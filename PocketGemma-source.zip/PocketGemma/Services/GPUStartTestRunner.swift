import Foundation
import LiteRTLM
import PocketCore
import os

/// The developer GPU start test (GPUStartTest): Qwen started once on the GPU
/// through the official Swift API, at the chosen precision, answering one
/// fixed question. It never touches the chat's engine, saved settings or
/// history.
enum GPUStartTestRunner {
    /// GPU starts made in this launch. A failed start can keep its address
    /// space until the app quits, so the app allows one test per launch.
    private(set) static var startsThisLaunch = 0

    static func run(model: ModelSpec, precision: GPUPrecision) async throws -> String {
        guard GPUStartTest.modelIDs.contains(model.id), AppFiles.hasVerifiedModel(model) else {
            throw TestError.modelMissing
        }
        var settings = GenerationSettings()
        settings.backend = .gpu; settings.maxTokens = 4096; settings.maxOutputTokens = GPUStartTest.maxOutputTokens
        settings.topK = 1; settings.topP = 1; settings.temperature = 0
        settings.enableThinking = false; settings.enableSpeculativeDecoding = false
        let plan = InferenceEnginePlan(model: model, settings: settings, needsVision: false)
        var record = InferenceDiagnostic(plan: plan, imageCount: 0, settings: settings, backend: .gpu)
        record.inputPath = GPUStartTest.inputPath
        record.activationPrecision = precision.diagnosticLabel
        record.cacheIdentity = "gpu-start-test (fresh cache, removed afterwards)"
        record.engineWasReused = false; record.conversationWasReused = false
        // A fresh cache compiles the GPU programs as a first start does.
        let work = AppFiles.root.appendingPathComponent("GPUStartTest/\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: work) }
        let log = NativeLogCapture(includeInfo: true, keepsGPUMessages: true)
        let memory = InferenceMemoryCapture()
        let timedOut = OSAllocatedUnfairLock(initialState: false)
        startsThisLaunch += 1
        do {
            let reply = try await answer(model: model, precision: precision, cache: work, record: &record, timedOut: timedOut)
            guard !reply.isEmpty else { throw TestError.emptyReply }
            let named = reply.contains("東京") || reply.contains("东京")
            record.fixedQuestionAnswered = named; record.replyCharacters = reply.count
            // The engine and conversation are gone by now: this stage's
            // address space is what the start left mapped.
            record.advance("complete")
            record.result = "success"
            record.recordNativeLog(log?.finish()); record.recordMemory(memory.finish()); record.save()
            func span(_ from: String, _ to: String) -> String {
                guard let start = record.events.first(where: { $0.stage == from })?.elapsedSeconds,
                      let end = record.events.first(where: { $0.stage == to })?.elapsedSeconds else { return "不明" }
                return String(format: "%.1f秒", end - start)
            }
            return """
            成功：\(model.name)がGPU（\(precision.title)）で起動し、回答しました。
            起動\(span("engine_initialization", "conversation_creation"))・回答\(span("text_generation", "complete"))・\(named ? "東京と回答" : "東京以外の回答")
            回答：\(reply)
            次の試験の前に、アプリを完全に終了して開き直してください。
            """
        } catch {
            let timeout = timedOut.withLock { $0 }
            record.result = timeout ? "timeout" : "failed"
            record.nativeError = InferenceDiagnostic.sanitize(error.localizedDescription)
            record.failureKind = NativeFailureKind(description: error.localizedDescription)
            record.availableMemoryAtFailure = UInt64(os_proc_available_memory())
            record.recordFailureAddressSpace()
            record.recordNativeLog(log?.finish(), error: record.nativeError ?? "")
            record.recordMemory(memory.finish()); record.save()
            throw TestError.failed(stage: record.stage,
                                   cause: timeout ? TestError.timeout.localizedDescription : error.localizedDescription)
        }
    }

    /// Starts the engine and asks the question. Both are released when this
    /// returns or throws, before the caller records what stayed mapped.
    private static func answer(model: ModelSpec, precision: GPUPrecision, cache: URL,
                               record: inout InferenceDiagnostic, timedOut: OSAllocatedUnfairLock<Bool>) async throws -> String {
        let config = try EngineConfig(modelPath: AppFiles.model(model).path, backend: .gpu,
                                      maxNumTokens: 4096, cacheDir: cache.path,
                                      activationDataType: precision.activationDataType)
        // Process-global; the chat sets its own before each engine it builds.
        ExperimentalFlags.optIntoExperimentalAPIs()
        ExperimentalFlags.visualTokenBudget = nil
        ExperimentalFlags.enableSpeculativeDecoding = false
        let engine = Engine(engineConfig: config)
        record.advance("engine_initialization")
        try await engine.initialize()
        record.advance("conversation_creation")
        let conversation = try await engine.createConversation(with: ConversationConfig(
            samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, enableSpeculativeDecoding: false))
        record.advance("text_generation")
        // A GPU that answers this slowly is a result too; stop it rather than
        // hold the test open.
        let watchdog = Task { [weak conversation] in
            try await Task.sleep(for: .seconds(GPUStartTest.replySeconds))
            timedOut.withLock { $0 = true }
            try? conversation?.cancel()
        }
        defer { watchdog.cancel() }
        let response = try await conversation.sendMessage(Message(GPUStartTest.question),
                                                          maxOutputTokens: GPUStartTest.maxOutputTokens)
        if timedOut.withLock({ $0 }) { throw TestError.timeout }
        return response.toString
    }

    private enum TestError: LocalizedError {
        case modelMissing, timeout, emptyReply
        case failed(stage: String, cause: String)
        var errorDescription: String? {
            switch self {
            case .modelMissing: return "試験するQwen3 0.6BまたはQwen2.5 1.5Bを先にインストールしてください。"
            case .timeout: return "回答が\(Int(GPUStartTest.replySeconds))秒以内に終わらなかったため止めました。"
            case .emptyReply: return "GPUで起動しましたが、回答が空でした。"
            case .failed(let stage, let cause):
                return "処理段階: \(stage)\n\(cause)\n次の試験やチャットの前に、アプリを完全に終了して開き直してください。"
            }
        }
    }
}
