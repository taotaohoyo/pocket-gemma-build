import Foundation
import PocketCore
#if canImport(PocketLlama)
import PocketLlama
#endif

/// LFM3 1.7B's replies on llama.cpp (1.1.0 (232)), for GemmaService: the
/// model loaded for one plan (the GPU on screen, the CPU in the background,
/// where iOS refuses the GPU), one reply at a time on a thread of its own,
/// its events in order, and stop from the service at any point, the load
/// included. LFM3-VL 2B's replies too (234), its picture projector loaded
/// with it on the same processor, and LFM3-Omni 2B's (236), whose projector
/// also hears a recording. Only the device app links llama.cpp: its
/// framework has no simulator slice, so the simulator's build says so instead.
final class LlamaReply: @unchecked Sendable {
    enum Event: Sendable {
        /// The prompt is read: its tokens, those the context already held,
        /// and the seconds it took.
        case prefilled(tokens: Int, reused: Int, seconds: Double)
        /// A token of the thought, which is never shown.
        case thought
        case answer(String)
        case finished(Finished)
    }

    struct Request: Sendable {
        let system: String
        let turns: [LFM3Prompt.Turn]
        let question: String
        /// The question's photos and the earlier turns' (`turns`' pictures),
        /// as JPEG files, for LFM3-VL 2B; LFM3-Omni 2B's recordings among
        /// them as WAV files (236).
        var questionPictures: [Data] = []
        var turnPictures: [Data] = []
        /// A stopped reply to go on from (OpenTurn's tail).
        let reply: String?
        let thinkingBudget: Int
        let inputTokenLimit: Int
        let settings: GenerationSettings
    }

    struct Finished: Sendable {
        let answer: String
        let cancelled: Bool
        let looped: Bool
        /// For the diagnostics: tokens, times and how the reply ended. Never
        /// the text.
        let note: String
    }

    /// The release the app links (Packages/PocketLlama).
    static let engineName = "llama.cpp b11960"
    let plan: InferenceEnginePlan
    /// min-p as each card gives it for llama.cpp: 0.05 for LFM3 1.7B, none
    /// for LFM3-VL 2B (1.1.0 (234)) and LFM3-Omni 2B (236).
    private var minP: Double { [ModelSpec.lfm3VL.id, ModelSpec.lfm3Omni.id].contains(plan.modelID) ? 0 : 0.05 }

    /// The chat as LFM3 reads it: the person's turns and the replies, text
    /// only, or with the person's photos (`pictures` names each message's,
    /// for LFM3-VL 2B).
    static func turns(_ history: [ChatMessage], pictures: (ChatMessage) -> Int = { _ in 0 }) -> [LFM3Prompt.Turn] {
        history.map { LFM3Prompt.Turn($0.role == .user ? .user : .assistant, $0.text, pictures: $0.role == .user ? pictures($0) : 0) }
    }

    #if canImport(PocketLlama)
    private let signal = LlamaStop()
    /// One reply at a time on the engine, also when a stopped one is still
    /// ending on its thread.
    private let turn = DispatchSemaphore(value: 1)
    private var engine: LlamaEngine?
    private var vision: LlamaVision?

    init(plan: InferenceEnginePlan) { self.plan = plan }

    /// Loads the file for the plan, and the picture projector after it when
    /// the model has one; blocks a worker while it reads them, and ends
    /// early when stopped.
    func load(path: String, projector: String? = nil) async throws {
        let options = LlamaEngine.Options(contextTokens: plan.maxTokens, gpu: plan.backend == .gpu)
        let signal = signal
        signal.reset()
        do {
            (engine, vision) = try await Task.detached(priority: .userInitiated) { () throws -> (LlamaEngine, LlamaVision?) in
                let engine = try LlamaEngine(path: path, options: options, stop: signal)
                guard let projector, !signal.isStopped else { return (engine, nil) }
                return (engine, try LlamaVision(engine: engine, projector: projector))
            }.value
        } catch {
            if signal.isStopped { throw CancellationError() }
            throw LlamaFailure(error)
        }
        if signal.isStopped { throw CancellationError() }
    }

    var threads: Int { engine?.options.threads ?? LlamaEngine.defaultThreads }

    /// A recording (VoiceNote's WAV) among a request's pictures.
    static func isSound(_ data: Data) -> Bool {
        data.count >= 12 && data.prefix(4) == Data("RIFF".utf8) && data.dropFirst(8).prefix(4) == Data("WAVE".utf8)
    }

    func stop() { signal.stop() }

    /// The reply's events; the stream ends after `.finished`, or with the
    /// error that ended the reply. Drain it: the reply's thread holds the
    /// engine until then.
    func reply(_ request: Request) -> AsyncThrowingStream<Event, Error> {
        let signal = signal, turn = turn, engine = engine, vision = vision
        signal.reset()
        return AsyncThrowingStream { continuation in
            guard let engine else {
                continuation.finish(throwing: LlamaUnavailable())
                return
            }
            // A reply nobody reads any more stops; one that ended stays as it was.
            continuation.onTermination = { termination in
                if case .cancelled = termination { signal.stop() }
            }
            let settings = request.settings
            let chat = LFM3Chat(engine: engine, vision: vision)
            let chatRequest = LFM3Chat.Request(
                system: request.system, turns: request.turns, question: request.question,
                questionPictures: request.questionPictures, turnPictures: request.turnPictures, reply: request.reply,
                thinkingBudget: request.thinkingBudget, inputTokenLimit: request.inputTokenLimit,
                sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature, minP: minP))
            let thread = Thread {
                turn.wait()
                defer { turn.signal() }
                do {
                    let outcome = try chat.reply(chatRequest) { event in
                        switch event {
                        case .prefilled(let stats):
                            continuation.yield(.prefilled(tokens: stats.promptTokens, reused: stats.reusedTokens,
                                                          seconds: stats.prefillSeconds))
                        case .thought: continuation.yield(.thought)
                        case .answer(let text): continuation.yield(.answer(text))
                        }
                    }
                    continuation.yield(.finished(Finished(outcome, gpu: engine.options.gpu, threads: engine.options.threads)))
                    continuation.finish()
                } catch {
                    let heard = (chatRequest.questionPictures + chatRequest.turnPictures).contains(where: LlamaReply.isSound)
                    continuation.finish(throwing: LlamaFailure(error, sound: heard))
                }
            }
            thread.name = "LFM3 reply"
            thread.qualityOfService = .userInitiated
            thread.stackSize = 8 << 20
            thread.start()
        }
    }
    #else
    init(plan: InferenceEnginePlan) { self.plan = plan }
    func load(path: String, projector: String? = nil) async throws { throw LlamaUnavailable() }
    var threads: Int { 0 }
    func stop() {}
    func reply(_ request: Request) -> AsyncThrowingStream<Event, Error> {
        AsyncThrowingStream { $0.finish(throwing: LlamaUnavailable()) }
    }
    #endif
}

#if canImport(PocketLlama)
private extension LlamaReply.Finished {
    init(_ outcome: LFM3Chat.Outcome, gpu: Bool, threads: Int) {
        let stats = outcome.stats
        answer = outcome.answer
        cancelled = stats.ending == .cancelled
        looped = outcome.looped
        let read = stats.promptTokens - stats.reusedTokens
        let pictures = outcome.pictures
        note = String(format: "%@ %@ · 入力 %ldトークン（再利用 %ld）%.2f秒・%.0f/秒%@ · 出力 %ldトークン %.2f秒・%.1f/秒 · 思考 %ldトークン%@ · 省いた履歴 %ld · 終了 %@%@",
                      LlamaReply.engineName, gpu ? "GPU" : "CPU \(threads)スレッド", stats.promptTokens, stats.reusedTokens,
                      stats.prefillSeconds, Double(read) / max(0.001, stats.prefillSeconds),
                      pictures.count == 0 ? "" : String(format: "（うち写真・音声 %ld件 %ldトークン %.2f秒）", pictures.count, pictures.tokens, pictures.seconds),
                      stats.generatedTokens, stats.decodeSeconds, Double(stats.generatedTokens) / max(0.001, stats.decodeSeconds),
                      outcome.thoughtTokens, outcome.thoughtClosed ? "（上限で閉じた）" : "", outcome.droppedTurns,
                      stats.ending.rawValue, outcome.looped ? " · 繰り返しで止めた" : "")
    }
}

/// What the person reads when llama.cpp fails: the cause in their language,
/// llama.cpp's own words after it.
struct LlamaFailure: LocalizedError {
    let cause: Error
    /// A recording was among the request's media: a failure to read it
    /// speaks of the sound, not of a photo.
    var sound = false
    init(_ cause: Error, sound: Bool = false) { self.cause = cause; self.sound = sound }
    var errorDescription: String? {
        let detail = cause.localizedDescription
        switch cause as? LlamaEngine.Failure {
        case .tooLong?:
            return String(localized: "質問が長すぎて、このモデルでは読み切れません。短くして送ってください。") + "\n" + detail
        case .load?, .context?:
            return String(localized: "モデルを読み込めませんでした。アプリを一度完全に終了してから開き直してください。") + "\n" + detail
        default:
            switch cause as? LlamaVision.Failure {
            case .projector?:
                return String(localized: "モデルを読み込めませんでした。アプリを一度完全に終了してから開き直してください。") + "\n" + detail
            case .some:
                if sound { return String(localized: "写真か音声を読み込めませんでした。もう一度録音するか、もう一度送ってください。") + "\n" + detail }
                return String(localized: "写真を読み込めませんでした。別の写真で試すか、もう一度送ってください。") + "\n" + detail
            case nil:
                break
            }
            return String(localized: "返信を書く処理が止まりました。もう一度送ってください。") + "\n" + detail
        }
    }
}
#endif

/// The simulator's build, without llama.cpp. Not shown on a device.
struct LlamaUnavailable: LocalizedError {
    var errorDescription: String? { "このビルドには llama.cpp が入っていないため、LFM3 のモデルを使えません。" }
}
