import ActivityKit
import BackgroundTasks
import UIKit
import PocketCore

/// While a model downloads: a Live Activity in the Dynamic Island and on the
/// Lock Screen (the model's mark on the left, the percentage on the right),
/// and a continued-processing task so the app keeps running, and the figure
/// keeps moving, after it goes to the background. Without that task iOS
/// suspends the app within seconds; the download itself still finishes in
/// the background session, but nothing could update the island.
@MainActor
final class DownloadActivity {
    /// The person stopped the download from the system's own progress display.
    var onStoppedBySystem: () -> Void = {}
    private var activity: Activity<ModelDownloadAttributes>?
    private var model: ModelSpec?
    private var fraction = 0.0
    private var shownPercent = -1
    private var continued: BGContinuedProcessingTask?
    private var fallbackTask: UIBackgroundTaskIdentifier = .invalid

    /// One identifier per download: the Info.plist permits them with a
    /// wildcard, and registering the same identifier twice ends the app.
    /// AltStore may add a team suffix to the bundle identifier, so the
    /// Info.plist also permits any identifier below the original one.
    private func newTaskIdentifier() -> String {
        (Bundle.main.bundleIdentifier ?? "app.pocketgemma.personal") + ".model-download." + UUID().uuidString
    }

    /// Only a download the person just started may ask to keep running in
    /// the background; one restored at launch only shows its activity.
    func begin(_ spec: ModelSpec, fraction: Double = 0, userInitiated: Bool) {
        model = spec
        self.fraction = fraction
        startActivity(spec)
        if userInitiated { keepRunning(spec) }
    }

    func update(_ fraction: Double) {
        guard model != nil else { return }
        self.fraction = fraction
        continued?.progress.completedUnitCount = Int64(fraction * 990)
        let state = ModelDownloadAttributes.ContentState(fraction: fraction, phase: .downloading)
        guard state.percent != shownPercent else { return }
        shownPercent = state.percent
        if let continued { continued.updateTitle(continued.title, subtitle: "\(state.percent)%") }
        push(state)
    }

    func verifying() {
        guard model != nil else { return }
        continued?.progress.completedUnitCount = 990
        push(.init(fraction: 1, phase: .verifying))
    }

    enum Outcome { case installed, failed, cancelled }

    func finish(_ outcome: Outcome) {
        if let activity {
            let state = ModelDownloadAttributes.ContentState(fraction: outcome == .installed ? 1 : fraction,
                                                             phase: outcome == .installed ? .finished : .failed)
            let policy: ActivityUIDismissalPolicy = switch outcome {
            case .installed: .after(.now.addingTimeInterval(8))
            case .failed: .after(.now.addingTimeInterval(30))
            case .cancelled: .immediate
            }
            Task { await activity.end(ActivityContent(state: state, staleDate: nil), dismissalPolicy: policy) }
        }
        activity = nil
        model = nil
        shownPercent = -1
        if let continued {
            if outcome == .installed { continued.progress.completedUnitCount = continued.progress.totalUnitCount }
            continued.setTaskCompleted(success: outcome == .installed)
        }
        continued = nil
        endFallback()
    }

    private func startActivity(_ spec: ModelSpec) {
        let running = Activity<ModelDownloadAttributes>.activities
        // A download restored at launch keeps the activity it already has.
        activity = running.first { $0.attributes.modelID == spec.id && $0.activityState == .active }
        for other in running where other.id != activity?.id {
            Task { await other.end(nil, dismissalPolicy: .immediate) }
        }
        let state = ModelDownloadAttributes.ContentState(fraction: fraction, phase: .downloading)
        shownPercent = state.percent
        if let activity { push(state); return }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        let attributes = ModelDownloadAttributes(modelID: spec.id, modelName: spec.name,
                                                 showsGemmaLogo: spec.family == "Gemma",
                                                 symbol: ModelMark(model: spec).symbol)
        // Requesting fails while the app is in the background, for example
        // when iOS launches it to finish a download; that is fine.
        activity = try? Activity.request(attributes: attributes,
                                         content: ActivityContent(state: state, staleDate: nil, relevanceScore: 100))
    }

    private func push(_ state: ModelDownloadAttributes.ContentState) {
        guard let activity else { return }
        Task { await activity.update(ActivityContent(state: state, staleDate: nil, relevanceScore: 100)) }
    }

    private func keepRunning(_ spec: ModelSpec) {
        let identifier = newTaskIdentifier()
        let registered = BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: .main) { [weak self] task in
            MainActor.assumeIsolated {
                if let self { self.adopt(task) } else { task.setTaskCompleted(success: false) }
            }
        }
        guard registered else { startFallback(); return }
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: "\(spec.name)をダウンロード",
                                                       subtitle: "\(Int(fraction * 100))%")
        request.strategy = .fail
        do { try BGTaskScheduler.shared.submit(request) } catch { startFallback() }
    }

    private func adopt(_ task: BGTask) {
        // The download may already be over by the time the task starts.
        guard let task = task as? BGContinuedProcessingTask, model != nil else {
            task.setTaskCompleted(success: model == nil)
            return
        }
        continued = task
        task.progress.totalUnitCount = 1000
        task.progress.completedUnitCount = Int64(fraction * 990)
        task.expirationHandler = { [weak self] in
            Task { @MainActor in self?.expired() }
        }
        endFallback()
    }

    /// The system ends the task when the person stops it from its progress
    /// display, which means stopping the download.
    private func expired() {
        guard let continued else { return }
        continued.setTaskCompleted(success: false)
        self.continued = nil
        onStoppedBySystem()
    }

    /// Without a continued-processing task: the usual short background time.
    private func startFallback() {
        guard fallbackTask == .invalid else { return }
        fallbackTask = UIApplication.shared.beginBackgroundTask(withName: "model-download") { [weak self] in
            MainActor.assumeIsolated { self?.endFallback() }
        }
    }

    private func endFallback() {
        guard fallbackTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(fallbackTask)
        fallbackTask = .invalid
    }
}
