import ActivityKit
import UIKit
import PocketCore

/// While models download: a Live Activity in the Dynamic Island and on the
/// Lock Screen (the model's mark on the left, the percentage on the right).
/// iOS shows only one activity of an app in the island, so every download
/// shares one activity; with two, each side of the island shows one model.
///
/// No continued-processing task: iOS would add its own progress display next
/// to this one, which apps cannot hide. Instead the app keeps itself running
/// with a silent sound (`BackgroundKeepAlive`) until every download is
/// checked, so the figure keeps moving after the app leaves the screen. If
/// iOS stops the sound and does not let it start again, the usual background
/// time is left; then the figure waits, while the background session still
/// finishes the file, and catches up when the app runs again.
@MainActor
final class DownloadActivity {
    private typealias Download = ModelDownloadAttributes.Download
    private var activity: Activity<ModelDownloadAttributes>?
    /// Every download under way, in the order they started.
    private var downloads: [Download] = []
    private var shown: [Download] = []
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var updateCount = 0

    /// For the download record: updates sent since the last call.
    func takeUpdateCount() -> Int {
        defer { updateCount = 0 }
        return updateCount
    }

    var stateText: String {
        guard let activity else { return "なし" }
        return switch activity.activityState {
        case .active: "表示中"
        case .stale: "古い表示"
        case .ended: "終了"
        case .dismissed: "閉じられた"
        case .pending: "準備中"
        @unknown default: "不明"
        }
    }

    func begin(_ spec: ModelSpec, fraction: Double) {
        set(spec, fraction: fraction, phase: .downloading)
        holdBackgroundTime()
    }

    func update(_ spec: ModelSpec, fraction: Double) {
        guard downloads.contains(where: { $0.modelID == spec.id }) else { return }
        set(spec, fraction: fraction, phase: .downloading)
    }

    func verifying(_ spec: ModelSpec) {
        set(spec, fraction: 1, phase: .verifying)
        // Checking a file can follow a download that finished while the app
        // was not running.
        holdBackgroundTime()
    }

    enum Outcome { case installed, failed, cancelled }

    func finish(_ spec: ModelSpec, _ outcome: Outcome) {
        guard let index = downloads.firstIndex(where: { $0.modelID == spec.id }) else { return }
        var last = downloads.remove(at: index)
        // Another model is still downloading: the island goes on with it.
        guard downloads.isEmpty else { push(); return }
        if let activity {
            if outcome == .installed { last.fraction = 1 }
            last.phase = outcome == .installed ? .finished : .failed
            let state = ModelDownloadAttributes.ContentState(fraction: last.fraction, phase: last.phase, downloads: [last])
            let policy: ActivityUIDismissalPolicy = switch outcome {
            case .installed: .after(.now.addingTimeInterval(8))
            case .failed: .after(.now.addingTimeInterval(30))
            case .cancelled: .immediate
            }
            Task { await activity.end(ActivityContent(state: state, staleDate: nil), dismissalPolicy: policy) }
        }
        activity = nil
        shown = []
        releaseBackgroundTime()
    }

    /// At launch: forgets downloads that no longer run, and ends the
    /// activity when none do.
    func endAll(except running: Set<String>) {
        downloads.removeAll { !running.contains($0.modelID) }
        for other in Activity<ModelDownloadAttributes>.activities where other.id != activity?.id || downloads.isEmpty {
            Task { await other.end(nil, dismissalPolicy: .immediate) }
        }
        if downloads.isEmpty {
            activity = nil
            shown = []
            releaseBackgroundTime()
        } else { push() }
    }

    private func set(_ spec: ModelSpec, fraction: Double, phase: ModelDownloadAttributes.Phase) {
        if let index = downloads.firstIndex(where: { $0.modelID == spec.id }) {
            downloads[index].fraction = fraction
            downloads[index].phase = phase
        } else {
            downloads.append(Download(modelID: spec.id, modelName: spec.name, showsGemmaLogo: spec.family == "Gemma",
                                      symbol: ModelMark(model: spec).symbol, fraction: fraction, phase: phase))
        }
        push()
    }

    /// Sends the downloads when a shown figure changes, starting the
    /// activity if there is none yet.
    private func push() {
        guard let first = downloads.first else { return }
        let changed = downloads.count != shown.count || zip(downloads, shown).contains {
            $0.modelID != $1.modelID || $0.percent != $1.percent || $0.phase != $1.phase
        }
        guard changed else { return }
        let state = ModelDownloadAttributes.ContentState(fraction: first.fraction, phase: first.phase, downloads: downloads)
        if activity == nil {
            // A download restored at launch keeps the activity it already has.
            activity = Activity<ModelDownloadAttributes>.activities.first { $0.activityState == .active }
            if activity == nil {
                guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
                let attributes = ModelDownloadAttributes(modelID: first.modelID, modelName: first.modelName,
                                                         showsGemmaLogo: first.showsGemmaLogo, symbol: first.symbol)
                // Requesting fails while the app is in the background, for
                // example when iOS launches it to finish a download; that is fine.
                do {
                    activity = try Activity.request(attributes: attributes,
                        content: ActivityContent(state: state, staleDate: nil, relevanceScore: 100))
                    shown = downloads
                } catch { DownloadLog.shared.note("島: 表示を始められない \(error.localizedDescription)") }
                return
            }
        }
        shown = downloads
        guard let activity else { return }
        updateCount += 1
        Task { await activity.update(ActivityContent(state: state, staleDate: nil, relevanceScore: 100)) }
    }

    private func holdBackgroundTime() {
        BackgroundKeepAlive.shared.start()
        guard backgroundTask == .invalid else { return }
        // The usual background time runs out long before a download ends;
        // the silent sound goes on.
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "model-download") { [weak self] in
            MainActor.assumeIsolated { self?.endBackgroundTask() }
        }
    }

    private func releaseBackgroundTime() {
        BackgroundKeepAlive.shared.stop()
        endBackgroundTask()
    }

    private func endBackgroundTask() {
        guard backgroundTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
    }
}
