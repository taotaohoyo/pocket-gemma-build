import ActivityKit
import BackgroundTasks
import UIKit
import PocketCore

/// While models download: a Live Activity in the Dynamic Island and on the
/// Lock Screen (the model's mark on the left, the percentage on the right),
/// and, for downloads the person starts, a continued-processing task.
/// iOS shows only one activity of an app in the island, so every download
/// shares one activity; with two, each side of the island shows one model.
///
/// iOS lets an app in the background update its activity only while it has
/// real background time. An app kept running by sound alone is refused:
/// 1.0.56-1.0.113 played silence, and the figure froze about 30 seconds
/// after the app left the screen, when the usual background time ran out.
/// The continued-processing task is that background time for as long as
/// the download runs. iOS shows its own progress display for it, which apps
/// cannot hide. With `mode` `.both` the app's activity stays next to it and
/// keeps updating (the island then shows both as small circles); with
/// `.systemOnly` it steps aside while the task runs. Either display only
/// ever shows figures the download really reached. Without the task (iOS
/// refused it, ended it, or the download was restored at launch) the app's
/// activity shows; once the usual background time is over its figure waits,
/// while the background session still finishes the file, and catches up
/// when the app runs again.
@MainActor
final class DownloadActivity {
    /// What shows while a download the person started runs in the background.
    /// iOS's display alone, as the person chose after seeing both on the
    /// phone (1.0.122): two displays only ever show as small circles.
    enum Mode { case systemOnly, both, ownOnly }
    static let mode: Mode = .systemOnly

    private typealias Download = ModelDownloadAttributes.Download
    private var activity: Activity<ModelDownloadAttributes>?
    /// Every download under way, in the order they started.
    private var downloads: [Download] = []
    private var shown: [Download] = []
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var updateCount = 0
    /// Updates go out one after another; the last one is awaited before
    /// iOS is told the app is done with a background launch.
    private var sending: Task<Void, Never>?
    private var continued: BGContinuedProcessingTask?
    private var continuedRequested = false
    /// What the continued task covers: each model's size and how far it got,
    /// kept until the task ends, so its progress never goes back when one of
    /// two downloads finishes.
    private var batch: [String: (bytes: Int64, fraction: Double)] = [:]
    private var continuedText = ""
    /// Each model's share received and checked, unrounded (1.1.0 (293)):
    /// the continued task's progress moves with them, at most once a second.
    private var exact: [String: Double] = [:]
    private var checked: [String: Double] = [:]
    private var lastAdvance: ContinuousClock.Instant?
    /// The longest time the continued task's progress did not move since
    /// the download record's last line, for the record.
    private var lastMove: ContinuousClock.Instant?
    private var longestStill: Duration = .zero
    /// Told when iOS ends the continued task (ModelStore hands over what the
    /// app receives itself).
    var continuedEnded: (() -> Void)?
    private var observer: NSObjectProtocol?
    /// A new figure goes out at most once a second; faster updates only
    /// cost battery. A download starting, being checked or ending goes out
    /// at once.
    private static let figureInterval: Duration = .seconds(1)
    private var lastPush: ContinuousClock.Instant?
    private var pushedPhases: [String] = []
    private var pushLater: Task<Void, Never>?

    init() {
        // The app's own activity can only start while the app is on screen.
        observer = NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification,
                                                          object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.push() }
        }
    }

    /// For the download record: updates sent since the last call.
    func takeUpdateCount() -> Int {
        defer { updateCount = 0 }
        return updateCount
    }

    var stateText: String {
        guard let activity else { return "なし" }
        return switch activity.activityState {
        case .active: "表示中"
        case .stale: "古い表示"
        case .ended: "終了"
        case .dismissed: "閉じられた"
        case .pending: "準備中"
        @unknown default: "不明"
        }
    }

    /// The continued-processing task keeps the app running now.
    var isContinuing: Bool { continued != nil }

    var continuedState: String {
        if continued != nil { return "実行中" }
        return continuedRequested ? "開始待ち" : "なし"
    }

    /// Only a download the person just started may ask to keep running in
    /// the background; one restored at launch only shows the app's activity.
    func begin(_ spec: ModelSpec, fraction: Double, userInitiated: Bool) {
        if userInitiated && Self.mode != .ownOnly { keepRunning(spec) }
        set(spec, fraction: fraction, phase: .downloading)
        holdBackgroundTime()
    }

    func update(_ spec: ModelSpec, fraction: Double) {
        guard downloads.contains(where: { $0.modelID == spec.id }) else { return }
        set(spec, fraction: fraction, phase: .downloading)
    }

    /// The model's share received, unrounded: the continued task's progress
    /// only (1.1.0 (293)). iOS takes a continued task whose progress has not
    /// moved for about 30 seconds for one that stopped and shows it as
    /// failed (Apple DTS, developer forums thread 805554, 2025). Until 292
    /// it moved with the cards' half percents: 18 MB of E4B, more than 30
    /// seconds below 0.6 MB/s.
    func advance(_ spec: ModelSpec, fraction: Double) {
        guard downloads.contains(where: { $0.modelID == spec.id }) else { return }
        exact[spec.id] = max(exact[spec.id] ?? 0, min(max(fraction, 0), 1))
        moveContinued()
    }

    /// How far the downloaded file's SHA-256 check got.
    func checking(_ spec: ModelSpec, fraction: Double) {
        guard downloads.contains(where: { $0.modelID == spec.id }) else { return }
        checked[spec.id] = min(max(fraction, 0), 1)
        moveContinued()
    }

    /// The longest still time of the continued task's progress since the
    /// last call, for the download record (only while it runs).
    func takeContinuedGap() -> String {
        defer { longestStill = .zero }
        guard continued != nil, longestStill > .zero else { return "" }
        return String(format: "（進みが最長%.0f秒止まった）", Double(longestStill.components.seconds))
    }

    func verifying(_ spec: ModelSpec) {
        set(spec, fraction: 1, phase: .verifying)
        // Checking a file can follow a download that finished while the app
        // was not running.
        holdBackgroundTime()
    }

    enum Outcome { case installed, failed, cancelled }

    func finish(_ spec: ModelSpec, _ outcome: Outcome) {
        guard let index = downloads.firstIndex(where: { $0.modelID == spec.id }) else { return }
        var last = downloads.remove(at: index)
        if outcome == .installed { batch[spec.id]?.fraction = 1 } else { batch[spec.id] = nil }
        // Another model is still downloading: the island goes on with it.
        guard downloads.isEmpty else { push(); return }
        if let activity {
            if outcome == .installed { last.fraction = 1 }
            last.phase = outcome == .installed ? .finished : .failed
            let state = ModelDownloadAttributes.ContentState(fraction: last.fraction, phase: last.phase, downloads: [last])
            let policy: ActivityUIDismissalPolicy = switch outcome {
            case .installed: .after(.now.addingTimeInterval(8))
            case .failed: .after(.now.addingTimeInterval(30))
            case .cancelled: .immediate
            }
            send { await activity.end(ActivityContent(state: state, staleDate: nil), dismissalPolicy: policy) }
        }
        activity = nil
        shown = []
        endContinued(success: outcome == .installed)
        releaseBackgroundTime()
    }

    /// At launch: forgets downloads that no longer run, and ends the
    /// activity when none do.
    func endAll(except running: Set<String>) {
        downloads.removeAll { !running.contains($0.modelID) }
        for other in Activity<ModelDownloadAttributes>.activities where other.id != activity?.id || downloads.isEmpty {
            Task { await other.end(nil, dismissalPolicy: .immediate) }
        }
        if downloads.isEmpty {
            activity = nil
            shown = []
            endContinued(success: false)
            releaseBackgroundTime()
        } else { push() }
    }

    /// Waits until the updates already asked for have gone out.
    func flush() async {
        await sending?.value
    }

    private func set(_ spec: ModelSpec, fraction: Double, phase: ModelDownloadAttributes.Phase) {
        if let index = downloads.firstIndex(where: { $0.modelID == spec.id }) {
            downloads[index].fraction = fraction
            downloads[index].phase = phase
        } else {
            downloads.append(Download(modelID: spec.id, modelName: spec.name, showsGemmaLogo: spec.family == "Gemma",
                                      symbol: ModelMark(model: spec).symbol, fraction: fraction, phase: phase,
                                      family: spec.family))
        }
        push()
    }

    /// While the continued task runs (or is being asked for) iOS shows its
    /// own display, and the app's would only repeat it.
    private var ownActivityStepsAside: Bool {
        Self.mode == .systemOnly && (continued != nil || continuedRequested)
    }

    /// Sends the downloads when a shown figure changes, starting the
    /// activity if there is none yet.
    private func push() {
        guard let first = downloads.first else { return }
        let phases = downloads.map { "\($0.modelID) \($0.phase)" }
        if phases == pushedPhases, let lastPush {
            let next = lastPush.advanced(by: Self.figureInterval)
            guard ContinuousClock.now >= next else {
                if pushLater == nil {
                    pushLater = Task { [weak self] in
                        try? await Task.sleep(until: next, clock: .continuous)
                        self?.pushLater = nil
                        self?.push()
                    }
                }
                return
            }
        }
        lastPush = .now
        pushedPhases = phases
        updateContinued()
        if ownActivityStepsAside { return }
        let changed = downloads.count != shown.count || zip(downloads, shown).contains {
            $0.modelID != $1.modelID || $0.percent != $1.percent || $0.phase != $1.phase
        }
        guard changed else { return }
        let state = ModelDownloadAttributes.ContentState(fraction: first.fraction, phase: first.phase, downloads: downloads)
        if activity == nil {
            // A download restored at launch keeps the activity it already has.
            activity = Activity<ModelDownloadAttributes>.activities.first { $0.activityState == .active }
            if activity == nil {
                guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
                // Requesting fails while the app is in the background, for
                // example when iOS launches it to finish a download; it starts
                // when the app comes back to the screen.
                guard UIApplication.shared.applicationState != .background else { return }
                let attributes = ModelDownloadAttributes(modelID: first.modelID, modelName: first.modelName,
                                                         showsGemmaLogo: first.showsGemmaLogo, symbol: first.symbol,
                                                         family: first.family)
                do {
                    activity = try Activity.request(attributes: attributes,
                        content: ActivityContent(state: state, staleDate: nil, relevanceScore: 100))
                    shown = downloads
                } catch { DownloadLog.shared.note("島: 表示を始められない \(error.localizedDescription)") }
                return
            }
        }
        shown = downloads
        guard let activity else { return }
        updateCount += 1
        send { await activity.update(ActivityContent(state: state, staleDate: nil, relevanceScore: 100)) }
    }

    private func send(_ work: @escaping @MainActor () async -> Void) {
        let previous = sending
        sending = Task {
            await previous?.value
            await work()
        }
    }

    private func endOwnActivity() {
        guard let activity else { return }
        self.activity = nil
        shown = []
        send { await activity.end(nil, dismissalPolicy: .immediate) }
    }

    // MARK: The continued-processing task

    /// One task covers every download the person starts while it runs.
    /// Each task needs an identifier of its own (registering one twice ends
    /// the app); the Info.plist permits them with a wildcard below the bundle
    /// identifier, which a re-signing installer may extend.
    private func keepRunning(_ spec: ModelSpec) {
        guard continued == nil, !continuedRequested else { return }
        let identifier = (Bundle.main.bundleIdentifier ?? "app.pocketgemma.personal") + ".model-download." + UUID().uuidString
        let registered = BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: .main) { [weak self] task in
            MainActor.assumeIsolated {
                if let self { self.adopt(task) } else { task.setTaskCompleted(success: false) }
            }
        }
        guard registered else {
            DownloadLog.shared.note("続ける作業: 登録できない")
            return
        }
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: String(localized: "\(spec.name)をダウンロード"),
                                                       subtitle: "0%")
        // Now or not at all: a download that waits for its task would leave
        // nothing on screen.
        request.strategy = .fail
        do {
            try BGTaskScheduler.shared.submit(request)
            continuedRequested = true
            DownloadLog.shared.note("続ける作業: 申し込んだ")
        } catch {
            DownloadLog.shared.note("続ける作業: 断られた \((error as NSError).code)")
            return
        }
        // iOS usually starts the task at once, but may not start it at all.
        // The request is withdrawn then (1.1.0 (240)): started late, next to
        // a newer one, it would end at once as a second task, and iOS shows
        // a task that ends that way as one that failed.
        Task {
            try? await Task.sleep(for: .seconds(5))
            guard continuedRequested, continued == nil else { return }
            continuedRequested = false
            BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: identifier)
            DownloadLog.shared.note("続ける作業: 5秒たっても始まらない")
            push()
        }
    }

    /// At most once a second, the continued task's figure from the
    /// unrounded shares; title and subtitle stay with `push`.
    private func moveContinued() {
        guard continued != nil else { return }
        if let lastAdvance, ContinuousClock.now < lastAdvance.advanced(by: Self.figureInterval) { return }
        lastAdvance = .now
        updateContinuedProgress()
    }

    private func adopt(_ task: BGTask) {
        continuedRequested = false
        // The downloads may be over by the time the task starts.
        guard let task = task as? BGContinuedProcessingTask, !downloads.isEmpty, continued == nil else {
            task.setTaskCompleted(success: downloads.isEmpty)
            return
        }
        continued = task
        continuedText = ""
        lastMove = .now
        longestStill = .zero
        // A unit is a hundred-thousandth: 37 KB of E4B (1.1.0 (293)).
        task.progress.totalUnitCount = Self.units
        task.expirationHandler = { [weak self] in
            Task { @MainActor in self?.continuedExpired() }
        }
        DownloadLog.shared.note("続ける作業: 始まった（\(DownloadLog.appState)）")
        if Self.mode == .systemOnly { endOwnActivity() }
        push()
    }

    /// iOS ended the task: the person stopped it from its display, or the
    /// system needed the resources. iOS does not say which, so the download
    /// is not cancelled; it goes on in the background session, and the
    /// app's own activity takes over (once the app is on screen).
    private func continuedExpired() {
        guard let continued else { return }
        let still = lastMove.map { ContinuousClock.now - $0 } ?? .zero
        continued.setTaskCompleted(success: false)
        self.continued = nil
        batch = [:]
        DownloadLog.shared.note("続ける作業: iOSが終えた（\(DownloadLog.appState)・進みが止まって\(still.components.seconds)秒）")
        continuedEnded?()
        push()
    }

    private func endContinued(success: Bool) {
        continuedRequested = false
        batch = [:]
        exact = [:]
        checked = [:]
        guard let continued else { return }
        if success { continued.progress.completedUnitCount = continued.progress.totalUnitCount }
        continued.setTaskCompleted(success: success)
        self.continued = nil
        DownloadLog.shared.note("続ける作業: 終えた（\(success ? "保存" : "保存なし")）")
    }

    private static let units: Int64 = 100_000

    /// The task's progress is the share of bytes its downloads reached,
    /// leaving the last 1% for checking the file; it never goes back.
    private func updateContinuedProgress() {
        guard let continued else { return }
        for download in downloads {
            let bytes = ModelSpec.find(download.modelID)?.downloadByteCount ?? 1
            let received = download.phase == .downloading ? max(download.fraction, exact[download.modelID] ?? 0) : 1
            let check = download.phase == .downloading ? 0 : checked[download.modelID] ?? 0
            batch[download.modelID] = (bytes, received * 0.99 + check * 0.01)
        }
        let total = batch.values.reduce(0) { $0 + Double($1.bytes) }
        let reached = batch.values.reduce(0) { $0 + Double($1.bytes) * min(max($1.fraction, 0), 1) }
        let completed = Int64(total > 0 ? reached / total * Double(Self.units) : 0)
        if completed > continued.progress.completedUnitCount {
            continued.progress.completedUnitCount = min(completed, Self.units - 1)
            if let lastMove { longestStill = max(longestStill, ContinuousClock.now - lastMove) }
            lastMove = .now
        }
    }

    /// The figure, the title and the subtitle.
    private func updateContinued() {
        guard let continued else { return }
        updateContinuedProgress()
        let title = downloads.count == 1 ? String(localized: "\(downloads[0].modelName)をダウンロード") : String(localized: "モデルをダウンロード")
        let subtitle = downloads.map { download in
            let figure = download.phase == .verifying ? String(localized: "確認中") : "\(download.percent)%"
            guard downloads.count == 1 else { return "\(download.modelName.replacingOccurrences(of: "Gemma 4 ", with: "")) \(figure)" }
            guard download.phase == .downloading, let spec = ModelSpec.find(download.modelID) else { return figure }
            let received = ByteCountFormatter.string(fromByteCount: Int64(Double(spec.downloadByteCount) * download.fraction), countStyle: .decimal)
            return "\(figure) · \(received) / \(spec.sizeLabel)"
        }.joined(separator: " · ")
        guard title + subtitle != continuedText else { return }
        continuedText = title + subtitle
        continued.updateTitle(title, subtitle: subtitle)
    }

    // MARK: Background time

    private func holdBackgroundTime() {
        guard backgroundTask == .invalid else { return }
        // About 30 seconds after the app leaves the screen, unless the
        // continued task keeps it running.
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "model-download") { [weak self] in
            MainActor.assumeIsolated { self?.endBackgroundTask() }
        }
    }

    private func releaseBackgroundTime() {
        endBackgroundTask()
    }

    private func endBackgroundTask() {
        guard backgroundTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
    }
}
