import ActivityKit
import UIKit
import PocketCore

/// While models download: one Live Activity per model in the Dynamic Island
/// and on the Lock Screen (the model's mark on the left, the percentage on
/// the right). iOS shows two of them side by side in the island.
///
/// No continued-processing task: iOS would add its own progress display next
/// to these, which apps cannot hide. Instead the app asks for the usual
/// background time, so the figure keeps moving for a while after the app
/// leaves the screen; after that iOS suspends it and the figure waits, while
/// the background session still finishes the file, and catches up when the
/// app runs again.
@MainActor
final class DownloadActivity {
    private var activities: [String: Activity<ModelDownloadAttributes>] = [:]
    private var fractions: [String: Double] = [:]
    private var shownPercent: [String: Int] = [:]
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid

    func begin(_ spec: ModelSpec, fraction: Double) {
        fractions[spec.id] = fraction
        let state = ModelDownloadAttributes.ContentState(fraction: fraction, phase: .downloading)
        shownPercent[spec.id] = state.percent
        // A download restored at launch keeps the activity it already has.
        if let running = Activity<ModelDownloadAttributes>.activities.first(where: {
            $0.attributes.modelID == spec.id && $0.activityState == .active
        }) {
            activities[spec.id] = running
            push(spec.id, state)
        } else if ActivityAuthorizationInfo().areActivitiesEnabled {
            let attributes = ModelDownloadAttributes(modelID: spec.id, modelName: spec.name,
                                                     showsGemmaLogo: spec.family == "Gemma",
                                                     symbol: ModelMark(model: spec).symbol)
            // Requesting fails while the app is in the background, for example
            // when iOS launches it to finish a download; that is fine.
            activities[spec.id] = try? Activity.request(attributes: attributes,
                content: ActivityContent(state: state, staleDate: nil, relevanceScore: 100))
        }
        holdBackgroundTime()
    }

    func update(_ spec: ModelSpec, fraction: Double) {
        guard fractions[spec.id] != nil else { return }
        fractions[spec.id] = fraction
        let state = ModelDownloadAttributes.ContentState(fraction: fraction, phase: .downloading)
        guard state.percent != shownPercent[spec.id] else { return }
        shownPercent[spec.id] = state.percent
        push(spec.id, state)
    }

    func verifying(_ spec: ModelSpec) {
        fractions[spec.id] = 1
        push(spec.id, .init(fraction: 1, phase: .verifying))
    }

    enum Outcome { case installed, failed, cancelled }

    func finish(_ spec: ModelSpec, _ outcome: Outcome) {
        if let activity = activities[spec.id] {
            let state = ModelDownloadAttributes.ContentState(fraction: outcome == .installed ? 1 : fractions[spec.id] ?? 0,
                                                             phase: outcome == .installed ? .finished : .failed)
            let policy: ActivityUIDismissalPolicy = switch outcome {
            case .installed: .after(.now.addingTimeInterval(8))
            case .failed: .after(.now.addingTimeInterval(30))
            case .cancelled: .immediate
            }
            Task { await activity.end(ActivityContent(state: state, staleDate: nil), dismissalPolicy: policy) }
        }
        activities[spec.id] = nil
        fractions[spec.id] = nil
        shownPercent[spec.id] = nil
        if fractions.isEmpty { releaseBackgroundTime() }
    }

    /// At launch: ends activities left over from downloads that no longer run.
    func endAll(except running: Set<String>) {
        for activity in Activity<ModelDownloadAttributes>.activities where !running.contains(activity.attributes.modelID) {
            Task { await activity.end(nil, dismissalPolicy: .immediate) }
        }
        for id in activities.keys where !running.contains(id) {
            activities[id] = nil
            fractions[id] = nil
            shownPercent[id] = nil
        }
        if fractions.isEmpty { releaseBackgroundTime() }
    }

    private func push(_ id: String, _ state: ModelDownloadAttributes.ContentState) {
        // A file checked at launch keeps the activity its download had.
        if activities[id] == nil {
            activities[id] = Activity<ModelDownloadAttributes>.activities.first {
                $0.attributes.modelID == id && $0.activityState == .active
            }
        }
        guard let activity = activities[id] else { return }
        Task { await activity.update(ActivityContent(state: state, staleDate: nil, relevanceScore: 100)) }
    }

    private func holdBackgroundTime() {
        guard backgroundTask == .invalid else { return }
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "model-download") { [weak self] in
            MainActor.assumeIsolated { self?.releaseBackgroundTime() }
        }
    }

    private func releaseBackgroundTime() {
        guard backgroundTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
    }
}
