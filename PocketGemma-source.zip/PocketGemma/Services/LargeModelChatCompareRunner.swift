import Foundation
import LiteRTLM
import PocketCore
import os

/// 開発者設定's 12B comparison (LargeModelChatCompare): each engine starts
/// the 12B file on the GPU the way GemmaService starts the chat's, with the
/// engine's context, benchmark mode and precision, and answers its prompts.
/// GemmaService releases the chat's model first. Every engine has a cache
/// folder of its own, removed after it (E reads D's), so their gigabytes
/// don't stay; the limits are checked before every start.
enum LargeModelChatCompareRunner {
    static func run(settings: GenerationSettings) async -> LargeModelChatCompare.Record {
        let log = LargeModelProbeFiles.compareLog
        let spec = LargeModelProbe.model
        let settings = settings.normalized(for: spec)
        var record = LargeModelChatCompare.Record()
        let info = Bundle.main.infoDictionary
        record.appVersion = "\(info?["CFBundleShortVersionString"] as? String ?? "?") (\(info?["CFBundleVersion"] as? String ?? "?"))"
        record.device = DeviceOverview.identifier
        record.chatSettings = "TopK \(settings.topK) · TopP \(settings.topP) · Temperature \(settings.temperature) · システムプロンプト\(settings.usesDefaultSystemPrompt ? "は既定" : "は自分で設定したもの")"
        // A run iOS ended left its cache behind.
        let caches = LargeModelProbeFiles.compareCache
        try? FileManager.default.removeItem(at: caches)
        defer { try? FileManager.default.removeItem(at: caches) }
        var previous: URL?
        for engine in LargeModelChatCompare.engines {
            // Only the next engine may read a cache; any other goes first,
            // so two caches never need the disk at once.
            if !engine.reusesCache, let previous { try? FileManager.default.removeItem(at: previous) }
            let cache = engine.reusesCache ? previous : caches.appendingPathComponent(engine.id, isDirectory: true)
            #if targetEnvironment(simulator)
            let available: UInt64? = nil
            #else
            let available: UInt64? = UInt64(os_proc_available_memory())
            #endif
            let blockers = LargeModelProbe.blockers(fileReady: LargeModelProbeFiles.isReady, ranThisLaunch: false,
                                                    largestFreeAddress: AddressSpace.current()?.largestFree, availableMemory: available,
                                                    freeDisk: DeviceOverview.freeDiskBytes,
                                                    cacheBytes: engine.reusesCache ? spec.byteCount : 0)
            guard blockers.isEmpty, let cache else {
                record.failures.append("\(engine.title): 開始前に止めました。" + blockers.map(\.message).joined(separator: " "))
                break
            }
            record.running = engine.id
            log.save(record)
            do {
                try await answer(engine, cache: cache, settings: settings, record: &record, log: log)
            } catch {
                record.failures.append("\(engine.title): 失敗 " + InferenceDiagnostic.sanitize(error.localizedDescription))
            }
            previous = cache
        }
        record.running = ""
        record.finished = true
        log.save(record)
        return record
    }

    /// Starts one engine and asks its prompts. The engine and its
    /// conversations are released when this returns or throws.
    private static func answer(_ engine: LargeModelChatCompare.Engine, cache: URL, settings: GenerationSettings,
                               record: inout LargeModelChatCompare.Record, log: LargeModelChatCompare.Log) async throws {
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        // The chat's engine for a text turn (GemmaService.prepareEngine).
        let config = try EngineConfig(modelPath: LargeModelProbeFiles.model.path, backend: .gpu,
                                      visionBackend: nil, audioBackend: nil,
                                      maxNumTokens: engine.context, cacheDir: cache.path,
                                      activationDataType: engine.float32 ? .float32 : nil,
                                      visionCpuKernelMode: .xnnpack)
        let native = Engine(engineConfig: config)
        ExperimentalFlags.optIntoExperimentalAPIs()
        ExperimentalFlags.visualTokenBudget = nil
        ExperimentalFlags.enableSpeculativeDecoding = false
        ExperimentalFlags.enableBenchmark = engine.benchmark
        defer { ExperimentalFlags.enableBenchmark = false }
        let loadStart = Date()
        try await native.initialize()
        let load = Date().timeIntervalSince(loadStart)
        for prompt in engine.prompts {
            let config: ConversationConfig
            switch prompt {
            case .chat:
                // As GemmaService.perform's first turn of a new chat.
                config = ConversationConfig(
                    systemMessage: Message(settings.systemMessage(for: LargeModelProbe.model), role: .system),
                    initialMessages: [], tools: [],
                    samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
                    thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
                    automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
                    enableSpeculativeDecoding: false)
            case .check:
                // As LargeModelProbeRunner's.
                config = ConversationConfig(
                    samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
                    thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
                    automaticToolCalling: false, enableSpeculativeDecoding: false)
            }
            let conversation = try await native.createConversation(with: config)
            let watchdog = Task { [weak conversation] in
                try await Task.sleep(for: .seconds(LargeModelChatCompare.replySeconds))
                try? conversation?.cancel()
            }
            let sent = Date()
            var reply = "", pieces = 0
            do {
                for try await part in conversation.sendMessageStream(Message(prompt.text),
                                                                      maxOutputTokens: LargeModelChatCompare.maxOutputTokens) {
                    pieces += 1
                    reply += part.toString
                }
            } catch {
                watchdog.cancel()
                throw error
            }
            watchdog.cancel()
            record.results.append(LargeModelChatCompare.Result(engine: engine.id, prompt: prompt, reply: reply, loadSeconds: load,
                                                               replySeconds: Date().timeIntervalSince(sent), pieces: pieces))
            log.save(record)
            // Let the final native callback return before the conversation goes.
            try await Task.sleep(for: .milliseconds(200))
        }
    }
}
