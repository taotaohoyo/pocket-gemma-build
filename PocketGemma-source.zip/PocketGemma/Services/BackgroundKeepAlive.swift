import AVFoundation

/// Keeps the app running in the background while a model downloads, so the
/// figure in the Dynamic Island keeps moving instead of stopping about 30
/// seconds after the app leaves the screen, when iOS would suspend it.
///
/// It plays silence through an audio session that mixes with other apps:
/// their music keeps playing at full volume, and the app never shows as
/// playing in Control Center or the island. It starts with the download,
/// while the app is still on screen, because iOS may refuse to start audio
/// from the background.
@MainActor
final class BackgroundKeepAlive {
    static let shared = BackgroundKeepAlive()
    private var engine: AVAudioEngine?
    private var observers: [NSObjectProtocol] = []
    private(set) var isRunning = false
    /// Why the sound could not start, if it could not.
    private(set) var failure: String?

    func start() {
        guard !isRunning else { return }
        isRunning = true
        let center = NotificationCenter.default
        // A call or Siri stops the sound; it starts again afterwards. So does
        // a change of output (headphones) or a reset of the audio system.
        observers = [
            center.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
                let ended = (note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt)
                    .flatMap(AVAudioSession.InterruptionType.init(rawValue:)) == .ended
                let reason = (note.userInfo?[AVAudioSessionInterruptionReasonKey] as? UInt).map { " 理由\($0)" } ?? ""
                MainActor.assumeIsolated {
                    DownloadLog.shared.note(ended ? "無音の音声: 中断が終わった" : "無音の音声: 中断された\(reason)")
                    if ended { self?.resume() }
                }
            },
            center.addObserver(forName: AVAudioSession.mediaServicesWereResetNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated {
                    DownloadLog.shared.note("無音の音声: 音声の仕組みがリセットされた")
                    self?.play()
                }
            },
            center.addObserver(forName: .AVAudioEngineConfigurationChange, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated {
                    DownloadLog.shared.note("無音の音声: 出力が変わった")
                    self?.resume()
                }
            },
        ]
        play()
    }

    func stop() {
        guard isRunning else { return }
        DownloadLog.shared.note("無音の音声: 止めた")
        isRunning = false
        for observer in observers { NotificationCenter.default.removeObserver(observer) }
        observers = []
        engine?.stop()
        engine = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    /// Only a stopped sound is rebuilt, so starting it never loops.
    private func resume() {
        if engine?.isRunning != true { play() }
    }

    /// Checked while a download runs: starts the sound again if iOS stopped
    /// it without telling.
    func ensurePlaying() {
        guard isRunning, engine?.isRunning != true else { return }
        DownloadLog.shared.note("無音の音声: 止まっていた")
        play()
    }

    var state: String {
        guard isRunning else { return "なし" }
        return engine?.isRunning == true ? "再生中" : "停止中"
    }

    private func play() {
        guard isRunning else { return }
        engine?.stop()
        engine = nil
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
            let engine = AVAudioEngine()
            let silence = Self.silence()
            engine.attach(silence)
            engine.connect(silence, to: engine.mainMixerNode,
                           format: AVAudioFormat(standardFormatWithSampleRate: 48_000, channels: 1))
            try engine.start()
            self.engine = engine
            failure = nil
            DownloadLog.shared.note("無音の音声: 再生を始めた（\(DownloadLog.appState)）")
        } catch {
            // Without it the download still finishes; only the figure waits.
            failure = error.localizedDescription
            DownloadLog.shared.note("無音の音声: 始められない \((error as NSError).code) \(error.localizedDescription)")
        }
    }

    /// Built outside the main actor: the audio thread calls it.
    nonisolated private static func silence() -> AVAudioSourceNode {
        AVAudioSourceNode { _, _, _, audioBufferList in
            for buffer in UnsafeMutableAudioBufferListPointer(audioBufferList) {
                if let data = buffer.mData { memset(data, 0, Int(buffer.mDataByteSize)) }
            }
            return noErr
        }
    }
}
