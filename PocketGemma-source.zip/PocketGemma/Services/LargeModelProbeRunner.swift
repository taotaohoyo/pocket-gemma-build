import Foundation
import LiteRTLM
import PocketCore
import os

/// The developer 12B check (LargeModelProbe): Gemma 4 12B started once from
/// its own folder through the official Swift API, answering one fixed
/// question. It never touches the chat's engine, models folder, saved
/// settings or history; GemmaService releases the chat's model first. Its
/// limits are checked before the start and never raised or skipped.
enum LargeModelProbeRunner {
    /// Checks started in this launch. A failed start can keep its address
    /// space until the app quits, so the app allows one check per launch.
    private(set) static var runsThisLaunch = 0

    static func run(backend: LargeModelProbe.Backend) async -> LargeModelProbe.Record {
        let log = LargeModelProbeFiles.log
        var record = LargeModelProbe.Record(backend: backend)
        let info = Bundle.main.infoDictionary
        record.appVersion = "\(info?["CFBundleShortVersionString"] as? String ?? "?") (\(info?["CFBundleVersion"] as? String ?? "?"))"
        record.device = DeviceOverview.identifier
        record.entitlements = LaunchMemory.atLaunch.appEntitlements
        let start = AddressSpace.current()
        let available = UInt64(os_proc_available_memory())
        let freeDisk = DeviceOverview.freeDiskBytes
        record.availableMemoryAtStart = available
        record.largestFreeAddressAtStart = start?.largestFree
        record.freeDiskAtStart = freeDisk
        // The simulator runs the app as a Mac process with no iOS memory
        // limit to keep (os_proc_available_memory has nothing to report);
        // on a phone the memory requirement always applies.
        #if targetEnvironment(simulator)
        let limited: UInt64? = nil
        #else
        let limited: UInt64? = available
        #endif
        let blockers = LargeModelProbe.blockers(fileReady: LargeModelProbeFiles.isReady, ranThisLaunch: runsThisLaunch > 0,
                                                largestFreeAddress: start?.largestFree, availableMemory: limited,
                                                freeDisk: freeDisk, cacheBytes: LargeModelProbeFiles.cacheBytes(backend))
        guard blockers.isEmpty else {
            record.result = "blocked"
            record.failure = blockers.map(\.message).joined(separator: "\n")
            log.save(record)
            return record
        }
        runsThisLaunch += 1
        log.save(record)
        let mappedBefore = start.map { Int64($0.range - $0.free) }
        let memory = InferenceMemoryCapture()
        let native = NativeLogCapture(includeInfo: true, keepsGPUMessages: backend == .gpu)
        let timedOut = OSAllocatedUnfairLock(initialState: false)
        do {
            try await answer(backend: backend, record: &record, log: log, timedOut: timedOut)
            if timedOut.withLock({ $0 }) { throw ProbeError.timeout }
            record.result = "success"
        } catch {
            record.result = timedOut.withLock { $0 } ? "timeout" : "failed"
            record.failure = InferenceDiagnostic.sanitize(error.localizedDescription)
            record.failureKind = NativeFailureKind(description: error.localizedDescription).rawValue
        }
        // The engine and conversation are released by now: what stays mapped
        // is what the start left behind.
        record.nativeLines = (native?.finish().lines ?? []).suffix(30).map { String($0.prefix(300)) }
        let measured = memory.finish()
        record.peakFootprint = measured.peak
        record.lowestAvailableMemory = measured.minimum
        record.lowestLargestFreeAddress = measured.lowestAddress?.largestFree
        if let after = AddressSpace.current(), let mappedBefore {
            record.mappedAfterRelease = Int64(after.range - after.free) - mappedBefore
        }
        record.cacheBytes = LargeModelProbeFiles.cacheBytes(backend)
        if record.result == "success" { record.stage = "complete" }
        log.save(record)
        return record
    }

    /// Starts the engine and asks the question. Both are released when this
    /// returns or throws, before the caller records what stayed mapped.
    private static func answer(backend: LargeModelProbe.Backend, record: inout LargeModelProbe.Record,
                               log: LargeModelProbe.Log, timedOut: OSAllocatedUnfairLock<Bool>) async throws {
        let cache = LargeModelProbeFiles.cache(backend)
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        let config = try EngineConfig(modelPath: LargeModelProbeFiles.model.path,
                                      backend: backend == .gpu ? .gpu : .cpu(),
                                      maxNumTokens: LargeModelProbe.contextTokens, cacheDir: cache.path)
        // Process-global; the chat sets its own before each engine it builds.
        ExperimentalFlags.optIntoExperimentalAPIs()
        ExperimentalFlags.visualTokenBudget = nil
        ExperimentalFlags.enableSpeculativeDecoding = false
        ExperimentalFlags.enableBenchmark = true
        defer { ExperimentalFlags.enableBenchmark = false }
        let engine = Engine(engineConfig: config)
        record.stage = "engine_initialization"; log.save(record)
        let loadStart = Date()
        try await engine.initialize()
        record.initializationSeconds = Date().timeIntervalSince(loadStart)
        record.stage = "conversation_creation"; log.save(record)
        let conversation = try await engine.createConversation(with: ConversationConfig(
            samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, enableSpeculativeDecoding: false))
        record.stage = "text_generation"; log.save(record)
        let watchdog = Task { [weak conversation] in
            try await Task.sleep(for: .seconds(LargeModelProbe.replySeconds))
            timedOut.withLock { $0 = true }
            try? conversation?.cancel()
        }
        defer { watchdog.cancel() }
        let sent = Date()
        var reply = "", pieces = 0
        for try await part in conversation.sendMessageStream(Message(LargeModelProbe.question),
                                                              maxOutputTokens: LargeModelProbe.maxOutputTokens) {
            if pieces == 0 { record.firstTextSeconds = Date().timeIntervalSince(sent) }
            pieces += 1
            reply += part.toString
        }
        record.replySeconds = Date().timeIntervalSince(sent)
        record.replyPieces = pieces
        record.conversationTokens = try? conversation.getTokenCount()
        record.promptTokens = try? conversation.getBenchmarkInfo().lastPrefillTokenCount
        record.reply = String(reply.prefix(300))
        record.answeredTokyo = reply.contains("東京")
        record.stage = "release"
        if reply.isEmpty && !timedOut.withLock({ $0 }) { throw ProbeError.emptyReply }
    }

    private enum ProbeError: LocalizedError {
        case timeout, emptyReply
        var errorDescription: String? {
            switch self {
            case .timeout: return "回答が\(Int(LargeModelProbe.replySeconds))秒以内に終わらなかったため止めました。"
            case .emptyReply: return "起動しましたが、回答が空でした。"
            }
        }
    }
}
