import Foundation
import PocketCore

enum AppFiles {
    static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma", isDirectory: true)
    }
    /// Models live in Documents so they appear in the Files app under
    /// "On My iPhone › Fielua › Models" (UIFileSharingEnabled).
    static var models: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models", isDirectory: true)
    }
    /// Where 1.0.35 and earlier kept models, inside the hidden app container.
    static var legacyModels: URL { root.appendingPathComponent("Models", isDirectory: true) }
    /// Receipts and partial downloads stay hidden; same volume as Documents,
    /// so finishing a download is still a rename.
    static var modelState: URL { root.appendingPathComponent("ModelState", isDirectory: true) }
    static var library: ModelLibrary { ModelLibrary(directory: models, stateDirectory: modelState) }
    static func model(_ spec: ModelSpec) -> URL { library.modelURL(spec) }
    static func pendingModel(_ spec: ModelSpec) -> URL { library.pendingURL(spec) }
    static var archive: URL { root.appendingPathComponent("conversations.json") }

    /// Move models from the hidden container to Files (same volume, so this
    /// is a rename, not a copy) and drop Gemma 4 12B files that aren't a
    /// verified copy of its pinned file.
    static func migrateModels() {
        let manager = FileManager.default
        try? prepareModels()
        if let items = try? manager.contentsOfDirectory(at: legacyModels, includingPropertiesForKeys: nil) {
            for item in items {
                let isModel = item.pathExtension == "litertlm"
                let destination = (isModel ? models : modelState).appendingPathComponent(item.lastPathComponent)
                if manager.fileExists(atPath: destination.path) { continue }
                try? manager.moveItem(at: item, to: destination)
            }
            if (try? manager.contentsOfDirectory(atPath: legacyModels.path))?.isEmpty == true {
                try? manager.removeItem(at: legacyModels)
            }
        }
        // The 12B withdrawn in Oct 2026 may still be here. From 1.1.0 (200)
        // a verified copy of the pinned file stays, also while it is locked,
        // so unlocking again needs no new 6.9 GB download; a partial
        // download is ModelStore's while it is unlocked.
        let twelve = ModelSpec.gemma12B
        if !library.isInstalled(twelve) {
            try? manager.removeItem(at: library.receiptURL(twelve))
            try? manager.removeItem(at: library.modelURL(twelve))
        }
        if twelve.isLocked { try? manager.removeItem(at: library.pendingURL(twelve)) }
        for name in ["gemma-4-12B-it.litertlm", "gemma-4-12b.verified", "gemma-4-12b.pending"] {
            try? manager.removeItem(at: legacyModels.appendingPathComponent(name))
        }
    }

    static func prepareModels() throws {
        for folder in [models, modelState] {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            // Multi-GB weights are re-downloadable; keep them out of backups.
            var url = folder
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try url.setResourceValues(values)
        }
    }

    /// The engine caches built for a model, under every runtime's folder
    /// (InferenceEnginePlan.cacheComponent): useless once its file is gone,
    /// and 12B's GPU cache alone takes about 6 GB.
    static func removeEngineCaches(_ spec: ModelSpec) {
        let caches = root.appendingPathComponent("InferenceCache", isDirectory: true)
        for runtime in (try? FileManager.default.contentsOfDirectory(at: caches, includingPropertiesForKeys: nil)) ?? [] {
            try? FileManager.default.removeItem(at: runtime.appendingPathComponent(spec.sha256, isDirectory: true))
        }
    }

    static func hasVerifiedModel(_ spec: ModelSpec) -> Bool { library.isInstalled(spec) }
    static func installVerifiedModel(_ spec: ModelSpec) throws { try library.installValidated(spec) }
}

