import Foundation
import PocketCore

enum AppFiles {
    static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma", isDirectory: true)
    }
    /// Models live in the app's own Application Support since 1.1.0 (251),
    /// which the Files app does not show; Fielua alone downloads, imports,
    /// uses and deletes them. Until then they were in Documents/Models,
    /// shown in the Files app (UIFileSharingEnabled), from where
    /// `migrateStorage` moves them.
    static var models: URL { root.appendingPathComponent("ModelFiles", isDirectory: true) }
    /// Where 1.0.36 to 1.1.0 (250) kept models: Documents, which the Files
    /// app showed. Still read from while a file is left there.
    static var documentModels: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models", isDirectory: true)
    }
    /// Where 1.0.35 and earlier kept models, inside the hidden app container.
    static var legacyModels: URL { root.appendingPathComponent("Models", isDirectory: true) }
    /// Receipts and partial downloads stay hidden; the same volume as the
    /// models, so finishing a download is still a rename.
    static var modelState: URL { root.appendingPathComponent("ModelState", isDirectory: true) }
    static var library: ModelLibrary {
        ModelLibrary(directory: models, stateDirectory: modelState, fallbackDirectories: [documentModels, legacyModels])
    }
    static func model(_ spec: ModelSpec) -> URL { library.modelURL(spec) }
    static func pendingModel(_ spec: ModelSpec) -> URL { library.pendingURL(spec) }
    static var archive: URL { root.appendingPathComponent("conversations.json") }
    /// A deletion's attachment files still to remove (DeletionJournal).
    static var deletionJournal: URL { root.appendingPathComponent("deletion-journal.json") }
    /// What each launch's move into the private folders did, for the
    /// diagnostics and the report (newest last, at most 20).
    static var migrationRecord: URL { root.appendingPathComponent("storage-migration.json") }
    /// Engine caches built from the models: gigabytes, built again when gone.
    static var inferenceCache: URL { root.appendingPathComponent("InferenceCache", isDirectory: true) }

    /// At launch, before any model is read (ModelStore): models move out of
    /// Documents into the private folder, and so does the developer 12B
    /// check's file (LargeModelProbeFiles); 1.0.35's hidden folder too. Each
    /// item is renamed inside the app's container, so it is never copied,
    /// needs no free space, and is never in two places or none; an item
    /// that cannot move stays and is read where it is, and the next launch
    /// tries again (StorageMigration). Nothing is deleted. Then the Gemma 4
    /// 12B files that aren't a verified copy of its pinned file go, as before.
    static func migrateModels() {
        let manager = FileManager.default
        try? prepareModels()
        var reports: [String: StorageMigration.Report] = [:]
        for (name, source) in [("Documents/Models", documentModels), ("Models (1.0.35)", legacyModels)]
        where manager.fileExists(atPath: source.path) {
            reports[name] = StorageMigration.move(contentsOf: source, into: models)
        }
        if manager.fileExists(atPath: LargeModelProbeFiles.documentsFolder.path) {
            try? LargeModelProbeFiles.prepare()
            reports["Documents/Verification"] = StorageMigration.move(contentsOf: LargeModelProbeFiles.documentsFolder,
                                                                      into: LargeModelProbeFiles.folder)
        }
        // The Documents folder itself stays: iOS keeps it for every app.
        recordMigration(reports)
        protectStorage()
        // The 12B withdrawn in Oct 2026 may still be here. From 1.1.0 (200)
        // a verified copy of the pinned file stays, also while it is locked,
        // so unlocking again needs no new 6.9 GB download; a partial
        // download is ModelStore's while it is unlocked.
        let twelve = ModelSpec.gemma12B
        if !library.isInstalled(twelve) {
            try? manager.removeItem(at: library.receiptURL(twelve))
            for url in library.allModelURLs(twelve) { try? manager.removeItem(at: url) }
        }
        if twelve.isLocked { try? manager.removeItem(at: library.pendingURL(twelve)) }
        for name in ["gemma-4-12B-it.litertlm", "gemma-4-12b.verified", "gemma-4-12b.pending"] {
            try? manager.removeItem(at: legacyModels.appendingPathComponent(name))
        }
    }

    /// Writes down what moved, with the launch's date; only when something
    /// was there to move.
    private static func recordMigration(_ reports: [String: StorageMigration.Report]) {
        guard !reports.isEmpty else { return }
        struct Entry: Codable { let date: Date; let version: String; let reports: [String: StorageMigration.Report] }
        let version = (Bundle.main.infoDictionary?["CFBundleVersion"] as? String) ?? "?"
        var entries = (try? Data(contentsOf: migrationRecord)).flatMap { try? JSONDecoder().decode([Entry].self, from: $0) } ?? []
        entries.append(Entry(date: Date(), version: version, reports: reports))
        if let data = try? JSONEncoder().encode(Array(entries.suffix(20))) {
            try? data.write(to: migrationRecord, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
        storageNote = reports.sorted { $0.key < $1.key }.map { "\($0.key): \($0.value.summary)" }.joined(separator: " / ")
    }
    /// This launch's move, for the download log (ModelStore writes it).
    private(set) static var storageNote: String?

    /// How iOS keeps each kind of file (1.1.0 (251)). Everything readable
    /// after the phone's first unlock since its start (iOS's protection
    /// class B, "until first user authentication"), not only while
    /// unlocked: a reply goes on in the background and the Apple Watch's
    /// questions are answered with the iPhone locked, which both read the
    /// model and write the conversation. On disk everything is encrypted by
    /// iOS either way. Backups: conversations and attachments go into the
    /// iPhone's backup (iCloud or a computer's) as the person's own data;
    /// models and the engines' caches, gigabytes that can be downloaded or
    /// built again, do not.
    static func protectStorage() {
        let manager = FileManager.default
        for folder in [root, AttachmentStorage.directory, inferenceCache] {
            try? manager.createDirectory(at: folder, withIntermediateDirectories: true)
            try? manager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                                       ofItemAtPath: folder.path)
        }
        var cache = inferenceCache, values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? cache.setResourceValues(values)
    }

    static func prepareModels() throws {
        for folder in [models, modelState] {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            // Multi-GB weights are re-downloadable; keep them out of backups.
            var url = folder
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try url.setResourceValues(values)
        }
    }

    /// The engine caches built for a model, under every runtime's folder
    /// (InferenceEnginePlan.cacheComponent): useless once its file is gone,
    /// and 12B's GPU cache alone takes about 6 GB.
    static func removeEngineCaches(_ spec: ModelSpec) {
        let caches = root.appendingPathComponent("InferenceCache", isDirectory: true)
        for runtime in (try? FileManager.default.contentsOfDirectory(at: caches, includingPropertiesForKeys: nil)) ?? [] {
            try? FileManager.default.removeItem(at: runtime.appendingPathComponent(spec.sha256, isDirectory: true))
        }
    }

    /// The model's engine caches except `component`'s, the one about to be
    /// used. 12B's caches of 1.1.0 (200) (Context 4,096, without benchmark
    /// mode) are never read again, and each is about 6 GB.
    static func removeEngineCaches(_ spec: ModelSpec, keeping component: String) {
        let caches = root.appendingPathComponent("InferenceCache", isDirectory: true)
        let kept = caches.appendingPathComponent(component, isDirectory: true).standardizedFileURL.path
        for runtime in (try? FileManager.default.contentsOfDirectory(at: caches, includingPropertiesForKeys: nil)) ?? [] {
            let model = runtime.appendingPathComponent(spec.sha256, isDirectory: true)
            for folder in (try? FileManager.default.contentsOfDirectory(at: model, includingPropertiesForKeys: nil)) ?? []
            where folder.standardizedFileURL.path != kept {
                try? FileManager.default.removeItem(at: folder)
            }
        }
    }

    static func hasVerifiedModel(_ spec: ModelSpec) -> Bool { library.isInstalled(spec) }
    static func installVerifiedModel(_ spec: ModelSpec) throws { try library.installValidated(spec) }
}

