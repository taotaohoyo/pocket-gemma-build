import Foundation
import PocketCore

enum AppFiles {
    static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma", isDirectory: true)
    }
    /// Models live in Documents so they appear in the Files app under
    /// "On My iPhone › Pocket AI › Models" (UIFileSharingEnabled).
    static var models: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Models", isDirectory: true)
    }
    /// Where 1.0.35 and earlier kept models, inside the hidden app container.
    static var legacyModels: URL { root.appendingPathComponent("Models", isDirectory: true) }
    /// Receipts and partial downloads stay hidden; same volume as Documents,
    /// so finishing a download is still a rename.
    static var modelState: URL { root.appendingPathComponent("ModelState", isDirectory: true) }
    static var library: ModelLibrary { ModelLibrary(directory: models, stateDirectory: modelState) }
    static func model(_ spec: ModelSpec) -> URL { library.modelURL(spec) }
    static func pendingModel(_ spec: ModelSpec) -> URL { library.pendingURL(spec) }
    static var archive: URL { root.appendingPathComponent("conversations.json") }

    /// Move models from the hidden container to Files (same volume, so this
    /// is a rename, not a copy) and drop the withdrawn Gemma 4 12B files.
    static func migrateModels() {
        let manager = FileManager.default
        try? prepareModels()
        if let items = try? manager.contentsOfDirectory(at: legacyModels, includingPropertiesForKeys: nil) {
            for item in items {
                let isModel = item.pathExtension == "litertlm"
                let destination = (isModel ? models : modelState).appendingPathComponent(item.lastPathComponent)
                if manager.fileExists(atPath: destination.path) { continue }
                try? manager.moveItem(at: item, to: destination)
            }
            if (try? manager.contentsOfDirectory(atPath: legacyModels.path))?.isEmpty == true {
                try? manager.removeItem(at: legacyModels)
            }
        }
        for name in ["gemma-4-12B-it.litertlm", "gemma-4-12b.verified", "gemma-4-12b.pending"] {
            for folder in [models, modelState, legacyModels] {
                try? manager.removeItem(at: folder.appendingPathComponent(name))
            }
        }
    }

    static func prepareModels() throws {
        for folder in [models, modelState] {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            // Multi-GB weights are re-downloadable; keep them out of backups.
            var url = folder
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try url.setResourceValues(values)
        }
    }

    static func hasVerifiedModel(_ spec: ModelSpec) -> Bool { library.isInstalled(spec) }
    static func installVerifiedModel(_ spec: ModelSpec) throws { try library.installValidated(spec) }
}

