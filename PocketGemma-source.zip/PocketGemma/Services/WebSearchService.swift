import Foundation
import LiteRTLM
import PocketCore

enum WebSearchEvent: Sendable {
    case started(String)
    case finished(query: String, sources: [WebSearchSource], failure: WebSearchFailure?)
    /// What the question named that no page the reply's searches read
    /// did ("iOS 27.2"); empty once one did.
    case unconfirmed([String])
}

/// The searches themselves: Tavily, through the person's Tavily account
/// when signed in (TavilyAccountSession, Tavily's MCP server), else with
/// their own key (WebSearchKey, the search API). Both ask for the same
/// search and read the same answer. Only the query leaves the device, over
/// an ephemeral session that keeps no cookies or cache.
enum WebSearchClient {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = WebSearch.timeout
        configuration.timeoutIntervalForResource = WebSearch.timeout * 2
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.waitsForConnectivity = false
        return URLSession(configuration: configuration)
    }()

    /// Throws a `WebSearchFailure`, or `CancellationError` when the reply
    /// is stopped (the request is cancelled with its task).
    static func search(_ query: TavilyQuery) async throws -> [WebSearchHit] {
        switch WebSearchConnection.current() {
        case .account:
            // The remote MCP's tavily_search: the same search, with only the
            // arguments its tool declares (no published dates there).
            let arguments = try JSONSerialization.data(withJSONObject: query.mcpArguments)
            return try TavilySearch.parse(try await TavilyAccountSession.shared.search(arguments: arguments))
        case .key(let key):
            var (data, response) = try await session.data(for: TavilySearch.request(query, key: key))
            // A body Tavily doesn't take goes again as 1.1.0 (205) sent it.
            if (response as? HTTPURLResponse)?.statusCode == 400 {
                (data, response) = try await session.data(for: TavilySearch.request(query, key: key, minimal: true))
            }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard status == 200 else { throw WebSearchFailure(status: status) }
            return try TavilySearch.parse(data)
        case .signInNeeded: throw WebSearchFailure.signInNeeded
        case .none: throw WebSearchFailure.keyMissing
        }
    }
}

/// One reply's searches. The runtime makes a new `WebSearchTool` for each
/// call, so the tool reaches the reply through `active`, which the service
/// sets for the reply's stream and clears after it. Stopping the reply
/// cancels a search under way, and the reply ends there.
///
/// Each search keeps the question's versions, model numbers and dates in
/// its query, reads the pages that are about what was asked first, and
/// when none is, or all are old where the latest was asked for, searches
/// once more on its own (SearchTarget, 1.1.0 (208)). That second request
/// counts toward the reply's `maximumSearches`.
final class WebSearchTurn: @unchecked Sendable {
    private static let activeLock = NSLock()
    private static var current: WebSearchTurn?
    static var active: WebSearchTurn? {
        get { activeLock.withLock { current } }
        set { activeLock.withLock { current = newValue } }
    }

    private let lock = NSLock()
    private var count = 0
    private var cancelled = false
    private var running: Task<[WebSearchHit], Error>?
    private var observer: (@Sendable (String) async -> Void)?
    private var found: [[String: Any]] = []
    private var target: SearchTarget?
    /// The pages given to the model so far, in the order the sources show
    /// them under the reply, which is how the results are numbered.
    private var given: [String] = []
    private var confirmed = false
    private var asWritten: [String] = []
    private let onEvent: @Sendable (WebSearchEvent) async -> Void
    private let perform: @Sendable (TavilyQuery) async throws -> [WebSearchHit]

    init(perform: @escaping @Sendable (TavilyQuery) async throws -> [WebSearchHit] = WebSearchClient.search,
         onEvent: @escaping @Sendable (WebSearchEvent) async -> Void) {
        self.perform = perform
        self.onEvent = onEvent
    }

    /// Searches made so far, including refused ones past the limit and the
    /// turn's own second requests.
    var searches: Int { lock.withLock { count } }

    /// The queries as the model wrote them, before the question's own words
    /// went back in: for the native probes, kept only while the reply is.
    var written: [String] { lock.withLock { asWritten } }

    /// What the reply's question asks about, set by the service before the
    /// reply streams.
    var focus: SearchTarget? {
        get { lock.withLock { target } }
        set { lock.withLock { target = newValue } }
    }

    /// What this reply's searches that got pages gave the model, for
    /// writing the reply again without the tool (GemmaService).
    var responses: [[String: Any]] { lock.withLock { found } }

    /// The reply's diagnostic notes when each search starts and how it
    /// ended, never the query: "web_search", then "web_search_results" or
    /// "web_search_failed_<kind>".
    func observe(_ observer: @escaping @Sendable (String) async -> Void) {
        lock.withLock { self.observer = observer }
    }

    private func note(_ stage: String) async {
        let observer = lock.withLock { self.observer }
        await observer?(stage)
    }

    func search(_ raw: String) async throws -> [String: Any] {
        guard var query = WebSearch.normalizedQuery(raw) else {
            await note("web_search_empty_query")
            return ["error": "The search words were empty. Answer without searching."]
        }
        let target = focus
        lock.withLock { asWritten.append(query) }
        // The question's own versions, numbers and dates, whatever the
        // model wrote (iOS 27.2, not the 17.2 E4B searched for on 205).
        if let kept = target?.repair(query), kept != query {
            query = kept
            await note("web_search_query_kept")
        }
        guard let number = reserve(past: true) else { throw CancellationError() }
        guard number <= WebSearch.maximumSearches else {
            await note("web_search_over_limit")
            return WebSearch.limitResponse(query: query)
        }
        await onEvent(.started(query))
        await note("web_search")
        let hits: [WebSearchHit]
        do {
            hits = try await run(TavilyQuery(query))
            try checkCancelled()
        } catch {
            try checkCancelled()
            guard let failure = WebSearchFailure(error) else { throw CancellationError() }
            await onEvent(.finished(query: query, sources: [], failure: failure))
            await note("web_search_failed_\(failure.rawValue)")
            return WebSearch.failureResponse(query: query, failure: failure)
        }
        let given = Set(lock.withLock { self.given })
        var findings = target?.select(hits, query: query, excluding: given)
            ?? WebSearchFindings(hits: Array(hits.filter { !given.contains($0.url) }.prefix(WebSearch.resultLimit)))
        // No page about what was asked, or only old ones for the latest:
        // once more, as an exact phrase or within the past year, if the
        // reply may still search.
        if let target, let retry = target.retry(after: findings, query: query), reserve(past: false) != nil {
            await onEvent(.finished(query: query, sources: [], failure: nil))
            await onEvent(.started(retry.query))
            await note("web_search_again")
            do {
                let more = try await run(retry)
                try checkCancelled()
                findings = target.select(more + hits, query: query, excluding: given)
                query = retry.query
            } catch {
                try checkCancelled()
                guard let failure = WebSearchFailure(error) else { throw CancellationError() }
                await onEvent(.finished(query: retry.query, sources: [], failure: failure))
                await note("web_search_failed_\(failure.rawValue)")
            }
        }
        let first = lock.withLock { self.given.count + 1 }
        let response = WebSearch.toolResponse(query: query, findings: findings, target: target, search: number, first: first)
        // The pages the model reads are the sources shown, numbered alike:
        // all those chosen, unless one didn't fit the prefill.
        let read = Array(findings.hits.prefix((response["results"] as? [Any])?.count ?? 0))
        lock.withLock { self.given += read.map(\.url) }
        await onEvent(.finished(query: query, sources: read.map(\.source), failure: nil))
        if findings.identifies {
            let unconfirmed: [String] = lock.withLock {
                if findings.matched > 0 { confirmed = true }
                return confirmed ? [] : findings.asked
            }
            if !unconfirmed.isEmpty { await note("web_search_off_target") }
            await onEvent(.unconfirmed(unconfirmed))
        }
        await note("web_search_results")
        lock.withLock { found.append(response) }
        return response
    }

    /// The next search's number; nil when the reply was stopped, or (for
    /// the turn's own second request, `past` false) when it would go past
    /// the reply's limit.
    private func reserve(past: Bool) -> Int? {
        lock.withLock {
            if cancelled || !past && count >= WebSearch.maximumSearches { return nil }
            count += 1
            return count
        }
    }

    private func run(_ query: TavilyQuery) async throws -> [WebSearchHit] {
        let task = Task { [perform] in try await perform(query) }
        let stop = lock.withLock { running = task; return cancelled }
        if stop { task.cancel() }
        return try await task.value
    }

    func cancel() {
        let task = lock.withLock { cancelled = true; return running }
        task?.cancel()
    }

    private func checkCancelled() throws {
        if lock.withLock({ cancelled }) { throw CancellationError() }
    }
}

/// The search tool Gemma 4 sees. Its declaration goes into the
/// conversation's system turn; a call runs the active reply's search.
struct WebSearchTool: Tool {
    static let name = "web_search"
    static let description = WebSearch.toolDescription

    @ToolParam(description: WebSearch.queryDescription)
    var query: String

    func run() async throws -> Any {
        guard let turn = WebSearchTurn.active else { return WebSearch.failureResponse(query: query, failure: .unavailable) }
        return try await turn.search(query)
    }
}
