import Foundation
import LiteRTLM
import PocketCore

enum WebSearchEvent: Sendable {
    case started(String)
    case finished(query: String, sources: [WebSearchSource], failure: WebSearchFailure?)
}

/// The searches themselves: Tavily, with the person's own key
/// (WebSearchKey). Only the query leaves the device, over an ephemeral
/// session that keeps no cookies or cache.
enum WebSearchClient {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = WebSearch.timeout
        configuration.timeoutIntervalForResource = WebSearch.timeout * 2
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.waitsForConnectivity = false
        return URLSession(configuration: configuration)
    }()

    /// Throws a `WebSearchFailure`, or `CancellationError` when the reply
    /// is stopped (the request is cancelled with its task).
    static func search(_ query: String) async throws -> [WebSearchHit] {
        guard let key = WebSearchKey.load() else { throw WebSearchFailure.keyMissing }
        let (data, response) = try await session.data(for: TavilySearch.request(query: query, key: key))
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else { throw WebSearchFailure(status: status) }
        return try TavilySearch.parse(data)
    }
}

/// One reply's searches. The runtime makes a new `WebSearchTool` for each
/// call, so the tool reaches the reply through `active`, which the service
/// sets for the reply's stream and clears after it. Stopping the reply
/// cancels a search under way, and the reply ends there.
final class WebSearchTurn: @unchecked Sendable {
    private static let activeLock = NSLock()
    private static var current: WebSearchTurn?
    static var active: WebSearchTurn? {
        get { activeLock.withLock { current } }
        set { activeLock.withLock { current = newValue } }
    }

    private let lock = NSLock()
    private var count = 0
    private var cancelled = false
    private var running: Task<[WebSearchHit], Error>?
    private var observer: (@Sendable (String) async -> Void)?
    private var found: [[String: Any]] = []
    private let onEvent: @Sendable (WebSearchEvent) async -> Void
    private let perform: @Sendable (String) async throws -> [WebSearchHit]

    init(perform: @escaping @Sendable (String) async throws -> [WebSearchHit] = WebSearchClient.search,
         onEvent: @escaping @Sendable (WebSearchEvent) async -> Void) {
        self.perform = perform
        self.onEvent = onEvent
    }

    /// Searches made so far, including refused ones past the limit.
    var searches: Int { lock.withLock { count } }

    /// What this reply's searches that got pages gave the model, for
    /// writing the reply again without the tool (GemmaService).
    var responses: [[String: Any]] { lock.withLock { found } }

    /// The reply's diagnostic notes when each search starts and how it
    /// ended, never the query: "web_search", then "web_search_results" or
    /// "web_search_failed_<kind>".
    func observe(_ observer: @escaping @Sendable (String) async -> Void) {
        lock.withLock { self.observer = observer }
    }

    private func note(_ stage: String) async {
        let observer = lock.withLock { self.observer }
        await observer?(stage)
    }

    func search(_ raw: String) async throws -> [String: Any] {
        guard let query = WebSearch.normalizedQuery(raw) else {
            await note("web_search_empty_query")
            return ["error": "検索語が空でした。検索せずに答えてください。"]
        }
        let number: Int? = lock.withLock {
            if cancelled { return nil }
            count += 1
            return count
        }
        guard let number else { throw CancellationError() }
        guard number <= WebSearch.maximumSearches else {
            await note("web_search_over_limit")
            return WebSearch.limitResponse(query: query)
        }
        await onEvent(.started(query))
        await note("web_search")
        let task = Task { [perform] in try await perform(query) }
        let stop = lock.withLock { running = task; return cancelled }
        if stop { task.cancel() }
        do {
            let hits = try await task.value
            try checkCancelled()
            await onEvent(.finished(query: query, sources: hits.prefix(WebSearch.resultLimit).map(\.source), failure: nil))
            await note("web_search_results")
            let response = WebSearch.toolResponse(query: query, hits: hits, search: number)
            lock.withLock { found.append(response) }
            return response
        } catch {
            try checkCancelled()
            guard let failure = WebSearchFailure(error) else { throw CancellationError() }
            await onEvent(.finished(query: query, sources: [], failure: failure))
            await note("web_search_failed_\(failure.rawValue)")
            return WebSearch.failureResponse(query: query, failure: failure)
        }
    }

    func cancel() {
        let task = lock.withLock { cancelled = true; return running }
        task?.cancel()
    }

    private func checkCancelled() throws {
        if lock.withLock({ cancelled }) { throw CancellationError() }
    }
}

/// The search tool Gemma 4 sees. Its declaration goes into the
/// conversation's system turn; a call runs the active reply's search.
struct WebSearchTool: Tool {
    static let name = "web_search"
    static let description = WebSearch.toolDescription

    @ToolParam(description: WebSearch.queryDescription)
    var query: String

    func run() async throws -> Any {
        guard let turn = WebSearchTurn.active else { return WebSearch.failureResponse(query: query, failure: .unavailable) }
        return try await turn.search(query)
    }
}
