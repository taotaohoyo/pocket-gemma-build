import Foundation
import LiteRTLM
import PocketCore

enum WebSearchEvent: Sendable {
    case started(String)
    case finished(query: String, sources: [WebSearchSource], failure: WebSearchFailure?)
    /// What the question named that no page the reply's searches read
    /// did ("iOS 27.2"); empty once one did.
    case unconfirmed([String])
}

/// The searches themselves: Tavily, through the person's Tavily account
/// when signed in (TavilyAccountSession, Tavily's MCP server), else with
/// their own key (WebSearchKey, the search API). Both ask for the same
/// search and read the same answer. Only the query leaves the device, over
/// an ephemeral session that keeps no cookies or cache.
enum WebSearchClient {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = WebSearch.timeout
        configuration.timeoutIntervalForResource = WebSearch.timeout * 2
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.waitsForConnectivity = false
        return URLSession(configuration: configuration)
    }()

    /// Throws a `WebSearchFailure`, or `CancellationError` when the reply
    /// is stopped (the request is cancelled with its task).
    static func search(_ query: TavilyQuery) async throws -> [WebSearchHit] {
        switch WebSearchConnection.current() {
        case .account:
            // The remote MCP's tavily_search: the same search, with only the
            // arguments its tool declares (no published dates there).
            let arguments = try JSONSerialization.data(withJSONObject: query.mcpArguments)
            return try TavilySearch.parse(try await TavilyAccountSession.shared.search(arguments: arguments))
        case .key(let key):
            var (data, response) = try await session.data(for: TavilySearch.request(query, key: key))
            // A body Tavily doesn't take goes again as 1.1.0 (205) sent it.
            if (response as? HTTPURLResponse)?.statusCode == 400 {
                (data, response) = try await session.data(for: TavilySearch.request(query, key: key, minimal: true))
            }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard status == 200 else { throw WebSearchFailure(status: status) }
            return try TavilySearch.parse(data)
        case .signInNeeded: throw WebSearchFailure.signInNeeded
        case .none: throw WebSearchFailure.keyMissing
        }
    }
}

/// One reply's searches. The runtime makes a new `WebSearchTool` for each
/// call, so the tool reaches the reply through `active`, which the service
/// sets for the reply's stream and clears after it. Stopping the reply
/// cancels a search under way, and the reply ends there.
///
/// Each search keeps the question's versions, model numbers and dates in
/// its query, reads the pages that are about what was asked first, and
/// when none is, or all are old where the latest was asked for, searches
/// once more on its own (SearchTarget, 1.1.0 (208)). A search for the
/// latest that no version narrows also asks for the past month's pages at
/// the same time, and the maker's own sites when neither found a page of
/// theirs (1.1.0 (211)). Those extra requests are two per reply
/// (`WebSearch.extraRequests`), on top of the model's `maximumSearches`.
final class WebSearchTurn: @unchecked Sendable {
    private static let activeLock = NSLock()
    private static var current: WebSearchTurn?
    static var active: WebSearchTurn? {
        get { activeLock.withLock { current } }
        set { activeLock.withLock { current = newValue } }
    }

    private let lock = NSLock()
    private var count = 0
    private var extras = 0
    private var cancelled = false
    private var running: [Task<[WebSearchHit], Error>] = []
    private var observer: (@Sendable (String) async -> Void)?
    private var found: [[String: Any]] = []
    private var target: SearchTarget?
    /// The pages given to the model so far, in the order the sources show
    /// them under the reply, which is how the results are numbered.
    private var given: [String] = []
    private var confirmed = false
    private var asWritten: [String] = []
    /// The words each search was sent with, folded, so the same search
    /// isn't sent twice.
    private var sent: Set<String> = []
    private let onEvent: @Sendable (WebSearchEvent) async -> Void
    private let perform: @Sendable (TavilyQuery) async throws -> [WebSearchHit]

    init(perform: @escaping @Sendable (TavilyQuery) async throws -> [WebSearchHit] = WebSearchClient.search,
         onEvent: @escaping @Sendable (WebSearchEvent) async -> Void) {
        self.perform = perform
        self.onEvent = onEvent
    }

    /// The model's searches so far, including refused ones past the limit;
    /// the turn's own extra requests aren't counted.
    var searches: Int { lock.withLock { count } }

    /// The queries as the model wrote them, before the question's own words
    /// went back in: for the native probes, kept only while the reply is.
    var written: [String] { lock.withLock { asWritten } }

    /// What the reply's question asks about, set by the service before the
    /// reply streams.
    var focus: SearchTarget? {
        get { lock.withLock { target } }
        set { lock.withLock { target = newValue } }
    }

    /// What this reply's searches that came back gave the model, pages or
    /// none, for writing the reply again without the tool (GemmaService).
    var responses: [[String: Any]] { lock.withLock { found } }

    /// A search of this reply came back, with pages or none, so the reply
    /// can be written again from what it found.
    var hasSearched: Bool { lock.withLock { !found.isEmpty } }

    /// The reply's diagnostic notes when each search starts and how it
    /// ended, never the query: "web_search", then "web_search_results" or
    /// "web_search_failed_<kind>".
    func observe(_ observer: @escaping @Sendable (String) async -> Void) {
        lock.withLock { self.observer = observer }
    }

    private func note(_ stage: String) async {
        let observer = lock.withLock { self.observer }
        await observer?(stage)
    }

    func search(_ raw: String) async throws -> [String: Any] {
        guard var query = WebSearch.normalizedQuery(raw) else {
            await note("web_search_empty_query")
            return ["error": "The search words were empty. Answer without searching."]
        }
        let target = focus
        lock.withLock { asWritten.append(query) }
        // The question's own versions, numbers and dates, whatever the
        // model wrote (iOS 27.2, not the 17.2 E4B searched for on 205).
        if let kept = target?.repair(query), kept != query {
            query = kept
            await note("web_search_query_kept")
        }
        guard let number = reserve() else { throw CancellationError() }
        let folded = query.precomposedStringWithCompatibilityMapping.lowercased()
        guard lock.withLock({ sent.insert(folded).inserted }) else {
            await note("web_search_repeated")
            return WebSearch.repeatResponse(query: query, language: target?.language)
        }
        guard number <= WebSearch.maximumSearches else {
            await note("web_search_over_limit")
            return WebSearch.limitResponse(query: query)
        }
        await onEvent(.started(query))
        await note("web_search")
        // For the latest, the past month's pages alongside, in the same
        // time; if that request fails the search goes on without it.
        let recent = target?.recent(for: query).flatMap { reserveExtra() ? $0 : nil }
        if recent != nil { await note("web_search_recent") }
        var hits: [WebSearchHit]
        var ranks: [String: Int]?
        do {
            async let month = runIfAny(recent)
            var lists = [try await run(TavilyQuery(query))]
            if let month = await month { lists.append(month) }
            // No page of the maker's own in either: once more on its sites.
            if let official = target?.official(for: query, after: lists.flatMap { $0 }), reserveExtra() {
                await note("web_search_official")
                if let theirs = await runIfAny(official) { lists.append(theirs) }
            }
            hits = Self.interleave(lists)
            if lists.count > 1 { ranks = Self.ranks(lists) }
            try checkCancelled()
        } catch {
            try checkCancelled()
            guard let failure = WebSearchFailure(error) else { throw CancellationError() }
            await onEvent(.finished(query: query, sources: [], failure: failure))
            await note("web_search_failed_\(failure.rawValue)")
            return WebSearch.failureResponse(query: query, failure: failure)
        }
        let given = Set(lock.withLock { self.given })
        var findings = target?.select(hits, query: query, excluding: given, ranks: ranks)
            ?? WebSearchFindings(hits: Array(hits.filter { !given.contains($0.url) }.prefix(WebSearch.resultLimit)))
        // No page about what was asked, or only old ones for the latest:
        // once more, as an exact phrase or within the past year, if the
        // reply may still search.
        if let target, let retry = target.retry(after: findings, query: query), reserveExtra() {
            await onEvent(.finished(query: query, sources: [], failure: nil))
            await onEvent(.started(retry.query))
            await note("web_search_again")
            do {
                let more = try await run(retry)
                try checkCancelled()
                findings = target.select(more + hits, query: query, excluding: given)
                query = retry.query
            } catch {
                try checkCancelled()
                guard let failure = WebSearchFailure(error) else { throw CancellationError() }
                await onEvent(.finished(query: retry.query, sources: [], failure: failure))
                await note("web_search_failed_\(failure.rawValue)")
            }
        }
        let first = lock.withLock { self.given.count + 1 }
        let response = WebSearch.toolResponse(query: query, findings: findings, target: target, search: number, first: first)
        // The pages the model reads are the sources shown, numbered alike:
        // all those chosen, unless one didn't fit the prefill.
        let read = Array(findings.hits.prefix((response["results"] as? [Any])?.count ?? 0))
        lock.withLock { self.given += read.map(\.url) }
        await onEvent(.finished(query: query, sources: read.map(\.source), failure: nil))
        if findings.identifies {
            let unconfirmed: [String] = lock.withLock {
                if findings.matched > 0 { confirmed = true }
                return confirmed ? [] : findings.asked
            }
            if !unconfirmed.isEmpty { await note("web_search_off_target") }
            await onEvent(.unconfirmed(unconfirmed))
        }
        await note("web_search_results")
        lock.withLock { found.append(response) }
        return response
    }

    /// The next search's number; nil when the reply was stopped.
    private func reserve() -> Int? {
        lock.withLock {
            if cancelled { return nil }
            count += 1
            return count
        }
    }

    /// Whether the reply may still make a request of its own (a retry, the
    /// past month's pages or the maker's sites): two per reply, so a reply
    /// costs at most `maximumSearches` + 2 credits.
    private func reserveExtra() -> Bool {
        lock.withLock {
            if cancelled || extras >= WebSearch.extraRequests { return false }
            extras += 1
            return true
        }
    }

    /// The searches' pages in turns, so each one's best come first.
    static func interleave(_ lists: [[WebSearchHit]]) -> [WebSearchHit] {
        (0..<(lists.map(\.count).max() ?? 0)).flatMap { index in
            lists.compactMap { $0.indices.contains(index) ? $0[index] : nil }
        }
    }

    /// Each page's place in its own search, the best one where several
    /// found it.
    static func ranks(_ lists: [[WebSearchHit]]) -> [String: Int] {
        var ranks: [String: Int] = [:]
        for list in lists {
            for (rank, hit) in list.enumerated() { ranks[hit.url] = min(ranks[hit.url] ?? rank, rank) }
        }
        return ranks
    }

    private func runIfAny(_ query: TavilyQuery?) async -> [WebSearchHit]? {
        guard let query else { return nil }
        return try? await run(query)
    }

    private func run(_ query: TavilyQuery) async throws -> [WebSearchHit] {
        let task = Task { [perform] in try await perform(query) }
        let stop = lock.withLock { running.append(task); return cancelled }
        if stop { task.cancel() }
        return try await task.value
    }

    func cancel() {
        let tasks = lock.withLock { cancelled = true; return running }
        tasks.forEach { $0.cancel() }
    }

    private func checkCancelled() throws {
        if lock.withLock({ cancelled }) { throw CancellationError() }
    }
}

/// The search tool Gemma 4 sees. Its declaration goes into the
/// conversation's system turn; a call runs the active reply's search.
struct WebSearchTool: Tool {
    static let name = "web_search"
    static let description = WebSearch.toolDescription

    @ToolParam(description: WebSearch.queryDescription)
    var query: String

    func run() async throws -> Any {
        guard let turn = WebSearchTurn.active else { return WebSearch.failureResponse(query: query, failure: .unavailable) }
        return try await turn.search(query)
    }
}
