import Foundation
import LiteRTLM
import PocketCore

enum WebSearchEvent: Sendable {
    case started(String)
    case finished(query: String, sources: [WebSearchSource], failed: Bool, provider: WebSearchProvider?)
}

/// The searches themselves: Wikipedia without a key, or the whole web
/// through Tavily with the person's own key (WebSearchKey). Only the query
/// leaves the device, over an ephemeral session that keeps no cookies or
/// cache.
enum WebSearchClient {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = WebSearch.timeout
        configuration.timeoutIntervalForResource = WebSearch.timeout * 2
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.waitsForConnectivity = false
        return URLSession(configuration: configuration)
    }()

    /// Wikimedia asks every client to name itself.
    static var userAgent: String {
        let info = Bundle.main.infoDictionary
        let version = info?["CFBundleShortVersionString"] as? String ?? "0"
        let build = info?["CFBundleVersion"] as? String ?? "0"
        return "Fielua/\(version) (iOS on-device chat app; build \(build))"
    }

    static var provider: WebSearchProvider { WebSearchKey.isSet ? .tavily : .wikipedia }

    static func search(_ query: String) async throws -> (WebSearchProvider, [WebSearchHit]) {
        if let key = WebSearchKey.load() {
            return (.tavily, try await hits(TavilySearch.request(query: query, key: key), parse: TavilySearch.parse))
        }
        let language = WikipediaSearch.language(for: query)
        var found = try await hits(WikipediaSearch.request(query: query, language: language, userAgent: userAgent),
                                   parse: WikipediaSearch.parse)
        // Words in Latin letters may still name a Japanese article.
        if found.isEmpty && language == "en" {
            found = try await hits(WikipediaSearch.request(query: query, language: "ja", userAgent: userAgent),
                                   parse: WikipediaSearch.parse)
        }
        return (.wikipedia, found)
    }

    private static func hits(_ request: URLRequest, parse: (Data) throws -> [WebSearchHit]) async throws -> [WebSearchHit] {
        let (data, response) = try await session.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else { throw WebSearchError.badResponse(status) }
        return try parse(data)
    }
}

/// One reply's searches. The runtime makes a new `WebSearchTool` for each
/// call, so the tool reaches the reply through `active`, which the service
/// sets for the reply's stream and clears after it. Stopping the reply
/// cancels a search under way, and the reply ends there.
final class WebSearchTurn: @unchecked Sendable {
    private static let activeLock = NSLock()
    private static var current: WebSearchTurn?
    static var active: WebSearchTurn? {
        get { activeLock.withLock { current } }
        set { activeLock.withLock { current = newValue } }
    }

    private let lock = NSLock()
    private var count = 0
    private var cancelled = false
    private var running: Task<(WebSearchProvider, [WebSearchHit]), Error>?
    private let onEvent: @Sendable (WebSearchEvent) async -> Void
    private let perform: @Sendable (String) async throws -> (WebSearchProvider, [WebSearchHit])

    init(perform: @escaping @Sendable (String) async throws -> (WebSearchProvider, [WebSearchHit]) = WebSearchClient.search,
         onEvent: @escaping @Sendable (WebSearchEvent) async -> Void) {
        self.perform = perform
        self.onEvent = onEvent
    }

    /// Searches made so far, including refused ones past the limit.
    var searches: Int { lock.withLock { count } }

    func search(_ raw: String) async throws -> [String: Any] {
        guard let query = WebSearch.normalizedQuery(raw) else {
            return ["error": "検索語が空でした。検索せずに答えてください。"]
        }
        let number: Int? = lock.withLock {
            if cancelled { return nil }
            count += 1
            return count
        }
        guard let number else { throw CancellationError() }
        guard number <= WebSearch.maximumSearches else { return WebSearch.limitResponse(query: query) }
        await onEvent(.started(query))
        let task = Task { [perform] in try await perform(query) }
        let stop = lock.withLock { running = task; return cancelled }
        if stop { task.cancel() }
        do {
            let (provider, hits) = try await task.value
            try checkCancelled()
            await onEvent(.finished(query: query, sources: hits.prefix(WebSearch.resultLimit).map(\.source),
                                    failed: false, provider: provider))
            return WebSearch.toolResponse(query: query, hits: hits, provider: provider, search: number)
        } catch {
            try checkCancelled()
            await onEvent(.finished(query: query, sources: [], failed: true, provider: nil))
            return WebSearch.failureResponse(query: query)
        }
    }

    func cancel() {
        let task = lock.withLock { cancelled = true; return running }
        task?.cancel()
    }

    private func checkCancelled() throws {
        if lock.withLock({ cancelled }) { throw CancellationError() }
    }
}

/// The search tool Gemma 4 sees. Its declaration goes into the
/// conversation's system turn; a call runs the active reply's search.
struct WebSearchTool: Tool {
    static let name = "web_search"
    static let description = WebSearch.toolDescription

    @ToolParam(description: WebSearch.queryDescription)
    var query: String

    func run() async throws -> Any {
        guard let turn = WebSearchTurn.active else { return WebSearch.failureResponse(query: query) }
        return try await turn.search(query)
    }
}
