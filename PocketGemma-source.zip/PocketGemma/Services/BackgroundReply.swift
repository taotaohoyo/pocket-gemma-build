import BackgroundTasks
import UIKit
import UserNotifications
import PocketCore

/// Background time for a reply that is still being written when the app
/// leaves the screen, so it can be finished there and announced.
///
/// iPhone apps can't use the GPU in the background (Metal work is refused,
/// and iOS's background GPU access is not offered on iPhones), so a reply on
/// the GPU stops when the app leaves and goes on from its last character on
/// the CPU (ChatStore.didEnterBackground), and back on the GPU when the app
/// is on screen again. The time for that comes from a
/// continued-processing task asked for when the person sends; iOS shows its
/// own display for it while the app is away, which apps cannot hide. Without
/// the task (iOS refused it, or `mode` is `.shortTime`) only the usual
/// background time is left, about 30 seconds; when it runs out the reply
/// stops and goes on when the app is opened again.
@MainActor
final class BackgroundReply {
    enum Mode { case continuedTask, shortTime }
    static let mode: Mode = .continuedTask

    /// The reply ran out of background time, or iOS ended its task: the
    /// person stopped it from iOS's display, or the system needed the
    /// resources. The reply stops and goes on when the app is opened.
    var onExpired: (@MainActor () -> Void)?
    private var continued: BGContinuedProcessingTask?
    private var requested = false
    private var outcome = "なし"
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var modelName = ""
    private var characters = 0
    private var stage: String?
    private var lastPush: ContinuousClock.Instant?
    private var shownText = ""

    /// For the diagnostics: what background time the reply has, and whether
    /// iOS offers background GPU time on this device.
    var state: String {
        let time: String
        if continued != nil { time = "続ける作業: 実行中" }
        else if requested { time = "続ける作業: 開始待ち" }
        else { time = "続ける作業: \(outcome)" + (backgroundTask != .invalid ? "・通常の時間" : "") }
        return time + " · " + Self.backgroundGPU
    }

    /// Apple has said only iPads offer it (2025); this tells whether this
    /// iPhone and iOS do. It is asked without the background GPU
    /// entitlement, which the app doesn't have.
    static var backgroundGPU: String {
        BGTaskScheduler.supportedResources.contains(.gpu) ? "裏のGPU: iOSが対応" : "裏のGPU: iOSが非対応"
    }

    /// When the person sends, while the app is on screen: iOS starts the
    /// task now or not at all.
    func begin(model: ModelSpec) {
        end(success: false)
        modelName = model.name.replacingOccurrences(of: "Gemma 4 ", with: "")
        characters = 0
        stage = nil
        shownText = ""
        guard Self.mode == .continuedTask else { outcome = "使わない"; return }
        // Each task needs an identifier of its own (registering one twice
        // ends the app); the Info.plist permits them below the bundle's.
        let identifier = (Bundle.main.bundleIdentifier ?? "app.pocketgemma.personal") + ".reply." + UUID().uuidString
        let registered = BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: .main) { [weak self] task in
            MainActor.assumeIsolated {
                if let self { self.adopt(task) } else { task.setTaskCompleted(success: false) }
            }
        }
        guard registered else { outcome = "登録できない"; return }
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: "回答を書いています",
                                                       subtitle: modelName)
        request.strategy = .fail
        do {
            try BGTaskScheduler.shared.submit(request)
            requested = true
            outcome = "申し込んだ"
        } catch {
            outcome = "断られた \((error as NSError).code)"
        }
    }

    private func adopt(_ task: BGTask) {
        let wanted = requested
        requested = false
        // The reply may be over by the time the task starts.
        guard let task = task as? BGContinuedProcessingTask, wanted, continued == nil else {
            task.setTaskCompleted(success: false)
            return
        }
        continued = task
        outcome = "実行中"
        task.progress.totalUnitCount = 1000
        let id = ObjectIdentifier(task)
        task.expirationHandler = { [weak self] in
            Task { @MainActor in self?.expired(id) }
        }
        push(force: true)
    }

    private func expired(_ id: ObjectIdentifier) {
        guard let task = continued, ObjectIdentifier(task) == id else { return }
        task.setTaskCompleted(success: false)
        continued = nil
        outcome = "iOSが終えた"
        onExpired?()
    }

    /// The reply's length so far, and what it waits for while it has no new
    /// text (such as the CPU taking over).
    func progress(characters: Int, stage: String? = nil) {
        self.characters = characters
        self.stage = stage
        push(force: false)
    }

    /// A figure goes out at most once a second; faster only costs battery.
    private func push(force: Bool) {
        guard let continued else { return }
        let now = ContinuousClock.now
        if !force, let lastPush, now - lastPush < .seconds(1) { return }
        lastPush = now
        let units = ReplyNotice.progressUnits(characters: characters, total: continued.progress.totalUnitCount)
        if units > continued.progress.completedUnitCount { continued.progress.completedUnitCount = units }
        let subtitle = stage.map { "\(modelName) · \($0)" }
            ?? (characters > 0 ? "\(modelName) · \(characters.formatted())文字" : modelName)
        guard subtitle != shownText else { return }
        shownText = subtitle
        continued.updateTitle("回答を書いています", subtitle: subtitle)
    }

    /// When the app leaves the screen with a reply under way: the usual
    /// background time, about 30 seconds. Without the continued task its end
    /// stops the reply.
    func holdBackgroundTime() {
        guard backgroundTask == .invalid else { return }
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "FinishGemmaReply") { [weak self] in
            MainActor.assumeIsolated {
                guard let self else { return }
                if self.continued == nil { self.onExpired?() }
                self.releaseBackgroundTime()
            }
        }
    }

    func releaseBackgroundTime() {
        guard backgroundTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
    }

    /// The reply ended (or stopped). The usual background time is kept for
    /// the caller to release once the model is unloaded.
    func end(success: Bool) {
        if requested { outcome = "始まる前に終えた" }
        requested = false
        guard let continued else { return }
        if success { continued.progress.completedUnitCount = continued.progress.totalUnitCount }
        continued.setTaskCompleted(success: success)
        self.continued = nil
        outcome = success ? "書き終えた" : "止めた"
    }
}

/// A notification when a reply ends while the app is not on screen; tapping
/// it opens that chat. Only the reply's first words are shown, as iOS's
/// preview setting allows (by default only while the phone is unlocked).
final class ReplyNotifications: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ReplyNotifications()
    /// Posted with the chat's id when the person taps a notification.
    static let openChat = Notification.Name("ReplyNotifications.openChat")
    private static let threadKey = "thread"

    /// The first time the person sends: iOS asks whether Fielua may notify.
    func requestPermissionOnce() {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .notDetermined else { return }
            center.requestAuthorization(options: [.alert, .sound]) { _, _ in }
        }
    }

    @MainActor
    func post(title: String, subtitle: String, body: String, threadID: UUID) {
        guard UIApplication.shared.applicationState != .active else { return }
        let content = UNMutableNotificationContent()
        content.title = title
        content.subtitle = subtitle
        content.body = body
        content.sound = .default
        content.threadIdentifier = threadID.uuidString
        content.userInfo = [Self.threadKey: threadID.uuidString]
        // One notification per chat: a newer one replaces it.
        let request = UNNotificationRequest(identifier: "reply-" + threadID.uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request) { _ in }
    }

    /// While the app is on screen the reply is there to see.
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([])
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let id = (response.notification.request.content.userInfo[Self.threadKey] as? String).flatMap(UUID.init(uuidString:))
        DispatchQueue.main.async {
            if let id { NotificationCenter.default.post(name: Self.openChat, object: nil, userInfo: [Self.threadKey: id]) }
            completionHandler()
        }
    }

    static func threadID(in notification: Notification) -> UUID? {
        notification.userInfo?[threadKey] as? UUID
    }
}
