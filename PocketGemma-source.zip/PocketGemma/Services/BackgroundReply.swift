import BackgroundTasks
import UIKit
import UserNotifications
import PocketCore

/// Background time for a reply that is still being written when the app
/// leaves the screen, so it can be finished there and announced.
///
/// iPhone apps can't use the GPU in the background (Metal work is refused,
/// and iOS's background GPU access is not offered on iPhones), so a reply on
/// the GPU stops when the app leaves and goes on from its last character on
/// the CPU (ChatStore.didEnterBackground), and back on the GPU when the app
/// is on screen again. The time for that comes from a
/// continued-processing task; iOS shows its own display for it while the
/// app is away, which apps cannot hide. iOS takes the request only from an
/// app on screen, so it is asked for as the app starts to leave the screen
/// with a reply under way (willResignActive), not when the person sends:
/// a task held while the app stayed on screen made the iPhone vibrate with
/// each reply (2026-10-25). Without the task (iOS refused it, or `mode` is
/// `.shortTime`) only the usual background time is left, about 30 seconds;
/// when it runs out the reply stops and goes on when the app is opened
/// again.
@MainActor
final class BackgroundReply {
    enum Mode { case continuedTask, shortTime }
    static let mode: Mode = .continuedTask

    /// How iOS's display shows the reply's progress. A reply's length isn't
    /// known while it is written, so a gauge could only creep, which looks
    /// slow (the person, 2026-10-23): the circle spins instead (progress
    /// with no total). The task's completed units still tell iOS the reply
    /// is moving: iOS takes a task whose progress hasn't moved for about 30
    /// seconds for stalled and may end it (Apple DTS, forums thread 805554),
    /// so besides each character every sign of work counts: a new stage,
    /// each moment of thinking, a search starting or ending. Without them a
    /// reply that searched or thought (E4B 深く with search, 2026-10-23)
    /// showed nothing new long enough for iOS to end it.
    /// `.gauge` is the earlier bar that rose with every character.
    enum ProgressStyle { case spinner, gauge }
    static let progressStyle: ProgressStyle = .spinner

    /// The reply ran out of background time, or iOS ended its task: the
    /// person stopped it from iOS's display, or the system needed the
    /// resources. The reply stops and goes on when the app is opened.
    var onExpired: (@MainActor () -> Void)?
    private var continued: BGContinuedProcessingTask?
    private var requested = false
    /// A reply is under way on screen: the task is asked for if the app
    /// starts to leave before it ends.
    private var armed = false
    private var leaving: [NSObjectProtocol] = []
    private var outcome = "なし"
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var modelName = ""
    private var characters = 0
    private var signs: Int64 = 0
    private var stage: String?
    private var lastPush: ContinuousClock.Instant?
    /// For the diagnostics: the longest time the task's progress stood still.
    private var lastMove: ContinuousClock.Instant?
    private var longestStill: Duration = .zero
    private var shownText = ""

    /// For the diagnostics: what background time the reply has, and whether
    /// iOS offers background GPU time on this device.
    var state: String {
        let time: String
        if continued != nil { time = "続ける作業: 実行中" }
        else if requested { time = "続ける作業: 開始待ち" }
        else if armed { time = "続ける作業: 画面を離れたら申し込む" }
        else { time = "続ける作業: \(outcome)" + (backgroundTask != .invalid ? "・通常の時間" : "") }
        return time + (Self.progressStyle == .spinner ? " · 回る表示" : " · ゲージ表示")
            + " · 進捗が止まった最長\(Int(longestStill.components.seconds))秒 · " + Self.backgroundGPU
    }

    /// Apple has said only iPads offer it (2025); this tells whether this
    /// iPhone and iOS do. It is asked without the background GPU
    /// entitlement, which the app doesn't have.
    static var backgroundGPU: String {
        BGTaskScheduler.supportedResources.contains(.gpu) ? "裏のGPU: iOSが対応" : "裏のGPU: iOSが非対応"
    }

    init() {
        // Both say the app is starting to leave the screen (home, the app
        // switcher, another app, the lock button); the first one asks.
        leaving = [UIApplication.willResignActiveNotification, UIScene.willDeactivateNotification].map { name in
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.appWillLeave() }
            }
        }
    }

    /// When a reply starts. On screen the task waits until the app starts
    /// to leave (appWillLeave). Away (iOS woke the app for the Apple Watch)
    /// it is asked for at once, though iOS may refuse it there.
    func begin(model: ModelSpec) {
        end(success: false)
        modelName = model.name.replacingOccurrences(of: "Gemma 4 ", with: "")
        characters = 0
        signs = 0
        stage = nil
        shownText = ""
        lastMove = nil
        longestStill = .zero
        guard Self.mode == .continuedTask else { outcome = "使わない"; return }
        if UIApplication.shared.applicationState == .active {
            armed = true
            outcome = "画面のまま"
            return
        }
        request()
    }

    /// The app starts to leave the screen while the reply is written: iOS
    /// starts the task now or not at all (`.fail`).
    private func appWillLeave() {
        guard armed else { return }
        armed = false
        request()
    }

    private func request() {
        // Each task needs an identifier of its own (registering one twice
        // ends the app); the Info.plist permits them below the bundle's.
        let identifier = (Bundle.main.bundleIdentifier ?? "app.pocketgemma.personal") + ".reply." + UUID().uuidString
        let registered = BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: .main) { [weak self] task in
            MainActor.assumeIsolated {
                if let self { self.adopt(task) } else { task.setTaskCompleted(success: false) }
            }
        }
        guard registered else { outcome = "登録できない"; return }
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: "返信を書いています",
                                                       subtitle: modelName)
        request.strategy = .fail
        do {
            try BGTaskScheduler.shared.submit(request)
            requested = true
            outcome = "申し込んだ"
        } catch {
            outcome = "断られた \((error as NSError).code)"
        }
    }

    private func adopt(_ task: BGTask) {
        let wanted = requested
        requested = false
        // The reply may be over by the time the task starts.
        guard let task = task as? BGContinuedProcessingTask, wanted, continued == nil else {
            task.setTaskCompleted(success: false)
            return
        }
        continued = task
        outcome = "実行中"
        task.progress.totalUnitCount = Self.progressStyle == .spinner ? -1 : 1000
        lastMove = ContinuousClock.now
        let id = ObjectIdentifier(task)
        task.expirationHandler = { [weak self] in
            Task { @MainActor in self?.expired(id) }
        }
        push(force: true)
    }

    private func expired(_ id: ObjectIdentifier) {
        guard let task = continued, ObjectIdentifier(task) == id else { return }
        noteStill()
        task.setTaskCompleted(success: false)
        continued = nil
        outcome = "iOSが終えた"
        onExpired?()
    }

    /// The reply's length so far, and what it waits for while it has no new
    /// text (such as the CPU taking over). Each call is a sign of work: new
    /// text, a new stage, a moment of thinking or a search.
    func progress(characters: Int, stage: String? = nil) {
        let changed = stage != self.stage
        self.characters = characters
        self.stage = stage
        signs += 1
        // A new stage goes out at once: the next sign may be a while away,
        // such as while the CPU loads the model.
        push(force: changed)
    }

    /// A figure goes out at most once a second; faster only costs battery.
    private func push(force: Bool) {
        guard let continued else { return }
        let now = ContinuousClock.now
        if !force, let lastPush, now - lastPush < .seconds(1) { return }
        lastPush = now
        // A spinner's units are never shown, only counted; a gauge's are its
        // share of the bar.
        let units = Self.progressStyle == .spinner ? Int64(characters) + signs
            : ReplyNotice.progressUnits(characters: characters, total: continued.progress.totalUnitCount)
        if units > continued.progress.completedUnitCount {
            continued.progress.completedUnitCount = units
            if let lastMove { longestStill = max(longestStill, now - lastMove) }
            lastMove = now
        }
        // No running count either: it would creep like the gauge.
        let subtitle = stage.map { "\(modelName) · \($0)" } ?? modelName
        guard subtitle != shownText else { return }
        shownText = subtitle
        continued.updateTitle("返信を書いています", subtitle: subtitle)
    }

    /// The time since the progress last moved, as the task ends.
    private func noteStill() {
        guard let lastMove else { return }
        longestStill = max(longestStill, ContinuousClock.now - lastMove)
        self.lastMove = nil
    }

    /// When the app leaves the screen with a reply under way: the usual
    /// background time, about 30 seconds. Without the continued task its end
    /// stops the reply.
    func holdBackgroundTime() {
        guard backgroundTask == .invalid else { return }
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "FinishGemmaReply") { [weak self] in
            MainActor.assumeIsolated {
                guard let self else { return }
                if self.continued == nil { self.onExpired?() }
                self.releaseBackgroundTime()
            }
        }
    }

    func releaseBackgroundTime() {
        guard backgroundTask != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
    }

    /// The reply ended (or stopped). The usual background time is kept for
    /// the caller to release once the model is unloaded.
    func end(success: Bool) {
        armed = false
        if requested { outcome = "始まる前に終えた" }
        requested = false
        guard let continued else { return }
        noteStill()
        if success {
            // A spinner's progress gets its total at the end, so it shows done.
            if continued.progress.totalUnitCount < 0 {
                continued.progress.totalUnitCount = max(1, continued.progress.completedUnitCount)
            }
            continued.progress.completedUnitCount = continued.progress.totalUnitCount
        }
        continued.setTaskCompleted(success: success)
        self.continued = nil
        outcome = success ? "書き終えた" : "止めた"
    }
}

/// A notification when a reply ends while the app is not on screen; tapping
/// it opens that chat. Only the reply's first words are shown, as iOS's
/// preview setting allows (by default only while the phone is unlocked).
final class ReplyNotifications: NSObject, UNUserNotificationCenterDelegate {
    static let shared = ReplyNotifications()
    /// Posted with the chat's id when the person taps a notification.
    static let openChat = Notification.Name("ReplyNotifications.openChat")
    private static let threadKey = "thread"

    /// The first time the person sends: iOS asks whether Fielua may notify.
    func requestPermissionOnce() {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .notDetermined else { return }
            center.requestAuthorization(options: [.alert, .sound]) { _, _ in }
        }
    }

    /// The chat's title (its first question) is left out: the person knows
    /// what they asked (2026-10-23).
    @MainActor
    func post(title: String, body: String, threadID: UUID) {
        guard UIApplication.shared.applicationState != .active else { return }
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        content.threadIdentifier = threadID.uuidString
        content.userInfo = [Self.threadKey: threadID.uuidString]
        // One notification per chat: a newer one replaces it.
        let request = UNNotificationRequest(identifier: "reply-" + threadID.uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request) { _ in }
    }

    /// While the app is on screen the reply is there to see. The Apple
    /// Watch's one notification (WatchIntro) shows anyway: it comes once.
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler(notification.request.identifier == WatchIntro.requestID ? [.banner, .list, .sound] : [])
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let id = (response.notification.request.content.userInfo[Self.threadKey] as? String).flatMap(UUID.init(uuidString:))
        DispatchQueue.main.async {
            if let id { NotificationCenter.default.post(name: Self.openChat, object: nil, userInfo: [Self.threadKey: id]) }
            completionHandler()
        }
    }

    static func threadID(in notification: Notification) -> UUID? {
        notification.userInfo?[threadKey] as? UUID
    }
}
