import Foundation
import CryptoKit
import LiteRTLM
import PocketCore
import VisionRuntimeBridge
import os

/// Direct official conversation API and independent LiteRT component probes.
/// Neither route calls AttachmentStorage, Photos, or the app image converter.
enum VisionDiagnosticRunner {
    /// E4B's chats take 70 or 140 image tokens (ModelSpec.photoDetails); this
    /// developer probe also runs 280 and any backend, and a 2048 context next to
    /// the usual 4096, recording what each needs on the phone, including the
    /// address space at each stage.
    static func run(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                    vision: ExecutionBackend, kernel: VisionCPUImplementation = .xnnpack,
                    visionTokens: Int = 280, contextTokens: Int = 4096) async throws -> String {
        guard [ModelSpec.e2b.id, ModelSpec.e4b.id].contains(model.id), AppFiles.hasVerifiedModel(model) else {
            throw ProbeError.modelMissing
        }
        guard model.visualTokenBudgets.contains(visionTokens), [2048, 4096].contains(contextTokens) else { throw ProbeError.budget }
        var settings = GenerationSettings()
        settings.backend = kind.isComponent ? .cpu : main
        settings.visionBackend = kind.isComponent ? .cpu : vision
        settings.visionCPUImplementation = kind.isComponent ? (kind.usesBuiltin ? .builtin : .xnnpack) : kernel
        settings.maxTokens = contextTokens; settings.visualTokenBudget = kind.isComponent ? 280 : visionTokens
        settings.maxOutputTokens = 128; settings.topK = 1; settings.topP = 1; settings.temperature = 0
        settings.enableThinking = false; settings.enableSpeculativeDecoding = false
        let plan = InferenceEnginePlan(model: model, settings: settings, needsVision: true,
                                       visualTokenBudget: settings.visualTokenBudget)
        var record = InferenceDiagnostic(plan: plan, imageCount: kind.isComponent ? 0 : 1, settings: settings)
        record.inputPath = kind.isComponent ? "isolated_component_synthetic_tensors" : "bundled_jpeg_direct_sdk"
        record.engineWasReused = false; record.conversationWasReused = false
        let work = AppFiles.root.appendingPathComponent("VisionProbe/\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: work) }
        let log = NativeLogCapture(includeInfo: true)
        let memory = InferenceMemoryCapture()
        do {
            let description: String
            if kind.isComponent {
                let encoder = kind.isEncoder
                record.testedComponent = encoder ? "vision_encoder" : "vision_adapter"
                record.componentKernelMode = kind.usesBuiltin ? "builtin_cpu_no_xnnpack" : "delegate_xnnpack"
                record.cpuThreadPolicy = "isolated component: 4 threads"
                record.advance("component_extraction")
                let section = try extract(model: model, encoder: encoder, to: work)
                record.sectionSHA256 = section.sha256
                record.advance("component_compile_or_invoke")
                let signature = encoder ? "vision_280" : "vision_adapter_280"
                let result = await Task.detached(priority: .userInitiated) {
                    var value = PGVisionProbeResult()
                    PGRunVisionComponent(section.url.path, signature, kind.usesBuiltin ? 2 : 0, &value)
                    return value
                }.value
                record.componentStatusCode = Int(result.status)
                record.componentTensorLayout = withUnsafePointer(to: result) { String(cString: PGVisionProbeTensors($0)) }
                record.outputFinite = result.nonfinite_elements == 0 && result.output_elements > 0 && result.status == 0
                record.advance(String(cString: PGVisionProbeStage(result.stage)))
                guard result.status == 0 else {
                    let details = withUnsafePointer(to: result) { String(cString: PGVisionProbeError($0)) }
                    throw ProbeError.component(status: Int(result.status), details: details)
                }
                guard record.outputFinite == true else { throw ProbeError.nonfinite }
                description = "\(kind.title)：実行成功。出力\(result.output_elements)要素、非有限値\(result.nonfinite_elements)。これは合成テンソルの単体検証で、画像について回答した結果ではありません。"
            } else {
                let portrait = kind == .portraitJPEG
                guard let jpeg = Bundle.main.url(forResource: portrait ? "vision-probe-portrait" : "vision-probe-square", withExtension: "jpg") else {
                    throw ProbeError.fixtureMissing
                }
                record.inputImageDimensions = [portrait ? "1200x1600" : "512x512"]
                let jpegData = try Data(contentsOf: jpeg)
                record.inputFixtureSHA256 = SHA256.hash(data: jpegData).map { String(format: "%02x", $0) }.joined()
                let config = try EngineConfig(modelPath: AppFiles.model(model).path,
                    backend: main == .gpu ? .gpu : .cpu(),
                    visionBackend: vision == .gpu ? .gpu : .cpu(), maxNumTokens: contextTokens, cacheDir: work.path,
                    visionCpuKernelMode: kernel == .builtin ? .builtin : .xnnpack)
                ExperimentalFlags.optIntoExperimentalAPIs()
                ExperimentalFlags.visualTokenBudget = Int32(visionTokens)
                ExperimentalFlags.enableSpeculativeDecoding = false
                let engine = Engine(engineConfig: config)
                record.advance("engine_initialization")
                try await engine.initialize()
                record.advance("conversation_creation")
                let conversation = try await engine.createConversation(with: ConversationConfig(
                    samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
                    thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
                    automaticToolCalling: false, visualTokenBudget: Int32(visionTokens), enableSpeculativeDecoding: false))
                record.advance("image_prefill")
                let response = try await conversation.sendMessage(Message(contents: [
                    .imageFile(jpeg.path), .text("Describe the main shape and its color in English with one short sentence.")
                ]), maxOutputTokens: 128)
                guard !response.toString.isEmpty else { throw ProbeError.emptyReply }
                description = "\(kind.title)：回答 \(response.toString)"
                record.advance("complete")
            }
            record.result = "success"
            record.recordNativeLog(log?.finish()); record.recordMemory(memory.finish()); record.save()
            return description
        } catch {
            record.result = "failed"
            record.nativeError = InferenceDiagnostic.sanitize(error.localizedDescription)
            record.failureKind = NativeFailureKind(description: error.localizedDescription)
            record.availableMemoryAtFailure = UInt64(os_proc_available_memory())
            record.recordFailureAddressSpace()
            record.recordNativeLog(log?.finish(), error: record.nativeError ?? "")
            record.recordMemory(memory.finish()); record.save()
            throw error
        }
    }

    /// Offsets are from the pinned containers whose full SHA256 is verified at
    /// installation. Copy bytes verbatim; never rewrite metadata or weights.
    private static func extract(model: ModelSpec, encoder: Bool, to work: URL) throws -> (url: URL, sha256: String) {
        let ranges: (encoder: Range<UInt64>, adapter: Range<UInt64>)
        if model.id == ModelSpec.e2b.id {
            ranges = (1_496_612_864..<1_720_750_800, 1_720_762_368..<1_725_505_296)
        } else {
            ranges = (1_122_271_232..<1_346_409_168, 1_346_420_736..<1_354_309_392)
        }
        let range = encoder ? ranges.encoder : ranges.adapter
        let source = try FileHandle(forReadingFrom: AppFiles.model(model))
        defer { try? source.close() }
        try source.seek(toOffset: range.lowerBound)
        let url = work.appendingPathComponent(encoder ? "encoder.tflite" : "adapter.tflite")
        guard FileManager.default.createFile(atPath: url.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
        let destination = try FileHandle(forWritingTo: url)
        defer { try? destination.close() }
        var remaining = range.count, hash = SHA256()
        while remaining > 0 {
            let count = min(4_194_304, remaining)
            guard let data = try source.read(upToCount: count), data.count == count else { throw CocoaError(.fileReadCorruptFile) }
            try destination.write(contentsOf: data); hash.update(data: data); remaining -= count
        }
        try destination.synchronize()
        return (url, hash.finalize().map { String(format: "%02x", $0) }.joined())
    }
    private enum ProbeError: LocalizedError {
        case modelMissing, fixtureMissing, emptyReply, nonfinite, budget
        case component(status: Int, details: String)
        var errorDescription: String? {
            switch self {
            case .modelMissing: return "検証するE2BまたはE4Bを先にインストールしてください。"
            case .fixtureMissing: return "同梱の検証JPEGが見つかりません。"
            case .emptyReply: return "検証の回答が空でした。"
            case .nonfinite: return "画像コンポーネントの出力が空か、NaN/Infinityを含みました。"
            case .budget: return "このモデルの画像トークンは70・140・280から選んでください。"
            case .component(let status, let details): return "画像コンポーネントのLiteRT status: \(status)\n\(details.isEmpty ? "追加のネイティブエラーなし" : details)"
            }
        }
    }
}
