import Foundation
import Combine
import UIKit
import Network
import PocketCore

/// The file a task downloads: a model, or a part of one (LFM3-VL 2B's
/// picture projector, 1.1.0 (234)).
private func downloadSpec(_ task: URLSessionTask) -> ModelSpec? {
    if let spec = ModelSpec.findFile(task.taskDescription) { return spec }
    // Background downloads started by 1.0.4 did not have taskDescription.
    let file = task.originalRequest?.url?.lastPathComponent
    return ModelSpec.allFiles.first { $0.fileName == file }
}

@MainActor
final class ModelStore: NSObject, ObservableObject {
    static let shared = ModelStore()
    @Published private(set) var selectedModel: ModelSpec
    /// The files checked and saved, by id: a model is installed when all of
    /// its files are (`ModelSpec.files`; LFM3-VL 2B has two since 1.1.0 (234)).
    @Published private(set) var installedIDs: Set<String>
    /// Running downloads and their progress by file id. Several can run at
    /// once; they share the Live Activity, which shows each model whole.
    @Published private(set) var downloads: [String: Double] = [:]
    /// The file being checked. Checks run one at a time; downloads that
    /// finish meanwhile wait in `queuedIDs`.
    @Published private(set) var verifyingID: String?
    @Published private(set) var queuedIDs: Set<String> = []
    @Published private(set) var isRestoring = true
    @Published var error: String?
    /// モデルと設定's モバイル通信でもダウンロード. A download keeps the
    /// choice it started with; one that has received nothing worth keeping
    /// starts again with the new one.
    @Published var allowsCellular = UserDefaults.standard.bool(forKey: ModelDownload.cellularKey) {
        didSet {
            guard allowsCellular != oldValue else { return }
            UserDefaults.standard.set(allowsCellular, forKey: ModelDownload.cellularKey)
            DownloadLog.shared.note("モバイル通信でのダウンロード: \(allowsCellular ? "オン" : "オフ")")
            restartUnstartedDownloads()
        }
    }
    /// Running downloads that may use cellular data.
    @Published private(set) var cellularIDs: Set<String> = []
    @Published private(set) var network = DownloadNetwork.unknown
    private let networkMonitor = NWPathMonitor()
    /// Satisfied only by a network other than cellular.
    private let wifiMonitor = NWPathMonitor(prohibitedInterfaceTypes: [.cellular])
    /// Tasks cancelled to start again (the other cellular choice, a stall,
    /// a task no download followed): their end is not the download's. By
    /// `taskKey`, as each session counts its tasks from 1.
    private var restartedTasks: Set<String> = []
    private var backgroundCompletion: (() -> Void)?
    private let liveActivity = DownloadActivity()
    /// While a download runs: reads the tasks' progress every two seconds
    /// (in case progress reports stop coming while the app is in the
    /// background) and writes a line to the download record every ten.
    private var progressTimer: Timer?
    private var ticks = 0
    private var progressReports = 0
    /// Bytes each download had at the last line of the record, for its speed.
    private var lastLogged: [String: (date: Date, bytes: Int64)] = [:]
    /// A model's file that failed or was cancelled while another of its
    /// files was still under way: the island ends with it.
    private var fileEndings: [String: DownloadActivity.Outcome] = [:]
    /// Running files that have received nothing for a while on screen
    /// (1.1.0 (240)): their card says they wait for the Hub, instead of a
    /// 0% that never moves (TestFlight 239).
    @Published private(set) var waitingIDs: Set<String> = []
    /// Why each model's last download stopped, by model id, for its card
    /// until the next download (1.1.0 (240)).
    @Published private(set) var failures: [String: String] = [:]
    private var stalls: [String: DownloadStall] = [:]
    /// Times a file's download started again by itself (stalled, link ran
    /// out, connection broke); at most `DownloadStall.restarts`.
    private var autoRestarts: [String: Int] = [:]
    /// Files whose task goes on from resume data: when that fails, the file
    /// starts over once from the beginning (the Hub's CDN link lasts an hour).
    private var resumedIDs: Set<String> = []
    /// Polls in a row that found no task for a running file.
    private var missingPolls: [String: Int] = [:]
    /// Wi-Fi in 低データモード, for the download record.
    private var lowDataMode = false
    /// Files received by the app itself (`directSession`) while it runs.
    private var directIDs: Set<String> = []

    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: "app.pocketgemma.model-download")
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        // Each download's request decides (ModelDownload.request): a
        // background session's configuration can't change while the app runs.
        config.allowsCellularAccess = true
        // One connection per model, so simultaneous downloads really run
        // side by side (the catalog shares a host).
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    /// The app's own session (1.1.0 (240)), for a file the background
    /// session has not started to receive although the network is up and
    /// the app is on screen (TestFlight 239: E2B at 0% with no end). It
    /// receives while the app runs: on screen, or kept running in the
    /// background by the continued-processing task. When the app leaves the
    /// screen without that task, the file goes back to the background
    /// session from what it received.
    private lazy var directSession: URLSession = {
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        config.allowsCellularAccess = true
        config.httpMaximumConnectionsPerHost = 4
        config.timeoutIntervalForResource = 7 * 24 * 3600
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    /// A task's name across both sessions.
    nonisolated private static func taskKey(_ task: URLSessionTask, in session: URLSession) -> String {
        (session.configuration.identifier == nil ? "app-" : "bg-") + String(task.taskIdentifier)
    }

    /// Every task of both sessions with its `taskKey`.
    private func everyTask(_ body: @escaping @Sendable ([(key: String, task: URLSessionTask)]) -> Void) {
        let background = session, direct = directSession
        background.getAllTasks { first in
            direct.getAllTasks { second in
                body(first.map { (Self.taskKey($0, in: background), $0) } + second.map { (Self.taskKey($0, in: direct), $0) })
            }
        }
    }

    private override init() {
        AppFiles.migrateModels()
        let installed = Self.savedFiles()
        installedIDs = installed
        // A model never chosen: E2B on a new phone, which the setup gets
        // ready first (1.1.0 (219)); E4B, as before, on a phone that has a
        // model saved from before the choice was kept.
        let hasModel = ModelSpec.catalog.contains { $0.files.allSatisfy { installed.contains($0.id) } }
        selectedModel = ModelSpec.find(UserDefaults.standard.string(forKey: "selectedModelID"))
            ?? (hasModel ? .e4b : .e2b)
        super.init()
        if let moved = AppFiles.storageNote { DownloadLog.shared.note("保存先の移動 " + moved) }
        DownloadLog.shared.watchApp()
        watchNetwork()
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.handOverDirectDownloads() }
        }
        session.getAllTasks { tasks in
            Task { @MainActor in
                // A completion delegate may already have started validation
                // while getAllTasks was in flight. Do not restore that old
                // download state over the newer verification state.
                let live = tasks.filter { $0.state != .completed && $0.state != .canceling }
                DownloadLog.shared.note("起動時のダウンロードタスク \(live.count)件")
                for task in live {
                    // A 12B download left running when it was locked.
                    if task.taskDescription == ModelSpec.gemma12B.id && ModelSpec.gemma12B.isLocked { task.cancel(); continue }
                    guard let spec = downloadSpec(task) else { continue }
                    // By file, not by model: until 1.1.0 (240) the model
                    // file of LFM3-VL 2B or LFM3-Omni 2B was left unfollowed
                    // when its projector's task came first. A second task
                    // for one file, or one for a file already saved, would
                    // only download it again.
                    if self.downloads[spec.id] != nil || self.verifyingID == spec.id || self.queuedIDs.contains(spec.id)
                        || AppFiles.library.hasFile(spec) {
                        self.restartedTasks.insert(Self.taskKey(task, in: self.session))
                        task.cancel()
                        DownloadLog.shared.note("重なったタスクを止めた \(spec.name)")
                        continue
                    }
                    let fraction = task.progress.fractionCompleted
                    self.downloads[spec.id] = fraction
                    self.stalls[spec.id] = DownloadStall(bytes: task.countOfBytesReceived)
                    self.setCellular(task.originalRequest?.allowsCellularAccess ?? false, for: spec)
                    self.liveActivity.begin(spec.owner, fraction: self.progress(for: spec.owner), userInitiated: false)
                    DownloadLog.shared.note("続きから \(spec.name) \(Int(fraction * 100))%")
                    self.watchProgress()
                }
                self.isRestoring = false
                self.restoreNextPending()
                let working = Set(self.downloads.keys).union(self.queuedIDs).union([self.verifyingID].compactMap { $0 })
                self.liveActivity.endAll(except: Set(working.compactMap { ModelSpec.findFile($0)?.owner.id }))
            }
        }
    }

    var isReady: Bool { isInstalled(selectedModel) }
    /// Restoring or checking a file: imports and automatic choices wait.
    var isBusy: Bool { isRestoring || verifyingID != nil }
    func isInstalled(_ spec: ModelSpec) -> Bool { spec.files.allSatisfy { installedIDs.contains($0.id) } }
    func isDownloading(_ spec: ModelSpec) -> Bool { spec.files.contains { downloads[$0.id] != nil } }
    /// How far the model's download is: its files' bytes together, those
    /// already saved or being checked included.
    func progress(for spec: ModelSpec) -> Double {
        guard !spec.parts.isEmpty else { return downloads[spec.id] ?? 0 }
        let received = spec.files.reduce(0.0) { sum, file in
            let done = installedIDs.contains(file.id) || verifyingID == file.id || queuedIDs.contains(file.id)
            return sum + (downloads[file.id] ?? (done ? 1 : 0)) * Double(file.byteCount)
        }
        return received / Double(spec.downloadByteCount)
    }
    /// What a running download waits for, or nil while it can receive.
    func downloadWait(for spec: ModelSpec) -> DownloadWait? {
        isDownloading(spec) ? network.wait(usesCellular: spec.files.contains { cellularIDs.contains($0.id) }) : nil
    }
    /// A running download whose files have received nothing for a while
    /// although the network is up (1.1.0 (240)).
    func isWaitingForData(_ spec: ModelSpec) -> Bool {
        spec.files.contains { waitingIDs.contains($0.id) && downloads[$0.id] != nil }
    }
    func isWorking(on spec: ModelSpec) -> Bool {
        spec.files.contains { downloads[$0.id] != nil || verifyingID == $0.id || queuedIDs.contains($0.id) }
    }
    /// The files saved, checked again whenever モデル管理 opens.
    func refreshInstalled() {
        guard !isBusy else { return }
        let current = Self.savedFiles()
        if current != installedIDs { installedIDs = current }
    }
    /// Every model file checked and saved, the parts of models included.
    private static func savedFiles() -> Set<String> {
        Set(ModelSpec.allFiles.filter { AppFiles.library.hasFile($0) }.map(\.id))
    }
    func select(_ spec: ModelSpec) {
        // The startup chooser records the preferred model before downloading
        // it. Readiness still depends on its verified installation receipt.
        // A locked model is not in the catalog, so it is never chosen.
        guard !spec.isLocked, ModelSpec.find(spec.id) != nil else { return }
        selectedModel = spec
        UserDefaults.standard.set(spec.id, forKey: "selectedModelID")
    }
    func statusText(for spec: ModelSpec) -> String {
        if isRestoring { return String(localized: "モデルを確認しています…") }
        // A model of several files shows its download while any still comes.
        if isDownloading(spec) {
            let percent = Int(progress(for: spec) * 100)
            if let wait = downloadWait(for: spec) { return wait.status(name: spec.name, percent: percent) }
            if isWaitingForData(spec) { return String(localized: "\(spec.name)の受信を待っています · \(percent)%") }
            return String(localized: "\(spec.name)をダウンロード中 · \(percent)%")
        }
        if spec.files.contains(where: { verifyingID == $0.id }) { return String(localized: "\(spec.name)を確認しています…") }
        if spec.files.contains(where: { queuedIDs.contains($0.id) }) { return String(localized: "\(spec.name)の確認を待っています…") }
        if isInstalled(spec) { return String(localized: "ダウンロード済み · オフラインで利用できます") }
        let missing = spec.files.filter { !installedIDs.contains($0.id) }
        if missing.count < spec.files.count {
            let size = ByteCountFormatter.string(fromByteCount: missing.reduce(0) { $0 + $1.byteCount }, countStyle: .decimal)
            return String(localized: "ファイルの一部が保存済みです · 残りの\(size)をダウンロードしてください")
        }
        return String(localized: "モデルを選んでダウンロードしてください")
    }

    func download(_ spec: ModelSpec) {
        // A locked model is listed only.
        guard !spec.isLocked, !isRestoring, !isWorking(on: spec), !isInstalled(spec) else { return }
        // The developer 12B check's file, checked when it was downloaded,
        // becomes the chat's (a rename in the app's folder), and the check's
        // caches go: the chat builds its own for its longer context.
        if spec.id == ModelSpec.gemma12B.id, LargeModelProbeFiles.ownFileReady {
            do {
                try AppFiles.prepareModels()
                try FileManager.default.moveItem(at: LargeModelProbeFiles.ownModel, to: AppFiles.pendingModel(spec))
                try AppFiles.installVerifiedModel(spec)
                LargeModelProbeFiles.handedOver()
                installedIDs.insert(spec.id)
                DownloadLog.shared.note("\(spec.name)は12Bの動作確認のファイルを使う")
            } catch { self.error = error.localizedDescription }
            return
        }
        do {
            try AppFiles.prepareModels()
            let values = try AppFiles.models.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            // The model's files not saved yet, side by side: LFM3-VL 2B's
            // model and picture projector (1.1.0 (234)), or what is left of them.
            let missing = spec.files.filter { !installedIDs.contains($0.id) }
            // Room for these and for the others still downloading.
            let others = downloads.keys.compactMap { ModelSpec.findFile($0)?.byteCount }.reduce(0, +)
            if let available = values.volumeAvailableCapacityForImportantUsage,
               available < missing.reduce(0, { $0 + $1.byteCount }) + others + 1_000_000_000 {
                throw NSError(domain: "PocketGemma", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: String(localized: "空き容量が不足しています。モデルのサイズに加えて1 GB以上の空きが必要です。")])
            }
            error = nil
            failures[spec.id] = nil
            for file in missing {
                downloads[file.id] = 0
                autoRestarts[file.id] = 0
            }
            // Waiting for Wi-Fi (or any network), nothing would move, and iOS
            // ends a background task that does not move and shows it as
            // タスクエラー (1.1.0 (247)): the card says what it waits for and
            // the app's own activity shows it, without iOS's task.
            let waits = network.wait(usesCellular: allowsCellular) != nil
            liveActivity.begin(spec, fraction: progress(for: spec), userInitiated: !waits)
            let files = spec.parts.isEmpty ? "" : "（\(missing.map(\.fileName).joined(separator: "・"))）"
            DownloadLog.shared.note("ダウンロード開始 \(spec.name)\(files)（\(allowsCellular ? "モバイル通信も使う" : "Wi-Fiのみ")・\(networkText)）・\(pathDetail)"
                + (waits ? "・通信を待つため続ける作業は申し込まない" : ""))
            watchProgress()
            everyTask { tasks in
                Task { @MainActor in self.startFiles(missing, among: tasks) }
            }
        } catch { self.error = error.localizedDescription }
    }

    /// Starts the files' tasks, after stopping the session's tasks that no
    /// download follows (1.1.0 (240)): one left for a file starting now, or
    /// for a file the app no longer shows as downloading. Such a task still
    /// takes one of the four connections to the Hub, and its end would be
    /// taken for the new download's.
    private func startFiles(_ files: [ModelSpec], among tasks: [(key: String, task: URLSessionTask)]) {
        let live = tasks.filter { $0.task.state == .running || $0.task.state == .suspended }
        let starting = Set(files.map(\.id))
        var stopped: [String] = []
        for (key, task) in live {
            let id = downloadSpec(task)?.id ?? task.taskDescription ?? ""
            guard starting.contains(id) || downloads[id] == nil else { continue }
            restartedTasks.insert(key)
            task.cancel()
            stopped.append("\(ModelSpec.findFile(id)?.name ?? id) \(Self.figures(task))")
        }
        DownloadLog.shared.note("セッションのタスク \(live.count)件" + (stopped.isEmpty ? "" : "・追われていないタスクを止めた: " + stopped.joined(separator: " / ")))
        for file in files where downloads[file.id] != nil {
            startTask(file)
        }
    }

    /// A file's task: from what an earlier task of it received, when that
    /// was kept (resume data), else from the beginning.
    private func startTask(_ spec: ModelSpec, fresh: Bool = false) {
        let resumeURL = AppFiles.library.resumeURL(spec)
        let resumeData = fresh ? nil : (try? Data(contentsOf: resumeURL)).flatMap(Self.usableResumeData)
        try? FileManager.default.removeItem(at: resumeURL)
        let chosen = directIDs.contains(spec.id) ? directSession : session
        let task = resumeData.map { chosen.downloadTask(withResumeData: $0) }
            ?? chosen.downloadTask(with: ModelDownload.request(for: spec, cellular: allowsCellular))
        task.taskDescription = spec.id
        task.resume()
        if resumeData != nil {
            resumedIDs.insert(spec.id)
            DownloadLog.shared.note("続きから受け取る \(spec.name)")
        } else { resumedIDs.remove(spec.id) }
        stalls[spec.id] = DownloadStall()
        missingPolls[spec.id] = nil
        waitingIDs.remove(spec.id)
        setCellular(task.originalRequest?.allowsCellularAccess ?? allowsCellular, for: spec)
    }

    /// Resume data the session can take: URLSession's property list.
    nonisolated private static func usableResumeData(_ data: Data) -> Data? {
        (try? PropertyListSerialization.propertyList(from: data, format: nil)) is [String: Any] ? data : nil
    }

    /// A task's figures for the download record: state, bytes, the Hub's
    /// answer and the host it came from.
    nonisolated private static func figures(_ task: URLSessionTask) -> String {
        let state = switch task.state {
        case .running: "実行中"
        case .suspended: "一時停止"
        case .canceling: "中止中"
        case .completed: "完了"
        @unknown default: "不明"
        }
        let answer = (task.response as? HTTPURLResponse).map { "HTTP \($0.statusCode)" } ?? "応答なし"
        return "（\(state)・受信 \(task.countOfBytesReceived / 1_000_000) MB・\(answer)・\(task.currentRequest?.url?.host ?? "-")）"
    }

    private func setCellular(_ cellular: Bool, for spec: ModelSpec) {
        if cellular { cellularIDs.insert(spec.id) } else { cellularIDs.remove(spec.id) }
    }

    /// After the switch changed: downloads with the other choice that have
    /// received less than 1% start again with this one. The rest keep theirs,
    /// so what they received is not thrown away.
    private func restartUnstartedDownloads() {
        let cellular = allowsCellular
        session.getAllTasks { tasks in
            let unstarted = tasks.filter { task in
                guard task.state == .running || task.state == .suspended, let spec = downloadSpec(task) else { return false }
                let expected = task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount
                return (task.originalRequest?.allowsCellularAccess ?? false) != cellular
                    && ModelDownload.startsOver(receivedBytes: task.countOfBytesReceived, expectedBytes: expected)
            }
            Task { @MainActor in
                // The switch may have changed back while the tasks were read.
                guard self.allowsCellular == cellular else { return }
                for task in unstarted {
                    guard let spec = downloadSpec(task), self.downloads[spec.id] != nil else { continue }
                    self.restartedTasks.insert(Self.taskKey(task, in: self.session))
                    task.cancel()
                    self.startTask(spec)
                    DownloadLog.shared.note("始め直し \(spec.name)（\(cellular ? "モバイル通信も使う" : "Wi-Fiのみ")）")
                    // A download that waited for Wi-Fi asked iOS for no
                    // background task; turning the switch on lets it go now.
                    if cellular, UIApplication.shared.applicationState == .active {
                        self.liveActivity.begin(spec.owner, fraction: self.progress(for: spec.owner), userInitiated: true)
                    }
                }
            }
        }
    }

    /// Wi-Fi and cellular as iOS reports them, for what a download waits for.
    private func watchNetwork() {
        let queue = DispatchQueue(label: "app.pocketgemma.download-network")
        networkMonitor.pathUpdateHandler = { [weak self] path in
            let online = path.status == .satisfied
            let denied = path.unsatisfiedReason == .cellularDenied
            let constrained = path.isConstrained
            let detail = NetworkCheck.describe(path)
            Task { @MainActor in
                guard let self else { return }
                self.lowDataMode = constrained
                self.pathDetail = detail
                self.networkChanged { $0.isOnline = online; $0.cellularDenied = denied }
                self.noteNetwork()
            }
        }
        wifiMonitor.pathUpdateHandler = { [weak self] path in
            // A tunnel iOS keeps over cellular (utun, of type other) also
            // satisfies a path without cellular, and a Wi-Fi-only download
            // still cannot use it: on 5G alone the app took it for Wi-Fi and
            // said nothing while LFM3 waited at 0% (1.1.0 (247)).
            let wifi = path.status == .satisfied
                && (path.usesInterfaceType(.wifi) || path.usesInterfaceType(.wiredEthernet)
                    || path.availableInterfaces.contains { $0.type == .wifi || $0.type == .wiredEthernet })
            Task { @MainActor in self?.networkChanged { $0.hasWiFi = wifi } }
        }
        networkMonitor.start(queue: queue)
        wifiMonitor.start(queue: queue)
    }

    private func networkChanged(_ change: (inout DownloadNetwork) -> Void) {
        var next = network
        change(&next)
        guard next != network else { return }
        network = next
        noteNetwork()
    }

    private var networkText: String {
        (network.hasWiFi ? "Wi-Fi" : network.isOnline ? "モバイル通信" : network.cellularDenied ? "モバイル通信は設定でオフ" : "通信なし")
            + (lowDataMode && network.isOnline ? "（低データモード）" : "")
    }
    /// The path as iOS reports it (IPv4, IPv6, DNS, the interfaces), for the
    /// record only (1.1.0 (241): E2B stalled on Wi-Fi and went on over 5G).
    private var pathDetail = ""
    private var notedNetwork: String?
    /// The download record names each change of network while a download runs.
    private func noteNetwork() {
        let text = networkText + (pathDetail.isEmpty ? "" : "・" + pathDetail)
        guard !downloads.isEmpty, text != notedNetwork else { return }
        notedNetwork = text
        DownloadLog.shared.note("通信: \(text)")
    }

    private func watchProgress() {
        guard progressTimer == nil else { return }
        ticks = 0
        progressTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.pollProgress() }
        }
    }

    private func pollProgress() {
        guard !downloads.isEmpty else {
            progressTimer?.invalidate()
            progressTimer = nil
            lastLogged = [:]
            return
        }
        ticks += 1
        everyTask { tasks in
            let live = tasks.filter { $0.task.state == .running || $0.task.state == .suspended }
            let received: [(id: String, bytes: Int64, expected: Int64)] = live.compactMap { _, task in
                guard task.state == .running, let spec = downloadSpec(task) else { return nil }
                return (spec.id, task.countOfBytesReceived,
                        task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount)
            }
            let carried = live.compactMap { key, task in downloadSpec(task).map { (id: $0.id, task: key, bytes: task.countOfBytesReceived) } }
            let details = live.map { key, task in
                "\(downloadSpec(task)?.name ?? task.taskDescription ?? "?")\(key.hasPrefix("app-") ? "・アプリで受信" : "")\(Self.figures(task))"
            }
            Task { @MainActor in
                self.applyPolledProgress(received, details: details)
                self.watchStalls(carried)
            }
        }
    }

    /// While the app is on screen: a running file that has received nothing
    /// for `DownloadStall.noticeAfter` says so on its card; after
    /// `restartAfter` its task starts again from what it has, at most
    /// `DownloadStall.restarts` times, and then the download stops with
    /// `.stalled`. A file the app shows as downloading with no task under
    /// it starts its task again. Off screen iOS may hold a background
    /// download back on purpose, so nothing is counted there.
    private func watchStalls(_ carried: [(id: String, task: String, bytes: Int64)]) {
        let now = Date()
        let onScreen = UIApplication.shared.applicationState == .active
        for id in Array(downloads.keys) {
            guard let file = ModelSpec.findFile(id) else { continue }
            let usesCellular = cellularIDs.contains(id)
            guard onScreen, network.wait(usesCellular: usesCellular) == nil else {
                stalls[id] = nil
                missingPolls[id] = nil
                waitingIDs.remove(id)
                continue
            }
            guard let task = carried.filter({ $0.id == id }).max(by: { $0.bytes < $1.bytes }) else {
                missingPolls[id, default: 0] += 1
                // Five polls (ten seconds) on screen with no task, and no
                // file waiting for its check: nothing will ever report.
                if missingPolls[id, default: 0] >= 5, verifyingID != id, !queuedIDs.contains(id),
                   !FileManager.default.fileExists(atPath: AppFiles.pendingModel(file).path) {
                    missingPolls[id] = nil
                    DownloadLog.shared.note("タスクが見つからない \(file.name)・始め直す")
                    startTask(file)
                }
                continue
            }
            missingPolls[id] = nil
            var stall = stalls[id] ?? DownloadStall(bytes: task.bytes, now: now)
            let idle = stall.idle(received: task.bytes, now: now)
            stalls[id] = stall
            guard idle >= DownloadStall.noticeAfter else { waitingIDs.remove(id); continue }
            if waitingIDs.insert(id).inserted {
                DownloadLog.shared.note("受信が\(Int(idle))秒止まっている \(file.name)（受信 \(task.bytes / 1_000_000) MB・\(networkText)）")
            }
            guard idle >= DownloadStall.restartAfter else { continue }
            stalls[id] = DownloadStall(bytes: task.bytes, now: now)
            if autoRestarts[id, default: 0] < DownloadStall.restarts {
                autoRestarts[id, default: 0] += 1
                // The app receives the file itself while it runs when iOS's
                // download service has not delivered a byte, or stalled twice.
                let direct = !directIDs.contains(id) && (task.bytes == 0 || autoRestarts[id, default: 0] >= DownloadStall.restarts)
                if direct { directIDs.insert(id) }
                restart(file, task: task.task, reason: "受信が\(Int(idle))秒止まった" + (direct ? "・アプリで直接受け取る" : ""))
            } else {
                stop(file, task: task.task, failure: .stalled)
            }
        }
    }

    /// Stops the file's task, keeping what it received, and starts it again
    /// from there.
    private func restart(_ file: ModelSpec, task identifier: String, reason: String) {
        restartedTasks.insert(identifier)
        stopTask(identifier) { data in
            guard self.downloads[file.id] != nil else { return }
            if let data { try? data.write(to: AppFiles.library.resumeURL(file)) }
            DownloadLog.shared.note("始め直し \(file.name)（\(reason)・\(data == nil ? "最初から" : "続きから")）")
            self.startTask(file)
        }
    }

    /// Stops the file's task for good, keeping what it received for the
    /// next download.
    private func stop(_ file: ModelSpec, task identifier: String, failure: DownloadFailure) {
        restartedTasks.insert(identifier)
        stopTask(identifier) { data in
            if let data { try? data.write(to: AppFiles.library.resumeURL(file)) }
            self.fail(file, failure, keepsReceived: data != nil)
        }
    }

    private func stopTask(_ identifier: String, then: @escaping @MainActor @Sendable (Data?) -> Void) {
        everyTask { tasks in
            guard let task = tasks.first(where: { $0.key == identifier })?.task as? URLSessionDownloadTask else {
                Task { @MainActor in then(nil) }
                return
            }
            task.cancel(byProducingResumeData: { data in Task { @MainActor in then(data) } })
        }
    }

    /// Ends a file's download as failed: the alert, the card's line, the
    /// island and the record say why.
    private func fail(_ file: ModelSpec, _ failure: DownloadFailure, keepsReceived: Bool) {
        guard downloads[file.id] != nil else { return }
        downloads[file.id] = nil
        forgetWatch(file.id)
        let message = failure.message(keepsReceived: keepsReceived)
        error = file.owner.name + "\n" + message
        failures[file.owner.id] = message
        finishActivity(file, .failed)
        DownloadLog.shared.note("ダウンロード失敗 \(file.name) [\(failure.logText)]" + (keepsReceived ? "・受け取った分を残した" : ""))
    }

    /// The app leaves the screen without the continued-processing task: a
    /// file it receives itself goes back to the background session from
    /// what it has, so it goes on while the app is suspended. Back on
    /// screen, a stall may bring it to the app again.
    private func handOverDirectDownloads() {
        guard !directIDs.isEmpty, !liveActivity.isContinuing else { return }
        let ids = directIDs
        let direct = directSession
        // A few seconds off screen to hand the files over before iOS
        // suspends the app.
        let handover = UIApplication.shared.beginBackgroundTask(withName: "model-download-handover", expirationHandler: nil)
        Task {
            try? await Task.sleep(for: .seconds(8))
            UIApplication.shared.endBackgroundTask(handover)
        }
        direct.getAllTasks { tasks in
            let handed = tasks.filter { ($0.state == .running || $0.state == .suspended) && ids.contains(downloadSpec($0)?.id ?? "") }
            Task { @MainActor in
                for task in handed {
                    guard let spec = downloadSpec(task), let download = task as? URLSessionDownloadTask else { continue }
                    self.restartedTasks.insert(Self.taskKey(task, in: direct))
                    self.directIDs.remove(spec.id)
                    self.autoRestarts[spec.id] = 0
                    download.cancel(byProducingResumeData: { data in
                        Task { @MainActor in
                            if let data { try? data.write(to: AppFiles.library.resumeURL(spec)) }
                            guard self.downloads[spec.id] != nil else { return }
                            DownloadLog.shared.note("裏に回るのでiOSの受け取りへ戻す \(spec.name)")
                            self.startTask(spec)
                        }
                    })
                }
            }
        }
    }

    private func stopOtherTasks(of file: ModelSpec, except identifier: String) {
        everyTask { tasks in
            let others = tasks.filter { $0.key != identifier && $0.task.state != .completed && downloadSpec($0.task)?.id == file.id }
            Task { @MainActor in
                for (key, task) in others {
                    self.restartedTasks.insert(key)
                    task.cancel()
                }
            }
        }
    }

    private func forgetWatch(_ id: String) {
        directIDs.remove(id)
        stalls[id] = nil
        missingPolls[id] = nil
        waitingIDs.remove(id)
        resumedIDs.remove(id)
    }

    private func applyPolledProgress(_ received: [(id: String, bytes: Int64, expected: Int64)], details: [String]) {
        for (id, bytes, expected) in received {
            guard let spec = ModelSpec.findFile(id), let shown = downloads[id] else { continue }
            let fraction = min(1, Double(bytes) / Double(expected))
            if fraction - shown > 0.005 {
                downloads[id] = fraction
                liveActivity.update(spec.owner, fraction: progress(for: spec.owner))
            }
        }
        guard ticks % 5 == 1 else { return }
        let now = Date()
        let figures = received.compactMap { id, bytes, _ -> String? in
            guard let spec = ModelSpec.findFile(id) else { return nil }
            // The speed since the last line tells a slower background
            // transfer apart from a figure that only stopped moving.
            var speed = ""
            if let last = lastLogged[id], bytes >= last.bytes, now.timeIntervalSince(last.date) > 1 {
                speed = String(format: " · %.1f MB/秒", Double(bytes - last.bytes) / 1_000_000 / now.timeIntervalSince(last.date))
            }
            lastLogged[id] = (now, bytes)
            return "\(spec.name) \(Int((downloads[id] ?? 0) * 100))%（受信 \(bytes / 1_000_000) MB\(speed)）"
        }
        DownloadLog.shared.note((figures.isEmpty ? "受信中のタスクなし" : figures.joined(separator: " / "))
            + " · タスク: " + (details.isEmpty ? "なし" : details.joined(separator: " / "))
            + " · 進み報告\(progressReports)回 · 島の更新\(liveActivity.takeUpdateCount())回 · \(DownloadLog.appState)"
            + " · 続ける作業\(liveActivity.continuedState) · 島\(liveActivity.stateText)")
        progressReports = 0
    }

    /// Removes the receipts first, so a model whose files could not be
    /// removed never counts as installed. All of its files go.
    func delete(_ spec: ModelSpec) {
        guard !isWorking(on: spec) else { return }
        let library = AppFiles.library
        for file in spec.files {
            try? FileManager.default.removeItem(at: library.receiptURL(file))
            try? FileManager.default.removeItem(at: library.resumeURL(file))
            installedIDs.remove(file.id)
        }
        failures[spec.id] = nil
        do {
            // Also a copy an earlier version left in Documents (AppFiles.migrateModels).
            for file in spec.files {
                for url in library.allModelURLs(file) where FileManager.default.fileExists(atPath: url.path) {
                    try FileManager.default.removeItem(at: url)
                }
            }
            AppFiles.removeEngineCaches(spec)
        } catch { self.error = String(localized: "モデルを削除できませんでした。") + "\n" + error.localizedDescription }
    }

    /// Stops the model's downloads; what they received goes too.
    func cancelDownload(_ spec: ModelSpec) {
        for file in spec.files { try? FileManager.default.removeItem(at: AppFiles.library.resumeURL(file)) }
        everyTask { tasks in
            // By its description too: a locked model's task finds no spec.
            let mine = tasks.map(\.task).filter { $0.taskDescription == spec.id || downloadSpec($0)?.owner.id == spec.id }
            mine.forEach { $0.cancel() }
            let carried = Set(mine.filter { $0.state != .completed }.compactMap { downloadSpec($0)?.id })
            Task { @MainActor in
                // A download shown with no task under it (1.1.0 (240)):
                // nothing would ever report its end, so it ends here.
                for file in spec.files where self.downloads[file.id] != nil && !carried.contains(file.id) {
                    self.downloads[file.id] = nil
                    self.forgetWatch(file.id)
                    self.finishActivity(file, .cancelled)
                    DownloadLog.shared.note("中止 \(file.name)（タスクなし）")
                }
            }
        }
    }

    func importModel(_ url: URL, spec: ModelSpec) {
        guard !spec.isLocked, !isBusy, !isWorking(on: spec), !isInstalled(spec) else { return }
        guard url.pathExtension.lowercased() == spec.fileExtension else {
            // LFM3 is a GGUF file (1.1.0 (232)).
            error = spec.runtime == .llamaCpp ? String(localized: "選んだモデルの .gguf ファイルを取り込んでください。")
                : String(localized: "選んだモデルの .litertlm ファイルを取り込んでください。")
            return
        }
        let file = importedFile(url, of: spec)
        verifyingID = file.id
        error = nil
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    let granted = url.startAccessingSecurityScopedResource()
                    defer { if granted { url.stopAccessingSecurityScopedResource() } }
                    try AppFiles.prepareModels()
                    let pending = AppFiles.pendingModel(file)
                    var coordinationError: NSError?
                    var copyError: Error?
                    NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordinationError) { source in
                        do {
                            if FileManager.default.fileExists(atPath: pending.path) {
                                try FileManager.default.removeItem(at: pending)
                            }
                            try FileManager.default.copyItem(at: source, to: pending)
                        } catch { copyError = error }
                    }
                    if let coordinationError { throw coordinationError }
                    if let copyError { throw copyError }
                    try ModelValidator.validate(pending, spec: file)
                    try AppFiles.installVerifiedModel(file)
                }.value
                installedIDs.insert(file.id)
                // LFM3-VL 2B's other file is still to come.
                let left = spec.files.filter { !installedIDs.contains($0.id) }
                if !left.isEmpty {
                    let names = left.map(\.fileName).formatted(.list(type: .and))
                    error = String(localized: "\(spec.name)を使うには、あと\(names)も取り込んでください。")
                }
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(file))
            }
            verifyingID = nil
            restoreNextPending()
        }
    }

    /// Which of the model's files not saved yet an imported file is, known
    /// by its size: a model of several files takes them one at a time
    /// (LFM3-VL 2B's model or its picture projector, 1.1.0 (234)).
    private func importedFile(_ url: URL, of spec: ModelSpec) -> ModelSpec {
        let missing = spec.files.filter { !installedIDs.contains($0.id) }
        guard missing.count > 1 else { return missing.first ?? spec }
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize.map(Int64.init)
        return missing.first { $0.byteCount == size } ?? spec
    }

    private func restoreNextPending() {
        guard !isRestoring, verifyingID == nil else { return }
        if let spec = ModelSpec.allFiles.first(where: {
            downloads[$0.id] == nil && FileManager.default.fileExists(atPath: AppFiles.pendingModel($0).path)
        }) { verifyPendingFile(spec) }
    }

    /// Checks a downloaded file. A model of several files shows in the
    /// island as checking once none of them is still downloading.
    private func verifyPendingFile(_ spec: ModelSpec) {
        downloads[spec.id] = nil
        forgetWatch(spec.id)
        if !isDownloading(spec.owner) { liveActivity.verifying(spec.owner) }
        DownloadLog.shared.note("ファイルの確認へ \(spec.name)（\(DownloadLog.appState)）")
        guard verifyingID == nil else { queuedIDs.insert(spec.id); return }
        queuedIDs.remove(spec.id)
        verifyingID = spec.id
        Task {
            let outcome: DownloadActivity.Outcome
            do {
                try await Task.detached(priority: .userInitiated) {
                    try ModelValidator.validate(AppFiles.pendingModel(spec), spec: spec)
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
                if isInstalled(spec.owner) { failures[spec.owner.id] = nil }
                outcome = .installed
                DownloadLog.shared.note("保存完了 \(spec.name)（SHA-256一致）")
            } catch {
                // A file that is not the pinned one is never kept, and
                // never counts as saved (1.1.0 (240): the words say it was
                // the file's check, not the network).
                let failure = DownloadFailure.from(error)
                let message = failure.message()
                self.error = spec.owner.name + "\n" + message
                failures[spec.owner.id] = message
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
                outcome = .failed
                DownloadLog.shared.note("確認に失敗 \(spec.name) [\(failure.logText)]")
            }
            verifyingID = nil
            finishActivity(spec, outcome)
            restoreNextPending()
        }
    }

    /// The island's end for a file's model, once none of its files is under
    /// way: saved when all of them are; otherwise how a file of it ended.
    /// While another file goes on, the island shows the model's progress.
    private func finishActivity(_ file: ModelSpec, _ outcome: DownloadActivity.Outcome) {
        let model = file.owner
        if outcome != .installed { fileEndings[model.id] = outcome }
        guard !isWorking(on: model) else {
            // The other file still downloads, or waits for its check.
            if isDownloading(model) { liveActivity.update(model, fraction: progress(for: model)) } else { liveActivity.verifying(model) }
            return
        }
        let ending = fileEndings.removeValue(forKey: model.id) ?? outcome
        liveActivity.finish(model, isInstalled(model) ? .installed : ending == .installed ? .failed : ending)
    }

    /// A file's task ended without the file (1.1.0 (240)). What it received
    /// is kept for the next try. A task that went on from resume data and
    /// failed starts over once from the beginning: the Hub's CDN link in the
    /// data lasts an hour (run 40825923927), and the file behind it may have
    /// changed. A link that ran out, a broken connection or a stall starts
    /// again by itself up to `DownloadStall.restarts` times; anything else
    /// ends the download with words that say what happened.
    private func taskFailed(_ file: ModelSpec, _ failure: DownloadFailure, identifier: String,
                            resumeData: Data?, detail: String) {
        if restartedTasks.remove(identifier) != nil { return }
        guard downloads[file.id] != nil else { return }
        DownloadLog.shared.note("タスクが終わった \(file.name) [\(failure.logText)] \(detail)" + (resumeData == nil ? "" : "・続きのデータあり"))
        if resumedIDs.contains(file.id), resumeData == nil || failure.kind == .server {
            resumedIDs.remove(file.id)
            DownloadLog.shared.note("続きからを諦めて最初から \(file.name)")
            startTask(file, fresh: true)
            return
        }
        if let resumeData { try? resumeData.write(to: AppFiles.library.resumeURL(file)) }
        if failure.retriesAtOnce, autoRestarts[file.id, default: 0] < DownloadStall.restarts {
            autoRestarts[file.id, default: 0] += 1
            DownloadLog.shared.note("もう一度 \(file.name)（\(autoRestarts[file.id, default: 0])回目）")
            startTask(file)
            return
        }
        fail(file, failure, keepsReceived: resumeData != nil)
    }

    func attachBackgroundCompletion(_ completion: @escaping () -> Void) {
        backgroundCompletion = completion
        DownloadLog.shared.note("iOSがダウンロードの知らせで起こした（\(DownloadLog.appState)）")
        _ = session
    }
    private func finishBackgroundEventsIfPossible() {
        // The delegate has persisted the file. Hashing must not hold iOS's
        // background event completion handler for a multi-gigabyte pass.
        guard let completion = backgroundCompletion else { return }
        backgroundCompletion = nil
        // This launch is the app's background time: the island's change
        // (checking, saved, failed) goes out before iOS suspends the app.
        Task {
            await Task.yield()
            await liveActivity.flush()
            completion()
        }
    }
}

extension ModelStore: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                               totalBytesExpectedToWrite: Int64) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let expected = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : spec.byteCount
        let fraction = min(1, Double(totalBytesWritten) / Double(expected))
        Task { @MainActor in
            self.progressReports += 1
            guard let shown = self.downloads[spec.id] else { return }
            if abs(shown - fraction) > 0.005 || fraction == 1 {
                self.downloads[spec.id] = fraction
                self.liveActivity.update(spec.owner, fraction: self.progress(for: spec.owner))
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didFinishDownloadingTo location: URL) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let identifier = Self.taskKey(downloadTask, in: session)
        let status = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0
        // The Hub's answer when it is not the file (an error page, a link
        // that ran out): never moved where a model goes.
        if let failure = DownloadFailure.from(status: status) {
            let detail = "\(downloadTask.currentRequest?.url?.host ?? "-")"
            Task { @MainActor in self.taskFailed(spec, failure, identifier: identifier, resumeData: nil, detail: detail) }
            return
        }
        do {
            try AppFiles.prepareModels()
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) {
                try FileManager.default.removeItem(at: pending)
            }
            // URLSession removes its temporary file when this callback returns.
            try FileManager.default.moveItem(at: location, to: pending)
            Task { @MainActor in
                // A task stopped to start again that finished meanwhile: its
                // file is as good, and the task started after it goes.
                if self.restartedTasks.remove(identifier) != nil { self.stopOtherTasks(of: spec, except: identifier) }
                self.verifyPendingFile(spec)
            }
        } catch {
            let failure = DownloadFailure.from(error)
            let detail = error.localizedDescription
            Task { @MainActor in self.taskFailed(spec, failure, identifier: identifier, resumeData: nil, detail: detail) }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let spec = downloadSpec(task) else { return }
        let nsError = error as NSError
        let canceled = nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorCancelled
        let resumeData = nsError.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        let failure = DownloadFailure.from(error)
        let detail = "\(nsError.domain) \(nsError.code) \(Self.figures(task))"
        let identifier = Self.taskKey(task, in: session)
        Task { @MainActor in
            guard canceled else {
                self.taskFailed(spec, failure, identifier: identifier, resumeData: resumeData, detail: detail)
                return
            }
            // Cancelled to start again (the other cellular choice, a stall,
            // a task no download followed).
            if self.restartedTasks.remove(identifier) != nil { return }
            guard self.downloads[spec.id] != nil else { return }
            self.downloads[spec.id] = nil
            self.forgetWatch(spec.id)
            try? FileManager.default.removeItem(at: AppFiles.library.resumeURL(spec))
            self.finishActivity(spec, .cancelled)
            DownloadLog.shared.note("中止 \(spec.name)")
        }
    }
    /// Each connection a download task went through, the Hub's and the
    /// CDN's (address, IPv4 or IPv6, protocol, cellular), when it ends or is
    /// stopped: for the record only (1.1.0 (241)).
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        guard let spec = downloadSpec(task) else { return }
        let receiver = session.configuration.identifier == nil ? "アプリ" : "iOS"
        let text = "経路 \(spec.name)（\(receiver)の受け取り・\(Int(metrics.taskInterval.duration))秒・受信 \(task.countOfBytesReceived / 1_000_000) MB）: "
            + NetworkCheck.route(metrics)
        Task { @MainActor in DownloadLog.shared.note(text) }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor in self.finishBackgroundEventsIfPossible() }
    }
}
