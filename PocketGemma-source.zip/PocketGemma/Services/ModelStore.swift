import Foundation
import Combine
import UIKit
import Network
import PocketCore

/// The file a task downloads: a model, or a part of one (LFM3-VL 2B's
/// picture projector, 1.1.0 (234)).
private func downloadSpec(_ task: URLSessionTask) -> ModelSpec? {
    if let spec = ModelSpec.findFile(task.taskDescription) { return spec }
    // Background downloads started by 1.0.4 did not have taskDescription.
    let file = task.originalRequest?.url?.lastPathComponent
    return ModelSpec.allFiles.first { $0.fileName == file }
}

@MainActor
final class ModelStore: NSObject, ObservableObject {
    static let shared = ModelStore()
    @Published private(set) var selectedModel: ModelSpec
    /// The files checked and saved, by id: a model is installed when all of
    /// its files are (`ModelSpec.files`; LFM3-VL 2B has two since 1.1.0 (234)).
    @Published private(set) var installedIDs: Set<String>
    /// Running downloads and their progress by file id. Several can run at
    /// once; they share the Live Activity, which shows each model whole.
    @Published private(set) var downloads: [String: Double] = [:]
    /// The file being checked. Checks run one at a time; downloads that
    /// finish meanwhile wait in `queuedIDs`.
    @Published private(set) var verifyingID: String?
    @Published private(set) var queuedIDs: Set<String> = []
    @Published private(set) var isRestoring = true
    @Published var error: String?
    /// What models Fielua no longer offers left on the phone (1.1.0 (279),
    /// ModelRetirement): モデル管理 lists them to delete, as nothing else
    /// shows or uses them.
    @Published private(set) var retiredFiles: [RetiredModelFiles] = []
    /// A retired model to tell the person about, once (StartupPresenter).
    @Published private(set) var retirementNotice: RetirementNotice?
    /// モデルと設定's モバイル通信でもダウンロード. A download keeps the
    /// choice it started with; one that has received nothing worth keeping
    /// starts again with the new one.
    @Published var allowsCellular = UserDefaults.standard.bool(forKey: ModelDownload.cellularKey) {
        didSet {
            guard allowsCellular != oldValue else { return }
            UserDefaults.standard.set(allowsCellular, forKey: ModelDownload.cellularKey)
            DownloadLog.shared.note("モバイル通信でのダウンロード: \(allowsCellular ? "オン" : "オフ")")
            restartUnstartedDownloads()
        }
    }
    /// Running downloads that may use cellular data.
    @Published private(set) var cellularIDs: Set<String> = []
    @Published private(set) var network = DownloadNetwork.unknown
    private let networkMonitor = NWPathMonitor()
    /// Satisfied only by a network other than cellular.
    private let wifiMonitor = NWPathMonitor(prohibitedInterfaceTypes: [.cellular])
    /// Tasks cancelled to start again (the other cellular choice, a stall,
    /// a task no download followed): their end is not the download's. By
    /// `taskKey`, as each session counts its tasks from 1.
    private var restartedTasks: Set<String> = []
    private var backgroundCompletion: (() -> Void)?
    private let liveActivity = DownloadActivity()
    /// While a download runs: reads the tasks' progress every two seconds
    /// (in case progress reports stop coming while the app is in the
    /// background) and writes a line to the download record every ten.
    private var progressTimer: Timer?
    private var ticks = 0
    private var progressReports = 0
    /// Bytes each download had at the last line of the record, for its speed.
    private var lastLogged: [String: (date: Date, bytes: Int64)] = [:]
    /// A model's file that failed or was cancelled while another of its
    /// files was still under way: the island ends with it.
    private var fileEndings: [String: DownloadActivity.Outcome] = [:]
    /// Running files that have received nothing for a while on screen
    /// (1.1.0 (240)): their card says they wait for the Hub, instead of a
    /// 0% that never moves (TestFlight 239).
    @Published private(set) var waitingIDs: Set<String> = []
    /// Why each model's last download stopped, by model id, for its card
    /// until the next download (1.1.0 (240)).
    @Published private(set) var failures: [String: String] = [:]
    private var stalls: [String: DownloadStall] = [:]
    /// Times a file's download started again by itself (stalled, link ran
    /// out, connection broke); at most `DownloadStall.restarts`.
    private var autoRestarts: [String: Int] = [:]
    /// Files whose task goes on from resume data: when that fails, the file
    /// starts over once from the beginning (the Hub's CDN link lasts an hour).
    private var resumedIDs: Set<String> = []
    /// Polls in a row that found no task for a running file.
    private var missingPolls: [String: Int] = [:]
    /// Wi-Fi in 低データモード, for the download record.
    private var lowDataMode = false
    /// Files received by the app itself (`directSession`) while it runs.
    private var directIDs: Set<String> = []
    /// Files with what came kept and no task now (1.1.0 (293)): stopped by
    /// the person keeping it, or ended with it kept; each card offers to go
    /// on from there or delete it. By file id.
    @Published private(set) var kept: [String: DownloadKeep] = [:]
    /// The task each running file follows, by `taskKey`: the end of another
    /// task of the file is an older one's, and starts nothing (1.1.0 (293)).
    private var currentTasks: [String: String] = [:]
    /// Files whose kept resume data a task went on from and then ended
    /// without new data: that data is not tried again (DownloadRetry).
    private var keptDataFailed: Set<String> = []
    /// Files that were running when the app last stopped and go on by
    /// themselves (DownloadKeep.running), until their task starts.
    private var adoptedIDs: Set<String> = []
    /// Each running file's share received, unrounded: the continued task's
    /// progress moves with every few kilobytes (1.1.0 (293)), while the
    /// cards and the island move by half a percent.
    private var exactFractions: [String: Double] = [:]
    /// Task ends that came at launch before the running tasks were read.
    private var afterRestore: [() -> Void] = []
    /// モデル管理's check of the saved files is under way (refreshInstalled).
    private var refreshingInstalled = false

    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: "app.pocketgemma.model-download")
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        // Each download's request decides (ModelDownload.request): a
        // background session's configuration can't change while the app runs.
        config.allowsCellularAccess = true
        // One connection per model, so simultaneous downloads really run
        // side by side (the catalog shares a host).
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    /// The app's own session (1.1.0 (240)), for a file the background
    /// session has not started to receive although the network is up and
    /// the app is on screen (TestFlight 239: E2B at 0% with no end). It
    /// receives while the app runs: on screen, or kept running in the
    /// background by the continued-processing task. When the app leaves the
    /// screen without that task, the file goes back to the background
    /// session from what it received.
    private lazy var directSession: URLSession = {
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        config.allowsCellularAccess = true
        config.httpMaximumConnectionsPerHost = 4
        config.timeoutIntervalForResource = 7 * 24 * 3600
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    /// A task's name across both sessions.
    nonisolated private static func taskKey(_ task: URLSessionTask, in session: URLSession) -> String {
        (session.configuration.identifier == nil ? "app-" : "bg-") + String(task.taskIdentifier)
    }

    /// Every task of both sessions with its `taskKey`.
    private func everyTask(_ body: @escaping @Sendable ([(key: String, task: URLSessionTask)]) -> Void) {
        let background = session, direct = directSession
        background.getAllTasks { first in
            direct.getAllTasks { second in
                body(first.map { (Self.taskKey($0, in: background), $0) } + second.map { (Self.taskKey($0, in: direct), $0) })
            }
        }
    }

    private override init() {
        AppFiles.migrateModels()
        let installed = Self.savedFiles()
        installedIDs = installed
        // A model never chosen: E2B on a new phone, which the setup gets
        // ready first (1.1.0 (219)); E4B, as before, on a phone that has a
        // model saved from before the choice was kept. A model chosen that
        // Fielua no longer offers (Phi, 1.1.0 (279)): a saved one in its
        // place, else E2B to download; nothing downloads by itself.
        let choice = ModelRetirement.selection(savedID: UserDefaults.standard.string(forKey: "selectedModelID"),
                                               installed: installed)
        selectedModel = choice.model
        let leftovers = ModelRetirement.leftovers(in: AppFiles.library, caches: AppFiles.inferenceCache)
        retiredFiles = leftovers
        let told = Set(UserDefaults.standard.stringArray(forKey: ModelRetirement.toldKey) ?? [])
        retirementNotice = ModelRetirement.notice(replaced: choice.replaced, leftovers: leftovers, told: told)
        super.init()
        if let replaced = choice.replaced {
            // Kept, so a launch that stops now moves on the same way next time.
            UserDefaults.standard.set(choice.model.id, forKey: "selectedModelID")
            DownloadLog.shared.note("提供終了のモデル \(replaced.name) から \(choice.model.name) へ"
                                    + (isInstalled(choice.model) ? "（保存済み）" : "（未ダウンロード・自動では取得しない）"))
        }
        for left in leftovers { DownloadLog.shared.note("提供終了のモデルのファイル \(left.spec.name) \(left.sizeLabel)（削除はモデル管理から）") }
        if let moved = AppFiles.storageNote { DownloadLog.shared.note("保存先の移動 " + moved) }
        DownloadLog.shared.watchApp()
        watchNetwork()
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.handOverDirectDownloads() }
        }
        // iOS ended the continued task while the app was away: the app is
        // suspended soon after, so a file it receives itself goes back to the
        // background session now (1.1.0 (293)). Until 292 the hand-over came
        // only when the app left the screen without the task, and a file the
        // app received itself stopped where it was.
        liveActivity.continuedEnded = { [weak self] in
            guard UIApplication.shared.applicationState != .active else { return }
            self?.handOverDirectDownloads(force: true)
        }
        session.getAllTasks { tasks in
            Task { @MainActor in
                // A completion delegate may already have started validation
                // while getAllTasks was in flight. Do not restore that old
                // download state over the newer verification state.
                let live = tasks.filter { $0.state != .completed && $0.state != .canceling }
                DownloadLog.shared.note("起動時のダウンロードタスク \(live.count)件")
                for task in live {
                    // A 12B download left running when it was locked.
                    if task.taskDescription == ModelSpec.gemma12B.id && ModelSpec.gemma12B.isLocked { task.cancel(); continue }
                    // A download of a model Fielua no longer offers (Phi,
                    // 1.1.0 (279)) stops: nothing could use it. What was
                    // saved of it before stays for モデル管理 to delete.
                    if let retired = ModelSpec.retired(task.taskDescription) {
                        task.cancel()
                        DownloadLog.shared.note("提供終了のモデルのダウンロードを止めた \(retired.name)")
                        continue
                    }
                    guard let spec = downloadSpec(task) else { continue }
                    // By file, not by model: until 1.1.0 (240) the model
                    // file of LFM3-VL 2B or LFM3-Omni 2B was left unfollowed
                    // when its projector's task came first. A second task
                    // for one file, or one for a file already saved, would
                    // only download it again.
                    if self.currentTasks[spec.id] != nil || self.verifyingID == spec.id || self.queuedIDs.contains(spec.id)
                        || AppFiles.library.hasFile(spec) {
                        self.restartedTasks.insert(Self.taskKey(task, in: self.session))
                        task.cancel()
                        DownloadLog.shared.note("重なったタスクを止めた \(spec.name)")
                        continue
                    }
                    let fraction = task.progress.fractionCompleted
                    self.downloads[spec.id] = fraction
                    self.currentTasks[spec.id] = Self.taskKey(task, in: self.session)
                    if self.readKeep(spec) == nil {
                        self.writeKeep(spec, .running, received: task.countOfBytesReceived,
                                       cellular: task.originalRequest?.allowsCellularAccess ?? false)
                    }
                    self.stalls[spec.id] = DownloadStall(bytes: task.countOfBytesReceived)
                    self.setCellular(task.originalRequest?.allowsCellularAccess ?? false, for: spec)
                    self.liveActivity.begin(spec.owner, fraction: self.progress(for: spec.owner), userInitiated: false)
                    DownloadLog.shared.note("続きから \(spec.name) \(Int(fraction * 100))%")
                    self.watchProgress()
                }
                self.restoreKept()
                self.isRestoring = false
                // Ends of tasks that came while the tasks were read.
                let waiting = self.afterRestore
                self.afterRestore = []
                waiting.forEach { $0() }
                self.restoreNextPending()
                let working = Set(self.downloads.keys).union(self.queuedIDs).union([self.verifyingID].compactMap { $0 })
                self.liveActivity.endAll(except: Set(working.compactMap { ModelSpec.findFile($0)?.owner.id }))
            }
        }
    }

    var isReady: Bool { isInstalled(selectedModel) }
    /// Restoring or checking a file: imports and automatic choices wait.
    var isBusy: Bool { isRestoring || verifyingID != nil }
    func isInstalled(_ spec: ModelSpec) -> Bool { spec.files.allSatisfy { installedIDs.contains($0.id) } }
    func isDownloading(_ spec: ModelSpec) -> Bool { spec.files.contains { downloads[$0.id] != nil } }
    /// How far the model's download is: its files' bytes together, those
    /// already saved or being checked included.
    func progress(for spec: ModelSpec) -> Double {
        guard !spec.parts.isEmpty else { return downloads[spec.id] ?? 0 }
        let received = spec.files.reduce(0.0) { sum, file in
            let done = installedIDs.contains(file.id) || verifyingID == file.id || queuedIDs.contains(file.id)
            return sum + (downloads[file.id] ?? (done ? 1 : 0)) * Double(file.byteCount)
        }
        return received / Double(spec.downloadByteCount)
    }
    /// What a running download waits for, or nil while it can receive.
    func downloadWait(for spec: ModelSpec) -> DownloadWait? {
        isDownloading(spec) ? network.wait(usesCellular: spec.files.contains { cellularIDs.contains($0.id) }) : nil
    }
    /// A running download whose files have received nothing for a while
    /// although the network is up (1.1.0 (240)).
    func isWaitingForData(_ spec: ModelSpec) -> Bool {
        spec.files.contains { waitingIDs.contains($0.id) && downloads[$0.id] != nil }
    }
    func isWorking(on spec: ModelSpec) -> Bool {
        spec.files.contains { downloads[$0.id] != nil || verifyingID == $0.id || queuedIDs.contains($0.id) }
    }
    /// The files saved, checked again whenever モデル管理 opens, and what
    /// retired models left.
    ///
    /// Read off the main thread (1.1.0 (291), Hachimoto さん's directive of
    /// 2026-11-16 on how 設定's pages slide): until 290 モデル管理 waited for
    /// every model's receipt to be read and its file's size checked, about
    /// twenty files, and for the retired models' caches to be walked, all
    /// in the frame that built the page, before it began to slide in. What
    /// the check finds replaces what the store has only where nothing else
    /// changed it meanwhile (a download checked, a model deleted): that
    /// change is the newer one. Nothing changes on screen when nothing
    /// changed on the phone, which is nearly always.
    func refreshInstalled() {
        guard !isBusy, !refreshingInstalled else { return }
        refreshingInstalled = true
        let installedBefore = installedIDs, retiredBefore = retiredFiles
        Task {
            let (current, left) = await Task.detached(priority: .userInitiated) {
                (Self.savedFiles(), ModelRetirement.leftovers(in: AppFiles.library, caches: AppFiles.inferenceCache))
            }.value
            refreshingInstalled = false
            guard !isBusy else { return }
            if installedIDs == installedBefore, current != installedIDs { installedIDs = current }
            if retiredFiles == retiredBefore, left != retiredFiles { retiredFiles = left }
        }
    }

    /// Deletes what a retired model left (モデル管理's 提供を終了したモデル,
    /// the person's tap after a confirmation): its file, a download not
    /// checked yet, its receipt and its engine caches. Its chats and
    /// settings stay. The engine may hold nothing of it: it can't be run.
    func deleteRetired(_ spec: ModelSpec) {
        guard spec.isRetired else { return }
        let before = retiredFiles.first { $0.spec.id == spec.id }?.sizeLabel ?? "-"
        do {
            try ModelRetirement.remove(spec, in: AppFiles.library, caches: AppFiles.inferenceCache)
            DownloadLog.shared.note("提供終了のモデルのファイルを削除 \(spec.name) \(before)")
        } catch {
            self.error = String(localized: "モデルを削除できませんでした。") + "\n" + error.localizedDescription
            DownloadLog.shared.note("提供終了のモデルのファイルを削除できなかった \(spec.name): \(error.localizedDescription)")
        }
        retiredFiles = ModelRetirement.leftovers(in: AppFiles.library, caches: AppFiles.inferenceCache)
    }

    /// The notice was seen: never shown again for that model.
    func retirementNoticeSeen() {
        guard let notice = retirementNotice else { return }
        var told = Set(UserDefaults.standard.stringArray(forKey: ModelRetirement.toldKey) ?? [])
        told.insert(notice.retired.id)
        UserDefaults.standard.set(told.sorted(), forKey: ModelRetirement.toldKey)
        retirementNotice = nil
    }
    /// Every model file checked and saved, the parts of models included.
    nonisolated private static func savedFiles() -> Set<String> {
        Set(ModelSpec.allFiles.filter { AppFiles.library.hasFile($0) }.map(\.id))
    }
    func select(_ spec: ModelSpec) {
        // The startup chooser records the preferred model before downloading
        // it. Readiness still depends on its verified installation receipt.
        // A locked model is not in the catalog, so it is never chosen.
        guard !spec.isLocked, ModelSpec.find(spec.id) != nil else { return }
        selectedModel = spec
        UserDefaults.standard.set(spec.id, forKey: "selectedModelID")
    }
    func statusText(for spec: ModelSpec) -> String {
        if isRestoring { return String(localized: "モデルを確認しています…") }
        // A model of several files shows its download while any still comes.
        if isDownloading(spec) {
            let percent = Int(progress(for: spec) * 100)
            if let wait = downloadWait(for: spec) { return wait.status(name: spec.name, percent: percent) }
            if isWaitingForData(spec) { return String(localized: "\(spec.name)の受信を待っています · \(percent)%") }
            return String(localized: "\(spec.name)をダウンロード中 · \(percent)%")
        }
        if spec.files.contains(where: { verifyingID == $0.id }) { return String(localized: "\(spec.name)を確認しています…") }
        if spec.files.contains(where: { queuedIDs.contains($0.id) }) { return String(localized: "\(spec.name)の確認を待っています…") }
        if isInstalled(spec) { return String(localized: "ダウンロード済み · オフラインで利用できます") }
        // What a stopped download kept (1.1.0 (293)).
        if hasKept(spec) {
            return keptProgress(for: spec).map { String(localized: "途中まで受け取り済み（\(Int($0 * 100))%）· 続きからダウンロードできます") }
                ?? String(localized: "途中まで受け取り済み · 続きからダウンロードできます")
        }
        let missing = spec.files.filter { !installedIDs.contains($0.id) }
        if missing.count < spec.files.count {
            let size = ByteCountFormatter.string(fromByteCount: missing.reduce(0) { $0 + $1.byteCount }, countStyle: .decimal)
            return String(localized: "ファイルの一部が保存済みです · 残りの\(size)をダウンロードしてください")
        }
        return String(localized: "モデルを選んでダウンロードしてください")
    }

    func download(_ spec: ModelSpec) {
        // A locked model is listed only.
        guard !spec.isLocked, !isRestoring, !isWorking(on: spec), !isInstalled(spec) else { return }
        // The developer 12B check's file, checked when it was downloaded,
        // becomes the chat's (a rename in the app's folder), and the check's
        // caches go: the chat builds its own for its longer context.
        if spec.id == ModelSpec.gemma12B.id, LargeModelProbeFiles.ownFileReady {
            do {
                try AppFiles.prepareModels()
                try FileManager.default.moveItem(at: LargeModelProbeFiles.ownModel, to: AppFiles.pendingModel(spec))
                try AppFiles.installVerifiedModel(spec)
                LargeModelProbeFiles.handedOver()
                installedIDs.insert(spec.id)
                DownloadLog.shared.note("\(spec.name)は12Bの動作確認のファイルを使う")
            } catch { self.error = error.localizedDescription }
            return
        }
        do {
            try AppFiles.prepareModels()
            let values = try AppFiles.models.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            // The model's files not saved yet, side by side: LFM3-VL 2B's
            // model and picture projector (1.1.0 (234)), or what is left of them.
            let missing = spec.files.filter { !installedIDs.contains($0.id) }
            // Room for what is still to come of these (what a stopped
            // download kept is already on the phone, 1.1.0 (293)) and for
            // the others still downloading.
            let others = downloads.keys.compactMap { ModelSpec.findFile($0)?.byteCount }.reduce(0, +)
            let remaining = missing.map { file in
                (byteCount: file.byteCount, received: hasResumeData(file) ? kept[file.id]?.receivedBytes ?? 0 : 0)
            }
            if let available = values.volumeAvailableCapacityForImportantUsage,
               available < ModelDownload.roomNeeded(remaining: remaining, others: others) {
                throw NSError(domain: "PocketGemma", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: String(localized: "空き容量が不足しています。モデルのサイズに加えて1 GB以上の空きが必要です。")])
            }
            error = nil
            failures[spec.id] = nil
            let carried = missing.filter(hasResumeData)
            for file in missing {
                downloads[file.id] = kept[file.id]?.fraction ?? 0
                autoRestarts[file.id] = 0
                keptDataFailed.remove(file.id)
            }
            // Waiting for Wi-Fi (or any network), nothing would move, and iOS
            // ends a background task that does not move and shows it as
            // タスクエラー (1.1.0 (247)): the card says what it waits for and
            // the app's own activity shows it, without iOS's task.
            let waits = network.wait(usesCellular: allowsCellular) != nil
            liveActivity.begin(spec, fraction: progress(for: spec), userInitiated: !waits)
            let files = spec.parts.isEmpty ? "" : "（\(missing.map(\.fileName).joined(separator: "・"))）"
            DownloadLog.shared.note("ダウンロード開始 \(spec.name)\(files)（\(allowsCellular ? "モバイル通信も使う" : "Wi-Fiのみ")・\(networkText)）・\(pathDetail)"
                + (carried.isEmpty ? "" : "・残した分から: " + carried.map { "\($0.name) \((kept[$0.id]?.receivedBytes ?? 0) / 1_000_000) MB" }.joined(separator: " / "))
                + (waits ? "・通信を待つため続ける作業は申し込まない" : ""))
            watchProgress()
            everyTask { tasks in
                Task { @MainActor in self.startFiles(missing, among: tasks) }
            }
        } catch { self.error = error.localizedDescription }
    }

    /// Starts the files' tasks, after stopping the session's tasks that no
    /// download follows (1.1.0 (240)): one left for a file starting now, or
    /// for a file the app no longer shows as downloading. Such a task still
    /// takes one of the four connections to the Hub, and its end would be
    /// taken for the new download's.
    private func startFiles(_ files: [ModelSpec], among tasks: [(key: String, task: URLSessionTask)]) {
        let live = tasks.filter { $0.task.state == .running || $0.task.state == .suspended }
        let starting = Set(files.map(\.id))
        var stopped: [String] = []
        for (key, task) in live {
            let id = downloadSpec(task)?.id ?? task.taskDescription ?? ""
            guard starting.contains(id) || downloads[id] == nil else { continue }
            restartedTasks.insert(key)
            task.cancel()
            stopped.append("\(ModelSpec.findFile(id)?.name ?? id) \(Self.figures(task))")
        }
        DownloadLog.shared.note("セッションのタスク \(live.count)件" + (stopped.isEmpty ? "" : "・追われていないタスクを止めた: " + stopped.joined(separator: " / ")))
        for file in files where downloads[file.id] != nil {
            startTask(file)
        }
    }

    /// A file's task: from what an earlier task of it received, when that
    /// was kept (resume data), else from the beginning.
    ///
    /// The resume data stays until newer data replaces it, the file is
    /// saved, or the person deletes what came (1.1.0 (293)). Until 292 it
    /// was deleted here, as the task took it: a task that then ended before
    /// leaving new data (a connection lost at once, the app closed from the
    /// app switcher) took everything received before it, and the next try
    /// began from nothing. `fresh`: from the beginning, the data dropped.
    private func startTask(_ spec: ModelSpec, fresh: Bool = false) {
        let resumeURL = AppFiles.library.resumeURL(spec)
        var resumeData: Data?
        if !fresh, let data = try? Data(contentsOf: resumeURL) {
            resumeData = Self.usableResumeData(data)
            if resumeData == nil { DownloadLog.shared.note("続きのデータが読めない \(spec.name)・最初から") }
        }
        if resumeData == nil { try? FileManager.default.removeItem(at: resumeURL) }
        let chosen = directIDs.contains(spec.id) ? directSession : session
        let task = resumeData.map { chosen.downloadTask(withResumeData: $0) }
            ?? chosen.downloadTask(with: ModelDownload.request(for: spec, cellular: allowsCellular))
        task.taskDescription = spec.id
        task.resume()
        currentTasks[spec.id] = Self.taskKey(task, in: chosen)
        adoptedIDs.remove(spec.id)
        kept[spec.id] = nil
        // A launch after the app stopped goes on with it (DownloadKeep).
        writeKeep(spec, .running, cellular: task.originalRequest?.allowsCellularAccess ?? allowsCellular)
        if resumeData != nil {
            resumedIDs.insert(spec.id)
            DownloadLog.shared.note("続きから受け取る \(spec.name)")
        } else { resumedIDs.remove(spec.id) }
        stalls[spec.id] = DownloadStall()
        missingPolls[spec.id] = nil
        waitingIDs.remove(spec.id)
        setCellular(task.originalRequest?.allowsCellularAccess ?? allowsCellular, for: spec)
    }

    /// Resume data the session can take: URLSession's property list.
    nonisolated private static func usableResumeData(_ data: Data) -> Data? {
        (try? PropertyListSerialization.propertyList(from: data, format: nil)) is [String: Any] ? data : nil
    }

    /// A task's figures for the download record: state, bytes, the Hub's
    /// answer and the host it came from.
    nonisolated private static func figures(_ task: URLSessionTask) -> String {
        let state = switch task.state {
        case .running: "実行中"
        case .suspended: "一時停止"
        case .canceling: "中止中"
        case .completed: "完了"
        @unknown default: "不明"
        }
        let answer = (task.response as? HTTPURLResponse).map { "HTTP \($0.statusCode)" } ?? "応答なし"
        return "（\(state)・受信 \(task.countOfBytesReceived / 1_000_000) MB・\(answer)・\(task.currentRequest?.url?.host ?? "-")）"
    }

    private func setCellular(_ cellular: Bool, for spec: ModelSpec) {
        if cellular { cellularIDs.insert(spec.id) } else { cellularIDs.remove(spec.id) }
    }

    /// After the switch changed: downloads with the other choice that have
    /// received less than 1% start again with this one. The rest keep theirs,
    /// so what they received is not thrown away.
    private func restartUnstartedDownloads() {
        let cellular = allowsCellular
        session.getAllTasks { tasks in
            let unstarted = tasks.filter { task in
                guard task.state == .running || task.state == .suspended, let spec = downloadSpec(task) else { return false }
                let expected = task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount
                return (task.originalRequest?.allowsCellularAccess ?? false) != cellular
                    && ModelDownload.startsOver(receivedBytes: task.countOfBytesReceived, expectedBytes: expected)
            }
            Task { @MainActor in
                // The switch may have changed back while the tasks were read.
                guard self.allowsCellular == cellular else { return }
                for task in unstarted {
                    guard let spec = downloadSpec(task), self.downloads[spec.id] != nil else { continue }
                    self.restartedTasks.insert(Self.taskKey(task, in: self.session))
                    task.cancel()
                    // Under 1%: nothing worth keeping, and resume data would
                    // keep the old choice.
                    self.startTask(spec, fresh: true)
                    DownloadLog.shared.note("始め直し \(spec.name)（\(cellular ? "モバイル通信も使う" : "Wi-Fiのみ")）")
                    // A download that waited for Wi-Fi asked iOS for no
                    // background task; turning the switch on lets it go now.
                    if cellular, UIApplication.shared.applicationState == .active {
                        self.liveActivity.begin(spec.owner, fraction: self.progress(for: spec.owner), userInitiated: true)
                    }
                }
            }
        }
    }

    /// Wi-Fi and cellular as iOS reports them, for what a download waits for.
    private func watchNetwork() {
        let queue = DispatchQueue(label: "app.pocketgemma.download-network")
        networkMonitor.pathUpdateHandler = { [weak self] path in
            let online = path.status == .satisfied
            let denied = path.unsatisfiedReason == .cellularDenied
            let constrained = path.isConstrained
            let detail = NetworkCheck.describe(path)
            Task { @MainActor in
                guard let self else { return }
                self.lowDataMode = constrained
                self.pathDetail = detail
                self.networkChanged { $0.isOnline = online; $0.cellularDenied = denied }
                self.noteNetwork()
            }
        }
        wifiMonitor.pathUpdateHandler = { [weak self] path in
            // A tunnel iOS keeps over cellular (utun, of type other) also
            // satisfies a path without cellular, and a Wi-Fi-only download
            // still cannot use it: on 5G alone the app took it for Wi-Fi and
            // said nothing while LFM3 waited at 0% (1.1.0 (247)).
            let wifi = path.status == .satisfied
                && (path.usesInterfaceType(.wifi) || path.usesInterfaceType(.wiredEthernet)
                    || path.availableInterfaces.contains { $0.type == .wifi || $0.type == .wiredEthernet })
            Task { @MainActor in self?.networkChanged { $0.hasWiFi = wifi } }
        }
        networkMonitor.start(queue: queue)
        wifiMonitor.start(queue: queue)
    }

    private func networkChanged(_ change: (inout DownloadNetwork) -> Void) {
        var next = network
        change(&next)
        guard next != network else { return }
        network = next
        noteNetwork()
    }

    private var networkText: String {
        (network.hasWiFi ? "Wi-Fi" : network.isOnline ? "モバイル通信" : network.cellularDenied ? "モバイル通信は設定でオフ" : "通信なし")
            + (lowDataMode && network.isOnline ? "（低データモード）" : "")
    }
    /// The path as iOS reports it (IPv4, IPv6, DNS, the interfaces), for the
    /// record only (1.1.0 (241): E2B stalled on Wi-Fi and went on over 5G).
    private var pathDetail = ""
    private var notedNetwork: String?
    /// The download record names each change of network while a download runs.
    private func noteNetwork() {
        let text = networkText + (pathDetail.isEmpty ? "" : "・" + pathDetail)
        guard !downloads.isEmpty, text != notedNetwork else { return }
        notedNetwork = text
        DownloadLog.shared.note("通信: \(text)")
    }

    private func watchProgress() {
        guard progressTimer == nil else { return }
        ticks = 0
        progressTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.pollProgress() }
        }
    }

    private func pollProgress() {
        guard !downloads.isEmpty else {
            progressTimer?.invalidate()
            progressTimer = nil
            lastLogged = [:]
            return
        }
        ticks += 1
        everyTask { tasks in
            let live = tasks.filter { $0.task.state == .running || $0.task.state == .suspended }
            let received: [(id: String, bytes: Int64, expected: Int64)] = live.compactMap { _, task in
                guard task.state == .running, let spec = downloadSpec(task) else { return nil }
                return (spec.id, task.countOfBytesReceived,
                        task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount)
            }
            let carried = live.compactMap { key, task in downloadSpec(task).map { (id: $0.id, task: key, bytes: task.countOfBytesReceived) } }
            let details = live.map { key, task in
                "\(downloadSpec(task)?.name ?? task.taskDescription ?? "?")\(key.hasPrefix("app-") ? "・アプリで受信" : "")\(Self.figures(task))"
            }
            Task { @MainActor in
                self.applyPolledProgress(received, details: details)
                self.watchStalls(carried)
            }
        }
    }

    /// While the app is on screen: a running file that has received nothing
    /// for `DownloadStall.noticeAfter` says so on its card; after
    /// `restartAfter` its task starts again from what it has, at most
    /// `DownloadStall.restarts` times, and then the download stops with
    /// `.stalled`. A file the app shows as downloading with no task under
    /// it starts its task again. Off screen iOS may hold a background
    /// download back on purpose, so nothing is counted there.
    private func watchStalls(_ carried: [(id: String, task: String, bytes: Int64)]) {
        let now = Date()
        let onScreen = UIApplication.shared.applicationState == .active
        for id in Array(downloads.keys) {
            guard let file = ModelSpec.findFile(id) else { continue }
            let usesCellular = cellularIDs.contains(id)
            guard onScreen, network.wait(usesCellular: usesCellular) == nil else {
                stalls[id] = nil
                missingPolls[id] = nil
                waitingIDs.remove(id)
                continue
            }
            guard let task = carried.filter({ $0.id == id }).max(by: { $0.bytes < $1.bytes }) else {
                missingPolls[id, default: 0] += 1
                // Five polls (ten seconds) on screen with no task, and no
                // file waiting for its check: nothing will ever report. A
                // download that was running when the app stopped waits two
                // (four seconds), for iOS's end of its old task with the
                // newest resume data (1.1.0 (293)).
                if missingPolls[id, default: 0] >= (adoptedIDs.contains(id) ? 2 : 5), verifyingID != id, !queuedIDs.contains(id),
                   !FileManager.default.fileExists(atPath: AppFiles.pendingModel(file).path) {
                    missingPolls[id] = nil
                    DownloadLog.shared.note("タスクが見つからない \(file.name)・" + (hasResumeData(file) ? "残した分から続ける" : "始め直す"))
                    startTask(file)
                }
                continue
            }
            missingPolls[id] = nil
            var stall = stalls[id] ?? DownloadStall(bytes: task.bytes, now: now)
            let idle = stall.idle(received: task.bytes, now: now)
            stalls[id] = stall
            guard idle >= DownloadStall.noticeAfter else { waitingIDs.remove(id); continue }
            if waitingIDs.insert(id).inserted {
                DownloadLog.shared.note("受信が\(Int(idle))秒止まっている \(file.name)（受信 \(task.bytes / 1_000_000) MB・\(networkText)）")
            }
            guard idle >= DownloadStall.restartAfter else { continue }
            stalls[id] = DownloadStall(bytes: task.bytes, now: now)
            if autoRestarts[id, default: 0] < DownloadStall.restarts {
                autoRestarts[id, default: 0] += 1
                // The app receives the file itself while it runs when iOS's
                // download service has not delivered a byte, or stalled twice.
                let direct = !directIDs.contains(id) && (task.bytes == 0 || autoRestarts[id, default: 0] >= DownloadStall.restarts)
                if direct { directIDs.insert(id) }
                restart(file, task: task.task, reason: "受信が\(Int(idle))秒止まった" + (direct ? "・アプリで直接受け取る" : ""))
            } else {
                stop(file, task: task.task, failure: .stalled)
            }
        }
    }

    /// Stops the file's task, keeping what it received, and starts it again
    /// from there.
    private func restart(_ file: ModelSpec, task identifier: String, reason: String) {
        restartedTasks.insert(identifier)
        stopTask(identifier) { data in
            guard self.downloads[file.id] != nil else { return }
            if let data { try? data.write(to: AppFiles.library.resumeURL(file)) }
            DownloadLog.shared.note("始め直し \(file.name)（\(reason)・\(data == nil ? "最初から" : "続きから")）")
            self.startTask(file)
        }
    }

    /// Stops the file's task for good, keeping what it received for the
    /// next download.
    private func stop(_ file: ModelSpec, task identifier: String, failure: DownloadFailure) {
        restartedTasks.insert(identifier)
        stopTask(identifier) { data in
            if let data { try? data.write(to: AppFiles.library.resumeURL(file)) }
            self.fail(file, failure, keepsReceived: data != nil)
        }
    }

    private func stopTask(_ identifier: String, then: @escaping @MainActor @Sendable (Data?) -> Void) {
        everyTask { tasks in
            guard let task = tasks.first(where: { $0.key == identifier })?.task as? URLSessionDownloadTask else {
                Task { @MainActor in then(nil) }
                return
            }
            task.cancel(byProducingResumeData: { data in Task { @MainActor in then(data) } })
        }
    }

    /// Ends a file's download as failed: the alert, the card's line, the
    /// island and the record say why.
    private func fail(_ file: ModelSpec, _ failure: DownloadFailure, keepsReceived: Bool, received: Int64 = 0) {
        guard downloads[file.id] != nil else { return }
        downloads[file.id] = nil
        forgetWatch(file.id)
        // What came stays for the card's 続きからダウンロード (1.1.0 (293)),
        // also resume data kept from before this task.
        keepAsPaused(file, received: received)
        let keeps = keepsReceived || hasResumeData(file)
        let message = failure.message(keepsReceived: keeps)
        error = file.owner.name + "\n" + message
        failures[file.owner.id] = message
        finishActivity(file, .failed)
        DownloadLog.shared.note("ダウンロード失敗 \(file.name) [\(failure.logText)]" + (keeps ? "・受け取った分を残した" : ""))
    }

    /// The app leaves the screen without the continued-processing task: a
    /// file it receives itself goes back to the background session from
    /// what it has, so it goes on while the app is suspended. Back on
    /// screen, a stall may bring it to the app again.
    private func handOverDirectDownloads(force: Bool = false) {
        guard !directIDs.isEmpty, force || !liveActivity.isContinuing else { return }
        let ids = directIDs
        let direct = directSession
        // A few seconds off screen to hand the files over before iOS
        // suspends the app.
        let handover = UIApplication.shared.beginBackgroundTask(withName: "model-download-handover", expirationHandler: nil)
        Task {
            try? await Task.sleep(for: .seconds(8))
            UIApplication.shared.endBackgroundTask(handover)
        }
        direct.getAllTasks { tasks in
            let handed = tasks.filter { ($0.state == .running || $0.state == .suspended) && ids.contains(downloadSpec($0)?.id ?? "") }
            Task { @MainActor in
                for task in handed {
                    guard let spec = downloadSpec(task), let download = task as? URLSessionDownloadTask else { continue }
                    self.restartedTasks.insert(Self.taskKey(task, in: direct))
                    self.directIDs.remove(spec.id)
                    self.autoRestarts[spec.id] = 0
                    download.cancel(byProducingResumeData: { data in
                        Task { @MainActor in
                            if let data { try? data.write(to: AppFiles.library.resumeURL(spec)) }
                            guard self.downloads[spec.id] != nil else { return }
                            DownloadLog.shared.note("裏に回るのでiOSの受け取りへ戻す \(spec.name)" + (force ? "（続ける作業が終わった）" : ""))
                            self.startTask(spec)
                        }
                    })
                }
            }
        }
    }

    private func stopOtherTasks(of file: ModelSpec, except identifier: String) {
        everyTask { tasks in
            let others = tasks.filter { $0.key != identifier && $0.task.state != .completed && downloadSpec($0.task)?.id == file.id }
            Task { @MainActor in
                for (key, task) in others {
                    self.restartedTasks.insert(key)
                    task.cancel()
                }
            }
        }
    }

    private func forgetWatch(_ id: String) {
        directIDs.remove(id)
        currentTasks[id] = nil
        adoptedIDs.remove(id)
        exactFractions[id] = nil
        stalls[id] = nil
        missingPolls[id] = nil
        waitingIDs.remove(id)
        resumedIDs.remove(id)
    }

    private func applyPolledProgress(_ received: [(id: String, bytes: Int64, expected: Int64)], details: [String]) {
        for (id, bytes, expected) in received {
            guard let spec = ModelSpec.findFile(id), let shown = downloads[id] else { continue }
            let fraction = min(1, Double(bytes) / Double(expected))
            exactFractions[id] = max(exactFractions[id] ?? 0, fraction)
            liveActivity.advance(spec.owner, fraction: exactProgress(for: spec.owner))
            if fraction - shown > 0.005 {
                downloads[id] = fraction
                liveActivity.update(spec.owner, fraction: progress(for: spec.owner))
            }
        }
        guard ticks % 5 == 1 else { return }
        // How far each running file got, for a launch after the app stopped.
        for (id, bytes, _) in received {
            guard let file = ModelSpec.findFile(id), downloads[id] != nil else { continue }
            writeKeep(file, .running, received: bytes)
        }
        let now = Date()
        let figures = received.compactMap { id, bytes, _ -> String? in
            guard let spec = ModelSpec.findFile(id) else { return nil }
            // The speed since the last line tells a slower background
            // transfer apart from a figure that only stopped moving.
            var speed = ""
            if let last = lastLogged[id], bytes >= last.bytes, now.timeIntervalSince(last.date) > 1 {
                speed = String(format: " · %.1f MB/秒", Double(bytes - last.bytes) / 1_000_000 / now.timeIntervalSince(last.date))
            }
            lastLogged[id] = (now, bytes)
            return "\(spec.name) \(Int((downloads[id] ?? 0) * 100))%（受信 \(bytes / 1_000_000) MB\(speed)）"
        }
        DownloadLog.shared.note((figures.isEmpty ? "受信中のタスクなし" : figures.joined(separator: " / "))
            + " · タスク: " + (details.isEmpty ? "なし" : details.joined(separator: " / "))
            + " · 進み報告\(progressReports)回 · 島の更新\(liveActivity.takeUpdateCount())回 · \(DownloadLog.appState)"
            + " · 続ける作業\(liveActivity.continuedState)\(liveActivity.takeContinuedGap()) · 島\(liveActivity.stateText)")
        progressReports = 0
    }

    /// Removes the receipts first, so a model whose files could not be
    /// removed never counts as installed. All of its files go.
    func delete(_ spec: ModelSpec) {
        guard !isWorking(on: spec) else { return }
        let library = AppFiles.library
        for file in spec.files {
            try? FileManager.default.removeItem(at: library.receiptURL(file))
            removeKept(file)
            installedIDs.remove(file.id)
        }
        failures[spec.id] = nil
        do {
            // Also a copy an earlier version left in Documents (AppFiles.migrateModels).
            for file in spec.files {
                for url in library.allModelURLs(file) where FileManager.default.fileExists(atPath: url.path) {
                    try FileManager.default.removeItem(at: url)
                }
            }
            AppFiles.removeEngineCaches(spec)
        } catch { self.error = String(localized: "モデルを削除できませんでした。") + "\n" + error.localizedDescription }
    }

    /// Stops the model's downloads. What they received is kept, and the
    /// next download goes on from there, unless the person chose to delete
    /// it (1.1.0 (293), Hachimoto さん's directive of 2026-11-17: 明示的な
    /// 破棄を選ばない限り、再開可能なデータを保護する). Until 292 every 中止
    /// deleted it: 330 MB went at once on 2026-10-30.
    func cancelDownload(_ spec: ModelSpec, keepingReceived keep: Bool = true) {
        if !keep { for file in spec.files { removeKept(file) } }
        everyTask { tasks in
            // By its description too: a locked model's task finds no spec.
            let mine = tasks.filter { $0.task.taskDescription == spec.id || downloadSpec($0.task)?.owner.id == spec.id }
            let live = mine.filter { $0.task.state == .running || $0.task.state == .suspended }
            let carried = Set(mine.filter { $0.task.state != .completed }.compactMap { downloadSpec($0.task)?.id })
            Task { @MainActor in
                if keep {
                    var pausing: Set<String> = []
                    for (key, task) in live {
                        guard let file = downloadSpec(task), let download = task as? URLSessionDownloadTask,
                              !pausing.contains(file.id) else {
                            // A second task of a file only repeats the first.
                            self.restartedTasks.insert(key)
                            task.cancel()
                            continue
                        }
                        pausing.insert(file.id)
                        self.restartedTasks.insert(key)
                        let received = task.countOfBytesReceived
                        download.cancel(byProducingResumeData: { data in
                            Task { @MainActor in self.paused(file, data: data, received: received) }
                        })
                    }
                    for file in spec.files where self.downloads[file.id] != nil && !pausing.contains(file.id) {
                        self.paused(file, data: nil, received: 0)
                    }
                    return
                }
                // The person chose to delete what came: the download ends
                // here, and the tasks' ends start nothing.
                for (key, task) in live {
                    self.restartedTasks.insert(key)
                    task.cancel()
                }
                for file in spec.files where self.downloads[file.id] != nil {
                    self.downloads[file.id] = nil
                    self.forgetWatch(file.id)
                    self.removeKept(file)
                    self.finishActivity(file, .cancelled)
                    DownloadLog.shared.note("中止 \(file.name)（受け取った分も削除" + (carried.contains(file.id) ? "" : "・タスクなし") + "）")
                }
            }
        }
    }

    /// The person's stop keeping what came: the card offers to go on.
    private func paused(_ file: ModelSpec, data: Data?, received: Int64) {
        if let data { try? data.write(to: AppFiles.library.resumeURL(file)) }
        guard downloads[file.id] != nil else { return }
        downloads[file.id] = nil
        forgetWatch(file.id)
        failures[file.owner.id] = nil
        keepAsPaused(file, received: received)
        finishActivity(file, .cancelled)
        let left = kept[file.id].map { "受け取った \($0.receivedBytes / 1_000_000) MB を残した・次は続きから" } ?? "残せる分はなかった"
        DownloadLog.shared.note("中止 \(file.name)（\(left)）")
    }

    func importModel(_ url: URL, spec: ModelSpec) {
        guard !spec.isLocked, !isBusy, !isWorking(on: spec), !isInstalled(spec) else { return }
        guard url.pathExtension.lowercased() == spec.fileExtension else {
            // LFM3 is a GGUF file (1.1.0 (232)).
            error = spec.runtime == .llamaCpp ? String(localized: "選んだモデルの .gguf ファイルを取り込んでください。")
                : String(localized: "選んだモデルの .litertlm ファイルを取り込んでください。")
            return
        }
        let file = importedFile(url, of: spec)
        verifyingID = file.id
        error = nil
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    let granted = url.startAccessingSecurityScopedResource()
                    defer { if granted { url.stopAccessingSecurityScopedResource() } }
                    try AppFiles.prepareModels()
                    let pending = AppFiles.pendingModel(file)
                    var coordinationError: NSError?
                    var copyError: Error?
                    NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordinationError) { source in
                        do {
                            if FileManager.default.fileExists(atPath: pending.path) {
                                try FileManager.default.removeItem(at: pending)
                            }
                            try FileManager.default.copyItem(at: source, to: pending)
                        } catch { copyError = error }
                    }
                    if let coordinationError { throw coordinationError }
                    if let copyError { throw copyError }
                    try ModelValidator.validate(pending, spec: file)
                    try AppFiles.installVerifiedModel(file)
                }.value
                installedIDs.insert(file.id)
                // LFM3-VL 2B's other file is still to come.
                let left = spec.files.filter { !installedIDs.contains($0.id) }
                if !left.isEmpty {
                    let names = left.map(\.fileName).formatted(.list(type: .and))
                    error = String(localized: "\(spec.name)を使うには、あと\(names)も取り込んでください。")
                }
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(file))
            }
            verifyingID = nil
            restoreNextPending()
        }
    }

    /// Which of the model's files not saved yet an imported file is, known
    /// by its size: a model of several files takes them one at a time
    /// (LFM3-VL 2B's model or its picture projector, 1.1.0 (234)).
    private func importedFile(_ url: URL, of spec: ModelSpec) -> ModelSpec {
        let missing = spec.files.filter { !installedIDs.contains($0.id) }
        guard missing.count > 1 else { return missing.first ?? spec }
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize.map(Int64.init)
        return missing.first { $0.byteCount == size } ?? spec
    }

    /// At launch (1.1.0 (293)): what earlier downloads left without a task
    /// now. One that was running (closed from the app switcher, the phone
    /// restarted, its task stopped by iOS) goes on by itself; one stopped
    /// with what came kept waits on its card. Resume data an earlier version
    /// left counts as kept too (292 wrote no record). A file saved, or
    /// waiting for its check, has nothing to restore.
    private func restoreKept() {
        let library = AppFiles.library
        for file in ModelSpec.allFiles where downloads[file.id] == nil && !file.isLocked && !library.hasFile(file) {
            let keep = readKeep(file)
            let hasData = hasResumeData(file)
            guard keep != nil || hasData else { continue }
            if FileManager.default.fileExists(atPath: AppFiles.pendingModel(file).path) {
                removeKept(file)
                continue
            }
            if keep?.state == .running {
                adoptRunning(file, keep)
                DownloadLog.shared.note("前回のダウンロードを続ける \(file.name)（受信 \((keep?.receivedBytes ?? 0) / 1_000_000) MB・続きのデータ\(hasData ? "あり" : "なし")）")
            } else if hasData {
                kept[file.id] = keep ?? DownloadKeep(state: .paused, receivedBytes: 0, expectedBytes: file.byteCount, cellular: false)
                DownloadLog.shared.note("受け取った分を残したダウンロード \(file.name)（\((keep?.receivedBytes ?? 0) / 1_000_000) MB）")
            } else {
                removeKept(file)
            }
        }
    }

    private func restoreNextPending() {
        guard !isRestoring, verifyingID == nil else { return }
        if let spec = ModelSpec.allFiles.first(where: {
            downloads[$0.id] == nil && FileManager.default.fileExists(atPath: AppFiles.pendingModel($0).path)
        }) { verifyPendingFile(spec) }
    }

    /// Checks a downloaded file. A model of several files shows in the
    /// island as checking once none of them is still downloading.
    private func verifyPendingFile(_ spec: ModelSpec) {
        downloads[spec.id] = nil
        forgetWatch(spec.id)
        if !isDownloading(spec.owner) { liveActivity.verifying(spec.owner) }
        DownloadLog.shared.note("ファイルの確認へ \(spec.name)（\(DownloadLog.appState)）")
        guard verifyingID == nil else { queuedIDs.insert(spec.id); return }
        queuedIDs.remove(spec.id)
        verifyingID = spec.id
        Task {
            let outcome: DownloadActivity.Outcome
            do {
                try await Task.detached(priority: .userInitiated) {
                    // The check's progress keeps the continued task moving
                    // (a few seconds for E4B on the phone, 1.1.0 (293)).
                    try ModelValidator.validate(AppFiles.pendingModel(spec), spec: spec) { checked in
                        Task { @MainActor in self.liveActivity.checking(spec.owner, fraction: Double(checked) / Double(spec.byteCount)) }
                    }
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
                if isInstalled(spec.owner) { failures[spec.owner.id] = nil }
                outcome = .installed
                DownloadLog.shared.note("保存完了 \(spec.name)（SHA-256一致）")
            } catch {
                // A file that is not the pinned one is never kept, and
                // never counts as saved (1.1.0 (240): the words say it was
                // the file's check, not the network).
                let failure = DownloadFailure.from(error)
                let message = failure.message()
                self.error = spec.owner.name + "\n" + message
                failures[spec.owner.id] = message
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
                outcome = .failed
                DownloadLog.shared.note("確認に失敗 \(spec.name) [\(failure.logText)]")
            }
            verifyingID = nil
            finishActivity(spec, outcome)
            restoreNextPending()
        }
    }

    /// The island's end for a file's model, once none of its files is under
    /// way: saved when all of them are; otherwise how a file of it ended.
    /// While another file goes on, the island shows the model's progress.
    private func finishActivity(_ file: ModelSpec, _ outcome: DownloadActivity.Outcome) {
        let model = file.owner
        if outcome != .installed { fileEndings[model.id] = outcome }
        guard !isWorking(on: model) else {
            // The other file still downloads, or waits for its check.
            if isDownloading(model) { liveActivity.update(model, fraction: progress(for: model)) } else { liveActivity.verifying(model) }
            return
        }
        let ending = fileEndings.removeValue(forKey: model.id) ?? outcome
        liveActivity.finish(model, isInstalled(model) ? .installed : ending == .installed ? .failed : ending)
    }

    /// A file's task ended without the file (1.1.0 (240)). What it received
    /// is kept for the next try (resume data). What comes next is
    /// `DownloadRetry`'s (1.1.0 (293)): from the new resume data; from the
    /// data kept before the task when it left none; from the beginning only
    /// when the kept data can't be used (a link that ran out: the Hub's CDN
    /// links last about an hour, run 40825923927; a file that changed); or
    /// a stop with words that say why, what came kept. Until 292 a task that
    /// went on from resume data and failed without new data started over
    /// from the beginning at once, and the data had been deleted already.
    private func taskFailed(_ file: ModelSpec, _ failure: DownloadFailure, identifier: String,
                            resumeData: Data?, received: Int64 = 0, detail: String) {
        // An end that comes at launch waits for the tasks still running to
        // be read, so the file is followed once.
        guard !isRestoring else {
            afterRestore.append { self.taskFailed(file, failure, identifier: identifier, resumeData: resumeData, received: received, detail: detail) }
            return
        }
        if restartedTasks.remove(identifier) != nil { return }
        if let current = currentTasks[file.id], current != identifier {
            // An older task of the file, ended after a newer one started.
            DownloadLog.shared.note("前のタスクの終わり \(file.name) [\(failure.logText)]・今のタスクはそのまま")
            return
        }
        let hadKeptData = hasResumeData(file)
        if let resumeData { try? resumeData.write(to: AppFiles.library.resumeURL(file)) }
        guard downloads[file.id] != nil || readKeep(file)?.state == .running else {
            // Its end came after the download stopped: what came is kept.
            if resumeData != nil { keepAsPaused(file, received: received) }
            return
        }
        // Its end came while the app was not running: it goes on as before.
        if downloads[file.id] == nil { adoptRunning(file, readKeep(file)) }
        currentTasks[file.id] = nil
        DownloadLog.shared.note("タスクが終わった \(file.name) [\(failure.logText)] \(detail)" + (resumeData == nil ? "" : "・続きのデータあり"))
        // A task that moved on before it ended is no failed try.
        if received >= 8_000_000 { autoRestarts[file.id] = 0 }
        let resumed = resumedIDs.contains(file.id)
        let step = DownloadRetry.after(failure, resumed: resumed, hasNewData: resumeData != nil,
                                       hasKeptData: hadKeptData && resumeData == nil,
                                       keptDataFailed: keptDataFailed.contains(file.id),
                                       tries: autoRestarts[file.id, default: 0], maxTries: DownloadStall.restarts)
        switch step {
        case .fromNewData, .fromKeptData:
            autoRestarts[file.id, default: 0] += 1
            if step == .fromNewData { keptDataFailed.remove(file.id) } else if resumed { keptDataFailed.insert(file.id) }
            DownloadLog.shared.note("もう一度 \(file.name)（\(autoRestarts[file.id, default: 0])回目・"
                                    + (step == .fromNewData ? "続きから" : "前に残した続きから") + "）")
            startTask(file)
        case .fromStart:
            autoRestarts[file.id, default: 0] += 1
            keptDataFailed.remove(file.id)
            DownloadLog.shared.note("続きからを諦めて最初から \(file.name)（\(autoRestarts[file.id, default: 0])回目・"
                                    + (hadKeptData || resumeData != nil ? "続きのデータが使えない" : "残せる分なし") + "）")
            startTask(file, fresh: true)
        case .stop:
            fail(file, failure, keepsReceived: hasResumeData(file), received: received)
        }
    }

    /// iOS stopped the file's task (1.1.0 (293)): the person closed the app
    /// from the app switcher, background updates are off, or the system
    /// needed the resources. That is not the person's stop of the download:
    /// what came is kept, and it goes on, from there, at once on screen and
    /// otherwise when the app is next on screen. Until 292 this was taken
    /// for the person's 中止, or, at the next launch, dropped with its
    /// resume data, so the download was gone.
    private func systemStopped(_ file: ModelSpec, reason: Int, identifier: String, resumeData: Data?, received: Int64) {
        guard !isRestoring else {
            afterRestore.append { self.systemStopped(file, reason: reason, identifier: identifier, resumeData: resumeData, received: received) }
            return
        }
        if restartedTasks.remove(identifier) != nil { return }
        if let current = currentTasks[file.id], current != identifier { return }
        if let resumeData { try? resumeData.write(to: AppFiles.library.resumeURL(file)) }
        DownloadLog.shared.note("iOSがタスクを止めた \(file.name)（\(DownloadEnding.reasonText(reason))・受信 \(received / 1_000_000) MB）"
                                + (resumeData != nil ? "・受け取った分を残した" : hasResumeData(file) ? "・前に残した分あり" : "・続きのデータなし"))
        currentTasks[file.id] = nil
        guard !AppFiles.library.hasFile(file) else { return }
        if downloads[file.id] == nil {
            guard readKeep(file)?.state != .paused else { return }
            adoptRunning(file, readKeep(file))
        }
        writeKeep(file, .running, received: received)
        adoptedIDs.insert(file.id)
        // On screen it goes on now; off screen a new task would wait for
        // iOS anyway, and with background updates off it would be stopped again.
        guard UIApplication.shared.applicationState == .active else { return }
        DownloadLog.shared.note("続きから再開 \(file.name)（iOSが止めた後）")
        startTask(file)
    }

    // MARK: What came, kept (1.1.0 (293))

    private func readKeep(_ file: ModelSpec) -> DownloadKeep? {
        DownloadKeep.read(from: AppFiles.library.keepURL(file))
    }

    private func hasResumeData(_ file: ModelSpec) -> Bool {
        FileManager.default.fileExists(atPath: AppFiles.library.resumeURL(file).path)
    }

    /// Writes the file's record; the bytes noted never go back.
    private func writeKeep(_ file: ModelSpec, _ state: DownloadKeep.State, received: Int64? = nil, cellular: Bool? = nil) {
        let before = readKeep(file)
        let keep = DownloadKeep(state: state, receivedBytes: max(received ?? 0, before?.receivedBytes ?? 0),
                                expectedBytes: file.byteCount, cellular: cellular ?? before?.cellular ?? allowsCellular)
        try? AppFiles.prepareModels()
        try? keep.write(to: AppFiles.library.keepURL(file))
    }

    /// The resume data and the record go: the file was saved, the person
    /// deleted what came, or the data can't be used any more.
    private func removeKept(_ file: ModelSpec, resumeData: Bool = true) {
        if resumeData { try? FileManager.default.removeItem(at: AppFiles.library.resumeURL(file)) }
        try? FileManager.default.removeItem(at: AppFiles.library.keepURL(file))
        kept[file.id] = nil
        keptDataFailed.remove(file.id)
    }

    /// A file that stopped with what came kept: its card offers to go on.
    private func keepAsPaused(_ file: ModelSpec, received: Int64) {
        guard hasResumeData(file) else {
            removeKept(file)
            return
        }
        writeKeep(file, .paused, received: received)
        kept[file.id] = readKeep(file)
    }

    /// A file running when the app last stopped (closed from the app
    /// switcher, the phone restarted, iOS stopped its task): shown as
    /// downloading again; its task starts from what came once the app is on
    /// screen (`watchStalls`), or at once when iOS's end of the old task
    /// comes (`systemStopped`).
    private func adoptRunning(_ file: ModelSpec, _ keep: DownloadKeep?) {
        guard downloads[file.id] == nil else { return }
        downloads[file.id] = keep?.fraction ?? 0
        autoRestarts[file.id] = 0
        adoptedIDs.insert(file.id)
        setCellular(keep?.cellular ?? allowsCellular, for: file)
        liveActivity.begin(file.owner, fraction: progress(for: file.owner), userInitiated: false)
        watchProgress()
    }

    /// What a model's files have kept, as a share of the model, when known.
    func keptProgress(for spec: ModelSpec) -> Double? {
        guard spec.files.contains(where: { kept[$0.id] != nil }) else { return nil }
        var known = false
        let received = spec.files.reduce(0.0) { sum, file in
            if installedIDs.contains(file.id) { return sum + Double(file.byteCount) }
            guard let keep = kept[file.id], keep.receivedBytes > 0 else { return sum }
            known = true
            return sum + Double(min(keep.receivedBytes, file.byteCount))
        }
        return known ? received / Double(spec.downloadByteCount) : nil
    }

    /// The model has what came of a stopped download kept.
    func hasKept(_ spec: ModelSpec) -> Bool {
        !isWorking(on: spec) && spec.files.contains { kept[$0.id] != nil }
    }

    /// Deletes what a stopped download kept (the card's 受け取った分を削除,
    /// the person's choice after a confirmation).
    func discardKept(_ spec: ModelSpec) {
        guard !isWorking(on: spec) else { return }
        for file in spec.files where kept[file.id] != nil || hasResumeData(file) {
            removeKept(file)
            DownloadLog.shared.note("受け取った分を削除 \(file.name)")
        }
        failures[spec.id] = nil
    }

    /// The model's share received, unrounded, for the continued task.
    private func exactProgress(for spec: ModelSpec) -> Double {
        let received = spec.files.reduce(0.0) { sum, file in
            let done = installedIDs.contains(file.id) || verifyingID == file.id || queuedIDs.contains(file.id)
            let share = downloads[file.id].map { max($0, exactFractions[file.id] ?? 0) } ?? (done ? 1 : 0)
            return sum + share * Double(file.byteCount)
        }
        return received / Double(spec.downloadByteCount)
    }

    func attachBackgroundCompletion(_ completion: @escaping () -> Void) {
        backgroundCompletion = completion
        DownloadLog.shared.note("iOSがダウンロードの知らせで起こした（\(DownloadLog.appState)）")
        _ = session
    }
    private func finishBackgroundEventsIfPossible() {
        // The delegate has persisted the file. Hashing must not hold iOS's
        // background event completion handler for a multi-gigabyte pass.
        guard let completion = backgroundCompletion else { return }
        backgroundCompletion = nil
        // This launch is the app's background time: the island's change
        // (checking, saved, failed) goes out before iOS suspends the app.
        Task {
            await Task.yield()
            await liveActivity.flush()
            completion()
        }
    }
}

extension ModelStore: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                               totalBytesExpectedToWrite: Int64) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let expected = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : spec.byteCount
        let fraction = min(1, Double(totalBytesWritten) / Double(expected))
        Task { @MainActor in
            self.progressReports += 1
            guard let shown = self.downloads[spec.id] else { return }
            self.exactFractions[spec.id] = fraction
            // iOS takes a continued task whose progress has not moved for
            // about 30 seconds for one that stopped, ends it and shows it
            // as failed (Apple DTS, developer forums 805554). Half a percent
            // of E4B is 18 MB: under 0.6 MB/s the task did not move for
            // longer than that until 292 (1.1.0 (293)).
            self.liveActivity.advance(spec.owner, fraction: self.exactProgress(for: spec.owner))
            if abs(shown - fraction) > 0.005 || fraction == 1 {
                self.downloads[spec.id] = fraction
                self.liveActivity.update(spec.owner, fraction: self.progress(for: spec.owner))
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didFinishDownloadingTo location: URL) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let identifier = Self.taskKey(downloadTask, in: session)
        let status = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0
        // The Hub's answer when it is not the file (an error page, a link
        // that ran out): never moved where a model goes.
        if let failure = DownloadFailure.from(status: status) {
            let detail = "\(downloadTask.currentRequest?.url?.host ?? "-")"
            Task { @MainActor in self.taskFailed(spec, failure, identifier: identifier, resumeData: nil, detail: detail) }
            return
        }
        do {
            try AppFiles.prepareModels()
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) {
                try FileManager.default.removeItem(at: pending)
            }
            // URLSession removes its temporary file when this callback returns.
            try FileManager.default.moveItem(at: location, to: pending)
            Task { @MainActor in
                // A task stopped to start again that finished meanwhile: its
                // file is as good, and the task started after it goes.
                if self.restartedTasks.remove(identifier) != nil { self.stopOtherTasks(of: spec, except: identifier) }
                // Every byte is in the pending file now: the resume data and
                // the record go. The file counts as saved only after its
                // size and SHA-256 check (verifyPendingFile).
                self.removeKept(spec)
                self.verifyPendingFile(spec)
            }
        } catch {
            let failure = DownloadFailure.from(error)
            let detail = error.localizedDescription
            Task { @MainActor in self.taskFailed(spec, failure, identifier: identifier, resumeData: nil, detail: detail) }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let spec = downloadSpec(task) else { return }
        let nsError = error as NSError
        let ending = DownloadEnding(nsError)
        let resumeData = nsError.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        let failure = DownloadFailure.from(error)
        let detail = "\(nsError.domain) \(nsError.code) \(Self.figures(task))"
        let identifier = Self.taskKey(task, in: session)
        let received = task.countOfBytesReceived
        Task { @MainActor in
            switch ending {
            case .failed:
                self.taskFailed(spec, failure, identifier: identifier, resumeData: resumeData, received: received, detail: detail)
            case .stoppedBySystem(let reason):
                self.systemStopped(spec, reason: reason, identifier: identifier, resumeData: resumeData, received: received)
            case .cancelledByApp:
                // Cancelled to start again (the other cellular choice, a
                // stall, a task no download followed) or by the person's 中止
                // (cancelDownload, which ends the download itself).
                if self.restartedTasks.remove(identifier) != nil { return }
                // Not tagged: cancelled by an earlier launch, whose tags went
                // with it. Nothing of the download is deleted for it
                // (1.1.0 (293)); until 292 a running download took it for
                // the person's 中止 and deleted what came.
                if let resumeData, !self.hasResumeData(spec), !AppFiles.library.hasFile(spec) {
                    try? resumeData.write(to: AppFiles.library.resumeURL(spec))
                }
                if self.downloads[spec.id] != nil, self.currentTasks[spec.id] == identifier {
                    // Its task is gone: the stall watch starts it again.
                    self.currentTasks[spec.id] = nil
                }
                DownloadLog.shared.note("前の起動で止めたタスクの終わり \(spec.name)" + (resumeData != nil ? "・続きのデータあり" : ""))
            }
        }
    }
    /// Each connection a download task went through, the Hub's and the
    /// CDN's (address, IPv4 or IPv6, protocol, cellular), when it ends or is
    /// stopped: for the record only (1.1.0 (241)).
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        guard let spec = downloadSpec(task) else { return }
        let receiver = session.configuration.identifier == nil ? "アプリ" : "iOS"
        let text = "経路 \(spec.name)（\(receiver)の受け取り・\(Int(metrics.taskInterval.duration))秒・受信 \(task.countOfBytesReceived / 1_000_000) MB）: "
            + NetworkCheck.route(metrics)
        Task { @MainActor in DownloadLog.shared.note(text) }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor in self.finishBackgroundEventsIfPossible() }
    }
}
