import Foundation
import Combine
import UIKit
import PocketCore

private func downloadSpec(_ task: URLSessionTask) -> ModelSpec? {
    if let spec = ModelSpec.find(task.taskDescription) { return spec }
    // Background downloads started by 1.0.4 did not have taskDescription.
    let file = task.originalRequest?.url?.lastPathComponent
    return ModelSpec.catalog.first { $0.fileName == file }
}

@MainActor
final class ModelStore: NSObject, ObservableObject {
    static let shared = ModelStore()
    @Published private(set) var selectedModel: ModelSpec
    @Published private(set) var installedIDs: Set<String>
    @Published private(set) var operationModelID: String?
    @Published private(set) var isDownloading = false
    @Published private(set) var isVerifying = false
    @Published private(set) var isRestoring = true
    @Published private(set) var progress: Double = 0
    @Published var error: String?
    private var backgroundCompletion: (() -> Void)?
    private let liveActivity = DownloadActivity()

    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: "app.pocketgemma.model-download")
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        config.allowsCellularAccess = false
        config.httpMaximumConnectionsPerHost = 1
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    private override init() {
        selectedModel = ModelSpec.find(UserDefaults.standard.string(forKey: "selectedModelID")) ?? .e4b
        AppFiles.migrateModels()
        installedIDs = Set(ModelSpec.catalog.filter { AppFiles.hasVerifiedModel($0) }.map(\.id))
        super.init()
        liveActivity.onStoppedBySystem = { [weak self] in self?.cancelDownload() }
        session.getAllTasks { tasks in
            Task { @MainActor in
                // A completion delegate may already have started validation
                // while getAllTasks was in flight. Do not restore that old
                // download state over the newer verification state.
                if !self.isVerifying,
                   let task = tasks.first(where: { $0.state != .completed && $0.state != .canceling }),
                   let spec = downloadSpec(task) {
                    self.operationModelID = spec.id
                    self.isDownloading = true
                    self.liveActivity.begin(spec, fraction: task.progress.fractionCompleted, userInitiated: false)
                }
                self.isRestoring = false
                if !self.isDownloading { self.restoreNextPending() }
            }
        }
    }

    var isReady: Bool { isInstalled(selectedModel) }
    var isBusy: Bool { isDownloading || isVerifying || isRestoring }
    func isInstalled(_ spec: ModelSpec) -> Bool { installedIDs.contains(spec.id) }
    /// Models are visible in the Files app, where they can be deleted.
    func refreshInstalled() {
        guard !isBusy else { return }
        let current = Set(ModelSpec.catalog.filter { AppFiles.hasVerifiedModel($0) }.map(\.id))
        if current != installedIDs { installedIDs = current }
    }
    func select(_ spec: ModelSpec) {
        // The startup chooser records the preferred model before downloading
        // it. Readiness still depends on its verified installation receipt.
        guard ModelSpec.find(spec.id) != nil else { return }
        selectedModel = spec
        UserDefaults.standard.set(spec.id, forKey: "selectedModelID")
    }
    var statusText: String {
        if isRestoring { return "保存状態を確認しています…" }
        let name = ModelSpec.find(operationModelID)?.name ?? selectedModel.name
        if isVerifying { return "\(name)を確認しています…" }
        if isDownloading { return "\(name)をダウンロード中 · \(Int(progress * 100))%" }
        return isReady ? "保存済み · オフラインで利用できます" : "モデルを選んで保存してください"
    }

    func download(_ spec: ModelSpec) {
        guard !isBusy, !isInstalled(spec) else { return }
        do {
            try AppFiles.prepareModels()
            let values = try AppFiles.models.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            if let available = values.volumeAvailableCapacityForImportantUsage,
               available < spec.byteCount + 1_000_000_000 {
                throw NSError(domain: "PocketGemma", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "空き容量が不足しています。モデルのサイズに加えて1 GB以上の空きが必要です。"])
            }
            progress = 0
            error = nil
            operationModelID = spec.id
            isDownloading = true
            let task = session.downloadTask(with: spec.downloadURL)
            task.taskDescription = spec.id
            task.resume()
            liveActivity.begin(spec, userInitiated: true)
        } catch { self.error = error.localizedDescription }
    }

    /// Removes the receipt first, so a model whose file could not be removed
    /// never counts as installed.
    func delete(_ spec: ModelSpec) {
        guard !isBusy else { return }
        let library = AppFiles.library
        try? FileManager.default.removeItem(at: library.receiptURL(spec))
        installedIDs.remove(spec.id)
        do {
            if FileManager.default.fileExists(atPath: library.modelURL(spec).path) {
                try FileManager.default.removeItem(at: library.modelURL(spec))
            }
        } catch { self.error = "モデルを削除できませんでした。\n\(error.localizedDescription)" }
    }

    func cancelDownload() {
        session.getAllTasks { tasks in tasks.forEach { $0.cancel() } }
    }

    func importModel(_ url: URL, spec: ModelSpec) {
        guard !isBusy, !isInstalled(spec) else { return }
        guard url.pathExtension.lowercased() == "litertlm" else {
            error = "選んだモデルの .litertlm ファイルを取り込んでください。"
            return
        }
        isVerifying = true
        operationModelID = spec.id
        error = nil
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    let granted = url.startAccessingSecurityScopedResource()
                    defer { if granted { url.stopAccessingSecurityScopedResource() } }
                    try AppFiles.prepareModels()
                    let pending = AppFiles.pendingModel(spec)
                    var coordinationError: NSError?
                    var copyError: Error?
                    NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordinationError) { source in
                        do {
                            if FileManager.default.fileExists(atPath: pending.path) {
                                try FileManager.default.removeItem(at: pending)
                            }
                            try FileManager.default.copyItem(at: source, to: pending)
                        } catch { copyError = error }
                    }
                    if let coordinationError { throw coordinationError }
                    if let copyError { throw copyError }
                    try ModelValidator.validate(pending, spec: spec)
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
            }
            isVerifying = false
            operationModelID = nil
            restoreNextPending()
        }
    }

    private func restoreNextPending() {
        guard !isBusy else { return }
        if let spec = ModelSpec.catalog.first(where: {
            FileManager.default.fileExists(atPath: AppFiles.pendingModel($0).path)
        }) { verifyPendingFile(spec) }
    }

    private func verifyPendingFile(_ spec: ModelSpec) {
        guard !isVerifying else { return }
        isDownloading = false
        isVerifying = true
        operationModelID = spec.id
        liveActivity.verifying()
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    try ModelValidator.validate(AppFiles.pendingModel(spec), spec: spec)
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
                liveActivity.finish(.installed)
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
                liveActivity.finish(.failed)
            }
            isVerifying = false
            operationModelID = nil
            restoreNextPending()
        }
    }

    func attachBackgroundCompletion(_ completion: @escaping () -> Void) {
        backgroundCompletion = completion
        _ = session
    }
    private func finishBackgroundEventsIfPossible() {
        // The delegate has persisted the file. Hashing must not hold iOS's
        // background event completion handler for a multi-gigabyte pass.
        guard let completion = backgroundCompletion else { return }
        backgroundCompletion = nil
        completion()
    }
}

extension ModelStore: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                               totalBytesExpectedToWrite: Int64) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let expected = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : spec.byteCount
        let fraction = min(1, Double(totalBytesWritten) / Double(expected))
        Task { @MainActor in
            guard self.operationModelID == spec.id else { return }
            if abs(self.progress - fraction) > 0.005 || fraction == 1 {
                self.progress = fraction
                self.liveActivity.update(fraction)
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didFinishDownloadingTo location: URL) {
        guard let spec = downloadSpec(downloadTask) else { return }
        do {
            guard let response = downloadTask.response as? HTTPURLResponse,
                  (200...299).contains(response.statusCode) else {
                throw NSError(domain: "PocketGemma", code: 2,
                    userInfo: [NSLocalizedDescriptionKey: "ダウンロードに失敗しました。Wi-Fi接続を確認して、もう一度お試しください。"])
            }
            try AppFiles.prepareModels()
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) {
                try FileManager.default.removeItem(at: pending)
            }
            // URLSession removes its temporary file when this callback returns.
            try FileManager.default.moveItem(at: location, to: pending)
            Task { @MainActor in self.verifyPendingFile(spec) }
        } catch {
            let description = error.localizedDescription
            Task { @MainActor in
                self.isDownloading = false
                self.operationModelID = nil
                self.error = description
                self.liveActivity.finish(.failed)
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let spec = downloadSpec(task) else { return }
        let canceled = (error as NSError).code == NSURLErrorCancelled
        let description = error.localizedDescription
        Task { @MainActor in
            guard self.operationModelID == spec.id, self.isDownloading else { return }
            self.isDownloading = false
            self.operationModelID = nil
            if !canceled { self.error = "ダウンロードを完了できませんでした。\n\(description)" }
            self.liveActivity.finish(canceled ? .cancelled : .failed)
        }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor in self.finishBackgroundEventsIfPossible() }
    }
}
