import Foundation
import Combine
import UIKit
import Network
import PocketCore

/// The file a task downloads: a model, or a part of one (LFM3-VL 2B's
/// picture projector, 1.1.0 (234)).
private func downloadSpec(_ task: URLSessionTask) -> ModelSpec? {
    if let spec = ModelSpec.findFile(task.taskDescription) { return spec }
    // Background downloads started by 1.0.4 did not have taskDescription.
    let file = task.originalRequest?.url?.lastPathComponent
    return ModelSpec.allFiles.first { $0.fileName == file }
}

@MainActor
final class ModelStore: NSObject, ObservableObject {
    static let shared = ModelStore()
    @Published private(set) var selectedModel: ModelSpec
    /// The files checked and saved, by id: a model is installed when all of
    /// its files are (`ModelSpec.files`; LFM3-VL 2B has two since 1.1.0 (234)).
    @Published private(set) var installedIDs: Set<String>
    /// Running downloads and their progress by file id. Several can run at
    /// once; they share the Live Activity, which shows each model whole.
    @Published private(set) var downloads: [String: Double] = [:]
    /// The file being checked. Checks run one at a time; downloads that
    /// finish meanwhile wait in `queuedIDs`.
    @Published private(set) var verifyingID: String?
    @Published private(set) var queuedIDs: Set<String> = []
    @Published private(set) var isRestoring = true
    @Published var error: String?
    /// モデルと設定's モバイル通信でもダウンロード. A download keeps the
    /// choice it started with; one that has received nothing worth keeping
    /// starts again with the new one.
    @Published var allowsCellular = UserDefaults.standard.bool(forKey: ModelDownload.cellularKey) {
        didSet {
            guard allowsCellular != oldValue else { return }
            UserDefaults.standard.set(allowsCellular, forKey: ModelDownload.cellularKey)
            DownloadLog.shared.note("モバイル通信でのダウンロード: \(allowsCellular ? "オン" : "オフ")")
            restartUnstartedDownloads()
        }
    }
    /// Running downloads that may use cellular data.
    @Published private(set) var cellularIDs: Set<String> = []
    @Published private(set) var network = DownloadNetwork.unknown
    private let networkMonitor = NWPathMonitor()
    /// Satisfied only by a network other than cellular.
    private let wifiMonitor = NWPathMonitor(prohibitedInterfaceTypes: [.cellular])
    /// Tasks cancelled to start again with the other cellular choice: their
    /// end is not the download's.
    private var restartedTasks: Set<Int> = []
    private var backgroundCompletion: (() -> Void)?
    private let liveActivity = DownloadActivity()
    /// While a download runs: reads the tasks' progress every two seconds
    /// (in case progress reports stop coming while the app is in the
    /// background) and writes a line to the download record every ten.
    private var progressTimer: Timer?
    private var ticks = 0
    private var progressReports = 0
    /// Bytes each download had at the last line of the record, for its speed.
    private var lastLogged: [String: (date: Date, bytes: Int64)] = [:]
    /// A model's file that failed or was cancelled while another of its
    /// files was still under way: the island ends with it.
    private var fileEndings: [String: DownloadActivity.Outcome] = [:]

    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: "app.pocketgemma.model-download")
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        // Each download's request decides (ModelDownload.request): a
        // background session's configuration can't change while the app runs.
        config.allowsCellularAccess = true
        // One connection per model, so simultaneous downloads really run
        // side by side (the catalog shares a host).
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    private override init() {
        AppFiles.migrateModels()
        let installed = Self.savedFiles()
        installedIDs = installed
        // A model never chosen: E2B on a new phone, which the setup gets
        // ready first (1.1.0 (219)); E4B, as before, on a phone that has a
        // model saved from before the choice was kept.
        let hasModel = ModelSpec.catalog.contains { $0.files.allSatisfy { installed.contains($0.id) } }
        selectedModel = ModelSpec.find(UserDefaults.standard.string(forKey: "selectedModelID"))
            ?? (hasModel ? .e4b : .e2b)
        super.init()
        DownloadLog.shared.watchApp()
        watchNetwork()
        session.getAllTasks { tasks in
            Task { @MainActor in
                // A completion delegate may already have started validation
                // while getAllTasks was in flight. Do not restore that old
                // download state over the newer verification state.
                for task in tasks where task.state != .completed && task.state != .canceling {
                    // A 12B download left running when it was locked.
                    if task.taskDescription == ModelSpec.gemma12B.id && ModelSpec.gemma12B.isLocked { task.cancel(); continue }
                    guard let spec = downloadSpec(task), !self.isWorking(on: spec) else { continue }
                    let fraction = task.progress.fractionCompleted
                    self.downloads[spec.id] = fraction
                    self.setCellular(task.originalRequest?.allowsCellularAccess ?? false, for: spec)
                    self.liveActivity.begin(spec.owner, fraction: self.progress(for: spec.owner), userInitiated: false)
                    DownloadLog.shared.note("続きから \(spec.name) \(Int(fraction * 100))%")
                    self.watchProgress()
                }
                self.isRestoring = false
                self.restoreNextPending()
                let working = Set(self.downloads.keys).union(self.queuedIDs).union([self.verifyingID].compactMap { $0 })
                self.liveActivity.endAll(except: Set(working.compactMap { ModelSpec.findFile($0)?.owner.id }))
            }
        }
    }

    var isReady: Bool { isInstalled(selectedModel) }
    /// Restoring or checking a file: imports and automatic choices wait.
    var isBusy: Bool { isRestoring || verifyingID != nil }
    func isInstalled(_ spec: ModelSpec) -> Bool { spec.files.allSatisfy { installedIDs.contains($0.id) } }
    func isDownloading(_ spec: ModelSpec) -> Bool { spec.files.contains { downloads[$0.id] != nil } }
    /// How far the model's download is: its files' bytes together, those
    /// already saved or being checked included.
    func progress(for spec: ModelSpec) -> Double {
        guard !spec.parts.isEmpty else { return downloads[spec.id] ?? 0 }
        let received = spec.files.reduce(0.0) { sum, file in
            let done = installedIDs.contains(file.id) || verifyingID == file.id || queuedIDs.contains(file.id)
            return sum + (downloads[file.id] ?? (done ? 1 : 0)) * Double(file.byteCount)
        }
        return received / Double(spec.downloadByteCount)
    }
    /// What a running download waits for, or nil while it can receive.
    func downloadWait(for spec: ModelSpec) -> DownloadWait? {
        isDownloading(spec) ? network.wait(usesCellular: spec.files.contains { cellularIDs.contains($0.id) }) : nil
    }
    func isWorking(on spec: ModelSpec) -> Bool {
        spec.files.contains { downloads[$0.id] != nil || verifyingID == $0.id || queuedIDs.contains($0.id) }
    }
    /// Models are visible in the Files app, where they can be deleted.
    func refreshInstalled() {
        guard !isBusy else { return }
        let current = Self.savedFiles()
        if current != installedIDs { installedIDs = current }
    }
    /// Every model file checked and saved, the parts of models included.
    private static func savedFiles() -> Set<String> {
        Set(ModelSpec.allFiles.filter { AppFiles.library.hasFile($0) }.map(\.id))
    }
    func select(_ spec: ModelSpec) {
        // The startup chooser records the preferred model before downloading
        // it. Readiness still depends on its verified installation receipt.
        // A locked model is not in the catalog, so it is never chosen.
        guard !spec.isLocked, ModelSpec.find(spec.id) != nil else { return }
        selectedModel = spec
        UserDefaults.standard.set(spec.id, forKey: "selectedModelID")
    }
    func statusText(for spec: ModelSpec) -> String {
        if isRestoring { return String(localized: "モデルを確認しています…") }
        // A model of several files shows its download while any still comes.
        if isDownloading(spec) {
            let percent = Int(progress(for: spec) * 100)
            if let wait = downloadWait(for: spec) { return wait.status(name: spec.name, percent: percent) }
            return String(localized: "\(spec.name)をダウンロード中 · \(percent)%")
        }
        if spec.files.contains(where: { verifyingID == $0.id }) { return String(localized: "\(spec.name)を確認しています…") }
        if spec.files.contains(where: { queuedIDs.contains($0.id) }) { return String(localized: "\(spec.name)の確認を待っています…") }
        if isInstalled(spec) { return String(localized: "ダウンロード済み · オフラインで利用できます") }
        let missing = spec.files.filter { !installedIDs.contains($0.id) }
        if missing.count < spec.files.count {
            let size = ByteCountFormatter.string(fromByteCount: missing.reduce(0) { $0 + $1.byteCount }, countStyle: .decimal)
            return String(localized: "ファイルの一部が保存済みです · 残りの\(size)をダウンロードしてください")
        }
        return String(localized: "モデルを選んでダウンロードしてください")
    }

    func download(_ spec: ModelSpec) {
        // A locked model is listed only.
        guard !spec.isLocked, !isRestoring, !isWorking(on: spec), !isInstalled(spec) else { return }
        // The developer 12B check's file, checked when it was downloaded,
        // becomes the chat's (a rename in Documents), and the check's
        // caches go: the chat builds its own for its longer context.
        if spec.id == ModelSpec.gemma12B.id, LargeModelProbeFiles.ownFileReady {
            do {
                try AppFiles.prepareModels()
                try FileManager.default.moveItem(at: LargeModelProbeFiles.ownModel, to: AppFiles.pendingModel(spec))
                try AppFiles.installVerifiedModel(spec)
                LargeModelProbeFiles.handedOver()
                installedIDs.insert(spec.id)
                DownloadLog.shared.note("\(spec.name)は12Bの動作確認のファイルを使う")
            } catch { self.error = error.localizedDescription }
            return
        }
        do {
            try AppFiles.prepareModels()
            let values = try AppFiles.models.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            // The model's files not saved yet, side by side: LFM3-VL 2B's
            // model and picture projector (1.1.0 (234)), or what is left of them.
            let missing = spec.files.filter { !installedIDs.contains($0.id) }
            // Room for these and for the others still downloading.
            let others = downloads.keys.compactMap { ModelSpec.findFile($0)?.byteCount }.reduce(0, +)
            if let available = values.volumeAvailableCapacityForImportantUsage,
               available < missing.reduce(0, { $0 + $1.byteCount }) + others + 1_000_000_000 {
                throw NSError(domain: "PocketGemma", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: String(localized: "空き容量が不足しています。モデルのサイズに加えて1 GB以上の空きが必要です。")])
            }
            error = nil
            for file in missing {
                downloads[file.id] = 0
                startTask(file)
            }
            liveActivity.begin(spec, fraction: progress(for: spec), userInitiated: true)
            let files = spec.parts.isEmpty ? "" : "（\(missing.map(\.fileName).joined(separator: "・"))）"
            DownloadLog.shared.note("ダウンロード開始 \(spec.name)\(files)（\(allowsCellular ? "モバイル通信も使う" : "Wi-Fiのみ")・\(networkText)）")
            watchProgress()
        } catch { self.error = error.localizedDescription }
    }

    private func startTask(_ spec: ModelSpec) {
        let task = session.downloadTask(with: ModelDownload.request(for: spec, cellular: allowsCellular))
        task.taskDescription = spec.id
        task.resume()
        setCellular(allowsCellular, for: spec)
    }

    private func setCellular(_ cellular: Bool, for spec: ModelSpec) {
        if cellular { cellularIDs.insert(spec.id) } else { cellularIDs.remove(spec.id) }
    }

    /// After the switch changed: downloads with the other choice that have
    /// received less than 1% start again with this one. The rest keep theirs,
    /// so what they received is not thrown away.
    private func restartUnstartedDownloads() {
        let cellular = allowsCellular
        session.getAllTasks { tasks in
            let unstarted = tasks.filter { task in
                guard task.state == .running || task.state == .suspended, let spec = downloadSpec(task) else { return false }
                let expected = task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount
                return (task.originalRequest?.allowsCellularAccess ?? false) != cellular
                    && ModelDownload.startsOver(receivedBytes: task.countOfBytesReceived, expectedBytes: expected)
            }
            Task { @MainActor in
                // The switch may have changed back while the tasks were read.
                guard self.allowsCellular == cellular else { return }
                for task in unstarted {
                    guard let spec = downloadSpec(task), self.downloads[spec.id] != nil else { continue }
                    self.restartedTasks.insert(task.taskIdentifier)
                    task.cancel()
                    self.startTask(spec)
                    DownloadLog.shared.note("始め直し \(spec.name)（\(cellular ? "モバイル通信も使う" : "Wi-Fiのみ")）")
                }
            }
        }
    }

    /// Wi-Fi and cellular as iOS reports them, for what a download waits for.
    private func watchNetwork() {
        let queue = DispatchQueue(label: "app.pocketgemma.download-network")
        networkMonitor.pathUpdateHandler = { [weak self] path in
            let online = path.status == .satisfied
            let denied = path.unsatisfiedReason == .cellularDenied
            Task { @MainActor in self?.networkChanged { $0.isOnline = online; $0.cellularDenied = denied } }
        }
        wifiMonitor.pathUpdateHandler = { [weak self] path in
            let wifi = path.status == .satisfied
            Task { @MainActor in self?.networkChanged { $0.hasWiFi = wifi } }
        }
        networkMonitor.start(queue: queue)
        wifiMonitor.start(queue: queue)
    }

    private func networkChanged(_ change: (inout DownloadNetwork) -> Void) {
        var next = network
        change(&next)
        guard next != network else { return }
        network = next
        noteNetwork()
    }

    private var networkText: String {
        network.hasWiFi ? "Wi-Fi" : network.isOnline ? "モバイル通信" : network.cellularDenied ? "モバイル通信は設定でオフ" : "通信なし"
    }
    private var notedNetwork: String?
    /// The download record names each change of network while a download runs.
    private func noteNetwork() {
        guard !downloads.isEmpty, networkText != notedNetwork else { return }
        notedNetwork = networkText
        DownloadLog.shared.note("通信: \(networkText)")
    }

    private func watchProgress() {
        guard progressTimer == nil else { return }
        ticks = 0
        progressTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.pollProgress() }
        }
    }

    private func pollProgress() {
        guard !downloads.isEmpty else {
            progressTimer?.invalidate()
            progressTimer = nil
            lastLogged = [:]
            return
        }
        ticks += 1
        session.getAllTasks { tasks in
            let received: [(id: String, bytes: Int64, expected: Int64)] = tasks.compactMap { task in
                guard task.state == .running, let spec = downloadSpec(task) else { return nil }
                return (spec.id, task.countOfBytesReceived,
                        task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount)
            }
            Task { @MainActor in self.applyPolledProgress(received) }
        }
    }

    private func applyPolledProgress(_ received: [(id: String, bytes: Int64, expected: Int64)]) {
        for (id, bytes, expected) in received {
            guard let spec = ModelSpec.findFile(id), let shown = downloads[id] else { continue }
            let fraction = min(1, Double(bytes) / Double(expected))
            if fraction - shown > 0.005 {
                downloads[id] = fraction
                liveActivity.update(spec.owner, fraction: progress(for: spec.owner))
            }
        }
        guard ticks % 5 == 1 else { return }
        let now = Date()
        let figures = received.compactMap { id, bytes, _ -> String? in
            guard let spec = ModelSpec.findFile(id) else { return nil }
            // The speed since the last line tells a slower background
            // transfer apart from a figure that only stopped moving.
            var speed = ""
            if let last = lastLogged[id], bytes >= last.bytes, now.timeIntervalSince(last.date) > 1 {
                speed = String(format: " · %.1f MB/秒", Double(bytes - last.bytes) / 1_000_000 / now.timeIntervalSince(last.date))
            }
            lastLogged[id] = (now, bytes)
            return "\(spec.name) \(Int((downloads[id] ?? 0) * 100))%（受信 \(bytes / 1_000_000) MB\(speed)）"
        }
        DownloadLog.shared.note((figures.isEmpty ? "実行中のタスクなし" : figures.joined(separator: " / "))
            + " · 進み報告\(progressReports)回 · 島の更新\(liveActivity.takeUpdateCount())回 · \(DownloadLog.appState)"
            + " · 続ける作業\(liveActivity.continuedState) · 島\(liveActivity.stateText)")
        progressReports = 0
    }

    /// Removes the receipts first, so a model whose files could not be
    /// removed never counts as installed. All of its files go.
    func delete(_ spec: ModelSpec) {
        guard !isWorking(on: spec) else { return }
        let library = AppFiles.library
        for file in spec.files {
            try? FileManager.default.removeItem(at: library.receiptURL(file))
            installedIDs.remove(file.id)
        }
        do {
            for file in spec.files where FileManager.default.fileExists(atPath: library.modelURL(file).path) {
                try FileManager.default.removeItem(at: library.modelURL(file))
            }
            AppFiles.removeEngineCaches(spec)
        } catch { self.error = String(localized: "モデルを削除できませんでした。") + "\n" + error.localizedDescription }
    }

    func cancelDownload(_ spec: ModelSpec) {
        session.getAllTasks { tasks in
            // By its description too: a locked model's task finds no spec.
            tasks.filter { $0.taskDescription == spec.id || downloadSpec($0)?.owner.id == spec.id }.forEach { $0.cancel() }
        }
    }

    func importModel(_ url: URL, spec: ModelSpec) {
        guard !spec.isLocked, !isBusy, !isWorking(on: spec), !isInstalled(spec) else { return }
        guard url.pathExtension.lowercased() == spec.fileExtension else {
            // LFM3 is a GGUF file (1.1.0 (232)).
            error = spec.runtime == .llamaCpp ? String(localized: "選んだモデルの .gguf ファイルを取り込んでください。")
                : String(localized: "選んだモデルの .litertlm ファイルを取り込んでください。")
            return
        }
        let file = importedFile(url, of: spec)
        verifyingID = file.id
        error = nil
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    let granted = url.startAccessingSecurityScopedResource()
                    defer { if granted { url.stopAccessingSecurityScopedResource() } }
                    try AppFiles.prepareModels()
                    let pending = AppFiles.pendingModel(file)
                    var coordinationError: NSError?
                    var copyError: Error?
                    NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordinationError) { source in
                        do {
                            if FileManager.default.fileExists(atPath: pending.path) {
                                try FileManager.default.removeItem(at: pending)
                            }
                            try FileManager.default.copyItem(at: source, to: pending)
                        } catch { copyError = error }
                    }
                    if let coordinationError { throw coordinationError }
                    if let copyError { throw copyError }
                    try ModelValidator.validate(pending, spec: file)
                    try AppFiles.installVerifiedModel(file)
                }.value
                installedIDs.insert(file.id)
                // LFM3-VL 2B's other file is still to come.
                let left = spec.files.filter { !installedIDs.contains($0.id) }
                if !left.isEmpty {
                    let names = left.map(\.fileName).formatted(.list(type: .and))
                    error = String(localized: "\(spec.name)を使うには、あと\(names)も取り込んでください。")
                }
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(file))
            }
            verifyingID = nil
            restoreNextPending()
        }
    }

    /// Which of the model's files not saved yet an imported file is, known
    /// by its size: a model of several files takes them one at a time
    /// (LFM3-VL 2B's model or its picture projector, 1.1.0 (234)).
    private func importedFile(_ url: URL, of spec: ModelSpec) -> ModelSpec {
        let missing = spec.files.filter { !installedIDs.contains($0.id) }
        guard missing.count > 1 else { return missing.first ?? spec }
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize.map(Int64.init)
        return missing.first { $0.byteCount == size } ?? spec
    }

    private func restoreNextPending() {
        guard !isRestoring, verifyingID == nil else { return }
        if let spec = ModelSpec.allFiles.first(where: {
            downloads[$0.id] == nil && FileManager.default.fileExists(atPath: AppFiles.pendingModel($0).path)
        }) { verifyPendingFile(spec) }
    }

    /// Checks a downloaded file. A model of several files shows in the
    /// island as checking once none of them is still downloading.
    private func verifyPendingFile(_ spec: ModelSpec) {
        downloads[spec.id] = nil
        if !isDownloading(spec.owner) { liveActivity.verifying(spec.owner) }
        DownloadLog.shared.note("ファイルの確認へ \(spec.name)（\(DownloadLog.appState)）")
        guard verifyingID == nil else { queuedIDs.insert(spec.id); return }
        queuedIDs.remove(spec.id)
        verifyingID = spec.id
        Task {
            let outcome: DownloadActivity.Outcome
            do {
                try await Task.detached(priority: .userInitiated) {
                    try ModelValidator.validate(AppFiles.pendingModel(spec), spec: spec)
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
                outcome = .installed
                DownloadLog.shared.note("保存完了 \(spec.name)")
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
                outcome = .failed
                DownloadLog.shared.note("確認に失敗 \(spec.name) \(error.localizedDescription)")
            }
            verifyingID = nil
            finishActivity(spec, outcome)
            restoreNextPending()
        }
    }

    /// The island's end for a file's model, once none of its files is under
    /// way: saved when all of them are; otherwise how a file of it ended.
    /// While another file goes on, the island shows the model's progress.
    private func finishActivity(_ file: ModelSpec, _ outcome: DownloadActivity.Outcome) {
        let model = file.owner
        if outcome != .installed { fileEndings[model.id] = outcome }
        guard !isWorking(on: model) else {
            // The other file still downloads, or waits for its check.
            if isDownloading(model) { liveActivity.update(model, fraction: progress(for: model)) } else { liveActivity.verifying(model) }
            return
        }
        let ending = fileEndings.removeValue(forKey: model.id) ?? outcome
        liveActivity.finish(model, isInstalled(model) ? .installed : ending == .installed ? .failed : ending)
    }

    func attachBackgroundCompletion(_ completion: @escaping () -> Void) {
        backgroundCompletion = completion
        DownloadLog.shared.note("iOSがダウンロードの知らせで起こした（\(DownloadLog.appState)）")
        _ = session
    }
    private func finishBackgroundEventsIfPossible() {
        // The delegate has persisted the file. Hashing must not hold iOS's
        // background event completion handler for a multi-gigabyte pass.
        guard let completion = backgroundCompletion else { return }
        backgroundCompletion = nil
        // This launch is the app's background time: the island's change
        // (checking, saved, failed) goes out before iOS suspends the app.
        Task {
            await Task.yield()
            await liveActivity.flush()
            completion()
        }
    }
}

extension ModelStore: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                               totalBytesExpectedToWrite: Int64) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let expected = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : spec.byteCount
        let fraction = min(1, Double(totalBytesWritten) / Double(expected))
        Task { @MainActor in
            self.progressReports += 1
            guard let shown = self.downloads[spec.id] else { return }
            if abs(shown - fraction) > 0.005 || fraction == 1 {
                self.downloads[spec.id] = fraction
                self.liveActivity.update(spec.owner, fraction: self.progress(for: spec.owner))
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didFinishDownloadingTo location: URL) {
        guard let spec = downloadSpec(downloadTask) else { return }
        do {
            guard let response = downloadTask.response as? HTTPURLResponse,
                  (200...299).contains(response.statusCode) else {
                throw NSError(domain: "PocketGemma", code: 2,
                    userInfo: [NSLocalizedDescriptionKey: String(localized: "ダウンロードに失敗しました。通信状態を確認して、もう一度お試しください。")])
            }
            try AppFiles.prepareModels()
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) {
                try FileManager.default.removeItem(at: pending)
            }
            // URLSession removes its temporary file when this callback returns.
            try FileManager.default.moveItem(at: location, to: pending)
            Task { @MainActor in self.verifyPendingFile(spec) }
        } catch {
            let description = error.localizedDescription
            Task { @MainActor in
                self.downloads[spec.id] = nil
                self.error = description
                self.finishActivity(spec, .failed)
                DownloadLog.shared.note("受け取りに失敗 \(spec.name) \(description)")
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let spec = downloadSpec(task) else { return }
        let canceled = (error as NSError).code == NSURLErrorCancelled
        let description = error.localizedDescription
        let identifier = task.taskIdentifier
        Task { @MainActor in
            // Cancelled to start again with the other cellular choice.
            if self.restartedTasks.remove(identifier) != nil { return }
            guard self.downloads[spec.id] != nil else { return }
            self.downloads[spec.id] = nil
            if !canceled { self.error = String(localized: "ダウンロードを完了できませんでした。") + "\n" + description }
            self.finishActivity(spec, canceled ? .cancelled : .failed)
            DownloadLog.shared.note((canceled ? "中止 " : "ダウンロード失敗 ") + "\(spec.name) \(canceled ? "" : description)")
        }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor in self.finishBackgroundEventsIfPossible() }
    }
}
