import Foundation
import Combine
import UIKit
import PocketCore

private func downloadSpec(_ task: URLSessionTask) -> ModelSpec? {
    if let spec = ModelSpec.find(task.taskDescription) { return spec }
    // Background downloads started by 1.0.4 did not have taskDescription.
    let file = task.originalRequest?.url?.lastPathComponent
    return ModelSpec.catalog.first { $0.fileName == file }
}

@MainActor
final class ModelStore: NSObject, ObservableObject {
    static let shared = ModelStore()
    @Published private(set) var selectedModel: ModelSpec
    @Published private(set) var installedIDs: Set<String>
    /// Running downloads and their progress by model id. Several can run at
    /// once; they share the Live Activity.
    @Published private(set) var downloads: [String: Double] = [:]
    /// The model whose file is being checked. Checks run one at a time;
    /// downloads that finish meanwhile wait in `queuedIDs`.
    @Published private(set) var verifyingID: String?
    @Published private(set) var queuedIDs: Set<String> = []
    @Published private(set) var isRestoring = true
    @Published var error: String?
    private var backgroundCompletion: (() -> Void)?
    private let liveActivity = DownloadActivity()
    /// While a download runs: reads the tasks' progress every two seconds
    /// (in case progress reports stop coming while the app is in the
    /// background) and writes a line to the download record every ten.
    private var progressTimer: Timer?
    private var ticks = 0
    private var progressReports = 0
    /// Bytes each download had at the last line of the record, for its speed.
    private var lastLogged: [String: (date: Date, bytes: Int64)] = [:]

    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: "app.pocketgemma.model-download")
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        config.allowsCellularAccess = false
        // One connection per model, so simultaneous downloads really run
        // side by side (the catalog shares a host).
        config.httpMaximumConnectionsPerHost = 4
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    private override init() {
        selectedModel = ModelSpec.find(UserDefaults.standard.string(forKey: "selectedModelID")) ?? .e4b
        AppFiles.migrateModels()
        installedIDs = Set(ModelSpec.catalog.filter { AppFiles.hasVerifiedModel($0) }.map(\.id))
        super.init()
        DownloadLog.shared.watchApp()
        session.getAllTasks { tasks in
            Task { @MainActor in
                // A completion delegate may already have started validation
                // while getAllTasks was in flight. Do not restore that old
                // download state over the newer verification state.
                for task in tasks where task.state != .completed && task.state != .canceling {
                    guard let spec = downloadSpec(task), !self.isWorking(on: spec) else { continue }
                    let fraction = task.progress.fractionCompleted
                    self.downloads[spec.id] = fraction
                    self.liveActivity.begin(spec, fraction: fraction, userInitiated: false)
                    DownloadLog.shared.note("続きから \(spec.name) \(Int(fraction * 100))%")
                    self.watchProgress()
                }
                self.isRestoring = false
                self.restoreNextPending()
                self.liveActivity.endAll(except: Set(self.downloads.keys).union(self.queuedIDs)
                    .union([self.verifyingID].compactMap { $0 }))
            }
        }
    }

    var isReady: Bool { isInstalled(selectedModel) }
    /// Restoring or checking a file: imports and automatic choices wait.
    var isBusy: Bool { isRestoring || verifyingID != nil }
    func isInstalled(_ spec: ModelSpec) -> Bool { installedIDs.contains(spec.id) }
    func isDownloading(_ spec: ModelSpec) -> Bool { downloads[spec.id] != nil }
    func progress(for spec: ModelSpec) -> Double { downloads[spec.id] ?? 0 }
    func isWorking(on spec: ModelSpec) -> Bool {
        downloads[spec.id] != nil || verifyingID == spec.id || queuedIDs.contains(spec.id)
    }
    /// Models are visible in the Files app, where they can be deleted.
    func refreshInstalled() {
        guard !isBusy else { return }
        let current = Set(ModelSpec.catalog.filter { AppFiles.hasVerifiedModel($0) }.map(\.id))
        if current != installedIDs { installedIDs = current }
    }
    func select(_ spec: ModelSpec) {
        // The startup chooser records the preferred model before downloading
        // it. Readiness still depends on its verified installation receipt.
        guard ModelSpec.find(spec.id) != nil else { return }
        selectedModel = spec
        UserDefaults.standard.set(spec.id, forKey: "selectedModelID")
    }
    func statusText(for spec: ModelSpec) -> String {
        if isRestoring { return "保存状態を確認しています…" }
        if verifyingID == spec.id { return "\(spec.name)を確認しています…" }
        if queuedIDs.contains(spec.id) { return "\(spec.name)の確認を待っています…" }
        if let fraction = downloads[spec.id] { return "\(spec.name)をダウンロード中 · \(Int(fraction * 100))%" }
        return isInstalled(spec) ? "保存済み · オフラインで利用できます" : "モデルを選んで保存してください"
    }

    func download(_ spec: ModelSpec) {
        guard !isRestoring, !isWorking(on: spec), !isInstalled(spec) else { return }
        do {
            try AppFiles.prepareModels()
            let values = try AppFiles.models.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            // Room for this model and for the others still downloading.
            let others = downloads.keys.compactMap { ModelSpec.find($0)?.byteCount }.reduce(0, +)
            if let available = values.volumeAvailableCapacityForImportantUsage,
               available < spec.byteCount + others + 1_000_000_000 {
                throw NSError(domain: "PocketGemma", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "空き容量が不足しています。モデルのサイズに加えて1 GB以上の空きが必要です。"])
            }
            error = nil
            downloads[spec.id] = 0
            let task = session.downloadTask(with: spec.downloadURL)
            task.taskDescription = spec.id
            task.resume()
            liveActivity.begin(spec, fraction: 0, userInitiated: true)
            DownloadLog.shared.note("ダウンロード開始 \(spec.name)")
            watchProgress()
        } catch { self.error = error.localizedDescription }
    }

    private func watchProgress() {
        guard progressTimer == nil else { return }
        ticks = 0
        progressTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.pollProgress() }
        }
    }

    private func pollProgress() {
        guard !downloads.isEmpty else {
            progressTimer?.invalidate()
            progressTimer = nil
            lastLogged = [:]
            return
        }
        ticks += 1
        session.getAllTasks { tasks in
            let received: [(id: String, bytes: Int64, expected: Int64)] = tasks.compactMap { task in
                guard task.state == .running, let spec = downloadSpec(task) else { return nil }
                return (spec.id, task.countOfBytesReceived,
                        task.countOfBytesExpectedToReceive > 0 ? task.countOfBytesExpectedToReceive : spec.byteCount)
            }
            Task { @MainActor in self.applyPolledProgress(received) }
        }
    }

    private func applyPolledProgress(_ received: [(id: String, bytes: Int64, expected: Int64)]) {
        for (id, bytes, expected) in received {
            guard let spec = ModelSpec.find(id), let shown = downloads[id] else { continue }
            let fraction = min(1, Double(bytes) / Double(expected))
            if fraction - shown > 0.005 {
                downloads[id] = fraction
                liveActivity.update(spec, fraction: fraction)
            }
        }
        guard ticks % 5 == 1 else { return }
        let now = Date()
        let figures = received.compactMap { id, bytes, _ -> String? in
            guard let spec = ModelSpec.find(id) else { return nil }
            // The speed since the last line tells a slower background
            // transfer apart from a figure that only stopped moving.
            var speed = ""
            if let last = lastLogged[id], bytes >= last.bytes, now.timeIntervalSince(last.date) > 1 {
                speed = String(format: " · %.1f MB/秒", Double(bytes - last.bytes) / 1_000_000 / now.timeIntervalSince(last.date))
            }
            lastLogged[id] = (now, bytes)
            return "\(spec.name) \(Int((downloads[id] ?? 0) * 100))%（受信 \(bytes / 1_000_000) MB\(speed)）"
        }
        DownloadLog.shared.note((figures.isEmpty ? "実行中のタスクなし" : figures.joined(separator: " / "))
            + " · 進み報告\(progressReports)回 · 島の更新\(liveActivity.takeUpdateCount())回 · \(DownloadLog.appState)"
            + " · 続ける作業\(liveActivity.continuedState) · 島\(liveActivity.stateText)")
        progressReports = 0
    }

    /// Removes the receipt first, so a model whose file could not be removed
    /// never counts as installed.
    func delete(_ spec: ModelSpec) {
        guard !isWorking(on: spec) else { return }
        let library = AppFiles.library
        try? FileManager.default.removeItem(at: library.receiptURL(spec))
        installedIDs.remove(spec.id)
        do {
            if FileManager.default.fileExists(atPath: library.modelURL(spec).path) {
                try FileManager.default.removeItem(at: library.modelURL(spec))
            }
        } catch { self.error = "モデルを削除できませんでした。\n\(error.localizedDescription)" }
    }

    func cancelDownload(_ spec: ModelSpec) {
        session.getAllTasks { tasks in
            tasks.filter { downloadSpec($0)?.id == spec.id }.forEach { $0.cancel() }
        }
    }

    func importModel(_ url: URL, spec: ModelSpec) {
        guard !isBusy, !isWorking(on: spec), !isInstalled(spec) else { return }
        guard url.pathExtension.lowercased() == "litertlm" else {
            error = "選んだモデルの .litertlm ファイルを取り込んでください。"
            return
        }
        verifyingID = spec.id
        error = nil
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    let granted = url.startAccessingSecurityScopedResource()
                    defer { if granted { url.stopAccessingSecurityScopedResource() } }
                    try AppFiles.prepareModels()
                    let pending = AppFiles.pendingModel(spec)
                    var coordinationError: NSError?
                    var copyError: Error?
                    NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordinationError) { source in
                        do {
                            if FileManager.default.fileExists(atPath: pending.path) {
                                try FileManager.default.removeItem(at: pending)
                            }
                            try FileManager.default.copyItem(at: source, to: pending)
                        } catch { copyError = error }
                    }
                    if let coordinationError { throw coordinationError }
                    if let copyError { throw copyError }
                    try ModelValidator.validate(pending, spec: spec)
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
            }
            verifyingID = nil
            restoreNextPending()
        }
    }

    private func restoreNextPending() {
        guard !isRestoring, verifyingID == nil else { return }
        if let spec = ModelSpec.catalog.first(where: {
            downloads[$0.id] == nil && FileManager.default.fileExists(atPath: AppFiles.pendingModel($0).path)
        }) { verifyPendingFile(spec) }
    }

    private func verifyPendingFile(_ spec: ModelSpec) {
        downloads[spec.id] = nil
        liveActivity.verifying(spec)
        DownloadLog.shared.note("ファイルの確認へ \(spec.name)（\(DownloadLog.appState)）")
        guard verifyingID == nil else { queuedIDs.insert(spec.id); return }
        queuedIDs.remove(spec.id)
        verifyingID = spec.id
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    try ModelValidator.validate(AppFiles.pendingModel(spec), spec: spec)
                    try AppFiles.installVerifiedModel(spec)
                }.value
                installedIDs.insert(spec.id)
                liveActivity.finish(spec, .installed)
                DownloadLog.shared.note("保存完了 \(spec.name)")
            } catch {
                self.error = error.localizedDescription
                try? FileManager.default.removeItem(at: AppFiles.pendingModel(spec))
                liveActivity.finish(spec, .failed)
                DownloadLog.shared.note("確認に失敗 \(spec.name) \(error.localizedDescription)")
            }
            verifyingID = nil
            restoreNextPending()
        }
    }

    func attachBackgroundCompletion(_ completion: @escaping () -> Void) {
        backgroundCompletion = completion
        DownloadLog.shared.note("iOSがダウンロードの知らせで起こした（\(DownloadLog.appState)）")
        _ = session
    }
    private func finishBackgroundEventsIfPossible() {
        // The delegate has persisted the file. Hashing must not hold iOS's
        // background event completion handler for a multi-gigabyte pass.
        guard let completion = backgroundCompletion else { return }
        backgroundCompletion = nil
        // This launch is the app's background time: the island's change
        // (checking, saved, failed) goes out before iOS suspends the app.
        Task {
            await Task.yield()
            await liveActivity.flush()
            completion()
        }
    }
}

extension ModelStore: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                               totalBytesExpectedToWrite: Int64) {
        guard let spec = downloadSpec(downloadTask) else { return }
        let expected = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : spec.byteCount
        let fraction = min(1, Double(totalBytesWritten) / Double(expected))
        Task { @MainActor in
            self.progressReports += 1
            guard let shown = self.downloads[spec.id] else { return }
            if abs(shown - fraction) > 0.005 || fraction == 1 {
                self.downloads[spec.id] = fraction
                self.liveActivity.update(spec, fraction: fraction)
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                               didFinishDownloadingTo location: URL) {
        guard let spec = downloadSpec(downloadTask) else { return }
        do {
            guard let response = downloadTask.response as? HTTPURLResponse,
                  (200...299).contains(response.statusCode) else {
                throw NSError(domain: "PocketGemma", code: 2,
                    userInfo: [NSLocalizedDescriptionKey: "ダウンロードに失敗しました。Wi-Fi接続を確認して、もう一度お試しください。"])
            }
            try AppFiles.prepareModels()
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) {
                try FileManager.default.removeItem(at: pending)
            }
            // URLSession removes its temporary file when this callback returns.
            try FileManager.default.moveItem(at: location, to: pending)
            Task { @MainActor in self.verifyPendingFile(spec) }
        } catch {
            let description = error.localizedDescription
            Task { @MainActor in
                self.downloads[spec.id] = nil
                self.error = description
                self.liveActivity.finish(spec, .failed)
                DownloadLog.shared.note("受け取りに失敗 \(spec.name) \(description)")
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error, let spec = downloadSpec(task) else { return }
        let canceled = (error as NSError).code == NSURLErrorCancelled
        let description = error.localizedDescription
        Task { @MainActor in
            guard self.downloads[spec.id] != nil else { return }
            self.downloads[spec.id] = nil
            if !canceled { self.error = "ダウンロードを完了できませんでした。\n\(description)" }
            self.liveActivity.finish(spec, canceled ? .cancelled : .failed)
            DownloadLog.shared.note((canceled ? "中止 " : "ダウンロード失敗 ") + "\(spec.name) \(canceled ? "" : description)")
        }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor in self.finishBackgroundEventsIfPossible() }
    }
}
