import Foundation
import Darwin
import CLiteRTLM
import PocketCore

/// The 0.18 C API has a severity setter, but no log callback. Read stderr
/// through a drained pipe, forward it to its original destination, and retain
/// only the core's bounded operational allowlist. OSLog is not captured.
final class NativeLogCapture: @unchecked Sendable {
    private static let reservation = NSLock()
    private static var reserved = false
    private let queue = DispatchQueue(label: "app.pocketgemma.native-diagnostics")
    private let queueKey = DispatchSpecificKey<UInt8>()
    private let readFD: Int32
    private let originalFD: Int32
    private var source: DispatchSourceRead?
    private var buffer: NativeLogBuffer
    private var stopped = false

    init?(includeInfo: Bool = false, keepsGPUMessages: Bool = false) {
        Self.reservation.lock()
        guard !Self.reserved else { Self.reservation.unlock(); return nil }
        Self.reserved = true
        Self.reservation.unlock()
        var descriptors: [Int32] = [-1, -1]
        let saved = dup(STDERR_FILENO)
        guard saved >= 0, pipe(&descriptors) == 0 else {
            if saved >= 0 { close(saved) }
            Self.releaseReservation(); return nil
        }
        guard fcntl(descriptors[0], F_SETFL, O_NONBLOCK) == 0 else {
            close(saved); close(descriptors[0]); close(descriptors[1])
            Self.releaseReservation(); return nil
        }
        fflush(stderr)
        guard dup2(descriptors[1], STDERR_FILENO) >= 0 else {
            close(saved); close(descriptors[0]); close(descriptors[1])
            Self.releaseReservation(); return nil
        }
        close(descriptors[1])
        readFD = descriptors[0]; originalFD = saved
        buffer = NativeLogBuffer(keepsGPUMessages: keepsGPUMessages)
        queue.setSpecific(key: queueKey, value: 1)
        // Public native API, not thread-local error retrieval from the wrong
        // Swift executor. Native TFLite messages may ignore this LM severity.
        litert_lm_set_min_log_level(includeInfo ? kLiteRtLmLogSeverityInfo : kLiteRtLmLogSeverityWarning)
        let reader = DispatchSource.makeReadSource(fileDescriptor: readFD, queue: queue)
        reader.setEventHandler { [weak self] in self?.drain() }
        reader.setCancelHandler { [readFD] in close(readFD) }
        source = reader
        reader.resume()
    }

    func finish() -> NativeLogBuffer {
        guard !stopped else { return queue.sync { buffer } }
        stopped = true
        fflush(stderr)
        // Restore first so native/background logging can no longer fill the
        // pipe. The queue consumes all remaining bytes before returning.
        _ = dup2(originalFD, STDERR_FILENO)
        let finishOnQueue = { () -> NativeLogBuffer in
            self.drain(); self.buffer.finish(); self.source?.cancel(); self.source = nil
            close(self.originalFD)
            return self.buffer
        }
        let snapshot = DispatchQueue.getSpecific(key: queueKey) != nil ? finishOnQueue() : queue.sync(execute: finishOnQueue)
        litert_lm_set_min_log_level(kLiteRtLmLogSeverityWarning)
        Self.releaseReservation()
        return snapshot
    }

    private func drain() {
        var bytes = [UInt8](repeating: 0, count: 4096)
        while true {
            let count = read(readFD, &bytes, bytes.count)
            if count < 0 && errno == EINTR { continue }
            guard count > 0 else { return }
            let data = Data(bytes.prefix(count))
            buffer.append(data)
            data.withUnsafeBytes { raw in
                var offset = 0
                while offset < raw.count {
                    let written = write(originalFD, raw.baseAddress!.advanced(by: offset), raw.count - offset)
                    if written < 0 && errno == EINTR { continue }
                    guard written > 0 else { break }
                    offset += written
                }
            }
        }
    }
    private static func releaseReservation() {
        reservation.lock(); reserved = false; reservation.unlock()
    }
    deinit { if !stopped { _ = finish() } }
}
