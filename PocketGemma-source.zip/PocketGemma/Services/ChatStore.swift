import Foundation
import Combine
import PocketCore
import UIKit

@MainActor
final class ChatStore: ObservableObject {
    /// One for the app: iOS may wake it in the background for a question
    /// from the Apple Watch (WatchBridge) before any screen is shown.
    static let shared = ChatStore()
    @Published private(set) var threads: [ChatThread] = []
    /// Kept for the next launch (起動時のチャット's 前回の会話, LaunchChatPlan).
    @Published private(set) var selectedID: UUID? {
        didSet { if selectedID != oldValue { LaunchChatPlan.remember(selectedID) } }
    }
    @Published private(set) var isGenerating = false
    @Published private(set) var isStopping = false
    @Published private(set) var status = ""
    /// One GPU start test per launch: a failed GPU start can keep its
    /// address space until the app quits, which would skew the next test.
    @Published private(set) var gpuStartTestRan = false
    /// A tapped notification chose the chat (起動時のチャット leaves it open).
    private(set) var openedFromNotification = false
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    private let archive = ChatArchive(fileURL: AppFiles.archive)
    private let gemma = GemmaService()
    private var generationTask: Task<Void, Never>?
    private var watchdogTask: Task<Void, Never>?
    private var replyTicket = ReplyTicket()
    private var lastActivity = Date()
    private var stageStarted = Date()
    private var currentStage = GemmaService.Stage.loading.rawValue
    private var archiveWritable = true
    private var lastCheckpoint = Date.distantPast
    private var bufferedText = ""
    private var bufferTask: Task<Void, Never>?
    private var bufferedTarget: (ticket: UUID, thread: UUID, message: UUID)?
    private var activeReply: (thread: UUID, message: UUID)?
    private var interruptedReply: (thread: UUID, message: UUID)?
    /// Background time for a reply still being written when the app leaves
    /// the screen, and the notification when it ends there.
    private let background = BackgroundReply()
    /// The language backend of the reply being written. iPhone apps can't
    /// use the GPU in the background, so a reply on the GPU stops when the
    /// app leaves and goes on on the CPU.
    private var activeBackend = ExecutionBackend.gpu
    /// The reply stopped on the GPU to go on on the CPU.
    private var handoff: (thread: UUID, message: UUID)?
    /// The reply that ran out of background time; its notification says so.
    private var pausedInBackground: UUID?
    /// For the diagnostics: the reply was written partly in the background,
    /// moved to the CPU there, and back to the GPU on return.
    private var leftScreen = false
    private var movedToCPU = false
    private var movedBackToGPU = false
    private var replyCharacters = 0
    /// The limits of the reply being written, for a model that has them
    /// (ReplyGuard); when the model began on the question, after loading;
    /// and whether a word of the answer has come.
    private var replyGuard: ReplyGuard?
    private var generationStarted: Date?
    private var replyAnswered = false
    private var openChatObserver: NSObjectProtocol?
    /// Replies written for the Apple Watch: Gemma 4 E2B's, whatever their
    /// chat's model, also when they go on after a stop (resume).
    private var watchReplies: Set<UUID> = []
    /// The reply a model on the PC writes (PCと接続, 1.1.0 (253)), and the
    /// id the PC knows its request by, to stop it there.
    private var pcReply: (message: UUID, request: String)?
    /// The reply Claude writes (1.1.0 (257)): stopped by closing its
    /// connection, which the relay passes on to Anthropic.
    private var claudeReply: UUID?
    /// That reply is kept at the relay (/v1/replies, 1.1.0 (260)): a
    /// dropped connection, or iOS holding the app, doesn't end it.
    private var claudeKept = false

    init() {
        do {
            threads = try archive.load().sorted { $0.updatedAt > $1.updatedAt }
            // The chat open when Fielua was last left, as it was.
            selectedID = LaunchChatPlan.opening(threads, lastOpen: LaunchChatPlan.lastOpen())
        } catch {
            // Preserve a corrupted archive for recovery, rather than overwrite it.
            archiveWritable = false
            self.error = String(localized: "会話履歴を開けませんでした。元のファイルを保護するため、この起動中は履歴保存を停止しています。") + "\n" + error.localizedDescription
        }
        // A deletion cut short (the app ended, the phone restarted): its
        // files go now, unless a saved chat still uses them (DeletionJournal).
        if archiveWritable { finishDeletion() }
        if selectedID == nil { newChat() }
        LaunchChat.choose(in: self)
        // Smart Memory's index, built ahead off the main thread.
        if SmartMemory.isOn {
            let saved = threads
            Task.detached(priority: .utility) { await SmartMemoryStore.shared.warm(saved) }
        }
        background.onExpired = { [weak self] in self?.pauseInBackground() }
        // A tapped notification opens its chat.
        openChatObserver = NotificationCenter.default.addObserver(forName: ReplyNotifications.openChat, object: nil,
                                                                  queue: .main) { [weak self] note in
            MainActor.assumeIsolated {
                if let id = ReplyNotifications.threadID(in: note) {
                    self?.openedFromNotification = true
                    self?.select(id)
                }
            }
        }
    }

    var current: ChatThread? { threads.first { $0.id == selectedID } }
    var messages: [ChatMessage] { current?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(current?.modelID) ?? .e4b }
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings(for: currentModel)).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        guard !isGenerating else { return }
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }
    /// How the current chat's model reads photos and replies (高速 or
    /// じっくり考える), when it offers a choice (ModelSpec.photoDetails): the
    /// choice, not what runs, which is 深く in じっくり考える's place where the
    /// launch lacks the room (`deeperFallsBack`). Saved with that model's
    /// settings and used from the next send; ignored while a reply is
    /// generating. The chat's messages and the model's other settings stay.
    var photoDetail: PhotoDetail { currentSettings.photoDetail.choice }
    /// Whether じっくり考える is chosen but runs as 深く on this launch, without
    /// thinking (GenerationSettings.deeperFallsBack): the chat and the menu
    /// say so.
    /// A Smart Mode chat chooses for each question and says what its choice
    /// could not give with the reply (SmartNotice).
    var deeperFallsBack: Bool { !isSmart && current?.isRemote != true && currentSettings.deeperFallsBack(on: currentModel) }
    func setPhotoDetail(_ detail: PhotoDetail) {
        guard currentModel.photoDetails.contains(detail) else { return }
        var settings = currentSettings
        settings.photoDetail = detail
        updateSettings(settings)
    }

    /// The current chat's web search switch (off unless turned on), and
    /// whether the chat may search at all: Gemma, and no file in it. The
    /// person's Tavily key is WebSearchKeyState's.
    /// A Claude chat's ウェブ検索 is Claude's own (1.1.0 (260)), files or not.
    var webSearchOn: Bool { current?.webSearch == true && current?.pc == nil }
    var webSearchBlocked: Bool { current?.claude == nil && WebSearchPolicy.blockedByFiles(messages) }
    /// In a Smart Mode chat, where a model that searches is saved: ウェブ検索
    /// goes to it (SmartPlanner).
    var webSearchOffered: Bool {
        // A PC chat sends the conversation to the PC alone (PCと接続); a
        // Claude chat searches with Claude's own tool where the relay offers it (1.1.0 (260)).
        if current?.claude != nil { return ClaudeLinkStore.shared.offersWebSearch }
        guard current?.isRemote != true else { return false }
        guard isSmart else { return WebSearchPolicy.offers(currentModel) }
        return SmartPlanner.starters.contains { ModelSpec.find($0).map(ModelStore.shared.isInstalled) == true }
    }
    func setWebSearch(_ on: Bool) {
        guard !isGenerating, let index = threads.firstIndex(where: { $0.id == selectedID }) else { return }
        threads[index].webSearch = on ? true : nil
        if threads[index].claude != nil { ClaudeLinkStore.shared.rememberTools(threads[index]) }
        persist()
    }

    /// A Claude chat's ファイル作成 (1.1.0 (260)): its replies may make
    /// files with code execution, where the relay offers it.
    var makesFilesOn: Bool { current?.claude != nil && current?.makesFiles == true }
    var makesFilesOffered: Bool { current?.claude != nil && ClaudeLinkStore.shared.offersFiles }
    func setMakesFiles(_ on: Bool) {
        guard !isGenerating, let index = threads.firstIndex(where: { $0.id == selectedID }), threads[index].claude != nil else { return }
        threads[index].makesFiles = on ? true : nil
        ClaudeLinkStore.shared.rememberTools(threads[index])
        persist()
    }

    /// `pinned`: the person chose the model (the model menu, or モデル管理's
    /// 「このモデルで会話を始める」), and the chat keeps it whatever Smart
    /// Mode would choose. Any other new chat is Smart Mode's while it is on,
    /// and rests on a saved model (SmartPlanner.restingModel). A new chat
    /// starts on 自動, an empty one reused too.
    func newChat(modelID: String? = nil, pinned: Bool = false) {
        guard !isGenerating else { return }
        // From a PC chat, a new chat goes on with the same model on the PC
        // while the PC is registered (PCと接続, 1.1.0 (253)).
        if modelID == nil, let pc = current?.pc, PCLinkStore.shared.paired?.pcID == pc.pcID {
            newPCChat(pc)
            return
        }
        // From a Claude chat, a new chat goes on with Claude while this
        // iPhone is registered (1.1.0 (257)).
        if modelID == nil, current?.claude != nil, ClaudeLinkStore.shared.isRegistered {
            newClaudeChat()
            return
        }
        let smart = SmartMode.isOn && !pinned
        var modelID = modelID ?? ModelStore.shared.selectedModel.id
        if smart, let resting = SmartPlanner.restingModel(preferred: ModelSpec.find(modelID) ?? .e4b,
                                                         context: smartContext(current: ModelSpec.find(modelID) ?? .e4b)) {
            modelID = resting.id
        }
        if let empty = threads.firstIndex(where: { $0.messages.isEmpty && !$0.isRemote && $0.modelID == modelID
                                                   && ($0.modelPinned == true) == pinned }) {
            threads[empty].genre = .auto
            selectedID = threads[empty].id
        } else {
            var thread = ChatThread(modelID: modelID)
            thread.modelPinned = pinned ? true : nil
            threads.insert(thread, at: 0)
            selectedID = thread.id
        }
        persist()
    }

    func select(_ id: UUID) {
        // A deleted chat (from a notification, say) is not opened.
        guard !isGenerating, threads.contains(where: { $0.id == id }) else { return }
        selectedID = id
    }

    /// The history sidebar's 削除: as 設定 › 会話履歴's, for one chat.
    func delete(_ id: UUID) { deleteChats([id]) }

    /// 設定 › 会話履歴 (1.1.0 (251)): the chats chosen go, with the
    /// attachment files only they used, their kept drafts, and every
    /// mention of them as Smart Memory's sources; the other chats, their
    /// files and the models stay. In this order, so nothing is lost if the
    /// app ends partway: the files to remove are written down, the
    /// conversations are saved without the chats, then the files go and
    /// the note with them (finishDeletion at the next launch otherwise).
    /// Not while a reply is written. With the open chat deleted, a new
    /// chat opens.
    @discardableResult
    func deleteChats(_ ids: Set<UUID>) -> Bool {
        guard !isGenerating, handoff == nil, !ids.isEmpty else { return false }
        guard archiveWritable else {
            error = String(localized: "会話履歴を開けなかったため、削除できません。")
            return false
        }
        let plan = ChatDeletion.plan(deleting: ids, from: threads)
        guard !plan.deleted.isEmpty else { return false }
        let journal = DeletionJournal(threads: Array(plan.deleted), files: plan.files.sorted())
        do {
            if !plan.files.isEmpty { try journal.save(AppFiles.deletionJournal) }
            try archive.save(plan.remaining)
        } catch {
            try? FileManager.default.removeItem(at: AppFiles.deletionJournal)
            self.error = String(localized: "会話を削除できませんでした。") + "\n" + error.localizedDescription
            return false
        }
        let openGone = selectedID.map(plan.deleted.contains) ?? true
        threads = plan.remaining
        for id in plan.deleted { LaunchDrafts.set("", for: id) }
        if let waiting = interruptedReply, plan.deleted.contains(waiting.thread) { interruptedReply = nil }
        finishDeletion()
        if openGone {
            selectedID = nil
            newChat()
        } else {
            CloudHistoryStore.shared.schedule(threads)
        }
        if SmartMemory.isOn {
            let saved = threads
            Task.detached(priority: .utility) { await SmartMemoryStore.shared.warm(saved) }
        }
        return true
    }

    /// Removes the attachment files a deletion wrote down, those no saved
    /// chat uses, then the note.
    private func finishDeletion() {
        guard let journal = DeletionJournal.load(AppFiles.deletionJournal) else { return }
        for name in journal.pending(given: threads) {
            if let url = AttachmentStorage.url(name) { try? FileManager.default.removeItem(at: url) }
        }
        try? FileManager.default.removeItem(at: AppFiles.deletionJournal)
    }

    /// 試験機能を試してみる's Smart Memory switch: its index is built ahead
    /// when turned on, and let go when turned off.
    func smartMemoryChanged(_ on: Bool) {
        let saved = threads
        Task.detached(priority: .utility) {
            if on { await SmartMemoryStore.shared.warm(saved) } else { await SmartMemoryStore.shared.clear() }
        }
    }

    /// Smart Memory's search for a question once its reply has begun; what
    /// it found is kept with the reply, by id (MemoryRecall).
    private func recallMemory(_ ask: SmartMemoryStore.Ask?, threadID: UUID, messageID: UUID) async -> SmartMemoryStore.Recalled? {
        guard let ask, SmartMemory.isOn, let recalled = await SmartMemoryStore.recall(ask) else { return nil }
        if let ti = threads.firstIndex(where: { $0.id == threadID }),
           let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) {
            threads[ti].messages[mi].memory = MemoryRecall(sources: recalled.note.sources)
        }
        return recalled
    }

    @discardableResult
    func send(_ raw: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        // Spoken alone, the recording is the question (VoiceNote.ask).
        let spoken = attachments.contains { $0.kind == .audio }
        let prompt = trimmed.isEmpty && !attachments.isEmpty
            ? (spoken ? VoiceNote.ask : String(localized: "添付した内容を説明してください。")) : trimmed
        guard !prompt.isEmpty, !isGenerating else { return false }
        guard prompt.utf8.count <= 4500 else {
            error = String(localized: "1回のメッセージは約1,500文字までです。長い文章は分けて送ってください。")
            return false
        }
        guard let id = selectedID, let index = threads.firstIndex(where: { $0.id == id }) else { return false }
        // A chat answered on the PC (PCと接続) asks it there.
        if let target = threads[index].pc {
            return sendToPC(prompt, target: target, threadIndex: index, messageID: messageID, attachments: attachments)
        }
        // A chat answered by Claude asks it through the relay (1.1.0 (257)),
        // with its photos and files (1.1.0 (260)).
        if threads[index].claude != nil {
            let alone = trimmed.isEmpty && attachments.contains { $0.kind == .image }
            return sendToClaude(prompt, threadIndex: index, messageID: messageID, attachments: attachments, hidesText: alone)
        }
        // Smart Mode chooses the model and its settings for the question
        // (SmartPlanner); a chat whose model the person chose keeps both.
        let smartPlan: SmartPlanner.Plan?
        if isSmartChat(threads[index]) {
            switch planReply(for: threads[index], prompt: prompt, attachments: attachments) {
            case .success(let plan): smartPlan = plan
            case .failure(let unavailable): error = unavailable.message; return false
            }
        } else { smartPlan = nil }
        let requestedModel = smartPlan?.model ?? currentModel
        let attachmentPolicy = ModelAttachmentPolicy(model: requestedModel)
        do { try attachmentPolicy.validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        let settings = smartPlan.map { savedSettings(for: requestedModel).tuned($0.tuning, for: requestedModel) } ?? currentSettings
        // A video counts the scenes the reply sees (VideoDigest.Allowance).
        let visualCount = attachments.reduce(0) { $0 + $1.modelImageNames(settings).count }
        guard visualCount == 0 || requestedModel.supportsVision else {
            error = String(localized: "写真にはGemma 4 E2Bを選んでください。"); return false
        }
        // A chart request also carries the chart format's note (GemmaService).
        let guideCost = RichFormatGuide.guide(for: prompt)?.utf8.count ?? 0
        let inputBudget = settings.inputByteBudget
        // Long files: what fits this turn, around the question.
        var prepared = AttachmentStorage.excerpted(attachments, question: prompt, settings: settings)
        // A sent video's note says how its analysis goes (VideoDigest.note).
        for index in prepared.indices {
            if let video = prepared[index].video { prepared[index].note = VideoDigest.note(video, sent: true) }
        }
        let currentCost = prompt.utf8.count + guideCost
            + prepared.reduce(0) { $0 + $1.contextByteCost(settings) }
        guard visualCount <= 4, currentCost <= inputBudget else {
            error = String(localized: "添付内容がモデルの入力上限を超えています。添付を減らすか、構成のMax Tokensを増やしてください。"); return false
        }
        guard ModelStore.shared.isInstalled(requestedModel) else {
            error = String(localized: "設定の「モデル管理」から\(requestedModel.name)をダウンロードしてください。")
            return false
        }
        // Only the query leaves the device, and only in a chat whose search
        // is on, with the person's key, and that has no file (WebSearchPolicy).
        // In Smart Mode the switch is the genre ウェブ検索: 自動 never
        // searches for what the words seem to ask.
        let searches = WebSearchPolicy.searches(enabled: smartPlan?.searches ?? (threads[index].webSearch == true),
                                                keyed: WebSearchKeyState.shared.isReady,
                                                model: requestedModel, messages: threads[index].messages, attachments: prepared,
                                                asked: prompt)
        let history = replyHistory(threads[index].messages, model: requestedModel, settings: settings,
                                   cost: currentCost + (searches ? WebSearch.reservedBytes : 0),
                                   images: attachments.reduce(0) { $0 + Self.mediaCount($1, settings) })
        var assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        if let smartPlan {
            assistant.smart = SmartReply(genre: threads[index].genre, modelID: requestedModel.id, tuning: smartPlan.tuning,
                                         searched: searches, notices: smartPlan.notices)
            // The chat goes on with the model chosen, which its next
            // question keeps while it suits (SmartPlanner.order).
            threads[index].modelID = requestedModel.id
        }
        var asked = ChatMessage(id: messageID, role: .user, text: prompt, attachments: prepared)
        // A photo, video or recording sent alone shows alone; the model
        // still gets the ask.
        if trimmed.isEmpty, prepared.contains(where: { [.image, .video, .audio].contains($0.kind) }) { asked.hidesText = true }
        threads[index].messages.append(asked)
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        let hasVision = (prepared + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
        let search = searches ? searchTurn(threadID: id, messageID: assistant.id) : nil
        let backend = InferenceEnginePlan(model: requestedModel, settings: settings, needsVision: hasVision).backend
        let keep = videoKeeper(threadID: id, messageID: messageID)
        // Smart Memory (1.1.0 (251)): the earlier exchanges that bear on the
        // question, searched for once the reply has begun (SmartMemoryStore).
        let memoryAsk = SmartMemory.isOn
            ? SmartMemoryStore.Ask(question: prompt, threads: threads, history: history,
                                   cost: currentCost + (searches ? WebSearch.reservedBytes : 0),
                                   inputByteBudget: inputBudget, visualTokenBudget: settings.visualTokenBudget)
            : nil
        let replyID = assistant.id
        startReply(threadID: id, messageID: assistant.id, hasVision: hasVision, backend: backend) { [gemma = self.gemma, weak self] onStage, onText in
            let recalled = await self?.recallMemory(memoryAsk, threadID: id, messageID: replyID)
            try await gemma.generate(threadID: id, prompt: prompt, history: recalled?.history ?? history,
                model: requestedModel, settings: settings, attachments: prepared, webSearch: search,
                memory: recalled?.note, memorySummary: recalled?.summary,
                onStage: onStage, onVideo: keep, onText: onText)
        }
        // Asked for now, while the person acts on screen: iOS lets the reply
        // be finished if the app leaves, and may announce it.
        background.begin(model: requestedModel)
        ReplyNotifications.shared.requestPermissionOnce()
        return true
    }

    /// A reply's searches: each query and the pages it found are kept with
    /// the reply as they come, and the status says what is being searched.
    private func searchTurn(threadID: UUID, messageID: UUID) -> WebSearchTurn {
        WebSearchTurn { [weak self] event in
            await self?.recordSearch(event, threadID: threadID, messageID: messageID)
        }
    }

    private func recordSearch(_ event: WebSearchEvent, threadID: UUID, messageID: UUID) {
        guard activeReply?.message == messageID, !isStopping,
              let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        var record = threads[ti].messages[mi].webSearch ?? WebSearchRecord()
        // What no page named shows with the queries; the wait is the same.
        if case .unconfirmed(let names) = event {
            record.unconfirmed = names.isEmpty ? nil : names
            threads[ti].messages[mi].webSearch = record
            return
        }
        // The query shows above the reply; the line under the Aurora Orb
        // says what the wait is for, and iOS's display a shorter line.
        let shortStage: String
        switch event {
        case .started(let query):
            record.add(query: query, sources: [], failure: nil)
            record.inProgress = query
            currentStage = "ウェブを検索しています…"
            shortStage = String(localized: "ウェブを検索しています")
        case .finished(let query, let sources, let failure):
            record.add(query: query, sources: sources, failure: failure)
            record.inProgress = nil
            currentStage = failure == nil ? "検索結果を読んでいます…" : "検索できませんでした。端末の中だけで答えています…"
            shortStage = failure == nil ? String(localized: "検索結果を読んでいます") : String(localized: "端末の中だけで答えています")
        case .unconfirmed:
            return
        }
        threads[ti].messages[mi].webSearch = record
        lastActivity = Date()
        stageStarted = Date()
        status = currentStage
        // A search is work too, though no text comes (BackgroundReply).
        background.progress(characters: replyCharacters, stage: shortStage)
    }

    /// `budget`: the room for the turns and this one together; by default
    /// all the settings allow.
    /// The pictures and recordings an attachment gives the model.
    private static func mediaCount(_ attachment: ChatAttachment, _ settings: GenerationSettings) -> Int {
        attachment.modelImageNames(settings).count + (attachment.kind == .audio ? 1 : 0)
    }

    private func replyHistory(_ messages: [ChatMessage], model: ModelSpec, settings: GenerationSettings,
                              cost: Int, images: Int, budget: Int? = nil) -> [ChatMessage] {
        let attachmentPolicy = ModelAttachmentPolicy(model: model)
        var history = HistoryBuilder.recentPairs(attachmentPolicy.inferenceHistory(messages),
            byteBudget: max(0, (budget ?? settings.inputByteBudget) - cost), visualTokenBudget: settings.visualTokenBudget,
            inputByteBudget: settings.inputByteBudget)
        // A recording counts as a photo does: LFM3-Omni 2B reads each again
        // with every question (1.1.0 (236)).
        while images + history.flatMap(\.media).reduce(0, { $0 + Self.mediaCount($1, settings) }) > 4, history.count >= 2 {
            history.removeFirst(2)
        }
        return history
    }

    /// `remote`: the reply comes from the PC (sendToPC) or Claude
    /// (sendToClaude); it has no ReplyGuard (that model is not the
    /// phone's), and its errors say what the PC or the relay said.
    private func startReply(threadID id: UUID, messageID: UUID, hasVision: Bool, backend: ExecutionBackend, remote: Bool = false,
                            _ work: @escaping (_ onStage: @escaping @Sendable (GemmaService.Stage) async -> Void,
                                               _ onText: @escaping @Sendable (String) async -> Void) async throws -> Void) {
        isGenerating = true
        isStopping = false
        let ticket = replyTicket.begin()
        activeReply = (id, messageID)
        activeBackend = backend
        replyCharacters = threads.first { $0.id == id }?.messages.first { $0.id == messageID }?.text.count ?? 0
        replyGuard = remote ? nil : ReplyGuard.of(replyModel((id, messageID)))
        generationStarted = nil
        replyAnswered = false
        lastActivity = Date()
        stageStarted = Date()
        currentStage = GemmaService.Stage.loading.rawValue
        status = currentStage
        persist()
        startWatchdog(ticket: ticket, threadID: id, messageID: messageID)
        generationTask = Task {
            var outcome: ReplyState = .complete
            do {
                try await work({ [weak self] stage in
                    await self?.setStage(stage, ticket: ticket)
                }, { [weak self] text in
                    await self?.append(text, ticket: ticket, threadID: id, messageID: messageID)
                })
            } catch {
                guard replyTicket.accepts(ticket) else { return }
                if error is CancellationError || isStopping {
                    outcome = .stopped
                } else {
                    outcome = .failed
                    self.error = remote ? error.localizedDescription : (hasVision
                        ? String(localized: "写真を読み取れませんでした。")
                        : String(localized: "返信できませんでした。新しいチャットか、軽いモデルでお試しください。")) + "\n" + error.localizedDescription
                }
            }
            guard replyTicket.accepts(ticket) else { return }
            flushBufferedReply()
            guard replyTicket.finish(ticket) else { return }
            watchdogTask?.cancel()
            watchdogTask = nil
            if let threadIndex = threads.firstIndex(where: { $0.id == id }),
               let messageIndex = threads[threadIndex].messages.firstIndex(where: { $0.id == messageID }) {
                if outcome == .complete && threads[threadIndex].messages[messageIndex].text.isEmpty {
                    outcome = .failed
                    error = String(localized: "返信が届きませんでした。新しいチャットでお試しください。")
                }
                threads[threadIndex].messages[messageIndex].state = outcome
                if outcome == .failed, let smart = threads[threadIndex].messages[messageIndex].smart { avoidAfterFailure(smart.modelID) }
            }
            isGenerating = false
            isStopping = false
            status = ""
            generationTask = nil
            activeReply = nil
            if pcReply?.message == messageID { pcReply = nil }
            if claudeReply == messageID { claudeReply = nil; claudeKept = false }
            persist()
            finishInBackground(threadID: id, messageID: messageID, outcome: outcome)
        }
    }

    private func setStage(_ stage: GemmaService.Stage, ticket: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        if generationStarted == nil, [.waiting, .continuing, .thinking].contains(stage) { generationStarted = Date() }
        // A reply that thinks shows nothing for a while but says so about once
        // a second: the watchdog waits on, the stage's seconds go on, and iOS
        // hears the reply is still moving (BackgroundReply).
        if stage == .thinking {
            lastActivity = Date()
            if currentStage == stage.rawValue {
                background.progress(characters: replyCharacters, stage: String(localized: "考えています"))
                return
            }
        }
        currentStage = stage.rawValue
        stageStarted = Date()
        // A new stage is progress too: the CPU taking over in the background
        // loads the model and reads the reply again before its next word.
        lastActivity = Date()
        status = currentStage
        switch stage {
        case .loading: background.progress(characters: replyCharacters, stage: String(localized: "読み込んでいます"))
        case .preparing: background.progress(characters: replyCharacters, stage: String(localized: "準備しています"))
        case .continuing: background.progress(characters: replyCharacters, stage: String(localized: "続きを準備しています"))
        case .thinking: background.progress(characters: replyCharacters, stage: String(localized: "考えています"))
        case .waiting: background.progress(characters: replyCharacters)
        case .listening: background.progress(characters: replyCharacters, stage: String(localized: "音声を書き起こしています"))
        case .watching: background.progress(characters: replyCharacters, stage: String(localized: "場面を見ています"))
        case .condensing: background.progress(characters: replyCharacters, stage: String(localized: "話をまとめています"))
        }
    }

    /// Keeps a video's analysis with the message it came in, after each
    /// step (GemmaService.analyze): a reply stopped part-way goes on from
    /// there, and the note under the video says how far it got. What was
    /// analyzed stays true after a stop, so it is kept then too.
    private func videoKeeper(threadID: UUID, messageID: UUID) -> @Sendable (UUID, VideoAnalysis) async -> Void {
        { [weak self] attachmentID, video in
            await self?.keepVideo(video, attachmentID: attachmentID, threadID: threadID, messageID: messageID)
        }
    }

    private func keepVideo(_ video: VideoAnalysis, attachmentID: UUID, threadID: UUID, messageID: UUID) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }),
              let ai = threads[ti].messages[mi].attachments?.firstIndex(where: { $0.id == attachmentID }) else { return }
        threads[ti].messages[mi].attachments?[ai].video = video
        threads[ti].messages[mi].attachments?[ai].note = VideoDigest.note(video, sent: true)
        // Each step is work too, though no text comes (BackgroundReply).
        lastActivity = Date()
        persist()
    }

    private func append(_ text: String, ticket: UUID, threadID: UUID, messageID: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        lastActivity = Date()
        if !text.isEmpty { replyAnswered = true }
        bufferedText += text
        bufferedTarget = (ticket, threadID, messageID)
        guard bufferTask == nil else { return }
        // Native token callbacks can arrive hundreds of times a second.
        // Batch them without re-laying out every row for each character.
        bufferTask = Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(45)) } catch { return }
            flushBufferedReply()
        }
    }
    private func flushBufferedReply() {
        bufferTask?.cancel(); bufferTask = nil
        let text = bufferedText, target = bufferedTarget
        bufferedText = ""; bufferedTarget = nil
        guard !text.isEmpty, let target, replyTicket.accepts(target.ticket) else { return }
        let threadID = target.thread, messageID = target.message
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].text += text
        replyCharacters = threads[ti].messages[mi].text.count
        background.progress(characters: replyCharacters)
        lastActivity = Date()
        stageStarted = Date()
        currentStage = "返信中…"
        status = "返信中…"
        if Date().timeIntervalSince(lastCheckpoint) > 2 {
            persist()
            lastCheckpoint = Date()
        }
    }

    func stop() {
        guard isGenerating, !isStopping else { return }
        flushBufferedReply()
        isStopping = true
        status = "停止しています…"
        // A reply on the PC: the PC is asked to stop, and the connection
        // closes, which stops it there too should the ask not arrive.
        if let pcReply {
            PCLinkStore.shared.cancel(requestID: pcReply.request)
            generationTask?.cancel()
            return
        }
        // A reply from Claude: its connection closes, and the relay stops
        // the request at Anthropic with it (1.1.0 (257)).
        if claudeReply != nil {
            generationTask?.cancel()
            return
        }
        Task { await gemma.cancel() }
    }

    /// Stops the reply as the stop button does, keeping what it wrote, and
    /// says why (ReplyGuard).
    private func stop(for reason: ReplyGuard.Stop) {
        switch reason {
        case .heat:
            error = String(localized: "端末が熱くなったため、返信を止めました。")
        case .noAnswer:
            error = String(localized: "5分たっても答えが始まらないため、止めました。E4BかE2Bをお試しください。")
        case .tooLong:
            error = String(localized: "返信が10分を超えたため、止めました。")
        }
        Task { await gemma.noteReplyGuard(reason) }
        stop()
    }

    private func startWatchdog(ticket: UUID, threadID: UUID, messageID: UUID) {
        watchdogTask?.cancel()
        watchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(5)) } catch { return }
                guard let self, self.replyTicket.accepts(ticket) else { return }
                if !self.isStopping, self.handoff == nil, let limits = self.replyGuard,
                   let reason = limits.stop(thermal: ProcessInfo.processInfo.thermalState,
                                            generating: self.generationStarted.map { Date().timeIntervalSince($0) },
                                            answered: self.replyAnswered) {
                    self.stop(for: reason)
                    continue
                }
                // A reply kept at the relay waits while the app is away: its
                // connection comes again when the app is back (1.1.0 (260)).
                if self.claudeKept, self.claudeReply == messageID, UIApplication.shared.applicationState != .active {
                    self.lastActivity = Date()
                    continue
                }
                if Date().timeIntervalSince(self.lastActivity) >= 120 {
                    guard self.replyTicket.finish(ticket) else { return }
                    if let ti = self.threads.firstIndex(where: { $0.id == threadID }),
                       let mi = self.threads[ti].messages.firstIndex(where: { $0.id == messageID }) {
                        self.threads[ti].messages[mi].state = self.isStopping ? .stopped : .failed
                    }
                    self.error = String(localized: "返信が届かないため、止めました。もう一度送信してください。")
                    self.isGenerating = false
                    self.isStopping = false
                    self.status = ""
                    self.activeReply = nil
                    // Keep the native request alive until it really finishes.
                    // Late callbacks are discarded by the ticket above.
                    self.persist()
                    if let pcReply = self.pcReply, pcReply.message == messageID {
                        self.pcReply = nil
                        PCLinkStore.shared.cancel(requestID: pcReply.request)
                        self.generationTask?.cancel()
                        return
                    }
                    if self.claudeReply == messageID {
                        self.claudeReply = nil
                        self.claudeKept = false
                        self.generationTask?.cancel()
                        return
                    }
                    await self.gemma.cancel()
                    return
                }
                if !self.isStopping, Date().timeIntervalSince(self.stageStarted) >= 15 {
                    self.status = "\(self.currentStage) \(Int(Date().timeIntervalSince(self.stageStarted)))秒"
                }
            }
        }
    }

    /// A reply being written goes on while the app is away. iPhone apps
    /// can't use the GPU in the background, so a reply on the GPU stops and
    /// goes on from its last character on the CPU; one on the CPU goes on as
    /// it is. When it ends (`finishInBackground`) a notification says so and
    /// the model is unloaded. Without a reply, the model is unloaded now.
    func didEnterBackground() {
        persist()
        // Between two backends: where it goes on is decided when the stop ends.
        if handoff != nil {
            leftScreen = true
            background.holdBackgroundTime()
            return
        }
        guard isGenerating, !isStopping, let reply = activeReply else {
            let backgroundID = UIApplication.shared.beginBackgroundTask(withName: "ReleaseGemma", expirationHandler: nil)
            let task = generationTask
            Task {
                await task?.value
                if !isGenerating { await gemma.unload() }
                if backgroundID != .invalid { UIApplication.shared.endBackgroundTask(backgroundID) }
            }
            return
        }
        leftScreen = true
        background.holdBackgroundTime()
        guard activeBackend == .gpu else { return }
        // A model without the CPU (12B) stops here and waits for the app,
        // as when the background time runs out; it goes on on the GPU.
        guard replyModel(reply).supportsCPU else {
            pauseInBackground()
            return
        }
        movedToCPU = true
        background.progress(characters: replyCharacters, stage: String(localized: "バックグラウンドで続けます"))
        move(reply)
    }

    /// The model a reply is written with, as `resume` picks it.
    private func replyModel(_ reply: (thread: UUID, message: UUID)) -> ModelSpec {
        watchReplies.contains(reply.message) ? .e2b : ModelSpec.find(threads.first { $0.id == reply.thread }?.modelID) ?? .e4b
    }

    /// Back on screen while the CPU stands in for the GPU: on the phone the
    /// CPU writes about a tenth as fast (E4B, 1.1.0 (134): 8 characters a
    /// second against 75 to 100), so the reply goes back to the GPU and on
    /// from its last character there.
    private func returnToGPU() -> Bool {
        guard movedToCPU, activeBackend == .cpu, handoff == nil, isGenerating, !isStopping,
              let reply = activeReply else { return false }
        movedBackToGPU = true
        move(reply)
        return true
    }

    /// Stops the reply and lets it go on from its last character where it
    /// can run once the stop ends: on the CPU while the app is away, on its
    /// own backend when the app is on screen.
    private func move(_ reply: (thread: UUID, message: UUID)) {
        handoff = reply
        stop()
        let stopping = generationTask
        Task {
            await stopping?.value
            guard let target = handoff, target.message == reply.message else { return }
            handoff = nil
            let state = threads.first { $0.id == target.thread }?.messages.first { $0.id == target.message }?.state
            guard state == .stopped else {
                // It ended before it could be stopped.
                finishInBackground(threadID: target.thread, messageID: target.message, outcome: state ?? .failed)
                return
            }
            let away = UIApplication.shared.applicationState != .active
            if away { movedToCPU = true }
            guard resume(target, onCPU: away) else {
                // It can't go on now (its model is gone, say): it waits for the app.
                interruptedReply = target
                pausedInBackground = target.message
                finishInBackground(threadID: target.thread, messageID: target.message, outcome: .stopped)
                return
            }
        }
    }

    /// The background time ran out, or iOS ended the reply's task (from its
    /// display, or for the resources): the reply stops where it is, a
    /// notification says so, and it goes on when the app is opened.
    private func pauseInBackground() {
        // iOS may end the task with the app back on screen; the reply goes on.
        guard UIApplication.shared.applicationState != .active else { return }
        let target = activeReply ?? handoff
        handoff = nil
        guard let target else { return }
        // A reply Claude writes at the relay goes on there while iOS holds
        // the app, and is read again when the app is back (1.1.0 (260)).
        if claudeKept && claudeReply == target.message { return }
        // A reply on the PC has no way to go on later (resume is the
        // phone's model): it stops with what it wrote.
        if pcReply?.message == target.message || claudeReply == target.message {
            stop()
            return
        }
        interruptedReply = target
        pausedInBackground = target.message
        if isGenerating {
            stop()
        } else {
            // Between the GPU's stop and the CPU's start.
            finishInBackground(threadID: target.thread, messageID: target.message, outcome: .stopped)
        }
    }

    /// After a reply ends, unless it stopped only to go on on the CPU: its
    /// background time ends, and while the app is away a notification says
    /// how it ended and the model is unloaded.
    private func finishInBackground(threadID: UUID, messageID: UUID, outcome: ReplyState) {
        guard handoff?.message != messageID else { return }
        background.end(success: outcome == .complete)
        let paused = pausedInBackground == messageID
        pausedInBackground = nil
        let note = leftScreen ? "アプリが裏に回った"
            + (movedToCPU ? " · CPUで続けた" : activeBackend == .gpu ? " · GPU専用のモデルなので止めて待った" : " · CPUのまま続けた")
            + (movedBackToGPU ? " · 戻ってGPUで続けた" : "")
            + " · \(background.state) · 結果: \(paused ? "時間切れで止めた" : outcome.rawValue)" : nil
        leftScreen = false
        movedToCPU = false
        movedBackToGPU = false
        // The Apple Watch app shows its own answer while it is open.
        if UIApplication.shared.applicationState != .active, !WatchBridge.shared.showsAnswer(in: threadID) {
            let thread = threads.first { $0.id == threadID }
            let text = thread?.messages.first { $0.id == messageID }?.text ?? ""
            switch outcome {
            case .complete:
                ReplyNotifications.shared.post(title: ReplyNotice.finishedTitle,
                                               body: ReplyNotice.preview(of: text), threadID: threadID)
            case .failed:
                ReplyNotifications.shared.post(title: ReplyNotice.failedTitle,
                                               body: ReplyNotice.failedBody, threadID: threadID)
            case .stopped where paused:
                ReplyNotifications.shared.post(title: ReplyNotice.pausedTitle,
                                               body: ReplyNotice.pausedBody, threadID: threadID)
            default:
                break
            }
        }
        let away = UIApplication.shared.applicationState == .background
        let forWatch = watchReplies.contains(messageID)
        Task {
            if let note { await gemma.noteBackground(note) }
            // Away from the screen the model's memory goes back to iOS, but
            // not after an answer for the Apple Watch (2026-10-24): its rest
            // (continueForWatch) or the watch's next question comes soon and
            // starts without loading the model again. iOS may still end the
            // app for the memory; it is then loaded as before.
            if away && !isGenerating && !forWatch { await gemma.unload() }
            // A reply begun meanwhile (the watch's) keeps the time it holds.
            if !isGenerating { background.releaseBackgroundTime() }
        }
    }

    /// Carries on a reply that leaving the app stopped. The model gets its
    /// own unfinished turn back and goes on from the text it reached.
    /// When the app is back on screen, a reply the CPU stood in for goes
    /// back to the GPU.
    func resumeInterruptedReply() {
        // A reply kept at the relay: the time away was no silence of its own.
        if claudeKept, claudeReply != nil { lastActivity = Date() }
        if returnToGPU() { return }
        guard handoff == nil, let target = interruptedReply else { return }
        interruptedReply = nil
        let stopping = generationTask
        Task {
            await stopping?.value
            resume(target)
        }
    }

    /// `onCPU` while the app is away: the GPU can't run in the background.
    @discardableResult
    private func resume(_ target: (thread: UUID, message: UUID), onCPU: Bool = false) -> Bool {
        guard !isGenerating, let ti = threads.firstIndex(where: { $0.id == target.thread }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == target.message }), mi > 0,
              threads[ti].messages[mi].state == .stopped, threads[ti].messages[mi - 1].role == .user else { return false }
        let question = threads[ti].messages[mi - 1]
        let forWatch = watchReplies.contains(target.message)
        let model = forWatch ? ModelSpec.e2b : ModelSpec.find(threads[ti].modelID) ?? .e4b
        guard ModelStore.shared.isInstalled(model), !onCPU || model.supportsCPU else { return false }
        // A Smart Mode reply goes on as it began (SmartReply.tuning).
        let smart = forWatch ? nil : threads[ti].messages[mi].smart
        var settings = smart.map { savedSettings(for: model).tuned($0.tuning, for: model) } ?? savedSettings(for: model)
        if onCPU { settings.backend = .cpu }
        var note = onCPU ? "アプリが裏に回ったのでCPUで続きを書く" : nil
        let partial = threads[ti].messages[mi].text
        threads[ti].messages[mi].state = .generating
        if partial.isEmpty {
            // Nothing had arrived yet, so ask the question again.
            let cost = question.text.utf8.count + question.media.reduce(0) { $0 + $1.contextByteCost(settings) }
            let images = question.media.reduce(0) { $0 + Self.mediaCount($1, settings) }
            // On the CPU in the background, the latest turns only (BackgroundRead).
            let earlier = Array(threads[ti].messages[..<(mi - 1)])
            let history = replyHistory(forWatch ? earlier.map(WatchAsk.textOnly) : earlier, model: model, settings: settings,
                                       cost: cost, images: images,
                                       budget: onCPU ? min(settings.inputByteBudget, cost + BackgroundRead.historyBudget(settings)) : nil)
            note = note.map { $0 + " · 前のやりとり\(history.count / 2)組を読む" }
            let hasVision = (question.media + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
            // The watch's questions don't search (askFromWatch).
            let searches = !forWatch && WebSearchPolicy.searches(enabled: smart?.searched ?? (threads[ti].webSearch == true),
                                                    keyed: WebSearchKeyState.shared.isReady,
                                                    model: model, messages: Array(threads[ti].messages[..<(mi - 1)]),
                                                    attachments: question.media, asked: question.text)
            let search = searches ? searchTurn(threadID: target.thread, messageID: target.message) : nil
            let backend = InferenceEnginePlan(model: model, settings: settings, needsVision: hasVision).backend
            let keep = videoKeeper(threadID: target.thread, messageID: question.id)
            // Asked again, the question is searched for again (Smart Memory);
            // not for the watch, whose questions are asked without it.
            let memoryAsk = SmartMemory.isOn && !forWatch
                ? SmartMemoryStore.Ask(question: question.text, threads: threads, history: history, cost: cost,
                                       inputByteBudget: onCPU ? min(settings.inputByteBudget, cost + BackgroundRead.historyBudget(settings))
                                           : settings.inputByteBudget,
                                       visualTokenBudget: settings.visualTokenBudget)
                : nil
            startReply(threadID: target.thread, messageID: target.message, hasVision: hasVision, backend: backend) { [gemma = self.gemma, note, weak self] onStage, onText in
                let recalled = await self?.recallMemory(memoryAsk, threadID: target.thread, messageID: target.message)
                try await gemma.generate(threadID: target.thread, prompt: question.text, history: recalled?.history ?? history,
                    model: model, settings: settings, attachments: question.media, webSearch: search, background: note,
                    readsLess: onCPU, memory: recalled?.note, memorySummary: recalled?.summary,
                    onStage: onStage, onVideo: keep, onText: onText)
            }
        } else {
            let backend = InferenceEnginePlan(model: model, settings: settings, needsVision: false).backend
            note = note.map { $0 + " · 回答の終わり\(min(partial.utf8.count, BackgroundRead.tailBytes))バイトを読み直す" }
            startReply(threadID: target.thread, messageID: target.message, hasVision: false, backend: backend) { [gemma = self.gemma, note] onStage, onText in
                try await gemma.continueReply(threadID: target.thread, prompt: question.text, reply: partial,
                    model: model, settings: settings, background: note, readsLess: onCPU,
                    onStage: onStage, onText: onText)
            }
        }
        // A reply going on with the app on screen may leave again.
        if !onCPU { background.begin(model: model) }
        return true
    }

    // MARK: PCと接続 (1.1.0 (253))

    /// The current chat's model on the PC, when its replies come from there.
    var currentPC: PCChatTarget? { current?.pc }

    /// A new chat answered by a model on the registered PC (the model menu's
    /// PC models, 設定 › PCと接続's list). Kept as a chosen model is: Smart
    /// Mode leaves it. An empty chat with the same model is reused.
    func newPCChat(_ target: PCChatTarget) {
        guard !isGenerating, handoff == nil else { return }
        if let empty = threads.firstIndex(where: { $0.messages.isEmpty && $0.pc == target }) {
            selectedID = threads[empty].id
        } else {
            var thread = ChatThread(modelID: ModelStore.shared.selectedModel.id)
            thread.modelPinned = true
            thread.pc = target
            threads.insert(thread, at: 0)
            selectedID = thread.id
        }
        persist()
    }

    /// The question goes to the chat's model on the PC with the earlier
    /// text exchanges that fit (PCContext), and the reply streams back as a
    /// phone model's does: saved as it comes, kept if the PC goes away.
    /// Text only: photos, files and recordings stay on the phone's models.
    /// No Smart Memory, web search or system prompt: the PC gets the
    /// conversation alone.
    private func sendToPC(_ prompt: String, target: PCChatTarget, threadIndex index: Int, messageID: UUID,
                          attachments: [ChatAttachment]) -> Bool {
        guard attachments.isEmpty else {
            error = String(localized: "PCのモデルには文字だけを送れます。写真・ファイル・音声は、iPhoneのモデルでお試しください。")
            return false
        }
        guard PCLinkStore.shared.paired?.pcID == target.pcID else {
            error = PCLinkError.notPaired.localizedDescription
            return false
        }
        let id = threads[index].id
        let turns = PCContext.turns(history: threads[index].messages, question: prompt)
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[index].messages.append(ChatMessage(id: messageID, role: .user, text: prompt))
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        let requestID = UUID().uuidString.lowercased()
        pcReply = (assistant.id, requestID)
        // The CPU's backend: nothing moves off the GPU when the app leaves,
        // and the reply goes on while iOS gives the app the time.
        startReply(threadID: id, messageID: assistant.id, hasVision: false, backend: .cpu, remote: true) { onStage, onText in
            try await PCLinkStore.shared.reply(target: target, turns: turns, requestID: requestID, onProgress: { progress in
                switch progress {
                case .starting: await onStage(.preparing)
                case .loading: await onStage(.loading)
                case .thinking: await onStage(.thinking)
                // Nothing to show, but the PC is still at it: the watchdog
                // and iOS's display hear so.
                case .alive: await onText("")
                }
            }, onText: onText)
        }
        background.begin(name: "\(target.pcName) · \(target.shortModel)")
        ReplyNotifications.shared.requestPermissionOnce()
        return true
    }

    // MARK: Claude (1.1.0 (257))

    /// The current chat's Claude, when its replies come from there.
    var currentClaude: ClaudeChatTarget? { current?.claude }
    /// Answered off the iPhone (the PC or Claude): text alone.
    var isRemoteChat: Bool { current?.isRemote == true }

    /// A new chat answered by Claude (the model menu's Claude models, 設定
    /// › Claude): `model`, or the one chosen last, at the level last chosen
    /// for it. Kept as a chosen model is: Smart Mode leaves it. An empty
    /// Claude chat is reused.
    func newClaudeChat(_ model: ClaudeModel? = nil) {
        guard !isGenerating, handoff == nil else { return }
        let link = ClaudeLinkStore.shared
        let target = link.target(for: model)
        link.remember(target)
        if let empty = threads.firstIndex(where: { $0.messages.isEmpty && $0.claude != nil }) {
            threads[empty].claude = target
            selectedID = threads[empty].id
        } else {
            var thread = ChatThread(modelID: ModelStore.shared.selectedModel.id)
            thread.modelPinned = true
            thread.claude = target
            // ウェブ検索 and ファイル作成 as the last Claude chat left them (1.1.0 (260)).
            link.applyLastTools(to: &thread)
            threads.insert(thread, at: 0)
            selectedID = thread.id
        }
        persist()
    }

    /// The Claude chat's reasoning level (its model settings): from the
    /// next question on, and for the next chat with this model. A reply
    /// being written goes on as it began.
    func setClaudeEffort(_ effort: ClaudeEffort) {
        guard let index = threads.firstIndex(where: { $0.id == selectedID }), var target = threads[index].claude,
              target.effort != effort, ClaudeLinkStore.shared.model(target.model)?.efforts.contains(effort) == true else { return }
        target.effort = effort
        threads[index].claude = target
        ClaudeLinkStore.shared.remember(target)
        persist()
    }

    /// The question goes to Claude with the earlier exchanges that fit
    /// (ClaudeContext), with the photos and files attached to them as far
    /// as one request carries (ClaudeRequest, 1.1.0 (260)), and the reply
    /// streams back as a phone model's does: saved as it comes, kept if the
    /// connection goes. With the chat's ウェブ検索 and ファイル作成, Claude's
    /// own tools (1.1.0 (260)). No Smart Memory or system prompt of the
    /// person's: the relay gets this chat's turns alone.
    private func sendToClaude(_ prompt: String, threadIndex index: Int, messageID: UUID,
                              attachments: [ChatAttachment], hidesText: Bool) -> Bool {
        guard attachments.allSatisfy(ClaudeContext.sends) else {
            error = ClaudeLinkError.attachmentKind.localizedDescription
            return false
        }
        guard ClaudeLinkStore.shared.isRegistered else {
            error = ClaudeLinkError.notRegistered.localizedDescription
            return false
        }
        // The chat's model and level as they are now, for this reply.
        guard let target = threads[index].claude, ClaudeLinkStore.shared.supports(target) else {
            error = ClaudeLinkError.unsupportedChoice.localizedDescription
            return false
        }
        let id = threads[index].id
        let turns = ClaudeContext.turns(history: threads[index].messages, question: prompt, attachments: attachments)
        let tools = threads[index].claudeTools
        let bytes = ClaudeLinkStore.shared.attachmentBytes
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        var asked = ChatMessage(id: messageID, role: .user, text: prompt, attachments: attachments)
        if hidesText { asked.hidesText = true }
        threads[index].messages.append(asked)
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        claudeReply = assistant.id
        claudeKept = ClaudeLinkStore.shared.resumable
        // The CPU's backend: nothing moves off the GPU when the app leaves,
        // and the reply goes on while iOS gives the app the time.
        startReply(threadID: id, messageID: assistant.id, hasVision: false, backend: .cpu, remote: true) { [weak self] onStage, onText in
            await onStage(.preparing)
            // Photos are encoded off the main thread.
            let messages = try await Task.detached(priority: .userInitiated) {
                try ClaudeRequest.messages(turns, attachmentBytes: bytes)
            }.value
            let reader = try await ClaudeLinkStore.shared.reply(messages: messages.list, target: target, tools: tools, onProgress: { progress in
                switch progress {
                case .thinking: await onStage(.thinking)
                // Nothing to show, but the reply is still coming: the
                // watchdog and iOS's display hear so.
                case .alive: await onText("")
                case .working(let activity): await self?.claudeWorking(activity, messageID: assistant.id)
                case .reconnecting: await self?.claudeWorking(.reconnecting, messageID: assistant.id)
                }
            }, onText: onText, onUpdate: { reader in
                await self?.applyClaude(reader, threadID: id, messageID: assistant.id, generating: true)
            })
            await self?.applyClaude(reader, threadID: id, messageID: assistant.id, generating: false)
            if !reader.files.isEmpty { await self?.loadClaudeFiles(reader.files, threadID: id, messageID: assistant.id) }
        }
        background.begin(name: target.modelName)
        ReplyNotifications.shared.requestPermissionOnce()
        return true
    }

    /// What Claude does now (a search, code), under the Aurora Orb and in
    /// iOS's display: work too, though no text comes.
    private func claudeWorking(_ activity: ClaudeActivity, messageID: UUID) {
        guard activeReply?.message == messageID, !isStopping else { return }
        currentStage = activity.line
        lastActivity = Date()
        stageStarted = Date()
        status = currentStage
        background.progress(characters: replyCharacters, stage: activity.short)
    }

    /// The reply's searches, files, container and end, as they come.
    private func applyClaude(_ reader: ClaudeReplyReader, threadID: UUID, messageID: UUID, generating: Bool) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].apply(reader, generating: generating)
        threads[ti].keepContainer(reader.container)
    }

    /// The made files' names and sizes, a moment after the reply (the
    /// relay learns of them as it ends); the reply is done meanwhile.
    private func loadClaudeFiles(_ ids: [String], threadID: UUID, messageID: UUID) {
        Task { [weak self] in
            let details = await ClaudeLinkStore.shared.fileDetails(ids, madeAt: Date())
            guard let self, let ti = self.threads.firstIndex(where: { $0.id == threadID }),
                  let mi = self.threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
            self.threads[ti].messages[mi].keepDetails(details)
            self.persist()
        }
    }

    // MARK: Smart Mode

    /// Models whose Smart Mode reply failed on this launch: tried last for
    /// the rest of it (SmartPlanner.Context.avoided), as a failed load can
    /// keep its address space until the app quits.
    private var smartAvoided: Set<String> = []
    /// Whether E4B is tight for this phone's memory, so E2B comes first:
    /// against its memory, not what is free now, which a loaded model lowers.
    private static let prefersSmall: Bool = {
        let device = DeviceOverview.memoryCapacity
        let capacity = DeviceCapacity(memoryBytes: device.memoryBytes, freeDiskBytes: 0,
                                      processorCount: device.processorCount, isPad: device.isPad)
        return ModelRecommendation.fit(.e4b, device: capacity, isInstalled: true).memoryIsTight
    }()

    /// Whether a chat chooses its model and settings for each question:
    /// Smart Mode on (モデル管理), and a model the person didn't choose.
    func isSmartChat(_ thread: ChatThread) -> Bool { SmartMode.isOn && thread.modelPinned != true && !thread.isRemote }
    var isSmart: Bool { current.map(isSmartChat) ?? SmartMode.isOn }

    /// The current chat's 質問のジャンル: 自動 for a new chat and for older ones.
    var genre: SmartGenre { current?.genre ?? .auto }
    /// From the next question on: a reply being written goes on as it
    /// began (its search and settings were taken when it was sent).
    func setGenre(_ genre: SmartGenre) {
        guard let index = threads.firstIndex(where: { $0.id == selectedID }), threads[index].genre != genre else { return }
        threads[index].genre = genre
        persist()
    }

    /// Lets Smart Mode choose the current chat's model again (the model
    /// menu's 「質問に合わせて自動で選ぶ」), from its next question.
    func unpinModel() {
        guard let index = threads.firstIndex(where: { $0.id == selectedID }), threads[index].modelPinned == true else { return }
        threads[index].modelPinned = nil
        // Smart Mode chooses among the phone's models.
        threads[index].pc = nil
        threads[index].claude = nil
        persist()
    }

    /// The model whose attachments the composer offers: in a Smart Mode
    /// chat the one its photos and files will go to.
    var attachmentModel: ModelSpec {
        // Claude takes photos and files as Gemma 4 E2B offers them (1.1.0 (260)).
        if current?.claude != nil { return .e2b }
        guard isSmart else { return currentModel }
        return SmartPlanner.attachmentModel(context: smartContext(current: currentModel))
    }

    /// Whether the current chat can be answered: its model is saved, or, in
    /// Smart Mode, a model it may choose.
    var canAnswer: Bool {
        // A PC chat says on sending why the PC can't answer, if it can't.
        if current?.isRemote == true { return true }
        if ModelStore.shared.isInstalled(currentModel) { return true }
        guard isSmart else { return false }
        return SmartPlanner.restingModel(preferred: currentModel, context: smartContext(current: currentModel)) != nil
    }

    /// What Smart Mode chose for the current chat's last reply.
    var lastSmartReply: SmartReply? { messages.last { $0.role == .assistant }?.smart }

    private func savedSettings(for model: ModelSpec) -> GenerationSettings {
        (configurations[model.id] ?? GenerationSettings(for: model)).normalized(for: model)
    }

    /// `sending`: for a question being sent, with the Tavily connection
    /// and whether the chat may search; otherwise for what the chat rests
    /// on and offers, which needs neither.
    private func smartContext(current: ModelSpec, sending: Bool = false, searchBlocked: Bool = false) -> SmartPlanner.Context {
        let store = ModelStore.shared
        return SmartPlanner.Context(current: current,
                                    installed: Set(ModelSpec.catalog.filter { store.isInstalled($0) }.map(\.id)),
                                    developer: UserDefaults.standard.bool(forKey: DeveloperUnlock.developerSettingsKey),
                                    prefersSmall: Self.prefersSmall, avoided: smartAvoided,
                                    searchReady: sending && WebSearchKeyState.shared.isReady, searchBlocked: searchBlocked)
    }

    private func planReply(for thread: ChatThread, prompt: String,
                           attachments: [ChatAttachment]) -> Result<SmartPlanner.Plan, SmartPlanner.Unavailable> {
        let context = smartContext(current: ModelSpec.find(thread.modelID) ?? .e4b, sending: true,
                                   searchBlocked: WebSearchPolicy.blockedByFiles(thread.messages, adding: attachments))
        let earlierDetail = thread.messages.last { $0.role == .assistant && $0.smart != nil }?.smart?.tuning.photoDetail
        let request = SmartPlanner.Request(genre: thread.genre, prompt: prompt, attachments: attachments.map(\.kind),
                                           earlier: thread.attachmentKinds, earlierDetail: earlierDetail)
        return SmartPlanner.plan(request, in: context)
    }

    /// A Smart Mode reply failed (not stopped): its model is tried last for
    /// the rest of the launch, and the error says the next question will
    /// go to another model where one is saved.
    private func avoidAfterFailure(_ modelID: String) {
        smartAvoided.insert(modelID)
        let store = ModelStore.shared
        let other = SmartPlanner.starters.contains { $0 != modelID && ModelSpec.find($0).map(store.isInstalled) == true }
        if other, let error {
            self.error = error + "\n" + String(localized: "次の質問は、ほかのモデルで答えます。")
        }
    }

    // MARK: Apple Watch

    enum WatchAsk {
        case started(thread: UUID, message: UUID)
        case refused(String)

        /// A turn as the watch's question reads it: its text, without the
        /// photos and files, which a reply for the watch doesn't load (the
        /// saved chat keeps them). As ModelAttachmentPolicy says it.
        static func textOnly(_ message: ChatMessage) -> ChatMessage {
            guard !message.media.isEmpty else { return message }
            var copy = message
            copy.attachments = nil
            if message.role == .user { copy.text += ModelAttachmentPolicy.earlierAttachmentsNote }
            return copy
        }
    }

    /// A question from the Apple Watch app (WatchBridge), answered by Gemma
    /// 4 E2B whatever the chats use, in the chat the watch shows: any chat
    /// of the history, whatever its model (`threadID`), or a new E2B chat
    /// (`newThreadID`, the id the watch gave it). The chat keeps its model
    /// and settings: only the question and E2B's answer are added, and its
    /// photos and files are not read (WatchAsk.textOnly). `messageID` is the
    /// watch's question's id. The chat is opened, so with Fielua on screen
    /// the answer is seen being written, as fast as a sent message's. Away
    /// from the screen (iOS woke the app for the watch) it is written on the
    /// CPU, reading less, as a reply that leaves goes on: iPhone apps can't
    /// use the GPU in the background. iOS gives the continued task only to
    /// an app on screen, so it is asked for anyway and otherwise the usual
    /// background time, about 30 seconds, is all there is; the reply then
    /// waits for the app to open.
    func askFromWatch(_ question: String, threadID: UUID?, newThreadID: UUID? = nil,
                      messageID: UUID = UUID()) -> WatchAsk {
        let prompt = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty else { return .refused(String(localized: "質問が空でした")) }
        guard prompt.utf8.count <= 4500 else { return .refused(String(localized: "質問が長すぎます。短くしてください")) }
        guard !isGenerating, handoff == nil else { return .refused(String(localized: "iPhoneで別の返信を書いています")) }
        let model = ModelSpec.e2b
        guard ModelStore.shared.isInstalled(model) else { return .refused(String(localized: "iPhoneのFieluaにGemma 4 E2Bが入っていません")) }
        let index: Int
        if let threadID, let found = threads.firstIndex(where: { $0.id == threadID }) {
            index = found
        } else {
            // A chat id is never used twice (the watch's are random).
            let id = newThreadID.flatMap { new in threads.contains { $0.id == new } ? nil : new } ?? UUID()
            threads.insert(ChatThread(id: id, modelID: model.id), at: 0)
            index = 0
        }
        let id = threads[index].id
        selectedID = id
        // A reply that waited for the app to open stays where it stopped:
        // the watch asked something new (WatchSession marks it so).
        interruptedReply = nil
        let away = UIApplication.shared.applicationState != .active
        var settings = (configurations[model.id] ?? GenerationSettings(for: model)).normalized(for: model)
        if away { settings.backend = .cpu }
        let cost = prompt.utf8.count
        let history = replyHistory(threads[index].messages.map(WatchAsk.textOnly), model: model, settings: settings,
                                   cost: cost, images: 0,
                                   budget: away ? min(settings.inputByteBudget, cost + BackgroundRead.historyBudget(settings)) : nil)
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[index].messages.append(ChatMessage(id: messageID, role: .user, text: prompt))
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        watchReplies.insert(assistant.id)
        let note = away ? "Apple Watchの質問・アプリは裏・CPUで書く · 前のやりとり\(history.count / 2)組を読む" : nil
        let backend = InferenceEnginePlan(model: model, settings: settings, needsVision: false).backend
        startReply(threadID: id, messageID: assistant.id, hasVision: false, backend: backend) { [gemma = self.gemma] onStage, onText in
            try await gemma.generate(threadID: id, prompt: prompt, history: history, model: model, settings: settings,
                                     attachments: [], background: note, readsLess: away, onStage: onStage, onText: onText)
        }
        background.begin(model: model)
        if away {
            // As a reply that left the screen: the diagnostics say so, and
            // back on screen it goes on on the GPU (returnToGPU).
            leftScreen = true
            movedToCPU = true
            background.holdBackgroundTime()
        }
        ReplyNotifications.shared.requestPermissionOnce()
        return .started(thread: id, message: assistant.id)
    }

    /// The Apple Watch app asks for the rest of its answer, which paused
    /// when the background time ran out (WatchBridge, WatchCarryOn,
    /// 2026-10-24). iOS woke the app for the watch's message with another
    /// stretch of background time, and the answer goes on from its last
    /// character on the CPU, in the model kept loaded since
    /// (finishInBackground). Also after iOS ended the app meanwhile: the
    /// watch asks only for an answer it saw pause. False when it can't go
    /// on now: another reply is being written or waits for the app.
    func continueForWatch(thread: UUID, message: UUID) -> Bool {
        guard !isGenerating, handoff == nil else { return false }
        if let interruptedReply, interruptedReply.message != message { return false }
        let waiting = interruptedReply
        let away = UIApplication.shared.applicationState != .active
        interruptedReply = nil
        watchReplies.insert(message)
        guard resume((thread, message), onCPU: away) else {
            interruptedReply = waiting
            return false
        }
        if away {
            // As askFromWatch: the diagnostics say so, and back on screen
            // it goes on on the GPU (returnToGPU).
            background.begin(model: .e2b)
            leftScreen = true
            movedToCPU = true
            background.holdBackgroundTime()
        }
        return true
    }

    /// The watch's question `id` (its message's id), if the iPhone has it
    /// already: its chat and the reply after it. A question the watch sends
    /// again is not written twice.
    func watchQuestion(_ id: UUID) -> (thread: UUID, reply: UUID?)? {
        for thread in threads {
            guard let index = thread.messages.firstIndex(where: { $0.id == id }) else { continue }
            let next = thread.messages.index(after: index)
            let reply = next < thread.messages.endIndex && thread.messages[next].role == .assistant
                ? thread.messages[next].id : nil
            return (thread.id, reply)
        }
        return nil
    }

    /// The reply stopped only to go on: on the other backend, or when the
    /// app is opened after its background time ran out.
    func replyWillContinue(_ messageID: UUID) -> Bool {
        handoff?.message == messageID || interruptedReply?.message == messageID
    }

    /// Out of background time, waiting for the app (not stopped by anyone).
    func replyIsPaused(_ messageID: UUID) -> Bool {
        interruptedReply?.message == messageID
    }

    func releaseModelMemory() {
        guard !isGenerating else { return }
        Task { await gemma.unload() }
    }

    /// Returns once the weights are unmapped, so a model file can be removed.
    func unloadModel() async {
        guard !isGenerating else { return }
        await gemma.unload()
    }

    func runVisionProbe(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                        vision: ExecutionBackend, kernel: VisionCPUImplementation = .xnnpack,
                        visionTokens: Int = 280, contextTokens: Int = 4096) async throws -> String {
        guard !isGenerating else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = "" }
        status = "画像の最小再現テストを実行しています…"
        return try await gemma.runVisionProbe(model: model, kind: kind, main: main, vision: vision, kernel: kernel,
                                              visionTokens: visionTokens, contextTokens: contextTokens)
    }

    func runLargeModelProbe(backend: LargeModelProbe.Backend) async throws -> LargeModelProbe.Record {
        guard !isGenerating else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = "" }
        status = "12Bの動作を確認しています…"
        return try await gemma.runLargeModelProbe(backend: backend)
    }

    /// With the 12B's saved chat settings, so its chat prompts are the chat's.
    func runLargeModelChatCompare() async throws -> LargeModelChatCompare.Record {
        guard !isGenerating else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = "" }
        status = "12Bの設定を比べています…"
        let twelve = ModelSpec.gemma12B
        return try await gemma.runLargeModelChatCompare(settings: configurations[twelve.id] ?? GenerationSettings(for: twelve))
    }

    func runGPUStartTest(model: ModelSpec, precision: GPUPrecision) async throws -> String {
        guard !isGenerating, !gpuStartTestRan else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = ""; gpuStartTestRan = GPUStartTestRunner.startsThisLaunch > 0 }
        status = "GPU起動テストを実行しています…"
        return try await gemma.runGPUStartTest(model: model, precision: precision)
    }

    private func persist() {
        guard archiveWritable else { return }
        do { try archive.save(threads); CloudHistoryStore.shared.schedule(threads) }
        catch { self.error = String(localized: "会話履歴を保存できませんでした。") + "\n" + error.localizedDescription }
    }
    func mergeBackup(_ incoming: [ChatThread]) {
        guard !isGenerating, archiveWritable else { return }
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
        if selectedID == nil { selectedID = threads.first?.id }
        persist()
    }
}

