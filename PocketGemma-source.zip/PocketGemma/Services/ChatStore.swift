import Foundation
import Combine
import PocketCore
import UIKit

@MainActor
final class ChatStore: ObservableObject {
    @Published private(set) var threads: [ChatThread] = []
    @Published private(set) var selectedID: UUID?
    @Published private(set) var isGenerating = false
    @Published private(set) var isStopping = false
    @Published private(set) var status = ""
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    private let archive = ChatArchive(fileURL: AppFiles.archive)
    private let gemma = GemmaService()
    private var generationTask: Task<Void, Never>?
    private var watchdogTask: Task<Void, Never>?
    private var replyTicket = ReplyTicket()
    private var lastActivity = Date()
    private var stageStarted = Date()
    private var currentStage = GemmaService.Stage.loading.rawValue
    private var archiveWritable = true
    private var lastCheckpoint = Date.distantPast
    private var bufferedText = ""
    private var bufferTask: Task<Void, Never>?
    private var bufferedTarget: (ticket: UUID, thread: UUID, message: UUID)?
    private var activeReply: (thread: UUID, message: UUID)?
    private var interruptedReply: (thread: UUID, message: UUID)?

    init() {
        do {
            threads = try archive.load().sorted { $0.updatedAt > $1.updatedAt }
            selectedID = threads.first?.id
        } catch {
            // Preserve a corrupted archive for recovery, rather than overwrite it.
            archiveWritable = false
            self.error = "会話履歴を開けませんでした。元のファイルを保護するため、この起動中は履歴保存を停止しています。\n\(error.localizedDescription)"
        }
        if selectedID == nil { newChat() }
    }

    var current: ChatThread? { threads.first { $0.id == selectedID } }
    var messages: [ChatMessage] { current?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(current?.modelID) ?? .e4b }
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings(for: currentModel)).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        guard !isGenerating else { return }
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }

    func newChat(modelID: String? = nil) {
        guard !isGenerating else { return }
        let modelID = modelID ?? ModelStore.shared.selectedModel.id
        if let empty = threads.first(where: { $0.messages.isEmpty && $0.modelID == modelID }) {
            selectedID = empty.id
        } else {
            let thread = ChatThread(modelID: modelID)
            threads.insert(thread, at: 0)
            selectedID = thread.id
        }
        persist()
    }

    func select(_ id: UUID) {
        guard !isGenerating else { return }
        selectedID = id
    }

    func delete(_ id: UUID) {
        guard !isGenerating else { return }
        threads.removeAll { $0.id == id }
        if selectedID == id {
            selectedID = threads.first?.id
            if selectedID == nil { newChat() }
        }
        persist()
    }

    @discardableResult
    func send(_ raw: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let prompt = trimmed.isEmpty && !attachments.isEmpty ? "添付した内容を説明してください。" : trimmed
        guard !prompt.isEmpty, !isGenerating else { return false }
        guard prompt.utf8.count <= 4500 else {
            error = "最初の版では、1回のメッセージは約1,500文字までです。長い文章は分けて送ってください。"
            return false
        }
        let requestedModel = currentModel
        let attachmentPolicy = ModelAttachmentPolicy(model: requestedModel)
        do { try attachmentPolicy.validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        let settings = currentSettings
        let visualCount = attachments.reduce(0) { $0 + $1.imageNames.count }
        guard visualCount == 0 || requestedModel.supportsVision else {
            error = "写真にはGemma 4 E2Bを選んでください。"; return false
        }
        // A chart request also carries the chart format's note (GemmaService).
        let guideCost = RichFormatGuide.guide(for: prompt)?.utf8.count ?? 0
        let inputBudget = settings.inputByteBudget
        // Long files: what fits this turn, around the question.
        let prepared = AttachmentStorage.excerpted(attachments, question: prompt, settings: settings)
        let currentCost = prompt.utf8.count + guideCost
            + prepared.reduce(0) { $0 + $1.contextByteCost(visualTokenBudget: settings.visualTokenBudget) }
        guard visualCount <= 4, currentCost <= inputBudget else {
            error = "添付内容がモデルの入力上限を超えています。添付を減らすか、構成のMax Tokensを増やしてください。"; return false
        }
        guard ModelStore.shared.isInstalled(requestedModel) else {
            error = "モデル画面から\(requestedModel.name)をダウンロードしてください。"
            return false
        }
        guard let id = selectedID, let index = threads.firstIndex(where: { $0.id == id }) else { return false }
        let history = replyHistory(threads[index].messages, model: requestedModel, settings: settings,
                                   cost: currentCost, images: visualCount)
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[index].messages.append(ChatMessage(id: messageID, role: .user, text: prompt, attachments: prepared))
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        let hasVision = (prepared + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
        startReply(threadID: id, messageID: assistant.id, hasVision: hasVision) { [gemma = self.gemma] onStage, onText in
            try await gemma.generate(threadID: id, prompt: prompt, history: history,
                model: requestedModel, settings: settings, attachments: prepared, onStage: onStage, onText: onText)
        }
        return true
    }

    private func replyHistory(_ messages: [ChatMessage], model: ModelSpec, settings: GenerationSettings,
                              cost: Int, images: Int) -> [ChatMessage] {
        let attachmentPolicy = ModelAttachmentPolicy(model: model)
        var history = HistoryBuilder.recentPairs(attachmentPolicy.inferenceHistory(messages),
            byteBudget: max(0, settings.inputByteBudget - cost), visualTokenBudget: settings.visualTokenBudget)
        while images + history.flatMap(\.media).reduce(0, { $0 + $1.imageNames.count }) > 4, history.count >= 2 {
            history.removeFirst(2)
        }
        return history
    }

    private func startReply(threadID id: UUID, messageID: UUID, hasVision: Bool,
                            _ work: @escaping (_ onStage: @escaping @Sendable (GemmaService.Stage) async -> Void,
                                               _ onText: @escaping @Sendable (String) async -> Void) async throws -> Void) {
        isGenerating = true
        isStopping = false
        let ticket = replyTicket.begin()
        activeReply = (id, messageID)
        lastActivity = Date()
        stageStarted = Date()
        currentStage = GemmaService.Stage.loading.rawValue
        status = currentStage
        persist()
        startWatchdog(ticket: ticket, threadID: id, messageID: messageID)
        generationTask = Task {
            var outcome: ReplyState = .complete
            do {
                try await work({ [weak self] stage in
                    await self?.setStage(stage, ticket: ticket)
                }, { [weak self] text in
                    await self?.append(text, ticket: ticket, threadID: id, messageID: messageID)
                })
            } catch {
                guard replyTicket.accepts(ticket) else { return }
                if error is CancellationError || isStopping {
                    outcome = .stopped
                } else {
                    outcome = .failed
                    self.error = (hasVision
                        ? "画像推論に失敗しました。モデルと設定の「推論の診断」で、実行段階と詳細を確認できます。\n"
                        : "回答を生成できませんでした。新しい会話か、軽いモデルでお試しください。\n") + error.localizedDescription
                }
            }
            guard replyTicket.accepts(ticket) else { return }
            flushBufferedReply()
            guard replyTicket.finish(ticket) else { return }
            watchdogTask?.cancel()
            watchdogTask = nil
            if let threadIndex = threads.firstIndex(where: { $0.id == id }),
               let messageIndex = threads[threadIndex].messages.firstIndex(where: { $0.id == messageID }) {
                if outcome == .complete && threads[threadIndex].messages[messageIndex].text.isEmpty {
                    outcome = .failed
                    error = "モデルから回答が届きませんでした。新しい会話でお試しください。"
                }
                threads[threadIndex].messages[messageIndex].state = outcome
            }
            isGenerating = false
            isStopping = false
            status = ""
            generationTask = nil
            activeReply = nil
            persist()
        }
    }

    private func setStage(_ stage: GemmaService.Stage, ticket: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        currentStage = stage.rawValue
        stageStarted = Date()
        status = currentStage
    }

    private func append(_ text: String, ticket: UUID, threadID: UUID, messageID: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        lastActivity = Date()
        bufferedText += text
        bufferedTarget = (ticket, threadID, messageID)
        guard bufferTask == nil else { return }
        // Native token callbacks can arrive hundreds of times a second.
        // Batch them without re-laying out every row for each character.
        bufferTask = Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(45)) } catch { return }
            flushBufferedReply()
        }
    }
    private func flushBufferedReply() {
        bufferTask?.cancel(); bufferTask = nil
        let text = bufferedText, target = bufferedTarget
        bufferedText = ""; bufferedTarget = nil
        guard !text.isEmpty, let target, replyTicket.accepts(target.ticket) else { return }
        let threadID = target.thread, messageID = target.message
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].text += text
        lastActivity = Date()
        stageStarted = Date()
        currentStage = "回答中…"
        status = "回答中…"
        if Date().timeIntervalSince(lastCheckpoint) > 2 {
            persist()
            lastCheckpoint = Date()
        }
    }

    func stop() {
        guard isGenerating, !isStopping else { return }
        flushBufferedReply()
        isStopping = true
        status = "停止しています…"
        Task { await gemma.cancel() }
    }

    private func startWatchdog(ticket: UUID, threadID: UUID, messageID: UUID) {
        watchdogTask?.cancel()
        watchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(5)) } catch { return }
                guard let self, self.replyTicket.accepts(ticket) else { return }
                if Date().timeIntervalSince(self.lastActivity) >= 120 {
                    guard self.replyTicket.finish(ticket) else { return }
                    if let ti = self.threads.firstIndex(where: { $0.id == threadID }),
                       let mi = self.threads[ti].messages.firstIndex(where: { $0.id == messageID }) {
                        self.threads[ti].messages[mi].state = self.isStopping ? .stopped : .failed
                    }
                    self.error = "返信が届かないため、待機を終了しました。もう一度送信してください。続く場合はアプリを開き直してください。"
                    self.isGenerating = false
                    self.isStopping = false
                    self.status = ""
                    self.activeReply = nil
                    // Keep the native request alive until it really finishes.
                    // Late callbacks are discarded by the ticket above.
                    self.persist()
                    await self.gemma.cancel()
                    return
                }
                if !self.isStopping, Date().timeIntervalSince(self.stageStarted) >= 15 {
                    self.status = "\(self.currentStage) \(Int(Date().timeIntervalSince(self.stageStarted)))秒"
                }
            }
        }
    }

    func didEnterBackground() {
        if isGenerating && !isStopping { interruptedReply = activeReply }
        stop()
        persist()
        let backgroundID = UIApplication.shared.beginBackgroundTask(withName: "FinishGemmaReply", expirationHandler: nil)
        let task = generationTask
        Task {
            await task?.value
            await gemma.unload()
            if backgroundID != .invalid { UIApplication.shared.endBackgroundTask(backgroundID) }
        }
    }

    /// Carries on a reply that leaving the app stopped. The GPU can't decode
    /// in the background, so the reply picks up from the text it reached.
    func resumeInterruptedReply() {
        guard let target = interruptedReply else { return }
        interruptedReply = nil
        let stopping = generationTask
        Task {
            await stopping?.value
            resume(target)
        }
    }

    private func resume(_ target: (thread: UUID, message: UUID)) {
        guard !isGenerating, let ti = threads.firstIndex(where: { $0.id == target.thread }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == target.message }), mi > 0,
              threads[ti].messages[mi].state == .stopped, threads[ti].messages[mi - 1].role == .user else { return }
        let question = threads[ti].messages[mi - 1]
        let model = ModelSpec.find(threads[ti].modelID) ?? .e4b
        guard ModelStore.shared.isInstalled(model) else { return }
        let settings = (configurations[model.id] ?? GenerationSettings(for: model)).normalized(for: model)
        let partial = threads[ti].messages[mi].text
        threads[ti].messages[mi].state = .generating
        if partial.isEmpty {
            // Nothing had arrived yet, so ask the question again.
            let cost = question.text.utf8.count + question.media.reduce(0) {
                $0 + $1.contextByteCost(visualTokenBudget: settings.visualTokenBudget) }
            let images = question.media.reduce(0) { $0 + $1.imageNames.count }
            let history = replyHistory(Array(threads[ti].messages[..<(mi - 1)]), model: model, settings: settings,
                                       cost: cost, images: images)
            let hasVision = (question.media + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
            startReply(threadID: target.thread, messageID: target.message, hasVision: hasVision) { [gemma = self.gemma] onStage, onText in
                try await gemma.generate(threadID: target.thread, prompt: question.text, history: history,
                    model: model, settings: settings, attachments: question.media, onStage: onStage, onText: onText)
            }
        } else {
            startReply(threadID: target.thread, messageID: target.message, hasVision: false) { [gemma = self.gemma] onStage, onText in
                try await gemma.continueReply(threadID: target.thread, prompt: question.text, reply: partial,
                    model: model, settings: settings, onStage: onStage, onText: onText)
            }
        }
    }

    func releaseModelMemory() {
        guard !isGenerating else { return }
        Task { await gemma.unload() }
    }

    /// Returns once the weights are unmapped, so a model file can be removed.
    func unloadModel() async {
        guard !isGenerating else { return }
        await gemma.unload()
    }

    func runVisionProbe(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                        vision: ExecutionBackend, kernel: VisionCPUImplementation = .xnnpack,
                        visionTokens: Int = 280) async throws -> String {
        guard !isGenerating else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = "" }
        status = "画像の最小再現テストを実行しています…"
        return try await gemma.runVisionProbe(model: model, kind: kind, main: main, vision: vision, kernel: kernel,
                                              visionTokens: visionTokens)
    }

    private func persist() {
        guard archiveWritable else { return }
        do { try archive.save(threads); CloudHistoryStore.shared.schedule(threads) }
        catch { self.error = "会話履歴を保存できませんでした。\n\(error.localizedDescription)" }
    }
    func mergeBackup(_ incoming: [ChatThread]) {
        guard !isGenerating, archiveWritable else { return }
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
        if selectedID == nil { selectedID = threads.first?.id }
        persist()
    }
}

