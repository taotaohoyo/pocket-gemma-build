import Foundation
import Combine
import PocketCore
import UIKit

@MainActor
final class ChatStore: ObservableObject {
    /// One for the app: iOS may wake it in the background for a question
    /// from the Apple Watch (WatchBridge) before any screen is shown.
    static let shared = ChatStore()
    @Published private(set) var threads: [ChatThread] = []
    /// Kept for the next launch (起動時のチャット's 前回の会話, LaunchChatPlan).
    @Published private(set) var selectedID: UUID? {
        didSet { if selectedID != oldValue { LaunchChatPlan.remember(selectedID) } }
    }
    @Published private(set) var isGenerating = false
    @Published private(set) var isStopping = false
    @Published private(set) var status = ""
    /// One GPU start test per launch: a failed GPU start can keep its
    /// address space until the app quits, which would skew the next test.
    @Published private(set) var gpuStartTestRan = false
    /// A tapped notification chose the chat (起動時のチャット leaves it open).
    private(set) var openedFromNotification = false
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    private let archive = ChatArchive(fileURL: AppFiles.archive)
    private let gemma = GemmaService()
    private var generationTask: Task<Void, Never>?
    private var watchdogTask: Task<Void, Never>?
    private var replyTicket = ReplyTicket()
    private var lastActivity = Date()
    private var stageStarted = Date()
    private var currentStage = GemmaService.Stage.loading.rawValue
    private var archiveWritable = true
    private var lastCheckpoint = Date.distantPast
    private var bufferedText = ""
    private var bufferTask: Task<Void, Never>?
    private var bufferedTarget: (ticket: UUID, thread: UUID, message: UUID)?
    private var activeReply: (thread: UUID, message: UUID)?
    private var interruptedReply: (thread: UUID, message: UUID)?
    /// Background time for a reply still being written when the app leaves
    /// the screen, and the notification when it ends there.
    private let background = BackgroundReply()
    /// The language backend of the reply being written. iPhone apps can't
    /// use the GPU in the background, so a reply on the GPU stops when the
    /// app leaves and goes on on the CPU.
    private var activeBackend = ExecutionBackend.gpu
    /// The reply stopped on the GPU to go on on the CPU.
    private var handoff: (thread: UUID, message: UUID)?
    /// The reply that ran out of background time; its notification says so.
    private var pausedInBackground: UUID?
    /// For the diagnostics: the reply was written partly in the background,
    /// moved to the CPU there, and back to the GPU on return.
    private var leftScreen = false
    private var movedToCPU = false
    private var movedBackToGPU = false
    private var replyCharacters = 0
    private var openChatObserver: NSObjectProtocol?
    /// Replies written for the Apple Watch: Gemma 4 E2B's, whatever their
    /// chat's model, also when they go on after a stop (resume).
    private var watchReplies: Set<UUID> = []

    init() {
        do {
            threads = try archive.load().sorted { $0.updatedAt > $1.updatedAt }
            // The chat open when Fielua was last left, as it was.
            selectedID = LaunchChatPlan.opening(threads, lastOpen: LaunchChatPlan.lastOpen())
        } catch {
            // Preserve a corrupted archive for recovery, rather than overwrite it.
            archiveWritable = false
            self.error = String(localized: "会話履歴を開けませんでした。元のファイルを保護するため、この起動中は履歴保存を停止しています。") + "\n" + error.localizedDescription
        }
        if selectedID == nil { newChat() }
        LaunchChat.choose(in: self)
        background.onExpired = { [weak self] in self?.pauseInBackground() }
        // A tapped notification opens its chat.
        openChatObserver = NotificationCenter.default.addObserver(forName: ReplyNotifications.openChat, object: nil,
                                                                  queue: .main) { [weak self] note in
            MainActor.assumeIsolated {
                if let id = ReplyNotifications.threadID(in: note) {
                    self?.openedFromNotification = true
                    self?.select(id)
                }
            }
        }
    }

    var current: ChatThread? { threads.first { $0.id == selectedID } }
    var messages: [ChatMessage] { current?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(current?.modelID) ?? .e4b }
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings(for: currentModel)).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        guard !isGenerating else { return }
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }
    /// How the current chat's model reads photos and replies (高速・深く, and
    /// さらに深く where offered), when it offers a choice
    /// (ModelSpec.photoDetails). Saved with that model's settings and used
    /// from the next send; ignored while a reply is generating.
    var photoDetail: PhotoDetail { currentSettings.photoDetail }
    func setPhotoDetail(_ detail: PhotoDetail) {
        guard currentModel.photoDetails.contains(detail) else { return }
        var settings = currentSettings
        settings.photoDetail = detail
        updateSettings(settings)
    }

    /// The current chat's web search switch (off unless turned on), and
    /// whether the chat may search at all: Gemma, and no file in it. The
    /// person's Tavily key is WebSearchKeyState's.
    var webSearchOn: Bool { current?.webSearch == true }
    var webSearchBlocked: Bool { WebSearchPolicy.blockedByFiles(messages) }
    var webSearchOffered: Bool { WebSearchPolicy.offers(currentModel) }
    func setWebSearch(_ on: Bool) {
        guard !isGenerating, let index = threads.firstIndex(where: { $0.id == selectedID }) else { return }
        threads[index].webSearch = on ? true : nil
        persist()
    }

    func newChat(modelID: String? = nil) {
        guard !isGenerating else { return }
        let modelID = modelID ?? ModelStore.shared.selectedModel.id
        if let empty = threads.first(where: { $0.messages.isEmpty && $0.modelID == modelID }) {
            selectedID = empty.id
        } else {
            let thread = ChatThread(modelID: modelID)
            threads.insert(thread, at: 0)
            selectedID = thread.id
        }
        persist()
    }

    func select(_ id: UUID) {
        guard !isGenerating else { return }
        selectedID = id
    }

    func delete(_ id: UUID) {
        guard !isGenerating else { return }
        threads.removeAll { $0.id == id }
        if selectedID == id {
            selectedID = threads.first?.id
            if selectedID == nil { newChat() }
        }
        persist()
    }

    @discardableResult
    func send(_ raw: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let prompt = trimmed.isEmpty && !attachments.isEmpty ? String(localized: "添付した内容を説明してください。") : trimmed
        guard !prompt.isEmpty, !isGenerating else { return false }
        guard prompt.utf8.count <= 4500 else {
            error = String(localized: "1回のメッセージは約1,500文字までです。長い文章は分けて送ってください。")
            return false
        }
        let requestedModel = currentModel
        let attachmentPolicy = ModelAttachmentPolicy(model: requestedModel)
        do { try attachmentPolicy.validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        let settings = currentSettings
        // A video counts the scenes the reply sees (VideoDigest.Allowance).
        let visualCount = attachments.reduce(0) { $0 + $1.modelImageNames(settings).count }
        guard visualCount == 0 || requestedModel.supportsVision else {
            error = String(localized: "写真にはGemma 4 E2Bを選んでください。"); return false
        }
        // A chart request also carries the chart format's note (GemmaService).
        let guideCost = RichFormatGuide.guide(for: prompt)?.utf8.count ?? 0
        let inputBudget = settings.inputByteBudget
        // Long files: what fits this turn, around the question.
        var prepared = AttachmentStorage.excerpted(attachments, question: prompt, settings: settings)
        // A sent video's note says how its analysis goes (VideoDigest.note).
        for index in prepared.indices {
            if let video = prepared[index].video { prepared[index].note = VideoDigest.note(video, sent: true) }
        }
        let currentCost = prompt.utf8.count + guideCost
            + prepared.reduce(0) { $0 + $1.contextByteCost(settings) }
        guard visualCount <= 4, currentCost <= inputBudget else {
            error = String(localized: "添付内容がモデルの入力上限を超えています。添付を減らすか、構成のMax Tokensを増やしてください。"); return false
        }
        guard ModelStore.shared.isInstalled(requestedModel) else {
            error = String(localized: "設定の「モデル管理」から\(requestedModel.name)をダウンロードしてください。")
            return false
        }
        guard let id = selectedID, let index = threads.firstIndex(where: { $0.id == id }) else { return false }
        // Only the query leaves the device, and only in a chat whose search
        // is on, with the person's key, and that has no file (WebSearchPolicy).
        let searches = WebSearchPolicy.searches(enabled: threads[index].webSearch == true, keyed: WebSearchKeyState.shared.isSet,
                                                model: requestedModel, messages: threads[index].messages, attachments: prepared)
        let history = replyHistory(threads[index].messages, model: requestedModel, settings: settings,
                                   cost: currentCost + (searches ? WebSearch.reservedBytes : 0), images: visualCount)
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[index].messages.append(ChatMessage(id: messageID, role: .user, text: prompt, attachments: prepared))
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        let hasVision = (prepared + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
        let search = searches ? searchTurn(threadID: id, messageID: assistant.id) : nil
        let backend = InferenceEnginePlan(model: requestedModel, settings: settings, needsVision: hasVision).backend
        let keep = videoKeeper(threadID: id, messageID: messageID)
        startReply(threadID: id, messageID: assistant.id, hasVision: hasVision, backend: backend) { [gemma = self.gemma] onStage, onText in
            try await gemma.generate(threadID: id, prompt: prompt, history: history,
                model: requestedModel, settings: settings, attachments: prepared, webSearch: search,
                onStage: onStage, onVideo: keep, onText: onText)
        }
        // Asked for now, while the person acts on screen: iOS lets the reply
        // be finished if the app leaves, and may announce it.
        background.begin(model: requestedModel)
        ReplyNotifications.shared.requestPermissionOnce()
        return true
    }

    /// A reply's searches: each query and the pages it found are kept with
    /// the reply as they come, and the status says what is being searched.
    private func searchTurn(threadID: UUID, messageID: UUID) -> WebSearchTurn {
        WebSearchTurn { [weak self] event in
            await self?.recordSearch(event, threadID: threadID, messageID: messageID)
        }
    }

    private func recordSearch(_ event: WebSearchEvent, threadID: UUID, messageID: UUID) {
        guard activeReply?.message == messageID, !isStopping,
              let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        var record = threads[ti].messages[mi].webSearch ?? WebSearchRecord()
        // The query shows above the reply; the line under the Aurora Orb
        // says what the wait is for, and iOS's display a shorter line.
        let shortStage: String
        switch event {
        case .started(let query):
            record.add(query: query, sources: [], failure: nil)
            record.inProgress = query
            currentStage = "ウェブを検索しています…"
            shortStage = String(localized: "ウェブを検索しています")
        case .finished(let query, let sources, let failure):
            record.add(query: query, sources: sources, failure: failure)
            record.inProgress = nil
            currentStage = failure == nil ? "検索結果を読んでいます…" : "検索できませんでした。端末の中だけで答えています…"
            shortStage = failure == nil ? String(localized: "検索結果を読んでいます") : String(localized: "端末の中だけで答えています")
        }
        threads[ti].messages[mi].webSearch = record
        lastActivity = Date()
        stageStarted = Date()
        status = currentStage
        // A search is work too, though no text comes (BackgroundReply).
        background.progress(characters: replyCharacters, stage: shortStage)
    }

    /// `budget`: the room for the turns and this one together; by default
    /// all the settings allow.
    private func replyHistory(_ messages: [ChatMessage], model: ModelSpec, settings: GenerationSettings,
                              cost: Int, images: Int, budget: Int? = nil) -> [ChatMessage] {
        let attachmentPolicy = ModelAttachmentPolicy(model: model)
        var history = HistoryBuilder.recentPairs(attachmentPolicy.inferenceHistory(messages),
            byteBudget: max(0, (budget ?? settings.inputByteBudget) - cost), visualTokenBudget: settings.visualTokenBudget,
            inputByteBudget: settings.inputByteBudget)
        while images + history.flatMap(\.media).reduce(0, { $0 + $1.modelImageNames(settings).count }) > 4, history.count >= 2 {
            history.removeFirst(2)
        }
        return history
    }

    private func startReply(threadID id: UUID, messageID: UUID, hasVision: Bool, backend: ExecutionBackend,
                            _ work: @escaping (_ onStage: @escaping @Sendable (GemmaService.Stage) async -> Void,
                                               _ onText: @escaping @Sendable (String) async -> Void) async throws -> Void) {
        isGenerating = true
        isStopping = false
        let ticket = replyTicket.begin()
        activeReply = (id, messageID)
        activeBackend = backend
        replyCharacters = threads.first { $0.id == id }?.messages.first { $0.id == messageID }?.text.count ?? 0
        lastActivity = Date()
        stageStarted = Date()
        currentStage = GemmaService.Stage.loading.rawValue
        status = currentStage
        persist()
        startWatchdog(ticket: ticket, threadID: id, messageID: messageID)
        generationTask = Task {
            var outcome: ReplyState = .complete
            do {
                try await work({ [weak self] stage in
                    await self?.setStage(stage, ticket: ticket)
                }, { [weak self] text in
                    await self?.append(text, ticket: ticket, threadID: id, messageID: messageID)
                })
            } catch {
                guard replyTicket.accepts(ticket) else { return }
                if error is CancellationError || isStopping {
                    outcome = .stopped
                } else {
                    outcome = .failed
                    self.error = (hasVision
                        ? String(localized: "写真を読み取れませんでした。開発者設定の「推論の診断」で詳しく確かめられます。")
                        : String(localized: "返信できませんでした。新しいチャットか、軽いモデルでお試しください。")) + "\n" + error.localizedDescription
                }
            }
            guard replyTicket.accepts(ticket) else { return }
            flushBufferedReply()
            guard replyTicket.finish(ticket) else { return }
            watchdogTask?.cancel()
            watchdogTask = nil
            if let threadIndex = threads.firstIndex(where: { $0.id == id }),
               let messageIndex = threads[threadIndex].messages.firstIndex(where: { $0.id == messageID }) {
                if outcome == .complete && threads[threadIndex].messages[messageIndex].text.isEmpty {
                    outcome = .failed
                    error = String(localized: "返信が届きませんでした。新しいチャットでお試しください。")
                }
                threads[threadIndex].messages[messageIndex].state = outcome
            }
            isGenerating = false
            isStopping = false
            status = ""
            generationTask = nil
            activeReply = nil
            persist()
            finishInBackground(threadID: id, messageID: messageID, outcome: outcome)
        }
    }

    private func setStage(_ stage: GemmaService.Stage, ticket: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        // A reply that thinks shows nothing for a while but says so about once
        // a second: the watchdog waits on, the stage's seconds go on, and iOS
        // hears the reply is still moving (BackgroundReply).
        if stage == .thinking {
            lastActivity = Date()
            if currentStage == stage.rawValue {
                background.progress(characters: replyCharacters, stage: String(localized: "考えています"))
                return
            }
        }
        currentStage = stage.rawValue
        stageStarted = Date()
        // A new stage is progress too: the CPU taking over in the background
        // loads the model and reads the reply again before its next word.
        lastActivity = Date()
        status = currentStage
        switch stage {
        case .loading: background.progress(characters: replyCharacters, stage: String(localized: "読み込んでいます"))
        case .preparing: background.progress(characters: replyCharacters, stage: String(localized: "準備しています"))
        case .continuing: background.progress(characters: replyCharacters, stage: String(localized: "続きを準備しています"))
        case .thinking: background.progress(characters: replyCharacters, stage: String(localized: "考えています"))
        case .waiting: background.progress(characters: replyCharacters)
        case .listening: background.progress(characters: replyCharacters, stage: String(localized: "音声を書き起こしています"))
        case .watching: background.progress(characters: replyCharacters, stage: String(localized: "場面を見ています"))
        case .condensing: background.progress(characters: replyCharacters, stage: String(localized: "話をまとめています"))
        }
    }

    /// Keeps a video's analysis with the message it came in, after each
    /// step (GemmaService.analyze): a reply stopped part-way goes on from
    /// there, and the note under the video says how far it got. What was
    /// analyzed stays true after a stop, so it is kept then too.
    private func videoKeeper(threadID: UUID, messageID: UUID) -> @Sendable (UUID, VideoAnalysis) async -> Void {
        { [weak self] attachmentID, video in
            await self?.keepVideo(video, attachmentID: attachmentID, threadID: threadID, messageID: messageID)
        }
    }

    private func keepVideo(_ video: VideoAnalysis, attachmentID: UUID, threadID: UUID, messageID: UUID) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }),
              let ai = threads[ti].messages[mi].attachments?.firstIndex(where: { $0.id == attachmentID }) else { return }
        threads[ti].messages[mi].attachments?[ai].video = video
        threads[ti].messages[mi].attachments?[ai].note = VideoDigest.note(video, sent: true)
        // Each step is work too, though no text comes (BackgroundReply).
        lastActivity = Date()
        persist()
    }

    private func append(_ text: String, ticket: UUID, threadID: UUID, messageID: UUID) {
        guard replyTicket.accepts(ticket), !isStopping else { return }
        lastActivity = Date()
        bufferedText += text
        bufferedTarget = (ticket, threadID, messageID)
        guard bufferTask == nil else { return }
        // Native token callbacks can arrive hundreds of times a second.
        // Batch them without re-laying out every row for each character.
        bufferTask = Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(45)) } catch { return }
            flushBufferedReply()
        }
    }
    private func flushBufferedReply() {
        bufferTask?.cancel(); bufferTask = nil
        let text = bufferedText, target = bufferedTarget
        bufferedText = ""; bufferedTarget = nil
        guard !text.isEmpty, let target, replyTicket.accepts(target.ticket) else { return }
        let threadID = target.thread, messageID = target.message
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].text += text
        replyCharacters = threads[ti].messages[mi].text.count
        background.progress(characters: replyCharacters)
        lastActivity = Date()
        stageStarted = Date()
        currentStage = "返信中…"
        status = "返信中…"
        if Date().timeIntervalSince(lastCheckpoint) > 2 {
            persist()
            lastCheckpoint = Date()
        }
    }

    func stop() {
        guard isGenerating, !isStopping else { return }
        flushBufferedReply()
        isStopping = true
        status = "停止しています…"
        Task { await gemma.cancel() }
    }

    private func startWatchdog(ticket: UUID, threadID: UUID, messageID: UUID) {
        watchdogTask?.cancel()
        watchdogTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(5)) } catch { return }
                guard let self, self.replyTicket.accepts(ticket) else { return }
                if Date().timeIntervalSince(self.lastActivity) >= 120 {
                    guard self.replyTicket.finish(ticket) else { return }
                    if let ti = self.threads.firstIndex(where: { $0.id == threadID }),
                       let mi = self.threads[ti].messages.firstIndex(where: { $0.id == messageID }) {
                        self.threads[ti].messages[mi].state = self.isStopping ? .stopped : .failed
                    }
                    self.error = String(localized: "返信が届かないため、待機を終了しました。もう一度送信してください。続く場合はアプリを開き直してください。")
                    self.isGenerating = false
                    self.isStopping = false
                    self.status = ""
                    self.activeReply = nil
                    // Keep the native request alive until it really finishes.
                    // Late callbacks are discarded by the ticket above.
                    self.persist()
                    await self.gemma.cancel()
                    return
                }
                if !self.isStopping, Date().timeIntervalSince(self.stageStarted) >= 15 {
                    self.status = "\(self.currentStage) \(Int(Date().timeIntervalSince(self.stageStarted)))秒"
                }
            }
        }
    }

    /// A reply being written goes on while the app is away. iPhone apps
    /// can't use the GPU in the background, so a reply on the GPU stops and
    /// goes on from its last character on the CPU; one on the CPU goes on as
    /// it is. When it ends (`finishInBackground`) a notification says so and
    /// the model is unloaded. Without a reply, the model is unloaded now.
    func didEnterBackground() {
        persist()
        // Between two backends: where it goes on is decided when the stop ends.
        if handoff != nil {
            leftScreen = true
            background.holdBackgroundTime()
            return
        }
        guard isGenerating, !isStopping, let reply = activeReply else {
            let backgroundID = UIApplication.shared.beginBackgroundTask(withName: "ReleaseGemma", expirationHandler: nil)
            let task = generationTask
            Task {
                await task?.value
                if !isGenerating { await gemma.unload() }
                if backgroundID != .invalid { UIApplication.shared.endBackgroundTask(backgroundID) }
            }
            return
        }
        leftScreen = true
        background.holdBackgroundTime()
        guard activeBackend == .gpu else { return }
        movedToCPU = true
        background.progress(characters: replyCharacters, stage: String(localized: "バックグラウンドで続けます"))
        move(reply)
    }

    /// Back on screen while the CPU stands in for the GPU: on the phone the
    /// CPU writes about a tenth as fast (E4B, 1.1.0 (134): 8 characters a
    /// second against 75 to 100), so the reply goes back to the GPU and on
    /// from its last character there.
    private func returnToGPU() -> Bool {
        guard movedToCPU, activeBackend == .cpu, handoff == nil, isGenerating, !isStopping,
              let reply = activeReply else { return false }
        movedBackToGPU = true
        move(reply)
        return true
    }

    /// Stops the reply and lets it go on from its last character where it
    /// can run once the stop ends: on the CPU while the app is away, on its
    /// own backend when the app is on screen.
    private func move(_ reply: (thread: UUID, message: UUID)) {
        handoff = reply
        stop()
        let stopping = generationTask
        Task {
            await stopping?.value
            guard let target = handoff, target.message == reply.message else { return }
            handoff = nil
            let state = threads.first { $0.id == target.thread }?.messages.first { $0.id == target.message }?.state
            guard state == .stopped else {
                // It ended before it could be stopped.
                finishInBackground(threadID: target.thread, messageID: target.message, outcome: state ?? .failed)
                return
            }
            let away = UIApplication.shared.applicationState != .active
            if away { movedToCPU = true }
            guard resume(target, onCPU: away) else {
                // It can't go on now (its model is gone, say): it waits for the app.
                interruptedReply = target
                pausedInBackground = target.message
                finishInBackground(threadID: target.thread, messageID: target.message, outcome: .stopped)
                return
            }
        }
    }

    /// The background time ran out, or iOS ended the reply's task (from its
    /// display, or for the resources): the reply stops where it is, a
    /// notification says so, and it goes on when the app is opened.
    private func pauseInBackground() {
        // iOS may end the task with the app back on screen; the reply goes on.
        guard UIApplication.shared.applicationState != .active else { return }
        let target = activeReply ?? handoff
        handoff = nil
        guard let target else { return }
        interruptedReply = target
        pausedInBackground = target.message
        if isGenerating {
            stop()
        } else {
            // Between the GPU's stop and the CPU's start.
            finishInBackground(threadID: target.thread, messageID: target.message, outcome: .stopped)
        }
    }

    /// After a reply ends, unless it stopped only to go on on the CPU: its
    /// background time ends, and while the app is away a notification says
    /// how it ended and the model is unloaded.
    private func finishInBackground(threadID: UUID, messageID: UUID, outcome: ReplyState) {
        guard handoff?.message != messageID else { return }
        background.end(success: outcome == .complete)
        let paused = pausedInBackground == messageID
        pausedInBackground = nil
        let note = leftScreen ? "アプリが裏に回った" + (movedToCPU ? " · CPUで続けた" : " · CPUのまま続けた")
            + (movedBackToGPU ? " · 戻ってGPUで続けた" : "")
            + " · \(background.state) · 結果: \(paused ? "時間切れで止めた" : outcome.rawValue)" : nil
        leftScreen = false
        movedToCPU = false
        movedBackToGPU = false
        // The Apple Watch app shows its own answer while it is open.
        if UIApplication.shared.applicationState != .active, !WatchBridge.shared.showsAnswer(in: threadID) {
            let thread = threads.first { $0.id == threadID }
            let text = thread?.messages.first { $0.id == messageID }?.text ?? ""
            switch outcome {
            case .complete:
                ReplyNotifications.shared.post(title: ReplyNotice.finishedTitle,
                                               body: ReplyNotice.preview(of: text), threadID: threadID)
            case .failed:
                ReplyNotifications.shared.post(title: ReplyNotice.failedTitle,
                                               body: ReplyNotice.failedBody, threadID: threadID)
            case .stopped where paused:
                ReplyNotifications.shared.post(title: ReplyNotice.pausedTitle,
                                               body: ReplyNotice.pausedBody, threadID: threadID)
            default:
                break
            }
        }
        let away = UIApplication.shared.applicationState == .background
        let forWatch = watchReplies.contains(messageID)
        Task {
            if let note { await gemma.noteBackground(note) }
            // Away from the screen the model's memory goes back to iOS, but
            // not after an answer for the Apple Watch (2026-10-24): its rest
            // (continueForWatch) or the watch's next question comes soon and
            // starts without loading the model again. iOS may still end the
            // app for the memory; it is then loaded as before.
            if away && !isGenerating && !forWatch { await gemma.unload() }
            // A reply begun meanwhile (the watch's) keeps the time it holds.
            if !isGenerating { background.releaseBackgroundTime() }
        }
    }

    /// Carries on a reply that leaving the app stopped. The model gets its
    /// own unfinished turn back and goes on from the text it reached.
    /// When the app is back on screen, a reply the CPU stood in for goes
    /// back to the GPU.
    func resumeInterruptedReply() {
        if returnToGPU() { return }
        guard handoff == nil, let target = interruptedReply else { return }
        interruptedReply = nil
        let stopping = generationTask
        Task {
            await stopping?.value
            resume(target)
        }
    }

    /// `onCPU` while the app is away: the GPU can't run in the background.
    @discardableResult
    private func resume(_ target: (thread: UUID, message: UUID), onCPU: Bool = false) -> Bool {
        guard !isGenerating, let ti = threads.firstIndex(where: { $0.id == target.thread }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == target.message }), mi > 0,
              threads[ti].messages[mi].state == .stopped, threads[ti].messages[mi - 1].role == .user else { return false }
        let question = threads[ti].messages[mi - 1]
        let forWatch = watchReplies.contains(target.message)
        let model = forWatch ? ModelSpec.e2b : ModelSpec.find(threads[ti].modelID) ?? .e4b
        guard ModelStore.shared.isInstalled(model) else { return false }
        var settings = (configurations[model.id] ?? GenerationSettings(for: model)).normalized(for: model)
        if onCPU { settings.backend = .cpu }
        var note = onCPU ? "アプリが裏に回ったのでCPUで続きを書く" : nil
        let partial = threads[ti].messages[mi].text
        threads[ti].messages[mi].state = .generating
        if partial.isEmpty {
            // Nothing had arrived yet, so ask the question again.
            let cost = question.text.utf8.count + question.media.reduce(0) { $0 + $1.contextByteCost(settings) }
            let images = question.media.reduce(0) { $0 + $1.modelImageNames(settings).count }
            // On the CPU in the background, the latest turns only (BackgroundRead).
            let earlier = Array(threads[ti].messages[..<(mi - 1)])
            let history = replyHistory(forWatch ? earlier.map(WatchAsk.textOnly) : earlier, model: model, settings: settings,
                                       cost: cost, images: images,
                                       budget: onCPU ? min(settings.inputByteBudget, cost + BackgroundRead.historyBudget(settings)) : nil)
            note = note.map { $0 + " · 前のやりとり\(history.count / 2)組を読む" }
            let hasVision = (question.media + history.flatMap(\.media)).contains { !$0.imageNames.isEmpty }
            // The watch's questions don't search (askFromWatch).
            let searches = !forWatch && WebSearchPolicy.searches(enabled: threads[ti].webSearch == true, keyed: WebSearchKeyState.shared.isSet,
                                                    model: model, messages: Array(threads[ti].messages[..<(mi - 1)]),
                                                    attachments: question.media)
            let search = searches ? searchTurn(threadID: target.thread, messageID: target.message) : nil
            let backend = InferenceEnginePlan(model: model, settings: settings, needsVision: hasVision).backend
            let keep = videoKeeper(threadID: target.thread, messageID: question.id)
            startReply(threadID: target.thread, messageID: target.message, hasVision: hasVision, backend: backend) { [gemma = self.gemma, note] onStage, onText in
                try await gemma.generate(threadID: target.thread, prompt: question.text, history: history,
                    model: model, settings: settings, attachments: question.media, webSearch: search, background: note,
                    readsLess: onCPU, onStage: onStage, onVideo: keep, onText: onText)
            }
        } else {
            let backend = InferenceEnginePlan(model: model, settings: settings, needsVision: false).backend
            note = note.map { $0 + " · 回答の終わり\(min(partial.utf8.count, BackgroundRead.tailBytes))バイトを読み直す" }
            startReply(threadID: target.thread, messageID: target.message, hasVision: false, backend: backend) { [gemma = self.gemma, note] onStage, onText in
                try await gemma.continueReply(threadID: target.thread, prompt: question.text, reply: partial,
                    model: model, settings: settings, background: note, readsLess: onCPU,
                    onStage: onStage, onText: onText)
            }
        }
        // A reply going on with the app on screen may leave again.
        if !onCPU { background.begin(model: model) }
        return true
    }

    // MARK: Apple Watch

    enum WatchAsk {
        case started(thread: UUID, message: UUID)
        case refused(String)

        /// A turn as the watch's question reads it: its text, without the
        /// photos and files, which a reply for the watch doesn't load (the
        /// saved chat keeps them). As ModelAttachmentPolicy says it.
        static func textOnly(_ message: ChatMessage) -> ChatMessage {
            guard !message.media.isEmpty else { return message }
            var copy = message
            copy.attachments = nil
            if message.role == .user { copy.text += ModelAttachmentPolicy.earlierAttachmentsNote }
            return copy
        }
    }

    /// A question from the Apple Watch app (WatchBridge), answered by Gemma
    /// 4 E2B whatever the chats use, in the chat the watch shows: any chat
    /// of the history, whatever its model (`threadID`), or a new E2B chat
    /// (`newThreadID`, the id the watch gave it). The chat keeps its model
    /// and settings: only the question and E2B's answer are added, and its
    /// photos and files are not read (WatchAsk.textOnly). `messageID` is the
    /// watch's question's id. The chat is opened, so with Fielua on screen
    /// the answer is seen being written, as fast as a sent message's. Away
    /// from the screen (iOS woke the app for the watch) it is written on the
    /// CPU, reading less, as a reply that leaves goes on: iPhone apps can't
    /// use the GPU in the background. iOS gives the continued task only to
    /// an app on screen, so it is asked for anyway and otherwise the usual
    /// background time, about 30 seconds, is all there is; the reply then
    /// waits for the app to open.
    func askFromWatch(_ question: String, threadID: UUID?, newThreadID: UUID? = nil,
                      messageID: UUID = UUID()) -> WatchAsk {
        let prompt = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !prompt.isEmpty else { return .refused(String(localized: "質問が空でした")) }
        guard prompt.utf8.count <= 4500 else { return .refused(String(localized: "質問が長すぎます。短くしてください")) }
        guard !isGenerating, handoff == nil else { return .refused(String(localized: "iPhoneで別の返信を書いています")) }
        let model = ModelSpec.e2b
        guard ModelStore.shared.isInstalled(model) else { return .refused(String(localized: "iPhoneのFieluaにGemma 4 E2Bが入っていません")) }
        let index: Int
        if let threadID, let found = threads.firstIndex(where: { $0.id == threadID }) {
            index = found
        } else {
            // A chat id is never used twice (the watch's are random).
            let id = newThreadID.flatMap { new in threads.contains { $0.id == new } ? nil : new } ?? UUID()
            threads.insert(ChatThread(id: id, modelID: model.id), at: 0)
            index = 0
        }
        let id = threads[index].id
        selectedID = id
        // A reply that waited for the app to open stays where it stopped:
        // the watch asked something new (WatchSession marks it so).
        interruptedReply = nil
        let away = UIApplication.shared.applicationState != .active
        var settings = (configurations[model.id] ?? GenerationSettings(for: model)).normalized(for: model)
        if away { settings.backend = .cpu }
        let cost = prompt.utf8.count
        let history = replyHistory(threads[index].messages.map(WatchAsk.textOnly), model: model, settings: settings,
                                   cost: cost, images: 0,
                                   budget: away ? min(settings.inputByteBudget, cost + BackgroundRead.historyBudget(settings)) : nil)
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[index].messages.append(ChatMessage(id: messageID, role: .user, text: prompt))
        threads[index].messages.append(assistant)
        threads[index].updatedAt = Date()
        watchReplies.insert(assistant.id)
        let note = away ? "Apple Watchの質問・アプリは裏・CPUで書く · 前のやりとり\(history.count / 2)組を読む" : nil
        let backend = InferenceEnginePlan(model: model, settings: settings, needsVision: false).backend
        startReply(threadID: id, messageID: assistant.id, hasVision: false, backend: backend) { [gemma = self.gemma] onStage, onText in
            try await gemma.generate(threadID: id, prompt: prompt, history: history, model: model, settings: settings,
                                     attachments: [], background: note, readsLess: away, onStage: onStage, onText: onText)
        }
        background.begin(model: model)
        if away {
            // As a reply that left the screen: the diagnostics say so, and
            // back on screen it goes on on the GPU (returnToGPU).
            leftScreen = true
            movedToCPU = true
            background.holdBackgroundTime()
        }
        ReplyNotifications.shared.requestPermissionOnce()
        return .started(thread: id, message: assistant.id)
    }

    /// The Apple Watch app asks for the rest of its answer, which paused
    /// when the background time ran out (WatchBridge, WatchCarryOn,
    /// 2026-10-24). iOS woke the app for the watch's message with another
    /// stretch of background time, and the answer goes on from its last
    /// character on the CPU, in the model kept loaded since
    /// (finishInBackground). Also after iOS ended the app meanwhile: the
    /// watch asks only for an answer it saw pause. False when it can't go
    /// on now: another reply is being written or waits for the app.
    func continueForWatch(thread: UUID, message: UUID) -> Bool {
        guard !isGenerating, handoff == nil else { return false }
        if let interruptedReply, interruptedReply.message != message { return false }
        let waiting = interruptedReply
        let away = UIApplication.shared.applicationState != .active
        interruptedReply = nil
        watchReplies.insert(message)
        guard resume((thread, message), onCPU: away) else {
            interruptedReply = waiting
            return false
        }
        if away {
            // As askFromWatch: the diagnostics say so, and back on screen
            // it goes on on the GPU (returnToGPU).
            background.begin(model: .e2b)
            leftScreen = true
            movedToCPU = true
            background.holdBackgroundTime()
        }
        return true
    }

    /// The watch's question `id` (its message's id), if the iPhone has it
    /// already: its chat and the reply after it. A question the watch sends
    /// again is not written twice.
    func watchQuestion(_ id: UUID) -> (thread: UUID, reply: UUID?)? {
        for thread in threads {
            guard let index = thread.messages.firstIndex(where: { $0.id == id }) else { continue }
            let next = thread.messages.index(after: index)
            let reply = next < thread.messages.endIndex && thread.messages[next].role == .assistant
                ? thread.messages[next].id : nil
            return (thread.id, reply)
        }
        return nil
    }

    /// The reply stopped only to go on: on the other backend, or when the
    /// app is opened after its background time ran out.
    func replyWillContinue(_ messageID: UUID) -> Bool {
        handoff?.message == messageID || interruptedReply?.message == messageID
    }

    /// Out of background time, waiting for the app (not stopped by anyone).
    func replyIsPaused(_ messageID: UUID) -> Bool {
        interruptedReply?.message == messageID
    }

    func releaseModelMemory() {
        guard !isGenerating else { return }
        Task { await gemma.unload() }
    }

    /// Returns once the weights are unmapped, so a model file can be removed.
    func unloadModel() async {
        guard !isGenerating else { return }
        await gemma.unload()
    }

    func runVisionProbe(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                        vision: ExecutionBackend, kernel: VisionCPUImplementation = .xnnpack,
                        visionTokens: Int = 280, contextTokens: Int = 4096) async throws -> String {
        guard !isGenerating else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = "" }
        status = "画像の最小再現テストを実行しています…"
        return try await gemma.runVisionProbe(model: model, kind: kind, main: main, vision: vision, kernel: kernel,
                                              visionTokens: visionTokens, contextTokens: contextTokens)
    }

    func runLargeModelProbe(backend: LargeModelProbe.Backend) async throws -> LargeModelProbe.Record {
        guard !isGenerating else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = "" }
        status = "12Bの動作を確認しています…"
        return try await gemma.runLargeModelProbe(backend: backend)
    }

    func runGPUStartTest(model: ModelSpec, precision: GPUPrecision) async throws -> String {
        guard !isGenerating, !gpuStartTestRan else { throw CocoaError(.userCancelled) }
        isGenerating = true
        defer { isGenerating = false; status = ""; gpuStartTestRan = GPUStartTestRunner.startsThisLaunch > 0 }
        status = "GPU起動テストを実行しています…"
        return try await gemma.runGPUStartTest(model: model, precision: precision)
    }

    private func persist() {
        guard archiveWritable else { return }
        do { try archive.save(threads); CloudHistoryStore.shared.schedule(threads) }
        catch { self.error = String(localized: "会話履歴を保存できませんでした。") + "\n" + error.localizedDescription }
    }
    func mergeBackup(_ incoming: [ChatThread]) {
        guard !isGenerating, archiveWritable else { return }
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
        if selectedID == nil { selectedID = threads.first?.id }
        persist()
    }
}

