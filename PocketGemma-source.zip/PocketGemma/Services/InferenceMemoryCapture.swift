import Foundation
import os
import PocketCore
import VisionRuntimeBridge

/// Sample the app footprint, not just free memory before native allocation.
/// Peaks between the 200 ms samples and the OS jetsam limit remain unknown.
final class InferenceMemoryCapture: @unchecked Sendable {
    private let queue = DispatchQueue(label: "app.pocketgemma.memory-probe")
    private let source: DispatchSourceTimer
    private var peak: UInt64 = 0
    private var minimum: UInt64 = .max
    private var count = 0
    private var virtualPeak: UInt64 = 0
    private var regionPeak: UInt64 = 0
    /// The tightest address space seen. A walk of the regions takes a few
    /// milliseconds, so it runs on every fifth sample (about once a second).
    private var lowestAddress: AddressSpace?
    init() {
        source = DispatchSource.makeTimerSource(queue: queue)
        source.schedule(deadline: .now(), repeating: .milliseconds(200))
        source.setEventHandler { [weak self] in self?.sample() }
        source.resume()
    }
    private func sample() {
        peak = max(peak, PGProcessMemoryFootprint())
        virtualPeak = max(virtualPeak, PGProcessVirtualSize())
        regionPeak = max(regionPeak, PGProcessRegionCount())
        minimum = min(minimum, UInt64(os_proc_available_memory()))
        if count % 5 == 0, let space = AddressSpace.current(),
           lowestAddress.map({ space.largestFree < $0.largestFree }) ?? true {
            lowestAddress = space
        }
        count += 1
    }
    func finish() -> (peak: UInt64, minimum: UInt64, samples: Int, virtualPeak: UInt64, regionPeak: UInt64,
                      lowestAddress: AddressSpace?) {
        source.cancel()
        return queue.sync { sample(); return (peak, minimum, count, virtualPeak, regionPeak, lowestAddress) }
    }
    deinit { source.cancel() }
}
