import Foundation
import UserNotifications
import WatchConnectivity

/// The one notification that tells someone whose Apple Watch has Fielua,
/// but who has not used it there, that they can talk to Fielua from the
/// watch (2026-10-24). It comes once: never again after it was shown, and
/// not at all once the watch app was used. It never asks for permission:
/// only where notifications are already allowed (ReplyNotifications asks
/// at the first question).
///
/// iOS shows an iPhone's notification on the Apple Watch only while the
/// iPhone is locked and the watch is worn, so it is set for a few minutes
/// after Fielua leaves the screen, and taken back if Fielua comes back
/// first. Tapped on the watch it opens Fielua there; on the iPhone, Fielua
/// on the iPhone. The sideloaded app has no watch app, so it never comes.
enum WatchIntro {
    static let requestID = "watch-intro"
    static let title = "Apple Watchからも会話できるようになりました！ ✨"
    static let body = "iPhoneを取り出さなくても、手元からFieluaに話しかけられます。"
    /// After Fielua leaves the screen, when the iPhone is usually locked.
    static let delay: TimeInterval = 180
    private static let usedKey = "watchIntroUsed"
    /// Set (or shown): never set again.
    private static let setKey = "watchIntroSet"

    /// The watch app was used: no notification, and a set one goes.
    @MainActor
    static func markUsed() {
        let defaults = UserDefaults.standard
        guard !defaults.bool(forKey: usedKey) else { return }
        defaults.set(true, forKey: usedKey)
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [requestID])
    }

    @MainActor
    private static var used: Bool {
        let defaults = UserDefaults.standard
        // 1.1.0 (152) kept the watch's conversation once it had asked.
        return defaults.bool(forKey: usedKey) || defaults.string(forKey: "watchConversation") != nil
    }

    /// 開発者設定's 「初回起動扱いにする」 (FirstLaunchResetCard): as if the
    /// watch app had never been used and the notification never set or
    /// shown, so it comes again the next time Fielua leaves the screen.
    @MainActor
    static func reset() {
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: usedKey)
        defaults.removeObject(forKey: setKey)
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [requestID])
        center.removeDeliveredNotifications(withIdentifiers: [requestID])
    }

    /// Fielua left the screen.
    @MainActor
    static func appDidLeave() {
        let defaults = UserDefaults.standard
        guard !used, !defaults.bool(forKey: setKey), WCSession.isSupported() else { return }
        let session = WCSession.default
        guard session.activationState == .activated, session.isPaired, session.isWatchAppInstalled else { return }
        defaults.set(true, forKey: setKey)
        Task { @MainActor in
            let center = UNUserNotificationCenter.current()
            let status = await center.notificationSettings().authorizationStatus
            guard status == .authorized || status == .provisional || status == .ephemeral else {
                UserDefaults.standard.set(false, forKey: setKey)
                return
            }
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body
            content.sound = .default
            content.threadIdentifier = requestID
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false)
            do {
                try await center.add(UNNotificationRequest(identifier: requestID, content: content, trigger: trigger))
            } catch {
                UserDefaults.standard.set(false, forKey: setKey)
            }
        }
    }

    /// Fielua is back on screen. Not shown yet: taken back, and set again
    /// when Fielua leaves. Already shown: it stays the only one.
    @MainActor
    static func appDidReturn() {
        guard UserDefaults.standard.bool(forKey: setKey) else { return }
        Task { @MainActor in
            let center = UNUserNotificationCenter.current()
            let pending = await center.pendingNotificationRequests()
            guard pending.contains(where: { $0.identifier == requestID }) else { return }
            center.removePendingNotificationRequests(withIdentifiers: [requestID])
            UserDefaults.standard.set(false, forKey: setKey)
        }
    }
}
