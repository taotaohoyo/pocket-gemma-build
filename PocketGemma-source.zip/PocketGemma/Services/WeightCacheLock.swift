import Foundation
import Darwin

/// Keeps a CPU engine's weight cache file in memory while the engine runs
/// (ModelCapabilities.locksCPUWeights): the file is mapped once more and
/// locked with `mlock`, so iOS cannot drop its pages, which the runtime's
/// own mapping of the same file then finds in memory. Unlocked and unmapped
/// when released, with the engine. The runtime (XNNPACK) reads every packed
/// weight for every word from this file; once iOS dropped some of Qwen3.5's
/// 2.66 GB or Phi's 2.17 GB, each word read them back from storage
/// (1.1.0 (206), see the capability). The runtime's in-memory cache
/// (":memory") is not built into the iOS runtime, and without any cache
/// Qwen3.5 took 15 GB on the simulator.
final class WeightCacheLock: @unchecked Sendable {
    let bytes: Int
    let seconds: TimeInterval
    private let base: UnsafeMutableRawPointer

    private init(base: UnsafeMutableRawPointer, bytes: Int, seconds: TimeInterval) {
        self.base = base; self.bytes = bytes; self.seconds = seconds
    }

    deinit {
        munlock(base, bytes)
        munmap(base, bytes)
    }

    /// The weight cache file in `folder` (XNNPACK's `.xnnpack_cache`, the
    /// newest if more), locked, or why it could not be.
    static func lock(in folder: URL) -> Result<WeightCacheLock, Failure> {
        let keys: [URLResourceKey] = [.contentModificationDateKey]
        let files = ((try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: keys)) ?? [])
            .filter { $0.pathExtension == "xnnpack_cache" }
        func modified(_ url: URL) -> Date {
            (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
        }
        guard let file = files.max(by: { modified($0) < modified($1) }) else { return .failure(.noFile) }
        let start = Date()
        let descriptor = open(file.path, O_RDONLY)
        guard descriptor >= 0 else { return .failure(.system("open", errno)) }
        defer { close(descriptor) }
        var info = stat()
        guard fstat(descriptor, &info) == 0 else { return .failure(.system("fstat", errno)) }
        let bytes = Int(info.st_size)
        guard bytes > 0 else { return .failure(.noFile) }
        // The soft limit may be below the hard one; the hard one stays.
        var limit = rlimit()
        if getrlimit(RLIMIT_MEMLOCK, &limit) == 0, limit.rlim_cur < limit.rlim_max {
            limit.rlim_cur = limit.rlim_max
            setrlimit(RLIMIT_MEMLOCK, &limit)
        }
        guard let base = mmap(nil, bytes, PROT_READ, MAP_SHARED, descriptor, 0), base != MAP_FAILED else {
            return .failure(.system("mmap", errno))
        }
        guard mlock(base, bytes) == 0 else {
            let code = errno
            munmap(base, bytes)
            return .failure(.system("mlock", code))
        }
        return .success(WeightCacheLock(base: base, bytes: bytes, seconds: Date().timeIntervalSince(start)))
    }

    enum Failure: Error, Equatable {
        case noFile
        case system(String, Int32)

        var label: String {
            switch self {
            case .noFile: "no cache file"
            case .system(let call, let code): "\(call) errno \(code) (\(String(cString: strerror(code))))"
            }
        }
    }

    /// For the diagnostics: what was locked, or why not.
    static func label(_ result: Result<WeightCacheLock, Failure>) -> String {
        switch result {
        case .success(let lock): String(format: "locked %.2f GB in %.1f s", Double(lock.bytes) / 1_000_000_000, lock.seconds)
        case .failure(let failure): "not locked: " + failure.label
        }
    }
}
