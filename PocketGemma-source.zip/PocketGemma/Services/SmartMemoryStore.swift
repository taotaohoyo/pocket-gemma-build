import Foundation
import PocketCore

/// Smart Memory's search (1.1.0 (251)), off the main thread: the index of
/// the saved exchanges (SmartMemoryIndex), in memory only, brought to the
/// conversations as they are before each search, so a deleted conversation
/// is never found. Nothing here is written to disk, and nothing leaves the
/// phone. With Smart Memory off the index is let go.
actor SmartMemoryStore {
    static let shared = SmartMemoryStore()
    private var index = SmartMemoryIndex()

    /// One question's search: the conversations as saved when it was sent,
    /// the turns the model gets anyway, and its input's room.
    struct Ask: Sendable {
        let question: String
        let threads: [ChatThread]
        let history: [ChatMessage]
        /// The question's own bytes: its text, notes and attachments.
        let cost: Int
        let inputByteBudget: Int
        let visualTokenBudget: Int
        /// How the turns and `cost` are measured (ContextMeasure, 1.1.0 (256)).
        var measure: ContextMeasure = .utf8
        /// Messages never to recall: the turns given and the question.
        var excluding: Set<UUID> { Set(history.map(\.id)) }
    }

    struct Recalled: Sendable {
        /// The turns to give, the oldest left out where the recalled
        /// exchanges needed their room (SmartMemoryFit).
        let history: [ChatMessage]
        let note: SmartMemoryNote
        /// For the diagnostics: the search's time and the index's size.
        let summary: String
        /// The person's messages of the exchanges left out for the note,
        /// and the questions the note quotes.
        var dropped: [ChatMessage] = []
        var recalledQuestions: Set<UUID> = []

        /// The person's earlier messages to keep in view (EarlierNote):
        /// those the history left out (`planned`) and those left out here,
        /// less the ones the note already quotes with their replies.
        func earlier(_ planned: [ChatMessage]) -> [ChatMessage] {
            (planned + dropped).filter { !recalledQuestions.contains($0.id) }
        }
    }

    /// Builds the index in advance (at launch, or when the switch is
    /// turned on), so the first question does not wait for it.
    func warm(_ threads: [ChatThread]) {
        guard SmartMemory.isOn else { return }
        index.sync(threads)
    }

    func clear() { index = SmartMemoryIndex() }

    func recall(_ ask: Ask) -> Recalled? {
        // Turned off meanwhile: nothing is searched.
        guard SmartMemory.isOn else { index = SmartMemoryIndex(); return nil }
        let start = Date()
        index.sync(ask.threads)
        let hits = index.search(ask.question, excluding: ask.excluding)
        guard !hits.isEmpty else { return nil }
        let plan = SmartMemoryFit.plan(history: ask.history, cost: ask.cost, inputByteBudget: ask.inputByteBudget,
                                       visualTokenBudget: ask.visualTokenBudget, measure: ask.measure, question: ask.question)
        guard plan.memoryBytes > 0,
              let note = SmartMemoryFit.fitting(hits, threads: ask.threads, question: ask.question, room: plan.memoryBytes,
                                                measure: ask.measure)
        else { return nil }
        let milliseconds = Int(Date().timeIntervalSince(start) * 1000)
        let summary = "\(note.sources.count)件 · \(note.text.utf8.count) B · \(milliseconds) ms · 索引 \(index.documentCount)組"
            + (plan.history.count < ask.history.count ? " · 古いやりとり\((ask.history.count - plan.history.count) / 2)組を外した" : "")
            + (plan.shortened ? " · 最新のやりとりを抜粋にした" : "")
        let quoted = Set(note.sources.map(\.message))
        return Recalled(history: plan.history, note: note, summary: summary,
                        dropped: ask.history.prefix(ask.history.count - plan.history.count).filter { $0.role == .user },
                        recalledQuestions: Set(hits.filter { quoted.contains($0.reply) }.map(\.question)))
    }

    /// The search, or nothing once `SmartMemory.searchTimeout` has passed:
    /// a question never waits longer for it. A search failing or finding
    /// nothing leaves the question as it would be without Smart Memory.
    static func recall(_ ask: Ask) async -> Recalled? {
        await withCheckedContinuation { continuation in
            let once = Once()
            Task.detached(priority: .userInitiated) {
                let found = await shared.recall(ask)
                if once.claim() { continuation.resume(returning: found) }
            }
            Task.detached {
                try? await Task.sleep(for: SmartMemory.searchTimeout)
                if once.claim() { continuation.resume(returning: nil) }
            }
        }
    }

    /// The first of the two to finish answers; the other is ignored.
    private final class Once: @unchecked Sendable {
        private let lock = NSLock()
        private var claimed = false
        func claim() -> Bool {
            lock.lock(); defer { lock.unlock() }
            if claimed { return false }
            claimed = true
            return true
        }
    }
}
