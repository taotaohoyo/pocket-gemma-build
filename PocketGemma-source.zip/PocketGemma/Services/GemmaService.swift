import Foundation
import LiteRTLM
import PocketCore
import os
import ImageIO

actor GemmaService {
    private var engine: Engine?
    private var enginePlan: InferenceEnginePlan?
    private var rebuildRequired = false
    private var diagnostic: InferenceDiagnostic?
    private var conversation: Conversation?
    private var running = false
    private var cancelRequested = false
    private var context = ConversationContext()
    private var conversationSettings: GenerationSettings?

    enum Stage: String, Sendable {
        case loading = "モデルを読み込んでいます…"
        case preparing = "会話を準備しています…"
        case waiting = "返信を考えています…"
        case continuing = "回答の続きを準備しています…"
    }

    func generate(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                  settings: GenerationSettings, attachments: [ChatAttachment],
                  onStage: @escaping @Sendable (Stage) async -> Void,
                  onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer {
            running = false
        }
        let settings = settings.normalized(for: spec)
        let attachmentPolicy = ModelAttachmentPolicy(model: spec)
        try attachmentPolicy.validateNewAttachments(attachments)
        let history = attachmentPolicy.inferenceHistory(history)
        let images = (attachments + history.flatMap(\.media)).reduce(0) { $0 + $1.imageNames.count }
        let plan = InferenceEnginePlan(model: spec, settings: settings, needsVision: images > 0)
        diagnostic = InferenceDiagnostic(plan: plan, imageCount: images, settings: settings, previous: diagnostic)
        diagnostic?.inputPath = "application_attachment_image_file"
        diagnostic?.inputImageDimensions = (attachments + history.flatMap(\.media)).flatMap(\.imageNames).prefix(4).compactMap { name in
            guard let url = AttachmentStorage.url(name), let source = CGImageSourceCreateWithURL(url as CFURL, nil),
                  let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
                  let width = properties[kCGImagePropertyPixelWidth] as? Int,
                  let height = properties[kCGImagePropertyPixelHeight] as? Int else { return nil }
            return "\(width)x\(height)"
        }
        diagnostic?.advance("validation")
        try await recordOutcome(nativeLog: NativeLogCapture(includeInfo: images > 0)) {
            try await perform(threadID: threadID, prompt: prompt, history: history, model: spec,
                settings: settings, attachments: attachments, plan: plan, resuming: nil, onStage: onStage, onText: onText)
        }
    }

    /// Carries on a reply that was stopped partway, such as by leaving the
    /// app: the GPU can't decode in the background.
    func continueReply(threadID: UUID, prompt: String, reply: String, model spec: ModelSpec,
                       settings: GenerationSettings,
                       onStage: @escaping @Sendable (Stage) async -> Void,
                       onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer { running = false }
        let settings = settings.normalized(for: spec)
        let plan = InferenceEnginePlan(model: spec, settings: settings, needsVision: false)
        diagnostic = InferenceDiagnostic(plan: plan, imageCount: 0, settings: settings, previous: diagnostic)
        diagnostic?.advance("validation")
        try await recordOutcome(nativeLog: NativeLogCapture(includeInfo: false)) {
            try await perform(threadID: threadID, prompt: prompt, history: [], model: spec, settings: settings,
                attachments: [], plan: plan, resuming: reply, onStage: onStage, onText: onText)
        }
    }

    private func recordOutcome(nativeLog: NativeLogCapture?, _ body: () async throws -> Void) async throws {
        let memory = InferenceMemoryCapture()
        defer { _ = nativeLog?.finish() }
        do {
            try await body()
            diagnostic?.result = "success"
            diagnostic?.recordNativeLog(nativeLog?.finish())
            diagnostic?.recordMemory(memory.finish())
            diagnostic?.advance("complete")
        } catch {
            context.invalidate()
            // Keep native objects alive through the final C callback; release
            // them on the next request, outside that callback's stack.
            rebuildRequired = true
            diagnostic?.result = error is CancellationError || cancelRequested ? "cancelled" : "failed"
            diagnostic?.failureKind = NativeFailureKind(description: error.localizedDescription)
            let nativeError = InferenceDiagnostic.sanitize(error.localizedDescription)
            diagnostic?.nativeError = nativeError
            diagnostic?.recordNativeLog(nativeLog?.finish(), error: nativeError)
            diagnostic?.recordMemory(memory.finish())
            diagnostic?.availableMemoryAtFailure = UInt64(os_proc_available_memory())
            diagnostic?.save()
            if error is CancellationError || cancelRequested { throw CancellationError() }
            throw InferenceFailure(stage: diagnostic?.stage ?? "unknown", cause: error)
        }
    }

    private func perform(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                         settings: GenerationSettings, attachments: [ChatAttachment], plan: InferenceEnginePlan,
                         resuming partial: String?,
                         onStage: @escaping @Sendable (Stage) async -> Void,
                         onText: @escaping @Sendable (String) async -> Void) async throws {
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        let needsVision = plan.visionBackend != nil
        diagnostic?.engineWasReused = engine != nil && enginePlan == plan && !rebuildRequired
        if needsVision && !spec.supportsVision { throw ServiceError.visionUnsupported }
        if engine == nil || enginePlan != plan || rebuildRequired {
            await onStage(.loading)
            conversation = nil
            context.invalidate()
            engine = nil
            enginePlan = nil
            let cache = AppFiles.root.appendingPathComponent("InferenceCache", isDirectory: true)
                .appendingPathComponent(plan.cacheComponent, isDirectory: true)
            try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
            let config = try EngineConfig(modelPath: AppFiles.model(spec).path,
                backend: plan.backend == .gpu ? .gpu : .cpu(),
                visionBackend: plan.visionBackend.map { $0 == .gpu ? .gpu : .cpu() },
                maxNumTokens: settings.maxTokens, cacheDir: cache.path,
                visionCpuKernelMode: plan.visionCPUImplementation == .builtin ? .builtin : .xnnpack)
            let newEngine = Engine(engineConfig: config)
            // The app has one inference service and serializes its requests.
            // These SDK flags are process-global and must be set before the
            // Engine actor allocates encoder/adapter signatures, not just on
            // ConversationConfig. Clearing nil on text turns avoids inheritance.
            ExperimentalFlags.optIntoExperimentalAPIs()
            ExperimentalFlags.visualTokenBudget = plan.visualTokenBudget.map(Int32.init)
            ExperimentalFlags.enableSpeculativeDecoding = plan.speculativeDecoding
            diagnostic?.advance("engine_initialization")
            // The SDK owns a separate Engine actor. Await it so this service
            // can still receive stop/timeout requests during initialization.
            try await newEngine.initialize()
            if cancelRequested { throw CancellationError() }
            engine = newEngine
            enginePlan = plan
            rebuildRequired = false
            conversationSettings = nil
        }
        guard let engine else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        // A message that asks for a chart carries the chart format's note to
        // the model, this turn only; the chat keeps the message as written.
        let guide = RichFormatGuide.guide(for: prompt)
        var reuse = false
        if partial == nil, let conversation, conversationSettings == settings, context.canReuse(threadID: threadID, history: history) {
            // Keep the reply's reserved space free after this turn's input too.
            let incoming = (prompt.utf8.count + (guide?.utf8.count ?? 0) + attachments.reduce(0) {
                $0 + $1.contextByteCost(visualTokenBudget: settings.visualTokenBudget) }) / 2
            reuse = try conversation.getTokenCount() + incoming
                < settings.maxTokens - settings.maxOutputTokens - settings.reservedTokens
        }
        if partial == nil && !reuse {
            await onStage(.preparing)
            diagnostic?.advance("conversation_creation")
            // The previous completed stream's conversation stays alive between
            // turns. Release it here, rather than inside its final C callback.
            conversation = nil
            context.invalidate()
            let initialMessages = try history.map { message in
                try nativeMessage(text: message.text, attachments: message.media,
                                  role: message.role == .user ? .user : .model)
            }
            let config = ConversationConfig(
                systemMessage: Message(settings.systemPrompt, role: .system),
                initialMessages: initialMessages,
                samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
                thinkingConfig: ThinkingConfig(enableThinking: settings.enableThinking,
                    thinkingTokenBudget: settings.enableThinking ? min(1024, settings.maxOutputTokens / 2) : 0),
                automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
                enableSpeculativeDecoding: settings.enableSpeculativeDecoding)
            conversation = try await engine.createConversation(with: config)
            conversationSettings = settings
        }
        diagnostic?.conversationWasReused = reuse
        if partial == nil && conversation == nil { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        if partial == nil {
            await onStage(.waiting)
            diagnostic?.advance(needsVision ? "image_prefill" : "text_generation")
        }
        var reply = partial ?? ""
        var rounds = 0, retries = 0
        do {
            var message: Message? = try partial == nil ? nativeMessage(text: prompt, attachments: attachments, note: guide) : nil
            while true {
                if message == nil {
                    if retries == 0 { rounds += 1 }
                    await onStage(.continuing)
                    diagnostic?.advance("reply_continuation")
                    let request = ReplyContinuation.request(prompt: prompt, reply: reply, settings: settings)
                    try await replaceConversation(on: engine, with: continuationConfig(request, settings: settings))
                    message = Message(request.instruction)
                }
                guard let active = conversation, let next = message else { throw ServiceError.modelMissing }
                message = nil
                // The reply's only limit is the context window: a fixed output
                // cap cut long answers off mid-sentence.
                let streamed = try await stream(next, on: active, maxOutputTokens: settings.maxTokens,
                                                continuing: rounds > 0 ? reply : nil, onText: onText)
                if cancelRequested { throw CancellationError() }
                guard let part = streamed else {
                    // Ask again; the model samples a new opening each time.
                    diagnostic?.advance("reply_continuation_dropped")
                    guard retries < ReplyContinuation.maximumRetries else { break }
                    retries += 1
                    continue
                }
                retries = 0
                reply += part
                guard rounds < ReplyContinuation.maximumRounds, !part.isEmpty,
                      ReplyContinuation.filledContext(tokenCount: (try? active.getTokenCount()) ?? 0, maxTokens: settings.maxTokens)
                else { break }
            }
            guard !reply.isEmpty else { throw ServiceError.emptyReply }
            if rounds == 0 {
                context.completeTurn(threadID: threadID, history: history, prompt: prompt, reply: reply, attachments: attachments)
            } else {
                // The continued conversation holds only the reply's tail.
                context.invalidate()
            }
        } catch {
            context.invalidate()
            try? conversation?.cancel()
            throw error
        }
    }

    /// Streams one model turn. A continuation's opening is held back until it
    /// can be trimmed of what the reply already says; one that apologises or
    /// starts over is cancelled unseen, and the result is nil.
    private func stream(_ message: Message, on active: Conversation, maxOutputTokens: Int, continuing reply: String?,
                        onText: @escaping @Sendable (String) async -> Void) async throws -> String? {
        // The SDK starts inference synchronously, so keep startup off this actor.
        let stream = await Task.detached(priority: .userInitiated) {
            active.sendMessageStream(message, maxOutputTokens: maxOutputTokens)
        }.value
        var part = ""
        var held = reply.map { _ in "" }
        var dropped = false
        do {
            for try await chunk in stream {
                // Drain the native stream after cancellation, keeping the engine
                // alive until its final callback before permitting another request.
                if cancelRequested || dropped { continue }
                let text = chunk.toString
                guard !text.isEmpty else { continue }
                if reply == nil && part.isEmpty { diagnostic?.advance("decode") }
                if let pending = held.map({ $0 + text }), let reply {
                    guard ReplyContinuation.canCheck(pending, after: reply) else { held = pending; continue }
                    held = nil
                    let trimmed = ReplyContinuation.trimmedStart(of: pending, after: reply)
                    if ReplyContinuation.rejects(trimmed, after: reply) {
                        dropped = true
                        try? active.cancel()
                        continue
                    }
                    part += trimmed
                    if !trimmed.isEmpty { await onText(trimmed) }
                } else {
                    part += text
                    await onText(text)
                }
            }
        } catch where dropped {
            // The cancelled continuation's own end; the reply goes on without it.
        }
        if dropped { return nil }
        if let pending = held, let reply, !cancelRequested {
            let trimmed = ReplyContinuation.trimmedStart(of: pending, after: reply)
            if ReplyContinuation.rejects(trimmed, after: reply) { return nil }
            part += trimmed
            if !trimmed.isEmpty { await onText(trimmed) }
        }
        return part
    }

    private func continuationConfig(_ request: ReplyContinuation.Request, settings: GenerationSettings) throws -> ConversationConfig {
        ConversationConfig(
            systemMessage: Message(settings.systemPrompt, role: .system),
            initialMessages: [Message(request.question, role: .user), Message(request.tail, role: .model)],
            samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
            enableSpeculativeDecoding: settings.enableSpeculativeDecoding)
    }

    private func replaceConversation(on engine: Engine, with config: ConversationConfig) async throws {
        // A finished stream holds its conversation until the final native
        // callback returns, and a conversation released inside that callback
        // waits on itself. Let the callback return before releasing ours.
        try await Task.sleep(for: .milliseconds(200))
        conversation = nil
        conversation = try await engine.createConversation(with: config)
        if cancelRequested { throw CancellationError() }
    }

    private func nativeMessage(text: String, attachments: [ChatAttachment], role: Role = .user, note: String? = nil) throws -> Message {
        var contents: [Content] = []
        for attachment in attachments {
            if let body = attachment.extractedText {
                contents.append(.text("\n添付ファイル: \(attachment.name)\n以下はファイルの内容です。\n\(body)"))
            }
            if attachment.kind == .video {
                contents.append(.text("\n動画 \(attachment.name) の開始・中間・終了付近の代表フレームです。音声は含みません。"))
            }
            for name in attachment.imageNames {
                guard let url = AttachmentStorage.url(name), FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
                contents.append(.imageFile(url.path))
            }
        }
        contents.append(.text(text))
        if let note { contents.append(.text("\n\n" + note)) }
        return Message(contents: contents, role: role)
    }

    func cancel() {
        guard running else { return }
        cancelRequested = true
        context.invalidate()
        try? conversation?.cancel()
    }

    func runVisionProbe(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                        vision: ExecutionBackend, kernel: VisionCPUImplementation = .xnnpack) async throws -> String {
        guard !running else { throw ServiceError.busy }
        // Release the chat's language engine before the component-only test.
        // The next normal message rebuilds the original saved configuration.
        unload()
        running = true
        defer { running = false }
        return try await VisionDiagnosticRunner.run(model: model, kind: kind, main: main, vision: vision, kernel: kernel)
    }

    func unload() {
        guard !running else { return }
        conversation = nil
        context.invalidate()
        engine = nil
        enginePlan = nil
        rebuildRequired = false
        conversationSettings = nil
    }
}

private struct InferenceFailure: LocalizedError {
    let stage: String
    let cause: Error
    var errorDescription: String? {
        let detail = cause.localizedDescription
        // A failed load can keep its address space until relaunch; say so
        // instead of suggesting another model that would fail the same way.
        let hint = detail.contains("Cannot allocate memory")
            ? "\nアプリが扱えるメモリ領域が不足しています。アプリを一度完全に終了してから開き直してください。" : ""
        return "処理段階: \(stage)\n\(detail)" + hint
    }
}

private enum ServiceError: LocalizedError {
    case busy, modelMissing, visionUnsupported, attachmentMissing, emptyReply
    var errorDescription: String? {
        switch self {
        case .busy: return "前の回答が終了するまでお待ちください。"
        case .modelMissing: return "この会話のモデルをダウンロードするか、対応するファイルを取り込んでください。"
        case .visionUnsupported: return "このモデルは画像・動画に対応していません。Gemma 4を選んでください。"
        case .attachmentMissing: return "保存した添付ファイルが見つかりません。もう一度添付してください。"
        case .emptyReply: return "推論は終了しましたが、モデルからテキスト回答が届きませんでした。"
        }
    }
}

