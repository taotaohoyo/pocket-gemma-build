import Foundation
import LiteRTLM
import PocketCore
import os
import ImageIO

actor GemmaService {
    private var engine: Engine?
    private var enginePlan: InferenceEnginePlan?
    /// The engine's CPU weight cache, locked in memory, for the models that
    /// ask (ModelCapabilities.locksCPUWeights); released with the engine.
    private var weightLock: WeightCacheLock?
    private var weightLockNote: String?
    /// Conversations started on the engine (ModelCapabilities.oneConversationPerEngine).
    private var conversationsOnEngine = 0
    private var rebuildRequired = false
    private var diagnostic: InferenceDiagnostic?
    private var conversation: Conversation?
    private var running = false
    private var cancelRequested = false
    private var context = ConversationContext()
    private var conversationSettings: GenerationSettings?
    /// The plan and settings the context's turns were run with; its turns
    /// outlive an unload, and a conversation rebuilt with the same ones may
    /// take them back (`ConversationContext.heldHistory`).
    private var contextPlan: InferenceEnginePlan?
    private var contextSettings: GenerationSettings?
    /// Whether the live conversation declares the web search tool: its
    /// declaration is part of the system turn, so turning search on or off
    /// starts the conversation again.
    private var conversationSearches = false
    /// The reply's searches while it streams, for stop.
    private var activeSearch: WebSearchTurn?
    /// Native probes only (`dropSearchedRepliesForProbe`).
    private var dropsSearchedReply = false
    /// The last stream stopped a reply written after a search in another
    /// language than the question's (WebSearch.replyIsIn).
    private var wroteOtherLanguage = false
    /// Native probes only (`keepOpenTurnForProbe`): the last open turn's
    /// rendered question, to print the model's turn markers.
    private var keepsOpenTurn = false
    private(set) var openTurnQuestionForProbe: String?
    /// Native probes only (`useSystemMessageForProbe`).
    private var probeSystemMessage: String?
    /// Native probes only (`capRepliesForProbe`).
    private var probeReplyTokens: Int?
    /// Native probes only (`useSearchNoteForProbe`).
    private var probeSearchNote: String?
    /// Native probes only (`useChartNoteForProbe`).
    private var probeChartNote: (@Sendable (String) -> String?)?
    /// Native probes only (`countPrefillsForProbe`).
    private var probeBenchmark = false
    /// Native probes only (`keepGivenTurnsForProbe`): the turns given are
    /// set up as given, as before 1.1.0 (256), not fitted to the room, and
    /// never retried with fewer.
    private var probeKeepsTurns = false
    /// Native probes only: how the last conversation set up again was filled.
    private(set) var lastContextFillForProbe: ContextFill?
    /// LFM3's engine on llama.cpp (1.1.0 (232)); a LiteRT-LM model's start
    /// releases it, and its start releases LiteRT-LM's.
    private var llama: LlamaReply?
    /// The last LFM3 reply failed: the next one loads the model again.
    private var llamaFailed = false

    enum Stage: String, Sendable {
        case loading = "モデルを読み込んでいます…"
        case preparing = "会話を準備しています…"
        case waiting = "返信を考えています…"
        /// Sent again about once a second while the model thinks, whose
        /// thoughts are never shown: each shows the reply is still coming.
        case thinking = "じっくり考えています…"
        case continuing = "返信の続きを準備しています…"
        /// A video's sound written down, a part at a time (VideoAnalysis).
        case listening = "動画の音声を書き起こしています…"
        /// A video's scenes described, a few at a time.
        case watching = "動画の場面を見ています…"
        /// A long video's speech condensed to fit the reply.
        case condensing = "動画の話をまとめています…"
    }

    /// `webSearch` is the reply's search turn when the chat searches
    /// (WebSearchPolicy): the model gets the web search tool and may call it.
    /// Without it the conversation is the same as before search existed.
    /// A video not yet analyzed is analyzed first (`analyze`); `onVideo`
    /// gets its analysis after each step, to keep with the message.
    /// `memory`: the earlier exchanges Smart Memory found for the question
    /// (1.1.0 (251)), quoted before it in the person's turn; nil without.
    /// `earlier`: the person's messages of this chat whose exchanges the
    /// history leaves out (ContextPlan.earlier, 1.1.0 (256)), for the note
    /// that keeps their words when the conversation is set up again.
    func generate(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                  settings: GenerationSettings, attachments: [ChatAttachment], webSearch: WebSearchTurn? = nil,
                  background: String? = nil, readsLess: Bool = false,
                  memory: SmartMemoryNote? = nil, memorySummary: String? = nil, earlier: [ChatMessage] = [],
                  onStage: @escaping @Sendable (Stage) async -> Void,
                  onVideo: (@Sendable (UUID, VideoAnalysis) async -> Void)? = nil,
                  onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer {
            running = false
        }
        let settings = settings.normalized(for: spec)
        let attachmentPolicy = ModelAttachmentPolicy(model: spec)
        try attachmentPolicy.validateNewAttachments(attachments)
        let history = attachmentPolicy.inferenceHistory(history)
        let images = (attachments + history.flatMap(\.media)).reduce(0) { $0 + $1.modelImageNames(settings).count }
        let plan = InferenceEnginePlan(model: spec, settings: settings, needsVision: images > 0)
        diagnostic = InferenceDiagnostic(plan: plan, imageCount: images, settings: settings, previous: diagnostic)
        diagnostic?.background = background
        diagnostic?.smartMemory = memorySummary
        diagnostic?.inputPath = "application_attachment_image_file"
        diagnostic?.inputImageDimensions = (attachments + history.flatMap(\.media)).flatMap(\.imageNames).prefix(4).compactMap { name in
            guard let url = AttachmentStorage.url(name), let source = CGImageSourceCreateWithURL(url as CFURL, nil),
                  let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
                  let width = properties[kCGImagePropertyPixelWidth] as? Int,
                  let height = properties[kCGImagePropertyPixelHeight] as? Int else { return nil }
            return "\(width)x\(height)"
        }
        diagnostic?.advance("validation")
        var attachments = attachments
        try await recordOutcome(nativeLog: NativeLogCapture(includeInfo: images > 0),
                                fastDrafter: plan.speculativeDecoding && !settings.enableSpeculativeDecoding) {
            if spec.runtime == .llamaCpp {
                try await performLlama(prompt: prompt, history: history, attachments: attachments, model: spec,
                                       settings: settings, plan: plan, resuming: nil, readsLess: readsLess,
                                       memory: memory, onStage: onStage, onText: onText)
                return
            }
            for index in attachments.indices where attachments[index].video.map({ !$0.isComplete || self.needsSummaries($0, settings) }) == true {
                attachments[index] = try await analyze(attachments[index], plan: plan, model: spec, settings: settings,
                                                       onStage: onStage, onVideo: onVideo)
            }
            try await perform(threadID: threadID, prompt: prompt, history: history, model: spec,
                settings: settings, attachments: attachments, plan: plan, resuming: nil, readsLess: readsLess,
                webSearch: spec.supportsWebSearch ? webSearch : nil, memory: memory, earlier: earlier,
                onStage: onStage, onText: onText)
        }
    }

    /// Carries on a reply that was stopped partway, such as by leaving the
    /// app: the GPU can't decode in the background. The model gets its own
    /// unfinished turn back and writes on from the reply's last character
    /// (OpenTurn). `background` says, for the diagnostics, why and where it
    /// goes on, such as on the CPU after the app left the screen; there
    /// `readsLess` gives back less of the reply (BackgroundRead).
    func continueReply(threadID: UUID, prompt: String, reply: String, model spec: ModelSpec,
                       settings: GenerationSettings, background: String? = nil, readsLess: Bool = false,
                       onStage: @escaping @Sendable (Stage) async -> Void,
                       onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !running else { throw ServiceError.busy }
        running = true
        cancelRequested = false
        defer { running = false }
        let settings = settings.normalized(for: spec)
        let plan = InferenceEnginePlan(model: spec, settings: settings, needsVision: false)
        diagnostic = InferenceDiagnostic(plan: plan, imageCount: 0, settings: settings, previous: diagnostic)
        diagnostic?.background = background
        diagnostic?.advance("validation")
        try await recordOutcome(nativeLog: NativeLogCapture(includeInfo: false),
                                fastDrafter: plan.speculativeDecoding && !settings.enableSpeculativeDecoding) {
            if spec.runtime == .llamaCpp {
                try await performLlama(prompt: prompt, history: [], attachments: [], model: spec, settings: settings,
                                       plan: plan, resuming: reply, readsLess: readsLess, onStage: onStage, onText: onText)
                return
            }
            try await perform(threadID: threadID, prompt: prompt, history: [], model: spec, settings: settings,
                attachments: [], plan: plan, resuming: reply, readsLess: readsLess, webSearch: nil,
                onStage: onStage, onText: onText)
        }
    }

    private func recordOutcome(nativeLog: NativeLogCapture?, fastDrafter: Bool,
                               _ body: () async throws -> Void) async throws {
        let memory = InferenceMemoryCapture()
        defer { _ = nativeLog?.finish() }
        do {
            try await body()
            diagnostic?.result = "success"
            diagnostic?.recordNativeLog(nativeLog?.finish())
            diagnostic?.recordMemory(memory.finish())
            diagnostic?.advance("complete")
        } catch {
            context.invalidate()
            // Keep native objects alive through the final C callback; release
            // them on the next request, outside that callback's stack.
            rebuildRequired = true
            diagnostic?.result = error is CancellationError || cancelRequested ? "cancelled" : "failed"
            diagnostic?.failureKind = NativeFailureKind(description: error.localizedDescription)
            let nativeError = InferenceDiagnostic.sanitize(error.localizedDescription)
            diagnostic?.nativeError = nativeError
            diagnostic?.recordNativeLog(nativeLog?.finish(), error: nativeError)
            diagnostic?.recordMemory(memory.finish())
            diagnostic?.availableMemoryAtFailure = UInt64(os_proc_available_memory())
            diagnostic?.recordFailureAddressSpace()
            diagnostic?.save()
            if error is CancellationError || cancelRequested { throw CancellationError() }
            throw InferenceFailure(stage: diagnostic?.stage ?? "unknown", cause: error,
                                   photoOnE4B: diagnostic?.modelID == ModelSpec.e4b.id && (diagnostic?.imageCount ?? 0) > 0,
                                   fastDrafter: fastDrafter)
        }
    }

    private func perform(threadID: UUID, prompt: String, history: [ChatMessage], model spec: ModelSpec,
                         settings: GenerationSettings, attachments: [ChatAttachment], plan: InferenceEnginePlan,
                         resuming partial: String?, readsLess: Bool = false, webSearch: WebSearchTurn?,
                         memory: SmartMemoryNote? = nil, earlier: [ChatMessage] = [],
                         onStage: @escaping @Sendable (Stage) async -> Void,
                         onText: @escaping @Sendable (String) async -> Void) async throws {
        // A locked model (12B before its unlock) never runs in a chat,
        // whatever reached here.
        guard !spec.isLocked else { throw ServiceError.modelLocked }
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        let needsVision = plan.visionBackend != nil
        // A message that asks for a chart carries the chart format's note to
        // the model, this turn only; the chat keeps the message as written.
        let guide = probeChartNote.map { $0(prompt) } ?? RichFormatGuide.guide(for: prompt)
        // Keep the reply's reserved space free after this turn's input too.
        // A turn that may search keeps room for the results it reads.
        let searches = webSearch != nil
        // Gemma's words are counted closer to its tokens (ContextMeasure,
        // 1.1.0 (256)); other models' as before, two bytes a token.
        let measure = ContextMeasure.of(spec)
        let attachmentCost = attachments.reduce(0) { $0 + $1.contextByteCost(settings) }
        let incoming = (measure == .gemma
            ? measure.tokens(prompt) + measure.tokens(guide ?? "") + measure.tokens(memory?.text ?? "") + attachmentCost / 2
                + GemmaTokens.perTurn
            : (prompt.utf8.count + (guide?.utf8.count ?? 0) + (memory?.text.utf8.count ?? 0) + attachmentCost) / 2)
            + (searches ? WebSearch.reservedTokens : 0)
        let inputLimit = settings.inputTokenLimit
        // Qwen3.5 starts each new conversation on an engine of its own
        // (ModelCapabilities.oneConversationPerEngine); a turn that goes on
        // in the live conversation keeps its engine.
        if spec.capabilities.oneConversationPerEngine, conversationsOnEngine > 0,
           try !(partial == nil && continuesConversation(threadID: threadID, history: history, settings: settings,
                                                         searches: searches, incoming: incoming)) {
            rebuildRequired = true
        }
        diagnostic?.engineWasReused = engine != nil && enginePlan == plan && !rebuildRequired
        if needsVision && !spec.supportsVision { throw ServiceError.visionUnsupported }
        try await prepareEngine(plan, model: spec, settings: settings, onStage: onStage)
        guard let engine else { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        lockWeights(plan, spec)
        var turns = history, reuse = false
        if partial == nil {
            reuse = try continuesConversation(threadID: threadID, history: history, settings: settings,
                                              searches: searches, incoming: incoming)
        }
        // 高速 asks for brief replies, and its engine may carry the MTP
        // drafter that its settings alone don't show (the plan).
        // じっくり考える asks for care and always thinks first; its
        // fallback (深く) does neither.
        let thinking = settings.thinkingTokenBudget(on: spec)
        // With search on, the system turn also declares the tool and
        // says when to use it, and gives today's date; off, the
        // conversation is as before.
        let system = systemMessage(settings, spec) + (searches ? "\n" + (probeSearchNote ?? WebSearch.systemNote(today: Date())) : "")
        func chatConfig(_ turns: [ChatMessage]) throws -> ConversationConfig {
            ConversationConfig(
                systemMessage: Message(system, role: .system),
                initialMessages: try nativeHistory(turns, settings: settings),
                tools: searches ? [WebSearchTool()] : [],
                samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
                thinkingConfig: ThinkingConfig(enableThinking: thinking > 0, thinkingTokenBudget: thinking),
                automaticToolCalling: searches, visualTokenBudget: Int32(settings.visualTokenBudget),
                enableSpeculativeDecoding: plan.speculativeDecoding)
        }
        var earlierNote: EarlierNote?, fill: ContextFill?
        lastContextFillForProbe = nil
        if partial == nil && !reuse {
            await onStage(.preparing)
            diagnostic?.advance("conversation_creation")
            // This chat's live conversation, set up again only because its
            // turns no longer leave room (the turn would go on in it otherwise).
            let filled = conversation != nil && conversationSettings == settings && conversationSearches == searches
                && context.canReuse(threadID: threadID, history: history)
            // The previous completed stream's conversation stays alive between
            // turns. Release it here, rather than inside its final C callback.
            conversation = nil
            // Released with the model, the conversation comes back with the
            // turns it held while they fit, not only what the estimate chose;
            // in the background on the CPU only the turns given (BackgroundRead).
            var held = false
            if !readsLess, contextSettings == settings,
               let kept = context.heldHistory(threadID: threadID, history: history, tokenLimit: inputLimit - incoming) {
                turns = kept
                held = true
            }
            context.invalidate()
            // Gemma (1.1.0 (256)): the turns chosen by estimate fit the room
            // the turn leaves, less the note of the person's earlier words
            // when there are any; after a conversation that filled up, two
            // thirds of it, so the next turns go on in the new one instead of
            // setting it up again each time. Turns the real count kept stay.
            if measure == .gemma && !readsLess {
                // The system turn is in the real count too.
                let room = max(0, inputLimit - incoming - measure.tokens(system) - GemmaTokens.perTurn) * 2
                let share = EarlierNote.share(inputByteBudget: settings.inputByteBudget)
                // The note's room, when there is one worth writing.
                let reserve = EarlierNote.build(earlier, question: prompt, budget: share, measure: measure, tag: "")
                    .map { measure.cost($0.text) + 16 } ?? 0
                var left = earlier
                if !held && !probeKeepsTurns {
                    (turns, left) = ContextPlanner.trimmed(turns, earlier: earlier, toBudget: (filled ? room * 2 / 3 : room) - reserve,
                                                           measure: measure, visualTokenBudget: settings.visualTokenBudget,
                                                           inputByteBudget: settings.inputByteBudget)
                }
                let given = Set(turns.filter { $0.role == .user }.map(\.text))
                let used = turns.reduce(0) { $0 + measure.cost($1, visualTokenBudget: settings.visualTokenBudget,
                                                               inputByteBudget: settings.inputByteBudget) }
                earlierNote = EarlierNote.build(left.filter { !given.contains($0.text) }, question: prompt,
                                                budget: min(share, room - used),
                                                measure: measure)
                fill = ContextFill(turns: turns.count / 2, pairs: turns.count / 2 + left.count,
                                   estimate: (used + measure.cost(earlierNote?.text ?? "")) / 2 + incoming
                                       - (searches ? WebSearch.reservedTokens : 0) + measure.tokens(system) + GemmaTokens.perTurn,
                                   earlier: earlierNote?.count ?? 0, filled: filled, held: held)
            }
            // The runtime's refusal of an input too long for its context, met
            // as the conversation is set up: half the turns, and no note.
            var refused = 0
            while true {
                do {
                    conversation = try await engine.createConversation(with: chatConfig(turns))
                    break
                } catch where measure == .gemma && refused < 2 && ContextOverflow.matches(error) && !cancelRequested && !probeKeepsTurns {
                    refused += 1
                    diagnostic?.advance("context_overflow_retry")
                    turns = Array(turns.suffix(turns.count / 2 / 2 * 2))
                    earlierNote = nil
                    fill?.overflowRetries = refused
                    fill?.turns = turns.count / 2
                    fill?.earlier = 0
                }
            }
            conversationsOnEngine += 1
            conversationSettings = settings
            conversationSearches = searches
        }
        diagnostic?.conversationWasReused = reuse
        if partial == nil && conversation == nil { throw ServiceError.modelMissing }
        if cancelRequested { throw CancellationError() }
        if partial == nil {
            await onStage(.waiting)
            diagnostic?.advance(needsVision ? "image_prefill" : "text_generation")
        }
        var reply = partial ?? ""
        var rounds = 0, retries = 0, looped = false, answeredAgain = false
        // The tool reaches this reply's searches while it streams. They
        // keep what the question names, and a follow-up the version the
        // person's last messages named (SearchTarget).
        webSearch?.focus = SearchTarget(question: prompt,
                                        earlier: history.reversed().filter { $0.role == .user }.prefix(2).map { String($0.text.prefix(2000)) })
        activeSearch = webSearch
        WebSearchTurn.active = webSearch
        webSearch?.observe { [weak self] stage in await self?.noteSearch(stage) }
        defer {
            WebSearchTurn.active = nil
            activeSearch = nil
        }
        // Smart Memory's tag never reaches the reply either.
        let tags = (attachments + history.flatMap(\.media)).filter { $0.extractedText != nil || $0.video != nil }
            .map(AttachmentPrompt.tag(for:)) + [memory?.tag, earlierNote?.tag].compactMap { $0 }
        do {
            // A question for the current state of things searches before it
            // answers: on 210 E4B answered 「今のchatGPTの最新モデルはなにー？」
            // from what it knew (1.1.0 (211)).
            let current = webSearch?.focus?.asksForCurrent == true ? WebSearch.currentNote : nil
            let notes = [guide, current].compactMap { $0 }
            var message: Message? = try partial == nil
                ? nativeMessage(text: prompt, attachments: attachments, settings: settings,
                                note: notes.isEmpty ? nil : notes.joined(separator: "\n\n"), memory: memory?.text,
                                earlier: earlierNote?.text)
                : nil
            // A Gemma conversation set up by estimate that the runtime finds
            // too long for its context is set up again with half its turns
            // and no note, at most twice (1.1.0 (256)).
            var overflowRetries = fill?.overflowRetries ?? 0
            // A reply stopped partway goes on in its own turn; asking for the
            // rest in a new turn is left for when that can't be set up, and
            // for replies that fill the context window.
            var openTurn = false
            if let partial, !partial.isEmpty {
                await onStage(.continuing)
                if let text = try await openTurnPrompt(prompt: prompt, reply: partial, settings: settings,
                                                       tailLimit: readsLess ? BackgroundRead.tailBytes : OpenTurn.tailBytes,
                                                       model: spec, plan: plan, on: engine) {
                    rounds = 1
                    openTurn = true
                    message = Message(text)
                }
            }
            while true {
                if message == nil {
                    if retries == 0 { rounds += 1 }
                    await onStage(.continuing)
                    diagnostic?.advance("reply_continuation")
                    let request = ReplyContinuation.request(prompt: prompt, reply: reply, settings: settings)
                    try await replaceConversation(on: engine, with: continuationConfig(request, settings: settings, model: spec, plan: plan))
                    message = Message(request.instruction)
                }
                guard let active = conversation, let next = message else { throw ServiceError.modelMissing }
                message = nil
                let dropping = dropsSearchedReply && webSearch != nil && rounds == 0 && !answeredAgain
                // The reply's only limit is the context window: a fixed output
                // cap cut long answers off mid-sentence.
                // The open turn's text goes on from the reply's last character,
                // so it is not held back to be trimmed.
                // The first answer after a search shows once its start is in
                // the question's language; one in another language (E4B
                // answered a Japanese question in English on 210) is written
                // again below.
                var checking: (language: String, searched: @Sendable () -> Bool)?
                if rounds == 0, !answeredAgain, let turn = webSearch, let language = turn.focus?.language {
                    checking = (language, { turn.hasSearched })
                }
                let streamed: String?
                do {
                    streamed = try await stream(next, on: active, maxOutputTokens: probeReplyTokens ?? settings.maxTokens,
                                                continuing: rounds > 0 && !openTurn ? reply : nil, hiding: tags,
                                                checking: checking,
                                                onThought: { await onStage(.thinking) }, onText: dropping ? { _ in } : onText)
                } catch where measure == .gemma && !reuse && rounds == 0 && reply.isEmpty && !answeredAgain
                    && overflowRetries < 2 && ContextOverflow.matches(error) && !cancelRequested && !probeKeepsTurns {
                    overflowRetries += 1
                    diagnostic?.advance("context_overflow_retry")
                    turns = Array(turns.suffix(turns.count / 2 / 2 * 2))
                    earlierNote = nil
                    fill?.overflowRetries = overflowRetries
                    fill?.turns = turns.count / 2
                    fill?.earlier = 0
                    try await replaceConversation(on: engine, with: chatConfig(turns))
                    message = try nativeMessage(text: prompt, attachments: attachments, settings: settings,
                                                note: notes.isEmpty ? nil : notes.joined(separator: "\n\n"), memory: memory?.text)
                    continue
                }
                openTurn = false
                if cancelRequested { throw CancellationError() }
                guard let part = streamed else {
                    // Ask again; the model samples a new opening each time.
                    diagnostic?.advance("reply_continuation_dropped")
                    guard retries < ReplyContinuation.maximumRetries else { break }
                    retries += 1
                    continue
                }
                retries = 0
                reply += dropping && (webSearch?.searches ?? 0) > 0 ? "" : part
                // On the phone E4B's 深く read a search's results and ended its
                // turn without a word (0.0.1 (131), 2026-10-23). The reply is
                // then written once more in a fresh conversation: the chat so
                // far, the question with the results quoted, and no tool. So
                // is one that began in another language (1.1.0 (211)), from
                // the pages found or, when none were, from that.
                let otherLanguage = wroteOtherLanguage
                wroteOtherLanguage = false
                if reply.isEmpty || otherLanguage, rounds == 0, !answeredAgain, let webSearch, webSearch.hasSearched {
                    let language = webSearch.focus?.language
                    let material = WebSearch.answerMaterial(webSearch.responses, language: language)
                        ?? WebSearch.noResultsMaterial(language: language)
                    answeredAgain = true
                    diagnostic?.advance(otherLanguage ? "web_search_answer_again_language" : "web_search_answer_again")
                    try await replaceConversation(on: engine, with: searchAnswerConfig(turns, settings: settings, model: spec, plan: plan))
                    message = try nativeMessage(text: prompt, attachments: attachments, settings: settings,
                                                note: [guide, material].compactMap { $0 }.joined(separator: "\n\n"))
                    continue
                }
                // A reply caught in a loop ends where it is: carried on, it
                // would only repeat itself for every round.
                if ReplyContinuation.isLooping(reply) {
                    looped = true
                    diagnostic?.advance("reply_loop_stopped")
                    break
                }
                guard rounds < ReplyContinuation.maximumRounds, !part.isEmpty,
                      ReplyContinuation.filledContext(tokenCount: (try? active.getTokenCount()) ?? 0, maxTokens: settings.maxTokens)
                else { break }
            }
            if let webSearch { diagnostic?.webSearches = webSearch.searches }
            guard !reply.isEmpty else { throw ServiceError.emptyReply }
            markCacheComplete()
            // With the stage times, how fast the reply was written; the
            // reply itself is not stored.
            diagnostic?.replyCharacters = reply.count
            if var fill {
                fill.tokens = try? conversation?.getTokenCount()
                diagnostic?.context = fill.summary
                lastContextFillForProbe = fill
            } else if reuse {
                diagnostic?.context = "前の会話を続けた" + ((try? conversation?.getTokenCount()).map { " · 実測 \($0)トークン" } ?? "")
            }
            if rounds == 0 && !looped {
                context.completeTurn(threadID: threadID, history: turns, prompt: prompt, reply: reply, attachments: attachments,
                                     tokens: (try? conversation?.getTokenCount()) ?? .max)
                contextPlan = plan
                contextSettings = settings
            } else {
                // The continued conversation holds only the reply's tail, and
                // a stopped loop leaves its turn unfinished.
                context.invalidate()
            }
        } catch {
            context.invalidate()
            try? conversation?.cancel()
            throw error
        }
    }

    /// The engine for `plan`, loaded unless it is the one in use.
    private func prepareEngine(_ plan: InferenceEnginePlan, model spec: ModelSpec, settings: GenerationSettings,
                               onStage: @escaping @Sendable (Stage) async -> Void) async throws {
        guard engine == nil || enginePlan != plan || rebuildRequired else { return }
        await onStage(.loading)
        conversation = nil
        if contextPlan != plan { context.invalidate() }
        engine = nil
        enginePlan = nil
        conversationsOnEngine = 0
        releaseWeights()
        llama = nil
        // Gemma 4 12B starts only with the room the developer 12B check
        // needed on the phone, read now that the previous model is released.
        if spec.id == ModelSpec.gemma12B.id {
            #if targetEnvironment(simulator)
            let available: UInt64? = nil
            #else
            let available: UInt64? = UInt64(os_proc_available_memory())
            #endif
            let blockers = LargeModelProbe.chatBlockers(largestFreeAddress: AddressSpace.current()?.largestFree,
                                                        availableMemory: available)
            if !blockers.isEmpty { throw ServiceError.noRoom(blockers.map(\.chatMessage).joined(separator: "\n")) }
            AppFiles.removeEngineCaches(spec, keeping: plan.cacheComponent)
        }
        let cache = Self.cacheFolder(plan)
        // 12B's cache is read only once a whole reply came from it
        // (`markCacheComplete`): a start the app never finished may leave
        // weights that read as other words. 1.1.0 (200)'s chats wrote
        // unrelated words and Bengali letters on the phone, while every
        // start from a fresh cache answered (201's comparison).
        if plan.gpuBenchmarkMode, !FileManager.default.fileExists(atPath: Self.completeMark(cache).path) {
            try? FileManager.default.removeItem(at: cache)
        }
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        let config = try EngineConfig(modelPath: AppFiles.model(spec).path,
            backend: plan.backend == .gpu ? .gpu : .cpu(),
            visionBackend: plan.visionBackend.map { $0 == .gpu ? .gpu : .cpu() },
            audioBackend: plan.audioBackend.map { $0 == .gpu ? .gpu : .cpu() },
            maxNumTokens: settings.maxTokens, cacheDir: cache.path,
            activationDataType: plan.gpuPrecision.activationDataType,
            visionCpuKernelMode: plan.visionCPUImplementation == .builtin ? .builtin : .xnnpack)
        let newEngine = Engine(engineConfig: config)
        // The app has one inference service and serializes its requests.
        // These SDK flags are process-global and must be set before the
        // Engine actor allocates encoder/adapter signatures, not just on
        // ConversationConfig. Clearing nil on text turns avoids inheritance.
        ExperimentalFlags.optIntoExperimentalAPIs()
        ExperimentalFlags.visualTokenBudget = plan.visualTokenBudget.map(Int32.init)
        ExperimentalFlags.enableSpeculativeDecoding = plan.speculativeDecoding
        // Read while the engine initializes (12B only, as the developer 12B
        // check started it); every other engine starts without it. Probes
        // that count prefills keep it on for the conversations too, where
        // the SDK reads it for getBenchmarkInfo.
        ExperimentalFlags.enableBenchmark = plan.gpuBenchmarkMode || probeBenchmark
        defer { ExperimentalFlags.enableBenchmark = probeBenchmark }
        diagnostic?.advance("engine_initialization")
        // The SDK owns a separate Engine actor. Await it so this service
        // can still receive stop/timeout requests during initialization.
        try await newEngine.initialize()
        if cancelRequested { throw CancellationError() }
        engine = newEngine
        enginePlan = plan
        rebuildRequired = false
        conversationSettings = nil
    }

    private static func cacheFolder(_ plan: InferenceEnginePlan) -> URL {
        AppFiles.root.appendingPathComponent("InferenceCache", isDirectory: true)
            .appendingPathComponent(plan.cacheComponent, isDirectory: true)
    }

    private static func completeMark(_ cache: URL) -> URL { cache.appendingPathComponent("pocketgemma-complete") }

    /// After a whole reply: the engine's cache is complete. 12B only (the
    /// plans in benchmark mode); every other model's cache is as before.
    private func markCacheComplete() {
        guard let enginePlan, enginePlan.gpuBenchmarkMode else { return }
        let mark = Self.completeMark(Self.cacheFolder(enginePlan))
        if !FileManager.default.fileExists(atPath: mark.path) { FileManager.default.createFile(atPath: mark.path, contents: nil) }
    }

    // MARK: Videos

    /// Whether a video's speech must still be condensed for the reply.
    private func needsSummaries(_ video: VideoAnalysis, _ settings: GenerationSettings) -> Bool {
        let allowance = VideoDigest.Allowance(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget)
        return video.summaries == nil && video.partsHeard > 0 && !VideoDigest.speechRoom(video, bytes: allowance.bytes).fits
    }

    /// Writes down a video's sound, describes its scenes and, when its
    /// speech is too long for the reply, condenses it (VideoAnalysis),
    /// passing the analysis on after each step (`onVideo`), so a reply
    /// stopped part-way goes on from there. The sound comes first, on an
    /// engine with the audio executor and no vision (InferenceEnginePlan
    /// `hearing`); then the scenes, on the reply's own engine, which the
    /// reply then uses. Each step is a conversation of its own, without
    /// the chat. Sound that can't be written down leaves the video without
    /// it, which the reply and the note say, rather than without a reply.
    private func analyze(_ attachment: ChatAttachment, plan: InferenceEnginePlan, model spec: ModelSpec,
                         settings: GenerationSettings, onStage: @escaping @Sendable (Stage) async -> Void,
                         onVideo: (@Sendable (UUID, VideoAnalysis) async -> Void)?) async throws -> ChatAttachment {
        guard var video = attachment.video else { return attachment }
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        // The chat's conversation is set aside; the reply starts its own.
        context.invalidate()
        conversation = nil
        conversationSettings = nil
        func keep() async { await onVideo?(attachment.id, video) }
        if video.soundPending && !VideoSound.hears(spec) {
            dropSound(&video, because: .memory)
            await keep()
        }
        if video.soundPending {
            do {
                try await prepareEngine(InferenceEnginePlan(model: spec, settings: settings, needsVision: false, hearing: true),
                                        model: spec, settings: settings, onStage: onStage)
                for index in video.parts.indices where video.parts[index].text == nil {
                    let part = video.parts[index]
                    guard let engine, let name = part.audio, let url = AttachmentStorage.url(name),
                          FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
                    await onStage(.listening)
                    diagnostic?.advance("video_sound")
                    let text = try await ask([.audioFile(url.path), .text(VideoDigest.transcribe)],
                                             maxTokens: VideoDigest.transcriptTokens(seconds: part.end - part.start),
                                             seeing: nil, on: engine)
                    video.parts[index].text = VideoDigest.cleaned(text)
                    video.parts[index].audio = nil
                    try? FileManager.default.removeItem(at: url)
                    await keep()
                }
            } catch {
                if error is CancellationError || cancelRequested { throw CancellationError() }
                diagnostic?.advance("video_sound_failed")
                diagnostic?.nativeError = InferenceDiagnostic.sanitize(error.localizedDescription)
                // Released on the next load, outside the failed call.
                rebuildRequired = true
                dropSound(&video, because: .failed)
                await keep()
            }
        }
        if video.scenesPending {
            try await prepareEngine(plan, model: spec, settings: settings, onStage: onStage)
            let pending = video.scenes.indices.filter { video.scenes[$0].caption == nil }
            for start in stride(from: 0, to: pending.count, by: VideoDigest.scenesPerLook) {
                let look = Array(pending[start..<min(pending.count, start + VideoDigest.scenesPerLook)])
                let captions = try await describe(look, of: video, settings: settings, onStage: onStage)
                for (index, caption) in zip(look, captions) { video.scenes[index].caption = caption }
                // A scene the model wrote no line for is looked at alone;
                // one it still says nothing of stays undescribed.
                for index in look where video.scenes[index].caption == nil {
                    video.scenes[index].caption = try await describe([index], of: video, settings: settings, onStage: onStage)[0] ?? ""
                }
                await keep()
            }
        }
        if needsSummaries(video, settings) {
            try await prepareEngine(plan, model: spec, settings: settings, onStage: onStage)
            let allowance = VideoDigest.Allowance(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget)
            let room = VideoDigest.speechRoom(video, bytes: allowance.bytes).room
            let groups = VideoDigest.condenseGroups(video)
            var summaries: [VideoAnalysis.Summary] = []
            for group in groups {
                guard let engine, let first = group.first, let last = group.last else { continue }
                await onStage(.condensing)
                diagnostic?.advance("video_condense")
                let characters = VideoDigest.summaryCharacters(group, of: groups, room: room)
                let task = VideoDigest.condense(from: VideoDigest.label(first.start, duration: video.duration),
                                                to: VideoDigest.label(last.end, duration: video.duration), characters: characters)
                let text = try await ask([.text(task + "\n\n" + VideoDigest.condenseText(group, duration: video.duration))],
                                         maxTokens: min(512, characters + 32), seeing: nil, on: engine)
                summaries.append(VideoAnalysis.Summary(start: first.start, end: last.end, text: VideoDigest.cleaned(text)))
            }
            video.summaries = summaries
            await keep()
        }
        // As the chat keeps it (ChatStore), so the next turn can reuse this
        // reply's conversation (ConversationContext).
        var analyzed = attachment
        analyzed.video = video
        analyzed.note = VideoDigest.note(video, sent: true)
        return analyzed
    }

    /// One look at a few scenes, each image after its time; the model's
    /// line for each, nil where it wrote none.
    private func describe(_ look: [Int], of video: VideoAnalysis, settings: GenerationSettings,
                          onStage: @escaping @Sendable (Stage) async -> Void) async throws -> [String?] {
        guard let engine, let first = look.first else { throw ServiceError.modelMissing }
        let labels = look.map { VideoDigest.label(video.scenes[$0].time, duration: video.duration) }
        var contents: [Content] = []
        for (index, label) in zip(look, labels) {
            guard let url = AttachmentStorage.url(video.scenes[index].image),
                  FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
            contents.append(.text("[\(label)]"))
            contents.append(.imageFile(url.path))
        }
        let before = video.scenes[..<first].last { !($0.caption ?? "").isEmpty }
            .map { (label: VideoDigest.label($0.time, duration: video.duration), caption: $0.caption ?? "") }
        contents.append(.text(VideoDigest.describe(labels: labels, before: before)))
        await onStage(.watching)
        diagnostic?.advance("video_scenes")
        let reply = try await ask(contents, maxTokens: VideoDigest.captionTokens(scenes: look.count),
                                  seeing: settings.visualTokenBudget, on: engine)
        return VideoDigest.captions(reply, labels: labels)
    }

    /// The video without its sound files, and why.
    private func dropSound(_ video: inout VideoAnalysis, because reason: VideoAnalysis.SoundSkip) {
        for name in video.audioNames {
            if let url = AttachmentStorage.url(name) { try? FileManager.default.removeItem(at: url) }
        }
        for index in video.parts.indices { video.parts[index].audio = nil }
        video.soundSkipped = reason
    }

    /// One step of a video's analysis: a conversation of its own, with no
    /// system turn and no thinking, sampled greedily, and its whole answer.
    /// `seeing` is the image tokens of a turn with images.
    private func ask(_ contents: [Content], maxTokens: Int, seeing: Int?, on engine: Engine) async throws -> String {
        let sampler = try SamplerConfig(topK: 1, topP: 1, temperature: 0)
        let thinking = ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0)
        try await replaceConversation(on: engine, with: seeing.map {
            ConversationConfig(samplerConfig: sampler, thinkingConfig: thinking, automaticToolCalling: false,
                               visualTokenBudget: Int32($0), enableSpeculativeDecoding: false)
        } ?? ConversationConfig(samplerConfig: sampler, thinkingConfig: thinking, automaticToolCalling: false,
                                enableSpeculativeDecoding: false))
        guard let active = conversation else { throw ServiceError.modelMissing }
        let message = Message(contents: contents, role: .user)
        // The SDK starts inference synchronously, so keep startup off this actor.
        let stream = await Task.detached(priority: .userInitiated) {
            active.sendMessageStream(message, maxOutputTokens: maxTokens)
        }.value
        var text = ""
        // Drained after a stop, as a reply's stream is.
        for try await chunk in stream where !cancelRequested { text += chunk.toString }
        if cancelRequested { throw CancellationError() }
        return text
    }

    /// Streams one model turn. A continuation's opening is held back until it
    /// can be trimmed of what the reply already says; one that apologises or
    /// starts over is cancelled unseen, and the result is nil. The files'
    /// material tags never reach the reply, nor do a thinking reply's
    /// thoughts: the runtime streams those in a channel of their own.
    /// `checking` holds back text written after a search until its start
    /// shows the question's `language` (WebSearch.replyIsIn); text in
    /// another stops the stream, unshown, and sets `wroteOtherLanguage`.
    private func stream(_ message: Message, on active: Conversation, maxOutputTokens: Int, continuing reply: String?,
                        hiding tags: [String], checking: (language: String, searched: @Sendable () -> Bool)? = nil,
                        onThought: @escaping @Sendable () async -> Void,
                        onText: @escaping @Sendable (String) async -> Void) async throws -> String? {
        // The SDK starts inference synchronously, so keep startup off this actor.
        let stream = await Task.detached(priority: .userInitiated) {
            active.sendMessageStream(message, maxOutputTokens: maxOutputTokens)
        }.value
        var part = ""
        var held = reply.map { _ in "" }
        var dropped = false, looping = false, unchecked = 0, otherLanguage = false
        var checking = checking, unsure = ""
        var filter = MaterialTagFilter(tags: tags)
        var thought: Date?
        do {
            for try await chunk in stream {
                // Drain the native stream after cancellation, keeping the engine
                // alive until its final callback before permitting another request.
                if cancelRequested || dropped || looping || otherLanguage { continue }
                let text = chunk.toString
                guard !text.isEmpty else {
                    // Thinking shows nothing for up to a minute on the phone;
                    // say so about once a second, so the wait isn't taken for
                    // a stalled reply.
                    if !chunk.channels.isEmpty, thought.map({ Date().timeIntervalSince($0) >= 1 }) ?? true {
                        if thought == nil { diagnostic?.advance("thinking") }
                        thought = Date()
                        await onThought()
                    }
                    continue
                }
                if reply == nil && part.isEmpty { diagnostic?.advance("decode") }
                if let pending = held.map({ $0 + text }), let reply {
                    guard ReplyContinuation.canCheck(pending, after: reply) else { held = pending; continue }
                    held = nil
                    let trimmed = ReplyContinuation.trimmedStart(of: pending, after: reply)
                    if ReplyContinuation.rejects(trimmed, after: reply) {
                        dropped = true
                        try? active.cancel()
                        continue
                    }
                    let shown = filter.feed(trimmed)
                    part += shown
                    if !shown.isEmpty { await onText(shown) }
                } else if let check = checking, check.searched() {
                    unsure += filter.feed(text)
                    switch WebSearch.replyIsIn(unsure, language: check.language) {
                    case false?:
                        otherLanguage = true
                        try? active.cancel()
                        continue
                    case nil where unsure.count < 160:
                        continue
                    default:
                        checking = nil
                        part += unsure
                        if !unsure.isEmpty { await onText(unsure) }
                        unsure = ""
                    }
                } else {
                    let shown = filter.feed(text)
                    part += shown
                    if !shown.isEmpty { await onText(shown) }
                }
                // A loop is stopped once it shows, rather than at the end of
                // the context window.
                unchecked += text.count
                if unchecked >= 32 {
                    unchecked = 0
                    if ReplyContinuation.isLooping(part) { looping = true; try? active.cancel() }
                }
            }
        } catch where dropped || looping || otherLanguage {
            // The cancelled continuation's own end; the reply goes on without it.
            // A stopped loop keeps what it wrote, and the caller ends the reply.
            // A reply in another language is written again by the caller.
        }
        if dropped { return nil }
        if otherLanguage {
            wroteOtherLanguage = true
            return part
        }
        // A short answer that never showed its language is the answer.
        if !unsure.isEmpty, !cancelRequested {
            part += unsure
            await onText(unsure)
        }
        if let pending = held, let reply, !cancelRequested {
            let trimmed = ReplyContinuation.trimmedStart(of: pending, after: reply)
            if ReplyContinuation.rejects(trimmed, after: reply) { return nil }
            let shown = filter.feed(trimmed)
            part += shown
            if !shown.isEmpty { await onText(shown) }
        }
        if !cancelRequested {
            let rest = filter.flush()
            part += rest
            if !rest.isEmpty { await onText(rest) }
        }
        return part
    }

    /// Sets up the conversation that gives the model its unfinished turn
    /// back (OpenTurn) and returns its prompt: the question rendered by the
    /// model's own template up to where its turn begins, then the reply so
    /// far, prefilled through a template that writes text as it is. Nil,
    /// with the reason in the diagnostics, when that prompt can't be made
    /// exactly; the reply is then asked for again in a new turn.
    private func openTurnPrompt(prompt: String, reply: String, settings: GenerationSettings, tailLimit: Int,
                                model spec: ModelSpec, plan: InferenceEnginePlan, on engine: Engine) async throws -> String? {
        let parts = OpenTurn.parts(prompt: prompt, reply: reply, settings: settings, tailLimit: tailLimit)
        do {
            let sampler = try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature))
            // The reply so far is the answer itself: no thinking before it.
            let thinking = ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0)
            // Rendering prefills nothing; the conversation only lends its template.
            try await replaceConversation(on: engine, with: ConversationConfig(
                systemMessage: Message(systemMessage(settings, spec), role: .system),
                samplerConfig: sampler, thinkingConfig: thinking, automaticToolCalling: false,
                enableSpeculativeDecoding: plan.speculativeDecoding))
            guard let rendering = conversation else { return nil }
            let question = try rendering.renderMessageIntoString(Message(parts.question))
            if keepsOpenTurn { openTurnQuestionForProbe = question }
            let text = OpenTurn.prompt(renderedQuestion: question, tail: parts.tail)
            try await replaceConversation(on: engine, with: ConversationConfig(
                samplerConfig: sampler, thinkingConfig: thinking, automaticToolCalling: false,
                enableSpeculativeDecoding: plan.speculativeDecoding, chatTemplate: OpenTurn.rawTemplate))
            guard let open = conversation, try open.renderMessageIntoString(Message(text)) == text else {
                diagnostic?.advance("reply_open_turn_mismatch")
                return nil
            }
            diagnostic?.advance("reply_open_turn")
            return text
        } catch {
            if error is CancellationError || cancelRequested { throw CancellationError() }
            diagnostic?.advance("reply_open_turn_failed")
            return nil
        }
    }

    /// Diagnostics only: how a reply that went on in the background fared.
    func noteBackground(_ note: String) {
        diagnostic?.background = note
        diagnostic?.save()
    }

    private func continuationConfig(_ request: ReplyContinuation.Request, settings: GenerationSettings, model spec: ModelSpec,
                                    plan: InferenceEnginePlan) throws -> ConversationConfig {
        ConversationConfig(
            systemMessage: Message(systemMessage(settings, spec), role: .system),
            initialMessages: [Message(request.question, role: .user), Message(request.tail, role: .model)],
            samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
            enableSpeculativeDecoding: plan.speculativeDecoding)
    }

    /// The conversation a reply is written in again after its search ended
    /// it without a word: the chat so far and no tool, so the model answers
    /// from the results quoted in the question.
    private func searchAnswerConfig(_ turns: [ChatMessage], settings: GenerationSettings, model spec: ModelSpec,
                                    plan: InferenceEnginePlan) throws -> ConversationConfig {
        let thinking = settings.thinkingTokenBudget(on: spec)
        return ConversationConfig(
            systemMessage: Message(systemMessage(settings, spec), role: .system),
            initialMessages: try nativeHistory(turns, settings: settings),
            samplerConfig: try SamplerConfig(topK: settings.topK, topP: Float(settings.topP), temperature: Float(settings.temperature)),
            thinkingConfig: ThinkingConfig(enableThinking: thinking > 0, thinkingTokenBudget: thinking),
            automaticToolCalling: false, visualTokenBudget: Int32(settings.visualTokenBudget),
            enableSpeculativeDecoding: plan.speculativeDecoding)
    }

    private func nativeHistory(_ turns: [ChatMessage], settings: GenerationSettings) throws -> [Message] {
        try turns.map { message in
            try nativeMessage(text: message.text, attachments: message.media, settings: settings,
                              role: message.role == .user ? .user : .model)
        }
    }

    /// Native probes only: the first part of a reply that searched is
    /// dropped unseen, as E4B's 深く ended it on the phone, so the answer
    /// written again from the results can be checked on the simulator.
    func dropSearchedRepliesForProbe() {
        dropsSearchedReply = true
    }

    /// Native probes only: keeps the open turn's rendered question.
    func keepOpenTurnForProbe() {
        keepsOpenTurn = true
    }

    /// Native probes only: conversations start with this system message
    /// instead of the settings', so instructions can be compared on the
    /// app's own path. nil goes back to the settings'.
    func useSystemMessageForProbe(_ message: String?) {
        probeSystemMessage = message
    }

    /// Native probes only: conversations that may search carry this note in
    /// the system turn instead of `WebSearch.systemNote`, so its wordings can
    /// be compared on the app's own path. nil goes back to the app's.
    func useSearchNoteForProbe(_ note: String?) {
        probeSearchNote = note
    }

    /// Native probes only: a message carries the note this gives for it
    /// (nil for none) instead of `RichFormatGuide.guide`, so the chart
    /// note's wordings can be compared on the app's own path. nil goes back
    /// to the app's.
    func useChartNoteForProbe(_ note: (@Sendable (String) -> String?)?) {
        probeChartNote = note
    }

    /// Native probes only: engines and conversations start with the SDK's
    /// benchmark on, so `lastPrefillTokenCount` can read how long a
    /// search's results were.
    func countPrefillsForProbe() {
        probeBenchmark = true
    }

    /// Native probes only: conversations set up again take the turns given
    /// whatever their size, and an input the runtime refuses fails the
    /// reply, as before 1.1.0 (256) (`probeKeepsTurns`).
    func keepGivenTurnsForProbe(_ on: Bool) {
        probeKeepsTurns = on
    }

    /// Native probes only: each reply ends after this many tokens, so a
    /// probe can read the start of many replies on the simulator's CPU.
    func capRepliesForProbe(_ tokens: Int?) {
        probeReplyTokens = tokens
    }

    private func systemMessage(_ settings: GenerationSettings, _ spec: ModelSpec) -> String {
        probeSystemMessage ?? settings.systemMessage(for: spec)
    }

    private func noteSearch(_ stage: String) {
        diagnostic?.advance(stage)
    }

    /// The reply's diagnostics say why ChatStore stopped it (ReplyGuard).
    func noteReplyGuard(_ reason: ReplyGuard.Stop) {
        diagnostic?.advance("reply_guard_\(reason.rawValue)")
    }

    private func replaceConversation(on engine: Engine, with config: ConversationConfig) async throws {
        // A finished stream holds its conversation until the final native
        // callback returns, and a conversation released inside that callback
        // waits on itself. Let the callback return before releasing ours.
        try await Task.sleep(for: .milliseconds(200))
        conversation = nil
        conversation = try await engine.createConversation(with: config)
        conversationsOnEngine += 1
        conversationSearches = !config.tools.isEmpty
        if cancelRequested { throw CancellationError() }
    }

    /// Whether this turn goes on in the live conversation: its chat, with
    /// the same settings and search, and room for the new input.
    private func continuesConversation(threadID: UUID, history: [ChatMessage], settings: GenerationSettings,
                                       searches: Bool, incoming: Int) throws -> Bool {
        guard let conversation, conversationSettings == settings, conversationSearches == searches,
              context.canReuse(threadID: threadID, history: history) else { return false }
        return try conversation.getTokenCount() + incoming < settings.inputTokenLimit
    }

    /// `memory`: Smart Memory's earlier exchanges, quoted before the
    /// question as the files' material is (SmartMemoryNote).
    private func nativeMessage(text: String, attachments: [ChatAttachment], settings: GenerationSettings,
                               role: Role = .user, note: String? = nil, memory: String? = nil, earlier: String? = nil) throws -> Message {
        var contents: [Content] = []
        // The person's earlier words first, then Smart Memory's record.
        if let earlier { contents.append(.text(earlier)) }
        if let memory { contents.append(.text(memory)) }
        for attachment in attachments {
            if let body = attachment.extractedText {
                // Quoted as material: instructions inside a file are not the person's.
                contents.append(.text(AttachmentPrompt.material(for: attachment, body: body)))
            }
            // A video is what its analysis found, as a timeline quoted as
            // material, and a few of its scenes, each after its time
            // (VideoDigest); LiteRT-LM takes no video itself.
            if let video = attachment.video {
                let allowance = VideoDigest.Allowance(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget)
                let scenes = VideoDigest.answerScenes(video, count: allowance.frames)
                contents.append(.text(VideoDigest.material(video, name: attachment.name, tag: AttachmentPrompt.tag(for: attachment),
                                                           frames: scenes.count, bytes: allowance.bytes)))
                for scene in scenes {
                    guard let url = AttachmentStorage.url(scene.image), FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
                    contents.append(.text("\n[\(VideoDigest.label(scene.time, duration: video.duration))]"))
                    contents.append(.imageFile(url.path))
                }
                contents.append(.text(VideoDigest.replyNote(VideoDigest.replyLanguage(of: text))))
                continue
            }
            // A video of 1.1.0 (192) and (193) is its three scenes, in
            // order, each after its time (VideoScenes).
            var sceneLabels: [String]?
            if attachment.kind == .video {
                contents.append(.text(VideoScenes.opening(name: attachment.name, duration: attachment.duration)))
                sceneLabels = VideoScenes.sceneLabels(duration: attachment.duration, scenes: attachment.imageNames.count)
            }
            for (index, name) in attachment.imageNames.enumerated() {
                guard let url = AttachmentStorage.url(name), FileManager.default.fileExists(atPath: url.path) else { throw ServiceError.attachmentMissing }
                if let sceneLabels { contents.append(.text(sceneLabels[index])) }
                contents.append(.imageFile(url.path))
            }
        }
        contents.append(.text(text))
        if let note { contents.append(.text("\n\n" + note)) }
        return Message(contents: contents, role: role)
    }

    func cancel() {
        guard running else { return }
        cancelRequested = true
        context.invalidate()
        activeSearch?.cancel()
        try? conversation?.cancel()
        llama?.stop()
    }

    func runVisionProbe(model: ModelSpec, kind: VisionProbeKind, main: ExecutionBackend,
                        vision: ExecutionBackend, kernel: VisionCPUImplementation = .xnnpack,
                        visionTokens: Int = 280, contextTokens: Int = 4096) async throws -> String {
        guard !running else { throw ServiceError.busy }
        // Release the chat's language engine before the component-only test.
        // The next normal message rebuilds the original saved configuration.
        unload()
        running = true
        defer { running = false }
        return try await VisionDiagnosticRunner.run(model: model, kind: kind, main: main, vision: vision, kernel: kernel,
                                                    visionTokens: visionTokens, contextTokens: contextTokens)
    }

    /// The developer GPU start test, on its own engine like the vision
    /// probe. The next message rebuilds the chat's engine from the saved
    /// settings, with the model's own GPU precision.
    /// The developer 12B check (LargeModelProbe): the chat's model is
    /// released first, and no reply can start while it runs.
    func runLargeModelProbe(backend: LargeModelProbe.Backend) async throws -> LargeModelProbe.Record {
        guard !running else { throw ServiceError.busy }
        unload()
        running = true
        defer { running = false }
        return await LargeModelProbeRunner.run(backend: backend)
    }

    /// 開発者設定's 12B comparison (LargeModelChatCompare), released and
    /// guarded as the 12B check is.
    func runLargeModelChatCompare(settings: GenerationSettings) async throws -> LargeModelChatCompare.Record {
        guard !running else { throw ServiceError.busy }
        unload()
        running = true
        defer { running = false }
        return await LargeModelChatCompareRunner.run(settings: settings)
    }

    func runGPUStartTest(model: ModelSpec, precision: GPUPrecision) async throws -> String {
        guard !running else { throw ServiceError.busy }
        unload()
        running = true
        defer { running = false }
        return try await GPUStartTestRunner.run(model: model, precision: precision)
    }

    /// Tokens the live conversation holds (history and the last turn), for
    /// the native probes; nil when no conversation is open.
    func contextTokenCount() -> Int? {
        try? conversation?.getTokenCount()
    }

    /// Tokens the live conversation's last prefill read (after a search,
    /// its results), for the native probes; needs the SDK's benchmark flag
    /// on before the engine starts.
    func lastPrefillTokenCount() -> Int? {
        try? conversation?.getBenchmarkInfo().lastPrefillTokenCount
    }

    /// Native probes only: why `lastPrefillTokenCount` has no count.
    func lastPrefillProblemForProbe() -> String {
        guard let conversation else { return "no conversation" }
        do { _ = try conversation.getBenchmarkInfo(); return "-" } catch { return String(describing: error).prefix(200).description }
    }

    /// Unloads `spec` only if it is the loaded model (a model locked again;
    /// 12B, which used it, is open to everyone since 1.1.0 (204)).
    func unload(_ spec: ModelSpec) {
        if enginePlan?.modelID == spec.id || llama?.plan.modelID == spec.id { unload() }
    }

    func unload() {
        guard !running else { return }
        // The completed turns stay known, so the next message can rebuild
        // the conversation with them (see `contextPlan`).
        conversation = nil
        engine = nil
        enginePlan = nil
        conversationsOnEngine = 0
        releaseWeights()
        rebuildRequired = false
        conversationSettings = nil
        llama = nil
    }

    /// LFM3 on llama.cpp (1.1.0 (232)), text only, LFM3-VL 2B (234) with
    /// the person's photos and LFM3-Omni 2B (236) with photos and spoken
    /// questions. Its model loads for the plan (the GPU, or
    /// the CPU in the background) after LiteRT-LM's engine is released, so
    /// one model holds memory at a time; LFM3-VL's picture projector loads
    /// with it, so a photo needs no other engine. The chat goes in whole,
    /// earlier turns and their photos left out where it doesn't fit; a
    /// stopped reply goes on from its last characters (OpenTurn), without
    /// thinking or photos.
    private func performLlama(prompt: String, history: [ChatMessage], attachments: [ChatAttachment], model spec: ModelSpec,
                              settings: GenerationSettings, plan: InferenceEnginePlan, resuming partial: String?,
                              readsLess: Bool, memory: SmartMemoryNote? = nil, onStage: @escaping @Sendable (Stage) async -> Void,
                              onText: @escaping @Sendable (String) async -> Void) async throws {
        guard !spec.isLocked else { throw ServiceError.modelLocked }
        guard AppFiles.hasVerifiedModel(spec) else { throw ServiceError.modelMissing }
        diagnostic?.inferenceEngine = LlamaReply.engineName
        // The same model on the same processor and context: photos or none.
        let loaded = llama.map {
            $0.plan.modelID == plan.modelID && $0.plan.backend == plan.backend && $0.plan.maxTokens == plan.maxTokens
        } ?? false
        diagnostic?.engineWasReused = loaded && !llamaFailed
        do {
            if !loaded || llamaFailed {
                await onStage(.loading)
                conversation = nil
                context.invalidate()
                engine = nil
                enginePlan = nil
                conversationsOnEngine = 0
                releaseWeights()
                conversationSettings = nil
                llama = nil
                diagnostic?.advance("engine_initialization")
                let loading = LlamaReply(plan: plan)
                // Kept while it loads, so a stop reaches the load.
                llama = loading
                do {
                    try await loading.load(path: AppFiles.model(spec).path, projector: spec.parts.first.map { AppFiles.model($0).path })
                } catch { llama = nil; throw error }
                llamaFailed = false
            }
            guard let llama else { throw ServiceError.modelMissing }
            diagnostic?.cpuThreadPolicy = plan.backend == .cpu ? "llama.cpp: \(llama.threads) threads" : "llama.cpp: Metal"
            if cancelRequested { throw CancellationError() }
            var request: LlamaReply.Request
            if let partial, !partial.isEmpty {
                await onStage(.continuing)
                diagnostic?.advance("reply_open_turn")
                let parts = OpenTurn.parts(prompt: prompt, reply: partial, settings: settings,
                                           tailLimit: readsLess ? BackgroundRead.tailBytes : OpenTurn.tailBytes)
                request = LlamaReply.Request(system: systemMessage(settings, spec), turns: [], question: parts.question,
                                             reply: parts.tail, thinkingBudget: 0, inputTokenLimit: settings.inputTokenLimit,
                                             settings: settings)
            } else {
                await onStage(.waiting)
                diagnostic?.advance("text_generation")
                // A message that asks for a chart carries the format's note, as on LiteRT-LM.
                let guide = RichFormatGuide.guide(for: prompt)
                // LFM3-VL 2B's photos, as the app keeps them (JPEG), and
                // LFM3-Omni 2B's photos and recordings (WAV, 236), in the
                // order they were attached; the policy has already left out
                // what this model doesn't read.
                let media = { (media: [ChatAttachment]) -> [String] in
                    media.flatMap { $0.kind == .audio ? [$0.storedName] : $0.modelImageNames(settings) }
                }
                let reads = spec.supportsVision || spec.supportsVoice
                request = LlamaReply.Request(system: systemMessage(settings, spec),
                                             turns: LlamaReply.turns(history, pictures: { reads ? media($0.media).count : 0 }),
                                             question: (memory.map { $0.text + "\n" } ?? "") + prompt + (guide.map { "\n\n" + $0 } ?? ""), reply: nil,
                                             thinkingBudget: settings.thinkingTokenBudget(on: spec),
                                             inputTokenLimit: settings.inputTokenLimit, settings: settings)
                if reads {
                    request.questionPictures = try Self.pictures(media(attachments))
                    request.turnPictures = try Self.pictures(history.filter { $0.role == .user }.flatMap { media($0.media) })
                }
            }
            var reply = "", thought: Date?, finished: LlamaReply.Finished?
            // Drained after a stop: the reply's thread holds the engine until its end.
            for try await event in llama.reply(request) {
                if cancelRequested { continue }
                switch event {
                case .prefilled:
                    break
                case .thought:
                    // Thinking shows nothing; say so about once a second.
                    if thought == nil { diagnostic?.advance("thinking") }
                    if thought.map({ Date().timeIntervalSince($0) >= 1 }) ?? true {
                        thought = Date()
                        await onStage(.thinking)
                    }
                case .answer(let text):
                    if reply.isEmpty && partial == nil { diagnostic?.advance("decode") }
                    reply += text
                    await onText(text)
                case .finished(let result):
                    finished = result
                }
            }
            diagnostic?.llamaReply = finished?.note
            if cancelRequested || finished?.cancelled == true { throw CancellationError() }
            if finished?.looped == true { diagnostic?.advance("reply_loop_stopped") }
            guard !reply.isEmpty else { throw ServiceError.emptyReply }
            diagnostic?.replyCharacters = reply.count
        } catch {
            if !(error is CancellationError || cancelRequested) { llamaFailed = true }
            throw error
        }
    }

    /// The photos' and recordings' files, for llama.cpp, which reads JPEG
    /// and WAV itself.
    private static func pictures(_ names: [String]) throws -> [Data] {
        try names.map { name in
            guard let url = AttachmentStorage.url(name), let data = try? Data(contentsOf: url) else {
                throw ServiceError.attachmentMissing
            }
            return data
        }
    }

    /// Locks the CPU weight cache of a model that asks for it
    /// (ModelCapabilities.locksCPUWeights) once its engine has started, and
    /// tries again at each reply until it holds; the reply's diagnostics say
    /// how it went. A cache that can't be locked leaves the reply as before.
    private func lockWeights(_ plan: InferenceEnginePlan, _ spec: ModelSpec) {
        guard plan.backend == .cpu, spec.capabilities.locksCPUWeights else { return }
        if weightLock == nil {
            let result = WeightCacheLock.lock(in: Self.cacheFolder(plan))
            weightLock = try? result.get()
            weightLockNote = WeightCacheLock.label(result)
        }
        diagnostic?.weightCache = weightLockNote
    }

    private func releaseWeights() {
        weightLock = nil
        weightLockNote = nil
    }
}

private struct InferenceFailure: LocalizedError {
    let stage: String
    let cause: Error
    let photoOnE4B: Bool
    /// The MTP drafter came from 高速 alone, which じっくり考える turns without.
    let fastDrafter: Bool
    var errorDescription: String? {
        let detail = cause.localizedDescription
        // A failed load can keep its address space until relaunch; say so
        // instead of suggesting another model that would fail the same way.
        // Image tensors with no room left are the same shortage: E4B's photos
        // leave little address space on the phone, and E2B's leave more.
        let shortage = detail.contains("Cannot allocate memory") || NativeFailureKind(description: detail) == .tensorAllocation
        let hint = shortage
            ? "\n" + Sentences.join([String(localized: "アプリが扱えるメモリ領域が不足しています。アプリを一度完全に終了してから開き直してください。"),
                                     photoOnE4B ? String(localized: "続けて失敗するときは、写真はGemma 4 E2Bで送ってください。") : ""]) : ""
        let drafter = fastDrafter
            ? "\n" + String(localized: "続けて失敗するときは、「じっくり考える」をお試しください。") : ""
        return String(localized: "処理段階: \(stage)") + "\n" + detail + hint + drafter
    }
}

private enum ServiceError: LocalizedError {
    case busy, modelMissing, modelLocked, visionUnsupported, attachmentMissing, emptyReply
    /// 12B without the room to start: the sideload's signature, or too
    /// little memory left (open to everyone since 1.1.0 (204)).
    case noRoom(String)
    var errorDescription: String? {
        switch self {
        case .noRoom(let reasons): return String(localized: "Gemma 4 12Bを読み込めません。") + "\n" + reasons
        case .busy: return String(localized: "前の返信が終わるまでお待ちください。")
        case .modelLocked: return String(localized: "このモデルはロック中のため、まだ使えません。")
        case .modelMissing: return String(localized: "この会話のモデルをダウンロードするか、対応するファイルを取り込んでください。")
        case .visionUnsupported: return String(localized: "このモデルは写真を読み込めません。写真にはGemma 4 E2Bを選んでください。")
        case .attachmentMissing: return String(localized: "保存した添付ファイルが見つかりません。もう一度添付してください。")
        case .emptyReply: return String(localized: "返信の文章が届きませんでした。")
        }
    }
}

extension GPUPrecision {
    /// nil leaves the precision to the runtime and the model file, as 1.0.104 did.
    var activationDataType: ActivationDataType? {
        switch self {
        case .modelDefault: return nil
        case .float16: return .float16
        case .float32: return .float32
        }
    }
}
