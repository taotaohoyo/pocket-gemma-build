import Foundation
import Combine
import PocketCore
import WatchConnectivity

/// Fielua's Apple Watch app on the iPhone's side (2026-10-23): a question
/// from the watch is answered here by Gemma 4 E2B (ChatStore.askFromWatch),
/// and the answer goes back to the watch as it is written. The watch can't
/// hold a model: its memory is a fraction of the iPhone's.
///
/// The answer is followed in the chat itself, a few times a second, and
/// sent whole each time it changes: while the watch app is open as a
/// message, and its last state also in the application context, which the
/// watch reads when it opens. A reply that ran out of background time is
/// followed on, so its rest reaches the watch once Fielua is opened, or
/// when the watch app asks for it (carryOn), which wakes Fielua again.
///
/// The watch also reads the chats (2026-10-24, WatchHistory): the list
/// rides in the application context, refreshed once the chats rest, and
/// the watch asks for a chat's latest messages when it shows that chat.
/// Nothing the watch sends changes a chat but a question.
@MainActor
final class WatchBridge: NSObject {
    static let shared = WatchBridge()

    private struct Following {
        let question: String
        let thread: UUID
        let message: UUID
        var sent: WatchLink.Reply?
    }

    private var following: Following?
    private var loop: Task<Void, Never>?
    /// The last word on the last answer, which the application context
    /// keeps beside the list.
    private var lastReply: WatchLink.Reply?
    /// The list the application context holds.
    private var sentList: Data?
    private var chatsChanged: AnyCancellable?
    /// The watch's conversation of 1.1.0 (152) and the chat it is on the
    /// iPhone. Read only: the watch now names chats by their own ids.
    private static let conversationKey = "watchConversation"
    private static let threadKey = "watchThread"

    func activate() {
        guard WCSession.isSupported() else { return }
        WCSession.default.delegate = self
        WCSession.default.activate()
        // The list follows the chats once they rest, not with every word.
        chatsChanged = ChatStore.shared.$threads
            .debounce(for: .seconds(1.5), scheduler: DispatchQueue.main)
            .sink { _ in MainActor.assumeIsolated { WatchBridge.shared.updateContext() } }
    }

    /// While the watch app is open it shows the answer itself, so the
    /// iPhone's notification would only say it again.
    func showsAnswer(in thread: UUID) -> Bool {
        following?.thread == thread && WCSession.isSupported() && WCSession.default.isReachable
    }

    private func handle(_ message: [String: Any]) -> [String: Any] {
        WatchIntro.markUsed()
        if let question = WatchLink.stopQuestion(in: message) {
            if let following, following.question == question, ChatStore.shared.isGenerating { ChatStore.shared.stop() }
            return [:]
        }
        if let question = WatchLink.carryOnQuestion(in: message) { return carryOn(question) }
        if WatchLink.isListRequest(message) { return WatchLink.list(listData()) }
        if let chat = WatchLink.requestedPage(in: message) { return page(chat) }
        guard let ask = WatchLink.Ask(message) else { return [:] }
        return answer(ask)
    }

    private func answer(_ ask: WatchLink.Ask) -> [String: Any] {
        let chats = ChatStore.shared
        let questionID = UUID(uuidString: ask.id) ?? UUID()
        // Sent again, when the watch didn't hear back: it is written once.
        if let known = chats.watchQuestion(questionID) {
            if let following, following.question == ask.id, let sent = following.sent { return sent.message }
            guard let replyID = known.reply,
                  let current = reply(question: ask.id, thread: known.thread, message: replyID) else {
                return WatchLink.Reply(question: ask.id, text: "", state: .failed, detail: String(localized: "iPhoneで返信を書けませんでした"),
                                       conversation: known.thread.uuidString).message
            }
            return current.message
        }
        let requested = UUID(uuidString: ask.conversation)
        var thread = requested.flatMap { id in chats.threads.contains { $0.id == id } ? id : nil }
        let defaults = UserDefaults.standard
        if thread == nil, defaults.string(forKey: Self.conversationKey) == ask.conversation {
            thread = defaults.string(forKey: Self.threadKey).flatMap(UUID.init(uuidString:))
        }
        switch chats.askFromWatch(ask.text, threadID: thread, newThreadID: requested, messageID: questionID) {
        case .refused(let reason):
            return WatchLink.Reply(question: ask.id, text: "", state: .refused, detail: reason).message
        case .started(let thread, let message):
            follow(Following(question: ask.id, thread: thread, message: message))
            return WatchLink.Reply(question: ask.id, text: "", state: .waiting, detail: String(localized: "iPhoneで準備しています"),
                                   conversation: thread.uuidString).message
        }
    }

    /// The watch asks for the rest of its answer, paused when the
    /// background time ran out (WatchLink.carryOn): it goes on where it
    /// stopped, if it can, and is followed as before. The answer is the
    /// reply as it stands.
    private func carryOn(_ question: String) -> [String: Any] {
        let chats = ChatStore.shared
        guard let id = UUID(uuidString: question), let known = chats.watchQuestion(id), let replyID = known.reply else {
            return WatchLink.Reply(question: question, text: "", state: .failed, detail: String(localized: "iPhoneで会話が削除されました")).message
        }
        _ = chats.continueForWatch(thread: known.thread, message: replyID)
        follow(Following(question: question, thread: known.thread, message: replyID))
        return reply(question: question, thread: known.thread, message: replyID)?.message
            ?? WatchLink.Reply(question: question, text: "", state: .failed, detail: String(localized: "iPhoneで会話が削除されました")).message
    }

    private func follow(_ next: Following) {
        loop?.cancel()
        following = next
        loop = Task { [weak self] in
            while !Task.isCancelled {
                guard let self, self.push() else { return }
                try? await Task.sleep(for: .milliseconds(350))
            }
        }
    }

    /// Sends the answer if it changed; false once nothing more will come.
    private func push() -> Bool {
        guard var current = following else { return false }
        guard let next = reply(question: current.question, thread: current.thread, message: current.message) else {
            // The chat was deleted on the iPhone.
            send(WatchLink.Reply(question: current.question, text: "", state: .failed, detail: String(localized: "iPhoneで会話が削除されました")))
            following = nil
            return false
        }
        if next != current.sent {
            send(next)
            current.sent = next
            following = current
        }
        if next.state.isFinal {
            following = nil
            return false
        }
        return true
    }

    /// The reply to the watch's question as it stands in the chat.
    private func reply(question: String, thread: UUID, message: UUID) -> WatchLink.Reply? {
        let chats = ChatStore.shared
        guard let reply = chats.threads.first(where: { $0.id == thread })?.messages
            .first(where: { $0.id == message }) else { return nil }
        let state: WatchLink.State
        var detail: String?
        switch reply.state {
        case .generating:
            state = reply.text.isEmpty ? .waiting : .writing
            if reply.text.isEmpty { detail = Self.stage(chats.status) }
        case .complete: state = .finished
        case .failed:
            state = .failed
            detail = String(localized: "iPhoneで返信を書けませんでした")
        case .stopped:
            if chats.replyIsPaused(message) {
                state = .paused
                detail = String(localized: "iPhoneでFieluaを開くと続きを書きます")
            } else if chats.replyWillContinue(message) {
                // Between the GPU and the CPU.
                state = reply.text.isEmpty ? .waiting : .writing
            } else {
                state = .stopped
            }
        }
        return WatchLink.Reply(question: question, text: reply.text, state: state, detail: detail,
                               conversation: thread.uuidString)
    }

    /// The chat's status line, as short as the watch needs it.
    private static func stage(_ status: String) -> String? {
        let text = status.replacingOccurrences(of: "…", with: "").trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return nil }
        // The seconds a long stage shows (ChatStore's watchdog). The line is
        // Japanese, as developers see it; the watch says it in its language.
        let stage = text.replacingOccurrences(of: #" \d+秒$"#, with: "", options: .regularExpression)
        return String(localized: String.LocalizationValue(stage))
    }

    private func send(_ reply: WatchLink.Reply) {
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isWatchAppInstalled else { return }
        if session.isReachable {
            session.sendMessage(reply.message, replyHandler: nil, errorHandler: nil)
        }
        // The last word also waits for the watch app, which reads it when it
        // opens; a newer context replaces an older one.
        if reply.state.isFinal || reply.state == .paused {
            lastReply = reply
            updateContext(force: true)
        }
    }

    /// 開発者設定's 「初回起動扱いにする」 (FirstLaunchResetCard): the iPhone
    /// forgets the watch's conversation of 1.1.0 (152), and the watch app
    /// is told to forget what it showed and that it was opened, as on its
    /// first launch (WatchLink.reset): queued, so it arrives when the
    /// watch app next runs. False when there is no watch app to tell.
    func resetWatch() -> Bool {
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: Self.conversationKey)
        defaults.removeObject(forKey: Self.threadKey)
        lastReply = nil
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isPaired,
              session.isWatchAppInstalled else { return false }
        session.transferUserInfo(WatchLink.reset)
        // The last answer leaves the application context too.
        updateContext(force: true)
        return true
    }

    // MARK: The chats, for the watch (WatchHistory)

    private func listData() -> Data {
        let defaults = UserDefaults.standard
        let former = defaults.string(forKey: Self.conversationKey).flatMap { conversation in
            defaults.string(forKey: Self.threadKey).flatMap(UUID.init(uuidString:)).map { (conversation, $0) }
        }
        return WatchHistory.encode(WatchHistory.list(ChatStore.shared.threads, former: former)) ?? Data()
    }

    private func page(_ chat: String) -> [String: Any] {
        let chats = ChatStore.shared
        guard let id = UUID(uuidString: chat), let thread = chats.threads.first(where: { $0.id == id }) else {
            return WatchLink.missingPage(chat: chat)
        }
        let paused = Set(thread.messages.map(\.id).filter { chats.replyIsPaused($0) })
        guard let data = WatchHistory.encode(WatchHistory.page(thread, paused: paused)) else {
            return WatchLink.missingPage(chat: chat)
        }
        return WatchLink.page(data)
    }

    /// Puts the list (and the last answer's last word) where the watch
    /// reads it when it opens, if the list changed. Only for a watch with
    /// Fielua on it: the sideloaded app has no watch app.
    private func updateContext(force: Bool = false) {
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isPaired,
              session.isWatchAppInstalled else { return }
        let list = listData()
        guard force || list != sentList else { return }
        sentList = list
        do {
            try session.updateApplicationContext(WatchLink.context(list: list, reply: lastReply))
        } catch {
            // Too much with a long answer: the list alone. The watch reads
            // its chat again when it opens.
            try? session.updateApplicationContext(WatchLink.context(list: list, reply: nil))
        }
    }
}

extension WatchBridge: WCSessionDelegate {
    nonisolated func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState,
                             error: Error?) {
        Task { @MainActor in WatchBridge.shared.updateContext(force: true) }
    }

    nonisolated func sessionDidBecomeInactive(_ session: WCSession) {}

    /// The person paired another watch: talk to that one.
    nonisolated func sessionDidDeactivate(_ session: WCSession) {
        session.activate()
    }

    /// The watch app was installed, say: it gets the list.
    nonisolated func sessionWatchStateDidChange(_ session: WCSession) {
        Task { @MainActor in WatchBridge.shared.updateContext(force: true) }
    }

    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any],
                             replyHandler: @escaping ([String: Any]) -> Void) {
        Task { @MainActor in replyHandler(WatchBridge.shared.handle(message)) }
    }

    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Task { @MainActor in _ = WatchBridge.shared.handle(message) }
    }

    /// The watch app's first opening (WatchLink.hello).
    nonisolated func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any] = [:]) {
        Task { @MainActor in WatchIntro.markUsed() }
    }
}
