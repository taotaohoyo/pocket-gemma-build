import Foundation
import WatchConnectivity

/// Fielua's Apple Watch app on the iPhone's side (2026-10-23): a question
/// from the watch is answered here by Gemma 4 E2B (ChatStore.askFromWatch),
/// and the answer goes back to the watch as it is written. The watch can't
/// hold a model: its memory is a fraction of the iPhone's.
///
/// The answer is followed in the chat itself, a few times a second, and
/// sent whole each time it changes: while the watch app is open as a
/// message, and its last state also as the application context, which the
/// watch reads when it opens. A reply that ran out of background time is
/// followed on, so its rest reaches the watch once Fielua is opened.
@MainActor
final class WatchBridge: NSObject {
    static let shared = WatchBridge()

    private struct Following {
        let question: String
        let thread: UUID
        let message: UUID
        var sent: WatchLink.Reply?
    }

    private var following: Following?
    private var loop: Task<Void, Never>?
    /// The watch's conversation and the chat it is on the iPhone.
    private static let conversationKey = "watchConversation"
    private static let threadKey = "watchThread"

    func activate() {
        guard WCSession.isSupported() else { return }
        WCSession.default.delegate = self
        WCSession.default.activate()
    }

    /// While the watch app is open it shows the answer itself, so the
    /// iPhone's notification would only say it again.
    func showsAnswer(in thread: UUID) -> Bool {
        following?.thread == thread && WCSession.isSupported() && WCSession.default.isReachable
    }

    private func handle(_ message: [String: Any]) -> [String: Any] {
        if let question = WatchLink.stopQuestion(in: message) {
            if let following, following.question == question, ChatStore.shared.isGenerating { ChatStore.shared.stop() }
            return [:]
        }
        guard let ask = WatchLink.Ask(message) else { return [:] }
        let defaults = UserDefaults.standard
        let thread = defaults.string(forKey: Self.conversationKey) == ask.conversation
            ? defaults.string(forKey: Self.threadKey).flatMap(UUID.init(uuidString:)) : nil
        switch ChatStore.shared.askFromWatch(ask.text, threadID: thread) {
        case .refused(let reason):
            return WatchLink.Reply(question: ask.id, text: "", state: .refused, detail: reason).message
        case .started(let thread, let message):
            defaults.set(ask.conversation, forKey: Self.conversationKey)
            defaults.set(thread.uuidString, forKey: Self.threadKey)
            follow(Following(question: ask.id, thread: thread, message: message))
            return WatchLink.Reply(question: ask.id, text: "", state: .waiting, detail: "iPhoneで準備しています").message
        }
    }

    private func follow(_ next: Following) {
        loop?.cancel()
        following = next
        loop = Task { [weak self] in
            while !Task.isCancelled {
                guard let self, self.push() else { return }
                try? await Task.sleep(for: .milliseconds(350))
            }
        }
    }

    /// Sends the answer if it changed; false once nothing more will come.
    private func push() -> Bool {
        guard var current = following else { return false }
        let chats = ChatStore.shared
        guard let reply = chats.threads.first(where: { $0.id == current.thread })?.messages
            .first(where: { $0.id == current.message }) else {
            // The chat was deleted on the iPhone.
            send(WatchLink.Reply(question: current.question, text: "", state: .failed, detail: "iPhoneで会話が削除されました"))
            following = nil
            return false
        }
        let state: WatchLink.State
        var detail: String?
        switch reply.state {
        case .generating:
            state = reply.text.isEmpty ? .waiting : .writing
            if reply.text.isEmpty { detail = Self.stage(chats.status) }
        case .complete: state = .finished
        case .failed:
            state = .failed
            detail = "iPhoneで回答を書けませんでした"
        case .stopped:
            if chats.replyIsPaused(current.message) {
                state = .paused
                detail = "iPhoneでFieluaを開くと続きを書きます"
            } else if chats.replyWillContinue(current.message) {
                // Between the GPU and the CPU.
                state = reply.text.isEmpty ? .waiting : .writing
            } else {
                state = .stopped
            }
        }
        let next = WatchLink.Reply(question: current.question, text: reply.text, state: state, detail: detail)
        if next != current.sent {
            send(next)
            current.sent = next
            following = current
        }
        if state.isFinal {
            following = nil
            return false
        }
        return true
    }

    /// The chat's status line, as short as the watch needs it.
    private static func stage(_ status: String) -> String? {
        let text = status.replacingOccurrences(of: "…", with: "").trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return nil }
        // The seconds a long stage shows (ChatStore's watchdog).
        return text.replacingOccurrences(of: #" \d+秒$"#, with: "", options: .regularExpression)
    }

    private func send(_ reply: WatchLink.Reply) {
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isWatchAppInstalled else { return }
        if session.isReachable {
            session.sendMessage(reply.message, replyHandler: nil, errorHandler: nil)
        }
        // The last word also waits for the watch app, which reads it when it
        // opens; a newer context replaces an older one.
        if reply.state.isFinal || reply.state == .paused {
            try? session.updateApplicationContext(reply.message)
        }
    }
}

extension WatchBridge: WCSessionDelegate {
    nonisolated func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState,
                             error: Error?) {}

    nonisolated func sessionDidBecomeInactive(_ session: WCSession) {}

    /// The person paired another watch: talk to that one.
    nonisolated func sessionDidDeactivate(_ session: WCSession) {
        session.activate()
    }

    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any],
                             replyHandler: @escaping ([String: Any]) -> Void) {
        Task { @MainActor in replyHandler(WatchBridge.shared.handle(message)) }
    }

    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Task { @MainActor in _ = WatchBridge.shared.handle(message) }
    }
}
