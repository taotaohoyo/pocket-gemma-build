import SwiftUI
import UIKit
import PocketCore

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        ModelStore.shared.attachBackgroundCompletion(completionHandler)
    }
}

@main
struct PocketGemmaApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var chats = ChatStore()
    @StateObject private var model = ModelStore.shared
    @Environment(\.scenePhase) private var scenePhase

    init() {
        // Before any model loads: what iOS gives the app, for the diagnostics,
        // and whether its address space has room for さらに深く.
        PhotoDetail.offer(atLaunch: LaunchMemory.atLaunch.addressSpace)
    }

    var body: some Scene {
        WindowGroup {
            ChatNavigationView()
                .modifier(StartupPresenter())
                .environmentObject(chats)
                .environmentObject(model)
                .onChange(of: scenePhase) { _, phase in
                    if phase == .background { chats.didEnterBackground() }
                    if phase == .active { chats.resumeInterruptedReply() }
                }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)) { _ in
                    chats.releaseModelMemory()
                    MarkdownCaches.purgeAll()
                }
        }
    }
}
