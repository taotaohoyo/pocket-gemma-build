import SwiftUI
import UIKit
import UserNotifications
import PocketCore

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // Before launch ends, so a tapped notification reaches the app.
        UNUserNotificationCenter.current().delegate = ReplyNotifications.shared
        // Questions from the Apple Watch app, which may be why iOS launched
        // the app.
        WatchBridge.shared.activate()
        return true
    }

    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        ModelStore.shared.attachBackgroundCompletion(completionHandler)
    }
}

@main
struct PocketGemmaApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var chats = ChatStore.shared
    @StateObject private var model = ModelStore.shared
    @Environment(\.scenePhase) private var scenePhase

    init() {
        // Before any model loads: what iOS gives the app, for the diagnostics,
        // and whether its address space has room for さらに深く, and for E4B
        // to write down a video's sound.
        PhotoDetail.offer(atLaunch: LaunchMemory.atLaunch.addressSpace)
        VideoSound.offer(atLaunch: LaunchMemory.atLaunch.addressSpace)
        // 起動時にキーボードを開いておく becomes 起動時のチャット (1.1.0 (182)).
        LaunchChatMode.migrate()
    }

    var body: some Scene {
        WindowGroup {
            ChatNavigationView()
                .modifier(StartupPresenter())
                .environmentObject(chats)
                .environmentObject(model)
                // The default text size, not iOS's 文字サイズ (2026-10-23).
                .modifier(FixedTextSize())
                .onChange(of: scenePhase) { _, phase in
                    if phase == .background {
                        chats.didEnterBackground()
                        WatchIntro.appDidLeave()
                    }
                    if phase == .active {
                        chats.resumeInterruptedReply()
                        WatchIntro.appDidReturn()
                        // The Tavily key may have come or gone through iCloud Keychain.
                        WebSearchKeyState.shared.refresh()
                    }
                }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)) { _ in
                    chats.releaseModelMemory()
                    MarkdownCaches.purgeAll()
                }
        }
    }
}
