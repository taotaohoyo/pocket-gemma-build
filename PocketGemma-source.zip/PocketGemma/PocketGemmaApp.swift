import SwiftUI
import UIKit
import UserNotifications
import PocketCore

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // Before launch ends, so a tapped notification reaches the app.
        UNUserNotificationCenter.current().delegate = ReplyNotifications.shared
        // Questions from the Apple Watch app, which may be why iOS launched
        // the app.
        WatchBridge.shared.activate()
        return true
    }

    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        // 受信方式を比較's sessions end with the comparison; nothing to take.
        guard !identifier.hasPrefix(NetworkCheck.sessionPrefix) else { return completionHandler() }
        ModelStore.shared.attachBackgroundCompletion(completionHandler)
    }
}

@main
struct PocketGemmaApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var chats = ChatStore.shared
    @StateObject private var model = ModelStore.shared
    @Environment(\.scenePhase) private var scenePhase

    init() {
        // Before any model loads: what iOS gives the app, for the diagnostics,
        // and whether its address space has room for じっくり考える, for E4B to
        // write down a video's sound, and for 12B.
        PhotoDetail.offer(atLaunch: LaunchMemory.atLaunch.addressSpace)
        VideoSound.offer(atLaunch: LaunchMemory.atLaunch.addressSpace)
        LargeModelProbe.offer(atLaunch: LaunchMemory.atLaunch.addressSpace)
        // 起動時にキーボードを開いておく becomes 起動時のチャット (1.1.0 (182)).
        LaunchChatMode.migrate()
    }

    var body: some Scene {
        WindowGroup {
            ChatNavigationView()
                .modifier(StartupPresenter())
                // Claude's invite link (fielua://claude, 1.1.0 (257)):
                // shown before anything is sent.
                .modifier(ClaudeInviteHandler())
                .environmentObject(chats)
                .environmentObject(model)
                // For the views that act on the chat without observing it (1.1.0 (263)).
                .environment(\.chatHandle, ChatHandle(chats))
                // The default text size, not iOS's 文字サイズ (2026-10-23).
                .modifier(FixedTextSize())
                // Warm ink and the honey tint everywhere (brand 2026-10-27).
                .fieluaAppearance()
                .onChange(of: scenePhase) { _, phase in
                    if phase == .background {
                        chats.didEnterBackground()
                        WatchIntro.appDidLeave()
                    }
                    if phase == .active {
                        chats.resumeInterruptedReply()
                        WatchIntro.appDidReturn()
                        // The Tavily key may have come or gone through iCloud Keychain.
                        WebSearchKeyState.shared.refresh()
                        // PCと接続 (1.1.0 (253)): whether the registered PC
                        // answers, and its models; nothing without one.
                        PCLinkStore.shared.refresh()
                        // Claude (1.1.0 (257)): whether the relay answers
                        // this iPhone now; nothing without a registration.
                        ClaudeLinkStore.shared.refresh()
                    }
                }
                .onReceive(NotificationCenter.default.publisher(for: UIApplication.didReceiveMemoryWarningNotification)) { _ in
                    chats.releaseModelMemory()
                    MarkdownCaches.purgeAll()
                }
        }
    }
}
