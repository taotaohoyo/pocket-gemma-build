import SwiftUI
import UIKit
import PocketCore

/// Scroll geometry changes as the lazy stack measures rows. Retain precise
/// position without invalidating that stack for every measurement; publish
/// only the change that controls the jump button.
@MainActor final class ChatScrollState: ObservableObject {
    private var policy = ChatScrollPolicy()
    @Published private(set) var followsLatest = true
    @Published private(set) var isUserScrolling = false
    @Published private(set) var showsJumpButton = false
    var shouldFollowStream: Bool { policy.shouldFollowStream }
    /// Not published: the last measured distance from the visible bottom to
    /// the end of the content. At or below zero the last row is already in
    /// view (a short chat, or the reader is at the end).
    private(set) var lastDistanceFromBottom = 0.0
    // Not published: these change every layout pass. Lazy rows can
    // overestimate contentSize by hundreds of points (d=272 with the reply's
    // end in view, UI test), so a manual return to the end still measured as
    // "far" and kept the jump control. The end marker decides only whether
    // the control is shown. It never changes the follow state: switching to
    // following there made the bottom-follow chase the estimate and hang.
    private var endMarkerY: CGFloat = .infinity
    private var endMarkerVisible = false
    private var readingBottom: CGFloat = 0
    private var endIsInView: Bool {
        endMarkerVisible && readingBottom > 0 && endMarkerY <= readingBottom + 32
    }
    var endMarkerDebug: String { "end=\(endMarkerVisible) endY=\(Int(min(endMarkerY, 99999))) readingBottom=\(Int(readingBottom))" }
    func observeReadingBottom(_ value: CGFloat) {
        guard abs(readingBottom - value) > 0.5 else { return }
        readingBottom = value; publishFollowChange()
    }
    func observeEndMarker(y: CGFloat) {
        guard abs(endMarkerY - y) > 0.5 else { return }
        endMarkerY = y; publishFollowChange()
    }
    func observeEndMarker(visible: Bool) {
        guard endMarkerVisible != visible else { return }
        endMarkerVisible = visible; publishFollowChange()
    }

    func observe(distanceFromBottom: Double) {
        lastDistanceFromBottom = distanceFromBottom.isFinite ? distanceFromBottom : 0
        policy.observe(distanceFromBottom: distanceFromBottom)
        publishFollowChange()
    }
    func setUserScrolling(_ scrolling: Bool) {
        policy.setUserScrolling(scrolling)
        publishFollowChange()
    }
    func requestLatest() {
        policy.requestLatest()
        publishFollowChange()
    }
    private func publishFollowChange() {
        if followsLatest != policy.followsLatest {
            followsLatest = policy.followsLatest
        }
        if isUserScrolling != policy.userIsScrolling { isUserScrolling = policy.userIsScrolling }
        let jump = policy.showsJumpButton && !endIsInView
        if showsJumpButton != jump { showsJumpButton = jump }
    }
}

// The system accessibility value is read-only. Only the separate preview
// target supplies this override; the installed app follows the system value.
private struct ChatPreviewReduceMotionKey: EnvironmentKey {
    static let defaultValue = false
}
extension EnvironmentValues {
    var chatPreviewReduceMotion: Bool {
        get { self[ChatPreviewReduceMotionKey.self] }
        set { self[ChatPreviewReduceMotionKey.self] = newValue }
    }
}

enum ChatMotion {
    // Public SwiftUI springs, not Apple's private Messages curves.
    static let send = Animation.spring(duration: 0.38, bounce: 0.08)
    static let menu = Animation.spring(duration: 0.34, bounce: 0.06)
    // A little bounce lets the glass overshoot as it separates from the plus
    // button; closing settles faster so the panel is absorbed without wobble.
    // Springs retarget from their current state, so repeated taps reverse
    // mid-flight instead of jumping.
    static let menuOpen = Animation.spring(duration: 0.44, bounce: 0.2)
    static let menuClose = Animation.spring(duration: 0.34, bounce: 0.08)
    static let reducedMenu = Animation.easeInOut(duration: 0.15)
    // Rows appear after the glass has begun to grow, and leave before it
    // shrinks, so text never sits outside the moving edge.
    static let menuContentIn = Animation.easeOut(duration: 0.16).delay(0.2)
    static let menuContentOut = Animation.easeIn(duration: 0.08)
    static let resize = Animation.smooth(duration: 0.22)
    static let scroll = Animation.smooth(duration: 0.2)
    static let glassSeparation = Animation.spring(duration: 0.46, bounce: 0.06)
    /// The jump control rises out of the field with a little life and sinks
    /// back without overshoot, so it never bobs above the field as it fuses.
    static let jumpRise = Animation.spring(duration: 0.42, bounce: 0.18)
    static let jumpSink = Animation.spring(duration: 0.38, bounce: 0)
    static let jumpIconIn = Animation.easeOut(duration: 0.16)
    static let jumpIconOut = Animation.easeIn(duration: 0.08)
    static let jumpMaterialize = Animation.easeInOut(duration: 0.26)
    /// Sunk, the circle shrinks to this scale and its center sits this far
    /// inside the field, so it lies wholly within the field's glass.
    static let jumpSunkScale: CGFloat = 0.4
    static let jumpSunkDepth: CGFloat = 11
    /// Close to the system keyboard's own curve, so following the latest
    /// message moves with the keyboard instead of ahead of it.
    static let keyboardFollow = Animation.smooth(duration: 0.3)
    /// One spring drives the composer's whole morph (ComposerPanelMorph).
    /// Folding is unhurried, so the buttons part slowly as it settles; a
    /// small bounce lets them overshoot apart and come back like drops.
    /// Unfolding is quicker: the reader is about to type.
    static let composerFold = Animation.spring(duration: 0.62 * composerSlowdown, bounce: 0.14)
    static let composerUnfold = Animation.spring(duration: 0.5 * composerSlowdown, bounce: 0.08)
    static let reducedComposer = Animation.easeInOut(duration: 0.2 * composerSlowdown)
    #if POCKET_PREVIEW
    /// `--slow-composer` plays the morph five times slower, so the UI
    /// check's back-to-back screenshots (about 0.2 s apart) sample it well.
    private static let composerSlowdown: Double = PreviewProbe.on("--slow-composer") ? 5 : 1
    #else
    private static let composerSlowdown: Double = 1
    #endif

    /// 0 below `from`, 1 above `to`, eased between.
    static func step(_ from: CGFloat, _ to: CGFloat, _ x: CGFloat) -> CGFloat {
        let t = min(1, max(0, (x - from) / (to - from)))
        return t * t * (3 - 2 * t)
    }
}

/// The composer's glass panel on its way into the middle of the three
/// buttons (progress 0 = the panel, 1 = the middle button). The panel
/// narrows and flattens into a pill exactly as wide as the three buttons,
/// whose outer two sit inside it from the start; the pill then keeps
/// narrowing to the middle one, so the shared glass container pinches it
/// into three drops. Unfolding runs the same path back. The content keeps
/// its full-size layout throughout (no text reflow) and is clipped by the
/// shrinking glass; it leaves first and returns last.
struct ComposerPanelMorph: ViewModifier, Animatable {
    var progress: CGFloat
    /// The panel's width and natural height at rest.
    let width: CGFloat
    let height: CGFloat
    let reduceMotion: Bool
    let onHeight: (CGFloat) -> Void
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        let p = min(1, max(0, progress))
        let morphing = p > 0.0005 && width > 0 && height > 0 && !reduceMotion
        let side = ChatMetrics.morphButton
        let pill = 3 * side + 2 * ChatMetrics.morphGap
        let w = width - (width - side) * p
        // Flat by the time the width reaches the pill, easing out.
        let flatten = min(1, p * (width - side) / max(1, width - pill))
        let h = height - (height - side) * (1 - (1 - flatten) * (1 - flatten))
        // At rest the panel is two rows tall, well above twice its radius.
        let shape = RoundedRectangle(cornerRadius: morphing ? min(ChatMetrics.composerRadius, h / 2) : ChatMetrics.composerRadius,
                                     style: .continuous)
        content
            .frame(width: morphing ? width : nil)
            .fixedSize(horizontal: false, vertical: true)
            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { onHeight($0) }
            .opacity(reduceMotion ? 1 : 1 - ChatMotion.step(0, 0.22, p))
            .frame(width: morphing ? w : nil, height: morphing ? h : nil, alignment: .bottom)
            .clipShape(shape)
            .chatGlass(in: shape)
            // Hidden only once it is the middle button's exact shape and
            // place, where that button's own glass takes over.
            .opacity(reduceMotion ? 1 - p : (p > 0.999 ? 0 : 1))
    }
}

/// One of the three buttons of the folded composer, at `slot` -1, 0 or 1
/// (voice, chat, latest). Each rests at its own place; while the panel
/// still covers it, the container draws the two as one glass. Its symbol
/// arrives only once the buttons have parted.
struct ComposerButtonMorph: ViewModifier, Animatable {
    var progress: CGFloat
    let slot: CGFloat
    let symbol: String
    let tint: Color
    let reduceMotion: Bool
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        let side = ChatMetrics.morphButton
        let shape = RoundedRectangle(cornerRadius: side / 2, style: .continuous)
        let reveal = reduceMotion ? min(1, max(0, progress)) : ChatMotion.step(0.72, 0.96, progress)
        // The spring's overshoot past 1 carries the outer buttons a little
        // further apart before they settle.
        let spread = 1 + max(0, progress - 1) * 1.5
        content
            .frame(width: side, height: side)
            .overlay {
                Image(systemName: symbol)
                    .font(.system(size: ChatMetrics.icon, weight: .medium))
                    .foregroundStyle(tint)
                    .scaleEffect(0.6 + 0.4 * reveal)
                    .opacity(reveal)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
            .chatGlass(in: shape, interactive: true)
            .offset(x: slot * (side + ChatMetrics.morphGap) * spread)
            .opacity(reduceMotion ? reveal : (progress > 0.0005 ? 1 : 0))
    }
}

/// Fades what sits above the panel (draft attachments, import status) with
/// the fold: gone before the panel narrows, back once it has unfolded.
struct ComposerFade: ViewModifier, Animatable {
    var progress: CGFloat
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        content.opacity(1 - ChatMotion.step(0, 0.2, progress))
    }
}

/// Notices a reader moving into older messages: a finger-driven scroll, or
/// its coast, that has travelled `ChatMetrics.collapseTravel` toward the
/// top with the end well below the screen. Keyboard, inset and follow
/// scrolls have no finger and never count. The composer then stays folded
/// until its chat button is tapped, so small offset changes cannot replay
/// the morph. `onLeaning` reports a drag heading that way, so the jump
/// control does not rise just before the fold.
struct ComposerFoldObserver: ViewModifier {
    let enabled: Bool
    let onLeaning: (Bool) -> Void
    let onFold: () -> Void
    @State private var travel = ComposerScrollTravel()

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ComposerScrollSample.self) { geometry in
                    ComposerScrollSample(offset: geometry.contentOffset.y,
                                         distance: max(0, geometry.contentSize.height - geometry.readingBottom),
                                         scrollable: geometry.contentSize.height > geometry.containerSize.height + 1)
                } action: { _, sample in
                    guard enabled, travel.dragging, !travel.spent, sample.scrollable else { return }
                    // Measured from the first position the finger moved.
                    guard let start = travel.start else { travel.start = sample.offset; return }
                    let moved = start - sample.offset
                    lean(moved > 6 && sample.distance > 32)
                    guard moved >= ChatMetrics.collapseTravel, sample.distance >= ChatMetrics.collapseDistance else { return }
                    // Once per gesture.
                    travel.spent = true
                    lean(false)
                    onFold()
                }
                .onScrollPhaseChange { _, phase in
                    switch phase {
                    case .tracking, .interacting, .decelerating:
                        travel.dragging = true
                    default:
                        travel.dragging = false; travel.spent = false; travel.start = nil
                        lean(false)
                    }
                }
        } else { content }
    }

    private func lean(_ leaning: Bool) {
        guard travel.leaning != leaning else { return }
        travel.leaning = leaning
        onLeaning(leaning)
    }
}

/// Changes on every scrolled frame, so it is not view state.
@MainActor private final class ComposerScrollTravel {
    /// A finger is on the conversation, or it coasts from one.
    var dragging = false
    /// Where that scroll began, and whether it already folded.
    var start: CGFloat?
    var spent = false
    var leaning = false
}

private struct ComposerScrollSample: Equatable {
    let offset: CGFloat
    let distance: CGFloat
    let scrollable: Bool
}

struct ChatTimestampReveal: ViewModifier {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content.gesture(TimestampPan(onChanged: onChanged, onEnded: onEnded))
        } else {
            content
        }
    }
}

/// Reject rightward pans before recognition, so the system back gesture can
/// complete. Ignoring their translation after a SwiftUI DragGesture has begun
/// still leaves an active recognizer competing with the navigation controller.
@available(iOS 18.0, *)
private struct TimestampPan: UIGestureRecognizerRepresentable {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.cancelsTouchesInView = false
        pan.delegate = context.coordinator
        return pan
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        switch pan.state {
        case .began, .changed:
            onChanged(min(1, max(0, -pan.translation(in: pan.view).x / 90)))
        case .ended, .cancelled, .failed:
            if !Self.probeHold { onEnded() }
        default: break
        }
    }
    #if POCKET_PREVIEW
    private static let probeAnywhere = PreviewProbe.on("--probe-timestamp-anywhere")
    /// Leaves the rows where the swipe left them, for a screenshot after it.
    private static let probeHold = PreviewProbe.on("--probe-timestamp-hold")
    #else
    private static let probeAnywhere = false
    private static let probeHold = false
    #endif
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            return velocity.x < -abs(velocity.y)
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
        /// A swipe on a block that scrolls sideways (a wide table, code or
        /// formula) scrolls that block alone; the rows stay where they are.
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            if TimestampPan.probeAnywhere { return true }
            var view = touch.view
            while let current = view {
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

struct ChatScrollObserver: ViewModifier {
    let onDistance: (Double) -> Void
    let onUserScrolling: (Bool) -> Void
    var onLayout: () -> Void = {}
    /// Bottom of the reading area (above the composer) in the scroll view's
    /// own coordinate space.
    var onReadingBottom: (CGFloat) -> Void = { _ in }
    /// Preview builds only: raw geometry for UI tests to report.
    var onDebug: (String) -> Void = { _ in }
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ScrollMeasurement.self) { geometry in
                    ScrollMeasurement(distance: ChatScrollGeometry.distanceFromBottom(
                        contentHeight: Double(geometry.contentSize.height),
                        visibleBottom: Double(geometry.readingBottom)),
                        contentHeight: geometry.contentSize.height, viewportHeight: geometry.containerSize.height,
                        bottomInset: geometry.contentInsets.bottom, offsetY: geometry.contentOffset.y,
                        topInset: geometry.contentInsets.top)
                } action: { old, new in
                    onReadingBottom(new.viewportHeight - new.bottomInset)
                    onDistance(new.distance)
                    #if POCKET_PREVIEW
                    onDebug(String(format: "d=%.1f content=%.1f offset=%.1f container=%.1f insetTop=%.1f insetBottom=%.1f",
                                   new.distance, new.contentHeight, new.offsetY, new.viewportHeight, new.topInset, new.bottomInset))
                    #endif
                    // Lazy rows revise estimated content height while they
                    // scroll into view. That is not a request to scroll again.
                    // ChatView follows actual message updates separately.
                    if abs(old.viewportHeight - new.viewportHeight) > 0.5
                        || abs(old.bottomInset - new.bottomInset) > 0.5 { onLayout() }
                }
                .onScrollPhaseChange { _, phase in
                    onUserScrolling(phase == .tracking || phase == .interacting || phase == .decelerating)
                }
        } else {
            content.simultaneousGesture(DragGesture().onChanged { _ in
                onUserScrolling(true)
            }.onEnded { _ in onUserScrolling(false) })
        }
    }
}

struct ChatScrollAnchoring: ViewModifier {
    let followsLatest: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            // Only initial placement belongs to the system anchor. Changing
            // the size-change anchor while a lazy stack is estimating rows
            // competes with scrollTo and can keep layout/AX from settling.
            // ChatView owns subsequent, coalesced following explicitly.
            content.defaultScrollAnchor(.bottom, for: .initialOffset)
                .defaultScrollAnchor(.top, for: .alignment)
        } else { content }
    }
}

/// Small, row-local lag during a finger-driven scroll. It changes rendering
/// only, so the spring cannot change measured content height or scroll offset.
struct BubbleScrollSpring: ViewModifier {
    let active: Bool
    let reducedMotion: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *), !reducedMotion {
            content.visualEffect { view, geometry in
                let y = geometry.frame(in: .scrollView(axis: .vertical)).midY
                let height = max(1, geometry.bounds(of: .scrollView(axis: .vertical))?.height ?? 800)
                // Neighbouring rows can differ by at most 3pt, below the
                // stack's 8pt gap. Rendering must never overlap layout.
                return view.offset(y: active ? max(-1.5, min(1.5, (y / height - 0.5) * 3)) : 0)
            }.animation(.spring(duration: 0.42, bounce: 0.22), value: active)
        } else { content }
    }
}

private struct ScrollMeasurement: Equatable {
    let distance: Double
    let contentHeight: CGFloat
    let viewportHeight: CGFloat
    let bottomInset: CGFloat
    var offsetY: CGFloat = 0
    var topInset: CGFloat = 0
}

/// Animate only the newly sent row. No overlay geometry is fed back into the
/// scroll layout, and revisiting an older row does not replay its arrival.
struct OutgoingArrival: ViewModifier {
    let animate: Bool
    @State private var progress: CGFloat
    init(animate: Bool) { self.animate = animate; _progress = State(initialValue: animate ? 0 : 1) }
    func body(content: Content) -> some View {
        // Grow inside the row's final bounds. Translating the entire row
        // 22pt down used to cross into the following assistant bubble.
        content.scaleEffect(0.94 + 0.06 * progress, anchor: .bottomTrailing)
            .opacity(Double(progress))
            .onAppear {
                guard progress < 1 else { return }
                withAnimation(ChatMotion.send) { progress = 1 }
            }
            .onChange(of: animate) { _, enabled in
                if !enabled {
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { progress = 1 }
                }
            }
    }
}

struct ComposerHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = ChatMetrics.control
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ComposerBoundsKey: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        value = nextValue() ?? value
    }
}
struct ChatViewportHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = 800
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ComposerTopKey: PreferenceKey {
    static let defaultValue: CGFloat = .nan
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ConversationBottomKey: PreferenceKey {
    static var defaultValue: CGFloat { 0 }
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

/// Moves the jump control into (and out of) the composer field. Applied as
/// a transition so the glass shapes animate inside their shared container.
struct JumpSink: ViewModifier {
    let offset: CGFloat
    var x: CGFloat = 0
    let scale: CGFloat
    let opacity: Double
    func body(content: Content) -> some View {
        content.scaleEffect(scale).offset(x: x, y: offset).opacity(opacity)
    }
}

@available(iOS 18.0, *)
extension ScrollGeometry {
    /// The content-space y of the bottom of the readable area (above the
    /// composer or other bottom bars). `contentOffset` is the raw offset (it
    /// starts at -contentInsets.top) and `containerSize` already excludes the
    /// insets, as measured in UI tests: subtracting the bottom inset again
    /// left a constant error of top + bottom inset (272pt in a chat), so the
    /// end of a conversation never counted as reached.
    var readingBottom: CGFloat { contentOffset.y + contentInsets.top + containerSize.height }
}
