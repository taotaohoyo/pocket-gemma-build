import SwiftUI
import UIKit
import PocketCore

/// Scroll geometry changes as the lazy stack measures rows. Retain precise
/// position without invalidating that stack for every measurement; publish
/// only the change that controls the jump button.
@MainActor final class ChatScrollState: ObservableObject {
    private var policy = ChatScrollPolicy()
    @Published private(set) var followsLatest = true
    @Published private(set) var isUserScrolling = false
    @Published private(set) var showsJumpButton = false
    /// The reader rests at the end, with a band between arriving and
    /// leaving (ChatEndPresence). Apart from following and from the fold:
    /// a folded composer's latest button flows into its chat button here.
    @Published private(set) var restsAtEnd = true
    private var endPresence = ChatEndPresence()
    var shouldFollowStream: Bool { policy.shouldFollowStream }
    /// Not published: the last measured distance from the visible bottom to
    /// the end of the content. At or below zero the last row is already in
    /// view (a short chat, or the reader is at the end).
    private(set) var lastDistanceFromBottom = 0.0
    // Not published: these change every layout pass. Lazy rows can
    // overestimate contentSize by hundreds of points (d=272 with the reply's
    // end in view, UI test), so a manual return to the end still measured as
    // "far" and kept the jump control. The end marker decides only whether
    // the control is shown. It never changes the follow state: switching to
    // following there made the bottom-follow chase the estimate and hang.
    private var endMarkerY: CGFloat = .infinity
    private var endMarkerVisible = false
    private var readingBottom: CGFloat = 0
    private var endIsInView: Bool {
        endMarkerVisible && readingBottom > 0 && endMarkerY <= readingBottom + 32
    }
    var endMarkerDebug: String { "end=\(endMarkerVisible) endY=\(Int(min(endMarkerY, 99999))) readingBottom=\(Int(readingBottom))" }
    func observeReadingBottom(_ value: CGFloat) {
        guard abs(readingBottom - value) > 0.5 else { return }
        readingBottom = value; publishFollowChange()
    }
    func observeEndMarker(y: CGFloat) {
        guard abs(endMarkerY - y) > 0.5 else { return }
        endMarkerY = y; publishFollowChange()
    }
    func observeEndMarker(visible: Bool) {
        guard endMarkerVisible != visible else { return }
        endMarkerVisible = visible; publishFollowChange()
    }

    func observe(distanceFromBottom: Double) {
        lastDistanceFromBottom = distanceFromBottom.isFinite ? distanceFromBottom : 0
        policy.observe(distanceFromBottom: distanceFromBottom)
        endPresence.observe(distanceFromBottom: distanceFromBottom)
        if restsAtEnd != endPresence.atEnd { restsAtEnd = endPresence.atEnd }
        publishFollowChange()
    }
    func setUserScrolling(_ scrolling: Bool) {
        policy.setUserScrolling(scrolling)
        publishFollowChange()
    }
    func requestLatest() {
        policy.requestLatest()
        publishFollowChange()
    }
    private func publishFollowChange() {
        if followsLatest != policy.followsLatest {
            followsLatest = policy.followsLatest
        }
        if isUserScrolling != policy.userIsScrolling { isUserScrolling = policy.userIsScrolling }
        let jump = policy.showsJumpButton && !endIsInView
        if showsJumpButton != jump { showsJumpButton = jump }
    }
}

// The system accessibility value is read-only. Only the separate preview
// target supplies this override; the installed app follows the system value.
private struct ChatPreviewReduceMotionKey: EnvironmentKey {
    static let defaultValue = false
}
extension EnvironmentValues {
    var chatPreviewReduceMotion: Bool {
        get { self[ChatPreviewReduceMotionKey.self] }
        set { self[ChatPreviewReduceMotionKey.self] = newValue }
    }
}

enum ChatMotion {
    // Public SwiftUI springs, not Apple's private Messages curves.
    static let send = Animation.spring(duration: 0.38, bounce: 0.08)
    static let menu = Animation.spring(duration: 0.34, bounce: 0.06)
    // A little bounce lets the glass overshoot as it separates from the plus
    // button; closing settles faster so the panel is absorbed without wobble.
    // Springs retarget from their current state, so repeated taps reverse
    // mid-flight instead of jumping.
    static let menuOpen = Animation.spring(duration: 0.44, bounce: 0.2)
    static let menuClose = Animation.spring(duration: 0.34, bounce: 0.08)
    static let reducedMenu = Animation.easeInOut(duration: 0.15)
    // Rows appear after the glass has begun to grow, and leave before it
    // shrinks, so text never sits outside the moving edge.
    static let menuContentIn = Animation.easeOut(duration: 0.16).delay(0.2)
    static let menuContentOut = Animation.easeIn(duration: 0.08)
    static let resize = Animation.smooth(duration: 0.22)
    /// A long table or a long code block folding and opening.
    static let blockFold = Animation.snappy(duration: 0.3)
    /// Colours changing in place: a code block's, once its language is known.
    static let recolor = Animation.easeInOut(duration: 0.25)

    // Values that were written where they were used until 1.1.0 (263); the
    // numbers are the ones each place had.
    /// With Reduce Motion, a short fade where something would move.
    static let reduced = Animation.easeInOut(duration: 0.2)
    /// Something fading as the conversation gains or loses its first message.
    static let fade = Animation.easeOut(duration: 0.25)
    /// A pill telling a new state (検索オン, ファイル作成オン).
    static let pillState = Animation.smooth(duration: 0.3)
    /// The send button between its looks (send, stop, record).
    static let sendLook = Animation.smooth(duration: 0.25)
    /// The history beside the iPad's conversation coming and going;
    /// 前回の会話に戻る rising into its room. The phone's drawer moves
    /// frame by frame instead (HistoryDrawerMotion, 1.1.0 (272)).
    static let drawer = Animation.spring(duration: 0.4, bounce: 0)
    /// A line going before the room it held closes.
    static let leave = Animation.easeOut(duration: 0.18)
    /// A ring or a bar reaching a new amount (Claude's credit).
    static let gauge = Animation.smooth(duration: 0.5)
    /// A chart's marks growing in, once, and the mark a finger picks.
    static let chartGrow = Animation.easeOut(duration: 0.6)
    static let chartSelect = Animation.snappy(duration: 0.25)
    /// A thumbnail arriving in the place kept for it.
    static let thumbnail = Animation.easeOut(duration: 0.18)
    /// The orb coming and going.
    static let orbIn = Animation.easeOut(duration: 0.2)
    static let orbOut = Animation.easeIn(duration: 0.18)
    /// A recording's bars between two samples of the microphone.
    static let level = Animation.linear(duration: 0.05)
    /// Pulling up for a new chat: the button popping out of the full ring
    /// (its bounce was 0.4, twice any other here), going back when the pull
    /// eases off, and the ring leaving once the pull was taken.
    static let pullArm = Animation.spring(duration: 0.32, bounce: 0.2)
    static let pullDisarm = Animation.spring(duration: 0.32)
    static let pullRelease = Animation.easeOut(duration: 0.2)
    /// Posted by a reply's row as what stands under the written reply comes
    /// in (1.1.0 (263)); the conversation follows it down.
    static let replySettled = Notification.Name("PocketAI.replySettled")
    static let scroll = Animation.smooth(duration: 0.2)
    static let glassSeparation = Animation.spring(duration: 0.46, bounce: 0.06)
    /// The jump control rises out of the field with a little life and sinks
    /// back without overshoot, so it never bobs above the field as it fuses.
    static let jumpRise = Animation.spring(duration: 0.42, bounce: 0.18)
    static let jumpSink = Animation.spring(duration: 0.38, bounce: 0)
    static let jumpIconIn = Animation.easeOut(duration: 0.16)
    static let jumpIconOut = Animation.easeIn(duration: 0.08)
    static let jumpMaterialize = Animation.easeInOut(duration: 0.26)
    /// The folded composer's latest button flowing into its chat button at
    /// the end, without overshoot so it never bobs back out, and drawn out
    /// of it again with a little life, a drop settling into its place.
    static let jumpAbsorb = Animation.spring(duration: 0.5, bounce: 0)
    static let jumpSplit = Animation.spring(duration: 0.56, bounce: 0.14)
    static let reducedJumpTuck = Animation.easeInOut(duration: 0.2)
    /// Sunk, the circle shrinks to this scale and its center sits this far
    /// inside the field, so it lies wholly within the field's glass.
    static let jumpSunkScale: CGFloat = 0.4
    static let jumpSunkDepth: CGFloat = 11
    /// Close to the system keyboard's own curve, so following the latest
    /// message moves with the keyboard instead of ahead of it.
    static let keyboardFollow = Animation.smooth(duration: 0.3)
    /// スタンダード's bar opening into the panel as the keyboard comes up,
    /// and closing as it goes (1.1.0 (255)): the glass grows up from the
    /// bar with a touch of give, and settles back without any. Its pills
    /// arrive once the text has risen off their line (about two thirds of
    /// the way) and leave at once. Since 1.1.0 (274) the bar at rest is
    /// narrower, and it widens and draws in on the same springs.
    static let standardOpen = Animation.spring(duration: 0.44 * standardSlowdown, bounce: 0.1)
    static let standardClose = Animation.spring(duration: 0.36 * standardSlowdown, bounce: 0)
    static let standardPillsIn = Animation.easeOut(duration: 0.2 * standardSlowdown).delay(0.16 * standardSlowdown)
    static let standardPillsOut = Animation.easeIn(duration: 0.09 * standardSlowdown)
    static let standardPillSlide: CGFloat = 12
    #if POCKET_PREVIEW
    /// `--slow-standard` plays スタンダード's opening and closing five times
    /// slower, so the UI check's frames from the recording, a few hundred
    /// milliseconds apart at worst, see the bar widen and draw in (274).
    private static let standardSlowdown: Double = PreviewProbe.on("--slow-standard") ? 5 : 1
    #else
    private static let standardSlowdown: Double = 1
    #endif
    /// One progress drives the composer's whole morph (ComposerMorphPath).
    /// Folding is a spring: the panel contracts briskly, and its slowing
    /// tail lets the drops part and their bridges snap where the eye can
    /// follow; a small bounce carries them a little further apart, like
    /// drops. Unfolding starts slowly, so the buttons are seen flowing
    /// together before the panel swells out and settles, with no bounce:
    /// the reader is about to type.
    static let composerFold = Animation.spring(duration: 0.75 * composerSlowdown, bounce: 0.12)
    static let composerUnfold = Animation.timingCurve(0.45, 0, 0.25, 1, duration: 0.56 * composerSlowdown)
    static let reducedComposer = Animation.easeInOut(duration: 0.2 * composerSlowdown)
    #if POCKET_PREVIEW
    /// `--slow-composer` plays the morph five times slower, so the UI
    /// check's back-to-back screenshots (about 0.2 s apart) sample it well.
    private static let composerSlowdown: Double = PreviewProbe.on("--slow-composer") ? 5 : 1
    #else
    private static let composerSlowdown: Double = 1
    #endif

    /// 0 below `from`, 1 above `to`, eased between.
    static func step(_ from: CGFloat, _ to: CGFloat, _ x: CGFloat) -> CGFloat {
        let t = min(1, max(0, (x - from) / (to - from)))
        return t * t * (3 - 2 * t)
    }
}

/// The fold's one path, shared by the panel and the three buttons
/// (progress 0 = the panel at rest, 1 = the buttons). First the panel
/// contracts, its height ahead of its width, so it is squeezed into a wide
/// pill and then narrows to a capsule exactly as wide as the three buttons
/// overlapping (`gather` apart). Then the capsule draws in to the middle
/// button while the outer two travel out of its ends: three overlapping
/// drops with waists between them, then drops held by thinning bridges
/// that the glass container draws, pulled thin, until they are
/// `ChatMetrics.composerBlend` apart and snap, and coast to their places.
/// Unfolding runs the same path back: the buttons flow together into one
/// capsule that swells into the panel.
enum ComposerMorphPath {
    static let side = ChatMetrics.morphButton
    /// From the middle button's center to an outer one's, at rest.
    static let pitch = ChatMetrics.morphButton + ChatMetrics.morphGap
    /// Where the outer buttons start, inside the capsule.
    static let gather: CGFloat = 30
    static let capsule = 2 * (gather + side / 2)

    /// The panel's contraction: its height, then its width.
    static func flatten(_ p: CGFloat) -> CGFloat { ChatMotion.step(0, 0.36, p) }
    static func narrow(_ p: CGFloat) -> CGFloat { ChatMotion.step(0.04, 0.6, p) }
    /// The split. Linear, so the spring's slow tail lingers on the bridges.
    static func split(_ p: CGFloat) -> CGFloat { min(1, max(0, (p - 0.45) / 0.55)) }
    /// The capsule drawing in to the middle button, early in the split.
    static func gatherIn(_ p: CGFloat) -> CGFloat { ChatMotion.step(0, 0.45, split(p)) }
    /// The outer buttons' distance from the middle. A spring's overshoot
    /// past 1 carries them a little further before they settle.
    static func outer(_ p: CGFloat) -> CGFloat {
        gather + (pitch - gather) * split(p) + max(0, p - 1) * 1.5 * pitch
    }
    /// How far the drops are pulled thin (0 to 1): growing while the
    /// bridges stretch, most just before they snap (the gap reaches the
    /// blend distance at about 0.85 of the split), gone once at rest.
    static func stretch(_ p: CGFloat) -> CGFloat {
        let s = split(p)
        return ChatMotion.step(0.35, 0.82, s) * (1 - ChatMotion.step(0.82, 1, s))
    }
}

/// The folded composer's latest button flowing into the chat button and
/// back out (0 = in its place, 1 = inside the chat button). It travels in
/// a straight line, the spring giving the pace. Nearing, it is caught by
/// the glass container's bridge and pulled thin toward the middle; it
/// shrinks on the way so that, taken in, it lies wholly inside the chat
/// button, which swells a little toward it as it arrives and settles. Its
/// arrow leaves as it sets off. Splitting runs the same path back: the
/// chat button swells to the right, a drop pulls away on a thinning
/// bridge and becomes the button, and the arrow returns as it settles.
/// The two that stay close up around the middle as it goes in, half a
/// pitch each (device check of 1.0.118: left where they were, they looked
/// lopsided), and go back to their places as it comes out. The voice
/// button sets off a little ahead, so that the gap between them narrows
/// into the glass container's reach and a thin bridge holds them while
/// they move; each is drawn out along its way.
enum JumpTuckPath {
    static let gather = ComposerMorphPath.pitch / 2
    static func voiceGather(_ t: CGFloat) -> CGFloat { ChatMotion.step(0.05, 0.8, t) }
    static func chatGather(_ t: CGFloat) -> CGFloat { ChatMotion.step(0.12, 0.9, t) }
    static func drift(_ t: CGFloat) -> CGFloat {
        ChatMotion.step(0.08, 0.35, t) * (1 - ChatMotion.step(0.5, 0.88, t))
    }
    static func scale(_ t: CGFloat) -> CGFloat { 1 - 0.45 * ChatMotion.step(0.3, 1, t) }
    static func stretch(_ t: CGFloat) -> CGFloat {
        ChatMotion.step(0.04, 0.2, t) * (1 - ChatMotion.step(0.3, 0.6, t))
    }
    static func swell(_ t: CGFloat) -> CGFloat {
        ChatMotion.step(0.45, 0.8, t) * (1 - ChatMotion.step(0.8, 1, t))
    }
    static func arrow(_ t: CGFloat) -> CGFloat { 1 - ChatMotion.step(0.02, 0.25, t) }
    /// Its glass goes off only once it lies inside the chat button's.
    static let glassOff: CGFloat = 0.97
}

/// 従来型's 高速 and model pills going into the field and coming out of
/// it as the folded composer's latest button goes into the chat button and
/// comes out (JumpTuckPath, the same curve and springs), straight down
/// instead of sideways (user, 2026-10-23: the bottom buttons' in and out,
/// exactly). `tuck` 0 is the pill in its place, 1 its drop inside the
/// field, `depth` below. The label and the pill's quiet fill leave as the
/// arrow does; the size is the glass shape's own (a scale effect around a
/// glass in a container drew a second, unscaled outline on the phone,
/// 1.1.0 (138)).
struct ClassicPillTuck<Label: View>: ViewModifier, Animatable {
    var tuck: CGFloat
    let width: CGFloat
    let depth: CGFloat
    /// Off while the pill itself stands in the drop's place.
    let shown: Bool
    let label: Label
    var animatableData: CGFloat {
        get { tuck }
        set { tuck = newValue }
    }

    func body(content: Content) -> some View {
        let t = tuck
        let pull = JumpTuckPath.stretch(t)
        let scale = JumpTuckPath.scale(t)
        // Drawn out along its way, as the latest button is.
        let w = max(0, width * scale - 4 * pull)
        let h = ChatMetrics.chip * scale + 8 * pull
        let reveal = shown ? JumpTuckPath.arrow(t) : 0
        content
            .frame(width: w, height: h)
            .background(Capsule().fill(Theme.chipFill).opacity(reveal))
            .overlay {
                // Laid out at the pill's width, so it never changes form.
                label
                    .foregroundStyle(.primary)
                    .frame(width: max(0, width - 24))
                    .fixedSize(horizontal: true, vertical: false)
                    .scaleEffect(0.6 + 0.4 * reveal)
                    .opacity(reveal)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
            .chatGlass(in: Capsule(), visible: shown && t < JumpTuckPath.glassOff)
            .offset(y: depth * t + 4 * pull)
    }
}

private typealias Morph = ComposerMorphPath

/// The composer's glass panel along the fold (ComposerMorphPath), until it
/// is the middle button. The content keeps its full-size layout throughout
/// (no text reflow) and is clipped by the shrinking glass; it leaves first
/// and returns last.
struct ComposerPanelMorph: ViewModifier, Animatable {
    var progress: CGFloat
    /// The latest button's tuck (JumpTuckPath): folded at the end, the
    /// middle button sits right of the middle, and the panel unfolds from
    /// there, drawing back to the middle as the drops gather.
    var tuck: CGFloat = 0
    /// The panel's width and natural height at rest.
    let width: CGFloat
    let height: CGFloat
    /// Its corners at rest: the panel's 22pt, or スタンダード's bar, round at
    /// its ends, rounding into the panel's as it opens (1.1.0 (255)).
    var radius: CGFloat = ChatMetrics.composerRadius
    let reduceMotion: Bool
    let onHeight: (CGFloat) -> Void
    var animatableData: AnimatablePair<AnimatablePair<CGFloat, CGFloat>, CGFloat> {
        get { AnimatablePair(AnimatablePair(progress, tuck), radius) }
        set { progress = newValue.first.first; tuck = newValue.first.second; radius = newValue.second }
    }

    func body(content: Content) -> some View {
        let p = min(1, max(0, progress))
        let morphing = p > 0.0005 && width > 0 && height > 0 && !reduceMotion
        let flatten = Morph.flatten(p), stretch = Morph.stretch(p)
        let narrowed = width + (Morph.capsule - width) * Morph.narrow(p)
        // Pulled sideways by the outer drops, and thinner for it.
        let w = narrowed + (Morph.side - narrowed) * Morph.gatherIn(p) + 10 * stretch
        let h = height + (Morph.side - height) * flatten - 6 * stretch
        // The corners round out with the height, ending as a circle. At
        // rest the panel is well above twice its radius.
        let corner = radius + (Morph.side / 2 - radius) * flatten
        let shape = RoundedRectangle(cornerRadius: morphing ? min(corner, h / 2) : radius, style: .continuous)
        content
            .frame(width: morphing ? width : nil)
            .fixedSize(horizontal: false, vertical: true)
            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { onHeight($0) }
            // Faded inside the glass, which an outer opacity would not
            // reach, and drawn in a little as the glass takes it.
            .opacity(reduceMotion ? 1 - p : 1 - ChatMotion.step(0, 0.22, p))
            .scaleEffect(reduceMotion ? 1 : 1 - 0.04 * ChatMotion.step(0, 0.22, p), anchor: .bottom)
            .frame(width: morphing ? w : nil, height: morphing ? h : nil, alignment: .bottom)
            .clipShape(shape)
            // Off only once it is the middle button's exact shape and place,
            // where that button's own glass takes over. With Reduce Motion
            // the panel keeps its shape and the glass changes over halfway
            // through the cross-fade.
            .chatGlass(in: shape, visible: reduceMotion ? p < 0.5 : p <= 0.999)
            .offset(x: reduceMotion ? 0 : JumpTuckPath.gather * JumpTuckPath.chatGather(tuck) * Morph.split(p))
    }
}

/// スタンダード's pills (1.1.0 (255)): the bar at rest has no room for them,
/// so they are away, a little toward the plus; as it opens they come once
/// the text has risen off their line, and as it closes they leave first.
/// Their opacity alone carries them, their glass staying on: none of them
/// is given its glass later, which on the phone left 205's row unanswering
/// (209). The row is outside every glass container, where an outer
/// opacity reaches the glass. With Reduce Motion they only fade.
struct StandardPillReveal: ViewModifier {
    let shown: Bool
    let reduceMotion: Bool
    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(x: shown || reduceMotion ? 0 : -ChatMotion.standardPillSlide)
            .animation(reduceMotion ? ChatMotion.reducedMenu
                       : (shown ? ChatMotion.standardPillsIn : ChatMotion.standardPillsOut), value: shown)
            .allowsHitTesting(shown)
            .accessibilityHidden(!shown)
    }
}

/// One of the three buttons of the folded composer, at `slot` -1, 0 or 1
/// (voice, chat, latest), along ComposerMorphPath. The outer two travel
/// out of the panel's capsule, stretched toward the middle while the glass
/// bridges hold them; the middle one's glass shows only once the panel has
/// become it. Each symbol arrives as its drop takes shape. `tuck` moves
/// the latest button into the chat button and out (JumpTuckPath); the
/// chat button swells toward it, and the voice and chat buttons close up
/// around the middle. With Reduce Motion it fades in place while the other
/// two slide over.
struct ComposerButtonMorph: ViewModifier, Animatable {
    var progress: CGFloat
    var tuck: CGFloat = 0
    let slot: CGFloat
    let symbol: String
    let symbolSize: CGFloat
    let tint: Color
    let reduceMotion: Bool
    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get { AnimatablePair(progress, tuck) }
        set { progress = newValue.first; tuck = newValue.second }
    }

    func body(content: Content) -> some View {
        let side = Morph.side
        let outer = slot != 0, latest = slot > 0
        let stretch = reduceMotion || !outer ? 0 : Morph.stretch(progress)
        let t = tuck
        let pull = reduceMotion || !latest ? 0 : JumpTuckPath.stretch(t)
        let swell = reduceMotion || slot != 0 ? 0 : JumpTuckPath.swell(t)
        let scale = reduceMotion || !latest ? 1 : JumpTuckPath.scale(t)
        // The voice and chat buttons close up around the middle; once the
        // drops have parted, by all of it (the panel unfolds from there).
        let gathered = slot < 0 ? JumpTuckPath.voiceGather(t) : JumpTuckPath.chatGather(t)
        let gather = latest ? 0 : JumpTuckPath.gather * (reduceMotion ? min(1, max(0, t))
            : gathered * Morph.split(progress))
        let drift = reduceMotion || latest ? 0 : JumpTuckPath.drift(t)
        let w = (side + 8 * stretch) * scale + 8 * pull + 6 * swell + (slot < 0 ? 4 : 3) * drift
        let h = (side - 4 * stretch) * scale - 4 * pull - 2 * drift
        let shape = RoundedRectangle(cornerRadius: min(w, h) / 2, style: .continuous)
        let arrival = reduceMotion ? min(1, max(0, progress))
            : outer ? ChatMotion.step(0.8, 0.98, progress) : ChatMotion.step(0.62, 0.86, progress)
        let reveal = !latest ? arrival : arrival * (reduceMotion ? 1 - min(1, max(0, t)) : JumpTuckPath.arrow(t))
        let glass = (reduceMotion ? progress >= 0.5 : outer ? progress > 0.0005 : progress > 0.999)
            && (!latest || t < (reduceMotion ? 0.5 : JumpTuckPath.glassOff))
        // Leaning toward the middle while it holds them; the latest button
        // travels in by `tuck` of the way to where the chat button is going,
        // which leans to meet it.
        let away = reduceMotion || !latest ? 1 : 1 - t
        let into = reduceMotion || !latest ? 0
            : t * JumpTuckPath.gather * JumpTuckPath.chatGather(t) * Morph.split(progress)
        let x = reduceMotion ? slot * Morph.pitch + gather
            : slot * (Morph.outer(progress) - 4 * stretch) * away + into + gather
                - 4 * pull + 3 * swell
        content
            .frame(width: w, height: h)
            .overlay {
                Image(systemName: symbol)
                    .font(.system(size: symbolSize, weight: .medium))
                    .foregroundStyle(tint)
                    .scaleEffect(reduceMotion ? 1 : 0.6 + 0.4 * reveal)
                    .opacity(reveal)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
            .chatGlass(in: shape, interactive: true, visible: glass)
            .offset(x: x)
            // Over the chat button the latest button takes no taps: they
            // are the chat button's until it has nearly drawn clear.
            .allowsHitTesting(!latest || t < 0.35)
    }
}

/// Fades what sits above the panel (draft attachments, import status) with
/// the fold: gone before the panel narrows, back once it has unfolded.
struct ComposerFade: ViewModifier, Animatable {
    var progress: CGFloat
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        content.opacity(1 - ChatMotion.step(0, 0.2, progress))
    }
}

/// The panel's row of buttons, which lies over the panel instead of in its
/// glass (ChatView.composerRowOverlay), so the shrinking glass cannot clip
/// it. It leaves like the panel's content, drawn in toward the bottom, and
/// sooner: gone by 0.12, while the panel's sides are still outside the
/// plus and send (about 4pt of the 12pt between them have closed).
struct ComposerRowFade: ViewModifier, Animatable {
    var progress: CGFloat
    let reduceMotion: Bool
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        let p = min(1, max(0, progress))
        content
            .opacity(reduceMotion ? 1 - p : 1 - ChatMotion.step(0, 0.12, p))
            .scaleEffect(reduceMotion ? 1 : 1 - 0.04 * ChatMotion.step(0, 0.12, p), anchor: .bottom)
    }
}

/// Notices a reader moving into older messages: a finger-driven scroll, or
/// its coast, that has travelled `ChatMetrics.collapseTravel` toward the
/// top with the end well below the screen. Keyboard, inset and follow
/// scrolls have no finger and never count. The composer then stays folded
/// until its chat button is tapped, so small offset changes cannot replay
/// the morph. Only a scroll whose finger came down while the panel showed
/// can fold it: one the chat button opened in the middle of, coast and
/// all, never folds it again (device report on 1.0.111, where a tap while
/// scrolling seemed not to open it). `onLeaning` reports a drag heading
/// that way, so the jump control does not rise just before the fold.
struct ComposerFoldObserver: ViewModifier {
    let enabled: Bool
    let onLeaning: (Bool) -> Void
    let onFold: () -> Void
    @State private var travel = ComposerScrollTravel()

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ComposerScrollSample.self) { geometry in
                    ComposerScrollSample(offset: geometry.contentOffset.y,
                                         distance: max(0, geometry.contentSize.height - geometry.readingBottom),
                                         scrollable: geometry.contentSize.height > geometry.containerSize.height + 1)
                } action: { _, sample in
                    guard enabled, travel.armed, sample.scrollable else { return }
                    // Measured from the first position the finger moved.
                    guard let start = travel.start else { travel.start = sample.offset; return }
                    let moved = start - sample.offset
                    lean(moved > 6 && sample.distance > 32)
                    guard moved >= ChatMetrics.collapseTravel, sample.distance >= ChatMetrics.collapseDistance else { return }
                    // Once per gesture.
                    travel.armed = false
                    lean(false)
                    onFold()
                }
                .onScrollPhaseChange { old, phase in
                    switch phase {
                    case .tracking, .interacting:
                        // A finger comes down, or catches a coasting scroll.
                        if old != .tracking && old != .interacting { travel.begin(armed: enabled) }
                    case .decelerating:
                        break
                    default:
                        travel.begin(armed: false)
                        lean(false)
                    }
                }
                .onChange(of: enabled) { _, allowed in
                    if allowed { travel.begin(armed: false) }
                }
        } else { content }
    }

    private func lean(_ leaning: Bool) {
        guard travel.leaning != leaning else { return }
        travel.leaning = leaning
        onLeaning(leaning)
    }
}

/// Changes on every scrolled frame, so it is not view state.
@MainActor private final class ComposerScrollTravel {
    /// This scroll (a finger on the conversation, or its coast) may still
    /// fold the composer, measured from `start`.
    var armed = false
    var start: CGFloat?
    var leaning = false
    func begin(armed: Bool) { self.armed = armed; start = nil }
}

private struct ComposerScrollSample: Equatable {
    let offset: CGFloat
    let distance: CGFloat
    let scrollable: Bool
}

/// How far the conversation is swiped aside to show each message's time
/// (0 to 1). By reference: the swipe writes it every frame, and only each
/// row's offset and time label read it (`ChatTimestampSlide`,
/// `ChatTimestampLabel`). As a value of the chat's own state (until 1.1.0
/// (262)) every frame of the swipe ran the whole chat's body and each
/// row's, which compared and laid out every message again (UI review,
/// 2026-11-11).
@Observable @MainActor final class ChatTimestampSwipe {
    var reveal: CGFloat = 0
}

struct ChatTimestampReveal: ViewModifier {
    let swipe: ChatTimestampSwipe
    let reduceMotion: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content.gesture(TimestampPan(onChanged: { swipe.reveal = $0 }, onEnded: {
                withAnimation(reduceMotion ? nil : ChatMotion.resize) { swipe.reveal = 0 }
            }))
            .environment(swipe)
        } else {
            content
        }
    }
}

/// A row's content moved aside by the swipe.
struct ChatTimestampSlide: ViewModifier {
    @Environment(ChatTimestampSwipe.self) private var swipe: ChatTimestampSwipe?
    func body(content: Content) -> some View {
        content.offset(x: -72 * (swipe?.reveal ?? 0))
    }
}

/// A message's time, in the room the swipe opens at the row's trailing edge.
struct ChatTimestampLabel: View {
    let date: Date
    @Environment(ChatTimestampSwipe.self) private var swipe: ChatTimestampSwipe?
    var body: some View {
        let reveal = swipe?.reveal ?? 0
        Text(date, style: .time)
            .font(.system(size: 11)).foregroundStyle(.secondary)
            .frame(width: 64).opacity(Double(reveal))
            .accessibilityHidden(reveal == 0)
    }
}

/// Reject rightward pans before recognition, so the system back gesture can
/// complete. Ignoring their translation after a SwiftUI DragGesture has begun
/// still leaves an active recognizer competing with the navigation controller.
@available(iOS 18.0, *)
private struct TimestampPan: UIGestureRecognizerRepresentable {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.cancelsTouchesInView = false
        pan.delegate = context.coordinator
        return pan
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        switch pan.state {
        case .began, .changed:
            onChanged(min(1, max(0, -pan.translation(in: pan.view).x / 90)))
        case .ended, .cancelled, .failed:
            if !Self.probeHold { onEnded() }
        default: break
        }
    }
    #if POCKET_PREVIEW
    private static let probeAnywhere = PreviewProbe.on("--probe-timestamp-anywhere")
    /// Leaves the rows where the swipe left them, for a screenshot after it.
    private static let probeHold = PreviewProbe.on("--probe-timestamp-hold")
    #else
    private static let probeAnywhere = false
    private static let probeHold = false
    #endif
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            return velocity.x < -abs(velocity.y)
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
        /// A swipe on a block that scrolls sideways (a wide table, code or
        /// formula) scrolls that block alone; the rows stay where they are.
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            if TimestampPan.probeAnywhere { return true }
            var view = touch.view
            while let current = view {
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

struct ChatScrollObserver: ViewModifier {
    let onDistance: (Double) -> Void
    let onUserScrolling: (Bool) -> Void
    var onLayout: () -> Void = {}
    /// Bottom of the reading area (above the composer) in the scroll view's
    /// own coordinate space.
    var onReadingBottom: (CGFloat) -> Void = { _ in }
    /// Preview builds only: raw geometry for UI tests to report.
    var onDebug: (String) -> Void = { _ in }
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ScrollMeasurement.self) { geometry in
                    ScrollMeasurement(distance: ChatScrollGeometry.distanceFromBottom(
                        contentHeight: Double(geometry.contentSize.height),
                        visibleBottom: Double(geometry.readingBottom)),
                        contentHeight: geometry.contentSize.height, viewportHeight: geometry.containerSize.height,
                        bottomInset: geometry.contentInsets.bottom, offsetY: geometry.contentOffset.y,
                        topInset: geometry.contentInsets.top)
                } action: { old, new in
                    onReadingBottom(new.viewportHeight - new.bottomInset)
                    onDistance(new.distance)
                    #if POCKET_PREVIEW
                    onDebug(String(format: "d=%.1f content=%.1f offset=%.1f container=%.1f insetTop=%.1f insetBottom=%.1f",
                                   new.distance, new.contentHeight, new.offsetY, new.viewportHeight, new.topInset, new.bottomInset))
                    #endif
                    // Lazy rows revise estimated content height while they
                    // scroll into view. That is not a request to scroll again.
                    // ChatView follows actual message updates separately.
                    if abs(old.viewportHeight - new.viewportHeight) > 0.5
                        || abs(old.bottomInset - new.bottomInset) > 0.5 { onLayout() }
                }
                .onScrollPhaseChange { _, phase in
                    onUserScrolling(phase == .tracking || phase == .interacting || phase == .decelerating)
                }
        } else {
            content.simultaneousGesture(DragGesture().onChanged { _ in
                onUserScrolling(true)
            }.onEnded { _ in onUserScrolling(false) })
        }
    }
}

struct ChatScrollAnchoring: ViewModifier {
    let followsLatest: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            // Only initial placement belongs to the system anchor. Changing
            // the size-change anchor while a lazy stack is estimating rows
            // competes with scrollTo and can keep layout/AX from settling.
            // ChatView owns subsequent, coalesced following explicitly.
            content.defaultScrollAnchor(.bottom, for: .initialOffset)
                .defaultScrollAnchor(.top, for: .alignment)
        } else { content }
    }
}

private struct ScrollMeasurement: Equatable {
    let distance: Double
    let contentHeight: CGFloat
    let viewportHeight: CGFloat
    let bottomInset: CGFloat
    var offsetY: CGFloat = 0
    var topInset: CGFloat = 0
}

/// Animate only the newly sent row. No overlay geometry is fed back into the
/// scroll layout, and revisiting an older row does not replay its arrival.
struct OutgoingArrival: ViewModifier {
    let animate: Bool
    @State private var progress: CGFloat
    init(animate: Bool) { self.animate = animate; _progress = State(initialValue: animate ? 0 : 1) }
    func body(content: Content) -> some View {
        // Grow inside the row's final bounds. Translating the entire row
        // 22pt down used to cross into the following assistant bubble.
        content.scaleEffect(0.94 + 0.06 * progress, anchor: .bottomTrailing)
            .opacity(Double(progress))
            .onAppear {
                guard progress < 1 else { return }
                withAnimation(ChatMotion.send) { progress = 1 }
            }
            .onChange(of: animate) { _, enabled in
                if !enabled {
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { progress = 1 }
                }
            }
    }
}

struct ComposerHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = ChatMetrics.control
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ComposerBoundsKey: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        value = nextValue() ?? value
    }
}
struct ChatViewportHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = 800
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ComposerTopKey: PreferenceKey {
    static let defaultValue: CGFloat = .nan
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ConversationBottomKey: PreferenceKey {
    static var defaultValue: CGFloat { 0 }
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

/// Moves the jump control into (and out of) the composer field. Applied as
/// a transition so the glass shapes animate inside their shared container.
struct JumpSink: ViewModifier {
    let offset: CGFloat
    var x: CGFloat = 0
    let scale: CGFloat
    let opacity: Double
    func body(content: Content) -> some View {
        content.scaleEffect(scale).offset(x: x, y: offset).opacity(opacity)
    }
}

@available(iOS 18.0, *)
extension ScrollGeometry {
    /// The content-space y of the bottom of the readable area (above the
    /// composer or other bottom bars). `contentOffset` is the raw offset (it
    /// starts at -contentInsets.top) and `containerSize` already excludes the
    /// insets, as measured in UI tests: subtracting the bottom inset again
    /// left a constant error of top + bottom inset (272pt in a chat), so the
    /// end of a conversation never counted as reached.
    var readingBottom: CGFloat { contentOffset.y + contentInsets.top + containerSize.height }
}
