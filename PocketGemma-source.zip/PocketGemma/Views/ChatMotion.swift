import SwiftUI
import UIKit
import PocketCore

/// Scroll geometry changes as the lazy stack measures rows. Retain precise
/// position without invalidating that stack for every measurement; publish
/// only the change that controls the jump button.
@MainActor final class ChatScrollState: ObservableObject {
    private var policy = ChatScrollPolicy()
    @Published private(set) var followsLatest = true
    @Published private(set) var isUserScrolling = false
    @Published private(set) var showsJumpButton = false
    var shouldFollowStream: Bool { policy.shouldFollowStream }
    /// Not published: the last measured distance from the visible bottom to
    /// the end of the content. At or below zero the last row is already in
    /// view (a short chat, or the reader is at the end).
    private(set) var lastDistanceFromBottom = 0.0
    // Not published: these change every layout pass. Lazy rows can
    // overestimate contentSize by hundreds of points (d=272 with the reply's
    // end in view, UI test), so a manual return to the end still measured as
    // "far" and kept the jump control. The end marker decides only whether
    // the control is shown. It never changes the follow state: switching to
    // following there made the bottom-follow chase the estimate and hang.
    private var endMarkerY: CGFloat = .infinity
    private var endMarkerVisible = false
    private var readingBottom: CGFloat = 0
    private var endIsInView: Bool {
        endMarkerVisible && readingBottom > 0 && endMarkerY <= readingBottom + 32
    }
    var endMarkerDebug: String { "end=\(endMarkerVisible) endY=\(Int(min(endMarkerY, 99999))) readingBottom=\(Int(readingBottom))" }
    func observeReadingBottom(_ value: CGFloat) {
        guard abs(readingBottom - value) > 0.5 else { return }
        readingBottom = value; publishFollowChange()
    }
    func observeEndMarker(y: CGFloat) {
        guard abs(endMarkerY - y) > 0.5 else { return }
        endMarkerY = y; publishFollowChange()
    }
    func observeEndMarker(visible: Bool) {
        guard endMarkerVisible != visible else { return }
        endMarkerVisible = visible; publishFollowChange()
    }

    func observe(distanceFromBottom: Double) {
        lastDistanceFromBottom = distanceFromBottom.isFinite ? distanceFromBottom : 0
        policy.observe(distanceFromBottom: distanceFromBottom)
        publishFollowChange()
    }
    func setUserScrolling(_ scrolling: Bool) {
        policy.setUserScrolling(scrolling)
        publishFollowChange()
    }
    func requestLatest() {
        policy.requestLatest()
        publishFollowChange()
    }
    private func publishFollowChange() {
        if followsLatest != policy.followsLatest {
            followsLatest = policy.followsLatest
        }
        if isUserScrolling != policy.userIsScrolling { isUserScrolling = policy.userIsScrolling }
        let jump = policy.showsJumpButton && !endIsInView
        if showsJumpButton != jump { showsJumpButton = jump }
    }
}

// The system accessibility value is read-only. Only the separate preview
// target supplies this override; the installed app follows the system value.
private struct ChatPreviewReduceMotionKey: EnvironmentKey {
    static let defaultValue = false
}
extension EnvironmentValues {
    var chatPreviewReduceMotion: Bool {
        get { self[ChatPreviewReduceMotionKey.self] }
        set { self[ChatPreviewReduceMotionKey.self] = newValue }
    }
}

enum ChatMotion {
    // Public SwiftUI springs, not Apple's private Messages curves.
    static let send = Animation.spring(duration: 0.38, bounce: 0.08)
    static let menu = Animation.spring(duration: 0.34, bounce: 0.06)
    // A little bounce lets the glass overshoot as it separates from the plus
    // button; closing settles faster so the panel is absorbed without wobble.
    // Springs retarget from their current state, so repeated taps reverse
    // mid-flight instead of jumping.
    static let menuOpen = Animation.spring(duration: 0.44, bounce: 0.2)
    static let menuClose = Animation.spring(duration: 0.34, bounce: 0.08)
    static let reducedMenu = Animation.easeInOut(duration: 0.15)
    // Rows appear after the glass has begun to grow, and leave before it
    // shrinks, so text never sits outside the moving edge.
    static let menuContentIn = Animation.easeOut(duration: 0.16).delay(0.2)
    static let menuContentOut = Animation.easeIn(duration: 0.08)
    static let resize = Animation.smooth(duration: 0.22)
    static let scroll = Animation.smooth(duration: 0.2)
    static let glassSeparation = Animation.spring(duration: 0.46, bounce: 0.06)
    /// The jump control rises out of the field with a little life and sinks
    /// back without overshoot, so it never bobs above the field as it fuses.
    static let jumpRise = Animation.spring(duration: 0.42, bounce: 0.18)
    static let jumpSink = Animation.spring(duration: 0.38, bounce: 0)
    static let jumpIconIn = Animation.easeOut(duration: 0.16)
    static let jumpIconOut = Animation.easeIn(duration: 0.08)
    static let jumpMaterialize = Animation.easeInOut(duration: 0.26)
    /// Sunk, the circle shrinks to this scale and its center sits this far
    /// inside the field, so it lies wholly within the field's glass.
    static let jumpSunkScale: CGFloat = 0.4
    static let jumpSunkDepth: CGFloat = 11
    /// Close to the system keyboard's own curve, so following the latest
    /// message moves with the keyboard instead of ahead of it.
    static let keyboardFollow = Animation.smooth(duration: 0.3)
    /// One progress drives the composer's whole morph (ComposerMorphPath).
    /// Folding is a spring: the panel contracts briskly, and its slowing
    /// tail lets the drops part and their bridges snap where the eye can
    /// follow; a small bounce carries them a little further apart, like
    /// drops. Unfolding starts slowly, so the buttons are seen flowing
    /// together before the panel swells out and settles, with no bounce:
    /// the reader is about to type.
    static let composerFold = Animation.spring(duration: 0.75 * composerSlowdown, bounce: 0.12)
    static let composerUnfold = Animation.timingCurve(0.45, 0, 0.25, 1, duration: 0.56 * composerSlowdown)
    static let reducedComposer = Animation.easeInOut(duration: 0.2 * composerSlowdown)
    #if POCKET_PREVIEW
    /// `--slow-composer` plays the morph five times slower, so the UI
    /// check's back-to-back screenshots (about 0.2 s apart) sample it well.
    private static let composerSlowdown: Double = PreviewProbe.on("--slow-composer") ? 5 : 1
    #else
    private static let composerSlowdown: Double = 1
    #endif

    /// 0 below `from`, 1 above `to`, eased between.
    static func step(_ from: CGFloat, _ to: CGFloat, _ x: CGFloat) -> CGFloat {
        let t = min(1, max(0, (x - from) / (to - from)))
        return t * t * (3 - 2 * t)
    }
}

/// The fold's one path, shared by the panel and the three buttons
/// (progress 0 = the panel at rest, 1 = the buttons). First the panel
/// contracts, its height ahead of its width, so it is squeezed into a wide
/// pill and then narrows to a capsule exactly as wide as the three buttons
/// overlapping (`gather` apart). Then the capsule draws in to the middle
/// button while the outer two travel out of its ends: three overlapping
/// drops with waists between them, then drops held by thinning bridges
/// that the glass container draws, pulled thin, until they are
/// `ChatMetrics.composerBlend` apart and snap, and coast to their places.
/// Unfolding runs the same path back: the buttons flow together into one
/// capsule that swells into the panel.
enum ComposerMorphPath {
    static let side = ChatMetrics.morphButton
    /// From the middle button's center to an outer one's, at rest.
    static let pitch = ChatMetrics.morphButton + ChatMetrics.morphGap
    /// Where the outer buttons start, inside the capsule.
    static let gather: CGFloat = 30
    static let capsule = 2 * (gather + side / 2)

    /// The panel's contraction: its height, then its width.
    static func flatten(_ p: CGFloat) -> CGFloat { ChatMotion.step(0, 0.36, p) }
    static func narrow(_ p: CGFloat) -> CGFloat { ChatMotion.step(0.04, 0.6, p) }
    /// The split. Linear, so the spring's slow tail lingers on the bridges.
    static func split(_ p: CGFloat) -> CGFloat { min(1, max(0, (p - 0.45) / 0.55)) }
    /// The capsule drawing in to the middle button, early in the split.
    static func gatherIn(_ p: CGFloat) -> CGFloat { ChatMotion.step(0, 0.45, split(p)) }
    /// The outer buttons' distance from the middle. A spring's overshoot
    /// past 1 carries them a little further before they settle.
    static func outer(_ p: CGFloat) -> CGFloat {
        gather + (pitch - gather) * split(p) + max(0, p - 1) * 1.5 * pitch
    }
    /// How far the drops are pulled thin (0 to 1): growing while the
    /// bridges stretch, most just before they snap (the gap reaches the
    /// blend distance at about 0.85 of the split), gone once at rest.
    static func stretch(_ p: CGFloat) -> CGFloat {
        let s = split(p)
        return ChatMotion.step(0.35, 0.82, s) * (1 - ChatMotion.step(0.82, 1, s))
    }
}

private typealias Morph = ComposerMorphPath

/// The composer's glass panel along the fold (ComposerMorphPath), until it
/// is the middle button. The content keeps its full-size layout throughout
/// (no text reflow) and is clipped by the shrinking glass; it leaves first
/// and returns last.
struct ComposerPanelMorph: ViewModifier, Animatable {
    var progress: CGFloat
    /// The panel's width and natural height at rest.
    let width: CGFloat
    let height: CGFloat
    let reduceMotion: Bool
    let onHeight: (CGFloat) -> Void
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        let p = min(1, max(0, progress))
        let morphing = p > 0.0005 && width > 0 && height > 0 && !reduceMotion
        let flatten = Morph.flatten(p), stretch = Morph.stretch(p)
        let narrowed = width + (Morph.capsule - width) * Morph.narrow(p)
        // Pulled sideways by the outer drops, and thinner for it.
        let w = narrowed + (Morph.side - narrowed) * Morph.gatherIn(p) + 10 * stretch
        let h = height + (Morph.side - height) * flatten - 6 * stretch
        // The corners round out with the height, ending as a circle. At
        // rest the panel is well above twice its radius.
        let radius = ChatMetrics.composerRadius + (Morph.side / 2 - ChatMetrics.composerRadius) * flatten
        let shape = RoundedRectangle(cornerRadius: morphing ? min(radius, h / 2) : ChatMetrics.composerRadius,
                                     style: .continuous)
        content
            .frame(width: morphing ? width : nil)
            .fixedSize(horizontal: false, vertical: true)
            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { onHeight($0) }
            // Faded inside the glass, which an outer opacity would not
            // reach, and drawn in a little as the glass takes it.
            .opacity(reduceMotion ? 1 - p : 1 - ChatMotion.step(0, 0.22, p))
            .scaleEffect(reduceMotion ? 1 : 1 - 0.04 * ChatMotion.step(0, 0.22, p), anchor: .bottom)
            .frame(width: morphing ? w : nil, height: morphing ? h : nil, alignment: .bottom)
            .clipShape(shape)
            // Off only once it is the middle button's exact shape and place,
            // where that button's own glass takes over. With Reduce Motion
            // the panel keeps its shape and the glass changes over halfway
            // through the cross-fade.
            .chatGlass(in: shape, visible: reduceMotion ? p < 0.5 : p <= 0.999)
    }
}

/// One of the three buttons of the folded composer, at `slot` -1, 0 or 1
/// (voice, chat, latest), along ComposerMorphPath. The outer two travel
/// out of the panel's capsule, stretched toward the middle while the glass
/// bridges hold them; the middle one's glass shows only once the panel has
/// become it. Each symbol arrives as its drop takes shape.
struct ComposerButtonMorph: ViewModifier, Animatable {
    var progress: CGFloat
    let slot: CGFloat
    let symbol: String
    let symbolSize: CGFloat
    let tint: Color
    let reduceMotion: Bool
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        let side = Morph.side
        let outer = slot != 0
        let stretch = reduceMotion || !outer ? 0 : Morph.stretch(progress)
        let w = side + 8 * stretch, h = side - 4 * stretch
        let shape = RoundedRectangle(cornerRadius: min(w, h) / 2, style: .continuous)
        let reveal = reduceMotion ? min(1, max(0, progress))
            : outer ? ChatMotion.step(0.8, 0.98, progress) : ChatMotion.step(0.62, 0.86, progress)
        let glass = reduceMotion ? progress >= 0.5 : outer ? progress > 0.0005 : progress > 0.999
        // Leaning toward the middle while it holds them.
        let x = reduceMotion ? slot * Morph.pitch : slot * (Morph.outer(progress) - 4 * stretch)
        content
            .frame(width: w, height: h)
            .overlay {
                Image(systemName: symbol)
                    .font(.system(size: symbolSize, weight: .medium))
                    .foregroundStyle(tint)
                    .scaleEffect(reduceMotion ? 1 : 0.6 + 0.4 * reveal)
                    .opacity(reveal)
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
            .chatGlass(in: shape, interactive: true, visible: glass)
            .offset(x: x)
    }
}

/// Fades what sits above the panel (draft attachments, import status) with
/// the fold: gone before the panel narrows, back once it has unfolded.
struct ComposerFade: ViewModifier, Animatable {
    var progress: CGFloat
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        content.opacity(1 - ChatMotion.step(0, 0.2, progress))
    }
}

/// Notices a reader moving into older messages: a finger-driven scroll, or
/// its coast, that has travelled `ChatMetrics.collapseTravel` toward the
/// top with the end well below the screen. Keyboard, inset and follow
/// scrolls have no finger and never count. The composer then stays folded
/// until its chat button is tapped, so small offset changes cannot replay
/// the morph. Only a scroll whose finger came down while the panel showed
/// can fold it: one the chat button opened in the middle of, coast and
/// all, never folds it again (device report on 1.0.111, where a tap while
/// scrolling seemed not to open it). `onLeaning` reports a drag heading
/// that way, so the jump control does not rise just before the fold.
struct ComposerFoldObserver: ViewModifier {
    let enabled: Bool
    let onLeaning: (Bool) -> Void
    let onFold: () -> Void
    @State private var travel = ComposerScrollTravel()

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ComposerScrollSample.self) { geometry in
                    ComposerScrollSample(offset: geometry.contentOffset.y,
                                         distance: max(0, geometry.contentSize.height - geometry.readingBottom),
                                         scrollable: geometry.contentSize.height > geometry.containerSize.height + 1)
                } action: { _, sample in
                    guard enabled, travel.armed, sample.scrollable else { return }
                    // Measured from the first position the finger moved.
                    guard let start = travel.start else { travel.start = sample.offset; return }
                    let moved = start - sample.offset
                    lean(moved > 6 && sample.distance > 32)
                    guard moved >= ChatMetrics.collapseTravel, sample.distance >= ChatMetrics.collapseDistance else { return }
                    // Once per gesture.
                    travel.armed = false
                    lean(false)
                    onFold()
                }
                .onScrollPhaseChange { old, phase in
                    switch phase {
                    case .tracking, .interacting:
                        // A finger comes down, or catches a coasting scroll.
                        if old != .tracking && old != .interacting { travel.begin(armed: enabled) }
                    case .decelerating:
                        break
                    default:
                        travel.begin(armed: false)
                        lean(false)
                    }
                }
                .onChange(of: enabled) { _, allowed in
                    if allowed { travel.begin(armed: false) }
                }
        } else { content }
    }

    private func lean(_ leaning: Bool) {
        guard travel.leaning != leaning else { return }
        travel.leaning = leaning
        onLeaning(leaning)
    }
}

/// Changes on every scrolled frame, so it is not view state.
@MainActor private final class ComposerScrollTravel {
    /// This scroll (a finger on the conversation, or its coast) may still
    /// fold the composer, measured from `start`.
    var armed = false
    var start: CGFloat?
    var leaning = false
    func begin(armed: Bool) { self.armed = armed; start = nil }
}

private struct ComposerScrollSample: Equatable {
    let offset: CGFloat
    let distance: CGFloat
    let scrollable: Bool
}

struct ChatTimestampReveal: ViewModifier {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content.gesture(TimestampPan(onChanged: onChanged, onEnded: onEnded))
        } else {
            content
        }
    }
}

/// Reject rightward pans before recognition, so the system back gesture can
/// complete. Ignoring their translation after a SwiftUI DragGesture has begun
/// still leaves an active recognizer competing with the navigation controller.
@available(iOS 18.0, *)
private struct TimestampPan: UIGestureRecognizerRepresentable {
    let onChanged: (CGFloat) -> Void
    let onEnded: () -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.cancelsTouchesInView = false
        pan.delegate = context.coordinator
        return pan
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        switch pan.state {
        case .began, .changed:
            onChanged(min(1, max(0, -pan.translation(in: pan.view).x / 90)))
        case .ended, .cancelled, .failed:
            if !Self.probeHold { onEnded() }
        default: break
        }
    }
    #if POCKET_PREVIEW
    private static let probeAnywhere = PreviewProbe.on("--probe-timestamp-anywhere")
    /// Leaves the rows where the swipe left them, for a screenshot after it.
    private static let probeHold = PreviewProbe.on("--probe-timestamp-hold")
    #else
    private static let probeAnywhere = false
    private static let probeHold = false
    #endif
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            return velocity.x < -abs(velocity.y)
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
        /// A swipe on a block that scrolls sideways (a wide table, code or
        /// formula) scrolls that block alone; the rows stay where they are.
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            if TimestampPan.probeAnywhere { return true }
            var view = touch.view
            while let current = view {
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

struct ChatScrollObserver: ViewModifier {
    let onDistance: (Double) -> Void
    let onUserScrolling: (Bool) -> Void
    var onLayout: () -> Void = {}
    /// Bottom of the reading area (above the composer) in the scroll view's
    /// own coordinate space.
    var onReadingBottom: (CGFloat) -> Void = { _ in }
    /// Preview builds only: raw geometry for UI tests to report.
    var onDebug: (String) -> Void = { _ in }
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: ScrollMeasurement.self) { geometry in
                    ScrollMeasurement(distance: ChatScrollGeometry.distanceFromBottom(
                        contentHeight: Double(geometry.contentSize.height),
                        visibleBottom: Double(geometry.readingBottom)),
                        contentHeight: geometry.contentSize.height, viewportHeight: geometry.containerSize.height,
                        bottomInset: geometry.contentInsets.bottom, offsetY: geometry.contentOffset.y,
                        topInset: geometry.contentInsets.top)
                } action: { old, new in
                    onReadingBottom(new.viewportHeight - new.bottomInset)
                    onDistance(new.distance)
                    #if POCKET_PREVIEW
                    onDebug(String(format: "d=%.1f content=%.1f offset=%.1f container=%.1f insetTop=%.1f insetBottom=%.1f",
                                   new.distance, new.contentHeight, new.offsetY, new.viewportHeight, new.topInset, new.bottomInset))
                    #endif
                    // Lazy rows revise estimated content height while they
                    // scroll into view. That is not a request to scroll again.
                    // ChatView follows actual message updates separately.
                    if abs(old.viewportHeight - new.viewportHeight) > 0.5
                        || abs(old.bottomInset - new.bottomInset) > 0.5 { onLayout() }
                }
                .onScrollPhaseChange { _, phase in
                    onUserScrolling(phase == .tracking || phase == .interacting || phase == .decelerating)
                }
        } else {
            content.simultaneousGesture(DragGesture().onChanged { _ in
                onUserScrolling(true)
            }.onEnded { _ in onUserScrolling(false) })
        }
    }
}

struct ChatScrollAnchoring: ViewModifier {
    let followsLatest: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            // Only initial placement belongs to the system anchor. Changing
            // the size-change anchor while a lazy stack is estimating rows
            // competes with scrollTo and can keep layout/AX from settling.
            // ChatView owns subsequent, coalesced following explicitly.
            content.defaultScrollAnchor(.bottom, for: .initialOffset)
                .defaultScrollAnchor(.top, for: .alignment)
        } else { content }
    }
}

/// Small, row-local lag during a finger-driven scroll. It changes rendering
/// only, so the spring cannot change measured content height or scroll offset.
struct BubbleScrollSpring: ViewModifier {
    let active: Bool
    let reducedMotion: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *), !reducedMotion {
            content.visualEffect { view, geometry in
                let y = geometry.frame(in: .scrollView(axis: .vertical)).midY
                let height = max(1, geometry.bounds(of: .scrollView(axis: .vertical))?.height ?? 800)
                // Neighbouring rows can differ by at most 3pt, below the
                // stack's 8pt gap. Rendering must never overlap layout.
                return view.offset(y: active ? max(-1.5, min(1.5, (y / height - 0.5) * 3)) : 0)
            }.animation(.spring(duration: 0.42, bounce: 0.22), value: active)
        } else { content }
    }
}

private struct ScrollMeasurement: Equatable {
    let distance: Double
    let contentHeight: CGFloat
    let viewportHeight: CGFloat
    let bottomInset: CGFloat
    var offsetY: CGFloat = 0
    var topInset: CGFloat = 0
}

/// Animate only the newly sent row. No overlay geometry is fed back into the
/// scroll layout, and revisiting an older row does not replay its arrival.
struct OutgoingArrival: ViewModifier {
    let animate: Bool
    @State private var progress: CGFloat
    init(animate: Bool) { self.animate = animate; _progress = State(initialValue: animate ? 0 : 1) }
    func body(content: Content) -> some View {
        // Grow inside the row's final bounds. Translating the entire row
        // 22pt down used to cross into the following assistant bubble.
        content.scaleEffect(0.94 + 0.06 * progress, anchor: .bottomTrailing)
            .opacity(Double(progress))
            .onAppear {
                guard progress < 1 else { return }
                withAnimation(ChatMotion.send) { progress = 1 }
            }
            .onChange(of: animate) { _, enabled in
                if !enabled {
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { progress = 1 }
                }
            }
    }
}

struct ComposerHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = ChatMetrics.control
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ComposerBoundsKey: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        value = nextValue() ?? value
    }
}
struct ChatViewportHeightKey: PreferenceKey {
    static let defaultValue: CGFloat = 800
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ComposerTopKey: PreferenceKey {
    static let defaultValue: CGFloat = .nan
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}
struct ConversationBottomKey: PreferenceKey {
    static var defaultValue: CGFloat { 0 }
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

/// Moves the jump control into (and out of) the composer field. Applied as
/// a transition so the glass shapes animate inside their shared container.
struct JumpSink: ViewModifier {
    let offset: CGFloat
    var x: CGFloat = 0
    let scale: CGFloat
    let opacity: Double
    func body(content: Content) -> some View {
        content.scaleEffect(scale).offset(x: x, y: offset).opacity(opacity)
    }
}

@available(iOS 18.0, *)
extension ScrollGeometry {
    /// The content-space y of the bottom of the readable area (above the
    /// composer or other bottom bars). `contentOffset` is the raw offset (it
    /// starts at -contentInsets.top) and `containerSize` already excludes the
    /// insets, as measured in UI tests: subtracting the bottom inset again
    /// left a constant error of top + bottom inset (272pt in a chat), so the
    /// end of a conversation never counted as reached.
    var readingBottom: CGFloat { contentOffset.y + contentInsets.top + containerSize.height }
}
