import SwiftUI
import UIKit
import AVFoundation
import os

/// 送信直後の画面の記録 (1.1.0 (184)). With another app's Picture in Picture
/// on screen, a send turned the lower half of the screen black and left it
/// unanswering, and a screenshot did not show it (the person, 2026-10-25).
/// For ten seconds after each send this notes what tells the causes apart:
/// - the app's own stall: how late the main thread answered (asked every
///   50 ms from another queue, so a stall that never ends is noted too) and
///   the longest wait between the frames iOS offered the app;
/// - a window of iOS's left over the screen: the shown windows of the app's
///   scene (the keyboard's are among them) and which one a tap in the lower
///   half reaches;
/// - what iOS said: the keyboard's frames, the scene losing focus, memory
///   warnings, heat, and whether another app plays sound (a video in Picture
///   in Picture does);
/// - the reply's stage as the model loads and starts.
/// Only times, figures and the kinds of windows; no chat text.
final class SendScreenLog: @unchecked Sendable {
    static let shared = SendScreenLog()
    /// How long after a send it watches.
    static let span: TimeInterval = 10

    // The queue's.
    private let queue = DispatchQueue(label: "app.pocketgemma.send-screen-log")
    private var stored: [String]
    private var pings: DispatchSourceTimer?
    private var start: CFTimeInterval = 0
    private var sends = 0
    private var lastAnswer: CFTimeInterval = 0
    private var worstDelay: CFTimeInterval = 0
    private var worstDelayAt: CFTimeInterval = 0
    private var lateAnswers = 0
    private var silentSince: CFTimeInterval?

    // The main thread's.
    private var running = false
    private var trace = 0
    private var observers: [NSObjectProtocol] = []
    private var frames: CADisplayLink?
    private var frameStart: CFTimeInterval = 0
    private var lastFrame: CFTimeInterval = 0
    private var worstGap: CFTimeInterval = 0
    private var worstGapAt: CFTimeInterval = 0
    private var longGaps = 0
    private var lastStage = ""
    private weak var window: UIWindow?

    static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("send-screen-log.txt")
    }

    private init() {
        stored = (try? String(contentsOf: Self.fileURL, encoding: .utf8))?
            .split(separator: "\n").map(String.init) ?? []
    }

    var lines: [String] { queue.sync { stored } }

    func clear() {
        queue.sync {
            stored = []
            try? FileManager.default.removeItem(at: Self.fileURL)
        }
    }

    /// As a send leaves the field, before the keyboard is put away.
    /// `keyboard`: the language of the keyboard in use.
    @MainActor
    func begin(in window: UIWindow?, keyboard: String?) {
        finish()
        running = true
        trace += 1
        self.window = window
        watchNotifications()
        let now = CACurrentMediaTime()
        let header = conditions(keyboard: keyboard)
        let clock = Date().formatted(.dateTime.month(.defaultDigits).day().hour(.twoDigits(amPM: .omitted)).minute().second())
        queue.async { [self] in
            start = now
            sends += 1
            lastAnswer = now
            worstDelay = 0
            worstDelayAt = 0
            lateAnswers = 0
            silentSince = nil
            stored.append("―― 送信 \(sends) · \(clock) ――")
            note(header, at: now)
            startPings()
        }
        frameStart = now
        lastFrame = now
        worstGap = 0
        worstGapAt = now
        longGaps = 0
        lastStage = ""
        let link = CADisplayLink(target: FrameTarget(self), selector: #selector(FrameTarget.tick(_:)))
        link.add(to: .main, forMode: .common)
        frames = link
        let id = trace
        for delay in [0.5, 1.5, 4, Self.span - 0.5] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                MainActor.assumeIsolated {
                    guard let self, self.running, self.trace == id else { return }
                    self.noteWindows()
                }
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + Self.span) { [weak self] in
            MainActor.assumeIsolated {
                guard let self, self.trace == id else { return }
                self.finish()
            }
        }
    }

    /// The reply's stage while the record runs (ChatStore.status).
    @MainActor
    func stage(_ text: String) {
        guard running, text != lastStage else { return }
        lastStage = text
        let now = CACurrentMediaTime()
        let line = "段階: " + (text.isEmpty ? "終わり" : text)
        queue.async { [self] in note(line, at: now) }
    }

    /// The figures since the send, once its ten seconds are over or the
    /// next send begins.
    @MainActor
    func finish() {
        guard running else { return }
        running = false
        frames?.invalidate()
        frames = nil
        let frameLine = String(format: "フレームの最長の間隔 %.0f ms（%.2f秒の時点）· 100 ms超 %d回",
                               worstGap * 1000, worstGapAt - frameStart, longGaps)
        let memory = Self.memory
        queue.async { [self] in
            pings?.cancel()
            pings = nil
            note(String(format: "まとめ: メインスレッドの最長の遅れ %.0f ms（%.2f秒の時点）· 100 ms超の待ち %d回（50 msごとに確認）· ",
                        worstDelay * 1000, worstDelayAt - start, lateAnswers) + frameLine + " · " + memory)
        }
    }

    // MARK: The main thread's answers

    /// From the queue every 50 ms: the main thread is asked to answer, and
    /// a second without any answer is noted at once, from here.
    private func startPings() {
        pings?.cancel()
        let source = DispatchSource.makeTimerSource(queue: queue)
        source.schedule(deadline: .now(), repeating: .milliseconds(50))
        source.setEventHandler { [weak self] in self?.ping() }
        source.resume()
        pings = source
    }

    private func ping() {
        let sent = CACurrentMediaTime()
        if silentSince == nil, sent - lastAnswer > 1 {
            silentSince = lastAnswer
            note("メインスレッドが1秒以上応答していません", at: sent)
        }
        DispatchQueue.main.async { [weak self] in
            let answered = CACurrentMediaTime()
            self?.queue.async { self?.answered(sent: sent, at: answered) }
        }
    }

    private func answered(sent: CFTimeInterval, at time: CFTimeInterval) {
        guard pings != nil, sent >= start else { return }
        lastAnswer = max(lastAnswer, time)
        let delay = time - sent
        if delay > worstDelay {
            worstDelay = delay
            worstDelayAt = sent
        }
        if delay > 0.1 { lateAnswers += 1 }
        if let since = silentSince {
            silentSince = nil
            note(String(format: "メインスレッドが再び応答（約%.1f秒止まっていた）", time - since), at: time)
        }
    }

    // MARK: The frames

    @MainActor
    fileprivate func frame(at time: CFTimeInterval) {
        let gap = time - lastFrame
        if gap > worstGap {
            worstGap = gap
            worstGapAt = lastFrame
        }
        if gap > 0.1 { longGaps += 1 }
        lastFrame = time
    }

    // MARK: What iOS says

    @MainActor
    private func watchNotifications() {
        guard observers.isEmpty else { return }
        let keyboard: [(Notification.Name, String)] = [
            (UIResponder.keyboardWillShowNotification, "キーボード: 出始め"),
            (UIResponder.keyboardDidShowNotification, "キーボード: 出た"),
            (UIResponder.keyboardWillHideNotification, "キーボード: 下がり始め"),
            (UIResponder.keyboardDidHideNotification, "キーボード: 下がった"),
        ]
        let others: [(Notification.Name, String)] = [
            (UIScene.willDeactivateNotification, "画面が操作を受けなくなる（iOSが手前に何かを出した）"),
            (UIScene.didActivateNotification, "画面がまた操作を受ける"),
            (UIScene.didEnterBackgroundNotification, "画面から離れた"),
            (UIScene.willEnterForegroundNotification, "画面に戻る"),
            (UIApplication.didReceiveMemoryWarningNotification, "メモリ不足の警告"),
            (ProcessInfo.thermalStateDidChangeNotification, "端末の温度が変わった"),
            (AVAudioSession.interruptionNotification, "音の中断"),
        ]
        observers = keyboard.map { name, text in
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] note in
                let end = (note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
                let duration = note.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double
                var line = text
                if let end { line += " · 行き先 " + Self.rect(end) }
                if let duration { line += String(format: " · %.2f秒", duration) }
                MainActor.assumeIsolated { self?.event(line) }
            }
        } + others.map { name, text in
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated {
                    let detail = name == ProcessInfo.thermalStateDidChangeNotification ? "（\(Self.thermal)）" : ""
                    self?.event(text + detail)
                }
            }
        }
    }

    @MainActor
    private func event(_ text: String) {
        guard running else { return }
        let now = CACurrentMediaTime()
        queue.async { [self] in note(text, at: now) }
    }

    /// As the send begins: the app's and the phone's state.
    @MainActor
    private func conditions(keyboard: String?) -> String {
        let traits = window?.traitCollection ?? UITraitCollection.current
        let otherSound = AVAudioSession.sharedInstance().isOtherAudioPlaying
        var parts: [String] = []
        parts.append("画面 \(DownloadLog.appState)・\(Self.scene(window?.windowScene?.activationState))")
        parts.append("他のアプリの音 " + (otherSound ? "あり" : "なし"))
        parts.append("外観 " + (traits.userInterfaceStyle == .dark ? "ダーク" : "ライト"))
        parts.append("透明度を下げる " + (UIAccessibility.isReduceTransparencyEnabled ? "オン" : "オフ"))
        parts.append("画面収録 " + (traits.sceneCaptureState == .active ? "中" : "なし"))
        parts.append("キーボード " + (keyboard ?? "不明"))
        parts.append(Self.memory)
        parts.append("温度 " + Self.thermal)
        if ProcessInfo.processInfo.isLowPowerModeEnabled { parts.append("低電力モード") }
        return parts.joined(separator: " · ")
    }

    private static func scene(_ state: UIScene.ActivationState?) -> String {
        guard let state else { return "なし" }
        switch state {
        case .foregroundActive: return "操作中"
        case .foregroundInactive: return "表示のみ"
        case .background: return "裏"
        case .unattached: return "なし"
        @unknown default: return "不明"
        }
    }

    /// The shown windows of the app's scene, back to front, and which of
    /// them a tap at three quarters down the screen reaches: the highest
    /// one that takes it, as UIKit asks them.
    @MainActor
    private func noteWindows() {
        guard let scene = window?.windowScene else { return event("ウィンドウ: 見つかりません") }
        let bounds = scene.coordinateSpace.bounds
        let point = CGPoint(x: bounds.midX, y: (bounds.height * 0.75).rounded())
        let shown = scene.windows.filter { !$0.isHidden }
        let list = shown.map { (window: UIWindow) -> String in
            var line = "\(Self.kind(window)) \(Self.rect(window.frame)) 段\(Int(window.windowLevel.rawValue))"
            if window.alpha < 1 { line += String(format: " 透明度%.2f", window.alpha) }
            if window.isKeyWindow { line += " 入力先" }
            return line
        }
        // Highest first; of two at one level, the later one in the list.
        var ordered: [UIWindow] = []
        for window in shown {
            let index = ordered.firstIndex { $0.windowLevel.rawValue <= window.windowLevel.rawValue } ?? ordered.endIndex
            ordered.insert(window, at: index)
        }
        var reached = "どれにも届かない"
        for window in ordered where window.isUserInteractionEnabled && window.alpha > 0.01 {
            if let hit = window.hitTest(window.convert(point, from: scene.coordinateSpace), with: nil) {
                reached = Self.kind(window) + " の " + Self.kind(hit)
                break
            }
        }
        event("ウィンドウ: " + list.joined(separator: " / ") + " · 下の方（y \(Int(point.y))）を押すと → " + reached)
    }

    // MARK: Lines

    /// The queue's: a line with its time since the send, kept at once (a
    /// stall that ends in a forced quit still leaves the lines before it).
    private func note(_ text: String, at time: CFTimeInterval) {
        stored.append(String(format: "%5.2f秒 ", time - start) + text)
        if stored.count > 400 { stored.removeFirst(stored.count - 400) }
        try? FileManager.default.createDirectory(at: Self.fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try? Data(stored.joined(separator: "\n").utf8)
            .write(to: Self.fileURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    private static var memory: String {
        String(format: "使えるメモリ %.2f GB", Double(os_proc_available_memory()) / 1_000_000_000)
    }

    private static var thermal: String {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: "平常"
        case .fair: "やや高い"
        case .serious: "高い"
        case .critical: "非常に高い"
        @unknown default: "不明"
        }
    }

    private static func rect(_ rect: CGRect) -> String {
        "(\(Int(rect.minX)),\(Int(rect.minY)) \(Int(rect.width))×\(Int(rect.height)))"
    }

    /// A view's class, without SwiftUI's long generic parameters.
    private static func kind(_ view: UIView) -> String {
        let name = String(describing: type(of: view))
        return name.split(separator: "<").first.map(String.init) ?? name
    }
}

/// The display link holds its target; this one holds the record weakly.
private final class FrameTarget: NSObject {
    weak var log: SendScreenLog?
    init(_ log: SendScreenLog) { self.log = log }
    @objc func tick(_ link: CADisplayLink) {
        MainActor.assumeIsolated { log?.frame(at: link.timestamp) }
    }
}

/// In the developer settings: the record above, to copy and send.
struct SendScreenLogCard: View {
    /// Raised by the settings' 診断をまとめて実行; the record is shown only
    /// once asked for, as the download record is.
    let loadRequest: Int
    @State private var lines: [String]?
    @State private var copied = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("送信直後の画面の記録", systemImage: "rectangle.bottomhalf.filled").font(.headline)
            Text("送ってから10秒のあいだ、アプリが止まっていないか、キーボードやiOSのウィンドウが画面に残っていないか、他のアプリの音（ピクチャ・イン・ピクチャの動画）やメモリ・温度を時刻つきで残します。会話の内容は含みません。")
                .font(.caption).foregroundStyle(.secondary)
            if let lines, lines.isEmpty {
                Text("まだ記録がありません。").font(.caption).foregroundStyle(.secondary)
            } else if let lines {
                Text(lines.suffix(60).joined(separator: "\n"))
                    .font(.system(.caption2, design: .monospaced)).textSelection(.enabled)
                    .accessibilityIdentifier("send-screen-log")
            } else {
                Text("「診断をまとめて実行」で読み込みます。").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 16) {
                Button(copied ? "コピーしました" : "記録をコピー") {
                    UIPasteboard.general.string = SendScreenLog.shared.lines.joined(separator: "\n")
                    copied = true
                }
                Button("再読み込み") { lines = SendScreenLog.shared.lines; copied = false }
                Button("消去", role: .destructive) { SendScreenLog.shared.clear(); lines = [] }
            }.font(.subheadline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
        .onChange(of: loadRequest) { lines = SendScreenLog.shared.lines; copied = false }
    }
}
