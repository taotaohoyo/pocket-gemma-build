import SwiftUI
import UIKit
import os

/// A short record of what happens while a model downloads: when the app
/// leaves the screen and the phone locks, whether iOS keeps it running for
/// the download (the continued-processing task) or wakes it, how often
/// progress arrives, how fast the bytes come and how often the island is
/// updated. It tells a figure that stops on a locked phone apart from the app
/// being stopped by iOS (a gap in the record, then a new launch), and a
/// slower transfer from a figure that only stopped moving. Only times and
/// figures.
@MainActor
final class DownloadLog {
    static let shared = DownloadLog()
    private(set) var lines: [String] = []
    private var observers: [NSObjectProtocol] = []
    private let clock: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ja_JP")
        formatter.dateFormat = "M/d HH:mm:ss"
        return formatter
    }()

    static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("download-log.txt")
    }

    private init() {
        lines = (try? String(contentsOf: Self.fileURL, encoding: .utf8))?
            .split(separator: "\n").map(String.init) ?? []
    }

    func note(_ text: String) {
        lines.append("\(clock.string(from: Date())) \(text)")
        if lines.count > 500 { lines.removeFirst(lines.count - 500) }
        try? FileManager.default.createDirectory(at: Self.fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        // Written while the phone is locked too.
        try? Data(lines.joined(separator: "\n").utf8)
            .write(to: Self.fileURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    func clear() {
        lines = []
        try? FileManager.default.removeItem(at: Self.fileURL)
    }

    /// The app's launch, leaving and returning to the screen, and locking.
    func watchApp() {
        guard observers.isEmpty else { return }
        note("起動" + (UIApplication.shared.applicationState == .background ? "（iOSがバックグラウンドで起動）" : ""))
        let events: [(Notification.Name, String)] = [
            (UIApplication.didEnterBackgroundNotification, "画面から離れた"),
            (UIApplication.willEnterForegroundNotification, "画面に戻った"),
            (UIApplication.protectedDataWillBecomeUnavailableNotification, "ロックした"),
            (UIApplication.protectedDataDidBecomeAvailableNotification, "ロックを解除した"),
            (UIApplication.didReceiveMemoryWarningNotification, "メモリ不足の警告"),
            (UIApplication.willTerminateNotification, "アプリが終了する"),
        ]
        observers = events.map { name, text in
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.note(text) }
            }
        }
        // What iOS weighs when it ends background work early (1.1.0 (295)).
        let device: [(Notification.Name, () -> String)] = [
            (ProcessInfo.thermalStateDidChangeNotification, { "本体の温度: " + Self.thermalText }),
            (Notification.Name.NSProcessInfoPowerStateDidChange, { "低電力モード: " + Self.lowPowerText }),
        ]
        observers += device.map { name, text in
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.note(text()) }
            }
        }
    }

    /// The phone's state as iOS weighs it for background work: heat, Low
    /// Power Mode and the app's memory (1.1.0 (295)).
    nonisolated static var deviceText: String {
        "温度 \(thermalText)・低電力モード \(lowPowerText)・アプリのメモリ \(footprintMB) MB・残り \(os_proc_available_memory() / 1_000_000) MB"
    }

    nonisolated static var thermalText: String {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: "平常"
        case .fair: "やや高い"
        case .serious: "高い"
        case .critical: "非常に高い"
        @unknown default: "不明"
        }
    }

    nonisolated static var lowPowerText: String { ProcessInfo.processInfo.isLowPowerModeEnabled ? "オン" : "オフ" }

    private nonisolated static var footprintMB: UInt64 {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return result == KERN_SUCCESS ? info.phys_footprint / 1_000_000 : 0
    }

    static var appState: String {
        let screen = switch UIApplication.shared.applicationState {
        case .active: "表示中"
        case .inactive: "切替中"
        case .background: "裏"
        @unknown default: "不明"
        }
        return screen + (UIApplication.shared.isProtectedDataAvailable ? "" : "・ロック中")
    }
}

/// In the developer settings: the record above, to copy or share.
struct DownloadLogCard: View {
    /// Raised by the settings' 診断をまとめて実行; the record is shown only
    /// once asked for, so opening the settings never lays out its lines.
    let loadRequest: Int
    @State private var lines: [String]?
    @State private var copied = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("ダウンロードの記録", systemImage: "arrow.down.circle").font(.headline)
            Text("ダウンロード中のアプリの状態、iOSの「作業を続ける」機能、進みの報告、速さとダイナミックアイランドの更新を時刻つきで残します。会話の内容は含みません。")
                .font(.caption).foregroundStyle(.secondary)
            if let lines, lines.isEmpty {
                Text("まだ記録がありません。").font(.caption).foregroundStyle(.secondary)
            } else if let lines {
                Text(lines.suffix(80).joined(separator: "\n"))
                    .font(.system(.caption2, design: .monospaced)).textSelection(.enabled)
                    .accessibilityIdentifier("download-log")
            } else {
                Text("「診断をまとめて実行」で読み込みます。").font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 16) {
                Button(copied ? "コピーしました" : "記録をコピー") {
                    UIPasteboard.general.string = DownloadLog.shared.lines.joined(separator: "\n")
                    copied = true
                }
                Button("再読み込み") { lines = DownloadLog.shared.lines; copied = false }
                Button("消去", role: .destructive) { DownloadLog.shared.clear(); lines = [] }
            }.font(.subheadline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .onChange(of: loadRequest) { lines = DownloadLog.shared.lines; copied = false }
    }
}
