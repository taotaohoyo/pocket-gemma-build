import SwiftUI
import UIKit

/// A short record of what happens while a model downloads: when the app
/// leaves the screen and the phone locks, whether iOS keeps it running for
/// the download (the continued-processing task) or wakes it, how often
/// progress arrives, how fast the bytes come and how often the island is
/// updated. It tells a figure that stops on a locked phone apart from the app
/// being stopped by iOS (a gap in the record, then a new launch), and a
/// slower transfer from a figure that only stopped moving. Only times and
/// figures.
@MainActor
final class DownloadLog {
    static let shared = DownloadLog()
    private(set) var lines: [String] = []
    private var observers: [NSObjectProtocol] = []
    private let clock: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ja_JP")
        formatter.dateFormat = "M/d HH:mm:ss"
        return formatter
    }()

    static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("download-log.txt")
    }

    private init() {
        lines = (try? String(contentsOf: Self.fileURL, encoding: .utf8))?
            .split(separator: "\n").map(String.init) ?? []
    }

    func note(_ text: String) {
        lines.append("\(clock.string(from: Date())) \(text)")
        if lines.count > 500 { lines.removeFirst(lines.count - 500) }
        try? FileManager.default.createDirectory(at: Self.fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        // Written while the phone is locked too.
        try? Data(lines.joined(separator: "\n").utf8)
            .write(to: Self.fileURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    func clear() {
        lines = []
        try? FileManager.default.removeItem(at: Self.fileURL)
    }

    /// The app's launch, leaving and returning to the screen, and locking.
    func watchApp() {
        guard observers.isEmpty else { return }
        note("起動" + (UIApplication.shared.applicationState == .background ? "（iOSがバックグラウンドで起動）" : ""))
        let events: [(Notification.Name, String)] = [
            (UIApplication.didEnterBackgroundNotification, "画面から離れた"),
            (UIApplication.willEnterForegroundNotification, "画面に戻った"),
            (UIApplication.protectedDataWillBecomeUnavailableNotification, "ロックした"),
            (UIApplication.protectedDataDidBecomeAvailableNotification, "ロックを解除した"),
            (UIApplication.didReceiveMemoryWarningNotification, "メモリ不足の警告"),
            (UIApplication.willTerminateNotification, "アプリが終了する"),
        ]
        observers = events.map { name, text in
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.note(text) }
            }
        }
    }

    static var appState: String {
        let screen = switch UIApplication.shared.applicationState {
        case .active: "表示中"
        case .inactive: "切替中"
        case .background: "裏"
        @unknown default: "不明"
        }
        return screen + (UIApplication.shared.isProtectedDataAvailable ? "" : "・ロック中")
    }
}

/// In the developer settings: the record above, to copy or share.
struct DownloadLogCard: View {
    @State private var lines = DownloadLog.shared.lines
    @State private var copied = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("ダウンロードの記録", systemImage: "arrow.down.circle").font(.headline)
            Text("ダウンロード中のアプリの状態、iOSの「作業を続ける」機能、進みの報告、速さとダイナミックアイランドの更新を時刻つきで残します。会話の内容は含みません。")
                .font(.caption).foregroundStyle(.secondary)
            if lines.isEmpty {
                Text("まだ記録がありません。").font(.caption).foregroundStyle(.secondary)
            } else {
                Text(lines.suffix(80).joined(separator: "\n"))
                    .font(.system(.caption2, design: .monospaced)).textSelection(.enabled)
                    .accessibilityIdentifier("download-log")
            }
            HStack(spacing: 16) {
                Button(copied ? "コピーしました" : "記録をコピー") {
                    UIPasteboard.general.string = DownloadLog.shared.lines.joined(separator: "\n")
                    copied = true
                }
                Button("再読み込み") { lines = DownloadLog.shared.lines; copied = false }
                Button("消去", role: .destructive) { DownloadLog.shared.clear(); lines = [] }
            }.font(.subheadline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}
