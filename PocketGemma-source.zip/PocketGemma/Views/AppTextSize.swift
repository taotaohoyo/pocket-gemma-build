import SwiftUI
import UIKit

/// The app keeps its own text size whatever iOS's 文字サイズ says (user
/// 2026-10-23): an iPhone 15 Pro Max set smaller showed replies at 14pt
/// beside 44pt buttons. Every view takes the default size (.large, body
/// 17pt), as approved on the phone.
enum AppTextSize {
    static let size: DynamicTypeSize = .large

    /// UIKit's name for a size, for the composer's text view.
    static func category(_ size: DynamicTypeSize) -> UIContentSizeCategory {
        switch size {
        case .xSmall: .extraSmall
        case .small: .small
        case .medium: .medium
        case .large: .large
        case .xLarge: .extraLarge
        case .xxLarge: .extraExtraLarge
        case .xxxLarge: .extraExtraExtraLarge
        case .accessibility1: .accessibilityMedium
        case .accessibility2: .accessibilityLarge
        case .accessibility3: .accessibilityExtraLarge
        case .accessibility4: .accessibilityExtraExtraLarge
        case .accessibility5: .accessibilityExtraExtraExtraLarge
        @unknown default: .large
        }
    }

    /// The window scenes' trait, so what UIKit draws in them (system menus,
    /// alerts and confirmation dialogs) takes the same size as SwiftUI.
    @MainActor static func applyToScenes() {
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes
        where !scene.traitOverrides.contains(UITraitPreferredContentSizeCategory.self) {
            scene.traitOverrides.preferredContentSizeCategory = category(size)
        }
    }
}

/// On the app's root view: SwiftUI's text and scaled metrics at
/// `AppTextSize.size`, and the window scene's trait for UIKit.
struct FixedTextSize: ViewModifier {
    func body(content: Content) -> some View {
        content
            .dynamicTypeSize(AppTextSize.size)
            .onAppear { AppTextSize.applyToScenes() }
    }
}
