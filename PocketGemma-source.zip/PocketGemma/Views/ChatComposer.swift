import SwiftUI
import UIKit

/// The composer's type, chosen in 設定's キーボード (2026-10-23). 縮小型 is the
/// two-row panel that folds into three buttons while older messages are
/// read (1.0.111 on). 従来型 is the field of 1.0.110 and before: the plus
/// circle beside a one-line field that holds send, as in Messages; while
/// it is typed in, the 高速 and model pills rise above it.
enum ComposerStyle: String, CaseIterable, Identifiable {
    case folding, classic
    static let storageKey = "composer-style-v1"
    var id: String { rawValue }
    var title: String {
        switch self {
        case .folding: "縮小型"
        case .classic: "従来型"
        }
    }
}

/// Own the marked-text commit and reset in one place. Clearing a SwiftUI
/// TextField binding while a Japanese IME is active can commit its old text
/// back into the binding as the keyboard resigns.
@MainActor final class ComposerInput: ObservableObject {
    weak var textView: UITextView?
    var onClear: (() -> Void)?
    func committedText(fallback: String) -> String {
        textView?.unmarkText()
        return textView?.text ?? fallback
    }
    func clearAndDismiss() {
        let active = textView
        onClear?()
        active?.resignFirstResponder()
        active?.window?.endEditing(true)
    }
}

struct ChatComposerText: UIViewRepresentable {
    @Binding var text: String
    @Binding var focused: Bool
    let enabled: Bool
    let input: ComposerInput
    /// False while the composer is folded into its buttons: the text view
    /// stays (with its draft) but leaves VoiceOver and UI queries.
    var accessible = true
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> ComposerTextView {
        let view = ComposerTextView()
        view.backgroundColor = .clear
        view.font = Self.font(context.environment)
        view.textColor = .label
        view.tintColor = .systemBlue
        view.textContainerInset = UIEdgeInsets(top: 11, left: 0, bottom: 11, right: 0)
        view.textContainer.lineFragmentPadding = 0
        view.isScrollEnabled = false
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.accessibilityIdentifier = "chat-input"
        view.accessibilityLabel = "メッセージ"
        view.delegate = context.coordinator
        input.textView = view
        input.onClear = { [weak view, weak coordinator = context.coordinator] in
            guard let view, let coordinator else { return }
            coordinator.applying = true
            // Clear the binding before UIKit commits/dismisses the IME so a
            // pending SwiftUI update cannot ask for first responder again.
            coordinator.parent.focused = false
            view.unmarkText()
            view.text = ""
            view.refreshPlaceholder()
            coordinator.parent.text = ""
            coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        return view
    }
    func updateUIView(_ view: ComposerTextView, context: Context) {
        context.coordinator.parent = self
        // The IME owns marked text until it commits. Do not replace it during
        // unrelated reply updates or attachment imports.
        if view.markedTextRange == nil && view.text != text {
            context.coordinator.applying = true
            view.text = text
            context.coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        let font = Self.font(context.environment)
        if view.font != font {
            view.font = font
            view.invalidateIntrinsicContentSize()
        }
        if view.isEditable != enabled { view.isEditable = enabled }
        if view.isAccessibilityElement != accessible {
            view.isAccessibilityElement = accessible
            view.accessibilityElementsHidden = !accessible
        }
        view.refreshPlaceholder()
        if focused && enabled && !view.isFirstResponder { view.becomeFirstResponder() }
        if !focused && view.isFirstResponder { view.resignFirstResponder() }
    }
    /// Callout at the app's text size (FixedTextSize), not at iOS's, and
    /// bold with iOS's 文字を太くする as before.
    static func font(_ environment: EnvironmentValues) -> UIFont {
        let traits = UITraitCollection { traits in
            traits.preferredContentSizeCategory = AppTextSize.category(environment.dynamicTypeSize)
            traits.legibilityWeight = environment.legibilityWeight == .bold ? .bold : .regular
        }
        return .preferredFont(forTextStyle: .callout, compatibleWith: traits)
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: ComposerTextView, context: Context) -> CGSize? {
        let width = proposal.width ?? 200
        let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
        let limit = (uiView.font?.lineHeight ?? 20) * 6 + 22
        if uiView.isScrollEnabled != (height > limit) { uiView.isScrollEnabled = height > limit }
        return CGSize(width: width, height: min(limit, max(44, height)))
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: ChatComposerText
        var applying = false
        init(_ parent: ChatComposerText) { self.parent = parent }
        func textViewDidChange(_ textView: UITextView) {
            guard !applying else { return }
            parent.text = textView.text
            (textView as? ComposerTextView)?.refreshPlaceholder()
            textView.invalidateIntrinsicContentSize()
        }
        func textViewDidBeginEditing(_ textView: UITextView) {
            guard !applying, textView.isFirstResponder else { return }
            if !parent.focused { parent.focused = true }
        }
        func textViewDidEndEditing(_ textView: UITextView) {
            guard !textView.isFirstResponder else { return }
            if parent.focused { parent.focused = false }
        }
    }
}

final class ComposerTextView: UITextView {
    private let placeholder = UILabel()
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        placeholder.text = "質問してみよう"
        placeholder.textColor = .placeholderText
        placeholder.isUserInteractionEnabled = false
        placeholder.isAccessibilityElement = false
        addSubview(placeholder)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    /// Below its six-line cap the view shows all its text and never
    /// scrolls: while the panel grows a line, UIKit would otherwise scroll
    /// the caret's new line into the frame that is still on its way.
    override var contentOffset: CGPoint {
        get { super.contentOffset }
        set { super.contentOffset = isScrollEnabled ? newValue : .zero }
    }
    override var isScrollEnabled: Bool {
        didSet { if !isScrollEnabled && super.contentOffset != .zero { super.contentOffset = .zero } }
    }
    func refreshPlaceholder() {
        placeholder.isHidden = !text.isEmpty
        placeholder.font = font
        setNeedsLayout()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        placeholder.frame = CGRect(x: 0, y: textContainerInset.top, width: bounds.width, height: font?.lineHeight ?? 20)
    }
}
