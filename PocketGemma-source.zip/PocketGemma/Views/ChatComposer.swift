import SwiftUI
import UIKit
import PocketCore

/// The composer's type, chosen in 設定's キーボードと入力 (2026-10-23). スマート
/// (縮小型 until 1.1.0 (164)) is the two-row panel that folds into three
/// buttons while older messages are read (1.0.111 on). スタンダード (従来型)
/// is the field of 1.0.110 and before: the plus circle beside a one-line
/// field that holds send, as in Messages; while it is typed in, the 高速 and
/// model pills rise above it. Only the names shown changed; the cases and
/// the saved value stay.
/// 設定 › キーボードと入力 「起動時のチャット」 (user, 2026-10-25, LaunchChatMode):
/// 前回の会話 or 新しいチャット, in place of 「起動時にキーボードを開いておく」
/// (2026-10-24), whose on is 新しいチャット's keyboard now.
enum LaunchChat {
    /// Once per launch: the first time Fielua comes to the screen, not on
    /// each return from the background.
    @MainActor static var handled = false
    /// The drafts kept when Fielua last left the screen (LaunchDrafts),
    /// read once a launch, each until its chat is shown again.
    @MainActor static var kept: [UUID: String] = LaunchDrafts.load()
    @MainActor static func takeDraft(for chat: UUID) -> String? {
        guard let text = kept.removeValue(forKey: chat) else { return nil }
        LaunchDrafts.remove(chat)
        return text
    }
}

extension LaunchChatMode {
    var title: String {
        switch self {
        case .resume: "前回の会話"
        case .newChat: "新しいチャット"
        }
    }

    /// What the phones show, under them in キーボードと入力 and in the setup.
    var previewCaption: String {
        switch self {
        case .resume: "最後に開いていた会話を、入力途中の文章ごと表示します。"
        case .newChat: "新しいチャットとキーボードを表示します。前の会話にもすぐ戻れます。"
        }
    }

    /// What the phone shows, for VoiceOver.
    var previewHint: String {
        switch self {
        case .resume:
            "Fieluaを開くと、最後に開いていた会話が、入力途中の文章とともに表示されます。"
        case .newChat:
            "Fieluaを開くと、新しいチャットが開いてキーボードが表示されます。入力欄の上の「前回の会話に戻る」で、前の会話に戻れます。"
        }
    }
}

enum ComposerStyle: String, CaseIterable, Identifiable {
    case folding, classic
    static let storageKey = "composer-style-v1"
    var id: String { rawValue }
    var title: String {
        switch self {
        case .folding: "スマート"
        case .classic: "スタンダード"
        }
    }
}

/// Own the marked-text commit and reset in one place. Clearing a SwiftUI
/// TextField binding while a Japanese IME is active can commit its old text
/// back into the binding as the keyboard resigns.
@MainActor final class ComposerInput: ObservableObject {
    weak var textView: UITextView?
    var onClear: (() -> Void)?
    func committedText(fallback: String) -> String {
        textView?.unmarkText()
        return textView?.text ?? fallback
    }
    func clearAndDismiss() {
        let active = textView
        onClear?()
        active?.resignFirstResponder()
        active?.window?.endEditing(true)
    }
}

struct ChatComposerText: UIViewRepresentable {
    @Binding var text: String
    @Binding var focused: Bool
    let enabled: Bool
    let input: ComposerInput
    /// False while the composer is folded into its buttons: the text view
    /// stays (with its draft) but leaves VoiceOver and UI queries.
    var accessible = true
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> ComposerTextView {
        let view = ComposerTextView()
        view.backgroundColor = .clear
        view.font = Self.font(context.environment)
        view.textColor = .label
        view.tintColor = .systemBlue
        view.textContainerInset = UIEdgeInsets(top: 11, left: 0, bottom: 11, right: 0)
        view.textContainer.lineFragmentPadding = 0
        view.isScrollEnabled = false
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.accessibilityIdentifier = "chat-input"
        view.accessibilityLabel = "メッセージ"
        view.delegate = context.coordinator
        input.textView = view
        input.onClear = { [weak view, weak coordinator = context.coordinator] in
            guard let view, let coordinator else { return }
            coordinator.applying = true
            // Clear the binding before UIKit commits/dismisses the IME so a
            // pending SwiftUI update cannot ask for first responder again.
            coordinator.parent.focused = false
            view.unmarkText()
            view.text = ""
            view.refreshPlaceholder()
            coordinator.parent.text = ""
            coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        return view
    }
    func updateUIView(_ view: ComposerTextView, context: Context) {
        context.coordinator.parent = self
        // The IME owns marked text until it commits. Do not replace it during
        // unrelated reply updates or attachment imports.
        if view.markedTextRange == nil && view.text != text {
            context.coordinator.applying = true
            view.text = text
            context.coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        let font = Self.font(context.environment)
        if view.font != font {
            view.font = font
            view.invalidateIntrinsicContentSize()
        }
        if view.isEditable != enabled { view.isEditable = enabled }
        if view.isAccessibilityElement != accessible {
            view.isAccessibilityElement = accessible
            view.accessibilityElementsHidden = !accessible
        }
        view.refreshPlaceholder()
        if focused && enabled && !view.isFirstResponder { view.becomeFirstResponder() }
        if !focused && view.isFirstResponder { view.resignFirstResponder() }
    }
    /// Callout at the app's text size (FixedTextSize), not at iOS's, and
    /// bold with iOS's 文字を太くする as before.
    static func font(_ environment: EnvironmentValues) -> UIFont {
        let traits = UITraitCollection { traits in
            traits.preferredContentSizeCategory = AppTextSize.category(environment.dynamicTypeSize)
            traits.legibilityWeight = environment.legibilityWeight == .bold ? .bold : .regular
        }
        return .preferredFont(forTextStyle: .callout, compatibleWith: traits)
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: ComposerTextView, context: Context) -> CGSize? {
        let width = proposal.width ?? 200
        let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
        let limit = (uiView.font?.lineHeight ?? 20) * 6 + 22
        if uiView.isScrollEnabled != (height > limit) { uiView.isScrollEnabled = height > limit }
        return CGSize(width: width, height: min(limit, max(44, height)))
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: ChatComposerText
        var applying = false
        init(_ parent: ChatComposerText) { self.parent = parent }
        func textViewDidChange(_ textView: UITextView) {
            guard !applying else { return }
            parent.text = textView.text
            (textView as? ComposerTextView)?.refreshPlaceholder()
            textView.invalidateIntrinsicContentSize()
        }
        func textViewDidBeginEditing(_ textView: UITextView) {
            guard !applying, textView.isFirstResponder else { return }
            if !parent.focused { parent.focused = true }
        }
        func textViewDidEndEditing(_ textView: UITextView) {
            guard !textView.isFirstResponder else { return }
            if parent.focused { parent.focused = false }
        }
    }
}

final class ComposerTextView: UITextView {
    private let placeholder = UILabel()
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        placeholder.text = "メッセージ"
        placeholder.textColor = .placeholderText
        placeholder.isUserInteractionEnabled = false
        placeholder.isAccessibilityElement = false
        addSubview(placeholder)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    /// Below its six-line cap the view shows all its text and never
    /// scrolls: while the panel grows a line, UIKit would otherwise scroll
    /// the caret's new line into the frame that is still on its way.
    override var contentOffset: CGPoint {
        get { super.contentOffset }
        set { super.contentOffset = isScrollEnabled ? newValue : .zero }
    }
    override var isScrollEnabled: Bool {
        didSet { if !isScrollEnabled && super.contentOffset != .zero { super.contentOffset = .zero } }
    }
    func refreshPlaceholder() {
        placeholder.isHidden = !text.isEmpty
        placeholder.font = font
        setNeedsLayout()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        placeholder.frame = CGRect(x: 0, y: textContainerInset.top, width: bounds.width, height: font?.lineHeight ?? 20)
    }
}
