import SwiftUI
import UIKit
import PocketCore
import GameController
import Combine

/// The composer's type, chosen in 設定's キーボードと入力 (2026-10-23). スマート
/// (縮小型 until 1.1.0 (164)) is the two-row panel that folds into three
/// buttons while older messages are read (1.0.111 on). スタンダード (従来型)
/// is the field of 1.0.110 and before: the plus circle beside a one-line
/// field that holds send, as in Messages; while it is typed in, the 高速 and
/// model pills rise above it. Only the names shown changed; the cases and
/// the saved value stay.
/// 設定 › キーボードと入力 「起動時のチャット」 (user, 2026-10-25, LaunchChatMode):
/// 前回の会話 or 新しいチャット, in place of 「起動時にキーボードを開いておく」
/// (2026-10-24), whose on is 新しいチャット's keyboard now.
enum LaunchChat {
    /// Once per launch: the first time Fielua comes to the screen, not on
    /// each return from the background.
    @MainActor static var handled = false
    /// The drafts kept when Fielua last left the screen (LaunchDrafts),
    /// read once a launch, each until its chat is shown again.
    @MainActor static var kept: [UUID: String] = LaunchDrafts.load()
    @MainActor static func takeDraft(for chat: UUID) -> String? {
        guard let text = kept.removeValue(forKey: chat) else { return nil }
        LaunchDrafts.remove(chat)
        return text
    }

    /// 新しいチャット's chat, opened as the chats are loaded, before the first
    /// frame, and the chat open before it. Switched to under the first
    /// frames instead, the conversation's scroll view, built for the chat
    /// of before, could go on settling without end and Fielua stopped
    /// answering (UI check 40205866579). Not under the setup.
    @MainActor private(set) static var opened: UUID?
    @MainActor private(set) static var before: UUID?
    @MainActor static func choose(in chats: ChatStore) {
        guard LaunchChatMode.current() == .newChat, !StartupPresenter.coversLaunch else { return }
        before = chats.selectedID
        chats.newChat()
        opened = chats.selectedID
    }
}

extension LaunchChatMode {
    var title: String {
        switch self {
        case .resume: String(localized: "前回の会話")
        case .newChat: String(localized: "新しいチャット")
        }
    }

    /// What the phones show, under them in キーボードと入力 and in the setup.
    var previewCaption: String {
        switch self {
        case .resume: String(localized: "最後に開いていた会話を、入力途中の文章ごと表示します。")
        case .newChat: String(localized: "新しいチャットとキーボードを表示します。")
        }
    }

    /// What the phone shows, for VoiceOver.
    var previewHint: String {
        switch self {
        case .resume:
            String(localized: "Fieluaを開くと、最後に開いていた会話が、入力途中の文章とともに表示されます。")
        case .newChat:
            String(localized: "Fieluaを開くと、新しいチャットが開いてキーボードが表示されます。入力欄の上の「前回の会話に戻る」で、前の会話に戻れます。")
        }
    }
}

enum ComposerStyle: String, CaseIterable, Identifiable {
    case folding, classic
    static let storageKey = "composer-style-v1"
    var id: String { rawValue }
    var title: String {
        switch self {
        case .folding: String(localized: "スマート")
        case .classic: String(localized: "スタンダード")
        }
    }
}

/// Own the marked-text commit and reset in one place. Clearing a SwiftUI
/// TextField binding while a Japanese IME is active can commit its old text
/// back into the binding as the keyboard resigns.
@MainActor final class ComposerInput: ObservableObject {
    weak var textView: UITextView?
    var onClear: (() -> Void)?
    func committedText(fallback: String) -> String {
        textView?.unmarkText()
        return textView?.text ?? fallback
    }
    func clearAndDismiss() {
        let active = textView
        onClear?()
        active?.resignFirstResponder()
        active?.window?.endEditing(true)
    }
}

/// A hardware keyboard on the device (Magic Keyboard on iPad,
/// fielua-reports #3), as the GameController framework sees one.
enum HardwareKeyboard {
    static var attached: Bool {
        #if POCKET_PREVIEW
        // The UI checks' simulators may have the Mac's keyboard joined to
        // them; only the hardware keyboard's checks count it.
        guard PreviewProbe.on("--hardware-keyboard"), !PreviewProbe.on("--keyboard-as-221") else { return false }
        #endif
        return GCKeyboard.coalesced != nil
    }

    /// As one connects or goes: a keyboard that goes may still be the
    /// coalesced one while its notice is posted.
    static func attached(after note: Notification) -> Bool {
        note.name == .GCKeyboardDidDisconnect ? false : attached
    }

    static let changes = NotificationCenter.default.publisher(for: .GCKeyboardDidConnect)
        .merge(with: NotificationCenter.default.publisher(for: .GCKeyboardDidDisconnect))
}

struct ChatComposerText: UIViewRepresentable {
    @Binding var text: String
    @Binding var focused: Bool
    let enabled: Bool
    let input: ComposerInput
    /// False while the composer is folded into its buttons: the text view
    /// stays (with its draft) but leaves VoiceOver and UI queries.
    var accessible = true
    /// A hardware keyboard's Return (ComposerReturnKey): sends, as the send
    /// button does. Nil leaves Return to the text view, a new line.
    var onReturnKey: (() -> Void)? = nil
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> ComposerTextView {
        let view = ComposerTextView()
        view.backgroundColor = .clear
        view.font = Self.font(context.environment)
        view.textColor = .label
        // The caret and selection in the app's tint: the warm umber (honey
        // until 1.1.0 (214)), as in every other text field.
        view.tintColor = UIColor(Theme.tint)
        view.textContainerInset = UIEdgeInsets(top: 11, left: 0, bottom: 11, right: 0)
        view.textContainer.lineFragmentPadding = 0
        view.isScrollEnabled = false
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.accessibilityIdentifier = "chat-input"
        view.accessibilityLabel = String(localized: "メッセージ")
        view.delegate = context.coordinator
        input.textView = view
        input.onClear = { [weak view, weak coordinator = context.coordinator] in
            guard let view, let coordinator else { return }
            coordinator.applying = true
            // Clear the binding before UIKit commits/dismisses the IME so a
            // pending SwiftUI update cannot ask for first responder again.
            coordinator.parent.focused = false
            view.unmarkText()
            view.text = ""
            view.refreshPlaceholder()
            coordinator.parent.text = ""
            coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        return view
    }
    func updateUIView(_ view: ComposerTextView, context: Context) {
        context.coordinator.parent = self
        // The IME owns marked text until it commits. Do not replace it during
        // unrelated reply updates or attachment imports.
        if view.markedTextRange == nil && view.text != text {
            context.coordinator.applying = true
            view.text = text
            context.coordinator.applying = false
            view.invalidateIntrinsicContentSize()
        }
        let font = Self.font(context.environment)
        if view.font != font {
            view.font = font
            view.invalidateIntrinsicContentSize()
        }
        if view.isEditable != enabled { view.isEditable = enabled }
        view.returnKey = onReturnKey
        if view.isAccessibilityElement != accessible {
            view.isAccessibilityElement = accessible
            view.accessibilityElementsHidden = !accessible
        }
        view.refreshPlaceholder()
        if focused && enabled && !view.isFirstResponder { view.becomeFirstResponder() }
        if !focused && view.isFirstResponder { view.resignFirstResponder() }
    }
    /// Callout at the app's text size (FixedTextSize), not at iOS's, and
    /// bold with iOS's 文字を太くする as before.
    static func font(_ environment: EnvironmentValues) -> UIFont {
        let traits = UITraitCollection { traits in
            traits.preferredContentSizeCategory = AppTextSize.category(environment.dynamicTypeSize)
            traits.legibilityWeight = environment.legibilityWeight == .bold ? .bold : .regular
        }
        return .preferredFont(forTextStyle: .callout, compatibleWith: traits)
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: ComposerTextView, context: Context) -> CGSize? {
        let width = proposal.width ?? 200
        let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
        let limit = (uiView.font?.lineHeight ?? 20) * 6 + 22
        if uiView.isScrollEnabled != (height > limit) { uiView.isScrollEnabled = height > limit }
        return CGSize(width: width, height: min(limit, max(44, height)))
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: ChatComposerText
        var applying = false
        init(_ parent: ChatComposerText) { self.parent = parent }
        func textViewDidChange(_ textView: UITextView) {
            guard !applying else { return }
            parent.text = textView.text
            (textView as? ComposerTextView)?.refreshPlaceholder()
            textView.invalidateIntrinsicContentSize()
        }
        func textViewDidBeginEditing(_ textView: UITextView) {
            #if POCKET_PREVIEW
            KeyboardProbe.note("did-begin focused=\(parent.focused)")
            KeyboardProbe.postHardwareNotices(in: textView)
            #endif
            SendScreenLog.shared.focus(true)
            guard !applying, textView.isFirstResponder else { return }
            if !parent.focused { parent.focused = true }
        }
        func textViewDidEndEditing(_ textView: UITextView) {
            #if POCKET_PREVIEW
            KeyboardProbe.note("did-end focused=\(parent.focused) first=\(textView.isFirstResponder)")
            #endif
            SendScreenLog.shared.focus(false)
            guard !textView.isFirstResponder else { return }
            if parent.focused { parent.focused = false }
        }
    }
}

final class ComposerTextView: UITextView {
    private let placeholder = UILabel()
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        placeholder.text = String(localized: "メッセージ")
        // A warm grey that reads on the paper and the glass (iOS's own
        // placeholder grey was faint there).
        placeholder.textColor = UIColor(Theme.placeholder)
        placeholder.isUserInteractionEnabled = false
        placeholder.isAccessibilityElement = false
        addSubview(placeholder)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    #if POCKET_PREVIEW
    override func becomeFirstResponder() -> Bool {
        let became = super.becomeFirstResponder()
        KeyboardProbe.note("become=\(became) by \(KeyboardProbe.caller())")
        return became
    }
    override func resignFirstResponder() -> Bool {
        let resigned = super.resignFirstResponder()
        KeyboardProbe.note("resign=\(resigned) by \(KeyboardProbe.caller())")
        return resigned
    }
    #endif
    /// Below its six-line cap the view shows all its text and never
    /// scrolls: while the panel grows a line, UIKit would otherwise scroll
    /// the caret's new line into the frame that is still on its way.
    override var contentOffset: CGPoint {
        get { super.contentOffset }
        set { super.contentOffset = isScrollEnabled ? newValue : .zero }
    }
    override var isScrollEnabled: Bool {
        didSet { if !isScrollEnabled && super.contentOffset != .zero { super.contentOffset = .zero } }
    }
    /// A hardware keyboard's Return (Magic Keyboard on iPad, fielua-reports
    /// #3): until 1.1.0 (222) it only ever began a new line, and only the
    /// send button sent. Now Return alone sends, through `returnKey`, while
    /// a word the IME still holds is confirmed by it as before, and Shift
    /// or Option Return begin a line (ComposerReturnKey). The on-screen
    /// keyboard's return key is no press here and still begins a line.
    var returnKey: (() -> Void)?
    /// Returns taken for sending: their ends stay away from the text view
    /// too, which never saw them begin.
    private var takenPresses: Set<UIPress> = []
    override func pressesBegan(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        let taken = presses.filter(sends)
        #if POCKET_PREVIEW
        for press in presses where press.key != nil {
            KeyboardProbe.note("press \(press.key!.keyCode.rawValue) mods=\(press.key!.modifierFlags.rawValue) marked=\(markedTextRange != nil) taken=\(taken.contains(press))")
        }
        #endif
        // 送信直後の画面の記録, with a hardware keyboard: Return only, never
        // the other keys (they are the message).
        for press in presses where Self.isReturn(press) {
            let flags = press.key?.modifierFlags ?? []
            var line = "キー: Return"
            if flags.contains(.shift) { line += " + Shift" }
            if flags.contains(.alternate) { line += " + Option" }
            if flags.contains(.control) { line += " + Control" }
            if flags.contains(.command) { line += " + Command" }
            if markedTextRange != nil { line += "（変換中）" }
            SendScreenLog.shared.mark(line + (taken.contains(press) ? " → 送信" : " → 入力欄（改行・確定）"))
        }
        takenPresses.formUnion(taken)
        let others = presses.subtracting(taken)
        if !others.isEmpty { super.pressesBegan(others, with: event) }
        // After this press has been dealt with: the send puts the
        // keyboard away, which is no work for the middle of a key event.
        if !taken.isEmpty, let returnKey { DispatchQueue.main.async { MainActor.assumeIsolated { returnKey() } } }
    }
    override func pressesChanged(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        let others = presses.subtracting(takenPresses)
        if !others.isEmpty { super.pressesChanged(others, with: event) }
    }
    override func pressesEnded(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        let others = presses.subtracting(takenPresses)
        takenPresses.subtract(presses)
        if !others.isEmpty { super.pressesEnded(others, with: event) }
    }
    override func pressesCancelled(_ presses: Set<UIPress>, with event: UIPressesEvent?) {
        let others = presses.subtracting(takenPresses)
        takenPresses.subtract(presses)
        if !others.isEmpty { super.pressesCancelled(others, with: event) }
    }
    private static func isReturn(_ press: UIPress) -> Bool {
        guard let key = press.key else { return false }
        return key.keyCode == .keyboardReturnOrEnter || key.keyCode == .keypadEnter
    }
    private func sends(_ press: UIPress) -> Bool {
        guard returnKey != nil, Self.isReturn(press), let key = press.key else { return false }
        let flags = key.modifierFlags
        return ComposerReturnKey.action(composing: markedTextRange != nil, shift: flags.contains(.shift),
                                        option: flags.contains(.alternate), control: flags.contains(.control)) == .send
    }
    func refreshPlaceholder() {
        placeholder.isHidden = !text.isEmpty
        placeholder.font = font
        setNeedsLayout()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        placeholder.frame = CGRect(x: 0, y: textContainerInset.top, width: bounds.width, height: font?.lineHeight ?? 20)
    }
}

#if POCKET_PREVIEW
/// `--keyboard-probe` (UI check only, fielua-reports #3): what the field,
/// the keyboard and its keys did, newest last, who holds the keys now and
/// whether a hardware keyboard is there, as one line the UI check reads
/// (HWKB lines).
@MainActor enum KeyboardProbe {
    private static var events: [String] = []
    private static var started = false
    fileprivate static var found: UIResponder?
    static var on: Bool { PreviewProbe.on("--keyboard-probe") }

    static func note(_ event: String) {
        guard on else { return }
        // The simulator's keyboard repeats its notices; one of each in a row.
        if let last = events.last, last.hasSuffix(event) {
            let count = (Int(last.split(separator: "×").first ?? "") ?? 1) + 1
            events[events.count - 1] = "\(count)×" + event
            return
        }
        events.append(event)
        if events.count > 24 { events.removeFirst(events.count - 24) }
    }

    /// `--probe-hardware-notices`: as the field takes the keys, the
    /// keyboard notices the tester's iPad posted with a Magic Keyboard
    /// (send record, 2026-10-28): frames below the window, no keyboard
    /// going anywhere. Under a name of their own, which only the chat's
    /// keyboard-will-hide handling hears: SwiftUI's own keyboard room
    /// follows the simulator's real keyboard.
    static let hardwareNotice = Notification.Name("PocketGemmaProbeHardwareKeyboardNotice")
    static func postHardwareNotices(in textView: UITextView) {
        guard PreviewProbe.on("--probe-hardware-notices") else { return }
        for (delay, full) in [(0.5, true), (0.8, false)] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak textView] in
                MainActor.assumeIsolated {
                    guard let window = textView?.window else { return }
                    let bottom = window.bounds.height, width = window.bounds.width
                    let keyboard = CGRect(x: 0, y: bottom, width: width, height: 470)
                    let none = CGRect(x: 0, y: bottom, width: 0, height: 0)
                    NotificationCenter.default.post(name: hardwareNotice, object: nil, userInfo: [
                        UIResponder.keyboardFrameBeginUserInfoKey: NSValue(cgRect: full ? keyboard : none),
                        UIResponder.keyboardFrameEndUserInfoKey: NSValue(cgRect: full ? none : keyboard),
                    ])
                    KeyboardProbe.note("hw-notice \(full ? "470→0" : "0→470")")
                }
            }
        }
    }

    /// Who asked: the first frames of UIKit's and the app's own, short.
    static func caller() -> String {
        guard on else { return "" }
        let app = Bundle.main.executableURL?.lastPathComponent ?? ""
        return Thread.callStackSymbols.dropFirst(2).compactMap { line -> String? in
            let parts = line.split(separator: " ", omittingEmptySubsequences: true)
            guard parts.count >= 4 else { return nil }
            let module = String(parts[1])
            guard module == "UIKitCore" || module == app || module == "SwiftUI" else { return nil }
            let symbol = parts[3...].joined(separator: " ").components(separatedBy: " + ").first ?? ""
            return String(symbol.prefix(64))
        }.prefix(7).joined(separator: " < ")
    }

    static var firstResponder: String {
        found = nil
        UIApplication.shared.sendAction(#selector(UIResponder.keyboardProbeFound(_:)), to: nil, from: nil, for: nil)
        return found.map { String(describing: type(of: $0)) } ?? "none"
    }

    private static func start() {
        guard on, !started else { return }
        started = true
        let center = NotificationCenter.default
        for (name, title) in [(UIResponder.keyboardWillShowNotification, "kb-will-show"),
                              (UIResponder.keyboardWillHideNotification, "kb-will-hide"),
                              (UIResponder.keyboardDidChangeFrameNotification, "kb-frame")] {
            center.addObserver(forName: name, object: nil, queue: .main) { note in
                let end = (note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect) ?? .zero
                MainActor.assumeIsolated { KeyboardProbe.note("\(title) \(Int(end.minX)),\(Int(end.minY)) \(Int(end.width))x\(Int(end.height))") }
            }
        }
        center.addObserver(forName: .GCKeyboardDidConnect, object: nil, queue: .main) { _ in
            MainActor.assumeIsolated { KeyboardProbe.note("hw-connect") }
        }
    }

    struct Readout: View {
        let focused: Bool
        var body: some View {
            TimelineView(.periodic(from: .now, by: 0.25)) { _ in
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityLabel(Text(verbatim: "focused=\(focused) responder=\(KeyboardProbe.firstResponder) "
                        + "hw=\(GCKeyboard.coalesced != nil) || " + KeyboardProbe.events.joined(separator: " | ")))
                    .accessibilityIdentifier("keyboard-probe")
            }
            .allowsHitTesting(false)
            .onAppear { KeyboardProbe.start() }
        }
    }
}

extension UIResponder {
    @objc fileprivate func keyboardProbeFound(_ sender: Any?) { KeyboardProbe.found = self }
}
#endif
