import SwiftUI
import UIKit
import PocketCore

/// A GitHub table: a bold header row, rows divided by hairlines and each
/// column aligned as its delimiter row says. Cells wrap past a set width;
/// a table a little wider than the reply wraps its widest columns more to
/// keep the reply's width, one that cannot scrolls sideways within it, and
/// a long one shows its first rows until the reader expands it. It never
/// takes more width than the reply offers. A long
/// press anywhere on it copies the table alone, as Markdown or tab
/// separated for a spreadsheet; VoiceOver reads each cell with its
/// column's header.
struct MarkdownTableView: View {
    let table: MarkdownTable
    @State private var expanded = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.markdownReplySource) private var reply

    var body: some View {
        let collapsible = table.rows.count > MarkdownMetrics.tableRowsCollapsed
        let rows = collapsible && !expanded ? Array(table.rows.prefix(MarkdownMetrics.tableRowsShown)) : table.rows
        VStack(alignment: .leading, spacing: 4) {
            // The menu belongs to the table inside the sideways scroll view.
            // Outside it, a long press on a wide table reached the reply's
            // own menu, which copies the whole reply.
            probed(rows)
            .accessibilityElement(children: .contain)
            .accessibilityLabel(Text(verbatim: table.spokenSummary))
            .accessibilityIdentifier("markdown-table")
            if collapsible {
                Button {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.3)) { expanded.toggle() }
                } label: {
                    Text(expanded ? "表を折りたたむ" : "残り\(table.rows.count - MarkdownMetrics.tableRowsShown)行を表示")
                        .font(.footnote.weight(.medium))
                        .frame(minHeight: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(Theme.tint)
            }
        }
    }

    #if POCKET_PREVIEW
    private static let probeMenuOutside = PreviewProbe.on("--probe-table-menu-outside")
    private static let probeOldFit = PreviewProbe.on("--probe-table-old-fit")
    #else
    private static let probeMenuOutside = false
    private static let probeOldFit = false
    #endif

    /// Held to the width the reply offers: a table that came out wider
    /// widened the whole reply with it, its prose and the sent bubble
    /// running past the screen's edges (219). As 219 drew it with
    /// `--probe-table-old-fit`.
    @ViewBuilder private func probed(_ rows: [[AttributedString]]) -> some View {
        if Self.probeOldFit {
            copyable(sized(rows), outside: true)
        } else {
            OfferedWidth { copyable(sized(rows), outside: true) }
        }
    }

    /// The table's menu, on the grid itself; on the whole block, as before
    /// 1.0.99, when `--probe-table-menu-outside` asks for that.
    @ViewBuilder private func copyable(_ content: some View, outside: Bool) -> some View {
        if outside != Self.probeMenuOutside {
            content
        } else if outside {
            content.contextMenu { copyMenu }
        } else {
            // The blank around short cells is the table's too, not the reply's.
            content.contentShape(.interaction, RoundedRectangle(cornerRadius: 8, style: .continuous))
                .contextMenu { copyMenu }
        }
    }

    @ViewBuilder private var copyMenu: some View {
        Button("表をコピー", systemImage: "tablecells") { UIPasteboard.general.string = table.markdown }
        Button("タブ区切りでコピー", systemImage: "arrow.right.to.line") { UIPasteboard.general.string = table.tabSeparated }
        if let reply {
            Divider()
            Button("返信全体をコピー", systemImage: "doc.plaintext") { UIPasteboard.general.string = reply.text }
        }
    }

    private func grid(_ rows: [[AttributedString]]) -> some View {
        Grid(alignment: .leading, horizontalSpacing: 0, verticalSpacing: 0) {
            GridRow {
                ForEach(table.header.indices, id: \.self) { column in
                    cell(table.header[column], column: column, row: nil)
                }
            }
            ForEach(rows.indices, id: \.self) { row in
                Rectangle().fill(Theme.markdownLine.opacity(0.7)).frame(height: 0.5)
                    .accessibilityHidden(true)
                GridRow {
                    ForEach(rows[row].indices, id: \.self) { column in
                        cell(rows[row][column], column: column, row: row)
                    }
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(Theme.markdownLine, lineWidth: 0.5)
        }
    }

    /// Fitted to the reply's width (`FittedColumns`): narrow columns share
    /// the room left as the grid shared it, and a table a little too wide,
    /// as a long Japanese column beside a short one often is, wraps its
    /// widest columns more so every word stays in sight. Too wide even so,
    /// the grid scrolls sideways at its columns' own widths, its bar showing
    /// for a moment as it comes so the table reads as one that moves.
    ///
    /// Up to 219 the grid itself took the reply's width whenever its
    /// columns' own widths fitted, and a table a little too wide scrolled.
    /// Offered the reply's width, `Grid` gave its first columns a share of
    /// it before a long column took its own, and came out wider than
    /// offered (a check table, 425pt in 370pt): the reply grew with it, past
    /// the screen's edges. A table a little too wide hid its last 10 to
    /// 30pt behind the edge with nothing to say it moved. Both read as cut
    /// off on the phone; `--probe-table-old-fit` draws them so.
    @ViewBuilder private func sized(_ rows: [[AttributedString]]) -> some View {
        if Self.probeOldFit {
            ViewThatFits(in: .horizontal) {
                copyable(grid(rows), outside: false)
                ScrollView(.horizontal, showsIndicators: false) { copyable(grid(rows), outside: false) }
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            }
        } else {
            ViewThatFits(in: .horizontal) {
                copyable(fitted(rows), outside: false)
                ScrollView(.horizontal) { copyable(grid(rows), outside: false) }
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
                    .scrollIndicatorsFlash(onAppear: true)
            }
        }
    }

    /// The grid's cells in columns fitted to the reply's width
    /// (`FittedColumns`).
    private func fitted(_ rows: [[AttributedString]]) -> some View {
        FittedColumns(columns: table.header.count, floor: MarkdownMetrics.tableColumnFloor) {
            ForEach(table.header.indices, id: \.self) { column in
                cell(table.header[column], column: column, row: nil, yielding: true)
            }
            ForEach(rows.indices, id: \.self) { row in
                ForEach(rows[row].indices, id: \.self) { column in
                    cell(rows[row][column], column: column, row: row, yielding: true)
                        .overlay(alignment: .top) {
                            Rectangle().fill(Theme.markdownLine.opacity(0.7)).frame(height: 0.5)
                                .accessibilityHidden(true)
                        }
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(Theme.markdownLine, lineWidth: 0.5)
        }
    }

    /// A header cell when `row` is nil. A `yielding` cell's text also wraps
    /// to the width its column is given.
    private func cell(_ text: AttributedString, column: Int, row: Int?, yielding: Bool = false) -> some View {
        let header = row == nil
        let alignment = column < table.alignments.count ? table.alignments[column] : .leading
        let capped = CappedWidth(maximum: MarkdownMetrics.tableCellWidth, yielding: yielding)
        // A cell with a link keeps its own elements, so the link can be opened.
        let hasLink = text.runs.contains { $0.link != nil }
        return capped {
            MarkdownText(text: text)
                .font(header ? .subheadline.weight(.semibold) : .subheadline)
                .multilineTextAlignment(alignment.text)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: alignment.frame)
        .background(header ? Theme.tableHeader : Color.clear)
        .accessibilityElement(children: hasLink ? .contain : .ignore)
        .accessibilityLabel(Text(verbatim: row.map { table.spokenCell(row: $0, column: column) }
                                    ?? MarkdownTable.spoken(text)))
        .accessibilityAddTraits(header ? .isHeader : [])
    }
}

private extension MarkdownTable.Alignment {
    var text: SwiftUI.TextAlignment {
        switch self {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }

    var frame: SwiftUI.Alignment {
        switch self {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }
}

/// Lays its content out in the width offered and never reports more, so a
/// block that comes out wider cannot widen the reply around it.
private struct OfferedWidth: Layout {
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let subview = subviews.first else { return .zero }
        let size = subview.sizeThatFits(proposal)
        guard let width = proposal.width, width.isFinite else { return size }
        return CGSize(width: min(size.width, width), height: size.height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: bounds.origin, anchor: .topLeading,
                              proposal: ProposedViewSize(width: bounds.width, height: proposal.height))
    }
}

/// Lays text out at its own width up to `maximum`, wrapping beyond it, even
/// where the parent offers unlimited width (a sideways scroll view). When
/// `yielding`, it also wraps to a narrower width offered (`FittedColumns`).
private struct CappedWidth: Layout {
    let maximum: CGFloat
    var yielding = false

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let subview = subviews.first else { return .zero }
        let ideal = subview.sizeThatFits(.unspecified)
        let room = yielding ? proposal.width ?? .infinity : .infinity
        return subview.sizeThatFits(ProposedViewSize(width: min(ideal.width, maximum, room), height: nil))
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: bounds.origin, anchor: .topLeading,
                              proposal: ProposedViewSize(width: bounds.width, height: nil))
    }
}

/// Table cells, the header's first, `columns` to a row, in columns as wide
/// as their widest cell. Offered less than that, the widest columns give
/// way first, their text wrapping, each down to `floor` at the least (a
/// column narrower than that keeps its width); offered more, the narrowest
/// columns widen first, to an equal width where the room allows, as `Grid`
/// shares the room among its cells when it can. It always takes exactly
/// the width offered, down to its floors. Its ideal width, which
/// `ViewThatFits` holds against the room there is, is the narrowest it can
/// be.
private struct FittedColumns: Layout {
    let columns: Int
    let floor: CGFloat

    struct Cache {
        /// Each column as wide as its widest cell.
        var natural: [CGFloat]
    }

    func makeCache(subviews: Subviews) -> Cache {
        var natural = Array(repeating: CGFloat(0), count: max(columns, 1))
        for index in subviews.indices {
            let column = index % natural.count
            natural[column] = max(natural[column], subviews[index].sizeThatFits(.unspecified).width)
        }
        return Cache(natural: natural)
    }

    func updateCache(_ cache: inout Cache, subviews: Subviews) {
        cache = makeCache(subviews: subviews)
    }

    /// The columns' widths in `room`, or at their ideal with no room given.
    func columnWidths(in room: CGFloat?, natural: [CGFloat]) -> [CGFloat] {
        let floors = natural.map { min($0, self.floor) }
        guard let room, room.isFinite else { return floors }
        let total = natural.reduce(0, +)
        if room >= total {
            // The width the narrower columns come up to for the row to fill
            // the room; the wider keep their own.
            let level = Self.level(fitting: room, high: room) { level in natural.map { max($0, level) } }
            return natural.map { max($0, level) }
        }
        // The width the widest columns come down to for the row to fill
        // the room; below the floors' sum it settles at the floors.
        let level = Self.level(fitting: room, high: natural.max() ?? 0) { level in
            zip(natural, floors).map { max($1, min($0, level)) }
        }
        return zip(natural, floors).map { max($1, min($0, level)) }
    }

    /// The highest level from 0 to `high` whose widths still fit `room`.
    private static func level(fitting room: CGFloat, high: CGFloat, widths: (CGFloat) -> [CGFloat]) -> CGFloat {
        var low: CGFloat = 0, high = high
        for _ in 0..<32 {
            let level = (low + high) / 2
            if widths(level).reduce(0, +) > room { high = level } else { low = level }
        }
        return low
    }

    /// Each row as tall as its tallest cell at its column's width.
    func rowHeights(_ widths: [CGFloat], subviews: Subviews) -> [CGFloat] {
        var heights: [CGFloat] = []
        for index in subviews.indices {
            let row = index / widths.count
            if row == heights.count { heights.append(0) }
            let size = subviews[index].sizeThatFits(ProposedViewSize(width: widths[index % widths.count], height: nil))
            heights[row] = max(heights[row], size.height)
        }
        return heights
    }

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout Cache) -> CGSize {
        let widths = columnWidths(in: proposal.width, natural: cache.natural)
        return CGSize(width: widths.reduce(0, +), height: rowHeights(widths, subviews: subviews).reduce(0, +))
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout Cache) {
        let widths = columnWidths(in: bounds.width, natural: cache.natural)
        let heights = rowHeights(widths, subviews: subviews)
        var origin = bounds.origin
        for index in subviews.indices {
            let row = index / widths.count, column = index % widths.count
            if column == 0 { origin.x = bounds.minX }
            subviews[index].place(at: origin, anchor: .topLeading,
                                  proposal: ProposedViewSize(width: widths[column], height: heights[row]))
            origin.x += widths[column]
            if column == widths.count - 1 { origin.y += heights[row] }
        }
    }
}
