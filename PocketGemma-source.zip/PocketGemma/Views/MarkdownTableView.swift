import SwiftUI
import UIKit
import PocketCore

/// A GitHub table: a bold header row, rows divided by hairlines and each
/// column aligned as its delimiter row says. Cells wrap past a set width,
/// a wide table scrolls sideways, and a long one shows its first rows until
/// the reader expands it. A long press copies it for a spreadsheet or as
/// Markdown; VoiceOver reads each cell with its column's header.
struct MarkdownTableView: View {
    let table: MarkdownTable
    @State private var expanded = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.markdownReplySource) private var reply

    var body: some View {
        let collapsible = table.rows.count > MarkdownMetrics.tableRowsCollapsed
        let rows = collapsible && !expanded ? Array(table.rows.prefix(MarkdownMetrics.tableRowsShown)) : table.rows
        VStack(alignment: .leading, spacing: 4) {
            ViewThatFits(in: .horizontal) {
                grid(rows)
                ScrollView(.horizontal, showsIndicators: false) { grid(rows) }
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            }
            .accessibilityElement(children: .contain)
            .accessibilityLabel(Text(verbatim: table.spokenSummary))
            .accessibilityIdentifier("markdown-table")
            .contextMenu {
                Button("表をコピー", systemImage: "tablecells") { UIPasteboard.general.string = table.tabSeparated }
                Button("Markdownでコピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = table.markdown }
                if let reply {
                    Divider()
                    Button("返信全体をコピー", systemImage: "doc.plaintext") { UIPasteboard.general.string = reply.text }
                }
            }
            if collapsible {
                Button {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.3)) { expanded.toggle() }
                } label: {
                    Text(expanded ? "表を折りたたむ" : "残り\(table.rows.count - MarkdownMetrics.tableRowsShown)行を表示")
                        .font(.footnote.weight(.medium))
                        .frame(minHeight: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(Theme.accent)
            }
        }
    }

    private func grid(_ rows: [[AttributedString]]) -> some View {
        Grid(alignment: .leading, horizontalSpacing: 0, verticalSpacing: 0) {
            GridRow {
                ForEach(table.header.indices, id: \.self) { column in
                    cell(table.header[column], column: column, row: nil)
                }
            }
            ForEach(rows.indices, id: \.self) { row in
                Rectangle().fill(Theme.markdownLine.opacity(0.7)).frame(height: 0.5)
                    .accessibilityHidden(true)
                GridRow {
                    ForEach(rows[row].indices, id: \.self) { column in
                        cell(rows[row][column], column: column, row: row)
                    }
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(Theme.markdownLine, lineWidth: 0.5)
        }
    }

    /// A header cell when `row` is nil.
    private func cell(_ text: AttributedString, column: Int, row: Int?) -> some View {
        let header = row == nil
        let alignment = column < table.alignments.count ? table.alignments[column] : .leading
        let capped = CappedWidth(maximum: MarkdownMetrics.tableCellWidth)
        // A cell with a link keeps its own elements, so the link can be opened.
        let hasLink = text.runs.contains { $0.link != nil }
        return capped {
            MarkdownText(text: text)
                .font(header ? .subheadline.weight(.semibold) : .subheadline)
                .multilineTextAlignment(alignment.text)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: alignment.frame)
        .background(header ? Theme.tableHeader : Color.clear)
        .accessibilityElement(children: hasLink ? .contain : .ignore)
        .accessibilityLabel(Text(verbatim: row.map { table.spokenCell(row: $0, column: column) }
                                    ?? MarkdownTable.spoken(text)))
        .accessibilityAddTraits(header ? .isHeader : [])
    }
}

private extension MarkdownTable.Alignment {
    var text: SwiftUI.TextAlignment {
        switch self {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }

    var frame: SwiftUI.Alignment {
        switch self {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }
}

/// Lays text out at its own width up to `maximum`, wrapping beyond it, even
/// where the parent offers unlimited width (a sideways scroll view).
private struct CappedWidth: Layout {
    let maximum: CGFloat

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let subview = subviews.first else { return .zero }
        let ideal = subview.sizeThatFits(.unspecified)
        return subview.sizeThatFits(ProposedViewSize(width: min(ideal.width, maximum), height: nil))
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: bounds.origin, anchor: .topLeading,
                              proposal: ProposedViewSize(width: bounds.width, height: nil))
    }
}
