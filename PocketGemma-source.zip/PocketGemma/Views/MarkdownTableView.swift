import SwiftUI
import PocketCore

/// A GitHub table: a bold header row, rows divided by hairlines and each
/// column aligned as its delimiter row says. Cells wrap past a set width,
/// a wide table scrolls sideways, and a long one shows its first rows until
/// the reader expands it.
struct MarkdownTableView: View {
    let table: MarkdownTable
    @State private var expanded = false

    var body: some View {
        let collapsible = table.rows.count > MarkdownMetrics.tableRowsCollapsed
        let rows = collapsible && !expanded ? Array(table.rows.prefix(MarkdownMetrics.tableRowsShown)) : table.rows
        VStack(alignment: .leading, spacing: 4) {
            ViewThatFits(in: .horizontal) {
                grid(rows)
                ScrollView(.horizontal, showsIndicators: false) { grid(rows) }
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            }
            if collapsible {
                Button {
                    withAnimation(.snappy(duration: 0.3)) { expanded.toggle() }
                } label: {
                    Text(expanded ? "表を折りたたむ" : "残り\(table.rows.count - MarkdownMetrics.tableRowsShown)行を表示")
                        .font(.footnote.weight(.medium))
                        .frame(minHeight: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(Theme.accent)
            }
        }
        .padding(.vertical, 2)
    }

    private func grid(_ rows: [[AttributedString]]) -> some View {
        Grid(alignment: .leading, horizontalSpacing: 0, verticalSpacing: 0) {
            GridRow {
                ForEach(table.header.indices, id: \.self) { column in
                    cell(table.header[column], column: column, header: true)
                }
            }
            ForEach(rows.indices, id: \.self) { row in
                Rectangle().fill(Theme.markdownLine.opacity(0.7)).frame(height: 0.5)
                GridRow {
                    ForEach(rows[row].indices, id: \.self) { column in
                        cell(rows[row][column], column: column, header: false)
                    }
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .strokeBorder(Theme.markdownLine, lineWidth: 0.5)
        }
    }

    private func cell(_ text: AttributedString, column: Int, header: Bool) -> some View {
        let alignment = column < table.alignments.count ? table.alignments[column] : .leading
        let capped = CappedWidth(maximum: MarkdownMetrics.tableCellWidth)
        return capped {
            MarkdownText(text: text)
                .font(header ? .subheadline.weight(.semibold) : .subheadline)
                .multilineTextAlignment(alignment.text)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: alignment.frame)
        .background(header ? Theme.tableHeader : Color.clear)
    }
}

private extension MarkdownTable.Alignment {
    var text: SwiftUI.TextAlignment {
        switch self {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }

    var frame: SwiftUI.Alignment {
        switch self {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }
}

/// Lays text out at its own width up to `maximum`, wrapping beyond it, even
/// where the parent offers unlimited width (a sideways scroll view).
private struct CappedWidth: Layout {
    let maximum: CGFloat

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let subview = subviews.first else { return .zero }
        let ideal = subview.sizeThatFits(.unspecified)
        return subview.sizeThatFits(ProposedViewSize(width: min(ideal.width, maximum), height: nil))
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: bounds.origin, anchor: .topLeading,
                              proposal: ProposedViewSize(width: bounds.width, height: nil))
    }
}
