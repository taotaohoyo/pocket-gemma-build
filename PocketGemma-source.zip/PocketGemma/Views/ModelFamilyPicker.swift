import SwiftUI
import PocketCore

/// The chat's model menu, its first level (fielua-reports Issue #7, the
/// user's request of 2026-11-12, 1.1.0 (269)): a submenu for each series,
/// Gemma, Qwen, LFM and Phi, as Gemma 4 alone had been one since 1.1.0
/// (204). The series' line says which of its models this chat uses, else
/// how many it has and how many are on the phone. Opening one chooses
/// nothing; its models are the checkable items they were, the current one
/// checked, with their state (未ダウンロード, ダウンロード中, テスト版) under
/// the name. iOS draws each submenu with the series' name at its top, the
/// way back. A struct of its own, so the composer's menu stays one type
/// deep (the launch's stack, 1.1.0 (239)).
struct ModelFamilyMenus: View {
    let groups: [ModelFamilyGroup]
    /// Models listed but not usable, dimmed in their series (none since
    /// 1.1.0 (204); the item stays for a model to come).
    let locked: [ModelSpec]
    /// The phone model this chat uses; nil in a chat with the PC or Claude,
    /// so no phone model is checked or named in use there.
    let currentID: String?
    let line: @MainActor (ModelFamilyGroup) -> String
    let status: @MainActor (ModelSpec) -> String
    let choose: @MainActor (ModelSpec) -> Void

    var body: some View {
        ForEach(groups) { group in
            Menu {
                ForEach(group.models) { spec in item(spec) }
                ForEach(locked.filter { $0.family == group.family }) { spec in lockedItem(spec) }
            } label: {
                Text(verbatim: group.title)
                Text(line(group))
            }
            .menuOrder(.fixed)
            .accessibilityIdentifier("model-menu-\(group.key)")
        }
    }

    /// A checkable item: the system menu draws the check before the title.
    /// A test version (12B, Phi, LFM) says so first in its subtitle.
    private func item(_ spec: ModelSpec) -> some View {
        Toggle(isOn: Binding(get: { currentID == spec.id }, set: { if $0 { choose(spec) } })) {
            Text(spec.name)
            Text(spec.isTestVersion ? String(localized: "テスト版 · \(status(spec))") : status(spec))
        }
        .accessibilityIdentifier("model-menu-\(spec.id)")
    }

    /// A locked model: a disabled item, so the system menu dims it and it
    /// can never be chosen (switchModel and ModelStore refuse it as well).
    private func lockedItem(_ spec: ModelSpec) -> some View {
        Button {} label: {
            Text(spec.name)
            Text("ロック中")
            Image(systemName: "lock")
        }
        .disabled(true)
        .accessibilityValue(String(localized: "ロック中。まだ選択やダウンロードはできません。"))
        .accessibilityIdentifier("model-menu-\(spec.id)")
    }
}

/// A series' mark on the first launch's list: Gemma's own logo, as its
/// models show; for another series its initial on the brand's yellow, the
/// way its models' marks are drawn, so a series never borrows the symbol
/// of one of its models.
struct ModelFamilyMark: View {
    let group: ModelFamilyGroup
    var size: CGFloat = 38

    var body: some View {
        if group.family == "Gemma", let first = group.models.first {
            ModelMark(model: first, size: size)
        } else {
            Text(verbatim: String(group.family.prefix(1)))
                .font(.system(size: size * 0.46, weight: .semibold, design: .rounded))
                .foregroundStyle(Theme.onAccent)
                .frame(width: size, height: size)
                .background(LinearGradient(colors: [Theme.brandLight, Theme.brandYellow],
                                           startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
                .accessibilityHidden(true)
        }
    }
}
