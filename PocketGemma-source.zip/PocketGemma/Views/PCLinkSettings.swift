import AVFoundation
import SwiftUI
import UIKit
import VisionKit
import PocketCore

/// 設定 › PCと接続 (1.1.0 (253)): the PC this iPhone uses, whether it
/// answers, and its models, each of which starts a chat; or, with none
/// registered, the QR code, the connection code and the PCs this network
/// announces. The row stood locked as 「今後のアップデートで対応」 before.
struct PCLinkSettingsView: View {
    @ObservedObject private var link = PCLinkStore.shared
    @StateObject private var browser = PCLinkBrowser()
    @State private var pairing: PCPairingRequest?
    @State private var cameraDenied = false

    var body: some View {
        let _ = SettingsSlideMeter.drew("PCと接続")
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("同じWi-FiのWindows PCで動くFieluaのAIを、このiPhoneから使えます。会話はこのiPhoneに残ります。")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("pc-link-lead")
                if link.isPaired {
                    PCLinkPairedCard()
                    PCLinkModelsCard()
                } else {
                    PCLinkAddCard(browser: browser, cameraDenied: cameraDenied, add: add)
                }
                PCLinkNotes()
            }
            .padding(20)
        }
        .accessibilityIdentifier("pc-link-list")
        .settingsScroll()
        .onAppear {
            link.refresh()
            if !link.isPaired { browser.start() }
        }
        .onDisappear { browser.stop() }
        .onChange(of: link.isPaired) { _, paired in
            if paired { browser.stop() } else { browser.start() }
        }
        .sheet(item: $pairing) { request in
            PCPairingSheet(request: request)
        }
    }

    /// The camera's permission is asked for when the QR code is chosen.
    private func add(_ request: PCPairingRequest) {
        guard request.mode == .scan else { pairing = request; return }
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            pairing = request
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                Task { @MainActor in
                    if granted { pairing = request } else { cameraDenied = true }
                }
            }
        default:
            cameraDenied = true
        }
    }
}

/// What the registration sheet opens on.
struct PCPairingRequest: Identifiable, Equatable {
    enum Mode: Equatable {
        case scan
        /// The connection code; a PC found on the network fills its address.
        case code(PCLinkBrowser.Found?)
    }
    let id = UUID()
    let mode: Mode
}

/// The registered PC: its name, whether it answers, and 接続を解除.
private struct PCLinkPairedCard: View {
    @ObservedObject private var link = PCLinkStore.shared
    @State private var confirmUnpair = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                PCMark(size: 40)
                VStack(alignment: .leading, spacing: 3) {
                    Text(verbatim: link.paired?.pcName ?? "")
                        .font(.headline)
                        .accessibilityIdentifier("pc-link-name")
                    PCLinkStatusLine()
                }
                Spacer(minLength: 4)
            }
            if let date = link.paired?.pairedAt {
                Text("登録した日: \(date.formatted(date: .abbreviated, time: .omitted))")
                    .font(.caption).foregroundStyle(.secondary)
            }
            HStack(spacing: 10) {
                Button {
                    link.refresh()
                } label: {
                    Text("接続を確かめる").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(link.connection == .checking)
                .accessibilityIdentifier("pc-link-check")
                Button(role: .destructive) {
                    confirmUnpair = true
                } label: {
                    Text("接続を解除").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .accessibilityIdentifier("pc-link-unpair")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("pc-link-paired")
        .confirmationDialog("このPCとの接続を解除しますか？", isPresented: $confirmUnpair, titleVisibility: .visible) {
            Button("接続を解除", role: .destructive) { link.unpair() }
                .accessibilityIdentifier("pc-link-unpair-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("PCの登録からもこのiPhoneを外します。PCのモデルで話した会話は、このiPhoneに残ります。")
        }
    }
}

/// Whether the PC answers, in a word and a dot.
struct PCLinkStatusLine: View {
    @ObservedObject private var link = PCLinkStore.shared

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7).accessibilityHidden(true)
            Text(text).font(.caption).foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("pc-link-status")
    }

    private var color: Color {
        switch link.connection {
        case .connected: return link.engineRunning == false ? Theme.caution : .green
        case .checking, .none: return Color.secondary.opacity(0.5)
        case .unreachable, .revoked, .wrongPC: return Theme.caution
        }
    }

    private var text: String {
        switch link.connection {
        case .connected:
            return link.engineRunning == false ? String(localized: "接続中 · PCのOllamaが止まっています") : String(localized: "接続中")
        case .checking: return String(localized: "確かめています…")
        case .unreachable: return String(localized: "接続できません")
        case .revoked: return String(localized: "PCで登録が削除されました")
        case .wrongPC: return String(localized: "証明書が違うため接続をやめました")
        case .none: return String(localized: "未登録")
        }
    }
}

/// The PC's models, each starting a chat answered by it.
private struct PCLinkModelsCard: View {
    @ObservedObject private var link = PCLinkStore.shared
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.closeSettings) private var closeSettings

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("PCのモデル")
                .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                .padding(.horizontal, 16).padding(.top, 14).padding(.bottom, 6)
                .accessibilityAddTraits(.isHeader)
            if link.models.isEmpty {
                Text(link.isConnected ? "PCにモデルがありません。PCのFieluaでモデルをダウンロードしてください。"
                                      : "PCに接続すると、ここにモデルが出ます。")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 16).padding(.bottom, 14)
                    .accessibilityIdentifier("pc-link-models-empty")
            } else {
                ForEach(link.models) { model in
                    if model.id != link.models.first?.id { Divider().padding(.leading, 16) }
                    row(model)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("pc-link-models")
    }

    private func row(_ model: PCModel) -> some View {
        let current = chats.currentPC?.model == model.name && chats.currentPC?.pcID == link.paired?.pcID
        return HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: model.shortName).font(.body)
                let detail = PCLinkStore.detail(model)
                if !detail.isEmpty { Text(verbatim: detail).font(.caption).foregroundStyle(.secondary) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            let use = Button {
                guard let pc = link.paired else { return }
                chats.newPCChat(PCChatTarget(pcID: pc.pcID, pcName: pc.pcName, model: model.name))
                closeSettings()
            } label: {
                if current { Label("使用中", systemImage: "checkmark") } else { Text("会話を始める") }
            }
            .disabled(current || chats.isGenerating)
            .accessibilityIdentifier("pc-link-use-\(model.name)")
            if current { use.buttonStyle(FieluaStateTag()) } else { use.fieluaProminentButton() }
        }
        .padding(.horizontal, 16).padding(.vertical, 10)
        .frame(minHeight: 56)
    }
}

/// No PC yet: the QR code, the connection code, and the PCs found here.
private struct PCLinkAddCard: View {
    @ObservedObject private var link = PCLinkStore.shared
    @ObservedObject var browser: PCLinkBrowser
    let cameraDenied: Bool
    let add: (PCPairingRequest) -> Void
    @Environment(\.openURL) private var openURL

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if link.connection == .revoked {
                Label("PCでこのiPhoneの登録が削除されました。もう一度登録してください。", systemImage: "exclamationmark.circle")
                    .font(.subheadline).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("pc-link-revoked")
            }
            Text("PCのFieluaで設定の「デバイスと接続」をオンにして「iPhone を追加」を押すと、QRコードと8けたの接続コードが出ます。")
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: true)
            if PCQRScanner.supported {
                Button { add(PCPairingRequest(mode: .scan)) } label: {
                    Label("QRコードを読み取る", systemImage: "qrcode.viewfinder")
                        .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaProminentButton()
                .controlSize(.large)
                .accessibilityIdentifier("pc-link-scan")
            }
            Button { add(PCPairingRequest(mode: .code(nil))) } label: {
                Text("接続コードを入力").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .modifier(CodeButtonStyle(prominent: !PCQRScanner.supported))
            .controlSize(.large)
            .accessibilityIdentifier("pc-link-code")
            if cameraDenied {
                Button {
                    if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
                } label: {
                    Text("QRコードを読み取るには、iOSの設定でFieluaのカメラをオンにしてください。")
                        .font(.caption).multilineTextAlignment(.leading)
                }
                .accessibilityIdentifier("pc-link-camera-denied")
            }
            found
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("pc-link-add")
    }

    @ViewBuilder private var found: some View {
        if browser.denied {
            Button {
                if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
            } label: {
                Text("同じネットワークのPCを探すには、iOSの設定でFieluaの「ローカルネットワーク」をオンにしてください。")
                    .font(.caption).multilineTextAlignment(.leading)
            }
            .accessibilityIdentifier("pc-link-local-network-denied")
        } else if !browser.found.isEmpty {
            VStack(alignment: .leading, spacing: 0) {
                Text("このネットワークのPC")
                    .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    .padding(.bottom, 4)
                    .accessibilityAddTraits(.isHeader)
                ForEach(browser.found) { pc in
                    Button { add(PCPairingRequest(mode: .code(pc))) } label: {
                        HStack(spacing: 10) {
                            PCMark(size: 28)
                            Text(verbatim: pc.name).frame(maxWidth: .infinity, alignment: .leading)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 13, weight: .semibold)).foregroundStyle(.tertiary)
                                .accessibilityHidden(true)
                        }
                        .frame(minHeight: 44)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityHint("接続コードで登録します")
                    .accessibilityIdentifier("pc-link-found-\(pc.id)")
                }
            }
            .padding(.top, 4)
        }
    }

    private struct CodeButtonStyle: ViewModifier {
        let prominent: Bool
        func body(content: Content) -> some View {
            if prominent { content.fieluaProminentButton() } else { content.fieluaSecondaryButton() }
        }
    }
}

private struct PCLinkNotes: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("PCへは、返信に必要な会話の文章だけを暗号化して送ります。写真・ファイル・音声と、Apple Watchからの質問は、PCのモデルには送りません。")
            Text("家や職場など、同じネットワークの中だけでつながります。インターネット経由では使えません。")
        }
        .font(.caption).foregroundStyle(.secondary)
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityIdentifier("pc-link-notes")
    }
}

/// The PC's mark: a desktop in Fielua's warm grey on the card's paper.
struct PCMark: View {
    let size: CGFloat
    var body: some View {
        Image(systemName: "desktopcomputer")
            .font(.system(size: size * 0.48, weight: .regular))
            .foregroundStyle(Theme.icon)
            .frame(width: size, height: size)
            .background(Theme.ink.opacity(0.06), in: RoundedRectangle(cornerRadius: size * 0.26, style: .continuous))
            .accessibilityHidden(true)
    }
}

// MARK: - Registering

/// The QR code, or the connection code and the PC's address; then the six
/// digits both screens show while the PC's person approves.
private struct PCPairingSheet: View {
    let request: PCPairingRequest
    @StateObject private var pairing = PCPairing()
    @Environment(\.dismiss) private var dismiss
    @State private var scanning = false
    @State private var code = ""
    @State private var address = ""
    @State private var scanProblem: String?
    @FocusState private var field: Field?

    private enum Field { case code, address }

    var body: some View {
        NavigationStack {
            ScrollView {
                content
                    .padding(20)
                    .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Theme.canvas)
            .navigationTitle("PCを登録")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        pairing.cancel()
                        dismiss()
                    } label: {
                        Text(isDone ? "閉じる" : "キャンセル")
                    }
                    .accessibilityIdentifier("pc-pair-close")
                }
            }
        }
        .onAppear {
            scanning = request.mode == .scan
            if case .code(let found?) = request.mode { address = found.host + ":\(found.port)" }
        }
        .onDisappear { if pairing.isBusy { pairing.cancel() } }
        .interactiveDismissDisabled(pairing.isBusy)
    }

    private var isDone: Bool { if case .paired = pairing.phase { return true } else { return false } }

    @ViewBuilder private var content: some View {
        switch pairing.phase {
        case .idle:
            if scanning { scanner } else { codeForm }
        case .connecting:
            waiting("PCに接続しています…")
        case .confirming(let number, let pcName):
            confirming(number: number, pcName: pcName)
        case .paired(let pcName):
            paired(pcName)
        case .failed(let message):
            failed(message)
        }
    }

    private var scanner: some View {
        VStack(spacing: 14) {
            Text("PCに出ているQRコードを枠に入れてください。")
                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
            PCQRScanner { text in
                guard let invite = PCPairingInvite(text) else {
                    scanProblem = String(localized: "Fielua for WindowsのQRコードではありません。")
                    return false
                }
                scanProblem = nil
                pairing.start(invite: invite)
                return true
            }
            .frame(height: 340)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .accessibilityLabel("カメラ")
            if let scanProblem {
                Text(scanProblem).font(.caption).foregroundStyle(Theme.caution)
                    .accessibilityIdentifier("pc-pair-scan-problem")
            }
            Button("接続コードを入力") { scanning = false }
                .font(.subheadline)
                .accessibilityIdentifier("pc-pair-use-code")
        }
    }

    private var codeForm: some View {
        let found: PCLinkBrowser.Found? = { if case .code(let found) = request.mode { return found } else { return nil } }()
        let digits = PCLink.normalizedCode(code)
        let target = PCLink.address(address)
        return VStack(alignment: .leading, spacing: 16) {
            if let found {
                HStack(spacing: 10) {
                    PCMark(size: 32)
                    Text(verbatim: found.name).font(.headline)
                }
            }
            VStack(alignment: .leading, spacing: 6) {
                Text("接続コード").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                TextField("8けたの数字", text: $code)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
                    .font(.title3.monospacedDigit())
                    .focused($field, equals: .code)
                    .padding(.horizontal, 14).frame(minHeight: 50)
                    .fieluaCard(cornerRadius: 14)
                    .accessibilityIdentifier("pc-pair-code")
            }
            if found == nil {
                VStack(alignment: .leading, spacing: 6) {
                    Text("PCのアドレス").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    TextField("192.168.1.10", text: $address)
                        .keyboardType(.numbersAndPunctuation)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .focused($field, equals: .address)
                        .padding(.horizontal, 14).frame(minHeight: 50)
                        .fieluaCard(cornerRadius: 14)
                        .accessibilityIdentifier("pc-pair-address")
                    Text("PCの「デバイスと接続」に出ているアドレスです。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            FieluaPrimaryButton("接続", enabled: digits.count == 8 && target != nil) {
                guard let target else { return }
                field = nil
                pairing.start(host: target.host, port: target.port, code: digits,
                              pinned: found?.fingerprint, expectedID: found?.id)
            }
            .accessibilityIdentifier("pc-pair-connect")
        }
        .onAppear { field = .code }
    }

    private func waiting(_ text: LocalizedStringKey) -> some View {
        VStack(spacing: 12) {
            ProgressView()
            Text(text).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity).padding(.top, 40)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("pc-pair-connecting")
    }

    private func confirming(number: String, pcName: String) -> some View {
        VStack(spacing: 18) {
            PCMark(size: 52)
            Text(verbatim: pcName).font(.headline)
            VStack(spacing: 6) {
                Text("確認の数字").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                Text(verbatim: number)
                    .font(.system(size: 44, weight: .semibold, design: .rounded).monospacedDigit())
                    .accessibilityIdentifier("pc-pair-number")
            }
            .padding(.vertical, 18).frame(maxWidth: .infinity)
            .fieluaCard(cornerRadius: 20)
            Text("PCの画面に同じ数字が出ていれば、PCで「許可する」を押してください。数字が違うときはキャンセルしてください。")
                .font(.subheadline).multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                ProgressView()
                Text("PCの許可を待っています…").font(.caption).foregroundStyle(.secondary)
            }
            .accessibilityElement(children: .combine)
            .accessibilityIdentifier("pc-pair-waiting")
        }
        .padding(.top, 8)
    }

    private func paired(_ pcName: String) -> some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 52))
                .symbolRenderingMode(.palette)
                .foregroundStyle(Theme.onAccent, Theme.accent)
                .accessibilityHidden(true)
            Text("「\(pcName)」を登録しました").font(.headline).multilineTextAlignment(.center)
                .accessibilityIdentifier("pc-pair-done")
            Text("チャットのモデルの選択で、PCのモデルを選べます。")
                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
            FieluaPrimaryButton("完了") { dismiss() }
                .accessibilityIdentifier("pc-pair-finish")
        }
        .padding(.top, 24)
    }

    private func failed(_ message: String) -> some View {
        VStack(spacing: 16) {
            Image(systemName: "exclamationmark.circle")
                .font(.system(size: 44)).foregroundStyle(Theme.caution)
                .accessibilityHidden(true)
            Text(verbatim: message).font(.subheadline).multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("pc-pair-failed")
            FieluaPrimaryButton("もう一度") { pairing.reset() }
                .accessibilityIdentifier("pc-pair-retry")
        }
        .padding(.top, 24)
    }
}

/// iOS's own scanner (VisionKit) for the QR code; nothing is kept. Where
/// the phone has no scanner (the simulator), the connection code is used.
private struct PCQRScanner: UIViewControllerRepresentable {
    /// Returns whether the text was a PC's invitation; scanning stops then.
    let found: (String) -> Bool

    static var supported: Bool { DataScannerViewController.isSupported }

    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(recognizedDataTypes: [.barcode(symbologies: [.qr])],
                                                qualityLevel: .balanced, recognizesMultipleItems: false,
                                                isHighFrameRateTrackingEnabled: false, isPinchToZoomEnabled: true,
                                                isGuidanceEnabled: true, isHighlightingEnabled: true)
        scanner.delegate = context.coordinator
        try? scanner.startScanning()
        return scanner
    }

    func updateUIViewController(_ scanner: DataScannerViewController, context: Context) {}

    static func dismantleUIViewController(_ scanner: DataScannerViewController, coordinator: Coordinator) {
        scanner.stopScanning()
    }

    func makeCoordinator() -> Coordinator { Coordinator(found: found) }

    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let found: (String) -> Bool
        private var done = false
        init(found: @escaping (String) -> Bool) { self.found = found }

        func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem],
                         allItems: [RecognizedItem]) {
            guard !done else { return }
            for item in addedItems {
                guard case .barcode(let barcode) = item, let text = barcode.payloadStringValue else { continue }
                if found(text) {
                    done = true
                    dataScanner.stopScanning()
                    return
                }
            }
        }
    }
}
