import SwiftUI
import UIKit

/// How 設定's pages slide on this phone, for 開発者設定. A screen recording
/// keeps at most 60 frames a second, so it cannot show any of this.
///
/// Each slide: how long after the tap it began moving, the frames that drew
/// it and their longest gap (1.1.0 (152)); since 153 also how busy the main
/// thread was meanwhile, the display's beats it missed, and which views
/// drew again. 「ページ移動を計測」 slides every page in and back out, twice,
/// and puts it all in one table to compare. Since 1.1.0 (283) (fielua-reports
/// Issue #20) the pages are the ones a person goes through (モデル管理 and a
/// series' page over it, ウェブ検索, 会話履歴 and the rest), each also with
/// the page underneath scrolled under the bar, so the blur under the bar
/// changes as it slides; and each stretch of main-thread work is held
/// against a 120Hz frame (8.3 ms), which a 60Hz simulator cannot show by
/// its frame rate alone.
@Observable @MainActor final class SettingsSlideMeter {
    static let shared = SettingsSlideMeter()

    /// The ways of sliding the measurement compares: 152's, and 153's with
    /// one condition at a time taken away.
    enum Variant: CaseIterable {
        /// 152: SwiftUI's animation, nothing asking for the screen's rate.
        case swiftUI
        /// SwiftUI's animation, with a display link asking for 120Hz beside it.
        case swiftUIAsking
        /// 153 to 282: moved at each beat of a display link that asks for
        /// 120Hz, to wherever the curve says, however little that moves it.
        case driven282
        /// 283: as 282, but a beat that would move a page by less than one of
        /// the screen's pixels leaves it where it is, and a page within 2% of
        /// whole or hidden is whole or hidden (fielua-reports Issue #20). The
        /// page coming and the one going both partly see-through, one over
        /// the other.
        case driven283
        /// 286 to 290: as 283, but the page on top covers the one
        /// underneath, which is cut where the top page begins, and the top
        /// page comes in and goes out whole (fielua-reports Issue #22). The
        /// page underneath still fades as it goes, gone a little past
        /// halfway: swiped back, the page coming showed as bare paper until
        /// then (Hachimoto さん's recording, 2026-11-16).
        case driven290
        /// 291: as 290, but the page underneath stays whole where it shows,
        /// a little darker the more it is covered, as iOS's own pages; and
        /// the names in the bar fade before they reach its buttons. The
        /// page coming in met the sheet's top and bottom edges square.
        case driven291
        /// 292: as 291, but the page on top, while it slides, is cut to the
        /// sheet's own outline, its corners as round as the sheet's, over
        /// a paper of its own; the page underneath shows in its corners.
        case driven
        /// As `driven`, pages only whole or hidden, never partly see-through,
        /// so no page is drawn apart to be blended.
        case drivenNoFade
        /// As `driven`, each page an empty list, so nothing of a page's own
        /// is drawn.
        case drivenEmptyPages

        var label: String {
            switch self {
            case .swiftUI: "152の動き（SwiftUIのアニメーション）"
            case .swiftUIAsking: "152の動き＋120Hzを要求"
            case .driven282: "282までの動き（コマごとに曲線どおり細かく動かす）"
            case .driven283: "283の動き（1ピクセル未満の動きと2%未満の透け具合は描き直さない）"
            case .driven290: "290までの動き（上のページが下のページを覆い、下のページは薄れていく）"
            case .driven291: "291の動き（下のページは薄れず少し暗くなる・バーの名前はボタンの手前で消える）"
            case .driven: "292の動き（291＋スライドしてくるページの角をシートと同じ丸みに）"
            case .drivenNoFade: "153の動き・フェードなし"
            case .drivenEmptyPages: "153の動き・ページの中身なし"
            }
        }
        var drivesItself: Bool { self != .swiftUI && self != .swiftUIAsking }
        /// Leaves out what no one could see change (283's way).
        var settles: Bool { drivesItself && self != .driven282 }
        /// Whether anything asks the display for its full rate meanwhile.
        var asksForFullRate: Bool { self != .swiftUI }
        var fades: Bool { self != .drivenNoFade }
        /// The page on top covers the one underneath (286's way): every way
        /// of sliding but 282's and 283's, the meter's before and after.
        var covers: Bool { drivesItself && self != .driven282 && self != .driven283 }
        var emptyPages: Bool { self == .drivenEmptyPages }
        /// 291's way: the page underneath whole where it shows, darkened by
        /// how much of it is covered, and the names in the bar clear of its
        /// buttons. Every way that covers but 286's to 290's.
        var keepsUnder: Bool { covers && self != .driven290 }
        /// 292's way: the page on top, while it slides, has the sheet's
        /// rounded corners. Every way that keeps the page underneath but
        /// 291's.
        var rounds: Bool { keepsUnder && self != .driven291 }
        /// The ways 「ページ移動を計測」 compares: since 283 only the way the
        /// pages slide (the others told 152 from 153, 2026-10-23).
        static var measured: [Variant] {
            #if POCKET_PREVIEW
            if ProcessInfo.processInfo.arguments.contains("--settings-perf-variants") { return allCases }
            // The UI check's before and after, in one run on one machine.
            // Since 1.1.0 (286) 283's way against 286's (Issue #22).
            if ProcessInfo.processInfo.arguments.contains("--settings-perf-compare") { return [.driven283, .driven] }
            // 1.1.0 (291): 290's way against 291's.
            if ProcessInfo.processInfo.arguments.contains("--settings-perf-compare-290") { return [.driven290, .driven] }
            // 1.1.0 (292): 291's square edge against 292's rounded corners.
            if ProcessInfo.processInfo.arguments.contains("--settings-perf-compare-291") { return [.driven291, .driven] }
            #endif
            return [.driven]
        }
    }

    /// Where a page starts from (1.1.0 (283)): every list at its top, or the
    /// page underneath scrolled under the bar, so the bar's blur goes from
    /// one page's strength to the other's while they slide.
    enum Condition: CaseIterable {
        case atTop, scrolled
        var label: String {
            switch self {
            case .atTop: "ページの一番上から"
            case .scrolled: "スクロールしたページから（バーのぼかしが変わる）"
            }
        }
    }

    /// One 120Hz frame, in seconds: a stretch of main-thread work longer
    /// than this would have kept a frame from the screen at 120Hz.
    static let frame120: CFTimeInterval = 1.0 / 120

    /// The last slide, in one line.
    private(set) var summary: String?
    /// The measurement's table, once it has run.
    private(set) var report: String?
    private(set) var running = false
    /// How the pages slide while the measurement runs.
    @ObservationIgnored var variant = SettingsSlideMeter.everyday
    /// How the pages slide outside the measurement: 292's way, or for the UI
    /// check's before and after 283's (`--settings-slide-283`), 290's
    /// (`--settings-slide-290`) or 291's (`--settings-slide-291`), preview only.
    static var everyday: Variant {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-slide-283") { return .driven283 }
        if PreviewProbe.on("--settings-slide-290") { return .driven290 }
        if PreviewProbe.on("--settings-slide-291") { return .driven291 }
        #endif
        return .driven
    }
    #if POCKET_PREVIEW
    /// The last slide's tap, first frame that moved and last frame, on the
    /// media clock: the UI check's profile windows (1.1.0 (291)).
    @ObservationIgnored private(set) var lastTimes: (asked: CFTimeInterval, first: CFTimeInterval, last: CFTimeInterval)?
    #endif
    /// Set by the sheet: starts the measurement.
    @ObservationIgnored var runner: (() -> Void)?

    @ObservationIgnored private var askedAt: CFTimeInterval = 0
    @ObservationIgnored private var lastBeatAt: CFTimeInterval?
    @ObservationIgnored private var frames: [CFTimeInterval] = []
    /// From the tap to the slide's end.
    @ObservationIgnored private var watching = false
    /// From the slide's first frame to its end.
    @ObservationIgnored private var moving = false
    @ObservationIgnored private var busy: [(start: CFTimeInterval, end: CFTimeInterval)] = []
    @ObservationIgnored private var wokeAt: CFTimeInterval?
    @ObservationIgnored private var beats: [CFTimeInterval] = []
    @ObservationIgnored private var beat: CFTimeInterval = 1.0 / 60
    @ObservationIgnored private var redrawn: [String: Int] = [:]
    @ObservationIgnored private var redrawnBefore: [String: Int] = [:]
    /// Pages drawn partly see-through while it moved (each is drawn apart
    /// and blended: work for the GPU a simulator does not show), and beats
    /// that moved nothing by a pixel and so changed nothing.
    @ObservationIgnored private var blendedFrames = 0
    /// Frames the page underneath still showed where the top page was, both
    /// partly or wholly in view, so their words read one over the other
    /// (fielua-reports Issue #22), and the most of it in one frame: the
    /// share of the sheet's width, by the fainter page's opacity.
    @ObservationIgnored private var overlapFrames = 0
    @ObservationIgnored private var overlapMost = 0.0
    @ObservationIgnored private var stillBeats = 0
    /// When each body ran while it moved, to name what a long stretch made.
    @ObservationIgnored private var drawnAt: [(time: CFTimeInterval, name: String)] = []
    @ObservationIgnored private var probe: SettingsBeatProbe?
    @ObservationIgnored private var observers: [CFRunLoopObserver] = []
    @ObservationIgnored private var current: (page: String, opening: Bool)?
    /// The condition the measurement is in, for the table.
    @ObservationIgnored var condition = Condition.atTop
    @ObservationIgnored private var slides: [Slide] = []

    struct Slide {
        var variant: Variant
        var condition: Condition
        var page: String
        var opening: Bool
        /// From the tap to the first frame that moved, in ms.
        var delay: Double
        var frames: Int
        var fps: Double
        /// The longest gap between two frames of the slide, in ms.
        var gap: Double
        /// The display's beats the main thread was too busy to answer.
        var missed: Int
        /// The main thread's busy share while it moved, 0 to 1.
        var load: Double
        /// Its longest stretch without rest while it moved, in ms.
        var longest: Double
        /// Busy between the tap and the first move, in ms.
        var before: Double
        /// Stretches of main-thread work while it moved longer than a 120Hz
        /// frame (8.3 ms) and than a 60Hz one (16.7 ms).
        var over120: Int
        var over60: Int
        /// The median stretch of main-thread work while it moved, in ms.
        var median: Double
        /// Where the long stretches fell: the slide's frame each came
        /// before (1 = the first frame that moved), with its length in ms.
        var long: [(frame: Int, ms: Double, drew: String)]
        var redrawn: [String: Int]
        var redrawnBefore: [String: Int]
        /// Frames a page was drawn partly see-through, page by page.
        var blended: Int
        /// Beats left as they were: the page would have moved under a pixel.
        var still: Int
        /// Frames the two pages showed over the same place (1.1.0 (286)),
        /// and the most of it: % of the width by the fainter one's opacity.
        var overlapped = 0
        var overlapMost = 0.0
    }

    // MARK: One slide

    func asked() {
        watchMainThread()
        let now = CACurrentMediaTime()
        askedAt = now
        lastBeatAt = nil
        watching = true
        moving = false
        busy = []
        wokeAt = now
        beats = []
        redrawn = [:]
        redrawnBefore = [:]
        drawnAt = []
        blendedFrames = 0
        overlapFrames = 0
        overlapMost = 0
        stillBeats = 0
        probe?.stop()
        probe = SettingsBeatProbe(fullRate: variant.asksForFullRate)
    }

    func began() {
        frames = []
        moving = true
    }

    /// Each time the top page is drawn at a new place in its slide.
    func frame() {
        guard moving else { return }
        let now = CACurrentMediaTime()
        if let last = frames.last, now - last < 0.002 { return }
        frames.append(now)
    }

    /// A page was placed partly see-through for a frame of the slide.
    func blended() {
        if moving { blendedFrames += 1 }
    }

    /// The page underneath was drawn showing where the top page is:
    /// `amount` is the width the two share (0 to 1) by the fainter one's
    /// opacity.
    func overlapped(_ amount: Double) {
        guard moving, amount > 0.002 else { return }
        overlapFrames += 1
        overlapMost = max(overlapMost, amount)
    }

    /// A beat that left the pages where they were; the frame it shows is
    /// the last one, as it would have been, so it counts as a frame.
    func stillBeat() {
        guard moving else { return }
        stillBeats += 1
        frame()
    }

    /// A view's body ran: counted while a slide is on its way.
    static func drew(_ name: String) {
        let meter = shared
        guard meter.watching else { return }
        if meter.moving {
            meter.redrawn[name, default: 0] += 1
            meter.drawnAt.append((time: CACurrentMediaTime(), name: name))
        } else {
            meter.redrawnBefore[name, default: 0] += 1
        }
    }

    /// The slide's last beat has set its last place: the frame it makes is
    /// still to be drawn, so `ended` waits for the next beat.
    func lastBeat() {
        guard watching else { return }
        lastBeatAt = CACurrentMediaTime()
    }

    func ended() {
        guard watching else { return }
        let end = CACurrentMediaTime()
        if let start = wokeAt { busy.append((start: start, end: end)); wokeAt = end }
        watching = false
        moving = false
        probe?.stop()
        probe = nil
        let finalBeat = lastBeatAt
        lastBeatAt = nil
        guard frames.count > 1, let first = frames.first, let drawn = frames.last, drawn > first else { return }
        // To the last frame drawn, or the last beat's, whose frame is made
        // after it: until 283 the slide's last frame (made once its beat had
        // ended the slide) was left out, with whatever it drew again.
        let last = max(drawn, finalBeat ?? drawn)
        let gaps = zip(frames.dropFirst(), frames).map { $0 - $1 }
        func clipped(_ from: CFTimeInterval, _ to: CFTimeInterval) -> [CFTimeInterval] {
            busy.map { min($0.end, to) - max($0.start, from) }.filter { $0 > 0 }
        }
        let during = clipped(first, last)
        let longest = busy.filter { $0.end > first && $0.start < last }.map { $0.end - $0.start }.max() ?? 0
        let inSlide = beats.filter { $0 >= first && $0 <= last }
        let missed = zip(inSlide.dropFirst(), inSlide).map { max(Int((($0 - $1) / beat).rounded()) - 1, 0) }.reduce(0, +)
        // Each stretch of work from the one that made the first frame to
        // the last, and the frame drawn in it.
        let stretches = busy.filter { $0.end > first && $0.start < last }
        let lengths = stretches.map { $0.end - $0.start }.sorted()
        // With the bodies that ran in it (none: UIKit's or Core Animation's
        // own work, or the slide's frame alone).
        let long = stretches.filter { $0.end - $0.start > Self.frame120 }.map { stretch in
            let names = drawnAt.filter { $0.time >= stretch.start && $0.time <= stretch.end }.map(\.name)
            let drew = names.reduce(into: [String]()) { if !$0.contains($1) { $0.append($1) } }.joined(separator: "・")
            return (frame: (frames.firstIndex { $0 >= stretch.start } ?? frames.count - 1) + 1,
                    ms: (stretch.end - stretch.start) * 1000, drew: drew)
        }
        let slide = Slide(variant: variant, condition: condition, page: current?.page ?? "", opening: current?.opening ?? true,
                          delay: (first - askedAt) * 1000, frames: frames.count,
                          fps: Double(frames.count - 1) / (last - first), gap: (gaps.max() ?? 0) * 1000,
                          missed: missed, load: during.reduce(0, +) / (last - first), longest: longest * 1000,
                          before: clipped(askedAt, first).reduce(0, +) * 1000,
                          over120: lengths.filter { $0 > Self.frame120 }.count,
                          over60: lengths.filter { $0 > 1.0 / 60 }.count,
                          median: lengths.isEmpty ? 0 : lengths[lengths.count / 2] * 1000,
                          long: long,
                          redrawn: redrawn, redrawnBefore: redrawnBefore,
                          blended: blendedFrames, still: stillBeats, overlapped: overlapFrames, overlapMost: overlapMost)
        #if POCKET_PREVIEW
        lastTimes = (asked: askedAt, first: first, last: last)
        #endif
        // Only the table's own slides: not the way back to the rows from
        // 開発者設定 before the first page (run 40037555815 counted it).
        if running, current != nil { slides.append(slide) }
        summary = "直近のページ移動：" + Self.line(slide) + "（画面は最大 \(Self.display)Hz・\(Self.conditions)）"
    }

    fileprivate func beat(at time: CFTimeInterval, length: CFTimeInterval) {
        guard watching else { return }
        beats.append(time)
        if length > 0 { beat = length }
    }

    /// Busy from each wake of the main run loop to its next sleep, the
    /// observers last to see it fall asleep, after the frame is committed.
    private func watchMainThread() {
        guard observers.isEmpty else { return }
        let woke = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.afterWaiting.rawValue,
                                                      true, CFIndex.min) { _, _ in
            MainActor.assumeIsolated { SettingsSlideMeter.shared.woke() }
        }
        let sleeps = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.beforeWaiting.rawValue,
                                                        true, CFIndex.max) { _, _ in
            MainActor.assumeIsolated { SettingsSlideMeter.shared.sleeps() }
        }
        for observer in [woke, sleeps].compactMap({ $0 }) {
            CFRunLoopAddObserver(CFRunLoopGetMain(), observer, .commonModes)
            observers.append(observer)
        }
    }

    private func woke() {
        if watching { wokeAt = CACurrentMediaTime() }
    }

    private func sleeps() {
        guard watching, let start = wokeAt else { return }
        busy.append((start: start, end: CACurrentMediaTime()))
        wokeAt = nil
    }

    // MARK: The measurement

    func start() {
        slides = []
        current = nil
        condition = .atTop
        report = nil
        running = true
    }

    /// The slide about to be asked for, for its row in the table; nil for a
    /// slide on the way to a page that is measured (モデル管理 before a
    /// series' page), which the table leaves out.
    func next(_ page: String?, opening: Bool) { current = page.map { ($0, opening) } }

    func finish(rounds: Int) {
        running = false
        variant = Self.everyday
        condition = .atTop
        current = nil
        let info = Bundle.main.object(forInfoDictionaryKey: "CADisableMinimumFrameDurationOnPhone") as? Bool ?? false
        let version = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "-"
        var lines = [String(format: "ページ移動の計測（ビルド%@・%@・iOS %@・画面 最大%dHz・アプリの120Hz設定 %@・%@・%d回ずつ）",
                            version, DeviceOverview.identifier, UIDevice.current.systemVersion, Self.display,
                            info ? "あり" : "なし", Self.conditions, rounds),
                     "（8.3ms超＝120Hzの1コマに収まらなかった主スレッドの処理。［n:m(名前)］＝n コマ目を描いた処理が m ms、その間に描き直した部分）"]
        for variant in Variant.allCases {
            for condition in Condition.allCases {
                let group = slides.filter { $0.variant == variant && $0.condition == condition }
                guard !group.isEmpty else { continue }
                lines.append("［\(Variant.measured.count > 1 ? variant.label + "・" : "")\(condition.label)］")
                var seen: [(String, Bool)] = []
                for slide in group where !seen.contains(where: { $0 == (slide.page, slide.opening) }) {
                    seen.append((slide.page, slide.opening))
                    let same = group.filter { $0.page == slide.page && $0.opening == slide.opening }
                    lines.append(Self.line(Self.combined(same)))
                }
                let all = Self.combined(group)
                lines.append(String(format: "→ 平均 %.0ffps・取りこぼし 計%d・主スレッド %.0f%%・8.3ms超 計%d・16.7ms超 計%d・最長 %.0fms・半透明で描いたページ 計%d・据え置いたコマ 計%d・2ページが重なったコマ 計%d（最大 %.0f%%）",
                                    all.fps, all.missed, all.load * 100, all.over120, all.over60, all.longest, all.blended, all.still,
                                    all.overlapped, all.overlapMost * 100))
            }
        }
        report = lines.joined(separator: "\n")
        #if POCKET_PREVIEW
        // Whole for the UI check: read off the screen, a table this long is
        // cut short (run 43728880161 lost 283's half of the comparison).
        try? report?.write(to: FileManager.default.temporaryDirectory.appendingPathComponent("settings-perf-report.txt"),
                           atomically: true, encoding: .utf8)
        #endif
        slides = []
    }

    /// Several runs of one slide as one: the means, the worst gaps.
    private static func combined(_ slides: [Slide]) -> Slide {
        var result = slides[0]
        let count = Double(slides.count)
        result.delay = slides.map(\.delay).reduce(0, +) / count
        result.frames = slides.map(\.frames).reduce(0, +) / slides.count
        result.fps = slides.map(\.fps).reduce(0, +) / count
        result.gap = slides.map(\.gap).max() ?? 0
        result.missed = slides.map(\.missed).reduce(0, +)
        result.load = slides.map(\.load).reduce(0, +) / count
        result.longest = slides.map(\.longest).max() ?? 0
        result.before = slides.map(\.before).reduce(0, +) / count
        result.over120 = slides.map(\.over120).reduce(0, +)
        result.over60 = slides.map(\.over60).reduce(0, +)
        result.median = slides.map(\.median).reduce(0, +) / count
        result.long = slides.flatMap(\.long)
        result.redrawn = slides.reduce(into: [String: Int]()) { sum, slide in sum.merge(slide.redrawn, uniquingKeysWith: +) }
        result.redrawnBefore = slides.reduce(into: [String: Int]()) { sum, slide in sum.merge(slide.redrawnBefore, uniquingKeysWith: +) }
        result.blended = slides.map(\.blended).reduce(0, +)
        result.still = slides.map(\.still).reduce(0, +)
        result.overlapped = slides.map(\.overlapped).reduce(0, +)
        result.overlapMost = slides.map(\.overlapMost).max() ?? 0
        return result
    }

    private static func line(_ slide: Slide) -> String {
        func names(_ counts: [String: Int]) -> String {
            counts.isEmpty ? "なし" : counts.sorted { $0.key < $1.key }.map { "\($0.key)\($0.value)" }.joined(separator: " ")
        }
        let head = slide.page.isEmpty ? "" : "\(slide.page) \(slide.opening ? "開く" : "戻る")："
        let long = slide.long.isEmpty ? "" : "［" + slide.long.prefix(8).map {
            String(format: "%d:%.0f", $0.frame, $0.ms) + ($0.drew.isEmpty ? "" : "(\($0.drew))")
        }.joined(separator: " ") + "］"
        return head + String(format: "動き出すまで %.0fms（主スレッド %.0fms）・%dコマ・平均 %.0ffps・最長の間隔 %.0fms・取りこぼし %d・移動中の主スレッド %.0f%%（中央 %.1fms・最長 %.0fms・8.3ms超 %d%@・16.7ms超 %d）",
                             slide.delay, slide.before, slide.frames, slide.fps, slide.gap, slide.missed,
                             slide.load * 100, slide.median, slide.longest, slide.over120, long, slide.over60)
            + "・半透明で描いたページ \(slide.blended)・据え置いたコマ \(slide.still)"
            + String(format: "・2ページが重なったコマ %d（最大 %.0f%%）", slide.overlapped, slide.overlapMost * 100)
            + "・移動中の描き直し \(names(slide.redrawn))・動き出す前 \(names(slide.redrawnBefore))"
    }

    /// What lets iOS hold the screen at 60Hz or lower whatever the app asks
    /// (1.1.0 (283)): 低電力モード, the phone's heat and a screen recording.
    private static var conditions: String {
        let heat = switch ProcessInfo.processInfo.thermalState {
        case .nominal: "正常"
        case .fair: "やや高い"
        case .serious: "高い"
        case .critical: "危険"
        @unknown default: "不明"
        }
        let recording = UIApplication.shared.connectedScenes.contains {
            ($0 as? UIWindowScene)?.traitCollection.sceneCaptureState == .active
        }
        return "低電力モード \(ProcessInfo.processInfo.isLowPowerModeEnabled ? "オン" : "オフ")・端末の温度 \(heat)・画面収録 \(recording ? "あり" : "なし")"
    }

    private static var display: Int {
        UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.screen.maximumFramesPerSecond }.first ?? 60
    }
}

/// The display's beats on the main thread while a slide is measured: a beat
/// the main thread was too busy to answer is a frame it could not draw.
@MainActor private final class SettingsBeatProbe: NSObject {
    private var link: CADisplayLink?

    /// Off, the probe asks for no more than 60Hz, so that it does not raise
    /// the display's rate for the slide it measures (152's way).
    init(fullRate: Bool) {
        super.init()
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFrameRateRange = fullRate ? CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
                                                : CAFrameRateRange(minimum: 30, maximum: 60, preferred: 60)
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    func stop() {
        link?.invalidate()
        link = nil
    }

    @objc private func tick(_ link: CADisplayLink) {
        SettingsSlideMeter.shared.beat(at: link.timestamp, length: link.targetTimestamp - link.timestamp)
    }
}
