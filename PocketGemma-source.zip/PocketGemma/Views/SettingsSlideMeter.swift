import SwiftUI
import UIKit

/// How 設定's pages slide on this phone, for 開発者設定. A screen recording
/// keeps at most 60 frames a second, so it cannot show any of this.
///
/// Each slide: how long after the tap it began moving, the frames that drew
/// it and their longest gap (1.1.0 (152)); since 153 also how busy the main
/// thread was meanwhile, the display's beats it missed, and which views
/// drew again. 「ページ移動を計測」 slides every page in and back out, twice,
/// for each way of sliding, one condition taken away at a time, and puts
/// it all in one table to compare.
@Observable @MainActor final class SettingsSlideMeter {
    static let shared = SettingsSlideMeter()

    /// The ways of sliding the measurement compares: 152's, and 153's with
    /// one condition at a time taken away.
    enum Variant: CaseIterable {
        /// 152: SwiftUI's animation, nothing asking for the screen's rate.
        case swiftUI
        /// SwiftUI's animation, with a display link asking for 120Hz beside it.
        case swiftUIAsking
        /// 153: moved at each beat of a display link that asks for 120Hz.
        case driven
        /// As `driven`, pages only whole or hidden, never partly see-through,
        /// so no page is drawn apart to be blended.
        case drivenNoFade
        /// As `driven`, each page an empty list, so nothing of a page's own
        /// is drawn.
        case drivenEmptyPages

        var label: String {
            switch self {
            case .swiftUI: "152の動き（SwiftUIのアニメーション）"
            case .swiftUIAsking: "152の動き＋120Hzを要求"
            case .driven: "153の動き（画面の120Hzに合わせて動かす）"
            case .drivenNoFade: "153の動き・フェードなし"
            case .drivenEmptyPages: "153の動き・ページの中身なし"
            }
        }
        var drivesItself: Bool { self == .driven || self == .drivenNoFade || self == .drivenEmptyPages }
        /// Whether anything asks the display for its full rate meanwhile.
        var asksForFullRate: Bool { self != .swiftUI }
        var fades: Bool { self != .drivenNoFade }
        var emptyPages: Bool { self == .drivenEmptyPages }
    }

    /// The last slide, in one line.
    private(set) var summary: String?
    /// The measurement's table, once it has run.
    private(set) var report: String?
    private(set) var running = false
    /// How the pages slide while the measurement runs.
    @ObservationIgnored var variant = Variant.driven
    /// Set by the sheet: starts the measurement.
    @ObservationIgnored var runner: (() -> Void)?

    @ObservationIgnored private var askedAt: CFTimeInterval = 0
    @ObservationIgnored private var frames: [CFTimeInterval] = []
    /// From the tap to the slide's end.
    @ObservationIgnored private var watching = false
    /// From the slide's first frame to its end.
    @ObservationIgnored private var moving = false
    @ObservationIgnored private var busy: [(start: CFTimeInterval, end: CFTimeInterval)] = []
    @ObservationIgnored private var wokeAt: CFTimeInterval?
    @ObservationIgnored private var beats: [CFTimeInterval] = []
    @ObservationIgnored private var beat: CFTimeInterval = 1.0 / 60
    @ObservationIgnored private var redrawn: [String: Int] = [:]
    @ObservationIgnored private var redrawnBefore: [String: Int] = [:]
    @ObservationIgnored private var probe: SettingsBeatProbe?
    @ObservationIgnored private var observers: [CFRunLoopObserver] = []
    @ObservationIgnored private var current: (page: String, opening: Bool)?
    @ObservationIgnored private var slides: [Slide] = []

    struct Slide {
        var variant: Variant
        var page: String
        var opening: Bool
        /// From the tap to the first frame that moved, in ms.
        var delay: Double
        var frames: Int
        var fps: Double
        /// The longest gap between two frames of the slide, in ms.
        var gap: Double
        /// The display's beats the main thread was too busy to answer.
        var missed: Int
        /// The main thread's busy share while it moved, 0 to 1.
        var load: Double
        /// Its longest stretch without rest while it moved, in ms.
        var longest: Double
        /// Busy between the tap and the first move, in ms.
        var before: Double
        var redrawn: [String: Int]
        var redrawnBefore: [String: Int]
    }

    // MARK: One slide

    func asked() {
        watchMainThread()
        let now = CACurrentMediaTime()
        askedAt = now
        watching = true
        moving = false
        busy = []
        wokeAt = now
        beats = []
        redrawn = [:]
        redrawnBefore = [:]
        probe?.stop()
        probe = SettingsBeatProbe(fullRate: variant.asksForFullRate)
    }

    func began() {
        frames = []
        moving = true
    }

    /// Each time the top page is drawn at a new place in its slide.
    func frame() {
        guard moving else { return }
        let now = CACurrentMediaTime()
        if let last = frames.last, now - last < 0.002 { return }
        frames.append(now)
    }

    /// A view's body ran: counted while a slide is on its way.
    static func drew(_ name: String) {
        let meter = shared
        guard meter.watching else { return }
        if meter.moving { meter.redrawn[name, default: 0] += 1 } else { meter.redrawnBefore[name, default: 0] += 1 }
    }

    func ended() {
        guard watching else { return }
        let end = CACurrentMediaTime()
        if let start = wokeAt { busy.append((start: start, end: end)); wokeAt = end }
        watching = false
        moving = false
        probe?.stop()
        probe = nil
        guard frames.count > 1, let first = frames.first, let last = frames.last, last > first else { return }
        let gaps = zip(frames.dropFirst(), frames).map { $0 - $1 }
        func clipped(_ from: CFTimeInterval, _ to: CFTimeInterval) -> [CFTimeInterval] {
            busy.map { min($0.end, to) - max($0.start, from) }.filter { $0 > 0 }
        }
        let during = clipped(first, last)
        let longest = busy.filter { $0.end > first && $0.start < last }.map { $0.end - $0.start }.max() ?? 0
        let inSlide = beats.filter { $0 >= first && $0 <= last }
        let missed = zip(inSlide.dropFirst(), inSlide).map { max(Int((($0 - $1) / beat).rounded()) - 1, 0) }.reduce(0, +)
        let slide = Slide(variant: variant, page: current?.page ?? "", opening: current?.opening ?? true,
                          delay: (first - askedAt) * 1000, frames: frames.count,
                          fps: Double(frames.count - 1) / (last - first), gap: (gaps.max() ?? 0) * 1000,
                          missed: missed, load: during.reduce(0, +) / (last - first), longest: longest * 1000,
                          before: clipped(askedAt, first).reduce(0, +) * 1000,
                          redrawn: redrawn, redrawnBefore: redrawnBefore)
        if running { slides.append(slide) }
        summary = "直近のページ移動：" + Self.line(slide) + "（画面は最大 \(Self.display)Hz）"
    }

    fileprivate func beat(at time: CFTimeInterval, length: CFTimeInterval) {
        guard watching else { return }
        beats.append(time)
        if length > 0 { beat = length }
    }

    /// Busy from each wake of the main run loop to its next sleep, the
    /// observers last to see it fall asleep, after the frame is committed.
    private func watchMainThread() {
        guard observers.isEmpty else { return }
        let woke = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.afterWaiting.rawValue,
                                                      true, CFIndex.min) { _, _ in
            MainActor.assumeIsolated { SettingsSlideMeter.shared.woke() }
        }
        let sleeps = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.beforeWaiting.rawValue,
                                                        true, CFIndex.max) { _, _ in
            MainActor.assumeIsolated { SettingsSlideMeter.shared.sleeps() }
        }
        for observer in [woke, sleeps].compactMap({ $0 }) {
            CFRunLoopAddObserver(CFRunLoopGetMain(), observer, .commonModes)
            observers.append(observer)
        }
    }

    private func woke() {
        if watching { wokeAt = CACurrentMediaTime() }
    }

    private func sleeps() {
        guard watching, let start = wokeAt else { return }
        busy.append((start: start, end: CACurrentMediaTime()))
        wokeAt = nil
    }

    // MARK: The measurement

    func start() {
        slides = []
        report = nil
        running = true
    }

    /// The slide about to be asked for, for its row in the table.
    func next(_ page: String, opening: Bool) { current = (page, opening) }

    func finish(rounds: Int) {
        running = false
        variant = .driven
        current = nil
        let info = Bundle.main.object(forInfoDictionaryKey: "CADisableMinimumFrameDurationOnPhone") as? Bool ?? false
        var lines = [String(format: "ページ移動の計測（%@・iOS %@・画面 最大%dHz・アプリの120Hz設定 %@・低電力モード %@・%d回ずつ）",
                            DeviceOverview.identifier, UIDevice.current.systemVersion, Self.display,
                            info ? "あり" : "なし", ProcessInfo.processInfo.isLowPowerModeEnabled ? "オン" : "オフ", rounds)]
        for variant in Variant.allCases {
            let ofVariant = slides.filter { $0.variant == variant }
            guard !ofVariant.isEmpty else { continue }
            lines.append("［\(variant.label)］")
            var seen: [(String, Bool)] = []
            for slide in ofVariant where !seen.contains(where: { $0 == (slide.page, slide.opening) }) {
                seen.append((slide.page, slide.opening))
                let same = ofVariant.filter { $0.page == slide.page && $0.opening == slide.opening }
                lines.append(Self.line(Self.combined(same)))
            }
            let all = Self.combined(ofVariant)
            lines.append(String(format: "→ 平均 %.0ffps・取りこぼし 計%d・主スレッド %.0f%%", all.fps, all.missed, all.load * 100))
        }
        report = lines.joined(separator: "\n")
        slides = []
    }

    /// Several runs of one slide as one: the means, the worst gaps.
    private static func combined(_ slides: [Slide]) -> Slide {
        var result = slides[0]
        let count = Double(slides.count)
        result.delay = slides.map(\.delay).reduce(0, +) / count
        result.frames = slides.map(\.frames).reduce(0, +) / slides.count
        result.fps = slides.map(\.fps).reduce(0, +) / count
        result.gap = slides.map(\.gap).max() ?? 0
        result.missed = slides.map(\.missed).reduce(0, +)
        result.load = slides.map(\.load).reduce(0, +) / count
        result.longest = slides.map(\.longest).max() ?? 0
        result.before = slides.map(\.before).reduce(0, +) / count
        result.redrawn = slides.reduce(into: [String: Int]()) { sum, slide in sum.merge(slide.redrawn, uniquingKeysWith: +) }
        result.redrawnBefore = slides.reduce(into: [String: Int]()) { sum, slide in sum.merge(slide.redrawnBefore, uniquingKeysWith: +) }
        return result
    }

    private static func line(_ slide: Slide) -> String {
        func names(_ counts: [String: Int]) -> String {
            counts.isEmpty ? "なし" : counts.sorted { $0.key < $1.key }.map { "\($0.key)\($0.value)" }.joined(separator: " ")
        }
        let head = slide.page.isEmpty ? "" : "\(slide.page) \(slide.opening ? "開く" : "戻る")："
        return head + String(format: "動き出すまで %.0fms（主スレッド %.0fms）・%dコマ・平均 %.0ffps・最長の間隔 %.0fms・取りこぼし %d・移動中の主スレッド %.0f%%（最長 %.0fms）",
                             slide.delay, slide.before, slide.frames, slide.fps, slide.gap, slide.missed,
                             slide.load * 100, slide.longest)
            + "・移動中の描き直し \(names(slide.redrawn))・動き出す前 \(names(slide.redrawnBefore))"
    }

    private static var display: Int {
        UIApplication.shared.connectedScenes.compactMap { ($0 as? UIWindowScene)?.screen.maximumFramesPerSecond }.first ?? 60
    }
}

/// The display's beats on the main thread while a slide is measured: a beat
/// the main thread was too busy to answer is a frame it could not draw.
@MainActor private final class SettingsBeatProbe: NSObject {
    private var link: CADisplayLink?

    /// Off, the probe asks for no more than 60Hz, so that it does not raise
    /// the display's rate for the slide it measures (152's way).
    init(fullRate: Bool) {
        super.init()
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFrameRateRange = fullRate ? CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
                                                : CAFrameRateRange(minimum: 30, maximum: 60, preferred: 60)
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    func stop() {
        link?.invalidate()
        link = nil
    }

    @objc private func tick(_ link: CADisplayLink) {
        SettingsSlideMeter.shared.beat(at: link.timestamp, length: link.targetTimestamp - link.timestamp)
    }
}
