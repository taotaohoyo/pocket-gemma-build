import Foundation
import PDFKit
import Vision
import ZIPFoundation
import PocketCore

enum DocumentReader {
    struct Result {
        let text: String
        let note: String?
    }
    static func pdf(_ url: URL, limit: Int) throws -> Result {
        guard let document = PDFDocument(url: url) else { throw AttachmentStorage.ImportError.unreadable }
        guard !document.isLocked else { throw AttachmentStorage.ImportError.locked }
        var text = "", scanned = 0, visited = 0
        for index in 0..<min(document.pageCount, 100) {
            try Task.checkCancellation()
            guard let page = document.page(at: index) else { continue }
            var body = page.string ?? ""
            if body.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                // OCR stays bounded even for a large scanned document.
                guard scanned < 6 else { break }
                scanned += 1
                let bounds = page.bounds(for: .mediaBox)
                let scale = min(1, 1600 / max(1, max(bounds.width, bounds.height)))
                let size = CGSize(width: max(1, bounds.width * scale), height: max(1, bounds.height * scale))
                if let image = page.thumbnail(of: size, for: .mediaBox).cgImage { body = try recognize(image) }
            }
            visited += 1
            text += body + "\n"
            if text.utf8.count > limit { break }
        }
        var notes: [String] = []
        if scanned > 0 { notes.append("スキャン部分は端末内の文字認識で読み取ります。図や写真は解析しません。") }
        if visited < document.pageCount || text.utf8.count > limit {
            notes.append("全\(document.pageCount)ページのうち、最初の\(visited)ページを対象にします。")
        }
        return Result(text: GenerationSettings.prefix(text, byteLimit: limit), note: notes.isEmpty ? nil : notes.joined(separator: " "))
    }

    private static func recognize(_ image: CGImage) throws -> String {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.recognitionLanguages = ["ja-JP", "en-US"]
        request.usesLanguageCorrection = true
        try VNImageRequestHandler(cgImage: image).perform([request])
        return (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
    }

    static func word(_ url: URL, limit: Int) throws -> Result {
        let archive = try Archive(url: url, accessMode: .read)
        guard let entry = archive["word/document.xml"], entry.type == .file,
              entry.uncompressedSize <= 8_000_000 else { throw AttachmentStorage.ImportError.unreadable }
        var xml = Data()
        // Extract one known entry into memory. Never unpack arbitrary paths,
        // embedded files, macros or external relationships onto the device.
        _ = try archive.extract(entry, bufferSize: 16_384) { chunk in
            try Task.checkCancellation()
            guard xml.count + chunk.count <= 8_000_000 else { throw AttachmentStorage.ImportError.tooLarge }
            xml.append(chunk)
        }
        guard !String(decoding: xml, as: UTF8.self).contains("<!DOCTYPE") else { throw AttachmentStorage.ImportError.unreadable }
        let parser = XMLParser(data: xml)
        let reader = WordTextParser(limit: limit)
        parser.delegate = reader
        parser.shouldResolveExternalEntities = false
        guard parser.parse() || reader.truncated else { throw AttachmentStorage.ImportError.unreadable }
        return Result(text: GenerationSettings.prefix(reader.text, byteLimit: limit),
                      note: reader.truncated ? "Word本文の先頭部分を対象にします。図・表の配置や埋め込み画像は解析しません。" : "Word本文を読み込みました。図・表の配置や埋め込み画像は解析しません。")
    }

    private final class WordTextParser: NSObject, XMLParserDelegate {
        var text = "", truncated = false
        private var inText = false
        private let limit: Int
        init(limit: Int) { self.limit = limit }
        func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes: [String: String]) {
            let name = elementName.split(separator: ":").last.map(String.init) ?? elementName
            if name == "t" { inText = true }
            if name == "tab" { text += "\t" }
            if name == "br" { text += "\n" }
        }
        func parser(_ parser: XMLParser, foundCharacters string: String) {
            if inText { text += string }
            if text.utf8.count > limit { truncated = true; parser.abortParsing() }
        }
        func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
            let name = elementName.split(separator: ":").last.map(String.init) ?? elementName
            if name == "t" { inText = false }
            if name == "p" { text += "\n" }
        }
    }
}
