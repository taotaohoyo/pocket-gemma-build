#include <metal_stdlib>
using namespace metal;

// Pocket AI's Aurora Orb: the app icon's colours flowing and mixing inside
// a circle of light that breathes a little, with the colours spilling onto
// the background around it as a soft tinted shadow. Used as a SwiftUI fill
// (`Shader` as a ShapeStyle, AuroraOrbView.swift): `position` is in points
// inside the square canvas, and the colour returned is premultiplied.

namespace aurora {

// A lattice hash without sin(), so the noise has no seams or banding.
inline float hash(float2 cell) {
    uint2 q = uint2(int2(cell)) * uint2(1597334673u, 3812015801u);
    uint n = (q.x ^ q.y) * 1597334673u;
    return float(n) * (1.0f / 4294967296.0f);
}

inline float2 direction(float2 cell) {
    float angle = hash(cell) * 6.2831853f;
    return float2(cos(angle), sin(angle));
}

// Gradient noise, about -0.7...0.7, smooth across cells.
inline float noise(float2 p) {
    float2 cell = floor(p);
    float2 f = p - cell;
    float2 u = f * f * f * (f * (f * 6.0f - 15.0f) + 10.0f);
    float a = dot(direction(cell), f);
    float b = dot(direction(cell + float2(1.0f, 0.0f)), f - float2(1.0f, 0.0f));
    float c = dot(direction(cell + float2(0.0f, 1.0f)), f - float2(0.0f, 1.0f));
    float d = dot(direction(cell + float2(1.0f, 1.0f)), f - float2(1.0f, 1.0f));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Two octaves, the second turned so no lattice shows through. More detail
// than this reads as grain at this size.
inline float fbm(float2 p) {
    const float2x2 turn = float2x2(float2(0.80f, 0.60f), float2(-0.60f, 0.80f));
    return 0.5f * noise(p) + 0.25f * noise(turn * p * 2.02f + float2(3.1f, 1.7f));
}

// Turns the points around `centre` by an angle that fades with distance.
// A turn that depends only on the distance keeps every area, so colours
// curl into each other without folding or bunching into hard lines.
inline float2 eddy(float2 p, float2 centre, float turn) {
    float2 d = p - centre;
    float angle = turn * exp(-3.0f * dot(d, d));
    float c = cos(angle);
    float s = sin(angle);
    return centre + float2(c * d.x - s * d.y, s * d.x + c * d.y);
}

inline float glow(float2 p, float2 at, float spread) {
    return exp(-spread * distance_squared(p, at));
}

// A light's place: where the icon has that colour at t = 0, swinging
// slowly about it afterwards.
inline float2 sway(float t, float angle, float radius, float swing, float swingRate,
                   float wobble, float wobbleRate, float wobblePhase) {
    float a = angle + swing * sin(swingRate * t);
    float r = radius + wobble * sin(wobbleRate * t + wobblePhase);
    return r * float2(cos(a), sin(a));
}

// How far a colour sits from grey; what mixing takes and is given back.
inline float chroma(float3 c) {
    return length(c - dot(c, float3(0.2126f, 0.7152f, 0.0722f)));
}

}

// size: the canvas in points. time: seconds, never wrapped, so the motion
// has no loop seam. dark: 1 in dark mode, 0 in light mode.
[[ stitchable ]] half4 auroraOrb(float2 position, float2 size, float time, float dark) {
    float side = max(min(size.x, size.y), 1.0f);
    // The centre at 0 and the canvas's inscribed circle at 1, then scaled
    // so the light, tuned at 17pt, draws 14pt across from the centre.
    float2 p = (position - 0.5f * size) / (0.5f * side) * (17.0f / 14.0f);
    float r = length(p);
    if (r >= 1.2f) {
        return half4(0.0h);
    }
    float t = time;

    // A true circle whose radius breathes by 1.5% every 2.2 s.
    float breath = 0.015f * sin(t * 2.8559933f);
    float edge = 0.654f * (1.0f + breath);
    // Beyond the rim, the rim's colour in the same direction is used, so
    // the spill onto the background follows the colours inside.
    float2 q = r > edge ? p * (edge / r) : p;
    // The flow inside runs faster than the breathing.
    float ti = 1.6f * t;

    // The colours are stirred by three slow eddies that wander and turn back
    // and forth, then bent a little by noise so they are never too regular.
    // Nothing turns about the centre as a whole.
    const float stir = 1.1f;
    float2 w = q;
    w = aurora::eddy(w, float2(0.30f * sin(0.23f * ti + 0.5f), 0.28f * cos(0.19f * ti + 2.2f)), stir * sin(0.37f * ti + 0.9f));
    w = aurora::eddy(w, float2(0.32f * sin(0.17f * ti + 3.9f), 0.30f * cos(0.29f * ti + 5.1f)), stir * sin(0.29f * ti + 3.8f));
    w = aurora::eddy(w, float2(0.26f * sin(0.31f * ti + 1.7f), 0.27f * cos(0.13f * ti + 0.4f)), stir * sin(0.43f * ti + 5.6f));
    float2 drift = float2(0.045f, -0.035f) * ti;
    w += 0.18f * float2(aurora::fbm(w * 1.3f + drift),
                        aurora::fbm(w * 1.3f + float2(5.2f, 1.3f) - drift.yx));

    // Lights where the icon has its colours (y runs down): red at the top,
    // orange and yellow to the left, green at the bottom, blue to the right
    // and through the middle. Neighbours swing opposite ways at different
    // rates, so nothing reads as the whole turning.
    float2 redAt = aurora::sway(ti, -1.5708f, 0.40f, 0.32f, 0.19f, 0.05f, 0.27f, 0.8f);
    float2 orangeAt = aurora::sway(ti, -2.30f, 0.40f, -0.22f, 0.23f, 0.04f, 0.31f, 2.0f);
    float2 yellowAt = aurora::sway(ti, 3.1416f, 0.42f, 0.30f, 0.13f, 0.05f, 0.21f, 4.1f);
    float2 greenAt = aurora::sway(ti, 1.5708f, 0.40f, -0.30f, 0.17f, 0.05f, 0.29f, 1.3f);
    float2 blueAt = aurora::sway(ti, 0.0f, 0.36f, 0.34f, 0.11f, 0.06f, 0.23f, 5.0f);
    float2 centreAt = float2(0.10f * sin(0.37f * ti + 0.4f), 0.08f * cos(0.29f * ti + 1.9f));

    // The icon's own colours (AppIcon.png, the most vivid of each hue), a
    // touch brighter in dark mode so they carry on black.
    float3 red = mix(float3(0.89f, 0.36f, 0.31f), float3(0.94f, 0.40f, 0.34f), dark);
    float3 orange = mix(float3(0.945f, 0.67f, 0.157f), float3(0.97f, 0.70f, 0.20f), dark);
    float3 yellow = mix(float3(0.973f, 0.753f, 0.102f), float3(0.99f, 0.78f, 0.15f), dark);
    float3 green = mix(float3(0.125f, 0.67f, 0.365f), float3(0.16f, 0.74f, 0.41f), dark);
    float3 blue = mix(float3(0.114f, 0.498f, 0.96f), float3(0.18f, 0.55f, 1.00f), dark);

    // Each light reaches a little way, yellow and green a little further
    // and orange less; blue also fills the middle, as in the icon.
    const float spread = 12.0f;
    float redWeight = aurora::glow(w, redAt, spread);
    float orangeWeight = aurora::glow(w, orangeAt, 16.0f);
    float yellowWeight = aurora::glow(w, yellowAt, spread * 0.9f);
    float greenWeight = aurora::glow(w, greenAt, spread * 0.85f);
    float blueWeight = aurora::glow(w, blueAt, spread) + 0.55f * aurora::glow(w, centreAt, 2.5f) + 0.03f;
    float total = redWeight + orangeWeight + yellowWeight + greenWeight + blueWeight;
    float3 rgb = (red * redWeight + orange * orangeWeight + yellow * yellowWeight
                  + green * greenWeight + blue * blueWeight) / total;

    // Mixing in RGB greys the colours where they meet; give back most of
    // the chroma the lights had, so the seams stay coloured, not muddy.
    // Red and blue mix to violet, and the icon keeps that seam muted, so
    // most of the restoring is skipped where those two overlap.
    float want = (aurora::chroma(red) * redWeight + aurora::chroma(orange) * orangeWeight
                  + aurora::chroma(yellow) * yellowWeight + aurora::chroma(green) * greenWeight
                  + aurora::chroma(blue) * blueWeight) / total;
    float luma = dot(rgb, float3(0.2126f, 0.7152f, 0.0722f));
    float have = length(rgb - luma);
    float seam = 4.0f * redWeight * blueWeight / (total * total);
    float gain = 1.0f + 0.65f * (1.0f - 0.75f * seam) * (clamp(want / max(have, 1e-4f), 1.0f, 2.5f) - 1.0f);
    rgb = luma + (rgb - luma) * gain;

    // Thicker and thinner colour carried by the same eddies (darker only,
    // so nothing clips toward white), and a little darker toward the rim.
    float mist = 0.5f + 1.2f * aurora::fbm(w * 1.4f + float2(-0.05f, 0.04f) * ti);
    rgb *= mix(0.93f, 1.04f, mist);
    rgb *= 1.0f - 0.03f * smoothstep(0.7f * edge, edge, r);

    // 28pt across (14pt of the canvas's 26) with an edge about a point
    // wide. Around it the colours spill onto the background as a soft
    // tinted shadow, a little lower than centred, that fades out before
    // the canvas ends.
    float core = 1.0f - smoothstep(edge - 0.045f, edge, r);
    float beyond = max(length(p - float2(0.0f, 0.10f)) - edge, 0.0f);
    float spill = mix(0.28f, 0.34f, dark) * exp(-beyond / 0.22f) * (1.0f - smoothstep(0.85f, 1.2f, r));
    float alpha = core + (1.0f - core) * spill;

    rgb = clamp(rgb, 0.0f, 1.0f);
    return half4(half3(rgb * alpha), half(alpha));
}
