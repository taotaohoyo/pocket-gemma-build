#include <metal_stdlib>
using namespace metal;

// Pocket AI's Aurora Orb: coloured mist drifting and mixing inside a soft
// round of light whose edge breathes a little. Used as a SwiftUI fill
// (`Shader` as a ShapeStyle, AuroraOrbView.swift): `position` is in points
// inside the square canvas, and the colour returned is premultiplied.

namespace aurora {

// A lattice hash without sin(), so the noise has no seams or banding.
inline float hash(float2 cell) {
    uint2 q = uint2(int2(cell)) * uint2(1597334673u, 3812015801u);
    uint n = (q.x ^ q.y) * 1597334673u;
    return float(n) * (1.0f / 4294967296.0f);
}

inline float2 direction(float2 cell) {
    float angle = hash(cell) * 6.2831853f;
    return float2(cos(angle), sin(angle));
}

// Gradient noise, about -0.7...0.7, smooth across cells.
inline float noise(float2 p) {
    float2 cell = floor(p);
    float2 f = p - cell;
    float2 u = f * f * f * (f * (f * 6.0f - 15.0f) + 10.0f);
    float a = dot(direction(cell), f);
    float b = dot(direction(cell + float2(1.0f, 0.0f)), f - float2(1.0f, 0.0f));
    float c = dot(direction(cell + float2(0.0f, 1.0f)), f - float2(0.0f, 1.0f));
    float d = dot(direction(cell + float2(1.0f, 1.0f)), f - float2(1.0f, 1.0f));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Two octaves, the second turned so no lattice shows through. More detail
// than this reads as grain at 34pt.
inline float fbm(float2 p) {
    const float2x2 turn = float2x2(float2(0.80f, 0.60f), float2(-0.60f, 0.80f));
    return 0.5f * noise(p) + 0.25f * noise(turn * p * 2.02f + float2(3.1f, 1.7f));
}

// Turns the points around `centre` by an angle that fades with distance.
// A turn that depends only on the distance keeps every area, so colours
// curl into each other without folding or bunching into hard lines.
inline float2 eddy(float2 p, float2 centre, float turn) {
    float2 d = p - centre;
    float angle = turn * exp(-3.0f * dot(d, d));
    float c = cos(angle);
    float s = sin(angle);
    return centre + float2(c * d.x - s * d.y, s * d.x + c * d.y);
}

inline float glow(float2 p, float2 at, float spread) {
    return exp(-spread * distance_squared(p, at));
}

}

// size: the canvas in points. time: seconds, never wrapped, so the motion
// has no loop seam. dark: 1 in dark mode, 0 in light mode.
[[ stitchable ]] half4 auroraOrb(float2 position, float2 size, float time, float dark) {
    float side = max(min(size.x, size.y), 1.0f);
    // The centre at 0 and the canvas's inscribed circle at 1.
    float2 p = (position - 0.5f * size) / (0.5f * side);
    float r = length(p);
    if (r >= 1.0f) {
        return half4(0.0h);
    }
    float t = time;

    // The mist is stirred by three slow eddies that wander and turn back
    // and forth, then bent a little by noise so it is never too regular.
    // Nothing turns about the centre as a whole.
    const float stir = 1.1f;
    float2 w = p;
    w = aurora::eddy(w, float2(0.30f * sin(0.23f * t + 0.5f), 0.28f * cos(0.19f * t + 2.2f)), stir * sin(0.37f * t + 0.9f));
    w = aurora::eddy(w, float2(0.32f * sin(0.17f * t + 3.9f), 0.30f * cos(0.29f * t + 5.1f)), stir * sin(0.29f * t + 3.8f));
    w = aurora::eddy(w, float2(0.26f * sin(0.31f * t + 1.7f), 0.27f * cos(0.13f * t + 0.4f)), stir * sin(0.43f * t + 5.6f));
    float2 drift = float2(0.045f, -0.035f) * t;
    w += 0.18f * float2(aurora::fbm(w * 1.3f + drift),
                        aurora::fbm(w * 1.3f + float2(5.2f, 1.3f) - drift.yx));

    // Coloured lights. Rose and green sway on opposite sides of an axis that
    // swings back and forth; blue stays near the middle and violet off to
    // one side, so the way from rose to green runs through blue, not grey.
    float axis = 2.4f + 1.25f * sin(0.21f * t) + 0.55f * sin(0.13f * t + 1.7f);
    float apart = 0.35f * sin(0.17f * t);
    float roseRadius = 0.34f + 0.05f * sin(0.27f * t);
    float greenRadius = 0.33f + 0.05f * sin(0.23f * t + 2.0f);
    float2 roseAt = roseRadius * float2(cos(axis), sin(axis));
    float2 greenAt = -greenRadius * float2(cos(axis + apart), sin(axis + apart));
    float2 blueAt = 0.14f * float2(sin(0.37f * t + 0.4f), cos(0.29f * t + 1.9f));
    float beside = axis + 1.5708f + 0.6f * sin(0.19f * t + 0.8f);
    float2 violetAt = 0.28f * float2(cos(beside), sin(beside));
    float2 glintAt = 0.22f * float2(sin(0.31f * t + 0.7f), cos(0.23f * t + 2.1f));

    // Hues of the app icon, deeper on a light background so the light does
    // not wash out, brighter on a dark one. Gold is only a highlight.
    float3 blue = mix(float3(0.12f, 0.45f, 0.96f), float3(0.22f, 0.54f, 1.00f), dark);
    float3 rose = mix(float3(0.95f, 0.30f, 0.52f), float3(1.00f, 0.40f, 0.62f), dark);
    float3 teal = mix(float3(0.05f, 0.68f, 0.80f), float3(0.20f, 0.85f, 0.93f), dark);
    float3 emerald = mix(float3(0.10f, 0.70f, 0.45f), float3(0.28f, 0.88f, 0.60f), dark);
    float3 violet = mix(float3(0.50f, 0.33f, 0.95f), float3(0.62f, 0.44f, 1.00f), dark);
    float3 gold = mix(float3(0.99f, 0.82f, 0.52f), float3(1.00f, 0.90f, 0.68f), dark);
    float3 green = mix(teal, emerald, 0.5f + 0.5f * sin(0.11f * t + 1.0f));
    float3 medium = mix(blue, violet, 0.25f);

    const float spread = 5.5f;
    float blueWeight = aurora::glow(w, blueAt, spread);
    float roseWeight = aurora::glow(w, roseAt, spread);
    float greenWeight = aurora::glow(w, greenAt, spread);
    float violetWeight = aurora::glow(w, violetAt, spread);
    // A blue-violet medium fills the gaps between the lights.
    const float base = 0.22f;
    float3 rgb = (blue * blueWeight + medium * base + rose * roseWeight + green * greenWeight + violet * violetWeight)
        / (blueWeight + roseWeight + greenWeight + violetWeight + base);
    // Mixing in RGB greys the colours a little; give back their saturation.
    float luma = dot(rgb, float3(0.2126f, 0.7152f, 0.0722f));
    rgb = luma + (rgb - luma) * mix(1.3f, 1.15f, dark);

    // Thicker and thinner mist carried by the same eddies, a pale gold
    // glint drifting near the middle, and a soft light at the centre.
    float mist = 0.5f + 1.2f * aurora::fbm(w * 1.4f + float2(-0.05f, 0.04f) * t);
    rgb *= mix(0.93f, 1.07f, mist);
    float glint = aurora::glow(w, glintAt, 7.0f) * (1.0f - smoothstep(0.2f, 0.8f, r));
    rgb = mix(rgb, gold, 0.22f * glint);
    rgb += mix(0.04f, 0.10f, dark) * (1.0f - smoothstep(0.0f, 0.55f, r));

    // The edge breathes every 2.2 s and its outline shifts slowly; the
    // radius changes by a few percent at most.
    float theta = atan2(p.y, p.x);
    float ripple = 0.018f * sin(2.0f * theta + 0.41f * t + 0.3f)
        + 0.013f * sin(3.0f * theta - 0.33f * t + 1.7f)
        + 0.008f * sin(5.0f * theta + 0.52f * t + 4.1f);
    float breath = 0.015f * sin(t * 2.8559933f);
    float edge = 0.86f * (1.0f + ripple + breath);

    // A soft round with no rim, frayed a little by the mist near its edge,
    // and a faint halo that fades out before the canvas ends.
    float core = 1.0f - smoothstep(0.56f * edge, edge, r);
    float rim = smoothstep(0.45f * edge, edge, r);
    core = clamp(core * mix(1.0f, 0.82f + 0.36f * mist, rim), 0.0f, 1.0f);
    float halo = mix(0.08f, 0.14f, dark) * (1.0f - smoothstep(0.60f * edge, 1.12f * edge, r));
    float alpha = core * mix(0.92f, 0.95f, dark) + (1.0f - core) * halo;
    alpha *= 1.0f - smoothstep(0.90f, 1.0f, r);

    rgb = clamp(rgb, 0.0f, 1.0f);
    return half4(half3(rgb * alpha), half(alpha));
}
