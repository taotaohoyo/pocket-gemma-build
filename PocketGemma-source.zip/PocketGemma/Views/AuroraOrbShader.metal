#include <metal_stdlib>
using namespace metal;

// Pocket AI's Aurora Orb: the flower's golds flowing and mixing inside
// a circle of light, with the colours spilling onto the background around
// it as a soft tinted shadow. The whole light is drawn at `scale` (1 = full
// size), which AuroraOrbView breathes and shrinks away. Used as a SwiftUI
// fill (`Shader` as a ShapeStyle): `position` is in points inside the
// square canvas, and the colour returned is premultiplied.

namespace aurora {

// A lattice hash without sin(), so the noise has no seams or banding.
inline float hash(float2 cell) {
    uint2 q = uint2(int2(cell)) * uint2(1597334673u, 3812015801u);
    uint n = (q.x ^ q.y) * 1597334673u;
    return float(n) * (1.0f / 4294967296.0f);
}

inline float2 direction(float2 cell) {
    float angle = hash(cell) * 6.2831853f;
    return float2(cos(angle), sin(angle));
}

// Gradient noise, about -0.7...0.7, smooth across cells.
inline float noise(float2 p) {
    float2 cell = floor(p);
    float2 f = p - cell;
    float2 u = f * f * f * (f * (f * 6.0f - 15.0f) + 10.0f);
    float a = dot(direction(cell), f);
    float b = dot(direction(cell + float2(1.0f, 0.0f)), f - float2(1.0f, 0.0f));
    float c = dot(direction(cell + float2(0.0f, 1.0f)), f - float2(0.0f, 1.0f));
    float d = dot(direction(cell + float2(1.0f, 1.0f)), f - float2(1.0f, 1.0f));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Two octaves, the second turned so no lattice shows through. More detail
// than this reads as grain at this size.
inline float fbm(float2 p) {
    const float2x2 turn = float2x2(float2(0.80f, 0.60f), float2(-0.60f, 0.80f));
    return 0.5f * noise(p) + 0.25f * noise(turn * p * 2.02f + float2(3.1f, 1.7f));
}

// Turns the points around `centre` by an angle that fades with distance.
// A turn that depends only on the distance keeps every area, so colours
// curl into each other without folding or bunching into hard lines.
inline float2 eddy(float2 p, float2 centre, float turn) {
    float2 d = p - centre;
    float angle = turn * exp(-3.0f * dot(d, d));
    float c = cos(angle);
    float s = sin(angle);
    return centre + float2(c * d.x - s * d.y, s * d.x + c * d.y);
}

inline float glow(float2 p, float2 at, float spread) {
    return exp(-spread * distance_squared(p, at));
}

// A light's place: where the icon has that colour at t = 0, swinging
// slowly about it afterwards.
inline float2 sway(float t, float angle, float radius, float swing, float swingRate,
                   float wobble, float wobbleRate, float wobblePhase) {
    float a = angle + swing * sin(swingRate * t);
    float r = radius + wobble * sin(wobbleRate * t + wobblePhase);
    return r * float2(cos(a), sin(a));
}

// How far a colour sits from grey; what mixing takes and is given back.
inline float chroma(float3 c) {
    return length(c - dot(c, float3(0.2126f, 0.7152f, 0.0722f)));
}

// A true circle; the whole light breathes by its size, not its edge.
constant float edge = 0.654f;

// The light's colour at p (the centre at 0, the light's rim at `edge`),
// r = length(p): inside, the icon's colours stirred by the flow; beyond
// the rim, the rim's colour in the same direction, for the spill.
inline float3 colour(float2 p, float r, float t, float dark) {
    // Beyond the rim, the rim's colour in the same direction is used, so
    // the spill onto the background follows the colours inside.
    float2 q = r > edge ? p * (edge / r) : p;
    // The flow inside runs faster than the breathing.
    float ti = 1.6f * t;

    // The colours are stirred by three slow eddies that wander and turn back
    // and forth, then bent a little by noise so they are never too regular.
    // Nothing turns about the centre as a whole.
    const float stir = 1.1f;
    float2 w = q;
    w = aurora::eddy(w, float2(0.30f * sin(0.23f * ti + 0.5f), 0.28f * cos(0.19f * ti + 2.2f)), stir * sin(0.37f * ti + 0.9f));
    w = aurora::eddy(w, float2(0.32f * sin(0.17f * ti + 3.9f), 0.30f * cos(0.29f * ti + 5.1f)), stir * sin(0.29f * ti + 3.8f));
    w = aurora::eddy(w, float2(0.26f * sin(0.31f * ti + 1.7f), 0.27f * cos(0.13f * ti + 0.4f)), stir * sin(0.43f * ti + 5.6f));
    float2 drift = float2(0.045f, -0.035f) * ti;
    w += 0.18f * float2(aurora::fbm(w * 1.3f + drift),
                        aurora::fbm(w * 1.3f + float2(5.2f, 1.3f) - drift.yx));

    // Lights where the icon has its colours (y runs down): red at the top,
    // orange and yellow to the left, green at the bottom, blue to the right
    // and through the middle. Neighbours swing opposite ways at different
    // rates, so nothing reads as the whole turning.
    float2 redAt = aurora::sway(ti, -1.5708f, 0.40f, 0.32f, 0.19f, 0.05f, 0.27f, 0.8f);
    float2 orangeAt = aurora::sway(ti, -2.30f, 0.40f, -0.22f, 0.23f, 0.04f, 0.31f, 2.0f);
    float2 yellowAt = aurora::sway(ti, 3.1416f, 0.42f, 0.30f, 0.13f, 0.05f, 0.21f, 4.1f);
    float2 greenAt = aurora::sway(ti, 1.5708f, 0.40f, -0.30f, 0.17f, 0.05f, 0.29f, 1.3f);
    float2 blueAt = aurora::sway(ti, 0.0f, 0.36f, 0.34f, 0.11f, 0.06f, 0.23f, 5.0f);
    float2 centreAt = float2(0.10f * sin(0.37f * ti + 0.4f), 0.08f * cos(0.29f * ti + 1.9f));

    // The flower's golds (brand 2026-10-27; the rainbow icon's colours
    // before), named by the places the rainbow had: amber at the top, honey
    // and the petals' light yellow to the sides, the brand yellow below and
    // a gold through the middle, as the flower is deepest at its centre. A
    // touch lighter in dark mode so they glow on charcoal; the light yellow
    // stays deeper than the paper's cream so the light keeps its edge.
    float3 red = mix(float3(0.91f, 0.52f, 0.12f), float3(0.95f, 0.58f, 0.18f), dark);
    float3 orange = mix(float3(0.95f, 0.66f, 0.13f), float3(0.97f, 0.70f, 0.20f), dark);
    float3 yellow = mix(float3(0.99f, 0.87f, 0.52f), float3(1.00f, 0.91f, 0.66f), dark);
    float3 green = mix(float3(0.98f, 0.80f, 0.24f), float3(0.99f, 0.82f, 0.30f), dark);
    float3 blue = mix(float3(0.96f, 0.73f, 0.17f), float3(0.98f, 0.77f, 0.24f), dark);

    // Each light reaches a little way, yellow and green a little further
    // and orange less; blue also fills the middle, as in the icon.
    const float spread = 12.0f;
    float redWeight = aurora::glow(w, redAt, spread);
    float orangeWeight = aurora::glow(w, orangeAt, 16.0f);
    float yellowWeight = aurora::glow(w, yellowAt, spread * 0.9f);
    float greenWeight = aurora::glow(w, greenAt, spread * 0.85f);
    float blueWeight = aurora::glow(w, blueAt, spread) + 0.55f * aurora::glow(w, centreAt, 2.5f) + 0.03f;
    float total = redWeight + orangeWeight + yellowWeight + greenWeight + blueWeight;
    float3 rgb = (red * redWeight + orange * orangeWeight + yellow * yellowWeight
                  + green * greenWeight + blue * blueWeight) / total;

    // Mixing in RGB greys the colours where they meet; give back most of
    // the chroma the lights had, so the seams stay coloured, not muddy.
    // Red and blue mix to violet, and the icon keeps that seam muted, so
    // most of the restoring is skipped where those two overlap.
    float want = (aurora::chroma(red) * redWeight + aurora::chroma(orange) * orangeWeight
                  + aurora::chroma(yellow) * yellowWeight + aurora::chroma(green) * greenWeight
                  + aurora::chroma(blue) * blueWeight) / total;
    float luma = dot(rgb, float3(0.2126f, 0.7152f, 0.0722f));
    float have = length(rgb - luma);
    float seam = 4.0f * redWeight * blueWeight / (total * total);
    float gain = 1.0f + 0.65f * (1.0f - 0.75f * seam) * (clamp(want / max(have, 1e-4f), 1.0f, 2.5f) - 1.0f);
    rgb = luma + (rgb - luma) * gain;

    // Thicker and thinner colour carried by the same eddies (darker only,
    // so nothing clips toward white), and a little darker toward the rim.
    float mist = 0.5f + 1.2f * aurora::fbm(w * 1.4f + float2(-0.05f, 0.04f) * ti);
    rgb *= mix(0.93f, 1.04f, mist);
    rgb *= 1.0f - 0.03f * smoothstep(0.7f * edge, edge, r);

    return rgb;
}

// How much of the colour spills onto the background around the light: a
// soft tinted shadow, a little lower than centred, that fades out before
// the canvas ends. glow above 1 makes it stronger and reach further, as
// the welcome's light opens (Aurora Bloom).
inline float spill(float2 p, float r, float dark, float glow) {
    float beyond = max(length(p - float2(0.0f, 0.10f)) - edge, 0.0f);
    return glow * mix(0.28f, 0.34f, dark) * exp(-beyond / (0.22f * glow)) * (1.0f - smoothstep(0.85f, 1.2f, r));
}

inline float spill(float2 p, float r, float dark) {
    return spill(p, r, dark, 1.0f);
}

// The halo of the reply's light (auroraField, auroraReplyOrb): a thin ring
// of light just beyond the rim that ties the field to the orb, `d` points
// from the light's centre, `radius` the light's radius now (points),
// `breath` the field's breath (0 at its low, 1 at its top), `halo` its
// share (it goes as the orb leaves) and `bloom` the field coming in.
inline float halo(float d, float radius, float dark, float breath, float halo, float bloom) {
    float reach = mix(mix(2.5f, 4.5f, breath), mix(3.0f, 5.0f, breath), dark);
    float ring = mix(mix(0.14f, 0.20f, breath), mix(0.22f, 0.30f, breath), dark) * halo * bloom;
    float beyond = max(d - radius, 0.0f);
    return ring * exp(-beyond / reach) * (1.0f - smoothstep(22.0f, 36.0f, d));
}

// The colour the field and its halo lay on the page at `d` points from
// the light's centre, `rim` the rim's colour in that direction: the rim's
// colour near the light, the outer colour further out. On paper a pale
// cream yellow, so the light lifts the page rather than tinting it; on
// charcoal a soft gold, so its faint edge stays warm light and not a
// beige-grey (1.1.0 (300)). It is drawn over the chat's own background
// only, so it blends against that colour here and is composited
// normally: on paper the light's colour at the paper's lightness (warm
// light, not a stain), on charcoal light added as by a screen (lifted,
// never muddy).
inline float3 fieldLit(float3 rim, float d, float radius, float dark) {
    const float3 luma = float3(0.2126f, 0.7152f, 0.0722f);
    float3 outer = mix(float3(1.00f, 0.92f, 0.68f), float3(1.00f, 0.86f, 0.58f), dark);
    float away = smoothstep(0.0f, 1.0f, (d - radius) / mix(46.0f, 30.0f, dark));
    float3 colour = mix(rim, rim * 0.45f + outer * 0.55f, away);
    if (dark > 0.5f) {
        // Screen over the chat's charcoal (Theme.chatBackground, 0x171512).
        float3 ground = float3(0.0902f, 0.0824f, 0.0706f);
        return colour + ground - colour * ground;
    }
    // The light's colour at the paper's lightness (0xFAF7F1), mostly:
    // nearer the paper's own lightness than in 1.1.0 (299) (0.7), so it
    // reads as light on the page and never as a stain.
    float paper = dot(float3(0.9804f, 0.9686f, 0.9451f), luma);
    return clamp(colour + 0.88f * (paper - dot(colour, luma)), 0.0f, 1.0f);
}

// How far the field reaches in the direction `toward` (a unit vector, y
// down), as a share of its spread: a little further where the rim is
// lighter, so the field's edge moves with the colours inside. `rim` is the
// rim's colour in that direction. The lightness is taken round about the
// direction, from the rim 20 degrees either side as well (weights 1, 2,
// 1), and eased into its limits (±15%) rather than clipped at them, as the
// design sample did (design/aurora-orb-sample, design2.py: the rim's
// colours smoothed round the light). Until 1.1.0 (304) it was this
// direction's alone, clipped (`soft` 0, kept for the UI checks): where the
// rim's lightness changed, the field's edge turned a corner, and it read
// as an angular light with a flat top.
inline float reachFlow(float2 toward, float3 rim, float time, float dark, float soft) {
    const float3 luma = float3(0.2126f, 0.7152f, 0.0722f);
    float base = mix(0.709f, 0.745f, dark);
    if (soft < 0.5f) {
        return 1.0f + 0.10f * clamp((dot(rim, luma) - base) / 0.05f, -1.5f, 1.5f);
    }
    // cos and sin of 20 degrees.
    const float c = 0.9396926f;
    const float s = 0.3420201f;
    float2 one = float2(c * toward.x - s * toward.y, s * toward.x + c * toward.y);
    float2 other = float2(c * toward.x + s * toward.y, c * toward.y - s * toward.x);
    float3 a = clamp(colour(one * edge, edge, time, dark), 0.0f, 1.0f);
    float3 b = clamp(colour(other * edge, edge, time, dark), 0.0f, 1.0f);
    float lightness = 0.25f * (dot(a, luma) + 2.0f * dot(rim, luma) + dot(b, luma));
    float u = (lightness - base) / 0.05f;
    return 1.0f + 0.15f * tanh(u / 1.5f);
}

}

// size: the canvas in points. time: seconds, never wrapped, so the motion
// has no loop seam. dark: 1 in dark mode, 0 in light mode. scale: the
// light's size, 1 = full (12pt from the centre), smaller as it breathes
// out or leaves; the shadow around it shrinks with it.
[[ stitchable ]] half4 auroraOrb(float2 position, float2 size, float time, float dark, float scale) {
    float side = max(min(size.x, size.y), 1.0f);
    // The centre at 0 and the canvas's inscribed circle at 1, then scaled
    // so the light, tuned at 17pt, draws 12pt from the centre at full size.
    float grow = (17.0f / 12.0f) / max(scale, 0.001f);
    float2 p = (position - 0.5f * size) / (0.5f * side) * grow;
    float r = length(p);
    if (r >= 1.2f) {
        return half4(0.0h);
    }
    float3 rgb = aurora::colour(p, r, time, dark);

    // 24pt across at full size (12pt of the canvas's 26) with an edge
    // about a point wide, and the colours' spill around it.
    float core = 1.0f - smoothstep(aurora::edge - 0.045f, aurora::edge, r);
    float alpha = core + (1.0f - core) * aurora::spill(p, r, dark);

    rgb = clamp(rgb, 0.0f, 1.0f);
    return half4(half3(rgb * alpha), half(alpha));
}

// The welcome screen's large light (OnboardingView's WelcomeOrb): the same
// light and spill as auroraOrb with a sharper outline. auroraOrb's edge is
// a share of the light, about a point wide at the chat's 24pt but 4.5pt at
// the welcome's 129pt, where it blurs the light into its spill. Here the
// edge is a point wide at any size, while the light opens and breathes,
// and lies where the soft edge was half-way, so the light keeps its size.
// glow: the spill, 1 = as auroraOrb's, more as the light opens.
[[ stitchable ]] half4 auroraWelcomeOrb(float2 position, float2 size, float time, float dark, float scale, float glow) {
    float side = max(min(size.x, size.y), 1.0f);
    float grow = (17.0f / 12.0f) / max(scale, 0.001f);
    // A point on the screen in the light's units.
    float onePoint = grow / (0.5f * side);
    float2 p = (position - 0.5f * size) * onePoint;
    float r = length(p);
    if (r >= 1.2f) {
        return half4(0.0h);
    }
    float3 rgb = aurora::colour(p, r, time, dark);

    float rim = aurora::edge - 0.0225f;
    float core = 1.0f - smoothstep(rim - 0.5f * onePoint, rim + 0.5f * onePoint, r);
    float alpha = core + (1.0f - core) * aurora::spill(p, r, dark, glow);

    rgb = clamp(rgb, 0.0f, 1.0f);
    return half4(half3(rgb * alpha), half(alpha));
}

// The light's field (光の面, 2026-11-19): a broad, soft light behind the
// reply's orb, as if its golds spread over the page round it. One smooth
// field, brightest at the orb and fading into a long, airy tail; wider
// along the line than tall, shorter upward (toward what was said before)
// than downward (where the reply is written). Near the orb it takes the
// rim's colour in each direction, so it moves with the colours inside;
// further out it melts into the petals' pale yellow on paper and a soft
// cream on charcoal. A thin halo just beyond the rim ties it to the orb:
// since 1.1.0 (304) drawn with the orb (auroraReplyOrb, `halo` 0 here), at
// full size and on the orb's clock; the same light either way.
//
// size: the canvas in points. centre: the light's centre in the canvas.
// unit: points per canvas point (the field is drawn small and scaled up,
// as it has no detail). time: the orb's time, for its colours. dark: 1 in
// dark mode. breath: 0 at the breath's low, 1 at its top (a beat behind
// the orb's). gather: 1 while the model thinks, then the orb's own shrink
// (1 to 0) as the reply begins, so the field closes with it. radius: the
// light's radius now (points). halo: the halo's share (fades as the orb
// leaves; 0 where the orb draws it). bloom: 0 to 1 as it comes in. soft:
// 1 to take the field's reach from the rim's lightness round about each
// direction (aurora::reachFlow, 1.1.0 (304)), 0 for 303's.
[[ stitchable ]] half4 auroraField(float2 position, float2 size, float2 centre, float unit, float time, float dark,
                                   float breath, float gather, float radius, float halo, float bloom, float soft) {
    const float wide = 1.28f;
    const float up = 0.80f;
    const float down = 1.10f;
    const float end = 118.0f;
    // The share of the longer, softer tail (the air round the light).
    // Shorter on charcoal, where a long faint tail read as a grey-brown
    // haze rather than light (1.1.0 (300)).
    float tail = mix(0.28f, 0.18f, dark);
    float2 d2 = (position - centre) * unit;
    float d = length(d2);
    float vert = d2.y < 0.0f ? up : down;
    float e = length(float2(d2.x / wide, d2.y / vert));

    float spread = mix(mix(31.0f, 36.0f, breath), mix(28.0f, 33.0f, breath), dark) * (0.30f + 0.70f * gather);
    float peak = mix(mix(0.27f, 0.34f, breath), mix(0.30f, 0.37f, breath), dark) * pow(max(gather, 0.0f), 0.7f) * bloom;
    float haloAlpha = aurora::halo(d, radius, dark, breath, halo, bloom);
    // The most the field can be here (its edge flowing outward), so the
    // colours are only worked out where there is light.
    float window = 1.0f - smoothstep(0.62f * end, end, e);
    float2 widest = float2(spread * wide * 1.15f, spread * vert * 1.15f);
    float q0 = dot(d2 / widest, d2 / widest);
    float most = peak * ((1.0f - tail) * exp(-0.5f * q0) + tail * exp(-sqrt(q0) * 1.15f)) * window;
    if (most < 0.0015f && haloAlpha < 0.0015f) {
        return half4(0.0h);
    }

    // The rim's colour in this direction (y runs down, as in the orb).
    float2 toward = d > 0.001f ? d2 / d : float2(1.0f, 0.0f);
    float3 rim = clamp(aurora::colour(toward * aurora::edge, aurora::edge, time, dark), 0.0f, 1.0f);
    float flow = aurora::reachFlow(toward, rim, time, dark, soft);
    float2 reachOf = float2(spread * wide * flow, spread * vert * flow);
    float q = dot(d2 / reachOf, d2 / reachOf);
    float field = peak * ((1.0f - tail) * exp(-0.5f * q) + tail * exp(-sqrt(q) * 1.15f)) * window;
    float alpha = 1.0f - (1.0f - field) * (1.0f - haloAlpha);
    float3 lit = aurora::fieldLit(rim, d, radius, dark);
    // A touch of noise, a step of 8-bit colour, so the long gradient has
    // no bands.
    float grain = (aurora::hash(floor(position * 3.0f)) - 0.5f) / 255.0f;
    alpha = clamp(alpha + grain, 0.0f, 1.0f);
    return half4(half3(lit * alpha), half(alpha));
}

// The reply's orb with its field's halo under it (1.1.0 (304)), drawn at
// full size on the orb's clock: what auroraOrb draws, over what
// auroraField drew round it until 303 (its halo, at a third of the size
// and on the field's slower clock). The same light: the halo in the
// field's colour, the orb over it. size: the canvas in points (wider than
// the orb's 52, for the halo's 36pt reach), the light at its centre.
// time, dark, scale: as auroraOrb's. opacity: the orb's own (it fades at
// the end of its shrink; the halo has gone by then). breath, halo, bloom:
// as the field's.
[[ stitchable ]] half4 auroraReplyOrb(float2 position, float2 size, float time, float dark, float scale,
                                      float opacity, float breath, float halo, float bloom) {
    // The orb's own canvas (AuroraOrbView.canvas): its light is laid out
    // in it, as auroraOrb's.
    const float side = 52.0f;
    float2 offset = position - 0.5f * size;
    float d = length(offset);
    float radius = 12.0f * scale;
    float haloAlpha = aurora::halo(d, radius, dark, breath, halo, bloom);
    float grow = (17.0f / 12.0f) / max(scale, 0.001f);
    float2 p = offset / (0.5f * side) * grow;
    float r = length(p);
    if (r >= 1.2f && haloAlpha < 0.0015f) {
        return half4(0.0h);
    }
    // Beyond the rim, colour() gives the rim's colour in that direction:
    // the orb's spill and the halo both take it.
    float3 rgb = clamp(aurora::colour(p, r, time, dark), 0.0f, 1.0f);
    float core = r >= 1.2f ? 0.0f : 1.0f - smoothstep(aurora::edge - 0.045f, aurora::edge, r);
    float alpha = (r >= 1.2f ? 0.0f : core + (1.0f - core) * aurora::spill(p, r, dark)) * opacity;
    if (alpha >= 1.0f || haloAlpha < 0.0015f) {
        return half4(half3(rgb * alpha), half(alpha));
    }
    float3 rim = rgb;
    if (r <= aurora::edge) {
        // Inside the rim's soft edge: the rim's colour in this direction.
        float2 toward = r > 0.0001f ? p / r : float2(1.0f, 0.0f);
        rim = clamp(aurora::colour(toward * aurora::edge, aurora::edge, time, dark), 0.0f, 1.0f);
    }
    float3 lit = aurora::fieldLit(rim, d, radius, dark);
    float3 premultiplied = rgb * alpha + (1.0f - alpha) * lit * haloAlpha;
    return half4(half3(premultiplied), half(alpha + (1.0f - alpha) * haloAlpha));
}
