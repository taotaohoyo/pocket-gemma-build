import SwiftUI
import PocketCore

/// モデル管理's facts on each model card (1.1.0 (225), fielua-reports
/// Issue #4), in place of the two gauges, whose 「重さ」 testers took for
/// the download and whose bars read either way: four quiet rows in words
/// (回答の速さ, 端末への負担, 必要メモリ, 保存容量) and 詳細 with what the
/// words rest on. No bars, colours or dots. That the words are estimates
/// is said once, in ModelPageIntro (each card's own line until 1.1.0 (227)).
struct ModelFacts: View {
    let spec: ModelSpec
    let fit: ModelFit
    let device: DeviceCapacity
    /// The file name to import, in 詳細, while the model is not saved
    /// (its own 「取り込むファイル名」 until 1.1.0 (225)).
    let showsFileName: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: FieluaSpace.xs) {
            VStack(spacing: 6) {
                row(String(localized: "回答の速さ"), fit.speedLabel, id: "speed")
                row(DeviceBurden.title(isPad: device.isPad), fit.burden.label, id: "burden")
                row(String(localized: "必要メモリ（目安）"), gigabytes(fit.estimatedMemoryBytes), id: "memory")
                row(String(localized: "保存容量"), spec.sizeLabel, id: "storage")
            }
            // Its chevron in the label's grey, not the ink (1.1.0 (227)).
            DisclosureGroup("詳細") { details.padding(.top, 6) }
                .font(.caption).foregroundStyle(.secondary).tint(Theme.icon)
                .accessibilityIdentifier("model-details-\(spec.id)")
        }
    }

    /// A name on the left, its word on the right, as in iOS's own lists.
    private func row(_ title: String, _ value: String, id: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: FieluaSpace.s) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 0)
            Text(value).foregroundStyle(.primary).multilineTextAlignment(.trailing)
        }
        .font(.footnote)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("model-\(id)-\(spec.id)")
    }

    private var details: some View {
        VStack(alignment: .leading, spacing: 10) {
            detail("回答の速さの根拠", fit.speed?.basis ?? SpeedEvidence.noneBasis)
            detail("負担の決め方", burdenBasis)
            detail("この端末で使えるメモリの目安", gigabytes(fit.deviceMemoryBudgetBytes))
            if showsFileName {
                detail("取り込むファイル名", spec.fileName).textSelection(.enabled)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func detail(_ title: LocalizedStringKey, _ text: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).fontWeight(.semibold)
            Text(text).fixedSize(horizontal: false, vertical: true)
        }
        .font(.caption).foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
    }

    /// The estimate's share of this device's memory, and the step up for a
    /// model that works on the CPU with its weights held (DeviceBurden).
    private var burdenBasis: String {
        let memory = String(format: "%.0f GB", Double(device.memoryBytes) / 1_000_000_000)
        let percent = Int((fit.memoryShare * 100).rounded())
        return Sentences.join([
            String(localized: "必要メモリが、この端末のメモリ\(memory)の約\(percent)%にあたります。"),
            spec.capabilities.locksCPUWeights
                ? String(localized: "CPUで動き、読み込んだモデルをメモリに置いたままにするため、一段階上にしています。") : ""
        ])
    }

    private func gigabytes(_ bytes: Double) -> String { String(format: "%.1f GB", bytes / 1_000_000_000) }
}

/// モデル管理's first card, as 設定's own pages open with one (the user,
/// 1.1.0 (227)): what the page is for and what the cards' words rest on,
/// said once here instead of under every card. The page's name is in the
/// bar already, so the card holds the page's symbol (its row's on 設定)
/// and the words. Not the flower: the mark stays in its six places.
struct ModelPageIntro: View {
    var body: some View {
        VStack(alignment: .leading, spacing: FieluaSpace.s) {
            Image(systemName: "square.stack.3d.up")
                .font(.system(size: 26, weight: .regular))
                .foregroundStyle(Theme.icon)
                .frame(width: 52, height: 52)
                .background(Theme.ink.opacity(0.06),
                            in: RoundedRectangle(cornerRadius: FieluaRadius.medium, style: .continuous))
                .accessibilityHidden(true)
            Text("ここでは、モデルのダウンロードや削除を管理します。端末への負担は、お使いの端末のメモリから計算しています。回答の速さと必要メモリは目安で、端末や質問によって変わります。")
                .font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(FieluaSpace.l)
        .frame(maxWidth: .infinity, alignment: .leading)
        .fieluaCard()
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("model-page-intro")
    }
}
