import SwiftUI
import PocketCore

/// モデル管理's facts on each model card (1.1.0 (225), fielua-reports
/// Issue #4), in place of the two gauges, whose 「重さ」 testers took for
/// the download and whose bars read either way: four quiet rows in words
/// (回答の速さ, 端末への負担, 必要メモリ, 保存容量) and 詳細 with what the
/// words rest on. No bars, colours or dots. That the words are estimates
/// is said once, above the cards (each card's own line until 1.1.0 (227),
/// the page's first card until 1.1.0 (231)).
struct ModelFacts: View {
    let spec: ModelSpec
    let fit: ModelFit
    let device: DeviceCapacity
    /// The file name to import, in 詳細, while the model is not saved
    /// (its own 「取り込むファイル名」 until 1.1.0 (225)).
    let showsFileName: Bool
    @State private var showsDetails = false

    var body: some View {
        VStack(alignment: .leading, spacing: FieluaSpace.xs) {
            VStack(spacing: 6) {
                row(String(localized: "回答の速さ"), fit.speedLabel, id: "speed")
                row(DeviceBurden.title(isPad: device.isPad), fit.burden.label, id: "burden")
                row(String(localized: "必要メモリ（目安）"), gigabytes(fit.estimatedMemoryBytes), id: "memory")
                row(String(localized: "保存容量"), spec.sizeLabel, id: "storage")
            }
            // The shared line (FieluaDisclosure, 1.1.0 (263)), a plain
            // button: DisclosureGroup draws its chevron in the label's black
            // or white whatever the tint (1.1.0 (227)), the strongest mark
            // on every card. This one is in the tertiary grey of 設定's.
            FieluaDisclosure("詳細", open: $showsDetails, font: .caption, quiet: true)
                .accessibilityIdentifier("model-details-\(spec.id)")
            if showsDetails { details.transition(.opacity) }
        }
    }

    /// A name on the left, its word on the right, as in iOS's own lists.
    private func row(_ title: String, _ value: String, id: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: FieluaSpace.s) {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 0)
            Text(value).foregroundStyle(.primary).multilineTextAlignment(.trailing)
        }
        .font(.footnote)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("model-\(id)-\(spec.id)")
    }

    private var details: some View {
        VStack(alignment: .leading, spacing: 10) {
            detail("回答の速さの根拠", fit.speed?.basis ?? SpeedEvidence.noneBasis)
            detail("負担の決め方", burdenBasis)
            detail("この端末で使えるメモリの目安", gigabytes(fit.deviceMemoryBudgetBytes))
            if showsFileName {
                // LFM3-VL 2B takes two files, one at a time (1.1.0 (234)).
                detail("取り込むファイル名", spec.files.map(\.fileName).joined(separator: "\n")).textSelection(.enabled)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func detail(_ title: LocalizedStringKey, _ text: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).fontWeight(.semibold)
            Text(text).fixedSize(horizontal: false, vertical: true)
        }
        .font(.caption).foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
    }

    /// The estimate's share of this device's memory, and the step up for a
    /// model that works on the CPU with its weights held (DeviceBurden).
    private var burdenBasis: String {
        let memory = String(format: "%.0f GB", Double(device.memoryBytes) / 1_000_000_000)
        let percent = Int((fit.memoryShare * 100).rounded())
        return Sentences.join([
            String(localized: "必要メモリが、この端末のメモリ\(memory)の約\(percent)%にあたります。"),
            spec.capabilities.locksCPUWeights
                ? String(localized: "CPUで動き、読み込んだモデルをメモリに置いたままにするため、一段階上にしています。") : ""
        ])
    }

    private func gigabytes(_ bytes: Double) -> String { String(format: "%.1f GB", bytes / 1_000_000_000) }
}
