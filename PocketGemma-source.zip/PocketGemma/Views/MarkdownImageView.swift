import SwiftUI
import UIKit
import ImageIO
import PocketCore

/// An image in a reply. Nothing loads until the reader taps the card, so a
/// reply cannot report back to a server on its own; only HTTPS images load,
/// without cookies, up to 10 MB, decoded at a reduced size.
struct MarkdownImageView: View {
    let url: URL?
    let alt: String
    @State private var phase = Phase.idle

    private enum Phase: Equatable {
        case idle, loading, failed(String)
        case loaded(UIImage)
    }

    private var loadable: Bool { url.map(MarkdownLinkPolicy.isLoadableImage) ?? false }
    private var title: String { alt.isEmpty ? String(localized: "画像") : alt }

    var body: some View {
        if case .loaded(let image) = phase {
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity, maxHeight: 320)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .accessibilityLabel(title)
        } else {
            Button(action: load) {
                HStack(spacing: 10) {
                    Image(systemName: symbol)
                        .font(.title3)
                        .foregroundStyle(.secondary)
                        .frame(width: 28)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(verbatim: title).font(.subheadline.weight(.medium)).lineLimit(2)
                        Text(verbatim: subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                    }
                    Spacer(minLength: 0)
                    if phase == .loading { ProgressView() }
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Theme.codeBackground, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                // Without a bubble around it, the card needs an edge on white.
                .overlay {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .strokeBorder(Theme.markdownLine.opacity(0.5), lineWidth: 0.5)
                }
                .contentShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(!loadable || phase == .loading)
            .accessibilityHint(loadable ? "画像を読み込みます" : "")
        }
    }

    private var symbol: String {
        if case .failed = phase { return "exclamationmark.triangle" }
        return loadable ? "photo" : "eye.slash"
    }

    private var subtitle: String {
        let host = url?.host ?? String(localized: "不明なアドレス")
        if case .failed(let reason) = phase { return "\(reason) · \(host)" }
        if phase == .loading { return String(localized: "読み込み中… · \(host)") }
        return loadable ? String(localized: "タップして読み込む · \(host)") : String(localized: "安全のため表示しません · \(host)")
    }

    private func load() {
        guard let url, loadable, phase != .loading else { return }
        phase = .loading
        Task {
            do { phase = .loaded(try await MarkdownImageLoader.image(url)) }
            catch { phase = .failed((error as? MarkdownImageLoader.Failure)?.message ?? String(localized: "読み込めませんでした")) }
        }
    }
}

enum MarkdownImageLoader {
    struct Failure: Error {
        let message: String
    }

    static let maximumBytes = 10 * 1024 * 1024
    static let maximumPixels = 2_000

    /// Loaded images, up to about 48 MB of pixels.
    private static let cache: NSCache<NSURL, UIImage> = {
        let cache = NSCache<NSURL, UIImage>()
        cache.countLimit = 40
        cache.totalCostLimit = 48 * 1024 * 1024
        return cache
    }()

    static func purge() { cache.removeAllObjects() }

    /// No cookies, cache or stored credentials, so loading tells the server
    /// as little as possible.
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 40
        configuration.httpAdditionalHeaders = ["Accept": "image/*"]
        return URLSession(configuration: configuration)
    }()

    static func image(_ url: URL) async throws -> UIImage {
        if let cached = cache.object(forKey: url as NSURL) { return cached }
        guard MarkdownLinkPolicy.isLoadableImage(url) else { throw Failure(message: String(localized: "HTTPS以外の画像は読み込みません")) }
        let (bytes, response) = try await session.bytes(from: url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw Failure(message: String(localized: "読み込めませんでした"))
        }
        guard MarkdownLinkPolicy.isLoadableImage(http.url ?? url) else { throw Failure(message: String(localized: "HTTPS以外へ転送されました")) }
        guard http.mimeType?.lowercased().hasPrefix("image/") == true else { throw Failure(message: String(localized: "画像ではありません")) }
        guard http.expectedContentLength <= Int64(maximumBytes) else { throw Failure(message: String(localized: "画像が大きすぎます")) }
        var data = Data()
        if http.expectedContentLength > 0 { data.reserveCapacity(Int(http.expectedContentLength)) }
        for try await byte in bytes {
            data.append(byte)
            if data.count > maximumBytes { throw Failure(message: String(localized: "画像が大きすぎます")) }
        }
        let image = try decode(data)
        cache.setObject(image, forKey: url as NSURL, cost: image.cgImage.map { $0.bytesPerRow * $0.height } ?? 0)
        return image
    }

    /// Decodes a thumbnail rather than the full image, so a huge picture
    /// cannot exhaust memory.
    static func decode(_ data: Data) throws -> UIImage {
        guard let source = CGImageSourceCreateWithData(data as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
              CGImageSourceGetCount(source) > 0 else { throw Failure(message: String(localized: "画像を開けませんでした")) }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maximumPixels,
        ]
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            throw Failure(message: String(localized: "画像を開けませんでした"))
        }
        return UIImage(cgImage: image)
    }
}
