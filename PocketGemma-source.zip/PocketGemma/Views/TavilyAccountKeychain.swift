import Foundation
import Security
import PocketCore

/// The person's Tavily sign-in (TavilyAccount) in the keychain: on this
/// device only, never synced. Its refresh token is renewed as it's used, so
/// two devices sharing one would sign each other out; each device signs in
/// on its own. Readable after the first unlock, so a reply finishing in the
/// background can still search.
struct TavilyAccountKeychain: TavilyAccountStore {
    private static var item: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.web-search",
         kSecAttrAccount as String: "tavily-account",
         kSecAttrSynchronizable as String: kCFBooleanFalse as Any]
    }

    func load() -> TavilyAccountRecord? {
        var query = Self.item
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return try? JSONDecoder().decode(TavilyAccountRecord.self, from: data)
    }

    @discardableResult
    func save(_ record: TavilyAccountRecord) -> Bool {
        guard let data = try? JSONEncoder().encode(record) else { return false }
        SecItemDelete(Self.item as CFDictionary)
        var entry = Self.item
        entry[kSecValueData as String] = data
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let saved = SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
        Self.announce(saved ? record.status : .signedOut)
        return saved
    }

    func delete() {
        SecItemDelete(Self.item as CFDictionary)
        Self.announce(.signedOut)
    }

    /// The views hear of every change, including a search that found the
    /// sign-in has run out.
    private static func announce(_ status: TavilyAccountRecord.Status) {
        Task { @MainActor in WebSearchKeyState.shared.accountChanged(status) }
    }
}

extension TavilyAccountSession {
    /// The app's one session, over an ephemeral URLSession that keeps no
    /// cookies or cache, like the searches with a key.
    static let shared = TavilyAccountSession(store: TavilyAccountKeychain(), transport: TavilyTransport.send,
                                             withoutRedirects: TavilyTransport.sendWithoutRedirects)
}

enum TavilyTransport {
    private static let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = WebSearch.timeout
        configuration.timeoutIntervalForResource = WebSearch.timeout * 2
        configuration.httpCookieStorage = nil
        configuration.urlCache = nil
        configuration.waitsForConnectivity = false
        return URLSession(configuration: configuration)
    }()

    @Sendable static func send(_ request: URLRequest) async throws -> (Data, HTTPURLResponse) {
        try await send(request, delegate: nil)
    }

    /// A redirect comes back as the answer instead of being followed: where
    /// Tavily's sign-in sends the browser, for 新規登録.
    @Sendable static func sendWithoutRedirects(_ request: URLRequest) async throws -> (Data, HTTPURLResponse) {
        try await send(request, delegate: StopsAtRedirects())
    }

    private static func send(_ request: URLRequest, delegate: URLSessionTaskDelegate?) async throws -> (Data, HTTPURLResponse) {
        #if POCKET_PREVIEW
        // --tavily-offline: every request finds no connection, for the
        // sign-in's error in the UI check.
        if ProcessInfo.processInfo.arguments.contains("--tavily-offline") { throw URLError(.notConnectedToInternet) }
        #endif
        let (data, response) = try await session.data(for: request, delegate: delegate)
        guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        return (data, http)
    }

    private final class StopsAtRedirects: NSObject, URLSessionTaskDelegate, Sendable {
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                        newRequest request: URLRequest) async -> URLRequest? {
            nil
        }
    }
}

/// How this device searches now: the Tavily account when signed in, the
/// person's own key otherwise.
enum WebSearchConnection {
    case account
    case key(String)
    /// Signed in once, but Tavily wants the person to sign in again, and
    /// there is no key to fall back on.
    case signInNeeded
    case none

    static func current() -> WebSearchConnection {
        let account = TavilyAccountKeychain().load()?.status
        if account == .connected { return .account }
        if let key = WebSearchKey.load() { return .key(key) }
        return account == .needsSignIn ? .signInNeeded : .none
    }
}
