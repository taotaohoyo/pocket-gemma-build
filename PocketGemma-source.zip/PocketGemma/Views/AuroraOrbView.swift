import SwiftUI
import Combine
import PocketCore

/// Pocket AI's thinking indicator: the app icon's colours flowing and mixing
/// inside a circle of light 24pt across (AuroraOrbShader.metal) that
/// breathes between half and its full size, and shrinks to nothing once the
/// reply's first token has come. It draws up to 30 frames a second, 15 in
/// Low Power Mode or while the phone runs hot, and holds one still frame
/// with Reduce Motion or when the phone is critically hot. It stops drawing
/// while scrolled out of sight, while its screen is covered and while the
/// app is not active. It changes nothing around it, so it can be shown
/// anywhere.
struct AuroraOrbView: View {
    /// The square the light is drawn in.
    static let canvas: CGFloat = 52
    /// Half the light's width at full size: its edge is 12pt from the centre.
    static let lightRadius: CGFloat = 12
    /// The light breathes between this share of its full size and the
    /// whole, once every `breathPeriod` seconds, full to begin with.
    static let smallest = 0.5
    static let breathPeriod: TimeInterval = 3.6
    /// How long the light takes to shrink to nothing once the reply begins.
    static let exitDuration: TimeInterval = 0.7
    /// Where the motion starts: the colours where the icon has them, at
    /// full size. Reduce Motion holds this frame.
    private static let origin: TimeInterval = 0

    /// When the light began to give way to the reply's text; nil while the
    /// model is still thinking.
    var leavingSince: Date? = nil

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()
    @State private var pace = OrbPace.current
    @State private var inSight = true
    @State private var onScreen = true

    init(leavingSince: Date? = nil) {
        self.leavingSince = leavingSince
    }

    var body: some View {
        Group {
            if systemReduceMotion || previewReduceMotion || pace == .still {
                light(at: Self.origin, size: 1)
            } else {
                TimelineView(.animation(minimumInterval: pace.interval, paused: !drawing)) { context in
                    let elapsed = context.date.timeIntervalSince(started)
                    let motion = Self.sizeAndOpacity(at: elapsed, leavingAt: leavingSince?.timeIntervalSince(started))
                    light(at: Self.origin + elapsed, size: motion.size).opacity(motion.opacity)
                }
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .onScrollVisibilityChange(threshold: 0.01) { inSight = $0 }
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .accessibilityElement()
        .accessibilityLabel(Text("返信を書いています"))
    }

    private var drawing: Bool { inSight && onScreen && scenePhase == .active }

    /// Whether the light shrinks away when the reply begins. With Reduce
    /// Motion, or while it holds still for heat, it fades instead.
    static func shrinksAway(reduceMotion: Bool) -> Bool {
        !reduceMotion && OrbPace.current != .still
    }

    /// How long the light takes to leave: the shrink, or the fade.
    static func exitDuration(reduceMotion: Bool) -> TimeInterval {
        shrinksAway(reduceMotion: reduceMotion) ? exitDuration : 0.18
    }

    /// The light's size (1 = full) and how fast that is changing, `time`
    /// seconds after it appeared: one slow breath after another.
    static func breath(at time: TimeInterval) -> (size: Double, rate: Double) {
        let turn = 2 * Double.pi / breathPeriod
        let half = 0.5 * (1 - smallest)
        return (smallest + half * (1 + cos(turn * time)), -half * turn * sin(turn * time))
    }

    /// Size and opacity at `time`: breathing until `leavingAt`, then a cubic
    /// from the breath's size and pace at that moment to nothing and still
    /// over `exitDuration`, so the breath runs on into the shrink. The last
    /// part also fades, so no speck pops out at the end.
    static func sizeAndOpacity(at time: TimeInterval, leavingAt: TimeInterval?) -> (size: Double, opacity: Double) {
        guard let leavingAt, time > leavingAt else { return (breath(at: time).size, 1) }
        let share = min((time - leavingAt) / exitDuration, 1)
        let start = breath(at: leavingAt)
        let keep = 2 * share * share * share - 3 * share * share + 1
        let carry = share * share * share - 2 * share * share + share
        let size = max(start.size * keep + start.rate * exitDuration * carry, 0)
        let fading = max((share - 0.6) / 0.4, 0)
        return (size, 1 - fading * fading * (3 - 2 * fading))
    }

    /// Compiles the light's shader for this GPU ahead of the first reply.
    /// Shaders otherwise compile on first use, and the first orb after
    /// launch then waits for the compiler (blank for 5 s on the CI
    /// simulator, 1.0.82).
    static func prepare() async {
        try? await ShaderLibrary.auroraOrb(.float2(canvas, canvas), .float(0), .float(0), .float(1)).compile(as: .shapeStyle)
    }

    private func light(at time: TimeInterval, size: Double) -> some View {
        let dark: Float = colorScheme == .dark ? 1 : 0
        return Rectangle().fill(ShaderLibrary.auroraOrb(.float2(Self.canvas, Self.canvas), .float(Float(time)),
                                                        .float(dark), .float(Float(size))))
    }
}

/// How often the orb may draw: half as often in Low Power Mode or while the
/// phone is hot, and not at all when it is critically hot.
enum OrbPace: Equatable {
    case full, half, still

    static var current: OrbPace {
        let info = ProcessInfo.processInfo
        switch info.thermalState {
        case .critical: return .still
        case .serious: return .half
        default: return info.isLowPowerModeEnabled ? .half : .full
        }
    }

    var interval: TimeInterval { self == .full ? 1.0 / 30.0 : 1.0 / 15.0 }

    /// Low Power Mode and heat changes, on the main thread.
    static let changes = NotificationCenter.default.publisher(for: .NSProcessInfoPowerStateDidChange)
        .merge(with: NotificationCenter.default.publisher(for: ProcessInfo.thermalStateDidChangeNotification))
        .receive(on: DispatchQueue.main)
}

/// The orb in a reply's place until the reply may show its text: on the
/// reply's first line, fading in, breathing while the model thinks, and
/// shrinking away from `leavingSince` once the first token has come (fading
/// instead when it cannot shrink). The reply removes it once it has gone,
/// so it needs no removal transition.
struct ReplyOrb: View {
    let leavingSince: Date?
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var shown = false

    init(leavingSince: Date?) {
        self.leavingSince = leavingSince
    }

    var body: some View {
        // A hidden line of reply text, so the orb stays centred on the
        // first line however long the reply grows as it leaves.
        Text(verbatim: "あ").font(ChatMetrics.replyFont).hidden().accessibilityHidden(true)
            .padding(.vertical, ChatMetrics.bubbleVertical)
            .overlay(alignment: .leading) {
                // The light's soft edge starts where the text does.
                AuroraOrbView(leavingSince: leavingSince)
                    .offset(x: ChatMetrics.replyInset + AuroraOrbView.lightRadius - AuroraOrbView.canvas / 2)
                    .opacity(shown ? 1 : 0)
            }
            .onAppear { fade(toward: true) }
            .onChange(of: leavingSince) { _, since in
                if since != nil, !AuroraOrbView.shrinksAway(reduceMotion: systemReduceMotion || previewReduceMotion) {
                    fade(toward: false)
                }
            }
    }

    /// From a new task, because changes that arrive while the conversation
    /// streams or scrolls come in transactions with animation turned off.
    private func fade(toward visible: Bool) {
        Task { @MainActor in
            withAnimation(visible ? .easeOut(duration: 0.2) : .easeIn(duration: 0.18)) { shown = visible }
        }
    }
}

/// Whether a reply's text draws anything yet, by the same parse the reply
/// view makes (MarkdownReplyView's chunks): text that so far holds only a
/// line break, spaces or syntax still being written draws nothing, and the
/// reply keeps its place blank until something can be read. Parses come
/// from the shared cache, so the reply view does not parse them again.
enum ReplyVisibility {
    static func drawsText(_ text: String, markdown: Bool) -> Bool {
        guard !text.isEmpty else { return false }
        // Past a few lines' worth, a reply always shows something.
        guard markdown, text.utf8.count < 256 else { return true }
        let chunks = MarkdownSource.chunks(text)
        let references = text.contains("]:") ? MarkdownSource.referenceDefinitions(text) : ""
        return chunks.indices.contains { index in
            !MarkdownCache.document(chunks[index], references: references,
                                    streaming: index == chunks.count - 1).blocks.isEmpty
        }
    }
}
