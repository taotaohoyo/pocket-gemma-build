import SwiftUI
import Combine
import PocketCore

/// Pocket AI's thinking indicator: coloured mist drifting and mixing inside
/// a soft round of light about 34pt across (AuroraOrbShader.metal). It draws
/// up to 30 frames a second, 15 in Low Power Mode or while the phone runs
/// hot, and holds one still frame with Reduce Motion or when the phone is
/// critically hot. It stops drawing while scrolled out of sight, while its
/// screen is covered and while the app is not active. It changes nothing
/// around it, so it can be shown anywhere.
struct AuroraOrbView: View {
    /// The square the light and its faint halo are drawn in.
    static let canvas: CGFloat = 52
    /// Half the light's width: its soft edge is about 17pt from the centre.
    static let lightRadius: CGFloat = 17
    /// Where the motion starts: a moment with three or four colours in the
    /// light. Reduce Motion holds this frame.
    private static let origin: TimeInterval = 4.5

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()
    @State private var pace = OrbPace.current
    @State private var inSight = true
    @State private var onScreen = true

    var body: some View {
        Group {
            if systemReduceMotion || previewReduceMotion || pace == .still {
                light(at: Self.origin)
            } else {
                TimelineView(.animation(minimumInterval: pace.interval, paused: !drawing)) { context in
                    light(at: Self.origin + context.date.timeIntervalSince(started))
                }
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .onScrollVisibilityChange(threshold: 0.01) { inSight = $0 }
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .accessibilityElement()
        .accessibilityLabel(Text("AIが回答を作成しています"))
    }

    private var drawing: Bool { inSight && onScreen && scenePhase == .active }

    private func light(at time: TimeInterval) -> some View {
        let dark: Float = colorScheme == .dark ? 1 : 0
        return Rectangle().fill(ShaderLibrary.auroraOrb(.float2(Self.canvas, Self.canvas), .float(Float(time)), .float(dark)))
    }
}

/// How often the orb may draw: half as often in Low Power Mode or while the
/// phone is hot, and not at all when it is critically hot.
enum OrbPace: Equatable {
    case full, half, still

    static var current: OrbPace {
        let info = ProcessInfo.processInfo
        switch info.thermalState {
        case .critical: return .still
        case .serious: return .half
        default: return info.isLowPowerModeEnabled ? .half : .full
        }
    }

    var interval: TimeInterval { self == .full ? 1.0 / 30.0 : 1.0 / 15.0 }

    /// Low Power Mode and heat changes, on the main thread.
    static let changes = NotificationCenter.default.publisher(for: .NSProcessInfoPowerStateDidChange)
        .merge(with: NotificationCenter.default.publisher(for: ProcessInfo.thermalStateDidChangeNotification))
        .receive(on: DispatchQueue.main)
}

/// The orb in a reply's place until the reply has text to draw. It sits on
/// the reply's first line, fades in, and fades out as the text arrives. It
/// stays mounted through its fade, since removal transitions do not animate
/// in iOS 26, and leaves nothing behind once it has faded.
struct ReplyOrb: View {
    let waiting: Bool
    @State private var wanted: Bool
    @State private var mounted: Bool
    @State private var shown = false

    init(waiting: Bool) {
        self.waiting = waiting
        _wanted = State(initialValue: waiting)
        _mounted = State(initialValue: waiting)
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            if mounted {
                // A hidden line of reply text, so the orb stays centred on
                // the first line however long the reply grows as it fades.
                Text(verbatim: "あ").font(ChatMetrics.replyFont).hidden().accessibilityHidden(true)
                    .padding(.vertical, ChatMetrics.bubbleVertical)
                    .overlay(alignment: .leading) {
                        // The light's soft edge starts where the text does.
                        AuroraOrbView()
                            .offset(x: ChatMetrics.replyInset + AuroraOrbView.lightRadius - AuroraOrbView.canvas / 2)
                            .opacity(shown ? 1 : 0)
                    }
                    .onAppear(perform: settle)
            }
        }
        .onChange(of: waiting) { _, waiting in
            wanted = waiting
            if waiting { mounted = true }
            settle()
        }
    }

    /// Fades toward what is wanted now. From a new task, because changes
    /// that arrive while the conversation streams or scrolls come in
    /// transactions with animation turned off.
    private func settle() {
        Task { @MainActor in
            if wanted {
                withAnimation(.easeOut(duration: 0.2)) { shown = true }
            } else {
                withAnimation(.easeIn(duration: 0.18)) { shown = false } completion: {
                    if !wanted { mounted = false }
                }
            }
        }
    }
}

/// Whether a reply's text draws anything yet, by the same parse the reply
/// view makes (MarkdownReplyView's chunks): text that so far holds only a
/// line break, spaces or syntax still being written draws nothing, and the
/// orb stays until something can be read. Parses come from the shared
/// cache, so the reply view does not parse them again.
enum ReplyVisibility {
    static func drawsText(_ text: String, markdown: Bool) -> Bool {
        guard !text.isEmpty else { return false }
        // Past a few lines' worth, a reply always shows something.
        guard markdown, text.utf8.count < 256 else { return true }
        let chunks = MarkdownSource.chunks(text)
        let references = text.contains("]:") ? MarkdownSource.referenceDefinitions(text) : ""
        return chunks.indices.contains { index in
            !MarkdownCache.document(chunks[index], references: references,
                                    streaming: index == chunks.count - 1).blocks.isEmpty
        }
    }
}
