import SwiftUI
import Combine
import PocketCore

/// Pocket AI's thinking indicator: the flower's golds flowing and mixing
/// inside a circle of light 24pt across (AuroraOrbShader.metal) that
/// breathes between half and its full size, and shrinks to nothing once the
/// reply's first token has come. Around it, soft motes of the same golds
/// leave its rim and drift out and down over a faint glow (AuroraMotes,
/// 1.1.0 (298)), and drift toward the reply's line as it leaves; they are
/// drawn beside it, outside its square, and change nothing around it
/// either. It draws up to 30 frames a second, 15 in
/// Low Power Mode or while the phone runs hot, and holds one still frame
/// with Reduce Motion or when the phone is critically hot. It stops drawing
/// while scrolled out of sight, while its screen is covered and while the
/// app is not active. It changes nothing around it, so it can be shown
/// anywhere.
struct AuroraOrbView: View {
    /// The square the light is drawn in.
    static let canvas: CGFloat = 52
    /// Half the light's width at full size: its edge is 12pt from the centre.
    static let lightRadius: CGFloat = 12
    /// The light breathes between this share of its full size and the
    /// whole, once every `breathPeriod` seconds, full to begin with.
    static let smallest = 0.5
    static let breathPeriod: TimeInterval = 3.6
    /// How long the light takes to shrink to nothing once the reply begins,
    /// in the light's own time...
    static let shrinkDuration: TimeInterval = 0.7
    /// ...and on the clock (four times as long in the preview's slow
    /// motion for filming, OrbFilm).
    static let exitDuration: TimeInterval = shrinkDuration * OrbFilm.scale
    /// Where the motion starts: the colours where the icon has them, at
    /// full size. Reduce Motion holds this frame.
    private static let origin: TimeInterval = 0

    /// When the light began to give way to the reply's text; nil while the
    /// model is still thinking.
    var leavingSince: Date? = nil
    /// Whether the motes and glow are drawn around the light.
    var motes = true

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()
    @State private var pace = OrbPace.current
    @State private var inSight = true
    @State private var onScreen = true

    init(leavingSince: Date? = nil, motes: Bool = true) {
        self.leavingSince = leavingSince
        self.motes = motes && !OrbFilm.noMotes
    }

    var body: some View {
        Group {
            // With Reduce Motion, or held still for heat, the light alone
            // and still: no motes.
            if systemReduceMotion || previewReduceMotion || pace == .still {
                light(at: Self.origin, size: 1)
            } else {
                TimelineView(.animation(minimumInterval: pace.interval, paused: !drawing)) { context in
                    // In the light's own time (slowed only to film it).
                    let elapsed = context.date.timeIntervalSince(started) / OrbFilm.scale
                    let leavingAt = leavingSince.map { $0.timeIntervalSince(started) / OrbFilm.scale }
                    let motion = Self.sizeAndOpacity(at: elapsed, leavingAt: leavingAt)
                    ZStack {
                        if motes { field(at: elapsed, leavingAt: leavingAt) }
                        light(at: Self.origin + elapsed, size: motion.size).opacity(motion.opacity)
                    }
                }
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .onScrollVisibilityChange(threshold: 0.01) { inSight = $0 }
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .accessibilityElement()
        .accessibilityLabel(Text("返信を書いています"))
    }

    private var drawing: Bool { inSight && onScreen && scenePhase == .active }

    /// Whether the light shrinks away when the reply begins. With Reduce
    /// Motion, or while it holds still for heat, it fades instead.
    static func shrinksAway(reduceMotion: Bool) -> Bool {
        !reduceMotion && OrbPace.current != .still
    }

    /// How long the light takes to leave: the shrink, or the fade.
    static func exitDuration(reduceMotion: Bool) -> TimeInterval {
        shrinksAway(reduceMotion: reduceMotion) ? exitDuration : 0.18
    }

    /// The light's size (1 = full) and how fast that is changing, `time`
    /// seconds after it appeared: one slow breath after another.
    static func breath(at time: TimeInterval) -> (size: Double, rate: Double) {
        let turn = 2 * Double.pi / breathPeriod
        let half = 0.5 * (1 - smallest)
        return (smallest + half * (1 + cos(turn * time)), -half * turn * sin(turn * time))
    }

    /// Size and opacity at `time`: breathing until `leavingAt`, then a cubic
    /// from the breath's size and pace at that moment to nothing and still
    /// over `shrinkDuration`, so the breath runs on into the shrink. The last
    /// part also fades, so no speck pops out at the end.
    static func sizeAndOpacity(at time: TimeInterval, leavingAt: TimeInterval?) -> (size: Double, opacity: Double) {
        guard let leavingAt, time > leavingAt else { return (breath(at: time).size, 1) }
        let share = min((time - leavingAt) / shrinkDuration, 1)
        let start = breath(at: leavingAt)
        let keep = 2 * share * share * share - 3 * share * share + 1
        let carry = share * share * share - 2 * share * share + share
        let size = max(start.size * keep + start.rate * shrinkDuration * carry, 0)
        let fading = max((share - 0.6) / 0.4, 0)
        return (size, 1 - fading * fading * (3 - 2 * fading))
    }

    /// Compiles the light's shader for this GPU ahead of the first reply.
    /// Shaders otherwise compile on first use, and the first orb after
    /// launch then waits for the compiler (blank for 5 s on the CI
    /// simulator, 1.0.82).
    static func prepare() async {
        try? await ShaderLibrary.auroraOrb(.float2(canvas, canvas), .float(0), .float(0), .float(1)).compile(as: .shapeStyle)
        try? await motesShader(values: Self.noMote, dark: 0, veil: 0).compile(as: .shapeStyle)
    }

    /// The motes' field: its size, and where the light's centre is in it.
    private static let fieldSize = CGSize(width: AuroraMotes.field.left + AuroraMotes.field.right,
                                          height: AuroraMotes.field.up + AuroraMotes.field.down)
    private static let fieldCentre = (x: AuroraMotes.field.left, y: AuroraMotes.field.up)
    /// The glow under the light, in the field: a little right of the
    /// light's centre and 12pt below it.
    private static let glowAt = CGPoint(x: AuroraMotes.field.left + 4, y: AuroraMotes.field.up + 12)
    /// A mote that shows nothing, for a frame without any (the shader
    /// always gets something to read).
    private static let noMote: [Float] = [0, 0, 1, 0, 0]

    private static func motesShader(values: [Float], dark: Float, veil: Float) -> Shader {
        ShaderLibrary.auroraMotes(.float2(fieldSize.width, fieldSize.height), .floatArray(values), .float(dark),
                                  .float2(glowAt.x, glowAt.y), .float(veil))
    }

    /// The motes and the glow at `time`, behind the light: a field larger
    /// than the light's square, placed so the light's centre is where the
    /// motes are counted from.
    private func field(at time: TimeInterval, leavingAt: TimeInterval?) -> some View {
        let breath: (TimeInterval) -> Double = { Self.breath(at: $0).size }
        let motes = AuroraMotes.motes(at: time, leavingAt: leavingAt, exitDuration: Self.shrinkDuration, breath: breath)
        let veil = AuroraMotes.veil(at: time, leavingAt: leavingAt, exitDuration: Self.shrinkDuration, breath: breath)
        let values = motes.isEmpty ? Self.noMote : AuroraMotes.packed(motes, origin: Self.fieldCentre)
        let dark: Float = colorScheme == .dark ? 1 : 0
        return Rectangle()
            .fill(Self.motesShader(values: values, dark: dark, veil: Float(veil)))
            .frame(width: Self.fieldSize.width, height: Self.fieldSize.height)
            .offset(x: Self.fieldSize.width / 2 - CGFloat(Self.fieldCentre.x),
                    y: Self.fieldSize.height / 2 - CGFloat(Self.fieldCentre.y))
    }

    private func light(at time: TimeInterval, size: Double) -> some View {
        let dark: Float = colorScheme == .dark ? 1 : 0
        return Rectangle().fill(ShaderLibrary.auroraOrb(.float2(Self.canvas, Self.canvas), .float(Float(time)),
                                                        .float(dark), .float(Float(size))))
    }
}

/// How often the orb may draw: half as often in Low Power Mode or while the
/// phone is hot, and not at all when it is critically hot.
enum OrbPace: Equatable {
    case full, half, still

    static var current: OrbPace {
        let info = ProcessInfo.processInfo
        switch info.thermalState {
        case .critical: return .still
        case .serious: return .half
        default: return info.isLowPowerModeEnabled ? .half : .full
        }
    }

    var interval: TimeInterval { self == .full ? 1.0 / 30.0 : 1.0 / 15.0 }

    /// Low Power Mode and heat changes, on the main thread.
    static let changes = NotificationCenter.default.publisher(for: .NSProcessInfoPowerStateDidChange)
        .merge(with: NotificationCenter.default.publisher(for: ProcessInfo.thermalStateDidChangeNotification))
        .receive(on: DispatchQueue.main)
}

/// The preview's slow motion for filming the orb frame by frame
/// (`--orb-slow-motion`): its breath, flow, motes and exit four times
/// slower; and `--probe-no-motes`, the light alone, for the frames' check.
/// Neither is in the app.
enum OrbFilm {
    #if POCKET_PREVIEW
    static let scale: Double = PreviewProbe.on("--orb-slow-motion") ? 4 : 1
    static let noMotes = PreviewProbe.on("--probe-no-motes")
    #else
    static let scale: Double = 1
    static let noMotes = false
    #endif
}

/// The orb in a reply's place until the reply may show its text: on the
/// reply's first line, fading in, breathing while the model thinks with its
/// motes drifting into the room under the reply, and shrinking away from
/// `leavingSince` once the first token has come, the motes drifting toward
/// the line and fading with it (fading instead when it cannot shrink, with
/// no motes). The reply removes it once it has gone, so it needs no removal
/// transition.
struct ReplyOrb: View {
    let leavingSince: Date?
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var shown = false

    init(leavingSince: Date?) {
        self.leavingSince = leavingSince
    }

    var body: some View {
        // A hidden line of reply text, so the orb stays centred on the
        // first line however long the reply grows as it leaves.
        Text(verbatim: "あ").font(ChatMetrics.replyFont).hidden().accessibilityHidden(true)
            .padding(.vertical, ChatMetrics.bubbleVertical)
            .overlay(alignment: .leading) {
                // The light's soft edge starts where the text does.
                AuroraOrbView(leavingSince: leavingSince)
                    .offset(x: ChatMetrics.replyInset + AuroraOrbView.lightRadius - AuroraOrbView.canvas / 2)
                    .opacity(shown ? 1 : 0)
            }
            .onAppear { fade(toward: true) }
            .onChange(of: leavingSince) { _, since in
                if since != nil, !AuroraOrbView.shrinksAway(reduceMotion: systemReduceMotion || previewReduceMotion) {
                    fade(toward: false)
                }
            }
    }

    /// From a new task, because changes that arrive while the conversation
    /// streams or scrolls come in transactions with animation turned off.
    private func fade(toward visible: Bool) {
        Task { @MainActor in
            withAnimation(visible ? ChatMotion.orbIn : ChatMotion.orbOut) { shown = visible }
        }
    }
}

/// Whether a reply's text draws anything yet, by the same parse the reply
/// view makes (MarkdownReplyView's chunks): text that so far holds only a
/// line break, spaces or syntax still being written draws nothing, and the
/// reply keeps its place blank until something can be read. Parses come
/// from the shared cache, so the reply view does not parse them again.
enum ReplyVisibility {
    static func drawsText(_ text: String, markdown: Bool) -> Bool {
        guard !text.isEmpty else { return false }
        // Past a few lines' worth, a reply always shows something.
        guard markdown, text.utf8.count < 256 else { return true }
        let chunks = MarkdownSource.chunks(text)
        let references = text.contains("]:") ? MarkdownSource.referenceDefinitions(text) : ""
        return chunks.indices.contains { index in
            !MarkdownCache.document(chunks[index], references: references,
                                    streaming: index == chunks.count - 1).blocks.isEmpty
        }
    }
}
