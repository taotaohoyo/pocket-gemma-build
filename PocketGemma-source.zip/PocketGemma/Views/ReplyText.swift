import SwiftUI
import UIKit
import PocketCore

/// A reply block's styled text whose newly arrived characters flow in while
/// Gemma streams: each character fades up from clear, rises into place by a
/// couple of points and sheds a slight blur over `ReplyRevealBuffer.duration`,
/// and the characters of one piece start a few hundredths of a second apart
/// (the buffer's stagger, set by the pace the pieces come at), so a step of
/// several characters reads as writing rather than a group appearing at
/// once. Only the reply's last chunk uses it; settled text is a plain
/// `Text`. Reduce Motion and VoiceOver turn it off (`MarkdownReplyView`).
struct RevealingRichText: View {
    let text: AttributedString
    let isStreaming: Bool
    @State private var buffer: ReplyRevealBuffer

    init(text: AttributedString, isStreaming: Bool) {
        self.text = text
        self.isStreaming = isStreaming
        let plain = String(text.characters)
        var initial = ReplyRevealBuffer(text: isStreaming ? "" : plain)
        if isStreaming { initial.update(plain, at: Date().timeIntervalSinceReferenceDate) }
        _buffer = State(initialValue: initial)
    }

    private var plain: String { String(text.characters) }

    /// The text split where the buffer's pieces arrived. Characters the
    /// buffer has not seen yet arrive now. Nil when the text was replaced.
    private func markedText(plain: String) -> Text? {
        let known = buffer.text
        guard plain.hasPrefix(known) else { return nil }
        let now = Date().timeIntervalSinceReferenceDate
        var cursor = text.startIndex
        func take(_ count: Int) -> AttributedString {
            let end = text.characters.index(cursor, offsetBy: count, limitedBy: text.endIndex) ?? text.endIndex
            defer { cursor = end }
            return AttributedString(text[cursor..<end])
        }
        var result = Text(take(buffer.settledText.count))
        for segment in buffer.segments {
            result = result + Text(take(segment.text.count))
                .customAttribute(ReplyArrival(arrivedAt: segment.arrivedAt, stagger: segment.stagger))
        }
        if cursor < text.endIndex {
            result = result + Text(take(plain.count - known.count))
                .customAttribute(ReplyArrival(arrivedAt: now, stagger: ReplyRevealBuffer.defaultStagger))
        }
        return result
    }

    var body: some View {
        let current = plain
        Group {
            if !isStreaming && buffer.segments.isEmpty && buffer.text == current {
                Text(text)
            } else if let rendered = markedText(plain: current) {
                // Build attributed text once per content update, not on every
                // animation frame of an increasingly long answer. The frames
                // only redraw the laid-out text.
                TimelineView(.animation(minimumInterval: 1.0 / 60.0, paused: buffer.segments.isEmpty)) { timeline in
                    rendered.textRenderer(ReplyAppearanceRenderer(now: timeline.date.timeIntervalSinceReferenceDate))
                }
                // The selectable system text view bypasses custom rendering
                // on the tested runtime. Restore selection once the final
                // arriving characters have finished becoming clear.
                .textSelection(.disabled)
            } else {
                Text(text)
            }
        }
        .onChange(of: current) { _, newest in
            buffer.update(newest, at: Date().timeIntervalSinceReferenceDate)
        }
        .task(id: buffer.animationDeadline) {
            guard let deadline = buffer.animationDeadline else { return }
            do {
                try await Task.sleep(for: .seconds(max(0, deadline - Date().timeIntervalSinceReferenceDate)))
            } catch { return }
            buffer.settle(at: Date().timeIntervalSinceReferenceDate)
        }
    }
}

private struct ReplyArrival: TextAttribute {
    let arrivedAt: TimeInterval
    let stagger: TimeInterval
}

/// How each arriving character appears, over `ReplyRevealBuffer.duration`.
enum ReplyRevealStyle {
    /// Points below its place a character starts from, rising as it clears.
    static let rise: CGFloat = 2
    /// The blur a character starts with, in points.
    static let blur: CGFloat = 1.5
}

/// Draws settled runs as they are and each arriving character by how far
/// along its own appearance it is: its start is its piece's arrival plus its
/// place in the piece times the piece's stagger. Characters of one piece
/// are counted across its runs (a run ends at a line break or a change of
/// style), so the stagger carries on over them.
private struct ReplyAppearanceRenderer: TextRenderer {
    let now: TimeInterval

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        var arrival: TimeInterval?
        var ordinal = 0
        for line in layout {
            for run in line {
                guard let mark = run[ReplyArrival.self] else {
                    context.draw(run)
                    arrival = nil
                    continue
                }
                if mark.arrivedAt != arrival {
                    arrival = mark.arrivedAt
                    ordinal = 0
                }
                for slice in run {
                    let start = mark.arrivedAt + Double(ordinal) * mark.stagger
                    ordinal += 1
                    let progress = (now - start) / ReplyRevealBuffer.duration
                    if progress >= 1 {
                        context.draw(slice)
                    } else if progress > 0 {
                        let eased = progress * progress * (3 - 2 * progress)
                        let remaining = 1 - progress
                        var copy = context
                        copy.opacity *= eased
                        copy.translateBy(x: 0, y: ReplyRevealStyle.rise * CGFloat(remaining * remaining))
                        let blur = ReplyRevealStyle.blur * CGFloat(remaining)
                        if blur > 0.2 { copy.addFilter(.blur(radius: blur)) }
                        copy.draw(slice)
                    }
                    // Before its start a character is not drawn at all.
                }
            }
        }
    }
}
