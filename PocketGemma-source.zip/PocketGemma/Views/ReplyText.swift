import SwiftUI
import UIKit
import PocketCore

/// The pace at which a reply's row is laying its text out (ReplyPacer), for
/// the text views that time each character's appearance to it.
struct ReplyCadence: Equatable {
    /// Characters a second.
    var pace = ReplyRevealBuffer.defaultPace
    /// Seconds between the row's steps.
    var step = ReplyRevealBuffer.defaultStep
}

extension EnvironmentValues {
    @Entry var replyCadence = ReplyCadence()
}

/// A reply block's styled text whose newly arrived characters flow in while
/// Gemma streams. Each character starts on one continuous schedule at the
/// row's pace, wherever the row's steps fall (ReplyRevealBuffer), and over
/// `ReplyRevealBuffer.duration` fades up from clear and rises into place by
/// a couple of points. It appears in a colour of the app icon's rainbow,
/// its neighbours in the neighbouring colours, so the characters in flight
/// carry a rainbow that moves with the writing; each gives way to its own
/// colour within `ReplyRevealBuffer.tintDuration`, and the text behind the
/// light reads in its own colours. Only the reply's last chunk uses it;
/// settled text is a plain `Text`. Reduce Motion and VoiceOver turn it off
/// (`MarkdownReplyView`).
struct RevealingRichText: View {
    let text: AttributedString
    let isStreaming: Bool
    @State private var buffer: ReplyRevealBuffer
    @Environment(\.replyCadence) private var cadence
    @Environment(\.colorScheme) private var colorScheme

    init(text: AttributedString, isStreaming: Bool) {
        self.text = text
        self.isStreaming = isStreaming
        let plain = String(text.characters)
        var initial = ReplyRevealBuffer(text: isStreaming ? "" : plain)
        // A block made mid-reply places its first piece at the usual pace;
        // the row's own pace reaches the pieces after it.
        if isStreaming { initial.update(plain, at: Date().timeIntervalSinceReferenceDate) }
        _buffer = State(initialValue: initial)
    }

    private var plain: String { String(text.characters) }

    /// The text split where the buffer's pieces arrived. Nil when the text
    /// was replaced.
    private func markedText(plain: String) -> Text? {
        let known = buffer.text
        guard plain.hasPrefix(known) else { return nil }
        var cursor = text.startIndex
        func take(_ count: Int) -> AttributedString {
            let end = text.characters.index(cursor, offsetBy: count, limitedBy: text.endIndex) ?? text.endIndex
            defer { cursor = end }
            return AttributedString(text[cursor..<end])
        }
        var result = Text(take(buffer.settledText.count))
        for segment in buffer.segments {
            result = result + Text(take(segment.text.count))
                .customAttribute(ReplyArrival(startsAt: segment.startsAt, spacing: segment.spacing))
        }
        if cursor < text.endIndex {
            // Characters the buffer has not placed yet (it does as this
            // update settles) are laid out but not drawn until then.
            result = result + Text(take(plain.count - known.count))
                .customAttribute(ReplyArrival(startsAt: .infinity, spacing: 0))
        }
        return result
    }

    /// Frames a second while characters are in flight: every frame on the
    /// phone, half as many when it is hot or saving power, and in the
    /// simulator, which draws in software.
    private static var frameInterval: TimeInterval {
        #if targetEnvironment(simulator)
        return 1.0 / 30.0
        #else
        return OrbPace.current == .full ? 1.0 / 60.0 : 1.0 / 30.0
        #endif
    }

    var body: some View {
        let current = plain
        Group {
            if !isStreaming && buffer.segments.isEmpty && buffer.text == current {
                Text(text)
            } else if let rendered = markedText(plain: current) {
                // Build attributed text once per content update, not on every
                // animation frame of an increasingly long answer. The frames
                // only redraw the laid-out text.
                TimelineView(.animation(minimumInterval: Self.frameInterval, paused: buffer.segments.isEmpty)) { timeline in
                    rendered.textRenderer(ReplyAppearanceRenderer(now: timeline.date.timeIntervalSinceReferenceDate,
                                                                   dark: colorScheme == .dark))
                }
                // The selectable system text view bypasses custom rendering
                // on the tested runtime. Restore selection once the final
                // arriving characters have finished becoming clear.
                .textSelection(.disabled)
            } else {
                Text(text)
            }
        }
        .onChange(of: current) { _, newest in
            buffer.update(newest, at: Date().timeIntervalSinceReferenceDate, pace: cadence.pace, step: cadence.step)
        }
        .task(id: buffer.animationDeadline) {
            guard let deadline = buffer.animationDeadline else { return }
            do {
                try await Task.sleep(for: .seconds(max(0, deadline - Date().timeIntervalSinceReferenceDate)))
            } catch { return }
            buffer.settle(at: Date().timeIntervalSinceReferenceDate)
        }
    }
}

private struct ReplyArrival: TextAttribute {
    let startsAt: TimeInterval
    let spacing: TimeInterval
}

/// How each arriving character appears: rising into place as it fades in
/// over `ReplyRevealBuffer.duration`, in a colour of the app icon's rainbow
/// that gives way to its own colour `ReplyRevealBuffer.tintDuration` after
/// it started.
enum ReplyRevealStyle {
    /// Points below its place a character starts from, rising as it clears.
    static let rise: CGFloat = 2
    /// Seconds in which the rainbow at the writing position runs red to
    /// blue and back to red. A character keeps the colour of the moment it
    /// was due, so the characters in flight show the rainbow in order at
    /// any pace, the head changes colour at one steady rate however fast
    /// the model writes, and the text behind the head never changes colour.
    /// (A colour by character position drifting at a fixed rate stood
    /// still at the head whenever the pace matched the drift.)
    static let cyclePeriod: TimeInterval = 1.2
    /// The share of `tintDuration` a character keeps its full colour
    /// before it gives way to its own.
    static let tintHold = 0.3
    /// The icon's rainbow, red to blue: for a dark background as the Aurora
    /// Orb samples it, for a light one deepened a little, as text on white
    /// needs.
    static let lightStops: [(red: Double, green: Double, blue: Double)] = [
        (0.85, 0.30, 0.26), (0.90, 0.56, 0.10), (0.86, 0.66, 0.04), (0.10, 0.60, 0.33), (0.10, 0.45, 0.90),
    ]
    static let darkStops: [(red: Double, green: Double, blue: Double)] = [
        (0.94, 0.40, 0.34), (0.97, 0.70, 0.20), (0.99, 0.78, 0.15), (0.16, 0.74, 0.41), (0.18, 0.55, 1.00),
    ]

    struct Tint: Equatable {
        var red: Double
        var green: Double
        var blue: Double
        /// How much of the colour shows over the character's own.
        var share: Double
    }

    /// The tint of a character that was due at `start`, `age` seconds
    /// after that: its colour on the rainbow, and how much of that colour
    /// still shows.
    static func tint(start: TimeInterval, age: TimeInterval, dark: Bool) -> Tint {
        var along = (start / cyclePeriod).truncatingRemainder(dividingBy: 1)
        if along < 0 { along += 1 }
        let sweep = along < 0.5 ? along * 2 : (1 - along) * 2
        let stops = dark ? darkStops : lightStops
        let position = sweep * Double(stops.count - 1)
        let at = min(Int(position), stops.count - 2)
        let mix = position - Double(at)
        let from = stops[at], to = stops[at + 1]
        let way = min(max(age / ReplyRevealBuffer.tintDuration, 0), 1)
        let share: Double
        if way <= tintHold {
            share = 1
        } else {
            let giving = (way - tintHold) / (1 - tintHold)
            share = 1 - giving * giving * (3 - 2 * giving)
        }
        return Tint(red: from.red + (to.red - from.red) * mix,
                    green: from.green + (to.green - from.green) * mix,
                    blue: from.blue + (to.blue - from.blue) * mix,
                    share: share)
    }

    /// The colour filter that mixes a tint into whatever colour a glyph is
    /// drawn in: `share` of the tint, the rest the glyph's own colour, the
    /// tint scaled by the pixel's alpha so the glyph's edges stay clean.
    static func filter(_ tint: Tint) -> ColorMatrix {
        var matrix = ColorMatrix()
        let own = Float(1 - tint.share)
        let mix = Float(tint.share)
        matrix.r1 = own
        matrix.g2 = own
        matrix.b3 = own
        matrix.r4 = mix * Float(tint.red)
        matrix.g4 = mix * Float(tint.green)
        matrix.b4 = mix * Float(tint.blue)
        return matrix
    }
}

/// Draws settled runs as they are and each character in flight by how far
/// along its own appearance it is: its start is its piece's start plus its
/// place in the piece times the piece's spacing. The characters of one
/// piece are counted across its runs (a run ends at a line break or a
/// change of style), so the schedule carries on over them; every character
/// is counted for its place on the rainbow.
private struct ReplyAppearanceRenderer: TextRenderer {
    let now: TimeInterval
    let dark: Bool

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        var piece: TimeInterval?
        var ordinal = 0
        for line in layout {
            for run in line {
                guard let mark = run[ReplyArrival.self] else {
                    context.draw(run)
                    piece = nil
                    continue
                }
                if mark.startsAt != piece {
                    piece = mark.startsAt
                    ordinal = 0
                }
                for slice in run {
                    let age = now - (mark.startsAt + Double(ordinal) * mark.spacing)
                    ordinal += 1
                    if age >= ReplyRevealBuffer.inFlight {
                        context.draw(slice)
                        continue
                    }
                    // Before its start a character is not drawn at all.
                    guard age >= 0 else { continue }
                    var copy = context
                    let progress = min(age / ReplyRevealBuffer.duration, 1)
                    if progress < 1 {
                        let remaining = 1 - progress
                        copy.opacity *= progress * progress * (3 - 2 * progress)
                        copy.translateBy(x: 0, y: ReplyRevealStyle.rise * CGFloat(remaining * remaining))
                    }
                    let tint = ReplyRevealStyle.tint(start: now - age, age: age, dark: dark)
                    if tint.share > 0.01 {
                        copy.addFilter(.colorMatrix(ReplyRevealStyle.filter(tint)))
                    }
                    copy.draw(slice)
                }
            }
        }
    }
}
