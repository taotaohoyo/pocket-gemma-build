import SwiftUI
import UIKit
import PocketCore

/// A reply block's styled text whose newly arrived characters fade in from a
/// blur while Gemma streams. Only the reply's last chunk uses it; settled
/// text is a plain `Text`. Reduce Motion and VoiceOver turn it off
/// (`MarkdownReplyView`).
struct RevealingRichText: View {
    let text: AttributedString
    let isStreaming: Bool
    @State private var buffer: ReplyRevealBuffer

    init(text: AttributedString, isStreaming: Bool) {
        self.text = text
        self.isStreaming = isStreaming
        let plain = String(text.characters)
        var initial = ReplyRevealBuffer(text: isStreaming ? "" : plain)
        if isStreaming { initial.update(plain, at: Date().timeIntervalSinceReferenceDate) }
        _buffer = State(initialValue: initial)
    }

    private var plain: String { String(text.characters) }

    /// The text split where the buffer's pieces arrived. Characters the
    /// buffer has not seen yet arrive now. Nil when the text was replaced.
    private func markedText(plain: String) -> Text? {
        let known = buffer.text
        guard plain.hasPrefix(known) else { return nil }
        let now = Date().timeIntervalSinceReferenceDate
        var cursor = text.startIndex
        func take(_ count: Int) -> AttributedString {
            let end = text.characters.index(cursor, offsetBy: count, limitedBy: text.endIndex) ?? text.endIndex
            defer { cursor = end }
            return AttributedString(text[cursor..<end])
        }
        var result = Text(take(buffer.settledText.count))
        for segment in buffer.segments {
            result = result + Text(take(segment.text.count)).customAttribute(ReplyArrival(arrivedAt: segment.arrivedAt))
        }
        if cursor < text.endIndex {
            result = result + Text(take(plain.count - known.count)).customAttribute(ReplyArrival(arrivedAt: now))
        }
        return result
    }

    var body: some View {
        let current = plain
        Group {
            if !isStreaming && buffer.segments.isEmpty && buffer.text == current {
                Text(text)
            } else if let rendered = markedText(plain: current) {
                // Build attributed text once per content update, not on every
                // animation frame of an increasingly long answer.
                TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: buffer.segments.isEmpty)) { timeline in
                    rendered.textRenderer(ReplyAppearanceRenderer(now: timeline.date.timeIntervalSinceReferenceDate))
                }
                // The selectable system text view bypasses custom rendering
                // on the tested runtime. Restore selection once the final
                // arriving characters have finished becoming clear.
                .textSelection(.disabled)
            } else {
                Text(text)
            }
        }
        .onChange(of: current) { _, newest in
            buffer.update(newest, at: Date().timeIntervalSinceReferenceDate)
        }
        .task(id: buffer.animationDeadline) {
            guard let deadline = buffer.animationDeadline else { return }
            do {
                try await Task.sleep(for: .seconds(max(0, deadline - Date().timeIntervalSinceReferenceDate)))
            } catch { return }
            buffer.settle(at: Date().timeIntervalSinceReferenceDate)
        }
    }
}

private struct ReplyArrival: TextAttribute {
    let arrivedAt: TimeInterval
}

private struct ReplyAppearanceRenderer: TextRenderer {
    let now: TimeInterval

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        for line in layout {
            for run in line {
                guard let arrival = run[ReplyArrival.self] else {
                    context.draw(run)
                    continue
                }
                let progress = min(1, max(0, (now - arrival.arrivedAt) / ReplyRevealBuffer.duration))
                let eased = progress * progress * (3 - 2 * progress)
                var copy = context
                copy.opacity *= 0.25 + 0.75 * eased
                if progress < 1 { copy.addFilter(.blur(radius: 2.8 * (1 - eased))) }
                copy.draw(run)
            }
        }
    }
}
