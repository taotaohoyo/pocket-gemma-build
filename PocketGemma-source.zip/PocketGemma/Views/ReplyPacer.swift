import Foundation

/// Lays a streaming reply's text out a step behind the model, at a steady
/// pace, so tokens that arrive in a burst (the first ones, held back while
/// the Aurora Orb shrinks away, or a batch after a stall) still read as
/// writing. The reply's text itself is untouched: the store, the archive,
/// copying and continuation keep the whole text, and only how much of it
/// is on screen trails. A reference, so the row's pacing task sees the
/// text as it grows while the row's view value is remade.
@MainActor
final class ReplyPacer {
    /// Characters per second at the least, so the display never crawls.
    static let slowest = 30.0
    /// The display aims to be this far behind the model while it writes...
    static let lagWhileWriting: TimeInterval = 1.0
    /// ...and catches up this quickly once the reply has ended.
    static let lagAfterEnd: TimeInterval = 0.3
    /// Posted when more of a reply is laid out, so the conversation follows
    /// the text as it grows, as it follows the model's text.
    static let revealed = Notification.Name("PocketAI.replyTextRevealed")

    /// The model's text so far, and whether it is still writing.
    var text: String
    var generating: Bool
    /// While the orb holds the reply's place, nothing is laid out.
    var held: Bool
    /// Characters laid out so far.
    private(set) var shown: Int
    private var carry = 0.0
    private var lastTick: TimeInterval?

    nonisolated init(text: String, generating: Bool, held: Bool, shown: Int) {
        self.text = text
        self.generating = generating
        self.held = held
        self.shown = shown
    }

    var caughtUp: Bool { shown >= text.count }

    /// Lays out more of the text for the time since the last call, and
    /// returns the new count when it changed. The pace follows the backlog,
    /// so the display stays about `lagWhileWriting` behind a model writing
    /// at any speed, and a long backlog (after the app was in the
    /// background) clears in about that time instead of crawling.
    func advance(at now: TimeInterval) -> Int? {
        // A pause does not come back as a burst.
        let elapsed = min(max(now - (lastTick ?? now), 0), 0.1)
        lastTick = now
        let total = text.count
        if shown > total {
            shown = total
            carry = 0
            return shown
        }
        let backlog = total - shown
        guard backlog > 0, !held else {
            carry = 0
            return nil
        }
        let lag = generating ? Self.lagWhileWriting : Self.lagAfterEnd
        carry += max(Self.slowest, Double(backlog) / lag) * elapsed
        let step = min(Int(carry), backlog)
        guard step > 0 else { return nil }
        carry = step < backlog ? carry - Double(step) : 0
        shown += Self.wholeSyntax(text, from: shown, step: step)
        return shown
    }

    /// Markdown and LaTeX syntax that should arrive whole: a step never ends
    /// inside a run of these, nor inside a backslash command's name, so
    /// unfinished syntax shows no more often than token streaming shows it.
    private static let syntax: Set<Character> = [
        "*", "_", "`", "$", "\\", "#", "|", "[", "]", "(", ")", "{", "}", "~", "<", ">", "!", "^",
    ]

    /// The step, extended past any syntax it would end inside.
    static func wholeSyntax(_ text: String, from shown: Int, step: Int) -> Int {
        var end = text.index(text.startIndex, offsetBy: shown + step)
        var count = step
        var command = commandBefore(text, end)
        while end < text.endIndex {
            let next = text[end]
            if syntax.contains(next) {
                command = next == "\\"
            } else if !(command && next.isLetter) {
                break
            }
            end = text.index(after: end)
            count += 1
        }
        return count
    }

    /// Whether the text just before `end` is a backslash and letters: a
    /// command still being named.
    private static func commandBefore(_ text: String, _ end: String.Index) -> Bool {
        var index = end
        var letters = 0
        while index > text.startIndex, letters < 16 {
            index = text.index(before: index)
            let character = text[index]
            if character == "\\" { return true }
            guard character.isLetter else { return false }
            letters += 1
        }
        return false
    }
}
