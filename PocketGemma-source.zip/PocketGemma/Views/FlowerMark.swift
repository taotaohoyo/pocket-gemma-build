import SwiftUI

/// Fielua's mark (brand 2026-10-27): five petals turning out from the centre,
/// warm yellow at the base fading to cream at the tips. Drawn from vectors at
/// any size: the outlines are cubic curves traced from the reference artwork
/// (/mnt/project-files/pocket-ai/redesign/reference/flower-logo.png), and each
/// petal's colour is a mesh gradient fitted to it. design/brand/ has the
/// generator that writes this file's numbers and the app icon from the same
/// data, so the icon and the mark in the app never drift apart.
///
/// Static: nothing here animates or redraws on its own.
struct FlowerMark: View {
    /// The flower's width; its height is a little less (the petals form a
    /// pentagon with one tip up).
    var size: CGFloat
    /// Below about 30pt the cream tips fade into light backgrounds and the
    /// gaps between petals close up, so small marks are drawn simpler: a
    /// deeper two-tone gradient and gaps kept at least half a point wide.
    var simplified: Bool? = nil

    var body: some View {
        let compact = simplified ?? (size < 30)
        let scale = size / FlowerGeometry.bounds.width
        ZStack(alignment: .topLeading) {
            ForEach(0..<FlowerGeometry.petals.count, id: \.self) { index in
                if compact { CompactPetal(index: index, scale: scale) }
                else { MeshPetal(index: index, scale: scale) }
            }
        }
        .frame(width: size, height: FlowerGeometry.bounds.height * scale, alignment: .topLeading)
        .accessibilityHidden(true)
    }
}

/// The mark opening, for ようこそ (brand 2026-10-27): the petals come out of
/// the centre one after another, clockwise from the top, each growing and
/// turning into its place, on Aurora Bloom's timeline (`time` in its
/// seconds). From `FlowerBloom.done` on it is the still mark; the caller
/// stops redrawing it then.
struct BloomingFlower: View {
    var size: CGFloat
    var time: TimeInterval

    var body: some View {
        let bounds = FlowerGeometry.bounds
        let scale = size / bounds.width
        let height = bounds.height * scale
        // The petals' shared base, where they turn about.
        let centre = UnitPoint(x: -bounds.minX / bounds.width, y: -bounds.minY / bounds.height)
        ZStack(alignment: .topLeading) {
            ForEach(0..<FlowerGeometry.petals.count, id: \.self) { index in
                let open = FlowerBloom.opening(petal: index, at: time)
                MeshPetal(index: index, scale: scale)
                    .frame(width: size, height: height, alignment: .topLeading)
                    .scaleEffect(FlowerBloom.seed + (1 - FlowerBloom.seed) * open.growth, anchor: centre)
                    .rotationEffect(.degrees(FlowerBloom.turn * (1 - open.growth)), anchor: centre)
                    .opacity(open.opacity)
            }
        }
        .frame(width: size, height: height, alignment: .topLeading)
        // The bud the petals come from swells as they open.
        .scaleEffect(FlowerBloom.bud(at: time), anchor: centre)
        .accessibilityHidden(true)
    }
}

/// How BloomingFlower opens. Each petal is born at a quarter of its size, a
/// third of a right angle back from its place, and opens over 1.3 s with no
/// overshoot; the next follows 0.12 s later. The whole bud starts at 45% and
/// swells to its size over 1.7 s, so the flower stays small for its first
/// second (a simulation of the outlines: 6pt across at the first petal,
/// 49pt at 1 s), is 119pt of its 132 as the wordmark comes in at 1.5 s
/// (AuroraBloom.wordmark), whole by 1.93 s, and its width only grows on
/// the way.
enum FlowerBloom {
    /// Clockwise from the top petal (FlowerGeometry.petals' order is the
    /// tracing's).
    static let order = [0, 2, 1, 3, 4]
    static let seed = 0.25
    /// Degrees each petal turns into its place, clockwise.
    static let turn = -34.0
    static let stagger: TimeInterval = 0.12
    static let span: TimeInterval = 1.3
    /// The bud's size at the start, and how long it takes to reach its own.
    static let budSeed = 0.45
    static let budSpan: TimeInterval = 1.7
    static var done: TimeInterval {
        AuroraBloom.hold + max(stagger * Double(order.count - 1) + span, budSpan)
    }

    static func bud(at time: TimeInterval) -> Double {
        let x = min(max((time - AuroraBloom.hold) / budSpan, 0), 1)
        return budSeed + (1 - budSeed) * x * x * x * (x * (x * 6 - 15) + 10)
    }

    static func opening(petal: Int, at time: TimeInterval) -> (growth: Double, opacity: Double) {
        let begin = AuroraBloom.hold + Double(order.firstIndex(of: petal) ?? petal) * stagger
        let x = min(max((time - begin) / span, 0), 1)
        let y = min(max((time - begin) / 0.35, 0), 1)
        return (x * x * x * (x * (x * 6 - 15) + 10), y * y * (3 - 2 * y))
    }
}

/// The empty chat's flower, alive (UI Phase 2, 1.1.0 (214); always moving
/// since 1.1.0 (215), when on the phone it looked almost still between
/// petals). While the empty chat shows, the whole flower breathes very
/// slowly and each petal opens and closes a little on its own slow beat
/// (FlowerLife), and now and then one petal loosens, drifts off turning in
/// the air and fades while a new one grows into its place (FlowerDrift).
/// The motion comes in over two and a half seconds and goes out over one
/// and a quarter, never starting or stopping at once.
///
/// Its budget: 30 frames a second while it breathes, 60 for the few
/// seconds a petal is in the air, and nothing at all once it has come to
/// rest: then the still FlowerMark is shown, which the resting flower
/// matches exactly. It rests while a reply is being written, a sheet covers
/// the chat, the app is not in front, in Low Power Mode or while the phone
/// is hot. With Reduce Motion it holds still.
///
/// While the person types it goes away altogether (1.1.0 (216)): the whole
/// flower shrinks a little and fades out, and once it is clear nothing is
/// drawn. When the field is empty again it grows back in from the still
/// mark and its motion comes in as on the first showing (FlowerAway).
struct LivingFlower: View {
    var size: CGFloat
    /// Settle now (a petal already in the air still lands).
    var resting = false
    /// Gone while the person types.
    var away = false

    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    /// This showing's own beats, so no two showings move alike.
    @State private var life = FlowerLife()
    @State private var swell = FlowerSwell()
    /// Drawing frames: from the moment it moves until it has settled.
    @State private var running = false
    /// `moving` as last seen, for the tasks, which keep the view as it was
    /// when they started.
    @State private var awake = false
    @State private var drift: FlowerDrift?
    @State private var drifts = 0
    @State private var lastPetal: Int?
    /// Full unless in Low Power Mode or the phone is hot (the orb's budget).
    @State private var pace = LivingFlower.currentPace

    private var still: Bool { systemReduceMotion || previewReduceMotion }
    private var moving: Bool { !still && !resting && !away && scenePhase == .active && pace == .full }

    var body: some View {
        // One view around both: a Group would give the frames and the still
        // mark each their own size and fade, and the motion taking over as
        // the flower came back started at full size and colour (1.1.0 (216),
        // the recording of run 40624292542).
        ZStack {
            if running && !still {
                TimelineView(.animation(minimumInterval: drift == nil ? FlowerLife.interval : FlowerDrift.interval)) { context in
                    #if POCKET_PREVIEW
                    let _ = LivingFlowerProbe.drew()
                    #endif
                    LiveFlower(size: size, life: life, level: swell.level(at: context.date),
                               date: context.date, drift: drift)
                }
            } else {
                FlowerMark(size: size)
            }
        }
        // Going and coming back on a spring, which carries on from where the
        // flower is: typing and deleting in turn never makes it jump.
        .scaleEffect(away && !still ? FlowerAway.scale : 1)
        .opacity(away ? 0 : 1)
        .animation(FlowerAway.animation(away: away, still: still), value: away)
        .accessibilityHidden(true)
        .onChange(of: moving, initial: true) { _, moving in
            // Nothing drawn (it was away or at rest): the motion comes in
            // from the still mark that was showing.
            if moving && !running { swell = FlowerSwell() }
            swell.turn(moving, at: .now)
            awake = moving
            if moving { running = true }
        }
        .task(id: moving) {
            guard moving else {
                // Once the motion has gone out and no petal is in the air,
                // the still mark takes over and nothing is drawn.
                do { try await Task.sleep(for: .seconds(FlowerSwell.fadeOut)) } catch { return }
                if drift == nil { running = false }
                return
            }
            var first = true
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(FlowerDrift.wait(first: first))) } catch { return }
                first = false
                guard drift == nil else { continue }
                let next = FlowerDrift(id: drifts, after: lastPetal)
                drifts += 1
                lastPetal = next.petal
                drift = next
                do { try await Task.sleep(for: .seconds(next.total)) } catch { return }
            }
        }
        // A petal in the air lands even when the flower is settling.
        .task(id: drift?.id) {
            guard let current = drift else { return }
            do { try await Task.sleep(for: .seconds(current.total)) } catch { return }
            if drift?.id == current.id {
                drift = nil
                if !awake && swell.level(at: .now) == 0 { running = false }
            }
        }
        // Once it has faded out, nothing is drawn, not even a petal in the
        // air (a change back before then cancels this).
        .task(id: away) {
            guard away else { return }
            do { try await Task.sleep(for: .seconds(FlowerAway.out)) } catch { return }
            drift = nil
            running = false
        }
        .onReceive(OrbPace.changes) { _ in pace = LivingFlower.currentPace }
        #if POCKET_PREVIEW
        .onChange(of: "running=\(running ? 1 : 0) moving=\(moving ? 1 : 0) drifts=\(drifts) away=\(away ? 1 : 0)", initial: true) { old, state in
            if old.hasPrefix("running=1") && state.hasPrefix("running=0") { LivingFlowerProbe.rests += 1 }
            LivingFlowerProbe.state = state
        }
        .onDisappear { LivingFlowerProbe.state = "running=0 moving=0 drifts=\(drifts) shown=0" }
        #endif
    }

    private static var currentPace: OrbPace {
        #if POCKET_PREVIEW
        // UI checks: Low Power Mode, which the simulator cannot turn on.
        if PreviewProbe.on("--low-power") { return .half }
        #endif
        return OrbPace.current
    }
}

#if POCKET_PREVIEW
/// UI checks: how many frames the living flower has drawn and its state,
/// read twice a second (shown by the empty chat's own sign, ChatView).
@MainActor enum LivingFlowerProbe {
    static var frames = 0
    static var state = ""
    /// How often the flower has stopped drawing.
    static var rests = 0
    static func drew() { frames += 1 }

    struct Readout: View {
        var body: some View {
            TimelineView(.periodic(from: .now, by: 0.5)) { _ in
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityLabel(Text(verbatim: "\(LivingFlowerProbe.state) rests=\(LivingFlowerProbe.rests) frames=\(LivingFlowerProbe.frames)"))
                    .accessibilityIdentifier("living-flower-probe")
            }
            .allowsHitTesting(false)
        }
    }
}
#endif

/// How the empty chat's flower goes while the person types and comes back
/// once the field is empty (1.1.0 (216)): a little smaller and clear, on a
/// spring that carries on from where it is when the person changes their
/// mind halfway. With Reduce Motion it only fades.
enum FlowerAway {
    /// Its size when gone, against its own.
    static let scale: CGFloat = 0.7
    /// Long enough for the fade to be over; then nothing is drawn.
    static let out: TimeInterval = 0.6

    static func animation(away: Bool, still: Bool) -> Animation {
        if still { return .easeInOut(duration: 0.25) }
        return away ? .smooth(duration: 0.42) : .smooth(duration: 0.65)
    }
}

/// How far the flower's motion has come in: 0 at rest (the still mark),
/// 1 in full. It eases from where it is to its new end whenever the flower
/// starts or settles, so a change halfway carries on from there.
struct FlowerSwell: Equatable {
    private var from: Double = 0
    private var to: Double = 0
    private var since: Date = .distantPast
    static let fadeIn: TimeInterval = 2.5
    static let fadeOut: TimeInterval = 1.25

    func level(at date: Date) -> Double {
        let span = (to > from ? Self.fadeIn : Self.fadeOut) * max(abs(to - from), 0.2)
        let x = min(max(date.timeIntervalSince(since) / span, 0), 1)
        return from + (to - from) * x * x * (3 - 2 * x)
    }

    mutating func turn(_ on: Bool, at date: Date) {
        let target: Double = on ? 1 : 0
        guard target != to else { return }
        from = level(at: date)
        to = target
        since = date
    }
}

/// The flower's slow life, as plain numbers of the seconds since it first
/// showed. The whole flower breathes about its centre, 4% larger and
/// smaller on a beat of 7.5 s mixed with one of 12.7 s, and leans 1.5° each
/// way on beats of 17 and 24 s. Each petal opens (reaches out 4% and turns
/// 3° outward) and closes on two beats of its own, between 5 and 13 s,
/// with its own start. None of the beats divide into another, so the
/// flower never repeats a movement in any time it is watched, and a
/// petal's tip moves at most about 3.4pt at 60pt (a simulation of the
/// outlines).
struct FlowerLife: Equatable {
    static let interval: TimeInterval = 1.0 / 30.0
    static let breath = 0.04
    static let lean = 1.5
    static let reach = 0.04
    static let open = 3.0
    private static let beats: [(Double, Double)] = [(5.3, 9.1), (6.1, 10.3), (6.7, 11.7), (5.7, 8.3), (7.1, 12.9)]

    let origin: Date
    private let starts: [Double]
    private let petalBeats: [(Double, Double)]

    static func == (a: Self, b: Self) -> Bool { a.origin == b.origin && a.starts == b.starts }

    init(origin: Date = .now) {
        self.origin = origin
        starts = (0..<14).map { _ in Double.random(in: 0...(2 * Double.pi)) }
        petalBeats = Self.beats.shuffled()
    }

    private func wave(_ seconds: Double, _ beat: Double, _ start: Int) -> Double {
        sin(2 * Double.pi * seconds / beat + starts[start])
    }

    /// The whole flower: its scale and lean about the centre.
    func breathing(at seconds: Double, level: Double) -> (scale: Double, turn: Double) {
        let breath = 0.75 * wave(seconds, 7.5, 0) + 0.25 * wave(seconds, 12.7, 1)
        let lean = 0.7 * wave(seconds, 17.3, 2) + 0.3 * wave(seconds, 23.9, 3)
        return (1 + Self.breath * breath * level, Self.lean * lean * level)
    }

    /// One petal: how far it reaches (a scale about the centre) and turns.
    func petal(_ index: Int, at seconds: Double, level: Double) -> (reach: Double, turn: Double) {
        let beats = petalBeats[index % petalBeats.count]
        let open = (0.65 * wave(seconds, beats.0, 4 + index) + 0.35 * wave(seconds, beats.1, 9 + index % 5)) * level
        return (1 + Self.reach * open, Self.open * open)
    }
}

/// One petal's leaving and its new one's growing, as plain numbers of the
/// time since `start` (flower units: the centre at 0, a petal tip at 1).
/// The leaving petal goes out along its own axis leaned to its side (so
/// the top petal drifts off to one side) with a breeze that slows, sinks
/// a little faster as it goes (barely, for the top petal, which would
/// otherwise fall back across the flower), sways across, turns its way
/// and tips over in the air, shrinking a little and fading out over its
/// second two thirds. The new petal starts at a fifth of its size in the centre
/// a moment later, turned back like ようこそ's bloom, and opens into the
/// petal's place with no overshoot. Each petal draws its own reach, sway,
/// turn and pace, so no two look the same. At night the leaving petal
/// fades sooner: half see-through, yellow over charcoal reads as a muddy
/// olive (UI check, 1.1.0 (214)).
struct FlowerDrift: Equatable {
    let id: Int
    let petal: Int
    let start: Date
    /// How long the leaving petal is in the air.
    let span: TimeInterval
    /// Which way it leans as it goes: right 1, left -1.
    let side: Double
    let reach: Double
    let fall: Double
    let sway: Double
    let phase: Double
    let turn: Double
    let tip: Double

    /// Frames while a petal is in the air (30 while the flower only
    /// breathes).
    static let interval: TimeInterval = 1.0 / 60.0
    static let regrowDelay: TimeInterval = 0.9
    static let regrowSpan: TimeInterval = 2.6
    var total: TimeInterval { max(span, Self.regrowDelay + Self.regrowSpan) }

    init(id: Int, after last: Int?, start: Date = .now) {
        self.id = id
        let others = (0..<FlowerGeometry.petals.count).filter { $0 != last }
        let chosen = others.randomElement() ?? 0
        let axis = Self.axes[chosen]
        let lean: Double = axis.dx > 0.15 ? 1 : axis.dx < -0.15 ? -1 : (Bool.random() ? 1 : -1)
        petal = chosen
        self.start = start
        side = lean
        span = Double.random(in: 3.2...3.6)
        reach = Double.random(in: 0.7...0.95)
        fall = Double.random(in: 0.45...0.7)
        sway = Double.random(in: 0.08...0.15) * (Bool.random() ? 1 : -1)
        phase = Double.random(in: 0...(2 * Double.pi))
        turn = Double.random(in: 40...75) * lean
        tip = Double.random(in: 45...65) * (Bool.random() ? 1 : -1)
    }

    /// Seconds before the next petal: 6 to 10 once the flower has started
    /// to move, then 10 to 18 between petals, for as long as the empty
    /// chat shows (at most 10 petals until 1.1.0 (215), when the flower
    /// stood still between them).
    static func wait(first: Bool) -> TimeInterval {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--living-flower-quick") { return first ? 1.5 : 2 }
        if PreviewProbe.on("--living-flower-calm") { return 60 }
        #endif
        return first ? .random(in: 6...10) : .random(in: 10...18)
    }

    /// Where each petal's tip points from the centre, and its middle (the
    /// point it turns about while in the air).
    static let axes: [CGVector] = FlowerGeometry.petals.map { points in
        let tip = points.max { $0.x * $0.x + $0.y * $0.y < $1.x * $1.x + $1.y * $1.y } ?? .zero
        let length = max((tip.x * tip.x + tip.y * tip.y).squareRoot(), 0.001)
        return CGVector(dx: tip.x / length, dy: tip.y / length)
    }
    static let middles: [CGPoint] = FlowerGeometry.petals.map { points in
        let n = CGFloat(max(points.count, 1))
        let sumX: CGFloat = points.reduce(0) { $0 + $1.x }
        let sumY: CGFloat = points.reduce(0) { $0 + $1.y }
        return CGPoint(x: sumX / n, y: sumY / n)
    }

    static func smooth(_ x: Double) -> Double {
        let x = min(max(x, 0), 1)
        return x * x * (3 - 2 * x)
    }

    struct Leaving {
        var offset: CGVector
        var turn: Double
        var tip: Double
        var scale: Double
        var opacity: Double
    }

    func leaving(at time: TimeInterval, dark: Bool = false) -> Leaving {
        let x: Double = min(max(time / span, 0), 1)
        let axisX = Double(Self.axes[petal].dx), axisY = Double(Self.axes[petal].dy)
        let leanX = axisX + side * 0.5
        let length = max((leanX * leanX + axisY * axisY).squareRoot(), 0.001)
        let wayX = leanX / length, wayY = axisY / length
        let loosen = Self.smooth(x / 0.15)
        let along: Double = 0.05 * loosen + reach * (1 - (1 - x) * (1 - x))
        let across: Double = sway * sin(Double.pi * 1.6 * x + phase) * Self.smooth(x / 0.4)
        let sink: Double = axisY < -0.5 ? 0.3 : 1
        let down: Double = fall * sink * x * x
        let dx: Double = wayX * along - wayY * across
        let dy: Double = wayY * along + wayX * across + down
        return Leaving(offset: CGVector(dx: dx, dy: dy),
                       turn: turn * Self.smooth(x),
                       tip: tip * sin(.pi * x),
                       scale: 1 + 0.04 * loosen - 0.18 * x,
                       opacity: 1 - (dark ? Self.smooth((x - 0.25) / 0.45) : Self.smooth((x - 0.3) / 0.7)))
    }

    /// The new petal: its size (from the centre), its turn back and its
    /// opacity.
    func regrowth(at time: TimeInterval) -> (scale: Double, turn: Double, opacity: Double) {
        let begin = time - Self.regrowDelay
        let x: Double = min(max(begin / Self.regrowSpan, 0), 1)
        let growth: Double = x * x * x * (x * (x * 6 - 15) + 10)
        return (0.2 + 0.8 * growth, FlowerBloom.turn * 0.5 * (1 - growth), Self.smooth(begin / 0.5))
    }
}

/// The living flower at one moment: the whole flower breathing about its
/// centre, each petal opening and closing about it, and while a petal
/// leaves, it in its own place in the stack (so nothing pops where petals
/// overlap as it starts) with the new one growing under it. At `level` 0
/// with no petal in the air it draws exactly the still FlowerMark.
private struct LiveFlower: View {
    let size: CGFloat
    let life: FlowerLife
    let level: Double
    let date: Date
    let drift: FlowerDrift?
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        let bounds = FlowerGeometry.bounds
        let scale = size / bounds.width
        let height = bounds.height * scale
        let centre = UnitPoint(x: -bounds.minX / bounds.width, y: -bounds.minY / bounds.height)
        let seconds = date.timeIntervalSince(life.origin)
        let breath = life.breathing(at: seconds, level: level)
        ZStack(alignment: .topLeading) {
            ForEach(0..<FlowerGeometry.petals.count, id: \.self) { index in
                let sway = life.petal(index, at: seconds, level: level)
                if let drift, index == drift.petal {
                    let since = date.timeIntervalSince(drift.start)
                    let grow = drift.regrowth(at: since)
                    let away = drift.leaving(at: since, dark: colorScheme == .dark)
                    let middle = FlowerDrift.middles[index]
                    let pivot = UnitPoint(x: (middle.x - bounds.minX) / bounds.width, y: (middle.y - bounds.minY) / bounds.height)
                    let axis = FlowerDrift.axes[index]
                    MeshPetal(index: index, scale: scale)
                        .frame(width: size, height: height, alignment: .topLeading)
                        .scaleEffect(CGFloat(grow.scale * sway.reach), anchor: centre)
                        .rotationEffect(.degrees(grow.turn + sway.turn), anchor: centre)
                        .opacity(grow.opacity)
                    MeshPetal(index: index, scale: scale)
                        .frame(width: size, height: height, alignment: .topLeading)
                        .scaleEffect(CGFloat(sway.reach), anchor: centre)
                        .rotationEffect(.degrees(sway.turn), anchor: centre)
                        // Tipping over about its own length, as a petal
                        // turns in the air.
                        .rotation3DEffect(.degrees(away.tip), axis: (x: axis.dx, y: axis.dy, z: 0),
                                          anchor: pivot, perspective: 0.5)
                        .rotationEffect(.degrees(away.turn), anchor: pivot)
                        .scaleEffect(CGFloat(away.scale), anchor: pivot)
                        .offset(x: away.offset.dx * scale, y: away.offset.dy * scale)
                        .opacity(away.opacity)
                } else {
                    MeshPetal(index: index, scale: scale)
                        .frame(width: size, height: height, alignment: .topLeading)
                        .scaleEffect(CGFloat(sway.reach), anchor: centre)
                        .rotationEffect(.degrees(sway.turn), anchor: centre)
                }
            }
        }
        .frame(width: size, height: height, alignment: .topLeading)
        .scaleEffect(CGFloat(breath.scale), anchor: centre)
        .rotationEffect(.degrees(breath.turn), anchor: centre)
    }
}

/// A petal filled with its fitted mesh. The mesh is laid out in a square
/// around the whole flower (its grid tilts with the petal), then masked by
/// the petal's outline.
private struct MeshPetal: View {
    let index: Int
    let scale: CGFloat
    var body: some View {
        let mesh = FlowerGeometry.meshes[index]
        let box = FlowerGeometry.meshBox
        MeshGradient(width: mesh.columns, height: mesh.rows,
                     points: mesh.points.map { SIMD2<Float>(Float(($0.x - box.minX) / box.width),
                                                            Float(($0.y - box.minY) / box.height)) },
                     colors: mesh.colors.map(FlowerGeometry.color), smoothsColors: true)
            .frame(width: box.width * scale, height: box.height * scale)
            .mask { FlowerPetalShape(index: index, frame: box).fill() }
            .offset(x: (box.minX - FlowerGeometry.bounds.minX) * scale,
                    y: (box.minY - FlowerGeometry.bounds.minY) * scale)
    }
}

/// A small petal: the base's yellow to a light yellow at the tip, out from
/// the flower's centre, with the gap to its neighbours kept open.
private struct CompactPetal: View {
    let index: Int
    let scale: CGFloat
    var body: some View {
        let box = FlowerGeometry.meshBox
        let centre = UnitPoint(x: (0 - box.minX) / box.width, y: (0 - box.minY) / box.height)
        FlowerPetalShape(index: index, frame: box)
            .fill(RadialGradient(colors: [Color(red: 0.965, green: 0.733, blue: 0.180),
                                          Theme.brandYellow, Theme.brandLight],
                                 center: centre, startRadius: 0, endRadius: box.width * scale * 0.42))
            .overlay {
                // Opens the gap between neighbours to half a point at least.
                FlowerPetalShape(index: index, frame: box)
                    .stroke(Color.black, lineWidth: max(0, 1.0 - 0.012 * box.width * scale))
                    .blendMode(.destinationOut)
            }
            .compositingGroup()
            .frame(width: box.width * scale, height: box.height * scale)
            .offset(x: (box.minX - FlowerGeometry.bounds.minX) * scale,
                    y: (box.minY - FlowerGeometry.bounds.minY) * scale)
    }
}

/// One petal's outline, in a frame laid over `frame` (flower units).
struct FlowerPetalShape: Shape {
    let index: Int
    var frame: CGRect = FlowerGeometry.bounds

    func path(in rect: CGRect) -> Path {
        let points = FlowerGeometry.petals[index]
        let sx = rect.width / frame.width, sy = rect.height / frame.height
        func place(_ p: CGPoint) -> CGPoint {
            CGPoint(x: rect.minX + (p.x - frame.minX) * sx, y: rect.minY + (p.y - frame.minY) * sy)
        }
        var path = Path()
        path.move(to: place(points[0]))
        var i = 1
        while i + 2 < points.count {
            path.addCurve(to: place(points[i + 2]), control1: place(points[i]), control2: place(points[i + 1]))
            i += 3
        }
        path.closeSubpath()
        return path
    }
}

/// The whole flower's outline (all five petals), for masks and hit shapes.
struct FlowerShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        for index in FlowerGeometry.petals.indices {
            path.addPath(FlowerPetalShape(index: index).path(in: rect))
        }
        return path
    }
}

/// 「Fielua」 in Apple's own serif (New York), as the brand's wordmark: warm
/// taupe on light backgrounds, warm cream on dark ones.
struct FieluaWordmark: View {
    var size: CGFloat
    var weight: Font.Weight = .regular
    var body: some View {
        Text(verbatim: "Fielua")
            .font(.system(size: size, weight: weight, design: .serif))
            .foregroundStyle(Theme.wordmark)
            .lineLimit(1)
            .fixedSize()
    }
}

/// The mark beside the wordmark, as on the brand board's examples: the
/// flower a little taller than the capitals, centred on the line.
struct FieluaLockup: View {
    /// The wordmark's point size.
    var size: CGFloat
    var weight: Font.Weight = .regular
    var body: some View {
        // The flower is hidden from VoiceOver; the wordmark stays the one
        // text 「Fielua」, as the title was before.
        HStack(spacing: size * 0.32) {
            FlowerMark(size: size * 1.18)
            FieluaWordmark(size: size, weight: weight)
        }
    }
}

struct PetalMesh {
    let columns: Int
    let rows: Int
    let points: [CGPoint]
    let colors: [UInt32]

    init(columns: Int, rows: Int, points: [SIMD2<Double>], colors: [UInt32]) {
        self.columns = columns; self.rows = rows
        self.points = points.map { CGPoint(x: $0.x, y: $0.y) }
        self.colors = colors
    }
}

enum FlowerGeometry {
    /// A square around the whole flower that every petal's mesh fits in.
    static let meshBox = CGRect(x: -1.18, y: -1.18, width: 2.36, height: 2.36)

    static func color(_ rgb: UInt32) -> Color {
        Color(red: Double((rgb >> 16) & 0xFF) / 255, green: Double((rgb >> 8) & 0xFF) / 255,
              blue: Double(rgb & 0xFF) / 255)
    }

    /// Each petal's outline, base first: a start point, then three points
    /// (two controls and an end) for each cubic segment. Flower units: the
    /// centre at 0, the longest petal's tip at 1, y down.
    static let petals: [[CGPoint]] = [
        [.init(x: 0.0005, y: -0.0071), .init(x: -0.0128, y: -0.0229), .init(x: -0.0061, y: -0.0577), .init(x: -0.0097, y: -0.0784), .init(x: -0.0173, y: -0.1232), .init(x: -0.0338, y: -0.1676), .init(x: -0.0566, y: -0.2068), .init(x: -0.1394, y: -0.3493), .init(x: -0.3421, y: -0.3979), .init(x: -0.3322, y: -0.5704), .init(x: -0.3235, y: -0.7219), .init(x: -0.2399, y: -0.8366), .init(x: -0.1248, y: -0.9293), .init(x: -0.0922, y: -0.9556), .init(x: -0.0479, y: -0.9995), .init(x: -0.0036, y: -1), .init(x: 0.0481, y: -1.0006), .init(x: 0.1544, y: -0.9155), .init(x: 0.1939, y: -0.8806), .init(x: 0.3271, y: -0.7628), .init(x: 0.3756, y: -0.5737), .init(x: 0.3019, y: -0.41), .init(x: 0.2784, y: -0.3578), .init(x: 0.2425, y: -0.3104), .init(x: 0.2099, y: -0.2638), .init(x: 0.1892, y: -0.2342), .init(x: 0.1701, y: -0.2032), .init(x: 0.1462, y: -0.1761), .init(x: 0.1198, y: -0.1463), .init(x: 0.0345, y: -0.0071), .init(x: 0.0005, y: -0.0071)],
        [.init(x: 0, y: 0.0084), .init(x: 0.0314, y: 0.0148), .init(x: 0.0546, y: 0.047), .init(x: 0.082, y: 0.0614), .init(x: 0.1137, y: 0.0781), .init(x: 0.148, y: 0.093), .init(x: 0.1818, y: 0.1051), .init(x: 0.3075, y: 0.15), .init(x: 0.4767, y: 0.1194), .init(x: 0.5669, y: 0.2348), .init(x: 0.6473, y: 0.3376), .init(x: 0.6479, y: 0.4784), .init(x: 0.6, y: 0.5954), .init(x: 0.5871, y: 0.6269), .init(x: 0.5743, y: 0.6709), .init(x: 0.5456, y: 0.6917), .init(x: 0.5243, y: 0.7071), .init(x: 0.458, y: 0.71), .init(x: 0.4314, y: 0.7111), .init(x: 0.1776, y: 0.7222), .init(x: -0.0353, y: 0.549), .init(x: -0.0585, y: 0.2923), .init(x: -0.0601, y: 0.2741), .init(x: -0.0554, y: 0.2569), .init(x: -0.0553, y: 0.2389), .init(x: -0.055, y: 0.191), .init(x: -0.0375, y: 0.039), .init(x: 0, y: 0.0084)],
        [.init(x: 0.0063, y: 0), .init(x: 0.0067, y: -0.0006), .init(x: 0.088, y: -0.0562), .init(x: 0.1283, y: -0.1099), .init(x: 0.2377, y: -0.2555), .init(x: 0.2816, y: -0.4142), .init(x: 0.4742, y: -0.4735), .init(x: 0.5991, y: -0.5119), .init(x: 0.726, y: -0.4524), .init(x: 0.8164, y: -0.3692), .init(x: 0.8343, y: -0.3527), .init(x: 0.8607, y: -0.3335), .init(x: 0.8698, y: -0.3102), .init(x: 0.8832, y: -0.2763), .init(x: 0.8435, y: -0.1762), .init(x: 0.828, y: -0.1426), .init(x: 0.751, y: 0.0236), .init(x: 0.5852, y: 0.1346), .init(x: 0.3993, y: 0.1264), .init(x: 0.3364, y: 0.1237), .init(x: 0.2736, y: 0.104), .init(x: 0.2139, y: 0.0854), .init(x: 0.1892, y: 0.0777), .init(x: 0.1637, y: 0.0721), .init(x: 0.139, y: 0.0643), .init(x: 0.1218, y: 0.0589), .init(x: 0.1067, y: 0.0486), .init(x: 0.0891, y: 0.0435), .init(x: 0.0798, y: 0.0409), .init(x: 0.0694, y: 0.0442), .init(x: 0.0606, y: 0.0404), .init(x: 0.0454, y: 0.0337), .init(x: 0.0108, y: 0.0155), .init(x: 0.0063, y: 0)],
        [.init(x: -0.0088, y: 0.0036), .init(x: -0.0049, y: 0.0199), .init(x: -0.028, y: 0.0402), .init(x: -0.0357, y: 0.0553), .init(x: -0.0555, y: 0.0943), .init(x: -0.0692, y: 0.1348), .init(x: -0.0759, y: 0.1783), .init(x: -0.0948, y: 0.3002), .init(x: -0.04, y: 0.4082), .init(x: -0.0603, y: 0.492), .init(x: -0.0743, y: 0.5496), .init(x: -0.1257, y: 0.5924), .init(x: -0.1711, y: 0.6252), .init(x: -0.2515, y: 0.6834), .init(x: -0.3595, y: 0.7041), .init(x: -0.4563, y: 0.7041), .init(x: -0.4892, y: 0.7041), .init(x: -0.5447, y: 0.7062), .init(x: -0.5637, y: 0.6738), .init(x: -0.612, y: 0.5914), .init(x: -0.6411, y: 0.4916), .init(x: -0.6325, y: 0.3957), .init(x: -0.6135, y: 0.1851), .init(x: -0.4213, y: 0.0201), .init(x: -0.2175, y: 0.0014), .init(x: -0.1865, y: -0.0014), .init(x: -0.1557, y: -0.0134), .init(x: -0.1248, y: -0.0149), .init(x: -0.1183, y: -0.0152), .init(x: -0.113, y: -0.0123), .init(x: -0.107, y: -0.0106), .init(x: -0.0807, y: -0.0035), .init(x: -0.0548, y: -0.0089), .init(x: -0.0285, y: -0.0045), .init(x: -0.0211, y: -0.0033), .init(x: -0.0149, y: -0.0007), .init(x: -0.0088, y: 0.0036)],
        [.init(x: -0.0065, y: -0.0036), .init(x: -0.0122, y: -0.002), .init(x: -0.1135, y: -0.028), .init(x: -0.1355, y: -0.03), .init(x: -0.2064, y: -0.0364), .init(x: -0.2777, y: -0.0201), .init(x: -0.3423, y: 0.0083), .init(x: -0.3994, y: 0.0333), .init(x: -0.4501, y: 0.0735), .init(x: -0.5134, y: 0.083), .init(x: -0.65, y: 0.1035), .init(x: -0.7642, y: -0.0127), .init(x: -0.82, y: -0.123), .init(x: -0.8415, y: -0.1655), .init(x: -0.8947, y: -0.2829), .init(x: -0.8647, y: -0.3244), .init(x: -0.8437, y: -0.3535), .init(x: -0.8153, y: -0.3757), .init(x: -0.7879, y: -0.3981), .init(x: -0.6406, y: -0.5183), .init(x: -0.4391, y: -0.4977), .init(x: -0.2888, y: -0.3926), .init(x: -0.2284, y: -0.3504), .init(x: -0.1804, y: -0.292), .init(x: -0.1355, y: -0.2347), .init(x: -0.1079, y: -0.1996), .init(x: -0.0021, y: -0.0392), .init(x: -0.0065, y: -0.0036)],
    ]

    /// Each petal's colour: a grid laid along the petal (rows from base to
    /// tip, columns across), in flower units, and its colours (sRGB 0-255),
    /// fitted to the reference artwork.
    static let meshes: [PetalMesh] = [
        PetalMesh(columns: 5, rows: 6,
                  points: [.init(-0.3606, 0.0143), .init(-0.1711, 0.0136), .init(0.0185, 0.013), .init(0.2081, 0.0123), .init(0.3977, 0.0116), .init(-0.3614, -0.1924), .init(-0.1718, -0.1931), .init(0.0178, -0.1937), .init(0.2074, -0.1944), .init(0.3969, -0.1951), .init(-0.3621, -0.3991), .init(-0.1725, -0.3997), .init(0.0171, -0.4004), .init(0.2066, -0.4011), .init(0.3962, -0.4018), .init(-0.3628, -0.6058), .init(-0.1733, -0.6064), .init(0.0163, -0.6071), .init(0.2059, -0.6078), .init(0.3955, -0.6085), .init(-0.3636, -0.8124), .init(-0.174, -0.8131), .init(0.0156, -0.8138), .init(0.2052, -0.8145), .init(0.3947, -0.8151), .init(-0.3643, -1.0191), .init(-0.1747, -1.0198), .init(0.0148, -1.0205), .init(0.2044, -1.0212), .init(0.394, -1.0218)],
                  colors: [0xF7CA66, 0xF7C555, 0xF7C85A, 0xF9E8BF, 0xFAFBFD, 0xF9D37C, 0xF8CA5E, 0xF8C241, 0xFAEBC7, 0xFAFCFF, 0xFCE2A0, 0xFCD87B, 0xFBCD59, 0xFAE8C2, 0xF9F9FF, 0xFCE29D, 0xFDE090, 0xFDDD88, 0xF9E5B7, 0xF8F0E7, 0xFCDE8F, 0xFDE297, 0xFEE9AF, 0xFCE8B8, 0xF9ECD3, 0xFCE092, 0xFDE6A3, 0xFEEFC3, 0xFDEEC8, 0xFBEED3]),
        PetalMesh(columns: 5, rows: 6,
                  points: [.init(0.2407, -0.2089), .init(0.1022, -0.0986), .init(-0.0362, 0.0117), .init(-0.1747, 0.122), .init(-0.3132, 0.2323), .init(0.3549, -0.0656), .init(0.2164, 0.0447), .init(0.0779, 0.155), .init(-0.0605, 0.2653), .init(-0.199, 0.3756), .init(0.469, 0.0777), .init(0.3305, 0.188), .init(0.1921, 0.2983), .init(0.0536, 0.4086), .init(-0.0849, 0.5189), .init(0.5832, 0.2209), .init(0.4447, 0.3313), .init(0.3062, 0.4416), .init(0.1678, 0.5519), .init(0.0293, 0.6622), .init(0.6973, 0.3642), .init(0.5589, 0.4745), .init(0.4204, 0.5849), .init(0.2819, 0.6952), .init(0.1435, 0.8055), .init(0.8115, 0.5075), .init(0.673, 0.6178), .init(0.5345, 0.7281), .init(0.3961, 0.8385), .init(0.2576, 0.9488)],
                  colors: [0xF0A000, 0xF4B421, 0xFBE5B2, 0xFBFFFF, 0xFBFFFF, 0xEEA200, 0xF1AB0C, 0xF9D682, 0xFAF9FD, 0xFAFFFF, 0xEEB63B, 0xF0B635, 0xFAD579, 0xFBEED0, 0xFAF8F8, 0xF4CD72, 0xF6CE70, 0xFCDE91, 0xFBE9BE, 0xF8EFDE, 0xF7DA93, 0xF9DB92, 0xFADF9F, 0xF7E4BA, 0xF5E8CF, 0xF6DA96, 0xF5D78F, 0xF4D692, 0xF2DCAE, 0xF2E1C2]),
        PetalMesh(columns: 5, rows: 6,
                  points: [.init(-0.1201, -0.2922), .init(-0.0648, -0.137), .init(-0.0095, 0.0181), .init(0.0458, 0.1733), .init(0.1012, 0.3284), .init(0.0606, -0.3566), .init(0.116, -0.2015), .init(0.1713, -0.0463), .init(0.2266, 0.1088), .init(0.282, 0.264), .init(0.2414, -0.4211), .init(0.2968, -0.266), .init(0.3521, -0.1108), .init(0.4074, 0.0443), .init(0.4627, 0.1995), .init(0.4222, -0.4856), .init(0.4776, -0.3304), .init(0.5329, -0.1753), .init(0.5882, -0.0201), .init(0.6435, 0.135), .init(0.603, -0.5501), .init(0.6584, -0.3949), .init(0.7137, -0.2397), .init(0.769, -0.0846), .init(0.8243, 0.0706), .init(0.7838, -0.6145), .init(0.8392, -0.4594), .init(0.8945, -0.3042), .init(0.9498, -0.1491), .init(1.0051, 0.0061)],
                  colors: [0xEFAD19, 0xF2B52C, 0xF9D27B, 0xFEFFFF, 0xFFFFFF, 0xF0B42B, 0xF2B221, 0xF8C346, 0xFDF9F1, 0xFFFFFF, 0xF4C962, 0xF4C046, 0xF9CC60, 0xFAECD2, 0xFCFEFF, 0xFADA8B, 0xF9D275, 0xF9D98C, 0xF8E9CE, 0xF9F4EB, 0xFDE8B0, 0xFCE4A7, 0xFAE2AB, 0xF6E3C2, 0xF6E9D5, 0xFFF3CB, 0xFFF1C8, 0xFCEABD, 0xF6E3BE, 0xF4E4C8]),
        PetalMesh(columns: 5, rows: 6,
                  points: [.init(0.2461, 0.1828), .init(0.1119, 0.0749), .init(-0.0223, -0.0329), .init(-0.1565, -0.1407), .init(-0.2907, -0.2486), .init(0.1304, 0.3267), .init(-0.0038, 0.2189), .init(-0.138, 0.1111), .init(-0.2722, 0.0032), .init(-0.4064, -0.1046), .init(0.0148, 0.4707), .init(-0.1194, 0.3629), .init(-0.2536, 0.255), .init(-0.3878, 0.1472), .init(-0.522, 0.0394), .init(-0.1009, 0.6146), .init(-0.2351, 0.5068), .init(-0.3693, 0.399), .init(-0.5035, 0.2911), .init(-0.6377, 0.1833), .init(-0.2166, 0.7586), .init(-0.3508, 0.6508), .init(-0.485, 0.5429), .init(-0.6192, 0.4351), .init(-0.7534, 0.3273), .init(-0.3322, 0.9026), .init(-0.4665, 0.7947), .init(-0.6007, 0.6869), .init(-0.7349, 0.5791), .init(-0.8691, 0.4712)],
                  colors: [0xF2AE12, 0xF6BB31, 0xFBD576, 0xFEF1CA, 0xFFFEF4, 0xF2B019, 0xF6BA2B, 0xFCD061, 0xFDEEC2, 0xFEFAEE, 0xF4BD3A, 0xF9C74B, 0xFCDB86, 0xFCEBC6, 0xFBF5E9, 0xFACF63, 0xFCD97B, 0xFBE4B0, 0xF8EBD3, 0xF8EFE2, 0xFADA83, 0xF9DC94, 0xF5E2BF, 0xF4E6CF, 0xF4E9DA, 0xF9DE99, 0xF6DFAB, 0xF2E2C6, 0xF1E4D1, 0xF1E6D8]),
        PetalMesh(columns: 5, rows: 6,
                  points: [.init(-0.0983, 0.3184), .init(-0.0423, 0.1586), .init(0.0138, -0.0011), .init(0.0699, -0.1608), .init(0.126, -0.3205), .init(-0.2815, 0.2541), .init(-0.2254, 0.0943), .init(-0.1693, -0.0654), .init(-0.1133, -0.2251), .init(-0.0572, -0.3848), .init(-0.4646, 0.1898), .init(-0.4086, 0.03), .init(-0.3525, -0.1297), .init(-0.2964, -0.2894), .init(-0.2404, -0.4491), .init(-0.6478, 0.1255), .init(-0.5917, -0.0343), .init(-0.5357, -0.194), .init(-0.4796, -0.3537), .init(-0.4235, -0.5134), .init(-0.831, 0.0612), .init(-0.7749, -0.0985), .init(-0.7188, -0.2583), .init(-0.6627, -0.418), .init(-0.6067, -0.5777), .init(-1.0141, -0.0031), .init(-0.958, -0.1628), .init(-0.902, -0.3226), .init(-0.8459, -0.4823), .init(-0.7898, -0.642)],
                  colors: [0xF2AF14, 0xF0B326, 0xEDBB4C, 0xEDCC87, 0xEED8AC, 0xF5B723, 0xF5BB31, 0xF4C14C, 0xF2D496, 0xF2DFBD, 0xF7C445, 0xF9CC5B, 0xFBDA8C, 0xF5E0B8, 0xF5E8D2, 0xF8CE6A, 0xFBDA8C, 0xFAE9C6, 0xF5E5C9, 0xF6EAD4, 0xF8D786, 0xF9DFA0, 0xF8E9CC, 0xF5E5C8, 0xF6E8CE, 0xF8DB95, 0xF8E1AA, 0xF7E8CA, 0xF5E6CC, 0xF6E7CE]),
    ]

    /// The flower's bounding box in flower units.
    static let bounds = CGRect(x: -0.8737, y: -1, width: 1.7462, height: 1.7116)
}
