import Foundation
import Network
import Security
import UIKit
import PocketCore

// PCと接続 (1.1.0 (253), the user's directive of 2026-11-01 「Windows・
// iPhone間のローカルAI接続」): a chat answered by a model on the person's
// Windows PC, through Fielua for Windows on the same LAN. Here are the
// connection, the registration and the PC's list; the numbers and the
// turns sent are PocketCore's (PCLink). In Views, so the UI preview, which
// compiles Views alone, talks to a PC (the pc-link UI check's stand-in)
// exactly as the app does.
//
// Safety, as the directive asks:
// - TLS 1.3 to the PC's own certificate, accepted only when its SHA-256 is
//   the one the QR code carried, or for a connection code the one the PC
//   showed first, which the six digits on both screens confirm (PCLink).
// - Nothing is asked before the PC's person approves this iPhone on the
//   PC; the token it then gives is kept in the keychain on this device
//   only (never synced, never logged) and is void once either side
//   removes the registration.
// - Same LAN only: the PC's local addresses and its mDNS name. Nothing goes
//   through the internet, and no PC is asked anything until the person
//   registers it.

/// What can go wrong talking to the PC, in words for the chat and the page.
enum PCLinkError: LocalizedError, Equatable {
    case notPaired
    case unreachable
    case wrongPC
    case revoked
    case pairingClosed
    case pairingBusy
    case badCode
    case staleQR
    case locked
    case tooManyAttempts
    case expired
    case denied
    case tampered
    case notSaved
    case modelMissing(String)
    case engine(kind: String, detail: String)
    case badResponse(Int)
    case lost

    var errorDescription: String? {
        switch self {
        case .notPaired:
            return String(localized: "PCが登録されていません。設定の「PCと接続」から登録してください。")
        case .unreachable:
            return String(localized: "PCに接続できません。PCの電源、Fielua for Windowsの「デバイスと接続」、同じWi-Fiにいるかを確かめてください。")
        case .wrongPC:
            return String(localized: "登録したPCと証明書が違うため、接続をやめました。")
        case .revoked:
            return String(localized: "PCでこのiPhoneの登録が削除されました。設定の「PCと接続」からもう一度登録してください。")
        case .pairingClosed:
            return String(localized: "PCのFieluaで「iPhone を追加」を押してから、もう一度お試しください。")
        case .pairingBusy:
            return String(localized: "PCはほかの端末の登録を受け付けています。少し待ってからお試しください。")
        case .badCode:
            return String(localized: "接続コードが違います。PCの画面の8けたの数字を確かめてください。")
        case .staleQR:
            return String(localized: "このQRコードは使えなくなっています。PCで「iPhone を追加」を押し直して、新しいQRコードを読み取ってください。")
        case .locked:
            return String(localized: "接続コードを何度も間違えたため、PCが登録を止めました。PCで「iPhone を追加」をやり直してください。")
        case .tooManyAttempts:
            return String(localized: "試した回数が多すぎます。10分ほど待ってからお試しください。")
        case .expired:
            return String(localized: "登録の時間が切れました。PCで「iPhone を追加」をやり直してください。")
        case .denied:
            return String(localized: "PCで登録が拒否されました。")
        case .tampered:
            return String(localized: "PCの応答が正しくないため、登録をやめました。")
        case .notSaved:
            return String(localized: "登録の情報をこのiPhoneに保存できませんでした。もう一度お試しください。")
        case .modelMissing(let name):
            return String(localized: "PCに\(name)が見つかりません。PCのFieluaでモデルを確かめてください。")
        case .engine(let kind, let detail):
            let lead: String
            switch kind {
            case "notRunning": lead = String(localized: "PCでOllamaを起動できませんでした。PCのFieluaを確かめてください。")
            case "outOfMemory": lead = String(localized: "PCのメモリが足りず、モデルを読み込めませんでした。小さいモデルをお試しください。")
            case "loadFailed": lead = String(localized: "PCでモデルを読み込めませんでした。")
            case "modelNotFound": lead = String(localized: "PCにこのモデルが見つかりません。PCのFieluaでモデルを確かめてください。")
            case "cloudRefused": lead = String(localized: "クラウドのモデルは使えません。PCにあるモデルを選んでください。")
            default: lead = String(localized: "PCで返信を作れませんでした。")
            }
            let shown = String(detail.trimmingCharacters(in: .whitespacesAndNewlines).prefix(200))
            return shown.isEmpty || kind == "cloudRefused" ? lead : lead + "\n" + shown
        case .badResponse(let status):
            return String(localized: "PCから予期しない応答がありました（\(status)）。")
        case .lost:
            return String(localized: "PCとの接続が切れました。ここまでの返信は残しています。")
        }
    }
}

/// Checks the PC by its certificate's SHA-256, as Fielua for Windows makes
/// its own (no certificate authority can vouch for a PC at home). With no
/// fingerprint yet (a connection code), the first one seen is kept, and
/// the six digits on both screens say whether it was the PC's.
final class PCLinkTrust: NSObject, URLSessionDelegate, @unchecked Sendable {
    private let lock = NSLock()
    private var pinned: Data?
    private var lastSeen: Data?
    private var lastRefused = false

    init(pinned: Data?) { self.pinned = pinned }

    var seen: Data? { lock.withLock { lastSeen } }
    var refused: Bool { lock.withLock { lastRefused } }
    func pin(_ fingerprint: Data) { lock.withLock { pinned = fingerprint } }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge) async
        -> (URLSession.AuthChallengeDisposition, URLCredential?) {
        guard challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let trust = challenge.protectionSpace.serverTrust,
              let leaf = (SecTrustCopyCertificateChain(trust) as? [SecCertificate])?.first else {
            return (.cancelAuthenticationChallenge, nil)
        }
        let fingerprint = PCLink.sha256(SecCertificateCopyData(leaf) as Data)
        let accepted: Bool = lock.withLock {
            lastSeen = fingerprint
            lastRefused = pinned.map { $0 != fingerprint } ?? false
            return !lastRefused
        }
        return accepted ? (.useCredential, URLCredential(trust: trust)) : (.cancelAuthenticationChallenge, nil)
    }
}

/// HTTPS to one PC: every request over TLS 1.3 to the certificate
/// PCLinkTrust accepts. Ephemeral: no cookies, cache or stored credentials.
final class PCLinkConnection: @unchecked Sendable {
    let trust: PCLinkTrust
    private let session: URLSession

    init(pinned: Data?) {
        trust = PCLinkTrust(pinned: pinned)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.tlsMinimumSupportedProtocolVersion = .TLSv13
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        configuration.waitsForConnectivity = false
        // A reply streams for minutes; the PC sends a line at least every
        // 5 seconds, so a minute and a half of silence is a lost PC.
        configuration.timeoutIntervalForRequest = 90
        configuration.timeoutIntervalForResource = 60 * 60
        // Only the Wi-Fi or wired LAN: never over cellular to an address
        // that happens to match.
        configuration.allowsCellularAccess = false
        session = URLSession(configuration: configuration, delegate: trust, delegateQueue: nil)
    }

    /// Ends the connection's requests; the session lets go of its delegate.
    func close() { session.invalidateAndCancel() }

    static func url(host: String, port: Int, path: String) -> URL? {
        var components = URLComponents()
        components.scheme = "https"
        components.host = host
        components.port = port
        components.path = path
        return components.url
    }

    private func request(host: String, port: Int, method: String, path: String, body: [String: Any]?,
                         token: String?, timeout: TimeInterval) throws -> URLRequest {
        guard let url = Self.url(host: host, port: port, path: path) else { throw PCLinkError.unreachable }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = method
        if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    /// One request and its JSON answer, whatever its status.
    func call(host: String, port: Int, _ method: String, _ path: String, body: [String: Any]? = nil,
              token: String? = nil, timeout: TimeInterval = 10) async throws -> (status: Int, json: [String: Any]) {
        let request = try request(host: host, port: port, method: method, path: path, body: body, token: token, timeout: timeout)
        do {
            let (data, response) = try await session.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            return (status, (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        } catch {
            throw mapped(error, streaming: false)
        }
    }

    /// A reply as the PC streams it, a line at a time, until it ends.
    func stream(host: String, port: Int, path: String, body: [String: Any], token: String,
                onLine: (String) async throws -> Bool) async throws {
        let request = try request(host: host, port: port, method: "POST", path: path, body: body, token: token, timeout: 90)
        let bytes: URLSession.AsyncBytes
        let response: URLResponse
        do { (bytes, response) = try await session.bytes(for: request) } catch { throw mapped(error, streaming: false) }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else {
            var data = Data()
            do {
                for try await byte in bytes {
                    data.append(byte)
                    if data.count > 16 * 1024 { break }
                }
            } catch { throw mapped(error, streaming: false) }
            throw Self.failure(status, (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        }
        do {
            for try await line in bytes.lines {
                if try await onLine(line) { return }
            }
        } catch let error as PCLinkError {
            throw error
        } catch {
            throw mapped(error, streaming: true)
        }
        // The stream ended without its last line: the PC went away.
        throw PCLinkError.lost
    }

    private func mapped(_ error: Error, streaming: Bool) -> Error {
        if error is CancellationError || Task.isCancelled { return CancellationError() }
        let error = error as NSError
        guard error.domain == NSURLErrorDomain else { return error }
        // A certificate PCLinkTrust turned away ends the request as cancelled.
        let refusals = [NSURLErrorCancelled, NSURLErrorSecureConnectionFailed, NSURLErrorServerCertificateUntrusted,
                        NSURLErrorServerCertificateHasUnknownRoot, NSURLErrorServerCertificateHasBadDate,
                        NSURLErrorServerCertificateNotYetValid]
        if trust.refused, refusals.contains(error.code) { return PCLinkError.wrongPC }
        return streaming ? PCLinkError.lost : PCLinkError.unreachable
    }

    /// A refusal in the PC's words ({"error": code}) as the person's.
    static func failure(_ status: Int, _ json: [String: Any]) -> PCLinkError {
        switch json["error"] as? String {
        case "pairingClosed": return .pairingClosed
        case "busy": return .pairingBusy
        case "badCredential": return .badCode
        case "locked": return .locked
        case "noSession": return .expired
        case "unauthorized": return .revoked
        case "tooManyAttempts": return .tooManyAttempts
        case "engine":
            let engine = json["engine"] as? [String: Any]
            return .engine(kind: engine?["kind"] as? String ?? "other", detail: engine?["detail"] as? String ?? "")
        default: return status == 401 ? .revoked : .badResponse(status)
        }
    }
}

/// The registered PC, kept whole in the keychain on this device only: it
/// holds the token. Not synced to the person's other devices, which would
/// each need the PC's own approval.
enum PCLinkKeychain {
    private static var item: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.pc-link",
         kSecAttrAccount as String: "paired-pc",
         kSecAttrSynchronizable as String: kCFBooleanFalse as Any]
    }

    static func load() -> PCPairedPC? {
        var query = item
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return try? JSONDecoder().decode(PCPairedPC.self, from: data)
    }

    static func save(_ pc: PCPairedPC) -> Bool {
        guard let data = try? JSONEncoder().encode(pc) else { return false }
        delete()
        var entry = item
        entry[kSecValueData as String] = data
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
    }

    static func delete() {
        SecItemDelete(item as CFDictionary)
    }
}

/// The registered PC, its models and whether it answers, for the views and
/// both ChatStores. One PC at a time: registering another replaces it.
@MainActor final class PCLinkStore: ObservableObject {
    static let shared = PCLinkStore()

    enum Connection: Equatable {
        /// No PC registered.
        case none
        case checking
        /// It answered at this address.
        case connected(host: String)
        case unreachable
        /// The PC removed this iPhone; the registration here is void.
        case revoked
        /// Another certificate answered at the PC's address.
        case wrongPC
    }

    @Published private(set) var paired: PCPairedPC?
    @Published private(set) var models: [PCModel] = []
    @Published private(set) var connection: Connection = .none
    /// The PC's Ollama was running at the last check; nil before one.
    @Published private(set) var engineRunning: Bool?
    @Published private(set) var lastChecked: Date?
    private var link: PCLinkConnection?
    private var refreshing: Task<Void, Never>?
    /// Which check `refreshing` is: one for a PC no longer registered ends
    /// without touching the next.
    private var refreshID = 0
    private var activeHost: String?

    private init() {
        #if POCKET_PREVIEW
        // The pc-link UI check starts with no PC registered.
        if ProcessInfo.processInfo.arguments.contains("--pc-link-reset") { PCLinkKeychain.delete() }
        #endif
        adopt(PCLinkKeychain.load())
    }

    var isPaired: Bool { paired != nil }
    var isConnected: Bool { if case .connected = connection { return true } else { return false } }

    private func adopt(_ pc: PCPairedPC?) {
        refreshing?.cancel()
        refreshing = nil
        refreshID += 1
        link?.close()
        link = pc.flatMap { PCLink.data(base64URL: $0.fingerprint) }.map { PCLinkConnection(pinned: $0) }
        paired = pc
        activeHost = nil
        engineRunning = nil
        lastChecked = nil
        connection = pc == nil ? .none : .checking
        models = pc.map { Self.cachedModels(for: $0.pcID) } ?? []
    }

    // MARK: Models, kept between launches (names only, nothing secret)

    private static func modelsKey(_ pcID: String) -> String { "fielua.pcLink.models.\(pcID)" }

    private static func cachedModels(for pcID: String) -> [PCModel] {
        guard let data = UserDefaults.standard.data(forKey: modelsKey(pcID)) else { return [] }
        return (try? JSONDecoder().decode([PCModel].self, from: data)) ?? []
    }

    private func keepModels(_ list: [PCModel], for pcID: String) {
        models = list
        if let data = try? JSONEncoder().encode(list) { UserDefaults.standard.set(data, forKey: Self.modelsKey(pcID)) }
    }

    // MARK: Checking the PC

    /// Asks the PC how it is and for its models. Called when 設定 › PCと接続
    /// or the chat shows, and when the app comes forward.
    func refresh() {
        guard paired != nil, refreshing == nil else { return }
        refreshID += 1
        let id = refreshID
        refreshing = Task { [weak self] in
            await self?.check()
            if self?.refreshID == id { self?.refreshing = nil }
        }
    }

    private func check() async {
        guard let pc = paired, let link else { return }
        if !isConnected { connection = .checking }
        do {
            let host = try await reachableHost(pc, link: link)
            let (status, json) = try await link.call(host: host, port: pc.port, "GET", "/v1/models", token: pc.token, timeout: 20)
            guard paired?.pcID == pc.pcID else { return }
            lastChecked = Date()
            if status == 200 {
                let list = (json["models"] as? [[String: Any]] ?? []).compactMap(Self.model)
                keepModels(list, for: pc.pcID)
                engineRunning = true
            } else {
                let failure = PCLinkConnection.failure(status, json)
                if failure == .revoked { revoked(); return }
                engineRunning = false
            }
        } catch {
            guard paired?.pcID == pc.pcID else { return }
            lastChecked = Date()
            settle(error)
        }
    }

    private static func model(_ json: [String: Any]) -> PCModel? {
        guard let name = json["name"] as? String, !name.isEmpty else { return nil }
        return PCModel(name: name, sizeBytes: (json["sizeBytes"] as? NSNumber)?.int64Value ?? 0,
                       family: json["family"] as? String, parameterSize: json["parameterSize"] as? String,
                       quantization: json["quantization"] as? String)
    }

    /// The first address that answers as the PC, the last that did first,
    /// then the others the PC gave and its mDNS name.
    private func reachableHost(_ pc: PCPairedPC, link: PCLinkConnection) async throws -> String {
        var hosts = pc.candidateHosts
        if let activeHost, let index = hosts.firstIndex(of: activeHost) { hosts.swapAt(0, index) }
        var lastError: Error = PCLinkError.unreachable
        for host in hosts {
            try Task.checkCancellation()
            do {
                let (status, json) = try await link.call(host: host, port: pc.port, "GET", "/v1/status", token: pc.token, timeout: 4)
                guard status == 200 else {
                    let failure = PCLinkConnection.failure(status, json)
                    if failure == .revoked { throw failure }
                    lastError = failure
                    continue
                }
                // Another Fielua for Windows on the same address is not this PC.
                if let id = json["pcId"] as? String, id != pc.pcID { lastError = PCLinkError.wrongPC; continue }
                answered(host, json: json)
                return host
            } catch PCLinkError.wrongPC {
                lastError = PCLinkError.wrongPC
            } catch PCLinkError.unreachable {
                continue
            }
        }
        throw lastError
    }

    private func answered(_ host: String, json: [String: Any]) {
        activeHost = host
        connection = .connected(host: host)
        if let engine = json["engine"] as? [String: Any] { engineRunning = engine["running"] as? Bool }
        guard var pc = paired, pc.hosts.first != host else { return }
        pc.answered(at: host)
        if let name = json["pcName"] as? String, !name.isEmpty { pc.pcName = String(name.prefix(60)) }
        if PCLinkKeychain.save(pc) { paired = pc }
    }

    private func settle(_ error: Error) {
        switch error {
        case PCLinkError.revoked: revoked()
        case PCLinkError.wrongPC: connection = .wrongPC
        case is CancellationError: break
        default: connection = .unreachable
        }
    }

    /// The PC no longer knows this iPhone: the token is void, so it goes.
    private func revoked() {
        PCLinkKeychain.delete()
        adopt(nil)
        connection = .revoked
    }

    // MARK: Registering and removing

    /// Keeps a PC the person registered (PCPairing), in place of any other.
    func register(_ pc: PCPairedPC) -> Bool {
        // The PC's earlier entry for this iPhone, or another PC's, is voided.
        if let old = paired, old.token != pc.token { forget(old) }
        guard PCLinkKeychain.save(pc) else { return false }
        adopt(pc)
        refresh()
        return true
    }

    /// 接続を解除: the PC is told to forget this iPhone when it answers, and
    /// the registration goes here at once either way. The chats stay.
    func unpair() {
        guard let pc = paired else { return }
        forget(pc)
        PCLinkKeychain.delete()
        UserDefaults.standard.removeObject(forKey: Self.modelsKey(pc.pcID))
        adopt(nil)
    }

    /// Tells the PC to void this iPhone's token, if it answers soon.
    private func forget(_ pc: PCPairedPC) {
        guard let fingerprint = PCLink.data(base64URL: pc.fingerprint) else { return }
        let link = PCLinkConnection(pinned: fingerprint)
        let hosts = Array(pc.candidateHosts.prefix(3))
        Task.detached {
            for host in hosts {
                let answer = try? await link.call(host: host, port: pc.port, "POST", "/v1/unpair", token: pc.token, timeout: 4)
                if let answer, answer.status == 200 || answer.status == 401 { break }
            }
            link.close()
        }
    }

    // MARK: Replies

    enum ReplyProgress {
        /// The PC is starting Ollama.
        case starting
        /// The model is loading or reading the question.
        case loading
        /// The model thinks before it answers (its thinking is not shown).
        case thinking
        /// Still working, nothing new to show.
        case alive
    }

    /// One reply from the chat's model on the PC, streamed to `onText`.
    /// Throws PCLinkError, or CancellationError when stopped here.
    func reply(target: PCChatTarget, turns: [PCTurn], requestID: String,
               onProgress: @escaping (ReplyProgress) async -> Void,
               onText: @escaping (String) async -> Void) async throws {
        guard let pc = paired, pc.pcID == target.pcID, let link else { throw PCLinkError.notPaired }
        let host: String
        do { host = try await reachableHost(pc, link: link) } catch { settle(error); throw error }
        let body: [String: Any] = [
            "requestId": requestID,
            "model": target.model,
            "messages": turns.map { ["role": $0.role, "content": $0.content] },
        ]
        var answered = false
        do {
            try await link.stream(host: host, port: pc.port, path: "/v1/chat", body: body, token: pc.token) { line in
                guard let event = PCChatEvent(line: line) else { return false }
                switch event {
                case .started:
                    await onProgress(.loading)
                case .waiting(let stage):
                    await onProgress(stage == "starting" ? .starting : .alive)
                case .delta(let content, let thinking):
                    if !content.isEmpty {
                        answered = true
                        await onText(content)
                    } else if !thinking.isEmpty, !answered {
                        await onProgress(.thinking)
                    } else {
                        await onProgress(.alive)
                    }
                case .done:
                    return true
                case .stopped:
                    throw CancellationError()
                case .failed(let kind, let detail):
                    if kind == "modelNotFound" { throw PCLinkError.modelMissing(target.shortModel) }
                    if kind == "cancelled" { throw CancellationError() }
                    throw PCLinkError.engine(kind: kind, detail: detail)
                }
                return false
            }
            connection = .connected(host: host)
        } catch {
            if case PCLinkError.revoked = error { revoked() }
            if case PCLinkError.wrongPC = error { connection = .wrongPC }
            if case PCLinkError.lost = error { connection = .unreachable; activeHost = nil }
            throw error
        }
    }

    /// Asks the PC to stop a reply; the stream then ends with "stopped".
    /// The reply's task is cancelled as well, which the PC sees as the
    /// connection closing and stops too, should this not reach it.
    func cancel(requestID: String) {
        guard let pc = paired, let link, let host = activeHost else { return }
        Task.detached {
            _ = try? await link.call(host: host, port: pc.port, "POST", "/v1/chat/cancel",
                                     body: ["requestId": requestID], token: pc.token, timeout: 4)
        }
    }

    /// The model's line under its name: its size and quantization.
    static func detail(_ model: PCModel) -> String {
        var parts: [String] = []
        if let size = model.parameterSize, !size.isEmpty { parts.append(size) }
        if let quantization = model.quantization, !quantization.isEmpty { parts.append(quantization) }
        if model.sizeBytes > 0 { parts.append(ByteCountFormatter.string(fromByteCount: model.sizeBytes, countStyle: .file)) }
        return parts.joined(separator: " · ")
    }
}

/// Registering this iPhone with a PC: the QR code, or the connection code
/// typed with the PC's address; then the six digits both screens show
/// while the PC's person approves.
@MainActor final class PCPairing: ObservableObject {
    enum Phase: Equatable {
        case idle
        case connecting
        /// Both screens show `number`; the PC's person approves there.
        case confirming(number: String, pcName: String)
        case paired(pcName: String)
        case failed(String)
    }

    @Published private(set) var phase: Phase = .idle
    private var task: Task<Void, Never>?

    var isBusy: Bool {
        switch phase {
        case .connecting, .confirming: return true
        default: return false
        }
    }

    /// The QR code Fielua for Windows shows: it names the PC's certificate,
    /// so no other device can stand in.
    func start(invite: PCPairingInvite) {
        run(hosts: invite.hosts + [PCLink.mdnsHost(pcID: invite.pcID)], port: invite.port, pinned: invite.fingerprint,
            credential: ("secret", invite.secret), expectedID: invite.pcID)
    }

    /// The eight digits with the PC's address ("192.168.1.10" or with its
    /// port), or a PC found on the network. The six digits confirm the PC.
    func start(host: String, port: Int, code: String, pinned: Data? = nil, expectedID: String? = nil) {
        run(hosts: [host], port: port, pinned: pinned, credential: ("code", PCLink.normalizedCode(code)), expectedID: expectedID)
    }

    func cancel() {
        task?.cancel()
        task = nil
        phase = .idle
    }

    func reset() {
        guard !isBusy else { return }
        phase = .idle
    }

    private func run(hosts: [String], port: Int, pinned: Data?, credential: (key: String, value: String), expectedID: String?) {
        task?.cancel()
        phase = .connecting
        // iOS 16 and later give "iPhone" here, which is all the PC shows.
        let deviceName = String(UIDevice.current.name.prefix(60))
        task = Task { [weak self] in
            let link = PCLinkConnection(pinned: pinned)
            defer { link.close() }
            do {
                let pc = try await Self.pair(link: link, hosts: hosts, port: port, credential: credential,
                                             deviceName: deviceName, expectedID: expectedID) { number, name in
                    self?.phase = .confirming(number: number, pcName: name)
                }
                guard let self, !Task.isCancelled else { return }
                guard PCLinkStore.shared.register(pc) else { throw PCLinkError.notSaved }
                self.phase = .paired(pcName: pc.pcName)
            } catch is CancellationError {
                return
            } catch {
                guard let self, !Task.isCancelled else { return }
                self.phase = .failed(error.localizedDescription)
            }
        }
    }

    nonisolated private static func pair(link: PCLinkConnection, hosts: [String], port: Int, credential: (key: String, value: String),
                                         deviceName: String, expectedID: String?,
                                         showNumber: @escaping @MainActor (String, String) -> Void) async throws -> PCPairedPC {
        let deviceID = UUID().uuidString.lowercased()
        var begun: (host: String, json: [String: Any])?
        var lastError: Error = PCLinkError.unreachable
        var tried = Set<String>()
        for host in hosts where tried.insert(host.lowercased()).inserted {
            try Task.checkCancellation()
            do {
                let (status, json) = try await link.call(host: host, port: port, "POST", "/v1/pair/begin",
                    body: ["deviceId": deviceID, "deviceName": deviceName, credential.key: credential.value], timeout: 6)
                guard status == 200 else {
                    let failure = PCLinkConnection.failure(status, json)
                    // A QR code's secret the PC no longer has: a new code is needed.
                    throw credential.key == "secret" && failure == .badCode ? PCLinkError.staleQR : failure
                }
                begun = (host, json)
                break
            } catch PCLinkError.unreachable {
                continue
            } catch PCLinkError.wrongPC {
                lastError = PCLinkError.wrongPC
                continue
            }
        }
        guard let begun, let session = begun.json["session"] as? String, let commit = begun.json["commit"] as? String,
              let fingerprint = link.trust.seen else { throw lastError }
        // From here on, only the certificate the first answer showed.
        link.trust.pin(fingerprint)
        let clientNonce = PCLink.randomNonce()
        let (status, confirm) = try await link.call(host: begun.host, port: port, "POST", "/v1/pair/confirm",
            body: ["session": session, "clientNonce": PCLink.base64URL(clientNonce)], timeout: 10)
        guard status == 200 else { throw PCLinkConnection.failure(status, confirm) }
        guard let serverNonce = (confirm["serverNonce"] as? String).flatMap(PCLink.data(base64URL:)),
              PCLink.commitment(serverNonce: serverNonce) == commit,
              let pcID = confirm["pcId"] as? String, !pcID.isEmpty, pcID.count <= 64,
              expectedID.map({ $0 == pcID }) ?? true else { throw PCLinkError.tampered }
        let pcName = String(((confirm["pcName"] as? String) ?? "").prefix(60))
        let shownName = pcName.isEmpty ? "Windows PC" : pcName
        await showNumber(PCLink.confirmationNumber(fingerprint: fingerprint, clientNonce: clientNonce, serverNonce: serverNonce),
                         shownName)
        // The PC answers within 25 seconds, approved or not yet; its window
        // stays open 10 minutes at most.
        let deadline = Date().addingTimeInterval(11 * 60)
        while Date() < deadline {
            try Task.checkCancellation()
            let (status, waited) = try await link.call(host: begun.host, port: port, "POST", "/v1/pair/wait",
                                                       body: ["session": session], timeout: 40)
            guard status == 200 else { throw PCLinkConnection.failure(status, waited) }
            switch waited["state"] as? String {
            case "approved":
                guard let token = waited["token"] as? String, !token.isEmpty,
                      (waited["pcId"] as? String).map({ $0 == pcID }) ?? true else { throw PCLinkError.tampered }
                var known = [begun.host]
                for host in hosts where !host.hasSuffix(".local") && !known.contains(host) { known.append(host) }
                return PCPairedPC(pcID: pcID, pcName: shownName, fingerprint: PCLink.base64URL(fingerprint),
                                  hosts: Array(known.prefix(6)), port: port, deviceID: deviceID, token: token)
            case "denied": throw PCLinkError.denied
            case "expired": throw PCLinkError.expired
            default: continue
            }
        }
        throw PCLinkError.expired
    }
}

/// Fielua for Windows on the same network, as it announces itself (Bonjour,
/// _fielua._tcp): its name, address and port. Anyone could announce the
/// same, so a PC found here is still registered with its connection code
/// and confirmed by the six digits.
@MainActor final class PCLinkBrowser: ObservableObject {
    struct Found: Identifiable, Equatable {
        let id: String
        let name: String
        let host: String
        let port: Int
        let fingerprint: Data?
    }

    @Published private(set) var found: [Found] = []
    /// iOS's ローカルネットワーク permission is off for Fielua.
    @Published private(set) var denied = false
    private var browser: NWBrowser?

    func start() {
        guard browser == nil else { return }
        let parameters = NWParameters()
        parameters.includePeerToPeer = false
        let browser = NWBrowser(for: .bonjourWithTXTRecord(type: PCLink.serviceType, domain: "local."), using: parameters)
        browser.stateUpdateHandler = { [weak self] state in
            let denied: Bool
            switch state {
            case .waiting(let error), .failed(let error):
                if case .dns(let code) = error { denied = code == -65570 } else { denied = false }
            default:
                denied = false
            }
            Task { @MainActor in self?.denied = denied }
        }
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            let list = results.compactMap(Self.found).sorted { $0.name < $1.name }
            Task { @MainActor in self?.found = list }
        }
        browser.start(queue: .main)
        self.browser = browser
    }

    func stop() {
        browser?.cancel()
        browser = nil
    }

    nonisolated private static func found(_ result: NWBrowser.Result) -> Found? {
        guard case let .service(name, _, _, _) = result.endpoint,
              case let .bonjour(record) = result.metadata else { return nil }
        let values = record.dictionary
        guard values["v"] == String(PCLink.protocolVersion), let id = values["id"], !id.isEmpty, id.count <= 64,
              id.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber) }),
              let port = values["p"].flatMap(Int.init), (1...65535).contains(port) else { return nil }
        let fingerprint = values["fp"].flatMap(PCLink.data(base64URL:)).flatMap { $0.count == 32 ? $0 : nil }
        return Found(id: id, name: String(name.prefix(60)), host: PCLink.mdnsHost(pcID: id), port: port, fingerprint: fingerprint)
    }
}
