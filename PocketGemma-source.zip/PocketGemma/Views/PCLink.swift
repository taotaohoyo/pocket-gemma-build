import Foundation
import Network
import Security
import UIKit
import PocketCore

// PCと接続 (1.1.0 (253), the user's directive of 2026-11-01 「Windows・
// iPhone間のローカルAI接続」): a chat answered by a model on the person's
// Windows PC, through Fielua for Windows on the same LAN. Here are the
// connection, the registration and the PC's list; the numbers and the
// turns sent are PocketCore's (PCLink). In Views, so the UI preview, which
// compiles Views alone, talks to a PC (the pc-link UI check's stand-in)
// exactly as the app does.
//
// Safety, as the directive asks:
// - TLS 1.3 to the PC's own certificate, accepted only when its SHA-256 is
//   the one the QR code carried, or for a connection code the one the PC
//   showed first, which the six digits on both screens confirm (PCLink).
// - Nothing is asked before the PC's person approves this iPhone on the
//   PC; the token it then gives is kept in the keychain on this device
//   only (never synced, never logged) and is void once either side
//   removes the registration.
// - Same LAN only: the PC's local addresses and its mDNS name. Nothing goes
//   through the internet, and no PC is asked anything until the person
//   registers it.
//
// 1.1.0 (254), the user's directive of 2026-11-01 「Fielua Link 接続体験改善」:
// a PC found on the network is registered by choosing it (no code), and the
// six digits are confirmed on both screens: the PC's person approves there,
// this iPhone's person taps 同じ数字です here, and only then is anything
// kept. Digits that differ withdraw it on the PC too (/v1/pair/cancel, or
// /v1/unpair once the PC gave its token). As anything on a network can
// announce itself, choosing a PC in the list proves nothing by itself: the
// digits do (PCLink.confirmationNumber), as for the connection code.
// The registered PC is looked for wherever it is now (the last address
// that answered, Bonjour, the addresses it gave, its mDNS name, its mobile
// hotspot), all at once; and when it doesn't answer, the person is told
// what the iPhone can see (PCLinkProblem), never more.

/// What can go wrong talking to the PC, in words for the chat and the page.
enum PCLinkError: LocalizedError, Equatable {
    case notPaired
    /// Nothing answered at the addresses tried.
    case unreachable
    /// The PC doesn't answer: why, as far as the iPhone can tell (254).
    case noAnswer(PCLinkProblem)
    case wrongPC
    case revoked
    case pairingClosed
    case pairingBusy
    case badCode
    case staleQR
    case locked
    case tooManyAttempts
    case expired
    case denied
    /// This iPhone's person said the six digits differ (254).
    case mismatch
    case tampered
    case notSaved
    case modelMissing(String)
    case engine(kind: String, detail: String)
    case badResponse(Int)
    case lost

    var errorDescription: String? {
        switch self {
        case .notPaired:
            return String(localized: "PCが登録されていません。設定の「PCと接続」から登録してください。")
        case .unreachable:
            return PCLinkProblem.notFound.message
        case .noAnswer(let problem):
            return problem.message
        case .wrongPC:
            return String(localized: "登録したPCと証明書が違うため、接続をやめました。")
        case .revoked:
            return String(localized: "PCでこのiPhoneの登録が削除されました。設定の「PCと接続」からもう一度登録してください。")
        case .pairingClosed:
            return String(localized: "PCのFieluaで「QR コードで追加」を押してから、もう一度お試しください。")
        case .pairingBusy:
            return String(localized: "PCはほかの端末の登録を受け付けています。少し待ってからお試しください。")
        case .badCode:
            return String(localized: "接続コードが違います。PCの画面の8けたの数字を確かめてください。")
        case .staleQR:
            return String(localized: "このQRコードは使えなくなっています。PCで「QR コードで追加」を押し直して、新しいQRコードを読み取ってください。")
        case .locked:
            return String(localized: "接続コードを何度も間違えたため、PCが登録を止めました。PCで「QR コードで追加」をやり直してください。")
        case .tooManyAttempts:
            return String(localized: "試した回数が多すぎます。10分ほど待ってからお試しください。")
        case .expired:
            return String(localized: "登録の時間が切れました。もう一度お試しください。")
        case .denied:
            return String(localized: "PCで登録が拒否されました。")
        case .mismatch:
            return String(localized: "数字が違ったため、登録をやめました。PCの画面に出ている名前と数字を確かめて、もう一度お試しください。")
        case .tampered:
            return String(localized: "PCの応答が正しくないため、登録をやめました。")
        case .notSaved:
            return String(localized: "登録の情報をこのiPhoneに保存できませんでした。もう一度お試しください。")
        case .modelMissing(let name):
            return String(localized: "PCに\(name)が見つかりません。PCのFieluaでモデルを確かめてください。")
        case .engine(let kind, let detail):
            let lead: String
            switch kind {
            case "notRunning": lead = String(localized: "PCでOllamaを起動できませんでした。PCのFieluaを確かめてください。")
            case "outOfMemory": lead = String(localized: "PCのメモリが足りず、モデルを読み込めませんでした。小さいモデルをお試しください。")
            case "loadFailed": lead = String(localized: "PCでモデルを読み込めませんでした。")
            case "modelNotFound": lead = String(localized: "PCにこのモデルが見つかりません。PCのFieluaでモデルを確かめてください。")
            case "cloudRefused": lead = String(localized: "クラウドのモデルは使えません。PCにあるモデルを選んでください。")
            default: lead = String(localized: "PCで返信を作れませんでした。")
            }
            let shown = String(detail.trimmingCharacters(in: .whitespacesAndNewlines).prefix(200))
            return shown.isEmpty || kind == "cloudRefused" ? lead : lead + "\n" + shown
        case .badResponse(let status):
            return String(localized: "PCから予期しない応答がありました（\(status)）。")
        case .lost:
            return String(localized: "PCとの接続が切れました。ここまでの返信は残しています。")
        }
    }
}

extension PCLinkProblem {
    /// In words for the chat and 設定 › PCと接続: what to check, as surely
    /// as the iPhone can tell (1.1.0 (254)).
    var message: String {
        switch self {
        case .localNetworkOff:
            return String(localized: "iOSの設定で、Fieluaの「ローカルネットワーク」をオンにしてください。PCとの接続に使います。")
        case .noNetwork:
            return String(localized: "iPhoneがWi-Fiにつながっていません。PCと同じネットワークのWi-Fiにつないでください。")
        case .pcSilent:
            return String(localized: "PCは見つかりましたが、応答がありません。Windowsのファイアウォールか、端末どうしの通信を止めるネットワーク（マンション・学校など）の可能性があります。PCのFieluaの「接続できないとき」をご覧ください。")
        case .hotspotElsewhere:
            return String(localized: "前回はPCのモバイルホットスポットでつながりました。iPhoneのWi-Fiで、PCのホットスポットを選んでください。")
        case .otherNetwork:
            return String(localized: "iPhoneとPCが別のネットワークにいるようです。iPhoneのWi-Fiを、PCと同じネットワークにつないでください。")
        case .notFound:
            return String(localized: "PCに接続できません。PCの電源とスリープ、Fielua for Windowsの「デバイスと接続」、同じネットワークにいるかを確かめてください。")
        }
    }
}

/// Checks the PC by its certificate's SHA-256, as Fielua for Windows makes
/// its own (no certificate authority can vouch for a PC at home). With no
/// fingerprint yet (a connection code), the first one seen is kept, and
/// the six digits on both screens say whether it was the PC's.
final class PCLinkTrust: NSObject, URLSessionDelegate, @unchecked Sendable {
    private let lock = NSLock()
    private var pinned: Data?
    private var lastSeen: Data?
    /// Where another certificate answered, each address as last tried:
    /// several are tried at once (1.1.0 (254)).
    private var refusedHosts: Set<String> = []

    init(pinned: Data?) { self.pinned = pinned }

    /// The certificate of the last answer accepted.
    var seen: Data? { lock.withLock { lastSeen } }
    func refused(_ host: String) -> Bool { lock.withLock { refusedHosts.contains(host.lowercased()) } }
    func pin(_ fingerprint: Data) { lock.withLock { pinned = fingerprint } }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge) async
        -> (URLSession.AuthChallengeDisposition, URLCredential?) {
        guard challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let trust = challenge.protectionSpace.serverTrust,
              let leaf = (SecTrustCopyCertificateChain(trust) as? [SecCertificate])?.first else {
            return (.cancelAuthenticationChallenge, nil)
        }
        let host = challenge.protectionSpace.host.lowercased()
        let fingerprint = PCLink.sha256(SecCertificateCopyData(leaf) as Data)
        let accepted: Bool = lock.withLock {
            let accepted = pinned.map { $0 == fingerprint } ?? true
            if accepted {
                lastSeen = fingerprint
                refusedHosts.remove(host)
            } else {
                refusedHosts.insert(host)
            }
            return accepted
        }
        return accepted ? (.useCredential, URLCredential(trust: trust)) : (.cancelAuthenticationChallenge, nil)
    }
}

/// HTTPS to one PC: every request over TLS 1.3 to the certificate
/// PCLinkTrust accepts. Ephemeral: no cookies, cache or stored credentials.
final class PCLinkConnection: @unchecked Sendable {
    let trust: PCLinkTrust
    private let session: URLSession

    init(pinned: Data?) {
        trust = PCLinkTrust(pinned: pinned)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.tlsMinimumSupportedProtocolVersion = .TLSv13
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        configuration.waitsForConnectivity = false
        // A reply streams for minutes; the PC sends a line at least every
        // 5 seconds, so a minute and a half of silence is a lost PC.
        configuration.timeoutIntervalForRequest = 90
        configuration.timeoutIntervalForResource = 60 * 60
        // Only the Wi-Fi or wired LAN: never over cellular to an address
        // that happens to match.
        configuration.allowsCellularAccess = false
        session = URLSession(configuration: configuration, delegate: trust, delegateQueue: nil)
    }

    /// Ends the connection's requests; the session lets go of its delegate.
    func close() { session.invalidateAndCancel() }

    static func url(host: String, port: Int, path: String) -> URL? {
        var components = URLComponents()
        components.scheme = "https"
        components.host = host
        components.port = port
        components.path = path
        return components.url
    }

    private func request(host: String, port: Int, method: String, path: String, body: [String: Any]?,
                         token: String?, timeout: TimeInterval) throws -> URLRequest {
        guard let url = Self.url(host: host, port: port, path: path) else { throw PCLinkError.unreachable }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = method
        if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    /// One request and its JSON answer, whatever its status.
    func call(host: String, port: Int, _ method: String, _ path: String, body: [String: Any]? = nil,
              token: String? = nil, timeout: TimeInterval = 10) async throws -> (status: Int, json: [String: Any]) {
        let request = try request(host: host, port: port, method: method, path: path, body: body, token: token, timeout: timeout)
        do {
            let (data, response) = try await session.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            return (status, (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        } catch {
            throw mapped(error, host: host, streaming: false)
        }
    }

    /// A reply as the PC streams it, a line at a time, until it ends.
    func stream(host: String, port: Int, path: String, body: [String: Any], token: String,
                onLine: (String) async throws -> Bool) async throws {
        let request = try request(host: host, port: port, method: "POST", path: path, body: body, token: token, timeout: 90)
        let bytes: URLSession.AsyncBytes
        let response: URLResponse
        do { (bytes, response) = try await session.bytes(for: request) } catch { throw mapped(error, host: host, streaming: false) }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else {
            var data = Data()
            do {
                for try await byte in bytes {
                    data.append(byte)
                    if data.count > 16 * 1024 { break }
                }
            } catch { throw mapped(error, host: host, streaming: false) }
            throw Self.failure(status, (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        }
        do {
            for try await line in bytes.lines {
                if try await onLine(line) { return }
            }
        } catch let error as PCLinkError {
            throw error
        } catch {
            throw mapped(error, host: host, streaming: true)
        }
        // The stream ended without its last line: the PC went away.
        throw PCLinkError.lost
    }

    private func mapped(_ error: Error, host: String, streaming: Bool) -> Error {
        if error is CancellationError || Task.isCancelled { return CancellationError() }
        let error = error as NSError
        guard error.domain == NSURLErrorDomain else { return error }
        // A certificate PCLinkTrust turned away ends the request as cancelled.
        let refusals = [NSURLErrorCancelled, NSURLErrorSecureConnectionFailed, NSURLErrorServerCertificateUntrusted,
                        NSURLErrorServerCertificateHasUnknownRoot, NSURLErrorServerCertificateHasBadDate,
                        NSURLErrorServerCertificateNotYetValid]
        if trust.refused(host), refusals.contains(error.code) { return PCLinkError.wrongPC }
        return streaming ? PCLinkError.lost : PCLinkError.unreachable
    }

    /// A refusal in the PC's words ({"error": code}) as the person's.
    static func failure(_ status: Int, _ json: [String: Any]) -> PCLinkError {
        switch json["error"] as? String {
        case "pairingClosed": return .pairingClosed
        case "busy": return .pairingBusy
        case "badCredential": return .badCode
        case "locked": return .locked
        case "noSession": return .expired
        case "unauthorized": return .revoked
        case "tooManyAttempts", "tooManyRequests": return .tooManyAttempts
        case "engine":
            let engine = json["engine"] as? [String: Any]
            return .engine(kind: engine?["kind"] as? String ?? "other", detail: engine?["detail"] as? String ?? "")
        default: return status == 401 ? .revoked : .badResponse(status)
        }
    }
}

/// The registered PC, kept whole in the keychain on this device only: it
/// holds the token. Not synced to the person's other devices, which would
/// each need the PC's own approval.
enum PCLinkKeychain {
    private static var item: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.pc-link",
         kSecAttrAccount as String: "paired-pc",
         kSecAttrSynchronizable as String: kCFBooleanFalse as Any]
    }

    static func load() -> PCPairedPC? {
        var query = item
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return try? JSONDecoder().decode(PCPairedPC.self, from: data)
    }

    static func save(_ pc: PCPairedPC) -> Bool {
        guard let data = try? JSONEncoder().encode(pc) else { return false }
        delete()
        var entry = item
        entry[kSecValueData as String] = data
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
    }

    static func delete() {
        SecItemDelete(item as CFDictionary)
    }
}

/// What /v1/status says, as plain values (they cross from the checks run
/// at once to the store).
struct PCStatus: Sendable {
    var pcID: String?
    var pcName: String?
    var engineRunning: Bool?
    /// The PC's LAN addresses now (Fielua for Windows from 1.1.0 (254)'s
    /// counterpart on): IPv4 only, six at most.
    var addresses: [String]

    init(_ json: [String: Any]) {
        pcID = json["pcId"] as? String
        pcName = json["pcName"] as? String
        engineRunning = (json["engine"] as? [String: Any])?["running"] as? Bool
        addresses = Array(((json["addresses"] as? [Any]) ?? []).compactMap { $0 as? String }
            .filter { PCLinkNetwork.value($0) != nil }.prefix(6))
    }
}

/// The registered PC, its models and whether it answers, for the views and
/// both ChatStores. One PC at a time: registering another replaces it.
@MainActor final class PCLinkStore: ObservableObject {
    static let shared = PCLinkStore()

    enum Connection: Equatable {
        /// No PC registered.
        case none
        case checking
        /// It answered at this address.
        case connected(host: String)
        /// It doesn't answer: what the iPhone can tell of why (254).
        case unreachable(PCLinkProblem)
        /// The PC removed this iPhone; the registration here is void.
        case revoked
        /// Another certificate answered at the PC's address.
        case wrongPC
    }

    @Published private(set) var paired: PCPairedPC?
    @Published private(set) var models: [PCModel] = []
    @Published private(set) var connection: Connection = .none
    /// The PC's Ollama was running at the last check; nil before one.
    @Published private(set) var engineRunning: Bool?
    @Published private(set) var lastChecked: Date?
    /// The PC is being asked now, whatever `connection` says (a PC that
    /// answered keeps 接続中 while it is asked again): for 接続を確かめる,
    /// which showed nothing of its work then (1.1.0 (263)).
    @Published private(set) var isChecking = false
    /// Why the PC didn't answer at the check before the one now running:
    /// `problem` keeps saying it meanwhile.
    private var heldProblem: PCLinkProblem?
    /// Fielua for Windows announced on this network (Bonjour): the page's
    /// list, and where the registered PC is now (1.1.0 (254)).
    let finder = PCLinkBrowser()
    /// The iPhone's own network (1.1.0 (254)).
    let path = PCLinkPath()
    private var link: PCLinkConnection?
    private var refreshing: Task<Void, Never>?
    /// Which check `refreshing` is: one for a PC no longer registered ends
    /// without touching the next.
    private var refreshID = 0
    private var activeHost: String?
    /// 設定 › PCと接続 is showing: PCs are looked for with none registered.
    private var pageShown = false
    private var watchingApp = false

    private init() {
        #if POCKET_PREVIEW
        let arguments = ProcessInfo.processInfo.arguments
        // The pc-link UI check starts with no PC registered...
        if arguments.contains("--pc-link-reset") { PCLinkKeychain.delete() }
        // ...or with one that never answers, for what the page says then.
        if let seed = arguments.first(where: { $0.hasPrefix("--pc-link-seed-silent=") }) {
            Self.seedSilentPC(String(seed.dropFirst("--pc-link-seed-silent=".count)))
        }
        #endif
        adopt(PCLinkKeychain.load())
        finder.changed = { [weak self] in self?.announcementsChanged() }
        path.changed = { [weak self] in self?.networkChanged() }
    }

    var isPaired: Bool { paired != nil }
    /// What the page says of a PC that doesn't answer. It stays while the
    /// PC is asked again (1.1.0 (263)): the note went away for the length
    /// of every check before, up to 20 seconds, and came back after it
    /// (UI review, 2026-11-11).
    var problem: PCLinkProblem? {
        switch connection {
        case .unreachable(let problem): return problem
        case .checking: return heldProblem
        default: return nil
        }
    }
    var isConnected: Bool { if case .connected = connection { return true } else { return false } }

    private func adopt(_ pc: PCPairedPC?) {
        refreshing?.cancel()
        refreshing = nil
        isChecking = false
        refreshID += 1
        link?.close()
        link = pc.flatMap { PCLink.data(base64URL: $0.fingerprint) }.map { PCLinkConnection(pinned: $0) }
        paired = pc
        activeHost = nil
        engineRunning = nil
        lastChecked = nil
        heldProblem = nil
        connection = pc == nil ? .none : .checking
        models = pc.map { Self.cachedModels(for: $0.pcID) } ?? []
        if pc == nil, !pageShown { unwatch() }
    }

    // MARK: Models and the network the PC last answered on, kept between
    // launches (nothing secret)

    private static func modelsKey(_ pcID: String) -> String { "fielua.pcLink.models.\(pcID)" }
    private static func networkKey(_ pcID: String) -> String { "fielua.pcLink.network.\(pcID)" }

    private static func cachedModels(for pcID: String) -> [PCModel] {
        guard let data = UserDefaults.standard.data(forKey: modelsKey(pcID)) else { return [] }
        return (try? JSONDecoder().decode([PCModel].self, from: data)) ?? []
    }

    private func keepModels(_ list: [PCModel], for pcID: String) {
        models = list
        if let data = try? JSONEncoder().encode(list) { UserDefaults.standard.set(data, forKey: Self.modelsKey(pcID)) }
    }

    /// The iPhone's network when the PC last answered: a different one now
    /// is what tells "another network" (and "the PC's hotspot") apart.
    private static func lastNetwork(for pcID: String) -> PCLinkNetwork? {
        UserDefaults.standard.string(forKey: networkKey(pcID)).flatMap { PCLinkNetwork($0) }
    }

    // MARK: Following the network

    /// Bonjour and the iPhone's network, only with a PC registered or the
    /// page showing: browsing is what asks for iOS's ローカルネットワーク
    /// permission, which nobody who never uses PCと接続 should be asked.
    private func watch() {
        guard paired != nil || pageShown else { return }
        path.start()
        finder.start()
        guard !watchingApp else { return }
        watchingApp = true
        // Nothing is browsed in the background; on the app's return the
        // search goes on (and the app checks the PC again).
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil,
                                               queue: .main) { [weak self] _ in
            // The list heard so far stays for the return (1.1.0 (263)).
            MainActor.assumeIsolated { self?.unwatch(keepingList: true) }
        }
        NotificationCenter.default.addObserver(forName: UIApplication.willEnterForegroundNotification, object: nil,
                                               queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.watch() }
        }
    }

    private func unwatch(keepingList: Bool = false) {
        finder.stop(keepingList: keepingList)
        path.stop()
    }

    /// 設定 › PCと接続 shows: the PCs on the network are listed with none
    /// registered, and the registered one is checked.
    func pageAppeared() {
        pageShown = true
        watch()
        refresh()
    }

    func pageDisappeared() {
        pageShown = false
        // With a PC registered, it is still followed; with none, nothing is.
        if paired == nil { unwatch() }
    }

    /// Another network (or none, or the same one back): the PC is looked
    /// for there at once, as it may answer at another address now.
    private func networkChanged() {
        guard paired != nil else { return }
        refreshing?.cancel()
        refreshing = nil
        isChecking = false
        refresh()
    }

    /// The registered PC announced itself: asked again if it didn't answer.
    private func announcementsChanged() {
        guard let pc = paired, finder.heard.contains(where: { $0.id == pc.pcID }) else { return }
        switch connection {
        case .unreachable, .wrongPC: refresh()
        default: break
        }
    }

    // MARK: Checking the PC

    /// Asks the PC how it is and for its models. Called when 設定 › PCと接続
    /// or the chat shows, when the app comes forward, and (254) when the
    /// network changes or the PC announces itself again.
    func refresh() {
        guard paired != nil, refreshing == nil else { return }
        watch()
        refreshID += 1
        let id = refreshID
        isChecking = true
        refreshing = Task { [weak self] in
            await self?.check()
            if self?.refreshID == id {
                self?.refreshing = nil
                self?.isChecking = false
            }
        }
    }

    private func check() async {
        guard let pc = paired, let link else { return }
        if !isConnected {
            if case .unreachable(let problem) = connection { heldProblem = problem } else if connection != .checking { heldProblem = nil }
            connection = .checking
        }
        do {
            let target = try await reachableHost(pc, link: link)
            let (status, json) = try await link.call(host: target.host, port: target.port, "GET", "/v1/models",
                                                     token: pc.token, timeout: 20)
            guard paired?.pcID == pc.pcID else { return }
            lastChecked = Date()
            if status == 200 {
                let list = (json["models"] as? [[String: Any]] ?? []).compactMap(Self.model)
                keepModels(list, for: pc.pcID)
                engineRunning = true
            } else {
                let failure = PCLinkConnection.failure(status, json)
                if failure == .revoked { revoked(); return }
                engineRunning = false
            }
        } catch {
            guard paired?.pcID == pc.pcID else { return }
            lastChecked = Date()
            await settle(error)
        }
    }

    private static func model(_ json: [String: Any]) -> PCModel? {
        guard let name = json["name"] as? String, !name.isEmpty else { return nil }
        return PCModel(name: name, sizeBytes: (json["sizeBytes"] as? NSNumber)?.int64Value ?? 0,
                       family: json["family"] as? String, parameterSize: json["parameterSize"] as? String,
                       quantization: json["quantization"] as? String)
    }

    /// Where the PC answers now (1.1.0 (254)): the address that did last,
    /// the PC where Bonjour finds it (on its port, should that have
    /// changed), the addresses it gave, its mDNS name, and on its mobile
    /// hotspot the hotspot's address; tried at once, the likeliest first.
    /// Only a certificate with the PC's SHA-256 is answered with the token.
    private func reachableHost(_ pc: PCPairedPC, link: PCLinkConnection) async throws -> (host: String, port: Int) {
        let announced = finder.found.first { $0.id == pc.pcID }
        let port = announced?.port ?? pc.port
        let network = path.facts.network
        var hosts = pc.candidateHosts
        if network?.isWindowsHotspot == true { hosts.append(PCLink.hotspotAddress) }
        let ordered = PCLink.orderedHosts(hosts, first: activeHost, announced: announced?.host, network: network)
        let (host, status) = try await Self.race(ordered, port: port, link: link, token: pc.token, pcID: pc.pcID)
        guard paired?.pcID == pc.pcID else { throw CancellationError() }
        answered(host, port: port, status: status)
        return (host, port)
    }

    private enum Attempt: Sendable {
        case answered(String, PCStatus)
        case refused(PCLinkError)
        case failed(PCLinkError?)
    }

    /// The first address that answers as the PC, all asked at once (the
    /// likeliest a moment before the rest, which stop once it answers).
    nonisolated private static func race(_ hosts: [String], port: Int, link: PCLinkConnection, token: String,
                                         pcID: String) async throws -> (String, PCStatus) {
        try await withThrowingTaskGroup(of: Attempt.self) { group in
            for (index, host) in hosts.enumerated() {
                group.addTask {
                    if index > 0 { try await Task.sleep(for: .milliseconds(250 * min(index, 4))) }
                    do {
                        let (status, json) = try await link.call(host: host, port: port, "GET", "/v1/status",
                                                                  token: token, timeout: 4)
                        return status == 200 ? .answered(host, PCStatus(json)) : .refused(PCLinkConnection.failure(status, json))
                    } catch let error as PCLinkError {
                        return .failed(error)
                    } catch {
                        return .failed(nil)
                    }
                }
            }
            var failure = PCLinkError.unreachable
            for try await attempt in group {
                switch attempt {
                case .answered(let host, let status):
                    // Another Fielua for Windows at that address is not this PC.
                    if let id = status.pcID, id != pcID { failure = .wrongPC; continue }
                    group.cancelAll()
                    return (host, status)
                case .refused(let refusal):
                    if refusal == .revoked { group.cancelAll(); throw refusal }
                    if failure != .wrongPC { failure = refusal }
                case .failed(let error):
                    if error == .wrongPC { failure = .wrongPC }
                }
            }
            throw failure
        }
    }

    private func answered(_ host: String, port: Int, status: PCStatus) {
        activeHost = host
        connection = .connected(host: host)
        if let running = status.engineRunning { engineRunning = running }
        guard var pc = paired else { return }
        if let network = path.facts.network {
            UserDefaults.standard.set(network.description, forKey: Self.networkKey(pc.pcID))
        }
        let before = pc
        pc.answered(at: host, port: port, addresses: status.addresses)
        if let name = status.pcName, !name.isEmpty { pc.pcName = String(name.prefix(60)) }
        if pc != before, PCLinkKeychain.save(pc) { paired = pc }
    }

    private func settle(_ error: Error) async {
        switch error {
        case PCLinkError.revoked: revoked()
        case PCLinkError.wrongPC: connection = .wrongPC
        case is CancellationError: break
        default:
            activeHost = nil
            let problem = await diagnosis()
            guard paired != nil else { return }
            connection = .unreachable(problem)
        }
    }

    /// What the iPhone can tell of why the PC doesn't answer. Bonjour has a
    /// couple of seconds to hear the PC first.
    private func diagnosis() async -> PCLinkProblem {
        if let started = finder.startedAt {
            let left = 2.5 - Date().timeIntervalSince(started)
            if left > 0 { try? await Task.sleep(for: .seconds(left)) }
        }
        guard let pc = paired else { return .notFound }
        return PCLinkProblem.diagnose(.init(localNetworkDenied: finder.denied,
                                            onLocalNetwork: path.facts.onLocalNetwork,
                                            phoneNetwork: path.facts.network,
                                            lastNetwork: Self.lastNetwork(for: pc.pcID),
                                            pcAnnounced: finder.heard.contains { $0.id == pc.pcID }))
    }

    /// The facts for a PC being registered, which hasn't answered yet.
    func registeringFacts(announced: Bool, addresses: [String]) -> PCLinkProblem.Facts {
        PCLinkProblem.Facts(localNetworkDenied: finder.denied, onLocalNetwork: path.facts.onLocalNetwork,
                            phoneNetwork: path.facts.network, pcAnnounced: announced, pcAddresses: addresses)
    }

    /// The PC no longer knows this iPhone: the token is void, so it goes.
    private func revoked() {
        PCLinkKeychain.delete()
        adopt(nil)
        connection = .revoked
    }

    // MARK: Registering and removing

    /// Keeps a PC the person registered (PCPairing), in place of any other.
    func register(_ pc: PCPairedPC) -> Bool {
        // The PC's earlier entry for this iPhone, or another PC's, is voided.
        if let old = paired, old.token != pc.token { Self.forget(old) }
        guard PCLinkKeychain.save(pc) else { return false }
        adopt(pc)
        refresh()
        return true
    }

    /// 接続を解除: the PC is told to forget this iPhone when it answers, and
    /// the registration goes here at once either way. The chats stay.
    func unpair() {
        guard let pc = paired else { return }
        Self.forget(pc)
        PCLinkKeychain.delete()
        UserDefaults.standard.removeObject(forKey: Self.modelsKey(pc.pcID))
        UserDefaults.standard.removeObject(forKey: Self.networkKey(pc.pcID))
        adopt(nil)
    }

    /// Tells the PC to void this iPhone's token, if it answers soon.
    nonisolated static func forget(_ pc: PCPairedPC) {
        guard let fingerprint = PCLink.data(base64URL: pc.fingerprint) else { return }
        let link = PCLinkConnection(pinned: fingerprint)
        let hosts = Array(pc.candidateHosts.prefix(3))
        Task.detached {
            for host in hosts {
                let answer = try? await link.call(host: host, port: pc.port, "POST", "/v1/unpair", token: pc.token, timeout: 4)
                if let answer, answer.status == 200 || answer.status == 401 { break }
            }
            link.close()
        }
    }

    #if POCKET_PREVIEW
    /// "127.0.0.1:47879" or "127.0.0.1:47879,192.168.137.0/24": a PC that
    /// never answers (nothing listens there), and the network it last
    /// answered on.
    private static func seedSilentPC(_ value: String) {
        let parts = value.split(separator: ",").map(String.init)
        guard let address = parts.first.flatMap({ PCLink.address($0) }) else { return }
        let pc = PCPairedPC(pcID: "silentpc00000001", pcName: "テスト用PC", fingerprint: PCLink.base64URL(Data(repeating: 7, count: 32)),
                            hosts: [address.host], port: address.port, deviceID: "seed", token: "seed")
        _ = PCLinkKeychain.save(pc)
        if parts.count > 1 {
            UserDefaults.standard.set(parts[1], forKey: networkKey(pc.pcID))
        } else {
            UserDefaults.standard.removeObject(forKey: networkKey(pc.pcID))
        }
    }
    #endif

    // MARK: Replies

    enum ReplyProgress {
        /// The PC is starting Ollama.
        case starting
        /// The model is loading or reading the question.
        case loading
        /// The model thinks before it answers (its thinking is not shown).
        case thinking
        /// Still working, nothing new to show.
        case alive
    }

    /// One reply from the chat's model on the PC, streamed to `onText`.
    /// Throws PCLinkError, or CancellationError when stopped here.
    func reply(target: PCChatTarget, turns: [PCTurn], requestID: String,
               onProgress: @escaping (ReplyProgress) async -> Void,
               onText: @escaping (String) async -> Void) async throws {
        guard let pc = paired, pc.pcID == target.pcID, let link else { throw PCLinkError.notPaired }
        let place: (host: String, port: Int)
        do {
            place = try await reachableHost(pc, link: link)
        } catch {
            await settle(error)
            if case .unreachable(let problem) = connection { throw PCLinkError.noAnswer(problem) }
            throw error
        }
        let body: [String: Any] = [
            "requestId": requestID,
            "model": target.model,
            "messages": turns.map { ["role": $0.role, "content": $0.content] },
        ]
        var answered = false
        do {
            try await link.stream(host: place.host, port: place.port, path: "/v1/chat", body: body, token: pc.token) { line in
                guard let event = PCChatEvent(line: line) else { return false }
                switch event {
                case .started:
                    await onProgress(.loading)
                case .waiting(let stage):
                    await onProgress(stage == "starting" ? .starting : .alive)
                case .delta(let content, let thinking):
                    if !content.isEmpty {
                        answered = true
                        await onText(content)
                    } else if !thinking.isEmpty, !answered {
                        await onProgress(.thinking)
                    } else {
                        await onProgress(.alive)
                    }
                case .done:
                    return true
                case .stopped:
                    throw CancellationError()
                case .failed(let kind, let detail):
                    if kind == "modelNotFound" { throw PCLinkError.modelMissing(target.shortModel) }
                    if kind == "cancelled" { throw CancellationError() }
                    throw PCLinkError.engine(kind: kind, detail: detail)
                }
                return false
            }
            connection = .connected(host: place.host)
        } catch {
            if case PCLinkError.revoked = error { revoked() }
            if case PCLinkError.wrongPC = error { connection = .wrongPC }
            if case PCLinkError.lost = error {
                activeHost = nil
                // Whether it is gone or only this reply: the next check says.
                refresh()
            }
            throw error
        }
    }

    /// Asks the PC to stop a reply; the stream then ends with "stopped".
    /// The reply's task is cancelled as well, which the PC sees as the
    /// connection closing and stops too, should this not reach it.
    func cancel(requestID: String) {
        guard let pc = paired, let link, let host = activeHost else { return }
        Task.detached {
            _ = try? await link.call(host: host, port: pc.port, "POST", "/v1/chat/cancel",
                                     body: ["requestId": requestID], token: pc.token, timeout: 4)
        }
    }

    /// The model's line under its name: its size and quantization.
    static func detail(_ model: PCModel) -> String {
        var parts: [String] = []
        if let size = model.parameterSize, !size.isEmpty { parts.append(size) }
        if let quantization = model.quantization, !quantization.isEmpty { parts.append(quantization) }
        if model.sizeBytes > 0 { parts.append(ByteCountFormatter.string(fromByteCount: model.sizeBytes, countStyle: .file)) }
        return parts.joined(separator: " · ")
    }
}

/// A registration under way, once the PC has shown its digits.
struct PCPairingSession: Sendable {
    let host: String
    let port: Int
    let session: String
    let fingerprint: Data
    let pcID: String
    let pcName: String
    let number: String
    let deviceID: String
    /// The addresses to keep for the PC.
    let hosts: [String]
}

/// Registering this iPhone with a PC: chosen in the list (1.1.0 (254)), the
/// QR code, or the connection code typed with the PC's address; then the
/// six digits both screens show, approved on the PC and here.
@MainActor final class PCPairing: ObservableObject {
    enum Phase: Equatable {
        case idle
        case connecting
        /// Both screens show `number`: the PC's person approves there, and
        /// this iPhone's says here that the digits match (`confirmedHere`).
        case confirming(number: String, pcName: String, confirmedHere: Bool)
        case paired(pcName: String)
        case failed(String)
    }

    @Published private(set) var phase: Phase = .idle
    /// This iPhone as the PC sees it while the sheet is open: starting over
    /// (もう一度) replaces its earlier request on the PC instead of meeting
    /// it as another device's.
    private let deviceID = UUID().uuidString.lowercased()
    private var task: Task<Void, Never>?
    private var pending: PCPairingSession?
    /// The PC approved: kept here, unsaved, until this iPhone's person
    /// confirms the digits too.
    private var approved: PCPairedPC?
    private var confirmedHere = false

    var isBusy: Bool {
        switch phase {
        case .connecting, .confirming: return true
        default: return false
        }
    }

    /// The QR code Fielua for Windows shows: it names the PC's certificate,
    /// so no other device can stand in.
    func start(invite: PCPairingInvite) {
        run(hosts: invite.hosts + [PCLink.mdnsHost(pcID: invite.pcID)], port: invite.port, pinned: invite.fingerprint,
            credential: ["secret": invite.secret], expectedID: invite.pcID,
            facts: PCLinkStore.shared.registeringFacts(announced: false, addresses: invite.hosts))
    }

    /// The eight digits with the PC's address ("192.168.1.10" or with its
    /// port), or a PC found on the network. The six digits confirm the PC.
    func start(host: String, port: Int, code: String, pinned: Data? = nil, expectedID: String? = nil) {
        run(hosts: [host], port: port, pinned: pinned, credential: ["code": PCLink.normalizedCode(code)], expectedID: expectedID,
            facts: PCLinkStore.shared.registeringFacts(announced: false, addresses: []))
    }

    /// A PC chosen in the list (1.1.0 (254)): no code. Anything can announce
    /// itself on a network, so the six digits, compared on both screens,
    /// are what says it is the PC.
    func start(select pc: PCLinkBrowser.Found) {
        run(hosts: [pc.host], port: pc.port, pinned: pc.fingerprint, credential: ["method": PCLink.pairSelect], expectedID: pc.id,
            facts: PCLinkStore.shared.registeringFacts(announced: true, addresses: []))
    }

    /// 同じ数字です: the digits on the PC match. Registered once the PC's
    /// person has approved too.
    func confirmHere() {
        guard case .confirming(let number, let pcName, false) = phase else { return }
        confirmedHere = true
        if let approved {
            finish(approved)
        } else {
            phase = .confirming(number: number, pcName: pcName, confirmedHere: true)
        }
    }

    /// 数字が違う: nothing is registered, and the PC is told so.
    func mismatch() {
        guard case .confirming = phase else { return }
        abandon()
        phase = .failed(PCLinkError.mismatch.localizedDescription)
    }

    func cancel() {
        abandon()
        phase = .idle
    }

    func reset() {
        guard !isBusy else { return }
        phase = .idle
    }

    private func run(hosts: [String], port: Int, pinned: Data?, credential: [String: String], expectedID: String?,
                     facts: PCLinkProblem.Facts) {
        abandon()
        phase = .connecting
        // iOS 16 and later give "iPhone" here, which is all the PC shows.
        let deviceName = String(UIDevice.current.name.prefix(60))
        let ordered = PCLink.orderedHosts(hosts, network: facts.phoneNetwork)
        let silent = PCLinkProblem.diagnose(facts)
        let deviceID = self.deviceID
        task = Task { [weak self] in
            let link = PCLinkConnection(pinned: pinned)
            defer { link.close() }
            do {
                let session = try await Self.begin(link: link, hosts: ordered, port: port, credential: credential,
                                                   deviceID: deviceID, deviceName: deviceName, expectedID: expectedID,
                                                   silent: silent)
                guard let self, !Task.isCancelled else { return }
                self.pending = session
                self.phase = .confirming(number: session.number, pcName: session.pcName, confirmedHere: false)
                let pc = try await Self.waitForApproval(link: link, session: session)
                guard !Task.isCancelled else {
                    // Left meanwhile: the registration the PC just made goes.
                    PCLinkStore.forget(pc)
                    return
                }
                self.pending = nil
                self.approved = pc
                if self.confirmedHere { self.finish(pc) }
            } catch is CancellationError {
                return
            } catch {
                guard let self, !Task.isCancelled else { return }
                self.fail(error)
            }
        }
    }

    private func finish(_ pc: PCPairedPC) {
        task = nil
        pending = nil
        approved = nil
        confirmedHere = false
        guard PCLinkStore.shared.register(pc) else {
            // Without its token here, the PC's entry for this iPhone goes too.
            PCLinkStore.forget(pc)
            phase = .failed(PCLinkError.notSaved.localizedDescription)
            return
        }
        phase = .paired(pcName: pc.pcName)
    }

    private func fail(_ error: Error) {
        task = nil
        if let pending { Self.withdraw(pending) }
        pending = nil
        approved = nil
        confirmedHere = false
        phase = .failed(error.localizedDescription)
    }

    /// Ends a registration under way, and tells the PC: its approval
    /// closes, and one it already gave is removed.
    private func abandon() {
        task?.cancel()
        task = nil
        if let approved {
            PCLinkStore.forget(approved)
        } else if let pending {
            Self.withdraw(pending)
        }
        pending = nil
        approved = nil
        confirmedHere = false
    }

    /// The PC closes its approval for this iPhone (and, for a connection
    /// code or QR code, its window), as this iPhone's person said no.
    nonisolated private static func withdraw(_ session: PCPairingSession) {
        let link = PCLinkConnection(pinned: session.fingerprint)
        Task.detached {
            _ = try? await link.call(host: session.host, port: session.port, "POST", "/v1/pair/cancel",
                                     body: ["session": session.session], timeout: 6)
            link.close()
        }
    }

    nonisolated private static func begin(link: PCLinkConnection, hosts: [String], port: Int, credential: [String: String],
                                          deviceID: String, deviceName: String, expectedID: String?,
                                          silent: PCLinkProblem) async throws -> PCPairingSession {
        var body: [String: Any] = ["deviceId": deviceID, "deviceName": deviceName]
        for (key, value) in credential { body[key] = value }
        var begun: (host: String, json: [String: Any])?
        var lastError: Error = PCLinkError.noAnswer(silent)
        var tried = Set<String>()
        for host in hosts where tried.insert(host.lowercased()).inserted {
            try Task.checkCancellation()
            do {
                let (status, json) = try await link.call(host: host, port: port, "POST", "/v1/pair/begin", body: body, timeout: 6)
                guard status == 200 else {
                    let failure = PCLinkConnection.failure(status, json)
                    // A QR code's secret the PC no longer has: a new code is needed.
                    throw credential["secret"] != nil && failure == .badCode ? PCLinkError.staleQR : failure
                }
                begun = (host, json)
                break
            } catch PCLinkError.unreachable {
                continue
            } catch PCLinkError.wrongPC {
                lastError = PCLinkError.wrongPC
                continue
            }
        }
        guard let begun, let session = begun.json["session"] as? String, let commit = begun.json["commit"] as? String,
              let fingerprint = link.trust.seen else { throw lastError }
        // From here on, only the certificate the first answer showed.
        link.trust.pin(fingerprint)
        let clientNonce = PCLink.randomNonce()
        let (status, confirm) = try await link.call(host: begun.host, port: port, "POST", "/v1/pair/confirm",
            body: ["session": session, "clientNonce": PCLink.base64URL(clientNonce)], timeout: 10)
        guard status == 200 else { throw PCLinkConnection.failure(status, confirm) }
        guard let serverNonce = (confirm["serverNonce"] as? String).flatMap(PCLink.data(base64URL:)),
              PCLink.commitment(serverNonce: serverNonce) == commit,
              let pcID = confirm["pcId"] as? String, !pcID.isEmpty, pcID.count <= 64,
              expectedID.map({ $0 == pcID }) ?? true else { throw PCLinkError.tampered }
        let pcName = String(((confirm["pcName"] as? String) ?? "").prefix(60))
        var known = [begun.host]
        for host in hosts where !host.hasSuffix(".local") && !known.contains(host) { known.append(host) }
        return PCPairingSession(host: begun.host, port: port, session: session, fingerprint: fingerprint, pcID: pcID,
                                pcName: pcName.isEmpty ? "Windows PC" : pcName,
                                number: PCLink.confirmationNumber(fingerprint: fingerprint, clientNonce: clientNonce,
                                                                  serverNonce: serverNonce),
                                deviceID: deviceID, hosts: Array(known.prefix(6)))
    }

    /// The PC's person approves or not. The PC answers within 25 seconds,
    /// approved or not yet; it gives up on a registration after a few minutes.
    nonisolated private static func waitForApproval(link: PCLinkConnection, session: PCPairingSession) async throws -> PCPairedPC {
        let deadline = Date().addingTimeInterval(11 * 60)
        while Date() < deadline {
            try Task.checkCancellation()
            let (status, waited) = try await link.call(host: session.host, port: session.port, "POST", "/v1/pair/wait",
                                                       body: ["session": session.session], timeout: 40)
            guard status == 200 else { throw PCLinkConnection.failure(status, waited) }
            switch waited["state"] as? String {
            case "approved":
                guard let token = waited["token"] as? String, !token.isEmpty,
                      (waited["pcId"] as? String).map({ $0 == session.pcID }) ?? true else { throw PCLinkError.tampered }
                return PCPairedPC(pcID: session.pcID, pcName: session.pcName, fingerprint: PCLink.base64URL(session.fingerprint),
                                  hosts: session.hosts, port: session.port, deviceID: session.deviceID, token: token)
            case "denied": throw PCLinkError.denied
            case "expired": throw PCLinkError.expired
            default: continue
            }
        }
        throw PCLinkError.expired
    }
}

/// Fielua for Windows on the same network, as it announces itself (Bonjour,
/// _fielua._tcp): its name, port, certificate's SHA-256 and whether it can
/// be registered by choosing it. Anyone could announce the same, so a PC
/// found here is confirmed by the six digits on both screens.
@MainActor final class PCLinkBrowser: ObservableObject {
    struct Found: Identifiable, Equatable {
        let id: String
        let name: String
        let host: String
        let port: Int
        let fingerprint: Data?
        /// It takes registering by choosing it here (pair=select, 254); an
        /// older Fielua for Windows takes its connection code.
        let selectable: Bool
    }

    @Published private(set) var found: [Found] = []
    /// iOS's ローカルネットワーク permission is off for Fielua.
    @Published private(set) var denied = false
    /// Five seconds of searching with nothing found: time for the page's hints.
    @Published private(set) var searchedAWhile = false
    private(set) var startedAt: Date?
    /// Called on the main actor when `found` changes.
    var changed: (@MainActor () -> Void)?
    private var browser: NWBrowser?
    private var patience: Task<Void, Never>?
    private var standIn: Found?
    /// `found` is what was heard before the app left: it stays on the page
    /// until this search has answered, or for three seconds, so that the
    /// list doesn't empty and fill again on every return (1.1.0 (263); UI
    /// review, 2026-11-11). It doesn't count as heard now.
    private var stale = false
    private var staleness: Task<Void, Never>?
    /// The PCs this search has heard (none of a list kept from before).
    var heard: [Found] { stale ? [] : found }

    func start() {
        guard browser == nil else { return }
        #if POCKET_PREVIEW
        // The pc-link UI check's stand-in PC, as Bonjour would list it.
        if let argument = ProcessInfo.processInfo.arguments.first(where: { $0.hasPrefix("--pc-link-found=") }),
           let address = PCLink.address(String(argument.dropFirst("--pc-link-found=".count))) {
            standIn = Found(id: "fakepc0123456789", name: "テスト用PC", host: address.host, port: address.port,
                            fingerprint: nil, selectable: true)
        }
        #endif
        startedAt = Date()
        searchedAWhile = false
        if let standIn { show([standIn]) }
        let parameters = NWParameters()
        parameters.includePeerToPeer = false
        let browser = NWBrowser(for: .bonjourWithTXTRecord(type: PCLink.serviceType, domain: "local."), using: parameters)
        browser.stateUpdateHandler = { [weak self] state in
            let denied: Bool
            switch state {
            case .waiting(let error), .failed(let error):
                if case .dns(let code) = error { denied = code == -65570 } else { denied = false }
            default:
                denied = false
            }
            Task { @MainActor in self?.denied = denied }
        }
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            let list = results.compactMap(Self.found).sorted { $0.name < $1.name }
            Task { @MainActor in
                guard let self else { return }
                self.show((self.standIn.map { [$0] } ?? []) + list.filter { $0.id != self.standIn?.id })
            }
        }
        browser.start(queue: .main)
        self.browser = browser
        patience = Task { [weak self] in
            try? await Task.sleep(for: .seconds(5))
            guard !Task.isCancelled else { return }
            self?.searchedAWhile = true
        }
        if stale {
            // Nothing announced any more: no result comes to say so.
            staleness = Task { [weak self] in
                try? await Task.sleep(for: .seconds(3))
                guard !Task.isCancelled, let self, self.stale else { return }
                self.show(self.standIn.map { [$0] } ?? [])
            }
        }
    }

    /// `keepingList`: the app goes to the background; the list is shown
    /// again as it comes back, until the new search has answered.
    func stop(keepingList: Bool = false) {
        browser?.cancel()
        browser = nil
        patience?.cancel()
        patience = nil
        staleness?.cancel()
        staleness = nil
        startedAt = nil
        searchedAWhile = false
        if keepingList, !found.isEmpty {
            stale = true
        } else {
            stale = false
            show([])
        }
    }

    private func show(_ list: [Found]) {
        guard list != found || stale else { return }
        stale = false
        staleness?.cancel()
        staleness = nil
        if list != found { found = list }
        changed?()
    }

    nonisolated private static func found(_ result: NWBrowser.Result) -> Found? {
        guard case let .service(name, _, _, _) = result.endpoint,
              case let .bonjour(record) = result.metadata else { return nil }
        let values = record.dictionary
        guard values["v"] == String(PCLink.protocolVersion), let id = values["id"], !id.isEmpty, id.count <= 64,
              id.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber) }),
              let port = values["p"].flatMap(Int.init), (1...65535).contains(port) else { return nil }
        let fingerprint = values["fp"].flatMap(PCLink.data(base64URL:)).flatMap { $0.count == 32 ? $0 : nil }
        return Found(id: id, name: String(name.prefix(60)), host: PCLink.mdnsHost(pcID: id), port: port, fingerprint: fingerprint,
                     selectable: values[PCLink.pairKey] == PCLink.pairSelect)
    }
}

/// The iPhone's own network as iOS reports it (1.1.0 (254)): whether it is
/// on a Wi-Fi (or wired) network, and that network's IPv4 range, for
/// telling "another network" and "the PC's hotspot" apart. Read only.
@MainActor final class PCLinkPath: ObservableObject {
    struct Facts: Equatable {
        /// nil before iOS has said.
        var onLocalNetwork: Bool?
        var network: PCLinkNetwork?
    }

    @Published private(set) var facts = Facts()
    /// Called on the main actor when `facts` change (not for the first
    /// report, which only says where the iPhone already is).
    var changed: (@MainActor () -> Void)?
    private var monitor: NWPathMonitor?
    private var heard = false

    func start() {
        guard monitor == nil else { return }
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { [weak self] path in
            let names = path.availableInterfaces.filter { $0.type == .wifi || $0.type == .wiredEthernet }.map(\.name)
            let network = Self.network(on: names)
            let facts = Facts(onLocalNetwork: network != nil, network: network)
            Task { @MainActor in
                guard let self, self.monitor != nil else { return }
                let first = !self.heard
                self.heard = true
                guard self.facts != facts else { return }
                self.facts = facts
                if !first { self.changed?() }
            }
        }
        monitor.start(queue: DispatchQueue(label: "fielua.pc-link.path"))
        self.monitor = monitor
    }

    func stop() {
        monitor?.cancel()
        monitor = nil
        heard = false
    }

    /// The first IPv4 network on these interfaces (getifaddrs); a
    /// self-assigned 169.254 address is no network.
    nonisolated private static func network(on names: [String]) -> PCLinkNetwork? {
        guard !names.isEmpty else { return nil }
        var list: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&list) == 0, let first = list else { return nil }
        defer { freeifaddrs(list) }
        var found: [String: PCLinkNetwork] = [:]
        for pointer in sequence(first: first, next: { $0.pointee.ifa_next }) {
            let entry = pointer.pointee
            guard let address = entry.ifa_addr, address.pointee.sa_family == UInt8(AF_INET), let mask = entry.ifa_netmask,
                  let name = entry.ifa_name.map({ String(cString: $0) }), names.contains(name), found[name] == nil else { continue }
            let value = Self.ipv4(address), maskValue = Self.ipv4(mask)
            guard value >> 16 != 0xA9FE else { continue }
            if let network = PCLinkNetwork(address: Self.dotted(value), netmask: Self.dotted(maskValue)) { found[name] = network }
        }
        return names.lazy.compactMap { found[$0] }.first
    }

    /// The address in a sockaddr_in, in host order. A netmask's sockaddr
    /// may be cut short after its last non-zero byte.
    nonisolated private static func ipv4(_ address: UnsafeMutablePointer<sockaddr>) -> UInt32 {
        let length = Int(address.pointee.sa_len)
        let available = length == 0 ? 8 : min(length, 8)
        var value: UInt32 = 0
        address.withMemoryRebound(to: UInt8.self, capacity: 8) { bytes in
            for index in 4..<8 { value = value << 8 | UInt32(index < available ? bytes[index] : 0) }
        }
        return value
    }

    nonisolated private static func dotted(_ value: UInt32) -> String {
        [24, 16, 8, 0].map { String((value >> UInt32($0)) & 0xFF) }.joined(separator: ".")
    }
}
