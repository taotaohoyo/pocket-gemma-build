import SwiftUI
import PocketCore

/// Claude in the composer's model menu and the Smart Mode genre menu
/// (1.1.0 (257)): a submenu, as Gemma 4's, with the relay's models in its
/// order (Claude Opus 5.5 first, Fielua's top choice at 超高), each a
/// checkable item that starts a chat answered by it, said to be an
/// external AI. Nothing on an iPhone not registered with the relay. Its
/// own view, so the chat's menus stay as shallow as they were (LAUNCH STACK).
struct ClaudeModelMenuSection: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    let current: ClaudeChatTarget?
    let choose: (ClaudeModel) -> Void

    var body: some View {
        if link.isRegistered {
            Section {
                Menu {
                    Section("外部AI · インターネット経由") {
                        ForEach(link.models) { model in
                            Toggle(isOn: Binding(get: { current?.model == model.id }, set: { if $0 { choose(model) } })) {
                                Text(verbatim: model.name)
                                Text(levelLine(model))
                            }
                            .accessibilityIdentifier("model-menu-\(model.id)")
                        }
                    }
                } label: {
                    Text(verbatim: "Claude")
                    Text(subtitle)
                }
                .accessibilityIdentifier("model-menu-claude")
            }
        }
    }

    /// The level a chat with this model gets: this chat's, or the one
    /// chosen last for the model.
    private func levelLine(_ model: ClaudeModel) -> String {
        let target = current.flatMap { $0.model == model.id ? $0 : nil } ?? link.target(for: model)
        guard let level = target.level else { return String(localized: "外部AI · インターネット経由") }
        if target.isTop { return String(localized: "推論レベル \(level.title) · Fieluaの最上級") }
        return String(localized: "推論レベル \(level.title)")
    }

    private var subtitle: String {
        if case .unavailable(let reason) = link.state { return reason.short }
        switch link.state {
        case .revoked: return String(localized: "利用を止められています")
        case .removed: return String(localized: "登録が削除されました")
        case .unreachable: return String(localized: "接続できません")
        default:
            if let current { return String(localized: "\(current.shortName)を使用中") }
            return String(localized: "外部AI · インターネット経由")
        }
    }
}

/// A Claude chat's model settings, where its header leads as a phone
/// model's does (1.1.0 (257)): the reasoning level, from those the model
/// takes (Anthropic's max is never offered), for this chat from its next
/// question, and for the next chat with the model. Laid out as 構成.
struct ClaudeChatSettingsView: View {
    @EnvironmentObject private var chats: ChatStore
    @ObservedObject private var link = ClaudeLinkStore.shared
    @Environment(\.dismiss) private var dismiss
    let target: ClaudeChatTarget
    @State private var effort: ClaudeEffort

    init(target: ClaudeChatTarget) {
        self.target = target
        _effort = State(initialValue: target.level ?? .medium)
    }

    private var model: ClaudeModel? { link.model(target.model) }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker(selection: $effort) {
                        ForEach(ClaudeEffort.allCases, id: \.self) { level in
                            ClaudeEffortRow(level: level, top: target.model == ClaudeModel.opus.id && level == .xhigh,
                                            standard: model?.defaultEffort == level)
                                .tag(level)
                                .disabled(model?.efforts.contains(level) != true)
                        }
                    } label: {
                        Text("推論レベル")
                    }
                    .pickerStyle(.inline)
                    .labelsHidden()
                    .accessibilityIdentifier("claude-effort")
                } header: {
                    Text("推論レベル")
                } footer: {
                    Text("上げるほどよく考えて答えます。返信が始まるまでの時間と料金も増えます。このチャットの次の送信から反映され、このモデルの次のチャットにも使います。モデルが対応していないレベルは選べません。")
                }
                .fieluaFormSection()
                Section {
                    LabeledContent("モデル") { Text(verbatim: target.modelName) }
                        .accessibilityIdentifier("claude-settings-model")
                    Text("Anthropicの公式APIで答える外部AIです。モデルは入力欄のモデル選択で変えられます（新しいチャットになります）。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .fieluaFormSection()
            }
            .scrollContentBackground(.hidden)
            .fieluaPageBackground()
            .safeAreaBar(edge: .top, spacing: 0) {
                Text("\(target.modelName)の設定").font(.subheadline).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 6)
                    .accessibilityIdentifier("configuration-model")
            }
            .navigationTitle("構成").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() }.accessibilityIdentifier("configuration-cancel") }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存", systemImage: "checkmark", role: .confirm) { chats.setClaudeEffort(effort); dismiss() }
                        .disabled(model?.efforts.contains(effort) != true)
                        .accessibilityIdentifier("configuration-save")
                }
            }
        }
        .accessibilityIdentifier("claude-chat-settings")
    }
}

/// One level in the picker: its name, 標準 for the model's default, and
/// what it does.
private struct ClaudeEffortRow: View {
    let level: ClaudeEffort
    /// Claude Opus 5.5 at 超高.
    let top: Bool
    let standard: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 6) {
                Text(level.title)
                if standard { Text("標準").font(.caption).foregroundStyle(.secondary) }
                if top { Text("Fieluaの最上級").font(.caption.weight(.semibold)).foregroundStyle(Theme.icon) }
            }
            Text(level.help).font(.caption).foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("claude-effort-\(level.rawValue)")
    }
}

/// A Claude chat's lines under its model's name: that it is an external
/// AI whose answers may be wrong, and, when Claude can't answer now, why
/// in a few words, so a question isn't sent into nothing.
struct ClaudeChatStateNote: View {
    @ObservedObject private var link = ClaudeLinkStore.shared

    var body: some View {
        VStack(spacing: 3) {
            Text("AnthropicのAIが答えます。誤りを含むことがあります。")
                .font(.system(size: 11)).foregroundStyle(.secondary)
                .accessibilityIdentifier("chat-claude-disclosure")
            if let problem = link.problem {
                Text(problem)
                    .font(.system(size: 11)).foregroundStyle(Theme.caution)
                    .accessibilityIdentifier("chat-claude-note")
            }
        }
        .multilineTextAlignment(.center)
        .onAppear { link.refresh() }
    }
}

/// Claude's mark: a cloud, as an AI reached over the internet, in
/// Fielua's warm grey on the card's paper (no one else's logo).
struct ClaudeMark: View {
    let size: CGFloat
    var body: some View {
        Image(systemName: "cloud")
            .font(.system(size: size * 0.46, weight: .regular))
            .foregroundStyle(Theme.icon)
            .frame(width: size, height: size)
            .background(Theme.ink.opacity(0.06), in: RoundedRectangle(cornerRadius: size * 0.26, style: .continuous))
            .accessibilityHidden(true)
    }
}

extension ClaudeEffort {
    /// 低, 中, 高, 超高.
    var title: String {
        switch self {
        case .low: return String(localized: "低")
        case .medium: return String(localized: "中")
        case .high: return String(localized: "高")
        case .xhigh: return String(localized: "超高")
        }
    }

    var help: String {
        switch self {
        case .low: return String(localized: "速く答えます。短い質問や確認に。")
        case .medium: return String(localized: "速さと深さのバランスをとります。")
        case .high: return String(localized: "難しい質問をじっくり考えます。")
        case .xhigh: return String(localized: "さらに深く考えます。時間と料金がいちばん増えます。")
        }
    }
}

extension ClaudeChatTarget {
    /// "Opus 5.5", for the model pill.
    var shortName: String { modelName.hasPrefix("Claude ") ? String(modelName.dropFirst(7)) : modelName }
    /// The level its questions go with: the chat's, or the model's default
    /// for a chat from before levels.
    var level: ClaudeEffort? { effort ?? ClaudeModel.builtIn.first { $0.id == model }?.defaultEffort }
    /// The chat's line: the model, its level, and that it is an external AI.
    var line: String {
        guard let level else { return String(localized: "\(modelName) · 外部AI") }
        return String(localized: "\(modelName) · 推論 \(level.title) · 外部AI")
    }
    /// For VoiceOver on the header and the model pill.
    var spoken: String {
        guard let level else { return String(localized: "\(modelName)、外部AI") }
        return String(localized: "\(modelName)、推論レベル\(level.title)、外部AI")
    }
}
