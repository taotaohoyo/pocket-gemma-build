import SwiftUI
import PocketCore

/// 起動時のチャット's two choices (user, 2026-10-25 13:55 UTC, 「起動時のチャット
/// 選択機能・オンボーディング拡張」) on 入力スタイル's small phones
/// (ComposerStylePreview), side by side on one clock. Both start on a home
/// screen of plain icons and a Dock: a finger taps Fielua's own icon and
/// the app opens out of it, as iOS opens an app, without a bounce. Then
/// 前回の会話 shows the conversation as it was left, and 新しいチャット an
/// empty chat, the keyboard coming up from the bottom and 「前回の会話に戻る」
/// rising in over the field. Both hold that moment long enough to compare,
/// then fade back to the home screen together. The composer is drawn in the
/// type chosen (スタンダード or スマート), and the drawing changes nothing
/// real: no chat opens, no keyboard comes up. As 入力スタイル's phones, they
/// play only while the page is in view and at rest; with Reduce Motion each
/// holds its moment.
struct LaunchChatPicker: View {
    @Binding var selection: LaunchChatMode
    let style: ComposerStyle
    @Environment(\.settingsPageInView) private var pageInView
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var onScreen = true
    @State private var clock = ComposerDemoClock()
    #if POCKET_PREVIEW
    @State private var demoOver = false
    #endif

    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    private var playing: Bool {
        pageInView && onScreen && scenePhase == .active && !reduceMotion && plays
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ForEach(LaunchChatMode.allCases) { mode in option(mode) }
        }
        .frame(maxWidth: .infinity)
        .sensoryFeedback(.selection, trigger: selection)
        // Mostly on screen (they shared キーボードと入力 with 入力スタイル's
        // phones until 1.1.0 (191)).
        .onScrollVisibilityChange(threshold: 0.5) { onScreen = $0 }
        .onChange(of: playing, initial: true) { _, playing in clock.set(playing: playing) }
        .task { await endDemo() }
    }

    #if POCKET_PREVIEW
    private var plays: Bool { LaunchChatBeat.plays && !demoOver }
    /// About two loops, then back to the start and still, so the UI check
    /// can ask the page things again.
    private func endDemo() async {
        guard LaunchChatBeat.plays else { return }
        do { try await Task.sleep(for: .seconds(16)) } catch { return }
        clock.reset()
        demoOver = true
    }
    #else
    private var plays: Bool { true }
    private func endDemo() async {}
    #endif

    private func option(_ mode: LaunchChatMode) -> some View {
        let selected = selection == mode
        return Button {
            guard selection != mode else { return }
            withAnimation(FieluaMotion.change(reduceMotion)) { selection = mode }
        } label: {
            VStack(spacing: 10) {
                LaunchChatPhone(mode: mode, style: style, clock: clock, playing: playing, still: reduceMotion)
                Text(mode.title)
                    .font(.callout.weight(.semibold))
                    .foregroundStyle(.primary)
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 22))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(selected ? Theme.onAccent : Color(uiColor: .tertiaryLabel), Theme.accent)
                    .contentTransition(.symbolEffect(.replace))
            }
            .frame(maxWidth: 156)
            .contentShape(Rectangle())
        }
        .buttonStyle(ComposerStyleOptionStyle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(mode.title)
        .accessibilityHint(mode.previewHint)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("launch-chat-\(mode.rawValue)")
    }
}

/// One phone, as 入力スタイル's: a Canvas redrawn on the display's beat while
/// it plays, its outline a thin line apart from it.
private struct LaunchChatPhone: View {
    let mode: LaunchChatMode
    let style: ComposerStyle
    let clock: ComposerDemoClock
    let playing: Bool
    let still: Bool
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let palette = ComposerDemoPalette(scheme)
        let colors = LaunchChatColors(scheme)
        TimelineView(.animation(minimumInterval: nil, paused: !playing)) { context in
            let scene = still ? LaunchChatScene.still(mode) : LaunchChatScene(mode, at: clock.time(at: context.date))
            Canvas { ctx, size in
                let icon = ctx.resolve(Image("FieluaIcon"))
                LaunchChatDrawing(scene: scene, style: style, palette: palette, colors: colors, icon: icon)
                    .draw(in: &ctx, size: size)
            } symbols: {
                ForEach(ComposerDemoSymbol.allCases, id: \.self) { symbol in
                    Image(systemName: symbol.name)
                        .font(.system(size: symbol.size, weight: .medium))
                        .foregroundStyle(palette.symbol)
                        .tag(symbol)
                }
                Image(systemName: "sidebar.left")
                    .font(.system(size: 20, weight: .medium))
                    .foregroundStyle(palette.symbol)
                    .tag(LaunchChatSymbol.sidebar)
                // The capsule's label, a little larger than the chat's so it
                // still reads on the small phone.
                HStack(spacing: 7) {
                    Image(systemName: "arrow.uturn.backward")
                    Text("前回の会話に戻る")
                }
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(palette.symbol)
                .fixedSize()
                .tag(LaunchChatSymbol.back)
            }
        }
        .aspectRatio(ComposerDemo.screen.width / ComposerDemo.screen.height, contentMode: .fit)
        .overlay {
            ComposerDemoScreenShape().strokeBorder(palette.outline, lineWidth: 1)
        }
        .accessibilityHidden(true)
    }
}

private enum LaunchChatSymbol: Hashable { case sidebar, back }

/// The home screen's and the keyboard's greys, beside ComposerDemoPalette's.
struct LaunchChatColors {
    let wallTop, wallBottom, icon, iconRim, dock, dockRim, keyboard, keyboardRim, key, modifier: Color
    /// How far the home screen darkens as the app opens over it.
    let dim: Double

    init(_ scheme: ColorScheme) {
        if scheme == .dark {
            wallTop = Color(white: 0.17); wallBottom = Color(white: 0.09)
            icon = Color(white: 0.27); iconRim = Color(white: 0.36)
            dock = Color(white: 0.2); dockRim = Color(white: 0.3)
            keyboard = Color(white: 0.13); keyboardRim = Color(white: 0.3)
            key = Color(white: 0.31); modifier = Color(white: 0.21)
            dim = 0.4
        } else {
            wallTop = Color(white: 0.93); wallBottom = Color(white: 0.85)
            icon = Color(white: 0.985); iconRim = Color(white: 0.76)
            dock = Color(white: 0.955); dockRim = Color(white: 0.8)
            keyboard = Color(white: 0.9); keyboardRim = Color(white: 0.78)
            key = .white; modifier = Color(white: 0.8)
            dim = 0.2
        }
    }
}

/// The home screen and the app's places, in the screen's points (a
/// 402 x 874 iPhone, as ComposerDemo's).
enum LaunchChatLayout {
    static let icon: CGFloat = 64
    /// iOS's icon corners, continuous.
    static func iconRadius(_ size: CGFloat) -> CGFloat { size * 0.225 }
    static let columns: [CGFloat] = [27, 121.67, 216.33, 311]
    static let rows: [CGFloat] = [80, 178]
    /// Fielua's place: the second row, third column.
    static let fielua = CGRect(x: columns[2], y: rows[1], width: icon, height: icon)
    static let dock = CGRect(x: 14, y: 766, width: 374, height: 90)
    static let dockIcon: CGFloat = 62
    /// The keyboard, as iOS's on this phone, its bottom 34pt the home area.
    static let keyboard: CGFloat = 336
    static let home: CGFloat = 34
    /// Up with the keyboard, the composer sits on it: the bar's bottom 6pt
    /// above its top.
    static let lift = keyboard - home
}

/// Where everything is at one moment of the loop.
struct LaunchChatScene {
    let mode: LaunchChatMode
    var finger: ComposerDemoScene.Finger?
    /// The icon darkening under the finger.
    var press: Double = 0
    /// The app opening out of the icon: 0 the icon, 1 the whole screen.
    var launch: CGFloat = 0
    /// The app over the icon as it opens.
    var appIn: Double = 0
    /// 新しいチャット: the keyboard up, スタンダード's pills out, the capsule in,
    /// and the field's caret.
    var keyboard: CGFloat = 0
    var pills: Double = 0
    var capsule: CGFloat = 0
    var caret: Double = 0
    /// How far the loop's start has faded in over this moment.
    var restart: Double = 0

    init(mode: LaunchChatMode) { self.mode = mode }

    init(_ mode: LaunchChatMode, at elapsed: TimeInterval) {
        typealias Beat = LaunchChatBeat
        self.mode = mode
        let t = elapsed.truncatingRemainder(dividingBy: Beat.loop)
        finger = Beat.finger(at: t)
        press = Beat.press(at: t)
        launch = Beat.launch(at: t)
        appIn = Beat.appIn(at: t)
        restart = Beat.restart(at: t)
        if mode == .newChat {
            keyboard = Beat.keyboard(at: t)
            pills = Beat.pills(at: t)
            capsule = Beat.capsule(at: t)
            caret = Beat.caret(at: t)
        }
    }

    /// With Reduce Motion: each choice's app, open, as it holds in the loop.
    static func still(_ mode: LaunchChatMode) -> LaunchChatScene {
        var scene = LaunchChatScene(mode: mode)
        scene.launch = 1; scene.appIn = 1
        if mode == .newChat {
            scene.keyboard = 1; scene.pills = 1; scene.capsule = 1; scene.caret = 1
        }
        return scene
    }
}

/// The loop's timing, the same for both phones (seconds from its start):
/// the home screen at rest, the tap, the app opening, then 新しいチャット's
/// keyboard and capsule as the chat brings them (ChatView.openAtLaunch:
/// the keyboard asked for at once, the capsule a moment later); both hold
/// four seconds and fade back to the start.
enum LaunchChatBeat {
    static let loop: TimeInterval = 7.6
    static let fingerIn: TimeInterval = 0.6
    static let pressAt: TimeInterval = 0.92
    static let releaseAt: TimeInterval = 1.04
    static let launchAt: TimeInterval = 1.08
    /// iOS's opening is smooth and does not overshoot.
    static let launchSpring = Spring(duration: 0.62, bounce: 0)
    static let keyboardAt: TimeInterval = 1.95
    /// Close to the keyboard's own curve (ChatMotion.keyboardFollow).
    static let keyboardSpring = Spring(duration: 0.42, bounce: 0)
    static let capsuleAt: TimeInterval = 2.3
    static let capsuleSpring = Spring(duration: 0.4, bounce: 0)
    static let restartFrom: TimeInterval = 6.75
    static let restartLength: TimeInterval = 0.6

    #if POCKET_PREVIEW
    /// As ComposerDemo.plays: still in UI checks unless one comes to watch,
    /// on the setup's page or on 設定's (1.1.0 (191)).
    static let plays = PreviewProbe.on("--launch-preview-demo") || PreviewProbe.on("--launch-settings-demo")
    #endif

    static func finger(at t: TimeInterval) -> ComposerDemoScene.Finger? {
        guard t >= fingerIn, t < releaseAt + 0.24 else { return nil }
        let appear = ease((t - fingerIn) / 0.18)
        let down = ease((t - pressAt) / 0.08)
        let lift = ease((t - releaseAt) / 0.22)
        let icon = LaunchChatLayout.fielua
        return .init(at: CGPoint(x: icon.midX + 4, y: icon.midY + 8),
                     scale: 1.15 - 0.15 * appear - 0.06 * down + 0.15 * lift, opacity: appear * (1 - lift))
    }

    static func press(at t: TimeInterval) -> Double {
        ease((t - pressAt) / 0.08) * (1 - ease((t - releaseAt) / 0.25))
    }

    static func launch(at t: TimeInterval) -> CGFloat { value(launchSpring, t - launchAt) }

    /// The app shows over the icon early, as iOS's does.
    static func appIn(at t: TimeInterval) -> Double { ease((t - launchAt - 0.02) / 0.2) }

    static func keyboard(at t: TimeInterval) -> CGFloat { value(keyboardSpring, t - keyboardAt) }

    /// スタンダード's pills come out of the field as the keyboard comes.
    static func pills(at t: TimeInterval) -> Double { ease((t - keyboardAt - 0.12) / 0.3) }

    static func capsule(at t: TimeInterval) -> CGFloat { value(capsuleSpring, t - capsuleAt) }

    /// The caret blinks once the field has the keyboard, about once a second.
    static func caret(at t: TimeInterval) -> Double {
        let since = t - keyboardAt - 0.25
        guard since > 0 else { return 0 }
        let phase = since.truncatingRemainder(dividingBy: 1.05)
        return ease(phase / 0.08) * (1 - ease((phase - 0.55) / 0.12))
    }

    static func restart(at t: TimeInterval) -> Double { ease((t - restartFrom) / restartLength) }

    private static func value(_ spring: Spring, _ time: TimeInterval) -> CGFloat {
        time <= 0 ? 0 : CGFloat(spring.value(target: 1.0, time: time))
    }
    private static func clamp(_ x: Double) -> Double { min(1, max(0, x)) }
    private static func ease(_ x: Double) -> Double { UnitCurve.easeInOut.value(at: clamp(x)) }
}

/// Draws one moment on the phone, scaled to the size it is given.
struct LaunchChatDrawing {
    let scene: LaunchChatScene
    let style: ComposerStyle
    let palette: ComposerDemoPalette
    let colors: LaunchChatColors
    let icon: GraphicsContext.ResolvedImage
    private typealias L = LaunchChatLayout

    /// The app's own drawing at rest (入力スタイル's phones).
    private var chat: ComposerDemoDrawing {
        ComposerDemoDrawing(scene: ComposerDemoScene(style: style), palette: palette)
    }

    func draw(in context: inout GraphicsContext, size: CGSize) {
        let scale = size.width / ComposerDemo.screen.width
        guard scale > 0 else { return }
        context.scaleBy(x: scale, y: scale)
        let hair = 0.75 / scale
        var screen = context
        screen.clip(to: Path(roundedRect: CGRect(origin: .zero, size: ComposerDemo.screen),
                             cornerRadius: ComposerDemo.screenRadius, style: .continuous))
        let first = LaunchChatDrawing(scene: LaunchChatScene(scene.mode, at: 0), style: style, palette: palette,
                                      colors: colors, icon: icon)
        if scene.restart >= 1 {
            first.drawMoment(in: &screen, hair: hair)
        } else {
            drawMoment(in: &screen, hair: hair)
            if scene.restart > 0 {
                var start = screen
                start.opacity = scene.restart
                start.drawLayer { layer in first.drawMoment(in: &layer, hair: hair) }
            }
        }
    }

    private func drawMoment(in context: inout GraphicsContext, hair: CGFloat) {
        let p = scene.launch
        if p < 0.999 { drawHome(in: &context, hair: hair) }
        if p > 0.0001 { drawWindow(in: &context, hair: hair) }
        if let finger = scene.finger { chat.drawFinger(finger, in: &context) }
    }

    // MARK: The home screen

    private func drawHome(in context: inout GraphicsContext, hair: CGFloat) {
        var home = context
        // It steps back behind the app opening out of the icon.
        let p = scene.launch, center = CGPoint(x: L.fielua.midX, y: L.fielua.midY)
        let zoom = 1 + 0.08 * p
        home.translateBy(x: center.x, y: center.y)
        home.scaleBy(x: zoom, y: zoom)
        home.translateBy(x: -center.x, y: -center.y)
        home.fill(Path(CGRect(x: -60, y: -60, width: 522, height: 994)),
                  with: .linearGradient(Gradient(colors: [colors.wallTop, colors.wallBottom]),
                                        startPoint: .zero, endPoint: CGPoint(x: 0, y: 874)))
        for row in L.rows {
            for column in L.columns {
                let rect = CGRect(x: column, y: row, width: L.icon, height: L.icon)
                if rect == L.fielua { drawFieluaIcon(in: rect, context: &home, hair: hair) }
                else { plainIcon(rect, in: &home, hair: hair) }
            }
        }
        // The Dock, a soft platter with four icons.
        let dock = Path(roundedRect: L.dock, cornerRadius: 38, style: .continuous)
        home.fill(dock, with: .color(colors.dock))
        home.stroke(dock, with: .color(colors.dockRim), lineWidth: hair)
        for slot in 0..<4 {
            let x = L.dock.minX + L.dock.width * CGFloat(2 * slot + 1) / 8
            plainIcon(CGRect(x: x - L.dockIcon / 2, y: L.dock.midY - L.dockIcon / 2, width: L.dockIcon, height: L.dockIcon),
                      in: &home, hair: hair)
        }
        if p > 0 {
            home.fill(Path(CGRect(x: -60, y: -60, width: 522, height: 994)), with: .color(.black.opacity(colors.dim * Double(p))))
        }
    }

    private func plainIcon(_ rect: CGRect, in context: inout GraphicsContext, hair: CGFloat) {
        let shape = Path(roundedRect: rect, cornerRadius: L.iconRadius(rect.width), style: .continuous)
        context.fill(shape, with: .color(colors.icon))
        context.stroke(shape, with: .color(colors.iconRim), lineWidth: hair)
    }

    /// Fielua's own icon, darkened while it is pressed.
    private func drawFieluaIcon(in rect: CGRect, context: inout GraphicsContext, hair: CGFloat) {
        let shape = Path(roundedRect: rect, cornerRadius: L.iconRadius(rect.width), style: .continuous)
        var image = context
        image.clip(to: shape)
        image.draw(icon, in: rect)
        if scene.press > 0 { image.fill(shape, with: .color(.black.opacity(0.28 * scene.press))) }
        context.stroke(shape, with: .color(colors.iconRim), lineWidth: hair)
    }

    // MARK: The app

    /// The app opening out of the icon: a rounded window from the icon's
    /// place to the whole screen, the app drawn to fill it, over the icon
    /// that fades as it grows.
    private func drawWindow(in context: inout GraphicsContext, hair: CGFloat) {
        let p = scene.launch
        let from = L.fielua, to = CGRect(origin: .zero, size: ComposerDemo.screen)
        let rect = CGRect(x: from.minX + (to.minX - from.minX) * p, y: from.minY + (to.minY - from.minY) * p,
                          width: from.width + (to.width - from.width) * p, height: from.height + (to.height - from.height) * p)
        let radius = L.iconRadius(from.width) + (ComposerDemo.screenRadius - L.iconRadius(from.width)) * p
        var window = context
        window.clip(to: Path(roundedRect: rect, cornerRadius: radius, style: .continuous))
        let scale = rect.width / ComposerDemo.screen.width
        var app = window
        app.translateBy(x: rect.midX - ComposerDemo.screen.width / 2 * scale,
                        y: rect.midY - ComposerDemo.screen.height / 2 * scale)
        app.scaleBy(x: scale, y: scale)
        if scene.appIn >= 0.999 {
            drawApp(in: &app, hair: hair / scale)
        } else {
            let side = max(rect.width, rect.height)
            window.draw(icon, in: CGRect(x: rect.midX - side / 2, y: rect.midY - side / 2, width: side, height: side))
            if scene.appIn > 0.001 {
                app.opacity = scene.appIn
                app.drawLayer { layer in drawApp(in: &layer, hair: hair / scale) }
            }
        }
    }

    private func drawApp(in context: inout GraphicsContext, hair: CGFloat) {
        let screen = Path(CGRect(origin: .zero, size: ComposerDemo.screen))
        switch scene.mode {
        case .resume:
            // The conversation as it was left, at its end; what is scrolled
            // up goes under the header past a soft edge, as in the chat,
            // so no part of a message rests beside the model's name.
            chat.drawScreen(screen, in: &context, hair: hair)
            let edge: CGFloat = 165
            context.fill(Path(CGRect(x: 0, y: 0, width: ComposerDemo.screen.width, height: edge)),
                         with: .linearGradient(Gradient(stops: [.init(color: palette.screen, location: 0),
                                                                .init(color: palette.screen, location: 0.73),
                                                                .init(color: palette.screen.opacity(0), location: 1)]),
                                               startPoint: .zero, endPoint: CGPoint(x: 0, y: edge)))
        case .newChat:
            drawNewChat(screen, in: &context, hair: hair)
        }
        drawHeader(in: &context, hair: hair)
    }

    /// ChatView's header: the sidebar button, the model's mark and name.
    private func drawHeader(in context: inout GraphicsContext, hair: CGFloat) {
        let button = Path(ellipseIn: CGRect(x: ComposerDemoLayout.gutter, y: 70, width: ChatMetrics.control,
                                            height: ChatMetrics.control))
        chat.glass(button, in: &context, hair: hair)
        if let glyph = context.resolveSymbol(id: LaunchChatSymbol.sidebar) {
            context.draw(glyph, at: CGPoint(x: ComposerDemoLayout.gutter + ChatMetrics.control / 2, y: 92), anchor: .center)
        }
        context.fill(Path(ellipseIn: CGRect(x: 181, y: 68, width: 40, height: 40)), with: .color(palette.chip))
        chat.glass(Path(roundedRect: CGRect(x: 166, y: 113, width: 70, height: 22), cornerRadius: 11), in: &context, hair: hair)
        context.fill(Path(roundedRect: CGRect(x: 180, y: 120.5, width: 42, height: 7), cornerRadius: 3.5),
                     with: .color(palette.placeholder))
    }

    /// An empty chat, only the model's name in it; the keyboard comes up,
    /// the composer on it (スタンダード's bar opening into the panel), the caret,
    /// and 「前回の会話に戻る」 over the field.
    private func drawNewChat(_ screen: Path, in context: inout GraphicsContext, hair: CGFloat) {
        context.fill(screen, with: .color(palette.screen))
        context.fill(Path(roundedRect: CGRect(x: 157, y: 158, width: 88, height: 9), cornerRadius: 4.5),
                     with: .color(palette.placeholder))
        let k = scene.keyboard
        if k > 0.0005 { drawKeyboard(top: ComposerDemo.screen.height - L.keyboard * k, in: &context, hair: hair) }
        var bar = context
        bar.translateBy(x: 0, y: -L.lift * k)
        // スタンダード's bar opens into スマート's panel as the field takes the
        // keys (1.1.0 (255); until 254 its pills rose above the field).
        chat.drawBar(in: &bar, hair: hair, open: style == .classic ? CGFloat(scene.pills) : 0)
        typealias C = ComposerDemoLayout
        // The top of the composer.
        let top: CGFloat
        switch style {
        case .folding:
            top = C.barBottom - C.panelHeight
            caret(CGRect(x: 26, y: top + 11, width: 2.5, height: 22), in: &bar)
        case .classic:
            let o = CGFloat(min(1, max(0, scene.pills)))
            top = C.barBottom - ChatMetrics.standardBar - (C.panelHeight - ChatMetrics.standardBar) * o
            // The bar at rest stands `standardBarMargin` further in (274).
            let rest: CGFloat = C.gutter + ChatMetrics.standardBarMargin + ChatMetrics.standardInset
            let after: CGFloat = rest + ChatMetrics.control + ChatMetrics.standardTextGap - 3
            let x = after * (1 - o) + 26 * o
            caret(CGRect(x: x, y: top + 15 - 4 * o, width: 2.5, height: 22), in: &bar)
        }
        drawCapsule(bottom: top - 14, in: &bar, hair: hair)
    }

    private func caret(_ rect: CGRect, in context: inout GraphicsContext) {
        guard scene.caret > 0.001 else { return }
        var mark = context
        mark.opacity *= scene.caret
        mark.fill(Path(roundedRect: rect, cornerRadius: rect.width / 2), with: .color(palette.symbol))
    }

    /// 「前回の会話に戻る」, centred, rising in a little as it shows.
    private func drawCapsule(bottom: CGFloat, in context: inout GraphicsContext, hair: CGFloat) {
        let c = scene.capsule
        guard c > 0.001, let label = context.resolveSymbol(id: LaunchChatSymbol.back) else { return }
        let height: CGFloat = 52
        let width = label.size.width + 44
        var capsule = context
        capsule.opacity *= Double(min(1, c * 1.4))
        let center = CGPoint(x: ComposerDemoLayout.center, y: bottom - height / 2 + 8 * (1 - c))
        let grow = 0.92 + 0.08 * c
        capsule.translateBy(x: center.x, y: center.y + height / 2)
        capsule.scaleBy(x: grow, y: grow)
        capsule.translateBy(x: -center.x, y: -center.y - height / 2)
        let shape = Path(roundedRect: CGRect(x: center.x - width / 2, y: center.y - height / 2, width: width, height: height),
                         cornerRadius: height / 2, style: .continuous)
        chat.glass(shape, in: &capsule, hair: hair)
        capsule.draw(label, at: center, anchor: .center)
    }

    /// iOS's keyboard, in plain keys: three rows of letters and the row
    /// with the space bar, on a panel with soft upper corners.
    private func drawKeyboard(top: CGFloat, in context: inout GraphicsContext, hair: CGFloat) {
        let panel = Path(roundedRect: CGRect(x: 0, y: top, width: 402, height: L.keyboard + 60), cornerRadius: 30,
                         style: .continuous)
        context.fill(panel, with: .color(colors.keyboard))
        context.stroke(panel, with: .color(colors.keyboardRim), lineWidth: hair)
        let key: CGFloat = 34.2, gap: CGFloat = 5.6, height: CGFloat = 42, side: CGFloat = 4.8
        func fill(_ rect: CGRect, _ color: Color) {
            context.fill(Path(roundedRect: rect, cornerRadius: 8.5, style: .continuous), with: .color(color))
        }
        func keys(_ count: Int, from x: CGFloat, y: CGFloat) {
            for index in 0..<count {
                fill(CGRect(x: x + CGFloat(index) * (key + gap), y: y, width: key, height: height), colors.key)
            }
        }
        let rows = (0..<4).map { top + 52 + CGFloat($0) * 54 }
        keys(10, from: side, y: rows[0])
        keys(9, from: (402 - 9 * key - 8 * gap) / 2, y: rows[1])
        fill(CGRect(x: side, y: rows[2], width: 44, height: height), colors.modifier)
        keys(7, from: (402 - 7 * key - 6 * gap) / 2, y: rows[2])
        fill(CGRect(x: 402 - side - 44, y: rows[2], width: 44, height: height), colors.modifier)
        fill(CGRect(x: side, y: rows[3], width: 90, height: height), colors.modifier)
        fill(CGRect(x: side + 90 + gap, y: rows[3], width: 402 - 2 * (side + 90 + gap), height: height), colors.key)
        fill(CGRect(x: 402 - side - 90, y: rows[3], width: 90, height: height), colors.modifier)
    }
}
