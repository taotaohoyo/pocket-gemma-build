import SwiftUI
import PocketCore

/// A recording (VoiceNote, 1.1.0 (236)) in the draft or in its message's
/// bubble, as Messages shows an audio message: play or stop, a waveform and
/// its length. It plays where it stands; it opens no preview.
struct VoiceNoteRow: View {
    let attachment: ChatAttachment
    var compact = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    private var player: VoicePlayer { .shared }

    var body: some View {
        let playing = player.playing == attachment.id
        Button { player.toggle(attachment) } label: {
            HStack(spacing: 8) {
                Image(systemName: playing ? "stop.fill" : "play.fill")
                    .font(.system(size: 12, weight: .bold))
                    .contentTransition(reduceMotion ? .identity : .symbolEffect(.replace))
                    .frame(width: 28, height: 28)
                    .background(Color.primary.opacity(0.1), in: Circle())
                Image(systemName: "waveform")
                    .font(.system(size: 17, weight: .medium))
                    .symbolEffect(.variableColor.iterative, isActive: playing && !reduceMotion)
                Text(verbatim: VoiceNote.clock(attachment.duration ?? 0))
                    .font(.subheadline.monospacedDigit())
            }
            .padding(.horizontal, compact ? 12 : 2)
            .frame(width: compact ? 130 : nil, alignment: .leading)
            .frame(minHeight: compact ? 64 : 36)
            .background(compact ? Color.secondary.opacity(0.06) : .clear, in: RoundedRectangle(cornerRadius: 12))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(attachment.name)
        .accessibilityValue(playing ? String(localized: "再生中") : "")
        .accessibilityHint(playing ? String(localized: "タップで止めます") : String(localized: "タップで再生します"))
        .accessibilityIdentifier("voice-note")
        .onDisappear { if player.playing == attachment.id { player.stop() } }
    }
}

/// Over the composer while a question is being recorded: a red dot, the
/// time so far and the voice's level, and a way to drop it. Send has
/// become the stop button meanwhile (ChatView). Its own view, so only it
/// follows the level twenty times a second, not the chat.
struct VoiceRecordingStrip: View {
    let recorder: VoiceRecorder
    let cancel: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "circle.fill")
                .font(.system(size: 9))
                .foregroundStyle(.red)
                .symbolEffect(.pulse, isActive: !reduceMotion)
                .accessibilityHidden(true)
            Text(verbatim: VoiceNote.clock(recorder.elapsed))
                .font(.subheadline.weight(.semibold).monospacedDigit())
                .contentTransition(reduceMotion ? .identity : .numericText())
            HStack(alignment: .center, spacing: 2) {
                ForEach(Array(recorder.levels.enumerated()), id: \.offset) { _, level in
                    Capsule().frame(width: 3, height: 4 + CGFloat(level) * 18)
                }
            }
            .foregroundStyle(.secondary)
            .frame(height: 22)
            .animation(reduceMotion ? nil : .linear(duration: 0.05), value: recorder.levels)
            .accessibilityHidden(true)
            Button(action: cancel) {
                Image(systemName: "xmark")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .frame(width: 44, height: 44)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("録音をやめる")
            .accessibilityHint("録音した音声を消します")
        }
        .padding(.leading, 16)
        .frame(minHeight: ChatMetrics.chip)
        .chatGlass(in: Capsule())
        .accessibilityElement(children: .contain)
        .accessibilityLabel("録音中")
        .accessibilityValue(VoiceNote.clock(recorder.elapsed))
        .accessibilityIdentifier("voice-recording")
    }
}
