import SwiftUI
import PocketCore

/// The conversation history as a sidebar under the conversation, laid out
/// after ChatGPT's (measured on a 402pt-wide iPhone): a bold title with a
/// search circle, plain one-line titles on a 48pt pitch, and a new chat
/// capsule at the bottom leading corner beside the settings circle.
struct HistoryView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.historySidebar) private var sidebar
    /// False as the phone's drawer begins to close (never beside an iPad's
    /// conversation): the search's keyboard goes with the history, not
    /// after it (1.1.0 (268)).
    @Environment(\.historyVisible) private var historyVisible
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    @State private var pendingDelete: ChatThread?
    @State private var showSettings = false
    @State private var searching = false
    @State private var query = ""
    @FocusState private var searchFocused: Bool
    @Namespace private var searchGlass
    @State private var search = HistorySearch()

    /// Every control and the selected row's highlight keep 24pt from both
    /// sides of the sidebar; title and row text line up 9pt inside that.
    private static let inset: CGFloat = 24
    private static let textInset: CGFloat = 9

    private var saved: [ChatThread] {
        chats.threads.filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }
    }

    private var shown: [ChatThread] {
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !needle.isEmpty else { return saved }
        return search.matches(needle, in: saved)
    }

    var body: some View {
        let _ = SettingsSlideMeter.drew("履歴")
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                let threads = shown
                if threads.isEmpty {
                    Text(saved.isEmpty ? "会話はまだありません" : "見つかりませんでした")
                        .foregroundStyle(.secondary)
                        .padding(.leading, Self.inset + Self.textInset).padding(.top, 12)
                } else {
                    ForEach(threads) { thread in row(thread) }
                }
            }
            .padding(.top, 8).padding(.bottom, 12)
        }
        .scrollDismissesKeyboard(.interactively)
        .modifier(SidebarScrollEdges())
        .safeAreaBar(edge: .top, spacing: 0) { header }
        .safeAreaBar(edge: .bottom, spacing: 0) { footer }
        .background(Theme.sidebar)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("history-sidebar")
        .onChange(of: historyVisible) { _, visible in
            guard !visible, searchFocused else { return }
            // The search's keyboard goes a moment after the history starts
            // to close (1.1.0 (272)). Going, it lays the window out in its
            // own animation, and a chat chosen from the results was laid
            // out in that same turn: its scroll view and buttons, new, came
            // in faint from the screen's leading edge over the closing
            // history and met the conversation's paper four frames on (UI
            // check run 43360091745; so since 267, 268's report). Chosen
            // first, the chat is laid out where it stands; its change of
            // chat leaves this keyboard to the history (ChatView, whose
            // putting every field away had sent it in that turn all the
            // same, run 43365104818).
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { searchFocused = false }
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .alert("この会話を削除しますか？", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } })) {
            Button("キャンセル", role: .cancel) { pendingDelete = nil }
            Button("削除", role: .destructive) {
                if let id = pendingDelete?.id { chats.delete(id) }
                pendingDelete = nil
            }
        } message: { Text(pendingDelete?.title ?? "") }
    }

    private func row(_ thread: ChatThread) -> some View {
        Button { sidebar?.select(thread.id) } label: {
            Text(thread.title)
                .font(.body)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, Self.textInset)
                .frame(height: 48)
                .background {
                    // The sidebar's own color, unseen in the list, gives the
                    // long-press preview a solid rounded platter.
                    RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.sidebar)
                    // The open chat: a warm grey wash (pale yellow until 1.1.0 (214)).
                    if thread.id == chats.selectedID {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Theme.selection)
                    }
                }
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(chats.isGenerating && thread.id != chats.selectedID)
        // A long press offers delete; a sideways swipe belongs to the sidebar.
        // The lifted preview is the row's own rounded shape: attached
        // outside the side insets, it lifted the whole sidebar-wide strip,
        // which ran under the conversation (1.0.53 on device).
        .contentShape(.contextMenuPreview, RoundedRectangle(cornerRadius: 14, style: .continuous))
        .contextMenu {
            Button("削除", systemImage: "trash", role: .destructive) { pendingDelete = thread }
                .disabled(chats.isGenerating)
        }
        .padding(.horizontal, Self.inset)
        .accessibilityLabel("会話を開く: \(thread.title)")
    }

    /// The search circle stays where it is and turns into the close button,
    /// while the field grows out of it as a second piece of glass and the
    /// magnifier slides across into the field.
    private var header: some View {
        ChatGlassGroup(spacing: 12) {
            HStack(spacing: 12) {
                if searching {
                    HStack(spacing: 8) {
                        searchGlyph(.secondary)
                        TextField("会話を検索", text: $query)
                            .focused($searchFocused)
                            .submitLabel(.search)
                            .onAppear { searchFocused = true }
                            .accessibilityIdentifier("history-search-field")
                    }
                    .padding(.horizontal, 16)
                    .frame(maxWidth: .infinity, minHeight: ChatMetrics.control, maxHeight: ChatMetrics.control)
                    .chatGlass(in: Capsule())
                    .chatGlassIdentity("search-field", in: searchGlass, reduceMotion: reduceMotion)
                } else {
                    // The flower and the wordmark in Apple's own serif (New
                    // York), so no font is bundled (brand 2026-10-27).
                    FieluaLockup(size: 24)
                        .padding(.leading, Self.textInset)
                        .transition(reduceMotion ? AnyTransition.opacity
                                    : AnyTransition.opacity.combined(with: .scale(scale: 0.94, anchor: .leading)))
                    Spacer(minLength: 8)
                }
                Button(action: searching ? endSearch : beginSearch) {
                    ZStack {
                        if searching {
                            Image(systemName: "xmark")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundStyle(Theme.tint)
                                .transition(reduceMotion ? AnyTransition.opacity
                                            : AnyTransition.scale(scale: 0.4).combined(with: .opacity))
                        } else {
                            searchGlyph(Theme.tint)
                        }
                    }
                    .frame(width: ChatMetrics.control, height: ChatMetrics.control)
                    .contentShape(Circle())
                    .chatGlass(in: Circle(), interactive: true)
                    .chatGlassIdentity("search-button", in: searchGlass, reduceMotion: reduceMotion)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(searching ? "検索を閉じる" : "会話を検索")
                .accessibilityIdentifier(searching ? "history-search-close" : "history-search")
            }
        }
        .padding(.horizontal, Self.inset)
        // Level with the conversation's header button, which sits 8pt
        // below the safe area.
        .padding(.top, 8).padding(.bottom, 6)
    }

    private func searchGlyph(_ style: Color) -> some View {
        Image(systemName: "magnifyingglass")
            .font(.system(size: 18, weight: .medium))
            .foregroundStyle(style)
            .matchedGeometryEffect(id: "search-glyph", in: searchGlass)
    }

    private var footer: some View {
        ChatGlassGroup(spacing: 12) {
            HStack {
                Button { sidebar?.compose() } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "square.and.pencil").font(.system(size: 19, weight: .semibold))
                        Text("チャット").font(.system(size: 17, weight: .semibold))
                    }
                    .foregroundStyle(Theme.onAccent)
                    .padding(.horizontal, 22)
                    .frame(height: 48)
                    .contentShape(Capsule())
                    .modifier(ProminentGlass(shape: Capsule()))
                }
                .buttonStyle(.plain)
                .opacity(chats.isGenerating ? 0.5 : 1)
                .disabled(chats.isGenerating)
                .accessibilityLabel("新しいチャット")
                .accessibilityIdentifier("history-compose")
                Spacer(minLength: 12)
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape")
                        .font(.system(size: 21, weight: .medium))
                        .foregroundStyle(.primary)
                        .frame(width: 48, height: 48)
                        .contentShape(Circle())
                        .chatGlass(in: Circle(), interactive: true)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("設定を開く")
                .accessibilityIdentifier("history-settings")
            }
        }
        // 4pt above the home indicator's safe area, level with the
        // conversation's plus button.
        .padding(.horizontal, Self.inset)
        .padding(.top, 8).padding(.bottom, 4)
    }

    private func beginSearch() {
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen) { searching = true }
    }

    private func endSearch() {
        searchFocused = false
        // The closing spring: the opening one overshot as the field shrank (1.1.0 (263)).
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuClose) { searching = false }
        query = ""
    }
}

/// The sidebar's search, remembered between draws (1.1.0 (263)). The list
/// is drawn again with every batch of a reply's text, and on an iPad it is
/// always there: each draw read every message of every chat again for the
/// words typed (UI review, 2026-11-11). A draw with the same words and the
/// same chats now reads nothing, and a longer word is looked for only in
/// what the shorter one found.
private final class HistorySearch {
    private struct Stamp: Equatable {
        let id: UUID
        let messages: Int
        let updated: Date
    }

    private var needle = ""
    private var stamps: [Stamp] = []
    private var found: Set<UUID> = []

    func matches(_ needle: String, in threads: [ChatThread]) -> [ChatThread] {
        let now = threads.map { Stamp(id: $0.id, messages: $0.messages.count, updated: $0.updatedAt) }
        let same = now == stamps
        if same, needle == self.needle { return threads.filter { found.contains($0.id) } }
        let narrows = same && !self.needle.isEmpty && needle.hasPrefix(self.needle)
        let pool = narrows ? threads.filter { found.contains($0.id) } : threads
        let hits = pool.filter { thread in
            thread.title.localizedStandardContains(needle)
                || thread.messages.contains { $0.text.localizedStandardContains(needle) }
        }
        self.needle = needle
        stamps = now
        found = Set(hits.map(\.id))
        return hits
    }
}

/// Titles fade softly under the header and the bottom buttons.
private struct SidebarScrollEdges: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.scrollEdgeEffectStyle(.soft, for: .all) }
        else { content }
    }
}
