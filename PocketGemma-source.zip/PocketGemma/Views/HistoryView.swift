import SwiftUI
import PocketCore

/// The conversation history as a sidebar under the conversation, laid out
/// after ChatGPT's (measured on a 402pt-wide iPhone): a bold title with a
/// search circle, plain one-line titles on a 48pt pitch, and a new chat
/// capsule at the bottom leading corner beside the settings circle.
struct HistoryView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.historySidebar) private var sidebar
    @State private var pendingDelete: ChatThread?
    @State private var showSettings = false
    @State private var searching = false
    @State private var query = ""
    @FocusState private var searchFocused: Bool

    /// Title and row text start 33pt in from the sidebar's leading edge.
    private static let leading: CGFloat = 33
    private static let trailing: CGFloat = 24

    private var saved: [ChatThread] {
        chats.threads.filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }
    }

    private var shown: [ChatThread] {
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !needle.isEmpty else { return saved }
        return saved.filter { thread in
            thread.title.localizedStandardContains(needle)
                || thread.messages.contains { $0.text.localizedStandardContains(needle) }
        }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                let threads = shown
                if threads.isEmpty {
                    Text(saved.isEmpty ? "会話はまだありません" : "見つかりませんでした")
                        .foregroundStyle(.secondary)
                        .padding(.leading, Self.leading).padding(.top, 12)
                } else {
                    ForEach(threads) { thread in row(thread) }
                }
            }
            .padding(.top, 8).padding(.bottom, 12)
        }
        .scrollDismissesKeyboard(.interactively)
        .modifier(SidebarScrollEdges())
        .safeAreaBar(edge: .top, spacing: 0) { header }
        .safeAreaBar(edge: .bottom, spacing: 0) { footer }
        .background(Theme.sidebar)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("history-sidebar")
        .sheet(isPresented: $showSettings) { ModelView() }
        .alert("この会話を削除しますか？", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } })) {
            Button("キャンセル", role: .cancel) { pendingDelete = nil }
            Button("削除", role: .destructive) {
                if let id = pendingDelete?.id { chats.delete(id) }
                pendingDelete = nil
            }
        } message: { Text(pendingDelete?.title ?? "") }
    }

    private func row(_ thread: ChatThread) -> some View {
        Button { sidebar?.select(thread.id) } label: {
            Text(thread.title)
                .font(.body)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, Self.leading - 16)
                .frame(height: 48)
                .background {
                    if thread.id == chats.selectedID {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Color.primary.opacity(0.06))
                    }
                }
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 16)
        .disabled(chats.isGenerating && thread.id != chats.selectedID)
        // A long press offers delete; a sideways swipe belongs to the sidebar.
        .contextMenu {
            Button("削除", systemImage: "trash", role: .destructive) { pendingDelete = thread }
                .disabled(chats.isGenerating)
        }
        .accessibilityLabel("会話を開く: \(thread.title)")
    }

    private var header: some View {
        HStack(spacing: 12) {
            if searching {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("会話を検索", text: $query)
                        .focused($searchFocused)
                        .submitLabel(.search)
                        .accessibilityIdentifier("history-search-field")
                }
                .padding(.horizontal, 16)
                .frame(height: ChatMetrics.control)
                .chatGlass(in: Capsule())
                ChatCircleButton(action: endSearch) {
                    Image(systemName: "xmark").font(.system(size: 17, weight: .medium))
                }
                .accessibilityLabel("検索を閉じる")
                .accessibilityIdentifier("history-search-close")
            } else {
                Text("Pocket Gemma")
                    .font(.system(size: 22, weight: .bold))
                    .lineLimit(1)
                    .padding(.leading, Self.leading - Self.trailing)
                Spacer(minLength: 8)
                ChatCircleButton {
                    searching = true
                    searchFocused = true
                } label: {
                    Image(systemName: "magnifyingglass").font(.system(size: ChatMetrics.icon, weight: .medium))
                }
                .accessibilityLabel("会話を検索")
                .accessibilityIdentifier("history-search")
            }
        }
        .padding(.leading, Self.trailing).padding(.trailing, Self.trailing)
        .padding(.bottom, 6)
    }

    private var footer: some View {
        ChatGlassGroup(spacing: 12) {
            HStack {
                Button { sidebar?.compose() } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "square.and.pencil").font(.system(size: 19, weight: .semibold))
                        Text("チャット").font(.system(size: 17, weight: .semibold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 22)
                    .frame(height: 48)
                    .contentShape(Capsule())
                    .modifier(ProminentGlass(shape: Capsule()))
                }
                .buttonStyle(.plain)
                .opacity(chats.isGenerating ? 0.5 : 1)
                .disabled(chats.isGenerating)
                .accessibilityLabel("新しいチャット")
                .accessibilityIdentifier("history-compose")
                Spacer(minLength: 12)
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape")
                        .font(.system(size: 21, weight: .medium))
                        .foregroundStyle(.primary)
                        .frame(width: 48, height: 48)
                        .contentShape(Circle())
                        .chatGlass(in: Circle(), interactive: true)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("モデルと設定を開く")
                .accessibilityIdentifier("history-settings")
            }
        }
        // ChatGPT's capsule starts 37pt in and sits 4pt above the home
        // indicator's safe area.
        .padding(.leading, 37).padding(.trailing, Self.trailing)
        .padding(.top, 8).padding(.bottom, 4)
    }

    private func endSearch() {
        searchFocused = false
        searching = false
        query = ""
    }
}

/// Titles fade softly under the header and the bottom buttons.
private struct SidebarScrollEdges: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.scrollEdgeEffectStyle(.soft, for: .all) }
        else { content }
    }
}
