import SwiftUI
import PocketCore

struct HistoryView: View {
    @EnvironmentObject private var chats: ChatStore
    @State private var pendingDelete: ChatThread?
    @State private var showSettings = false
    let onOpen: (UUID) -> Void
    let onCompose: () -> Void

    private var saved: [ChatThread] {
        chats.threads.filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        Group {
            Group {
                if saved.isEmpty {
                    ContentUnavailableView("会話はこれから", systemImage: "bubble.left.and.bubble.right",
                                           description: Text("話した内容はここに保存されます。"))
                } else {
                    List(saved) { thread in
                        Button {
                            onOpen(thread.id)
                        } label: {
                            HStack(alignment: .top, spacing: 12) {
                                ModelMark(model: ModelSpec.find(thread.modelID) ?? .e4b, size: 42)
                                VStack(alignment: .leading, spacing: 6) {
                                    HStack {
                                        Text(thread.title).font(.callout.weight(.semibold)).lineLimit(1)
                                        Spacer(minLength: 8)
                                        Text(thread.updatedAt, style: .date).font(.caption).foregroundStyle(.secondary)
                                        Image(systemName: "chevron.right").font(.caption2.weight(.semibold)).foregroundStyle(.tertiary)
                                    }
                                    Text(thread.messages.last?.text.isEmpty == false ? (thread.messages.last?.text ?? "") : "回答を停止しました")
                                        .font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                            }
                            .padding(.vertical, 6)
                        }
                        .accessibilityLabel("会話を開く: \(thread.title)")
                        .buttonStyle(.plain).disabled(chats.isGenerating && thread.id != chats.selectedID)
                        .swipeActions {
                            Button("削除", role: .destructive) { pendingDelete = thread }
                                .disabled(chats.isGenerating)
                        }
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                    .chatScrollEdges()
                }
            }
            // The native navigation bar owns large-title collapse, safe-area
            // clipping and scroll-edge material as one coordinated layer.
            .navigationTitle("メッセージ")
            .navigationBarTitleDisplayMode(.large)
            .toolbar(.visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                        .accessibilityLabel("モデルと設定を開く")
                        .accessibilityIdentifier("history-settings")
                }
            }
            .tint(Theme.accent)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                HStack {
                    Spacer()
                    ChatCircleButton(action: onCompose) {
                        Image(systemName: "square.and.pencil").font(.system(size: ChatMetrics.icon))
                    }
                    .accessibilityLabel("新しい会話").accessibilityIdentifier("history-compose")
                    .disabled(chats.isGenerating)
                }
                .padding(.horizontal, ChatMetrics.gutter).padding(.top, 8).padding(.bottom, 6)
            }
        }
        .sheet(isPresented: $showSettings) { ModelView() }
        .alert("この会話を削除しますか？", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } })) {
            Button("キャンセル", role: .cancel) { pendingDelete = nil }
            Button("削除", role: .destructive) {
                if let id = pendingDelete?.id { chats.delete(id) }
                pendingDelete = nil
            }
        } message: { Text(pendingDelete?.title ?? "") }
    }
}
