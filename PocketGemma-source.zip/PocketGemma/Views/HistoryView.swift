import SwiftUI
import PocketCore

/// The conversation history as a sidebar under the conversation, laid out
/// after ChatGPT's (measured on a 402pt-wide iPhone): a bold title with a
/// search circle, plain one-line titles on a 48pt pitch, and a new chat
/// capsule at the bottom leading corner beside the settings circle.
struct HistoryView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.historySidebar) private var sidebar
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    @State private var pendingDelete: ChatThread?
    @State private var showSettings = false
    @State private var searching = false
    @State private var query = ""
    @FocusState private var searchFocused: Bool
    @Namespace private var searchGlass

    /// Every control and the selected row's highlight keep 24pt from both
    /// sides of the sidebar; title and row text line up 9pt inside that.
    private static let inset: CGFloat = 24
    private static let textInset: CGFloat = 9

    private var saved: [ChatThread] {
        chats.threads.filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }
    }

    private var shown: [ChatThread] {
        let needle = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !needle.isEmpty else { return saved }
        return saved.filter { thread in
            thread.title.localizedStandardContains(needle)
                || thread.messages.contains { $0.text.localizedStandardContains(needle) }
        }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                let threads = shown
                if threads.isEmpty {
                    Text(saved.isEmpty ? "会話はまだありません" : "見つかりませんでした")
                        .foregroundStyle(.secondary)
                        .padding(.leading, Self.inset + Self.textInset).padding(.top, 12)
                } else {
                    ForEach(threads) { thread in row(thread) }
                }
            }
            .padding(.top, 8).padding(.bottom, 12)
        }
        .scrollDismissesKeyboard(.interactively)
        .modifier(SidebarScrollEdges())
        .safeAreaBar(edge: .top, spacing: 0) { header }
        .safeAreaBar(edge: .bottom, spacing: 0) { footer }
        .background(Theme.sidebar)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("history-sidebar")
        .sheet(isPresented: $showSettings) { ModelView() }
        .alert("この会話を削除しますか？", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } })) {
            Button("キャンセル", role: .cancel) { pendingDelete = nil }
            Button("削除", role: .destructive) {
                if let id = pendingDelete?.id { chats.delete(id) }
                pendingDelete = nil
            }
        } message: { Text(pendingDelete?.title ?? "") }
    }

    private func row(_ thread: ChatThread) -> some View {
        Button { sidebar?.select(thread.id) } label: {
            Text(thread.title)
                .font(.body)
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, Self.textInset)
                .frame(height: 48)
                .background {
                    if thread.id == chats.selectedID {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Color.primary.opacity(0.06))
                    }
                }
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(chats.isGenerating && thread.id != chats.selectedID)
        // A long press offers delete; a sideways swipe belongs to the sidebar.
        // The lifted preview is the row's own rounded shape: attached
        // outside the side insets, it lifted the whole sidebar-wide strip,
        // which ran under the conversation (1.0.53 on device).
        .contentShape(.contextMenuPreview, RoundedRectangle(cornerRadius: 14, style: .continuous))
        .contextMenu {
            Button("削除", systemImage: "trash", role: .destructive) { pendingDelete = thread }
                .disabled(chats.isGenerating)
        }
        .padding(.horizontal, Self.inset)
        .accessibilityLabel("会話を開く: \(thread.title)")
    }

    /// The search circle stays where it is and turns into the close button,
    /// while the field grows out of it as a second piece of glass and the
    /// magnifier slides across into the field.
    private var header: some View {
        ChatGlassGroup(spacing: 12) {
            HStack(spacing: 12) {
                if searching {
                    HStack(spacing: 8) {
                        searchGlyph(.secondary)
                        TextField("会話を検索", text: $query)
                            .focused($searchFocused)
                            .submitLabel(.search)
                            .onAppear { searchFocused = true }
                            .accessibilityIdentifier("history-search-field")
                    }
                    .padding(.horizontal, 16)
                    .frame(maxWidth: .infinity, minHeight: ChatMetrics.control, maxHeight: ChatMetrics.control)
                    .chatGlass(in: Capsule())
                    .chatGlassIdentity("search-field", in: searchGlass, reduceMotion: reduceMotion)
                } else {
                    Text("Pocket AI")
                        .font(.system(size: 22, weight: .bold))
                        .lineLimit(1)
                        .padding(.leading, Self.textInset)
                        .transition(reduceMotion ? AnyTransition.opacity
                                    : AnyTransition.opacity.combined(with: .scale(scale: 0.94, anchor: .leading)))
                    Spacer(minLength: 8)
                }
                Button(action: searching ? endSearch : beginSearch) {
                    ZStack {
                        if searching {
                            Image(systemName: "xmark")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundStyle(Theme.accent)
                                .transition(reduceMotion ? AnyTransition.opacity
                                            : AnyTransition.scale(scale: 0.4).combined(with: .opacity))
                        } else {
                            searchGlyph(Theme.accent)
                        }
                    }
                    .frame(width: ChatMetrics.control, height: ChatMetrics.control)
                    .contentShape(Circle())
                    .chatGlass(in: Circle(), interactive: true)
                    .chatGlassIdentity("search-button", in: searchGlass, reduceMotion: reduceMotion)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(searching ? "検索を閉じる" : "会話を検索")
                .accessibilityIdentifier(searching ? "history-search-close" : "history-search")
            }
        }
        .padding(.horizontal, Self.inset)
        // Level with the conversation's header button, which sits 8pt
        // below the safe area.
        .padding(.top, 8).padding(.bottom, 6)
    }

    private func searchGlyph(_ style: Color) -> some View {
        Image(systemName: "magnifyingglass")
            .font(.system(size: 18, weight: .medium))
            .foregroundStyle(style)
            .matchedGeometryEffect(id: "search-glyph", in: searchGlass)
    }

    private var footer: some View {
        ChatGlassGroup(spacing: 12) {
            HStack {
                Button { sidebar?.compose() } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "square.and.pencil").font(.system(size: 19, weight: .semibold))
                        Text("チャット").font(.system(size: 17, weight: .semibold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 22)
                    .frame(height: 48)
                    .contentShape(Capsule())
                    .modifier(ProminentGlass(shape: Capsule()))
                }
                .buttonStyle(.plain)
                .opacity(chats.isGenerating ? 0.5 : 1)
                .disabled(chats.isGenerating)
                .accessibilityLabel("新しいチャット")
                .accessibilityIdentifier("history-compose")
                Spacer(minLength: 12)
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape")
                        .font(.system(size: 21, weight: .medium))
                        .foregroundStyle(.primary)
                        .frame(width: 48, height: 48)
                        .contentShape(Circle())
                        .chatGlass(in: Circle(), interactive: true)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("モデルと設定を開く")
                .accessibilityIdentifier("history-settings")
            }
        }
        // 4pt above the home indicator's safe area, level with the
        // conversation's plus button.
        .padding(.horizontal, Self.inset)
        .padding(.top, 8).padding(.bottom, 4)
    }

    private func beginSearch() {
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen) { searching = true }
    }

    private func endSearch() {
        searchFocused = false
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen) { searching = false }
        query = ""
    }
}

/// Titles fade softly under the header and the bottom buttons.
private struct SidebarScrollEdges: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) { content.scrollEdgeEffectStyle(.soft, for: .all) }
        else { content }
    }
}
