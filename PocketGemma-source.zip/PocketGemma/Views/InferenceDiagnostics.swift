import SwiftUI
import os
import PocketCore

/// Local, bounded diagnostics. Never record prompts, replies, image bytes,
/// attachment names, Apple IDs, or the app's full sandbox path.
struct InferenceDiagnostic: Codable, Sendable {
    struct Event: Codable, Sendable {
        let stage: String; let elapsedSeconds: Double; let availableMemoryBytes: UInt64
        /// The app's unmapped address space at this stage (AddressSpace).
        var largestFreeAddressBytes: UInt64? = nil
        var freeAddressBytes: UInt64? = nil
        /// The app's pages read back from storage so far (getrusage's major
        /// faults), its CPU time, and how hot iOS says the phone is
        /// (ProcessInfo.ThermalState, 0 nominal to 3 critical): a model whose
        /// weights no longer stay in memory reads them back for every word
        /// (1.1.0 (206)).
        var pageIns: Int? = nil
        var cpuSeconds: Double? = nil
        var thermal: Int? = nil
    }
    struct Failure: Codable, Sendable {
        let stage: String; let nativeError: String
        let visionTokens: Int?; let visionBackend: String?
    }
    let startedAt: Date
    var runID: UUID?
    let appVersion: String
    let runtime: String
    let modelID: String
    let modelSHA256: String
    let system: String
    let device: String
    let physicalMemory: UInt64
    let mainBackend: String
    let visionBackend: String?
    let contextTokens: Int
    let visionTokens: Int?
    let imageCount: Int
    var events: [Event] = []
    var visionSignatures: [Int]?
    var result = "running"
    var failureKind: NativeFailureKind?
    var nativeError: String?
    var availableMemoryAtFailure: UInt64?
    var priorFailures: [Failure] = []
    var nativeLogLines: [String]?
    var nativeLogCapture: String?
    var nativeLogTruncated: Bool?
    var nativeLogDiscardedLines: Int?
    var evidence: NativeLogEvidence?
    var runtimeBuild: RuntimeBuildProvenance?
    var cacheIdentity: String?
    var engineWasReused: Bool?
    var conversationWasReused: Bool?
    var maxOutputTokens: Int?
    var topK: Int?
    var topP: Double?
    var temperature: Double?
    var thinking: Bool?
    /// The most tokens the reply could think for (GenerationSettings.thinkingTokenBudget).
    var thinkingTokens: Int?
    var speculation: Bool?
    var cpuThreadPolicy: String?
    var activationPrecision: String?
    var visionAdapterBackend: String?
    var inputPath: String?
    var inputImageDimensions: [String]?
    var componentKernelMode: String?
    var testedComponent: String?
    var componentStatusCode: Int?
    var componentTensorLayout: String?
    var outputFinite: Bool?
    var sectionSHA256: String?
    var inputFixtureSHA256: String?
    var sampledPeakFootprint: UInt64?
    var sampledMinimumAvailableMemory: UInt64?
    var memorySampleCount: Int?
    var visionCPUImplementation: String?
    var sampledPeakVirtualSize: UInt64?
    var sampledPeakRegionCount: UInt64?
    /// The address space iOS gives the app, and its unmapped space at the
    /// tightest sample (about once a second) and right after a failure.
    var addressSpaceRange: UInt64?
    var lowestLargestFreeAddress: UInt64?
    var freeAddressAtLowest: UInt64?
    var largestFreeAddressAtFailure: UInt64?
    /// GPU start test: whether the reply to its fixed question named Tokyo.
    /// Every reply's length, also the start test's; the reply itself is not
    /// stored.
    var fixedQuestionAnswered: Bool?
    var replyCharacters: Int?
    /// E4B's reply mode (PhotoDetail) as it ran, so 高速 and じっくり考える can
    /// be compared: "deep" is じっくり考える's fallback since 1.1.0 (248).
    var replyMode: String?
    /// Smart Mode's tuning for the turn (1.1.0 (249)): its task, pace,
    /// thinking and photo detail, as raw values; nil outside Smart Mode.
    var smartMode: String?
    /// Smart Memory's search for the turn (1.1.0 (251)): how many earlier
    /// exchanges, their bytes, the search's time; never their words.
    var smartMemory: String?
    /// How the turn's conversation was set up (1.1.0 (256)): exchanges
    /// given, estimated and real tokens, earlier messages quoted; counts
    /// only, never words (ContextFill).
    var context: String?
    /// Searches the reply made (with search on); their starts and ends are
    /// events, never their queries.
    var webSearches: Int?
    /// How a reply fared after the app left the screen: moved to the CPU,
    /// the background time it had, how it ended. Never its text.
    var background: String?
    /// What the app had at launch and the memory entitlements it is signed
    /// with, so runs from builds signed differently can be compared.
    var launch: LaunchMemory?
    /// Whether the CPU weight cache was locked in memory (WeightCacheLock),
    /// for the models that ask for it.
    var weightCache: String?
    /// The runtime of a model LiteRT-LM doesn't run ("llama.cpp b11960" for
    /// LFM3, 1.1.0 (232)); nil for LiteRT-LM, whose version is `runtime`.
    var inferenceEngine: String?
    /// llama.cpp's figures for the reply: tokens read and written, their
    /// times, the thought, how it ended. Never its text.
    var llamaReply: String?
    /// How the LFM3 engine the reply used was loaded (1.1.0 (289)): ahead
    /// of the question or by the send, its seconds, the memory iOS still
    /// gave and the largest free block of address space before and after.
    var llamaLoad: String?
    /// How the reply found its engine when a load ahead of the question
    /// (先行読み込み, 1.1.0 (284)) was asked for: ready, joined while it
    /// loaded, left (and why), failed. Nil when none was.
    var prewarm: String?
    var stage: String { events.last?.stage ?? "validation" }

    /// From the reply's start, just after the send, to its first
    /// characters, and the model's load among them (its own, or the wait
    /// for the load ahead it joined), to compare a first reply with the
    /// next (1.1.0 (284)). Nil for a reply without text or carried on.
    var firstTextSummary: String? {
        guard result == "success", !events.contains(where: { $0.stage == "reply_continuation" }),
              let first = events.first(where: { $0.stage == "decode" }) else { return nil }
        func span(_ stage: String) -> Double? {
            guard let index = events.firstIndex(where: { $0.stage == stage }), index + 1 < events.count else { return nil }
            return events[index + 1].elapsedSeconds - events[index].elapsedSeconds
        }
        let load = [span("prewarm_join"), span("prewarm_wait"), span("engine_initialization")].compactMap { $0 }
        let loading = load.isEmpty ? "モデルは読み込み済み" : String(format: "うちモデルの読み込み %.1f秒", load.reduce(0, +))
        return String(format: "送信から最初の文字まで %.1f秒", first.elapsedSeconds) + "（\(loading)） · 言語 \(mainBackend)"
            + (prewarm.map { " · " + $0 } ?? "")
    }

    /// `backend` records the backend actually started when it differs from
    /// the plan's, as in the GPU start test, which always starts the GPU.
    init(plan: InferenceEnginePlan, imageCount: Int, settings: GenerationSettings? = nil, previous: Self? = nil,
         backend: ExecutionBackend? = nil) {
        startedAt = Date(); runtime = InferenceEnginePlan.runtimeVersion
        runID = UUID()
        let bundle = Bundle.main
        appVersion = "\(bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown") (\(bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown"))"
        modelID = plan.modelID; modelSHA256 = plan.modelSHA256
        mainBackend = (backend ?? plan.backend).rawValue; visionBackend = plan.visionBackend?.rawValue
        contextTokens = plan.maxTokens; visionTokens = plan.visualTokenBudget
        self.imageCount = imageCount
        system = ProcessInfo.processInfo.operatingSystemVersionString
        device = DeviceOverview.identifier
        physicalMemory = ProcessInfo.processInfo.physicalMemory
        runtimeBuild = RuntimeBuildProvenance.load()
        cacheIdentity = plan.cacheComponent
        visionCPUImplementation = plan.visionCPUImplementation?.rawValue
        cpuThreadPolicy = "language: SDK default; vision: official 0.18 executor fixed 4 threads"
        activationPrecision = plan.gpuPrecision.diagnosticLabel
        if [ModelSpec.e2b.id, ModelSpec.e4b.id].contains(modelID), plan.visionBackend != nil {
            visionAdapterBackend = "CPU (pinned model metadata)"
        }
        maxOutputTokens = settings?.maxOutputTokens; topK = settings?.topK
        topP = settings?.topP; temperature = settings?.temperature
        // The drafter the engine runs with: 高速 turns without photos use it
        // whatever was saved. じっくり考える thinks whatever was saved, and
        // its fallback 深く never does.
        speculation = plan.speculativeDecoding
        if let settings, let spec = ModelSpec.find(modelID) {
            thinking = settings.thinks(on: spec); thinkingTokens = settings.thinkingTokenBudget(on: spec)
            if !spec.photoDetails.isEmpty { replyMode = settings.photoDetail.rawValue }
            if let smart = settings.smart {
                smartMode = [smart.task.rawValue, smart.pace.rawValue, smart.thinks ? "thinks" : "no-thinking",
                             smart.photoDetail?.rawValue].compactMap { $0 }.joined(separator: " · ")
            }
        } else { thinking = settings?.enableThinking }
        launch = .atLaunch
        if let previous, previous.modelID == modelID, previous.result == "failed",
           Date().timeIntervalSince(previous.startedAt) < 120, let error = previous.nativeError {
            priorFailures = Array((previous.priorFailures + [Failure(stage: previous.stage, nativeError: error,
                visionTokens: previous.visionTokens, visionBackend: previous.visionBackend)]).suffix(2))
        }
    }

    mutating func recordNativeLog(_ log: NativeLogBuffer?, error: String = "") {
        nativeLogCapture = log == nil ? "stderr capture unavailable; Swift native error only"
            : log?.keepsGPUMessages == true
            ? "stderr operational allowlist plus GPU messages (GPU start test, fixed question only); OSLog/filtered lines unavailable"
            : "stderr operational allowlist; OSLog/filtered lines unavailable"
        nativeLogLines = log?.lines ?? []
        nativeLogTruncated = log?.truncated
        nativeLogDiscardedLines = log?.discardedLines
        evidence = NativeLogEvidence(error: error, logLines: nativeLogLines ?? [])
    }

    mutating func recordMemory(_ memory: (peak: UInt64, minimum: UInt64, samples: Int, virtualPeak: UInt64, regionPeak: UInt64,
                                          lowestAddress: AddressSpace?)) {
        sampledPeakFootprint = memory.peak
        sampledMinimumAvailableMemory = memory.minimum
        memorySampleCount = memory.samples
        sampledPeakVirtualSize = memory.virtualPeak
        sampledPeakRegionCount = memory.regionPeak
        if let low = memory.lowestAddress {
            addressSpaceRange = low.range
            if lowestLargestFreeAddress.map({ low.largestFree < $0 }) ?? true {
                lowestLargestFreeAddress = low.largestFree; freeAddressAtLowest = low.free
            }
        }
    }

    /// The range and its largest unmapped block, for the card.
    var addressSpaceSummary: String? {
        guard let range = addressSpaceRange else { return nil }
        func gigabytes(_ bytes: UInt64) -> String { String(format: "%.2f GB", Double(bytes) / 1_000_000_000) }
        var line = "アドレス空間の範囲: \(gigabytes(range)) · 最大の連続した空き（最も少ない時）: "
            + (lowestLargestFreeAddress.map(gigabytes) ?? "未計測")
        if let failure = largestFreeAddressAtFailure { line += " · 失敗直後: \(gigabytes(failure))" }
        return line
    }

    /// How fast a reply came, to compare 高速 and じっくり考える: the wait
    /// for its first characters, with the time it thought, then its pace
    /// while writing. Nil for a reply carried on over more rounds, whose time
    /// includes each round's new start.
    var replySpeedSummary: String? {
        guard result == "success", let characters = replyCharacters,
              !events.contains(where: { $0.stage == "reply_continuation" }),
              let asked = events.first(where: { $0.stage == "text_generation" || $0.stage == "image_prefill" }),
              let first = events.first(where: { $0.stage == "decode" }),
              let done = events.last(where: { $0.stage == "complete" }) else { return nil }
        let writing = max(0.001, done.elapsedSeconds - first.elapsedSeconds)
        let mode = smartMode.map { "おまかせ（\($0)） · " } ?? replyMode.flatMap(PhotoDetail.init(rawValue:))
            .map { $0 == .deep ? "\($0.choice.title)（深くで代替） · " : "\($0.title) · " } ?? ""
        let thought = events.first(where: { $0.stage == "thinking" })
            .map { String(format: "（うち考えた時間 %.1f秒）", first.elapsedSeconds - $0.elapsedSeconds) } ?? ""
        return mode + String(format: "最初の文字まで %.1f秒", first.elapsedSeconds - asked.elapsedSeconds) + thought
            + String(format: " · %.0f文字/秒（%ld文字・%.1f秒）", Double(characters) / writing, characters, writing)
            + " · 先読み" + (speculation == true ? "あり" : "なし")
            + " · thinking" + (thinking == true ? "あり" + (thinkingTokens.map { "（上限\($0)）" } ?? "") : "なし")
            + (smartMemory.map { " · Smart Memory \($0)" } ?? "")
    }

    mutating func recordFailureAddressSpace() {
        guard let space = AddressSpace.current() else { return }
        addressSpaceRange = space.range
        largestFreeAddressAtFailure = space.largestFree
    }

    mutating func advance(_ stage: String) {
        if events.count < 16 {
            let space = AddressSpace.current()
            if let space { addressSpaceRange = space.range }
            var use = rusage()
            let used = getrusage(RUSAGE_SELF, &use) == 0
            func seconds(_ time: timeval) -> Double { Double(time.tv_sec) + Double(time.tv_usec) / 1_000_000 }
            events.append(Event(stage: stage, elapsedSeconds: Date().timeIntervalSince(startedAt),
                                availableMemoryBytes: UInt64(os_proc_available_memory()),
                                largestFreeAddressBytes: space?.largestFree, freeAddressBytes: space?.free,
                                pageIns: used ? Int(use.ru_majflt) : nil,
                                cpuSeconds: used ? seconds(use.ru_utime) + seconds(use.ru_stime) : nil,
                                thermal: ProcessInfo.processInfo.thermalState.rawValue))
        }
        save()
    }

    /// The pages read back from storage and the CPU time from the reply's
    /// first stage to its last, the hottest the phone got, and whether the
    /// weights were locked, for the card.
    var storageReadSummary: String? {
        guard let first = events.first(where: { $0.pageIns != nil }), let last = events.last(where: { $0.pageIns != nil }),
              let startPages = first.pageIns, let endPages = last.pageIns else { return weightCache.map { "CPUの重み: " + $0 } }
        let heat = ["平常", "やや高い", "高い", "危険"]
        let hottest = events.compactMap(\.thermal).max().map { heat.indices.contains($0) ? heat[$0] : "\($0)" } ?? "不明"
        var line = "ストレージからの読み直し: \(endPages - startPages)回"
        if let start = first.cpuSeconds, let end = last.cpuSeconds { line += String(format: " · CPU時間 %.1f秒", end - start) }
        line += " · 端末の温度: " + hottest
        if let weightCache { line += "\nCPUの重み: " + weightCache }
        return line
    }
    static var fileURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma/last-inference.json")
    }
    static var historyURL: URL { fileURL.deletingLastPathComponent().appendingPathComponent("inference-comparisons.json") }
    func save() {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        // Diagnostic IO must not change the outcome of inference.
        try? FileManager.default.createDirectory(at: Self.fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        if let data = try? encoder.encode(self) {
            try? data.write(to: Self.fileURL, options: [.atomic, .completeFileProtectionUnlessOpen])
        }
        // While the phone is locked the saved runs can't be read (complete
        // protection unless open); writing then would replace them with this
        // run alone. The last run above is still kept.
        if FileManager.default.fileExists(atPath: Self.historyURL.path) {
            guard let handle = try? FileHandle(forReadingFrom: Self.historyURL) else { return }
            try? handle.close()
        }
        var history = Self.history()
        history.removeAll { runID != nil ? $0.runID == runID : $0.startedAt == startedAt }
        history.append(self)
        history = Array(history.suffix(24))
        if let data = try? encoder.encode(history), data.count <= 768_000 {
            try? data.write(to: Self.historyURL, options: [.atomic, .completeFileProtectionUnlessOpen])
        }
    }
    static func load() -> Self? {
        guard let handle = try? FileHandle(forReadingFrom: fileURL) else { return nil }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 64_000) else { return nil }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(Self.self, from: data)
    }
    static func history() -> [Self] {
        guard let handle = try? FileHandle(forReadingFrom: historyURL) else { return load().map { [$0] } ?? [] }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 768_001), data.count <= 768_000 else { return [] }
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        return Array(((try? decoder.decode([Self].self, from: data)) ?? []).suffix(24))
    }
    static func sanitize(_ error: String) -> String {
        // Preserve official runtime source locations; redact user/device paths.
        let text = NativeLogBuffer.redact(error.replacingOccurrences(of: NSHomeDirectory(), with: "<app>"))
        return GenerationSettings.prefix(text, byteLimit: 6000)
    }
}

/// The memory iOS lets the app use and its address space at launch, before
/// any model, and the memory entitlements in its own signatures (the app and
/// its Live Activity extension). Whoever signed the build last, TestFlight
/// included, this shows whether the address-space entitlements are there and
/// what they changed.
struct LaunchMemory: Codable, Sendable {
    let availableMemoryBytes: UInt64
    let addressSpace: AddressSpace?
    /// SignedEntitlements.memoryKeys each signature carries; nil when it
    /// could not be read.
    let appEntitlements: [String]?
    let extensionEntitlements: [String]?

    /// Taken once, from PocketGemmaApp's init.
    static let atLaunch = LaunchMemory(availableMemoryBytes: UInt64(os_proc_available_memory()),
                                       addressSpace: AddressSpace.current(),
                                       appEntitlements: Bundle.main.executableURL.flatMap(SignedEntitlements.memoryEntitlements(ofExecutableAt:)),
                                       extensionEntitlements: extensionEntitlements())

    private static func extensionEntitlements() -> [String]? {
        guard let plugIns = Bundle.main.builtInPlugInsURL,
              let names = try? FileManager.default.contentsOfDirectory(atPath: plugIns.path) else { return nil }
        var found: [String] = []
        for name in names.sorted() where name.hasSuffix(".appex") {
            guard let executable = Bundle(url: plugIns.appendingPathComponent(name))?.executableURL,
                  let keys = SignedEntitlements.memoryEntitlements(ofExecutableAt: executable) else { return nil }
            found += keys.filter { !found.contains($0) }
        }
        return found
    }

    var entitlementSummary: String {
        func names(_ keys: [String]?) -> String {
            guard let keys else { return "読めませんでした" }
            return SignedEntitlements.memoryKeys.map { key in
                (key == SignedEntitlements.extendedVirtualAddressing ? "Extended Virtual Addressing" : "Increased Memory Limit")
                    + (keys.contains(key) ? " あり" : " なし")
            }.joined(separator: " · ")
        }
        return "署名の権限（アプリ）: \(names(appEntitlements))\n署名の権限（Live Activity）: \(names(extensionEntitlements))"
    }

    var memorySummary: String {
        func gigabytes(_ bytes: UInt64) -> String { String(format: "%.2f GB", Double(bytes) / 1_000_000_000) }
        var line = "起動直後: 使えるメモリ \(gigabytes(availableMemoryBytes))"
        if let space = addressSpace {
            line += " · アドレス空間の範囲 \(gigabytes(space.range)) · 空き \(gigabytes(space.free)) · 最大の連続した空き \(gigabytes(space.largestFree))"
        }
        return line
    }
}

struct InferenceDiagnosticsCard: View {
    @State private var showProbe = false
    @State private var showGPUTest = false
    /// Raised by the settings' 診断をまとめて実行; 0 until then.
    let loadRequest: Int
    /// Read off the main thread only when asked (reload()): as initial state,
    /// up to 768 KB of JSON was decoded again each time the settings redrew,
    /// before the sheet could open.
    @State private var latest: InferenceDiagnostic?
    @State private var history: [InferenceDiagnostic] = []
    @State private var loaded = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("推論の診断", systemImage: "stethoscope").font(.headline)
            Text("直近24回の構成・実行段階・メモリ・ネイティブエラーを端末内に保存します。会話本文や添付画像は含みません。")
                .font(.caption).foregroundStyle(.secondary)
            Text(LaunchMemory.atLaunch.entitlementSummary + "\n" + LaunchMemory.atLaunch.memorySummary)
                .font(.caption).textSelection(.enabled).accessibilityIdentifier("launch-memory")
            Button { showProbe = true } label: { Label("画像の最小再現テスト", systemImage: "testtube.2") }
                .font(.subheadline).accessibilityIdentifier("open-vision-probe")
            Button { showGPUTest = true } label: { Label("GPU起動テスト（Qwen）", systemImage: "cpu") }
                .font(.subheadline).accessibilityIdentifier("open-gpu-test")
                .sheet(isPresented: $showGPUTest, onDismiss: { Task { await reload() } }) {
                    GPUStartTestView()
                }
            if let latest {
                Text("\(latest.modelID) · \(latest.stage) · \(latest.result)")
                    .font(.caption).textSelection(.enabled)
                if let component = latest.testedComponent {
                    Text("単体検証: \(component) · \(latest.componentKernelMode ?? "不明")（言語エンジンは実行していません）")
                        .font(.caption).textSelection(.enabled)
                } else {
                    Text("言語 \(latest.mainBackend) / 画像 \(latest.visionBackend ?? "なし") · Context \(latest.contextTokens) · Vision \(latest.visionTokens.map(String.init) ?? "なし")")
                        .font(.caption).textSelection(.enabled)
                }
                Text("失敗デリゲート: \(latest.evidence?.failedDelegate ?? "ログに明記なし")\n原因の演算子: \(latest.evidence?.operatorNames.joined(separator: ", ").nilIfEmpty ?? "ログに明記なし")")
                    .font(.caption).textSelection(.enabled)
                if let nodes = latest.evidence?.delegateNodes, !nodes.isEmpty {
                    Text("委譲ノード: \(nodes.map(String.init).joined(separator: ", "))（原因の演算子番号とは限りません）").font(.caption).foregroundStyle(.secondary)
                }
                if let phase = latest.evidence?.xnnpackPhase {
                    Text("XNNPACK内の失敗段階: \(phase)（メモリ不足を意味するとは限りません）").font(.caption)
                }
                if let patches = latest.evidence?.preparedImagePatches {
                    Text("ネイティブログの画像パッチ数: \(patches.map(String.init).joined(separator: ", "))").font(.caption)
                }
                if let input = latest.inputPath { Text("入力経路: \(input)").font(.caption) }
                if let speed = latest.replySpeedSummary { Text("返事の速さ: " + speed).font(.caption).textSelection(.enabled) }
                if let first = latest.firstTextSummary { Text("返事の始まり: " + first).font(.caption).textSelection(.enabled) }
                if let context = latest.context { Text("文脈: " + context).font(.caption).textSelection(.enabled) }
                if let llama = latest.llamaReply { Text(verbatim: llama).font(.caption).textSelection(.enabled) }
                if let load = latest.llamaLoad { Text(verbatim: load).font(.caption).textSelection(.enabled) }
                if let reads = latest.storageReadSummary { Text(reads).font(.caption).textSelection(.enabled) }
                if latest.inputPath == GPUStartTest.inputPath {
                    Text("GPU起動テスト · 精度: \(latest.activationPrecision ?? "不明") · 回答: \(latest.fixedQuestionAnswered.map { $0 ? "東京と回答" : "東京以外" } ?? "なし")\(latest.replyCharacters.map { "（\($0)文字）" } ?? "")")
                        .font(.caption).textSelection(.enabled)
                }
                if let kernel = latest.visionCPUImplementation { Text("画像CPU: \(kernel)").font(.caption) }
                if let peak = latest.sampledPeakFootprint {
                    Text("アプリ使用メモリの観測ピーク: \(Double(peak)/1_000_000_000, specifier: "%.2f") GB（200 ms間隔）").font(.caption)
                }
                if let virtual = latest.sampledPeakVirtualSize {
                    Text("仮想メモリの観測ピーク: \(Double(virtual)/1_000_000_000, specifier: "%.2f") GB · 領域数の最大: \(latest.sampledPeakRegionCount ?? 0)")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if let line = latest.addressSpaceSummary { Text(line).font(.caption).textSelection(.enabled) }
                if let tensors = latest.componentTensorLayout {
                    Text(tensors).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                }
                if let error = latest.nativeError { Text(error).font(.caption).foregroundStyle(.secondary).textSelection(.enabled) }
                DisclosureGroup("ネイティブログとライブラリ情報") {
                    Text(latest.nativeLogCapture ?? "旧版の診断です").font(.caption).foregroundStyle(.secondary)
                    if let lines = latest.nativeLogLines, !lines.isEmpty {
                        Text(lines.joined(separator: "\n")).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                    } else { Text("利用できる追加のstderrログがありません。").font(.caption) }
                    if let build = latest.runtimeBuild {
                        if let native = build.nativeBuild {
                            Text("ネイティブ修正: \(native.buildID)\n\(native.scope)").font(.caption)
                        }
                        Text("LiteRT-LM \(build.runtimeVersion) · \(build.packageRevision)\n\(build.target) · \(build.sdk)\n\(build.binaryCompilerFlags)")
                            .font(.caption).textSelection(.enabled)
                        Text("実際のフレームワークのSHA256は共有ファイルに含まれます。").font(.caption)
                        if let sdk = build.nativeFiles.first?.nativeSDK {
                            Text("ネイティブバイナリのSDK: \(sdk) / 最低OS: \(build.nativeFiles.first?.minimumOS ?? "不明")").font(.caption)
                        }
                    } else { Text("このビルドにはバイナリの照合情報がありません。").font(.caption) }
                }.font(.caption)
                ShareLink(item: InferenceDiagnostic.historyURL) { Label("比較結果と診断を共有", systemImage: "square.and.arrow.up") }
                    .font(.subheadline)
                    .accessibilityIdentifier("share-inference-comparisons")
            } else {
                Text(loaded ? "モデルを実行すると診断が表示されます。" : "「診断をまとめて実行」で読み込みます。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            if !history.isEmpty {
                DisclosureGroup("構成ごとの結果（\(history.count)回）") {
                    ForEach(Array(history.reversed().enumerated()), id: \.offset) { _, record in
                        VStack(alignment: .leading, spacing: 3) {
                            Text("\(record.modelID) · \(record.testedComponent ?? "\(record.mainBackend)/\(record.visionBackend ?? "なし")") · \(record.result)")
                            Text("\(record.stage) · Context \(record.contextTokens) / Vision \(record.visionTokens ?? 0)")
                            if let speed = record.replySpeedSummary { Text(speed) }
                            if let first = record.firstTextSummary { Text(first) }
                            if record.inputPath == GPUStartTest.inputPath {
                                Text("GPU起動テスト · \(record.activationPrecision ?? "精度不明")")
                            }
                            Text(record.startedAt, style: .time).foregroundStyle(.secondary)
                        }.font(.caption).padding(.vertical, 3)
                    }
                }.font(.caption).accessibilityIdentifier("inference-comparison-history")
            }
            Text("比較は同じ画像・モデル・トークン数を使い、新しい会話で実行してください。演算子やデリゲートが明記されないエラーからは断定できません。")
                .font(.caption).foregroundStyle(.secondary)
            Button("診断を再読み込み") { Task { await reload() } }.font(.caption)
        }.padding(18).fieluaCard(cornerRadius: 20)
            .task(id: loadRequest) { if loadRequest > 0 { await reload() } }
            .sheet(isPresented: $showProbe, onDismiss: { Task { await reload() } }) {
                VisionProbeView()
            }
    }

    private func reload() async {
        let (last, past) = await Task.detached(priority: .userInitiated) {
            (InferenceDiagnostic.load(), InferenceDiagnostic.history())
        }.value
        latest = last; history = past; loaded = true
    }
}

struct RuntimeBuildProvenance: Codable, Sendable {
    struct NativeBuild: Codable, Sendable {
        let buildID: String; let sourceRevision: String; let patchSHA256: String; let scope: String
    }
    struct NativeFile: Codable, Sendable {
        let name: String; let sha256: String; let bytes: Int
        let architecture: String?; let platform: Int?; let nativeSDK: String?; let minimumOS: String?; let uuid: String?
    }
    let runtimeVersion: String
    let packageRevision: String
    let artifactURL: String
    let artifactSHA256: String
    let target: String
    let sdk: String
    let configuration: String
    let nativeFiles: [NativeFile]
    let upstreamLiteRTSourceRef: String
    let binaryCompilerFlags: String
    let nativeBuild: NativeBuild?
    static func load() -> Self? {
        guard let url = Bundle.main.url(forResource: "runtime-build", withExtension: "json"),
              let data = try? Data(contentsOf: url), data.count < 32_768 else { return nil }
        return try? JSONDecoder().decode(Self.self, from: data)
    }
}

private extension String {
    var nilIfEmpty: String? { isEmpty ? nil : self }
}
