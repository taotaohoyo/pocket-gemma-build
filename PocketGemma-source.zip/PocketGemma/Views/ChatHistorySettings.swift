import SwiftUI
import PocketCore

/// 設定 › 会話履歴 (1.1.0 (251), the user's directive of 2026-10-31): the
/// saved conversations, as the history sidebar lists them (one plain line
/// each, newest first, the chosen ones in its grey wash), to choose and
/// delete several at once. All of them chosen or none with one button;
/// deleting asks first, naming how many. Only the chats chosen go, with
/// the attachment files only they used (ChatStore.deleteChats).
struct ChatHistorySettingsView: View {
    @EnvironmentObject private var chats: ChatStore
    @State private var chosen: Set<UUID> = []
    @State private var confirming = false

    private var saved: [ChatThread] {
        chats.threads.filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        let _ = SettingsSlideMeter.drew("会話履歴")
        let threads = saved
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if threads.isEmpty {
                    Text("会話はまだありません")
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 4)
                        .accessibilityIdentifier("chat-history-empty")
                } else {
                    HStack {
                        Text("\(threads.count)件の会話")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Spacer(minLength: 8)
                        let all = chosen.count == threads.count
                        Button(all ? "選択を解除" : "すべて選択") {
                            chosen = all ? [] : Set(threads.map(\.id))
                        }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Theme.link)
                        .accessibilityIdentifier("chat-history-select-all")
                    }
                    .padding(.horizontal, 4)
                    VStack(spacing: 0) {
                        ForEach(threads) { thread in row(thread) }
                    }
                    .padding(6)
                    .fieluaCard(cornerRadius: 20)
                }
            }
            .padding(20)
        }
        .accessibilityIdentifier("chat-history-list")
        .settingsScroll()
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if !threads.isEmpty { deleteBar }
        }
        // A chat deleted elsewhere (the sidebar) is no longer chosen.
        .onChange(of: chats.threads.map(\.id)) { _, ids in chosen.formIntersection(ids) }
        .alert(Text("\(chosen.count)件の会話を削除しますか？"), isPresented: $confirming) {
            Button("キャンセル", role: .cancel) {}
            Button("削除", role: .destructive) {
                if chats.deleteChats(chosen) { chosen = [] }
            }
        } message: {
            Text(verbatim: deleteMessage)
        }
    }

    /// What else the delete does to the automatic backup (設定's iCloud 自動
    /// 保存). Fielua's own iCloud (1.1.0 (252)) follows: its next save leaves
    /// the chats and the attachments only they used out. A folder the person
    /// chose is their own copy: its next save leaves the chats out, and the
    /// copies already in it stay (1.1.0 (251) directive).
    private var deleteMessage: String {
        let cloud = CloudHistoryStore.shared
        var lines = [String(localized: "添付した写真やファイルも削除されます。この操作は取り消せません。")]
        if cloud.privateCloud {
            lines.append(cloud.enabled ? String(localized: "Fielua 専用の iCloud のバックアップからも、次の自動保存で消えます。")
                                       : String(localized: "自動保存がオフのため、Fielua 専用の iCloud のバックアップには残ります。"))
            if cloud.earlierFolderName != nil {
                lines.append(String(localized: "前の保存先のフォルダに保存済みのコピーは削除されません。"))
            }
        } else if cloud.enabled {
            lines.append(String(localized: "バックアップ先のフォルダに保存済みのコピーは削除されません。"))
        }
        return lines.joined(separator: "\n")
    }

    private func row(_ thread: ChatThread) -> some View {
        let on = chosen.contains(thread.id)
        return Button {
            if on { chosen.remove(thread.id) } else { chosen.insert(thread.id) }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: on ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 21, weight: .regular))
                    .foregroundStyle(on ? AnyShapeStyle(Theme.active) : AnyShapeStyle(.tertiary))
                    .accessibilityHidden(true)
                Text(thread.title)
                    .font(.body)
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(thread.updatedAt.formatted(date: .numeric, time: .omitted))
                    .font(.caption).foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            .padding(.horizontal, 10)
            .frame(minHeight: 48)
            .background {
                // The sidebar's open chat: the warm grey wash.
                if on { RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Theme.selection) }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(thread.title)
        .accessibilityValue(Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted)))
        .accessibilityAddTraits(on ? .isSelected : [])
        .accessibilityIdentifier("chat-history-row")
    }

    private var deleteBar: some View {
        VStack(spacing: 6) {
            if chats.isGenerating {
                Text("返信を書き終えると削除できます")
                    .font(.caption).foregroundStyle(.secondary)
            }
            let usable = !chosen.isEmpty && !chats.isGenerating
            Button(role: .destructive) { confirming = true } label: {
                Text(chosen.isEmpty ? String(localized: "削除") : String(localized: "\(chosen.count)件を削除"))
                    .font(.body.weight(.semibold))
                    // The glass style draws its label in the primary colour
                    // whatever the tint; the red of a deletion is set here,
                    // and a button that cannot be pressed stays grey.
                    .foregroundStyle(usable ? AnyShapeStyle(Color.red) : AnyShapeStyle(.tertiary))
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .contentShape(Capsule())
            }
            .buttonStyle(.glass)
            .disabled(!usable)
            .accessibilityIdentifier("chat-history-delete")
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 12)
    }
}

/// 試験機能を試してみる's Smart Memory (1.1.0 (251)): off until turned on,
/// apart from Smart Mode's switch. On, each question also gets what of the
/// saved conversations bears on it, found and read on this iPhone alone
/// (SmartMemory); off, nothing is searched.
struct SmartMemoryCard: View {
    @EnvironmentObject private var chats: ChatStore
    @AppStorage(SmartMemory.storageKey) private var on = false
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Toggle("Smart Memory", isOn: $on)
                .font(.headline).fieluaStateTint().accessibilityIdentifier("experiments-smart-memory-toggle")
            Text("過去の関連会話をこのiPhone内だけで検索し、モデル変更時も記憶を引き継いで回答します。")
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("experiments-smart-memory-caption")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .onChange(of: on) { _, value in chats.smartMemoryChanged(value) }
    }
}

/// Under a reply Smart Memory gave earlier exchanges (1.1.0 (251)): how
/// many, and in its menu the conversations they came from, each opening
/// that conversation. Only those still saved; none, and nothing shows.
struct MemorySourcesView: View {
    let recall: MemoryRecall
    @EnvironmentObject private var chats: ChatStore

    var body: some View {
        let sources = recall.live(in: chats.threads)
        let threads = sources.reduce(into: [UUID]()) { if !$0.contains($1.thread) { $0.append($1.thread) } }
        if !threads.isEmpty {
            Menu {
                Section("参照した会話") {
                    ForEach(threads, id: \.self) { id in
                        if let thread = chats.threads.first(where: { $0.id == id }) {
                            Button {
                                chats.select(id)
                            } label: {
                                Text(thread.title)
                                Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted))
                            }
                            .disabled(chats.isGenerating || id == chats.selectedID)
                        }
                    }
                }
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "clock.arrow.circlepath").font(.system(size: 11, weight: .semibold))
                    Text("過去の会話を参照 · \(sources.count)件")
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(.vertical, 4)
                .contentShape(Rectangle())
            }
            .menuOrder(.fixed)
            .accessibilityLabel(Text("過去の会話を参照 · \(sources.count)件"))
            .accessibilityIdentifier("reply-memory-sources")
        }
    }
}

/// The chat's mark and name at the top (1.1.0 (251), the user's directive
/// of 2026-10-31 18:47 UTC): in a Smart Mode chat Fielua's own app icon and
/// 「Fielua」, before the first question and whichever model answers or
/// genre is chosen; otherwise the chat's model, as before. The model a
/// reply used stays in its long-press menu and the diagnostics.
struct ChatHeaderMark: View {
    let model: ModelSpec
    let smart: Bool

    var body: some View {
        VStack(spacing: 4) {
            if smart { FieluaAppIcon(size: 38).frame(width: 40, height: 40) }
            else { ModelMark(model: model, size: 40) }
            HStack(spacing: 3) {
                Text(verbatim: smart ? "Fielua" : model.family).font(.caption.weight(.semibold))
                Image(systemName: "chevron.right").font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 9).padding(.vertical, 4)
            .chatGlass(in: Capsule())
        }
    }
}

/// The home-screen icon (FieluaIcon, made from the app icon by
/// scripts/make-icon.py, light and dark), in iOS's rounded square with a
/// hairline, as the 起動時のチャット preview draws it.
struct FieluaAppIcon: View {
    let size: CGFloat
    var body: some View {
        let shape = RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
        Image("FieluaIcon")
            .resizable()
            .interpolation(.high)
            .scaledToFill()
            .frame(width: size, height: size)
            .clipShape(shape)
            .overlay { shape.strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.5) }
            .accessibilityHidden(true)
    }
}
