import SwiftUI
import PocketCore

/// 設定 › 会話履歴 (1.1.0 (251), the user's directive of 2026-10-31): the
/// saved conversations, as the history sidebar lists them (one plain line
/// each, newest first, the chosen ones in its grey wash), to choose and
/// delete several at once. All of them chosen or none with one button;
/// deleting asks first, naming how many. Only the chats chosen go, with
/// the attachment files only they used (ChatStore.deleteChats).
struct ChatHistorySettingsView: View {
    // The store is read as the page draws and acted on, not observed: it
    // publishes with every batch of a reply's text, and this page filtered
    // and sorted every chat again each time (1.1.0 (263); ChatPulse). The
    // page draws again when a reply starts or ends and for its own changes.
    @ObservedObject private var pulse = ChatPulse.shared
    @Environment(\.chatHandle) private var chatHandle
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var chosen: Set<UUID> = []
    @State private var confirming = false
    /// Why the last delete did not happen, said here: the chat's own alert
    /// is under this sheet, where nobody saw it (UI review, 2026-11-11).
    @State private var problem: String?
    @State private var deletions = 0
    @State private var failures = 0

    private var saved: [ChatThread] {
        (chatHandle.store?.threads ?? []).filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        let _ = SettingsSlideMeter.drew("会話履歴")
        let threads = saved
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if threads.isEmpty {
                    // The flower of every empty place, over the one line.
                    VStack(spacing: 14) {
                        FieluaEmptyMark()
                        Text("会話はまだありません")
                            .foregroundStyle(.secondary)
                            .accessibilityIdentifier("chat-history-empty")
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 48)
                    .transition(.opacity)
                } else {
                    HStack {
                        Text("\(threads.count)件の会話")
                            .font(.subheadline).foregroundStyle(.secondary)
                            .contentTransition(.numericText(value: Double(threads.count)))
                        Spacer(minLength: 8)
                        let all = chosen.count == threads.count
                        Button(all ? "選択を解除" : "すべて選択") {
                            withAnimation(FieluaMotion.mark) { chosen = all ? [] : Set(threads.map(\.id)) }
                        }
                        .font(.subheadline.weight(.semibold))
                        // The umber of every tappable word (the links' amber before 1.1.0 (263)).
                        .fieluaTextButton()
                        .accessibilityIdentifier("chat-history-select-all")
                    }
                    .padding(.horizontal, 4)
                    VStack(spacing: 0) {
                        // Chosen neighbours share one wash (1.1.0 (252), the
                        // user's screenshot: each row's own rounded wash
                        // overlapped the next at the corners).
                        ForEach(Array(threads.enumerated()), id: \.element.id) { index, thread in
                            row(thread,
                                joinsAbove: index > 0 && chosen.contains(threads[index - 1].id),
                                joinsBelow: index + 1 < threads.count && chosen.contains(threads[index + 1].id))
                                .transition(.opacity)
                        }
                    }
                    .padding(6)
                    .fieluaCard(cornerRadius: 20)
                    .transition(.opacity)
                }
            }
            .padding(20)
        }
        .accessibilityIdentifier("chat-history-list")
        .settingsScroll()
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if !threads.isEmpty { deleteBar }
        }
        // Deleted, and not: both are felt (neither was before 1.1.0 (263)).
        .sensoryFeedback(.success, trigger: deletions)
        .sensoryFeedback(.error, trigger: failures)
        .alert(Text("\(chosen.count)件の会話を削除しますか？"), isPresented: $confirming) {
            Button("キャンセル", role: .cancel) {}
            Button("削除", role: .destructive) { deleteChosen() }
        } message: {
            Text(verbatim: deleteMessage)
        }
    }

    /// The chosen chats go, their rows fading out and the count counting
    /// down; or the reason they did not is said above the button.
    private func deleteChosen() {
        guard let chats = chatHandle.store else { return }
        if chats.deleteChats(chosen) {
            deletions += 1
            withAnimation(FieluaMotion.change(reduceMotion)) {
                chosen = []
                problem = nil
            }
        } else if let message = chats.error {
            // Said here; the chat's alert would wait under this sheet.
            chats.error = nil
            failures += 1
            withAnimation(FieluaMotion.change(reduceMotion)) { problem = message }
        }
    }

    /// What else the delete does to the automatic backup (設定's iCloud 自動
    /// 保存). Fielua's own iCloud (1.1.0 (252)) follows: its next save leaves
    /// the chats and the attachments only they used out. A folder the person
    /// chose is their own copy: its next save leaves the chats out, and the
    /// copies already in it stay (1.1.0 (251) directive).
    private var deleteMessage: String {
        let cloud = CloudHistoryStore.shared
        var lines = [String(localized: "添付した写真やファイルも削除されます。この操作は取り消せません。")]
        if cloud.privateCloud {
            lines.append(cloud.enabled ? String(localized: "Fielua 専用の iCloud のバックアップからも、次の自動保存で消えます。")
                                       : String(localized: "自動保存がオフのため、Fielua 専用の iCloud のバックアップには残ります。"))
            if cloud.earlierFolderName != nil {
                lines.append(String(localized: "前の保存先のフォルダに保存済みのコピーは削除されません。"))
            }
        } else if cloud.enabled {
            lines.append(String(localized: "バックアップ先のフォルダに保存済みのコピーは削除されません。"))
        }
        return lines.joined(separator: "\n")
    }

    /// `joinsAbove` / `joinsBelow`: the row next to it is chosen too, so the
    /// wash runs on square across that edge and a run of chosen chats reads as
    /// one block, rounded only at its ends.
    private func row(_ thread: ChatThread, joinsAbove: Bool, joinsBelow: Bool) -> some View {
        let on = chosen.contains(thread.id)
        return Button {
            // The check takes its ring and the wash comes with it (both
            // were cut, with a check drawn here, before 1.1.0 (263)).
            withAnimation(FieluaMotion.mark) {
                if on { chosen.remove(thread.id) } else { chosen.insert(thread.id) }
            }
        } label: {
            HStack(spacing: 12) {
                FieluaCheckMark(on: on, size: 21)
                Text(thread.title)
                    .font(.body)
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(thread.updatedAt.formatted(date: .numeric, time: .omitted))
                    .font(.caption).foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            .padding(.horizontal, 10)
            .frame(minHeight: 48)
            .background {
                // The sidebar's open chat: the warm grey wash.
                if on {
                    let top: CGFloat = joinsAbove ? 0 : 14, bottom: CGFloat = joinsBelow ? 0 : 14
                    UnevenRoundedRectangle(topLeadingRadius: top, bottomLeadingRadius: bottom,
                                           bottomTrailingRadius: bottom, topTrailingRadius: top, style: .continuous)
                        .fill(Theme.selection)
                        .transition(.opacity)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(thread.title)
        .accessibilityValue(Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted)))
        .accessibilityAddTraits(on ? .isSelected : [])
        .accessibilityIdentifier("chat-history-row")
    }

    private var deleteBar: some View {
        VStack(spacing: 6) {
            if let problem {
                Text(verbatim: problem)
                    .font(.caption).foregroundStyle(Theme.caution)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
                    .accessibilityIdentifier("chat-history-problem")
            }
            if pulse.isGenerating {
                Text("返信を書き終えると削除できます")
                    .font(.caption).foregroundStyle(.secondary)
                    .transition(.opacity)
            }
            let usable = !chosen.isEmpty && !pulse.isGenerating
            Button(role: .destructive) { confirming = true } label: {
                Text(chosen.isEmpty ? String(localized: "削除") : String(localized: "\(chosen.count)件を削除"))
                    .contentTransition(.numericText(value: Double(chosen.count)))
                    .font(.body.weight(.semibold))
                    // The glass style draws its label in the primary colour
                    // whatever the tint; the red of a deletion is set here,
                    // and a button that cannot be pressed stays grey.
                    .foregroundStyle(usable ? AnyShapeStyle(Color.red) : AnyShapeStyle(.tertiary))
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .contentShape(Capsule())
            }
            .buttonStyle(.glass)
            .disabled(!usable)
            .accessibilityIdentifier("chat-history-delete")
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 12)
        .animation(FieluaMotion.change(reduceMotion), value: pulse.isGenerating)
    }
}

/// 試験機能を試してみる's Smart Memory (1.1.0 (251)): off until turned on,
/// apart from Smart Mode's switch. On, each question also gets what of the
/// saved conversations bears on it, found and read on this iPhone alone
/// (SmartMemory); off, nothing is searched.
struct SmartMemoryCard: View {
    // Acted on, never read: no need to draw again with it (1.1.0 (263)).
    @Environment(\.chatHandle) private var chatHandle
    @AppStorage(SmartMemory.storageKey) private var on = false
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Toggle("Smart Memory", isOn: $on)
                .font(.headline).fieluaStateTint().accessibilityIdentifier("experiments-smart-memory-toggle")
            Text("過去の関連会話をこのiPhone内だけで検索し、モデル変更時も記憶を引き継いで回答します。")
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("experiments-smart-memory-caption")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .onChange(of: on) { _, value in chatHandle.store?.smartMemoryChanged(value) }
    }
}

/// Under a reply Smart Memory gave earlier exchanges (1.1.0 (251)): how
/// many, and in its menu the conversations they came from, each opening
/// that conversation. Only those still saved; none, and nothing shows.
struct MemorySourcesView: View {
    let recall: MemoryRecall
    @EnvironmentObject private var chats: ChatStore

    var body: some View {
        let sources = recall.live(in: chats.threads)
        let threads = sources.reduce(into: [UUID]()) { if !$0.contains($1.thread) { $0.append($1.thread) } }
        if !threads.isEmpty {
            Menu {
                Section("参照した会話") {
                    ForEach(threads, id: \.self) { id in
                        if let thread = chats.threads.first(where: { $0.id == id }) {
                            Button {
                                chats.select(id)
                            } label: {
                                Text(thread.title)
                                Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted))
                            }
                            .disabled(chats.isGenerating || id == chats.selectedID)
                        }
                    }
                }
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "clock.arrow.circlepath").font(.system(size: 11, weight: .semibold))
                    Text("過去の会話を参照 · \(sources.count)件")
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(.vertical, 4)
                .contentShape(Rectangle())
            }
            .menuOrder(.fixed)
            .accessibilityLabel(Text("過去の会話を参照 · \(sources.count)件"))
            .accessibilityIdentifier("reply-memory-sources")
        }
    }
}

/// The chat's mark and name at the top (1.1.0 (251), the user's directive
/// of 2026-10-31 18:47 UTC): in a Smart Mode chat Fielua's own app icon and
/// 「Fielua」, before the first question and whichever model answers or
/// genre is chosen; otherwise the chat's model, as before. The model a
/// reply used stays in its long-press menu and the diagnostics.
struct ChatHeaderMark: View {
    let model: ModelSpec
    let smart: Bool
    /// A chat answered on the PC (PCと接続, 1.1.0 (253)): the PC's mark and
    /// its model's name.
    var pc: PCChatTarget? = nil
    /// A chat answered by Claude (1.1.0 (257)): a cloud and 「Claude」.
    var claude: ClaudeChatTarget? = nil

    var body: some View {
        VStack(spacing: 4) {
            if pc != nil { PCMark(size: 40) }
            else if claude != nil { ClaudeMark(size: 40) }
            else if smart { FieluaAppIcon(size: 38).frame(width: 40, height: 40) }
            else { ModelMark(model: model, size: 40) }
            HStack(spacing: 3) {
                Text(verbatim: pc?.pillName ?? (claude != nil ? "Claude" : smart ? "Fielua" : model.family)).font(.caption.weight(.semibold))
                Image(systemName: "chevron.right").font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 9).padding(.vertical, 4)
            .chatGlass(in: Capsule())
        }
    }
}

/// The home-screen icon (FieluaIcon, made from the app icon by
/// scripts/make-icon.py, light and dark), in iOS's rounded square with a
/// hairline, as the 起動時のチャット preview draws it.
struct FieluaAppIcon: View {
    let size: CGFloat
    var body: some View {
        let shape = RoundedRectangle(cornerRadius: size * 0.225, style: .continuous)
        Image("FieluaIcon")
            .resizable()
            .interpolation(.high)
            .scaledToFill()
            .frame(width: size, height: size)
            .clipShape(shape)
            .overlay { shape.strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.5) }
            .accessibilityHidden(true)
    }
}
