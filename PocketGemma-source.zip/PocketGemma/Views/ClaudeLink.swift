import Foundation
import Security
import UIKit
import UniformTypeIdentifiers
import PocketCore

// Claude (1.1.0 (257), the user's directive of 2026-11-06 「Claude API
// 接続」): a chat answered by Claude through Fielua's relay
// (claude-relay/ in the repository, on the developer's Cloudflare
// account). Here are the connection, the registration and the
// developer's management; the invite, the turns sent and the reply's
// events are PocketCore's (ClaudeLink). In Views, so the UI preview,
// which compiles Views alone, talks to a relay exactly as the app does.
//
// Safety, as the directive asks:
// - The Anthropic key never reaches the app: it is the relay's secret.
//   The app holds this iPhone's access token alone, kept in the keychain
//   on this device only (never synced, never logged), void at once when
//   the developer stops or deletes it, or when this iPhone leaves.
// - HTTPS only (TLS 1.3), to the relay's address alone: no redirects,
//   cookies, cache or stored credentials. The address and the token are
//   sent nowhere else.
// - Only the chat's text turns that the reply needs go (ClaudeContext):
//   never photos, files, recordings, other chats or Smart Memory.
// - The developer's admin key, when this iPhone manages the relay, is
//   kept the same way, and copied out only for the relay's settings.

/// What can go wrong with Claude, in words for the chat and the page.
enum ClaudeLinkError: LocalizedError, Equatable {
    case notRegistered
    case badServer
    case unreachable
    case unavailable(ClaudeUnavailable)
    case revoked
    case removed
    case invalidInvite
    case tooManyAttempts
    case adminKey
    case adminNotConfigured
    case rateLimited
    case overloaded
    case serverKey
    case modelUnavailable
    /// The relay doesn't offer this model or level (an older or changed relay).
    case unsupportedChoice
    case tooLarge
    case rejected
    case refused
    case lost
    case notSaved
    case badResponse(Int)

    var errorDescription: String? {
        switch self {
        case .notRegistered:
            return String(localized: "Claudeが登録されていません。設定の「Claude」から登録してください。")
        case .badServer:
            return String(localized: "中継サーバーのアドレスが正しくありません。https:// で始まるアドレスを入れてください。")
        case .unreachable:
            return String(localized: "Claudeの中継サーバーに接続できません。インターネット接続を確かめてください。")
        case .unavailable(let reason):
            return reason.message
        case .revoked:
            return String(localized: "開発者がこのiPhoneのClaudeの利用を止めています。")
        case .removed:
            return String(localized: "このiPhoneのClaudeの登録が削除されました。招待を受けて、もう一度登録してください。")
        case .invalidInvite:
            return String(localized: "招待が無効です。使用済みか、72時間を過ぎています。新しい招待をもらってください。")
        case .tooManyAttempts:
            return String(localized: "試した回数が多すぎます。1時間ほど待ってからお試しください。")
        case .adminKey:
            return String(localized: "管理キーが違います。CloudflareのADMIN_TOKENと同じものを入れてください。")
        case .adminNotConfigured:
            return String(localized: "中継サーバーに管理キー（ADMIN_TOKEN、32文字以上）が設定されていません。")
        case .rateLimited:
            return String(localized: "Claudeへの問い合わせが多すぎます。少し待ってからお試しください。")
        case .overloaded:
            return String(localized: "Claudeが混み合っています。少し待ってからお試しください。")
        case .serverKey:
            return String(localized: "中継サーバーのAPIキーがAnthropicに受け付けられませんでした。開発者がキーを確かめる必要があります。")
        case .modelUnavailable:
            return String(localized: "中継サーバーのモデルがAnthropicで見つかりません。開発者が設定を確かめる必要があります。")
        case .unsupportedChoice:
            return String(localized: "このモデルか推論レベルは、中継サーバーで使えません。モデルの設定で選び直してください。")
        case .tooLarge:
            return String(localized: "会話が長すぎます。新しいチャットでお試しください。")
        case .rejected:
            return String(localized: "Anthropicがこの依頼を受け付けませんでした。新しいチャットでお試しください。")
        case .refused:
            return String(localized: "Claudeはこの質問への回答を控えました。")
        case .lost:
            return String(localized: "Claudeとの接続が切れました。ここまでの返信は残しています。")
        case .notSaved:
            return String(localized: "登録の情報をこのiPhoneに保存できませんでした。もう一度お試しください。")
        case .badResponse(let status):
            return String(localized: "中継サーバーから予期しない応答がありました（\(status)）。")
        }
    }

    /// A refusal in the relay's words ({"error": code, "reason": ..}).
    static func from(status: Int, json: [String: Any]) -> ClaudeLinkError {
        let code = json["error"] as? String
        switch code {
        case "unavailable":
            return .unavailable(ClaudeUnavailable(rawValue: json["reason"] as? String ?? "") ?? .notConfigured)
        case "unauthorized": return .removed
        case "revoked": return .revoked
        case "invalid_code": return .invalidInvite
        case "too_many_attempts": return .tooManyAttempts
        case "rate_limited": return .rateLimited
        case "overloaded": return .overloaded
        case "server_key": return .serverKey
        case "model_unavailable": return .modelUnavailable
        case "unsupported_model", "unsupported_effort": return .unsupportedChoice
        case "too_large": return .tooLarge
        case "rejected", "bad_request": return .rejected
        case "upstream_unreachable": return .unreachable
        case "admin_not_configured": return .adminNotConfigured
        default: return .badResponse(status)
        }
    }
}

extension ClaudeUnavailable {
    /// In words for the chat and 設定 › Claude.
    var message: String {
        switch self {
        case .notConfigured:
            return String(localized: "中継サーバーにAnthropicのAPIキーが設定されていません。")
        case .pausedBilling:
            return String(localized: "AnthropicのAPIクレジットがなくなったため、Claudeを止めています。追加購入はしていません。開発者が再開するまでお待ちください。")
        case .pausedLimit:
            return String(localized: "Anthropicの利用上限に達したため、Claudeを止めています。開発者が再開するまでお待ちください。")
        case .friendsDisabled:
            return String(localized: "開発者が友人の利用をまだオンにしていません。")
        }
    }

    /// A few words, for the model menu and the chat's line.
    var short: String {
        switch self {
        case .notConfigured: return String(localized: "APIキーが未設定")
        case .pausedBilling: return String(localized: "クレジット切れで停止中")
        case .pausedLimit: return String(localized: "利用上限で停止中")
        case .friendsDisabled: return String(localized: "友人の利用はオフ")
        }
    }
}

/// This iPhone's registration and the developer's admin key, in the
/// keychain on this device only.
enum ClaudeKeychain {
    private static func item(_ account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.claude",
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: kCFBooleanFalse as Any]
    }

    private static func load(_ account: String) -> Data? {
        var query = item(account)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess else { return nil }
        return result as? Data
    }

    private static func save(_ data: Data, as account: String) -> Bool {
        SecItemDelete(item(account) as CFDictionary)
        var entry = item(account)
        entry[kSecValueData as String] = data
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
    }

    static func account() -> ClaudeAccount? {
        load("account").flatMap { try? JSONDecoder().decode(ClaudeAccount.self, from: $0) }
    }

    static func save(_ account: ClaudeAccount) -> Bool {
        guard let data = try? JSONEncoder().encode(account) else { return false }
        return save(data, as: "account")
    }

    static func adminKey() -> String? {
        load("admin-key").flatMap { String(data: $0, encoding: .utf8) }
    }

    static func saveAdminKey(_ key: String) -> Bool { save(Data(key.utf8), as: "admin-key") }

    static func deleteAccount() { SecItemDelete(item("account") as CFDictionary) }
    static func deleteAdminKey() { SecItemDelete(item("admin-key") as CFDictionary) }
}

/// HTTPS to the relay: TLS 1.3, no redirects, cookies, cache or stored
/// credentials; the token in its header to the relay's own address alone.
final class ClaudeConnection: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    private var session: URLSession!

    override init() {
        super.init()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.tlsMinimumSupportedProtocolVersion = .TLSv13
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        configuration.waitsForConnectivity = false
        // Anthropic's stream sends a ping while Claude thinks: two minutes
        // of silence is a lost connection.
        configuration.timeoutIntervalForRequest = 120
        configuration.timeoutIntervalForResource = 30 * 60
        session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }

    /// A redirect is refused: the token goes to the relay's address alone.
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest) async -> URLRequest? { nil }

    private func request(_ server: URL, _ method: String, _ path: String, body: [String: Any]?,
                         token: String?, timeout: TimeInterval) throws -> URLRequest {
        guard var components = URLComponents(url: server, resolvingAgainstBaseURL: false) else { throw ClaudeLinkError.badServer }
        components.path = path
        guard let url = components.url else { throw ClaudeLinkError.badServer }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = method
        if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    /// One request and its JSON answer, whatever its status.
    func call(_ server: URL, _ method: String, _ path: String, body: [String: Any]? = nil,
              token: String? = nil) async throws -> (status: Int, json: [String: Any]) {
        let request = try request(server, method, path, body: body, token: token, timeout: 20)
        do {
            let (data, response) = try await session.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            return (status, (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        } catch {
            throw Self.mapped(error, streaming: false)
        }
    }

    /// A reply as the relay streams it, a line at a time, until `onLine`
    /// says it ended. Cancelling the task closes the connection, which
    /// the relay passes on: Anthropic stops writing too.
    func stream(_ server: URL, _ path: String, body: [String: Any], token: String,
                onLine: (String) async throws -> Bool) async throws {
        let request = try request(server, "POST", path, body: body, token: token, timeout: 120)
        let bytes: URLSession.AsyncBytes
        let response: URLResponse
        do { (bytes, response) = try await session.bytes(for: request) } catch { throw Self.mapped(error, streaming: false) }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else {
            var data = Data()
            do {
                for try await byte in bytes {
                    data.append(byte)
                    if data.count > 16 * 1024 { break }
                }
            } catch { throw Self.mapped(error, streaming: false) }
            throw ClaudeLinkError.from(status: status, json: (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        }
        do {
            for try await line in bytes.lines {
                if try await onLine(line) { return }
            }
        } catch let error as ClaudeLinkError {
            throw error
        } catch {
            throw Self.mapped(error, streaming: true)
        }
        // The stream ended without message_stop: the connection went away.
        throw ClaudeLinkError.lost
    }

    private static func mapped(_ error: Error, streaming: Bool) -> Error {
        if error is CancellationError || Task.isCancelled { return CancellationError() }
        if (error as NSError).domain == NSURLErrorDomain, (error as NSError).code == NSURLErrorCancelled { return CancellationError() }
        return streaming ? ClaudeLinkError.lost : ClaudeLinkError.unreachable
    }
}

/// The relay as the developer manages it (GET /admin/state).
struct ClaudeAdminState: Equatable {
    struct Person: Equatable, Identifiable {
        var id: String
        var name: String
        var isDeveloper: Bool
        var active: Bool
        var lastUsed: Date?
    }
    struct OpenInvite: Equatable, Identifiable {
        var id: String
        var name: String
        var isDeveloper: Bool
        var expires: Date
    }
    var people: [Person]
    var invites: [OpenInvite]
    var friendsEnabled: Bool
    var paused: ClaudeUnavailable?
    var configured: Bool
    var modelName: String

    init(_ json: [String: Any]) {
        func date(_ value: Any?) -> Date? { (value as? NSNumber).map { Date(timeIntervalSince1970: $0.doubleValue / 1000) } }
        people = ((json["users"] as? [[String: Any]]) ?? []).compactMap { user in
            guard let id = user["id"] as? String else { return nil }
            return Person(id: id, name: user["name"] as? String ?? "", isDeveloper: user["role"] as? String == "developer",
                          active: user["status"] as? String != "revoked", lastUsed: date(user["lastUsedAt"]))
        }
        invites = ((json["invites"] as? [[String: Any]]) ?? []).compactMap { invite in
            guard let id = invite["id"] as? String, let expires = date(invite["expiresAt"]) else { return nil }
            return OpenInvite(id: id, name: invite["name"] as? String ?? "", isDeveloper: invite["role"] as? String == "developer",
                              expires: expires)
        }
        let settings = json["settings"] as? [String: Any]
        friendsEnabled = settings?["friendsEnabled"] as? Bool ?? false
        switch settings?["paused"] as? String {
        case "billing": paused = .pausedBilling
        case "limit": paused = .pausedLimit
        default: paused = nil
        }
        configured = json["configured"] as? Bool ?? false
        modelName = ClaudeLinkStore.modelName(json["model"] as? String ?? "")
    }
}

/// This iPhone's registration, whether Claude answers now, and the
/// developer's management, for the views and both ChatStores.
@MainActor final class ClaudeLinkStore: ObservableObject {
    static let shared = ClaudeLinkStore()

    enum State: Equatable {
        /// Not registered.
        case none
        case checking
        case ready
        case unavailable(ClaudeUnavailable)
        case revoked
        /// The relay doesn't know this iPhone any more.
        case removed
        case unreachable
    }

    @Published private(set) var account: ClaudeAccount?
    @Published private(set) var state: State = .none
    /// The models the relay offers and their levels, as it last said
    /// (this version's own list until it answers): the model menu and the
    /// chat's model settings offer these alone.
    @Published private(set) var models: [ClaudeModel] = ClaudeModel.builtIn
    /// The relay's model for a chat when the person has chosen none.
    @Published private(set) var defaultModel: String = ClaudeModel.opus.id
    /// The developer's admin key is on this iPhone.
    @Published private(set) var hasAdminKey = false
    /// An invite opened from its link, waiting for the person's yes.
    @Published var pendingInvite: ClaudeInvite?
    private let connection = ClaudeConnection()
    private var checking: Task<Void, Never>?

    /// Plain http to this Mac for the UI preview's checks; https otherwise.
    nonisolated static var allowsLocal: Bool {
        #if POCKET_PREVIEW
        true
        #else
        false
        #endif
    }

    private init() {
        #if POCKET_PREVIEW
        // The claude UI check starts with nothing registered.
        if ProcessInfo.processInfo.arguments.contains("--claude-reset") {
            ClaudeKeychain.deleteAccount()
            ClaudeKeychain.deleteAdminKey()
            for key in UserDefaults.standard.dictionaryRepresentation().keys where key.hasPrefix("claude.") {
                UserDefaults.standard.removeObject(forKey: key)
            }
        }
        #endif
        account = ClaudeKeychain.account()
        hasAdminKey = ClaudeKeychain.adminKey() != nil
        if account != nil { state = .checking }
    }

    var isRegistered: Bool { account != nil }
    var isReady: Bool { state == .ready }

    nonisolated static func modelName(_ model: String) -> String {
        ClaudeModel.forChat(model, offered: ClaudeModel.builtIn)?.name ?? (model.isEmpty ? "Claude" : model)
    }

    // MARK: The model and level a chat uses

    /// The last model chosen, and each model's last level: on this iPhone
    /// only, as a phone model's settings are.
    private static let chosenModelKey = "claude.model"
    private static func effortKey(_ model: String) -> String { "claude.effort.\(model)" }

    /// A chat's model and its levels: one the relay offers, or a former one
    /// (Claude Fable 5.1 since 2026-11-10), which a chat begun with it keeps.
    func model(_ id: String) -> ClaudeModel? { ClaudeModel.forChat(id, offered: models) }

    /// A new chat's Claude: `model` (the model menu's choice), or the one
    /// chosen last (the one that took its place, for a former model), or
    /// the relay's; at the level last chosen for it, or its default.
    func target(for model: ClaudeModel? = nil) -> ClaudeChatTarget {
        let defaults = UserDefaults.standard
        let last = defaults.string(forKey: Self.chosenModelKey)
        let chosen = model ?? last.flatMap { ClaudeModel.forNewChat($0, offered: models) }
            ?? ClaudeModel.forNewChat(defaultModel, offered: models) ?? models.first ?? .opus
        // A former model's level goes on with the one that took its place.
        let formerLevel = last.flatMap { id in ClaudeModel.former.first { $0.model.id == id && $0.successor == chosen.id } }
            .flatMap { defaults.string(forKey: Self.effortKey($0.model.id)) }
        let effort = (defaults.string(forKey: Self.effortKey(chosen.id)) ?? formerLevel).flatMap(ClaudeEffort.init(rawValue:))
        return ClaudeChatTarget(chosen, effort: effort)
    }

    /// The person's choice, for the next new chat with Claude.
    func remember(_ target: ClaudeChatTarget) {
        UserDefaults.standard.set(target.model, forKey: Self.chosenModelKey)
        if let effort = target.effort { UserDefaults.standard.set(effort.rawValue, forKey: Self.effortKey(target.model)) }
    }

    /// Whether the relay offers this model at this level (nil: its default).
    func supports(_ target: ClaudeChatTarget) -> Bool {
        guard let model = self.model(target.model) else { return false }
        return target.effort.map { model.efforts.contains($0) } ?? true
    }

    private func server() throws -> (URL, ClaudeAccount) {
        guard let account else { throw ClaudeLinkError.notRegistered }
        guard let url = ClaudeLink.server(account.server, allowsLocal: Self.allowsLocal) else { throw ClaudeLinkError.badServer }
        return (url, account)
    }

    // MARK: Whether Claude answers

    /// Asks the relay whether Claude answers this iPhone now; nothing
    /// without a registration. Called as the app comes back and the page opens.
    func refresh() {
        guard account != nil, checking == nil else { return }
        state = .checking
        checking = Task {
            await check()
            checking = nil
        }
    }

    private func check() async {
        guard let place = try? server() else { state = .none; return }
        let (url, account) = place
        do {
            let (status, json) = try await connection.call(url, "GET", "/v1/status", token: account.token)
            guard self.account?.token == account.token else { return }
            switch status {
            case 200:
                // An older relay sends no list: this version's own stays.
                if let offered = ClaudeModel.catalog(json["models"]), !offered.isEmpty, offered != models { models = offered }
                if let model = json["model"] as? String, !model.isEmpty, model != defaultModel { defaultModel = model }
                if json["available"] as? Bool == true {
                    state = .ready
                } else {
                    state = .unavailable(ClaudeUnavailable(rawValue: json["reason"] as? String ?? "") ?? .notConfigured)
                }
            case 401: state = .removed
            case 403: state = .revoked
            default: state = .unreachable
            }
        } catch {
            if self.account?.token == account.token { state = .unreachable }
        }
    }

    /// What the chat says when Claude can't answer now; nil when it can
    /// (or while it is being checked: sending says why, if it fails).
    var problem: String? {
        switch state {
        case .none: return ClaudeLinkError.notRegistered.localizedDescription
        case .unavailable(let reason): return reason.message
        case .revoked: return ClaudeLinkError.revoked.localizedDescription
        case .removed: return ClaudeLinkError.removed.localizedDescription
        case .unreachable: return ClaudeLinkError.unreachable.localizedDescription
        case .ready, .checking: return nil
        }
    }

    // MARK: Registering

    /// An invite's code for this iPhone's access token, kept in the keychain.
    func redeem(_ invite: ClaudeInvite) async throws {
        let (status, json) = try await connection.call(invite.server, "POST", "/v1/redeem", body: ["code": invite.code])
        guard status == 200, let token = json["token"] as? String else { throw ClaudeLinkError.from(status: status, json: json) }
        // Registering again replaces the registration before: the relay forgets it too.
        if account != nil { await leaveRelay() }
        let registered = ClaudeAccount(server: invite.server.absoluteString, token: token,
                                       name: json["name"] as? String ?? "", role: json["role"] as? String ?? "friend")
        guard ClaudeKeychain.save(registered) else { throw ClaudeLinkError.notSaved }
        account = registered
        pendingInvite = nil
        state = .checking
        await check()
    }

    /// The developer's own registration: an invite made with the admin
    /// key, redeemed at once; the key is kept to manage the relay.
    func registerAsDeveloper(server text: String, adminKey: String) async throws {
        guard let server = ClaudeLink.server(text, allowsLocal: Self.allowsLocal) else { throw ClaudeLinkError.badServer }
        let key = adminKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let (status, json) = try await connection.call(server, "POST", "/admin/invites",
                                                       body: ["name": String(localized: "開発者"), "role": "developer"], token: key)
        guard status == 200, let raw = json["code"] as? String, let code = ClaudeLink.code(raw) else {
            throw status == 401 ? ClaudeLinkError.adminKey : ClaudeLinkError.from(status: status, json: json)
        }
        guard ClaudeKeychain.saveAdminKey(key) else { throw ClaudeLinkError.notSaved }
        hasAdminKey = true
        try await redeem(ClaudeInvite(server: server, code: code))
    }

    /// 登録を解除: the relay deletes this iPhone's registration (if it can
    /// be reached), and this iPhone forgets it and the admin key. The
    /// chats with Claude stay.
    func leave() async {
        await leaveRelay()
        ClaudeKeychain.deleteAccount()
        ClaudeKeychain.deleteAdminKey()
        account = nil
        hasAdminKey = false
        state = .none
    }

    private func leaveRelay() async {
        guard let place = try? server() else { return }
        let (url, account) = place
        _ = try? await connection.call(url, "POST", "/v1/leave", token: account.token)
    }

    // MARK: A reply

    enum ReplyProgress {
        /// Claude thinks before it answers (its thinking is not shown).
        case thinking
        /// Still working, nothing new to show.
        case alive
    }

    /// One reply from Claude, streamed to `onText`: from the chat's model
    /// at its level, both named in the request (超高 goes as "xhigh").
    /// Throws ClaudeLinkError, or CancellationError when stopped here.
    /// Returns whether the reply reached its length limit.
    @discardableResult
    func reply(turns: [PCTurn], target: ClaudeChatTarget, onProgress: @escaping (ReplyProgress) async -> Void,
               onText: @escaping (String) async -> Void) async throws -> Bool {
        let (url, account) = try server()
        guard supports(target), let model = self.model(target.model) else { throw ClaudeLinkError.unsupportedChoice }
        // Always named, the model's default too (a chat from before levels).
        let body: [String: Any] = ["messages": turns.map { ["role": $0.role, "content": $0.content] },
                                   "model": model.id, "effort": (target.effort ?? model.defaultEffort).rawValue]
        var cutOff = false
        do {
            try await connection.stream(url, "/v1/messages", body: body, token: account.token) { line in
                guard let event = ClaudeStreamEvent(line: line) else { return false }
                switch event {
                case .started, .alive: await onProgress(.alive)
                case .thinking: await onProgress(.thinking)
                case .text(let text): await onText(text)
                case .refused: throw ClaudeLinkError.refused
                case .cutOff: cutOff = true
                case .done: return true
                case .failed(let type):
                    switch type {
                    case "overloaded_error": throw ClaudeLinkError.overloaded
                    case "rate_limit_error": throw ClaudeLinkError.rateLimited
                    default: throw ClaudeLinkError.lost
                    }
                }
                return false
            }
            if state != .ready { state = .ready }
        } catch let error as ClaudeLinkError {
            switch error {
            case .unavailable(let reason): state = .unavailable(reason)
            case .revoked: state = .revoked
            case .removed: state = .removed
            case .unreachable: state = .unreachable
            default: break
            }
            throw error
        }
        return cutOff
    }

    // MARK: The developer's management (the admin key)

    private func admin(_ method: String, _ path: String, body: [String: Any]? = nil) async throws -> [String: Any] {
        let (url, _) = try server()
        guard let key = ClaudeKeychain.adminKey() else { throw ClaudeLinkError.adminKey }
        let (status, json) = try await connection.call(url, method, path, body: body, token: key)
        guard status == 200 else { throw status == 401 ? ClaudeLinkError.adminKey : ClaudeLinkError.from(status: status, json: json) }
        return json
    }

    func adminState() async throws -> ClaudeAdminState {
        ClaudeAdminState(try await admin("GET", "/admin/state"))
    }

    /// A friend's invite: the link to send them (https://<relay>/join#CODE).
    func invite(name: String) async throws -> URL {
        let json = try await admin("POST", "/admin/invites", body: ["name": name, "role": "friend"])
        guard let text = json["link"] as? String, let link = URL(string: text) else { throw ClaudeLinkError.badResponse(200) }
        return link
    }

    func setActive(_ person: ClaudeAdminState.Person, _ active: Bool) async throws {
        _ = try await admin("POST", "/admin/users/\(person.id)/\(active ? "restore" : "revoke")")
    }

    func delete(_ person: ClaudeAdminState.Person) async throws {
        _ = try await admin("DELETE", "/admin/users/\(person.id)")
    }

    func cancel(_ invite: ClaudeAdminState.OpenInvite) async throws {
        _ = try await admin("DELETE", "/admin/invites/\(invite.id)")
    }

    func setFriendsEnabled(_ on: Bool) async throws {
        _ = try await admin("POST", "/admin/settings", body: ["friendsEnabled": on])
        await check()
    }

    /// After the credit or the limit was seen to: Claude answers again.
    func resume() async throws {
        _ = try await admin("POST", "/admin/settings", body: ["resume": true])
        await check()
    }

    /// The admin key typed on this iPhone again (after reinstalling): kept
    /// once the relay accepts it.
    func useAdminKey(_ key: String) async throws {
        let key = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let (url, _) = try server()
        let (status, json) = try await connection.call(url, "GET", "/admin/state", token: key)
        guard status == 200 else { throw status == 401 ? ClaudeLinkError.adminKey : ClaudeLinkError.from(status: status, json: json) }
        guard ClaudeKeychain.saveAdminKey(key) else { throw ClaudeLinkError.notSaved }
        hasAdminKey = true
    }

    func forgetAdminKey() {
        ClaudeKeychain.deleteAdminKey()
        hasAdminKey = false
    }

    /// A new admin key for the relay's ADMIN_TOKEN: 32 random bytes,
    /// base64url (43 characters).
    static func newAdminKey() -> String {
        var bytes = [UInt8](repeating: 0, count: 32)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else {
            return (0..<2).map { _ in UUID().uuidString.replacingOccurrences(of: "-", with: "") }.joined()
        }
        return PCLink.base64URL(Data(bytes))
    }

    /// Copies a secret for pasting into the relay's settings: this device
    /// only (never to Universal Clipboard), and gone after ten minutes.
    static func copySecret(_ text: String) {
        UIPasteboard.general.setItems([[UTType.plainText.identifier: text]],
                                      options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(600)])
    }
}
