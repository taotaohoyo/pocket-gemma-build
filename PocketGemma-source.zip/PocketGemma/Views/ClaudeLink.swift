import CryptoKit
import Foundation
import LocalAuthentication
import Security
import UIKit
import UniformTypeIdentifiers
import PocketCore

// Claude (1.1.0 (257), the user's directive of 2026-11-06 「Claude API
// 接続」): a chat answered by Claude through Fielua's relay
// (claude-relay/ in the repository, on the developer's Cloudflare
// account). Here are the connection, the registration and the
// developer's management; the invite, the turns sent and the reply's
// events are PocketCore's (ClaudeLink). In Views, so the UI preview,
// which compiles Views alone, talks to a relay exactly as the app does.
//
// Safety, as the directive asks:
// - The Anthropic key never reaches the app: it is the relay's secret.
//   The app holds this iPhone's access token alone, kept in the keychain
//   on this device only (never synced, never logged), void at once when
//   the developer stops or deletes it, or when this iPhone leaves.
// - HTTPS only (TLS 1.3), to the relay's address alone: no redirects,
//   cookies, cache or stored credentials. The address and the token are
//   sent nowhere else.
// - Only the chat's turns that the reply needs go (ClaudeContext), with
//   the photos, PDFs and files the person attached to them (1.1.0 (260)),
//   newest first as far as one request carries: never recordings, videos,
//   other chats or Smart Memory. Photos go re-encoded (no location or
//   other metadata).
// - Web search and file creation (1.1.0 (260)) are Claude's own tools at
//   Anthropic, on only while the chat's switch is; a file made is the
//   person's alone at the relay, downloaded only when they save it.
// - The developer's admin key, when this iPhone manages the relay, is
//   kept the same way, and copied out only for the relay's settings.
// - Or, without the admin key (1.1.0 (262)), Face ID: a key made in the
//   Secure Enclave when the developer's invite is redeemed, which signs
//   the relay's challenge only after Face ID (or the passcode) and never
//   leaves the iPhone (ClaudeDeviceKey). The relay's admin token it gets
//   lasts 15 minutes and is kept in memory only.

/// What can go wrong with Claude, in words for the chat and the page.
enum ClaudeLinkError: LocalizedError, Equatable {
    case notRegistered
    case badServer
    case unreachable
    case unavailable(ClaudeUnavailable)
    case revoked
    case removed
    case invalidInvite
    case tooManyAttempts
    case adminKey
    case adminNotConfigured
    /// Face ID (or the passcode) didn't say it is the developer.
    case notVerified
    /// The relay has no Face ID key for this registration (or not this iPhone's).
    case noDeviceKey
    case rateLimited
    case overloaded
    case serverKey
    case modelUnavailable
    /// The relay doesn't offer this model or level (an older or changed relay).
    case unsupportedChoice
    case tooLarge
    case rejected
    case refused
    case lost
    case notSaved
    case badResponse(Int)
    /// The question's photos and files are more than one request carries (1.1.0 (260)).
    case attachmentsTooLarge
    /// A video or recording: Claude reads neither.
    case attachmentKind
    /// The relay couldn't read a photo or file as what it says it is.
    case badAttachment
    /// A file a reply made is no longer kept (or isn't this person's).
    case fileGone

    var errorDescription: String? {
        switch self {
        case .notRegistered:
            return String(localized: "Claudeが登録されていません。設定の「Claude」から登録してください。")
        case .badServer:
            return String(localized: "中継サーバーのアドレスが正しくありません。https:// で始まるアドレスを入れてください。")
        case .unreachable:
            return String(localized: "Claudeの中継サーバーに接続できません。インターネット接続を確かめてください。")
        case .unavailable(let reason):
            return reason.message
        case .revoked:
            return String(localized: "開発者がこのiPhoneのClaudeの利用を止めています。")
        case .removed:
            return String(localized: "このiPhoneのClaudeの登録が削除されました。招待を受けて、もう一度登録してください。")
        case .invalidInvite:
            return String(localized: "招待が無効です。使用済みか、72時間を過ぎています。新しい招待をもらってください。")
        case .tooManyAttempts:
            return String(localized: "試した回数が多すぎます。1時間ほど待ってからお試しください。")
        case .adminKey:
            return String(localized: "管理キーが違います。CloudflareのADMIN_TOKENと同じものを入れてください。")
        case .adminNotConfigured:
            return String(localized: "中継サーバーに管理キー（ADMIN_TOKEN、32文字以上）が設定されていません。")
        case .notVerified:
            return String(localized: "本人の確認ができませんでした。もう一度お試しください。")
        case .noDeviceKey:
            return String(localized: "このiPhoneの登録では管理できません。開発者の招待で、このiPhoneを登録し直してください。")
        case .rateLimited:
            return String(localized: "Claudeへの問い合わせが多すぎます。少し待ってからお試しください。")
        case .overloaded:
            return String(localized: "Claudeが混み合っています。少し待ってからお試しください。")
        case .serverKey:
            return String(localized: "中継サーバーのAPIキーがAnthropicに受け付けられませんでした。開発者がキーを確かめる必要があります。")
        case .modelUnavailable:
            return String(localized: "中継サーバーのモデルがAnthropicで見つかりません。開発者が設定を確かめる必要があります。")
        case .unsupportedChoice:
            return String(localized: "このモデルか推論レベルは、中継サーバーで使えません。モデルの設定で選び直してください。")
        case .tooLarge:
            return String(localized: "会話が長すぎます。新しいチャットでお試しください。")
        case .rejected:
            return String(localized: "Anthropicがこの依頼を受け付けませんでした。新しいチャットでお試しください。")
        case .refused:
            return String(localized: "Claudeはこの質問への回答を控えました。")
        case .lost:
            return String(localized: "Claudeとの接続が切れました。ここまでの返信は残しています。")
        case .notSaved:
            return String(localized: "登録の情報をこのiPhoneに保存できませんでした。もう一度お試しください。")
        case .badResponse(let status):
            return String(localized: "中継サーバーから予期しない応答がありました（\(status)）。")
        case .attachmentsTooLarge:
            return String(localized: "添付が大きすぎます。Claudeに一度に送れるのは、写真とPDFを合わせて約\(ClaudeLinkStore.attachmentLabel)までです。")
        case .attachmentKind:
            return String(localized: "Claudeには写真・PDF・ファイルを送れます。動画と音声は、iPhoneのモデルでお試しください。")
        case .badAttachment:
            return String(localized: "添付した写真かファイルを、中継サーバーが読み取れませんでした。")
        case .fileGone:
            return String(localized: "このファイルは保存できませんでした。作成から30日を過ぎたか、もう残っていません。")
        }
    }

    /// A refusal in the relay's words ({"error": code, "reason": ..}).
    static func from(status: Int, json: [String: Any]) -> ClaudeLinkError {
        let code = json["error"] as? String
        switch code {
        case "unavailable":
            return .unavailable(ClaudeUnavailable(rawValue: json["reason"] as? String ?? "") ?? .notConfigured)
        case "unauthorized": return .removed
        case "revoked": return .revoked
        case "invalid_code": return .invalidInvite
        case "too_many_attempts": return .tooManyAttempts
        case "rate_limited": return .rateLimited
        case "overloaded": return .overloaded
        case "server_key": return .serverKey
        case "model_unavailable": return .modelUnavailable
        case "unsupported_model", "unsupported_effort": return .unsupportedChoice
        case "too_large": return .tooLarge
        case "bad_attachment": return .badAttachment
        case "rejected", "bad_request": return .rejected
        case "upstream_unreachable": return .unreachable
        case "admin_not_configured": return .adminNotConfigured
        case "reauth_required": return .notVerified
        case "no_device_key", "signature_rejected": return .noDeviceKey
        default: return .badResponse(status)
        }
    }
}

extension ClaudeUnavailable {
    /// In words for the chat and 設定 › Claude.
    var message: String {
        switch self {
        case .notConfigured:
            return String(localized: "中継サーバーにAnthropicのAPIキーが設定されていません。")
        case .pausedBilling:
            return String(localized: "AnthropicのAPIクレジットがなくなったため、Claudeを止めています。追加購入はしていません。開発者が再開するまでお待ちください。")
        case .pausedLimit:
            return String(localized: "Anthropicの利用上限に達したため、Claudeを止めています。開発者が再開するまでお待ちください。")
        case .friendsDisabled:
            return String(localized: "開発者が友人の利用をまだオンにしていません。")
        }
    }

    /// A few words, for the model menu and the chat's line.
    var short: String {
        switch self {
        case .notConfigured: return String(localized: "APIキーが未設定")
        case .pausedBilling: return String(localized: "クレジット切れで停止中")
        case .pausedLimit: return String(localized: "利用上限で停止中")
        case .friendsDisabled: return String(localized: "友人の利用はオフ")
        }
    }
}

/// This iPhone's registration and the developer's admin key, in the
/// keychain on this device only.
enum ClaudeKeychain {
    private static func item(_ account: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.claude",
         kSecAttrAccount as String: account,
         kSecAttrSynchronizable as String: kCFBooleanFalse as Any]
    }

    private static func load(_ account: String) -> Data? {
        var query = item(account)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess else { return nil }
        return result as? Data
    }

    private static func save(_ data: Data, as account: String) -> Bool {
        SecItemDelete(item(account) as CFDictionary)
        var entry = item(account)
        entry[kSecValueData as String] = data
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
    }

    static func account() -> ClaudeAccount? {
        load("account").flatMap { try? JSONDecoder().decode(ClaudeAccount.self, from: $0) }
    }

    static func save(_ account: ClaudeAccount) -> Bool {
        guard let data = try? JSONEncoder().encode(account) else { return false }
        return save(data, as: "account")
    }

    static func adminKey() -> String? {
        load("admin-key").flatMap { String(data: $0, encoding: .utf8) }
    }

    static func saveAdminKey(_ key: String) -> Bool { save(Data(key.utf8), as: "admin-key") }

    /// The Secure Enclave's wrapped form of the Face ID key (of use on this iPhone's Secure Enclave alone).
    static func deviceKey() -> Data? { load("device-key") }
    static func saveDeviceKey(_ data: Data) -> Bool { save(data, as: "device-key") }

    static func deleteAccount() { SecItemDelete(item("account") as CFDictionary) }
    static func deleteAdminKey() { SecItemDelete(item("admin-key") as CFDictionary) }
    static func deleteDeviceKey() { SecItemDelete(item("device-key") as CFDictionary) }
}

/// This iPhone's key for managing the relay with Face ID (1.1.0 (262)),
/// as the web manages it with a passkey: made in the Secure Enclave when
/// an invite is redeemed, it signs only after Face ID or the passcode, and
/// the private key never leaves the Secure Enclave. The relay ties its
/// public half to the person when their invite is a developer's
/// (claude-relay/src/device.ts). The simulator has no Secure Enclave:
/// there alone, for the UI checks, a plain key that asks nothing.
enum ClaudeDeviceKey {
    struct Made {
        /// What the keychain keeps: the Secure Enclave's wrapped key.
        let stored: Data
        /// The public half, as the relay reads it (65 bytes, uncompressed).
        let publicKey: Data
    }

    static func make() -> Made? {
        #if targetEnvironment(simulator)
        let key = P256.Signing.PrivateKey()
        return Made(stored: key.rawRepresentation, publicKey: key.publicKey.x963Representation)
        #else
        guard SecureEnclave.isAvailable,
              let access = SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                                                           [.privateKeyUsage, .userPresence], nil),
              let key = try? SecureEnclave.P256.Signing.PrivateKey(accessControl: access)
        else { return nil }
        return Made(stored: key.dataRepresentation, publicKey: key.publicKey.x963Representation)
        #endif
    }

    /// The relay's challenge, signed once Face ID (or the passcode) said
    /// it is the developer. Cancelled by the person: CancellationError.
    static func sign(_ message: Data, with stored: Data) async throws -> Data {
        #if targetEnvironment(simulator)
        let key = try P256.Signing.PrivateKey(rawRepresentation: stored)
        return try key.signature(for: message).rawRepresentation
        #else
        let context = LAContext()
        do {
            _ = try await context.evaluatePolicy(.deviceOwnerAuthentication,
                                                 localizedReason: String(localized: "Claudeの中継サーバーを管理します。"))
        } catch let error as LAError where [LAError.Code.userCancel, .appCancel, .systemCancel].contains(error.code) {
            throw CancellationError()
        } catch {
            throw ClaudeLinkError.notVerified
        }
        // The context Face ID just passed: the key signs without asking again.
        return try await Task.detached(priority: .userInitiated) {
            let key = try SecureEnclave.P256.Signing.PrivateKey(dataRepresentation: stored, authenticationContext: context)
            return try key.signature(for: message).rawRepresentation
        }.value
        #endif
    }

    /// "Face ID", "Touch ID", or the passcode on an iPhone with neither, and its symbol.
    static let method: (name: String, symbol: String) = {
        let context = LAContext()
        _ = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        switch context.biometryType {
        case .faceID: return ("Face ID", "faceid")
        case .touchID: return ("Touch ID", "touchid")
        case .opticID: return ("Optic ID", "opticid")
        default: return (String(localized: "パスコード"), "lock")
        }
    }()
}

/// HTTPS to the relay: TLS 1.3, no redirects, cookies, cache or stored
/// credentials; the token in its header to the relay's own address alone.
final class ClaudeConnection: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    private var session: URLSession!

    override init() {
        super.init()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.tlsMinimumSupportedProtocolVersion = .TLSv13
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        configuration.waitsForConnectivity = false
        // Anthropic's stream sends a ping while Claude thinks: two minutes
        // of silence is a lost connection.
        configuration.timeoutIntervalForRequest = 120
        configuration.timeoutIntervalForResource = 30 * 60
        session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }

    /// A redirect is refused: the token goes to the relay's address alone.
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest) async -> URLRequest? { nil }

    private func request(_ server: URL, _ method: String, _ path: String, body: [String: Any]?,
                         token: String?, timeout: TimeInterval) throws -> URLRequest {
        guard var components = URLComponents(url: server, resolvingAgainstBaseURL: false) else { throw ClaudeLinkError.badServer }
        components.path = path
        guard let url = components.url else { throw ClaudeLinkError.badServer }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        request.httpMethod = method
        if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        return request
    }

    /// One request and its JSON answer, whatever its status.
    func call(_ server: URL, _ method: String, _ path: String, body: [String: Any]? = nil,
              token: String? = nil) async throws -> (status: Int, json: [String: Any]) {
        let request = try request(server, method, path, body: body, token: token, timeout: 20)
        do {
            let (data, response) = try await session.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            return (status, (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        } catch {
            throw Self.mapped(error, streaming: false)
        }
    }

    /// A reply as the relay streams it, a line at a time, until `onLine`
    /// says it ended. Cancelling the task closes the connection, which
    /// the relay passes on: Anthropic stops writing too.
    func stream(_ server: URL, _ path: String, body: [String: Any], token: String,
                onLine: (String) async throws -> Bool) async throws {
        let request = try request(server, "POST", path, body: body, token: token, timeout: 120)
        let bytes: URLSession.AsyncBytes
        let response: URLResponse
        do { (bytes, response) = try await session.bytes(for: request) } catch { throw Self.mapped(error, streaming: false) }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else {
            var data = Data()
            do {
                for try await byte in bytes {
                    data.append(byte)
                    if data.count > 16 * 1024 { break }
                }
            } catch { throw Self.mapped(error, streaming: false) }
            throw ClaudeLinkError.from(status: status, json: (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
        }
        do {
            for try await line in bytes.lines {
                if try await onLine(line) { return }
            }
        } catch let error as ClaudeLinkError {
            throw error
        } catch {
            throw Self.mapped(error, streaming: true)
        }
        // The stream ended without message_stop: the connection went away.
        throw ClaudeLinkError.lost
    }

    /// A file a reply made (GET /v1/files/:id/content), saved under its
    /// own name in a folder of its own in this app's temporary files.
    func download(_ server: URL, _ path: String, token: String, as name: String) async throws -> URL {
        let request = try request(server, "GET", path, body: nil, token: token, timeout: 60)
        let (location, response): (URL, URLResponse)
        do { (location, response) = try await session.download(for: request) } catch { throw Self.mapped(error, streaming: false) }
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 else {
            let json = (try? JSONSerialization.jsonObject(with: Data(contentsOf: location))) as? [String: Any] ?? [:]
            try? FileManager.default.removeItem(at: location)
            if status == 404 { throw ClaudeLinkError.fileGone }
            throw ClaudeLinkError.from(status: status, json: json)
        }
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("ClaudeFiles/" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let destination = folder.appendingPathComponent(name)
        try FileManager.default.moveItem(at: location, to: destination)
        return destination
    }

    /// Lets a kept reply's connection go and come again (the app back from
    /// the background): set while one is read.
    final class Renewal: @unchecked Sendable {
        private let lock = NSLock()
        private var action: (() -> Void)?
        func set(_ action: (() -> Void)?) { lock.withLock { self.action = action } }
        func fire() { lock.withLock { action }?() }
    }

    /// What one connection of a kept reply came to.
    private final class Attempt: @unchecked Sendable {
        var received = 0
        var fresh = false
        var renewed = false
        var heardAnything = false
    }

    /// A reply the relay keeps (/v1/replies/:key, 1.1.0 (260)): asked with
    /// POST, it goes on at the relay when this connection drops (iOS
    /// suspending the app, a lost network). It is then read again with GET
    /// from its first byte, the bytes already read passed over, and the
    /// lines go on as if nothing happened. `renewal` swaps the connection
    /// for a new one the same way. Four drops in a row with nothing new
    /// between them, and it is over (as the web's readEvents).
    func streamKept(_ server: URL, key: String, body: [String: Any], token: String, renewal: Renewal,
                    onReconnect: @escaping (Bool) async -> Void, onLine: @escaping (String) async throws -> Bool) async throws {
        let path = "/v1/replies/" + key
        var received = 0
        var asked = false
        var fruitless = 0
        var waits = 0
        while true {
            try Task.checkCancellation()
            let attempt = Attempt()
            attempt.received = received
            let first = !asked
            let request = try self.request(server, first ? "POST" : "GET", path, body: first ? body : nil, token: token, timeout: 120)
            let reading = Task { () async throws -> Bool in
                let (bytes, response) = try await self.session.bytes(for: request)
                let status = (response as? HTTPURLResponse)?.statusCode ?? 0
                guard status == 200 else {
                    var data = Data()
                    for try await byte in bytes {
                        data.append(byte)
                        if data.count > 16 * 1024 { break }
                    }
                    throw KeptRefusal(status: status, json: (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:])
                }
                // Counted a whole line at a time, so a connection let go in
                // the middle of one reads it again whole.
                var skip = attempt.received
                var position = attempt.received
                var line: [UInt8] = []
                for try await byte in bytes {
                    if skip > 0 { skip -= 1; continue }
                    position += 1
                    attempt.heardAnything = true
                    guard byte == 0x0A else { line.append(byte); continue }
                    if line.last == 0x0D { line.removeLast() }
                    let text = String(decoding: line, as: UTF8.self)
                    line.removeAll(keepingCapacity: true)
                    attempt.received = position
                    attempt.fresh = true
                    do {
                        if try await onLine(text) { return true }
                    } catch {
                        throw LineFailure(error: error)
                    }
                    #if POCKET_PREVIEW
                    // The claude UI check: the first kept reply's connection
                    // goes after its second piece of text, as iOS's would.
                    if first, text.contains("text_delta"), Self.dropsOnce() { throw URLError(.networkConnectionLost) }
                    #endif
                }
                return false
            }
            renewal.set { attempt.renewed = true; reading.cancel() }
            defer { renewal.set(nil) }
            do {
                let ended = try await withTaskCancellationHandler { try await reading.value } onCancel: { reading.cancel() }
                received = attempt.received
                asked = true
                if ended { return }
                // The stream ended without message_stop: as a dropped connection.
                throw ClaudeLinkError.lost
            } catch {
                received = attempt.received
                if Task.isCancelled { throw CancellationError() }
                // What the reply itself said (refused, overloaded…) ends it.
                if let failure = error as? LineFailure { throw failure.error }
                if let refusal = error as? KeptRefusal {
                    // The question itself was refused (too large, unavailable…): nothing was kept.
                    if first { throw ClaudeLinkError.from(status: refusal.status, json: refusal.json) }
                    // Not begun at Anthropic yet (409), or busy: wait and ask again.
                    if refusal.status == 409 || refusal.status == 429 || refusal.status >= 500 {
                        waits += 1
                        guard waits <= 6 else { throw ClaudeLinkError.lost }
                        await onReconnect(true)
                        try await Task.sleep(for: .seconds(min(pow(2, Double(waits - 1)), 8)))
                        continue
                    }
                    // Gone at the relay: what came stays, as for any broken reply.
                    throw attempt.heardAnything || received > 0 ? ClaudeLinkError.lost : ClaudeLinkError.unreachable
                }
                // A POST that got no answer at all may still have reached
                // the relay: from now on the reply is looked for there.
                asked = true
                if attempt.renewed { continue }
                fruitless = attempt.fresh ? 0 : fruitless + 1
                guard fruitless < 4 else { throw received > 0 ? ClaudeLinkError.lost : ClaudeLinkError.unreachable }
                await onReconnect(true)
                try await Task.sleep(for: .seconds(min(pow(2, Double(fruitless)), 8)))
            }
        }
    }

    #if POCKET_PREVIEW
    private static let dropLock = NSLock()
    nonisolated(unsafe) private static var dropTexts = ProcessInfo.processInfo.arguments.contains("--claude-drop-once") ? 2 : 0
    /// Counts the kept reply's pieces of text; true once, at the second.
    private static func dropsOnce() -> Bool {
        dropLock.withLock {
            guard dropTexts > 0 else { return false }
            dropTexts -= 1
            return dropTexts == 0
        }
    }
    #endif

    /// An error from reading a line: the reply's own end, never a drop.
    private struct LineFailure: Error { let error: Error }

    /// The relay's answer to a kept reply's request, other than 200.
    private struct KeptRefusal: Error {
        let status: Int
        let json: [String: Any]
    }

    /// Forgets a kept reply at the relay: read whole, or stopped (Anthropic stops too).
    func forget(_ server: URL, key: String, token: String) async {
        _ = try? await call(server, "DELETE", "/v1/replies/" + key, token: token)
    }

    private static func mapped(_ error: Error, streaming: Bool) -> Error {
        if error is CancellationError || Task.isCancelled { return CancellationError() }
        if (error as NSError).domain == NSURLErrorDomain, (error as NSError).code == NSURLErrorCancelled { return CancellationError() }
        return streaming ? ClaudeLinkError.lost : ClaudeLinkError.unreachable
    }
}

/// The relay as the developer manages it (GET /admin/state).
struct ClaudeAdminState: Equatable {
    struct Person: Equatable, Identifiable {
        var id: String
        var name: String
        var isDeveloper: Bool
        var active: Bool
        var lastUsed: Date?
    }
    struct OpenInvite: Equatable, Identifiable {
        var id: String
        var name: String
        var isDeveloper: Bool
        var expires: Date
    }
    var people: [Person]
    var invites: [OpenInvite]
    var friendsEnabled: Bool
    var paused: ClaudeUnavailable?
    var configured: Bool
    var modelName: String

    init(_ json: [String: Any]) {
        func date(_ value: Any?) -> Date? { (value as? NSNumber).map { Date(timeIntervalSince1970: $0.doubleValue / 1000) } }
        people = ((json["users"] as? [[String: Any]]) ?? []).compactMap { user in
            guard let id = user["id"] as? String else { return nil }
            return Person(id: id, name: user["name"] as? String ?? "", isDeveloper: user["role"] as? String == "developer",
                          active: user["status"] as? String != "revoked", lastUsed: date(user["lastUsedAt"]))
        }
        invites = ((json["invites"] as? [[String: Any]]) ?? []).compactMap { invite in
            guard let id = invite["id"] as? String, let expires = date(invite["expiresAt"]) else { return nil }
            return OpenInvite(id: id, name: invite["name"] as? String ?? "", isDeveloper: invite["role"] as? String == "developer",
                              expires: expires)
        }
        let settings = json["settings"] as? [String: Any]
        friendsEnabled = settings?["friendsEnabled"] as? Bool ?? false
        switch settings?["paused"] as? String {
        case "billing": paused = .pausedBilling
        case "limit": paused = .pausedLimit
        default: paused = nil
        }
        configured = json["configured"] as? Bool ?? false
        modelName = ClaudeLinkStore.modelName(json["model"] as? String ?? "")
    }
}

/// This iPhone's registration, whether Claude answers now, and the
/// developer's management, for the views and both ChatStores.
@MainActor final class ClaudeLinkStore: ObservableObject {
    static let shared = ClaudeLinkStore()

    enum State: Equatable {
        /// Not registered.
        case none
        case checking
        case ready
        case unavailable(ClaudeUnavailable)
        case revoked
        /// The relay doesn't know this iPhone any more.
        case removed
        case unreachable
    }

    @Published private(set) var account: ClaudeAccount?
    @Published private(set) var state: State = .none
    /// The state before the check now running: what `problem` says stays
    /// while the relay is asked again (1.1.0 (263)). Until then the page's
    /// explanation went away for the length of every check and came back
    /// after it (UI review, 2026-11-11).
    private var held: State = .ready
    /// 登録を解除 is running (up to the connection's own timeout when the
    /// relay can't be reached): the page's buttons wait, and it can't be
    /// started twice.
    @Published private(set) var leaving = false
    /// The models the relay offers and their levels, as it last said
    /// (this version's own list until it answers): the model menu and the
    /// chat's model settings offer these alone.
    @Published private(set) var models: [ClaudeModel] = ClaudeModel.builtIn
    /// The relay's model for a chat when the person has chosen none.
    @Published private(set) var defaultModel: String = ClaudeModel.opus.id
    /// The developer's admin key is on this iPhone.
    @Published private(set) var hasAdminKey = false
    /// The Face ID key the relay tied to this registration is on this iPhone (1.1.0 (262)).
    @Published private(set) var hasDeviceKey = false
    /// The relay's admin token after Face ID, and when it lapses (15 minutes; in memory only).
    @Published private(set) var adminUntil: Date?
    private var adminToken: String?
    private var unlocking: Task<String, Error>?
    /// An invite opened from its link, waiting for the person's yes.
    @Published var pendingInvite: ClaudeInvite?
    /// The estimate of the credit left, when the developer entered the
    /// balance (and, for a friend, lets friends see it); nil otherwise.
    @Published private(set) var credit: ClaudeCredit?
    /// What one request may carry of photos and PDFs, in bytes (the
    /// relay's ATTACHMENT_MB, 3 MB of base64 on the free plan).
    @Published private(set) var attachmentBytes = ClaudeLinkStore.defaultAttachmentBytes
    /// Whether the relay offers web search and file creation (an older one doesn't).
    @Published private(set) var offersWebSearch = false
    @Published private(set) var offersFiles = false
    /// What the reply being read is doing while it writes nothing (running
    /// code, writing a file, reading a page, connecting again), for the
    /// chat's line under it (ClaudeActivityLine, 1.1.0 (263)); nil while it
    /// writes, and with no reply. Until then only developers were told, and
    /// the reply stood still for seconds (UI review, 2026-11-11).
    @Published private(set) var working: ClaudeActivity?
    /// Whether the relay keeps a reply to be read again (/v1/replies).
    private(set) var resumable = false
    private let connection = ClaudeConnection()
    private var checking: Task<Void, Never>?
    /// The reply being read from the relay, to renew its connection when the app comes back.
    private let renewal = ClaudeConnection.Renewal()
    private var backgroundAt: Date?
    private var lifecycle: [NSObjectProtocol] = []

    nonisolated static let defaultAttachmentBytes = 3 * 1024 * 1024 * 3 / 4
    /// "2.3 MB": what one request carries, for the composer's errors.
    nonisolated static var attachmentLabel: String {
        ByteCountFormatter.string(fromByteCount: Int64(defaultAttachmentBytes), countStyle: .file)
    }

    /// Plain http to this Mac for the UI preview's checks; https otherwise.
    nonisolated static var allowsLocal: Bool {
        #if POCKET_PREVIEW
        true
        #else
        false
        #endif
    }

    private init() {
        #if POCKET_PREVIEW
        // The claude UI check starts with nothing registered.
        if ProcessInfo.processInfo.arguments.contains("--claude-reset") {
            ClaudeKeychain.deleteAccount()
            ClaudeKeychain.deleteAdminKey()
            ClaudeKeychain.deleteDeviceKey()
            for key in UserDefaults.standard.dictionaryRepresentation().keys where key.hasPrefix("claude.") {
                UserDefaults.standard.removeObject(forKey: key)
            }
        }
        #endif
        account = ClaudeKeychain.account()
        hasAdminKey = ClaudeKeychain.adminKey() != nil
        hasDeviceKey = ClaudeKeychain.deviceKey() != nil
        if account != nil { state = .checking }
        // A kept reply's connection may have died quietly while iOS held
        // the app: back after a few seconds away, a new one (as the web).
        let center = NotificationCenter.default
        lifecycle = [
            center.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.backgroundAt = Date() }
            },
            center.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated {
                    guard let self, let away = self.backgroundAt else { return }
                    self.backgroundAt = nil
                    if Date().timeIntervalSince(away) >= 3 { self.renewal.fire() }
                }
            },
        ]
    }

    /// The developer (who may set the credit's balance) on this iPhone.
    var isDeveloper: Bool { account?.role == "developer" }

    /// This iPhone may manage the relay: with the admin key, or with Face ID.
    var canManage: Bool { hasAdminKey || (isDeveloper && hasDeviceKey) }

    /// Managing now asks Face ID first: no admin key, and no admin token still good.
    var needsUnlock: Bool {
        guard !hasAdminKey, isDeveloper, hasDeviceKey else { return false }
        return adminToken == nil || (adminUntil ?? .distantPast) <= Date()
    }

    var isRegistered: Bool { account != nil }
    var isReady: Bool { state == .ready }

    nonisolated static func modelName(_ model: String) -> String {
        ClaudeModel.forChat(model, offered: ClaudeModel.builtIn)?.name ?? (model.isEmpty ? "Claude" : model)
    }

    // MARK: The model and level a chat uses

    /// The last model chosen, and each model's last level: on this iPhone
    /// only, as a phone model's settings are.
    private static let chosenModelKey = "claude.model"
    private static func effortKey(_ model: String) -> String { "claude.effort.\(model)" }

    /// A chat's model and its levels: one the relay offers, or a former one
    /// (Claude Fable 5.1 since 2026-11-10), which a chat begun with it keeps.
    func model(_ id: String) -> ClaudeModel? { ClaudeModel.forChat(id, offered: models) }

    /// A new chat's Claude: `model` (the model menu's choice), or the one
    /// chosen last (the one that took its place, for a former model), or
    /// the relay's; at the level last chosen for it, or its default.
    func target(for model: ClaudeModel? = nil) -> ClaudeChatTarget {
        let defaults = UserDefaults.standard
        let last = defaults.string(forKey: Self.chosenModelKey)
        let chosen = model ?? last.flatMap { ClaudeModel.forNewChat($0, offered: models) }
            ?? ClaudeModel.forNewChat(defaultModel, offered: models) ?? models.first ?? .opus
        // A former model's level goes on with the one that took its place.
        let formerLevel = last.flatMap { id in ClaudeModel.former.first { $0.model.id == id && $0.successor == chosen.id } }
            .flatMap { defaults.string(forKey: Self.effortKey($0.model.id)) }
        let effort = (defaults.string(forKey: Self.effortKey(chosen.id)) ?? formerLevel).flatMap(ClaudeEffort.init(rawValue:))
        return ClaudeChatTarget(chosen, effort: effort)
    }

    /// The person's choice, for the next new chat with Claude.
    func remember(_ target: ClaudeChatTarget) {
        UserDefaults.standard.set(target.model, forKey: Self.chosenModelKey)
        if let effort = target.effort { UserDefaults.standard.set(effort.rawValue, forKey: Self.effortKey(target.model)) }
    }

    /// ウェブ検索 and ファイル作成 as the person last left them in a Claude
    /// chat (1.1.0 (260)): a new Claude chat starts so.
    private static let webSearchKey = "claude.tools.webSearch"
    private static let filesKey = "claude.tools.files"

    func rememberTools(_ thread: ChatThread) {
        UserDefaults.standard.set(thread.webSearch == true, forKey: Self.webSearchKey)
        UserDefaults.standard.set(thread.makesFiles == true, forKey: Self.filesKey)
    }

    func applyLastTools(to thread: inout ChatThread) {
        thread.webSearch = UserDefaults.standard.bool(forKey: Self.webSearchKey) ? true : nil
        thread.makesFiles = UserDefaults.standard.bool(forKey: Self.filesKey) ? true : nil
    }

    /// Whether the relay offers this model at this level (nil: its default).
    func supports(_ target: ClaudeChatTarget) -> Bool {
        guard let model = self.model(target.model) else { return false }
        return target.effort.map { model.efforts.contains($0) } ?? true
    }

    private func server() throws -> (URL, ClaudeAccount) {
        guard let account else { throw ClaudeLinkError.notRegistered }
        guard let url = ClaudeLink.server(account.server, allowsLocal: Self.allowsLocal) else { throw ClaudeLinkError.badServer }
        return (url, account)
    }

    // MARK: Whether Claude answers

    /// Asks the relay whether Claude answers this iPhone now; nothing
    /// without a registration. Called as the app comes back and the page opens.
    func refresh() {
        guard account != nil, checking == nil else { return }
        if state != .checking { held = state }
        state = .checking
        checking = Task {
            await check()
            checking = nil
        }
    }

    private func check() async {
        guard let place = try? server() else { state = .none; return }
        let (url, account) = place
        do {
            let (status, json) = try await connection.call(url, "GET", "/v1/status", token: account.token)
            guard self.account?.token == account.token else { return }
            switch status {
            case 200:
                // An older relay sends no list: this version's own stays.
                if let offered = ClaudeModel.catalog(json["models"]), !offered.isEmpty, offered != models { models = offered }
                if let model = json["model"] as? String, !model.isEmpty, model != defaultModel { defaultModel = model }
                let credit = ClaudeCredit(json["credit"])
                if credit != self.credit { self.credit = credit }
                let bytes = ((json["attachments"] as? [String: Any])?["bytes"] as? NSNumber)?.intValue ?? Self.defaultAttachmentBytes
                if bytes != attachmentBytes { attachmentBytes = bytes }
                let tools = json["tools"] as? [String: Any]
                if (tools?["webSearch"] as? Bool == true) != offersWebSearch { offersWebSearch = tools?["webSearch"] as? Bool == true }
                if (tools?["files"] as? Bool == true) != offersFiles { offersFiles = tools?["files"] as? Bool == true }
                resumable = json["resumable"] as? Bool == true
                if json["available"] as? Bool == true {
                    state = .ready
                } else {
                    state = .unavailable(ClaudeUnavailable(rawValue: json["reason"] as? String ?? "") ?? .notConfigured)
                }
            case 401: state = .removed
            case 403: state = .revoked
            default: state = .unreachable
            }
        } catch {
            if self.account?.token == account.token { state = .unreachable }
        }
    }

    /// What the chat says when Claude can't answer now; nil when it can.
    /// While it is being checked again, what the last check found stays
    /// (nil on the first: sending says why, if it fails).
    var problem: String? {
        switch state == .checking ? held : state {
        case .none: return ClaudeLinkError.notRegistered.localizedDescription
        case .unavailable(let reason): return reason.message
        case .revoked: return ClaudeLinkError.revoked.localizedDescription
        case .removed: return ClaudeLinkError.removed.localizedDescription
        case .unreachable: return ClaudeLinkError.unreachable.localizedDescription
        case .ready, .checking: return nil
        }
    }

    // MARK: Registering

    /// An invite's code for this iPhone's access token, kept in the keychain.
    /// A Face ID key goes with it: the relay ties it to the person when
    /// the invite is a developer's (1.1.0 (262)), and this iPhone keeps it then.
    func redeem(_ invite: ClaudeInvite) async throws {
        let made = ClaudeDeviceKey.make()
        var body: [String: Any] = ["code": invite.code]
        if let made { body["deviceKey"] = PCLink.base64URL(made.publicKey) }
        let (status, json) = try await connection.call(invite.server, "POST", "/v1/redeem", body: body)
        guard status == 200, let token = json["token"] as? String else { throw ClaudeLinkError.from(status: status, json: json) }
        // Registering again replaces the registration before: the relay forgets it too.
        if account != nil { await leaveRelay() }
        let registered = ClaudeAccount(server: invite.server.absoluteString, token: token,
                                       name: json["name"] as? String ?? "", role: json["role"] as? String ?? "friend")
        guard ClaudeKeychain.save(registered) else { throw ClaudeLinkError.notSaved }
        endAdmin()
        ClaudeKeychain.deleteDeviceKey()
        if let made, json["deviceAdmin"] as? Bool == true { _ = ClaudeKeychain.saveDeviceKey(made.stored) }
        hasDeviceKey = ClaudeKeychain.deviceKey() != nil
        account = registered
        // The invite a link opened stays until its sheet has said
        // 「登録しました」 (the sheet clears it); another one is void now.
        if pendingInvite != invite { pendingInvite = nil }
        held = .ready
        state = .checking
        await check()
    }

    /// The developer's own registration: an invite made with the admin
    /// key, redeemed at once; the key is kept to manage the relay.
    func registerAsDeveloper(server text: String, adminKey: String) async throws {
        guard let server = ClaudeLink.server(text, allowsLocal: Self.allowsLocal) else { throw ClaudeLinkError.badServer }
        let key = adminKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let (status, json) = try await connection.call(server, "POST", "/admin/invites",
                                                       body: ["name": String(localized: "開発者"), "role": "developer"], token: key)
        guard status == 200, let raw = json["code"] as? String, let code = ClaudeLink.code(raw) else {
            throw status == 401 ? ClaudeLinkError.adminKey : ClaudeLinkError.from(status: status, json: json)
        }
        guard ClaudeKeychain.saveAdminKey(key) else { throw ClaudeLinkError.notSaved }
        hasAdminKey = true
        try await redeem(ClaudeInvite(server: server, code: code))
    }

    /// 登録を解除: the relay deletes this iPhone's registration (if it can
    /// be reached), and this iPhone forgets it and the admin key. The
    /// chats with Claude stay.
    func leave() async {
        guard !leaving else { return }
        leaving = true
        defer { leaving = false }
        await leaveRelay()
        ClaudeKeychain.deleteAccount()
        ClaudeKeychain.deleteAdminKey()
        ClaudeKeychain.deleteDeviceKey()
        endAdmin()
        account = nil
        hasAdminKey = false
        hasDeviceKey = false
        credit = nil
        state = .none
    }

    private func leaveRelay() async {
        guard let place = try? server() else { return }
        let (url, account) = place
        _ = try? await connection.call(url, "POST", "/v1/leave", token: account.token)
    }

    // MARK: A reply

    enum ReplyProgress: Equatable {
        /// Claude thinks before it answers (its thinking is not shown).
        case thinking
        /// Still working, nothing new to show.
        case alive
        /// Searching, reading a page, writing a file or running code (1.1.0 (260)).
        case working(ClaudeActivity)
        /// The connection went; the relay kept the reply, and it is read again.
        case reconnecting
    }

    /// The tools a reply may use (1.1.0 (260)), each only while the chat's
    /// switch is on, and the code container its files are in.
    struct Tools: Equatable {
        var webSearch = false
        var files = false
        var container: String?

        var json: [String: Any]? {
            guard webSearch || files else { return nil }
            var object: [String: Any] = ["webSearch": webSearch, "files": files]
            if files, let container { object["container"] = container }
            return object
        }
    }

    /// The reply's reader, shared by the stream's lines, and what `working` was last told.
    private final class ReaderBox: @unchecked Sendable {
        var reader = ClaudeReplyReader()
        var told: ClaudeActivity?
    }

    private func note(working activity: ClaudeActivity?) {
        if working != activity { working = activity }
    }

    /// One reply from Claude, its text streamed to `onText` and what it
    /// searched, made and how it ended to `onUpdate`: from the chat's model
    /// at its level, both named in the request (超高 goes as "xhigh").
    /// `messages`: the turns as the relay takes them (ClaudeRequest). Kept
    /// at the relay where it can be (/v1/replies), so a dropped connection
    /// (the app in the background) reads it again. Throws ClaudeLinkError,
    /// or CancellationError when stopped here.
    @discardableResult
    func reply(messages: [[String: Any]], target: ClaudeChatTarget, tools: Tools = Tools(),
               onProgress: @escaping (ReplyProgress) async -> Void,
               onText: @escaping (String) async -> Void,
               onUpdate: @escaping (ClaudeReplyReader) async -> Void = { _ in }) async throws -> ClaudeReplyReader {
        let (url, account) = try server()
        guard supports(target), let model = self.model(target.model) else { throw ClaudeLinkError.unsupportedChoice }
        // Always named, the model's default too (a chat from before levels).
        var body: [String: Any] = ["messages": messages, "model": model.id, "effort": (target.effort ?? model.defaultEffort).rawValue]
        if let tools = tools.json { body["tools"] = tools }
        let box = ReaderBox()
        note(working: nil)
        defer { note(working: nil) }
        let onLine: (String) async throws -> Bool = { [weak self] line in
            guard let event = ClaudeStreamEvent(line: line) else { return false }
            let before = box.reader.activity
            let added = box.reader.read(event)
            // The chat's line follows the reader: a tool's work, nothing
            // once text comes again (and after a new connection, whatever
            // the reply is doing now).
            if box.reader.activity != box.told {
                box.told = box.reader.activity
                await self?.note(working: box.told)
            }
            switch event {
            case .refused: throw ClaudeLinkError.refused
            case .done: return true
            case .failed(let type):
                switch type {
                case "overloaded_error": throw ClaudeLinkError.overloaded
                case "rate_limit_error": throw ClaudeLinkError.rateLimited
                default: throw ClaudeLinkError.lost
                }
            case .thinking: await onProgress(.thinking)
            case .text, .textStart, .alive: break
            default: await onUpdate(box.reader)
            }
            if let added {
                await onText(added)
            } else if let activity = box.reader.activity, activity != before {
                await onProgress(.working(activity))
            } else if event != .thinking {
                await onProgress(.alive)
            }
            return false
        }
        do {
            if resumable {
                let key = ClaudeReplyKey.make()
                do {
                    try await connection.streamKept(url, key: key, body: body, token: account.token, renewal: renewal,
                                                    onReconnect: { [weak self] _ in
                                                        box.told = .reconnecting
                                                        await self?.note(working: .reconnecting)
                                                        await onProgress(.reconnecting)
                                                    }, onLine: onLine)
                } catch {
                    // Stopped, or gone for good: the relay stops it at Anthropic and forgets it.
                    forget(url, key: key, token: account.token)
                    throw error
                }
                forget(url, key: key, token: account.token)
            } else {
                try await connection.stream(url, "/v1/messages", body: body, token: account.token, onLine: onLine)
            }
            if state != .ready { state = .ready }
        } catch let error as ClaudeLinkError {
            switch error {
            case .unavailable(let reason): state = .unavailable(reason)
            case .revoked: state = .revoked
            case .removed: state = .removed
            case .unreachable: state = .unreachable
            default: break
            }
            throw error
        }
        // A reply cost something: the estimate of what is left changed.
        if credit != nil { refresh() }
        return box.reader
    }

    /// The relay lets a kept reply go: never waited for, and not stopped with the reply's task.
    private func forget(_ url: URL, key: String, token: String) {
        let connection = connection
        Task.detached { await connection.forget(url, key: key, token: token) }
    }

    // MARK: Files a reply made (1.1.0 (260))

    /// A made file's name, kind and size: nil while the relay can't say yet
    /// (it may learn of the file a moment after the reply ends), and
    /// fileGone when it is no longer kept.
    func fileInfo(_ id: String) async throws -> ClaudeMadeFile? {
        let (url, account) = try server()
        guard ClaudeStreamEvent.isOutputID(id) else { throw ClaudeLinkError.fileGone }
        let (status, json) = try await connection.call(url, "GET", "/v1/files/" + id, token: account.token)
        switch status {
        case 200:
            return ClaudeMadeFile(id: id, name: json["filename"] as? String, mimeType: json["mimeType"] as? String,
                                  size: (json["size"] as? NSNumber)?.intValue)
        case 404: return nil
        default: throw ClaudeLinkError.from(status: status, json: json)
        }
    }

    /// The details of a reply's files, as the relay comes to know them: a
    /// few tries, a little longer apart each time (as the web's loadFileInfo).
    func fileDetails(_ ids: [String], madeAt: Date) async -> [ClaudeMadeFile] {
        var found: [ClaudeMadeFile] = []
        for id in ids {
            var file = ClaudeMadeFile(id: id, madeAt: madeAt)
            for attempt in 0..<5 {
                if Task.isCancelled { break }
                if let info = try? await fileInfo(id) {
                    file.name = info.name; file.mimeType = info.mimeType; file.size = info.size
                    break
                }
                try? await Task.sleep(for: .milliseconds(600 * (attempt + 1)))
            }
            found.append(file)
        }
        return found
    }

    /// The file itself, saved under its name in this app's temporary files,
    /// for the share sheet to save or send it. Only this person's own.
    func download(_ file: ClaudeMadeFile) async throws -> URL {
        let (url, account) = try server()
        guard ClaudeStreamEvent.isOutputID(file.id), !file.expired() else { throw ClaudeLinkError.fileGone }
        return try await connection.download(url, "/v1/files/\(file.id)/content", token: account.token,
                                             as: Self.safeFileName(file.name))
    }

    /// A name to save a file under: its last part, nothing the file system would read otherwise.
    nonisolated static func safeFileName(_ raw: String?) -> String {
        let last = (raw ?? "").split(whereSeparator: { $0 == "/" || $0 == "\\" }).last.map(String.init) ?? ""
        let cleaned = String(String.UnicodeScalarView(last.unicodeScalars.filter { !CharacterSet.controlCharacters.contains($0) && $0 != ":" }))
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let short = String(cleaned.suffix(120))
        if short.isEmpty || short == "." || short == ".." { return "file" }
        return short.hasPrefix(".") ? "file" + short : short
    }

    // MARK: The developer's management (the admin key, or Face ID)

    private func admin(_ method: String, _ path: String, body: [String: Any]? = nil) async throws -> [String: Any] {
        let (url, account) = try server()
        if let key = ClaudeKeychain.adminKey() {
            let (status, json) = try await connection.call(url, method, path, body: body, token: key)
            guard status == 200 else { throw status == 401 ? ClaudeLinkError.adminKey : ClaudeLinkError.from(status: status, json: json) }
            return json
        }
        guard account.role == "developer", hasDeviceKey else { throw ClaudeLinkError.adminKey }
        // The admin token lapsed at the relay (15 minutes): Face ID once more, then the same request.
        for attempt in 0..<2 {
            let token = try await adminSession(url, account)
            let (status, json) = try await connection.call(url, method, path, body: body, token: token)
            if status == 200 { return json }
            if status == 401, attempt == 0 { endAdmin(); continue }
            throw ClaudeLinkError.from(status: status, json: json)
        }
        throw ClaudeLinkError.notVerified
    }

    /// The relay's admin token: the one still good, or a new one after
    /// Face ID signs the relay's challenge. One Face ID at a time.
    private func adminSession(_ url: URL, _ account: ClaudeAccount) async throws -> String {
        if let adminToken, let adminUntil, adminUntil > Date().addingTimeInterval(10) { return adminToken }
        if let unlocking { return try await unlocking.value }
        let task = Task { try await self.unlock(url, account) }
        unlocking = task
        defer { unlocking = nil }
        return try await task.value
    }

    private func unlock(_ url: URL, _ account: ClaudeAccount) async throws -> String {
        guard let stored = ClaudeKeychain.deviceKey() else { throw ClaudeLinkError.noDeviceKey }
        let (status, json) = try await connection.call(url, "POST", "/v1/admin-session/options", token: account.token)
        guard status == 200, let id = json["challengeId"] as? String, let challenge = json["challenge"] as? String else {
            throw deviceRefusal(status, json)
        }
        let signature = try await ClaudeDeviceKey.sign(ClaudeLink.adminSigned(challenge), with: stored)
        let (verified, answer) = try await connection.call(url, "POST", "/v1/admin-session",
                                                           body: ["challengeId": id, "signature": PCLink.base64URL(signature)],
                                                           token: account.token)
        guard verified == 200, let token = answer["token"] as? String, let expires = answer["expiresAt"] as? NSNumber else {
            throw deviceRefusal(verified, answer)
        }
        adminToken = token
        adminUntil = Date(timeIntervalSince1970: expires.doubleValue / 1000)
        return token
    }

    /// The relay's no; one that says this iPhone's key is no use there lets the key go.
    private func deviceRefusal(_ status: Int, _ json: [String: Any]) -> ClaudeLinkError {
        let error = ClaudeLinkError.from(status: status, json: json)
        if error == .noDeviceKey {
            ClaudeKeychain.deleteDeviceKey()
            hasDeviceKey = false
            endAdmin()
        }
        return error
    }

    private func endAdmin() {
        adminToken = nil
        adminUntil = nil
    }

    func adminState() async throws -> ClaudeAdminState {
        ClaudeAdminState(try await admin("GET", "/admin/state"))
    }

    /// A friend's invite: the link to send them (https://<relay>/join#CODE).
    func invite(name: String) async throws -> URL {
        let json = try await admin("POST", "/admin/invites", body: ["name": name, "role": "friend"])
        guard let text = json["link"] as? String, let link = URL(string: text) else { throw ClaudeLinkError.badResponse(200) }
        return link
    }

    func setActive(_ person: ClaudeAdminState.Person, _ active: Bool) async throws {
        _ = try await admin("POST", "/admin/users/\(person.id)/\(active ? "restore" : "revoke")")
    }

    func delete(_ person: ClaudeAdminState.Person) async throws {
        _ = try await admin("DELETE", "/admin/users/\(person.id)")
    }

    func cancel(_ invite: ClaudeAdminState.OpenInvite) async throws {
        _ = try await admin("DELETE", "/admin/invites/\(invite.id)")
    }

    func setFriendsEnabled(_ on: Bool) async throws {
        _ = try await admin("POST", "/admin/settings", body: ["friendsEnabled": on])
        await check()
    }

    /// After the credit or the limit was seen to: Claude answers again.
    func resume() async throws {
        _ = try await admin("POST", "/admin/settings", body: ["resume": true])
        await check()
    }

    /// The balance Anthropic's Console shows, in US dollars (1.1.0 (260)):
    /// the estimate counts down from it. nil stops the estimate.
    func setCredit(_ dollars: Double?) async throws {
        let value: Any
        if let dollars { value = (dollars * 100).rounded() / 100 } else { value = NSNull() }
        _ = try await admin("POST", "/admin/settings", body: ["creditUSD": value])
        await check()
    }

    /// Whether friends see the estimate too.
    func setCreditFriends(_ on: Bool) async throws {
        _ = try await admin("POST", "/admin/settings", body: ["creditFriends": on])
        await check()
    }

    /// The admin key typed on this iPhone again (after reinstalling): kept
    /// once the relay accepts it.
    func useAdminKey(_ key: String) async throws {
        let key = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let (url, _) = try server()
        let (status, json) = try await connection.call(url, "GET", "/admin/state", token: key)
        guard status == 200 else { throw status == 401 ? ClaudeLinkError.adminKey : ClaudeLinkError.from(status: status, json: json) }
        guard ClaudeKeychain.saveAdminKey(key) else { throw ClaudeLinkError.notSaved }
        hasAdminKey = true
    }

    func forgetAdminKey() {
        ClaudeKeychain.deleteAdminKey()
        hasAdminKey = false
    }

    /// A new admin key for the relay's ADMIN_TOKEN: 32 random bytes,
    /// base64url (43 characters).
    static func newAdminKey() -> String {
        var bytes = [UInt8](repeating: 0, count: 32)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else {
            return (0..<2).map { _ in UUID().uuidString.replacingOccurrences(of: "-", with: "") }.joined()
        }
        return PCLink.base64URL(Data(bytes))
    }

    /// Copies a secret for pasting into the relay's settings: this device
    /// only (never to Universal Clipboard), and gone after ten minutes.
    static func copySecret(_ text: String) {
        UIPasteboard.general.setItems([[UTType.plainText.identifier: text]],
                                      options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(600)])
    }
}
