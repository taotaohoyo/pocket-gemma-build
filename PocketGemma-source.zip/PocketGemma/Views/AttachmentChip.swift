import SwiftUI
import PocketCore

/// A document waiting in the draft, above the field (1.1.0 (271),
/// fielua-reports Issue #9 「ファイル添付UIのLiquid Glass化」): a small card of
/// Liquid Glass, warmed to the paper with a faint gold, holding a paper
/// document's mark on a pale gold tile, the file's name, and the cross that
/// takes it out. Before it (built as 271, given out in the combined 270)
/// the draft showed a file as its name beside a grey 「doc.text」 on a 130
/// by 64pt grey box, with the photos' white cross on its corner.
///
/// Photos, videos and recordings keep their 64pt cards (AttachmentCard),
/// and a file sent is drawn in its message as before. Only how the draft
/// shows a file changed: reading, checking, keeping and sending it did not.
///
/// The card is a plain view with two buttons in it (open, take out), and the
/// glass is behind them: no glass on the buttons themselves, nothing laid
/// over them, so each answers its own touch. The mark's tile is a fill,
/// not glass: glass inside glass shows as a ring on the phone (1.0.115).
struct DraftFileChip: View {
    let attachment: ChatAttachment
    let onRemove: () -> Void
    @State private var showPreview = false
    @Environment(\.horizontalSizeClass) private var sizeClass

    /// What the draft shows as this card: everything that is not a photo, a
    /// video or a recording, the items AttachmentCard drew by their name
    /// alone before.
    nonisolated static func shows(_ attachment: ChatAttachment) -> Bool {
        attachment.kind != .audio && attachment.thumbnailName == nil
    }

    var body: some View {
        HStack(spacing: 0) {
            Button { showPreview = true } label: {
                HStack(spacing: DraftChip.iconGap) {
                    DraftFileMark()
                    DraftFileName(name: attachment.name, limit: DraftChip.nameLimit(sizeClass))
                }
                .padding(.leading, DraftChip.inset)
                .padding(.trailing, DraftChip.nameGap)
                .frame(height: DraftChip.height)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            // The whole name, also when the card shows it shortened.
            .accessibilityLabel("添付ファイルを開く: \(attachment.name)")
            Button(action: onRemove) {
                Image(systemName: "xmark")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Theme.icon)
                    .frame(width: DraftChip.cross, height: DraftChip.cross)
                    .background(Theme.chipFill, in: Circle())
                    // A 44pt-tall target over the card's end.
                    .frame(width: DraftChip.crossTarget, height: DraftChip.height)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("添付を外す: \(attachment.name)")
        }
        .modifier(DraftChipGlass())
        .attachmentPreviewSheet(attachment, isPresented: $showPreview)
    }
}

/// The card in the place of a document still being read in (1.1.0 (263)'s
/// 「読み込み中の仮の枠」, shaped as the card it becomes): the file's name, a
/// spinner on the mark's tile, and the cross's room kept empty, so the card
/// that takes its place stands where it stood, as wide.
struct DraftFileLoadingChip: View {
    let name: String
    @Environment(\.horizontalSizeClass) private var sizeClass
    var body: some View {
        HStack(spacing: 0) {
            HStack(spacing: DraftChip.iconGap) {
                DraftFileMark(loading: true)
                DraftFileName(name: name, limit: DraftChip.nameLimit(sizeClass)).opacity(0.6)
            }
            .padding(.leading, DraftChip.inset)
            .padding(.trailing, DraftChip.nameGap)
            Color.clear.frame(width: DraftChip.crossTarget)
        }
        .frame(height: DraftChip.height)
        .modifier(DraftChipGlass())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text("添付を読み込んでいます…"))
        .accessibilityValue(Text(verbatim: name))
    }
}

/// The card's measures. 44pt tall, a touch below スタンダード's 52pt bar, so
/// the field stays the larger shape; the mark's tile sits 7pt in, its
/// corners concentric with the card's.
enum DraftChip {
    static let height: CGFloat = 44
    static let inset: CGFloat = 7
    static let tile: CGFloat = height - 2 * inset
    static let radius: CGFloat = 15
    static let tileRadius: CGFloat = radius - inset
    static let iconGap: CGFloat = 8
    static let nameGap: CGFloat = 4
    static let cross: CGFloat = 22
    static let crossTarget: CGFloat = 38
    /// The draft row with only documents in it: the card and 6pt above and
    /// below, for its glass's edge and shadow (82 with a photo in it).
    static let row: CGFloat = height + 12
    static var shape: RoundedRectangle { RoundedRectangle(cornerRadius: radius, style: .continuous) }
    /// The name's widest: 144pt on the phone (「sample-document.pdf」 whole,
    /// a card at most 231pt, under two thirds of the field), 168 in the
    /// iPad's wide field. One width whatever else is
    /// in the draft, the row scrolling past the screen's edge as it did:
    /// a card that narrowed when a second came (and widened when it left)
    /// cut its name anew mid-motion, the old name and the new one crossing
    /// in the frames (UI check, 271), and on the iPad it cut
    /// 「sample-document.pdf」 beside 600pt of empty row.
    static func nameLimit(_ sizeClass: UserInterfaceSizeClass?) -> CGFloat {
        sizeClass == .regular ? 168 : 144
    }
}

/// The card's glass: the system's regular Liquid Glass with the paper's
/// warmth and a little gold in it (Theme.attachmentGlass). Not interactive:
/// the buttons inside answer the touch, the glass does not take it.
private struct DraftChipGlass: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.tint(Theme.attachmentGlass), in: DraftChip.shape)
        } else {
            content.background(.regularMaterial, in: DraftChip.shape)
                .overlay { DraftChip.shape.strokeBorder(Theme.inputBorder.opacity(0.4), lineWidth: 0.5) }
        }
    }
}

/// A paper document (its outline, folded corner and lines: 「doc.text」) in
/// deep honey on a pale gold tile with a light edge along its top.
struct DraftFileMark: View {
    var loading = false
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: DraftChip.tileRadius, style: .continuous)
                .fill(LinearGradient(colors: [Theme.attachmentTileTop, Theme.attachmentTileBottom],
                                     startPoint: .top, endPoint: .bottom))
            RoundedRectangle(cornerRadius: DraftChip.tileRadius, style: .continuous)
                .strokeBorder(LinearGradient(colors: [Theme.attachmentTileEdge, .clear],
                                             startPoint: .top, endPoint: .bottom), lineWidth: 0.75)
            if loading {
                ProgressView().controlSize(.small).tint(Theme.attachmentMark)
            } else {
                Image(systemName: "doc.text")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Theme.attachmentMark)
            }
        }
        .frame(width: DraftChip.tile, height: DraftChip.tile)
        .accessibilityHidden(true)
    }
}

/// The name on one line within `limit`: what does not fit is cut from the
/// middle of the name with 「…」 (as Files cuts it), its start and its end
/// kept, the extension (「.pdf」) with the end, so the kind of file still
/// shows: 「2026年11月…_ver3.txt」. One text, not the name and its
/// extension side by side: cut at its end, the name's 「…」 met the
/// extension's dot (「….pdf」); cut in its middle, it left a space before
/// the extension (UI check, 271).
struct DraftFileName: View {
    let name: String
    let limit: CGFloat
    var body: some View {
        WidthCap(limit: limit) {
            Text(verbatim: name).lineLimit(1).truncationMode(.middle)
        }
        .font(.footnote.weight(.medium))
        .foregroundStyle(Theme.ink)
        .accessibilityHidden(true)
    }
}

/// Offers its content at most `limit` of the width and takes what the
/// content uses: a short name keeps the card short, a long one stops at the
/// limit (a flexible frame would widen every card to its limit).
struct WidthCap: Layout {
    let limit: CGFloat
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let content = subviews.first else { return .zero }
        let width = min(proposal.width ?? limit, limit)
        return content.sizeThatFits(ProposedViewSize(width: width, height: proposal.height))
    }
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: CGPoint(x: bounds.minX, y: bounds.midY), anchor: .leading,
                              proposal: ProposedViewSize(width: bounds.width, height: bounds.height))
    }
}

extension View {
    /// The file opened in Quick Look, closed with the cross every sheet has.
    func attachmentPreviewSheet(_ attachment: ChatAttachment, isPresented: Binding<Bool>) -> some View {
        sheet(isPresented: isPresented) {
            NavigationStack {
                AttachmentPreview(attachment: attachment).ignoresSafeArea(edges: .bottom)
                    .navigationTitle(attachment.name).navigationBarTitleDisplayMode(.inline)
                    // The cross every sheet closes with (「完了」 in words before 1.1.0 (263)).
                    .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("閉じる", systemImage: "xmark", role: .close) { isPresented.wrappedValue = false } } }
            }
        }
    }
}
