import SwiftUI
import PocketCore

/// 「モデルを起動中です…」 (1.1.0 (288), fielua-reports Issue #25): whether
/// a start of a phone model ahead of the question (先行読み込み,
/// ModelPrewarm) is running, for the small line under the chat's model.
/// GemmaService tells ChatStore as each start ahead begins and returns;
/// never for a reply's own start (the reply shows its own stages), a load
/// left to the send, or a chat opened on the engine already loaded. The
/// line shows once a start has run ModelPrewarm.indicatorDelay, so a start
/// over at once shows nothing, and once shown stays at least
/// ModelPrewarm.indicatorMinimum, so it never only blinks.
@MainActor final class ModelStartup: ObservableObject {
    static let shared = ModelStartup()
    /// The model whose start the line names, nil while it shows nothing.
    @Published private(set) var shownModelID: String?
    /// The model starting now, as GemmaService last said.
    private(set) var startingModelID: String?
    private var shownAt: Date?
    private var pending: Task<Void, Never>?

    private init() {}

    /// From GemmaService through ChatStore: `id` began starting, or (nil)
    /// the start returned.
    func note(_ id: String?) {
        startingModelID = id
        pending?.cancel()
        if let id {
            if shownModelID != nil { show(id); return }
            pending = Task { [weak self] in
                do { try await Task.sleep(for: ModelPrewarm.indicatorDelay) } catch { return }
                guard let self, self.startingModelID == id else { return }
                self.show(id)
            }
        } else {
            guard shownModelID != nil else { return }
            let left = ModelPrewarm.indicatorMinimum - .seconds(Date().timeIntervalSince(shownAt ?? .distantPast))
            pending = Task { [weak self] in
                if left > .zero { do { try await Task.sleep(for: left) } catch { return } }
                guard let self, self.startingModelID == nil else { return }
                self.hide()
            }
        }
    }

    private func show(_ id: String) {
        if shownModelID == nil { shownAt = Date() }
        shownModelID = id
        #if POCKET_PREVIEW
        ModelStartupNotes.write("shown \(id)")
        #endif
    }

    private func hide() {
        shownModelID = nil
        shownAt = nil
        #if POCKET_PREVIEW
        ModelStartupNotes.write("hidden")
        #endif
    }
}

/// The line under the chat's model mark: a small spinner and
/// 「モデルを起動中です…」 in the header's secondary ink, on the header's own
/// soft blur, without glass of its own. It is laid over the header, so the
/// header and the conversation keep their size and place whether it shows
/// or not; it takes no touches. `modelID`: the open chat's phone model,
/// nil for a chat that loads nothing here (the PC, Claude, おまかせ). A
/// reply being written shows its own stages instead. It is there only
/// while it shows (VoiceOver reads it then), and fades in and out.
struct ModelStartingLine: View {
    let modelID: String?
    @ObservedObject private var startup = ModelStartup.shared
    @ObservedObject private var pulse = ChatPulse.shared
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        let shown = modelID != nil && startup.shownModelID == modelID && !pulse.isGenerating
        ZStack {
            if shown {
                HStack(spacing: 5) {
                    ProgressView().controlSize(.mini)
                    Text("モデルを起動中です…")
                }
                .font(.caption2.weight(.medium))
                .foregroundStyle(.secondary)
                .fixedSize()
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("モデルを起動中です")
                .accessibilityIdentifier("chat-model-starting")
                // In from just under the model's capsule, out where it is;
                // Reduce Motion fades it only.
                .transition(reduceMotion ? AnyTransition.opacity : AnyTransition.opacity.combined(with: .offset(y: -3)))
            }
        }
        .animation(reduceMotion ? .easeInOut(duration: 0.2) : .smooth(duration: shown ? 0.35 : 0.3), value: shown)
        .allowsHitTesting(false)
    }
}

#if POCKET_PREVIEW
/// The line's moments for the UI check (tmp/model-starting.txt in the
/// preview's container, MODEL-STARTING lines), on the Mac's clock as the
/// test's marks are.
enum ModelStartupNotes {
    static let url = FileManager.default.temporaryDirectory.appendingPathComponent("model-starting.txt")
    static func write(_ event: String) {
        let line = String(format: "%.3f ", Date().timeIntervalSince1970) + event + "\n"
        if let handle = try? FileHandle(forWritingTo: url) {
            handle.seekToEndOfFile(); handle.write(Data(line.utf8)); try? handle.close()
        } else {
            try? Data(line.utf8).write(to: url)
        }
    }
}
#endif
