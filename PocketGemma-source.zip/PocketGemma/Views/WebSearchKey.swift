import Foundation
import Security

/// The person's own Tavily key for web search. It lives only in the
/// keychain, synced through iCloud Keychain (end-to-end encrypted) to the
/// person's other devices; never in the app, its logs or its diagnostics,
/// and never sent anywhere but Tavily.
enum WebSearchKey {
    enum Saved: Equatable {
        /// In the keychain and synced by iCloud Keychain.
        case synced
        /// The keychain refused a synced item (no iCloud Keychain for this
        /// signing), so the key stays on this device.
        case thisDeviceOnly
        case failed
    }

    private static var item: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.web-search",
         kSecAttrAccount as String: "tavily"]
    }

    /// Finds the item whether or not it syncs.
    private static var anyItem: [String: Any] {
        var query = item
        query[kSecAttrSynchronizable as String] = kSecAttrSynchronizableAny
        return query
    }

    static func load() -> String? {
        var query = anyItem
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data, let key = String(data: data, encoding: .utf8), !key.isEmpty else { return nil }
        return key
    }

    /// Whether the saved key syncs through iCloud Keychain; nil without a key.
    static func syncs() -> Bool? {
        var query = anyItem
        query[kSecReturnAttributes as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let attributes = result as? [String: Any] else { return nil }
        return (attributes[kSecAttrSynchronizable as String] as? Bool)
            ?? ((attributes[kSecAttrSynchronizable as String] as? NSNumber)?.boolValue ?? false)
    }

    /// A key is one word; spaces and line breaks around it (from pasting)
    /// are dropped.
    static func cleaned(_ raw: String) -> String? {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return key.isEmpty || key.contains(where: \.isWhitespace) ? nil : key
    }

    /// Replaces any saved key. Synced when the keychain allows it, otherwise
    /// on this device only.
    @discardableResult
    static func save(_ raw: String) -> Saved {
        guard let key = cleaned(raw) else { return .failed }
        delete()
        var entry = item
        entry[kSecValueData as String] = Data(key.utf8)
        entry[kSecAttrSynchronizable as String] = kCFBooleanTrue
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        if SecItemAdd(entry as CFDictionary, nil) == errSecSuccess { return .synced }
        entry[kSecAttrSynchronizable as String] = kCFBooleanFalse
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess ? .thisDeviceOnly : .failed
    }

    /// Removes the key here and, when it synced, on the person's other
    /// devices too.
    static func delete() {
        SecItemDelete(anyItem as CFDictionary)
    }
}

/// Whether a key is saved, for the views: read off the main thread when the
/// app comes forward (another device may have added or removed it) and set
/// at once when the person saves or deletes it here.
@MainActor final class WebSearchKeyState: ObservableObject {
    static let shared = WebSearchKeyState()
    @Published private(set) var isSet = false
    @Published private(set) var syncs = false
    /// A read that finishes after a save or delete here is out of date.
    private var changes = 0

    private init() { refresh() }

    func refresh() {
        let started = changes
        Task.detached(priority: .utility) {
            let synced = WebSearchKey.syncs()
            await MainActor.run {
                guard self.changes == started else { return }
                self.isSet = synced != nil
                self.syncs = synced == true
            }
        }
    }

    @discardableResult
    func save(_ raw: String) -> WebSearchKey.Saved {
        let saved = WebSearchKey.save(raw)
        changes += 1
        isSet = saved != .failed
        syncs = saved == .synced
        return saved
    }

    func delete() {
        WebSearchKey.delete()
        changes += 1
        isSet = false
        syncs = false
    }
}
