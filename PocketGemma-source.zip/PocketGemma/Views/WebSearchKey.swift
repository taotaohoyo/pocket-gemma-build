import Foundation
import Security

/// The person's own Tavily key for web search. It lives only in this
/// device's keychain: not synced, not in backups, never in the app, its
/// logs or its diagnostics. Without it, search uses Wikipedia, which needs
/// no key.
enum WebSearchKey {
    private static var item: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "fielua.web-search",
         kSecAttrAccount as String: "tavily"]
    }

    static func load() -> String? {
        var query = item
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data, let key = String(data: data, encoding: .utf8), !key.isEmpty else { return nil }
        return key
    }

    static var isSet: Bool { load() != nil }

    @discardableResult
    static func save(_ raw: String) -> Bool {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, !key.contains(where: \.isWhitespace) else { return false }
        SecItemDelete(item as CFDictionary)
        var entry = item
        entry[kSecValueData as String] = Data(key.utf8)
        entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(entry as CFDictionary, nil) == errSecSuccess
    }

    static func delete() {
        SecItemDelete(item as CFDictionary)
    }
}
