import SwiftUI

extension View {
    @ViewBuilder func recordChatLayout(_ id: UUID) -> some View {
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--layout-metrics") {
            // Resolve every retained lazy row in one layout pass. Cached global
            // CGRect values can otherwise mix offsets from different scroll frames.
            anchorPreference(key: PreviewBubbleFrames.self, value: .bounds) { [id: $0] }
        } else { self }
        #else
        self
        #endif
    }
}
