import SwiftUI

extension View {
    @ViewBuilder func recordChatLayout(_ id: UUID) -> some View {
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--layout-metrics") {
            background {
                GeometryReader { geometry in
                    Color.clear.preference(key: PreviewBubbleFrames.self,
                        value: [id: geometry.frame(in: .global)])
                }
            }
        } else { self }
        #else
        self
        #endif
    }
}
