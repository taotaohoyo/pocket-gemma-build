import SwiftUI
import UIKit

/// Pulling a conversation up past its end opens a new chat, as in ChatGPT:
/// below the last message a ring fills as the pull grows, turns into a
/// filled button with the compose symbol once it is full, and letting go
/// there starts a new chat. Easing off before that leaves the conversation
/// as it is, and the ring winds back with the content.
@Observable @MainActor final class PullToComposeState {
    /// How far the content is pulled past its end, for a pull a finger began.
    fileprivate(set) var pull: CGFloat = 0
    /// The end of the reading area (above the composer) and of the content,
    /// in the content's own coordinates, where the ring is drawn.
    fileprivate(set) var readingBottom: CGFloat = 0
    fileprivate(set) var contentEnd: CGFloat = 0
    fileprivate(set) var armed = false
}

enum PullToCompose {
    /// The ring begins at this pull and is full at this one (pt), measured
    /// from ChatGPT's screen recording.
    static let start: CGFloat = 30
    static let full: CGFloat = 118
    static func progress(_ pull: CGFloat) -> CGFloat { min(max((pull - start) / (full - start), 0), 1) }
}

private struct PullGeometry: Equatable {
    var pull: CGFloat = 0
    var readingBottom: CGFloat = 0
    var contentEnd: CGFloat = 0
}

@MainActor struct PullToComposeObserver: ViewModifier {
    let state: PullToComposeState
    let enabled: Bool
    let onCompose: () -> Void
    @State private var dragging = false
    /// The pull under way began while a finger moved the list; a flick's
    /// bounce at the end never shows the ring.
    @State private var tracking = false
    @State private var armed = false
    @State private var lastPull: CGFloat = 0
    /// A touch that lands while the list is already past its end must not
    /// count as a pull, or any touch there would open a new chat.
    @State private var blocked = false

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .onScrollGeometryChange(for: PullGeometry.self) { geometry in
                    let pull = geometry.readingBottom - max(geometry.contentSize.height, geometry.containerSize.height)
                    guard pull >= 1 else { return PullGeometry() }
                    return PullGeometry(pull: pull.rounded(), readingBottom: geometry.readingBottom.rounded(),
                                        contentEnd: geometry.contentSize.height.rounded())
                } action: { _, new in follow(new) }
                .onScrollPhaseChange { old, new in
                    let wasDragging = dragging
                    dragging = new == .interacting || new == .tracking
                    if dragging && !wasDragging { blocked = lastPull > PullToCompose.start }
                    if wasDragging && !dragging { release(); blocked = false }
                }
        } else { content }
    }

    private func follow(_ geometry: PullGeometry) {
        lastPull = geometry.pull
        guard geometry.pull > 0 else { reset(); return }
        if !tracking {
            guard dragging, enabled, !blocked else { return }
            tracking = true
        }
        state.pull = geometry.pull
        state.readingBottom = geometry.readingBottom
        state.contentEnd = geometry.contentEnd
        // After the finger lifts the ring only winds back with the content.
        guard dragging else { return }
        #if POCKET_PREVIEW
        if PullToCompose.progress(geometry.pull) >= 0.5 { PullSnapshots.shared.take("half") }
        #endif
        // A little give before it lets go of the full state again.
        let full = armed ? geometry.pull >= PullToCompose.full - 10 : geometry.pull >= PullToCompose.full
        guard full != armed else { return }
        armed = full
        if full { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
        // Scroll updates arrive with animations disabled; the button's pop
        // needs a transaction of its own.
        Task { @MainActor in
            withAnimation(.spring(duration: 0.32, bounce: 0.4)) { state.armed = full }
            #if POCKET_PREVIEW
            if full {
                try? await Task.sleep(for: .milliseconds(350))
                if armed { PullSnapshots.shared.take("armed") }
            }
            #endif
        }
    }

    private func release() {
        guard tracking else { return }
        #if POCKET_PREVIEW
        PullSnapshots.shared.reveal()
        #endif
        if armed && enabled {
            armed = false
            tracking = false
            onCompose()
            Task { @MainActor in
                withAnimation(.easeOut(duration: 0.2)) { state.pull = 0; state.armed = false }
            }
        } else if armed {
            armed = false
            Task { @MainActor in withAnimation(.spring(duration: 0.32)) { state.armed = false } }
        }
    }

    private func reset() {
        tracking = false
        armed = false
        guard state.pull != 0 || state.armed else { return }
        state.pull = 0
        state.armed = false
    }
}

/// Drawn below the end of the content; it rises a third as fast as the
/// content, as in ChatGPT, but never into the last message.
@MainActor struct PullToComposeIndicator: View {
    let state: PullToComposeState
    var body: some View {
        let pull = state.pull
        let progress = PullToCompose.progress(pull)
        let center = max(state.readingBottom - 56 - pull / 3, state.contentEnd + 22)
        VStack(spacing: 3) {
            ZStack {
                Circle().stroke(Theme.accent.opacity(0.16), lineWidth: 3)
                    .frame(width: 31, height: 31)
                Circle().trim(from: 0, to: progress)
                    .stroke(Theme.accent, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .frame(width: 31, height: 31)
                Circle().fill(Theme.accent)
                    .overlay {
                        Image(systemName: "square.and.pencil")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(.white)
                            .offset(y: -1)
                    }
                    .frame(width: 42, height: 42)
                    .scaleEffect(state.armed ? 1 : 0.7)
                    .opacity(state.armed ? 1 : 0)
            }
            .frame(width: 44, height: 44)
            Text("新しいチャット")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(.secondary)
                .fixedSize()
        }
        .opacity(min(max((pull - 24) / 24, 0), 1))
        .frame(maxWidth: .infinity)
        .offset(y: center - 22)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

#if POCKET_PREVIEW
/// `--pull-snapshot`: the screen as the ring half fills and once it is the
/// button, shown after the finger lifts so a UI test can photograph them
/// (XCTest cannot take a screenshot during a drag).
@Observable @MainActor final class PullSnapshots {
    static let shared = PullSnapshots()
    private(set) var images: [UIImage] = []
    private(set) var shown = false
    private var taken: Set<String> = []
    private let enabled = ProcessInfo.processInfo.arguments.contains("--pull-snapshot")

    func take(_ name: String) {
        guard enabled, !taken.contains(name),
              let window = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene })
                .flatMap(\.windows).first(where: \.isKeyWindow) else { return }
        taken.insert(name)
        images.append(UIGraphicsImageRenderer(bounds: window.bounds).image { _ in
            window.drawHierarchy(in: window.bounds, afterScreenUpdates: false)
        })
    }
    func reveal() { if enabled && !images.isEmpty { shown = true } }
    func dismiss() { shown = false; images = []; taken = [] }
}

struct PullSnapshotView: View {
    private var snapshots: PullSnapshots { .shared }
    var body: some View {
        if snapshots.shown {
            HStack(spacing: 6) {
                ForEach(Array(snapshots.images.enumerated()), id: \.offset) { _, image in
                    Image(uiImage: image).resizable().scaledToFit()
                        .border(Color.gray.opacity(0.4))
                }
            }
            .padding(6)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(uiColor: .systemBackground))
            .contentShape(Rectangle())
            .onTapGesture { snapshots.dismiss() }
            .accessibilityElement()
            .accessibilityLabel("pull snapshots \(snapshots.images.count)")
            .accessibilityIdentifier("pull-snapshots")
            .accessibilityAddTraits(.isButton)
        }
    }
}
#endif
