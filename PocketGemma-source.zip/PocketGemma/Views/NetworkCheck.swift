import SwiftUI
import UIKit
import Network
import PocketCore

/// 開発者設定's 配布元への通信の診断 (1.1.0 (241)). On the phone, E2B hardly
/// moved on Wi-Fi and went on over 5G (2026-10-29 06:52 UTC): this takes the
/// network the phone has now apart, step by step as a model download goes
/// through it. What iOS reports (Wi-Fi or cellular, IPv4, IPv6, DNS, a VPN
/// or proxy); the addresses DNS gives for the Hub and its CDN; the Hub's
/// redirect; then the first 8 MB of E2B from the CDN over IPv4 only, over
/// IPv6 only, and through a URLSession like the app's own, with the address,
/// protocol, times and speed of each. It only reads the Hub's public file
/// and keeps nothing. The lines also go to the download record.
@MainActor
final class NetworkCheck: ObservableObject {
    static let shared = NetworkCheck()
    @Published private(set) var isRunning = false
    @Published private(set) var lines: [String] = []
    /// What each transfer asks for, and how long it may take.
    nonisolated static let sampleBytes = 8_000_000
    nonisolated static let timeLimit: TimeInterval = 20

    func run() {
        guard !isRunning else { return }
        isRunning = true
        lines = []
        Task {
            await check()
            isRunning = false
        }
    }

    private func say(_ text: String) {
        lines.append(text)
        DownloadLog.shared.note("通信の診断: " + text)
    }

    private func check() async {
        let path = await Self.currentPath()
        say(Self.describe(path) + "・" + Self.proxyText())
        let file = ModelSpec.e2b.downloadURL
        let hub = file.host ?? "huggingface.co"
        say(Self.dnsText(hub, await Task.detached { Self.resolve(hub) }.value))
        let redirect = await Self.redirect(of: file)
        say(redirect.text)
        guard let location = redirect.location, let cdn = location.host else {
            say("まとめ: 配布元の転送先が分からないため、ここまで")
            return
        }
        say(Self.dnsText(cdn, await Task.detached { Self.resolve(cdn) }.value))
        var speeds: [String] = []
        let families: [(NWProtocolIP.Options.Version, String)] = [(.v4, "IPv4"), (.v6, "IPv6")]
        for (family, name) in families {
            let result = await FamilyFetch(url: location, family: family, label: name).run()
            say(result.text)
            speeds.append("\(name)だけ \(result.speed)")
        }
        let session = await SessionFetch(url: location).run()
        say(session.text)
        speeds.append("アプリと同じ通信 \(session.speed)")
        say("まとめ（\(Self.interfaceName(path))）: " + speeds.joined(separator: "・"))
    }

    // MARK: The network iOS reports

    nonisolated static func currentPath() async -> NWPath {
        await withCheckedContinuation { continuation in
            let monitor = NWPathMonitor()
            let once = Once()
            monitor.pathUpdateHandler = { path in
                guard once.claim() else { return }
                monitor.cancel()
                monitor.pathUpdateHandler = nil
                continuation.resume(returning: path)
            }
            monitor.start(queue: DispatchQueue(label: "app.pocketgemma.network-check.path"))
        }
    }

    nonisolated static func interfaceName(_ path: NWPath) -> String {
        if path.usesInterfaceType(.wifi) { return "Wi-Fi" }
        if path.usesInterfaceType(.cellular) { return "モバイル通信" }
        if path.usesInterfaceType(.wiredEthernet) { return "有線" }
        return path.status == .satisfied ? "その他の経路" : "通信なし"
    }

    /// The path in the download record's words: the interface, IPv4, IPv6,
    /// DNS, 低データモード, and the interfaces' names (utun is a VPN).
    nonisolated static func describe(_ path: NWPath) -> String {
        let status = switch path.status {
        case .satisfied: "接続"
        case .requiresConnection: "接続待ち"
        case .unsatisfied: "未接続"
        @unknown default: "不明"
        }
        var parts = ["経路 \(interfaceName(path))（\(status)）", "IPv4 \(path.supportsIPv4 ? "あり" : "なし")",
                     "IPv6 \(path.supportsIPv6 ? "あり" : "なし")", "DNS \(path.supportsDNS ? "あり" : "なし")"]
        if path.isConstrained { parts.append("低データモード") }
        if path.isExpensive { parts.append("従量の通信") }
        parts.append("インターフェース " + path.availableInterfaces.map(\.name).joined(separator: ","))
        return parts.joined(separator: "・")
    }

    /// A proxy, an automatic proxy setting, or a VPN's interface.
    nonisolated static func proxyText() -> String {
        guard let settings = CFNetworkCopySystemProxySettings()?.takeRetainedValue() as? [String: Any] else { return "プロキシ 不明" }
        let on = { (key: String) in (settings[key] as? NSNumber)?.boolValue == true }
        let scoped = (settings["__SCOPED__"] as? [String: Any])?.keys.sorted() ?? []
        let tunnels = scoped.filter { $0.hasPrefix("utun") || $0.hasPrefix("ipsec") || $0.hasPrefix("ppp") }
        return "プロキシ \(on("HTTPEnable") || on("HTTPSEnable") ? "あり" : "なし")・プロキシの自動設定 \(on("ProxyAutoConfigEnable") ? "あり" : "なし")"
            + "・VPN \(tunnels.isEmpty ? "なし" : tunnels.joined(separator: ","))"
    }

    // MARK: DNS

    struct Addresses: Sendable {
        var v4: [String] = [], v6: [String] = []
        var milliseconds = 0
        var error: String?
    }

    /// What the phone's resolver gives for the host, as a download asks it.
    nonisolated static func resolve(_ host: String) -> Addresses {
        var result = Addresses()
        var hints = addrinfo()
        hints.ai_family = AF_UNSPEC
        hints.ai_socktype = SOCK_STREAM
        var list: UnsafeMutablePointer<addrinfo>?
        let start = Date()
        let status = getaddrinfo(host, "443", &hints, &list)
        result.milliseconds = Int(Date().timeIntervalSince(start) * 1000)
        guard status == 0, let first = list else {
            result.error = String(cString: gai_strerror(status))
            return result
        }
        defer { freeaddrinfo(first) }
        var cursor: UnsafeMutablePointer<addrinfo>? = first
        while let info = cursor {
            var name = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(info.pointee.ai_addr, info.pointee.ai_addrlen, &name, socklen_t(name.count), nil, 0, NI_NUMERICHOST) == 0 {
                let address = name.withUnsafeBufferPointer { String(cString: $0.baseAddress!) }
                if info.pointee.ai_family == AF_INET6 {
                    if !result.v6.contains(address) { result.v6.append(address) }
                } else if !result.v4.contains(address) { result.v4.append(address) }
            }
            cursor = info.pointee.ai_next
        }
        return result
    }

    nonisolated static func dnsText(_ host: String, _ addresses: Addresses) -> String {
        if let error = addresses.error { return "DNS \(host): 失敗（\(error)）\(addresses.milliseconds)ms" }
        let v4 = addresses.v4.prefix(3).joined(separator: ","), v6 = addresses.v6.prefix(3).joined(separator: ",")
        return "DNS \(host) \(addresses.milliseconds)ms・IPv4 \(addresses.v4.count)件\(v4.isEmpty ? "" : "（\(v4)）")"
            + "・IPv6 \(addresses.v6.count)件\(v6.isEmpty ? "" : "（\(v6)）")"
    }

    // MARK: The Hub's redirect

    /// The app's E2B link, one byte of it, without following the redirect:
    /// the Hub's answer and where it sends the download.
    nonisolated static func redirect(of url: URL) async -> (text: String, location: URL?) {
        var request = URLRequest(url: url)
        request.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        request.timeoutInterval = timeLimit
        let collector = RedirectStop()
        let session = URLSession(configuration: .ephemeral)
        defer { session.finishTasksAndInvalidate() }
        let start = Date()
        do {
            let (_, response) = try await session.data(for: request, delegate: collector)
            let http = response as? HTTPURLResponse
            let location = http?.value(forHTTPHeaderField: "Location").flatMap(URL.init(string:))
            let took = Int(Date().timeIntervalSince(start) * 1000)
            let target = location.map { ($0.host ?? "-") + String($0.path.prefix(16)) } ?? "転送なし"
            return ("転送: \(url.host ?? "-") HTTP \(http?.statusCode ?? 0) → \(target) \(took)ms・\(describe(collector.metrics))", location)
        } catch {
            return ("転送: 失敗（\(errorText(error))）・\(describe(collector.metrics))", nil)
        }
    }

    // MARK: Words for URLSession's figures

    nonisolated static func errorText(_ error: Error) -> String {
        let error = error as NSError
        return "\(error.domain) \(error.code)"
    }

    /// The transfer's last connection: its address and IP version, the
    /// protocol, a proxy, cellular, and how long each step took.
    nonisolated static func describe(_ metrics: URLSessionTaskMetrics?) -> String {
        guard let metrics, let transaction = metrics.transactionMetrics.last(where: { $0.resourceFetchType == .networkLoad })
                ?? metrics.transactionMetrics.last else { return "計測なし" }
        var parts: [String] = []
        if let address = transaction.remoteAddress {
            parts.append("相手 \(address)（\(address.contains(":") ? "IPv6" : "IPv4")）")
        }
        parts.append(transaction.networkProtocolName ?? "プロトコル不明")
        if transaction.isProxyConnection { parts.append("プロキシ経由") }
        if transaction.isReusedConnection { parts.append("接続の再利用") }
        if transaction.isCellular { parts.append("モバイル通信") }
        if transaction.isConstrained { parts.append("低データモード") }
        func span(_ from: Date?, _ to: Date?) -> String {
            guard let from, let to else { return "-" }
            return "\(Int(to.timeIntervalSince(from) * 1000))ms"
        }
        parts.append("DNS \(span(transaction.domainLookupStartDate, transaction.domainLookupEndDate))")
        parts.append("接続 \(span(transaction.connectStartDate, transaction.connectEndDate))")
        parts.append("TLS \(span(transaction.secureConnectionStartDate, transaction.secureConnectionEndDate))")
        parts.append("最初の応答 \(span(transaction.requestStartDate, transaction.responseStartDate))")
        return parts.joined(separator: "・")
    }

    /// Every connection of a download, the Hub's and the CDN's, in order.
    nonisolated static func route(_ metrics: URLSessionTaskMetrics) -> String {
        let hops = metrics.transactionMetrics.filter { $0.resourceFetchType == .networkLoad }.map { transaction in
            let address = transaction.remoteAddress.map { "\($0)（\($0.contains(":") ? "IPv6" : "IPv4")）" } ?? "相手不明"
            let status = (transaction.response as? HTTPURLResponse).map { " HTTP \($0.statusCode)" } ?? ""
            return "\(transaction.request.url?.host ?? "-") \(address) \(transaction.networkProtocolName ?? "?")\(status)"
                + (transaction.isProxyConnection ? " プロキシ経由" : "") + (transaction.isCellular ? " モバイル通信" : "")
        }
        return hops.isEmpty ? "通信なし" : hops.joined(separator: " → ")
    }

    nonisolated static func speed(bytes: Int, from start: Date?, to end: Date) -> String {
        guard let start, bytes > 0 else { return "0.0 MB/秒" }
        return String(format: "%.1f MB/秒", Double(bytes) / 1_000_000 / max(end.timeIntervalSince(start), 0.001))
    }
}

private final class Once: @unchecked Sendable {
    private let lock = NSLock()
    private var claimed = false
    func claim() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        if claimed { return false }
        claimed = true
        return true
    }
}

/// Keeps the Hub's redirect from being followed, and its figures.
private final class RedirectStop: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    private(set) var metrics: URLSessionTaskMetrics?
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest) async -> URLRequest? {
        nil
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        self.metrics = metrics
    }
}

struct NetworkCheckResult: Sendable {
    let text: String
    let speed: String
}

/// The first bytes of the file over one IP version only, on a connection of
/// its own (TCP and TLS, HTTP/1.1): an IPv6 route that connects but carries
/// little stands apart from IPv4.
private final class FamilyFetch: @unchecked Sendable {
    private let url: URL
    private let family: NWProtocolIP.Options.Version
    private let label: String
    private let queue = DispatchQueue(label: "app.pocketgemma.network-check.family")
    private var connection: NWConnection?
    private var continuation: CheckedContinuation<NetworkCheckResult, Never>?
    private var started = Date()
    private var ready: Date?
    private var firstByte: Date?
    private var received = 0
    private var statusLine = ""
    private var done = false

    init(url: URL, family: NWProtocolIP.Options.Version, label: String) {
        self.url = url
        self.family = family
        self.label = label
    }

    func run() async -> NetworkCheckResult {
        await withCheckedContinuation { continuation in
            queue.async { self.begin(continuation) }
        }
    }

    private func begin(_ continuation: CheckedContinuation<NetworkCheckResult, Never>) {
        self.continuation = continuation
        guard let host = url.host else { finish("転送先にホストがない"); return }
        let parameters = NWParameters(tls: NWProtocolTLS.Options(), tcp: NWProtocolTCP.Options())
        if let ip = parameters.defaultProtocolStack.internetProtocol as? NWProtocolIP.Options { ip.version = family }
        let connection = NWConnection(host: NWEndpoint.Host(host), port: 443, using: parameters)
        self.connection = connection
        connection.stateUpdateHandler = { state in self.changed(state) }
        started = Date()
        connection.start(queue: queue)
        queue.asyncAfter(deadline: .now() + NetworkCheck.timeLimit) { self.finish("時間切れ") }
    }

    private func changed(_ state: NWConnection.State) {
        switch state {
        case .ready:
            ready = Date()
            send()
        case .waiting(let error): finish("つながらない（\(error)）")
        case .failed(let error): finish("失敗（\(error)）")
        default: break
        }
    }

    private func send() {
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        let target = (components?.percentEncodedPath ?? "/") + (components?.percentEncodedQuery.map { "?" + $0 } ?? "")
        let request = "GET \(target) HTTP/1.1\r\nHost: \(url.host ?? "")\r\nRange: bytes=0-\(NetworkCheck.sampleBytes - 1)\r\n"
            + "User-Agent: Fielua-network-check\r\nAccept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n"
        connection?.send(content: Data(request.utf8), completion: .contentProcessed { error in
            if let error { self.finish("送れない（\(error)）") } else { self.receive() }
        })
    }

    private func receive() {
        connection?.receive(minimumIncompleteLength: 1, maximumLength: 1 << 20) { data, _, isComplete, error in
            if let data, !data.isEmpty {
                if self.firstByte == nil {
                    self.firstByte = Date()
                    self.statusLine = String(decoding: data.prefix(80), as: UTF8.self).components(separatedBy: "\r\n").first ?? ""
                }
                self.received += data.count
            }
            if self.received >= NetworkCheck.sampleBytes { self.finish("完了") }
            else if let error { self.finish("途中で切れた（\(error)）") }
            else if isComplete { self.finish("相手が閉じた") }
            else { self.receive() }
        }
    }

    private func finish(_ how: String) {
        guard !done else { return }
        done = true
        let now = Date()
        let remote = connection?.currentPath?.remoteEndpoint.map { "\($0)" } ?? "-"
        connection?.stateUpdateHandler = nil
        connection?.cancel()
        connection = nil
        let speed = NetworkCheck.speed(bytes: received, from: firstByte, to: now)
        var parts = ["\(label)だけ: \(how)"]
        if let ready { parts.append("接続 \(Int(ready.timeIntervalSince(started) * 1000))ms（TCP＋TLS）") }
        if let ready, let firstByte { parts.append("最初のデータ \(Int(firstByte.timeIntervalSince(ready) * 1000))ms") }
        parts.append(String(format: "受信 %.1fMB", Double(received) / 1_000_000) + "・" + speed)
        if !statusLine.isEmpty { parts.append(statusLine) }
        parts.append("相手 \(remote)")
        continuation?.resume(returning: NetworkCheckResult(text: parts.joined(separator: "・"), speed: speed))
        continuation = nil
    }
}

/// The first bytes of the file through URLSession as the app's own session
/// receives (iOS picks IPv4 or IPv6 and the protocol): which it picked, and
/// how fast.
private final class SessionFetch: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let url: URL
    private let lock = NSLock()
    private var continuation: CheckedContinuation<NetworkCheckResult, Never>?
    private var started = Date()
    private var firstByte: Date?
    private var received = 0
    private var metrics: URLSessionTaskMetrics?
    private var outOfTime = false
    private var done = false

    init(url: URL) { self.url = url }

    func run() async -> NetworkCheckResult {
        await withCheckedContinuation { continuation in
            lock.lock()
            self.continuation = continuation
            lock.unlock()
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
            let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
            var request = URLRequest(url: url)
            request.setValue("bytes=0-\(NetworkCheck.sampleBytes - 1)", forHTTPHeaderField: "Range")
            let task = session.dataTask(with: request)
            started = Date()
            task.resume()
            DispatchQueue.global().asyncAfter(deadline: .now() + NetworkCheck.timeLimit) {
                self.lock.lock()
                let open = !self.done
                if open { self.outOfTime = true }
                self.lock.unlock()
                if open { task.cancel() }
            }
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        if firstByte == nil { firstByte = Date() }
        received += data.count
        lock.unlock()
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics) {
        lock.lock()
        self.metrics = metrics
        lock.unlock()
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let now = Date()
        lock.lock()
        done = true
        let how = outOfTime ? "時間切れ" : error.map { "失敗（\(NetworkCheck.errorText($0))）" } ?? "完了"
        let speed = NetworkCheck.speed(bytes: received, from: firstByte, to: now)
        let status = (task.response as? HTTPURLResponse)?.statusCode ?? 0
        var parts = ["アプリと同じ通信: \(how)", "HTTP \(status)", String(format: "受信 %.1fMB", Double(received) / 1_000_000) + "・" + speed]
        if let firstByte { parts.append("最初のデータまで \(Int(firstByte.timeIntervalSince(started) * 1000))ms") }
        parts.append(NetworkCheck.describe(metrics))
        let continuation = self.continuation
        self.continuation = nil
        lock.unlock()
        session.finishTasksAndInvalidate()
        continuation?.resume(returning: NetworkCheckResult(text: parts.joined(separator: "・"), speed: speed))
    }
}

/// In the developer settings, above the download record.
struct NetworkCheckCard: View {
    @ObservedObject private var check = NetworkCheck.shared
    @State private var copied = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("配布元への通信の診断", systemImage: "network").font(.headline)
            Text("いまのネットワーク（Wi-Fiかモバイル通信か、IPv4・IPv6、DNS、VPN）と、モデルの配布元までの経路を調べます。E2Bの先頭8MBを、IPv4だけ・IPv6だけ・アプリと同じ通信の3通りで受け取って比べます。1回に最大約24MBを使い、保存はしません。結果はダウンロードの記録にも残ります。")
                .font(.caption).foregroundStyle(.secondary)
            HStack(spacing: 10) {
                Button { copied = false; check.run() } label: { Label("通信を診断", systemImage: "stethoscope") }
                    .font(.subheadline).disabled(check.isRunning)
                    .accessibilityIdentifier("network-check-run")
                if check.isRunning { ProgressView().controlSize(.small) }
            }
            if !check.lines.isEmpty {
                Text(check.lines.joined(separator: "\n"))
                    .font(.system(.caption2, design: .monospaced)).textSelection(.enabled)
                    .accessibilityIdentifier("network-check-result")
                Button(copied ? "コピーしました" : "結果をコピー") {
                    UIPasteboard.general.string = check.lines.joined(separator: "\n")
                    copied = true
                }
                .font(.subheadline).disabled(check.isRunning)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }
}
