import SwiftUI

/// The model series that have a mark of Fielua's own (fielua-reports Issue
/// #19, 1.1.0 (282)). A model's `family` names its series.
enum ModelSeries: String, CaseIterable {
    case gemma, qwen, lfm

    init?(family: String) {
        switch family.lowercased() {
        case "gemma": self = .gemma
        case "qwen": self = .qwen
        case "lfm": self = .lfm
        default: return nil
        }
    }
}

/// A series' mark, Fielua's own (fielua-reports Issue #19, the user's
/// request and choice of 2026-11-15, look A): a symbol that calls the
/// series to mind in a round paper tile. Gemma a softly cut gem with two
/// grains of light in Fielua's yellow, Qwen two planes laid over each other
/// at an angle, LFM a drop leaning as it starts to flow, in three layers.
/// No one's logo is used, traced or retouched; the series' name is always
/// written beside it, and VoiceOver reads the name, not the picture.
///
/// One drawing for every place a model's mark shows: モデル管理's series
/// rows and the cards on a series' page, the first launch's list, the
/// chat's top and the download's Live Activity (this file is in the widget
/// extension too). Light and dark have their own colours; with Increase
/// Contrast the tile's edge is deeper. Static: nothing here animates.
///
/// The shapes and colours are SeriesMarkArt.swift, written by
/// design/series-marks/series_marks.py from the previewed design.
struct SeriesMark: View {
    let series: ModelSeries
    var size: CGFloat = 32
    /// Light or dark, and Increase Contrast, as given rather than as the
    /// screen has them: the app's one-picture copy (SeriesMarkTile) is drawn
    /// apart from the screen, where neither is known (1.1.0 (291)).
    var dark: Bool? = nil
    var strong: Bool? = nil
    @Environment(\.colorScheme) private var scheme
    @Environment(\.colorSchemeContrast) private var contrast

    var body: some View {
        let dark = self.dark ?? (scheme == .dark)
        let strong = self.strong ?? (contrast == .increased)
        ZStack {
            ForEach(SeriesMarkArt.layers(of: series).indices, id: \.self) { index in
                SeriesMarkLayer(layer: SeriesMarkArt.layers(of: series)[index], dark: dark, strong: strong)
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

/// One shape of a mark, filled and clipped as the design has it.
private struct SeriesMarkLayer: View {
    let layer: SeriesMarkArt.Layer
    let dark: Bool
    let strong: Bool

    var body: some View {
        let filled = SeriesMarkArt.Outline(steps: layer.steps)
            .fill(style, style: FillStyle(eoFill: layer.evenOdd))
        if let clip = layer.clip {
            filled.clipShape(SeriesMarkArt.Outline(steps: clip))
        } else {
            filled
        }
    }

    private var style: AnyShapeStyle {
        if layer.rim && strong {
            // Increase Contrast: the tile's edge in Fielua's taupe.
            return AnyShapeStyle(dark ? Color(red: 0.55, green: 0.51, blue: 0.46) : Color(red: 0.56, green: 0.49, blue: 0.42))
        }
        switch dark ? layer.dark : layer.light {
        case let .solid(hex, alpha):
            return AnyShapeStyle(SeriesMarkArt.color(hex, alpha))
        case let .linear(fromHex, fromAlpha, toHex, toAlpha, start, end):
            return AnyShapeStyle(LinearGradient(colors: [SeriesMarkArt.color(fromHex, fromAlpha), SeriesMarkArt.color(toHex, toAlpha)],
                                                startPoint: UnitPoint(x: start.0 / 100, y: start.1 / 100),
                                                endPoint: UnitPoint(x: end.0 / 100, y: end.1 / 100)))
        }
    }
}

/// The marks' drawing on a 100 x 100 canvas (the numbers are in
/// SeriesMarkArt.swift).
enum SeriesMarkArt {
    enum Step {
        case move(CGFloat, CGFloat)
        case line(CGFloat, CGFloat)
        case curve(CGFloat, CGFloat, CGFloat, CGFloat, CGFloat, CGFloat)
        case close
    }

    enum Paint {
        case solid(UInt32, Double)
        /// Two colours along a line, its ends on the canvas.
        case linear(UInt32, Double, UInt32, Double, from: (CGFloat, CGFloat), to: (CGFloat, CGFloat))
    }

    struct Layer {
        let steps: [Step]
        let light: Paint
        let dark: Paint
        var clip: [Step]? = nil
        var evenOdd = false
        /// The tile's edge (deeper with Increase Contrast).
        var rim = false

        init(_ steps: [Step], light: Paint, dark: Paint, clip: [Step]? = nil, evenOdd: Bool = false, rim: Bool = false) {
            self.steps = steps; self.light = light; self.dark = dark
            self.clip = clip; self.evenOdd = evenOdd; self.rim = rim
        }
    }

    static func layers(of series: ModelSeries) -> [Layer] {
        switch series {
        case .gemma: return gemma
        case .qwen: return qwen
        case .lfm: return lfm
        }
    }

    static func color(_ hex: UInt32, _ alpha: Double) -> Color {
        Color(.sRGB, red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255,
              blue: Double(hex & 0xFF) / 255, opacity: alpha)
    }

    /// Steps drawn into the frame given (the canvas's 100 units across it).
    struct Outline: Shape {
        let steps: [Step]

        func path(in rect: CGRect) -> Path {
            let sx = rect.width / 100, sy = rect.height / 100
            func point(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: rect.minX + x * sx, y: rect.minY + y * sy) }
            var path = Path()
            for step in steps {
                switch step {
                case let .move(x, y): path.move(to: point(x, y))
                case let .line(x, y): path.addLine(to: point(x, y))
                case let .curve(x1, y1, x2, y2, x, y):
                    path.addCurve(to: point(x, y), control1: point(x1, y1), control2: point(x2, y2))
                case .close: path.closeSubpath()
                }
            }
            return path
        }
    }
}
