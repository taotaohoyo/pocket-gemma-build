import SwiftUI

/// Whether a reply is being written, for the views that need only that of
/// the chat (1.1.0 (263)). ChatStore publishes with every batch of a reply's
/// text, about 22 times a second, and a page of 設定 that observed it to dim
/// one button drew itself again each time, through its slide as well (UI
/// review, 2026-11-11). Both ChatStores set this as their own
/// `isGenerating` changes; it changes twice a reply.
@MainActor final class ChatPulse: ObservableObject {
    static let shared = ChatPulse()
    @Published private(set) var isGenerating = false

    private init() {}

    func set(generating: Bool) {
        if isGenerating != generating { isGenerating = generating }
    }
}

/// The chat's store for a view that acts on it, or reads it as it draws,
/// without observing it (ChatPulse says when a reply starts and ends). Set
/// beside `.environmentObject(chats)` at the app's root, so sheets have it too.
struct ChatHandle {
    weak var store: ChatStore?
    init(_ store: ChatStore? = nil) { self.store = store }
}

extension EnvironmentValues {
    @Entry var chatHandle = ChatHandle()
}
