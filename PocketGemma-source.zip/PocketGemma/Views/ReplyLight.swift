import SwiftUI
import PocketCore

/// The reply's light from the send until its text is written (the user's
/// directive of 2026-11-19, one light from thinking to writing): the
/// Aurora Orb as in 296, a broad soft light behind it (光の面,
/// AuroraOrbShader's auroraField) and, beside it, what the reply is waiting
/// for in a few quiet words (状態の一行) with the orb's gold passing over
/// them once a breath. When the reply's first text comes (1.1.0 (301)),
/// the text is laid out above the orb at once; the orb stays in its row
/// under the reply's newest line, its field drawn in a little, and the
/// stage's words say 書いています until the reply's first point takes
/// their place (要点, 1.1.0 (302): a short point of what the reply has said,
/// ReplyPoints, ReplyPreviewLine; until 302 the newest words the model had
/// written). Once the reply is written (or stopped, or failed) the orb
/// shrinks away where it is, its words with it, and its row closes. The
/// writing carries the orb's gold in its newest characters, as in 296
/// (ReplyText, ReplyWritingLight).
///
/// It draws only over the chat's own background, never takes a touch and
/// is drawn under the reply's text (ReplyOrb). Up to 30 frames a second
/// while the model thinks; from the reply's first text until the orb has
/// gone, the orb, its halo and its words as often as the text itself is
/// drawn (`textInterval`: 60 on the phone; 1.1.0 (304)) and the broad field
/// behind them 20 (`writingInterval`); 15 in Low Power Mode or while hot,
/// one still frame with Reduce Motion or when critically hot; nothing
/// while out of sight.
enum ReplyLight {
    /// The field follows the breath this far behind.
    static let lag: TimeInterval = 0.4
    /// The field comes in over this long (the orb in ChatMotion.orbIn's 0.2 s).
    static let bloom: TimeInterval = 0.8
    /// The halo just beyond the rim goes with the orb over this long.
    static let haloGone: TimeInterval = 0.6

    /// The square the field is drawn in, and the light's centre in it
    /// (points): the field is fully gone 151pt along the line, 94pt up and
    /// 130pt down.
    static let canvas = CGSize(width: 192, height: 228)
    static let centre = CGPoint(x: 32, y: 96)
    /// The field has no detail: it is drawn at a third of the size and
    /// scaled up (a ninth of the pixels).
    static let fieldScale: CGFloat = 3

    /// The words start this far right of the light's centre.
    static let wordsGap: CGFloat = 22

    /// 生成中の一節 (1.1.0 (301)): while the reply is written the orb stays,
    /// in a row of its own under the reply's newest line, this tall, with
    /// its point beside it (ReplyPreviewLine; 301 the newest words).
    static let rowHeight: CGFloat = 44
    /// While it writes, the field draws in to this share of itself (its
    /// reach and strength), over `writingGather`, so it lights the orb's
    /// row and only the edge of the text above.
    static let writingField = 0.6
    static let writingGather: TimeInterval = 0.6
    /// 301 and 302's ease of the row down to a new line in a chat that fits
    /// on the page, kept for the UI checks' comparison
    /// (`--probe-orb-302-motion`, ReplyRowMotion302): a spring fastest at
    /// its start, which the user saw as a jolt at the reply's first
    /// character (2026-11-20). Since 1.1.0 (303) the row moves as the room
    /// above it grows (ReplyGlide, ReplyFollow).
    static let rowGlide = Animation.smooth(duration: 0.24)
    /// While the row makes room for a new line, the reply's text is drawn
    /// down to this far below the room's edge (the row's top) and no
    /// further: 2pt above the orb at its fullest breath (its centre 22pt
    /// down the row, 12pt round), above the point beside it (1.1.0 (303),
    /// ReplyTextClip). At rest the text's last line ends 7pt above the
    /// room's edge, its writing light 4pt below it: nothing of it is cut.
    static let textClear: CGFloat = 8
    /// While the reply is written its broad field, drawn in and barely
    /// changing, is drawn 20 times a second rather than 30 (1.1.0 (302);
    /// 301 drew it at 30 throughout). Until 1.1.0 (303) the orb, its halo
    /// and the point beside it were too: 20 a second, at uneven steps of 50
    /// and 67 ms on the phone, beside text drawn at 60, the orb read as
    /// heavy next to its text (the user's directive of 2026-11-20).
    static let writingInterval: TimeInterval = 1.0 / 20.0
    /// How often the reply's text is drawn while its characters come in
    /// (RevealingRichText), and from 1.1.0 (304) the orb, its halo and its
    /// words with it while it writes: every frame up to 60 a second on the
    /// phone, 30 when it is hot or saving power (the orb itself then 15,
    /// its pace), 30 in the simulator, which draws in software.
    static var textInterval: TimeInterval {
        #if targetEnvironment(simulator)
        return 1.0 / 30.0
        #else
        return OrbPace.current == .full ? 1.0 / 60.0 : 1.0 / 30.0
        #endif
    }
    /// The square the orb and its halo are drawn in (auroraReplyOrb): the
    /// halo reaches 36pt from the light's centre.
    static let orbCanvas: CGFloat = 72
    #if POCKET_PREVIEW
    /// UI checks only (`--probe-writing-30fps`): 301's 30 while writing.
    static let writesAtThirty = PreviewProbe.on("--probe-writing-30fps")
    /// UI checks only (`--probe-orb-303`): the light drawn as in 1.1.0
    /// (303), to compare: one clock, 20 a second while it writes, the halo
    /// in the field at a third of the size, the field's reach from each
    /// direction's rim alone; the text cut at the room's edge (ReplyText).
    static let drawsAs303 = PreviewProbe.on("--probe-orb-303")
    #else
    static let writesAtThirty = false
    static let drawsAs303 = false
    #endif
    /// The phrase's width: the row's, less the orb's side and the reply's
    /// inset on the other.
    static func previewWidth(row: CGFloat) -> CGFloat {
        max(row - ChatMetrics.replyInset - AuroraOrbView.lightRadius - wordsGap - ChatMetrics.replyInset - 2, 0)
    }

    /// UI checks only: the light's own clock runs this many times slower
    /// (`--orb-slow-motion`), and with it the orb's close and its words.
    #if POCKET_PREVIEW
    static let slowMotion: Double = PreviewProbe.on("--orb-slow-motion") ? 4 : 1
    #else
    static let slowMotion: Double = 1
    #endif

    /// The orb's shrink at `share` of it (296's cubic, 1 to 0).
    static func keep(_ share: Double) -> Double {
        let s = min(max(share, 0), 1)
        return 2 * s * s * s - 3 * s * s + 1
    }

    static func easeOut(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return 1 - (1 - s) * (1 - s) * (1 - s)
    }

    static func smooth(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return s * s * (3 - 2 * s)
    }

    /// The reply's stage while it waits (ChatStore.status) in a few
    /// words, or nil when something else already says it (the web search's
    /// own line). Once its text is under way the orb says 書いています
    /// instead (ReplyStageWords).
    static func words(for status: String) -> LocalizedStringKey? {
        if status.hasPrefix("ウェブを検索") { return nil }
        if status.hasPrefix("モデルを読み込んで") { return "読み込んでいます" }
        if status.hasPrefix("会話を準備") { return "準備しています" }
        if status.hasPrefix("じっくり考えて") { return "じっくり考えています" }
        if status.hasPrefix("返信の続きを準備") { return "続きを準備しています" }
        if status.hasPrefix("動画の音声を書き起こして") { return "音声を書き起こしています" }
        if status.hasPrefix("動画の場面を見て") { return "場面を見ています" }
        if status.hasPrefix("動画の話をまとめて") { return "話をまとめています" }
        if status.hasPrefix("検索結果を読んで") { return "検索結果を読んでいます" }
        return "考えています"
    }

    /// Compiles the field's and the orb's shaders ahead of the first
    /// reply, as the orb's (AuroraOrbView.prepare).
    static func prepare() async {
        try? await ShaderLibrary.auroraField(.float2(64, 76), .float2(10, 32), .float(3), .float(0), .float(0),
                                             .float(1), .float(1), .float(12), .float(0), .float(1), .float(1))
            .compile(as: .shapeStyle)
        try? await ShaderLibrary.auroraReplyOrb(.float2(orbCanvas, orbCanvas), .float(0), .float(0), .float(1), .float(1),
                                                .float(1), .float(1), .float(1))
            .compile(as: .shapeStyle)
    }
}

/// The orb, its field and the stage's words; while the reply is written,
/// 書いています and then its points in their place. Two clocks since 1.1.0
/// (304): the broad field on its own (`fieldInterval`), the orb with its
/// halo and words on the text's while it writes (`orbInterval`); the same
/// moment on both, from the same start.
struct ReplyLightView: View {
    /// When the reply's first text came; nil while the model thinks.
    let writingSince: Date?
    /// When the orb began to close (the reply written, stopped or failed).
    let leavingSince: Date?
    let preview: ReplyPreview
    let version: Int
    /// The phrase's width (ReplyLight.previewWidth).
    let width: CGFloat

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()
    @State private var pace = OrbPace.current
    @State private var inSight = true
    @State private var onScreen = true

    private var still: Bool { systemReduceMotion || previewReduceMotion || pace == .still }

    /// One moment of the light: seconds since it came in (`time`), when
    /// the text began, its first point came and the orb began to close on
    /// the same clock, and `now` in reference-date seconds (the phrase's).
    private struct Moment {
        var time: TimeInterval
        var writingAt: TimeInterval?
        var pointAt: TimeInterval?
        var leavingAt: TimeInterval?
        /// The field's breath, fixed for a still frame.
        var breath: Double?
        var still: Bool
        var now: TimeInterval
    }

    var body: some View {
        Group {
            if still {
                // One still frame: the orb as it starts, the field at the
                // middle of its breath, the words without the passing gold;
                // drawn again as the phrase changes (`version`).
                let moment = Moment(time: 0, writingAt: writingSince.map { _ in -10 },
                                    pointAt: preview.firstShownAt.map { _ in -10 }, leavingAt: nil, breath: 0.5,
                                    still: true, now: Date().timeIntervalSinceReferenceDate)
                ZStack(alignment: .topLeading) {
                    fieldLayer(moment)
                    lightLayer(moment)
                }
            } else if ReplyLight.drawsAs303 {
                TimelineView(.animation(minimumInterval: fieldInterval, paused: !drawing)) { context in
                    let moment = self.moment(at: context.date)
                    #if POCKET_PREVIEW
                    let _ = GlideTrace.shared.drew(.field)
                    let _ = GlideTrace.shared.drew(.orb)
                    #endif
                    ZStack(alignment: .topLeading) {
                        fieldLayer(moment)
                        lightLayer(moment)
                    }
                }
            } else {
                ZStack(alignment: .topLeading) {
                    TimelineView(.animation(minimumInterval: fieldInterval, paused: !drawing)) { context in
                        #if POCKET_PREVIEW
                        let _ = GlideTrace.shared.drew(.field)
                        #endif
                        fieldLayer(moment(at: context.date))
                    }
                    TimelineView(.animation(minimumInterval: orbInterval, paused: !drawing)) { context in
                        #if POCKET_PREVIEW
                        let _ = GlideTrace.shared.drew(.orb)
                        #endif
                        lightLayer(moment(at: context.date))
                    }
                }
            }
        }
        .frame(width: ReplyLight.canvas.width, height: ReplyLight.canvas.height, alignment: .topLeading)
        #if POCKET_PREVIEW
        .opacity(PreviewOrbSample.plate ? 0 : 1)
        #endif
        .allowsHitTesting(false)
        .onScrollVisibilityChange(threshold: 0.01) { inSight = $0 }
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .accessibilityElement()
        .accessibilityLabel(Text("返信を書いています"))
        // Once the text is under way it is what VoiceOver reads.
        .accessibilityHidden(writingSince != nil)
    }

    private var drawing: Bool { inSight && onScreen && scenePhase == .active }

    /// The field: 20 frames a second while the reply is written (and not
    /// yet closing), else the pace's.
    private var fieldInterval: TimeInterval {
        guard pace == .full, writingSince != nil, leavingSince == nil, !ReplyLight.writesAtThirty else { return pace.interval }
        return ReplyLight.writingInterval
    }

    /// The orb, its halo and its words: as often as the reply's text from
    /// its first text until the orb has gone (1.1.0 (304)), else the
    /// pace's. In Low Power Mode or while hot the pace's 15 throughout.
    private var orbInterval: TimeInterval {
        guard pace == .full, writingSince != nil else { return pace.interval }
        if ReplyLight.writesAtThirty { return pace.interval }
        return ReplyLight.textInterval
    }

    private func moment(at date: Date) -> Moment {
        Moment(time: date.timeIntervalSince(started) / ReplyLight.slowMotion,
               writingAt: writingSince.map { $0.timeIntervalSince(started) / ReplyLight.slowMotion },
               pointAt: preview.firstShownAt.map { ($0 - started.timeIntervalSinceReferenceDate) / ReplyLight.slowMotion },
               leavingAt: leavingSince.map { $0.timeIntervalSince(started) / ReplyLight.slowMotion },
               breath: nil, still: false, now: date.timeIntervalSinceReferenceDate)
    }

    /// Seconds since the orb began to close.
    private func since(_ m: Moment) -> TimeInterval? { m.leavingAt.map { max(m.time - $0, 0) } }

    /// The field's breath (0 at its low, 1 at its top), a beat behind the
    /// orb's, held where the orb began to close.
    private func breath(_ m: Moment) -> Double {
        m.breath ?? {
            let behind = min(m.time, m.leavingAt ?? .infinity) - ReplyLight.lag
            return (AuroraOrbView.breath(at: max(behind, 0)).size - AuroraOrbView.smallest) / (1 - AuroraOrbView.smallest)
        }()
    }

    private func bloom(_ m: Moment) -> Double { m.still ? 1 : ReplyLight.easeOut(m.time / ReplyLight.bloom) }

    /// The halo's share: it goes with the orb.
    private func halo(_ m: Moment) -> Double { since(m).map { 1 - ReplyLight.smooth($0 / ReplyLight.haloGone) } ?? 1 }

    /// The broad field, behind everything; until 303 its halo too.
    private func fieldLayer(_ m: Moment) -> some View {
        let motion = AuroraOrbView.sizeAndOpacity(at: m.time, leavingAt: m.leavingAt)
        let keep = since(m).map { ReplyLight.keep($0 / AuroraOrbView.exitDuration) } ?? 1
        let writing = m.writingAt.map { m.still ? 1 : ReplyLight.easeOut(max(m.time - $0, 0) / ReplyLight.writingGather) } ?? 0
        let gather = keep * (1 - (1 - ReplyLight.writingField) * writing)
        return field(time: m.time, breath: breath(m), gather: gather, radius: AuroraOrbView.lightRadius * motion.size,
                     halo: ReplyLight.drawsAs303 ? halo(m) : 0, bloom: bloom(m))
    }

    /// The orb with its halo, and the stage's words or the reply's point
    /// beside it.
    private func lightLayer(_ m: Moment) -> some View {
        let motion = AuroraOrbView.sizeAndOpacity(at: m.time, leavingAt: m.leavingAt)
        let centre = ReplyLight.centre
        // The stage's words go where they are as the text begins (or with
        // the orb, stopped before it did); 書いています then comes in under
        // the reply's first line and gives way to its first point (or goes
        // with the orb, written or stopped before one came).
        let thinkingGone = (m.writingAt ?? m.leavingAt).map { max(m.time - $0, 0) }
        let writingGone = (m.pointAt ?? m.leavingAt).map { max(m.time - $0, 0) }
        return ZStack(alignment: .topLeading) {
            if ReplyLight.drawsAs303 {
                orb303(time: m.time, size: motion.size)
                    .opacity(motion.opacity)
                    .offset(x: centre.x - AuroraOrbView.canvas / 2, y: centre.y - AuroraOrbView.canvas / 2)
            } else {
                orb(time: m.time, size: motion.size, opacity: motion.opacity, breath: breath(m), halo: halo(m), bloom: bloom(m))
                    .offset(x: centre.x - ReplyLight.orbCanvas / 2, y: centre.y - ReplyLight.orbCanvas / 2)
            }
            ReplyStageWords(time: m.time, writingSince: m.writingAt.map { max(m.time - $0, 0) }, thinkingGone: thinkingGone,
                            writingGone: writingGone, still: m.still)
                .offset(x: centre.x + ReplyLight.wordsGap, y: centre.y - ReplyStageWords.height / 2)
            if m.writingAt != nil {
                ReplyPreviewLine(preview: preview, version: version, now: m.now, width: width,
                                 leaving: since(m).map { $0 * ReplyLight.slowMotion }, still: m.still)
                    .offset(x: centre.x + ReplyLight.wordsGap, y: centre.y)
            }
        }
    }

    private var dark: Float { colorScheme == .dark ? 1 : 0 }

    /// The orb over its halo (auroraReplyOrb), at full size.
    private func orb(time: TimeInterval, size: Double, opacity: Double, breath: Double, halo: Double,
                     bloom: Double) -> some View {
        Rectangle()
            .fill(ShaderLibrary.auroraReplyOrb(.float2(ReplyLight.orbCanvas, ReplyLight.orbCanvas), .float(Float(time)),
                                               .float(dark), .float(Float(size)), .float(Float(opacity)),
                                               .float(Float(breath)), .float(Float(halo)), .float(Float(bloom))))
            .frame(width: ReplyLight.orbCanvas, height: ReplyLight.orbCanvas)
    }

    /// 303's orb alone (`--probe-orb-303`): its halo was the field's.
    private func orb303(time: TimeInterval, size: Double) -> some View {
        Rectangle()
            .fill(ShaderLibrary.auroraOrb(.float2(AuroraOrbView.canvas, AuroraOrbView.canvas), .float(Float(time)),
                                          .float(dark), .float(Float(size))))
            .frame(width: AuroraOrbView.canvas, height: AuroraOrbView.canvas)
    }

    private func field(time: TimeInterval, breath: Double, gather: Double, radius: Double, halo: Double,
                       bloom: Double) -> some View {
        let scale = ReplyLight.fieldScale
        let size = CGSize(width: ReplyLight.canvas.width / scale, height: ReplyLight.canvas.height / scale)
        let centre = CGPoint(x: ReplyLight.centre.x / scale, y: ReplyLight.centre.y / scale)
        return Rectangle()
            .fill(ShaderLibrary.auroraField(.float2(size.width, size.height), .float2(centre.x, centre.y),
                                            .float(Float(scale)), .float(Float(time)), .float(dark),
                                            .float(Float(breath)), .float(Float(gather)), .float(Float(radius)),
                                            .float(Float(halo)), .float(Float(bloom)),
                                            .float(ReplyLight.drawsAs303 ? 0 : 1)))
            .frame(width: size.width, height: size.height)
            // Drawn at a third of the size, then scaled up as an image: it
            // has no detail (beside the full-size field it differs by at
            // most 2 of 255 levels, 1.1.0 (304)).
            .drawingGroup()
            .scaleEffect(scale, anchor: .topLeading)
            .frame(width: ReplyLight.canvas.width, height: ReplyLight.canvas.height, alignment: .topLeading)
    }
}

/// 状態の一行: what the reply waits for (ChatStore.status, in
/// ReplyLight.words), in the web search line's quiet footnote, with the
/// orb's gold passing over it as the orb breathes out. It comes out of the
/// orb a moment after it and goes where it is as the reply's text begins;
/// once the orb's row has eased under the first line, 書いています comes
/// in its place until the reply's first point takes it (1.1.0 (302): one
/// word for one moment, never two at once; in 301 the words went as the
/// text began). The only place the stage is said: the developers' line
/// under the conversation no longer says it too. Read by nobody: the orb
/// says 返信を書いています.
struct ReplyStageWords: View {
    static let height: CGFloat = 22
    /// The gold passes once each breath, as the orb breathes out.
    static let passStart = 0.2
    static let passLength = 1.7
    /// How much of the ink the words are drawn in.
    static let inkShare = 0.68
    /// 書いています comes in once the row has eased under the reply's first
    /// line (ReplyLight.rowGlide, 0.24 s) and the stage's words have gone
    /// (0.25 s), over `writingIn`.
    static let writingDelay: TimeInterval = 0.3
    static let writingIn: TimeInterval = 0.4

    let time: TimeInterval
    /// Seconds since the reply's text began; nil while it thinks.
    let writingSince: TimeInterval?
    /// Seconds since the stage's words began to go (the text began, or the
    /// orb closed before it did).
    let thinkingGone: TimeInterval?
    /// Seconds since 書いています began to go (the first point came, or the
    /// orb closed before one did).
    let writingGone: TimeInterval?
    let still: Bool

    @EnvironmentObject private var chats: ChatStore
    @Environment(\.colorScheme) private var colorScheme
    /// The stage's words as they were when the text began: the store says
    /// 返信中… with the first text, and words that are going do not change.
    @State private var stage: LocalizedStringKey?

    var body: some View {
        ZStack(alignment: .leading) {
            if let stage {
                let shown = still ? 1 : ReplyLight.easeOut((time - 0.25) / 0.5)
                let gone = thinkingGone.map { still ? 1 : ReplyLight.easeOut($0 / 0.25) } ?? 0
                line(stage)
                    .opacity(shown * (1 - gone))
                    .offset(x: -6 * CGFloat(1 - shown) - 6 * CGFloat(gone))
                    // A new stage (考えています to じっくり考えています)
                    // comes in over the old one rather than in one frame.
                    .animation(still || writingSince != nil ? nil : .easeInOut(duration: 0.4), value: stage)
            }
            if let since = writingSince {
                let shown = still ? 1 : ReplyLight.easeOut((since - Self.writingDelay) / Self.writingIn)
                let gone = writingGone.map { still ? 1 : ReplyLight.easeOut($0 / 0.25) } ?? 0
                line("書いています")
                    .opacity(shown * (1 - gone))
                    .offset(x: -6 * CGFloat(gone))
            }
        }
        .accessibilityHidden(true)
        .onChange(of: chats.status, initial: true) { _, status in
            guard writingSince == nil, !status.hasPrefix("返信中") else { return }
            stage = ReplyLight.words(for: status)
        }
    }

    private func line(_ words: LocalizedStringKey) -> some View {
        Text(words)
            .font(.footnote)
            // The ink at two thirds: read at a glance on paper and on
            // charcoal (contrast about 6:1 and 8:1), still quieter than the
            // reply. The system's secondary was too faint over the light
            // (1.1.0 (300)).
            .foregroundStyle(Theme.ink.opacity(ReplyStageWords.inkShare))
            .contentTransition(.opacity)
            .overlay { if !still { gold(words) } }
            .lineLimit(1)
            .fixedSize()
            .frame(height: Self.height)
    }

    /// The gold passing over the words, left to right, from the orb.
    private func gold(_ words: LocalizedStringKey) -> some View {
        let cycle = time.truncatingRemainder(dividingBy: AuroraOrbView.breathPeriod)
        let along = (cycle - Self.passStart) / Self.passLength
        let strength = along > 0 && along < 1 ? sin(Double.pi * along) : 0
        let at = -0.35 + 1.7 * along
        let tone = colorScheme == .dark ? Color(red: 1.0, green: 0.86, blue: 0.55) : Color(red: 0.80, green: 0.56, blue: 0.05)
        return Text(words)
            .font(.footnote)
            .foregroundStyle(tone)
            .mask {
                LinearGradient(stops: [.init(color: .clear, location: 0), .init(color: .white, location: 0.5),
                                       .init(color: .clear, location: 1)],
                               startPoint: UnitPoint(x: at - 0.35, y: 0.5), endPoint: UnitPoint(x: at + 0.35, y: 0.5))
            }
            .opacity(strength)
    }
}
