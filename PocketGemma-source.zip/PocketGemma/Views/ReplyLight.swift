import SwiftUI
import PocketCore

/// The reply's light from the send until its text is under way (the user's
/// directive of 2026-11-19, one light from thinking to writing): the
/// Aurora Orb as in 296, a broad soft light behind it (光の面,
/// AuroraOrbShader's auroraField) and, beside it, what the reply is waiting
/// for in a few quiet words (状態の一行) with the orb's gold passing over
/// them once a breath. When the reply's first text comes, the orb shrinks
/// as in 296 onto the first character, the field closes with it and the
/// words go back into it; the text may show 0.35 s in (`release`), under
/// the closing orb. The writing then carries the orb's gold in its newest
/// characters, as in 296 (ReplyText); a light under them was tried and
/// left out (unseen on paper, a smudge on charcoal).
///
/// It draws only over the chat's own background, never takes a touch and
/// changes nothing around it: it hangs from the reply's first line as an
/// overlay (ReplyOrb). Up to 30 frames a second, 15 in Low Power Mode or
/// while hot, one still frame with Reduce Motion or when critically hot;
/// nothing while out of sight.
enum ReplyLight {
    /// How long after the reply's first text its text may show: the orb is
    /// then half-way through its shrink, and closes over the first
    /// character as it appears (296: once the orb had gone, 0.7 s).
    static let release: TimeInterval = 0.35
    /// How far the orb moves along the line as it closes, onto the first
    /// character's centre (points).
    static let settle: CGFloat = -3.5
    /// The field follows the breath this far behind.
    static let lag: TimeInterval = 0.4
    /// The field comes in over this long (the orb in ChatMotion.orbIn's 0.2 s).
    static let bloom: TimeInterval = 0.8
    /// The halo just beyond the rim goes with the orb over this long.
    static let haloGone: TimeInterval = 0.6

    /// The square the field is drawn in, and the light's centre in it
    /// (points): the field is fully gone 151pt along the line, 94pt up and
    /// 130pt down.
    static let canvas = CGSize(width: 192, height: 228)
    static let centre = CGPoint(x: 32, y: 96)
    /// The field has no detail: it is drawn at a third of the size and
    /// scaled up (a ninth of the pixels).
    static let fieldScale: CGFloat = 3

    /// The words start this far right of the light's centre.
    static let wordsGap: CGFloat = 22

    /// UI checks only: the light's own clock runs this many times slower
    /// (`--orb-slow-motion`), and with it the text's release.
    #if POCKET_PREVIEW
    static let slowMotion: Double = PreviewProbe.on("--orb-slow-motion") ? 4 : 1
    #else
    static let slowMotion: Double = 1
    #endif

    /// The orb's shrink at `share` of it (296's cubic, 1 to 0).
    static func keep(_ share: Double) -> Double {
        let s = min(max(share, 0), 1)
        return 2 * s * s * s - 3 * s * s + 1
    }

    static func easeOut(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return 1 - (1 - s) * (1 - s) * (1 - s)
    }

    static func smooth(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return s * s * (3 - 2 * s)
    }

    /// The reply's stage (ChatStore.status) in a few words, or nil when
    /// something else already says it (the web search's own line).
    static func words(for status: String) -> LocalizedStringKey? {
        if status.hasPrefix("ウェブを検索") { return nil }
        if status.hasPrefix("モデルを読み込んで") { return "読み込んでいます" }
        if status.hasPrefix("会話を準備") { return "準備しています" }
        if status.hasPrefix("じっくり考えて") { return "じっくり考えています" }
        if status.hasPrefix("返信の続きを準備") { return "続きを準備しています" }
        if status.hasPrefix("動画の音声を書き起こして") { return "音声を書き起こしています" }
        if status.hasPrefix("動画の場面を見て") { return "場面を見ています" }
        if status.hasPrefix("動画の話をまとめて") { return "話をまとめています" }
        if status.hasPrefix("検索結果を読んで") { return "検索結果を読んでいます" }
        return "考えています"
    }

    /// Compiles the field's shader ahead of the first reply, as the orb's
    /// (AuroraOrbView.prepare).
    static func prepare() async {
        try? await ShaderLibrary.auroraField(.float2(64, 76), .float2(10, 32), .float(3), .float(0), .float(0),
                                             .float(1), .float(1), .float(12), .float(1), .float(1))
            .compile(as: .shapeStyle)
    }
}

/// The orb, its field and the stage's words, drawn on one clock.
struct ReplyLightView: View {
    /// When the reply's first text came; nil while the model thinks.
    let leavingSince: Date?

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()
    @State private var pace = OrbPace.current
    @State private var inSight = true
    @State private var onScreen = true

    private var still: Bool { systemReduceMotion || previewReduceMotion || pace == .still }

    var body: some View {
        Group {
            if still {
                // One still frame: the orb as it starts, the field at the
                // middle of its breath, the words without the passing gold.
                scene(time: 0, leavingAt: nil, breath: 0.5, still: true)
            } else {
                TimelineView(.animation(minimumInterval: pace.interval, paused: !drawing)) { context in
                    let elapsed = context.date.timeIntervalSince(started) / ReplyLight.slowMotion
                    let leavingAt = leavingSince.map { $0.timeIntervalSince(started) / ReplyLight.slowMotion }
                    scene(time: elapsed, leavingAt: leavingAt, breath: nil, still: false)
                }
            }
        }
        .frame(width: ReplyLight.canvas.width, height: ReplyLight.canvas.height, alignment: .topLeading)
        #if POCKET_PREVIEW
        .opacity(PreviewOrbSample.plate ? 0 : 1)
        #endif
        .allowsHitTesting(false)
        .onScrollVisibilityChange(threshold: 0.01) { inSight = $0 }
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .accessibilityElement()
        .accessibilityLabel(Text("返信を書いています"))
    }

    private var drawing: Bool { inSight && onScreen && scenePhase == .active }

    /// Everything at `time` seconds after the light came in.
    @ViewBuilder
    private func scene(time: TimeInterval, leavingAt: TimeInterval?, breath fixed: Double?, still: Bool) -> some View {
        let motion = AuroraOrbView.sizeAndOpacity(at: time, leavingAt: leavingAt)
        let since = leavingAt.map { max(time - $0, 0) }
        let keep = since.map { ReplyLight.keep($0 / AuroraOrbView.exitDuration) } ?? 1
        let settle = ReplyLight.settle * CGFloat(1 - keep)
        let breath = fixed ?? {
            let behind = min(time, leavingAt ?? .infinity) - ReplyLight.lag
            return (AuroraOrbView.breath(at: max(behind, 0)).size - AuroraOrbView.smallest) / (1 - AuroraOrbView.smallest)
        }()
        let bloom = still ? 1 : ReplyLight.easeOut(time / ReplyLight.bloom)
        let halo = since.map { 1 - ReplyLight.smooth($0 / ReplyLight.haloGone) } ?? 1
        let centre = ReplyLight.centre
        ZStack(alignment: .topLeading) {
            field(time: time, breath: breath, gather: keep, radius: AuroraOrbView.lightRadius * motion.size,
                  halo: halo, bloom: bloom, settle: settle)
            orb(time: time, size: motion.size)
                .opacity(motion.opacity)
                .offset(x: centre.x - AuroraOrbView.canvas / 2 + settle, y: centre.y - AuroraOrbView.canvas / 2)
            ReplyStageWords(time: time, leavingSince: since, still: still)
                .offset(x: centre.x + ReplyLight.wordsGap, y: centre.y - ReplyStageWords.height / 2)
        }
    }

    private var dark: Float { colorScheme == .dark ? 1 : 0 }

    private func orb(time: TimeInterval, size: Double) -> some View {
        Rectangle()
            .fill(ShaderLibrary.auroraOrb(.float2(AuroraOrbView.canvas, AuroraOrbView.canvas), .float(Float(time)),
                                          .float(dark), .float(Float(size))))
            .frame(width: AuroraOrbView.canvas, height: AuroraOrbView.canvas)
    }

    private func field(time: TimeInterval, breath: Double, gather: Double, radius: Double, halo: Double,
                       bloom: Double, settle: CGFloat) -> some View {
        let scale = ReplyLight.fieldScale
        let size = CGSize(width: ReplyLight.canvas.width / scale, height: ReplyLight.canvas.height / scale)
        let centre = CGPoint(x: (ReplyLight.centre.x + settle) / scale, y: ReplyLight.centre.y / scale)
        return Rectangle()
            .fill(ShaderLibrary.auroraField(.float2(size.width, size.height), .float2(centre.x, centre.y),
                                            .float(Float(scale)), .float(Float(time)), .float(dark),
                                            .float(Float(breath)), .float(Float(gather)), .float(Float(radius)),
                                            .float(Float(halo)), .float(Float(bloom))))
            .frame(width: size.width, height: size.height)
            // Drawn at a third of the size, then scaled up as an image.
            .drawingGroup()
            .scaleEffect(scale, anchor: .topLeading)
            .frame(width: ReplyLight.canvas.width, height: ReplyLight.canvas.height, alignment: .topLeading)
    }
}

/// 状態の一行: what the reply waits for (ChatStore.status, in
/// ReplyLight.words), in the web search line's quiet footnote, with the
/// orb's gold passing over it as the orb breathes out. It comes out of the
/// orb a moment after it and goes back into it when the reply begins.
/// Read by nobody: the orb says 返信を書いています.
struct ReplyStageWords: View {
    static let height: CGFloat = 22
    /// The gold passes once each breath, as the orb breathes out.
    static let passStart = 0.2
    static let passLength = 1.7
    /// How much of the ink the words are drawn in.
    static let inkShare = 0.68

    let time: TimeInterval
    /// Seconds since the reply's first text; nil while it thinks.
    let leavingSince: TimeInterval?
    let still: Bool

    @EnvironmentObject private var chats: ChatStore
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        if let words = ReplyLight.words(for: chats.status) {
            let shown = still ? 1 : ReplyLight.easeOut((time - 0.25) / 0.5)
            let gone = leavingSince.map { ReplyLight.easeOut($0 / 0.25) } ?? 0
            Text(words)
                .font(.footnote)
                // The ink at two thirds: read at a glance on paper and on
                // charcoal (contrast about 6:1 and 8:1), still quieter than
                // the reply. The system's secondary was too faint over the
                // light (1.1.0 (300)).
                .foregroundStyle(Theme.ink.opacity(ReplyStageWords.inkShare))
                // A new stage (考えています to じっくり考えています) comes
                // in over the old one rather than in one frame.
                .contentTransition(.opacity)
                .overlay { if !still { gold(words) } }
                .lineLimit(1)
                .fixedSize()
                .frame(height: Self.height)
                .opacity(shown * (1 - gone))
                .offset(x: -6 * CGFloat(1 - shown) - 6 * CGFloat(gone))
                .animation(still ? nil : .easeInOut(duration: 0.4), value: chats.status)
                .accessibilityHidden(true)
        }
    }

    /// The gold passing over the words, left to right, from the orb.
    private func gold(_ words: LocalizedStringKey) -> some View {
        let cycle = time.truncatingRemainder(dividingBy: AuroraOrbView.breathPeriod)
        let along = (cycle - Self.passStart) / Self.passLength
        let strength = along > 0 && along < 1 ? sin(Double.pi * along) : 0
        let at = -0.35 + 1.7 * along
        let tone = colorScheme == .dark ? Color(red: 1.0, green: 0.86, blue: 0.55) : Color(red: 0.80, green: 0.56, blue: 0.05)
        return Text(words)
            .font(.footnote)
            .foregroundStyle(tone)
            .mask {
                LinearGradient(stops: [.init(color: .clear, location: 0), .init(color: .white, location: 0.5),
                                       .init(color: .clear, location: 1)],
                               startPoint: UnitPoint(x: at - 0.35, y: 0.5), endPoint: UnitPoint(x: at + 0.35, y: 0.5))
            }
            .opacity(strength)
    }
}
