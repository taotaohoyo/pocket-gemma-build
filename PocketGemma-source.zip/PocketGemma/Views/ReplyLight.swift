import SwiftUI
import PocketCore

/// The reply's light from the send until its text is written (the user's
/// directive of 2026-11-19, one light from thinking to writing): the
/// Aurora Orb as in 296, a broad soft light behind it (光の面,
/// AuroraOrbShader's auroraField) and, beside it, what the reply is waiting
/// for in a few quiet words (状態の一行) with the orb's gold passing over
/// them once a breath. When the reply's first text comes (1.1.0 (301)),
/// the text is laid out above the orb at once; the orb stays in its row
/// under the reply's newest line, its field drawn in a little, and the
/// stage's words say 書いています until the reply's first point takes
/// their place (要点, 1.1.0 (302): a short point of what the reply has said,
/// ReplyPoints, ReplyPreviewLine; until 302 the newest words the model had
/// written). Once the reply is written (or stopped, or failed) the orb
/// shrinks away where it is, its words with it, and its row closes. The
/// writing carries the orb's gold in its newest characters, as in 296
/// (ReplyText, ReplyWritingLight).
///
/// It draws only over the chat's own background, never takes a touch and
/// is drawn under the reply's text (ReplyOrb). Up to 30 frames a second
/// while the model thinks and while the orb closes, 20 while the reply is
/// written (`writingInterval`), 15 in Low Power Mode or while hot, one
/// still frame with Reduce Motion or when critically hot; nothing while
/// out of sight.
enum ReplyLight {
    /// The field follows the breath this far behind.
    static let lag: TimeInterval = 0.4
    /// The field comes in over this long (the orb in ChatMotion.orbIn's 0.2 s).
    static let bloom: TimeInterval = 0.8
    /// The halo just beyond the rim goes with the orb over this long.
    static let haloGone: TimeInterval = 0.6

    /// The square the field is drawn in, and the light's centre in it
    /// (points): the field is fully gone 151pt along the line, 94pt up and
    /// 130pt down.
    static let canvas = CGSize(width: 192, height: 228)
    static let centre = CGPoint(x: 32, y: 96)
    /// The field has no detail: it is drawn at a third of the size and
    /// scaled up (a ninth of the pixels).
    static let fieldScale: CGFloat = 3

    /// The words start this far right of the light's centre.
    static let wordsGap: CGFloat = 22

    /// 生成中の一節 (1.1.0 (301)): while the reply is written the orb stays,
    /// in a row of its own under the reply's newest line, this tall, with
    /// its point beside it (ReplyPreviewLine; 301 the newest words).
    static let rowHeight: CGFloat = 44
    /// While it writes, the field draws in to this share of itself (its
    /// reach and strength), over `writingGather`, so it lights the orb's
    /// row and only the edge of the text above.
    static let writingField = 0.6
    static let writingGather: TimeInterval = 0.6
    /// How the row eases down to a new line in a chat that fits on the
    /// page (in one that scrolls to follow the reply it stays put on
    /// screen): quick, so the new line's first characters and the words
    /// beside the orb barely meet.
    static let rowGlide = Animation.smooth(duration: 0.24)
    /// While the reply is written its text is what moves: the orb, its
    /// drawn-in field and the point beside it are drawn 20 times a second
    /// rather than 30, a third fewer frames for the longest part of a
    /// reply (1.1.0 (302); 301 drew them at 30 throughout, about half the
    /// simulator's frames while a long text was written).
    static let writingInterval: TimeInterval = 1.0 / 20.0
    #if POCKET_PREVIEW
    /// UI checks only (`--probe-writing-30fps`): 301's 30 while writing.
    static let writesAtThirty = PreviewProbe.on("--probe-writing-30fps")
    #else
    static let writesAtThirty = false
    #endif
    /// The phrase's width: the row's, less the orb's side and the reply's
    /// inset on the other.
    static func previewWidth(row: CGFloat) -> CGFloat {
        max(row - ChatMetrics.replyInset - AuroraOrbView.lightRadius - wordsGap - ChatMetrics.replyInset - 2, 0)
    }

    /// UI checks only: the light's own clock runs this many times slower
    /// (`--orb-slow-motion`), and with it the orb's close and its words.
    #if POCKET_PREVIEW
    static let slowMotion: Double = PreviewProbe.on("--orb-slow-motion") ? 4 : 1
    #else
    static let slowMotion: Double = 1
    #endif

    /// The orb's shrink at `share` of it (296's cubic, 1 to 0).
    static func keep(_ share: Double) -> Double {
        let s = min(max(share, 0), 1)
        return 2 * s * s * s - 3 * s * s + 1
    }

    static func easeOut(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return 1 - (1 - s) * (1 - s) * (1 - s)
    }

    static func smooth(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return s * s * (3 - 2 * s)
    }

    /// The reply's stage (ChatStore.status) in a few words, or nil when
    /// something else already says it (the web search's own line); once
    /// its text is under way, 書いています until its first point.
    static func words(for status: String, writing: Bool) -> LocalizedStringKey? {
        if writing { return "書いています" }
        if status.hasPrefix("ウェブを検索") { return nil }
        if status.hasPrefix("モデルを読み込んで") { return "読み込んでいます" }
        if status.hasPrefix("会話を準備") { return "準備しています" }
        if status.hasPrefix("じっくり考えて") { return "じっくり考えています" }
        if status.hasPrefix("返信の続きを準備") { return "続きを準備しています" }
        if status.hasPrefix("動画の音声を書き起こして") { return "音声を書き起こしています" }
        if status.hasPrefix("動画の場面を見て") { return "場面を見ています" }
        if status.hasPrefix("動画の話をまとめて") { return "話をまとめています" }
        if status.hasPrefix("検索結果を読んで") { return "検索結果を読んでいます" }
        return "考えています"
    }

    /// Compiles the field's shader ahead of the first reply, as the orb's
    /// (AuroraOrbView.prepare).
    static func prepare() async {
        try? await ShaderLibrary.auroraField(.float2(64, 76), .float2(10, 32), .float(3), .float(0), .float(0),
                                             .float(1), .float(1), .float(12), .float(1), .float(1))
            .compile(as: .shapeStyle)
    }
}

/// The orb, its field and the stage's words, drawn on one clock; while
/// the reply is written, 書いています and then its points in their place.
struct ReplyLightView: View {
    /// When the reply's first text came; nil while the model thinks.
    let writingSince: Date?
    /// When the orb began to close (the reply written, stopped or failed).
    let leavingSince: Date?
    let preview: ReplyPreview
    let version: Int
    /// The phrase's width (ReplyLight.previewWidth).
    let width: CGFloat

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()
    @State private var pace = OrbPace.current
    @State private var inSight = true
    @State private var onScreen = true

    private var still: Bool { systemReduceMotion || previewReduceMotion || pace == .still }

    var body: some View {
        Group {
            if still {
                // One still frame: the orb as it starts, the field at the
                // middle of its breath, the words without the passing gold;
                // drawn again as the phrase changes (`version`).
                scene(time: 0, writingAt: writingSince.map { _ in -10 }, pointAt: preview.firstShownAt.map { _ in -10 },
                      leavingAt: nil, breath: 0.5, still: true, now: Date().timeIntervalSinceReferenceDate)
            } else {
                TimelineView(.animation(minimumInterval: interval, paused: !drawing)) { context in
                    let elapsed = context.date.timeIntervalSince(started) / ReplyLight.slowMotion
                    let writingAt = writingSince.map { $0.timeIntervalSince(started) / ReplyLight.slowMotion }
                    let leavingAt = leavingSince.map { $0.timeIntervalSince(started) / ReplyLight.slowMotion }
                    let pointAt = preview.firstShownAt.map {
                        ($0 - started.timeIntervalSinceReferenceDate) / ReplyLight.slowMotion
                    }
                    scene(time: elapsed, writingAt: writingAt, pointAt: pointAt, leavingAt: leavingAt, breath: nil, still: false,
                          now: context.date.timeIntervalSinceReferenceDate)
                }
            }
        }
        .frame(width: ReplyLight.canvas.width, height: ReplyLight.canvas.height, alignment: .topLeading)
        #if POCKET_PREVIEW
        .opacity(PreviewOrbSample.plate ? 0 : 1)
        #endif
        .allowsHitTesting(false)
        .onScrollVisibilityChange(threshold: 0.01) { inSight = $0 }
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .accessibilityElement()
        .accessibilityLabel(Text("返信を書いています"))
        // Once the text is under way it is what VoiceOver reads.
        .accessibilityHidden(writingSince != nil)
    }

    private var drawing: Bool { inSight && onScreen && scenePhase == .active }

    /// 20 frames a second while the reply is written (and not yet closing),
    /// else the pace's.
    private var interval: TimeInterval {
        guard pace == .full, writingSince != nil, leavingSince == nil, !ReplyLight.writesAtThirty else { return pace.interval }
        return ReplyLight.writingInterval
    }

    /// Everything at `time` seconds after the light came in (`now` the
    /// same moment in reference-date seconds, the phrase's clock).
    @ViewBuilder
    private func scene(time: TimeInterval, writingAt: TimeInterval?, pointAt: TimeInterval?, leavingAt: TimeInterval?,
                       breath fixed: Double?, still: Bool, now: TimeInterval) -> some View {
        let motion = AuroraOrbView.sizeAndOpacity(at: time, leavingAt: leavingAt)
        let since = leavingAt.map { max(time - $0, 0) }
        let keep = since.map { ReplyLight.keep($0 / AuroraOrbView.exitDuration) } ?? 1
        // The orb closes where it is: in its own row it has no character
        // to settle onto (1.1.0 (301)).
        let settle: CGFloat = 0
        let writing = writingAt.map { still ? 1 : ReplyLight.easeOut(max(time - $0, 0) / ReplyLight.writingGather) } ?? 0
        let gather = keep * (1 - (1 - ReplyLight.writingField) * writing)
        let breath = fixed ?? {
            let behind = min(time, leavingAt ?? .infinity) - ReplyLight.lag
            return (AuroraOrbView.breath(at: max(behind, 0)).size - AuroraOrbView.smallest) / (1 - AuroraOrbView.smallest)
        }()
        let bloom = still ? 1 : ReplyLight.easeOut(time / ReplyLight.bloom)
        let halo = since.map { 1 - ReplyLight.smooth($0 / ReplyLight.haloGone) } ?? 1
        let centre = ReplyLight.centre
        // The stage's words (書いています once the text is under way) give
        // way to the reply's first point (or go with the orb, stopped or
        // written before it came).
        let wordsGone = (pointAt ?? leavingAt).map { max(time - $0, 0) }
        ZStack(alignment: .topLeading) {
            field(time: time, breath: breath, gather: gather, radius: AuroraOrbView.lightRadius * motion.size,
                  halo: halo, bloom: bloom, settle: settle)
            orb(time: time, size: motion.size)
                .opacity(motion.opacity)
                .offset(x: centre.x - AuroraOrbView.canvas / 2 + settle, y: centre.y - AuroraOrbView.canvas / 2)
            ReplyStageWords(time: time, writing: writingAt != nil, leavingSince: wordsGone, still: still)
                .offset(x: centre.x + ReplyLight.wordsGap, y: centre.y - ReplyStageWords.height / 2)
            if writingAt != nil {
                ReplyPreviewLine(preview: preview, version: version, now: now, width: width,
                                 leaving: since.map { $0 * ReplyLight.slowMotion }, still: still)
                    .offset(x: centre.x + ReplyLight.wordsGap, y: centre.y)
            }
        }
    }

    private var dark: Float { colorScheme == .dark ? 1 : 0 }

    private func orb(time: TimeInterval, size: Double) -> some View {
        Rectangle()
            .fill(ShaderLibrary.auroraOrb(.float2(AuroraOrbView.canvas, AuroraOrbView.canvas), .float(Float(time)),
                                          .float(dark), .float(Float(size))))
            .frame(width: AuroraOrbView.canvas, height: AuroraOrbView.canvas)
    }

    private func field(time: TimeInterval, breath: Double, gather: Double, radius: Double, halo: Double,
                       bloom: Double, settle: CGFloat) -> some View {
        let scale = ReplyLight.fieldScale
        let size = CGSize(width: ReplyLight.canvas.width / scale, height: ReplyLight.canvas.height / scale)
        let centre = CGPoint(x: (ReplyLight.centre.x + settle) / scale, y: ReplyLight.centre.y / scale)
        return Rectangle()
            .fill(ShaderLibrary.auroraField(.float2(size.width, size.height), .float2(centre.x, centre.y),
                                            .float(Float(scale)), .float(Float(time)), .float(dark),
                                            .float(Float(breath)), .float(Float(gather)), .float(Float(radius)),
                                            .float(Float(halo)), .float(Float(bloom))))
            .frame(width: size.width, height: size.height)
            // Drawn at a third of the size, then scaled up as an image.
            .drawingGroup()
            .scaleEffect(scale, anchor: .topLeading)
            .frame(width: ReplyLight.canvas.width, height: ReplyLight.canvas.height, alignment: .topLeading)
    }
}

/// 状態の一行: what the reply waits for (ChatStore.status, in
/// ReplyLight.words), in the web search line's quiet footnote, with the
/// orb's gold passing over it as the orb breathes out. It comes out of the
/// orb a moment after it, says 書いています once the text is under way and
/// goes back into the orb when the reply's first point comes (1.1.0
/// (302); in 301 as the text began). The only place the stage is said:
/// the developers' line under the conversation no longer says it too.
/// Read by nobody: the orb says 返信を書いています.
struct ReplyStageWords: View {
    static let height: CGFloat = 22
    /// The gold passes once each breath, as the orb breathes out.
    static let passStart = 0.2
    static let passLength = 1.7
    /// How much of the ink the words are drawn in.
    static let inkShare = 0.68

    let time: TimeInterval
    /// The reply's text is under way.
    let writing: Bool
    /// Seconds since the reply's first point; nil until it comes.
    let leavingSince: TimeInterval?
    let still: Bool

    @EnvironmentObject private var chats: ChatStore
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        if let words = ReplyLight.words(for: chats.status, writing: writing) {
            let shown = still ? 1 : ReplyLight.easeOut((time - 0.25) / 0.5)
            let gone = leavingSince.map { ReplyLight.easeOut($0 / 0.25) } ?? 0
            Text(words)
                .font(.footnote)
                // The ink at two thirds: read at a glance on paper and on
                // charcoal (contrast about 6:1 and 8:1), still quieter than
                // the reply. The system's secondary was too faint over the
                // light (1.1.0 (300)).
                .foregroundStyle(Theme.ink.opacity(ReplyStageWords.inkShare))
                // A new stage (考えています to じっくり考えています, and
                // to 書いています) comes in over the old one rather than
                // in one frame.
                .contentTransition(.opacity)
                .overlay { if !still { gold(words) } }
                .lineLimit(1)
                .fixedSize()
                .frame(height: Self.height)
                .opacity(shown * (1 - gone))
                .offset(x: -6 * CGFloat(1 - shown) - 6 * CGFloat(gone))
                .animation(still ? nil : .easeInOut(duration: 0.4), value: writing ? "書いています" : chats.status)
                .accessibilityHidden(true)
        }
    }

    /// The gold passing over the words, left to right, from the orb.
    private func gold(_ words: LocalizedStringKey) -> some View {
        let cycle = time.truncatingRemainder(dividingBy: AuroraOrbView.breathPeriod)
        let along = (cycle - Self.passStart) / Self.passLength
        let strength = along > 0 && along < 1 ? sin(Double.pi * along) : 0
        let at = -0.35 + 1.7 * along
        let tone = colorScheme == .dark ? Color(red: 1.0, green: 0.86, blue: 0.55) : Color(red: 0.80, green: 0.56, blue: 0.05)
        return Text(words)
            .font(.footnote)
            .foregroundStyle(tone)
            .mask {
                LinearGradient(stops: [.init(color: .clear, location: 0), .init(color: .white, location: 0.5),
                                       .init(color: .clear, location: 1)],
                               startPoint: UnitPoint(x: at - 0.35, y: 0.5), endPoint: UnitPoint(x: at + 0.35, y: 0.5))
            }
            .opacity(strength)
    }
}
