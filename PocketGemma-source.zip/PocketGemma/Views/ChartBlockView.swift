import SwiftUI
import UIKit
import Charts
import PocketCore

/// Sizes of a chart card at the default text size; they follow Dynamic Type.
enum ChartMetrics {
    /// The plot of upright bars and of a line, and a placeholder's body.
    static let plotHeight: CGFloat = 200
    /// A pie chart's ring.
    static let pieHeight: CGFloat = 180
    /// The room each bar laid on its side takes.
    static let rowHeight: CGFloat = 28
    /// Below bars laid on their side, for the value axis's labels.
    static let axisHeight: CGFloat = 24
    /// A legend of several series.
    static let legendHeight: CGFloat = 28
}

/// The app icon's rainbow as the Aurora Orb samples it, a little brighter in
/// dark mode, for charts. Blue leads, as the conversation's accent does.
enum ChartPalette {
    private static let light: [(Double, Double, Double)] = [
        (0.114, 0.498, 0.96), (0.125, 0.67, 0.365), (0.973, 0.753, 0.102), (0.945, 0.67, 0.157), (0.89, 0.36, 0.31),
    ]
    private static let dark: [(Double, Double, Double)] = [
        (0.18, 0.55, 1.0), (0.16, 0.74, 0.41), (0.99, 0.78, 0.15), (0.97, 0.70, 0.20), (0.94, 0.40, 0.34),
    ]

    private static func color(_ index: Int, depth: Double) -> Color {
        func ui(_ rgb: (Double, Double, Double)) -> UIColor {
            UIColor(red: rgb.0 * depth, green: rgb.1 * depth, blue: rgb.2 * depth, alpha: 1)
        }
        return Theme.adaptive(light: ui(light[index]), dark: ui(dark[index]))
    }

    static let blue = ChartPalette.color(0, depth: 1)
    /// Series of bars or lines: blue, orange, green and red (yellow is too
    /// faint as a line on white).
    static let series: [Color] = [0, 3, 1, 4].map { ChartPalette.color($0, depth: 1) }
    /// Slices around a pie from the top: the five colours, then the same
    /// deepened twice.
    static let slices: [Color] = [1.0, 0.72, 0.5].flatMap { depth in (0..<5).map { ChartPalette.color($0, depth: depth) } }
}

/// A chart card's heading: the kind of chart, its title and its unit.
struct ChartTitle: View {
    let kind: ChartSpec.Kind?
    let title: String
    let unit: String

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Image(systemName: Self.symbol(kind))
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(ChartPalette.blue)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: title.isEmpty ? (kind?.name ?? String(localized: "グラフ")) : title)
                    .font(.subheadline.weight(.semibold))
                    .fixedSize(horizontal: false, vertical: true)
                if !unit.isEmpty {
                    Text(verbatim: String(localized: "単位：\(unit)"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    static func symbol(_ kind: ChartSpec.Kind?) -> String {
        switch kind {
        case .bar?: return "chart.bar.fill"
        case .line?: return "chart.line.uptrend.xyaxis"
        case .pie?: return "chart.pie.fill"
        case nil: return "chart.bar.xaxis"
        }
    }
}

/// A chart in a reply (`ChartSpec`), drawn with Swift Charts on a card: its
/// title and unit, a line reading out the picked item (with none picked, the
/// largest bar, a line's first and last values or a pie's total), and the
/// plot. A tap picks an item; a long press offers copying the chart's data,
/// as a table or tab separated, or the whole reply. When the chart has just
/// been written, bars and lines grow in and a pie fades in, except with
/// Reduce Motion. The card keeps the reply's width: long labels are
/// shortened on the axes and given whole in the readout and to VoiceOver.
struct ChartBlockView: View {
    let chart: ChartSpec
    @State private var selected: Int?
    @State private var grown: Bool
    @State private var copied = false
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.markdownReplySource) private var reply
    @ScaledMetric(relativeTo: .body) private var plotHeight = ChartMetrics.plotHeight
    @ScaledMetric(relativeTo: .body) private var pieHeight = ChartMetrics.pieHeight
    @ScaledMetric(relativeTo: .body) private var rowHeight = ChartMetrics.rowHeight
    @ScaledMetric(relativeTo: .body) private var axisHeight = ChartMetrics.axisHeight
    @ScaledMetric(relativeTo: .body) private var legendHeight = ChartMetrics.legendHeight

    init(chart: ChartSpec, appears: Bool) {
        self.chart = chart
        _grown = State(initialValue: !appears)
    }

    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    /// How far the marks have grown in: 0 until the chart appears, then 1.
    private var progress: Double { grown ? 1 : 0 }

    var body: some View {
        RichCard {
            HStack(alignment: .top, spacing: 8) {
                ChartTitle(kind: chart.kind, title: chart.title, unit: chart.unit)
                Spacer(minLength: 8)
                copyButton
            }
            Text(verbatim: selected.map { chart.readout(at: $0) } ?? chart.overview)
                .font(.footnote.monospacedDigit())
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .truncationMode(.middle)
                .accessibilityIdentifier("chart-readout")
            plot
            if chart.kind == .pie { pieLegend }
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel(Text(verbatim: chart.spokenSummary))
        .accessibilityIdentifier("chart-block")
        // No `.contentShape(.contextMenuPreview, …)`: the reply's own menu
        // would take it as its preview (1.0.80).
        .contextMenu { menu }
        .sensoryFeedback(.selection, trigger: selected)
        .onAppear {
            guard !grown else { return }
            if reduceMotion { grown = true } else { withAnimation(.easeOut(duration: 0.6)) { grown = true } }
        }
    }

    // MARK: Plots

    @ViewBuilder private var plot: some View {
        switch chart.kind {
        case .bar:
            if chart.prefersColumns { columnChart } else { rowChart }
        case .line:
            lineChart
        case .pie:
            pieChart
        }
    }

    private var seriesColors: [Color] {
        chart.series.indices.map { ChartPalette.series[$0 % ChartPalette.series.count] }
    }

    /// Upright bars, a few with short labels.
    private var columnChart: some View {
        Chart {
            ForEach(chart.items.indices, id: \.self) { index in
                ForEach(chart.series.indices, id: \.self) { column in
                    bar(index, column, sideways: false)
                }
            }
        }
        .chartForegroundStyleScale(domain: chart.series, range: seriesColors)
        .chartLegend(chart.isSingleSeries ? .hidden : .visible)
        .chartYScale(domain: chart.valueRange(headroom: 0.12))
        .chartXAxis {
            AxisMarks { value in
                AxisValueLabel {
                    Text(verbatim: label(forKey: value.as(String.self), width: 10))
                }
            }
        }
        .chartYAxis {
            AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { value in
                AxisGridLine()
                AxisValueLabel {
                    Text(verbatim: value.as(Double.self).map { ChartSpec.axisLabel($0) } ?? "")
                }
            }
        }
        .chartOverlay { proxy in
            tapArea(proxy) { location, frame in
                Int((location.x - frame.minX) / max(frame.width, 1) * CGFloat(chart.items.count))
            }
        }
        .frame(height: plotHeight + (chart.isSingleSeries ? 0 : legendHeight))
    }

    /// Bars laid on their side, one row each: more items, or longer labels.
    private var rowChart: some View {
        Chart {
            ForEach(chart.items.indices, id: \.self) { index in
                ForEach(chart.series.indices, id: \.self) { column in
                    bar(index, column, sideways: true)
                }
            }
        }
        .chartForegroundStyleScale(domain: chart.series, range: seriesColors)
        .chartLegend(chart.isSingleSeries ? .hidden : .visible)
        .chartXScale(domain: chart.valueRange(headroom: 0.3))
        .chartYAxis {
            AxisMarks(position: .leading) { value in
                AxisValueLabel {
                    Text(verbatim: label(forKey: value.as(String.self), width: 12))
                }
            }
        }
        .chartXAxis {
            AxisMarks(position: .bottom, values: .automatic(desiredCount: 4)) { value in
                AxisGridLine()
                AxisValueLabel {
                    Text(verbatim: value.as(Double.self).map { ChartSpec.axisLabel($0) } ?? "")
                }
            }
        }
        .chartOverlay { proxy in
            tapArea(proxy) { location, frame in
                Int((location.y - frame.minY) / max(frame.height, 1) * CGFloat(chart.items.count))
            }
        }
        .frame(height: rowsHeight)
    }

    private var rowsHeight: CGFloat {
        let perItem = chart.isSingleSeries ? rowHeight : rowHeight * (0.5 + 0.45 * CGFloat(chart.series.count))
        return max(CGFloat(chart.items.count) * perItem, rowHeight * 3) + axisHeight
            + (chart.isSingleSeries ? 0 : legendHeight)
    }

    /// One bar of one series, on its side when `sideways`, with its value at
    /// its end when there is one series.
    @ChartContentBuilder private func bar(_ index: Int, _ column: Int, sideways: Bool) -> some ChartContent {
        if let value = chart.items[index].values[column] {
            let name = chart.series[column]
            (sideways ? BarMark(x: .value("値", value * progress), y: .value("項目", Self.key(index)))
                      : BarMark(x: .value("項目", Self.key(index)), y: .value("値", value * progress)))
                .foregroundStyle(by: .value("系列", name))
                .position(by: .value("系列", name), axis: sideways ? .vertical : .horizontal)
                .cornerRadius(4)
                .opacity(dimmed(index) ? 0.3 : 1)
                .annotation(position: annotationPosition(value, sideways: sideways), spacing: 4) {
                    Text(verbatim: chart.isSingleSeries ? chart.display(value) : "")
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.secondary)
                        .opacity(progress)
                }
                .accessibilityLabel(Text(verbatim: chart.spokenLabel(index, series: column)))
                .accessibilityValue(Text(verbatim: chart.display(value)))
        }
    }

    private func annotationPosition(_ value: Double, sideways: Bool) -> AnnotationPosition {
        sideways ? (value < 0 ? .leading : .trailing) : (value < 0 ? .bottom : .top)
    }

    /// A line through the items in order, one per series.
    private var lineChart: some View {
        let range = chart.valueRange(headroom: 0.08)
        return Chart {
            ForEach(chart.series.indices, id: \.self) { column in
                ForEach(chart.items.indices, id: \.self) { index in
                    linePoint(index, column, floor: range.lowerBound)
                }
            }
            if let selected {
                RuleMark(x: .value("項目", Double(selected)))
                    .foregroundStyle(Color.secondary.opacity(0.4))
                    .lineStyle(StrokeStyle(lineWidth: 1))
                    .accessibilityHidden(true)
            }
        }
        .chartForegroundStyleScale(domain: chart.series, range: seriesColors)
        .chartLegend(chart.isSingleSeries ? .hidden : .visible)
        .chartYScale(domain: range)
        .chartXScale(domain: lineDomain)
        .chartXAxis {
            AxisMarks(values: chart.tickIndices(maximum: 5).map { Double($0) }) { value in
                AxisGridLine()
                AxisValueLabel {
                    Text(verbatim: label(at: value.as(Double.self), width: 10))
                }
            }
        }
        .chartYAxis {
            AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { value in
                AxisGridLine()
                AxisValueLabel {
                    Text(verbatim: value.as(Double.self).map { ChartSpec.axisLabel($0) } ?? "")
                }
            }
        }
        .chartOverlay { proxy in
            tapArea(proxy) { location, frame in
                let span = lineDomain.upperBound - lineDomain.lowerBound
                let x = Double((location.x - frame.minX) / max(frame.width, 1)) * span + lineDomain.lowerBound
                return Int(x.rounded())
            }
        }
        .frame(height: plotHeight + (chart.isSingleSeries ? 0 : legendHeight))
    }

    private var lineDomain: ClosedRange<Double> {
        chart.items.count > 1 ? 0...Double(chart.items.count - 1) : -0.5...0.5
    }

    /// One item on one series' line: its point, and for a single series of
    /// values above zero the soft area under the line.
    @ChartContentBuilder private func linePoint(_ index: Int, _ column: Int, floor: Double) -> some ChartContent {
        if let value = chart.items[index].values[column] {
            let name = chart.series[column]
            let y = floor + (value - floor) * progress
            if chart.isSingleSeries && floor == 0 && value >= 0 {
                AreaMark(x: .value("項目", Double(index)), y: .value("値", y))
                    .foregroundStyle(LinearGradient(colors: [ChartPalette.blue.opacity(0.2), ChartPalette.blue.opacity(0.02)],
                                                    startPoint: .top, endPoint: .bottom))
                    .accessibilityHidden(true)
            }
            LineMark(x: .value("項目", Double(index)), y: .value("値", y), series: .value("系列", name))
                .foregroundStyle(by: .value("系列", name))
                .lineStyle(StrokeStyle(lineWidth: 2.5, lineCap: .round, lineJoin: .round))
                .accessibilityLabel(Text(verbatim: chart.spokenLabel(index, series: column)))
                .accessibilityValue(Text(verbatim: chart.display(value)))
            PointMark(x: .value("項目", Double(index)), y: .value("値", y))
                .foregroundStyle(by: .value("系列", name))
                .symbolSize(selected == index ? 64 : (chart.items.count <= 24 ? 24 : 0))
                .accessibilityHidden(true)
        }
    }

    /// A ring of slices with the total, or the picked slice's share, in its
    /// middle; the legend below lists every slice.
    private var pieChart: some View {
        Chart {
            ForEach(chart.items.indices, id: \.self) { index in
                slice(index)
            }
        }
        .chartLegend(.hidden)
        .chartBackground { proxy in
            GeometryReader { geometry in
                if let plot = proxy.plotFrame {
                    let frame = geometry[plot]
                    pieCenter
                        .frame(maxWidth: min(frame.width, frame.height) * 0.48)
                        .position(x: frame.midX, y: frame.midY)
                }
            }
        }
        .chartOverlay { proxy in
            tapArea(proxy) { location, frame in sliceIndex(at: location, in: frame) }
        }
        .frame(height: pieHeight)
        .scaleEffect(grown ? 1 : 0.9)
        .opacity(grown ? 1 : 0)
        // The legend's rows say each slice to VoiceOver.
        .accessibilityHidden(true)
    }

    @ChartContentBuilder private func slice(_ index: Int) -> some ChartContent {
        if let value = chart.items[index].values[0], value > 0 {
            SectorMark(angle: .value("値", value), innerRadius: .ratio(0.6),
                       outerRadius: .ratio(selected == index ? 1 : 0.93), angularInset: 1.2)
                .cornerRadius(3)
                .foregroundStyle(ChartPalette.slices[index % ChartPalette.slices.count])
                .opacity(dimmed(index) ? 0.45 : 1)
        }
    }

    private var pieCenter: some View {
        VStack(spacing: 2) {
            if let selected, chart.items.indices.contains(selected) {
                Text(verbatim: chart.items[selected].label)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(verbatim: chart.percentage(selected))
                    .font(.title3.weight(.semibold).monospacedDigit())
            } else {
                Text("合計")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(verbatim: chart.display(chart.total))
                    .font(.subheadline.weight(.semibold).monospacedDigit())
            }
        }
        .multilineTextAlignment(.center)
        .lineLimit(2)
        .minimumScaleFactor(0.6)
        .accessibilityHidden(true)
    }

    /// The slice under a tap: its angle from the top, clockwise, against the
    /// slices' running shares.
    private func sliceIndex(at location: CGPoint, in frame: CGRect) -> Int? {
        let dx = location.x - frame.midX
        let dy = location.y - frame.midY
        guard hypot(dx, dy) <= min(frame.width, frame.height) / 2 else { return nil }
        var angle = atan2(dx, -dy)
        if angle < 0 { angle += 2 * .pi }
        let target = Double(angle / (2 * .pi)) * chart.total
        var sum = 0.0
        for (index, item) in chart.items.enumerated() {
            guard let value = item.values[0], value > 0 else { continue }
            sum += value
            if target <= sum { return index }
        }
        return nil
    }

    private var pieLegend: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(chart.items.indices, id: \.self) { index in
                Button {
                    pick(index)
                } label: {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(ChartPalette.slices[index % ChartPalette.slices.count])
                            .frame(width: 9, height: 9)
                        Text(verbatim: chart.items[index].label)
                            .lineLimit(1)
                        Spacer(minLength: 8)
                        Text(verbatim: chart.display(chart.items[index].values[0]))
                            .monospacedDigit()
                            .foregroundStyle(.secondary)
                        Text(verbatim: chart.percentage(index))
                            .monospacedDigit()
                            .frame(minWidth: 48, alignment: .trailing)
                    }
                    .font(.footnote)
                    .opacity(dimmed(index) ? 0.5 : 1)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(Text(verbatim: chart.spokenItem(index)))
                .accessibilityAddTraits(selected == index ? .isSelected : [])
            }
        }
    }

    // MARK: Picking

    /// A clear layer over the plot that picks the item under a tap. A tap,
    /// not a drag, so the conversation still scrolls and the reply's menu
    /// still opens over the chart.
    private func tapArea(_ proxy: ChartProxy, item: @escaping (CGPoint, CGRect) -> Int?) -> some View {
        GeometryReader { geometry in
            Rectangle()
                .fill(Color.clear)
                .contentShape(Rectangle())
                .onTapGesture { location in
                    guard let plot = proxy.plotFrame else { return }
                    let index = item(location, geometry[plot])
                    pick(index.flatMap { chart.items.indices.contains($0) ? $0 : nil })
                }
        }
        .accessibilityHidden(true)
    }

    /// Picks an item, or lets go of it when it is picked already.
    private func pick(_ index: Int?) {
        let next = index == selected ? nil : index
        if reduceMotion {
            selected = next
        } else {
            withAnimation(.snappy(duration: 0.25)) { selected = next }
        }
    }

    private func dimmed(_ index: Int) -> Bool { selected != nil && selected != index }

    /// Items are plotted by their place, so two with the same label stay two.
    private static func key(_ index: Int) -> String { String(index) }

    private func label(forKey key: String?, width: Int) -> String {
        guard let key, let index = Int(key), chart.items.indices.contains(index) else { return "" }
        return ChartSpec.shortened(chart.items[index].label, width: width)
    }

    private func label(at position: Double?, width: Int) -> String {
        guard let position else { return "" }
        let index = Int(position.rounded())
        guard chart.items.indices.contains(index) else { return "" }
        return ChartSpec.shortened(chart.items[index].label, width: width)
    }

    // MARK: Copying

    private var copyButton: some View {
        Button {
            UIPasteboard.general.string = chart.markdown
            copied = true
        } label: {
            Image(systemName: copied ? "checkmark" : "doc.on.doc")
                .font(.footnote.weight(.medium))
                .contentTransition(.symbolEffect(.replace))
                .frame(width: 36, height: 36)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(.secondary)
        .padding(.vertical, -8)
        .accessibilityLabel(copied ? "コピーしました" : "データをコピー")
        .accessibilityIdentifier("chart-copy")
        .sensoryFeedback(.success, trigger: copied) { _, now in now }
        .task(id: copied) {
            guard copied else { return }
            try? await Task.sleep(for: .seconds(1.6))
            copied = false
        }
    }

    @ViewBuilder private var menu: some View {
        Button("データをコピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = chart.markdown }
        Button("タブ区切りでコピー", systemImage: "arrow.right.to.line") { UIPasteboard.general.string = chart.tabSeparated }
        if let reply {
            Divider()
            Button("返信全体をコピー", systemImage: "doc.plaintext") { UIPasteboard.general.string = reply.text }
        }
    }
}
