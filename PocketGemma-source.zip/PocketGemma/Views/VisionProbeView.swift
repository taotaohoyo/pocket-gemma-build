import SwiftUI
import PocketCore

struct VisionProbeView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var modelID = ModelSpec.e2b.id
    @State private var kind = VisionProbeKind.squareJPEG
    @State private var main = ExecutionBackend.gpu
    @State private var vision = ExecutionBackend.cpu
    @State private var kernel = VisionCPUImplementation.xnnpack
    @State private var visionTokens = 280
    @State private var contextTokens = 4096
    @State private var running = false
    @State private var result = ""
    /// E4B's chat photos take 70 or 140 image tokens (高速・深く); this probe
    /// runs 280 too, to record what each needs on the phone.
    private var chatBudgets: [Int] { (ModelSpec.find(modelID) ?? .e2b).chatVisualTokenBudgets }
    private var limitedInChat: Bool { chatBudgets != (ModelSpec.find(modelID) ?? .e2b).visualTokenBudgets }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("会話履歴と保存済み設定を変更せず、同じ公式モデルで検証します。MTPとThinkingは無効です。現在のAIのメモリを解放してから実行します。")
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("モデル", selection: $modelID) {
                        Text("Gemma 4 E2B").tag(ModelSpec.e2b.id)
                        Text("Gemma 4 E4B（検証用）").tag(ModelSpec.e4b.id)
                    }.accessibilityIdentifier("vision-probe-model")
                    Picker("検証経路", selection: $kind) {
                        ForEach(VisionProbeKind.allCases) { item in Text(item.title).tag(item) }
                    }.accessibilityIdentifier("vision-probe-kind")
                    if !kind.isComponent {
                        Picker("画像トークン", selection: $visionTokens) {
                            ForEach([70, 140, 280], id: \.self) { Text("\($0)").tag($0) }
                        }.accessibilityIdentifier("vision-probe-tokens")
                        // A smaller context keeps less room for the conversation,
                        // and leaves more of the address space for the image.
                        Picker("Context", selection: $contextTokens) {
                            ForEach([4096, 2048], id: \.self) { Text("\($0)").tag($0) }
                        }.accessibilityIdentifier("vision-probe-context")
                        Picker("言語", selection: $main) { ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) } }
                        Picker("画像", selection: $vision) { ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) } }
                        if vision == .cpu {
                            Picker("画像CPUの実行方式", selection: $kernel) {
                                ForEach(VisionCPUImplementation.allCases) { Text($0.title).tag($0) }
                            }
                        }
                        Text("同梱のJPEGを公式Swift APIへ直接渡します。写真選択、画像変換、アプリの添付処理を通しません。正方形は512×512、縦長は1200×1600です。")
                            .font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text("同じモデルからエンコーダーまたはアダプターのバイト列をそのまま取り出し、合成テンソルで単独実行します。組み込みCPUではXNNPACKを使いません。これは画像の内容に回答するテストではありません。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.disabled(running).fieluaFormSection()
                Section {
                    if limitedInChat {
                        Text("このモデルの写真は、チャットでは画像トークン\(chatBudgets.map(String.init).joined(separator: "・"))で使います。ここではほかの設定も実行して、各段階のメモリとアドレス空間を記録します。失敗したら、次の検証の前にアプリを完全に終了してから開き直してください。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Button(running ? "検証を実行しています…" : "この構成で1回検証") { run() }
                        .disabled(running || chats.isGenerating).accessibilityIdentifier("run-vision-probe")
                    if running { ProgressView() }
                    if !result.isEmpty { Text(result).font(.subheadline).textSelection(.enabled) }
                    Text("XNNPACKの失敗を確認したら、同じコンポーネントの組み込みCPUと比較します。組み込みCPUの結果は、そのまま会話APIの成功を意味しません。")
                        .font(.caption).foregroundStyle(.secondary)
                    ShareLink(item: InferenceDiagnostic.historyURL) { Label("比較結果と診断を共有", systemImage: "square.and.arrow.up") }
                }.fieluaFormSection()
            }
            .fieluaForm()
            .navigationTitle("画像の最小再現テスト").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("閉じる", systemImage: "xmark", role: .close) { dismiss() }.disabled(running) } }
        }.interactiveDismissDisabled(running)
    }
    private func run() {
        #if POCKET_PREVIEW
        result = "UI検証用アプリではネイティブ推論を実行しません。"
        #else
        guard let spec = ModelSpec.find(modelID) else { return }
        running = true; result = ""
        Task {
            defer { running = false }
            do {
                result = try await chats.runVisionProbe(model: spec, kind: kind, main: main, vision: vision, kernel: kernel,
                                                        visionTokens: visionTokens, contextTokens: contextTokens)
            }
            catch { result = "検証失敗：\(error.localizedDescription)\n比較結果と診断を共有して、失敗段階を確認してください。" }
        }
        #endif
    }
}
