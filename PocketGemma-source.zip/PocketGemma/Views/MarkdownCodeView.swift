import SwiftUI
import UIKit
import PocketCore

/// A fenced code block: the language and a copy button above code colored
/// by `SyntaxHighlighter`. Lines never wrap; a wide block scrolls sideways.
/// Long finished code shows its first lines until the reader expands it.
struct MarkdownCodeView: View {
    let language: String?
    let code: String
    let streaming: Bool
    @State private var copied = false
    @State private var expanded = false

    private var lineCount: Int { code.utf8.reduce(1) { $1 == 0x0A ? $0 + 1 : $0 } }

    var body: some View {
        let lines = lineCount
        let collapsible = !streaming && lines > MarkdownMetrics.codeLinesCollapsed
        let shown = collapsible && !expanded ? Self.prefix(code, lines: MarkdownMetrics.codeLinesShown) : code
        VStack(alignment: .leading, spacing: 0) {
            header
            Rectangle().fill(Theme.markdownLine.opacity(0.6)).frame(height: 0.5)
            let text = Text(MarkdownCodeColors.highlighted(shown, language: language, remember: !streaming))
                .font(.system(.footnote, design: .monospaced))
                .lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
            ViewThatFits(in: .horizontal) {
                text.padding(.horizontal, 12)
                ScrollView(.horizontal, showsIndicators: false) {
                    text.fixedSize(horizontal: true, vertical: false).padding(.horizontal, 12)
                }
                .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            }
            .padding(.vertical, 10)
            if collapsible {
                Rectangle().fill(Theme.markdownLine.opacity(0.6)).frame(height: 0.5)
                Button {
                    withAnimation(.snappy(duration: 0.3)) { expanded.toggle() }
                } label: {
                    Text(expanded ? "折りたたむ" : "残り\(lines - MarkdownMetrics.codeLinesShown)行を表示")
                        .font(.footnote.weight(.medium))
                        .frame(maxWidth: .infinity, minHeight: 36)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(Theme.accent)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.codeBackground)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(Theme.markdownLine.opacity(0.5), lineWidth: 0.5)
        }
    }

    private var header: some View {
        HStack(spacing: 8) {
            Text(verbatim: SyntaxHighlighter.displayName(for: language) ?? language ?? "コード")
                .font(.caption.weight(.medium))
                .foregroundStyle(.secondary)
                .lineLimit(1)
            Spacer(minLength: 8)
            Button {
                UIPasteboard.general.string = code
                copied = true
            } label: {
                Label(copied ? "コピーしました" : "コピー", systemImage: copied ? "checkmark" : "doc.on.doc")
                    .font(.caption.weight(.medium))
                    .contentTransition(.symbolEffect(.replace))
                    .padding(.horizontal, 12)
                    .frame(minHeight: 36)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .foregroundStyle(.secondary)
            .accessibilityLabel(copied ? "コピーしました" : "コードをコピー")
            .accessibilityIdentifier("code-copy")
            .sensoryFeedback(.success, trigger: copied) { _, now in now }
            .task(id: copied) {
                guard copied else { return }
                try? await Task.sleep(for: .seconds(1.6))
                copied = false
            }
        }
        .padding(.leading, 12)
        .background(Theme.codeHeader)
    }

    static func prefix(_ code: String, lines: Int) -> String {
        var remaining = lines
        var end = code.endIndex
        for index in code.indices where code[index] == "\n" {
            remaining -= 1
            if remaining == 0 { end = index; break }
        }
        return String(code[..<end])
    }
}

/// Code colors close to Xcode's default themes, light and dark.
enum MarkdownCodeColors {
    private final class Entry {
        let text: AttributedString
        init(_ text: AttributedString) { self.text = text }
    }

    private static let cache: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 200
        return cache
    }()

    /// `remember` keeps finished code; streaming code changes every token.
    static func highlighted(_ code: String, language: String?, remember: Bool) -> AttributedString {
        let key = "\(language ?? "")\u{0}\(code)" as NSString
        if remember, let entry = cache.object(forKey: key) { return entry.text }
        var result = AttributedString()
        for token in SyntaxHighlighter.tokens(code, language: language) {
            var piece = AttributedString(token.text)
            if let color = color(token.kind) { piece.foregroundColor = color }
            if token.kind == .heading { piece.inlinePresentationIntent = .stronglyEmphasized }
            result.append(piece)
        }
        if remember { cache.setObject(Entry(result), forKey: key) }
        return result
    }

    private static func color(_ kind: CodeTokenKind) -> Color? {
        switch kind {
        case .plain: return nil
        case .keyword: return keyword
        case .type: return type
        case .string: return string
        case .number: return number
        case .comment: return comment
        case .function: return function
        case .attribute: return attribute
        case .tag: return tag
        case .property: return property
        case .inserted: return inserted
        case .deleted: return deleted
        case .heading: return heading
        }
    }

    private static func rgb(_ light: UInt32, _ dark: UInt32) -> Color {
        func color(_ value: UInt32) -> UIColor {
            UIColor(red: CGFloat((value >> 16) & 0xFF) / 255, green: CGFloat((value >> 8) & 0xFF) / 255,
                    blue: CGFloat(value & 0xFF) / 255, alpha: 1)
        }
        return Theme.adaptive(light: color(light), dark: color(dark))
    }

    private static let keyword = rgb(0x9B2393, 0xFF7AB2)
    private static let type = rgb(0x0B4F79, 0x5DD8FF)
    private static let string = rgb(0xC41A16, 0xFF8170)
    private static let number = rgb(0x1C00CF, 0xD9C97C)
    private static let comment = rgb(0x5D6C79, 0x7F8C98)
    private static let function = rgb(0x326D74, 0x67B7A4)
    private static let attribute = rgb(0x815F03, 0xCC9768)
    private static let tag = rgb(0x881280, 0xFF7AB2)
    private static let property = rgb(0x3E6D9C, 0xA0C4FF)
    private static let inserted = rgb(0x1E7B34, 0x7DD87F)
    private static let deleted = rgb(0xB3261E, 0xFF6B68)
    private static let heading = rgb(0x0F68A0, 0x6BDFFF)
}
