import AVFoundation
import CoreGraphics
import SoundAnalysis
import PocketCore

/// Takes a video apart on import (1.1.0 (194)), with no model: its scenes
/// are picked from small frames looked at across it (VideoScenePicker),
/// and its sound's parts that are not silent are kept as 16 kHz WAV files
/// (SoundParts), each named by the system's sound classifier. The model
/// reads them when the message is sent (GemmaService). Nothing is held
/// whole in memory: frames are looked at one at a time, and the sound is
/// streamed to a file and read back a part at a time.
enum VideoImport {
    static let sampleRate = 16_000.0

    /// Fills the attachment's scenes, sound and note from its video at
    /// `url`. `hearing` is whether the chosen model can write the sound down
    /// on this launch (VideoSound); when it can't, the sound is not kept.
    /// Sound that can't be read leaves the video without it, not unread.
    static func take(_ url: URL, into attachment: inout ChatAttachment, hearing: Bool) async throws {
        let asset = AVURLAsset(url: url)
        let tracks = try await asset.loadTracks(withMediaType: .video)
        guard !tracks.isEmpty else { throw AttachmentStorage.ImportError.unreadable }
        let duration = try await asset.load(.duration).seconds
        guard duration.isFinite, duration > 0 else { throw AttachmentStorage.ImportError.unreadable }
        attachment.duration = duration
        let prefix = attachment.id.uuidString
        let looked = try await scenes(of: asset, duration: duration, prefix: prefix, into: &attachment)
        var analysis = VideoAnalysis(duration: duration, scenes: looked.scenes, framesLooked: looked.frames, sound: .none)
        attachment.video = analysis
        analysis = await sound(of: asset, analysis: analysis, prefix: prefix)
        if !hearing, analysis.sound == .parts {
            remove(analysis.audioNames)
            analysis.parts = analysis.parts.map { VideoAnalysis.SoundPart(start: $0.start, end: $0.end, sounds: $0.sounds) }
            analysis.soundSkipped = .memory
        }
        attachment.video = analysis
        attachment.note = VideoDigest.note(analysis, sent: false)
    }

    // MARK: Scenes

    private static func scenes(of asset: AVAsset, duration: Double, prefix: String,
                               into attachment: inout ChatAttachment) async throws -> (scenes: [VideoAnalysis.Scene], frames: Int) {
        let times = VideoScenePicker.frameTimes(duration: duration)
        let step = times.count > 1 ? times[1] - times[0] : duration
        // Small and near each time, not exactly: the nearest frame decodes
        // fast, and a cut still shows.
        let small = AVAssetImageGenerator(asset: asset)
        small.appliesPreferredTrackTransform = true
        small.maximumSize = CGSize(width: 96, height: 96)
        let near = CMTime(seconds: max(0.05, step / 2), preferredTimescale: 600)
        small.requestedTimeToleranceBefore = near
        small.requestedTimeToleranceAfter = near
        var looked: [(time: Double, feature: [Float])] = []
        for time in times {
            try Task.checkCancellation()
            guard let result = try? await small.image(at: CMTime(seconds: time, preferredTimescale: 600)) else { continue }
            let actual = result.actualTime.seconds
            let at = actual.isFinite ? min(max(0, actual), duration) : time
            if let last = looked.last, abs(last.time - at) < 0.01 { continue }
            looked.append((at, feature(result.image)))
        }
        guard !looked.isEmpty else { throw AttachmentStorage.ImportError.unreadable }
        let picked = VideoScenePicker.pick(features: looked.map(\.feature), count: VideoScenePicker.sceneCount(duration: duration))
        // The photos the model gets (768 pixels on the long side), at the
        // frames looked at.
        let full = AVAssetImageGenerator(asset: asset)
        full.appliesPreferredTrackTransform = true
        full.maximumSize = CGSize(width: 768, height: 768)
        let exact = CMTime(seconds: min(0.1, step / 4), preferredTimescale: 600)
        full.requestedTimeToleranceBefore = exact
        full.requestedTimeToleranceAfter = exact
        var scenes: [VideoAnalysis.Scene] = []
        var previous: [Float]?
        for index in picked {
            try Task.checkCancellation()
            let frame = looked[index]
            let result = try await full.image(at: CMTime(seconds: frame.time, preferredTimescale: 600))
            let name = prefix + "-frame-\(scenes.count).jpg"
            try AttachmentStorage.writeJPEG(result.image, name: name)
            attachment.imageNames.append(name)
            scenes.append(VideoAnalysis.Scene(time: frame.time, image: name,
                                              change: previous.map { VideoScenePicker.difference($0, frame.feature) } ?? 0))
            previous = frame.feature
        }
        attachment.thumbnailName = attachment.imageNames.first
        return (scenes, looked.count)
    }

    /// A frame's 8 × 8 picture, as red, green and blue from 0 to 1.
    private static func feature(_ image: CGImage) -> [Float] {
        let side = 8
        var pixels = [UInt8](repeating: 0, count: side * side * 4)
        let drawn = pixels.withUnsafeMutableBytes { raw -> Bool in
            guard let context = CGContext(data: raw.baseAddress, width: side, height: side, bitsPerComponent: 8,
                                          bytesPerRow: side * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { return false }
            context.interpolationQuality = .medium
            context.draw(image, in: CGRect(x: 0, y: 0, width: side, height: side))
            return true
        }
        guard drawn else { return [] }
        var result: [Float] = []
        result.reserveCapacity(side * side * 3)
        for pixel in 0..<(side * side) {
            for channel in 0..<3 { result.append(Float(pixels[pixel * 4 + channel]) / 255) }
        }
        return result
    }

    // MARK: Sound

    /// The analysis with its sound: none, silent, or its parts as files.
    private static func sound(of asset: AVAsset, analysis: VideoAnalysis, prefix: String) async -> VideoAnalysis {
        var analysis = analysis
        guard let tracks = try? await asset.loadTracks(withMediaType: .audio), !tracks.isEmpty else { return analysis }
        // One track: an iPhone's spatial audio comes with a stereo track of
        // the same sound, and mixed they would double it.
        var track = tracks[0]
        for candidate in tracks {
            if (try? await candidate.load(.isEnabled)) == true { track = candidate; break }
        }
        let taken = min(analysis.duration, SoundParts.limit)
        analysis.soundTaken = taken
        let pcm = FileManager.default.temporaryDirectory.appendingPathComponent(prefix + "-sound.pcm")
        defer { try? FileManager.default.removeItem(at: pcm) }
        var written: [String] = []
        do {
            let energies = try read(track, of: asset, seconds: taken, to: pcm)
            let spans = SoundParts.split(energies)
            guard !spans.isEmpty else { analysis.sound = .silent; return analysis }
            let handle = try FileHandle(forReadingFrom: pcm)
            defer { try? handle.close() }
            var parts: [VideoAnalysis.SoundPart] = []
            for span in spans {
                try Task.checkCancellation()
                let name = prefix + "-sound-\(parts.count).wav"
                guard let url = AttachmentStorage.url(name) else { throw AttachmentStorage.ImportError.unreadable }
                let from = Int(span.start * sampleRate) * 2, to = Int(span.end * sampleRate) * 2
                try handle.seek(toOffset: UInt64(from))
                let samples = try handle.read(upToCount: to - from) ?? Data()
                guard !samples.isEmpty else { continue }
                try wav(samples).write(to: url, options: .atomic)
                written.append(name)
                parts.append(VideoAnalysis.SoundPart(start: span.start, end: span.end, audio: name, sounds: classify(url)))
            }
            guard !parts.isEmpty else { analysis.sound = .silent; return analysis }
            analysis.sound = .parts
            analysis.parts = parts
        } catch {
            remove(written)
            analysis.sound = .parts
            analysis.parts = []
            analysis.soundSkipped = .failed
        }
        return analysis
    }

    /// Streams the first `seconds` of the track to `file` as 16 kHz mono
    /// 16-bit samples, and returns its level every `SoundParts.frame`.
    private static func read(_ track: AVAssetTrack, of asset: AVAsset, seconds: Double, to file: URL) throws -> [Float] {
        let reader = try AVAssetReader(asset: asset)
        reader.timeRange = CMTimeRange(start: .zero, duration: CMTime(seconds: seconds, preferredTimescale: 600))
        let output = AVAssetReaderAudioMixOutput(audioTracks: [track], audioSettings: [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVSampleRateKey: sampleRate,
            AVNumberOfChannelsKey: 1,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false,
            AVLinearPCMIsNonInterleaved: false
        ])
        guard reader.canAdd(output) else { throw AttachmentStorage.ImportError.unreadable }
        reader.add(output)
        guard reader.startReading() else { throw reader.error ?? AttachmentStorage.ImportError.unreadable }
        defer { reader.cancelReading() }
        guard FileManager.default.createFile(atPath: file.path, contents: nil) else { throw AttachmentStorage.ImportError.unreadable }
        let handle = try FileHandle(forWritingTo: file)
        defer { try? handle.close() }
        let window = Int(SoundParts.frame * sampleRate), limit = Int(seconds * sampleRate)
        var energies: [Float] = []
        var sum = 0.0, count = 0, total = 0
        while total < limit, let buffer = output.copyNextSampleBuffer() {
            guard let block = CMSampleBufferGetDataBuffer(buffer) else { continue }
            let length = CMBlockBufferGetDataLength(block)
            guard length > 0 else { continue }
            var data = Data(count: length)
            let status = data.withUnsafeMutableBytes { raw in
                CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: length, destination: raw.baseAddress!)
            }
            guard status == kCMBlockBufferNoErr else { throw AttachmentStorage.ImportError.unreadable }
            let samples = min(length / 2, limit - total)
            data.withUnsafeBytes { raw in
                let values = raw.bindMemory(to: Int16.self)
                for index in 0..<samples {
                    let value = Double(values[index]) / 32_768
                    sum += value * value
                    count += 1
                    if count == window {
                        energies.append(Float((sum / Double(window)).squareRoot()))
                        sum = 0; count = 0
                    }
                }
            }
            try handle.write(contentsOf: data.prefix(samples * 2))
            total += samples
        }
        if reader.status == .failed { throw reader.error ?? AttachmentStorage.ImportError.unreadable }
        if count >= window / 2 { energies.append(Float((sum / Double(count)).squareRoot())) }
        return energies
    }

    /// 16 kHz mono 16-bit samples as a WAV file.
    static func wav(_ samples: Data) -> Data {
        var data = Data()
        func append<T: FixedWidthInteger>(_ value: T) { withUnsafeBytes(of: value.littleEndian) { data.append(contentsOf: $0) } }
        data.append(contentsOf: Array("RIFF".utf8)); append(UInt32(36 + samples.count))
        data.append(contentsOf: Array("WAVEfmt ".utf8)); append(UInt32(16)); append(UInt16(1)); append(UInt16(1))
        append(UInt32(sampleRate)); append(UInt32(sampleRate * 2)); append(UInt16(2)); append(UInt16(16))
        data.append(contentsOf: Array("data".utf8)); append(UInt32(samples.count))
        data.append(samples)
        return data
    }

    /// The sounds the system's classifier is fairly sure of in a part,
    /// likeliest first, at most four; nil where it can't run.
    static func classify(_ url: URL) -> [String]? {
        guard let analyzer = try? SNAudioFileAnalyzer(url: url),
              let request = try? SNClassifySoundRequest(classifierIdentifier: .version1) else { return nil }
        let collector = SoundCollector()
        guard (try? analyzer.add(request, withObserver: collector)) != nil else { return nil }
        analyzer.analyze()
        return collector.failed ? nil : collector.labels
    }

    private static func remove(_ names: [String]) {
        for name in names { if let url = AttachmentStorage.url(name) { try? FileManager.default.removeItem(at: url) } }
    }
}

/// The classifier's results for one file: each sound's highest confidence.
private final class SoundCollector: NSObject, SNResultsObserving {
    private var best: [String: Double] = [:]
    private(set) var failed = false
    /// Sure enough to name. A synthesized voice scored speech 0.85-0.95,
    /// a melody synthesizer 0.85 and beeps beep 0.94, but the voice also
    /// scored insect up to 0.63 (run 40257613957).
    static let confidence = 0.75
    func request(_ request: SNRequest, didProduce result: SNResult) {
        guard let result = result as? SNClassificationResult else { return }
        for classification in result.classifications.prefix(3) where classification.confidence >= Self.confidence {
            best[classification.identifier] = max(best[classification.identifier] ?? 0, classification.confidence)
        }
    }
    func request(_ request: SNRequest, didFailWithError error: Error) { failed = true }
    var labels: [String] {
        best.sorted { $0.value > $1.value }.prefix(4).map { $0.key.replacingOccurrences(of: "_", with: " ") }
    }
}
