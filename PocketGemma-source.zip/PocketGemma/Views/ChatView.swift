import SwiftUI
import UIKit
import PocketCore
import UniformTypeIdentifiers

struct ChatView: View {
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @ScaledMetric(relativeTo: .body) private var menuRowHeight: CGFloat = 46
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    @State private var draft = ""
    @StateObject private var composerInput = ComposerInput()
    @State private var showModel = false
    @State private var showActions = false
    @StateObject private var scrollPolicy = ChatScrollState()
    @State private var viewportHeight: CGFloat = 800
    @State private var arrivingMessageID: UUID?
    @State private var arrivalCleanup: Task<Void, Never>?
    @State private var scrollTask: Task<Void, Never>?
    @State private var attachments: [ChatAttachment] = []
    @State private var showPhotos = false
    @State private var expandedPhotos = false
    @State private var photoPickerTicket = UUID()
    @State private var showFiles = false
    @State private var showAttachmentGuide = false
    @State private var draftToRestore: String?
    @State private var pickerContext: AttachmentImportContext?
    @State private var isImporting = false
    @State private var importTask: Task<Void, Never>?
    @State private var importID: UUID?
    @State private var timestampReveal: CGFloat = 0
    @State private var latestRequest = 0
    /// The jump control's glass stays mounted while it sinks into the field;
    /// insertion/removal transitions do not run inside the composer bar.
    @State private var jumpPresent = false
    @State private var jumpRaised = false
    @State private var jumpSettle: Task<Void, Never>?
    @State private var inputTopGlobal: CGFloat = 0
    @State private var composerTopGlobal: CGFloat = 0
    /// Follows the latest message by scrolling to the bottom edge of the
    /// valid scroll range. A chat shorter than the screen has no range, so it
    /// cannot be pushed down; aligning the "bottom" row to the viewport edge
    /// did exactly that and the rows dropped mid-reply.
    @State private var scrollPosition = ScrollPosition(edge: .bottom)
    @Namespace private var composerGlass
    @Namespace private var actionGlass
    // The native UITextView owns first responder status. A SwiftUI FocusState
    // without a .focused view can reset itself while its UIKit delegate is
    // beginning an edit, dismissing the keyboard during typing.
    @State private var inputFocused = false
    private var attachmentPolicy: ModelAttachmentPolicy { ModelAttachmentPolicy(model: chats.currentModel) }

    private var canSend: Bool {
        model.isInstalled(chats.currentModel) && !isImporting
            && (!draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty)
    }
    private var datedMessages: Set<UUID> {
        var result: Set<UUID> = []
        var previous: Date?
        for message in chats.messages {
            if previous == nil || message.createdAt.timeIntervalSince(previous!) > 300 { result.insert(message.id) }
            previous = message.createdAt
        }
        return result
    }

    private var tailedMessages: Set<UUID> {
        var result: Set<UUID> = []
        for (index, message) in chats.messages.enumerated() {
            let next = chats.messages.dropFirst(index + 1).first
            if next == nil || next?.role != message.role
                || (next?.createdAt.timeIntervalSince(message.createdAt) ?? 0) > 60 {
                result.insert(message.id)
            }
        }
        return result
    }

    var body: some View {
        ChatGlassGroup(spacing: 14) {
        conversation
            .background(Theme.chatBackground)
            // Tap outside closes the plus menu. It sits on the conversation,
            // under the composer inset that draws the menu itself.
            .overlay {
                if showActions {
                    Color.black.opacity(0.03).ignoresSafeArea()
                        .contentShape(Rectangle())
                        .onTapGesture { closeActions() }
                        .accessibilityHidden(true)
                        .transition(.opacity)
                }
            }
            .chatBars(top: {
                header.accessibilityHidden(showActions)
                    .background { ChatChromeBackdrop(edge: .top) }
            }, bottom: {
                // No opaque band: the conversation scrolls behind the glass
                // controls and the system's soft scroll edge effect keeps the
                // text legible, as in Messages on iOS 26.
                composer
            })
            // The visible jump control is drawn inside the composer's glass
            // container (so it can merge into the field), but it sits above
            // the bar's bounds where the bar cannot receive touches. This
            // transparent target at the same spot owns the tap and VoiceOver.
            .overlayPreferenceValue(ComposerBoundsKey.self) { bounds in
                GeometryReader { overlay in
                    if let bounds, scrollPolicy.showsJumpButton && !showActions {
                        Button { scrollPolicy.requestLatest(); latestRequest += 1 } label: {
                            Color.clear.frame(width: ChatMetrics.control, height: ChatMetrics.control)
                                .contentShape(Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("最新のメッセージへ移動").accessibilityIdentifier("chat-jump-latest")
                        .position(x: overlay.size.width - ChatMetrics.gutter - ChatMetrics.control / 2,
                                  y: overlay[bounds].minY + max(0, inputTopGlobal - composerTopGlobal)
                                     - jumpLift - ChatMetrics.control / 2)
                    }
                }
            }
            .background { GeometryReader { area in
                Color.clear.preference(key: ChatViewportHeightKey.self, value: area.size.height)
            } }
            .onPreferenceChange(ChatViewportHeightKey.self) { if abs(viewportHeight - $0) > 1 { viewportHeight = $0 } }
            .toolbar(.hidden, for: .navigationBar)
            .toolbar(.hidden, for: .bottomBar)
            .background { ChatBackSwipe().frame(width: 0, height: 0) }
            .tint(Theme.accent)
            .sheet(isPresented: $showModel) { ModelView() }
            .fileImporter(isPresented: $showFiles,
                          allowedContentTypes: fileImportTypes, allowsMultipleSelection: true) { result in
                do {
                    let urls = try result.get()
                    guard pickerContext?.matches(threadID: chats.selectedID, modelID: chats.currentModel.id) == true else { return }
                    importAttachments(urls, temporary: false)
                }
                catch { chats.error = error.localizedDescription }
            }
            .onChange(of: chats.selectedID) { _, _ in
                composerInput.clearAndDismiss()
                draft = draftToRestore ?? ""; draftToRestore = nil
                clearTransientState()
                scrollPolicy.requestLatest()
            }
            .onChange(of: chats.currentModel.id) { _, _ in
                showPhotos = false; showFiles = false
                clearTransientState()
            }
            .onDisappear { clearTransientState() }
            .confirmationDialog("添付について", isPresented: $showAttachmentGuide, titleVisibility: .visible) {
                if !attachmentPolicy.allowsImages {
                    Button(model.isInstalled(.e2b) ? "E2Bで新しい会話を開く" : "E2Bを準備する") { switchToE2B() }
                        .disabled(chats.isGenerating)
                }
                Button("閉じる", role: .cancel) {}
            } message: {
                Text(attachmentPolicy.guidance + (!attachmentPolicy.allowsImages
                    ? "\n切り替えると入力中の文章を引き継ぎます。元の会話は履歴に残ります。" : ""))
            }
            .alert("お知らせ", isPresented: Binding(get: { chats.error != nil || (!showModel && model.error != nil) },
                set: { if !$0 { chats.error = nil; model.error = nil } })) {
                Button("閉じる") { chats.error = nil; model.error = nil }
            } message: { Text(chats.error ?? model.error ?? "") }
        }
    }

    /// What the file picker offers. Documents are converted to text on
    /// device (AttachmentStorage), so the model only receives plain text.
    private var fileImportTypes: [UTType] {
        var types: [UTType] = attachmentPolicy.allowsImages ? [.image, .plainText] : [.plainText]
        if attachmentPolicy.allowsDocuments {
            types += [.pdf, .text, .rtf, .json, .xml, .html, .commaSeparatedText,
                      .tabSeparatedText, .yaml, .sourceCode]
            if let word = UTType("org.openxmlformats.wordprocessingml.document") { types.append(word) }
        }
        return types
    }

    private var header: some View {
        ChatGlassGroup {
            ZStack(alignment: .topLeading) {
                ChatCircleButton(action: {
                    inputFocused = false
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: ChatMetrics.icon, weight: .medium)).foregroundStyle(.primary)
                }
                .accessibilityLabel("会話一覧を開く")
                .padding(.leading, ChatMetrics.gutter).padding(.top, 8)

                Button {
                    inputFocused = false
                    showModel = true
                } label: {
                    VStack(spacing: 4) {
                        ModelMark(model: chats.currentModel, size: 40)
                        HStack(spacing: 3) {
                            Text(chats.currentModel.family).font(.caption.weight(.semibold))
                            Image(systemName: "chevron.right").font(.system(size: 8, weight: .semibold))
                                .foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 9).padding(.vertical, 4)
                        .chatGlass(in: Capsule())
                    }
                    .foregroundStyle(.primary).frame(maxWidth: .infinity)
                    .padding(.top, 6).padding(.bottom, 8).contentShape(Rectangle())
                }
                .accessibilityLabel("モデルと設定を開く").accessibilityIdentifier("chat-model-settings")
                .padding(.horizontal, 74)
            }
            .buttonStyle(.plain)
        }
    }

    private var conversation: some View {
        let dates = datedMessages
        let tails = tailedMessages
        return GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 8) {
                        Text(chats.currentModel.name)
                            .font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity).padding(.top, 14).padding(.bottom, 8)
                        if chats.messages.isEmpty {
                            if !model.isInstalled(chats.currentModel) { preparation }
                            else {
                                Text("メッセージを送って会話を始めましょう")
                                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                                    .padding(.horizontal, 26).padding(.top, 8)
                            }
                        }
                        ForEach(chats.messages) { message in
                            // One stable, measurable row per message. Returning
                            // a conditional timestamp beside the bubble made
                            // the lazy stack repeatedly enumerate variable
                            // subview lists while estimating long histories.
                            VStack(spacing: 8) {
                            if dates.contains(message.id) { timestamp(message.createdAt) }
                            MessageView(message: message, oppositeInset: dynamicTypeSize.isAccessibilitySize
                                    ? max(20, geometry.size.width * 0.08) : max(56, geometry.size.width * 0.20),
                                        hasTail: tails.contains(message.id),
                                        animateArrival: arrivingMessageID == message.id && !reduceMotion,
                                        timestampReveal: timestampReveal)
                                .equatable()
                                .recordChatLayout(message.id)
                                .modifier(BubbleScrollSpring(active: scrollPolicy.isUserScrolling, reducedMotion: reduceMotion))
                            }
                                .frame(maxWidth: .infinity)
                                .id(message.id)
                                .transition(message.role == .assistant && !reduceMotion
                                    ? .opacity : .identity)
                        }
                        if chats.isGenerating {
                            Text(chats.status).font(.caption2).foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 20).padding(.top, 2)
                        }
                        // The target belongs to the same lazy layout as the
                        // messages. An outer eager stack turned estimated
                        // content height into a second scroll target layout.
                        Color.clear.frame(height: 1).id("bottom")
                    }
                    .padding(.horizontal, ChatMetrics.gutter).padding(.bottom, 10)
                }
                .scrollPosition($scrollPosition)
                .coordinateSpace(name: "conversation")
                .scrollDismissesKeyboard(.interactively)
                .chatScrollEdges(customChrome: true)
                .scrollBounceBehavior(.always)
                .modifier(ChatScrollAnchoring(followsLatest: scrollPolicy.shouldFollowStream))
                .modifier(ChatScrollObserver(onDistance: { scrollPolicy.observe(distanceFromBottom: $0) },
                    onUserScrolling: {
                        scrollPolicy.setUserScrolling($0)
                        if $0 { scrollTask?.cancel(); scrollTask = nil }
                    }, onLayout: { scheduleBottom(proxy, animated: true) }))
                .modifier(ChatTimestampReveal(onChanged: { timestampReveal = $0 }, onEnded: {
                    withAnimation(reduceMotion ? nil : ChatMotion.resize) { timestampReveal = 0 }
                }))
                .onChange(of: chats.messages.last?.text) { _, _ in
                    scheduleBottom(proxy)
                }
                .onChange(of: chats.messages.count) { _, _ in
                    scheduleBottom(proxy)
                }
                .onChange(of: chats.isGenerating) { _, generating in
                    if !generating { scheduleBottom(proxy) }
                }
                .onChange(of: chats.selectedID) { _, _ in scrollPosition.scrollTo(edge: .bottom) }
                .onChange(of: latestRequest) { _, _ in scheduleBottom(proxy, force: true, animated: true) }
                .onChange(of: inputFocused) { _, focused in
                    if focused && showPhotos { closePhotoDock() }
                    if focused { scheduleBottom(proxy) }
                }
                .task { if #unavailable(iOS 18.0) { proxy.scrollTo("bottom", anchor: .bottom) } }
                .accessibilityIdentifier("chat-conversation")
                .accessibilityHidden(showActions)
            }
        }
        // Content continues beneath the feathered backdrop and glass controls.
    }

    /// `animated` is for viewport changes (the keyboard closing after send)
    /// and explicit requests: the geometry callback reports the final size at
    /// once, so an instant jump there moved the rows ahead of the animating
    /// keyboard and the conversation visibly bounced. Streaming text updates
    /// stay unanimated so repeated scrolls never compete with the reply.
    private func scheduleBottom(_ proxy: ScrollViewProxy, force: Bool = false, animated: Bool = false) {
        guard force || scrollPolicy.shouldFollowStream else { return }
        if force { scrollTask?.cancel(); scrollTask = nil }
        guard scrollTask == nil else { return }
        scrollTask = Task { @MainActor in
            // Wait for the newly inserted row / keyboard size to be measured.
            do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            scrollTask = nil
            guard !Task.isCancelled, scrollPolicy.shouldFollowStream else { return }
            // Streaming uses a settled offset. Repeated scroll animations used
            // to compete with the outgoing bubble and grow the lazy stack.
            if animated && !reduceMotion {
                withAnimation(ChatMotion.keyboardFollow) { scrollPosition.scrollTo(edge: .bottom) }
            } else {
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { scrollPosition.scrollTo(edge: .bottom) }
            }
        }
    }
    private func timestamp(_ date: Date) -> some View {
        HStack(spacing: 4) {
            Text(date, format: .dateTime.month().day()).fontWeight(.semibold)
            Text(date, style: .time)
        }
        .font(.system(size: 11)).foregroundStyle(.secondary)
        .frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 9)
    }
    private var preparation: some View {
        VStack(spacing: 9) {
            Text(model.isBusy ? model.statusText : "モデルを保存すると、このiPhoneで会話できます。")
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button("モデルを準備する") { showModel = true }.font(.subheadline)
        }
        .padding(.horizontal, 24).padding(.vertical, 14)
    }

    private var composer: some View {
        VStack(spacing: 6) {
            if attachmentPolicy.isTemporarilyLocked {
                // One glass capsule over the conversation, like the controls
                // below it. Bare caption text over scrolling bubbles collided
                // with the reply once the bar stopped painting an opaque band.
                HStack {
                    ChatGlassGroup {
                        Button { showAttachmentGuide = true } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "lock.fill").foregroundStyle(.secondary)
                                Text("添付は調整中").foregroundStyle(.secondary)
                                Text("画像を使う（E2B）").foregroundStyle(Theme.accent)
                            }
                            .font(.caption).lineLimit(1)
                        }
                        .modifier(GlassCapsuleControl())
                        .disabled(chats.isGenerating)
                        .accessibilityLabel("添付は調整中。画像を使う（E2B）")
                        .accessibilityIdentifier("chat-switch-e2b")
                    }
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, ChatMetrics.gutter).padding(.top, 4)
                .padding(.trailing, ChatMetrics.control + ChatMetrics.controlGap)
            }
            if !attachments.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(attachments) { attachment in
                            ZStack(alignment: .topTrailing) {
                                AttachmentCard(attachment: attachment, compact: true)
                                Button { attachments.removeAll { $0.id == attachment.id }; AttachmentStorage.remove(attachment) } label: {
                                    Image(systemName: "xmark.circle.fill").symbolRenderingMode(.palette)
                                        .foregroundStyle(.white, Color(uiColor: .systemGray))
                                        .font(.system(size: 20)).frame(width: 44, height: 44)
                                }.buttonStyle(.plain).accessibilityLabel("添付を外す: \(attachment.name)")
                                    .offset(x: 10, y: -10)
                            }.padding(.top, 10).padding(.trailing, 8)
                        }
                    }.padding(.horizontal, ChatMetrics.gutter)
                }.frame(height: 82).accessibilityIdentifier("draft-attachments")
            }
            if isImporting { ProgressView("添付を読み込んでいます…").font(.caption) }
            HStack(alignment: .bottom, spacing: ChatMetrics.controlGap) {
                // A native SwiftUI Menu on a glass button. On iOS 26 the
                // system morphs the menu out of the button (and back) with
                // Liquid Glass, as in Notes and Messages; no custom animation.
                attachmentMenuButton
                // Only the input and its emerging jump control share this
                // container. The plus button remains a separate glass shape.
                ChatGlassGroup(spacing: ChatMetrics.jumpGap) {
                    ZStack(alignment: .bottomTrailing) {
                        composerField
                            .chatGlass(in: RoundedRectangle(cornerRadius: ChatMetrics.control / 2))
                            .chatGlassIdentity("input", in: composerGlass, reduceMotion: reduceMotion)
                            .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: {
                                inputTopGlobal = $0
                            }
                            // The jump control lives in the input's glass
                            // container: it rises out of the field and sinks
                            // back into it, merging like Liquid Glass. An
                            // overlay keeps it out of the composer's layout.
                            .overlay(alignment: .topTrailing) {
                                if jumpPresent && !showActions {
                                    jumpButton
                                        .modifier(JumpSink(offset: jumpRaised || reduceMotion ? 0 : jumpLift + ChatMetrics.control,
                                                           // Land over the empty text area, clear of
                                                           // the send button and the field's corner.
                                                           x: jumpRaised || reduceMotion ? 0 : -(ChatMetrics.control + 16),
                                                           scale: jumpRaised || reduceMotion ? 1 : 0.2,
                                                           opacity: !reduceMotion || jumpRaised ? 1 : 0))
                                        .offset(y: -(ChatMetrics.control + jumpLift))
                                        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.glassSeparation,
                                                   value: jumpRaised)
                                }
                            }
                    }
                }
                // Scroll updates run in transactions that disable animations,
                // which also cut the jump control's merge to a single frame.
                // Mirror the policy into local state with its own transaction.
                .onChange(of: scrollPolicy.showsJumpButton) { _, visible in setJumpVisible(visible) }
                .onAppear { jumpPresent = scrollPolicy.showsJumpButton; jumpRaised = jumpPresent }
            }
            .padding(.horizontal, ChatMetrics.gutter).padding(.top, 8).padding(.bottom, 6)
            if showPhotos { photoDock }
        }
        .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: { composerTopGlobal = $0 }
        .anchorPreference(key: ComposerBoundsKey.self, value: .bounds) { $0 }
    }

    /// Clears everything above the field (guidance, draft attachments) by
    /// the same gap the control previously kept from the composer's edge.
    private var jumpLift: CGFloat {
        // Just above the field, beside the (narrowed) guidance capsule.
        // Draft attachments span the full width, so then clear the composer.
        guard attachments.isEmpty, !isImporting else {
            return max(0, inputTopGlobal - composerTopGlobal) + ChatMetrics.jumpGap
        }
        return ChatMetrics.jumpFieldGap
    }

    /// Rise out of / sink into the field. Sinking travels onto the field's
    /// trailing end while shrinking, so inside the shared glass container the
    /// two shapes fuse; the glass is unmounted only after it has merged.
    private func setJumpVisible(_ visible: Bool) {
        jumpSettle?.cancel()
        if visible {
            jumpPresent = true
            jumpSettle = Task { @MainActor in
                // Mount sunk first, then raise on the next frame.
                try? await Task.sleep(for: .milliseconds(16))
                guard !Task.isCancelled else { return }
                jumpRaised = true
            }
        } else {
            // Scroll updates arrive in transactions that disable animations
            // (and with them this view's implicit animation); change the
            // state from a fresh task instead.
            jumpSettle = Task { @MainActor in
                jumpRaised = false
                try? await Task.sleep(for: .milliseconds(520))
                guard !Task.isCancelled, !scrollPolicy.showsJumpButton else { return }
                jumpPresent = false
            }
        }
    }

    /// Visual only; the tap target is the transparent button in `body`.
    private var jumpButton: some View {
        Image(systemName: "arrow.down")
            .font(.system(size: ChatMetrics.icon, weight: .medium))
            .foregroundStyle(Theme.accent)
            // The arrow leaves first so it never crosses the send button's.
            .opacity(jumpRaised ? 1 : 0)
            .animation(.easeOut(duration: jumpRaised ? 0.2 : 0.08), value: jumpRaised)
            .frame(width: ChatMetrics.control, height: ChatMetrics.control)
            .chatGlass(in: Circle())
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }

    private var photoDock: some View {
        let ticket = photoPickerTicket
        let owner = pickerContext
        return VStack(spacing: 0) {
            HStack {
                Text("写真").font(.subheadline.weight(.semibold))
                Spacer()
                Button { withAnimation(reduceMotion ? nil : ChatMotion.resize) { expandedPhotos.toggle() } } label: {
                    Image(systemName: expandedPhotos ? "chevron.down" : "chevron.up")
                        .frame(width: 44, height: 44)
                }.accessibilityLabel(expandedPhotos ? "写真一覧を縮小" : "写真一覧を拡大")
                Button(action: closePhotoDock) { Image(systemName: "xmark").frame(width: 44, height: 44) }
                    .accessibilityLabel("写真一覧を閉じる").accessibilityIdentifier("photo-dock-close")
            }.padding(.leading, 18).padding(.trailing, 4)
            ChatPhotoPicker(selectionLimit: max(1, 3 - attachments.count), inline: true, onSelect: { urls in
                guard ticket == photoPickerTicket,
                      owner?.matches(threadID: chats.selectedID, modelID: chats.currentModel.id) == true else {
                    for url in urls { try? FileManager.default.removeItem(at: url) }; return
                }
                showPhotos = false; photoPickerTicket = UUID(); pickerContext = nil
                importAttachments(urls, temporary: true)
            }, onError: { message in
                if ticket == photoPickerTicket,
                   owner?.matches(threadID: chats.selectedID, modelID: chats.currentModel.id) == true { chats.error = message }
            })
            .id(ticket)
            .frame(height: expandedPhotos ? min(360, max(140, viewportHeight * 0.45)) : min(220, max(120, viewportHeight * 0.33)))
            .clipShape(RoundedRectangle(cornerRadius: 18))
        }
        // The bar itself is transparent; the dock is a panel and keeps a
        // solid surface so the conversation never shows through its title.
        .background(Theme.chatBackground.ignoresSafeArea(edges: .bottom))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("photo-dock")
        .transition(reduceMotion ? .opacity : .move(edge: .bottom).combined(with: .opacity))
    }

    private func closePhotoDock() {
        showPhotos = false; expandedPhotos = false
        // A provider may still be staging a selected file after dismissal.
        // Invalidate that picker so its late callback discards its own copies.
        pickerContext = nil
        photoPickerTicket = UUID()
    }

    private var composerField: some View {
                HStack(alignment: .bottom, spacing: 0) {
                    ChatComposerText(text: $draft,
                        focused: $inputFocused,
                        enabled: model.isInstalled(chats.currentModel), input: composerInput)
                        .padding(.leading, 14)
                    Button {
                        if chats.isGenerating { chats.stop() }
                        else { send() }
                    } label: {
                        Image(systemName: chats.isGenerating ? "stop.fill" : "arrow.up")
                            .contentTransition(reduceMotion ? .identity : .symbolEffect(.replace))
                            .font(.system(size: chats.isGenerating ? 11 : 17, weight: .bold))
                            .foregroundStyle(.white).frame(width: 30, height: 30)
                            .background(chats.isGenerating || canSend ? Theme.accent : Color(uiColor: .systemGray3), in: Circle())
                            .frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Rectangle())
                    }
                    .accessibilityLabel(chats.isGenerating ? "回答を停止する" : "送信する")
                    .disabled(chats.isStopping || (!chats.isGenerating && !canSend))
                    .buttonStyle(.plain)
                }
                .frame(minHeight: ChatMetrics.control)
                .accessibilityElement(children: .contain)
                .accessibilityIdentifier("chat-composer")
                .accessibilityHidden(showActions)
    }

    private var attachmentMenuButton: some View {
        Menu {
            Section {
                menuItem("写真", icon: "photo.on.rectangle", id: "chat-attach-photos",
                         locked: !attachmentPolicy.allowsImages,
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3) {
                    if attachmentPolicy.allowsImages { openPicker(photos: true) } else { showAttachmentGuide = true }
                }
                menuItem("カメラ", icon: "camera", id: "chat-attach-camera", locked: true,
                         disabled: chats.isGenerating || isImporting) { showAttachmentGuide = true }
                menuItem("ファイル", icon: "folder", id: "chat-attach-files",
                         locked: !attachmentPolicy.allowsAnyAttachment,
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3) {
                    if attachmentPolicy.allowsAnyAttachment { openPicker(photos: false) } else { showAttachmentGuide = true }
                }
                menuItem("動画", icon: "video", id: "chat-attach-video", locked: true,
                         disabled: chats.isGenerating || isImporting) { showAttachmentGuide = true }
            }
            #if POCKET_PREVIEW
            if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
                Section {
                    ForEach(PreviewAttachments.names, id: \.self) { name in
                        menuItem(name, icon: "doc", id: name, disabled: isImporting || chats.isGenerating) {
                            if let url = PreviewAttachments.url(name) { importAttachments([url], temporary: false) }
                        }
                    }
                }
            }
            #endif
            Section {
                menuItem("新しい会話", icon: "square.and.pencil", disabled: chats.isGenerating) { chats.newChat() }
                menuItem("会話一覧", icon: "bubble.left.and.bubble.right") { dismiss() }
                menuItem("モデルと設定", icon: "slider.horizontal.3") { showModel = true }
            }
        } label: {
            // Measured in UI tests: a Menu with the glass circle style renders
            // 2 x label - 6pt (30pt -> 54pt, 20pt -> 34pt), so 25pt gives the
            // same 44pt circle as the other chat controls.
            Image(systemName: "plus").font(.system(size: ChatMetrics.icon, weight: .regular))
                .foregroundStyle(.primary)
                .frame(width: 25, height: 25)
        }
        // Keep the written order even though the menu opens upward from the
        // bottom of the screen (automatic order would reverse it there).
        .menuOrder(.fixed)
        .modifier(GlassCircleControl())
        .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        .accessibilityLabel("会話の操作を開く")
        .accessibilityIdentifier("chat-add-menu")
    }

    /// A menu row. Locked items stay selectable and explain how to use them;
    /// they show a lock and a "調整中" subtitle instead of looking disabled.
    private func menuItem(_ title: String, icon: String, id: String? = nil, locked: Bool = false,
                          disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
            if locked { Text("調整中") }
            Image(systemName: locked ? "lock" : icon)
        }
        .disabled(disabled)
        .accessibilityIdentifier(id ?? title)
        .accessibilityValue(locked ? "現在調整中" : "")
    }

    private var actionMenuHeight: CGFloat {
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") { return 460 }
        #endif
        return min(460, menuRowHeight * 7 + 32)
    }
    private func actionRow(_ title: String, icon: String, tint: Color, locked: Bool = false, disabled: Bool = false,
                           action: @escaping () -> Void) -> some View {
        Button {
            closeActions()
            action()
        } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 17, weight: .medium)).foregroundStyle(tint)
                    .frame(width: 32, height: 32)
                    .background(tint.opacity(0.12), in: Circle())
                Text(title).font(.body.weight(.medium)).foregroundStyle(.primary).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                if locked { Image(systemName: "lock.fill").font(.caption).foregroundStyle(.secondary).accessibilityHidden(true) }
            }
            .frame(maxWidth: .infinity, minHeight: menuRowHeight, alignment: .leading).padding(.horizontal, 6)
            .contentShape(Rectangle())
        }
        .accessibilityLabel(title)
        .accessibilityValue(locked ? "現在調整中" : "")
        .accessibilityHint(locked ? "利用できる方法を確認します" : "")
        .buttonStyle(.plain).disabled(disabled).opacity(disabled ? 0.4 : 1)
    }
    private func switchToE2B() {
        guard !chats.isGenerating else { return }
        guard model.isInstalled(.e2b) else { showModel = true; return }
        draftToRestore = composerInput.committedText(fallback: draft)
        inputFocused = false
        model.select(.e2b)
        chats.newChat(modelID: ModelSpec.e2b.id)
        chats.releaseModelMemory()
    }
    private func openPicker(photos: Bool) {
        pickerContext = AttachmentImportContext(threadID: chats.selectedID, modelID: chats.currentModel.id)
        if photos {
            inputFocused = false
            photoPickerTicket = UUID()
            expandedPhotos = false
            withAnimation(reduceMotion ? nil : ChatMotion.resize) { showPhotos = true }
        } else { showFiles = true }
    }
    private func openActions() {
        inputFocused = false
        if showPhotos { closePhotoDock() }
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen) { showActions = true }
    }
    private func closeActions() {
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuClose) { showActions = false }
    }
    private func send() {
        let committed = composerInput.committedText(fallback: draft)
        let id = UUID()
        arrivingMessageID = id
        guard chats.send(committed, messageID: id, attachments: attachments) else { arrivingMessageID = nil; return }
        inputFocused = false
        composerInput.clearAndDismiss()
        draft = ""; attachments = []
        scrollPolicy.requestLatest(); latestRequest += 1
        arrivalCleanup?.cancel()
        arrivalCleanup = Task {
            do { try await Task.sleep(for: .milliseconds(650)) } catch { return }
            if arrivingMessageID == id { arrivingMessageID = nil }
        }
    }
    private func clearTransientState() {
        showPhotos = false; expandedPhotos = false; showActions = false
        photoPickerTicket = UUID()
        pickerContext = nil
        arrivalCleanup?.cancel(); arrivingMessageID = nil
        scrollTask?.cancel(); scrollTask = nil
        importTask?.cancel(); importID = nil; isImporting = false
        for attachment in attachments { AttachmentStorage.remove(attachment) }
        attachments = []
    }
    private func importAttachments(_ urls: [URL], temporary: Bool) {
        func discardStaged() { if temporary { for url in urls { try? FileManager.default.removeItem(at: url) } } }
        guard !urls.isEmpty else { return }
        guard attachmentPolicy.allowsAnyAttachment else { discardStaged(); showAttachmentGuide = true; return }
        guard !isImporting, !chats.isGenerating else { discardStaged(); return }
        guard attachments.count + urls.count <= 3 else { discardStaged(); chats.error = "添付は1回の送信で3つまでです。"; return }
        let ticket = UUID(); importID = ticket
        let selectedThread = chats.selectedID, selectedModel = chats.currentModel
        isImporting = true
        importTask = Task { @MainActor in
            defer {
                discardStaged()
                if importID == ticket { isImporting = false; importID = nil }
            }
            for url in urls {
                guard !Task.isCancelled else { return }
                do {
                    let attachment = try await Task.detached(priority: .userInitiated) {
                        try await AttachmentStorage.importFile(url, model: selectedModel)
                    }.value
                    guard !Task.isCancelled, importID == ticket, chats.selectedID == selectedThread,
                          chats.currentModel.id == selectedModel.id else { AttachmentStorage.remove(attachment); return }
                    guard attachmentPolicy.allows(attachment) else {
                        AttachmentStorage.remove(attachment); showAttachmentGuide = true; continue
                    }
                    guard attachments.reduce(0, { $0 + $1.imageNames.count }) + attachment.imageNames.count <= 4 else {
                        AttachmentStorage.remove(attachment); chats.error = "画像は合計4場面まで添付できます。"; continue
                    }
                    attachments.append(attachment)
                } catch { if !Task.isCancelled, importID == ticket, chats.selectedID == selectedThread { chats.error = error.localizedDescription } }
            }
        }
    }
}

struct MessageView: View, Equatable {
    let message: ChatMessage
    let oppositeInset: CGFloat
    var hasTail = true
    var animateArrival = false
    var timestampReveal: CGFloat = 0
    private var outgoing: Bool { message.role == .user }

    var body: some View {
        HStack(alignment: .bottom, spacing: 0) {
            if outgoing { Spacer(minLength: oppositeInset) }
            VStack(alignment: outgoing ? .trailing : .leading, spacing: 4) {
                Group {
                    if message.text.isEmpty && message.state == .generating {
                        TypingIndicator()
                    } else {
                        VStack(alignment: .leading, spacing: 4) {
                            ForEach(message.media) { attachment in AttachmentCard(attachment: attachment) }
                            Group {
                            if !outgoing && !message.text.isEmpty {
                                ReplyText(text: message.text, isStreaming: message.state == .generating)
                            } else {
                                Text(message.text.isEmpty ? (message.state == .failed ? "回答を生成できませんでした" : "回答を停止しました") : message.text)
                            }
                            }
                        }
                            .font(ChatMetrics.messageFont).lineSpacing(1)
                            .textSelection(.enabled)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.vertical, ChatMetrics.bubbleVertical)
                            .padding(.leading, outgoing ? ChatMetrics.bubbleInset : ChatMetrics.bubbleTailInset)
                            .padding(.trailing, outgoing ? ChatMetrics.bubbleTailInset : ChatMetrics.bubbleInset)
                    }
                }
                .foregroundStyle(outgoing ? Color.white : Color.primary)
                .background(outgoing ? Theme.accent : Theme.incoming,
                            in: MessageBubble(outgoing: outgoing, hasTail: hasTail))
                .modifier(OutgoingArrival(animate: outgoing && animateArrival))
                .contextMenu {
                    if !message.text.isEmpty {
                        Button("コピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.text }
                    }
                }
                if message.state == .stopped || message.state == .failed {
                    Text(message.state == .stopped ? "停止した回答" : "回答を生成できませんでした")
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                        .padding(.horizontal, 9)
                }
            }
            .offset(x: -72 * timestampReveal)
            if !outgoing { Spacer(minLength: oppositeInset) }
        }
        .overlay(alignment: .trailing) {
            Text(message.createdAt, style: .time)
                .font(.system(size: 11)).foregroundStyle(.secondary)
                .frame(width: 64).opacity(Double(timestampReveal))
                .accessibilityHidden(timestampReveal == 0)
        }
        .accessibilityElement(children: message.media.isEmpty ? .combine : .contain)
    }
}

struct MessageBubble: Shape {
    var outgoing: Bool
    var hasTail = true

    func path(in rect: CGRect) -> Path {
        // Cubic quarter-circles stay round even for a reply taller than the
        // viewport. The short curved tail is part of this same outline.
        var path = Path()
        let left = rect.minX, top = rect.minY, bottom = rect.maxY
        let right = rect.maxX - 6
        let radius = max(0, min(18, min((rect.width - 6) / 2, rect.height / 2)))
        let curve = radius * 0.5522847498
        path.move(to: CGPoint(x: left + radius, y: top))
        path.addLine(to: CGPoint(x: right - radius, y: top))
        path.addCurve(to: CGPoint(x: right, y: top + radius),
                      control1: CGPoint(x: right - radius + curve, y: top),
                      control2: CGPoint(x: right, y: top + radius - curve))
        path.addLine(to: CGPoint(x: right, y: bottom - radius))
        if hasTail {
            path.addCurve(to: CGPoint(x: rect.maxX, y: bottom),
                          control1: CGPoint(x: right, y: bottom - 7),
                          control2: CGPoint(x: right + 1, y: bottom - 3))
            path.addCurve(to: CGPoint(x: right - 8, y: bottom - 4),
                          control1: CGPoint(x: right + 1, y: bottom),
                          control2: CGPoint(x: right - 4, y: bottom - 1))
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right - 11, y: bottom - 1),
                          control2: CGPoint(x: right - 14, y: bottom))
        } else {
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right, y: bottom - radius + curve),
                          control2: CGPoint(x: right - radius + curve, y: bottom))
        }
        path.addLine(to: CGPoint(x: left + radius, y: bottom))
        path.addCurve(to: CGPoint(x: left, y: bottom - radius),
                      control1: CGPoint(x: left + radius - curve, y: bottom),
                      control2: CGPoint(x: left, y: bottom - radius + curve))
        path.addLine(to: CGPoint(x: left, y: top + radius))
        path.addCurve(to: CGPoint(x: left + radius, y: top),
                      control1: CGPoint(x: left, y: top + radius - curve),
                      control2: CGPoint(x: left + radius - curve, y: top))
        path.closeSubpath()
        if !outgoing {
            return path.applying(CGAffineTransform(a: -1, b: 0, c: 0, d: 1, tx: rect.minX + rect.maxX, ty: 0))
        }
        return path
    }
}

private struct TypingIndicator: View {
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { timeline in
            let phase = timeline.date.timeIntervalSinceReferenceDate * 4.5
            HStack(spacing: 5) {
                ForEach(0..<3) { dot in
                    let wave = reduceMotion ? 1 : (sin(phase - Double(dot) * 0.8) + 1) / 2
                    Circle().fill(Color(uiColor: .systemGray))
                        .frame(width: 8, height: 8)
                        .opacity(0.4 + wave * 0.6)
                        .scaleEffect(0.9 + wave * 0.1)
                }
            }
            .padding(.leading, 20).padding(.trailing, 14).padding(.vertical, 13)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("AIが回答を作成しています")
    }
}
