import SwiftUI
import UIKit
import PocketCore
import UniformTypeIdentifiers
import PhotosUI

struct ChatView: View {
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @Environment(\.historySidebar) private var historySidebar
    @Environment(\.historyVisible) private var historyVisible
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @ScaledMetric(relativeTo: .body) private var menuRowHeight: CGFloat = 46
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    @State private var draft = ""
    @StateObject private var composerInput = ComposerInput()
    @State private var showModel = false
    /// モデルと設定 opened from the web search note scrolls to its card.
    @State private var modelShowsWebSearch = false
    @State private var showWebSearchKeyNote = false
    @ObservedObject private var searchKey = WebSearchKeyState.shared
    /// The header's model mark opens this: the current model's generation
    /// settings and the user's own system prompt (GenerationConfigView).
    @State private var showConfiguration = false
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// 縮小型 (the folding panel) or 従来型 (the plus and a one-line field).
    @AppStorage(ComposerStyle.storageKey) private var composerStyle = ComposerStyle.folding
    @State private var showActions = false
    @StateObject private var scrollPolicy = ChatScrollState()
    @State private var viewportHeight: CGFloat = 800
    @State private var arrivingMessageID: UUID?
    @State private var arrivalCleanup: Task<Void, Never>?
    @State private var scrollTask: Task<Void, Never>?
    @State private var attachments: [ChatAttachment] = []
    @State private var showPhotos = false
    /// The photo picker's top on screen, for placing its done check.
    @State private var photoPickerFrame = PhotoPickerFrame()
    /// The photo sheet's size: the compact card under the field, or large.
    @State private var photoDetent: PresentationDetent = .large
    /// The compact card's height, fixed when the sheet opens so its detents
    /// do not change while the keyboard that it replaces is going away.
    @State private var photoSheetHeight: CGFloat = 300
    /// Mirrors showPhotos with an animation, so the field rises and settles
    /// smoothly however the sheet was opened or dismissed.
    @State private var photoRoom = false
    @State private var photoPickerTicket = UUID()
    @State private var photoSelection: [PhotosPickerItem] = []
    @State private var pickedAttachments: [PhotosPickerItem: UUID] = [:]
    @State private var pickerChain: Task<Void, Never>?
    @State private var showFiles = false
    @State private var showAttachmentGuide = false
    @State private var draftToRestore: String?
    @State private var pickerContext: AttachmentImportContext?
    @State private var isImporting = false
    @State private var importTask: Task<Void, Never>?
    @State private var importID: UUID?
    @State private var timestampReveal: CGFloat = 0
    @State private var latestRequest = 0
    /// The jump control's glass stays mounted while it sinks into the field;
    /// insertion/removal transitions do not run inside the composer bar.
    @State private var scrollDebug = ""
    @State private var jumpPresent = false
    @State private var jumpRaised = false
    /// The arrow leaves before the glass sinks and returns after it has
    /// separated, so it never crosses the field's text.
    @State private var jumpIconShown = false
    /// Hidden only once the shrunken glass has fused into the field.
    @State private var jumpGlassShown = false
    @State private var jumpSettle: Task<Void, Never>?
    /// 従来型's pills rise out of the field as drops of its glass and sink
    /// back into it (user, 2026-10-23), the way the jump control does. The
    /// drops share the field's glass container (classicPillDrops); the
    /// pills are menus, which must stay outside any container, and take
    /// over only once the drops rest where they stand.
    @State private var classicDropsPresent = false
    @State private var classicDropsRaised = false
    @State private var classicDropsGlass = false
    @State private var classicDropLabels = false
    @State private var classicPillsSettled = false
    /// The bar's room for the pills, made and given back at once, as the
    /// keyboard starts to move: grown or shrunk with an animation, it
    /// relaid the field out while the drops moved, and their glass was
    /// drawn apart from it, under the field (simulator, 1.1.0 (138)).
    @State private var classicPillRoom = false
    @State private var classicDetailWidth: CGFloat = 0
    @State private var classicModelWidth: CGFloat = 0
    @State private var classicPillsTask: Task<Void, Never>?
    @State private var inputTopGlobal: CGFloat = 0
    @State private var composerTopGlobal: CGFloat = 0
    /// Follows the latest message by scrolling to the bottom edge of the
    /// valid scroll range. A chat shorter than the screen has no range, so it
    /// cannot be pushed down; aligning the "bottom" row to the viewport edge
    /// did exactly that and the rows dropped mid-reply.
    @State private var scrollPosition = ScrollPosition(edge: .bottom)
    /// The chat `scrollPosition` belongs to. A chat's new scroll view starts
    /// at the bottom edge, not where the user left the previous chat: that
    /// position, read when the new view was made, opened a long chat from
    /// history at its top (UI check, 1.0.59).
    @State private var scrollPositionChat: UUID?
    /// Puts a chat that just opened back at its end; see `settleOpenedChat`.
    @State private var openSettle: Task<Void, Never>?
    /// Read only by the ring below the last message, so following a pull
    /// redraws that ring and not the conversation.
    @State private var pullToCompose = PullToComposeState()
    @Namespace private var composerGlass
    @Namespace private var actionGlass
    // The native UITextView owns first responder status. A SwiftUI FocusState
    // without a .focused view can reset itself while its UIKit delegate is
    // beginning an edit, dismissing the keyboard during typing.
    @State private var inputFocused = false
    /// Reading older messages folds the composer into three glass buttons
    /// (voice, chat, latest); only the chat button unfolds it.
    @State private var composerFolded = false
    /// Drives ComposerPanelMorph: 0 = the panel, 1 = the three buttons.
    @State private var composerMorph: CGFloat = 0
    /// While the morph runs the bar keeps the panel's height, so the
    /// conversation is not laid out again on every frame. Folded and
    /// settled, it gives that room back.
    @State private var composerMorphing = false
    @State private var composerSettled = false
    @State private var composerMorphID = 0
    /// Folded at the end of the chat, the latest button flows into the chat
    /// button (ComposerButtonMorph `tuck`: 0 = in its place, 1 = inside),
    /// and once inside it leaves the hierarchy, for touch and VoiceOver.
    @State private var jumpTuck: CGFloat = 0
    @State private var jumpTucked = false
    @State private var jumpTuckID = 0
    /// A drag heading into older messages, which is about to fold.
    @State private var foldLeaning = false
    @State private var composerHeight: CGFloat = 0
    @State private var composerWidth: CGFloat = 0
    @State private var showVoiceNote = false
    @AccessibilityFocusState private var unfoldFocused: Bool
    private var attachmentPolicy: ModelAttachmentPolicy { ModelAttachmentPolicy(model: chats.currentModel) }

    private var canSend: Bool {
        model.isInstalled(chats.currentModel) && !isImporting
            && (!draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty)
    }
    private var datedMessages: Set<UUID> {
        var result: Set<UUID> = []
        var previous: Date?
        for message in chats.messages {
            if previous == nil || message.createdAt.timeIntervalSince(previous!) > 300 { result.insert(message.id) }
            previous = message.createdAt
        }
        return result
    }

    /// Replies to messages that asked for a chart (RichFormatGuide), whose
    /// chart data under a ```json or bare fence is drawn too.
    private var chartAnswers: Set<UUID> {
        var result: Set<UUID> = []
        var asked = false
        for message in chats.messages {
            if message.role == .user { asked = RichFormatGuide.asksForChart(message.text) }
            else if asked { result.insert(message.id) }
        }
        return result
    }

    private var tailedMessages: Set<UUID> {
        var result: Set<UUID> = []
        for (index, message) in chats.messages.enumerated() {
            let next = chats.messages.dropFirst(index + 1).first
            if next == nil || next?.role != message.role
                || (next?.createdAt.timeIntervalSince(message.createdAt) ?? 0) > 60 {
                result.insert(message.id)
            }
        }
        return result
    }

    // No glass container spans the screen: the header and the composer
    // have their own, and the composer's menus stand outside every one.
    // Until 1.0.114 a screen-wide group also held the system menus inside
    // a glass container (`--menus-in-panel` keeps it for comparison).
    var body: some View {
        if menusInPanel { ChatGlassGroup(spacing: 14) { screen } } else { screen }
    }

    private var screen: some View {
        conversation
            .background(Theme.chatBackground)
            // Tap outside closes the plus menu. It sits on the conversation,
            // under the composer inset that draws the menu itself.
            .overlay {
                if showActions {
                    Color.black.opacity(0.03).ignoresSafeArea()
                        .contentShape(Rectangle())
                        .onTapGesture { closeActions() }
                        .accessibilityHidden(true)
                        .transition(.opacity)
                }
            }
            .chatBars(top: {
                header.accessibilityHidden(showActions)
                    .background { ChatChromeBackdrop(edge: .top) }
            }, bottom: {
                // No opaque band: the conversation scrolls behind the glass
                // controls and the system's soft scroll edge effect keeps the
                // text legible, as in Messages on iOS 26.
                composer
            })
            // The visible jump control is drawn inside the composer's glass
            // container (so it can merge into the field), but it sits above
            // the bar's bounds where the bar cannot receive touches. This
            // transparent target at the same spot owns the tap and VoiceOver.
            .overlayPreferenceValue(ComposerBoundsKey.self) { bounds in
                GeometryReader { overlay in
                    if let bounds, floatingJumpWanted && !showActions {
                        Button { scrollPolicy.requestLatest(); latestRequest += 1 } label: {
                            Color.clear.frame(width: ChatMetrics.control, height: ChatMetrics.control)
                                .contentShape(Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("最新のメッセージへ移動").accessibilityIdentifier("chat-jump-latest")
                        .position(x: overlay.size.width / 2,
                                  y: overlay[bounds].minY + max(0, inputTopGlobal - composerTopGlobal)
                                     - jumpLift - ChatMetrics.control / 2)
                    }
                }
            }
            #if POCKET_PREVIEW
            .overlay(alignment: .topLeading) {
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityIdentifier("scroll-debug")
                    .accessibilityLabel(scrollDebug + " " + scrollPolicy.endMarkerDebug + " follows=\(scrollPolicy.followsLatest) scrolling=\(scrollPolicy.isUserScrolling) jump=\(scrollPolicy.showsJumpButton)")
            }
            #endif
            .background { GeometryReader { area in
                Color.clear.preference(key: ChatViewportHeightKey.self, value: area.size.height)
            }.ignoresSafeArea(.keyboard) }
            .onPreferenceChange(ChatViewportHeightKey.self) { if abs(viewportHeight - $0) > 1 { viewportHeight = $0 } }
            .toolbar(.hidden, for: .navigationBar)
            .toolbar(.hidden, for: .bottomBar)
            .tint(Theme.accent)
            .sheet(isPresented: $showModel, onDismiss: { modelShowsWebSearch = false }) {
                ModelView(showsWebSearch: modelShowsWebSearch)
            }
            .sheet(isPresented: $showConfiguration) {
                GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings,
                                     onSave: chats.updateSettings)
            }
            .fileImporter(isPresented: $showFiles,
                          allowedContentTypes: fileImportTypes, allowsMultipleSelection: true) { result in
                do {
                    let urls = try result.get()
                    guard pickerContext?.matches(threadID: chats.selectedID, modelID: chats.currentModel.id) == true else { return }
                    importAttachments(urls, temporary: false)
                }
                catch { chats.error = error.localizedDescription }
            }
            .onChange(of: chats.selectedID) { _, _ in
                composerInput.clearAndDismiss()
                draft = draftToRestore ?? ""; draftToRestore = nil
                clearTransientState()
                // Another chat opens with its composer, ready to type.
                unfoldComposerAtOnce()
                scrollPolicy.requestLatest()
            }
            .onChange(of: chats.currentModel.id) { _, _ in
                showPhotos = false; showFiles = false
                clearTransientState()
            }
            .onDisappear { clearTransientState() }
            // 従来型 never folds: a folded panel opens as it changes type.
            .onChange(of: composerStyle) { _, _ in unfoldComposerAtOnce() }
            // The sidebar takes over the screen: put away the keyboard, the
            // photo sheet and the plus menu as soon as it starts to show.
            .onChange(of: historyVisible) { _, visible in
                guard visible else { return }
                inputFocused = false
                if showPhotos { closePhotoDock() }
                if showActions { closeActions() }
            }
            .confirmationDialog("添付について", isPresented: $showAttachmentGuide, titleVisibility: .visible) {
                if !attachmentPolicy.allowsImages {
                    Button(model.isInstalled(.e2b) ? "E2Bで新しい会話を開く" : "E2Bを準備する") { switchToE2B() }
                        .disabled(chats.isGenerating)
                }
                Button("閉じる", role: .cancel) {}
            } message: {
                Text(attachmentPolicy.guidance + (!attachmentPolicy.allowsImages
                    ? "\n切り替えると入力中の文章を引き継ぎます。元の会話は履歴に残ります。" : ""))
            }
            .alert("お知らせ", isPresented: Binding(get: { chats.error != nil || (!showModel && model.error != nil) },
                set: { if !$0 { chats.error = nil; model.error = nil } })) {
                Button("閉じる") { chats.error = nil; model.error = nil }
            } message: { Text(chats.error ?? model.error ?? "") }
    }

    /// What the file picker offers. Documents are converted to text on
    /// device (AttachmentStorage), so the model only receives plain text.
    private var fileImportTypes: [UTType] {
        var types: [UTType] = attachmentPolicy.allowsPhotos ? [.image] : []
        if attachmentPolicy.allowsDocuments {
            types += [.plainText, .pdf, .text, .rtf, .json, .xml, .html, .commaSeparatedText,
                      .tabSeparatedText, .yaml, .sourceCode]
            for identifier in ["net.daringfireball.markdown", "org.openxmlformats.wordprocessingml.document"] {
                if let type = UTType(identifier) { types.append(type) }
            }
        }
        return types
    }

    private var header: some View {
        ChatGlassGroup {
            ZStack(alignment: .topLeading) {
                ChatCircleButton(action: {
                    inputFocused = false
                    historySidebar?.open()
                }) {
                    SidebarGlyph()
                }
                .accessibilityLabel("会話一覧を開く")
                .padding(.leading, ChatMetrics.gutter).padding(.top, 8)

                // The model is chosen in the composer; the mark opens what
                // belongs to the current model: its generation settings and
                // the user's system prompt.
                Button {
                    inputFocused = false
                    showConfiguration = true
                } label: {
                    VStack(spacing: 4) {
                        ModelMark(model: chats.currentModel, size: 40)
                        HStack(spacing: 3) {
                            Text(chats.currentModel.family).font(.caption.weight(.semibold))
                            Image(systemName: "chevron.right").font(.system(size: 8, weight: .semibold))
                                .foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 9).padding(.vertical, 4)
                        .chatGlass(in: Capsule())
                    }
                    .foregroundStyle(.primary).frame(maxWidth: .infinity)
                    .padding(.top, 6).padding(.bottom, 8).contentShape(Rectangle())
                }
                .accessibilityLabel("生成設定とシステムプロンプトを開く")
                .accessibilityValue(chats.currentModel.name)
                .accessibilityIdentifier("chat-model-settings")
                .padding(.horizontal, 74)
            }
            .buttonStyle(.plain)
        }
    }

    /// Each chat's conversation is a scroll view of its own.
    private var conversationID: UUID? {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-shared-scroll") { return nil }
        #endif
        return chats.selectedID
    }

    /// The latest messages are laid out eagerly. With every message a lazy
    /// row, scrolling up after two sends kept the stack re-placing its rows:
    /// the simulator spun at full CPU in that UI test, with plain and
    /// Markdown replies alike, and the device hitched. A long chat's older
    /// messages stay lazy above them; the split moves in steps of 20, so a
    /// send rarely moves a row between the two.
    private static let eagerMessages = 40
    private var eagerStart: Int {
        let count = chats.messages.count
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-all-lazy") { return count }
        #endif
        guard count > Self.eagerMessages else { return 0 }
        return (count - Self.eagerMessages) / 20 * 20
    }

    /// One stable, measurable row per message. Returning a conditional
    /// timestamp beside the bubble made the lazy stack repeatedly enumerate
    /// variable subview lists while estimating long histories.
    private func messageRow(_ message: ChatMessage, dated: Bool, tail: Bool, chart: Bool, width: CGFloat) -> some View {
        VStack(spacing: 8) {
            if dated { timestamp(message.createdAt) }
            MessageView(message: message, oppositeInset: dynamicTypeSize.isAccessibilitySize
                    ? max(20, width * 0.08) : max(56, width * 0.20),
                        hasTail: tail,
                        animateArrival: arrivingMessageID == message.id && !reduceMotion,
                        timestampReveal: timestampReveal,
                        answersChartRequest: chart)
                .equatable()
                .recordChatLayout(message.id)
                .modifier(BubbleScrollSpring(active: scrollPolicy.isUserScrolling, reducedMotion: reduceMotion))
        }
        .frame(maxWidth: .infinity)
        .id(message.id)
        .transition(message.role == .assistant && !reduceMotion ? .opacity : .identity)
    }

    /// The conversation's outer stack is eager. As one tall item of a lazy
    /// stack, the latest messages were sometimes not drawn at all: the screen
    /// stayed blank after scrolling up during a reply, and the content height
    /// ran about 1400pt long until the reply ended (UI check, 1.0.71).
    @ViewBuilder private func conversationStack<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-eager-item") { LazyVStack(spacing: 8, content: content) }
        else { VStack(spacing: 8, content: content) }
        #else
        VStack(spacing: 8, content: content)
        #endif
    }

    private var keyboardDismissal: ScrollDismissesKeyboardMode {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-keep-keyboard") { return .never }
        if PreviewProbe.on("--probe-dismiss-immediately") { return .immediately }
        #endif
        return .interactively
    }

    private var conversation: some View {
        let dates = datedMessages
        let tails = tailedMessages
        let charts = chartAnswers
        return GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    conversationStack {
                        Text(chats.currentModel.name)
                            .font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity).padding(.top, 14).padding(.bottom, 8)
                        if chats.messages.isEmpty {
                            if !model.isInstalled(chats.currentModel) { preparation }
                            else {
                                Text("メッセージを送って会話を始めましょう")
                                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                                    .padding(.horizontal, 26).padding(.top, 8)
                            }
                        }
                        let split = eagerStart
                        if split > 0 {
                            LazyVStack(spacing: 8) {
                                ForEach(chats.messages[..<split]) { message in
                                    messageRow(message, dated: dates.contains(message.id), tail: tails.contains(message.id),
                                               chart: charts.contains(message.id), width: geometry.size.width)
                                }
                            }
                        }
                        if split < chats.messages.count {
                            VStack(spacing: 8) {
                                ForEach(chats.messages[split...]) { message in
                                    messageRow(message, dated: dates.contains(message.id), tail: tails.contains(message.id),
                                               chart: charts.contains(message.id), width: geometry.size.width)
                                }
                            }
                        }
                        if chats.isGenerating {
                            Text(chats.status).font(.caption2).foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, ChatMetrics.replyInset).padding(.top, 2)
                        }
                        // Only rows far above the end are estimated, so the
                        // target's position stays exact; below a fully lazy
                        // stack it used to chase estimated row heights.
                        // It ends the content, so scrolling it to the bottom
                        // reaches the end; the stack's 10pt bottom padding
                        // used to stay below the screen (UI check, 1.0.67).
                        Color.clear.frame(height: 11).id("bottom")
                    }
                    .padding(.horizontal, ChatMetrics.gutter)
                    .overlay(alignment: .top) { PullToComposeIndicator(state: pullToCompose) }
                }
                // Each chat gets a scroll view of its own, placed at its end
                // like the first launch. Reusing one kept the last chat's
                // offset and row estimates, and a chat opened from history
                // could rest below its last message (1.0.58).
                .id(conversationID)
                .transition(.identity)
                .scrollPosition(Binding(get: { scrollPositionChat == chats.selectedID ? scrollPosition : ScrollPosition(edge: .bottom) },
                                        set: { scrollPosition = $0; scrollPositionChat = chats.selectedID }))
                .coordinateSpace(name: "conversation")
                .scrollDismissesKeyboard(keyboardDismissal)
                .chatScrollEdges(customChrome: true)
                .scrollBounceBehavior(.always)
                .modifier(ChatScrollAnchoring(followsLatest: scrollPolicy.shouldFollowStream))
                .modifier(ChatScrollObserver(onDistance: { scrollPolicy.observe(distanceFromBottom: $0) },
                    onUserScrolling: {
                        scrollPolicy.setUserScrolling($0)
                        if $0 { scrollTask?.cancel(); scrollTask = nil }
                    }, onLayout: { scheduleBottom(proxy, animated: true) },
                    onDebug: { scrollDebug = $0 }))
                // Pulling past the end opens a new chat, as in ChatGPT.
                .modifier(PullToComposeObserver(state: pullToCompose,
                                                enabled: !chats.messages.isEmpty && !chats.isGenerating && !showActions,
                                                onCompose: { chats.newChat() }))
                // Reading older messages folds the composer.
                .modifier(ComposerFoldObserver(enabled: foldAllowed,
                                               onLeaning: { if foldLeaning != $0 { foldLeaning = $0 } },
                                               onFold: { foldComposer() }))
                .modifier(ChatTimestampReveal(onChanged: { timestampReveal = $0 }, onEnded: {
                    withAnimation(reduceMotion ? nil : ChatMotion.resize) { timestampReveal = 0 }
                }))
                .onChange(of: chats.messages.last?.text) { _, _ in
                    scheduleBottom(proxy)
                }
                .onReceive(NotificationCenter.default.publisher(for: ReplyPacer.revealed)) { _ in
                    scheduleBottom(proxy)
                }
                .onChange(of: chats.messages.count) { _, _ in
                    scheduleBottom(proxy)
                }
                .onChange(of: chats.isGenerating) { _, generating in
                    if !generating { scheduleBottom(proxy) }
                }
                .onChange(of: chats.selectedID, initial: true) { _, selected in
                    // Selecting from history happens inside the drawer's
                    // slide; the new chat must not scroll down with it.
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) {
                        scrollPosition = ScrollPosition(edge: .bottom)
                        scrollPositionChat = selected
                    }
                    settleOpenedChat(proxy)
                }
                .onChange(of: latestRequest) { _, _ in jumpToBottom(proxy) }
                .onChange(of: inputFocused) { _, focused in
                    if focused && showPhotos { closePhotoDock() }
                    if focused { scheduleBottom(proxy) }
                }
                .task { if #unavailable(iOS 18.0) { proxy.scrollTo("bottom", anchor: .bottom) } }
                .accessibilityIdentifier("chat-conversation")
                .accessibilityHidden(showActions)
            }
        }
        // Content continues beneath the feathered backdrop and glass controls.
    }

    /// `animated` is for viewport changes (the keyboard closing after send)
    /// and explicit requests: the geometry callback reports the final size at
    /// once, so an instant jump there moved the rows ahead of the animating
    /// keyboard and the conversation visibly bounced. Streaming text updates
    /// stay unanimated so repeated scrolls never compete with the reply.
    /// An explicit request (the jump control, sending). It must work while the
    /// list is still coasting from a flick: the `ScrollPosition` binding may
    /// still read `.bottom` from an earlier jump until scrolling settles, so
    /// setting it again changed nothing. The proxy scrolls imperatively; a
    /// final unanimated edge scroll corrects lazy-height estimates.
    private func jumpToBottom(_ proxy: ScrollViewProxy) {
        scrollTask?.cancel()
        scrollTask = Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            if reduceMotion {
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { proxy.scrollTo("bottom", anchor: .bottom) }
            } else {
                withAnimation(ChatMotion.keyboardFollow) { proxy.scrollTo("bottom", anchor: .bottom) }
            }
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            scrollTask = nil
            guard scrollPolicy.followsLatest, !scrollPolicy.isUserScrolling,
                  scrollPolicy.lastDistanceFromBottom > 1 else { return }
            // Lazy rows were measured on the way; settle the last few points
            // smoothly rather than snapping.
            withAnimation(reduceMotion ? nil : ChatMotion.scroll) { scrollPosition.scrollTo(edge: .bottom) }
        }
    }

    /// A chat that just opened is placed at its end from estimated row
    /// heights, and rows measured taller then push the end below the screen
    /// (UI check: up to 1156pt, and 17-52pt still after 0.3s with tables,
    /// code and math). Put it back at the end without animation until it has
    /// stayed there for 0.3s, for at most 1.5s: chasing the estimate for good
    /// hung layout before. A touch ends it.
    private func settleOpenedChat(_ proxy: ScrollViewProxy) {
        openSettle?.cancel()
        openSettle = Task { @MainActor in
            var atEnd = 0
            for _ in 0..<30 {
                do { try await Task.sleep(for: .milliseconds(50)) } catch { return }
                guard !scrollPolicy.isUserScrolling else { break }
                guard scrollPolicy.lastDistanceFromBottom > 1 else {
                    atEnd += 1
                    if atEnd >= 6 { break } else { continue }
                }
                atEnd = 0
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { proxy.scrollTo("bottom", anchor: .bottom) }
            }
            openSettle = nil
        }
    }

    private func scheduleBottom(_ proxy: ScrollViewProxy, force: Bool = false, animated: Bool = false) {
        guard force || scrollPolicy.shouldFollowStream else { return }
        if force { scrollTask?.cancel(); scrollTask = nil }
        guard scrollTask == nil else { return }
        scrollTask = Task { @MainActor in
            // Wait for the newly inserted row / keyboard size to be measured.
            do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            scrollTask = nil
            guard !Task.isCancelled, scrollPolicy.shouldFollowStream else { return }
            // Streaming uses a settled offset. Repeated scroll animations used
            // to compete with the outgoing bubble and grow the lazy stack.
            if animated && !reduceMotion {
                withAnimation(ChatMotion.keyboardFollow) { scrollPosition.scrollTo(edge: .bottom) }
            } else {
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { scrollPosition.scrollTo(edge: .bottom) }
            }
        }
    }
    private func timestamp(_ date: Date) -> some View {
        HStack(spacing: 4) {
            Text(date, format: .dateTime.month().day()).fontWeight(.semibold)
            Text(date, style: .time)
        }
        .font(.system(size: 11)).foregroundStyle(.secondary)
        .frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 9)
    }
    private var preparation: some View {
        VStack(spacing: 9) {
            Text(model.isRestoring || model.isWorking(on: chats.currentModel)
                 ? model.statusText(for: chats.currentModel) : "モデルを保存すると、このiPhoneで会話できます。")
                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            Button("モデルを準備する") { showModel = true }.font(.subheadline)
        }
        .padding(.horizontal, 24).padding(.vertical, 14)
    }

    private var composer: some View {
        VStack(spacing: 6) {
            // Hidden with the fold; removed from the bar only once folded.
            if !attachments.isEmpty && !composerSettled {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(attachments) { attachment in
                            ZStack(alignment: .topTrailing) {
                                AttachmentCard(attachment: attachment, compact: true)
                                Button {
                                    attachments.removeAll { $0.id == attachment.id }; AttachmentStorage.remove(attachment)
                                    if let item = pickedAttachments.first(where: { $0.value == attachment.id })?.key {
                                        pickedAttachments[item] = nil; photoSelection.removeAll { $0 == item }
                                    }
                                } label: {
                                    Image(systemName: "xmark.circle.fill").symbolRenderingMode(.palette)
                                        .foregroundStyle(.white, Color(uiColor: .systemGray))
                                        .font(.system(size: 20)).frame(width: 44, height: 44)
                                }.buttonStyle(.plain).accessibilityLabel("添付を外す: \(attachment.name)")
                                    .offset(x: 10, y: -10)
                            }.padding(.top, 10).padding(.trailing, 8)
                        }
                    }.padding(.horizontal, ChatMetrics.gutter)
                }.frame(height: 82).accessibilityIdentifier("draft-attachments")
                    .modifier(ComposerFade(progress: composerMorph))
                    .allowsHitTesting(!composerFolded)
                    .accessibilityHidden(composerFolded)
            }
            if isImporting && !composerSettled {
                ProgressView("添付を読み込んでいます…").font(.caption)
                    .modifier(ComposerFade(progress: composerMorph))
                    .accessibilityHidden(composerFolded)
            }
            composerStage
                // There is no voice feature yet; the button says so rather
                // than pretending, and offers the keyboard's own dictation.
                .alert("音声入力", isPresented: $showVoiceNote) {
                    Button("入力欄を開く") {
                        // The field cannot take the keyboard while the
                        // alert is still dismissing.
                        Task { @MainActor in
                            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                            unfoldComposer()
                        }
                    }
                    Button("閉じる", role: .cancel) {}
                } message: {
                    Text("Fielua には、まだ音声で話しかける機能がありません。入力欄を開くと、キーボードに音声入力のボタンがあれば、それで文字を入力できます。")
                }
                // Search without a key: where to get one and what it sends.
                .alert("ウェブ検索にはTavilyのキーが必要です", isPresented: $showWebSearchKeyNote) {
                    Button("設定を開く") {
                        // The sheet cannot open while the alert is still dismissing.
                        Task { @MainActor in
                            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                            modelShowsWebSearch = true
                            showModel = true
                        }
                    }
                    Button("キャンセル", role: .cancel) {}
                } message: {
                    Text("ご自身のTavilyのAPIキーを「モデルと設定」で登録すると、Gemmaが必要なときにウェブを検索し、出典付きで答えます。送るのは検索語だけです。")
                }
                // Scroll updates run in transactions that disable animations,
                // which also cut the jump control's merge to a single frame.
                // Mirror the policy into local state with its own transaction.
                .onChange(of: floatingJumpWanted) { _, visible in setJumpVisible(visible) }
                .onChange(of: scrollPolicy.restsAtEnd) { _, _ in updateJumpTuck() }
                // Here, not on 従来型's field: changing the type removes the
                // field, and the pills must still be put away.
                .onChange(of: classicPillsShown) { _, shown in setClassicPillsVisible(shown) }
                .onAppear {
                    jumpPresent = floatingJumpWanted
                    jumpRaised = jumpPresent; jumpIconShown = jumpPresent; jumpGlassShown = jumpPresent
                    classicPillsSettled = classicPillsShown; classicPillRoom = classicPillsShown
                }
                .padding(.horizontal, ChatMetrics.gutter).padding(.top, 8).padding(.bottom, 6)
            if photoRoom {
                // Room for the compact photo sheet, which floats here under
                // the field the way the keyboard would. Its detent height is
                // measured from the bottom safe area, where this bar already
                // ends. Less the stack spacing and the row's bottom padding
                // (6pt each) and the ~7pt the floating card sits below its
                // detent height (measured in the simulator, 1.0.48), the
                // field keeps Messages' gap above the card.
                Color.clear.frame(height: photoSheetHeight + ChatMetrics.photoSheetGap - 19)
                    .accessibilityHidden(true)
            }
        }
        // A line more or less of text grows or shrinks the panel smoothly,
        // the text riding up with its top edge (ComposerTextView keeps the
        // text in place while the frame catches up).
        .animation(reduceMotion ? nil : ChatMotion.resize, value: draft)
        .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: { composerTopGlobal = $0 }
        .anchorPreference(key: ComposerBoundsKey.self, value: .bounds) { $0 }
        .onChange(of: showPhotos) { _, shown in
            withAnimation(reduceMotion ? nil : ChatMotion.resize) { photoRoom = shown }
        }
        .sheet(isPresented: $showPhotos, onDismiss: {
            // Swiped away, or closed from the field. The picker gets a new
            // identity only now, so its grid is not rebuilt while visible.
            guard !showPhotos else { return }
            closePhotoDock()
            photoPickerTicket = UUID()
        }) {
            photoSheet.onChange(of: photoSelection) { old, new in syncPickedPhotos(old: old, new: new) }
        }
    }

    /// 縮小型: the panel and the three buttons it folds into. 従来型: the
    /// plus and the one-line field of 1.0.110 (classicComposer).
    @ViewBuilder private var composerStage: some View {
        if composerStyle == .classic {
            classicComposer
        } else {
            // The panel and the three buttons it folds into share one glass
            // container, as does the jump control that rises out of the
            // panel: the shapes fuse while they part or merge.
            ChatGlassGroup(spacing: ChatMetrics.composerBlend) {
                ZStack(alignment: .bottom) {
                    composerPanel
                    // As in the reference image: a waveform, a round speech
                    // bubble and a down arrow, all in the label color. They
                    // exist only while folded or morphing; at rest the panel
                    // alone is there, for touch and VoiceOver alike.
                    if composerFolded || composerMorphing {
                        foldedButton(-1, symbol: "waveform", size: 19, label: "音声入力", id: "composer-voice",
                                     tuck: jumpTuck) {
                            showVoiceNote = true
                        }
                        foldedButton(0, symbol: "message", size: 19, label: "入力欄を開く", id: "composer-expand",
                                     tuck: jumpTuck) {
                            unfoldComposer()
                        }
                        .accessibilityHint("メッセージをすぐに入力できます")
                        .accessibilityFocused($unfoldFocused)
                        if !jumpTucked {
                            foldedButton(1, symbol: "arrow.down", size: 16, label: "最新のメッセージへ移動", id: "composer-jump",
                                         tuck: jumpTuck, away: jumpTuck > 0.5) {
                                scrollPolicy.requestLatest(); latestRequest += 1
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(height: composerStageHeight, alignment: .bottom)
                .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                    if abs(composerWidth - $0) > 0.5 { composerWidth = $0 }
                }
                #if POCKET_PREVIEW
                // `--fold-button`: a clear target in the panel's top trailing
                // corner folds the composer, so the UI check can photograph
                // the whole fold (a drag returns only once the app is idle
                // again, after the morph).
                .overlay(alignment: .topTrailing) {
                    if PreviewProbe.on("--fold-button") && !composerFolded {
                        Button { foldComposer() } label: {
                            Color.clear.frame(width: 44, height: 44).contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("折りたたむ")
                        .accessibilityIdentifier("probe-fold")
                    }
                }
                #endif
            }
            .overlay(alignment: .bottom) { composerRowOverlay }
        }
    }

    /// The two-row glass panel. The jump control lives in its glass
    /// container: it rises out of the panel and sinks back into it, merging
    /// like Liquid Glass. An overlay keeps it out of the composer's layout.
    private var composerPanel: some View {
        composerField
            // Folded with Reduce Motion, the clear panel keeps its size
            // above the buttons; once settled it takes no taps. (Not from
            // the fold's start, while the field is giving up the keyboard.)
            .allowsHitTesting(!composerSettled)
            .modifier(ComposerPanelMorph(progress: composerMorph, tuck: jumpTuck, width: composerWidth,
                                         height: composerHeight, reduceMotion: reduceMotion) { height in
                if abs(composerHeight - height) > 0.5 { composerHeight = height }
            })
            .chatGlassIdentity("input", in: composerGlass, reduceMotion: reduceMotion)
            .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: {
                // The morph moves this edge on every frame; the jump control
                // only needs it at rest.
                if !composerMorphing && !composerFolded { inputTopGlobal = $0 }
            }
            .overlay(alignment: .top) { risingJump(centerOffset: 0) }
            .allowsHitTesting(!composerFolded)
    }

    /// The jump control over the field it rises out of: centered on the
    /// screen (`centerOffset` from the field's center), sinking straight
    /// down into the field while the shapes fuse.
    @ViewBuilder private func risingJump(centerOffset: CGFloat) -> some View {
        if jumpPresent && !showActions {
            jumpButton
                .offset(x: centerOffset)
                .modifier(JumpSink(offset: jumpRaised || reduceMotion || !jumpFusesIntoField ? 0 : jumpSinkDistance,
                                   scale: jumpRaised || reduceMotion ? 1 : ChatMotion.jumpSunkScale,
                                   opacity: jumpGlassShown ? 1 : 0))
                .offset(y: -(ChatMetrics.control + jumpLift))
                .animation(reduceMotion ? ChatMotion.reducedMenu
                           : (jumpRaised ? ChatMotion.jumpRise : ChatMotion.jumpSink),
                           value: jumpRaised)
                .animation(reduceMotion ? ChatMotion.reducedMenu
                           : (jumpFusesIntoField ? nil : ChatMotion.jumpMaterialize),
                           value: jumpGlassShown)
        }
    }

    /// 従来型 (1.0.110): the plus circle beside a one-line field that holds
    /// send, the jump control rising out of the field, nothing folding.
    /// While the field is typed in, the 高速 and model pills rise above it,
    /// lined up with its leading edge; at rest it stays one line thin. Only
    /// the field, the pills' drops and the jump control share a glass
    /// container; the plus and the pills are menus, each with glass of its
    /// own and in no container (pocket-gemma-menu-glass-afterimage).
    private var classicComposer: some View {
        HStack(alignment: .bottom, spacing: ChatMetrics.controlGap) {
            classicPlusButton
            ChatGlassGroup(spacing: ChatMetrics.classicBlend) {
                classicField
                    .chatGlass(in: RoundedRectangle(cornerRadius: ChatMetrics.control / 2))
                    .chatGlassIdentity("input", in: composerGlass, reduceMotion: reduceMotion)
                    .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: {
                        inputTopGlobal = $0
                    }
                    .overlay(alignment: .topLeading) { classicPillDrops }
                    // Centered on the screen: the field starts after
                    // the plus button.
                    .overlay(alignment: .top) {
                        risingJump(centerOffset: -(ChatMetrics.control + ChatMetrics.controlGap) / 2)
                    }
            }
        }
        // The pills stand on the field's top edge, a row above it, in the
        // bar's room for them (taps outside the bar do not reach them).
        .overlay(alignment: .topLeading) {
            if classicPillsShown || classicPillsSettled {
                classicPills.offset(y: -(ChatMetrics.control + ChatMetrics.chipGap))
            }
        }
        .padding(.top, classicPillRoom ? ChatMetrics.control + ChatMetrics.chipGap : 0)
        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.keyboardFollow, value: classicPillsShown)
    }

    /// The pills show while the field has the keyboard, as long as it can
    /// be typed in (not while the plus panel is open).
    private var classicPillsShown: Bool {
        composerStyle == .classic && inputFocused && !showActions
    }

    /// 高速/深く (E4B) and the model, as in 縮小型's lower row, their glass
    /// edge on the field's leading edge. Laid out (and measured for their
    /// drops) as the field takes the keyboard, seen only once the drops
    /// rest in their place.
    private var classicPills: some View {
        HStack(spacing: 0) {
            if !chats.currentModel.photoDetails.isEmpty {
                photoDetailMenu
                    .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                        classicDetailWidth = $0 - ChatMetrics.chipGap
                    }
            }
            modelMenu
                .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                    classicModelWidth = $0 - ChatMetrics.chipGap
                }
        }
        .padding(.leading, ChatMetrics.control + ChatMetrics.controlGap - ChatMetrics.chipGap / 2)
        .opacity(classicPillsSettled ? 1 : 0)
        .allowsHitTesting(classicPillsShown)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("composer-classic-pills")
        .accessibilityHidden(!classicPillsShown)
    }

    /// The pills on their way out of the field and back into it: drops of
    /// the field's glass in its container, each straight under its pill,
    /// that rise and grow into the pill's capsule. While they touch the
    /// field they are one shape with it; rising, the bridge between them
    /// stretches and snaps (classicBlend). The labels are the drops' own
    /// content, as the jump control's arrow is, and come once they part.
    @ViewBuilder private var classicPillDrops: some View {
        if classicDropsPresent && !reduceMotion {
            HStack(spacing: ChatMetrics.chipGap) {
                if !chats.currentModel.photoDetails.isEmpty {
                    classicDrop(width: classicDetailWidth, lag: 0) { photoDetailPillLabel }
                }
                // The second a moment later, as drops do not part at once.
                classicDrop(width: classicModelWidth, lag: 0.04) { modelPillLabel }
            }
            .offset(y: -(ChatMetrics.chip + (ChatMetrics.control - ChatMetrics.chip) / 2 + ChatMetrics.chipGap))
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
    }

    private func classicDrop<Label: View>(width: CGFloat, lag: Double,
                                          @ViewBuilder label: () -> Label) -> some View {
        label()
            .foregroundStyle(.primary)
            .frame(width: max(0, width - 24))
            .scaleEffect(classicDropLabels ? 1 : 0.7)
            .opacity(classicDropLabels ? 1 : 0)
            .animation(classicDropLabels ? ChatMotion.jumpIconIn : ChatMotion.jumpIconOut, value: classicDropLabels)
            .frame(width: max(0, width), height: ChatMetrics.chip)
            .background(Capsule().fill(Theme.chipFill).opacity(classicDropsRaised && classicDropsGlass ? 1 : 0))
            .chatGlass(in: Capsule(), visible: classicDropsGlass)
            .modifier(JumpSink(offset: classicDropsRaised ? 0 : classicDropSinkDistance,
                               scale: classicDropsRaised ? 1 : ChatMotion.jumpSunkScale, opacity: 1))
            .animation((classicDropsRaised ? ChatMotion.jumpRise : ChatMotion.jumpSink).delay(lag),
                       value: classicDropsRaised)
    }

    /// From a pill's place down until its shrunken drop lies wholly inside
    /// the field's top edge, as the jump control's does.
    private var classicDropSinkDistance: CGFloat {
        ChatMetrics.chipGap + (ChatMetrics.control - ChatMetrics.chip) / 2 + ChatMetrics.chip / 2
            + ChatMotion.jumpSunkDepth
    }

    /// Rise out of / sink into the field, step by step from a task as the
    /// jump control does (setJumpVisible); springs retarget if the field
    /// loses the keyboard on the way. The pills (menus) and the drops
    /// change places without a frame between them: the same shape, place
    /// and label, the glass on one and off the other.
    private func setClassicPillsVisible(_ visible: Bool) {
        classicPillsTask?.cancel()
        let instant: Transaction = { var t = Transaction(); t.disablesAnimations = true; return t }()
        // Drawn outside the bar while they sink, as the jump control is.
        withTransaction(instant) { classicPillRoom = visible }
        if reduceMotion {
            classicDropsPresent = false; classicDropsRaised = false
            classicDropsGlass = false; classicDropLabels = false
            withAnimation(ChatMotion.reducedMenu) { classicPillsSettled = visible }
            return
        }
        if visible {
            if !classicDropsPresent {
                // Mount fused into the field, then rise out of it.
                withTransaction(instant) {
                    classicDropsRaised = false; classicDropLabels = false
                    classicDropsGlass = true; classicDropsPresent = true
                }
            }
            classicPillsTask = Task { @MainActor in
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                // The first time, the pills are measured only now.
                for _ in 0..<6 where classicModelWidth <= 0 {
                    do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                }
                classicDropsGlass = true
                classicDropsRaised = true
                // The labels arrive once the drops have parted.
                do { try await Task.sleep(for: .milliseconds(180)) } catch { return }
                classicDropLabels = true
                // The rise (with the second drop's lag) has settled.
                do { try await Task.sleep(for: .milliseconds(520)) } catch { return }
                withTransaction(instant) {
                    classicPillsSettled = true
                    classicDropsGlass = false; classicDropLabels = false
                }
            }
        } else {
            guard classicDropsPresent || classicPillsSettled else { return }
            if classicPillsSettled {
                withTransaction(instant) {
                    classicPillsSettled = false
                    classicDropsGlass = true; classicDropLabels = true
                    classicDropsRaised = true; classicDropsPresent = true
                }
            }
            classicPillsTask = Task { @MainActor in
                // Let the labels clear first, then sink and fuse.
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                classicDropLabels = false
                do { try await Task.sleep(for: .milliseconds(60)) } catch { return }
                classicDropsRaised = false
                do { try await Task.sleep(for: .milliseconds(460)) } catch { return }
                classicDropsGlass = false
                do { try await Task.sleep(for: .milliseconds(32)) } catch { return }
                classicDropsPresent = false
            }
        }
    }

    /// 1.0.110's field: the text and send in one glass capsule. With web
    /// search on, a globe at its start says so (and turns it off) at rest
    /// too, since search sends the question's words out.
    private var classicField: some View {
        HStack(alignment: .bottom, spacing: 0) {
            if webSearchActive {
                classicWebSearchButton.transition(.scale(scale: 0.6).combined(with: .opacity))
            }
            ChatComposerText(text: $draft,
                focused: $inputFocused,
                enabled: model.isInstalled(chats.currentModel), input: composerInput)
                .padding(.leading, webSearchActive ? 0 : 14)
            sendButton(circle: 30, glyph: 17)
        }
        .frame(minHeight: ChatMetrics.control)
        .animation(reduceMotion ? nil : .smooth(duration: 0.3), value: webSearchActive)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("chat-composer")
        .accessibilityHidden(showActions)
    }

    private var classicWebSearchButton: some View {
        Button { chats.setWebSearch(false) } label: {
            Image(systemName: "globe").font(.system(size: 16, weight: .medium))
                .foregroundStyle(Theme.accent)
                .frame(width: 36, height: ChatMetrics.control)
                .padding(.leading, 4)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(chats.isGenerating)
        .accessibilityLabel("ウェブ検索")
        .accessibilityValue("オン")
        .accessibilityHint("タップでオフにします。オンの間は検索語だけをインターネットに送ります")
        .accessibilityIdentifier("composer-web-search")
    }

    /// 1.0.110's plus: the system glass circle, so the menu morphs out of
    /// it (GlassCircleControl), with the same menu as 縮小型's plus.
    private var classicPlusButton: some View {
        Menu {
            plusMenuItems
        } label: {
            // The glass circle style adds 7pt of padding per side, so a
            // 30pt label gives the shared 44pt circle (iOS 26.4).
            Image(systemName: "plus").font(.system(size: ChatMetrics.icon, weight: .regular))
                .foregroundStyle(.primary)
                .frame(width: 30, height: 30)
        }
        // Keep the written order even though the menu opens upward from the
        // bottom of the screen (automatic order would reverse it there).
        .menuOrder(.fixed)
        .modifier(GlassCircleControl())
        // A neutral glass circle with a label-colored plus, as in Messages;
        // the glass style otherwise paints its label with the app's blue.
        .tint(Color.primary)
        .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        .accessibilityLabel("会話の操作を開く")
        .accessibilityIdentifier("chat-add-menu")
    }

    /// One of the folded composer's buttons. Its glass and symbol follow
    /// the morph (ComposerButtonMorph); it takes taps only while folded.
    private func foldedButton(_ slot: CGFloat, symbol: String, size: CGFloat, label: String, id: String,
                              tuck: CGFloat = 0, away: Bool = false,
                              action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Color.clear
                .frame(width: ChatMetrics.morphButton, height: ChatMetrics.morphButton)
                .contentShape(RoundedRectangle(cornerRadius: ChatMetrics.morphButton / 2, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
        .accessibilityIdentifier(id)
        .modifier(ComposerButtonMorph(progress: composerMorph, tuck: tuck, slot: slot, symbol: symbol, symbolSize: size,
                                      tint: .primary, reduceMotion: reduceMotion))
        // On its way into the chat button, taps go to the chat button.
        .allowsHitTesting(composerFolded && !away)
        .accessibilityHidden(!composerFolded || away)
    }

    /// The bar's height: the panel's while it is shown or morphing (fixed,
    /// so the morph never relays the conversation out), a button's once
    /// folded, and the panel's own natural size at rest.
    private var composerStageHeight: CGFloat? {
        if composerSettled { return ChatMetrics.morphButton }
        if (composerMorphing || composerFolded) && composerHeight > 0 { return composerHeight }
        return nil
    }

    /// The plus, 高速 and model menus open from glass of their own. Without
    /// it the system menu shrank into a bare outline over the panel when it
    /// closed, and the label came back blurred (device recording, 1.0.111).
    /// A 44pt circle (1.0.113) reached the panel's edge: the plus bulged
    /// out of its corner and fused with the 高速 pill. A 12pt drop at each
    /// center (1.0.114) showed on the phone as a stray ring behind each
    /// label, and the light-mode afterimage stayed. Now the glass is each
    /// button's own circle or capsule (ComposerChipStyle), on a row
    /// outside the panel's glass and outside any glass container, so the
    /// buttons never fuse (composerRowOverlay). It is off while the panel
    /// folds, as the row fades away.
    /// 従来型's pills have theirs only while they stand in their place;
    /// on their way out of the field and back, their drops carry it.
    private var menuSourceGlass: Bool {
        composerStyle == .classic ? classicPillsSettled : !composerFolded && !composerMorphing
    }

    /// The jump control over the panel: only while the panel shows, and not
    /// while a drag into older messages is about to fold it.
    private var floatingJumpWanted: Bool {
        scrollPolicy.showsJumpButton && !composerFolded && !foldLeaning
    }

    private var foldAllowed: Bool {
        #if POCKET_PREVIEW
        // Earlier scroll and jump checks read the unfolded composer.
        if PreviewProbe.on("--keep-composer-open") { return false }
        #endif
        return composerStyle == .folding
            && !composerFolded && !chats.messages.isEmpty && !showPhotos && !showActions && !historyVisible
    }

    /// Reading older messages: the panel shrinks and splits into the three
    /// buttons. The draft stays as it is; only the keyboard goes away.
    private func foldComposer() {
        guard foldAllowed else { return }
        composerFolded = true
        inputFocused = false
        // The fold always parts into all three; at the end the latest
        // button flows into the chat button once they have settled.
        jumpTuckID += 1
        var reset = Transaction(); reset.disablesAnimations = true
        withTransaction(reset) { jumpTuck = 0; jumpTucked = false }
        composerMorphID += 1
        let id = composerMorphID
        composerMorphing = true
        // Scroll callbacks run in transactions without animation.
        Task { @MainActor in
            // Unless the chat button already opened it again.
            guard composerMorphID == id, composerFolded else { return }
            withAnimation(reduceMotion ? ChatMotion.reducedComposer : ChatMotion.composerFold) {
                composerMorph = 1
            } completion: {
                guard composerMorphID == id, composerFolded else { return }
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { composerSettled = true; composerMorphing = false }
                updateJumpTuck()
            }
            if UIAccessibility.isVoiceOverRunning {
                unfoldFocused = true
                UIAccessibility.post(notification: .layoutChanged, argument: nil)
            }
        }
    }

    /// Folded, the latest button is needed only away from the end of the
    /// chat: there it flows into the chat button like liquid, reading up
    /// from the end draws it back out, and the latest button's own tap goes
    /// to the end and then lets it flow in (integrated directive,
    /// 2026-10-21). The end is the scroll state's (`restsAtEnd`, with a
    /// band between arriving and leaving), not the fold's: only a settled
    /// fold follows it, the unfold leaves the button where it is, and
    /// nothing here opens the composer. Springs retarget if the reader
    /// turns back halfway.
    private func updateJumpTuck() {
        guard composerSettled else { return }
        jumpTuckID += 1
        let id = jumpTuckID
        // Scroll updates arrive in transactions without animation. The
        // latest call reads the end as it is by then.
        Task { @MainActor in
            guard jumpTuckID == id, composerSettled else { return }
            let inside = scrollPolicy.restsAtEnd
            guard inside != (jumpTuck == 1) else { return }
            if inside {
                withAnimation(reduceMotion ? ChatMotion.reducedJumpTuck : ChatMotion.jumpAbsorb) {
                    jumpTuck = 1
                } completion: {
                    // Still on its way in, not drawn out again meanwhile.
                    guard jumpTuck == 1, composerSettled else { return }
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { jumpTucked = true }
                }
            } else {
                if jumpTucked {
                    // Back in the hierarchy inside the chat button first.
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { jumpTucked = false }
                    do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                    guard jumpTuckID == id else { return }
                }
                withAnimation(reduceMotion ? ChatMotion.reducedJumpTuck : ChatMotion.jumpSplit) { jumpTuck = 0 }
            }
        }
    }

    /// The chat button: the buttons merge back into the panel, and the
    /// field takes the keyboard at once so the draft continues with no
    /// further tap.
    private func unfoldComposer() {
        guard composerFolded else { return }
        composerMorphID += 1
        let id = composerMorphID
        var transaction = Transaction(); transaction.disablesAnimations = true
        withTransaction(transaction) {
            // The panel's room comes back first, so it grows within it.
            composerSettled = false; composerMorphing = true; composerFolded = false
        }
        withAnimation(reduceMotion ? ChatMotion.reducedComposer : ChatMotion.composerUnfold) {
            composerMorph = 0
        } completion: {
            guard composerMorphID == id, !composerFolded else { return }
            composerMorphing = false
        }
        inputFocused = true
        if UIAccessibility.isVoiceOverRunning {
            Task { @MainActor in
                do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                UIAccessibility.post(notification: .layoutChanged, argument: composerInput.textView)
            }
        }
    }

    private func unfoldComposerAtOnce() {
        composerMorphID += 1
        var transaction = Transaction(); transaction.disablesAnimations = true
        withTransaction(transaction) {
            composerFolded = false; composerSettled = false; composerMorphing = false
            composerMorph = 0; foldLeaning = false
        }
    }

    /// Clears everything above the field (guidance, draft attachments) by
    /// the same gap the control previously kept from the composer's edge.
    private var jumpLift: CGFloat {
        // 24 pt above the field. Draft attachments and
        // the import status sit above the field across the center, so then
        // clear the whole composer.
        guard attachments.isEmpty, !isImporting, !classicPillsShown else {
            return max(0, inputTopGlobal - composerTopGlobal) + ChatMetrics.jumpGap
        }
        return ChatMetrics.jumpGap
    }

    /// Rise out of / sink into the field. Sinking travels onto the field's
    /// trailing end while shrinking, so inside the shared glass container the
    /// two shapes fuse; the glass is unmounted only after it has merged.
    private func setJumpVisible(_ visible: Bool) {
        jumpSettle?.cancel()
        // Scroll updates arrive in transactions that disable animations (and
        // with them this view's implicit animations); every step runs from a
        // fresh task instead, and springs retarget if the reader reverses.
        if visible {
            if !jumpPresent {
                jumpRaised = false; jumpIconShown = false
                jumpGlassShown = !reduceMotion && jumpFusesIntoField
                jumpPresent = true
            }
            jumpSettle = Task { @MainActor in
                // Mount fused into the field, then rise out of it.
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                jumpGlassShown = true
                jumpRaised = true
                // The arrow arrives once the circle has separated.
                do { try await Task.sleep(for: .milliseconds(reduceMotion ? 0 : 150)) } catch { return }
                jumpIconShown = true
            }
        } else {
            jumpSettle = Task { @MainActor in
                jumpIconShown = false
                if reduceMotion {
                    jumpGlassShown = false
                    do { try await Task.sleep(for: .milliseconds(200)) } catch { return }
                } else if !jumpFusesIntoField {
                    do { try await Task.sleep(for: .milliseconds(60)) } catch { return }
                    jumpRaised = false; jumpGlassShown = false
                    do { try await Task.sleep(for: .milliseconds(320)) } catch { return }
                } else {
                    // Let the arrow clear first, then sink and fuse.
                    do { try await Task.sleep(for: .milliseconds(60)) } catch { return }
                    jumpRaised = false
                    do { try await Task.sleep(for: .milliseconds(420)) } catch { return }
                    jumpGlassShown = false
                    do { try await Task.sleep(for: .milliseconds(32)) } catch { return }
                }
                guard !floatingJumpWanted else { return }
                jumpPresent = false
            }
        }
    }


    /// Visual only; the tap target is the transparent button in `body`.
    /// The arrow fades on its own timing, but as the glass's content it
    /// never leaves the moving shape.
    private var jumpButton: some View {
        // The arrow is the glass's own content, so the system draws it on
        // top of the material. As an overlay inside the shared container it
        // was rendered under the glass: dimmed, and lensed into blue flecks
        // along the rim.
        Image(systemName: "arrow.down")
            .font(.system(size: ChatMetrics.icon, weight: .medium))
            .foregroundStyle(Theme.accent)
            .scaleEffect(jumpIconShown || reduceMotion ? 1 : 0.5)
            .opacity(jumpIconShown ? 1 : 0)
            .animation(reduceMotion ? ChatMotion.reducedMenu
                       : (jumpIconShown ? ChatMotion.jumpIconIn : ChatMotion.jumpIconOut),
                       value: jumpIconShown)
            .frame(width: ChatMetrics.control, height: ChatMetrics.control)
            .chatGlass(in: Circle())
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }

    /// From its resting place down until the shrunken circle sits wholly
    /// inside the field's top edge, where the shared glass container fuses
    /// the two shapes into one.
    /// Anything above the field (the guidance capsule, draft attachments,
    /// 従来型's pills) would be crossed on the way down; then the circle shrinks and
    /// dematerializes where it rests instead.
    private var jumpFusesIntoField: Bool {
        attachments.isEmpty && !isImporting && !classicPillsShown
    }

    private var jumpSinkDistance: CGFloat {
        jumpLift + ChatMetrics.control / 2 + ChatMotion.jumpSunkDepth
    }

    /// The photo picker as Messages shows it: a sheet resting as a compact
    /// floating card under the field, which a swipe up on the grid grows to
    /// full height and a swipe down returns (or closes). The system drives
    /// that resize, so the embedded grid moves with the sheet instead of
    /// being relaid out frame by frame. The conversation and field stay
    /// usable behind the compact card; tapping the field closes it. Each
    /// tap on a photo adds it to the draft at once; tapping again removes it.
    private var photoSheet: some View {
        PhotosPicker(selection: $photoSelection, maxSelectionCount: 3,
                     selectionBehavior: .continuousAndOrdered, matching: .images,
                     photoLibrary: .shared()) { EmptyView() }
            .photosPickerStyle(.inline)
            .photosPickerDisabledCapabilities([.selectionActions])
            // Messages shows the picker's own bars (albums, search) only
            // at full height; the compact card is the bare grid.
            .photosPickerAccessoryVisibility(photoDetent == .large ? .visible : .hidden, edges: .all)
            .id(photoPickerTicket)
            .ignoresSafeArea(edges: .bottom)
            .presentationDetents([.height(photoSheetHeight), .large], selection: $photoDetent)
            .presentationDragIndicator(.visible)
            .presentationContentInteraction(.resizes)
            .presentationBackgroundInteraction(.enabled(upThrough: .height(photoSheetHeight)))
            // Once a photo is picked, the full-height picker offers the
            // done check on its segmented row, at the trailing edge, as
            // Messages does. At full height the picker's frame starts at the
            // top of the screen (measured on device, 1.0.48), above the
            // sheet's visible top at the status bar's safe area, so the
            // check is placed from that edge rather than the frame's. The
            // frame is read with onGeometryChange: a GeometryReader overlay
            // made the dock's accessibility frame screen-sized (1.0.49-1.0.50).
            // Only the check's slot reads it, so resizing the sheet does not
            // re-render the conversation.
            .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: { photoPickerFrame.top = $0 }
            .overlay(alignment: .topTrailing) {
                PhotoDoneSlot(frame: photoPickerFrame, safeTop: windowSafeTop,
                              visible: showsPhotoDone, reduceMotion: reduceMotion) { photoDoneButton }
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("photo-dock")
    }

    private var showsPhotoDone: Bool { photoDetent == .large && !photoSelection.isEmpty }

    /// Where a full-height sheet's visible top sits on screen.
    private var windowSafeTop: CGFloat {
        (UIApplication.shared.connectedScenes.first { $0.activationState == .foregroundActive } as? UIWindowScene)?
            .keyWindow?.safeAreaInsets.top ?? 0
    }

    /// Back to the conversation; the picked photos stay in the draft.
    private var photoDoneButton: some View {
        Button { closePhotoDock() } label: {
            Image(systemName: "checkmark")
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: ChatMetrics.photoDone, height: ChatMetrics.photoDone)
                .contentShape(Circle())
                .modifier(ProminentGlass(shape: Circle()))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("完了")
        .accessibilityIdentifier("photo-done")
    }

    private var photoCompactHeight: CGFloat { min(340, max(220, viewportHeight * 0.42)) }

    /// Mirror the picker's live selection into draft attachments, in order.
    private func syncPickedPhotos(old: [PhotosPickerItem], new: [PhotosPickerItem]) {
        for item in old where !new.contains(item) {
            if let id = pickedAttachments.removeValue(forKey: item),
               let attachment = attachments.first(where: { $0.id == id }) {
                attachments.removeAll { $0.id == id }; AttachmentStorage.remove(attachment)
            }
        }
        for item in new where !old.contains(item) { enqueuePicked(item) }
    }

    private func enqueuePicked(_ item: PhotosPickerItem) {
        let previous = pickerChain
        let ticket = photoPickerTicket
        let owner = pickerContext
        pickerChain = Task { @MainActor in
            await previous?.value
            @MainActor func stillWanted() -> Bool {
                guard ticket == photoPickerTicket, photoSelection.contains(item), let owner else { return false }
                let thread = chats.selectedID, modelID = chats.currentModel.id
                return owner.matches(threadID: thread, modelID: modelID)
            }
            guard stillWanted() else { return }
            do {
                guard let file = try await item.loadTransferable(type: PickedImageFile.self) else {
                    photoSelection.removeAll { $0 == item }; return
                }
                guard stillWanted() else { try? FileManager.default.removeItem(at: file.url); return }
                if let attachment = await importSingle(file.url) {
                    if stillWanted() { pickedAttachments[item] = attachment.id }
                    else { attachments.removeAll { $0.id == attachment.id }; AttachmentStorage.remove(attachment) }
                } else { photoSelection.removeAll { $0 == item } }
            } catch {
                photoSelection.removeAll { $0 == item }
                chats.error = error.localizedDescription
            }
        }
    }

    /// One staged photo through the same validation as other attachments.
    private func importSingle(_ url: URL) async -> ChatAttachment? {
        defer { try? FileManager.default.removeItem(at: url) }
        guard attachmentPolicy.allowsPhotos else { showAttachmentGuide = true; return nil }
        guard !chats.isGenerating, attachments.count < 3 else {
            chats.error = "添付は1回の送信で3つまでです。"; return nil
        }
        let selectedThread = chats.selectedID, selectedModel = chats.currentModel
        isImporting = true
        defer { isImporting = false }
        do {
            let attachment = try await Task.detached(priority: .userInitiated) {
                try await AttachmentStorage.importFile(url, model: selectedModel)
            }.value
            guard chats.selectedID == selectedThread, chats.currentModel.id == selectedModel.id,
                  attachmentPolicy.allows(attachment) else { AttachmentStorage.remove(attachment); return nil }
            guard attachments.reduce(0, { $0 + $1.imageNames.count }) + attachment.imageNames.count <= 4 else {
                AttachmentStorage.remove(attachment); chats.error = "画像は合計4場面まで添付できます。"; return nil
            }
            attachments.append(attachment)
            return attachment
        } catch {
            chats.error = error.localizedDescription
            return nil
        }
    }

    private func closePhotoDock() {
        showPhotos = false
        // Picked photos stay in the draft; the next panel starts unselected.
        photoSelection = []; pickedAttachments = [:]
        pickerChain?.cancel(); pickerChain = nil
        // A provider may still be staging a selected file after dismissal;
        // with the selection cleared its late callback discards its copies.
        // The sheet's dismissal then gives the picker a new identity.
        pickerContext = nil
    }

    /// Two rows inside one glass panel: the text above, the plus menu and
    /// send (or stop) below, with the keyboard up or down alike. A tap on
    /// the panel's empty space starts typing, as on the field itself.
    private var composerField: some View {
        VStack(spacing: 0) {
            ChatComposerText(text: $draft,
                focused: $inputFocused,
                enabled: model.isInstalled(chats.currentModel), input: composerInput,
                accessible: !composerFolded)
                .frame(minHeight: ChatMetrics.composerTextMinHeight, alignment: .top)
                .padding(.horizontal, ChatMetrics.composerTextInset)
                .padding(.top, 4)
            if menusInPanel {
                composerRow
            } else {
                // The row itself lies over the panel (composerRowOverlay).
                Color.clear.frame(height: ChatMetrics.control + ChatMetrics.composerRowInset)
                    .accessibilityHidden(true)
            }
        }
        .frame(maxWidth: .infinity)
        // Behind the rows, so the field, menu and send keep their own taps.
        .background {
            Color.clear.contentShape(Rectangle())
                .onTapGesture { if model.isInstalled(chats.currentModel) { inputFocused = true } }
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("chat-composer")
        .accessibilityHidden(showActions || composerFolded)
    }

    /// The panel's bottom row: plus, 高速 (E4B), the model, and send.
    private var composerRow: some View {
        HStack(alignment: .center, spacing: 0) {
            // Folded, the panel is hidden under the middle button; its
            // menu and send leave too, so nothing unseen can be reached.
            if composerSettled {
                Color.clear.frame(height: ChatMetrics.control).accessibilityHidden(true)
            } else {
                if menusInPanel {
                    // Their glass blends with nothing nearer than touching:
                    // the panel's group would fuse buttons 8pt apart.
                    ChatGlassGroup(spacing: 0) { composerMenus }
                } else {
                    composerMenus
                }
                Spacer(minLength: 0)
                sendButton
            }
        }
        // The plus and send sit as far in from either edge. Every
        // control's target is 44pt tall and they lie side by side, so no
        // two overlap; the pills keep 8pt between them.
        .padding(.horizontal, ChatMetrics.composerRowInset)
        .padding(.bottom, ChatMetrics.composerRowInset)
    }

    private var composerMenus: some View {
        HStack(alignment: .center, spacing: 0) {
            attachmentMenuButton
            if webSearchActive { webSearchChip.transition(.scale(scale: 0.6).combined(with: .opacity)) }
            if !chats.currentModel.photoDetails.isEmpty { photoDetailMenu }
            modelMenu
        }
        .animation(reduceMotion ? nil : .smooth(duration: 0.3), value: webSearchActive)
    }

    /// Whether the next send may search: the chat's switch, a Gemma model,
    /// and no file in the chat or the draft (WebSearchPolicy).
    private var webSearchActive: Bool {
        WebSearchPolicy.searches(enabled: chats.webSearchOn, keyed: searchKey.isSet, model: chats.currentModel,
                                 messages: chats.messages, attachments: attachments)
    }

    /// While search is on: a pill beside the plus that says so in the
    /// accent color and turns it off. The plus menu turns it on.
    private var webSearchChip: some View {
        Button { chats.setWebSearch(false) } label: {
            ViewThatFits(in: .horizontal) {
                webSearchLabel(named: true)
                webSearchLabel(named: false)
                    .accessibilityShowsLargeContentViewer { Label("ウェブ検索", systemImage: "globe") }
            }
        }
        .modifier(ComposerChipButton(inStyle: true, glass: menuSourceGlass, shape: Capsule()))
        .disabled(chats.isGenerating)
        .accessibilityLabel("ウェブ検索")
        .accessibilityValue("オン")
        .accessibilityHint("タップでオフにします。オンの間は検索語だけをインターネットに送ります")
        .accessibilityIdentifier("composer-web-search")
    }

    private func webSearchLabel(named: Bool) -> some View {
        WholePointWidth {
            HStack(spacing: 4) {
                Image(systemName: "globe").font(.system(size: 14, weight: .medium))
                if named { Text("検索").font(.subheadline.weight(.medium)) }
            }
            .foregroundStyle(Theme.accent)
        }
    }

    /// The row over the panel, outside its glass and outside every glass
    /// container, the way a glass button stands on its own over content.
    /// Inside them (1.0.111-1.0.114), each system menu grew out of a
    /// label nested in the panel's glass: on the phone, light mode showed an
    /// afterimage behind the plus and 高速 menus while they opened and
    /// closed (the developer forums report dark flashes and halos for
    /// menus inside glass, and broken morphs inside glass containers).
    /// It fades and shrinks with the panel's content as the panel folds.
    @ViewBuilder private var composerRowOverlay: some View {
        if !menusInPanel && !composerSettled {
            composerRow
                .modifier(ComposerRowFade(progress: composerMorph, reduceMotion: reduceMotion))
                .allowsHitTesting(!composerFolded)
                .accessibilityHidden(showActions || composerFolded)
        }
    }

    /// `--menus-in-panel` (UI check only) puts the row back inside the
    /// panel's glass as in 1.0.114, to compare their menu frames.
    private var menusInPanel: Bool {
        #if POCKET_PREVIEW
        PreviewProbe.on("--menus-in-panel")
        #else
        false
        #endif
    }

    /// E4B only: how it reads photos and writes replies (高速 or 深く, and
    /// さらに深く where the launch offers it), a pill beside the plus that
    /// shows the saved choice and changes it from a menu. 高速 also answers
    /// chats without photos briefly and faster, so the pill stays in every
    /// E4B chat. The choice applies from the next send, so it waits while a
    /// reply is written. The model pill follows it.
    private var photoDetailMenu: some View {
        Menu {
            Picker("返事のモード", selection: Binding(get: { chats.photoDetail }, set: { chats.setPhotoDetail($0) })) {
                ForEach(chats.currentModel.photoDetails) { detail in
                    Label(detail.title, systemImage: photoDetailSymbol(detail)).tag(detail)
                }
            }
            .pickerStyle(.inline)
        } label: {
            photoDetailPillLabel
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        .menuOrder(.fixed)
        .tint(Color.primary)
        .disabled(chats.isGenerating)
        .accessibilityLabel("返事のモード")
        .accessibilityValue(chats.photoDetail.title)
        .accessibilityHint("高速は短く速く答えます。深くは写真をより細かく読み、いつもの長さで答えます。返事は少し遅くなります"
                           + (chats.currentModel.photoDetails.contains(.deeper)
                              ? "。さらに深くは写真を最も細かく読み、よく考えてから答えます。返事はもっと遅くなります" : ""))
        .accessibilityIdentifier("composer-photo-detail")
    }

    /// さらに深く is the longest name. Where the row has no room for it
    /// (large text), the pill says 深く＋, then 深く beside its own symbol,
    /// at the same size, so it needs no more room than 深く's pill. Where
    /// no name fits (the largest text on a narrow phone), any mode shows its
    /// symbol alone, whose name a long press shows large, as a bar's
    /// buttons do. The capsule stays 36pt.
    private var photoDetailPillLabel: some View {
        let names = photoDetailNames(chats.photoDetail)
        return ViewThatFits(in: .horizontal) {
            photoDetailLabel(names.full)
            photoDetailLabel(names.short)
            photoDetailLabel(names.shortest)
            photoDetailLabel(nil)
                .accessibilityShowsLargeContentViewer {
                    Label(chats.photoDetail.title, systemImage: photoDetailSymbol(chats.photoDetail))
                }
        }
    }

    private func photoDetailSymbol(_ detail: PhotoDetail) -> String {
        switch detail {
        case .fast: "bolt"
        case .deep: "sparkle.magnifyingglass"
        case .deeper: "brain"
        }
    }

    /// The pill's names, longest first. Only さらに深く has shorter ones: at
    /// the largest text 深く＋ was cut short to 深… (run 39693690687).
    private func photoDetailNames(_ detail: PhotoDetail) -> (full: String, short: String, shortest: String) {
        detail == .deeper ? (detail.title, "深く＋", "深く") : (detail.title, detail.title, detail.title)
    }

    /// The pill's content: the mode's symbol, a name unless none fits, and
    /// the menu's chevron, in a width of whole points (WholePointWidth).
    private func photoDetailLabel(_ name: String?) -> some View {
        WholePointWidth {
            HStack(spacing: 4) {
                Image(systemName: photoDetailSymbol(chats.photoDetail))
                    .font(.system(size: 13, weight: .medium))
                if let name { Text(name).font(.subheadline.weight(.medium)) }
                Image(systemName: "chevron.down")
                    .font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
            }
        }
    }

    /// The model pill: Pocket AI's models by family in a system menu. Gemma 4
    /// is a submenu of E2B and E4B, so the family alone never switches; the
    /// developer models follow it only while developer settings are on.
    /// The current model has the check. Choosing another opens a new chat
    /// with it, as the model list does, carrying the draft's text.
    private var modelMenu: some View {
        Menu {
            Section {
                Menu {
                    ForEach(gemmaModels) { spec in modelItem(spec) }
                } label: {
                    Text("Gemma 4")
                    Text(chats.currentModel.family == ModelSpec.e4b.family
                         ? "\(shortModelName(chats.currentModel))を使用中" : "E2B・E4B")
                }
                .accessibilityIdentifier("model-menu-gemma")
                ForEach(otherModels) { spec in modelItem(spec) }
            }
            Section {
                Button { showModel = true } label: {
                    Label("モデルを管理", systemImage: "square.stack.3d.up")
                }
                .accessibilityIdentifier("model-menu-manage")
            }
        } label: {
            modelPillLabel
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        .menuOrder(.fixed)
        .tint(Color.primary)
        .disabled(chats.isGenerating)
        .accessibilityLabel("モデルを選ぶ")
        .accessibilityValue(chats.currentModel.name)
        .accessibilityHint("新しい会話を別のモデルで始めます")
        .accessibilityIdentifier("composer-model")
    }

    private var modelPillLabel: some View {
        HStack(spacing: 4) {
            Text(shortModelName(chats.currentModel)).font(.subheadline.weight(.medium)).lineLimit(1)
            Image(systemName: "chevron.down")
                .font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
        }
    }

    private var gemmaModels: [ModelSpec] {
        ModelSpec.visibleCatalog(developer: showDeveloperSettings)
            .filter { $0.family == ModelSpec.e4b.family }.sorted { $0.name < $1.name }
    }

    private var otherModels: [ModelSpec] {
        ModelSpec.visibleCatalog(developer: showDeveloperSettings).filter { $0.family != ModelSpec.e4b.family }
    }

    /// E2B and E4B within Gemma 4; other models by their whole name.
    private func shortModelName(_ spec: ModelSpec) -> String {
        spec.family == ModelSpec.e4b.family ? spec.name.replacingOccurrences(of: "Gemma 4 ", with: "") : spec.name
    }

    /// A checkable item: the system menu draws the check before the title.
    private func modelItem(_ spec: ModelSpec) -> some View {
        Toggle(isOn: Binding(get: { chats.currentModel.id == spec.id },
                             set: { if $0 { switchModel(to: spec) } })) {
            Text(spec.name)
            Text(modelStatus(spec))
        }
        .accessibilityIdentifier("model-menu-\(spec.id)")
    }

    private func modelStatus(_ spec: ModelSpec) -> String {
        if model.isDownloading(spec) { return "ダウンロード中 \(Int((model.progress(for: spec) * 100).rounded()))%" }
        if model.isWorking(on: spec) { return model.statusText(for: spec) }
        if !model.isInstalled(spec) { return "未ダウンロード・選ぶと準備できます" }
        return ModelAttachmentPolicy(model: spec).summary
    }

    private var sendButton: some View { sendButton(circle: ChatMetrics.sendButton, glyph: 18) }

    /// Send, or stop while a reply is written: a `circle` in a 44pt target.
    /// The panel's is 34pt, 従来型's field keeps 1.0.110's 30pt.
    private func sendButton(circle: CGFloat, glyph: CGFloat) -> some View {
        Button {
            if chats.isGenerating { chats.stop() }
            else { send() }
        } label: {
            Image(systemName: chats.isGenerating ? "stop.fill" : "arrow.up")
                .contentTransition(reduceMotion ? .identity : .symbolEffect(.replace))
                .font(.system(size: chats.isGenerating ? glyph - 6 : glyph, weight: .bold))
                .foregroundStyle(.white).frame(width: circle, height: circle)
                .background(chats.isGenerating || canSend ? Theme.accent : Color(uiColor: .systemGray3), in: Circle())
                .frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Rectangle())
        }
        .accessibilityLabel(chats.isGenerating ? "回答を停止する" : "送信する")
        .disabled(chats.isStopping || (!chats.isGenerating && !canSend))
        .buttonStyle(.plain)
    }

    private var attachmentMenuButton: some View {
        Menu {
            plusMenuItems
        } label: {
            // A label-colored plus in a glass circle as tall as the pills
            // (ComposerChipStyle).
            Image(systemName: "plus").font(.system(size: 17, weight: .medium))
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Circle(),
                                            width: ChatMetrics.chip))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Circle(),
                                     width: ChatMetrics.chip))
        // Keep the written order even though the menu opens upward from the
        // bottom of the screen (automatic order would reverse it there).
        .menuOrder(.fixed)
        .tint(Color.primary)
        .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        .accessibilityLabel("会話の操作を開く")
        .accessibilityIdentifier("chat-add-menu")
    }

    /// The plus menu: attachments, web search and the conversation actions.
    @ViewBuilder private var plusMenuItems: some View {
        // A model that takes no attachments (Qwen) offers none of them;
        // the conversation actions below stay.
        if attachmentPolicy.allowsAnyAttachment {
            Section {
                // A text-only model reads only the photo's text, and says so.
                menuItem("写真", icon: "photo.on.rectangle", id: "chat-attach-photos",
                         subtitle: attachmentPolicy.readsPhotoText ? "文字だけ読み取り" : nil,
                         locked: !attachmentPolicy.allowsPhotos,
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3) {
                    if attachmentPolicy.allowsPhotos { openPicker(photos: true) } else { showAttachmentGuide = true }
                }
                menuItem("カメラ", icon: "camera", id: "chat-attach-camera", locked: true,
                         disabled: chats.isGenerating || isImporting) { showAttachmentGuide = true }
                menuItem("ファイル", icon: "folder", id: "chat-attach-files",
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3) {
                    openPicker(photos: false)
                }
                menuItem("動画", icon: "video", id: "chat-attach-video", locked: true,
                         disabled: chats.isGenerating || isImporting) { showAttachmentGuide = true }
            }
        }
        // Gemma may search the web for this chat. Off by default; a chat
        // with a file stays offline. Without the person's Tavily key the
        // row says where to register one.
        if chats.webSearchOffered {
            Section {
                if searchKey.isSet {
                    Toggle(isOn: Binding(get: { chats.webSearchOn && !chats.webSearchBlocked },
                                         set: { chats.setWebSearch($0) })) {
                        Text("ウェブ検索")
                        Text(chats.webSearchBlocked ? "ファイル付きの会話では使えません"
                             : chats.webSearchOn ? "検索語だけを送ります" : "オフ・端末の中だけで答えます")
                        Image(systemName: "globe")
                    }
                    .disabled(chats.isGenerating || chats.webSearchBlocked)
                    .accessibilityIdentifier("chat-web-search")
                } else {
                    menuItem("ウェブ検索", icon: "globe", id: "chat-web-search",
                             subtitle: chats.webSearchBlocked ? "ファイル付きの会話では使えません" : "Tavilyのキーを登録すると使えます",
                             disabled: chats.isGenerating || chats.webSearchBlocked) { showWebSearchKeyNote = true }
                }
            }
        }
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
            Section {
                ForEach(PreviewAttachments.names, id: \.self) { name in
                    menuItem(name, icon: "doc", id: name, disabled: isImporting || chats.isGenerating) {
                        if let url = PreviewAttachments.url(name) { importAttachments([url], temporary: false) }
                    }
                }
            }
        }
        #endif
        Section {
            menuItem("新しい会話", icon: "square.and.pencil", disabled: chats.isGenerating) { chats.newChat() }
            menuItem("会話一覧", icon: "bubble.left.and.bubble.right") { historySidebar?.open() }
            menuItem("モデルと設定", icon: "slider.horizontal.3") { showModel = true }
        }
    }

    /// A menu row. Locked items stay selectable and explain how to use them;
    /// they show a lock and a "調整中" subtitle instead of looking disabled.
    private func menuItem(_ title: String, icon: String, id: String? = nil, subtitle: String? = nil, locked: Bool = false,
                          disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
            if locked { Text("調整中") } else if let subtitle { Text(subtitle) }
            Image(systemName: locked ? "lock" : icon)
        }
        .disabled(disabled)
        .accessibilityIdentifier(id ?? title)
        .accessibilityValue(locked ? "現在調整中" : subtitle ?? "")
    }

    private var actionMenuHeight: CGFloat {
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") { return 460 }
        #endif
        return min(460, menuRowHeight * 7 + 32)
    }
    private func actionRow(_ title: String, icon: String, tint: Color, locked: Bool = false, disabled: Bool = false,
                           action: @escaping () -> Void) -> some View {
        Button {
            closeActions()
            action()
        } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 17, weight: .medium)).foregroundStyle(tint)
                    .frame(width: 32, height: 32)
                    .background(tint.opacity(0.12), in: Circle())
                Text(title).font(.body.weight(.medium)).foregroundStyle(.primary).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                if locked { Image(systemName: "lock.fill").font(.caption).foregroundStyle(.secondary).accessibilityHidden(true) }
            }
            .frame(maxWidth: .infinity, minHeight: menuRowHeight, alignment: .leading).padding(.horizontal, 6)
            .contentShape(Rectangle())
        }
        .accessibilityLabel(title)
        .accessibilityValue(locked ? "現在調整中" : "")
        .accessibilityHint(locked ? "利用できる方法を確認します" : "")
        .buttonStyle(.plain).disabled(disabled).opacity(disabled ? 0.4 : 1)
    }
    private func switchToE2B() { switchModel(to: .e2b) }

    /// The model list's path (ModelView): a new chat with the model, the
    /// previous model's memory released, and only the draft's text carried
    /// over; draft photos and files stay behind. A model that is not saved
    /// on the phone opens the model list instead.
    private func switchModel(to spec: ModelSpec) {
        guard !chats.isGenerating, spec.id != chats.currentModel.id else { return }
        guard model.isInstalled(spec) else { showModel = true; return }
        draftToRestore = composerInput.committedText(fallback: draft)
        inputFocused = false
        model.select(spec)
        chats.newChat(modelID: spec.id)
        chats.releaseModelMemory()
    }
    private func openPicker(photos: Bool) {
        pickerContext = AttachmentImportContext(threadID: chats.selectedID, modelID: chats.currentModel.id)
        if photos {
            inputFocused = false
            photoPickerTicket = UUID()
            photoSheetHeight = photoCompactHeight
            photoDetent = .height(photoSheetHeight)
            showPhotos = true
        } else { showFiles = true }
    }
    private func openActions() {
        inputFocused = false
        if showPhotos { closePhotoDock() }
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen) { showActions = true }
    }
    private func closeActions() {
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuClose) { showActions = false }
    }
    private func send() {
        let committed = composerInput.committedText(fallback: draft)
        let id = UUID()
        arrivingMessageID = id
        guard chats.send(committed, messageID: id, attachments: attachments) else { arrivingMessageID = nil; return }
        inputFocused = false
        composerInput.clearAndDismiss()
        draft = ""; attachments = []
        pickedAttachments = [:]; photoSelection = []
        if showPhotos { closePhotoDock() }
        scrollPolicy.requestLatest(); latestRequest += 1
        arrivalCleanup?.cancel()
        arrivalCleanup = Task {
            do { try await Task.sleep(for: .milliseconds(650)) } catch { return }
            if arrivingMessageID == id { arrivingMessageID = nil }
        }
    }
    private func clearTransientState() {
        showPhotos = false; showActions = false
        photoSelection = []; pickedAttachments = [:]
        pickerChain?.cancel(); pickerChain = nil
        photoPickerTicket = UUID()
        pickerContext = nil
        arrivalCleanup?.cancel(); arrivingMessageID = nil
        scrollTask?.cancel(); scrollTask = nil
        importTask?.cancel(); importID = nil; isImporting = false
        for attachment in attachments { AttachmentStorage.remove(attachment) }
        attachments = []
    }
    private func importAttachments(_ urls: [URL], temporary: Bool) {
        func discardStaged() { if temporary { for url in urls { try? FileManager.default.removeItem(at: url) } } }
        guard !urls.isEmpty else { return }
        guard attachmentPolicy.allowsAnyAttachment else { discardStaged(); showAttachmentGuide = true; return }
        guard !isImporting, !chats.isGenerating else { discardStaged(); return }
        guard attachments.count + urls.count <= 3 else { discardStaged(); chats.error = "添付は1回の送信で3つまでです。"; return }
        let ticket = UUID(); importID = ticket
        let selectedThread = chats.selectedID, selectedModel = chats.currentModel
        isImporting = true
        importTask = Task { @MainActor in
            defer {
                discardStaged()
                if importID == ticket { isImporting = false; importID = nil }
            }
            for url in urls {
                guard !Task.isCancelled else { return }
                do {
                    let attachment = try await Task.detached(priority: .userInitiated) {
                        try await AttachmentStorage.importFile(url, model: selectedModel)
                    }.value
                    guard !Task.isCancelled, importID == ticket, chats.selectedID == selectedThread,
                          chats.currentModel.id == selectedModel.id else { AttachmentStorage.remove(attachment); return }
                    guard attachmentPolicy.allows(attachment) else {
                        AttachmentStorage.remove(attachment); showAttachmentGuide = true; continue
                    }
                    guard attachments.reduce(0, { $0 + $1.imageNames.count }) + attachment.imageNames.count <= 4 else {
                        AttachmentStorage.remove(attachment); chats.error = "画像は合計4場面まで添付できます。"; continue
                    }
                    attachments.append(attachment)
                } catch { if !Task.isCancelled, importID == ticket, chats.selectedID == selectedThread { chats.error = error.localizedDescription } }
            }
        }
    }
}

struct MessageView: View, Equatable {
    let message: ChatMessage
    let oppositeInset: CGFloat
    var hasTail = true
    var animateArrival = false
    var timestampReveal: CGFloat = 0
    /// It answers a message that asked for a chart: chart data the model
    /// fenced as JSON is drawn as a chart too.
    var answersChartRequest = false
    /// The Aurora Orb's place in a reply: breathing while the model thinks,
    /// leaving from the first token, and gone before the text may show.
    @State private var orb: OrbPhase
    /// How much of the reply is laid out: about a second behind the model,
    /// at the model's own pace smoothed (ReplyPacer), so a burst of tokens
    /// still reads as writing. Off with Reduce Motion, VoiceOver and the
    /// instant-text probe.
    @State private var pacer: ReplyPacer
    @State private var shown: Int
    @State private var catchingUp = false
    @State private var voiceOver = UIAccessibility.isVoiceOverRunning
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var outgoing: Bool { message.role == .user }

    enum OrbPhase: Equatable { case waiting, leaving(Date), gone }

    init(message: ChatMessage, oppositeInset: CGFloat, hasTail: Bool = true,
         animateArrival: Bool = false, timestampReveal: CGFloat = 0, answersChartRequest: Bool = false) {
        self.message = message
        self.oppositeInset = oppositeInset
        self.hasTail = hasTail
        self.animateArrival = animateArrival
        self.timestampReveal = timestampReveal
        self.answersChartRequest = answersChartRequest
        let thinking = message.role != .user && message.state == .generating && message.text.isEmpty
        _orb = State(initialValue: thinking ? .waiting : .gone)
        // A reply already under way when its row is made shows what it has.
        let text = Self.readText(message, charts: answersChartRequest)
        let laidOut = thinking ? 0 : text.count
        _pacer = State(initialValue: ReplyPacer(text: text, generating: message.state == .generating,
                                                held: thinking, shown: laidOut))
        _shown = State(initialValue: laidOut)
    }

    /// What the row shows depends on these alone; the orb's phase is the
    /// row's own state.
    static func == (lhs: MessageView, rhs: MessageView) -> Bool {
        lhs.message == rhs.message && lhs.oppositeInset == rhs.oppositeInset && lhs.hasTail == rhs.hasTail
            && lhs.animateArrival == rhs.animateArrival && lhs.timestampReveal == rhs.timestampReveal
            && lhs.answersChartRequest == rhs.answersChartRequest
    }
    #if POCKET_PREVIEW
    private static let plainReplies = PreviewProbe.on("--probe-plain-replies")
    private static let instantText = PreviewProbe.on("--probe-instant-text")
    #else
    private static let plainReplies = false
    private static let instantText = false
    #endif

    var body: some View {
        let displayed = displayedText
        let awaiting = awaiting(displayed)
        HStack(alignment: .bottom, spacing: 0) {
            if outgoing { Spacer(minLength: oppositeInset) }
            VStack(alignment: outgoing ? .trailing : .leading, spacing: 4) {
                // A reply that searched says what it sent before its text.
                if !outgoing, let search = message.webSearch, !search.isEmpty {
                    WebSearchHeader(record: search, generating: message.state == .generating)
                        .padding(.horizontal, ChatMetrics.replyInset)
                        .transition(.opacity)
                }
                Group {
                    if awaiting {
                        // One hidden line of reply text holds the place of
                        // the reply's first line while the orb shows, so
                        // nothing moves when the text takes over.
                        Text(verbatim: "あ").hidden().accessibilityHidden(true)
                            .font(ChatMetrics.replyFont)
                            .padding(.vertical, ChatMetrics.bubbleVertical)
                            .padding(.horizontal, ChatMetrics.replyInset)
                    } else {
                        VStack(alignment: .leading, spacing: 4) {
                            ForEach(message.media) { attachment in AttachmentCard(attachment: attachment) }
                            Group {
                            if !outgoing && !displayed.isEmpty && !Self.plainReplies {
                                // The same laid-out text is not chunked
                                // and parsed again for each piece the model
                                // writes behind it.
                                MarkdownReplyView(text: displayed, isStreaming: message.state == .generating || catchingUp,
                                                  original: message.text)
                                    .equatable()
                                    // The pace the text is laid out at, so
                                    // its characters appear to that rhythm
                                    // whatever the steps bring.
                                    .environment(\.replyCadence, ReplyCadence(pace: pacer.pace,
                                                                              step: ReplyPacer.interval(forLength: shown)))
                            } else {
                                Text(displayed.isEmpty ? (message.state == .failed ? "回答を生成できませんでした" : "回答を停止しました") : displayed)
                            }
                            }
                        }
                            .font(outgoing ? ChatMetrics.messageFont : ChatMetrics.replyFont).lineSpacing(1)
                            #if POCKET_PREVIEW
                            .modifier(ProbeTextSelection())
                            #else
                            .textSelection(.enabled)
                            #endif
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.vertical, ChatMetrics.bubbleVertical)
                            .padding(.leading, outgoing ? ChatMetrics.bubbleInset : ChatMetrics.replyInset)
                            .padding(.trailing, outgoing ? ChatMetrics.bubbleTailInset : ChatMetrics.replyInset)
                    }
                }
                .foregroundStyle(outgoing ? Color.white : Color.primary)
                // A reply has no bubble and runs the width of the
                // conversation, as in ChatGPT; only sent messages are bubbles.
                .frame(maxWidth: outgoing ? nil : .infinity, alignment: .leading)
                .overlay(alignment: .topLeading) {
                    if !outgoing && message.state == .generating && orb != .gone {
                        ReplyOrb(leavingSince: leavingSince)
                    }
                }
                .background {
                    if outgoing { MessageBubble(outgoing: true, hasTail: hasTail).fill(Theme.accent) }
                }
                // Without a bubble, the blank beside a short line still
                // opens the reply's copy menu.
                .contentShape(.interaction, Rectangle())
                .modifier(OutgoingArrival(animate: outgoing && animateArrival))
                .contextMenu {
                    if !message.text.isEmpty {
                        Button("コピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.text }
                    }
                }
                // The pages it read, once the reply is written.
                if !outgoing, message.state != .generating, !catchingUp,
                   let sources = message.webSearch?.sources, !sources.isEmpty {
                    WebSearchSources(sources: sources)
                        .padding(.horizontal, ChatMetrics.replyInset - 4)
                        .padding(.top, 4)
                        .transition(.opacity)
                }
                if message.state == .stopped || message.state == .failed {
                    Text(message.state == .stopped ? "停止した回答" : "回答を生成できませんでした")
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                        .padding(.horizontal, outgoing ? 9 : ChatMetrics.replyInset)
                }
            }
            .offset(x: -72 * timestampReveal)
        }
        .overlay(alignment: .trailing) {
            Text(message.createdAt, style: .time)
                .font(.system(size: 11)).foregroundStyle(.secondary)
                .frame(width: 64).opacity(Double(timestampReveal))
                .accessibilityHidden(timestampReveal == 0)
        }
        .accessibilityElement(children: message.media.isEmpty && !hasControls ? .combine : .contain)
        // The first token sends the orb away; stopping or failing removes
        // it at once.
        .onChange(of: message.text) { _, text in
            pacer.text = Self.readText(message, charts: answersChartRequest)
            if !text.isEmpty { orbLeaves() }
        }
        .onChange(of: message.state) { _, state in
            pacer.text = Self.readText(message, charts: answersChartRequest)
            pacer.generating = state == .generating
            if state != .generating {
                setOrb(.gone)
                // Whatever came with the end is laid out at the pace too.
                catchingUp = paced && !pacer.caughtUp
            }
        }
        // Lay the reply out at a pace while it is written, and catch up
        // once it has ended.
        .task(id: message.state) {
            guard paced, message.state == .generating || catchingUp else { return }
            while !Task.isCancelled {
                if let count = pacer.advance(at: Date().timeIntervalSinceReferenceDate) {
                    shown = count
                    NotificationCenter.default.post(name: ReplyPacer.revealed, object: nil)
                }
                let behind = !pacer.caughtUp
                if catchingUp != behind { catchingUp = behind }
                if !behind && !pacer.generating { break }
                // About 24 steps a second, fewer as the reply grows long:
                // each step has the reply's last chunk parsed and laid out
                // again, and its characters start one after another on a
                // schedule at the pace (RevealingRichText), whatever the
                // step's size.
                try? await Task.sleep(for: .seconds(ReplyPacer.interval(forLength: pacer.shown)))
            }
        }
    }

    /// Whether this reply's text is laid out at a pace rather than as it
    /// comes.
    private var paced: Bool {
        !outgoing && !Self.instantText && !systemReduceMotion && !previewReduceMotion && !voiceOver
    }

    /// The reply's text as laid out so far.
    private var displayedText: String {
        let text = Self.readText(message, charts: answersChartRequest)
        guard paced, message.state == .generating || catchingUp else { return text }
        return String(text.prefix(shown))
    }

    /// The text the reply is laid out from and paced through: the model's,
    /// with its charts read as it meant them (a chart block wrapped in
    /// another fence, and in an answer to a chart request JSON chart data).
    private static func readText(_ message: ChatMessage, charts: Bool) -> String {
        guard message.role != .user else { return message.text }
        return MarkdownSource.readingCharts(message.text, generating: message.state == .generating, requested: charts)
    }

    /// A reply being written that has nothing to show yet: the Aurora Orb
    /// holds its place until it has gone, and the place stays blank until
    /// the first text that draws.
    private func awaiting(_ displayed: String) -> Bool {
        !outgoing && message.state == .generating
            && (orb != .gone || !ReplyVisibility.drawsText(displayed, markdown: !Self.plainReplies))
    }

    private var leavingSince: Date? {
        if case .leaving(let since) = orb { return since }
        return nil
    }

    private func setOrb(_ phase: OrbPhase) {
        orb = phase
        pacer.held = phase != .gone
    }

    /// The first token has come: the orb shrinks away (or fades, where it
    /// cannot shrink), and the text waits until it has gone.
    private func orbLeaves() {
        guard orb == .waiting else { return }
        let since = Date()
        setOrb(.leaving(since))
        let wait = AuroraOrbView.exitDuration(reduceMotion: systemReduceMotion || previewReduceMotion)
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(wait))
            if orb == .leaving(since) { setOrb(.gone) }
        }
    }

    /// A reply with code, images or links (its search's pages too) has
    /// buttons of its own, which a combined accessibility element would hide.
    private var hasControls: Bool {
        !outgoing && (["```", "~~~", "![", "](", "http", "|"].contains { message.text.contains($0) }
                      || message.webSearch?.sources.isEmpty == false)
    }
}

struct MessageBubble: Shape {
    var outgoing: Bool
    var hasTail = true

    func path(in rect: CGRect) -> Path {
        // Cubic quarter-circles stay round even for a reply taller than the
        // viewport. The short curved tail is part of this same outline.
        var path = Path()
        let left = rect.minX, top = rect.minY, bottom = rect.maxY
        let right = rect.maxX - 6
        let radius = max(0, min(18, min((rect.width - 6) / 2, rect.height / 2)))
        let curve = radius * 0.5522847498
        path.move(to: CGPoint(x: left + radius, y: top))
        path.addLine(to: CGPoint(x: right - radius, y: top))
        path.addCurve(to: CGPoint(x: right, y: top + radius),
                      control1: CGPoint(x: right - radius + curve, y: top),
                      control2: CGPoint(x: right, y: top + radius - curve))
        path.addLine(to: CGPoint(x: right, y: bottom - radius))
        if hasTail {
            path.addCurve(to: CGPoint(x: rect.maxX, y: bottom),
                          control1: CGPoint(x: right, y: bottom - 7),
                          control2: CGPoint(x: right + 1, y: bottom - 3))
            path.addCurve(to: CGPoint(x: right - 8, y: bottom - 4),
                          control1: CGPoint(x: right + 1, y: bottom),
                          control2: CGPoint(x: right - 4, y: bottom - 1))
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right - 11, y: bottom - 1),
                          control2: CGPoint(x: right - 14, y: bottom))
        } else {
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right, y: bottom - radius + curve),
                          control2: CGPoint(x: right - radius + curve, y: bottom))
        }
        path.addLine(to: CGPoint(x: left + radius, y: bottom))
        path.addCurve(to: CGPoint(x: left, y: bottom - radius),
                      control1: CGPoint(x: left + radius - curve, y: bottom),
                      control2: CGPoint(x: left, y: bottom - radius + curve))
        path.addLine(to: CGPoint(x: left, y: top + radius))
        path.addCurve(to: CGPoint(x: left + radius, y: top),
                      control1: CGPoint(x: left, y: top + radius - curve),
                      control2: CGPoint(x: left + radius - curve, y: top))
        path.closeSubpath()
        if !outgoing {
            return path.applying(CGAffineTransform(a: -1, b: 0, c: 0, d: 1, tx: rect.minX + rect.maxX, ty: 0))
        }
        return path
    }
}

/// Where the photo picker sits on screen, observed only by the done
/// check's slot.
@Observable final class PhotoPickerFrame {
    var top: CGFloat = 0
}

/// The photo sheet's done check, centered on the picker's segmented row
/// below the full-height sheet's visible top.
private struct PhotoDoneSlot<Check: View>: View {
    let frame: PhotoPickerFrame
    let safeTop: CGFloat
    let visible: Bool
    let reduceMotion: Bool
    @ViewBuilder let check: Check

    var body: some View {
        ZStack {
            if visible {
                check.transition(reduceMotion ? AnyTransition.opacity : AnyTransition.scale(scale: 0.5).combined(with: .opacity))
            }
        }
        .padding(.top, max(0, safeTop - frame.top) + ChatMetrics.photoDoneRowCenter - ChatMetrics.photoDone / 2)
        .padding(.trailing, 16)
        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen, value: visible)
    }
}

/// Lays its content out in a width of whole points. A menu's label is laid
/// out again in the frame the row gave the menu, and the pill's
/// ViewThatFits chooses again there. Snapped to the screen's pixels, that
/// frame came out a little narrower than 深く's name, so the pill showed
/// its symbol alone in 深く's room, 44pt from either neighbour (the largest
/// text on a 402pt phone, run 39697821838). A width of whole points stays
/// as it is when snapped, so both choices agree.
private struct WholePointWidth: Layout {
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let subview = subviews.first else { return .zero }
        let size = subview.sizeThatFits(proposal)
        return CGSize(width: size.width.rounded(.up), height: size.height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: CGPoint(x: bounds.midX, y: bounds.midY), anchor: .center,
                              proposal: ProposedViewSize(width: bounds.width, height: bounds.height))
    }
}
