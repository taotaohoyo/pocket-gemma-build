import SwiftUI
import UIKit
import PocketCore
import UniformTypeIdentifiers
import PhotosUI

struct ChatView: View {
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @Environment(\.historyVisible) private var historyVisible
    /// Beside the iPad's history: the history's width and the column the
    /// conversation keeps either way (1.1.0 (242)); nil on the phone.
    /// Whether the history shows is read only by what moves with it
    /// (BesideShift, HistoryToggleButton), so the conversation is not asked
    /// for again when it comes or goes.
    @Environment(\.historyDockLayout) private var dockLayout
    @Environment(\.startupCovers) private var startupCovers
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.scenePhase) private var scenePhase
    @ScaledMetric(relativeTo: .body) private var menuRowHeight: CGFloat = 46
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    @State private var draft = ""
    @StateObject private var composerInput = ComposerInput()
    @State private var showModel = false
    /// モデルと設定 opened from the web search note scrolls to its card.
    @State private var modelShowsWebSearch = false
    @State private var showWebSearchKeyNote = false
    @ObservedObject private var searchKey = WebSearchKeyState.shared
    /// The header's model mark opens this: the current model's generation
    /// settings and the user's own system prompt (GenerationConfigView).
    @State private var showConfiguration = false
    /// Claude's クレジットの残り sheet is up (opened from the composer's ring).
    @State private var showCredit = false
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// 縮小型 (the folding panel) or 従来型 (the plus and a one-line field).
    @AppStorage(ComposerStyle.storageKey) private var composerStyle = ComposerStyle.folding
    /// Smart Mode (1.1.0 (249)), 設定 › 試験機能を試してみる's switch (since
    /// 250; off until turned on): read here so the composer follows it at once.
    @AppStorage(SmartMode.storageKey) private var smartModeOn = false
    /// 新しいチャット's 「前回の会話に戻る」: the launch's new chat and the chat
    /// to go back to, while the capsule is there (made room for, then seen).
    @State private var launchReturn: LaunchReturn?
    @State private var launchReturnRoom = false
    @State private var launchReturnShown = false
    /// 体験型おすすめ質問's chips (1.1.0 (219)): seen, with their room over
    /// the field, or put away; and kept on the screen while they fade
    /// after one of them was sent.
    @State private var tryShown = false
    @State private var tryLeaving = false
    @State private var showActions = false
    @StateObject private var scrollPolicy = ChatScrollState()
    @State private var viewportHeight: CGFloat = 800
    @State private var arrivingMessageID: UUID?
    @State private var arrivalCleanup: Task<Void, Never>?
    @State private var scrollTask: Task<Void, Never>?
    @State private var attachments: [ChatAttachment] = []
    @State private var showPhotos = false
    /// The photo picker's top on screen, for placing its done check.
    @State private var photoPickerFrame = PhotoPickerFrame()
    /// The photo sheet's size: the compact card under the field, or large.
    @State private var photoDetent: PresentationDetent = .large
    /// The compact card's height, fixed when the sheet opens so its detents
    /// do not change while the keyboard that it replaces is going away.
    @State private var photoSheetHeight: CGFloat = 300
    /// Mirrors showPhotos with an animation, so the field rises and settles
    /// smoothly however the sheet was opened or dismissed.
    @State private var photoRoom = false
    @State private var photoPickerTicket = UUID()
    @State private var photoSelection: [PhotosPickerItem] = []
    @State private var pickedAttachments: [PhotosPickerItem: UUID] = [:]
    @State private var pickerChain: Task<Void, Never>?
    @State private var showFiles = false
    /// The photo library's picker for one video (動画).
    @State private var showVideos = false
    @State private var videoItem: PhotosPickerItem?
    @State private var showAttachmentGuide = false
    @State private var draftToRestore: String?
    @State private var pickerContext: AttachmentImportContext?
    @State private var isImporting = false
    /// The document being read in, if it is one (setImporting).
    @State private var importingFile: String?
    @State private var importTask: Task<Void, Never>?
    @State private var importID: UUID?
    @State private var timestampSwipe = ChatTimestampSwipe()
    @State private var latestRequest = 0
    /// The jump control's glass stays mounted while it sinks into the field;
    /// insertion/removal transitions do not run inside the composer bar.
    @State private var scrollDebug = ""
    @State private var jumpPresent = false
    @State private var jumpRaised = false
    /// The arrow leaves before the glass sinks and returns after it has
    /// separated, so it never crosses the field's text.
    @State private var jumpIconShown = false
    /// Hidden only once the shrunken glass has fused into the field.
    @State private var jumpGlassShown = false
    @State private var jumpSettle: Task<Void, Never>?
    /// 従来型's pills come out of the field and go back into it as the
    /// folded composer's latest button comes out of the chat button and
    /// goes into it (user, 2026-10-23). Drops of glass in the field's glass
    /// container carry them (classicPillDrops), along `classicTuck` (0 out
    /// in their places, 1 inside the field); the pills are menus, which
    /// must stay outside any container, and stand in for the drops only
    /// while they rest in their places.
    @State private var classicDropsPresent = false
    @State private var classicTuck: CGFloat = 1
    @State private var classicPillsSettled = false
    /// The bar's room for the pills, made and given back at once, as the
    /// keyboard starts to move: grown or shrunk with an animation, it
    /// relaid the field out while the drops moved, and their glass was
    /// drawn apart from it, under the field (simulator, 1.1.0 (138)).
    @State private var classicPillRoom = false
    @State private var classicDetailWidth: CGFloat = 0
    @State private var classicModelWidth: CGFloat = 0
    @State private var classicPillsTask: Task<Void, Never>?
    /// スタンダード since 1.1.0 (255) (user directive 2026-11-03): one bar at
    /// rest, the plus inside it in its own quiet glass circle, as in ChatGPT;
    /// typed in, it opens into スマート's panel, the same field, row and send
    /// (`standardOpen`), and closes again as the keyboard goes.
    @State private var standardOpen = false
    /// The bar's leading controls at rest (the plus, and the search pill
    /// while search is on): the text starts after them.
    @State private var standardLead: CGFloat = ChatMetrics.control
    /// The keyboard is on its way down while the field still has it: iOS
    /// lets the field go only once the keyboard is gone, and until then
    /// the pills stood alone over the field (simulator, 1.1.0 (140)).
    /// They go into it with the keyboard instead.
    @State private var keyboardLeaving = false
    /// A hardware keyboard is there (Magic Keyboard, fielua-reports #3):
    /// 従来型's pills then always stand (ComposerKeyboard).
    @State private var hardwareKeyboard = HardwareKeyboard.attached
    /// How far the field's top is below the composer's (the draft's
    /// attachments, a guide or the pills stand between them), measured in
    /// the composer's own space (`ChatView.composerSpace`). Up to 1.1.0
    /// (262) both tops were kept as places on the screen and subtracted:
    /// each moved on every frame the keyboard did (a finger pulling it
    /// down, its own rise and fall), and each frame wrote two states of
    /// the chat and ran its whole body for a difference that had not
    /// changed (UI review, 2026-11-11).
    @State private var inputTopInComposer: CGFloat = 0
    /// The field's top on every frame, kept without redrawing anything: an
    /// unfold hands it to inputTopInComposer as its motion ends (1.1.0 (209)).
    /// Until then the jump control's target kept the field's place from
    /// before the fold, with the keyboard down, and an unfold that brought
    /// the keyboard up left the target under the keyboard, away from the
    /// control it stands for: the control did not answer.
    @State private var inputTopLatest = LatestValue()
    private static let composerSpace = "composer"
    /// Follows the latest message by scrolling to the bottom edge of the
    /// valid scroll range. A chat shorter than the screen has no range, so it
    /// cannot be pushed down; aligning the "bottom" row to the viewport edge
    /// did exactly that and the rows dropped mid-reply.
    @State private var scrollPosition = ScrollPosition(edge: .bottom)
    /// The chat `scrollPosition` belongs to. A chat's new scroll view starts
    /// at the bottom edge, not where the user left the previous chat: that
    /// position, read when the new view was made, opened a long chat from
    /// history at its top (UI check, 1.0.59).
    @State private var scrollPositionChat: UUID?
    /// Puts a chat that just opened back at its end; see `settleOpenedChat`.
    @State private var openSettle: Task<Void, Never>?
    /// Read only by the ring below the last message, so following a pull
    /// redraws that ring and not the conversation.
    @State private var pullToCompose = PullToComposeState()
    @Namespace private var composerGlass
    @Namespace private var actionGlass
    // The native UITextView owns first responder status. A SwiftUI FocusState
    // without a .focused view can reset itself while its UIKit delegate is
    // beginning an edit, dismissing the keyboard during typing.
    @State private var inputFocused = false
    /// 設定 put the keyboard down on its way in (`openSettings`).
    @State private var settingsTookKeyboard = false
    /// Reading older messages folds the composer into three glass buttons
    /// (voice, chat, latest); only the chat button unfolds it.
    @State private var composerFolded = false
    /// Drives ComposerPanelMorph: 0 = the panel, 1 = the three buttons.
    @State private var composerMorph: CGFloat = 0
    /// While the morph runs the bar keeps the panel's height, so the
    /// conversation is not laid out again on every frame. Folded and
    /// settled, it gives that room back.
    @State private var composerMorphing = false
    @State private var composerSettled = false
    @State private var composerMorphID = 0
    /// Folded at the end of the chat, the latest button flows into the chat
    /// button (ComposerButtonMorph `tuck`: 0 = in its place, 1 = inside),
    /// and once inside it leaves the hierarchy, for touch and VoiceOver.
    @State private var jumpTuck: CGFloat = 0
    @State private var jumpTucked = false
    @State private var jumpTuckID = 0
    /// A drag heading into older messages, which is about to fold.
    @State private var foldLeaning = false
    @State private var composerHeight: CGFloat = 0
    @State private var composerWidth: CGFloat = 0
    @State private var showVoiceNote = false
    /// A question spoken into the chat (1.1.0 (236)), for a model that
    /// hears one (LFM3-Omni 2B).
    @State private var recorder = VoiceRecorder()
    @State private var showMicrophoneNote = false
    @AccessibilityFocusState private var unfoldFocused: Bool
    /// The attachments the composer offers: the chat's model's, or in a
    /// Smart Mode chat those of the model its photos and files go to.
    private var attachmentPolicy: ModelAttachmentPolicy { ModelAttachmentPolicy(model: chats.attachmentModel) }
    /// A Smart Mode chat: the genre in place of the reply mode and the model.
    private var smartChat: Bool { smartModeOn && chats.isSmart }
    /// An empty chat's line: its model, Smart Mode's choice, or the PC's
    /// model and the PC (PCと接続, 1.1.0 (253)).
    private var emptyChatModelLine: String {
        if let pc = chats.currentPC { return "\(pc.shortModel) · \(pc.pcName)" }
        // Claude (1.1.0 (257)): its model, said to be an external AI.
        if let claude = chats.currentClaude { return claude.line }
        return smartChat ? String(localized: "質問に合わせて自動で選びます") : chats.currentModel.name
    }
    /// The chat can be answered: its model is saved, or in Smart Mode one it
    /// may choose.
    private var chatReady: Bool { chats.canAnswer }
    /// The conversation's text column beside the iPad's history, its
    /// gutters left out; nil (any width) on the phone.
    private var columnText: CGFloat? { dockLayout.map { $0.column - 2 * ChatMetrics.gutter } }

    private var canSend: Bool {
        chatReady && !isImporting
            && (!draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty)
    }
    private var recording: Bool { recorder.isRecording }
    /// A spoken question can start: a model that hears one, saved, and
    /// nothing written, read in or recorded already.
    private var voiceReady: Bool {
        hearsVoice && !chats.isGenerating && !isImporting
            && !attachments.contains { $0.kind == .audio } && attachments.count < 3
    }
    /// A spoken question has a model that hears it: the chat's, saved, or
    /// in a Smart Mode chat LFM3-Omni 2B, saved, which it goes to with
    /// photos at most (SmartPlanner).
    private var hearsVoice: Bool {
        smartChat ? model.isInstalled(.lfm3Omni) && attachments.allSatisfy { $0.kind == .audio || $0.kind == .image }
            : !chats.isRemoteChat && attachmentPolicy.allowsVoice && model.isInstalled(chats.currentModel)
    }
    /// With nothing to send, send is the waveform that records instead, as
    /// in Messages' field.
    private var recordOffered: Bool { voiceReady && !canSend }
    /// The try questions belong to an empty chat whose model is saved; one
    /// whose model is not has 「モデルを準備する」 instead, and no chip that
    /// could not send.
    private var tryOffered: Bool { chats.messages.isEmpty && chatReady }
    /// Seen while nothing is typed (a word still being converted counts),
    /// attached or written, and nothing else is over the field: 「前回の会話に
    /// 戻る」, the plus menu and the photos come first.
    private var tryWanted: Bool {
        tryOffered && !chats.isGenerating && draft.isEmpty && attachments.isEmpty && !isImporting && !recording
            && launchReturn == nil && !showActions && !showPhotos && !composerFolded
    }
    private var datedMessages: Set<UUID> {
        var result: Set<UUID> = []
        var previous: Date?
        for message in chats.messages {
            if previous == nil || message.createdAt.timeIntervalSince(previous!) > 300 { result.insert(message.id) }
            previous = message.createdAt
        }
        return result
    }

    /// Replies to messages that asked for a chart (RichFormatGuide), whose
    /// chart data under a ```json or bare fence is drawn too.
    private var chartAnswers: Set<UUID> {
        var result: Set<UUID> = []
        var asked = false
        for message in chats.messages {
            if message.role == .user { asked = RichFormatGuide.asksForChart(message.text) }
            else if asked { result.insert(message.id) }
        }
        return result
    }

    private var tailedMessages: Set<UUID> {
        var result: Set<UUID> = []
        for (index, message) in chats.messages.enumerated() {
            let next = chats.messages.dropFirst(index + 1).first
            if next == nil || next?.role != message.role
                || (next?.createdAt.timeIntervalSince(message.createdAt) ?? 0) > 60 {
                result.insert(message.id)
            }
        }
        return result
    }

    // No glass container spans the screen: the header and the composer
    // have their own, and the composer's menus stand outside every one.
    // Until 1.0.114 a screen-wide group also held the system menus inside
    // a glass container (`--menus-in-panel` keeps it for comparison).
    var body: some View {
        let _ = SettingsSlideMeter.drew("チャット")
        #if POCKET_PREVIEW
        let _ = StackProbe.mark("ChatView.body")
        #endif
        if menusInPanel { ChatGlassGroup(spacing: 14) { screen } } else { screen }
    }

    private var screen: some View {
        conversation
            // Warm paper with its faint grain, still under the scrolling;
            // round-cornered while slid aside for the history.
            .background { ConversationPaper() }
            // Tap outside closes the plus menu. It sits on the conversation,
            // under the composer inset that draws the menu itself.
            .overlay {
                if showActions {
                    Color.black.opacity(0.03).ignoresSafeArea()
                        .contentShape(Rectangle())
                        .onTapGesture { closeActions() }
                        .accessibilityHidden(true)
                        .transition(.opacity)
                }
            }
            .chatBars(top: {
                header.accessibilityHidden(showActions)
                    .background { ChatChromeBackdrop(edge: .top) }
            }, bottom: {
                // No opaque band: the conversation scrolls behind the glass
                // controls and the system's soft scroll edge effect keeps the
                // text legible, as in Messages on iOS 26.
                // Beside the iPad's history, as wide as the conversation's
                // column, and moving over with it (1.1.0 (242)).
                composer.frame(maxWidth: dockLayout?.column).frame(maxWidth: .infinity)
                    .modifier(BesideShift())
            })
            // The visible jump control is drawn inside the composer's glass
            // container (so it can merge into the field), but it sits above
            // the bar's bounds where the bar cannot receive touches. This
            // transparent target at the same spot owns the tap and VoiceOver.
            .overlayPreferenceValue(ComposerBoundsKey.self) { bounds in
                GeometryReader { overlay in
                    if let bounds, floatingJumpWanted && !showActions {
                        Button { scrollPolicy.requestLatest(); latestRequest += 1 } label: {
                            Color.clear.frame(width: ChatMetrics.control, height: ChatMetrics.control)
                                .contentShape(Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("最新のメッセージへ移動").accessibilityIdentifier("chat-jump-latest")
                        .position(x: overlay.size.width / 2,
                                  y: overlay[bounds].minY + max(0, inputTopInComposer)
                                     - jumpLift - ChatMetrics.control / 2)
                        .modifier(BesideShift())
                    }
                }
            }
            #if POCKET_PREVIEW
            .overlay(alignment: .topLeading) {
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityIdentifier("scroll-debug")
                    .accessibilityLabel(scrollDebug + " " + scrollPolicy.endMarkerDebug + " follows=\(scrollPolicy.followsLatest) scrolling=\(scrollPolicy.isUserScrolling) jump=\(scrollPolicy.showsJumpButton)")
            }
            // The field, the keyboard and its keys (fielua-reports #3).
            .overlay(alignment: .bottomLeading) {
                if PreviewProbe.on("--keyboard-probe") { KeyboardProbe.Readout(focused: inputFocused) }
            }
            // The try chips' state for the UI check: XCUITest still finds
            // controls that are put away.
            .overlay(alignment: .topTrailing) {
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityIdentifier("chat-try-state")
                    .accessibilityLabel(tryOffered || tryLeaving ? (tryShown ? "shown" : "hidden") : "none")
            }
            #endif
            .background { GeometryReader { area in
                Color.clear.preference(key: ChatViewportHeightKey.self, value: area.size.height)
            }.ignoresSafeArea(.keyboard) }
            .onPreferenceChange(ChatViewportHeightKey.self) { if abs(viewportHeight - $0) > 1 { viewportHeight = $0 } }
            .toolbar(.hidden, for: .navigationBar)
            .toolbar(.hidden, for: .bottomBar)
            .tint(Theme.tint)
            .sheet(isPresented: $showModel, onDismiss: {
                modelShowsWebSearch = false
                if settingsTookKeyboard {
                    settingsTookKeyboard = false
                    if chatReady { inputFocused = true }
                }
            }) {
                SettingsView(start: modelShowsWebSearch ? .webSearch : .models)
            }
            .sheet(isPresented: $showConfiguration) {
                // A Claude chat's model settings: its reasoning level (1.1.0 (257)).
                if let claude = chats.currentClaude {
                    ClaudeChatSettingsView(target: claude)
                } else {
                    GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings,
                                         onSave: chats.updateSettings)
                }
            }
            .fileImporter(isPresented: $showFiles,
                          allowedContentTypes: fileImportTypes, allowsMultipleSelection: true) { result in
                do {
                    let urls = try result.get()
                    guard pickerContext?.matches(threadID: chats.selectedID, modelID: chats.currentModel.id) == true else { return }
                    importAttachments(urls, temporary: false)
                }
                catch { chats.error = error.localizedDescription }
            }
            // As it is in the library: no conversion, the scenes are read
            // from the file (AttachmentStorage).
            .photosPicker(isPresented: $showVideos, selection: $videoItem, matching: .videos,
                          preferredItemEncoding: .current)
            .onChange(of: videoItem) { _, item in
                guard let item else { return }
                videoItem = nil
                importPickedVideo(item)
            }
            .onChange(of: chats.selectedID) { old, selected in
                composerInput.clearAndDismiss()
                draft = draftToRestore ?? ""; draftToRestore = nil
                // The text left behind goes, as it does from the field; one
                // kept through the launch comes back with its chat.
                if let old, LaunchChat.kept[old] == nil { LaunchDrafts.remove(old) }
                if draft.isEmpty, let selected, let kept = LaunchChat.takeDraft(for: selected) { draft = kept }
                if launchReturn?.chat != selected { endLaunchReturn(animated: false) }
                clearTransientState()
                // Another chat opens with its composer, ready to type.
                unfoldComposerAtOnce()
                scrollPolicy.requestLatest()
            }
            .onChange(of: chats.currentModel.id) { _, _ in
                // Smart Mode's send moves the chat to the model it chose;
                // the draft was sent with it.
                guard !chats.isGenerating else { return }
                showPhotos = false; showFiles = false; showVideos = false
                clearTransientState()
            }
            .onDisappear { clearTransientState() }
            // 従来型 never folds: a folded panel opens as it changes type.
            .onChange(of: composerStyle) { _, _ in unfoldComposerAtOnce() }
            .onChange(of: scenePhase, initial: true) { _, phase in
                // iOS takes the microphone in the background: keep what was said.
                if phase == .background { finishRecording(); keepDraft() }
                openAtLaunch(phase)
            }
            // Something typed or attached in the new chat: it is the one.
            .onChange(of: draft.isEmpty && attachments.isEmpty) { _, empty in
                if !empty { endLaunchReturn(animated: true) }
            }
            // The sidebar takes over the screen: put away the keyboard, the
            // photo sheet and the plus menu as soon as it starts to show.
            .onChange(of: historyVisible) { _, visible in
                guard visible else { return }
                inputFocused = false
                if showPhotos { closePhotoDock() }
                if showActions { closeActions() }
            }
            .confirmationDialog("添付について", isPresented: $showAttachmentGuide, titleVisibility: .visible) {
                // Also for LFM3-VL 2B's videos and files (1.1.0 (234)).
                if !attachmentPolicy.allowsVideo {
                    Button(model.isInstalled(.e2b) ? "E2Bで新しいチャットを開く" : "E2Bを準備する") { switchToE2B() }
                        .disabled(chats.isGenerating)
                }
                Button("閉じる", role: .cancel) {}
            } message: {
                Text(attachmentPolicy.guidance + (!attachmentPolicy.allowsVideo
                    ? "\n" + String(localized: "入力中の文章はそのまま引き継ぎます。") : ""))
            }
            // A download's error during the first launch's setup is the
            // setup's to show.
            .alert("お知らせ", isPresented: Binding(get: { chats.error != nil || (!showModel && !StartupPresenter.presenting && model.error != nil) },
                set: { if !$0 { chats.error = nil; model.error = nil } })) {
                Button("閉じる") { chats.error = nil; model.error = nil }
            } message: { Text(chats.error ?? model.error ?? "") }
    }

    /// What the file picker offers. Documents are converted to text on
    /// device (AttachmentStorage), so the model only receives plain text.
    private var fileImportTypes: [UTType] {
        var types: [UTType] = attachmentPolicy.allowsPhotos ? [.image] : []
        if attachmentPolicy.allowsVideo { types.append(.movie) }
        if attachmentPolicy.allowsDocuments {
            types += [.plainText, .pdf, .text, .rtf, .json, .xml, .html, .commaSeparatedText,
                      .tabSeparatedText, .yaml, .sourceCode]
            for identifier in ["net.daringfireball.markdown", "org.openxmlformats.wordprocessingml.document"] {
                if let type = UTType(identifier) { types.append(type) }
            }
        }
        return types
    }

    private var header: some View {
        ChatGlassGroup {
            ZStack(alignment: .topLeading) {
                HistoryToggleButton(onDrawer: { inputFocused = false })
                    .padding(.leading, ChatMetrics.gutter).padding(.top, 8)
                    // It keeps to the conversation's leading edge, beside
                    // the history's.
                    .modifier(BesideShift(factor: 2))
                    // Over the model mark's wide tap area, which moves over
                    // by half as much: beside the history that area reached
                    // the button, and a tap to put the history away opened
                    // 構成 instead (UI check, 1.1.0 (242)).
                    .zIndex(1)

                // The model is chosen in the composer; the mark opens what
                // belongs to the current model: its generation settings and
                // the user's system prompt.
                Button {
                    inputFocused = false
                    showConfiguration = true
                } label: {
                    // Fielua in a Smart Mode chat, whichever model answers
                    // (1.1.0 (251)); the chat's model otherwise.
                    // A PC chat's model on the PC (PCと接続, 1.1.0 (253)).
                    ChatHeaderMark(model: chats.currentModel, smart: smartChat, pc: chats.currentPC, claude: chats.currentClaude)
                    .foregroundStyle(.primary).frame(maxWidth: .infinity)
                    .padding(.top, 6).padding(.bottom, 8).contentShape(Rectangle())
                }
                .accessibilityLabel("モデルの設定を開く")
                .accessibilityValue(chats.currentPC.map { "\($0.pcName) · \($0.model)" } ?? chats.currentClaude?.spoken
                                    ?? (smartChat ? "Fielua" : chats.currentModel.name))
                .accessibilityIdentifier("chat-model-settings")
                .padding(.horizontal, 74)
                .modifier(BesideShift())
            }
            .buttonStyle(.plain)
        }
    }

    /// Each chat's conversation is a scroll view of its own.
    private var conversationID: UUID? {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-shared-scroll") { return nil }
        #endif
        return chats.selectedID
    }

    /// The latest messages are laid out eagerly. With every message a lazy
    /// row, scrolling up after two sends kept the stack re-placing its rows:
    /// the simulator spun at full CPU in that UI test, with plain and
    /// Markdown replies alike, and the device hitched. A long chat's older
    /// messages stay lazy above them; the split moves in steps of 20, so a
    /// send rarely moves a row between the two.
    private static let eagerMessages = 40
    private var eagerStart: Int {
        let count = chats.messages.count
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-all-lazy") { return count }
        #endif
        guard count > Self.eagerMessages else { return 0 }
        return (count - Self.eagerMessages) / 20 * 20
    }

    /// One stable, measurable row per message. Returning a conditional
    /// timestamp beside the bubble made the lazy stack repeatedly enumerate
    /// variable subview lists while estimating long histories.
    private func messageRow(_ message: ChatMessage, dated: Bool, tail: Bool, chart: Bool, width: CGFloat) -> some View {
        VStack(spacing: 8) {
            if dated { timestamp(message.createdAt) }
            MessageView(message: message, oppositeInset: dynamicTypeSize.isAccessibilitySize
                    ? max(20, width * 0.08) : max(56, width * 0.20),
                        hasTail: tail,
                        animateArrival: arrivingMessageID == message.id && !reduceMotion,
                        answersChartRequest: chart)
                .equatable()
                .recordChatLayout(message.id)
        }
        .frame(maxWidth: .infinity)
        .id(message.id)
        .transition(message.role == .assistant && !reduceMotion ? .opacity : .identity)
    }

    /// The conversation's outer stack is eager. As one tall item of a lazy
    /// stack, the latest messages were sometimes not drawn at all: the screen
    /// stayed blank after scrolling up during a reply, and the content height
    /// ran about 1400pt long until the reply ended (UI check, 1.0.71).
    @ViewBuilder private func conversationStack<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-eager-item") { LazyVStack(spacing: 8, content: content) }
        else { VStack(spacing: 8, content: content) }
        #else
        VStack(spacing: 8, content: content)
        #endif
    }

    private var keyboardDismissal: ScrollDismissesKeyboardMode {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-keep-keyboard") { return .never }
        if PreviewProbe.on("--probe-dismiss-immediately") { return .immediately }
        #endif
        return .interactively
    }

    private var conversation: some View {
        let dates = datedMessages
        let tails = tailedMessages
        let charts = chartAnswers
        return GeometryReader { geometry in
            // Counted while a slide is measured: each new width lays every
            // row out again.
            let _ = SettingsSlideMeter.drew("会話の幅")
            ScrollViewReader { proxy in
                ScrollView {
                    conversationStack {
                        // An empty chat shows only the model's name, with no
                        // line asking for a message (2026-10-24, fewer words).
                        // A test version's chats say so under it (12B, 204).
                        VStack(spacing: 3) {
                            // A Smart Mode chat chooses for each question.
                            Text(emptyChatModelLine)
                                .font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                                .accessibilityIdentifier("chat-model-line")
                            if let pc = chats.currentPC { PCChatStateNote(target: pc) }
                            if chats.currentClaude != nil { ClaudeChatStateNote() }
                            if chats.currentModel.isTestVersion {
                                Text(ModelSpec.testVersionNote)
                                    .font(.system(size: 11)).foregroundStyle(Theme.caution)
                                    .multilineTextAlignment(.center)
                                    .accessibilityIdentifier("chat-test-version-note")
                            }
                            // じっくり考える without the room for it answers
                            // without thinking; its chats say so (1.1.0 (248)).
                            if chats.deeperFallsBack {
                                Text(Self.deeperFallbackNote)
                                    .font(.system(size: 11)).foregroundStyle(Theme.caution)
                                    .multilineTextAlignment(.center)
                                    .accessibilityIdentifier("chat-reply-mode-note")
                                    .transition(.opacity)
                            }
                        }
                        .frame(maxWidth: .infinity).padding(.top, 14).padding(.bottom, 8)
                            #if POCKET_PREVIEW
                            // The UI check's sign of an empty chat, which has
                            // no words of its own now.
                            .overlay {
                                if chats.messages.isEmpty {
                                    Color.clear.accessibilityElement()
                                        .accessibilityLabel("empty").accessibilityIdentifier("chat-empty")
                                }
                                // The living flower's frames and state: the
                                // flower behind the list is not read by
                                // accessibility. Also once a message is sent,
                                // to see the flower gone.
                                if PreviewProbe.on("--living-flower-probe") { LivingFlowerProbe.Readout() }
                            }
                            #endif
                        if chats.messages.isEmpty && !chatReady { preparation }
                        let split = eagerStart
                        if split > 0 {
                            LazyVStack(spacing: 8) {
                                ForEach(chats.messages[..<split]) { message in
                                    messageRow(message, dated: dates.contains(message.id), tail: tails.contains(message.id),
                                               chart: charts.contains(message.id), width: dockLayout?.column ?? geometry.size.width)
                                }
                            }
                        }
                        if split < chats.messages.count {
                            VStack(spacing: 8) {
                                ForEach(chats.messages[split...]) { message in
                                    messageRow(message, dated: dates.contains(message.id), tail: tails.contains(message.id),
                                               chart: charts.contains(message.id), width: dockLayout?.column ?? geometry.size.width)
                                }
                            }
                        }
                        // What the reply waits for, in words, only for
                        // developers: the Aurora Orb says it to everyone.
                        if chats.isGenerating && showDeveloperSettings {
                            ChatDeveloperStatusLine(status: chats.status, claude: chats.currentClaude != nil)
                        }
                        // Only rows far above the end are estimated, so the
                        // target's position stays exact; below a fully lazy
                        // stack it used to chase estimated row heights.
                        // It ends the content, so scrolling it to the bottom
                        // reaches the end; the stack's 10pt bottom padding
                        // used to stay below the screen (UI check, 1.0.67).
                        Color.clear.frame(height: 11).id("bottom")
                            // What Claude is doing while its reply stands
                            // still, in the room under the last reply (its
                            // 7pt, the stack's 8 and these 11).
                            .overlay(alignment: .bottomLeading) {
                                if chats.currentClaude != nil {
                                    ClaudeActivityLine(active: chats.isGenerating)
                                        .padding(.leading, ChatMetrics.replyInset).padding(.bottom, 3)
                                }
                            }
                    }
                    // Beside the iPad's history, a column as wide whether
                    // the history shows or not (1.1.0 (242)).
                    .frame(maxWidth: columnText)
                    .padding(.horizontal, ChatMetrics.gutter)
                    .frame(maxWidth: .infinity)
                    .overlay(alignment: .top) { PullToComposeIndicator(state: pullToCompose) }
                    // Moved over with the history inside the scroll view,
                    // which keeps its size, its place and its scroll bar.
                    .modifier(BesideShift())
                }
                // An empty chat shows the flower in the middle of the
                // paper, no words (brand 2026-10-27), breathing slowly and
                // now and then letting a petal go and growing a new one
                // (1.1.0 (214), always moving since (215)). It is only
                // there while the chat is empty, so a chat with messages
                // keeps nothing of it.
                .background {
                    let empty = chats.messages.isEmpty && chatReady
                    ZStack {
                        if empty {
                            // It settles while anything else has the
                            // person's attention: a reply, a sheet or a
                            // picker (構成 and the pickers since 1.1.0 (215)),
                            // the history or the setup over the chat (both
                            // hid it while it went on moving until 1.1.0
                            // (218)). While the person types it shrinks and
                            // fades away, and comes back once the field is
                            // empty (1.1.0 (216)).
                            LivingFlower(size: 60, resting: chats.isGenerating || showModel
                                         || showConfiguration || showPhotos || showFiles || showVideos
                                         || showCredit || historyVisible || startupCovers,
                                         away: !draft.isEmpty)
                                .opacity(0.9)
                                .transition(.opacity)
                        }
                    }
                    .animation(reduceMotion ? nil : ChatMotion.fade, value: empty)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .modifier(BesideShift())
                    .allowsHitTesting(false)
                }
                // Each chat gets a scroll view of its own, placed at its end
                // like the first launch. Reusing one kept the last chat's
                // offset and row estimates, and a chat opened from history
                // could rest below its last message (1.0.58).
                .id(conversationID)
                .transition(.identity)
                .scrollPosition(Binding(get: { scrollPositionChat == chats.selectedID ? scrollPosition : ScrollPosition(edge: .bottom) },
                                        set: { scrollPosition = $0; scrollPositionChat = chats.selectedID }))
                .coordinateSpace(name: "conversation")
                .scrollDismissesKeyboard(keyboardDismissal)
                .chatScrollEdges(customChrome: true)
                .scrollBounceBehavior(.always)
                .modifier(ChatScrollAnchoring(followsLatest: scrollPolicy.shouldFollowStream))
                .modifier(ChatScrollObserver(onDistance: { scrollPolicy.observe(distanceFromBottom: $0) },
                    onUserScrolling: {
                        scrollPolicy.setUserScrolling($0)
                        if $0 { scrollTask?.cancel(); scrollTask = nil }
                    }, onLayout: { scheduleBottom(proxy, animated: true) },
                    onDebug: { scrollDebug = $0 }))
                // Pulling past the end opens a new chat, as in ChatGPT.
                .modifier(PullToComposeObserver(state: pullToCompose,
                                                enabled: !chats.messages.isEmpty && !chats.isGenerating && !showActions,
                                                onCompose: { chats.newChat() }))
                // Reading older messages folds the composer.
                .modifier(ComposerFoldObserver(enabled: foldAllowed,
                                               onLeaning: { if foldLeaning != $0 { foldLeaning = $0 } },
                                               onFold: { foldComposer() }))
                .modifier(ChatTimestampReveal(swipe: timestampSwipe, reduceMotion: reduceMotion))
                .onChange(of: chats.messages.last?.text) { _, _ in
                    scheduleBottom(proxy)
                }
                .onReceive(NotificationCenter.default.publisher(for: ReplyPacer.revealed)) { _ in
                    scheduleBottom(proxy)
                }
                // What comes under a written reply (MessageView.showExtras)
                // fades in; the list goes down to it smoothly, once, rather
                // than at the step a pending text update would take.
                .onReceive(NotificationCenter.default.publisher(for: ChatMotion.replySettled)) { _ in
                    scrollTask?.cancel(); scrollTask = nil
                    scheduleBottom(proxy, animated: true)
                }
                .onChange(of: chats.messages.count) { _, _ in
                    scheduleBottom(proxy)
                }
                .onChange(of: chats.isGenerating) { _, generating in
                    if !generating { scheduleBottom(proxy) }
                }
                .onChange(of: chats.status) { _, status in SendScreenLog.shared.stage(status) }
                .onChange(of: chats.selectedID, initial: true) { _, selected in
                    // Selecting from history happens inside the drawer's
                    // slide; the new chat must not scroll down with it.
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) {
                        scrollPosition = ScrollPosition(edge: .bottom)
                        scrollPositionChat = selected
                    }
                    settleOpenedChat(proxy)
                }
                .onChange(of: latestRequest) { _, _ in jumpToBottom(proxy) }
                .onChange(of: inputFocused) { _, focused in
                    if focused && showPhotos { closePhotoDock() }
                    if focused { scheduleBottom(proxy) }
                }
                .task { if #unavailable(iOS 18.0) { proxy.scrollTo("bottom", anchor: .bottom) } }
                .accessibilityIdentifier("chat-conversation")
                .accessibilityHidden(showActions)
            }
        }
        // Content continues beneath the feathered backdrop and glass controls.
    }

    /// `animated` is for viewport changes (the keyboard closing after send)
    /// and explicit requests: the geometry callback reports the final size at
    /// once, so an instant jump there moved the rows ahead of the animating
    /// keyboard and the conversation visibly bounced. Streaming text updates
    /// stay unanimated so repeated scrolls never compete with the reply.
    /// An explicit request (the jump control, sending). It must work while the
    /// list is still coasting from a flick: the `ScrollPosition` binding may
    /// still read `.bottom` from an earlier jump until scrolling settles, so
    /// setting it again changed nothing. The proxy scrolls imperatively; a
    /// final unanimated edge scroll corrects lazy-height estimates.
    private func jumpToBottom(_ proxy: ScrollViewProxy) {
        scrollTask?.cancel()
        scrollTask = Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            if reduceMotion {
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { proxy.scrollTo("bottom", anchor: .bottom) }
            } else {
                withAnimation(ChatMotion.keyboardFollow) { proxy.scrollTo("bottom", anchor: .bottom) }
            }
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            scrollTask = nil
            guard scrollPolicy.followsLatest, !scrollPolicy.isUserScrolling,
                  scrollPolicy.lastDistanceFromBottom > 1 else { return }
            // Lazy rows were measured on the way; settle the last few points
            // smoothly rather than snapping.
            withAnimation(reduceMotion ? nil : ChatMotion.scroll) { scrollPosition.scrollTo(edge: .bottom) }
        }
    }

    /// A chat that just opened is placed at its end from estimated row
    /// heights, and rows measured taller then push the end below the screen
    /// (UI check: up to 1156pt, and 17-52pt still after 0.3s with tables,
    /// code and math). Put it back at the end without animation until it has
    /// stayed there for 0.3s, for at most 1.5s: chasing the estimate for good
    /// hung layout before. A touch ends it.
    private func settleOpenedChat(_ proxy: ScrollViewProxy) {
        openSettle?.cancel()
        openSettle = Task { @MainActor in
            var atEnd = 0
            for _ in 0..<30 {
                do { try await Task.sleep(for: .milliseconds(50)) } catch { return }
                guard !scrollPolicy.isUserScrolling else { break }
                guard scrollPolicy.lastDistanceFromBottom > 1 else {
                    atEnd += 1
                    if atEnd >= 6 { break } else { continue }
                }
                atEnd = 0
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { proxy.scrollTo("bottom", anchor: .bottom) }
            }
            openSettle = nil
        }
    }

    private func scheduleBottom(_ proxy: ScrollViewProxy, force: Bool = false, animated: Bool = false) {
        guard force || scrollPolicy.shouldFollowStream else { return }
        if force { scrollTask?.cancel(); scrollTask = nil }
        guard scrollTask == nil else { return }
        scrollTask = Task { @MainActor in
            // Wait for the newly inserted row / keyboard size to be measured.
            do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
            scrollTask = nil
            guard !Task.isCancelled, scrollPolicy.shouldFollowStream else { return }
            // Streaming uses a settled offset. Repeated scroll animations used
            // to compete with the outgoing bubble and grow the lazy stack.
            if animated && !reduceMotion {
                withAnimation(ChatMotion.keyboardFollow) { scrollPosition.scrollTo(edge: .bottom) }
            } else {
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { scrollPosition.scrollTo(edge: .bottom) }
            }
        }
    }
    private func timestamp(_ date: Date) -> some View {
        HStack(spacing: 4) {
            Text(date, format: .dateTime.month().day()).fontWeight(.semibold)
            Text(date, style: .time)
        }
        .font(.system(size: 11)).foregroundStyle(.secondary)
        .frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 9)
    }
    private var preparation: some View {
        VStack(spacing: 9) {
            if model.isRestoring || model.isWorking(on: chats.currentModel) {
                Text(model.statusText(for: chats.currentModel))
                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
            Button("モデルを準備する") { showModel = true }.font(.subheadline)
        }
        .padding(.horizontal, 24).padding(.vertical, 14)
    }

    private var composer: some View {
        #if POCKET_PREVIEW
        StackProbe.mark("composer")
        #endif
        return VStack(spacing: 6) {
            // Hidden with the fold; removed from the bar only once folded.
            if draftStripShown { draftStrip }
            if tryOffered || tryLeaving { tryQuestions }
            if let launchReturn { launchReturnCapsule(launchReturn.back) }
            if recording {
                VoiceRecordingStrip(recorder: recorder) { cancelRecording() }
                    .transition(reduceMotion ? .opacity : .scale(scale: 0.92, anchor: .bottom).combined(with: .opacity))
            }
            composerStage
                // A model that hears no voice: the button says which one
                // does, rather than pretending, and offers the keyboard's
                // own dictation.
                .alert("音声入力", isPresented: $showVoiceNote) {
                    Button("LFM3-Omni 2Bに切り替える") {
                        // The model list cannot open while the alert is
                        // still dismissing.
                        Task { @MainActor in
                            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                            switchModel(to: .lfm3Omni)
                        }
                    }
                    Button("入力欄を開く") {
                        // The field cannot take the keyboard while the
                        // alert is still dismissing.
                        Task { @MainActor in
                            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                            unfoldComposer()
                        }
                    }
                    Button("閉じる", role: .cancel) {}
                } message: {
                    Text(ModelAttachmentPolicy.voiceGuidance)
                }
                .alert("マイクを使えません", isPresented: $showMicrophoneNote) {
                    Button("設定を開く") {
                        if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
                    }
                    Button("閉じる", role: .cancel) {}
                } message: {
                    Text("話しかけて質問するには、設定アプリでFieluaのマイクをオンにしてください。")
                }
                // Folded, send is gone: what was said so far is kept.
                .onChange(of: composerFolded) { _, folded in if folded { finishRecording() } }
                // Search without a key: where to get one and what it sends.
                .alert("ウェブ検索にはTavilyへの接続が必要です", isPresented: $showWebSearchKeyNote) {
                    Button("設定を開く") {
                        // The sheet cannot open while the alert is still dismissing.
                        Task { @MainActor in
                            do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                            modelShowsWebSearch = true
                            showModel = true
                        }
                    }
                    Button("キャンセル", role: .cancel) {}
                } message: {
                    Text("設定でTavilyに登録またはログインしてください。")
                }
                // Scroll updates run in transactions that disable animations,
                // which also cut the jump control's merge to a single frame.
                // Mirror the policy into local state with its own transaction.
                .onChange(of: floatingJumpWanted) { _, visible in setJumpVisible(visible) }
                // With the flower's pace; at launch only once 起動時のチャット
                // has put 「前回の会話に戻る」 there or not (openAtLaunch).
                .onChange(of: tryWanted, initial: true) { old, wanted in
                    if old != wanted { setTryShown(wanted, animated: true) } else { revealTryQuestions() }
                }
                .onChange(of: scrollPolicy.restsAtEnd) { _, _ in updateJumpTuck() }
                // Here, not on 従来型's field: changing the type removes the
                // field, and the pills must still be put away.
                .onChange(of: classicPillsShown) { _, shown in
                    setClassicPillsVisible(shown)
                    notePills(shown)
                }
                .onChange(of: standardOpenWanted) { _, open in
                    setStandardOpen(open)
                    notePills(open)
                }
                .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { note in
                    keyboardWillHide(note)
                }
                .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
                    keyboardLeaving = false
                }
                .onChange(of: inputFocused) { _, focused in
                    keyboardLeaving = false
                    if focused && hardwareKeyboard {
                        SendScreenLog.shared.beginKeys(field: composerInput.textView, composer: composerStyle, rowAbove: legacyStandard)
                    }
                }
                .onReceive(HardwareKeyboard.changes) { note in hardwareKeyboardChanged(note) }
                #if POCKET_PREVIEW
                .onReceive(NotificationCenter.default.publisher(for: KeyboardProbe.hardwareNotice)) { note in
                    keyboardWillHide(note)
                }
                #endif
                .onAppear {
                    jumpPresent = floatingJumpWanted
                    jumpRaised = jumpPresent; jumpIconShown = jumpPresent; jumpGlassShown = jumpPresent
                    classicPillsSettled = classicPillsShown; classicPillRoom = classicPillsShown
                    classicTuck = classicPillsShown ? 0 : 1
                    standardOpen = standardOpenWanted
                }
                .padding(.horizontal, ChatMetrics.gutter).padding(.top, 8).padding(.bottom, 6)
            if photoRoom {
                // Room for the compact photo sheet, which floats here under
                // the field the way the keyboard would. Its detent height is
                // measured from the bottom safe area, where this bar already
                // ends. Less the stack spacing and the row's bottom padding
                // (6pt each) and the ~7pt the floating card sits below its
                // detent height (measured in the simulator, 1.0.48), the
                // field keeps Messages' gap above the card.
                Color.clear.frame(height: photoSheetHeight + ChatMetrics.photoSheetGap - 19)
                    .accessibilityHidden(true)
            }
        }
        // A line more or less of text grows or shrinks the panel smoothly,
        // the text riding up with its top edge (ComposerTextView keeps the
        // text in place while the frame catches up).
        .animation(reduceMotion ? nil : ChatMotion.resize, value: draft)
        // The draft's attachments too (1.1.0 (263)): taken out, or sent
        // with nothing typed, their 88pt left in one frame.
        .animation(draftStripMotion, value: draftStripKey)
        // The recording strip comes and goes with the panel's pace.
        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.resize, value: recording)
        .coordinateSpace(.named(Self.composerSpace))
        .anchorPreference(key: ComposerBoundsKey.self, value: .bounds) { $0 }
        .onChange(of: showPhotos) { _, shown in
            withAnimation(reduceMotion ? nil : ChatMotion.resize) { photoRoom = shown }
        }
        .sheet(isPresented: $showPhotos, onDismiss: {
            // Swiped away, or closed from the field. The picker gets a new
            // identity only now, so its grid is not rebuilt while visible.
            guard !showPhotos else { return }
            closePhotoDock()
            photoPickerTicket = UUID()
        }) {
            photoSheet.onChange(of: photoSelection) { old, new in syncPickedPhotos(old: old, new: new) }
        }
        .composerPart()
    }

    private var draftStripShown: Bool { (!attachments.isEmpty || isImporting) && !composerSettled }
    private var draftStripMotion: Animation {
        let motion = reduceMotion ? ChatMotion.reducedMenu : ChatMotion.resize
        #if POCKET_PREVIEW
        // `--slow-draft`: the draft's row eight times slower, so the UI
        // check's frames sample its cards coming and going.
        if PreviewProbe.on("--slow-draft") { return motion.speed(0.125) }
        #endif
        return motion
    }
    /// Changes whenever the draft's row does: what is in it, and whether
    /// one more is being read in.
    private var draftStripKey: Int {
        var hasher = Hasher()
        for attachment in attachments { hasher.combine(attachment.id) }
        hasher.combine(isImporting)
        hasher.combine(importingFile)
        return hasher.finalize()
    }
    /// The row is a photo's height (82pt) with a photo, a video, a recording
    /// or the photo's frame of one being read in, and a document card's
    /// (56pt) with documents alone (1.1.0 (271)).
    private var draftStripHeight: CGFloat {
        let tall = attachments.contains { !DraftFileChip.shows($0) } || (isImporting && importingFile == nil)
        return tall ? 82 : DraftChip.row
    }

    /// The draft's photos, files and recordings above the field, with the
    /// place of one still being read in at the row's end. Until 1.1.0
    /// (262) a 20pt 「添付を読み込んでいます…」 line came first and the 82pt
    /// row then took its place, so the panel jumped twice for one photo
    /// (UI review, 2026-11-11); now the row comes once, at the panel's
    /// pace, and the frame in it becomes the photo.
    private var draftStrip: AnyView {
        let nameLimit = DraftChip.nameLimit(items: attachments.count + (isImporting ? 1 : 0))
        return ScrollView(.horizontal) {
            // Along the bottom: a document's card (44pt) sits on the same
            // line as a photo's 64pt card beside it.
            HStack(alignment: .bottom, spacing: 8) {
                ForEach(attachments) { attachment in
                    if DraftFileChip.shows(attachment) {
                        // A document: its own small glass card, the cross
                        // inside it (1.1.0 (271)). It comes in over the
                        // card-shaped place it was read into, as wide and
                        // where it stood, so it fades in rather than grows;
                        // taken out, it leaves as a photo does.
                        DraftFileChip(attachment: attachment, nameLimit: nameLimit) { takeOutDraft(attachment) }
                            .transition(.asymmetric(insertion: .opacity,
                                                    removal: reduceMotion ? .opacity : .scale(scale: 0.86).combined(with: .opacity)))
                    } else {
                        ZStack(alignment: .topTrailing) {
                            AttachmentCard(attachment: attachment, compact: true)
                            Button { takeOutDraft(attachment) } label: {
                                Image(systemName: "xmark.circle.fill").symbolRenderingMode(.palette)
                                    .foregroundStyle(.white, Color(uiColor: .systemGray))
                                    .font(.system(size: 20)).frame(width: 44, height: 44)
                            }.buttonStyle(.plain).accessibilityLabel("添付を外す: \(attachment.name)")
                                .offset(x: 10, y: -10)
                        }.padding(.top, 10).padding(.trailing, 8)
                            .transition(reduceMotion ? .opacity : .scale(scale: 0.86).combined(with: .opacity))
                    }
                }
                if isImporting {
                    if let importingFile {
                        DraftFileLoadingChip(name: importingFile, nameLimit: nameLimit)
                            .transition(.opacity)
                    } else {
                        AttachmentLoadingCard().padding(.top, 10).padding(.trailing, 8)
                            .transition(.opacity)
                    }
                }
            }.padding(.horizontal, ChatMetrics.gutter)
        }.frame(height: draftStripHeight).accessibilityIdentifier("draft-attachments")
            .modifier(ComposerFade(progress: composerMorph))
            .allowsHitTesting(!composerFolded)
            .accessibilityHidden(composerFolded)
            .transition(.opacity)
            .composerPart()
    }

    /// The draft's row changes at the panel's pace wherever it is changed
    /// from: the whole update, so the conversation above follows with it.
    private func addDraft(_ attachment: ChatAttachment) {
        withAnimation(draftStripMotion) { attachments.append(attachment) }
    }
    private func removeDraft(_ attachment: ChatAttachment) {
        withAnimation(draftStripMotion) { attachments.removeAll { $0.id == attachment.id } }
        AttachmentStorage.remove(attachment)
    }
    /// The cross on an item of the draft: that item alone leaves it, and a
    /// photo picked in the sheet is unpicked there too.
    private func takeOutDraft(_ attachment: ChatAttachment) {
        removeDraft(attachment)
        if let item = pickedAttachments.first(where: { $0.value == attachment.id })?.key {
            pickedAttachments[item] = nil; photoSelection.removeAll { $0 == item }
        }
    }
    /// `file`: the name of a document being read in, whose place is then a
    /// document's card rather than a photo's frame (1.1.0 (271)).
    private func setImporting(_ importing: Bool, file: String? = nil) {
        let file = importing ? file : nil
        guard isImporting != importing || importingFile != file else { return }
        withAnimation(draftStripMotion) { isImporting = importing; importingFile = file }
    }
    /// A document's name, or nil for a photo or a video (from the file's
    /// extension; the import itself still decides what it is).
    private static func documentName(_ url: URL) -> String? {
        guard let type = UTType(filenameExtension: url.pathExtension) else { return url.lastPathComponent }
        return type.conforms(to: .image) || type.conforms(to: .movie) ? nil : url.lastPathComponent
    }

    /// 縮小型: the panel and the three buttons it folds into. スタンダード
    /// (1.1.0 (255)): the same panel, one bar at rest that never folds;
    /// until 254 the plus and the one-line field of 1.0.110
    /// (classicComposer, kept for the UI check's comparison).
    @ViewBuilder private var composerStage: some View {
        if legacyStandard {
            classicComposer
        } else {
            // The panel and the three buttons it folds into share one glass
            // container, as does the jump control that rises out of the
            // panel: the shapes fuse while they part or merge.
            ChatGlassGroup(spacing: ChatMetrics.composerBlend) {
                ZStack(alignment: .bottom) {
                    composerPanel
                    // As in the reference image: a waveform, a round speech
                    // bubble and a down arrow, all in the label color. They
                    // exist only while folded or morphing; at rest the panel
                    // alone is there, for touch and VoiceOver alike.
                    if composerFolded || composerMorphing {
                        foldedButton(-1, symbol: "waveform", size: 19, label: "音声入力", id: "composer-voice",
                                     tuck: jumpTuck) {
                            voiceButtonTapped()
                        }
                        foldedButton(0, symbol: "message", size: 19, label: "入力欄を開く", id: "composer-expand",
                                     tuck: jumpTuck) {
                            unfoldComposer()
                        }
                        .accessibilityHint("メッセージをすぐに入力できます")
                        .accessibilityFocused($unfoldFocused)
                        if !jumpTucked {
                            foldedButton(1, symbol: "arrow.down", size: 16, label: "最新のメッセージへ移動", id: "composer-jump",
                                         tuck: jumpTuck, away: jumpTuck > 0.5) {
                                scrollPolicy.requestLatest(); latestRequest += 1
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(height: composerStageHeight, alignment: .bottom)
                .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                    if abs(composerWidth - $0) > 0.5 { composerWidth = $0 }
                }
                #if POCKET_PREVIEW
                // `--fold-button`: a clear target in the panel's top trailing
                // corner folds the composer, so the UI check can photograph
                // the whole fold (a drag returns only once the app is idle
                // again, after the morph).
                .overlay(alignment: .topTrailing) {
                    if PreviewProbe.on("--fold-button") && !composerFolded {
                        Button { foldComposer() } label: {
                            Color.clear.frame(width: 44, height: 44).contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("折りたたむ")
                        .accessibilityIdentifier("probe-fold")
                    }
                }
                #endif
            }
            .overlay(alignment: .bottom) { composerRowOverlay }
            .composerPart()
        }
    }

    /// The two-row glass panel. The jump control lives in its glass
    /// container: it rises out of the panel and sinks back into it, merging
    /// like Liquid Glass. An overlay keeps it out of the composer's layout.
    private var composerPanel: some View {
        composerField
            // Folded with Reduce Motion, the clear panel keeps its size
            // above the buttons; once settled it takes no taps. (Not from
            // the fold's start, while the field is giving up the keyboard.)
            .allowsHitTesting(!composerSettled)
            .modifier(ComposerPanelMorph(progress: composerMorph, tuck: jumpTuck, width: composerWidth,
                                         height: composerHeight,
                                         radius: standardBar ? ChatMetrics.standardBar / 2 : ChatMetrics.composerRadius,
                                         reduceMotion: reduceMotion) { height in
                if abs(composerHeight - height) > 0.5 { composerHeight = height }
            })
            .chatGlassIdentity("input", in: composerGlass, reduceMotion: reduceMotion)
            .onGeometryChange(for: CGFloat.self) { $0.frame(in: .named(Self.composerSpace)).minY } action: {
                inputTopLatest.value = $0
                // The morph moves this edge on every frame; the jump control
                // only needs it at rest.
                if !composerMorphing && !composerFolded { inputTopInComposer = $0 }
            }
            .overlay(alignment: .top) { risingJump(centerOffset: 0) }
            .allowsHitTesting(!composerFolded)
            .composerPart()
    }

    /// The jump control over the field it rises out of: centered on the
    /// screen (`centerOffset` from the field's center), sinking straight
    /// down into the field while the shapes fuse.
    @ViewBuilder private func risingJump(centerOffset: CGFloat) -> some View {
        if jumpPresent && !showActions {
            jumpButton
                // The glass's own coming and going (jumpGlassVisible), nearest
                // to it: under the two below, the one for `jumpRaised` won
                // whenever both changed at once.
                .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.jumpMaterialize, value: jumpGlassVisible)
                .offset(x: centerOffset)
                .modifier(JumpSink(offset: jumpRaised || reduceMotion || !jumpFusesIntoField ? 0 : jumpSinkDistance,
                                   scale: jumpRaised || reduceMotion ? 1 : ChatMotion.jumpSunkScale,
                                   opacity: jumpGlassShown ? 1 : 0))
                .offset(y: -(ChatMetrics.control + jumpLift))
                .animation(reduceMotion ? ChatMotion.reducedMenu
                           : (jumpRaised ? ChatMotion.jumpRise : ChatMotion.jumpSink),
                           value: jumpRaised)
                .animation(reduceMotion ? ChatMotion.reducedMenu
                           : (jumpFusesIntoField ? nil : ChatMotion.jumpMaterialize),
                           value: jumpGlassShown)
                // Its place above the draft's row, which now comes and goes
                // at the panel's pace: the control goes with it.
                .animation(draftStripMotion, value: jumpLift)
        }
    }

    /// 従来型 (1.0.110): the plus circle beside a one-line field that holds
    /// send, the jump control rising out of the field, nothing folding.
    /// While the field is typed in, the 高速 and model pills rise above it,
    /// lined up with its leading edge; at rest it stays one line thin. Only
    /// the field, the pills' drops and the jump control share a glass
    /// container; the plus and the pills are menus, each with glass of its
    /// own and in no container (pocket-gemma-menu-glass-afterimage).
    private var classicComposer: some View {
        HStack(alignment: .bottom, spacing: ChatMetrics.controlGap) {
            classicPlusButton
            ChatGlassGroup(spacing: ChatMetrics.classicBlend) {
                classicField
                    .chatGlass(in: RoundedRectangle(cornerRadius: ChatMetrics.control / 2))
                    .chatGlassIdentity("input", in: composerGlass, reduceMotion: reduceMotion)
                    .onGeometryChange(for: CGFloat.self) { $0.frame(in: .named(Self.composerSpace)).minY } action: {
                        inputTopInComposer = $0
                    }
                    .overlay(alignment: .topLeading) { classicPillDrops }
                    // Centered on the screen: the field starts after
                    // the plus button.
                    .overlay(alignment: .top) {
                        risingJump(centerOffset: -(ChatMetrics.control + ChatMetrics.controlGap) / 2)
                    }
            }
        }
        // The pills stand on the field's top edge, a row above it, in the
        // bar's room for them (taps outside the bar do not reach them).
        .overlay(alignment: .topLeading) {
            if classicPillsShown || classicPillsSettled {
                classicPills.offset(y: -(ChatMetrics.control + ChatMetrics.chipGap))
            }
        }
        .padding(.top, classicPillRoom ? ChatMetrics.control + ChatMetrics.chipGap : 0)
        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.keyboardFollow, value: classicPillsShown)
        .composerPart()
    }

    /// The pills show while the field has the keyboard, as long as it can
    /// be typed in (not while the plus panel is open); with a hardware
    /// keyboard always (ComposerKeyboard, fielua-reports #3).
    /// Only スタンダード as it was until 1.1.0 (254) has them (`legacyStandard`).
    private var classicPillsShown: Bool {
        legacyStandard && standardTyping
    }

    /// 従来型's pills stood, and スタンダード's bar is open, while the field
    /// has the keys, closing as the keyboard starts down; with a hardware
    /// keyboard always, so its menus answer without the field (222).
    private var standardTyping: Bool {
        ComposerKeyboard.classicPillsShown(focused: inputFocused, keyboardLeaving: keyboardLeaving,
                                           actionsOpen: showActions, hardwareKeyboard: hardwareKeyboard)
    }

    /// スタンダード as it was until 1.1.0 (254), the plus beside a one-line
    /// field (classicComposer): only for the UI check's comparison
    /// (`--standard-as-254`).
    private var legacyStandard: Bool {
        #if POCKET_PREVIEW
        return composerStyle == .classic && PreviewProbe.on("--standard-as-254")
        #else
        return false
        #endif
    }

    /// スタンダード in スマート's panel (1.1.0 (255)): one bar at rest, the
    /// panel while typed in.
    private var standardPanel: Bool { composerStyle == .classic && !legacyStandard }
    private var standardOpenWanted: Bool { standardPanel && standardTyping }
    /// The bar at rest: the text between the plus and send, the pills away.
    private var standardBar: Bool { standardPanel && !standardOpen }

    /// Opens with the keyboard coming up and closes as it goes down, on
    /// the springs the glass moves with elsewhere; the pills come once
    /// there is room for them and leave first (StandardPillReveal).
    private func setStandardOpen(_ open: Bool) {
        guard standardOpen != open else { return }
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : (open ? ChatMotion.standardOpen : ChatMotion.standardClose)) {
            standardOpen = open
        }
    }

    /// The keyboard on its way down: the pills go into the field with it.
    /// Not for a hardware keyboard's notices, whose frames are off the
    /// screen while the field keeps the keys (ComposerKeyboard).
    private func keyboardWillHide(_ note: Notification) {
        let begin = (note.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        let end = (note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
        let leaves = keyboardAs221 || ComposerKeyboard.onScreenKeyboardLeaves(
            beginTop: begin.map { Double($0.minY) }, beginHeight: begin.map { Double($0.height) },
            endTop: end.map { Double($0.minY) })
        if leaves { keyboardLeaving = true }
        SendScreenLog.shared.mark("キーボードの通知: 下がり始め → " + (leaves ? "画面のキーボードが下がる" : "画面外（ボタンはそのまま）"))
    }

    /// 送信直後の画面の記録, with a hardware keyboard: the pills going or
    /// coming, and why.
    private func notePills(_ shown: Bool) {
        let why: [String] = [
            "入力先 " + (inputFocused ? "はい" : "いいえ"),
            "キーボード下降中 " + (keyboardLeaving ? "はい" : "いいえ"),
            "外付けキーボード " + (hardwareKeyboard ? "あり" : "なし"),
            "＋パネル " + (showActions ? "開" : "閉"),
        ]
        SendScreenLog.shared.mark("スタンダードのボタン: \(shown ? "出す" : "しまう")（\(why.joined(separator: " · "))）")
    }

    /// For the UI check's comparison: every notice a leave, as in 1.1.0 (221).
    private var keyboardAs221: Bool {
        #if POCKET_PREVIEW
        return PreviewProbe.on("--keyboard-as-221")
        #else
        return false
        #endif
    }

    /// GameController's word on a hardware keyboard, and again once it has
    /// settled (another keyboard may still be there).
    private func hardwareKeyboardChanged(_ note: Notification) {
        hardwareKeyboard = HardwareKeyboard.attached(after: note)
        if hardwareKeyboard && inputFocused {
            SendScreenLog.shared.beginKeys(field: composerInput.textView, composer: composerStyle, rowAbove: legacyStandard)
        }
        Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(500)) } catch { return }
            hardwareKeyboard = HardwareKeyboard.attached
        }
    }

    /// 高速/じっくり考える (E4B) and the model, as in 縮小型's lower row, their glass
    /// edge on the field's leading edge. Laid out (and measured for their
    /// drops) as the field takes the keyboard, seen only once the drops
    /// rest in their place.
    private var classicPills: some View {
        HStack(spacing: 0) {
            // A Smart Mode chat's genre stands in the model's place.
            if smartChat {
                genreMenu
                    .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                        classicModelWidth = $0 - ChatMetrics.chipGap
                    }
            } else {
                if !chats.currentModel.photoDetails.isEmpty && !chats.isRemoteChat {
                    photoDetailMenu
                        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                            classicDetailWidth = $0 - ChatMetrics.chipGap
                        }
                }
                modelMenu
                    .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                        classicModelWidth = $0 - ChatMetrics.chipGap
                    }
            }
        }
        .padding(.leading, ChatMetrics.control + ChatMetrics.controlGap - ChatMetrics.chipGap / 2)
        .opacity(classicPillsSettled ? 1 : 0)
        .allowsHitTesting(classicPillsShown)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("composer-classic-pills")
        .accessibilityHidden(!classicPillsShown)
        .composerPart()
    }

    /// The pills on their way out of the field and back into it: drops of
    /// the field's glass in its container, each in its pill's place, that
    /// go into the field as the latest button goes into the chat button
    /// (ClassicPillTuck). Their glass is off while the pills stand there.
    @ViewBuilder private var classicPillDrops: some View {
        if classicDropsPresent && !reduceMotion {
            HStack(spacing: ChatMetrics.chipGap) {
                if smartChat {
                    classicDrop(width: classicModelWidth) { genrePillLabel }
                } else {
                    if !chats.currentModel.photoDetails.isEmpty && !chats.isRemoteChat {
                        classicDrop(width: classicDetailWidth) { photoDetailPillLabel }
                    }
                    classicDrop(width: classicModelWidth) { modelPillLabel }
                }
            }
            .offset(y: -(ChatMetrics.chip + (ChatMetrics.control - ChatMetrics.chip) / 2 + ChatMetrics.chipGap))
            .allowsHitTesting(false)
            .accessibilityHidden(true)
        }
    }

    private func classicDrop<Label: View>(width: CGFloat, @ViewBuilder label: () -> Label) -> some View {
        Color.clear
            .modifier(ClassicPillTuck(tuck: classicTuck, width: width, depth: classicTuckDepth,
                                      shown: !classicPillsSettled, label: label()))
            // The pill's place, whatever the drop's size on the way.
            .frame(width: max(0, width), height: ChatMetrics.chip)
    }

    /// From a pill's center to the middle of the field's first line.
    private var classicTuckDepth: CGFloat {
        ChatMetrics.chip / 2 + (ChatMetrics.control - ChatMetrics.chip) / 2 + ChatMetrics.chipGap
            + ChatMetrics.control / 2
    }

    /// Out of the field with the latest button's split, into it with its
    /// absorb (updateJumpTuck), the same springs; they retarget if the
    /// field loses the keyboard on the way. The pills (menus) and the
    /// drops change places without a frame between them: the same shape,
    /// place, fill and label, the glass on one and off the other. Once
    /// made, the drops stay in the field, unseen, so both ways start at
    /// once: a wait for the next turn took a third of a second while the
    /// keyboard came or went (run 279), the pills standing alone meanwhile.
    private func setClassicPillsVisible(_ visible: Bool) {
        classicPillsTask?.cancel()
        let instant: Transaction = { var t = Transaction(); t.disablesAnimations = true; return t }()
        // Drawn outside the bar while they go in, as the jump control is.
        withTransaction(instant) { classicPillRoom = visible }
        if reduceMotion {
            classicDropsPresent = false; classicTuck = 1
            withAnimation(ChatMotion.reducedMenu) { classicPillsSettled = visible }
            return
        }
        let split = {
            withAnimation(ChatMotion.jumpSplit) { classicTuck = 0 } completion: {
                guard classicPillsShown, classicTuck == 0 else { return }
                withTransaction(instant) { classicPillsSettled = true }
            }
        }
        if visible {
            if classicDropsPresent && classicModelWidth > 0 { split(); return }
            // The first time: the drops go into the field, and the pills
            // are measured, before they come out.
            withTransaction(instant) { classicTuck = 1; classicDropsPresent = true }
            classicPillsTask = Task { @MainActor in
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                for _ in 0..<6 where classicModelWidth <= 0 {
                    do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                }
                split()
            }
        } else {
            guard classicPillsSettled || classicTuck < 1 else { return }
            // The drops take the pills' place; made only now (the pills
            // were already out as the field came), they are drawn first.
            let absorb = {
                withAnimation(ChatMotion.jumpAbsorb) { classicTuck = 1 }
            }
            let made = classicDropsPresent
            withTransaction(instant) { classicPillsSettled = false; classicDropsPresent = true }
            if made { absorb(); return }
            classicPillsTask = Task { @MainActor in
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                absorb()
            }
        }
    }

    /// 1.0.110's field: the text and send in one glass capsule. With web
    /// search on, a globe at its start says so (and turns it off) at rest
    /// too, since search sends the question's words out.
    private var classicField: some View {
        HStack(alignment: .bottom, spacing: 0) {
            if webSearchActive {
                classicWebSearchButton.transition(.scale(scale: 0.6).combined(with: .opacity))
            }
            ChatComposerText(text: $draft,
                focused: $inputFocused,
                enabled: chatReady, input: composerInput,
                onReturnKey: returnKeySends)
                .padding(.leading, webSearchActive ? 0 : 14)
            sendButton(circle: 30, glyph: 17)
        }
        .frame(minHeight: ChatMetrics.control)
        .animation(reduceMotion ? nil : ChatMotion.pillState, value: webSearchActive)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("chat-composer")
        .accessibilityHidden(showActions)
        .composerPart()
    }

    private var classicWebSearchButton: some View {
        Button { chats.setWebSearch(false) } label: {
            Image(systemName: "globe").font(.system(size: 16, weight: .medium))
                .foregroundStyle(Theme.active)
                .frame(width: 36, height: ChatMetrics.control)
                .padding(.leading, 4)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(chats.isGenerating)
        .accessibilityLabel("ウェブ検索")
        .accessibilityValue("オン")
        .accessibilityHint("タップでオフにします。オンの間は検索語だけをインターネットに送ります")
        .accessibilityIdentifier("composer-web-search")
    }

    /// 1.0.110's plus: the system glass circle, so the menu morphs out of
    /// it (GlassCircleControl), with the same menu as 縮小型's plus.
    private var classicPlusButton: some View {
        Menu {
            plusMenuItems
        } label: {
            // The glass circle style adds 7pt of padding per side, so a
            // 30pt label gives the shared 44pt circle (iOS 26.4).
            Image(systemName: "plus").font(.system(size: ChatMetrics.icon, weight: .regular))
                .foregroundStyle(.primary)
                .frame(width: 30, height: 30)
        }
        // Keep the written order even though the menu opens upward from the
        // bottom of the screen (automatic order would reverse it there).
        .menuOrder(.fixed)
        .modifier(GlassCircleControl())
        // A neutral glass circle with a label-colored plus, as in Messages;
        // the glass style otherwise paints its label with the app's blue.
        .tint(Color.primary)
        .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        .accessibilityLabel("会話の操作を開く")
        .accessibilityIdentifier("chat-add-menu")
        .composerPart()
    }

    /// One of the folded composer's buttons. Its glass and symbol follow
    /// the morph (ComposerButtonMorph); it takes taps only while folded.
    private func foldedButton(_ slot: CGFloat, symbol: String, size: CGFloat, label: LocalizedStringKey, id: String,
                              tuck: CGFloat = 0, away: Bool = false,
                              action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Color.clear
                .frame(width: ChatMetrics.morphButton, height: ChatMetrics.morphButton)
                .contentShape(RoundedRectangle(cornerRadius: ChatMetrics.morphButton / 2, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
        .accessibilityIdentifier(id)
        .modifier(ComposerButtonMorph(progress: composerMorph, tuck: tuck, slot: slot, symbol: symbol, symbolSize: size,
                                      tint: .primary, reduceMotion: reduceMotion))
        // On its way into the chat button, taps go to the chat button.
        .allowsHitTesting(composerFolded && !away)
        .accessibilityHidden(!composerFolded || away)
    }

    /// The bar's height: the panel's while it is shown or morphing (fixed,
    /// so the morph never relays the conversation out), a button's once
    /// folded, and the panel's own natural size at rest.
    private var composerStageHeight: CGFloat? {
        if composerSettled { return ChatMetrics.morphButton }
        if (composerMorphing || composerFolded) && composerHeight > 0 { return composerHeight }
        return nil
    }

    /// The plus, 高速 and model menus open from glass of their own. Without
    /// it the system menu shrank into a bare outline over the panel when it
    /// closed, and the label came back blurred (device recording, 1.0.111).
    /// A 44pt circle (1.0.113) reached the panel's edge: the plus bulged
    /// out of its corner and fused with the 高速 pill. A 12pt drop at each
    /// center (1.0.114) showed on the phone as a stray ring behind each
    /// label, and the light-mode afterimage stayed. Now the glass is each
    /// button's own circle or capsule (ComposerChipStyle), on a row
    /// outside the panel's glass and outside any glass container, so the
    /// buttons never fuse (composerRowOverlay). It is off while the panel
    /// folds, as the row fades away.
    /// 従来型's pills have theirs only while they stand in their place;
    /// on their way out of the field and back, their drops carry it.
    /// スタンダード's bar (1.1.0 (255)) never folds: its buttons keep their
    /// glass, and its pills come and go by their opacity alone, so none of
    /// them is given its glass later (StandardPillReveal, 209).
    private var menuSourceGlass: Bool {
        if legacyStandard { return classicPillsSettled }
        if standardPanel { return true }
        return !composerFolded && !composerMorphing
    }

    /// The jump control over the panel: only while the panel shows, and not
    /// while a drag into older messages is about to fold it.
    private var floatingJumpWanted: Bool {
        scrollPolicy.showsJumpButton && !composerFolded && !foldLeaning
    }

    private var foldAllowed: Bool {
        #if POCKET_PREVIEW
        // Earlier scroll and jump checks read the unfolded composer.
        if PreviewProbe.on("--keep-composer-open") { return false }
        #endif
        return composerStyle == .folding
            && !composerFolded && !chats.messages.isEmpty && !showPhotos && !showActions && !historyVisible
    }

    /// Reading older messages: the panel shrinks and splits into the three
    /// buttons. The draft stays as it is; only the keyboard goes away.
    private func foldComposer() {
        guard foldAllowed else { return }
        composerFolded = true
        inputFocused = false
        // The fold always parts into all three; at the end the latest
        // button flows into the chat button once they have settled.
        jumpTuckID += 1
        var reset = Transaction(); reset.disablesAnimations = true
        withTransaction(reset) { jumpTuck = 0; jumpTucked = false }
        composerMorphID += 1
        let id = composerMorphID
        composerMorphing = true
        // Scroll callbacks run in transactions without animation.
        Task { @MainActor in
            // Unless the chat button already opened it again.
            guard composerMorphID == id, composerFolded else { return }
            withAnimation(reduceMotion ? ChatMotion.reducedComposer : ChatMotion.composerFold) {
                composerMorph = 1
            } completion: {
                guard composerMorphID == id, composerFolded else { return }
                var transaction = Transaction(); transaction.disablesAnimations = true
                withTransaction(transaction) { composerSettled = true; composerMorphing = false }
                updateJumpTuck()
            }
            if UIAccessibility.isVoiceOverRunning {
                unfoldFocused = true
                UIAccessibility.post(notification: .layoutChanged, argument: nil)
            }
        }
    }

    /// Folded, the latest button is needed only away from the end of the
    /// chat: there it flows into the chat button like liquid, reading up
    /// from the end draws it back out, and the latest button's own tap goes
    /// to the end and then lets it flow in (integrated directive,
    /// 2026-10-21). The end is the scroll state's (`restsAtEnd`, with a
    /// band between arriving and leaving), not the fold's: only a settled
    /// fold follows it, the unfold leaves the button where it is, and
    /// nothing here opens the composer. Springs retarget if the reader
    /// turns back halfway.
    private func updateJumpTuck() {
        guard composerSettled else { return }
        jumpTuckID += 1
        let id = jumpTuckID
        // Scroll updates arrive in transactions without animation. The
        // latest call reads the end as it is by then.
        Task { @MainActor in
            guard jumpTuckID == id, composerSettled else { return }
            let inside = scrollPolicy.restsAtEnd
            guard inside != (jumpTuck == 1) else { return }
            if inside {
                withAnimation(reduceMotion ? ChatMotion.reducedJumpTuck : ChatMotion.jumpAbsorb) {
                    jumpTuck = 1
                } completion: {
                    // Still on its way in, not drawn out again meanwhile.
                    guard jumpTuck == 1, composerSettled else { return }
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { jumpTucked = true }
                }
            } else {
                if jumpTucked {
                    // Back in the hierarchy inside the chat button first.
                    var transaction = Transaction(); transaction.disablesAnimations = true
                    withTransaction(transaction) { jumpTucked = false }
                    do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                    guard jumpTuckID == id else { return }
                }
                withAnimation(reduceMotion ? ChatMotion.reducedJumpTuck : ChatMotion.jumpSplit) { jumpTuck = 0 }
            }
        }
    }

    /// The chat button: the buttons merge back into the panel, and the
    /// field takes the keyboard at once so the draft continues with no
    /// further tap.
    /// `focus`: the keyboard comes up with the panel; not when the panel
    /// opens to record.
    private func unfoldComposer(focus: Bool = true) {
        guard composerFolded else { return }
        composerMorphID += 1
        let id = composerMorphID
        var transaction = Transaction(); transaction.disablesAnimations = true
        withTransaction(transaction) {
            // The panel's room comes back first, so it grows within it.
            composerSettled = false; composerMorphing = true; composerFolded = false
        }
        // 開発者設定's record: where the touches after the unfold go.
        SendScreenLog.shared.beginUnfold(field: composerInput.textView)
        withAnimation(reduceMotion ? ChatMotion.reducedComposer : ChatMotion.composerUnfold) {
            composerMorph = 0
        } completion: {
            guard composerMorphID == id, !composerFolded else { return }
            // The row's buttons are made again with their glass, at once,
            // and the jump control's target finds the field where it now
            // is: the keyboard came up while the morph ran, and nothing
            // moves the field again to tell it.
            var settle = Transaction(); settle.disablesAnimations = true
            withTransaction(settle) {
                composerMorphing = false
                if !unfoldAs205 { inputTopInComposer = inputTopLatest.value }
            }
            SendScreenLog.shared.mark("展開: 動き終わり · 入力欄の上端 \(Int(inputTopInComposer))")
        }
        if focus { inputFocused = true }
        if UIAccessibility.isVoiceOverRunning {
            Task { @MainActor in
                do { try await Task.sleep(for: .milliseconds(350)) } catch { return }
                UIAccessibility.post(notification: .layoutChanged, argument: composerInput.textView)
            }
        }
    }

    private func unfoldComposerAtOnce() {
        composerMorphID += 1
        var transaction = Transaction(); transaction.disablesAnimations = true
        withTransaction(transaction) {
            composerFolded = false; composerSettled = false; composerMorphing = false
            composerMorph = 0; foldLeaning = false
        }
    }

    /// Clears everything above the field (guidance, draft attachments) by
    /// the same gap the control previously kept from the composer's edge.
    private var jumpLift: CGFloat {
        // 24 pt above the field. Draft attachments and
        // the import status sit above the field across the center, so then
        // clear the whole composer.
        guard attachments.isEmpty, !isImporting, !classicPillsShown, !recording else {
            return max(0, inputTopInComposer) + ChatMetrics.jumpGap
        }
        return ChatMetrics.jumpGap
    }

    /// Rise out of / sink into the field. Sinking travels onto the field's
    /// trailing end while shrinking, so inside the shared glass container the
    /// two shapes fuse; the glass is unmounted only after it has merged.
    private func setJumpVisible(_ visible: Bool) {
        jumpSettle?.cancel()
        // Scroll updates arrive in transactions that disable animations (and
        // with them this view's implicit animations); every step runs from a
        // fresh task instead, and springs retarget if the reader reverses.
        if visible {
            if !jumpPresent {
                jumpRaised = false; jumpIconShown = false
                jumpGlassShown = !reduceMotion && jumpFusesIntoField
                jumpPresent = true
            }
            jumpSettle = Task { @MainActor in
                // Mount fused into the field, then rise out of it.
                do { try await Task.sleep(for: .milliseconds(16)) } catch { return }
                jumpGlassShown = true
                jumpRaised = true
                // The arrow arrives once the circle has separated.
                do { try await Task.sleep(for: .milliseconds(reduceMotion ? 0 : 150)) } catch { return }
                jumpIconShown = true
            }
        } else {
            jumpSettle = Task { @MainActor in
                jumpIconShown = false
                if reduceMotion {
                    jumpGlassShown = false
                    do { try await Task.sleep(for: .milliseconds(200)) } catch { return }
                } else if !jumpFusesIntoField {
                    do { try await Task.sleep(for: .milliseconds(60)) } catch { return }
                    jumpRaised = false; jumpGlassShown = false
                    do { try await Task.sleep(for: .milliseconds(320)) } catch { return }
                } else {
                    // Let the arrow clear first, then sink and fuse.
                    do { try await Task.sleep(for: .milliseconds(60)) } catch { return }
                    jumpRaised = false
                    do { try await Task.sleep(for: .milliseconds(420)) } catch { return }
                    jumpGlassShown = false
                    do { try await Task.sleep(for: .milliseconds(32)) } catch { return }
                }
                guard !floatingJumpWanted else { return }
                jumpPresent = false
            }
        }
    }


    /// Visual only; the tap target is the transparent button in `body`.
    /// The arrow fades on its own timing, but as the glass's content it
    /// never leaves the moving shape.
    private var jumpButton: some View {
        // The arrow is the glass's own content, so the system draws it on
        // top of the material. As an overlay inside the shared container it
        // was rendered under the glass: dimmed, and lensed into blue flecks
        // along the rim.
        Image(systemName: "arrow.down")
            .font(.system(size: ChatMetrics.icon, weight: .medium))
            .foregroundStyle(Theme.tint)
            .scaleEffect(jumpIconShown || reduceMotion ? 1 : 0.5)
            .opacity(jumpIconShown ? 1 : 0)
            .animation(reduceMotion ? ChatMotion.reducedMenu
                       : (jumpIconShown ? ChatMotion.jumpIconIn : ChatMotion.jumpIconOut),
                       value: jumpIconShown)
            .frame(width: ChatMetrics.control, height: ChatMetrics.control)
            .chatGlass(in: Circle(), visible: jumpGlassVisible)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }

    /// Whether the control's glass is drawn. Rising out of the field and
    /// sinking into it, the glass stays whole until the circle is taken
    /// away, as approved on the phone (1.0.122). Where it comes and goes in
    /// place instead (「視差効果を減らす」, or with something above the field)
    /// the glass itself is turned off: in the shared container the opacity
    /// around it never hid the glass (UI check 39450890021), so there the
    /// disc came and went in a single frame until 1.1.0 (262).
    private var jumpGlassVisible: Bool { jumpGlassShown || (jumpFusesIntoField && !reduceMotion) }

    /// From its resting place down until the shrunken circle sits wholly
    /// inside the field's top edge, where the shared glass container fuses
    /// the two shapes into one.
    /// Anything above the field (the guidance capsule, draft attachments,
    /// 従来型's pills) would be crossed on the way down; then the circle shrinks and
    /// dematerializes where it rests instead.
    private var jumpFusesIntoField: Bool {
        attachments.isEmpty && !isImporting && !classicPillsShown
    }

    private var jumpSinkDistance: CGFloat {
        jumpLift + ChatMetrics.control / 2 + ChatMotion.jumpSunkDepth
    }

    /// The photo picker as Messages shows it: a sheet resting as a compact
    /// floating card under the field, which a swipe up on the grid grows to
    /// full height and a swipe down returns (or closes). The system drives
    /// that resize, so the embedded grid moves with the sheet instead of
    /// being relaid out frame by frame. The conversation and field stay
    /// usable behind the compact card; tapping the field closes it. Each
    /// tap on a photo adds it to the draft at once; tapping again removes it.
    private var photoSheet: some View {
        PhotosPicker(selection: $photoSelection, maxSelectionCount: 3,
                     selectionBehavior: .continuousAndOrdered, matching: .images,
                     photoLibrary: .shared()) { EmptyView() }
            .photosPickerStyle(.inline)
            .photosPickerDisabledCapabilities([.selectionActions])
            // Messages shows the picker's own bars (albums, search) only
            // at full height; the compact card is the bare grid.
            .photosPickerAccessoryVisibility(photoDetent == .large ? .visible : .hidden, edges: .all)
            .id(photoPickerTicket)
            .ignoresSafeArea(edges: .bottom)
            .presentationDetents([.height(photoSheetHeight), .large], selection: $photoDetent)
            .presentationDragIndicator(.visible)
            .presentationContentInteraction(.resizes)
            .presentationBackgroundInteraction(.enabled(upThrough: .height(photoSheetHeight)))
            // Once a photo is picked, the full-height picker offers the
            // done check on its segmented row, at the trailing edge, as
            // Messages does. At full height the picker's frame starts at the
            // top of the screen (measured on device, 1.0.48), above the
            // sheet's visible top at the status bar's safe area, so the
            // check is placed from that edge rather than the frame's. The
            // frame is read with onGeometryChange: a GeometryReader overlay
            // made the dock's accessibility frame screen-sized (1.0.49-1.0.50).
            // Only the check's slot reads it, so resizing the sheet does not
            // re-render the conversation.
            .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).minY } action: { photoPickerFrame.top = $0 }
            .overlay(alignment: .topTrailing) {
                PhotoDoneSlot(frame: photoPickerFrame, safeTop: windowSafeTop,
                              visible: showsPhotoDone, reduceMotion: reduceMotion) { photoDoneButton }
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("photo-dock")
    }

    private var showsPhotoDone: Bool { photoDetent == .large && !photoSelection.isEmpty }

    /// Where a full-height sheet's visible top sits on screen.
    private var windowSafeTop: CGFloat {
        (UIApplication.shared.connectedScenes.first { $0.activationState == .foregroundActive } as? UIWindowScene)?
            .keyWindow?.safeAreaInsets.top ?? 0
    }

    /// Back to the conversation; the picked photos stay in the draft.
    private var photoDoneButton: some View {
        Button { closePhotoDock() } label: {
            Image(systemName: "checkmark")
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(Theme.onAccent)
                .frame(width: ChatMetrics.photoDone, height: ChatMetrics.photoDone)
                .contentShape(Circle())
                .modifier(ProminentGlass(shape: Circle()))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("完了")
        .accessibilityIdentifier("photo-done")
    }

    private var photoCompactHeight: CGFloat { min(340, max(220, viewportHeight * 0.42)) }

    /// Mirror the picker's live selection into draft attachments, in order.
    private func syncPickedPhotos(old: [PhotosPickerItem], new: [PhotosPickerItem]) {
        for item in old where !new.contains(item) {
            if let id = pickedAttachments.removeValue(forKey: item),
               let attachment = attachments.first(where: { $0.id == id }) {
                removeDraft(attachment)
            }
        }
        for item in new where !old.contains(item) { enqueuePicked(item) }
    }

    private func enqueuePicked(_ item: PhotosPickerItem) {
        let previous = pickerChain
        let ticket = photoPickerTicket
        let owner = pickerContext
        pickerChain = Task { @MainActor in
            await previous?.value
            @MainActor func stillWanted() -> Bool {
                guard ticket == photoPickerTicket, photoSelection.contains(item), let owner else { return false }
                let thread = chats.selectedID, modelID = chats.currentModel.id
                return owner.matches(threadID: thread, modelID: modelID)
            }
            guard stillWanted() else { return }
            do {
                guard let file = try await item.loadTransferable(type: PickedImageFile.self) else {
                    photoSelection.removeAll { $0 == item }; return
                }
                guard stillWanted() else { try? FileManager.default.removeItem(at: file.url); return }
                if let attachment = await importSingle(file.url) {
                    if stillWanted() { pickedAttachments[item] = attachment.id }
                    else { removeDraft(attachment) }
                } else { photoSelection.removeAll { $0 == item } }
            } catch {
                photoSelection.removeAll { $0 == item }
                chats.error = error.localizedDescription
            }
        }
    }

    /// The images a send gives the model: a photo's one, a video's scenes
    /// that the reply sees (ChatAttachment.modelImageNames).
    private func modelImages(_ list: [ChatAttachment]) -> Int {
        let settings = chats.currentSettings
        return list.reduce(0) { $0 + $1.modelImageNames(settings).count }
    }
    private var videoFrames: Int {
        let settings = chats.currentSettings
        return VideoDigest.Allowance(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget).frames
    }

    /// One staged photo through the same validation as other attachments.
    private func importSingle(_ url: URL) async -> ChatAttachment? {
        defer { try? FileManager.default.removeItem(at: url) }
        guard attachmentPolicy.allowsPhotos else { showAttachmentGuide = true; return nil }
        guard !chats.isGenerating, attachments.count < 3 else {
            chats.error = String(localized: "添付は1回の送信で3つまでです。"); return nil
        }
        let selectedThread = chats.selectedID, selectedModel = chats.attachmentModel
        let forClaude = chats.currentClaude != nil
        setImporting(true)
        defer { setImporting(false) }
        do {
            let attachment = try await Task.detached(priority: .userInitiated) {
                try await AttachmentStorage.importFile(url, model: selectedModel, forClaude: forClaude)
            }.value
            guard chats.selectedID == selectedThread, chats.attachmentModel.id == selectedModel.id,
                  attachmentPolicy.allows(attachment) else { AttachmentStorage.remove(attachment); return nil }
            guard modelImages(attachments + [attachment]) <= 4 else {
                AttachmentStorage.remove(attachment); chats.error = String(localized: "画像は合計4場面まで添付できます。"); return nil
            }
            addDraft(attachment)
            return attachment
        } catch {
            chats.error = error.localizedDescription
            return nil
        }
    }

    private func closePhotoDock() {
        showPhotos = false
        // Picked photos stay in the draft; the next panel starts unselected.
        photoSelection = []; pickedAttachments = [:]
        pickerChain?.cancel(); pickerChain = nil
        // A provider may still be staging a selected file after dismissal;
        // with the selection cleared its late callback discards its copies.
        // The sheet's dismissal then gives the picker a new identity.
        pickerContext = nil
    }

    /// Two rows inside one glass panel: the text above, the plus menu and
    /// send (or stop) below, with the keyboard up or down alike. A tap on
    /// the panel's empty space starts typing, as on the field itself.
    private var composerField: some View {
        #if POCKET_PREVIEW
        StackProbe.mark("composerField")
        #endif
        return VStack(spacing: 0) {
            ChatComposerText(text: $draft,
                focused: $inputFocused,
                enabled: chatReady, input: composerInput,
                accessible: !composerFolded, onReturnKey: returnKeySends)
                .frame(minHeight: ChatMetrics.composerTextMinHeight, alignment: .top)
                // スタンダード's bar: the text between the plus and send, on
                // their line; opened, above them as in スマート.
                .padding(.leading, standardBar ? ChatMetrics.standardInset + standardLead + ChatMetrics.standardTextGap
                         : ChatMetrics.composerTextInset)
                .padding(.trailing, standardBar ? ChatMetrics.standardInset + ChatMetrics.control + ChatMetrics.standardTextGap / 2
                         : ChatMetrics.composerTextInset)
                // One line of text is 44pt: 4pt above and below it make the
                // bar, whose ends are round, concentric with the plus and send.
                .padding(.top, 4)
            if menusInPanel {
                composerRow
            } else {
                // The row itself lies over the panel (composerRowOverlay).
                Color.clear.frame(height: standardBar ? ChatMetrics.standardInset
                                  : ChatMetrics.control + ChatMetrics.composerRowInset)
                    .accessibilityHidden(true)
            }
        }
        .frame(maxWidth: .infinity)
        // Behind the rows, so the field, menu and send keep their own taps.
        .background {
            Color.clear.contentShape(Rectangle())
                .onTapGesture { if chatReady { inputFocused = true } }
                .accessibilityHidden(true)
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("chat-composer")
        .accessibilityHidden(showActions || composerFolded)
        .composerPart()
    }

    /// The panel's bottom row: plus, 高速 (E4B), the model, and send.
    private var composerRow: some View {
        HStack(alignment: .center, spacing: 0) {
            // Folded, the panel is hidden under the middle button; its
            // menu and send leave too, so nothing unseen can be reached.
            if composerSettled {
                Color.clear.frame(height: ChatMetrics.control).accessibilityHidden(true)
            } else {
                if menusInPanel {
                    // Their glass blends with nothing nearer than touching:
                    // the panel's group would fuse buttons 8pt apart.
                    ChatGlassGroup(spacing: 0) { composerMenus }
                } else {
                    composerMenus
                }
                // At least the pills' 8pt before send: with じっくり考える's
                // longer name (1.1.0 (248)) a 375pt phone's row left 5pt,
                // and its pill now says じっくり there instead.
                Spacer(minLength: ChatMetrics.chipGap)
                // The estimate of Claude's credit left (1.1.0 (260)), while the relay gives one.
                if chats.currentClaude != nil {
                    ClaudeCreditButton(showSheet: $showCredit)
                        .modifier(StandardPillReveal(shown: !standardBar, reduceMotion: reduceMotion))
                }
                sendButton
            }
        }
        // The plus and send sit as far in from either edge. Every
        // control's target is 44pt tall and they lie side by side, so no
        // two overlap; the pills keep 8pt between them and before send.
        // スタンダード's bar holds them 4pt in, centered on its one line.
        .padding(.horizontal, standardBar ? ChatMetrics.standardInset : ChatMetrics.composerRowInset)
        .padding(.bottom, standardBar ? ChatMetrics.standardInset : ChatMetrics.composerRowInset)
        .composerPart()
    }

    private var composerMenus: some View {
        HStack(alignment: .center, spacing: 0) {
            // What スタンダード's bar keeps at rest (1.1.0 (255)): the plus,
            // and while search is on, the pill that says so and turns it
            // off, since search sends the question's words out.
            HStack(alignment: .center, spacing: 0) {
                attachmentMenuButton
                if !smartChat && webSearchActive {
                    webSearchChip.transition(.scale(scale: 0.6).combined(with: .opacity))
                }
                // Claude's ファイル作成 (1.1.0 (260)), as the web's pill.
                if makesFilesActive {
                    makesFilesChip.transition(.scale(scale: 0.6).combined(with: .opacity))
                }
            }
            .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
                if abs(standardLead - $0) > 0.5 { standardLead = $0 }
            }
            // A Smart Mode chat: the genre alone, which also says ウェブ検索.
            Group {
                if smartChat {
                    genreMenu
                } else {
                    if !chats.currentModel.photoDetails.isEmpty && !chats.isRemoteChat { photoDetailMenu }
                    modelMenu
                }
            }
            .modifier(StandardPillReveal(shown: !standardBar, reduceMotion: reduceMotion))
        }
        .animation(reduceMotion ? nil : ChatMotion.pillState, value: webSearchActive)
        .animation(reduceMotion ? nil : ChatMotion.pillState, value: makesFilesActive)
        .composerPart()
    }

    private var makesFilesActive: Bool { chats.makesFilesOn && chats.makesFilesOffered }

    /// While a Claude chat's ファイル作成 is on: its pill, as search's.
    private var makesFilesChip: some View {
        Button { chats.setMakesFiles(false) } label: {
            ViewThatFits(in: .horizontal) {
                toolLabel(String(localized: "ファイル"), icon: "doc.badge.plus", named: true)
                toolLabel(String(localized: "ファイル"), icon: "doc.badge.plus", named: false)
                    .accessibilityShowsLargeContentViewer { Label("ファイル作成", systemImage: "doc.badge.plus") }
            }
        }
        .modifier(ComposerChipButton(inStyle: true, glass: menuSourceGlass, shape: Capsule()))
        .disabled(chats.isGenerating)
        .accessibilityLabel("ファイル作成")
        .accessibilityValue("オン")
        .accessibilityHint("タップでオフにします")
        .accessibilityIdentifier("composer-make-files")
        .composerPart()
    }

    private func toolLabel(_ name: String, icon: String, named: Bool) -> some View {
        WholePointWidth {
            HStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 14, weight: .medium))
                if named { Text(verbatim: name).font(.subheadline.weight(.medium)) }
            }
            .foregroundStyle(Theme.active)
        }
    }

    /// Whether the next send may search: the chat's switch, a Gemma model,
    /// and no file in the chat or the draft (WebSearchPolicy).
    private var webSearchActive: Bool {
        // Claude searches itself, files or not (1.1.0 (260)).
        if chats.currentClaude != nil { return chats.webSearchOn && chats.webSearchOffered }
        // Smart Mode's ウェブ検索 chooses a model that searches (SmartPlanner).
        if smartChat {
            return chats.genre == .webSearch && searchKey.isReady && chats.webSearchOffered
                && !WebSearchPolicy.blockedByFiles(chats.messages, adding: attachments)
        }
        return WebSearchPolicy.searches(enabled: chats.webSearchOn, keyed: searchKey.isReady, model: chats.currentModel,
                                 messages: chats.messages, attachments: attachments)
    }

    /// While search is on: a pill beside the plus that says so in the
    /// accent color and turns it off. The plus menu turns it on.
    private var webSearchChip: some View {
        Button { chats.setWebSearch(false) } label: {
            ViewThatFits(in: .horizontal) {
                webSearchLabel(named: true)
                webSearchLabel(named: false)
                    .accessibilityShowsLargeContentViewer { Label("ウェブ検索", systemImage: "globe") }
            }
        }
        .modifier(ComposerChipButton(inStyle: true, glass: menuSourceGlass, shape: Capsule()))
        .disabled(chats.isGenerating)
        .accessibilityLabel("ウェブ検索")
        .accessibilityValue("オン")
        .accessibilityHint("タップでオフにします。オンの間は検索語だけをインターネットに送ります")
        .accessibilityIdentifier("composer-web-search")
        .composerPart()
    }

    private func webSearchLabel(named: Bool) -> some View {
        WholePointWidth {
            HStack(spacing: 4) {
                Image(systemName: "globe").font(.system(size: 14, weight: .medium))
                if named { Text("検索").font(.subheadline.weight(.medium)) }
            }
            .foregroundStyle(Theme.active)
        }
    }

    /// The row over the panel, outside its glass and outside every glass
    /// container, the way a glass button stands on its own over content.
    /// Inside them (1.0.111-1.0.114), each system menu grew out of a
    /// label nested in the panel's glass: on the phone, light mode showed an
    /// afterimage behind the plus and 高速 menus while they opened and
    /// closed (the developer forums report dark flashes and halos for
    /// menus inside glass, and broken morphs inside glass containers).
    /// It fades and shrinks with the panel's content as the panel folds.
    @ViewBuilder private var composerRowOverlay: some View {
        if !menusInPanel && !composerSettled {
            composerRow
                .id(unfoldAs205 || composerRowGlass)
                .modifier(ComposerRowFade(progress: composerMorph, reduceMotion: reduceMotion))
                .allowsHitTesting(!composerFolded)
                .accessibilityHidden(showActions || composerFolded)
        }
    }

    /// The row comes back with the unfold before its buttons' glass does
    /// (menuSourceGlass): the plus, 検索, 深く and model buttons were made
    /// with no glass and given their interactive glass later, unlike at
    /// launch. On the phone (iOS 27.2) they did not answer after an unfold
    /// (the person, 2026-10-27; the simulator, iOS 26, answers either way),
    /// so they are made again the moment their glass returns, exactly as
    /// the row is made at launch (1.1.0 (209)).
    private var composerRowGlass: Bool { menuSourceGlass }

    /// `--unfold-as-205` (UI check only): the unfold as in 1.1.0 (205),
    /// the row kept and the jump control's target where it was, for
    /// comparison.
    private var unfoldAs205: Bool {
        #if POCKET_PREVIEW
        PreviewProbe.on("--unfold-as-205")
        #else
        false
        #endif
    }

    /// `--menus-in-panel` (UI check only) puts the row back inside the
    /// panel's glass as in 1.0.114, to compare their menu frames.
    private var menusInPanel: Bool {
        #if POCKET_PREVIEW
        PreviewProbe.on("--menus-in-panel")
        #else
        false
        #endif
    }

    /// E4B only: how it reads photos and writes replies (高速 or じっくり考える,
    /// 1.1.0 (248)), a pill beside the plus that shows the saved choice and
    /// changes it from a menu. 高速 also answers chats without photos
    /// briefly and faster, so the pill stays in every E4B chat. The choice
    /// applies from the next send, so it waits while a reply is written. The
    /// model pill follows it. Where the launch lacks the address space for
    /// じっくり考える, it runs as 深く without thinking; the menu ends with a
    /// dimmed row that says so, as a locked model's does, and the pill shows
    /// a caution sign in place of its brain (`deeperFallsBack`).
    private var photoDetailMenu: some View {
        Menu {
            Picker("返信のモード", selection: Binding(get: { chats.photoDetail }, set: { detail in
                // The pill takes its new width, and the model's pill its new
                // place, at the panel's pace (in one frame until 1.1.0 (262)).
                withAnimation(reduceMotion ? nil : ChatMotion.resize) { chats.setPhotoDetail(detail) }
            })) {
                ForEach(chats.currentModel.photoDetails) { detail in
                    Label(detail.title, systemImage: photoDetailSymbol(detail)).tag(detail)
                }
            }
            .pickerStyle(.inline)
            if chats.deeperFallsBack {
                Section {
                    Button {} label: {
                        Text("今は考える処理を使えません")
                        Text("アドレス空間が足りないため、考えずに答えます。")
                        Image(systemName: "exclamationmark.triangle")
                    }
                    .disabled(true)
                    .accessibilityIdentifier("composer-photo-detail-fallback")
                }
            }
        } label: {
            photoDetailPillLabel
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        .menuOrder(.fixed)
        .tint(Color.primary)
        .disabled(chats.isGenerating)
        .accessibilityLabel("返信のモード")
        .accessibilityValue(chats.deeperFallsBack
                            ? String(localized: "\(chats.photoDetail.title)。今は考える処理を使えません")
                            : chats.photoDetail.title)
        .accessibilityHint("高速は短く速く返信します。じっくり考えるは写真を最も細かく読み、よく考えてから返信します")
        .accessibilityIdentifier("composer-photo-detail")
        .composerPart()
    }

    /// What じっくり考える does where the launch lacks the address space for
    /// it, at the top of the chat: it never runs as another mode unannounced
    /// (the user's directive, 2026-10-31). Its menu row says it shorter, as
    /// a menu cuts a subtitle at three lines.
    static var deeperFallbackNote: String {
        String(localized: "アドレス空間が足りないため、じっくり考えるでも今は考えずに答えます。")
    }

    /// じっくり考える is the longest name. Where the row has no room for it
    /// (large text, a narrow phone), the pill says じっくり beside its own
    /// symbol, at the same size. Where no name fits (the largest text on a
    /// narrow phone), any mode shows its symbol alone, whose name a long
    /// press shows large, as a bar's buttons do. The capsule stays 36pt.
    private var photoDetailPillLabel: some View {
        let detail = chats.photoDetail
        let short = detail == .deeper ? String(localized: "じっくり") : detail.title
        return ViewThatFits(in: .horizontal) {
            photoDetailLabel(detail.title)
            photoDetailLabel(short)
            photoDetailLabel(nil)
                .accessibilityShowsLargeContentViewer {
                    Label(detail.title, systemImage: pillSymbol)
                }
        }
    }

    private func photoDetailSymbol(_ detail: PhotoDetail) -> String {
        switch detail {
        case .fast: "bolt"
        case .deep: "sparkle.magnifyingglass"
        case .deeper: "brain"
        }
    }

    /// The pill's symbol: the mode's, or a caution sign while じっくり考える
    /// runs without thinking.
    private var pillSymbol: String {
        chats.deeperFallsBack ? "exclamationmark.triangle" : photoDetailSymbol(chats.photoDetail)
    }

    /// The pill's content: the mode's symbol, a name unless none fits, and
    /// the menu's chevron, in a width of whole points (WholePointWidth).
    private func photoDetailLabel(_ name: String?) -> some View {
        WholePointWidth {
            HStack(spacing: 4) {
                Image(systemName: pillSymbol)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(chats.deeperFallsBack ? AnyShapeStyle(Theme.caution) : AnyShapeStyle(ForegroundStyle()))
                    .contentTransition(.symbolEffect(.replace))
                if let name { Text(name).font(.subheadline.weight(.medium)).contentTransition(.opacity) }
                Image(systemName: "chevron.down")
                    .font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
            }
        }
    }

    /// The model pill: Pocket AI's models by family in a system menu. Gemma 4
    /// is a submenu of E2B, E4B and the test version 12B, so the family
    /// alone never switches; Qwen2.5 follows it, and Qwen3 too while
    /// developer settings are on (1.1.0 (204)).
    /// The current model has the check. Choosing another opens a new chat
    /// with it, as the model list does, carrying the draft's text.
    private var modelMenu: some View {
        Menu {
            Section {
                Menu {
                    ForEach(gemmaModels) { spec in modelItem(spec) }
                    ForEach(lockedModels) { spec in lockedModelItem(spec) }
                } label: {
                    Text("Gemma 4")
                    Text(chats.currentModel.family == ModelSpec.e4b.family
                         ? "\(shortModelName(chats.currentModel))を使用中" : "E2B・E4B・12B")
                }
                .accessibilityIdentifier("model-menu-gemma")
                ForEach(otherModels) { spec in modelItem(spec) }
            }
            // The registered PC's models (PCと接続, 1.1.0 (253)).
            PCModelMenuSection(current: chats.currentPC) { switchToPC($0) }
            // Claude, once this iPhone is registered (1.1.0 (257)).
            ClaudeModelMenuSection(current: chats.currentClaude) { switchToClaude($0) }
            // A chat whose model the person chose, with Smart Mode on: its
            // next question may be Smart Mode's again.
            if smartModeOn && chats.current?.modelPinned == true {
                Section {
                    Button { chats.unpinModel() } label: {
                        Label("質問に合わせて自動で選ぶ", systemImage: "sparkles")
                    }
                    .accessibilityIdentifier("model-menu-smart")
                }
            }
            Section {
                Button { openSettings() } label: {
                    Label("モデルを管理", systemImage: "square.stack.3d.up")
                }
                .accessibilityIdentifier("model-menu-manage")
            }
        } label: {
            modelPillLabel
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        .menuOrder(.fixed)
        .tint(Color.primary)
        .disabled(chats.isGenerating)
        .accessibilityLabel("モデルを選ぶ")
        .accessibilityValue(chats.currentPC.map { "\($0.pcName) · \($0.model)" } ?? chats.currentClaude?.spoken ?? chats.currentModel.name)
        .accessibilityHint("選んだモデルで新しいチャットを始めます")
        .accessibilityIdentifier("composer-model")
        .composerPart()
    }

    private var modelPillLabel: some View {
        HStack(spacing: 4) {
            // A PC chat: the PC's mark before its model (PCと接続, 1.1.0 (253)).
            // Claude: a cloud, an AI over the internet (1.1.0 (257)).
            if chats.isRemoteChat {
                Image(systemName: chats.currentPC != nil ? "desktopcomputer" : "cloud").font(.system(size: 12, weight: .medium))
            }
            Text(chats.currentPC?.pillName ?? chats.currentClaude?.shortName ?? shortModelName(chats.currentModel))
                .font(.subheadline.weight(.medium)).lineLimit(1)
            Image(systemName: "chevron.down")
                .font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
        }
    }

    /// Smart Mode (1.1.0 (249), the user's directive of 2026-10-31): the
    /// chat's 質問のジャンル, a pill beside the plus in place of the reply
    /// mode and the model, which Smart Mode chooses for each question
    /// (SmartPlanner). 自動 unless the person names a genre; the genre is
    /// kept with the chat and applies from the next question, so it may be
    /// changed while a reply is written, which goes on as it began.
    /// ウェブ検索 needs the Tavily connection, which it asks for as the plus
    /// menu does. The menu ends with what the last reply was answered with
    /// and モデルを管理, where a model may still be chosen for a chat.
    private var genreMenu: some View {
        Menu {
            Picker("質問のジャンル", selection: Binding(get: { chats.genre }, set: { chooseGenre($0) })) {
                ForEach(SmartGenre.allCases) { genre in
                    Label(genre.title, systemImage: genre.symbol).tag(genre)
                }
            }
            .pickerStyle(.inline)
            if let reply = chats.lastSmartReply {
                Section("前回の返信") {
                    Button {} label: {
                        Text(reply.summary)
                        Text(reply.genreLine)
                        Image(systemName: "info.circle")
                    }
                    .disabled(true)
                    .accessibilityIdentifier("composer-genre-last")
                }
            }
            // The registered PC's models, which a Smart Mode chat may also
            // use, as a chosen model (PCと接続, 1.1.0 (253)).
            PCModelMenuSection(current: chats.currentPC) { switchToPC($0) }
            // Claude, once this iPhone is registered (1.1.0 (257)).
            ClaudeModelMenuSection(current: chats.currentClaude) { switchToClaude($0) }
            Section {
                Button { openSettings() } label: {
                    Label("モデルを管理", systemImage: "square.stack.3d.up")
                }
                .accessibilityIdentifier("composer-genre-manage")
            }
        } label: {
            genrePillLabel
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Capsule()))
        .menuOrder(.fixed)
        .tint(Color.primary)
        .accessibilityLabel("質問のジャンル")
        .accessibilityValue(chats.genre.title)
        .accessibilityHint("選んだジャンルに合わせて、モデルと返信の仕方を自動で選びます")
        .accessibilityIdentifier("composer-genre")
        .composerPart()
    }

    /// The genre's symbol and name, or its symbol alone where no name fits
    /// (the largest text on a narrow phone), whose name a long press shows
    /// large. ウェブ検索 is in the accent color, as the search pill was: it
    /// sends the question's words out.
    private var genrePillLabel: some View {
        let genre = chats.genre
        return ViewThatFits(in: .horizontal) {
            genreLabel(genre, named: true)
            genreLabel(genre, named: false)
                .accessibilityShowsLargeContentViewer { Label(genre.title, systemImage: genre.symbol) }
        }
    }

    private func genreLabel(_ genre: SmartGenre, named: Bool) -> some View {
        WholePointWidth {
            HStack(spacing: 4) {
                Image(systemName: genre.symbol)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(genre == .webSearch ? AnyShapeStyle(Theme.active) : AnyShapeStyle(ForegroundStyle()))
                    .contentTransition(.symbolEffect(.replace))
                if named { Text(genre.title).font(.subheadline.weight(.medium)).lineLimit(1).contentTransition(.opacity) }
                Image(systemName: "chevron.down")
                    .font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
            }
        }
    }

    /// ウェブ検索 only where the chat may search: connected to Tavily (else
    /// the connection's note, as the plus menu shows), and no file or video
    /// in the chat or the draft.
    private func chooseGenre(_ genre: SmartGenre) {
        if genre == .webSearch {
            if WebSearchPolicy.blockedByFiles(chats.messages, adding: attachments) {
                chats.error = SmartNotice.searchBlockedByFiles.text; return
            }
            if !searchKey.isReady { showWebSearchKeyNote = true; return }
        }
        withAnimation(reduceMotion ? nil : ChatMotion.resize) { chats.setGenre(genre) }
    }

    /// E2B and E4B, then the test version 12B (1.1.0 (204)).
    private var gemmaModels: [ModelSpec] {
        ModelSpec.visibleCatalog(developer: showDeveloperSettings)
            .filter { $0.family == ModelSpec.e4b.family }
            .sorted { ($0.isTestVersion ? 1 : 0, $0.name) < ($1.isTestVersion ? 1 : 0, $1.name) }
    }

    /// Qwen2.5 1.5B for everyone (1.1.0 (204)); Qwen3 0.6B before it with
    /// developer settings.
    private var otherModels: [ModelSpec] {
        ModelSpec.visibleCatalog(developer: showDeveloperSettings).filter { $0.family != ModelSpec.e4b.family }
    }

    /// A locked Gemma, dimmed under Gemma 4: none since 12B opened in
    /// 1.1.0 (204).
    private var lockedModels: [ModelSpec] {
        ModelSpec.lockedCatalog.filter { $0.family == ModelSpec.e4b.family }
    }

    /// E2B and E4B within Gemma 4; other models by their whole name.
    private func shortModelName(_ spec: ModelSpec) -> String {
        spec.family == ModelSpec.e4b.family ? spec.name.replacingOccurrences(of: "Gemma 4 ", with: "") : spec.name
    }

    /// A checkable item: the system menu draws the check before the title.
    /// A test version (12B) says so first in its subtitle.
    private func modelItem(_ spec: ModelSpec) -> some View {
        Toggle(isOn: Binding(get: { !chats.isRemoteChat && chats.currentModel.id == spec.id },
                             set: { if $0 { switchModel(to: spec) } })) {
            Text(spec.name)
            Text(spec.isTestVersion ? String(localized: "テスト版 · \(modelStatus(spec))") : modelStatus(spec))
        }
        .accessibilityIdentifier("model-menu-\(spec.id)")
    }

    /// A locked model: a disabled item, so the system menu dims it and it
    /// can never be chosen (switchModel and ModelStore refuse it as well).
    private func lockedModelItem(_ spec: ModelSpec) -> some View {
        Button {} label: {
            Text(spec.name)
            Text("ロック中")
            Image(systemName: "lock")
        }
        .disabled(true)
        .accessibilityValue(String(localized: "ロック中。まだ選択やダウンロードはできません。"))
        .accessibilityIdentifier("model-menu-\(spec.id)")
    }

    private func modelStatus(_ spec: ModelSpec) -> String {
        if model.isDownloading(spec) { return String(localized: "ダウンロード中 \(Int((model.progress(for: spec) * 100).rounded()))%") }
        if model.isWorking(on: spec) { return model.statusText(for: spec) }
        if !model.isInstalled(spec) { return String(localized: "未ダウンロード") }
        return ModelAttachmentPolicy(model: spec).summary
    }

    private var sendButton: some View { sendButton(circle: ChatMetrics.sendButton, glyph: 18) }

    /// Send, or stop while a reply is written: a `circle` in a 44pt target.
    /// The panel's is 34pt, 従来型's field keeps 1.0.110's 30pt. For a model
    /// that hears a voice (1.1.0 (236)), with nothing to send it is the
    /// waveform that records, and the red stop that ends the recording.
    private func sendButton(circle: CGFloat, glyph: CGFloat) -> some View {
        #if POCKET_PREVIEW
        StackProbe.mark("sendButton")
        #endif
        let mode: SendMode = chats.isGenerating ? .stop : (recording ? .endRecording : (recordOffered ? .record : .send))
        let filled = mode == .stop || (mode == .send && canSend)
        return Button {
            switch mode {
            case .stop: chats.stop()
            case .endRecording: finishRecording()
            case .record: startRecording()
            case .send: send()
            }
        } label: {
            Image(systemName: mode.symbol)
                .contentTransition(reduceMotion ? .identity : .symbolEffect(.replace))
                .font(.system(size: mode.stops ? glyph - 6 : glyph, weight: mode == .record ? .semibold : .bold))
                .foregroundStyle(mode == .endRecording ? Color.white : (filled ? Theme.onAccent : (mode == .record ? Color.primary : Theme.sendIdleGlyph)))
                .frame(width: circle, height: circle)
                .background(mode == .endRecording ? Color.red : (filled ? Theme.accent : Theme.sendIdle), in: Circle())
                .frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Rectangle())
                .animation(reduceMotion ? nil : ChatMotion.sendLook, value: mode)
        }
        .accessibilityLabel(mode.label)
        .accessibilityHint(mode == .record ? "録音を始めます。もう一度タップすると止まります" : "")
        .disabled(chats.isStopping || (mode == .send && !canSend))
        .buttonStyle(.plain)
        .composerPart()
    }

    private enum SendMode: Equatable {
        case send, stop, record, endRecording
        var symbol: String {
            switch self {
            case .send: "arrow.up"
            case .stop, .endRecording: "stop.fill"
            case .record: "waveform"
            }
        }
        var stops: Bool { self == .stop || self == .endRecording }
        var label: LocalizedStringKey {
            switch self {
            case .send: "送信する"
            case .stop: "停止する"
            case .record: "話しかける"
            case .endRecording: "録音を止める"
            }
        }
    }

    /// The folded composer's waveform: records where the model hears a
    /// voice, the panel opening without the keyboard; elsewhere says which
    /// model does.
    private func voiceButtonTapped() {
        guard smartChat ? model.isInstalled(.lfm3Omni) : attachmentPolicy.allowsVoice else { showVoiceNote = true; return }
        guard smartChat || model.isInstalled(chats.currentModel) else { openSettings(); return }
        unfoldComposer(focus: false)
        startRecording()
    }

    private func startRecording() {
        guard voiceReady, recorder.phase == .idle else { return }
        inputFocused = false
        if showPhotos { closePhotoDock() }
        let owner = AttachmentImportContext(threadID: chats.selectedID, modelID: chats.currentModel.id)
        Task { @MainActor in
            let start = await recorder.start { outcome in voiceFinished(outcome, owner: owner) }
            switch start {
            case .recording:
                UIAccessibility.post(notification: .announcement, argument: String(localized: "録音を始めました"))
            case .denied: showMicrophoneNote = true
            case .failed(let message): if !message.isEmpty { chats.error = message }
            }
        }
    }

    /// Ends the recording; it joins the draft (voiceFinished).
    private func finishRecording() {
        guard recorder.isRecording else { return }
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.resize) { recorder.stop() }
    }

    private func cancelRecording() {
        guard recorder.phase != .idle else { return }
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.resize) { recorder.cancel() }
    }

    /// The recording, attached to the draft of the chat and model it was
    /// made for; dropped when the screen has moved on.
    private func voiceFinished(_ outcome: VoiceRecorder.Outcome, owner: AttachmentImportContext) {
        switch outcome {
        case .recorded(let attachment):
            guard owner.matches(threadID: chats.selectedID, modelID: chats.currentModel.id), attachments.count < 3 else {
                AttachmentStorage.remove(attachment); return
            }
            addDraft(attachment)
        case .tooShort:
            UIAccessibility.post(notification: .announcement, argument: String(localized: "短すぎたため、録音を消しました"))
        case .failed(let message):
            if !message.isEmpty { chats.error = message }
        }
    }

    private var attachmentMenuButton: some View {
        Menu {
            plusMenuItems
        } label: {
            // A label-colored plus in a glass circle as tall as the pills
            // (ComposerChipStyle).
            Image(systemName: "plus").font(.system(size: 17, weight: .medium))
                .modifier(ComposerChipLabel(inLabel: menusInPanel, glass: menuSourceGlass, shape: Circle(),
                                            width: ChatMetrics.chip))
        }
        .modifier(ComposerChipButton(inStyle: !menusInPanel, glass: menuSourceGlass, shape: Circle(),
                                     width: ChatMetrics.chip))
        // Keep the written order even though the menu opens upward from the
        // bottom of the screen (automatic order would reverse it there).
        .menuOrder(.fixed)
        .tint(Color.primary)
        .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        .accessibilityLabel("会話の操作を開く")
        .accessibilityIdentifier("chat-add-menu")
        .composerPart()
    }

    /// The plus menu: attachments, web search and the conversation actions.
    @ViewBuilder private var plusMenuItems: some View {
        // A model that takes no attachments (Qwen) offers none of them;
        // the conversation actions below stay.
        // A PC chat sends text alone (PCと接続, 1.1.0 (253)); a Claude chat
        // photos and files, never videos (1.1.0 (260)).
        if attachmentPolicy.allowsAnyAttachment && chats.currentPC == nil {
            Section {
                // A text-only model reads only the photo's text, and says so.
                // No カメラ since 1.1.0 (191): the user dropped it (2026-10-25).
                menuItem(String(localized: "写真"), icon: "photo.on.rectangle", id: "chat-attach-photos",
                         subtitle: attachmentPolicy.readsPhotoText ? String(localized: "文字だけ読み取り") : nil,
                         locked: !attachmentPolicy.allowsPhotos,
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3) {
                    if attachmentPolicy.allowsPhotos { openPicker(photos: true) } else { showAttachmentGuide = true }
                }
                menuItem(String(localized: "ファイル"), icon: "folder", id: "chat-attach-files",
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3) {
                    openPicker(photos: false)
                }
                // A video takes one to three of a send's four images, the
                // scenes the reply sees (VideoDigest.Allowance), and one is
                // analyzed at a time.
                let hasVideo = attachments.contains { $0.kind == .video }
                let videoFits = !hasVideo && modelImages(attachments) + videoFrames <= 4
                if chats.currentClaude == nil {
                menuItem(String(localized: "動画"), icon: "video", id: "chat-attach-video",
                         subtitle: !attachmentPolicy.allowsVideo || videoFits ? nil
                            : (hasVideo ? String(localized: "動画は1回の送信で1本までです。") : String(localized: "画像は合計4場面まで添付できます。")),
                         locked: !attachmentPolicy.allowsVideo,
                         disabled: chats.isGenerating || isImporting || attachments.count >= 3 || !videoFits) {
                    if attachmentPolicy.allowsVideo { openVideoPicker() } else { showAttachmentGuide = true }
                }
                }
            }
        }
        // Claude's own ウェブ検索 and ファイル作成 (1.1.0 (260)).
        if chats.currentClaude != nil {
            ClaudeToolItems(chats: chats)
        } else {
            gemmaWebSearchItems
        }
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
            Section {
                ForEach(PreviewAttachments.names, id: \.self) { name in
                    menuItem(name, icon: "doc", id: name, disabled: isImporting || chats.isGenerating) {
                        if let url = PreviewAttachments.url(name) { importAttachments([url], temporary: false) }
                    }
                }
            }
        }
        #endif
        // 会話一覧 and 設定 are the header's and the history's alone (user
        // 2026-10-28 14:28 UTC, 1.1.0 (224)).
        Section {
            menuItem(String(localized: "新しいチャット"), icon: "square.and.pencil", id: "新しいチャット", disabled: chats.isGenerating) { chats.newChat() }
        }
    }

    @ViewBuilder private var gemmaWebSearchItems: some View {
        // Gemma may search the web for this chat. Off by default; a chat
        // with a file stays offline. Not connected to Tavily (no sign-in, no
        // key), the row says where to connect.
        if chats.webSearchOffered {
            Section {
                if searchKey.isReady {
                    Toggle(isOn: Binding(get: { chats.webSearchOn && !chats.webSearchBlocked },
                                         set: { chats.setWebSearch($0) })) {
                        Text("ウェブ検索")
                        // On, what leaves the phone; off, nothing to say.
                        if chats.webSearchBlocked { Text("ファイル付きの会話では使えません") }
                        else if chats.webSearchOn { Text("検索語だけを送ります") }
                        Image(systemName: "globe")
                    }
                    .disabled(chats.isGenerating || chats.webSearchBlocked)
                    .accessibilityIdentifier("chat-web-search")
                } else {
                    menuItem(String(localized: "ウェブ検索"), icon: "globe", id: "chat-web-search",
                             subtitle: chats.webSearchBlocked ? String(localized: "ファイル付きの会話では使えません")
                                : searchKey.account == .needsSignIn ? String(localized: "Tavilyにもう一度ログインすると使えます")
                                : String(localized: "Tavilyに接続すると使えます"),
                             disabled: chats.isGenerating || chats.webSearchBlocked) { showWebSearchKeyNote = true }
                }
            }
        }
    }

    /// モデル管理 from the composer's model menu. The keyboard goes down
    /// first, as for 構成's mark, and comes back once the sheet has closed:
    /// left for the sheet to put away, its fall now and then laid the new
    /// sheet out from nothing, and the rows grew from a sliver to their width
    /// as it rose (user's recording, 2026-10-26 16:01 UTC).
    private func openSettings() {
        var keyboardFirst = inputFocused
        #if POCKET_PREVIEW
        // For the UI check's comparison: the sheet taking the keyboard, as before.
        if PreviewProbe.on("--settings-open-keep-keyboard") { keyboardFirst = false }
        #endif
        if keyboardFirst { settingsTookKeyboard = true; inputFocused = false }
        #if POCKET_PREVIEW
        // For the UI check: the sheet asked for inside an animation, as the
        // keyboard's fall did on the phone (the simulator's keyboard is
        // down before its sheet comes).
        if PreviewProbe.on("--settings-open-in-animation") {
            withAnimation(.linear(duration: 0.8)) { showModel = true }
            return
        }
        #endif
        showModel = true
    }

    /// A menu row. Locked items stay selectable and explain how to use them;
    /// they show a lock and a "調整中" subtitle instead of looking disabled.
    private func menuItem(_ title: String, icon: String, id: String? = nil, subtitle: String? = nil, locked: Bool = false,
                          disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
            if locked { Text("調整中") } else if let subtitle { Text(subtitle) }
            Image(systemName: locked ? "lock" : icon)
        }
        .disabled(disabled)
        .accessibilityIdentifier(id ?? title)
        .accessibilityValue(locked ? String(localized: "現在調整中") : subtitle ?? "")
    }

    private var actionMenuHeight: CGFloat {
        #if POCKET_PREVIEW
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") { return 460 }
        #endif
        return min(460, menuRowHeight * 7 + 32)
    }
    private func actionRow(_ title: String, icon: String, tint: Color, locked: Bool = false, disabled: Bool = false,
                           action: @escaping () -> Void) -> some View {
        Button {
            closeActions()
            action()
        } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 17, weight: .medium)).foregroundStyle(tint)
                    .frame(width: 32, height: 32)
                    .background(tint.opacity(0.12), in: Circle())
                Text(title).font(.body.weight(.medium)).foregroundStyle(.primary).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 4)
                if locked { Image(systemName: "lock.fill").font(.caption).foregroundStyle(.secondary).accessibilityHidden(true) }
            }
            .frame(maxWidth: .infinity, minHeight: menuRowHeight, alignment: .leading).padding(.horizontal, 6)
            .contentShape(Rectangle())
        }
        .accessibilityLabel(title)
        .accessibilityValue(locked ? "現在調整中" : "")
        .accessibilityHint(locked ? "利用できる方法を確認します" : "")
        .buttonStyle(.plain).disabled(disabled).opacity(disabled ? 0.4 : 1)
    }
    private func switchToE2B() { switchModel(to: .e2b) }

    /// The model list's path (ModelView): a new chat with the model, the
    /// previous model's memory released, and only the draft's text carried
    /// over; draft photos and files stay behind. A model that is not saved
    /// on the phone opens the model list instead.
    private func switchModel(to spec: ModelSpec) {
        guard !spec.isLocked, !chats.isGenerating, spec.id != chats.currentModel.id || chats.isRemoteChat else { return }
        // Not saved yet (12B and Qwen2.5 for everyone since 1.1.0 (204)):
        // モデル管理 opens as from the menu's モデルを管理, keyboard down first.
        guard model.isInstalled(spec) else { openSettings(); return }
        draftToRestore = composerInput.committedText(fallback: draft)
        inputFocused = false
        model.select(spec)
        // The person's choice: Smart Mode leaves the chat's model as chosen.
        chats.newChat(modelID: spec.id, pinned: true)
        chats.releaseModelMemory()
    }
    /// A model on the registered PC (PCと接続, 1.1.0 (253)): a new chat
    /// answered by it, as a phone model's choice starts one.
    private func switchToPC(_ target: PCChatTarget) {
        guard !chats.isGenerating, chats.currentPC != target else { return }
        draftToRestore = composerInput.committedText(fallback: draft)
        inputFocused = false
        chats.newPCChat(target)
        chats.releaseModelMemory()
    }
    /// Claude (1.1.0 (257)): a new chat answered by the model chosen, as a
    /// phone model's choice starts one.
    private func switchToClaude(_ model: ClaudeModel) {
        guard !chats.isGenerating, chats.currentClaude?.model != model.id else { return }
        draftToRestore = composerInput.committedText(fallback: draft)
        inputFocused = false
        chats.newClaudeChat(model)
        chats.releaseModelMemory()
    }
    private func openPicker(photos: Bool) {
        pickerContext = AttachmentImportContext(threadID: chats.selectedID, modelID: chats.currentModel.id)
        if photos {
            inputFocused = false
            photoPickerTicket = UUID()
            photoSheetHeight = photoCompactHeight
            photoDetent = .height(photoSheetHeight)
            showPhotos = true
        } else { showFiles = true }
    }
    private func openVideoPicker() {
        pickerContext = AttachmentImportContext(threadID: chats.selectedID, modelID: chats.currentModel.id)
        inputFocused = false
        guard showPhotos else { showVideos = true; return }
        // One sheet at a time: the photo sheet goes first, its photos stay.
        closePhotoDock()
        Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            showVideos = true
        }
    }
    /// A video from the photo library: copied out of Photos (from iCloud
    /// when it must be), then imported as one from ファイル is.
    private func importPickedVideo(_ item: PhotosPickerItem) {
        guard let owner = pickerContext, !isImporting, !chats.isGenerating else { return }
        let ticket = UUID(); importID = ticket
        setImporting(true)
        importTask = Task { @MainActor in
            let file: PickedMovieFile?
            do { file = try await item.loadTransferable(type: PickedMovieFile.self) }
            catch {
                if importID == ticket { setImporting(false); importID = nil; chats.error = error.localizedDescription }
                return
            }
            let wanted = !Task.isCancelled && importID == ticket
                && owner.matches(threadID: chats.selectedID, modelID: chats.currentModel.id)
            if importID == ticket { isImporting = false; importID = nil }
            guard let file else { return }
            guard wanted else { try? FileManager.default.removeItem(at: file.url); return }
            importAttachments([file.url], temporary: true)
        }
    }
    private func openActions() {
        inputFocused = false
        if showPhotos { closePhotoDock() }
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen) { showActions = true }
    }
    private func closeActions() {
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuClose) { showActions = false }
    }
    /// The field's text and attachments, or a try question's text (the
    /// field is empty and nothing is attached while the chips are there):
    /// one path either way, so a tried question is sent, answered and kept
    /// as any other.
    private func send(_ sample: TryQuestion? = nil) {
        // Sent while recording (Return): the recording goes with it.
        finishRecording()
        let committed = sample?.prompt ?? composerInput.committedText(fallback: draft)
        let id = UUID()
        arrivingMessageID = id
        guard chats.send(committed, messageID: id, attachments: attachments) else { arrivingMessageID = nil; return }
        // Before the keyboard is put away: 送信直後の画面の記録.
        SendScreenLog.shared.begin(field: composerInput.textView,
                                   keyboard: composerInput.textView?.textInputMode?.primaryLanguage)
        inputFocused = false
        composerInput.clearAndDismiss()
        draft = ""; attachments = []
        pickedAttachments = [:]; photoSelection = []
        if showPhotos { closePhotoDock() }
        scrollPolicy.requestLatest(); latestRequest += 1
        arrivalCleanup?.cancel()
        arrivalCleanup = Task {
            do { try await Task.sleep(for: .milliseconds(650)) } catch { return }
            if arrivingMessageID == id { arrivingMessageID = nil }
        }
    }
    /// A hardware keyboard's Return (Magic Keyboard, fielua-reports #3):
    /// what the send button does, when it would send. Nothing while a reply
    /// is written, so Return never stops one, nor with nothing to send.
    private var returnKeySends: (() -> Void)? {
        #if POCKET_PREVIEW
        // For the UI check's comparison: Return as in 1.1.0 (221), a new line.
        if PreviewProbe.on("--keyboard-as-221") { return nil }
        #endif
        return {
            guard canSend, !chats.isGenerating, !chats.isStopping else {
                SendScreenLog.shared.mark("Return: 送らない（" + (canSend ? "返答中" : "送るものがない") + "）")
                return
            }
            send()
        }
    }
    /// 起動時のチャット (LaunchChatMode), once a launch, the first time Fielua
    /// is on the screen; a return from the background changes nothing.
    /// 前回の会話: the chat ChatStore opened, the one last open, with the text
    /// left in its field. 新しいチャット: the new chat ChatStore opened (the
    /// empty one there is, else a new one) gets the keyboard, and 「前回の会話
    /// に戻る」 over the field while there is a chat to go back to. Neither
    /// over the setup, in a chat a tapped notification chose or while a
    /// reply is being written; no keyboard while the chat's model is not
    /// saved yet.
    private func openAtLaunch(_ phase: ScenePhase) {
        guard phase == .active, !LaunchChat.handled else { return }
        LaunchChat.handled = true
        LaunchDrafts.prune(keeping: Set(chats.threads.map(\.id)))
        guard !StartupPresenter.coversLaunch, !chats.openedFromNotification else { return }
        // 新しいチャット: its chat is open from the first frame (LaunchChat.choose).
        guard let chat = LaunchChat.opened, chats.selectedID == chat, !chats.isGenerating else {
            showKeptDraft(); return
        }
        let before = LaunchChat.before
        if chat == before { showKeptDraft() }
        if draft.isEmpty, let back = LaunchChatPlan.returnTarget(chats.threads, before: before, newChat: chat) {
            // Its room is there from the start, so only the keyboard moves
            // the field; the capsule shows once the keyboard is on its way.
            launchReturn = LaunchReturn(chat: chat, back: back)
            launchReturnRoom = true
        }
        Task { @MainActor in
            // After the change of chat has put the last one's keyboard away.
            do { try await Task.sleep(for: .milliseconds(150)) } catch { return }
            guard chats.selectedID == chat else { return }
            if chatReady, !historyVisible { inputFocused = true }
            do { try await Task.sleep(for: .milliseconds(220)) } catch { return }
            guard launchReturn?.chat == chat, chats.selectedID == chat else { return }
            withAnimation(reduceMotion ? ChatMotion.reduced : ChatMotion.drawer) {
                launchReturnShown = true
            }
        }
    }

    /// The text kept for the chat shown, when its field is empty.
    private func showKeptDraft() {
        guard draft.isEmpty, let chat = chats.selectedID, let kept = LaunchChat.takeDraft(for: chat) else { return }
        draft = kept
    }

    /// Leaving the screen: the field's text, for the chat it is in, so the
    /// next launch has it (LaunchDrafts). A kept text still waiting for its
    /// chat to be shown stays as it is.
    private func keepDraft() {
        guard let chat = chats.selectedID, !(draft.isEmpty && LaunchChat.kept[chat] != nil) else { return }
        LaunchDrafts.set(draft, for: chat)
    }

    /// 体験型おすすめ質問 (fielua-reports Issue #1, 1.1.0 (219)): over the
    /// field of an empty chat, a small 「試してみる」 and three small neutral
    /// glass chips (no yellow: the flower is the empty chat's one colour),
    /// the empty chat's only words besides its model's name. A chip sends
    /// its question at once (send), and the chat's model answers it on the
    /// phone. They go as the flower does while something is typed and come
    /// back with it once the field is empty; sent, they fade with the
    /// flower as the chat begins.
    private var tryQuestions: some View {
        let shown = tryShown
        return VStack(alignment: .leading, spacing: 6) {
            Text("試してみる")
                .font(.caption.weight(.medium)).foregroundStyle(.secondary)
                .padding(.leading, 6)
                .opacity(shown ? 1 : 0)
                .accessibilityAddTraits(.isHeader)
            // Their own glass, apart from the composer's: shapes nearer
            // than 4pt would fuse, and the chips stand 8pt apart.
            ChatGlassGroup(spacing: 4) {
                HStack(spacing: ChatMetrics.chipGap) {
                    ForEach(TryQuestion.allCases) { question in tryChip(question, shown: shown) }
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .scaleEffect(shown || reduceMotion ? 1 : TryChips.scale, anchor: .bottom)
        .offset(y: shown || reduceMotion ? 0 : 6)
        .allowsHitTesting(shown)
        .accessibilityElement(children: .contain)
        .accessibilityHidden(!shown)
        .accessibilityIdentifier("chat-try-questions")
        // Put away, they give back their row and the stack's gap too.
        .frame(height: shown ? nil : 0, alignment: .bottom)
        .padding(.bottom, shown ? 0 : -6)
        .padding(.horizontal, ChatMetrics.gutter)
        .composerPart()
    }

    private func tryChip(_ question: TryQuestion, shown: Bool) -> some View {
        Button { sendTry(question) } label: {
            Text(question.label)
                .font(.footnote.weight(.medium))
                .foregroundStyle(.primary)
                .lineLimit(1).minimumScaleFactor(0.8)
                .padding(.horizontal, 12)
                .frame(maxWidth: .infinity, minHeight: ChatMetrics.chip)
                // The glass ignores an opacity around it; the words fade
                // inside it and the glass itself turns off.
                .opacity(shown ? 1 : 0)
                .contentShape(Capsule())
                .chatGlass(in: Capsule(), interactive: true, visible: shown)
        }
        .buttonStyle(.plain)
        .disabled(chats.isGenerating)
        .accessibilityLabel(question.label)
        .accessibilityHint("例の質問を送信します。")
        .accessibilityIdentifier("chat-try-\(question.rawValue)")
        .composerPart()
    }

    private func sendTry(_ question: TryQuestion) {
        guard tryShown, tryWanted else { return }
        // Kept until it has faded: the chat has a message from now on.
        tryLeaving = true
        send(question)
    }

    /// As the chat first shows: after 起動時のチャット's keyboard and
    /// capsule have had their moment (150 + 220 ms), so the chips never
    /// flash before the capsule that comes first.
    private func revealTryQuestions() {
        guard tryWanted else { return }
        Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            if tryWanted && !tryShown { setTryShown(true, animated: true) }
        }
    }

    private func setTryShown(_ shown: Bool, animated: Bool) {
        guard shown != tryShown else { return }
        guard animated else { tryShown = shown; tryLeaving = false; return }
        withAnimation(TryChips.animation(shown: shown, still: reduceMotion)) { tryShown = shown } completion: {
            if !tryShown { tryLeaving = false }
        }
    }

    /// 「前回の会話に戻る」: a small glass capsule centred over the field. It
    /// rises in once the keyboard is coming, and goes once something is
    /// typed or attached, or another chat opens.
    private func launchReturnCapsule(_ back: UUID) -> some View {
        let shown = launchReturnShown && !showActions
        return Button {
            guard !chats.isGenerating else { return }
            guard chats.threads.contains(where: { $0.id == back }) else { return endLaunchReturn(animated: true) }
            chats.select(back)
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "arrow.uturn.backward")
                Text("前回の会話に戻る")
            }
            .font(.footnote.weight(.semibold))
            .foregroundStyle(.primary)
            .padding(.horizontal, 16)
            .frame(minHeight: ChatMetrics.chip)
            .contentShape(Capsule())
            .chatGlass(in: Capsule(), interactive: true)
        }
        .buttonStyle(.plain)
        .disabled(chats.isGenerating)
        .accessibilityLabel("前回の会話に戻る")
        .accessibilityHint("Fieluaを開く前に表示していた会話に戻ります。")
        .accessibilityIdentifier("chat-launch-return")
        .accessibilityHidden(!shown)
        .allowsHitTesting(shown)
        .opacity(shown ? 1 : 0)
        .scaleEffect(shown || reduceMotion ? 1 : 0.92, anchor: .bottom)
        .offset(y: shown || reduceMotion ? 0 : 8)
        .frame(maxWidth: .infinity)
        // Folded away, it gives back its row and the stack's gap too.
        .frame(height: launchReturnRoom ? nil : 0, alignment: .bottom)
        .padding(.bottom, launchReturnRoom ? 0 : -6)
    }

    private func endLaunchReturn(animated: Bool) {
        guard launchReturn != nil else { return }
        guard animated else {
            launchReturn = nil; launchReturnShown = false; launchReturnRoom = false
            return
        }
        withAnimation(ChatMotion.leave) { launchReturnShown = false }
        withAnimation(reduceMotion ? ChatMotion.reduced : ChatMotion.resize) {
            launchReturnRoom = false
        } completion: {
            if !launchReturnRoom { launchReturn = nil }
        }
    }

    private func clearTransientState() {
        recorder.cancel()
        showPhotos = false; showActions = false
        photoSelection = []; pickedAttachments = [:]
        pickerChain?.cancel(); pickerChain = nil
        photoPickerTicket = UUID()
        pickerContext = nil
        arrivalCleanup?.cancel(); arrivingMessageID = nil
        scrollTask?.cancel(); scrollTask = nil
        importTask?.cancel(); importID = nil; isImporting = false; importingFile = nil
        for attachment in attachments { AttachmentStorage.remove(attachment) }
        attachments = []
    }
    private func importAttachments(_ urls: [URL], temporary: Bool) {
        func discardStaged() { if temporary { for url in urls { try? FileManager.default.removeItem(at: url) } } }
        guard !urls.isEmpty else { return }
        guard attachmentPolicy.allowsAnyAttachment else { discardStaged(); showAttachmentGuide = true; return }
        guard !isImporting, !chats.isGenerating else { discardStaged(); return }
        guard attachments.count + urls.count <= 3 else { discardStaged(); chats.error = String(localized: "添付は1回の送信で3つまでです。"); return }
        let ticket = UUID(); importID = ticket
        let selectedThread = chats.selectedID, selectedModel = chats.attachmentModel
        let forClaude = chats.currentClaude != nil
        setImporting(true, file: Self.documentName(urls[0]))
        importTask = Task { @MainActor in
            defer {
                discardStaged()
                if importID == ticket { setImporting(false); importID = nil }
            }
            for url in urls {
                guard !Task.isCancelled else { return }
                if importID == ticket { setImporting(true, file: Self.documentName(url)) }
                do {
                    let attachment = try await Task.detached(priority: .userInitiated) {
                        try await AttachmentStorage.importFile(url, model: selectedModel, forClaude: forClaude)
                    }.value
                    guard !Task.isCancelled, importID == ticket, chats.selectedID == selectedThread,
                          chats.attachmentModel.id == selectedModel.id else { AttachmentStorage.remove(attachment); return }
                    // A Claude chat takes a scanned PDF too: Claude reads it itself (1.1.0 (260)).
                    guard attachmentPolicy.allows(attachment)
                            || (forClaude && attachment.kind == .file && ClaudeAttachmentEncoder.isPDF(attachment)) else {
                        AttachmentStorage.remove(attachment); showAttachmentGuide = true; continue
                    }
                    guard attachment.kind != .video || !attachments.contains(where: { $0.kind == .video }) else {
                        AttachmentStorage.remove(attachment); chats.error = String(localized: "動画は1回の送信で1本までです。"); continue
                    }
                    guard modelImages(attachments + [attachment]) <= 4 else {
                        AttachmentStorage.remove(attachment); chats.error = String(localized: "画像は合計4場面まで添付できます。"); continue
                    }
                    addDraft(attachment)
                } catch { if !Task.isCancelled, importID == ticket, chats.selectedID == selectedThread { chats.error = error.localizedDescription } }
            }
        }
    }
}

struct MessageView: View, Equatable {
    let message: ChatMessage
    let oppositeInset: CGFloat
    var hasTail = true
    var animateArrival = false
    /// It answers a message that asked for a chart: chart data the model
    /// fenced as JSON is drawn as a chart too.
    var answersChartRequest = false
    /// The Aurora Orb's place in a reply: breathing while the model thinks,
    /// leaving from the first token, and gone before the text may show.
    @State private var orb: OrbPhase
    /// How much of the reply is laid out: about a second behind the model,
    /// at the model's own pace smoothed (ReplyPacer), so a burst of tokens
    /// still reads as writing. Off with Reduce Motion, VoiceOver and the
    /// instant-text probe.
    @State private var pacer: ReplyPacer
    @State private var shown: Int
    @State private var catchingUp = false
    /// What stands under a reply once it is written (the pages it read,
    /// Claude's files, Smart Memory's sources, 停止しました): shown from the
    /// start in a reply that had ended when its row was made, and brought in
    /// at the panel's pace (`showExtras`) in one written here. Until 1.1.0
    /// (262) they all cut in on the frame the last character came, up to
    /// 200pt at once, and 停止しました stood under a reply that went on being
    /// written for another two seconds (UI review, 2026-11-11).
    @State private var extrasShown: Bool
    /// The pace for this reply's text views, by reference (ReplyCadenceBox).
    @State private var cadence = ReplyCadenceBox()
    @State private var voiceOver = UIAccessibility.isVoiceOverRunning
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var outgoing: Bool { message.role == .user }

    enum OrbPhase: Equatable { case waiting, leaving(Date), gone }

    init(message: ChatMessage, oppositeInset: CGFloat, hasTail: Bool = true,
         animateArrival: Bool = false, answersChartRequest: Bool = false) {
        self.message = message
        self.oppositeInset = oppositeInset
        self.hasTail = hasTail
        self.animateArrival = animateArrival
        self.answersChartRequest = answersChartRequest
        let thinking = message.role != .user && message.state == .generating && message.text.isEmpty
        _orb = State(initialValue: thinking ? .waiting : .gone)
        // A reply already under way when its row is made shows what it has.
        let text = Self.readText(message, charts: answersChartRequest)
        let laidOut = thinking ? 0 : text.count
        _pacer = State(initialValue: ReplyPacer(text: text, generating: message.state == .generating,
                                                held: thinking, shown: laidOut))
        _shown = State(initialValue: laidOut)
        _extrasShown = State(initialValue: message.state != .generating)
    }

    /// What the row shows depends on these alone; the orb's phase is the
    /// row's own state.
    static func == (lhs: MessageView, rhs: MessageView) -> Bool {
        lhs.message == rhs.message && lhs.oppositeInset == rhs.oppositeInset && lhs.hasTail == rhs.hasTail
            && lhs.animateArrival == rhs.animateArrival
            && lhs.answersChartRequest == rhs.answersChartRequest
    }
    #if POCKET_PREVIEW
    private static let plainReplies = PreviewProbe.on("--probe-plain-replies")
    private static let instantText = PreviewProbe.on("--probe-instant-text")
    #else
    private static let plainReplies = false
    private static let instantText = false
    #endif

    var body: some View {
        let _ = SettingsSlideMeter.drew("吹き出し")
        let text = Self.readText(message, charts: answersChartRequest)
        let displayed = laidOut(of: text)
        let awaiting = awaiting(displayed, of: text)
        let inBubble = outgoing ? message.media.filter { !SentPhoto.shows($0) } : message.media
        let _ = cadence.set(ReplyCadence(pace: pacer.pace, step: ReplyPacer.interval(forLength: shown)))
        HStack(alignment: .bottom, spacing: 0) {
            if outgoing { Spacer(minLength: oppositeInset) }
            VStack(alignment: outgoing ? .trailing : .leading, spacing: 4) {
                // A reply that searched says what it sent before its text.
                if !outgoing, let search = message.webSearch, !search.isEmpty {
                    WebSearchHeader(record: search, generating: message.state == .generating)
                        .padding(.horizontal, ChatMetrics.replyInset)
                        .transition(.opacity)
                }
                // Sent photos and videos stand on their own above the
                // bubble, their edge in line with its side, 6pt in from the
                // tail's tip (MessageBubble; SentPhoto, 2026-10-25).
                if outgoing, !photos.isEmpty {
                    VStack(alignment: .trailing, spacing: 4) {
                        ForEach(photos) { attachment in AttachmentCard(attachment: attachment) }
                    }
                    .padding(.trailing, 6)
                    .modifier(OutgoingArrival(animate: animateArrival))
                }
                // Sent alone, they have no bubble (ChatMessage.hidesText).
                if !outgoing || !displayed.isEmpty || !inBubble.isEmpty {
                Group {
                    if awaiting {
                        // One hidden line of reply text holds the place of
                        // the reply's first line while the orb shows, so
                        // nothing moves when the text takes over.
                        Text(verbatim: "あ").hidden().accessibilityHidden(true)
                            .font(ChatMetrics.replyFont)
                            .padding(.vertical, ChatMetrics.bubbleVertical)
                            .padding(.horizontal, ChatMetrics.replyInset)
                    } else {
                        VStack(alignment: .leading, spacing: 4) {
                            ForEach(inBubble) { attachment in
                                AttachmentCard(attachment: attachment)
                            }
                            Group {
                            if !outgoing && !displayed.isEmpty && !Self.plainReplies {
                                // The same laid-out text is not chunked
                                // and parsed again for each piece the model
                                // writes behind it.
                                MarkdownReplyView(text: displayed, isStreaming: message.state == .generating || catchingUp,
                                                  original: message.text)
                                    .equatable()
                                    // The pace the text is laid out at, so
                                    // its characters appear to that rhythm
                                    // whatever the steps bring.
                                    .environment(\.replyCadence, cadence)
                            } else if !outgoing || !displayed.isEmpty {
                                // Empty here only when the reply ended with
                                // no text at all (awaiting holds the place
                                // while its text is still to be laid out).
                                Text(displayed.isEmpty ? (message.state == .failed ? String(localized: "返信できませんでした") : String(localized: "停止しました")) : displayed)
                                    #if POCKET_PREVIEW
                                    .modifier(ReplyPlaceholderTrace(shows: !outgoing && displayed.isEmpty,
                                                                    state: message.state, characters: text.count))
                                    #endif
                            }
                            }
                        }
                            .font(outgoing ? ChatMetrics.messageFont : ChatMetrics.replyFont).lineSpacing(1)
                            #if POCKET_PREVIEW
                            .modifier(ProbeTextSelection())
                            #else
                            .textSelection(.enabled)
                            #endif
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.vertical, ChatMetrics.bubbleVertical)
                            .padding(.leading, outgoing ? ChatMetrics.bubbleInset : ChatMetrics.replyInset)
                            .padding(.trailing, outgoing ? ChatMetrics.bubbleTailInset : ChatMetrics.replyInset)
                    }
                }
                .foregroundStyle(outgoing ? Theme.onOutgoing : Theme.ink)
                // A reply has no bubble and runs the width of the
                // conversation, as in ChatGPT; only sent messages are bubbles.
                .frame(maxWidth: outgoing ? nil : .infinity, alignment: .leading)
                .overlay(alignment: .topLeading) {
                    // Also while it leaves a reply that has just ended.
                    if !outgoing && orb != .gone {
                        ReplyOrb(leavingSince: leavingSince)
                    }
                }
                .background {
                    if outgoing { MessageBubble(outgoing: true, hasTail: hasTail).fill(Theme.outgoing) }
                }
                // Without a bubble, the blank beside a short line still
                // opens the reply's copy menu.
                .contentShape(.interaction, Rectangle())
                .modifier(OutgoingArrival(animate: outgoing && animateArrival))
                .contextMenu {
                    if !message.shownText.isEmpty {
                        Button("コピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.text }
                    }
                    // What Smart Mode answered with, and what it could not
                    // give (1.1.0 (249)).
                    if !outgoing, let smart = message.smart {
                        Section(smart.genreLine) {
                            Button {} label: {
                                Text(smart.summary)
                                Image(systemName: "sparkles")
                            }
                            .disabled(true)
                            ForEach(smart.notices, id: \.self) { notice in
                                Button {} label: {
                                    Text(notice.text)
                                    Image(systemName: "exclamationmark.triangle")
                                }
                                .disabled(true)
                            }
                        }
                    }
                }
                }
                // The pages it read, once the reply is written.
                if !outgoing, extrasShown, message.state != .generating,
                   let sources = message.webSearch?.sources, !sources.isEmpty {
                    WebSearchSources(sources: sources)
                        .padding(.horizontal, ChatMetrics.replyInset - 4)
                        .padding(.top, 4)
                        .transition(.opacity)
                }
                // The files a Claude reply made, and how it ended (1.1.0 (260)).
                if !outgoing, extrasShown, message.state != .generating, message.claudeFiles != nil || message.claudeEnd != nil {
                    ClaudeReplyExtras(files: message.claudeFiles ?? [], end: message.claudeEnd)
                        .padding(.horizontal, ChatMetrics.replyInset)
                        .padding(.top, 4)
                        .transition(.opacity)
                }
                // The earlier conversations Smart Memory gave it (1.1.0 (251)).
                if !outgoing, extrasShown, message.state != .generating, let recall = message.memory {
                    MemorySourcesView(recall: recall)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, ChatMetrics.replyInset)
                        .transition(.opacity)
                }
                // Under the text written before it ended; a reply with none
                // says it in its own place above.
                if extrasShown, (message.state == .stopped || message.state == .failed) && !displayed.isEmpty {
                    Text(message.state == .stopped ? "停止しました" : "ここで途切れました")
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                        .padding(.horizontal, outgoing ? 9 : ChatMetrics.replyInset)
                        .transition(.opacity)
                }
            }
            // The swipe that shows the times moves this and nothing else
            // of the row (ChatTimestampSwipe).
            .modifier(ChatTimestampSlide())
        }
        .overlay(alignment: .trailing) { ChatTimestampLabel(date: message.createdAt) }
        .accessibilityElement(children: message.media.isEmpty && !hasControls ? .combine : .contain)
        // The first token sends the orb away; stopping or failing removes
        // it at once. A short reply can be written before the orb has gone
        // (on the phone, 0.1 s after its first text, 2026-10-25): the orb
        // goes on leaving, and the text follows at the pace once it has.
        .onChange(of: message.text) { _, text in
            pacer.text = Self.readText(message, charts: answersChartRequest)
            if !text.isEmpty { orbLeaves() }
        }
        .onChange(of: message.state) { _, state in
            pacer.text = Self.readText(message, charts: answersChartRequest)
            pacer.generating = state == .generating
            if state != .generating {
                if state == .complete && !pacer.text.isEmpty { orbLeaves() } else { setOrb(.gone) }
                // Whatever came with the end is laid out at the pace too.
                catchingUp = paced && !pacer.caughtUp
                if !catchingUp { showExtras() }
            } else if extrasShown {
                // Written on again (a reply resumed): what stood under it
                // waits for the new end.
                extrasShown = false
            }
        }
        // VoiceOver turned on while the reply is written: the rest is not
        // paced, so nothing is read from text still to come (the flag was
        // read once, when the row was made, until 1.1.0 (262)).
        .onReceive(NotificationCenter.default.publisher(for: UIAccessibility.voiceOverStatusDidChangeNotification)) { _ in
            let running = UIAccessibility.isVoiceOverRunning
            if voiceOver != running { voiceOver = running }
        }
        // Lay the reply out at a pace while it is written, and catch up
        // once it has ended.
        .task(id: message.state) {
            guard paced, message.state == .generating || catchingUp else { return }
            while !Task.isCancelled {
                if let count = pacer.advance(at: Date().timeIntervalSinceReferenceDate) {
                    shown = count
                    NotificationCenter.default.post(name: ReplyPacer.revealed, object: nil)
                }
                let behind = !pacer.caughtUp
                if catchingUp != behind { catchingUp = behind }
                if !behind && !pacer.generating {
                    if message.state != .generating { showExtras() }
                    break
                }
                // About 24 steps a second, fewer as the reply grows long:
                // each step has the reply's last chunk parsed and laid out
                // again, and its characters start one after another on a
                // schedule at the pace (RevealingRichText), whatever the
                // step's size.
                try? await Task.sleep(for: .seconds(ReplyPacer.interval(forLength: pacer.shown)))
            }
        }
    }

    /// The reply is written: what stands under it comes in at the panel's
    /// pace, and the conversation follows it down at the same time.
    private func showExtras() {
        guard !extrasShown else { return }
        let reduced = systemReduceMotion || previewReduceMotion
        withAnimation(reduced ? ChatMotion.reducedMenu : ChatMotion.resize) { extrasShown = true }
        NotificationCenter.default.post(name: ChatMotion.replySettled, object: nil)
    }

    /// Whether this reply's text is laid out at a pace rather than as it
    /// comes.
    private var paced: Bool {
        !outgoing && !Self.instantText && !systemReduceMotion && !previewReduceMotion && !voiceOver
    }

    /// The reply's text (`text`, readText's) as laid out so far. Held while
    /// the orb is there: a reply that ends with its first text arrives in
    /// one change, before the row knows it is catching up.
    private func laidOut(of text: String) -> String {
        guard paced, message.state == .generating || catchingUp || orb != .gone else { return text }
        return String(text.prefix(shown))
    }

    /// The text the reply is laid out from and paced through: the model's,
    /// with its charts read as it meant them (a chart block wrapped in
    /// another fence, and in an answer to a chart request JSON chart data).
    private static func readText(_ message: ChatMessage, charts: Bool) -> String {
        guard message.role != .user else { return message.shownText }
        return MarkdownSource.readingCharts(message.text, generating: message.state == .generating, requested: charts)
    }

    /// A reply that has nothing to show yet: the Aurora Orb holds its place
    /// until it has gone, and the place stays blank until the first text
    /// that draws, while the reply is written or its text (`text`) is still
    /// being laid out. Only a reply that ended with no text says so in its
    /// place: one that ended a moment after its first text had said
    /// 停止しました until that text showed (2026-10-25).
    private func awaiting(_ displayed: String, of text: String) -> Bool {
        guard !outgoing else { return false }
        if orb != .gone { return true }
        let laying = message.state == .generating || displayed.utf8.count < text.utf8.count
        return laying && !ReplyVisibility.drawsText(displayed, markdown: !Self.plainReplies)
    }

    private var leavingSince: Date? {
        if case .leaving(let since) = orb { return since }
        return nil
    }

    private func setOrb(_ phase: OrbPhase) {
        orb = phase
        pacer.held = phase != .gone
    }

    /// The first token has come: the orb shrinks away (or fades, where it
    /// cannot shrink), and the text waits until it has gone.
    private func orbLeaves() {
        guard orb == .waiting else { return }
        let since = Date()
        setOrb(.leaving(since))
        let wait = AuroraOrbView.exitDuration(reduceMotion: systemReduceMotion || previewReduceMotion)
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(wait))
            if orb == .leaving(since) { setOrb(.gone) }
        }
    }

    /// A sent message's photos and videos, drawn outside its bubble.
    private var photos: [ChatAttachment] { message.media.filter(SentPhoto.shows) }

    /// A reply with code, images or links (its search's pages too) has
    /// buttons of its own, which a combined accessibility element would hide.
    /// A reply with controls inside keeps them as elements of their own
    /// (VoiceOver reaches each): code, links, tables, the pages it read, and
    /// the earlier conversations Smart Memory gave it (1.1.0 (251)).
    private var hasControls: Bool {
        !outgoing && (["```", "~~~", "![", "](", "http", "|"].contains { message.text.contains($0) }
                      || message.webSearch?.sources.isEmpty == false
                      || message.memory?.sources.isEmpty == false
                      || message.claudeFiles?.isEmpty == false)
    }
}

struct MessageBubble: Shape {
    var outgoing: Bool
    var hasTail = true

    func path(in rect: CGRect) -> Path {
        // Cubic quarter-circles stay round even for a reply taller than the
        // viewport. The short curved tail is part of this same outline.
        var path = Path()
        let left = rect.minX, top = rect.minY, bottom = rect.maxY
        let right = rect.maxX - 6
        let radius = max(0, min(18, min((rect.width - 6) / 2, rect.height / 2)))
        let curve = radius * 0.5522847498
        path.move(to: CGPoint(x: left + radius, y: top))
        path.addLine(to: CGPoint(x: right - radius, y: top))
        path.addCurve(to: CGPoint(x: right, y: top + radius),
                      control1: CGPoint(x: right - radius + curve, y: top),
                      control2: CGPoint(x: right, y: top + radius - curve))
        path.addLine(to: CGPoint(x: right, y: bottom - radius))
        if hasTail {
            path.addCurve(to: CGPoint(x: rect.maxX, y: bottom),
                          control1: CGPoint(x: right, y: bottom - 7),
                          control2: CGPoint(x: right + 1, y: bottom - 3))
            path.addCurve(to: CGPoint(x: right - 8, y: bottom - 4),
                          control1: CGPoint(x: right + 1, y: bottom),
                          control2: CGPoint(x: right - 4, y: bottom - 1))
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right - 11, y: bottom - 1),
                          control2: CGPoint(x: right - 14, y: bottom))
        } else {
            path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                          control1: CGPoint(x: right, y: bottom - radius + curve),
                          control2: CGPoint(x: right - radius + curve, y: bottom))
        }
        path.addLine(to: CGPoint(x: left + radius, y: bottom))
        path.addCurve(to: CGPoint(x: left, y: bottom - radius),
                      control1: CGPoint(x: left + radius - curve, y: bottom),
                      control2: CGPoint(x: left, y: bottom - radius + curve))
        path.addLine(to: CGPoint(x: left, y: top + radius))
        path.addCurve(to: CGPoint(x: left + radius, y: top),
                      control1: CGPoint(x: left, y: top + radius - curve),
                      control2: CGPoint(x: left + radius - curve, y: top))
        path.closeSubpath()
        if !outgoing {
            return path.applying(CGAffineTransform(a: -1, b: 0, c: 0, d: 1, tx: rect.minX + rect.maxX, ty: 0))
        }
        return path
    }
}

/// Where the photo picker sits on screen, observed only by the done
/// check's slot.
@Observable final class PhotoPickerFrame {
    var top: CGFloat = 0
}

/// The photo sheet's done check, centered on the picker's segmented row
/// below the full-height sheet's visible top.
private struct PhotoDoneSlot<Check: View>: View {
    let frame: PhotoPickerFrame
    let safeTop: CGFloat
    let visible: Bool
    let reduceMotion: Bool
    @ViewBuilder let check: Check

    var body: some View {
        ZStack {
            if visible {
                check.transition(reduceMotion ? AnyTransition.opacity : AnyTransition.scale(scale: 0.5).combined(with: .opacity))
            }
        }
        .padding(.top, max(0, safeTop - frame.top) + ChatMetrics.photoDoneRowCenter - ChatMetrics.photoDone / 2)
        .padding(.trailing, 16)
        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.menuOpen, value: visible)
    }
}

/// Lays its content out in a width of whole points. A menu's label is laid
/// out again in the frame the row gave the menu, and the pill's
/// ViewThatFits chooses again there. Snapped to the screen's pixels, that
/// frame came out a little narrower than 深く's name, so the pill showed
/// its symbol alone in 深く's room, 44pt from either neighbour (the largest
/// text on a 402pt phone, run 39697821838). A width of whole points stays
/// as it is when snapped, so both choices agree.
private struct WholePointWidth: Layout {
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        guard let subview = subviews.first else { return .zero }
        let size = subview.sizeThatFits(proposal)
        return CGSize(width: size.width.rounded(.up), height: size.height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        subviews.first?.place(at: CGPoint(x: bounds.midX, y: bounds.midY), anchor: .center,
                              proposal: ProposedViewSize(width: bounds.width, height: bounds.height))
    }
}

/// 新しいチャット's launch: its chat and the chat 「前回の会話に戻る」 opens.
/// A value read and written on every frame without redrawing the view.
private final class LatestValue {
    var value: CGFloat = 0
}

private struct LaunchReturn: Equatable {
    let chat: UUID
    let back: UUID
}

/// The try chips' motion: the flower's (FlowerAway), so the two go and come
/// back together while the person types; a short fade with Reduce Motion.
private enum TryChips {
    static let scale: CGFloat = 0.94
    static func animation(shown: Bool, still: Bool) -> Animation {
        FlowerAway.animation(away: !shown, still: still)
    }
}

/// The composer's parts each stand behind AnyView (1.1.0 (239)). On the
/// phone the main thread has 1 MB of stack, and 238 crashed as the chat
/// first opened: Swift built the types of the whole composer, dozens of
/// views and modifiers nested inside one another, from within the
/// composer's own getters, and ran out of stack in ChatView.composerField
/// (TestFlight crash log, 2026-10-29 12:43 JST). The simulator's main
/// thread has 8 MB, so the UI checks never saw it. Behind AnyView each
/// part's types are built on their own, a few levels deep;
/// scripts/check-launch-stack.sh measures the stack. Each part is always
/// the same view inside, so SwiftUI keeps its identity, state and
/// animations as before.
private extension View {
    func composerPart() -> AnyView { AnyView(self) }
}

/// The header's history button. It reads where the history stands itself,
/// so that showing or putting away the iPad's history draws this button
/// again and not the whole conversation (1.1.0 (242)).
private struct HistoryToggleButton: View {
    /// On the phone the drawer takes the screen: the field lets the
    /// keyboard go first.
    let onDrawer: () -> Void
    @Environment(\.historySidebar) private var historySidebar
    /// The iPad's history beside the conversation: shown, put away, or nil
    /// with the phone's drawer.
    @Environment(\.historyBeside) private var historyBeside

    var body: some View {
        ChatCircleButton(action: {
            // Beside the conversation the history leaves the
            // field and its keyboard as they are.
            if historyBeside == nil { onDrawer() }
            historySidebar?.toggle()
        }) {
            SidebarGlyph()
        }
        .accessibilityLabel(historyBeside == true ? Text("会話一覧を閉じる") : Text("会話一覧を開く"))
        .accessibilityIdentifier("chat-history")
        // iPadOS's own keys for a sidebar, ⌃⌘S, with a keyboard.
        .keyboardShortcut(historyBeside != nil ? KeyboardShortcut("s", modifiers: [.command, .control]) : nil)
    }
}
