import SwiftUI
import PocketCore

/// A rich block in a reply (`MarkdownBlock.rich`): the view its kind names
/// once its data holds up, a placeholder while it is still arriving, and
/// otherwise its source as code under a line saying why it is not drawn, so
/// nothing the model wrote is lost. Each kind brings its own view, menu and
/// copying; a new kind adds a case here and leaves the rest of the reply's
/// drawing as it is.
struct RichBlockView: View, Equatable {
    let block: RichBlock
    /// In the chunk the model is writing: a block that becomes ready here
    /// appears with its own motion; one in a reply opened later does not.
    let streaming: Bool

    /// The same block draws the same, whether its reply is still streaming
    /// or not, so the end of a reply does not draw it again.
    static func == (lhs: Self, rhs: Self) -> Bool { lhs.block == rhs.block }

    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion

    var body: some View {
        // The chart takes its placeholder's place over it, and whatever
        // height still differs is taken at the panel's pace (1.1.0 (263)):
        // the card cut from one to the other, 26 to 150pt taller.
        ZStack(alignment: .topLeading) {
            switch block.state {
            case .ready(.chart(let chart)):
                ChartBlockView(chart: chart, appears: streaming).transition(.opacity)
            case .pending:
                RichPendingView(source: block.source).transition(.opacity)
            case .failed(let error):
                RichFallbackView(source: block.source, reason: error.message).transition(.opacity)
            }
        }
        .animation(systemReduceMotion || previewReduceMotion ? nil : ChatMotion.resize, value: phase)
    }

    private var phase: Int {
        switch block.state {
        case .ready: 0
        case .pending: 1
        case .failed: 2
        }
    }
}

/// The card a rich block sits on, as a code block does: the reply's width,
/// rounded corners and a hairline edge.
struct RichCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) { content }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.codeBackground)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(Theme.markdownLine.opacity(0.5), lineWidth: 0.5)
            }
    }
}

/// A chart still arriving: a card about a chart's size with what the block
/// already says it is, so the reply never shows half its data and the chart
/// takes the card's place once its data is complete.
private struct RichPendingView: View {
    let source: String
    @ScaledMetric(relativeTo: .body) private var plotHeight = ChartMetrics.plotHeight
    @ScaledMetric(relativeTo: .body) private var pieHeight = ChartMetrics.pieHeight
    @ScaledMetric(relativeTo: .body) private var rowHeight = ChartMetrics.rowHeight
    @ScaledMetric(relativeTo: .body) private var axisHeight = ChartMetrics.axisHeight
    @ScaledMetric(relativeTo: .body) private var legendHeight = ChartMetrics.legendHeight
    @ScaledMetric(relativeTo: .footnote) private var legendRow: CGFloat = 18

    var body: some View {
        let peek = ChartSpec.peek(source)
        let shape = ChartPendingShape(source)
        RichCard {
            ChartTitle(kind: peek.kind, title: peek.title ?? "", unit: shape.unit)
            // The line the chart reads its values out on, kept from the start.
            Text(verbatim: " ").font(.footnote.monospacedDigit()).lineLimit(1).accessibilityHidden(true)
            HStack(spacing: 8) {
                ProgressView().controlSize(.small)
                Text("グラフを準備しています")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, minHeight: height(shape, kind: peek.kind))
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text("グラフを準備しています"))
        .accessibilityIdentifier("chart-pending")
    }

    /// The room the chart's plot (and a pie's list) will take, as far as
    /// what has come of the block tells: ChartBlockView's own sums. It grows
    /// with the items of a pie or of bars on their side as they arrive, so
    /// the chart finds its place ready (200pt whatever the chart, until
    /// 1.1.0 (262)).
    private func height(_ shape: ChartPendingShape, kind: ChartSpec.Kind?) -> CGFloat {
        let legend = shape.series > 1 ? legendHeight : 0
        switch kind {
        case .pie?:
            let rows = CGFloat(max(shape.items, 1))
            return pieHeight + 10 + rows * legendRow + (rows - 1) * 6
        case .bar? where shape.items > 6 || shape.items * shape.series > 12:
            let perItem = shape.series > 1 ? rowHeight * (0.5 + 0.45 * CGFloat(shape.series)) : rowHeight
            return max(CGFloat(shape.items) * perItem, rowHeight * 3) + axisHeight + legend
        default:
            return plotHeight + legend
        }
    }
}

/// What a chart block still arriving already says of its size: its unit,
/// how many items have come and how many series it names. Read from the
/// text as it stands, since JSON cut off partway does not parse.
private struct ChartPendingShape {
    var unit = ""
    var items = 0
    var series = 1

    init(_ partial: String) {
        unit = Self.text(after: "\"unit\"", in: partial) ?? ""
        let labelled = partial.components(separatedBy: "\"label\"").count - 1
        let listed = Self.strings(after: "\"labels\"", in: partial)
        if partial.contains("\"datasets\"") {
            // Chart.js's shape: a label for each series, the items in "labels".
            items = listed
            series = max(labelled, 1)
        } else {
            items = labelled > 0 ? labelled : listed
            series = max(Self.strings(after: "\"series\"", in: partial), 1)
        }
        series = min(series, ChartSpec.maximumSeries)
    }

    /// The text given for `key`, once its closing quote has come.
    private static func text(after key: String, in partial: String) -> String? {
        guard let found = partial.range(of: key) else { return nil }
        let rest = partial[found.upperBound...].drop(while: { $0 == " " || $0 == ":" || $0 == "\t" || $0 == "\n" })
        guard rest.first == "\"" else { return nil }
        let body = rest.dropFirst()
        guard let end = body.firstIndex(of: "\"") else { return nil }
        let value = String(body[..<end])
        return value.isEmpty || value.contains("\\") || value.count > 40 ? nil : value
    }

    /// How many texts the list after `key` holds so far.
    private static func strings(after key: String, in partial: String) -> Int {
        guard let found = partial.range(of: key) else { return 0 }
        let rest = partial[found.upperBound...]
        guard let open = rest.firstIndex(of: "[") else { return 0 }
        let list = rest[rest.index(after: open)...]
        let body = list.firstIndex(of: "]").map { list[..<$0] } ?? list
        return body.reduce(0) { $1 == "\"" ? $0 + 1 : $0 } / 2
    }
}

/// A block that cannot be drawn: why, then its source as code, which can be
/// read and copied as it was written.
private struct RichFallbackView: View {
    let source: String
    let reason: String

    var body: some View {
        let note = String(localized: "グラフを表示できませんでした（\(reason)）")
        VStack(alignment: .leading, spacing: 6) {
            Label {
                Text(verbatim: note)
            } icon: {
                Image(systemName: "exclamationmark.triangle")
            }
            .font(.footnote)
            .foregroundStyle(.secondary)
            // One element that says why, not the icon's "警告" on its own.
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(Text(verbatim: note))
            .accessibilityIdentifier("chart-fallback")
            MarkdownCodeView(language: "json", code: source, streaming: false)
        }
    }
}
