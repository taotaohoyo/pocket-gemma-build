import SwiftUI
import PocketCore

/// A rich block in a reply (`MarkdownBlock.rich`): the view its kind names
/// once its data holds up, a placeholder while it is still arriving, and
/// otherwise its source as code under a line saying why it is not drawn, so
/// nothing the model wrote is lost. Each kind brings its own view, menu and
/// copying; a new kind adds a case here and leaves the rest of the reply's
/// drawing as it is.
struct RichBlockView: View, Equatable {
    let block: RichBlock
    /// In the chunk the model is writing: a block that becomes ready here
    /// appears with its own motion; one in a reply opened later does not.
    let streaming: Bool

    /// The same block draws the same, whether its reply is still streaming
    /// or not, so the end of a reply does not draw it again.
    static func == (lhs: Self, rhs: Self) -> Bool { lhs.block == rhs.block }

    var body: some View {
        switch block.state {
        case .ready(.chart(let chart)):
            ChartBlockView(chart: chart, appears: streaming)
        case .pending:
            RichPendingView(source: block.source)
        case .failed(let error):
            RichFallbackView(source: block.source, reason: error.message)
        }
    }
}

/// The card a rich block sits on, as a code block does: the reply's width,
/// rounded corners and a hairline edge.
struct RichCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) { content }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.codeBackground)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(Theme.markdownLine.opacity(0.5), lineWidth: 0.5)
            }
    }
}

/// A chart still arriving: a card about a chart's size with what the block
/// already says it is, so the reply never shows half its data and the chart
/// takes the card's place once its data is complete.
private struct RichPendingView: View {
    let source: String
    @ScaledMetric(relativeTo: .body) private var plotHeight = ChartMetrics.plotHeight

    var body: some View {
        let peek = ChartSpec.peek(source)
        RichCard {
            ChartTitle(kind: peek.kind, title: peek.title ?? "", unit: "")
            HStack(spacing: 8) {
                ProgressView().controlSize(.small)
                Text("グラフを準備しています")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, minHeight: plotHeight)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text("グラフを準備しています"))
        .accessibilityIdentifier("chart-pending")
    }
}

/// A block that cannot be drawn: why, then its source as code, which can be
/// read and copied as it was written.
private struct RichFallbackView: View {
    let source: String
    let reason: String

    var body: some View {
        let note = String(localized: "グラフを表示できませんでした（\(reason)）")
        VStack(alignment: .leading, spacing: 6) {
            Label {
                Text(verbatim: note)
            } icon: {
                Image(systemName: "exclamationmark.triangle")
            }
            .font(.footnote)
            .foregroundStyle(.secondary)
            // One element that says why, not the icon's "警告" on its own.
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(Text(verbatim: note))
            .accessibilityIdentifier("chart-fallback")
            MarkdownCodeView(language: "json", code: source, streaming: false)
        }
    }
}
