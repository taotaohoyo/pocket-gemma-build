import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers
import PocketCore

// Claude in the app as in Fielua for the web (1.1.0 (260), the user's
// 2026-11-11 「web版で作成した機能などをすべてFielua ipaに移す」): photos,
// PDFs and files sent with a question, Claude's own web search and file
// creation, the files a reply made, and the estimate of the credit left.
// In Views, so the UI preview's store, which compiles Views alone, sends
// and shows them exactly as the app's ChatStore does.

// MARK: What a request carries

/// A Claude request's turns as the relay takes them (claude-relay
/// src/turns.ts): the text of each, and the photos and files of the
/// person's own turns, read and sized here.
enum ClaudeRequest {
    /// Older turns' attachments tried at most, newest first: each photo is
    /// encoded again for every request.
    static let earlierTries = 12

    /// `turns` (ClaudeContext.turns) with their photos and files: all of
    /// the question's, which must fit one request (attachmentsTooLarge),
    /// then the earlier turns' newest first while they fit. One left out
    /// is named in its turn's text, so Claude knows it was there. Off the
    /// main thread: photos are encoded here.
    /// The request's turns, handed from the encoding off the main thread.
    struct Messages: @unchecked Sendable {
        let list: [[String: Any]]
    }

    static func messages(_ turns: [ClaudeTurn], attachmentBytes: Int) throws -> Messages {
        var budget = ClaudeAttachmentBudget(bytes: attachmentBytes)
        var parts = Array(repeating: [ClaudeAttachmentPart](), count: turns.count)
        var left = Array(repeating: [String](), count: turns.count)
        if let last = turns.indices.last {
            for attachment in turns[last].attachments {
                guard ClaudeContext.sends(attachment) else { throw ClaudeLinkError.attachmentKind }
                guard let taken = take(attachment, budget: &budget, inTurn: parts[last].count) else {
                    throw ClaudeLinkError.attachmentsTooLarge
                }
                parts[last] += taken
            }
        }
        var tries = 0
        for index in turns.indices.dropLast().reversed() where turns[index].role == "user" {
            for attachment in turns[index].attachments {
                var taken: [ClaudeAttachmentPart]?
                if ClaudeContext.sends(attachment), tries < earlierTries {
                    tries += 1
                    taken = take(attachment, budget: &budget, inTurn: parts[index].count)
                }
                if let taken { parts[index] += taken } else { left[index].append(attachment.name) }
            }
        }
        return Messages(list: turns.indices.map { index in
            var content = turns[index].content
            if !left[index].isEmpty {
                content += (content.isEmpty ? "" : "\n\n") + ClaudeContext.notSentNote(left[index])
            }
            var message: [String: Any] = ["role": turns[index].role, "content": content]
            if !parts[index].isEmpty { message["attachments"] = parts[index].map(\.json) }
            return message
        })
    }

    /// One attachment as it best fits what is left: a photo smaller if it
    /// must be; a PDF itself, or its text when the PDF is too large.
    private static func take(_ attachment: ChatAttachment, budget: inout ClaudeAttachmentBudget,
                             inTurn: Int) -> [ClaudeAttachmentPart]? {
        switch attachment.kind {
        case .image:
            guard let part = ClaudeAttachmentEncoder.image(attachment, room: budget.remainingChars) else { return nil }
            return budget.take([part], alreadyInTurn: inTurn) ? [part] : nil
        case .file:
            if let pdf = ClaudeAttachmentEncoder.pdf(attachment, room: budget.remainingChars),
               budget.take([pdf], alreadyInTurn: inTurn) { return [pdf] }
            if let text = ClaudeAttachmentEncoder.text(attachment), budget.take([text], alreadyInTurn: inTurn) { return [text] }
            return nil
        case .video, .audio:
            return nil
        }
    }
}

/// A photo or file as Claude reads it, from what the chat keeps of it.
enum ClaudeAttachmentEncoder {
    /// A photo at most 1,568 pixels on its long side (what Claude reads
    /// without scaling it down itself), as a JPEG made anew: no location
    /// or other metadata leaves the iPhone. Smaller where it wouldn't fit.
    static func image(_ attachment: ChatAttachment, room: Int) -> ClaudeAttachmentPart? {
        let original = AttachmentStorage.url(attachment.storedName).flatMap { CGImageSourceCreateWithURL($0 as CFURL, nil) }
        let thumbnail = attachment.thumbnailName.flatMap(AttachmentStorage.url).flatMap { CGImageSourceCreateWithURL($0 as CFURL, nil) }
        guard let source = original ?? thumbnail else { return nil }
        let steps: [(pixels: Int, quality: Double)] = [(1568, 0.82), (1024, 0.72), (768, 0.62)]
        var last: Data?
        for step in steps {
            guard let data = jpeg(source, maxPixels: step.pixels, quality: step.quality) else { break }
            last = data
            if (data.count + 2) / 3 * 4 <= room { break }
        }
        guard let last else { return nil }
        return ClaudeAttachmentPart(image: last.base64EncodedString(), mediaType: "image/jpeg", name: attachment.name)
    }

    private static func jpeg(_ source: CGImageSource, maxPixels: Int, quality: Double) -> Data? {
        let options: [CFString: Any] = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                                        kCGImageSourceCreateThumbnailWithTransform: true,
                                        kCGImageSourceThumbnailMaxPixelSize: maxPixels]
        guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return nil }
        let data = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(data, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { return nil }
        return data as Data
    }

    static func isPDF(_ attachment: ChatAttachment) -> Bool {
        (attachment.storedName as NSString).pathExtension.lowercased() == "pdf"
            || (attachment.name as NSString).pathExtension.lowercased() == "pdf"
    }

    /// A PDF itself, which Claude reads with its pages' pictures, when it fits.
    static func pdf(_ attachment: ChatAttachment, room: Int) -> ClaudeAttachmentPart? {
        guard isPDF(attachment), (Int(attachment.byteCount) + 2) / 3 * 4 <= room,
              let url = AttachmentStorage.url(attachment.storedName),
              let data = try? Data(contentsOf: url), data.starts(with: Array("%PDF-".utf8)) else { return nil }
        return ClaudeAttachmentPart(pdf: data.base64EncodedString(), name: attachment.name)
    }

    /// A file's text as the iPhone read it (Word, text files; a PDF too
    /// large to go itself), up to what the relay takes of one file.
    static func text(_ attachment: ChatAttachment) -> ClaudeAttachmentPart? {
        let text = AttachmentStorage.fullText(attachment) ?? attachment.extractedText ?? ""
        let kept = GenerationSettings.prefix(text, byteLimit: ClaudeAttachmentBudget.maxTextFileBytes)
        guard !kept.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        return ClaudeAttachmentPart(text: kept, name: attachment.name)
    }
}

// MARK: What a reply keeps

extension ChatThread {
    /// What a Claude reply in this chat may use: its switches, where the
    /// relay offers them, and its container while Anthropic keeps it.
    @MainActor var claudeTools: ClaudeLinkStore.Tools {
        let link = ClaudeLinkStore.shared
        let files = makesFiles == true && link.offersFiles
        return ClaudeLinkStore.Tools(webSearch: webSearch == true && link.offersWebSearch, files: files,
                                     container: files ? claudeContainer.flatMap { $0.live() ? $0.id : nil } : nil)
    }

    /// The container a reply made its files in, kept for the next question.
    mutating func keepContainer(_ id: String?) {
        guard let id, claudeContainer?.id != id else { return }
        claudeContainer = ClaudeContainer(id: id)
    }
}

extension ChatMessage {
    /// What a Claude reply searched, made and how it ended, as it is read.
    mutating func apply(_ reader: ClaudeReplyReader, generating: Bool) {
        webSearch = reader.search(generating: generating)
        let known = claudeFiles ?? []
        let files = reader.files.map { id in known.first { $0.id == id } ?? ClaudeMadeFile(id: id) }
        claudeFiles = files.isEmpty ? nil : files
        claudeEnd = reader.end
    }

    /// The made files' names, kinds and sizes, once the relay told them.
    mutating func keepDetails(_ details: [ClaudeMadeFile]) {
        guard var files = claudeFiles else { return }
        for index in files.indices {
            guard let detail = details.first(where: { $0.id == files[index].id }), detail.name != nil else { continue }
            files[index].name = detail.name
            files[index].mimeType = detail.mimeType
            files[index].size = detail.size
        }
        claudeFiles = files
    }
}

// MARK: In the composer

/// The plus menu's ウェブ検索 and ファイル作成 in a Claude chat (1.1.0 (260)):
/// Claude's own tools at Anthropic, each while the chat's switch is on,
/// where the relay offers them.
struct ClaudeToolItems: View {
    @ObservedObject var chats: ChatStore
    @ObservedObject private var link = ClaudeLinkStore.shared

    var body: some View {
        if link.offersWebSearch || link.offersFiles {
            Section {
                if link.offersWebSearch {
                    Toggle(isOn: Binding(get: { chats.webSearchOn }, set: { chats.setWebSearch($0) })) {
                        Text("ウェブ検索")
                        Image(systemName: "globe")
                    }
                    .disabled(chats.isGenerating)
                    .accessibilityIdentifier("chat-web-search")
                }
                if link.offersFiles {
                    Toggle(isOn: Binding(get: { chats.makesFilesOn }, set: { chats.setMakesFiles($0) })) {
                        Text("ファイル作成")
                        Image(systemName: "doc.badge.plus")
                    }
                    .disabled(chats.isGenerating)
                    .accessibilityIdentifier("chat-make-files")
                }
            }
        }
    }
}

// MARK: Under a reply

/// Below a Claude reply: the files it made, to save, and how it ended
/// when it paused or reached its length limit.
struct ClaudeReplyExtras: View {
    let files: [ClaudeMadeFile]
    let end: ClaudeReplyEnd?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(files) { file in ClaudeFileCard(file: file) }
            if let end {
                Text(end.notice)
                    .font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("claude-reply-end")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .contain)
    }
}

/// A file a reply made: its name, kind and size, and 保存, which fetches it
/// from the relay (this person's alone) and opens the share sheet to save
/// it to ファイル or send it on. Content, so no glass.
struct ClaudeFileCard: View {
    let file: ClaudeMadeFile
    @State private var saving = false
    @State private var fetched: Fetched?
    /// The copy fetched last, removed once the share sheet has gone.
    @State private var copy: URL?
    @State private var problem: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    struct Fetched: Identifiable {
        let id = UUID()
        let url: URL
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 10) {
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .regular))
                    .foregroundStyle(Theme.icon)
                    .frame(width: 28)
                    .accessibilityHidden(true)
                // Until the relay says what the file is (0.6 to 3 s after the
                // reply), its lines are a pale stand-in, and the name and
                // size fade in over them: the card said 「ファイル」 and then
                // changed its words until 1.1.0 (262).
                VStack(alignment: .leading, spacing: 1) {
                    Text(verbatim: file.name ?? String(localized: "ファイル"))
                        .font(.footnote.weight(.medium)).foregroundStyle(Theme.ink)
                        .lineLimit(1).truncationMode(.middle)
                    Text(known ? detail : "000 KB").font(.caption2).foregroundStyle(.secondary)
                }
                .redacted(reason: known ? [] : .placeholder)
                .contentTransition(.opacity)
                .animation(FieluaMotion.change(reduceMotion), value: known)
                Spacer(minLength: 8)
                if file.expired() {
                    Text("保存期間が過ぎました").font(.caption2).foregroundStyle(.secondary)
                } else {
                    Button(action: save) {
                        FieluaBusyLabel("保存", busy: saving)
                            .font(.footnote.weight(.semibold))
                            .frame(minWidth: 30)
                    }
                    // The cards' own button (the system's, in umber, until 1.1.0 (262)).
                    .fieluaSecondaryButton()
                    .disabled(saving)
                    .accessibilityLabel(Text("\(file.name ?? String(localized: "ファイル"))を保存"))
                    .accessibilityIdentifier("claude-file-save")
                }
            }
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .fieluaCard(cornerRadius: 14)
        .frame(maxWidth: 420, alignment: .leading)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-file")
        .sheet(item: $fetched, onDismiss: removeFetched) { fetched in
            // Half the screen first, as iOS's own share sheet comes up.
            ClaudeShareSheet(url: fetched.url).ignoresSafeArea()
                .presentationDetents([.medium, .large])
        }
        // The file has come: a tap as its sheet opens.
        .sensoryFeedback(.success, trigger: fetched?.id) { _, id in id != nil }
    }

    /// The relay has said what the file is.
    private var known: Bool { file.name != nil }

    private var symbol: String {
        if file.isPicture { return "photo" }
        switch file.kind {
        case "PDF": return "doc.richtext"
        case "Excel", "CSV": return "tablecells"
        case "PowerPoint": return "rectangle.on.rectangle"
        default: return "doc.text"
        }
    }

    private var detail: String {
        let size = file.size.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file) }
        return [file.kind, size].compactMap { $0 }.joined(separator: " · ")
    }

    private func save() {
        guard !saving else { return }
        saving = true
        problem = nil
        Task {
            defer { saving = false }
            do {
                let url = try await ClaudeLinkStore.shared.download(file)
                copy = url
                fetched = Fetched(url: url)
            } catch is CancellationError {
            } catch {
                problem = error.localizedDescription
            }
        }
    }

    /// The copy fetched for the share sheet goes once the sheet does.
    private func removeFetched() {
        guard let folder = copy?.deletingLastPathComponent() else { return }
        copy = nil
        try? FileManager.default.removeItem(at: folder)
    }
}

/// iOS's share sheet for a file fetched from the relay.
struct ClaudeShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

// MARK: The credit left

/// The estimate of the credit left as a ring: honey, or the caution color
/// below 15%.
struct ClaudeCreditRing: View {
    let percent: Double
    let low: Bool
    var lineWidth: CGFloat = 3
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            Circle().stroke(Theme.markdownLine, lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: max(0, min(1, percent / 100)))
                .stroke(low ? Theme.caution : Theme.active, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
        .padding(lineWidth / 2)
        .animation(reduceMotion ? nil : ChatMotion.gauge, value: percent)
        .accessibilityHidden(true)
    }
}

/// In a Claude chat's composer row, while the relay gives the estimate:
/// a small ring with the percent left, opening the sheet with the rest.
struct ClaudeCreditButton: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    /// The chat's own, so what moves by itself there rests under the sheet (1.1.0 (263)).
    @Binding var showSheet: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        // The ring comes as the relay's estimate does, a moment after the
        // chat: it grows into its place (it was there in a frame before
        // 1.1.0 (263)). Nothing else in the row moves for it.
        ZStack {
            if let credit = link.credit {
                ring(credit).transition(reduceMotion ? .opacity : .scale(scale: 0.6).combined(with: .opacity))
            }
        }
        .animation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.resize, value: link.credit != nil)
        .sheet(isPresented: $showSheet) {
            ClaudeCreditSheet().presentationDetents([.medium, .large])
        }
    }

    private func ring(_ credit: ClaudeCredit) -> some View {
        let percent = Int(credit.percent.rounded())
        return Button { showSheet = true } label: {
            ZStack {
                ClaudeCreditRing(percent: credit.percent, low: credit.isLow, lineWidth: 2.5)
                    .frame(width: 28, height: 28)
                Text(verbatim: "\(percent)")
                    .font(.system(size: 10, weight: .semibold, design: .rounded).monospacedDigit())
                    .foregroundStyle(credit.isLow ? Theme.caution : Theme.tint)
                    .minimumScaleFactor(0.7)
                    .contentTransition(.numericText(value: Double(percent)))
            }
            // The number counts and the colour turns, with the ring's own sweep.
            .animation(reduceMotion ? nil : ChatMotion.recolor, value: percent)
            .animation(reduceMotion ? nil : ChatMotion.recolor, value: credit.isLow)
            .frame(width: ChatMetrics.chip, height: ChatMetrics.control)
            .contentShape(Rectangle())
            // A finger's 44pt, toward the pills (send touches the other
            // side): the row is too full on a 375pt phone to draw it wider.
            .background(alignment: .trailing) {
                Color.clear.frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Rectangle())
            }
        }
        .buttonStyle(ClaudeCreditPress())
        .accessibilityLabel(Text("クレジットの残り、推定\(percent)%"))
        .accessibilityIdentifier("claude-credit")
    }
}

/// The ring answers a finger (the plain style showed nothing).
private struct ClaudeCreditPress: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.5 : 1)
            .animation(configuration.isPressed ? nil : FieluaMotion.release, value: configuration.isPressed)
    }
}

/// The estimate in full: the big ring, about how much is left, the
/// balance it counts from; for the developer, the balance to enter from
/// Anthropic's Console, whether friends see it, and 推定をやめる.
struct ClaudeCreditSheet: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var amount = ""
    @State private var busy = false
    /// 保存 runs (its label shows it).
    @State private var saving = false
    @State private var saves = 0
    /// 友人にも残りを表示 as it was just set, until the relay has answered
    /// (the switch sprang back for the length of the call before 1.1.0 (263)).
    @State private var friendsAsked: Bool?
    @State private var problem: String?
    @FocusState private var amountFocused: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    if let credit = link.credit {
                        let percent = Int(credit.percent.rounded())
                        ZStack {
                            ClaudeCreditRing(percent: credit.percent, low: credit.isLow, lineWidth: 10)
                                .frame(width: 136, height: 136)
                            Text(verbatim: "\(percent)%")
                                .font(.system(size: 32, weight: .semibold, design: .rounded).monospacedDigit())
                                .foregroundStyle(credit.isLow ? Theme.caution : Theme.ink)
                                .contentTransition(.numericText(value: Double(percent)))
                                // Counts with the ring's sweep (it jumped before 1.1.0 (263)).
                                .animation(reduceMotion ? nil : ChatMotion.gauge, value: percent)
                        }
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(Text("推定\(percent)%"))
                        .padding(.top, 8)
                        Text("残り 約\(ClaudeCredit.dollars(credit.remainingUSD))（推定）")
                            .font(.subheadline).foregroundStyle(.secondary)
                            .contentTransition(.opacity)
                            .accessibilityIdentifier("claude-credit-left")
                        VStack(alignment: .leading, spacing: 6) {
                            Text("\(credit.setAt.formatted(date: .abbreviated, time: .shortened))の残高 \(ClaudeCredit.dollars(credit.budgetUSD)) · それ以降に使った分 約\(ClaudeCredit.dollars(credit.spentUSD))")
                            if link.state == .unavailable(.pausedBilling) {
                                Text("Anthropicでクレジットが切れています。").foregroundStyle(Theme.caution)
                            }
                        }
                        .font(.footnote)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16).fieluaCard(cornerRadius: FieluaRadius.card)
                    } else {
                        Text("残りのクレジットはまだ入力されていません。")
                            .font(.subheadline).foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16).fieluaCard(cornerRadius: FieluaRadius.card)
                            .transition(.opacity)
                    }
                    if link.isDeveloper && link.canManage { controls }
                }
                .padding(.horizontal, 20).padding(.bottom, 24)
                // The estimate entered or taken away, and what the relay says back.
                .animation(FieluaMotion.change(reduceMotion), value: link.credit == nil)
                .animation(FieluaMotion.change(reduceMotion), value: problem)
            }
            // The paper and the cross of every other sheet (the plain canvas
            // and 「閉じる」 in words before 1.1.0 (263)).
            .fieluaPageBackground()
            .navigationTitle("クレジットの残り")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("閉じる", systemImage: "xmark", role: .close) { dismiss() }
                        .accessibilityIdentifier("claude-credit-close")
                }
            }
        }
        .task { link.refresh() }
        .sensoryFeedback(.success, trigger: saves)
        .accessibilityIdentifier("claude-credit-sheet")
    }

    private var controls: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Console（Billing）の残高（米ドル）").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
            HStack(spacing: 10) {
                TextField("例：25.00", text: $amount)
                    .keyboardType(.decimalPad)
                    .focused($amountFocused)
                    .fieluaField()
                    .accessibilityIdentifier("claude-credit-amount")
                Button { saveAmount() } label: {
                    FieluaBusyLabel("保存", busy: saving)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(busy || dollars == nil)
                .accessibilityIdentifier("claude-credit-save")
            }
            Toggle("友人にも残りを表示", isOn: Binding(get: { friendsAsked ?? (link.credit?.friends ?? false) }, set: { on in
                friendsAsked = on
                run { try await link.setCreditFriends(on) }
            }))
            .disabled(busy || link.credit == nil)
            .accessibilityIdentifier("claude-credit-friends")
            if link.credit != nil {
                Button("推定をやめる", role: .destructive) { run { try await link.setCredit(nil) } }
                    .font(.footnote)
                    .fieluaTextButton()
                    .disabled(busy)
                    .transition(.opacity)
                    .accessibilityIdentifier("claude-credit-clear")
            }
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16).fieluaCard(cornerRadius: FieluaRadius.card)
    }

    /// The amount typed: "25", "$25.00", "1,000"; nothing else.
    private var dollars: Double? {
        let cleaned = amount.replacingOccurrences(of: "[$,＄、\\s]", with: "", options: .regularExpression)
            .replacingOccurrences(of: "．", with: ".")
        guard let value = Double(cleaned), value > 0, value <= 100_000 else { return nil }
        return value
    }

    private func saveAmount() {
        guard let value = dollars else { return }
        amountFocused = false
        saving = true
        run {
            try await link.setCredit(value)
            amount = ""
            saves += 1
        }
    }

    private func run(_ work: @escaping () async throws -> Void) {
        guard !busy else { saving = false; friendsAsked = nil; return }
        busy = true
        problem = nil
        Task {
            defer { busy = false; saving = false; friendsAsked = nil }
            do { try await work() } catch is CancellationError {} catch { problem = error.localizedDescription }
        }
    }
}

/// 設定 › Claude, for the developer: the estimate, and where to enter the
/// balance it counts from.
struct ClaudeCreditRow: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @State private var showSheet = false

    var body: some View {
        Button { showSheet = true } label: {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("クレジットの残り（推定）").foregroundStyle(Theme.ink)
                    Group {
                        if let credit = link.credit {
                            Text("推定\(Int(credit.percent.rounded()))%（約\(ClaudeCredit.dollars(credit.remainingUSD))）")
                        } else {
                            Text("未入力")
                        }
                    }
                    .font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 8)
                if let credit = link.credit {
                    ClaudeCreditRing(percent: credit.percent, low: credit.isLow, lineWidth: 3).frame(width: 26, height: 26)
                }
                Image(systemName: "chevron.right").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("claude-credit-row")
        .sheet(isPresented: $showSheet) {
            ClaudeCreditSheet().presentationDetents([.medium, .large])
        }
    }
}
