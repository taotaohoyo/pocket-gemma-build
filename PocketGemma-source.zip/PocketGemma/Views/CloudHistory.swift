import SwiftUI
import UniformTypeIdentifiers
import PocketCore

/// User-selected File Provider access works with AltStore personal signing,
/// without a paid team's CloudKit container or an iCloud entitlement.
@MainActor final class CloudHistoryStore: ObservableObject {
    static let shared = CloudHistoryStore()
    @Published private(set) var enabled = UserDefaults.standard.bool(forKey: "cloud-history-enabled")
    @Published private(set) var busy = false
    @Published private(set) var status = ""
    @Published private(set) var lastSaved = UserDefaults.standard.object(forKey: "cloud-history-last-saved") as? Date
    @Published var error: String?
    private let io = CloudHistoryIO()
    private var scheduled: Task<Void, Never>?
    private var pendingSnapshot: [ChatThread]?
    private var generation = 0
    private var bookmark: Data? { UserDefaults.standard.data(forKey: "cloud-history-folder") }
    var destinationName: String { UserDefaults.standard.string(forKey: "cloud-history-folder-name") ?? String(localized: "保存先を選択") }
    private var deviceID: String {
        if let id = UserDefaults.standard.string(forKey: "cloud-history-device-id"), UUID(uuidString: id) != nil { return id }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey: "cloud-history-device-id"); return id
    }
    func configure(_ url: URL) {
        guard !busy else { return }
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)
            generation += 1; scheduled?.cancel(); scheduled = nil; pendingSnapshot = nil
            UserDefaults.standard.set(data, forKey: "cloud-history-folder")
            UserDefaults.standard.set(url.lastPathComponent, forKey: "cloud-history-folder-name")
            UserDefaults.standard.set(true, forKey: "cloud-history-enabled")
            UserDefaults.standard.removeObject(forKey: "cloud-history-last-saved"); lastSaved = nil
            enabled = true; error = nil; status = String(localized: "自動保存を有効にしました")
        } catch { self.error = String(localized: "保存先へのアクセスを保存できませんでした。") + "\n" + error.localizedDescription }
    }
    func disable() {
        generation += 1; scheduled?.cancel(); scheduled = nil
        pendingSnapshot = nil
        enabled = false; UserDefaults.standard.set(false, forKey: "cloud-history-enabled")
        status = String(localized: "自動保存はオフです。保存済みのバックアップは残ります。")
    }
    func schedule(_ threads: [ChatThread]) {
        guard enabled else { return }
        pendingSnapshot = threads
        // Do not cancel a write already copying media. Queue the newest
        // snapshot so a reply finishing during that write cannot be lost.
        guard !busy else { return }
        scheduled?.cancel()
        scheduled = Task {
            do { try await Task.sleep(for: .seconds(3)) } catch { return }
            guard !Task.isCancelled, enabled else { return }
            guard let newest = pendingSnapshot else { return }
            pendingSnapshot = nil; scheduled = nil
            await saveNow(newest)
        }
    }
    func saveNow(_ threads: [ChatThread]) async {
        guard enabled, let bookmark else { return }
        if busy { pendingSnapshot = threads; return }
        scheduled?.cancel(); scheduled = nil; pendingSnapshot = nil
        let ticket = generation
        busy = true; status = String(localized: "会話と添付を保存しています…")
        defer { finishOperation() }
        do {
            try await io.save(threads, bookmark: bookmark, deviceID: deviceID)
            guard generation == ticket, enabled else { return }
            let date = Date(); lastSaved = date
            UserDefaults.standard.set(date, forKey: "cloud-history-last-saved")
            status = String(localized: "保存しました。")
            error = nil
        } catch { if enabled { self.error = String(localized: "バックアップを保存できませんでした。") + "\n" + error.localizedDescription } }
    }
    func restore() async throws -> [ChatThread] {
        guard !busy, let bookmark else { throw CocoaError(.fileReadNoPermission) }
        busy = true; status = String(localized: "バックアップを読み込んでいます…")
        defer { finishOperation() }
        let threads = try await io.restore(bookmark: bookmark)
        status = String(localized: "バックアップを読み込みました")
        return threads
    }
    private func finishOperation() {
        busy = false
        if enabled, let newest = pendingSnapshot { schedule(newest) }
    }
}

actor CloudHistoryIO {
    /// The folder backups go in, inside the one the person picked; it shows
    /// in the Files app. Backups from before the app was named Fielua are in
    /// "PocketGemma", which restoring still reads when there is no "Fielua".
    static let folderName = "Fielua"
    static let earlierFolderName = "PocketGemma"
    private func access<T>(_ bookmark: Data, writing: Bool, work: (URL) throws -> T) throws -> T {
        var stale = false
        let folder = try URL(resolvingBookmarkData: bookmark, options: [.withoutUI], relativeTo: nil, bookmarkDataIsStale: &stale)
        guard !stale else { throw CocoaError(.fileReadNoPermission) }
        let accessed = folder.startAccessingSecurityScopedResource()
        defer { if accessed { folder.stopAccessingSecurityScopedResource() } }
        var result: Result<T, Error>?
        var coordinationError: NSError?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        if writing {
            coordinator.coordinate(writingItemAt: folder, options: .forMerging, error: &coordinationError) { url in result = Result { try work(url) } }
        } else {
            coordinator.coordinate(readingItemAt: folder, options: [], error: &coordinationError) { url in result = Result { try work(url) } }
        }
        if let coordinationError { throw coordinationError }
        guard let result else { throw CocoaError(.fileReadUnknown) }
        return try result.get()
    }
    func save(_ threads: [ChatThread], bookmark: Data, deviceID: String) throws {
        guard UUID(uuidString: deviceID) != nil else { throw CocoaError(.fileWriteInvalidFileName) }
        let names = try HistoryMerge.attachmentNames(in: threads)
        try access(bookmark, writing: true) { folder in
            let root = folder.appendingPathComponent(Self.folderName, isDirectory: true)
            let media = root.appendingPathComponent("Attachments", isDirectory: true)
            let device = root.appendingPathComponent(deviceID, isDirectory: true)
            try FileManager.default.createDirectory(at: media, withIntermediateDirectories: true)
            try FileManager.default.createDirectory(at: device, withIntermediateDirectories: true)
            for url in [root, media, device] { try requireDirectory(url) }
            for name in names {
                try Task.checkCancellation()
                guard let source = AttachmentStorage.url(name), FileManager.default.fileExists(atPath: source.path) else { throw CocoaError(.fileReadNoSuchFile) }
                let destination = media.appendingPathComponent(name)
                if !FileManager.default.fileExists(atPath: destination.path) {
                    try FileManager.default.copyItem(at: source, to: destination)
                }
                try requireFile(destination)
            }
            // Publish the archive only after all its referenced media exists.
            // Separate device snapshots prevent another device erasing history.
            try ChatArchive(fileURL: device.appendingPathComponent("conversations.json")).save(threads)
        }
    }
    func restore(bookmark: Data) throws -> [ChatThread] {
        try access(bookmark, writing: false) { folder in
            let current = folder.appendingPathComponent(Self.folderName, isDirectory: true)
            let hasCurrent = (try? current.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory == true
            let root = hasCurrent ? current : folder.appendingPathComponent(Self.earlierFolderName, isDirectory: true)
            try requireDirectory(root)
            let devices = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            var restored: [ChatThread] = []
            for device in devices where UUID(uuidString: device.lastPathComponent) != nil {
                let values = try device.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                guard values.isDirectory == true, values.isSymbolicLink != true else { continue }
                let file = device.appendingPathComponent("conversations.json")
                guard FileManager.default.fileExists(atPath: file.path) else { continue }
                try requireFile(file)
                let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
                guard ((attrs[.size] as? NSNumber)?.intValue ?? Int.max) <= 32_000_000 else { throw CocoaError(.fileReadTooLarge) }
                restored = HistoryMerge.merge(local: restored, incoming: try ChatArchive(fileURL: file).load())
            }
            guard !restored.isEmpty else { throw CocoaError(.fileReadNoSuchFile) }
            let names = try HistoryMerge.attachmentNames(in: restored)
            let media = root.appendingPathComponent("Attachments", isDirectory: true)
            if !names.isEmpty { try requireDirectory(media) }
            try FileManager.default.createDirectory(at: AttachmentStorage.directory, withIntermediateDirectories: true)
            for name in names {
                try Task.checkCancellation()
                guard let destination = AttachmentStorage.url(name) else { throw CocoaError(.fileReadCorruptFile) }
                if FileManager.default.fileExists(atPath: destination.path) { continue }
                let source = media.appendingPathComponent(name)
                let values = try source.resourceValues(forKeys: [.isSymbolicLinkKey, .isRegularFileKey])
                guard values.isSymbolicLink != true, values.isRegularFile == true else { throw CocoaError(.fileReadCorruptFile) }
                try FileManager.default.copyItem(at: source, to: destination)
            }
            return restored
        }
    }
    private func requireDirectory(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
    }
    private func requireFile(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
    }
}

struct CloudHistoryCard: View {
    @EnvironmentObject private var chats: ChatStore
    @StateObject private var cloud = CloudHistoryStore.shared
    @State private var chooseFolder = false
    @State private var confirmRestore = false
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("iCloud Driveに会話を保存", isOn: Binding(get: { cloud.enabled }, set: {
                if $0 { chooseFolder = true } else { cloud.disable() }
            })).font(.headline).fieluaStateTint().accessibilityIdentifier("cloud-history-toggle")
            // What leaves the phone, and where to: the rest the buttons say.
            Text("会話と添付を、指定したフォルダに自動でバックアップします。")
                .font(.caption).foregroundStyle(.secondary)
            if cloud.enabled {
                Text("保存先: \(cloud.destinationName)").font(.caption)
                if let date = cloud.lastSaved { Text("最終書き込み: \(date.formatted(date: .abbreviated, time: .shortened))").font(.caption).foregroundStyle(.secondary) }
                HStack {
                    Button("今すぐ保存") { Task { await cloud.saveNow(chats.threads) } }
                    Button("履歴を復元") { confirmRestore = true }
                }.font(.subheadline).disabled(cloud.busy || chats.isGenerating)
                Button("保存先を変更") { chooseFolder = true }.font(.caption).disabled(cloud.busy)
            }
            if cloud.busy { ProgressView().controlSize(.small) }
            if !cloud.status.isEmpty { Text(cloud.status).font(.caption).foregroundStyle(.secondary) }
            if let error = cloud.error { Text(error).font(.caption).foregroundStyle(.orange) }
        }.padding(18).fieluaCard(cornerRadius: 20)
            .sheet(isPresented: $chooseFolder) {
                CloudFolderPicker { url in
                    chooseFolder = false
                    if let url { cloud.configure(url); Task { await cloud.saveNow(chats.threads) } }
                }
            }
            .confirmationDialog("バックアップの会話を、今の会話に追加します。", isPresented: $confirmRestore, titleVisibility: .visible) {
                Button("履歴を復元") {
                    Task {
                        do { chats.mergeBackup(try await cloud.restore()) }
                        catch { cloud.error = String(localized: "バックアップを読み込めませんでした。") + "\n" + error.localizedDescription }
                    }
                }
            }
    }
}

private struct CloudFolderPicker: UIViewControllerRepresentable {
    let completion: (URL?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = false; picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let completion: (URL?) -> Void
        init(_ completion: @escaping (URL?) -> Void) { self.completion = completion }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { completion(urls.first) }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { completion(nil) }
    }
}
