import SwiftUI
import UniformTypeIdentifiers
import PocketCore

/// Where the automatic backup goes. From 1.1.0 (252), with the TestFlight
/// build's iCloud entitlement: Fielua's own place in iCloud, which the Files
/// app does not list (PrivateBackup). Without it (the sideload build, or no
/// iCloud on the phone): a folder the person picks through File Provider,
/// which works with AltStore personal signing and which the Files app shows.
@MainActor final class CloudHistoryStore: ObservableObject {
    static let shared = CloudHistoryStore()
    @Published private(set) var enabled = UserDefaults.standard.bool(forKey: "cloud-history-enabled")
    /// The backup goes to Fielua's own iCloud, not a chosen folder.
    @Published private(set) var privateCloud = UserDefaults.standard.string(forKey: "cloud-history-destination") == CloudHistoryStore.privateDestination
    /// Whether this build and phone can use Fielua's own iCloud; nil until
    /// checked (the card checks when it shows, a save before it writes).
    @Published private(set) var privateAvailable: Bool?
    @Published private(set) var busy = false
    @Published private(set) var status = ""
    @Published private(set) var lastSaved = UserDefaults.standard.object(forKey: "cloud-history-last-saved") as? Date
    @Published var error: String?
    private static let privateDestination = "icloud-private"
    private let io = CloudHistoryIO()
    private var scheduled: Task<Void, Never>?
    private var pendingSnapshot: [ChatThread]?
    private var generation = 0
    private var bookmark: Data? { UserDefaults.standard.data(forKey: "cloud-history-folder") }
    /// What decides the card's lines, for the views that animate with it (1.1.0 (263)).
    var layout: [String] {
        [offersPrivateCloud ? "p" : "d", enabled ? "on" : "off", busy ? "busy" : "", status, error ?? "",
         lastSaved == nil ? "" : "saved", earlierFolderName ?? ""]
    }
    var destinationName: String {
        privateCloud ? String(localized: "Fielua 専用の iCloud")
            : UserDefaults.standard.string(forKey: "cloud-history-folder-name") ?? String(localized: "保存先を選択")
    }
    /// The folder the backup went to before it moved to Fielua's own iCloud:
    /// its copies stay there, in the Files app, until the person deletes them.
    var earlierFolderName: String? {
        guard privateCloud, bookmark != nil else { return nil }
        return UserDefaults.standard.string(forKey: "cloud-history-folder-name") ?? String(localized: "前の保存先")
    }
    /// The card names Fielua's own iCloud rather than a folder.
    var offersPrivateCloud: Bool { privateCloud || (privateAvailable ?? Self.lastAvailable) }
    /// What the check found at the launch before, for the card's words
    /// until this launch's check has answered: the card opened as iCloud
    /// Drive's and changed its title and grew a moment later, every launch
    /// (UI review, 2026-11-11). Only what is shown; what is done waits for
    /// the check (`privateAvailable`).
    private static let lastAvailableKey = "cloud-history-private-available"
    private static let lastAvailable = UserDefaults.standard.bool(forKey: lastAvailableKey)
    private var deviceID: String {
        if let id = UserDefaults.standard.string(forKey: "cloud-history-device-id"), UUID(uuidString: id) != nil { return id }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey: "cloud-history-device-id"); return id
    }
    /// Checks whether Fielua's own iCloud is there. An automatic backup that
    /// was going to a chosen folder moves to it (the person's choice for
    /// 1.1.0 (252)); the folder and its copies are left as they are.
    /// true when it moved.
    @discardableResult func checkPrivateCloud() async -> Bool {
        let available = await io.privateContainer() != nil
        privateAvailable = available
        UserDefaults.standard.set(available, forKey: Self.lastAvailableKey)
        guard available, enabled, !privateCloud else { return false }
        usePrivateCloud()
        status = String(localized: "保存先を Fielua 専用の iCloud に変えました。前の保存先のコピーはそのまま残っています。")
        return true
    }
    /// The switch: true when it turned on the backup to Fielua's own iCloud,
    /// false when a folder has to be chosen for it instead.
    func turnOn() async -> Bool {
        if privateAvailable == nil { await checkPrivateCloud() }
        guard privateAvailable == true, !busy else { return false }
        usePrivateCloud()
        enabled = true; UserDefaults.standard.set(true, forKey: "cloud-history-enabled")
        error = nil; status = String(localized: "自動保存を有効にしました")
        return true
    }
    private func usePrivateCloud() {
        generation += 1
        UserDefaults.standard.set(Self.privateDestination, forKey: "cloud-history-destination")
        UserDefaults.standard.removeObject(forKey: "cloud-history-last-saved"); lastSaved = nil
        privateCloud = true
    }
    func configure(_ url: URL) {
        guard !busy else { return }
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)
            generation += 1; scheduled?.cancel(); scheduled = nil; pendingSnapshot = nil
            UserDefaults.standard.set(data, forKey: "cloud-history-folder")
            UserDefaults.standard.set(url.lastPathComponent, forKey: "cloud-history-folder-name")
            UserDefaults.standard.removeObject(forKey: "cloud-history-destination"); privateCloud = false
            UserDefaults.standard.set(true, forKey: "cloud-history-enabled")
            UserDefaults.standard.removeObject(forKey: "cloud-history-last-saved"); lastSaved = nil
            enabled = true; error = nil; status = String(localized: "自動保存を有効にしました")
        } catch { self.error = String(localized: "保存先へのアクセスを保存できませんでした。") + "\n" + error.localizedDescription }
    }
    func disable() {
        generation += 1; scheduled?.cancel(); scheduled = nil
        pendingSnapshot = nil
        enabled = false; UserDefaults.standard.set(false, forKey: "cloud-history-enabled")
        status = String(localized: "自動保存はオフです。保存済みのバックアップは残ります。")
    }
    func schedule(_ threads: [ChatThread]) {
        guard enabled else { return }
        pendingSnapshot = threads
        // Do not cancel a write already copying media. Queue the newest
        // snapshot so a reply finishing during that write cannot be lost.
        guard !busy else { return }
        scheduled?.cancel()
        scheduled = Task {
            do { try await Task.sleep(for: .seconds(3)) } catch { return }
            guard !Task.isCancelled, enabled else { return }
            guard let newest = pendingSnapshot else { return }
            pendingSnapshot = nil; scheduled = nil
            await saveNow(newest)
        }
    }
    func saveNow(_ threads: [ChatThread]) async {
        guard enabled else { return }
        // The first save after an update checks for Fielua's own iCloud, so
        // a backup going to a folder moves there without a visit to 設定.
        if !privateCloud, privateAvailable == nil {
            await checkPrivateCloud()
            guard enabled else { return }
        }
        let folder = bookmark
        guard privateCloud || folder != nil else { return }
        if busy { pendingSnapshot = threads; return }
        scheduled?.cancel(); scheduled = nil; pendingSnapshot = nil
        let ticket = generation
        busy = true; status = String(localized: "会話と添付を保存しています…")
        defer { finishOperation() }
        do {
            if privateCloud {
                try await io.savePrivate(threads, deviceID: deviceID)
            } else if let folder {
                try await io.save(threads, bookmark: folder, deviceID: deviceID)
            }
            guard generation == ticket, enabled else { return }
            let date = Date(); lastSaved = date
            UserDefaults.standard.set(date, forKey: "cloud-history-last-saved")
            status = String(localized: "保存しました。")
            error = nil
        } catch { if enabled { self.error = String(localized: "バックアップを保存できませんでした。") + "\n" + error.localizedDescription } }
    }
    /// The backup the switch saves to: Fielua's own iCloud (every device's
    /// conversations in it), or the chosen folder.
    func restore() async throws -> [ChatThread] {
        if privateCloud { return try await restoring { try await $0.restorePrivate() } }
        guard let bookmark else { throw CocoaError(.fileReadNoPermission) }
        return try await restoring { try await $0.restore(bookmark: bookmark) }
    }
    /// The folder the backup went to before Fielua's own iCloud.
    func restoreEarlierFolder() async throws -> [ChatThread] {
        guard let bookmark else { throw CocoaError(.fileReadNoPermission) }
        return try await restoring { try await $0.restore(bookmark: bookmark) }
    }
    private func restoring(_ read: (CloudHistoryIO) async throws -> [ChatThread]) async throws -> [ChatThread] {
        guard !busy else { throw CocoaError(.fileReadNoPermission) }
        busy = true; status = String(localized: "バックアップを読み込んでいます…")
        defer { finishOperation() }
        let threads = try await read(io)
        status = String(localized: "バックアップを読み込みました")
        return threads
    }
    private func finishOperation() {
        busy = false
        if enabled, let newest = pendingSnapshot { schedule(newest) }
    }
#if POCKET_PREVIEW
    /// The UI check's stand-in for Fielua's iCloud container: a local folder.
    func usePreviewContainer(_ url: URL?) async {
        await io.usePreviewContainer(url)
        privateAvailable = nil
        if url == nil {
            UserDefaults.standard.removeObject(forKey: "cloud-history-destination"); privateCloud = false
        }
    }
#endif
}

/// Fielua's own iCloud is there only with the TestFlight build's iCloud
/// entitlement, while the phone is signed in to iCloud with iCloud Drive on.
struct PrivateCloudUnavailable: LocalizedError {
    var errorDescription: String? {
        String(localized: "Fielua 専用の iCloud を使えません。iPhone で iCloud にサインインし、iCloud Drive がオンか確認してください。")
    }
}

actor CloudHistoryIO {
    /// The folder backups go in, inside the one the person picked; it shows
    /// in the Files app. Backups from before the app was named Fielua are in
    /// "PocketGemma", which restoring still reads when there is no "Fielua".
    static let folderName = "Fielua"
    static let earlierFolderName = "PocketGemma"
    private var container: URL?
#if POCKET_PREVIEW
    private var previewContainer: URL?
    func usePreviewContainer(_ url: URL?) { previewContainer = url; container = nil }
#endif
    /// Fielua's iCloud container (iCloud.com.fielua.app, the only one the
    /// TestFlight build is signed with); nil without the entitlement (the
    /// sideload build) or without iCloud Drive. Never on the main thread:
    /// the first lookup can take a while.
    func privateContainer() -> URL? {
#if POCKET_PREVIEW
        if let previewContainer { return previewContainer }
#endif
        // Signed out of iCloud, or iCloud Drive off for the app: nothing is
        // written to the container's folder on the phone.
        guard FileManager.default.ubiquityIdentityToken != nil else { container = nil; return nil }
        if let container { return container }
        container = FileManager.default.url(forUbiquityContainerIdentifier: nil)
        return container
    }
    /// One coordinated read or write of `url`, so iCloud never syncs a file
    /// while it is half written.
    private func coordinated<T>(_ url: URL, writing: Bool, work: (URL) throws -> T) throws -> T {
        var result: Result<T, Error>?
        var coordinationError: NSError?
        let coordinator = NSFileCoordinator(filePresenter: nil)
        if writing {
            coordinator.coordinate(writingItemAt: url, options: .forMerging, error: &coordinationError) { url in result = Result { try work(url) } }
        } else {
            coordinator.coordinate(readingItemAt: url, options: [], error: &coordinationError) { url in result = Result { try work(url) } }
        }
        if let coordinationError { throw coordinationError }
        guard let result else { throw CocoaError(.fileReadUnknown) }
        return try result.get()
    }
    /// This device's folder in Fielua's own iCloud: its conversations, the
    /// attachments they use, and no others.
    func savePrivate(_ threads: [ChatThread], deviceID: String) throws {
        guard let container = privateContainer() else { throw PrivateCloudUnavailable() }
        let backup = PrivateBackup(container: container)
        let device = try backup.deviceFolder(deviceID)
        try FileManager.default.createDirectory(at: device, withIntermediateDirectories: true)
        try coordinated(device, writing: true) { _ in
            try backup.save(threads, deviceID: deviceID) { AttachmentStorage.url($0) }
        }
    }
    /// Every device's conversations in Fielua's own iCloud, each file
    /// downloaded first (a file another device wrote may be in iCloud only).
    func restorePrivate() throws -> [ChatThread] {
        guard let container = privateContainer() else { throw PrivateCloudUnavailable() }
        let deadline = Date().addingTimeInterval(120)
        try FileManager.default.createDirectory(at: AttachmentStorage.directory, withIntermediateDirectories: true)
        return try PrivateBackup(container: container).restore(prepare: { try Self.download($0, until: deadline) },
                                                               destination: { AttachmentStorage.url($0) })
    }
    /// Asks iCloud for the newest copy of a file kept only there, and waits
    /// for it until `deadline`; an older copy already here is used then.
    private static func download(_ url: URL, until deadline: Date) throws {
        var url = url
        let keys: Set<URLResourceKey> = [.isUbiquitousItemKey, .ubiquitousItemDownloadingStatusKey]
        guard (try? url.resourceValues(forKeys: keys))?.isUbiquitousItem == true else { return }
        var asked = false
        while true {
            url.removeAllCachedResourceValues()
            let status = try url.resourceValues(forKeys: keys).ubiquitousItemDownloadingStatus
            if status == .current { return }
            if !asked { try FileManager.default.startDownloadingUbiquitousItem(at: url); asked = true }
            guard Date() < deadline else {
                if status == .downloaded { return }
                throw CocoaError(.ubiquitousFileUnavailable)
            }
            try Task.checkCancellation()
            Thread.sleep(forTimeInterval: 0.25)
        }
    }
    private func access<T>(_ bookmark: Data, writing: Bool, work: (URL) throws -> T) throws -> T {
        var stale = false
        let folder = try URL(resolvingBookmarkData: bookmark, options: [.withoutUI], relativeTo: nil, bookmarkDataIsStale: &stale)
        guard !stale else { throw CocoaError(.fileReadNoPermission) }
        let accessed = folder.startAccessingSecurityScopedResource()
        defer { if accessed { folder.stopAccessingSecurityScopedResource() } }
        return try coordinated(folder, writing: writing, work: work)
    }
    func save(_ threads: [ChatThread], bookmark: Data, deviceID: String) throws {
        guard UUID(uuidString: deviceID) != nil else { throw CocoaError(.fileWriteInvalidFileName) }
        let names = try HistoryMerge.attachmentNames(in: threads)
        try access(bookmark, writing: true) { folder in
            let root = folder.appendingPathComponent(Self.folderName, isDirectory: true)
            let media = root.appendingPathComponent("Attachments", isDirectory: true)
            let device = root.appendingPathComponent(deviceID, isDirectory: true)
            try FileManager.default.createDirectory(at: media, withIntermediateDirectories: true)
            try FileManager.default.createDirectory(at: device, withIntermediateDirectories: true)
            for url in [root, media, device] { try requireDirectory(url) }
            for name in names {
                try Task.checkCancellation()
                guard let source = AttachmentStorage.url(name), FileManager.default.fileExists(atPath: source.path) else { throw CocoaError(.fileReadNoSuchFile) }
                let destination = media.appendingPathComponent(name)
                if !FileManager.default.fileExists(atPath: destination.path) {
                    try FileManager.default.copyItem(at: source, to: destination)
                }
                try requireFile(destination)
            }
            // Publish the archive only after all its referenced media exists.
            // Separate device snapshots prevent another device erasing history.
            try ChatArchive(fileURL: device.appendingPathComponent("conversations.json")).save(threads)
        }
    }
    func restore(bookmark: Data) throws -> [ChatThread] {
        try access(bookmark, writing: false) { folder in
            let current = folder.appendingPathComponent(Self.folderName, isDirectory: true)
            let hasCurrent = (try? current.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory == true
            let root = hasCurrent ? current : folder.appendingPathComponent(Self.earlierFolderName, isDirectory: true)
            try requireDirectory(root)
            let devices = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            var restored: [ChatThread] = []
            for device in devices where UUID(uuidString: device.lastPathComponent) != nil {
                let values = try device.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                guard values.isDirectory == true, values.isSymbolicLink != true else { continue }
                let file = device.appendingPathComponent("conversations.json")
                guard FileManager.default.fileExists(atPath: file.path) else { continue }
                try requireFile(file)
                let attrs = try FileManager.default.attributesOfItem(atPath: file.path)
                guard ((attrs[.size] as? NSNumber)?.intValue ?? Int.max) <= 32_000_000 else { throw CocoaError(.fileReadTooLarge) }
                restored = HistoryMerge.merge(local: restored, incoming: try ChatArchive(fileURL: file).load())
            }
            guard !restored.isEmpty else { throw CocoaError(.fileReadNoSuchFile) }
            let names = try HistoryMerge.attachmentNames(in: restored)
            let media = root.appendingPathComponent("Attachments", isDirectory: true)
            if !names.isEmpty { try requireDirectory(media) }
            try FileManager.default.createDirectory(at: AttachmentStorage.directory, withIntermediateDirectories: true)
            for name in names {
                try Task.checkCancellation()
                guard let destination = AttachmentStorage.url(name) else { throw CocoaError(.fileReadCorruptFile) }
                if FileManager.default.fileExists(atPath: destination.path) { continue }
                let source = media.appendingPathComponent(name)
                let values = try source.resourceValues(forKeys: [.isSymbolicLinkKey, .isRegularFileKey])
                guard values.isSymbolicLink != true, values.isRegularFile == true else { throw CocoaError(.fileReadCorruptFile) }
                try FileManager.default.copyItem(at: source, to: destination)
            }
            return restored
        }
    }
    private func requireDirectory(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
    }
    private func requireFile(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
    }
}

struct CloudHistoryCard: View {
    // The chats are read when a save is asked for, not observed: the store
    // publishes with every batch of a reply's text (1.1.0 (263); ChatPulse).
    @ObservedObject private var pulse = ChatPulse.shared
    @Environment(\.chatHandle) private var chatHandle
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var cloud = CloudHistoryStore.shared
    @State private var chooseFolder = false
    @State private var confirmRestore = false
    @State private var confirmEarlier = false

    private var threads: [ChatThread] { chatHandle.store?.threads ?? [] }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: Binding(get: { cloud.enabled }, set: { on in
                guard on else { cloud.disable(); return }
                Task {
                    if await cloud.turnOn() { await cloud.saveNow(threads) } else { chooseFolder = true }
                }
            })) {
                Text(cloud.offersPrivateCloud ? LocalizedStringKey("iCloudに会話を保存") : LocalizedStringKey("iCloud Driveに会話を保存"))
                    .contentTransition(.opacity)
            }.font(.headline).fieluaStateTint().accessibilityIdentifier("cloud-history-toggle")
            caption
            if cloud.enabled {
                // What the backup is and its buttons come in one piece.
                VStack(alignment: .leading, spacing: 12) {
                    Text("保存先: \(cloud.destinationName)").font(.caption)
                    if let date = cloud.lastSaved {
                        Text("最終書き込み: \(date.formatted(date: .abbreviated, time: .shortened))").font(.caption).foregroundStyle(.secondary)
                            .contentTransition(.opacity)
                            .transition(.opacity)
                    }
                    HStack(spacing: 20) {
                        Button("今すぐ保存") { Task { await cloud.saveNow(threads) } }.fieluaTextButton()
                        Button("履歴を復元") { confirmRestore = true }.fieluaTextButton()
                    }.font(.subheadline).disabled(cloud.busy || pulse.isGenerating)
                    if cloud.privateCloud {
                        earlierFolder
                    } else {
                        Button("保存先を変更") { chooseFolder = true }.font(.caption).fieluaTextButton().disabled(cloud.busy)
                    }
                }
                .transition(.opacity)
            }
            // The spinner beside what is being done, not on a line of its own.
            if cloud.busy || !cloud.status.isEmpty {
                HStack(spacing: 8) {
                    if cloud.busy { ProgressView().controlSize(.small).transition(.opacity) }
                    if !cloud.status.isEmpty {
                        Text(cloud.status).font(.caption).foregroundStyle(.secondary)
                            .contentTransition(.opacity)
                    }
                }
                .transition(.opacity)
            }
            if let error = cloud.error {
                Text(error).font(.caption).foregroundStyle(Theme.caution)
                    .transition(.opacity)
            }
        }.padding(18).fieluaCard(cornerRadius: 20)
            // What comes after the card is drawn (the check of iCloud, a
            // save's state and result) comes in softly; モデル管理 moves the
            // cards under it in the same motion (its `shape`).
            .animation(FieluaMotion.change(reduceMotion), value: cloud.layout)
            .task { if await cloud.checkPrivateCloud() { await cloud.saveNow(threads) } }
            .sheet(isPresented: $chooseFolder) {
                CloudFolderPicker { url in
                    chooseFolder = false
                    if let url { cloud.configure(url); Task { await cloud.saveNow(threads) } }
                }
            }
            .confirmationDialog("バックアップの会話を、今の会話に追加します。", isPresented: $confirmRestore, titleVisibility: .visible) {
                Button("履歴を復元") { restore { try await cloud.restore() } }
            }
            .confirmationDialog("前の保存先のバックアップの会話を、今の会話に追加します。", isPresented: $confirmEarlier, titleVisibility: .visible) {
                Button("前の保存先から復元") { restore { try await cloud.restoreEarlierFolder() } }
            }
    }

    /// What leaves the phone, and where to: the rest the buttons say.
    @ViewBuilder private var caption: some View {
        if cloud.offersPrivateCloud {
            // Hidden from the Files app is not a lock of its own (the
            // 1.1.0 (251) directive): say how it is kept and where it goes.
            Text("会話と添付を、Fielua 専用の iCloud の保存場所に自動でバックアップします。「ファイル」アプリには表示されません。")
                .font(.caption).foregroundStyle(.secondary)
            Text("表示されないだけで、守られ方は iCloud のほかのデータと同じです。iPhone の設定の iCloud ストレージから確認・削除できます。")
                .font(.caption).foregroundStyle(.secondary)
        } else {
            // The copies are in the folder chosen, which the Files app shows,
            // unlike the app's own conversations since 1.1.0 (251); Fielua
            // never deletes them.
            Text("会話と添付を、指定したフォルダに自動でバックアップします。バックアップは「ファイル」アプリから見えます。")
                .font(.caption).foregroundStyle(.secondary)
        }
    }

    /// The folder the backup went to before 1.1.0 (252): Fielua leaves its
    /// copies, which the Files app still shows, and can still read them.
    @ViewBuilder private var earlierFolder: some View {
        if let name = cloud.earlierFolderName {
            Text("前の保存先「\(name)」のコピーは残っていて、「ファイル」アプリから見えます。Fielua は削除しません。")
                .font(.caption).foregroundStyle(.secondary)
            Button("前の保存先から復元") { confirmEarlier = true }
                .font(.caption).fieluaTextButton().disabled(cloud.busy || pulse.isGenerating)
                .accessibilityIdentifier("cloud-history-restore-earlier")
        }
    }

    private func restore(_ read: @escaping () async throws -> [ChatThread]) {
        Task {
            do { chatHandle.store?.mergeBackup(try await read()) }
            catch { cloud.error = String(localized: "バックアップを読み込めませんでした。") + "\n" + error.localizedDescription }
        }
    }
}

private struct CloudFolderPicker: UIViewControllerRepresentable {
    let completion: (URL?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = false; picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let completion: (URL?) -> Void
        init(_ completion: @escaping (URL?) -> Void) { self.completion = completion }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { completion(urls.first) }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { completion(nil) }
    }
}
