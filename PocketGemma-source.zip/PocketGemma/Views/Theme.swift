import SwiftUI
import UIKit

/// Fielua's design tokens (brand 2026-10-27: 温かい紙のような背景 × 柔らかな黄色 ×
/// 5枚の花びら). Every screen takes its colours from here, so a new feature
/// looks like the rest without choosing any of its own. The rules behind
/// them are in design/FIELUA-DESIGN.md; the parts built from them
/// (cards, buttons, the mark) are in FieluaDesign.swift and FlowerMark.swift.
///
/// Light mode is warm paper: never pure white or grey. Dark mode is its own
/// design, warm charcoal with the same yellow, not an inversion.
///
/// Phase 2 (1.1.0 (214), user 2026-10-27: 「洗練・統一・引き算」): the yellow
/// is kept for the main action and what is chosen; icons, other buttons,
/// the person's own bubbles, the system tint and the gauges are warm
/// neutrals, and edges and shadows are quieter.
enum Theme {
    // MARK: Brand palette, as given (brand board, 2026-10-27)
    static let brandYellow = rgb(0xFACC3D)
    static let brandLight = rgb(0xFFE39A)
    static let brandPale = rgb(0xFFF6D8)
    static let brandCream = rgb(0xFAF7F1)
    static let brandTaupe = rgb(0x8E7D6A)

    // MARK: Surfaces
    /// The conversation's paper: the brand's cream; warm charcoal at night.
    static let chatBackground = adaptive(0xFAF7F1, 0x171512)
    /// The history sidebar under the conversation: a shade deeper than the
    /// paper so the slid conversation reads as a sheet on it (as ChatGPT's
    /// and the brand board's), and deeper still at night.
    static let sidebar = adaptive(0xF1EDE5, 0x0E0D0B)
    /// Pages with cards on them (onboarding, model pages): a little deeper
    /// than the paper so the cards stand out without lines.
    static let canvas = adaptive(0xF4F0E8, 0x121110)
    /// Cards, grouped rows and sheets' panels: warm white, raised charcoal.
    static let card = adaptive(0xFFFDF9, 0x221F1B)
    /// A card's hairline edge, barely there (1.1.0 (214)).
    static let cardStroke = adaptive(0xEEE8DE, 0x2A2622)
    static let inputBorder = adaptive(0xE2DACC, 0x3A352E)
    /// Laid over the conversation while it is slid aside, at
    /// `ChatMetrics.panelVeil`, so its bubbles, header blur and composer read
    /// as one quiet panel (measured from ChatGPT, warmed to the paper).
    static let panelVeil = adaptive(0xFAF7F1, 0x26231F)

    // MARK: Ink
    /// Text and line icons: warm near-black, warm off-white. The app's
    /// root sets it as the foreground, so .secondary and .tertiary follow.
    static let ink = adaptive(0x1F1C18, 0xF3EEE6)
    /// The wordmark and quiet decorative icons: the brand's taupe (3.7:1 on
    /// the paper, for large type and icons only), lighter at night.
    static let wordmark = adaptive(0x8E7D6A, 0xD9CDBD)
    static let taupe = adaptive(0x8E7D6A, 0xA39582)
    /// Line icons in lists and quiet glyphs: a warm grey (5.6:1 on the
    /// card), not gold (1.1.0 (214)).
    static let icon = adaptive(0x6F655A, 0xB3A898)
    /// The composer's 「メッセージ」 before anything is typed: a warm grey
    /// that still reads (3.2:1; iOS's placeholder grey read at 1.8:1 on the
    /// paper).
    static let placeholder = adaptive(0x948A7E, 0x8C8276)
    // MARK: Yellow, only for the main action and what is chosen
    /// Fills that mark the main action: send, new chat, a page's main
    /// button, a chosen option's check.
    static let accent = rgb(0xFACC3D)
    /// Text and glyphs on `accent` (9:1).
    static let onAccent = rgb(0x2B2108)
    /// The system tint (switch tracks, menu checks, text buttons, the
    /// caret, the bars' glass buttons): a warm umber, neutral but still a
    /// colour (7:1 on the paper); a light warm grey at night. Honey until
    /// 1.1.0 (214).
    static let tint = adaptive(0x5C5045, 0xD6CABA)
    /// A state that is on and matters (ウェブ検索 on in the composer): the
    /// deep honey that was the tint, kept for this (3:1 on the paper).
    static let active = adaptive(0xB38600, 0xE8B931)
    /// The open chat in the sidebar and a pressed row: a warm grey wash
    /// (pale yellow until 1.1.0 (214)).
    static let selection = adaptive(0xE3DCCF, 0x34302A)
    /// Links inside replies: underlined in a deep amber that reads as text
    /// (5:1 on the paper).
    static let link = adaptive(0x8C6400, 0xF5CD5A)
    /// The send button with nothing to send: a quiet warm circle.
    static let sendIdle = adaptive(0xE4DCCF, 0x3A352E)
    static let sendIdleGlyph = adaptive(0xFFFDF9, 0x8A8073)
    /// The person's own messages: warm grey paper with ink, and a warm
    /// charcoal at night (light yellow until 1.1.0 (214)).
    static let outgoing = adaptive(0xEDE7DC, 0x2D2925)
    static let onOutgoing = adaptive(0x1F1C18, 0xF7F0E2)
    /// Unused since replies are flat; kept for older layouts.
    static let incoming = adaptive(0xEDE7DC, 0x2A2622)

    // Markdown in replies, on the conversation's paper.
    static let inlineCode = adaptive(UIColor(red: 0.42, green: 0.33, blue: 0.20, alpha: 0.09),
                                     UIColor(red: 1, green: 0.94, blue: 0.82, alpha: 0.12))
    static let codeBackground = adaptive(0xF3EEE4, 0x100F0D)
    static let codeHeader = adaptive(0xEAE3D6, 0x1D1A17)
    static let quoteBar = adaptive(0xD9C9A6, 0x5C5244)
    static let tableHeader = adaptive(UIColor(red: 0.42, green: 0.33, blue: 0.20, alpha: 0.06),
                                      UIColor(red: 1, green: 0.94, blue: 0.82, alpha: 0.07))
    static let markdownLine = adaptive(0xE2DACC, 0x38332C)
    /// The composer's pills (高速, the model): a quiet warm fill in the panel.
    static let chipFill = adaptive(UIColor(red: 0.42, green: 0.33, blue: 0.20, alpha: 0.07),
                                   UIColor(red: 1, green: 0.94, blue: 0.82, alpha: 0.08))
    /// A test version's 「テスト版」 and its note (1.1.0 (204)): a burnt
    /// orange that reads as a warning on paper (4.8:1), lighter at night.
    static let caution = adaptive(UIColor(red: 0.70, green: 0.35, blue: 0, alpha: 1), .systemOrange)

    static func adaptive(light: UIColor, dark: UIColor) -> Color {
        Color(uiColor: UIColor { $0.userInterfaceStyle == .dark ? dark : light })
    }
    static func adaptive(_ light: UIColor, _ dark: UIColor) -> Color { adaptive(light: light, dark: dark) }
    static func adaptive(_ light: UInt32, _ dark: UInt32) -> Color {
        adaptive(light: uiColor(light), dark: uiColor(dark))
    }
    static func rgb(_ hex: UInt32) -> Color { Color(uiColor: uiColor(hex)) }
    static func uiColor(_ hex: UInt32) -> UIColor {
        UIColor(red: CGFloat((hex >> 16) & 0xFF) / 255, green: CGFloat((hex >> 8) & 0xFF) / 255,
                blue: CGFloat(hex & 0xFF) / 255, alpha: 1)
    }
}

enum ChatMetrics {
    static let control: CGFloat = 44
    static let icon: CGFloat = 20
    static let gutter: CGFloat = 12
    static let controlGap: CGFloat = 12
    static let jumpGap: CGFloat = 24
    /// The composer's two-row glass panel: text above, the plus menu and
    /// send below. From the user's reference image (2026-10-20, a 378pt
    /// panel): corners about 22pt, text 15pt in, the lower row's centers
    /// 30pt above the bottom edge.
    static let composerRadius: CGFloat = 22
    static let composerTextInset: CGFloat = 15
    /// One line of text at rest, right above the buttons, so the panel is
    /// 100pt tall; each further line adds its own height (user, 2026-10-21:
    /// the reference's room for two lines read as a gap on the phone).
    static let composerTextMinHeight: CGFloat = 44
    /// The lower row's side and bottom inset: the plus and send, centered
    /// in 44pt targets, sit 30pt in from their edges.
    static let composerRowInset: CGFloat = 8
    static let sendButton: CGFloat = 34
    /// The composer's plus circle and pills (高速, the model), 36pt tall
    /// and `chipGap` apart. A menu answers only within its own bounds, so
    /// this is their target too (32pt until 1.0.115, on 44pt targets).
    static let chip: CGFloat = 36
    static let chipGap: CGFloat = 8
    /// The three glass buttons the panel splits into while older messages
    /// are read, `morphGap` apart at rest.
    static let morphButton: CGFloat = 48
    static let morphGap: CGFloat = jumpGap
    /// The composer's glass container spacing: glass shapes nearer than
    /// this fuse. Below the buttons' gap, so while they part the bridges
    /// between them snap before they reach their places, and at rest
    /// they (and the jump control above the panel) stand clearly apart.
    static let composerBlend: CGFloat = 18
    /// 従来型's field and what rises out of it (the pills' drops, the jump
    /// control) fuse nearer than this. Below the pills' gaps (12pt to the
    /// field, `chipGap` to each other), so a drop's bridge to the field
    /// snaps before it reaches its place and the pills rest apart.
    static let classicBlend: CGFloat = 6
    /// A finger-driven scroll this far toward older messages, with the end
    /// at least `collapseDistance` below the screen, folds the composer.
    static let collapseTravel: CGFloat = 56
    static let collapseDistance: CGFloat = 96
    /// Glass container spacing for the plus menu morph.
    static let menuMergeSpacing: CGFloat = 8
    /// Corners of the conversation while it is slid aside for the sidebar,
    /// within the display's own corner so they appear as it starts moving.
    static let panelRadius: CGFloat = 55
    static let panelVeil: CGFloat = 0.55
    /// The slid panel's shadow on the sidebar, as in ChatGPT.
    static let panelShadow = Color.black.opacity(0.12)
    static let panelShadowRadius: CGFloat = 18
    /// Space between the field and the compact photo sheet, as in Messages
    /// (21pt, measured from a Messages screenshot).
    static let photoSheetGap: CGFloat = 21
    /// The photo picker's done check, as tall as the picker's segmented
    /// control beside it, as in Messages.
    static let photoDone: CGFloat = 48
    /// The center of the picker's segmented row below the full-height
    /// sheet's top (measured on device, 1.0.48).
    static let photoDoneRowCenter: CGFloat = 71
    static let bubbleVertical: CGFloat = 7
    static let bubbleInset: CGFloat = 12
    static let bubbleTailInset: CGFloat = 18
    /// A reply's text sits 16pt from the screen's edges, past the 12pt
    /// gutter, as in ChatGPT (measured from a ChatGPT screenshot).
    static let replyInset: CGFloat = 4
    static let messageFont = Font.callout
    /// Replies read at 17pt like ChatGPT's; sent bubbles stay at 16pt.
    static let replyFont = Font.body
}

/// A real backdrop material, feathered into the conversation. It is separate
/// from Liquid Glass controls so neither text nor controls are blurred.
struct ChatChromeBackdrop: View {
    let edge: VerticalEdge
    /// The chat's header blurs at 0.96 all the time; 設定 fades it in as its
    /// list scrolls under the bar.
    var strength: CGFloat = 0.96
    /// The chat's reaches past the safe area to the screen's edge; in a
    /// sheet it stops at the sheet's own top.
    var reachesScreenEdge = true
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    var body: some View {
        // Use the bar's layout size rather than asking the UIKit container
        // to measure its effect subview, which extends beyond those bounds.
        GeometryReader { bar in
            if reduceTransparency { Theme.chatBackground.opacity(min(strength / 0.96, 1)) }
            else {
            NativeChromeBlur(edge: edge,
                             // 30pt below the header (52 until 1.0.50 spread
                             // the blur too far into the conversation).
                             feather: 30,
                             style: colorScheme == .dark ? .systemUltraThinMaterialDark : .systemUltraThinMaterialLight,
                             strength: strength, reachesScreenEdge: reachesScreenEdge)
                .frame(width: bar.size.width, height: bar.size.height)
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// Mask the native effect view itself. A SwiftUI mask can flatten a material
/// into a tinted layer instead of sampling and blurring the live conversation.
private struct NativeChromeBlur: UIViewRepresentable {
    let edge: VerticalEdge
    let feather: CGFloat
    let style: UIBlurEffect.Style
    let strength: CGFloat
    let reachesScreenEdge: Bool
    func makeUIView(context: Context) -> ChromeBlurContainer {
        let view = ChromeBlurContainer()
        view.isUserInteractionEnabled = false
        view.configure(style: style, strength: strength)
        return view
    }
    func updateUIView(_ view: ChromeBlurContainer, context: Context) {
        view.configure(style: style, strength: strength)
        guard view.edge != edge || view.feather != feather || view.reachesScreenEdge != reachesScreenEdge else { return }
        view.edge = edge
        view.feather = feather
        view.reachesScreenEdge = reachesScreenEdge
        view.setNeedsLayout()
    }
}

/// Window insets stay correct after SwiftUI has consumed the bar's safe area.
/// Position the effect as a native subview so its extended area is preserved.
private final class ChromeBlurContainer: UIView {
    var edge: VerticalEdge = .top
    var feather: CGFloat = 32
    var reachesScreenEdge = true
    private let blur = ChromeBlurView(effect: nil)

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private func setup() {
        isOpaque = false
        clipsToBounds = false
        blur.isUserInteractionEnabled = false
        addSubview(blur)
    }
    func configure(style: UIBlurEffect.Style, strength: CGFloat) {
        blur.configure(style: style, strength: strength)
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        setNeedsLayout()
    }
    override func safeAreaInsetsDidChange() {
        super.safeAreaInsetsDidChange()
        setNeedsLayout()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        let insets = window?.safeAreaInsets ?? safeAreaInsets
        let extensionHeight = reachesScreenEdge ? (edge == .top ? insets.top : insets.bottom) : 0
        let frame = CGRect(x: 0, y: edge == .top ? -extensionHeight : -feather,
                           width: bounds.width, height: bounds.height + extensionHeight + feather)
        // Effect views can invalidate their parent while relaying out. Avoid
        // scheduling another effect layout when its geometry is unchanged.
        guard blur.frame != frame || blur.edge != edge || blur.feather != feather else { return }
        blur.edge = edge
        blur.feather = feather
        blur.frame = frame
        blur.setNeedsLayout()
    }
}

private final class ChromeBlurView: UIVisualEffectView {
    var edge: VerticalEdge = .top
    var feather: CGFloat = 32
    private let gradientMask = ChromeGradientMask()
    private var maskedBounds = CGRect.zero
    private var maskedEdge: VerticalEdge = .top
    private var maskedFeather: CGFloat = -1
    private var strength: CGFloat = 1
    private var maskedStrength: CGFloat = -1
    private var appliedStyle: UIBlurEffect.Style?

    func configure(style: UIBlurEffect.Style, strength: CGFloat) {
        // UIKit forwards this view's mask to its native effect layers. Blend
        // a lighter material with the readable backdrop while keeping
        // the effect view and its ancestors at alpha 1 and free of animators.
        if appliedStyle != style {
            appliedStyle = style
            effect = UIBlurEffect(style: style)
            maskedStrength = -1
            setNeedsLayout()
        }
        let strength = min(1, max(0, strength))
        if self.strength != strength {
            self.strength = strength
            setNeedsLayout()
        }
        // Fully faded (設定 at the top of a page) the effect stops sampling
        // the pages sliding beneath it.
        isHidden = strength == 0
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard bounds != maskedBounds || edge != maskedEdge || feather != maskedFeather
                || strength != maskedStrength else { return }
        maskedBounds = bounds
        maskedEdge = edge
        maskedFeather = feather
        maskedStrength = strength
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradientMask.frame = bounds
        let gradient = gradientMask.layer as! CAGradientLayer
        let peak = UIColor.black.withAlphaComponent(strength).cgColor
        gradient.colors = [peak, UIColor.black.withAlphaComponent(0.92 * strength).cgColor,
                           UIColor.black.withAlphaComponent(0.42 * strength).cgColor,
                           UIColor.clear.cgColor]
        // Fade throughout the header; a flat plateau followed by an 18pt fade
        // looked like a visible horizontal boundary on both color schemes.
        gradient.locations = [0, 0.48, 0.78, 1]
        gradient.startPoint = CGPoint(x: 0.5, y: edge == .top ? 0 : 1)
        gradient.endPoint = CGPoint(x: 0.5, y: edge == .top ? 1 : 0)
        // UIKit copies an effect view's mask. Reapply it when the size changes,
        // with the values recorded above to avoid recursive layout updates.
        mask = nil
        mask = gradientMask
        CATransaction.commit()
    }
}

private final class ChromeGradientMask: UIView {
    override class var layerClass: AnyClass { CAGradientLayer.self }
}

struct GemmaMark: View {
    var size: CGFloat = 40
    var letter = "G"
    var body: some View {
        Text(letter)
            .font(.system(size: size * 0.50, weight: .medium, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: [Color(uiColor: .systemGray3), Color(uiColor: .systemGray)],
                                       startPoint: .top, endPoint: .bottom), in: Circle())
            .accessibilityHidden(true)
    }
}

/// Use Apple's glass material on iOS 26 and a native material on older iOS.
struct ChatGlassSurface<S: Shape>: ViewModifier {
    var shape: S
    var interactive: Bool
    /// Inside a glass container an opacity around the glass does not hide
    /// it (UI check 39450890021), so a surface that must vanish turns its
    /// glass off instead.
    var visible = true
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(visible ? .regular.interactive(interactive) : .identity, in: shape)
        } else if visible {
            content.background(.regularMaterial, in: shape)
                .overlay { shape.stroke(Theme.inputBorder.opacity(0.4), lineWidth: 0.5) }
        } else {
            content
        }
    }
}

struct ChatGlassGroup<Content: View>: View {
    private let spacing: CGFloat
    private let content: Content

    init(spacing: CGFloat = 6, @ViewBuilder content: () -> Content) {
        self.spacing = spacing
        self.content = content()
    }

    @ViewBuilder var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: spacing) { content }
        } else {
            content
        }
    }
}

/// The plus menu's button: the system glass circle on iOS 26, so the menu
/// can morph out of it; a material circle on older systems.
struct GlassCircleControl: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.buttonStyle(.glass).buttonBorderShape(.circle).controlSize(.regular)
        } else {
            content.frame(width: ChatMetrics.control, height: ChatMetrics.control)
                .contentShape(Circle()).chatGlass(in: Circle())
        }
    }
}

/// A composer menu's button: its label in a glass shape with a quiet fill.
/// The plus is a circle, the pills capsules. As the Menu's button style,
/// the glass is the button's own, standing on its own over the panel: the
/// system menu grows out of it and shrinks back into it, and it answers a
/// touch like other glass buttons. A smaller drop of glass at the center
/// (1.0.114) showed on the phone as a stray ring behind the label.
///
/// The button is exactly its shape. On the phone (iOS 27.2, 1.0.115) a
/// second glass outline showed around each one, the size of the 44pt
/// target the style then also laid out, as if the system gave the menu's
/// button a glass of its own bounds (the simulator, iOS 26, shows none).
/// So the bounds, the menu's source shape and the glass are one shape
/// now. A content shape past the bounds does not reach a menu (UI check,
/// 2026-10-21), so the shape is a little larger instead (ChatMetrics.chip).
struct ComposerChipStyle<S: Shape>: ButtonStyle {
    let glass: Bool
    var shape: S
    var width: CGFloat? = nil
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(.primary)
            .padding(.horizontal, width == nil ? 12 : 0)
            .frame(width: width, height: ChatMetrics.chip)
            .background(shape.fill(Theme.chipFill))
            .chatGlass(in: shape, interactive: true, visible: glass)
            .contentShape(.interaction, Rectangle())
            .contentShape(.contextMenuPreview, shape)
            .contentShape(.hoverEffect, shape)
    }
}

/// A composer menu's label and the Menu itself: the button style above with
/// room around it (`chipGap` between the pills, the plus in the 44pt
/// column that keeps it 30pt in from the panel's edge), or (`inLabel`) the
/// 1.0.114 label with its glass inside the label.
struct ComposerChipButton<S: Shape>: ViewModifier {
    let inStyle: Bool
    let glass: Bool
    var shape: S
    var width: CGFloat? = nil
    @ViewBuilder func body(content: Content) -> some View {
        if inStyle {
            content.buttonStyle(ComposerChipStyle(glass: glass, shape: shape, width: width))
                .padding(.horizontal, ChatMetrics.chipGap / 2)
                .frame(minWidth: ChatMetrics.control, minHeight: ChatMetrics.control)
        } else { content }
    }
}

struct ComposerChipLabel<S: Shape>: ViewModifier {
    let inLabel: Bool
    let glass: Bool
    var shape: S
    var width: CGFloat? = nil
    @ViewBuilder func body(content: Content) -> some View {
        if inLabel {
            content.modifier(ComposerChip(glass: glass, shape: shape, width: width))
                .frame(minWidth: ChatMetrics.control, minHeight: ChatMetrics.control)
                .contentShape(Rectangle())
        } else { content }
    }
}

/// The 1.0.114 label, glass inside the label and the row inside the
/// panel's glass; only for the UI check's comparison (`--menus-in-panel`).
struct ComposerChip<S: Shape>: ViewModifier {
    let glass: Bool
    var shape: S
    var width: CGFloat? = nil
    func body(content: Content) -> some View {
        content
            .foregroundStyle(.primary)
            .padding(.horizontal, width == nil ? 11 : 0)
            .frame(width: width, height: ChatMetrics.chip)
            .background(shape.fill(Theme.chipFill))
            .chatGlass(in: shape, visible: glass)
            .padding(.horizontal, ChatMetrics.chipGap / 2)
            .frame(height: ChatMetrics.control)
            .contentShape(Rectangle())
    }
}

/// Accent-tinted glass for a primary action, like Messages' done check.
/// Drawn on a fixed-size label so the shape keeps its exact size.
struct ProminentGlass<S: Shape>: ViewModifier {
    var shape: S
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.tint(Theme.accent).interactive(), in: shape)
        } else {
            content.background(Theme.accent, in: shape)
        }
    }
}

/// The sidebar button's two lines, the upper one longer, as in ChatGPT.
struct SidebarGlyph: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Capsule().frame(width: 19, height: 2.2)
            Capsule().frame(width: 12, height: 2.2)
        }
        .foregroundStyle(.primary)
        .frame(width: 30, height: 30)
    }
}

/// A system glass capsule button (iOS 26) for short status actions.
struct GlassCapsuleControl: ViewModifier {
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.buttonStyle(.glass).buttonBorderShape(.capsule).controlSize(.regular)
        } else {
            content.buttonStyle(.plain).padding(.horizontal, 12).padding(.vertical, 8)
                .chatGlass(in: Capsule())
        }
    }
}

/// Let the native button style own touch feedback and the hit target.
struct ChatCircleButton<Label: View>: View {
    private let action: () -> Void
    private let label: Label
    init(action: @escaping () -> Void, @ViewBuilder label: () -> Label) {
        self.action = action
        self.label = label()
    }
    @ViewBuilder var body: some View {
        if #available(iOS 26.0, *) {
            // The regular style adds its own padding. A 30pt label layout
            // produces a 44pt glass circle; the symbol itself remains 20pt.
            Button(action: action) { label.frame(width: 30, height: 30) }
                .buttonStyle(.glass).buttonBorderShape(.circle).controlSize(.regular)
                .frame(width: ChatMetrics.control, height: ChatMetrics.control)
        } else {
            Button(action: action) {
                label.frame(width: ChatMetrics.control, height: ChatMetrics.control).contentShape(Circle())
                    .chatGlass(in: Circle())
            }
            .buttonStyle(.plain)
        }
    }
}

extension View {
    /// Bars reserve reading space. The chrome owns its feathered backdrop.
    @ViewBuilder func chatBars<Top: View, Bottom: View>(@ViewBuilder top: () -> Top,
                                                       @ViewBuilder bottom: () -> Bottom) -> some View {
        // The bottom is a safe-area *bar*: unlike safeAreaInset it extends the
        // scroll view's edge effect under the composer, so the conversation
        // softly blurs behind the transparent glass controls (iOS 26).
        self.safeAreaInset(edge: .top, spacing: 0, content: top)
            .safeAreaBar(edge: .bottom, spacing: 0, content: bottom)
    }

    @ViewBuilder func chatScrollEdges(customChrome: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            // Keep the scroll viewport clipped. Disabling clipping also let
            // row text paint over the status bar and the composer.
            // The header draws its own feathered backdrop; the composer
            // relies on the system's soft bottom edge effect.
            if customChrome {
                self.scrollEdgeEffectHidden(true, for: .top)
                    .scrollEdgeEffectStyle(.soft, for: .bottom)
            }
            else { self.scrollEdgeEffectStyle(.soft, for: .top) }
        } else { self }
    }

    @ViewBuilder func chatGlassIdentity(_ id: String, in namespace: Namespace.ID,
                                       reduceMotion: Bool = false) -> some View {
        if #available(iOS 26.0, *) {
            self.glassEffectID(id, in: namespace)
                .glassEffectTransition(reduceMotion ? .identity : .matchedGeometry)
        } else { self }
    }

    func chatGlass<S: Shape>(in shape: S, interactive: Bool = false, visible: Bool = true) -> some View {
        modifier(ChatGlassSurface(shape: shape, interactive: interactive, visible: visible))
    }

    @ViewBuilder func chatChromeBackground() -> some View {
        if #available(iOS 26.0, *) { self }
        else { background(.ultraThinMaterial) }
    }
}

