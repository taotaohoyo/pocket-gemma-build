import SwiftUI
import UIKit

/// A series' mark in the app as one picture (1.1.0 (291), the directive of
/// 2026-11-16 on how 設定's pages slide): SeriesMark drawn once for each size,
/// light or dark and contrast, at the screen's scale, and kept for the
/// visit. The drawing is the same, pixel for pixel at that scale.
///
/// Gemma's mark is 19 shapes, 14 of them clipped by another, Qwen's 5 and
/// LFM's 6. Drawn as shapes, every one was a view of its own to make each
/// time モデル管理 or a series' page came in (three marks on モデル管理, one on
/// each card of a series' page), and every clip a mask the screen drew
/// apart at each frame of a slide. The sampled main thread spent モデル管理's
/// and Gemma's page's first frames in SwiftUI's own updates of the page's
/// views (UI check settings-profile, run 43936772156), and the series' page
/// first in was the slowest slide to start (earlier runs: one frame of
/// 400 ms). As one picture each mark is one view and one layer.
///
/// The download's Live Activity keeps SeriesMark (this file is the app's
/// alone). `--series-mark-layers` (preview only) draws the shapes as
/// before, for the UI check's before and after.
struct SeriesMarkTile: View {
    let series: ModelSeries
    var size: CGFloat = 32
    @Environment(\.colorScheme) private var scheme
    @Environment(\.colorSchemeContrast) private var contrast
    @Environment(\.displayScale) private var scale

    var body: some View {
        if !Self.drawsShapes, let picture = SeriesMarkPictures.picture(series, size: size, dark: scheme == .dark,
                                                                       strong: contrast == .increased, scale: scale) {
            Image(uiImage: picture)
                .resizable()
                .frame(width: size, height: size)
                .accessibilityHidden(true)
        } else {
            SeriesMark(series: series, size: size)
        }
    }

    private static let drawsShapes: Bool = {
        #if POCKET_PREVIEW
        return PreviewProbe.on("--series-mark-layers")
        #else
        return false
        #endif
    }()
}

/// The marks drawn so far in this visit, by series, size, appearance and
/// scale: a handful of small pictures.
@MainActor private enum SeriesMarkPictures {
    struct Key: Hashable {
        let series: ModelSeries
        let size: CGFloat
        let dark: Bool
        let strong: Bool
        let scale: CGFloat
    }

    private static var pictures: [Key: UIImage] = [:]

    static func picture(_ series: ModelSeries, size: CGFloat, dark: Bool, strong: Bool, scale: CGFloat) -> UIImage? {
        let key = Key(series: series, size: size, dark: dark, strong: strong, scale: scale)
        if let picture = pictures[key] { return picture }
        let renderer = ImageRenderer(content: SeriesMark(series: series, size: size, dark: dark, strong: strong))
        renderer.scale = scale
        renderer.isOpaque = false
        guard let picture = renderer.uiImage else { return nil }
        pictures[key] = picture
        return picture
    }
}
