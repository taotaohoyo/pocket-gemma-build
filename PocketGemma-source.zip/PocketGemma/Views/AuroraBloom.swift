import CoreHaptics
import SwiftUI

/// Aurora Bloom (user, 2026-10-25 09:46 UTC, 「Fielua — Aurora Bloom 起動演出の
/// 実装」): ようこそ's light is born small, grows as its colours mix, opens
/// out to its full size with its glow spreading a little and settles into
/// its breath, in about two seconds, and is felt in the hand as it grows
/// (BloomHaptics). The light, the wordmark and the haptics all read this one
/// timeline, in seconds from the light's first frame, so they keep together.
enum AuroraBloom {
    /// From the first light to its full size.
    static let duration: TimeInterval = 2.0
    /// Its size when it is born: about 9pt of the light's 129pt.
    static let seed = 0.07
    /// How long it stays that small before it grows.
    static let hold: TimeInterval = 0.15
    /// When the wordmark's first letter comes in: the light is nine tenths
    /// grown.
    static let wordmark: TimeInterval = 1.5
    /// When the line under the wordmark fades in.
    static let caption: TimeInterval = 2.2

    /// The light's size, 1 = full: slow to start, no overshoot, and at rest
    /// when it reaches its size, where the slow breath of 4% takes over.
    static func size(at time: TimeInterval) -> Double {
        if time >= duration { return 0.98 + 0.02 * cos(2 * .pi * (time - duration) / 6) }
        return seed + (1 - seed) * growth(at: time)
    }

    /// How far it has grown, 0 to 1.
    static func growth(at time: TimeInterval) -> Double {
        let x = min(max((time - hold) / (duration - hold), 0), 1)
        return x * x * x * (x * (x * 6 - 15) + 10)
    }

    /// When it reaches a size on its way up.
    static func time(atSize target: Double) -> TimeInterval {
        var low = 0.0, high = duration
        for _ in 0..<40 {
            let middle = (low + high) / 2
            if size(at: middle) < target { low = middle } else { high = middle }
        }
        return high
    }

    static func opacity(at time: TimeInterval) -> Double { smooth(time / 0.45) }

    /// The shader's time: the colours flow up to 1.75 times as fast while
    /// the light grows, at their own pace before and after.
    static func flow(at time: TimeInterval) -> Double { time + smooth(time / duration) }

    /// The glow around the light, 1 = as always: a third more, reaching a
    /// third further, as it opens, and back over the next second.
    static func glow(at time: TimeInterval) -> Double {
        let away = (time - 1.85) / 0.45
        return 1 + 0.35 * exp(-away * away)
    }

    /// Seconds on the bloom's timeline since its start.
    static func age(since start: Date, at date: Date = .now) -> TimeInterval {
        date.timeIntervalSince(start) / pace
    }

    /// The seconds it takes to reach a time on the bloom's timeline.
    static func span(_ time: TimeInterval) -> TimeInterval { time * pace }

    #if POCKET_PREVIEW
    /// UI tests: XCUIApplication waits for the app to settle before each
    /// launch, query and touch, which it does not while the light moves.
    /// --bloom-delay holds the bloom back until a launch has settled, and
    /// --slow-bloom plays it four times as slow, so a touch lands part-way.
    private static let pace: Double = ProcessInfo.processInfo.arguments.contains("--slow-bloom") ? 4 : 1

    static func previewDelay() async {
        guard ProcessInfo.processInfo.arguments.contains("--bloom-delay") else { return }
        // 5 s was too short once on a busy runner (run 40191910506).
        try? await Task.sleep(for: .seconds(8))
    }
    #else
    private static let pace: Double = 1
    #endif

    private static func smooth(_ x: Double) -> Double {
        let x = min(max(x, 0), 1)
        return x * x * (3 - 2 * x)
    }
}

/// Aurora Bloom's haptics (Core Haptics), on the light's timeline: a faint
/// tap as it is born, a soft swell that grows with it and three light taps
/// a quarter, a half and three quarters of the way, a soft tap as it opens
/// with an afterglow that fades. With Reduce Motion, where the light is
/// there at once, one soft tap with its afterglow. Only the ようこそ screen
/// plays them, once: 続ける, leaving the screen or Fielua becoming inactive
/// stops what has not played, and nothing starts again. Phones without
/// haptics, or with vibration turned off, play nothing and the light is
/// the same.
@Observable @MainActor final class BloomHaptics {
    enum Kind { case bloom, still }

    private struct Beat {
        var time: TimeInterval
        /// 0 for a tap.
        var duration: TimeInterval = 0
        var intensity: Float
        var sharpness: Float
        /// The strength over the beat's own time, 0 to 1.
        var envelope: ((TimeInterval) -> Double)?
    }

    @ObservationIgnored private var engine: CHHapticEngine?
    @ObservationIgnored private var ready = false
    @ObservationIgnored private var players: [CHHapticPatternPlayer] = []
    @ObservationIgnored private var beats: [Beat] = []
    @ObservationIgnored private var kind = Kind.bloom
    @ObservationIgnored private var began: Date?
    @ObservationIgnored private var done = false
    @ObservationIgnored private var ending: Task<Void, Never>?
    /// What happened, for the UI tests (preview builds show it).
    private(set) var trace = "waiting"

    private static var supported: Bool { CHHapticEngine.capabilitiesForHardware().supportsHaptics }

    /// Starts the haptic engine while the light's shader compiles, so the
    /// first beat is on time.
    func prepare() {
        guard engine == nil, !done, Self.supported, let engine = try? CHHapticEngine() else { return }
        engine.playsHapticsOnly = true
        engine.isAutoShutdownEnabled = false
        let id = ObjectIdentifier(engine)
        engine.stoppedHandler = { [weak self] _ in Task { @MainActor in self?.engineStopped(id) } }
        engine.resetHandler = { [weak self] in Task { @MainActor in self?.engineStopped(id) } }
        self.engine = engine
        engine.start { [weak self] error in
            Task { @MainActor in
                guard let self, error == nil, self.engine === engine else { return }
                self.ready = true
                self.startPlayers()
            }
        }
    }

    /// iOS stopped the engine (Fielua left the screen, or another app took
    /// the haptics). Before the light has begun, it is started again with
    /// it; after, what was left does not come back.
    private func engineStopped(_ stopped: ObjectIdentifier) {
        guard let current = engine, ObjectIdentifier(current) == stopped else { return }
        if began == nil {
            engine = nil
            ready = false
        } else {
            stop("system")
        }
    }

    /// The light's first frame: the beats start with it.
    func play(_ kind: Kind) {
        guard !done, began == nil else { return }
        self.kind = kind
        beats = Self.beats(kind)
        began = .now
        trace = "\(kind) began, \(beats.count) beats" + (Self.supported ? "" : " (no haptics here)")
        startPlayers()
        let length = beats.map { $0.time + $0.duration }.max() ?? 0
        ending = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(AuroraBloom.span(length) + 0.1)) } catch { return }
            self?.finish()
        }
    }

    /// Stops what has not played yet, for good.
    func stop(_ reason: String) {
        guard !done else { return }
        done = true
        ending?.cancel()
        halt()
        if let began {
            let at = AuroraBloom.age(since: began)
            let played = beats.filter { $0.time <= at }.count
            trace = String(format: "\(kind) stopped (\(reason)) at %.2f s, played \(played) of \(beats.count)", at)
        } else {
            trace = "\(kind) stopped (\(reason)) before it began"
        }
    }

    private func finish() {
        guard !done else { return }
        done = true
        halt()
        trace = "\(kind) finished, played \(beats.count) of \(beats.count)"
    }

    private func halt() {
        for player in players { try? player.stop(atTime: CHHapticTimeImmediate) }
        players = []
        engine?.stop(completionHandler: nil)
        engine = nil
    }

    /// Once the engine is running and the light has begun, from where the
    /// light is: an engine that started late skips what has passed.
    private func startPlayers() {
        guard ready, !done, players.isEmpty, let engine, let began else { return }
        let offset = AuroraBloom.age(since: began)
        // Each beat with a changing strength has its own player: an
        // intensity curve acts on everything its player plays.
        let groups = [beats.filter { $0.envelope == nil }] + beats.filter { $0.envelope != nil }.map { [$0] }
        let at = engine.currentTime + 0.01
        for group in groups {
            guard let pattern = try? Self.pattern(group, from: offset),
                  let player = try? engine.makePlayer(with: pattern) else { continue }
            try? player.start(atTime: at)
            players.append(player)
        }
    }

    private static func beats(_ kind: Kind) -> [Beat] {
        let fade: (TimeInterval) -> (TimeInterval) -> Double = { length in { t in pow(max(1 - t / length, 0), 2) } }
        switch kind {
        case .still:
            return [Beat(time: 0.02, intensity: 0.3, sharpness: 0.12),
                    Beat(time: 0.02, duration: 0.4, intensity: 0.16, sharpness: 0.04, envelope: fade(0.4))]
        case .bloom:
            // The growth about twice as strong as in 1.1.0 (178), which was
            // hard to feel on the phone (user, 2026-10-25 11:29 UTC); the
            // birth stays faint and the opening the strongest.
            let swell = 0.35, open = AuroraBloom.time(atSize: 0.985)
            return [Beat(time: 0.06, intensity: 0.18, sharpness: 0.1),
                    Beat(time: swell, duration: open - swell, intensity: 0.5, sharpness: 0.14,
                         envelope: { t in 0.35 + 0.65 * AuroraBloom.growth(at: swell + t) }),
                    Beat(time: AuroraBloom.time(atSize: 0.28), intensity: 0.42, sharpness: 0.26),
                    Beat(time: AuroraBloom.time(atSize: 0.52), intensity: 0.5, sharpness: 0.28),
                    Beat(time: AuroraBloom.time(atSize: 0.76), intensity: 0.58, sharpness: 0.3),
                    Beat(time: open, intensity: 0.66, sharpness: 0.26),
                    Beat(time: open, duration: 0.7, intensity: 0.34, sharpness: 0.06, envelope: fade(0.7))]
        }
    }

    /// The beats from a time on the light's timeline, in the engine's
    /// seconds.
    private static func pattern(_ beats: [Beat], from offset: TimeInterval) throws -> CHHapticPattern? {
        let span = AuroraBloom.span
        var events: [CHHapticEvent] = []
        var curves: [CHHapticParameterCurve] = []
        for beat in beats {
            let parameters = [CHHapticEventParameter(parameterID: .hapticIntensity, value: beat.intensity),
                              CHHapticEventParameter(parameterID: .hapticSharpness, value: beat.sharpness)]
            if beat.duration == 0 {
                guard beat.time >= offset else { continue }
                events.append(CHHapticEvent(eventType: .hapticTransient, parameters: parameters,
                                            relativeTime: span(beat.time - offset)))
                continue
            }
            let start = max(beat.time, offset), end = beat.time + beat.duration
            guard end - start > 0.05 else { continue }
            events.append(CHHapticEvent(eventType: .hapticContinuous, parameters: parameters,
                                        relativeTime: span(start - offset), duration: span(end - start)))
            if let envelope = beat.envelope {
                let points = (0...10).map { step in
                    let t = (end - start) * Double(step) / 10
                    return CHHapticParameterCurve.ControlPoint(relativeTime: span(t),
                                                               value: Float(envelope(start - beat.time + t)))
                }
                curves.append(CHHapticParameterCurve(parameterID: .hapticIntensityControl, controlPoints: points,
                                                     relativeTime: span(start - offset)))
            }
        }
        guard !events.isEmpty else { return nil }
        return try CHHapticPattern(events: events, parameterCurves: curves)
    }
}
