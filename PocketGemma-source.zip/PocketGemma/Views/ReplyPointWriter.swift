import Foundation
import UIKit
import SwiftUI
import PocketCore
import FoundationModels

/// 要点, summed up on the phone (1.1.0 (302)): the passage of a reply that
/// a point is for (ReplyPoints.Request, words already on the screen) put
/// to Apple's on-device model (Apple Intelligence's, run by iOS in a
/// process of its own, nothing sent anywhere) for one short noun phrase.
/// What it answers is shown only if ReplyPointCheck lets it (ReplyPoints
/// settles it); otherwise, or when it cannot be asked, the reply's own
/// structure gives the point.
///
/// Asked only while the app is in front, one passage at a time, at most
/// every ReplyPoints.quiet seconds per reply, for at most 40 tokens, with
/// greedy sampling (the same passage, the same point), given up after
/// `timeout`. Not asked in Low Power Mode, while the phone is hot
/// (serious or critical), when Apple Intelligence is off or not ready, on
/// a phone without it, or when 開発者設定 turns it off. The person's
/// chat model (Gemma and the rest) is never asked: it is busy writing.
@MainActor final class ReplyPointWriter: ObservableObject {
    static let shared = ReplyPointWriter()
    /// 開発者設定's switch: on unless turned off.
    static let settingKey = "reply-points-on-device-model-v1"
    /// A passage's summary is given up after this long.
    static let timeout: TimeInterval = 5

    enum Availability: Equatable {
        case ready, off, lowPower, hot
        case unavailable(String)

        /// In a few words, for 開発者設定.
        var words: String {
            switch self {
            case .ready: String(localized: "使えます")
            case .off: String(localized: "オフ（構成から要点を作ります）")
            case .lowPower: String(localized: "低電力モードのため使いません")
            case .hot: String(localized: "端末が熱いため使いません")
            case .unavailable(let reason): reason
            }
        }
    }

    /// The newest reply's record, for 開発者設定.
    struct Record: Equatable {
        var asked = 0
        var answered = 0
        var failed = 0
        var seconds: [Double] = []
        var shown: [ReplyPoints.Kind: Int] = [:]
        /// Why the newest request that came back with nothing did, in the
        /// model's own words (a timeout, a refusal, assets not ready).
        var failure: String?
    }

    @Published private(set) var record = Record()
    /// Why the newest `respond` gave nothing.
    private var lastFailure: String?
    /// A session made ready ahead of a reply's first passage.
    private var warm: LanguageModelSession?

    #if POCKET_PREVIEW
    /// UI checks only (`--points-model-stub`): the model's answers played
    /// in (PreviewReplyPoints), as the simulator has no Apple Intelligence.
    private static let stub = PreviewProbe.on("--points-model-stub")
    #else
    private static let stub = false
    #endif

    var availability: Availability {
        if !(UserDefaults.standard.object(forKey: Self.settingKey) as? Bool ?? true) { return .off }
        let info = ProcessInfo.processInfo
        if info.isLowPowerModeEnabled { return .lowPower }
        if info.thermalState == .serious || info.thermalState == .critical { return .hot }
        if Self.stub { return .ready }
        let state = SystemLanguageModel.default.availability
        if case .available = state { return .ready }
        if case .unavailable(let reason) = state {
            switch reason {
            case .deviceNotEligible: return .unavailable(String(localized: "この端末では使えません"))
            case .appleIntelligenceNotEnabled: return .unavailable(String(localized: "Apple Intelligence がオフです"))
            case .modelNotReady: return .unavailable(String(localized: "Apple のモデルを準備中です"))
            @unknown default: break
            }
        }
        return .unavailable(String(localized: "使えません"))
    }

    /// A reply began to be written: a fresh record, and the model made
    /// ready for its first passage (loaded by iOS, if it is not).
    func replyBegan() {
        record = Record()
        guard availability == .ready, !Self.stub, warm == nil else { return }
        let session = LanguageModelSession(instructions: Self.instructions)
        session.prewarm()
        warm = session
    }

    /// The row showed a point of this kind.
    func shown(_ kind: ReplyPoints.Kind) {
        record.shown[kind, default: 0] += 1
    }

    /// The model's point for `request`'s passage, unchecked; nil when it
    /// cannot be asked, fails, refuses or takes too long.
    func summary(for request: ReplyPoints.Request) async -> String? {
        guard request.summarises, availability == .ready, UIApplication.shared.applicationState == .active else { return nil }
        record.asked += 1
        lastFailure = "no answer"
        let started = Date()
        let answer: String?
        #if POCKET_PREVIEW
        if Self.stub {
            try? await Task.sleep(for: .seconds(0.6))
            answer = PreviewReplyPoints.answer(for: request.passage)
        } else {
            answer = await respond(to: Self.prompt(for: request))
        }
        #else
        answer = await respond(to: Self.prompt(for: request))
        #endif
        if let answer {
            record.answered += 1
            record.seconds.append(Date().timeIntervalSince(started))
        } else {
            record.failed += 1
            record.failure = lastFailure ?? "nil"
        }
        return answer
    }

    private func respond(to prompt: String) async -> String? {
        // A fresh session each time (one that went on would carry every
        // passage before), the one made ready first.
        let session = warm ?? LanguageModelSession(instructions: Self.instructions)
        warm = nil
        let options = GenerationOptions(sampling: .greedy, maximumResponseTokens: 40)
        let work = Task { @MainActor in try await session.respond(to: prompt, options: options).content }
        let timer = Task { @MainActor in
            try? await Task.sleep(for: .seconds(Self.timeout))
            work.cancel()
        }
        defer { timer.cancel() }
        lastFailure = nil
        do {
            return try await work.value
        } catch {
            lastFailure = work.isCancelled ? "timeout" : String(String(describing: error).prefix(80))
            return nil
        }
    }

    /// What the model is asked for: one short noun phrase of what the
    /// passage says, nothing it does not say, not its own words cut out.
    static let instructions = """
        あなたは、書きかけの返答の「いま伝えていること」を、短い見出しで示す係です。
        渡される文章は、返答のうち画面に出た部分です。その内容を、8〜18文字ほどの名詞句ひとつで表してください。
        ・文章に書かれていることだけを使う。推測、これから書かれそうなこと、結論、意見は足さない。
        ・文章の一文をそのまま抜き出さず、短く言い換えてまとめる。
        ・文章が英語なら、英語で6語以内の名詞句にする。
        ・答えは名詞句だけ。句点、かぎかっこ、記号、前置き、説明は付けない。
        例
        文章：画面の明るさを下げると、電池の減りを抑えられます。位置情報も、使うときだけにすると効果があります。
        答え：電池を長持ちさせる設定
        例
        文章：量子ビットは0と1を同時に持てるため、たくさんの計算を一度に進められます。
        答え：量子ビットで同時に計算
        """

    static func prompt(for request: ReplyPoints.Request) -> String {
        var prompt = ""
        if let heading = request.heading { prompt += "見出し：\(heading)\n" }
        prompt += "文章：\(request.passage)\n答え："
        return prompt
    }
}

/// 開発者設定's card for 要点 (1.1.0 (302)): whether Apple's on-device
/// model sums the points up (turned off, they come from the reply's
/// structure alone, to compare a reply's speed and the phone's heat), and
/// what the newest reply's points were.
struct ReplyPointsCard: View {
    @AppStorage(ReplyPointWriter.settingKey) private var on = true
    @ObservedObject private var writer = ReplyPointWriter.shared

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Toggle("Orb の要点を端末内モデルで要約する", isOn: $on)
                .fieluaStateTint()
                .accessibilityIdentifier("reply-points-model-toggle")
            Text("オフにすると、項目名・表の見出し・話題の語から要点を作ります。生成の速さや熱を比べるときに使います。")
                .font(.caption).foregroundStyle(.secondary)
            Text(verbatim: "Apple Intelligence: " + writer.availability.words)
                .font(.caption).foregroundStyle(.secondary)
            Text(verbatim: Self.line(writer.record))
                .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                .accessibilityIdentifier("reply-points-record")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }

    /// The newest reply's points and the model's answers, in figures.
    static func line(_ record: ReplyPointWriter.Record) -> String {
        let shown = record.shown.values.reduce(0, +)
        var line = "直近の返答：要点 \(shown) 回（要約 \(record.shown[.summary] ?? 0)・話題 \(record.shown[.topics] ?? 0)・構成 \(record.shown[.structure] ?? 0)）"
        if record.asked > 0 {
            let mean = record.seconds.isEmpty ? 0 : record.seconds.reduce(0, +) / Double(record.seconds.count)
            line += String(format: "／要約の依頼 %d 回・答え %d・失敗 %d・平均 %.2f 秒・最長 %.2f 秒",
                           record.asked, record.answered, record.failed, mean, record.seconds.max() ?? 0)
        }
        if let failure = record.failure { line += "／最後の失敗：" + failure }
        return line
    }
}
