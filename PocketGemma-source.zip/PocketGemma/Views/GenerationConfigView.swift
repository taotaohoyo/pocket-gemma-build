import SwiftUI
import PocketCore

enum GenerationPreferences {
    private static let key = "generation-settings-v1"
    private static let qwen3GPUKey = "qwen3-gpu-float32-v1"
    static func load() -> [String: GenerationSettings] {
        let defaults = UserDefaults.standard
        var settings = defaults.data(forKey: key)
            .flatMap { try? JSONDecoder().decode([String: GenerationSettings].self, from: $0) } ?? [:]
        // Once per install, so a CPU chosen for Qwen3 from now on stays.
        if !defaults.bool(forKey: qwen3GPUKey) {
            defaults.set(true, forKey: qwen3GPUKey)
            let moved = GenerationSettings.movingQwen3ToTheGPU(settings)
            if moved != settings { settings = moved; save(settings) }
        }
        return settings
    }
    static func save(_ settings: [String: GenerationSettings]) {
        if let data = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(data, forKey: key) }
    }
}

/// One model's generation settings and the user's own system prompt; the
/// app's internal instructions (such as the chart guide added to a request)
/// are never part of it. Opened from the chat's header mark and from the
/// model list, always for the current chat's model.
struct GenerationConfigView: View {
    let model: ModelSpec
    let onSave: (GenerationSettings) -> Void
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: GenerationSettings
    @State private var tab = 0
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    init(model: ModelSpec, settings: GenerationSettings, onSave: @escaping (GenerationSettings) -> Void) {
        self.model = model; self.onSave = onSave
        _draft = State(initialValue: settings)
    }
    var body: some View {
        NavigationStack {
            Group {
                if tab == 0 {
                    Form {
                        Section {
                            integer("Max Tokens", value: $draft.maxTokens, range: 1024...model.maximumContextTokens, step: 256,
                                    help: "入力・会話履歴・返信を合わせた上限。増やすと長い会話を覚えられますが、メモリ使用量と準備時間も増えます。")
                            integer("返信用の空き", value: $draft.maxOutputTokens, range: 128...max(512, min(4096, draft.maxTokens / 2)), step: 128,
                                    help: "会話履歴を入れるときに、返信のために空けておく枠。返信はこの数で打ち切られず、最後まで生成します。会話全体がMax Tokensに達したときは、自動で続きを書きます。増やすと履歴に使える枠が減ります。")
                            if showDeveloperSettings { integer("TopK", value: $draft.topK, range: 1...64,
                                    help: "次の言葉を選ぶ候補の数。小さくすると安定しやすく、大きくすると表現の幅が広がります。")
                            decimal("TopP", value: $draft.topP, range: 0.01...1,
                                    help: "候補に含める確率の範囲。下げると無難な言葉に絞り、上げると多様な言葉を選びやすくなります。")
                            }
                            decimal("Temperature", value: $draft.temperature, range: 0...2,
                                    help: "言葉選びのランダムさ。低いと一貫した回答、高いと変化のある回答になります。上げすぎると誤りも増えやすくなります。")
                        }
                        if showDeveloperSettings { Section("開発者向け") {
                            if model.photoDetails.isEmpty {
                                VStack(alignment: .leading, spacing: 8) {
                                    Picker("Visual token budget", selection: $draft.visualTokenBudget) {
                                        ForEach(model.chatVisualTokenBudgets, id: \.self) { Text("\($0)").tag($0) }
                                    }.disabled(!model.supportsVision).accessibilityIdentifier("visual-token-budget")
                                    explanation("画像1場面あたりの情報量。増やすと細部を読み取りやすくなりますが、メモリ・処理時間・入力枠を多く使います。", id: "visual-token-budget")
                                }
                            } else {
                                // The photo detail sets this model's image tokens,
                                // and 高速 also how its replies are written.
                                VStack(alignment: .leading, spacing: 8) {
                                    Picker("返事のモード", selection: $draft.photoDetail) {
                                        ForEach(model.photoDetails) { Text("\($0.title)（\($0.imageTokens)）").tag($0) }
                                    }.accessibilityIdentifier("photo-detail")
                                    explanation("高速は画像トークン70で、言語はAcceleratorの設定のまま動きます。返事は要点をしぼって短めにし、thinkingは使いません。写真のない会話では、先読み（speculative decoding）でも速くします。深くは画像トークン140で少し細かく読み取り、返事の長さ・thinking・先読みは下の設定のままです。写真のある会話は言語をCPUで動かすため、返事が遅くなります。"
                                                + (model.photoDetails.contains(.deeper)
                                                   ? "さらに深くは画像トークン280でE2Bと同じ細かさで読み取り、言語はAcceleratorの設定のまま動きます。返事の前に必ずthinkingでよく考え、そのぶん会話履歴を短めに覚えます。この端末のメモリ領域に余裕があるときだけ選べます。" : ""),
                                                id: "photo-detail")
                                }
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Accelerator")
                                Picker("Accelerator", selection: $draft.backend) {
                                    ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) }
                                }.pickerStyle(.segmented).disabled(!model.supportsGPU).accessibilityIdentifier("execution-backend")
                                explanation(acceleratorHelp, id: "execution-backend")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Text("画像のAccelerator")
                                Picker("画像のAccelerator", selection: $draft.visionBackend) {
                                    ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) }
                                }.pickerStyle(.segmented).disabled(!model.supportsVision)
                                    .accessibilityIdentifier("vision-execution-backend")
                                explanation("画像エンコーダーだけを変更します。初期設定はCPUです。GPUで画像の準備に失敗する場合は、上のAcceleratorをGPUのまま、ここだけCPUにして比較できます。画像アダプターはモデル指定のCPUで動作します。", id: "vision-execution-backend")
                                if model.supportsVision && draft.visionBackend == .cpu {
                                    Picker("画像CPUの実行方式", selection: $draft.visionCPUImplementation) {
                                        ForEach(VisionCPUImplementation.allCases) { Text($0.title).tag($0) }
                                    }.accessibilityIdentifier("vision-cpu-implementation")
                                    explanation("標準はXNNPACK。互換では画像エンコーダーとアダプターを組み込みCPUで実行します。画像の準備が大幅に遅くなる場合があります。言語側のGPU/CPU設定は変わりません。失敗時の自動切り替えは行いません。", id: "vision-cpu-implementation")
                                }
                                if model.supportsVision {
                                    Menu("画像推論の比較構成") {
                                        Button("GPU / GPU") { draft.backend = .gpu; draft.visionBackend = .gpu }
                                        Button("GPU / CPU（画像側だけCPU）") { draft.backend = .gpu; draft.visionBackend = .cpu }
                                        Button("CPU / CPU") { draft.backend = .cpu; draft.visionBackend = .cpu }
                                    }.accessibilityIdentifier("vision-comparison-presets")
                                    explanation("順番は言語生成 / 画像エンコーダー。モデル・トークン数・会話本文は変更しません。比較時は同じ画像を新しい会話で送信してください。結果は「推論の診断」に残ります。", id: "vision-comparison-presets")
                                }
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                // 高速 never thinks and さらに深く always does, so
                                // the switch shows that there and keeps the
                                // saved choice for 深く.
                                Toggle("Enable thinking", isOn: Binding(get: { draft.thinks(on: model) },
                                                                        set: { draft.enableThinking = $0 }))
                                    .disabled(!model.supportsThinking || draft.isFast(on: model) || draft.isDeeper(on: model))
                                    .accessibilityIdentifier("enable-thinking")
                                explanation((draft.isFast(on: model) ? "高速では使いません。深くを選ぶと使えます。"
                                             : draft.isDeeper(on: model) ? "さらに深くでは必ず使い、考える枠を別にとります。" : "")
                                            + "回答前に推論を行います。複雑な問題を検討できますが、返信の開始が遅くなり、返信トークン枠の一部を消費します。", id: "enable-thinking")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Toggle("Enable speculative decoding", isOn: $draft.enableSpeculativeDecoding).disabled(!model.supportsSpeculation).accessibilityIdentifier("enable-speculation")
                                explanation("候補を先読みして生成を速める機能。速度向上はモデルと端末によって異なり、メモリ使用量や消費電力が増える場合があります。"
                                            + (model.photoDetails.isEmpty ? "" : "高速の写真のない会話では、ここがオフでも使います。オンにすると、写真のある会話と深くでも使います。"),
                                            id: "enable-speculation")
                            }
                            Text("設定はこのモデルに保存され、次の送信から反映されます。モデルが対応していない項目は変更できません。").font(.caption).foregroundStyle(.secondary)
                        }
                        }
                        Button("モデル構成をデフォルトに戻す") {
                            let prompt = draft.systemPrompt; draft = GenerationSettings(for: model); draft.systemPrompt = prompt
                        }
                    }.scrollDismissesKeyboard(.interactively).accessibilityIdentifier("generation-configuration")
                } else {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("回答の口調や、アシスタントの役割を指定できます。").font(.subheadline).foregroundStyle(.secondary)
                        // The card color matched the light sheet exactly, so the
                        // field had no visible edge. Use a fill plus a hairline.
                        TextEditor(text: $draft.systemPrompt).font(.body)
                            .scrollContentBackground(.hidden)
                            .padding(10)
                            .frame(minHeight: 180, maxHeight: 320)
                            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
                            .overlay { RoundedRectangle(cornerRadius: 16).strokeBorder(Color(uiColor: .separator), lineWidth: 0.5) }
                            .accessibilityIdentifier("system-prompt-input")
                        Button("デフォルトに戻す") { draft.systemPrompt = GenerationSettings.defaultSystemPrompt }
                        Spacer(minLength: 0)
                    }.padding()
                }
            }
            // The settings scroll under the model's name and the tabs and fade
            // there, as under the title. Laid out above the Form instead, the
            // Form's first card was cut off by a hard line (device, 1.0.114).
            .safeAreaBar(edge: .top, spacing: 0) { header }
            .navigationTitle("構成").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { onSave(draft.normalized(for: model)); dismiss() }
                        .disabled(chats.isGenerating).accessibilityIdentifier("configuration-save")
                }
            }
        }
    }
    private var header: some View {
        VStack(spacing: 0) {
            Text("\(model.name)の設定").font(.subheadline).foregroundStyle(.secondary)
                .frame(maxWidth: .infinity).padding(.top, 10)
                .accessibilityIdentifier("configuration-model")
            Picker("構成", selection: $tab) {
                Text("モデル構成").tag(0); Text("システムプロンプト").tag(1)
            }.pickerStyle(.segmented).padding()
                .accessibilityIdentifier("configuration-tabs")
            // Settings change from the next send, never during a reply.
            if chats.isGenerating {
                Text("返信を書き終えると保存できます。").font(.caption).foregroundStyle(.secondary)
                    .padding(.bottom, 8)
            }
        }
    }
    private var acceleratorHelp: String {
        guard model.supportsGPU else { return "このモデルはCPUで動作します。iPhoneのGPUでは起動できなかったため、GPUは選べません。" }
        let help = "返信テキストを生成する処理の設定。画像の設定とは独立しています。どちらも端末内で動作します。"
        guard model.capabilities.gpuPrecision == .float32 else { return help }
        return help + "このモデルのGPUは32ビットで計算します（16ビットではiPhoneのGPUで起動できないため）。"
    }
    private func explanation(_ text: String, id: String) -> some View {
        Text(text).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            .accessibilityIdentifier("setting-help-" + id)
    }
    private func integer(_ title: String, value: Binding<Int>, range: ClosedRange<Int>, step: Int = 1, help: String) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.grouping(.never)).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { Double(min(range.upperBound, max(range.lowerBound, value.wrappedValue))) }, set: { value.wrappedValue = Int($0) }), in: Double(range.lowerBound)...Double(range.upperBound), step: Double(step))
            explanation(help, id: title)
        }
    }
    private func decimal(_ title: String, value: Binding<Double>, range: ClosedRange<Double>, help: String) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.precision(.fractionLength(2))).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { value.wrappedValue.isFinite ? min(range.upperBound, max(range.lowerBound, value.wrappedValue)) : range.lowerBound }, set: { value.wrappedValue = $0 }), in: range, step: 0.01)
            explanation(help, id: title)
        }
    }
}
