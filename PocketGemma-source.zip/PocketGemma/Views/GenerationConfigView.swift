import SwiftUI
import PocketCore

enum GenerationPreferences {
    private static let key = "generation-settings-v1"
    private static let qwen3GPUKey = "qwen3-gpu-float32-v1"
    static func load() -> [String: GenerationSettings] {
        let defaults = UserDefaults.standard
        var settings = defaults.data(forKey: key)
            .flatMap { try? JSONDecoder().decode([String: GenerationSettings].self, from: $0) } ?? [:]
        // Once per install, so a CPU chosen for Qwen3 from now on stays.
        if !defaults.bool(forKey: qwen3GPUKey) {
            defaults.set(true, forKey: qwen3GPUKey)
            let moved = GenerationSettings.movingQwen3ToTheGPU(settings)
            if moved != settings { settings = moved; save(settings) }
        }
        return settings
    }
    static func save(_ settings: [String: GenerationSettings]) {
        if let data = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(data, forKey: key) }
    }
}

/// One model's generation settings and the user's own system prompt; the
/// app's internal instructions (such as the chart guide added to a request)
/// are never part of it. Opened from the chat's header mark and from the
/// model list, always for the current chat's model.
struct GenerationConfigView: View {
    let model: ModelSpec
    let onSave: (GenerationSettings) -> Void
    // Only whether a reply is being written (ChatPulse, 1.1.0 (263)): the
    // store itself publishes with every batch of its text.
    @ObservedObject private var pulse = ChatPulse.shared
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var draft: GenerationSettings
    @State private var tab = 0
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    init(model: ModelSpec, settings: GenerationSettings, onSave: @escaping (GenerationSettings) -> Void) {
        self.model = model; self.onSave = onSave
        _draft = State(initialValue: settings)
    }
    /// The default prompt in the app's language; in Japanese the words of
    /// 183 and earlier. The model reads the same words in English
    /// (GenerationSettings.defaultInstruction), whichever language the app
    /// shows.
    private static var defaultPrompt: String {
        String(localized: "system-prompt-default", defaultValue: "あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。",
               comment: "The default system prompt as 構成 shows it. The model reads the same words in English.")
    }
    /// The prompt as the field shows it: the default in the app's language,
    /// or the person's own words as saved. Left as the default, it is saved
    /// as the default, not as the words shown, so it follows the app's
    /// language; anything typed is the person's own and is kept as written.
    private var prompt: Binding<String> {
        Binding(get: { draft.usesDefaultSystemPrompt ? Self.defaultPrompt : draft.systemPrompt },
                set: { draft.systemPrompt = $0 == Self.defaultPrompt ? GenerationSettings.defaultSystemPrompt : $0 })
    }
    var body: some View {
        NavigationStack {
            // One view for both tabs, so the header above them, and its
            // segmented control, stay the same while the tabs change. In a
            // Group each tab had a header of its own: the control was made
            // anew on every switch and its glass jumped to the other side
            // instead of gliding there (user 17:51 UTC 2026-10-25).
            ZStack {
                if tab == 0 {
                    Form {
                        Section {
                            // 12B has 1,024 tokens only: no slider with one value.
                            if model.maximumContextTokens > 1024 {
                            integer("Max Tokens", value: $draft.maxTokens, range: 1024...model.maximumContextTokens, step: 256,
                                    help: String(localized: "覚えておける会話の量です。増やすとメモリと準備の時間が増えます。"))
                            }
                            integer(String(localized: "返信用の空き"), value: $draft.maxOutputTokens, range: 128...max(512, min(4096, draft.maxTokens / 2)), step: 128,
                                    help: String(localized: "返信のために空けておく量です。増やすと覚えておける会話が減ります。"))
                            if showDeveloperSettings { integer("TopK", value: $draft.topK, range: 1...64,
                                    help: "次の言葉を選ぶ候補の数。小さくすると安定しやすく、大きくすると表現の幅が広がります。")
                            decimal("TopP", value: $draft.topP, range: 0.01...1,
                                    help: "候補に含める確率の範囲。下げると無難な言葉に絞り、上げると多様な言葉を選びやすくなります。")
                            }
                            decimal("Temperature", value: $draft.temperature, range: 0...2,
                                    help: String(localized: "言葉選びのゆらぎです。低いと安定し、高いと変化が出ます。"))
                        }.fieluaFormSection()
                        if showDeveloperSettings { Section("開発者向け") {
                            if model.photoDetails.isEmpty {
                                VStack(alignment: .leading, spacing: 8) {
                                    Picker("Visual token budget", selection: $draft.visualTokenBudget) {
                                        ForEach(model.chatVisualTokenBudgets, id: \.self) { Text("\($0)").tag($0) }
                                    }.disabled(!readsLiteRTPhotos).accessibilityIdentifier("visual-token-budget")
                                    explanation("画像1場面あたりの情報量です。増やすと細かく読めますが、メモリと時間を多く使います。", id: "visual-token-budget")
                                }
                            } else {
                                // The photo detail sets this model's image tokens,
                                // and how its replies are written: 高速 or
                                // じっくり考える, which runs as 深く where the
                                // launch lacks the room (1.1.0 (248)).
                                VStack(alignment: .leading, spacing: 8) {
                                    Picker("返信のモード", selection: Binding(get: { draft.photoDetail.choice },
                                                                         set: { draft.photoDetail = $0.running })) {
                                        ForEach(model.photoDetails) { Text("\($0.title)（\($0.running.imageTokens)）").tag($0) }
                                    }.accessibilityIdentifier("photo-detail")
                                    explanation("高速は画像トークン70で、短く速く答えます。じっくり考えるは280で最も細かく読み、よく考えてから答えます。"
                                                + (PhotoDetail.deeperFits ? ""
                                                   : "この起動ではアドレス空間が足りないため、じっくり考えるは深くと同じく140で読み（写真のある会話は言語モデルもCPU）、考えずに答えます。"),
                                                id: "photo-detail")
                                }
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Text("Accelerator")
                                Picker("Accelerator", selection: $draft.backend) {
                                    ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) }
                                }.pickerStyle(.segmented).disabled(!model.supportsGPU || !model.supportsCPU).accessibilityIdentifier("execution-backend")
                                explanation(acceleratorHelp, id: "execution-backend")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Text("画像のAccelerator")
                                Picker("画像のAccelerator", selection: $draft.visionBackend) {
                                    ForEach(ExecutionBackend.allCases) { Text($0.rawValue).tag($0) }
                                }.pickerStyle(.segmented).disabled(!readsLiteRTPhotos)
                                    .accessibilityIdentifier("vision-execution-backend")
                                explanation("画像エンコーダーだけを変更します。初期設定はCPUです。GPUで画像の準備に失敗する場合は、上のAcceleratorをGPUのまま、ここだけCPUにして比較できます。画像アダプターはモデル指定のCPUで動作します。", id: "vision-execution-backend")
                                if readsLiteRTPhotos && draft.visionBackend == .cpu {
                                    Picker("画像CPUの実行方式", selection: $draft.visionCPUImplementation) {
                                        ForEach(VisionCPUImplementation.allCases) { Text($0.title).tag($0) }
                                    }.accessibilityIdentifier("vision-cpu-implementation")
                                    explanation("標準はXNNPACK。互換では画像エンコーダーとアダプターを組み込みCPUで実行します。画像の準備が大幅に遅くなる場合があります。言語側のGPU/CPU設定は変わりません。失敗時の自動切り替えは行いません。", id: "vision-cpu-implementation")
                                }
                                if readsLiteRTPhotos {
                                    Menu("画像推論の比較構成") {
                                        Button("GPU / GPU") { draft.backend = .gpu; draft.visionBackend = .gpu }
                                        Button("GPU / CPU（画像側だけCPU）") { draft.backend = .gpu; draft.visionBackend = .cpu }
                                        Button("CPU / CPU") { draft.backend = .cpu; draft.visionBackend = .cpu }
                                    }.accessibilityIdentifier("vision-comparison-presets")
                                    explanation("順番は言語生成 / 画像エンコーダー。モデル・トークン数・会話本文は変更しません。比較時は同じ画像を新しい会話で送信してください。結果は「推論の診断」に残ります。", id: "vision-comparison-presets")
                                }
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                // 高速 and じっくり考える's fallback never think
                                // and じっくり考える always does, so the switch
                                // shows that there and keeps the saved choice.
                                Toggle("Enable thinking", isOn: Binding(get: { draft.thinks(on: model) },
                                                                        set: { draft.enableThinking = $0 }))
                                    .disabled(!model.supportsThinking || model.capabilities.reasons || draft.isFast(on: model)
                                              || draft.isDeeper(on: model) || draft.deeperFallsBack(on: model))
                                    .fieluaStateTint()
                                    .accessibilityIdentifier("enable-thinking")
                                explanation((model.capabilities.reasons ? "このモデルは必ず考えてから答え、考える枠を別にとります。考えた内容は表示しません。"
                                             : draft.isFast(on: model) ? "高速では使いません。"
                                             : draft.isDeeper(on: model) ? "じっくり考えるでは必ず使い、考える枠を別にとります。"
                                             : draft.deeperFallsBack(on: model) ? "この起動ではアドレス空間が足りないため、じっくり考えるでも使いません。" : "")
                                            + "回答前に推論を行います。複雑な問題を検討できますが、返信の開始が遅くなり、返信トークン枠の一部を消費します。", id: "enable-thinking")
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Toggle("Enable speculative decoding", isOn: $draft.enableSpeculativeDecoding).disabled(!model.supportsSpeculation).fieluaStateTint().accessibilityIdentifier("enable-speculation")
                                explanation("候補を先読みして生成を速める機能。速度向上はモデルと端末によって異なり、メモリ使用量や消費電力が増える場合があります。"
                                            + (model.photoDetails.isEmpty ? "" : "高速の写真のない会話では、ここがオフでも使います。オンにすると、写真のある会話とじっくり考えるでも使います。"),
                                            id: "enable-speculation")
                            }
                            Text("設定はこのモデルに保存され、次の送信から反映されます。モデルが対応していない項目は変更できません。").font(.caption).foregroundStyle(.secondary)
                            // Smart Mode (1.1.0 (249)) uses these settings but
                            // the reply mode and thinking, which it chooses.
                            if SmartMode.isOn {
                                Text("「質問に合わせて自動で選ぶ」の会話では、返信モードとthinkingを質問ごとに選び、ほかの項目はここで保存した値を使います。")
                                    .font(.caption).foregroundStyle(.secondary)
                                    .accessibilityIdentifier("config-smart-note")
                            }
                        }.fieluaFormSection()
                        }
                        Button("モデル構成をデフォルトに戻す") {
                            let prompt = draft.systemPrompt; draft = GenerationSettings(for: model); draft.systemPrompt = prompt
                        }.fieluaFormSection()
                    }
                    // On the page's paper below, not iOS's grey (1.1.0 (215)).
                    .scrollContentBackground(.hidden)
                    .scrollDismissesKeyboard(.interactively).accessibilityIdentifier("generation-configuration")
                    .transition(.opacity)
                } else {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("返信の口調や役割を指定できます。").font(.subheadline).foregroundStyle(.secondary)
                        // A card on the page's paper, as モデル構成's rows are,
                        // with the input's hairline so its edge shows.
                        TextEditor(text: prompt).font(.body)
                            .scrollContentBackground(.hidden)
                            .padding(10)
                            .frame(minHeight: 180, maxHeight: 320)
                            .background(Theme.card, in: RoundedRectangle(cornerRadius: 16))
                            .overlay { RoundedRectangle(cornerRadius: 16).strokeBorder(Theme.inputBorder, lineWidth: 0.5) }
                            .accessibilityIdentifier("system-prompt-input")
                        Button("デフォルトに戻す") { draft.systemPrompt = GenerationSettings.defaultSystemPrompt }
                        Spacer(minLength: 0)
                    }.padding()
                    .transition(.opacity)
                }
            }
            // One tab's content fades into the other's while the control
            // glides (it was cut under the gliding control before 1.1.0 (263)).
            .animation(FieluaMotion.change(reduceMotion), value: tab)
            // One paper under both tabs and the bars, so it stays while they
            // change (iOS's grey and white until 1.1.0 (215)).
            .fieluaPageBackground()
            // The settings scroll under the model's name and the tabs and fade
            // there, as under the title. Laid out above the Form instead, the
            // Form's first card was cut off by a hard line (device, 1.0.114).
            .safeAreaBar(edge: .top, spacing: 0) { header }
            .navigationTitle("構成").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // A cross for キャンセル beside iOS's checkmark: the pair of every
                // sheet that saves (the word and the mark before 1.1.0 (263)).
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル", systemImage: "xmark", role: .cancel) { dismiss() }
                        .accessibilityIdentifier("configuration-cancel")
                }
                // iOS's own checkmark, prominent glass (user 17:51 UTC 2026-10-25).
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存", systemImage: "checkmark", role: .confirm) { onSave(draft.normalized(for: model)); dismiss() }
                        .disabled(pulse.isGenerating).accessibilityIdentifier("configuration-save")
                }
            }
        }
    }
    private var header: some View {
        VStack(spacing: 0) {
            Text("\(model.name)の設定").font(.subheadline).foregroundStyle(.secondary)
                .frame(maxWidth: .infinity).padding(.top, 10)
                .accessibilityIdentifier("configuration-model")
            Picker("構成", selection: $tab) {
                Text("モデル構成").tag(0); Text("システムプロンプト").tag(1)
            }.pickerStyle(.segmented).padding()
                .accessibilityIdentifier("configuration-tabs")
                #if POCKET_PREVIEW
                // UI checks: how many times the tabs were made, which a
                // change of tab must not add to.
                .onAppear { ConfigurationTabsProbe.made += 1 }
                .overlay {
                    Color.clear.allowsHitTesting(false).accessibilityElement()
                        .accessibilityLabel("\(ConfigurationTabsProbe.made)").accessibilityIdentifier("configuration-tabs-made")
                }
                #endif
            // Settings change from the next send, never during a reply.
            if pulse.isGenerating {
                Text("返信を書き終えると保存できます。").font(.caption).foregroundStyle(.secondary)
                    .padding(.bottom, 8)
                    .transition(.opacity)
            }
        }
        .animation(FieluaMotion.change(reduceMotion), value: pulse.isGenerating)
    }
    /// Photos read by LiteRT-LM's vision encoder, whose settings these are.
    /// LFM3-VL 2B's projector runs where its replies do (1.1.0 (234)).
    private var readsLiteRTPhotos: Bool { model.supportsVision && model.runtime == .liteRT }
    private var acceleratorHelp: String {
        guard model.supportsGPU else {
            // Qwen3.5 4B: its export card measured 5.74 GB and a 65 s load on
            // an iPhone's GPU, for a reply not much faster than the CPU's.
            if model.id == ModelSpec.qwen35.id {
                return "このモデルはCPUで動作します。GPUでは速くならず、メモリを多く使うため選べません。"
            }
            return "このモデルはCPUで動作します。GPUでは起動できないため選べません。"
        }
        guard model.supportsCPU else { return "このモデルはGPUで動作します。CPUでは遅すぎるため選べません。" }
        var help = "返信を書く処理の設定です。"
        if !model.capabilities.startsOnGPU {
            help += "このモデルは最初はCPUで動きます。iPhoneのGPUでの動作はまだ確かめていません。"
        }
        guard model.capabilities.gpuPrecision == .float32 else { return help }
        return help + "このモデルのGPUは32ビットで計算します。"
    }
    private func explanation(_ text: String, id: String) -> some View {
        Text(text).font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            .accessibilityIdentifier("setting-help-" + id)
    }
    private func integer(_ title: String, value: Binding<Int>, range: ClosedRange<Int>, step: Int = 1, help: String) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.grouping(.never)).keyboardType(.numberPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { Double(min(range.upperBound, max(range.lowerBound, value.wrappedValue))) }, set: { value.wrappedValue = Int($0) }), in: Double(range.lowerBound)...Double(range.upperBound), step: Double(step))
                .fieluaStateTint()
            explanation(help, id: title)
        }
    }
    private func decimal(_ title: String, value: Binding<Double>, range: ClosedRange<Double>, help: String) -> some View {
        VStack(alignment: .leading) {
            HStack { Text(title); Spacer(); TextField(title, value: value, format: .number.precision(.fractionLength(2))).keyboardType(.decimalPad).multilineTextAlignment(.trailing).frame(width: 85).accessibilityIdentifier("setting-" + title) }
            Slider(value: Binding(get: { value.wrappedValue.isFinite ? min(range.upperBound, max(range.lowerBound, value.wrappedValue)) : range.lowerBound }, set: { value.wrappedValue = $0 }), in: range, step: 0.01)
                .fieluaStateTint()
            explanation(help, id: title)
        }
    }
}

#if POCKET_PREVIEW
@MainActor enum ConfigurationTabsProbe {
    static var made = 0
}
#endif
