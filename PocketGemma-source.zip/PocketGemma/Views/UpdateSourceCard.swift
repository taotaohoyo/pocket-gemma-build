import SwiftUI
import UIKit

enum AppDistribution {
    static let sourceURL = URL(string: "https://raw.githubusercontent.com/taotaohoyo/pocket-gemma-build/main/altstore-source.json")!
    static let releasesURL = URL(string: "https://github.com/taotaohoyo/pocket-gemma-build/releases")!
}

struct UpdateSourceCard: View {
    @State private var copied = false
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("AltStoreで更新", systemImage: "arrow.triangle.2.circlepath").font(.headline)
            Text("AltStore ClassicのSourcesに更新ソースを一度追加すると、新しいバージョンがAltStoreに表示されます。同じApple IDで更新すると、保存したモデルと会話を引き継げます。")
                .font(.subheadline).foregroundStyle(.secondary)
            Button {
                UIPasteboard.general.string = AppDistribution.sourceURL.absoluteString
                copied = true
            } label: {
                Label(copied ? "URLをコピーしました" : "更新ソースのURLをコピー", systemImage: copied ? "checkmark" : "doc.on.doc")
            }.buttonStyle(.bordered).accessibilityIdentifier("copy-update-source")
            Link("公開バージョンを確認", destination: AppDistribution.releasesURL).font(.subheadline)
            Text("無料Apple IDの署名期限の更新（Refresh）は、引き続きAltStoreで行ってください。アプリ単体では署名を更新できません。")
                .font(.caption).foregroundStyle(.secondary)
        }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
            .accessibilityIdentifier("update-source-card")
    }
}
