import SwiftUI
import UIKit
import SwiftMath

/// A `$$…$$` formula on its own line, centered; a wide one scrolls sideways.
/// LaTeX SwiftMath cannot typeset is shown as its source.
struct MarkdownMathBlock: View {
    let latex: String
    @ScaledMetric(relativeTo: .body) private var size: CGFloat = 19

    var body: some View {
        if let rendered = MarkdownMathRenderer.render(latex, display: true, fontSize: size) {
            ViewThatFits(in: .horizontal) {
                rendered.image.frame(maxWidth: .infinity)
                ScrollView(.horizontal, showsIndicators: false) { rendered.image }
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            }
            .padding(.vertical, 4)
        } else {
            Text(verbatim: latex)
                .font(.system(.footnote, design: .monospaced))
                .foregroundStyle(.secondary)
        }
    }
}

/// Typesets LaTeX with SwiftMath (Latin Modern Math) into a template image,
/// which takes the text color, so one image serves light and dark mode.
@MainActor
enum MarkdownMathRenderer {
    struct Rendered {
        let image: Image
        /// How far the formula reaches below the text's baseline.
        let descent: CGFloat
    }

    private final class Entry {
        let rendered: Rendered?
        init(_ rendered: Rendered?) { self.rendered = rendered }
    }

    private static let cache: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 300
        return cache
    }()

    static func render(_ latex: String, display: Bool, fontSize: CGFloat) -> Rendered? {
        let key = "\(display ? "D" : "T")\(fontSize)\u{0}\(latex)" as NSString
        if let entry = cache.object(forKey: key) { return entry.rendered }
        let rendered = typeset(latex, display: display, fontSize: fontSize)
        cache.setObject(Entry(rendered), forKey: key)
        return rendered
    }

    private static func typeset(_ latex: String, display: Bool, fontSize: CGFloat) -> Rendered? {
        guard !latex.isEmpty, latex.count < 4_000 else { return nil }
        let label = MTMathUILabel()
        label.labelMode = display ? .display : .text
        label.fontSize = fontSize
        label.textColor = .black
        guard let list = MathText.parse(latex) else { return nil }
        label.mathList = list
        let size = label.intrinsicContentSize
        guard size.width > 0, size.height > 0, size.width < 6_000, size.height < 2_000 else { return nil }
        label.frame = CGRect(origin: .zero, size: size)
        label.setNeedsLayout()
        label.layoutIfNeeded()
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        format.opaque = false
        let picture = UIGraphicsImageRenderer(size: size, format: format).image { context in
            // The label draws in a flipped layer's coordinates.
            if label.layer.isGeometryFlipped {
                context.cgContext.translateBy(x: 0, y: size.height)
                context.cgContext.scaleBy(x: 1, y: -1)
            }
            label.draw(label.bounds)
        }
        guard let cgImage = picture.cgImage else { return nil }
        let image = Image(cgImage, scale: format.scale, label: Text(verbatim: "数式 \(latex)"))
            .renderingMode(.template)
        let descent = label.displayList.map { CGFloat($0.descent) } ?? size.height / 4
        return Rendered(image: image, descent: min(max(0, descent), size.height))
    }
}

/// SwiftMath drops every character it gives no math meaning, which is all
/// Japanese, so `\text{自己分析} \times \text{企業研究}` came out as a bare "×".
/// Runs of such text go through the parser as placeholder commands and come
/// back as ordinary atoms holding the text, which Core Text draws in a
/// fallback font. Symbols SwiftMath knows by a command (×, ≤, α) become that
/// command, so they keep their math spacing.
@MainActor
private enum MathText {
    private static let prefix = "PocketText"
    /// Placeholder nuclei: one private-use scalar per run.
    private static let firstMark: UInt32 = 0xF0000
    private static var registered = 0

    static func parse(_ latex: String) -> MTMathList? {
        var source = ""
        var texts: [String] = []
        var run = ""
        func endRun() {
            guard !run.isEmpty else { return }
            source += "{\\\(name(texts.count))}"
            texts.append(run)
            run = ""
        }
        for character in latex {
            if character.isASCII || (run.isEmpty && character.isWhitespace)
                || MTMathAtomFactory.atom(forCharacter: character) != nil {
                endRun()
                source.append(character)
            } else if let symbol = symbolName(character) {
                endRun()
                source += "{\\\(symbol)}"
            } else {
                run.append(character)
            }
        }
        endRun()
        register(texts.count)
        var error: NSError?
        guard let list = MTMathListBuilder.build(fromString: source, error: &error), error == nil else { return nil }
        restore(list, texts)
        return list
    }

    private static func symbolName(_ character: Character) -> String? {
        guard let name = MTMathAtomFactory.textToLatexSymbolName[String(character)],
              !name.hasPrefix(prefix), name.allSatisfy({ $0.isASCII && $0.isLetter }) else { return nil }
        return name
    }

    /// Command names are letters only: 0 → A, 25 → Z, 26 → BA.
    private static func name(_ index: Int) -> String {
        var letters = ""
        var rest = index
        repeat {
            letters.insert(Character(UnicodeScalar(UInt8(65 + rest % 26))), at: letters.startIndex)
            rest /= 26
        } while rest > 0
        return prefix + letters
    }

    private static func register(_ count: Int) {
        while registered < count {
            // SwiftMath has no public initializer, so an ordinary atom is borrowed.
            guard let atom = MTMathAtomFactory.atom(forCharacter: "/"),
                  let mark = UnicodeScalar(firstMark + UInt32(registered)) else { return }
            atom.nucleus = String(mark)
            MTMathAtomFactory.add(latexSymbol: name(registered), value: atom)
            registered += 1
        }
    }

    private static func restore(_ list: MTMathList?, _ texts: [String]) {
        for atom in list?.atoms ?? [] {
            let scalars = atom.nucleus.unicodeScalars
            if scalars.count == 1, let value = scalars.first?.value, value >= firstMark,
               Int(value - firstMark) < texts.count {
                atom.nucleus = texts[Int(value - firstMark)]
            }
            restore(atom.superScript, texts)
            restore(atom.subScript, texts)
            switch atom {
            case let fraction as MTFraction:
                restore(fraction.numerator, texts)
                restore(fraction.denominator, texts)
            case let radical as MTRadical:
                restore(radical.radicand, texts)
                restore(radical.degree, texts)
            case let inner as MTInner: restore(inner.innerList, texts)
            case let line as MTOverLine: restore(line.innerList, texts)
            case let line as MTUnderLine: restore(line.innerList, texts)
            case let accent as MTAccent: restore(accent.innerList, texts)
            case let color as MTMathColor: restore(color.innerList, texts)
            case let color as MTMathTextColor: restore(color.innerList, texts)
            case let box as MTMathColorbox: restore(box.innerList, texts)
            case let table as MTMathTable:
                for cell in table.cells.joined() { restore(cell, texts) }
            default: break
            }
        }
    }
}
