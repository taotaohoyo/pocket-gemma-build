import SwiftUI
import UIKit
import os
import PocketCore
import SwiftMath

/// A `$$…$$` formula on its own line, centered; a wide one scrolls sideways.
/// LaTeX the engine cannot typeset is shown as its source with a short hint,
/// as is a formula still arriving, so a half-written one is never typeset
/// or cached. VoiceOver reads the formula in words (`MathSpeech`), and a
/// long press copies its LaTeX.
struct MarkdownMathBlock: View {
    let latex: String
    var unfinished = false
    /// Whether the formula is drawn typeset. It follows `unfinished` from a
    /// task of its own, animated: the source gives way to the formula in a
    /// fade and the lines below move to its height (the formula took the
    /// source's place in one frame until 1.1.0 (262), when the change came
    /// in the reply's own update, which is not animated).
    @State private var typeset: Bool
    @ScaledMetric(relativeTo: .body) private var size: CGFloat = 19
    @Environment(\.displayScale) private var displayScale
    @Environment(\.markdownReplySource) private var reply
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init(latex: String, unfinished: Bool = false) {
        self.latex = latex
        self.unfinished = unfinished
        _typeset = State(initialValue: !unfinished)
    }

    var body: some View {
        // One container, so the two never stand one above the other while
        // they trade places.
        ZStack(alignment: .topLeading) {
            if typeset && !unfinished {
                formula.transition(.opacity)
            } else {
                source(hint: nil).transition(.opacity)
            }
        }
        .onChange(of: unfinished) { _, open in
            Task { @MainActor in
                withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.recolor) { typeset = !open }
            }
        }
    }

    private var formula: some View {
            Group {
                switch MarkdownMathRenderer.render(latex, display: true, fontSize: size, scale: displayScale) {
                case .success(let rendered):
                    MarkdownMathImage(rendered: rendered).padding(.vertical, 4)
                case .failure(let failure):
                    source(hint: failure.hint)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(Text(verbatim: MarkdownMathRenderer.spokenLabel(latex, display: true)))
                        .accessibilityHint(failure.hint.map { Text(verbatim: $0) } ?? Text(verbatim: ""))
                }
            }
            .accessibilityIdentifier("math-block")
            .accessibilityAction(named: Text("LaTeXをコピー")) { UIPasteboard.general.string = latex }
            .contextMenu {
                Button("LaTeXをコピー", systemImage: "function") { UIPasteboard.general.string = latex }
                if let reply {
                    Divider()
                    Button("返信全体をコピー", systemImage: "doc.plaintext") { UIPasteboard.general.string = reply.text }
                }
            }
    }

    private func source(hint: String?) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(verbatim: latex)
                .font(.system(.footnote, design: .monospaced))
                .foregroundStyle(.secondary)
            if let hint {
                Text(hint)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
        }
    }
}

/// A typeset formula that scrolls sideways when wider than its line. Its
/// baseline is the formula's, so a list marker beside it lines up with the
/// formula and not with its bottom edge.
struct MarkdownMathImage: View {
    let rendered: MarkdownMathRenderer.Rendered

    var body: some View {
        ViewThatFits(in: .horizontal) {
            rendered.image.frame(maxWidth: .infinity)
            ScrollView(.horizontal, showsIndicators: false) { rendered.image }
                .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
        }
        .alignmentGuide(.firstTextBaseline) { dimensions in dimensions[.bottom] - rendered.descent }
    }
}

/// Why a formula is shown as its source.
struct MathFailure: Error, Hashable {
    enum Reason: Hashable {
        case empty
        case tooLong(Int)
        case tooLarge(width: Int, height: Int)
        case unreadable(String)
    }

    let reason: Reason

    /// A line for the reader under the source; none for an empty formula.
    var hint: String? {
        switch reason {
        case .empty:
            return nil
        case .tooLong:
            return String(localized: "数式が長すぎるため、そのまま表示しています")
        case .tooLarge:
            return String(localized: "数式が大きすぎるため、そのまま表示しています")
        case .unreadable(let message):
            if let range = message.range(of: "Invalid command ") {
                let command = message[range.upperBound...].trimmingCharacters(in: .whitespacesAndNewlines)
                return String(localized: "未対応の記法 \(command) があるため、そのまま表示しています")
            }
            if message.localizedCaseInsensitiveContains("brace") || message.contains("Missing {") || message.contains("Missing }") {
                return String(localized: "波かっこが対応していないため、そのまま表示しています")
            }
            if message.contains("can only have") {
                return String(localized: "この環境の列の数が合わないため、そのまま表示しています")
            }
            if let range = message.range(of: "Unknown environment ") {
                let environment = message[range.upperBound...].trimmingCharacters(in: .whitespacesAndNewlines)
                return String(localized: "未対応の環境 \(environment) があるため、そのまま表示しています")
            }
            if message.contains("\\end") || message.contains("\\begin") || message.localizedCaseInsensitiveContains("environment") {
                return String(localized: "\\begin と \\end が対応していないため、そのまま表示しています")
            }
            if message.contains("\\left") || message.contains("\\right") || message.localizedCaseInsensitiveContains("delimiter") {
                return String(localized: "\\left と \\right が対応していないため、そのまま表示しています")
            }
            return String(localized: "読めない記法があるため、そのまま表示しています")
        }
    }
}

/// What typesets LaTeX into an image: SwiftMath today, behind one boundary.
@MainActor
protocol MathEngine {
    func typeset(_ latex: String, display: Bool, fontSize: CGFloat, scale: CGFloat) -> MarkdownMathRenderer.Outcome
}

/// Typeset formulas by source, size and screen scale, kept up to about
/// 32 MB of image; a failure is kept too, so it is not retried every draw.
@MainActor
enum MarkdownMathRenderer {
    struct Rendered {
        let image: Image
        /// The image's size in points.
        let size: CGSize
        /// How far the formula reaches below the text's baseline.
        let descent: CGFloat
        /// The image's bytes, the cache's cost.
        let bytes: Int
    }

    typealias Outcome = Result<Rendered, MathFailure>

    private final class Entry {
        let outcome: Outcome
        init(_ outcome: Outcome) { self.outcome = outcome }
    }

    static var engine: any MathEngine = SwiftMathEngine()

    private static let cache: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 300
        cache.totalCostLimit = 32 * 1024 * 1024
        return cache
    }()

    /// The largest formula drawn, in points squared: a page of matrices,
    /// about 16 MB of image at 3x. Beyond it the source is shown.
    static let maximumArea: CGFloat = 450_000

    static let log = Logger(subsystem: "PocketAI", category: "math")

    static func render(_ latex: String, display: Bool, fontSize: CGFloat, scale: CGFloat) -> Outcome {
        let key = "\(display ? "D" : "T")\(fontSize)@\(scale)\u{0}\(latex)" as NSString
        if let entry = cache.object(forKey: key) { return entry.outcome }
        let outcome = engine.typeset(latex, display: display, fontSize: fontSize, scale: scale)
        let cost = (try? outcome.get().bytes) ?? 0
        cache.setObject(Entry(outcome), forKey: key, cost: cost)
        return outcome
    }

    static func purge() { cache.removeAllObjects() }

    /// What VoiceOver says for a formula: its LaTeX in words, after "数式"
    /// when it stands on its own line.
    static func spokenLabel(_ latex: String, display: Bool) -> String {
        let spoken = MathSpeech.spoken(latex)
        return display ? String(localized: "数式、\(spoken)") : spoken
    }
}

/// SwiftMath (Latin Modern Math) drawn into a template image, which takes
/// the text color, so one image serves light and dark mode. The LaTeX goes
/// through `MathSyntax.normalized` first, so what SwiftMath lacks (`align`,
/// `\dfrac`, primes, full-width characters) still draws.
@MainActor
struct SwiftMathEngine: MathEngine {
    func typeset(_ latex: String, display: Bool, fontSize: CGFloat, scale: CGFloat) -> MarkdownMathRenderer.Outcome {
        guard !latex.isEmpty else { return .failure(MathFailure(reason: .empty)) }
        guard latex.count < 4_000 else {
            MarkdownMathRenderer.log.notice("Formula of \(latex.count) characters shown as source")
            return .failure(MathFailure(reason: .tooLong(latex.count)))
        }
        let label = MTMathUILabel()
        label.labelMode = display ? .display : .text
        label.fontSize = fontSize
        label.textColor = .black
        switch MathText.parse(MathSyntax.normalized(latex)) {
        case .failure(let failure): return .failure(failure)
        case .success(let list): label.mathList = list
        }
        let size = label.intrinsicContentSize
        guard size.width > 0, size.height > 0 else { return .failure(MathFailure(reason: .empty)) }
        guard size.width * size.height <= MarkdownMathRenderer.maximumArea else {
            MarkdownMathRenderer.log.notice("Formula of \(Int(size.width))x\(Int(size.height))pt shown as source")
            return .failure(MathFailure(reason: .tooLarge(width: Int(size.width), height: Int(size.height))))
        }
        label.frame = CGRect(origin: .zero, size: size)
        label.setNeedsLayout()
        label.layoutIfNeeded()
        let format = UIGraphicsImageRendererFormat()
        format.scale = max(1, scale)
        format.opaque = false
        let picture = UIGraphicsImageRenderer(size: size, format: format).image { context in
            // The label draws in a flipped layer's coordinates.
            if label.layer.isGeometryFlipped {
                context.cgContext.translateBy(x: 0, y: size.height)
                context.cgContext.scaleBy(x: 1, y: -1)
            }
            label.draw(label.bounds)
        }
        guard let cgImage = picture.cgImage else { return .failure(MathFailure(reason: .unreadable("no image"))) }
        let image = Image(cgImage, scale: format.scale,
                          label: Text(verbatim: MarkdownMathRenderer.spokenLabel(latex, display: display)))
            .renderingMode(.template)
        let descent = label.displayList.map { CGFloat($0.descent) } ?? size.height / 4
        return .success(MarkdownMathRenderer.Rendered(image: image, size: size,
                                                      descent: min(max(0, descent), size.height),
                                                      bytes: cgImage.bytesPerRow * cgImage.height))
    }
}

/// SwiftMath drops every character it gives no math meaning, which is all
/// Japanese, so `\text{自己分析} \times \text{企業研究}` came out as a bare "×".
/// Runs of such text go through the parser as placeholder commands
/// (`MathSyntax.placeholders`) and come back as ordinary atoms holding the
/// text, which Core Text draws in a fallback font. Symbols SwiftMath knows
/// by a command (×, ≤, α) become that command, so they keep their spacing.
@MainActor
private enum MathText {
    /// Placeholder nuclei: one private-use scalar per run.
    private static let firstMark: UInt32 = 0xF0000
    private static var registered = 0

    static func parse(_ latex: String) -> Result<MTMathList, MathFailure> {
        let (source, texts) = MathSyntax.placeholders(
            latex,
            isKnown: { MTMathAtomFactory.atom(forCharacter: $0) != nil },
            symbolName: { MTMathAtomFactory.textToLatexSymbolName[String($0)] })
        register(texts.count)
        var error: NSError?
        guard let list = MTMathListBuilder.build(fromString: source, error: &error), error == nil else {
            // The formula shows as its source; the reason goes to the log.
            let message = error?.localizedDescription ?? "no error"
            MarkdownMathRenderer.log.debug("SwiftMath could not read \(latex): \(message, privacy: .public)")
            return .failure(MathFailure(reason: .unreadable(message)))
        }
        restore(list, texts)
        return .success(list)
    }

    private static func register(_ count: Int) {
        while registered < count {
            // SwiftMath has no public initializer, so an ordinary atom is borrowed.
            guard let atom = MTMathAtomFactory.atom(forCharacter: "/"),
                  let mark = UnicodeScalar(firstMark + UInt32(registered)) else { return }
            atom.nucleus = String(mark)
            MTMathAtomFactory.add(latexSymbol: MathSyntax.placeholderName(registered), value: atom)
            registered += 1
        }
    }

    private static func restore(_ list: MTMathList?, _ texts: [String]) {
        for atom in list?.atoms ?? [] {
            let scalars = atom.nucleus.unicodeScalars
            if scalars.count == 1, let value = scalars.first?.value, value >= firstMark,
               Int(value - firstMark) < texts.count {
                atom.nucleus = texts[Int(value - firstMark)]
            }
            restore(atom.superScript, texts)
            restore(atom.subScript, texts)
            switch atom {
            case let fraction as MTFraction:
                restore(fraction.numerator, texts)
                restore(fraction.denominator, texts)
            case let radical as MTRadical:
                restore(radical.radicand, texts)
                restore(radical.degree, texts)
            case let inner as MTInner: restore(inner.innerList, texts)
            case let line as MTOverLine: restore(line.innerList, texts)
            case let line as MTUnderLine: restore(line.innerList, texts)
            case let accent as MTAccent: restore(accent.innerList, texts)
            case let color as MTMathColor: restore(color.innerList, texts)
            case let color as MTMathTextColor: restore(color.innerList, texts)
            case let box as MTMathColorbox: restore(box.innerList, texts)
            case let table as MTMathTable:
                for cell in table.cells.joined() { restore(cell, texts) }
            default: break
            }
        }
    }
}
