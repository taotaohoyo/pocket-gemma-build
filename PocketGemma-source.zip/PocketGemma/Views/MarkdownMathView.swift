import SwiftUI
import UIKit
import SwiftMath

/// A `$$…$$` formula on its own line, centered; a wide one scrolls sideways.
/// LaTeX SwiftMath cannot typeset is shown as its source.
struct MarkdownMathBlock: View {
    let latex: String
    @ScaledMetric(relativeTo: .body) private var size: CGFloat = 19

    var body: some View {
        if let rendered = MarkdownMathRenderer.render(latex, display: true, fontSize: size) {
            ViewThatFits(in: .horizontal) {
                rendered.image.frame(maxWidth: .infinity)
                ScrollView(.horizontal, showsIndicators: false) { rendered.image }
                    .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            }
            .padding(.vertical, 4)
        } else {
            Text(verbatim: latex)
                .font(.system(.footnote, design: .monospaced))
                .foregroundStyle(.secondary)
        }
    }
}

/// Typesets LaTeX with SwiftMath (Latin Modern Math) into a template image,
/// which takes the text color, so one image serves light and dark mode.
@MainActor
enum MarkdownMathRenderer {
    struct Rendered {
        let image: Image
        /// How far the formula reaches below the text's baseline.
        let descent: CGFloat
    }

    private final class Entry {
        let rendered: Rendered?
        init(_ rendered: Rendered?) { self.rendered = rendered }
    }

    private static let cache: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 300
        return cache
    }()

    static func render(_ latex: String, display: Bool, fontSize: CGFloat) -> Rendered? {
        let key = "\(display ? "D" : "T")\(fontSize)\u{0}\(latex)" as NSString
        if let entry = cache.object(forKey: key) { return entry.rendered }
        let rendered = typeset(latex, display: display, fontSize: fontSize)
        cache.setObject(Entry(rendered), forKey: key)
        return rendered
    }

    private static func typeset(_ latex: String, display: Bool, fontSize: CGFloat) -> Rendered? {
        guard !latex.isEmpty, latex.count < 4_000 else { return nil }
        let label = MTMathUILabel()
        label.labelMode = display ? .display : .text
        label.fontSize = fontSize
        label.textColor = .black
        label.latex = latex
        guard label.error == nil else { return nil }
        let size = label.intrinsicContentSize
        guard size.width > 0, size.height > 0, size.width < 6_000, size.height < 2_000 else { return nil }
        label.frame = CGRect(origin: .zero, size: size)
        label.setNeedsLayout()
        label.layoutIfNeeded()
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        format.opaque = false
        let picture = UIGraphicsImageRenderer(size: size, format: format).image { context in
            // The label draws in a flipped layer's coordinates.
            if label.layer.isGeometryFlipped {
                context.cgContext.translateBy(x: 0, y: size.height)
                context.cgContext.scaleBy(x: 1, y: -1)
            }
            label.draw(label.bounds)
        }
        guard let cgImage = picture.cgImage else { return nil }
        let image = Image(cgImage, scale: format.scale, label: Text(verbatim: "数式 \(latex)"))
            .renderingMode(.template)
        let descent = label.displayList.map { CGFloat($0.descent) } ?? size.height / 4
        return Rendered(image: image, descent: min(max(0, descent), size.height))
    }
}
