import SwiftUI
import UIKit
import PocketCore

/// 設定 › Claude (1.1.0 (257), the user's directive of 2026-11-06 「Claude
/// API 接続」): this iPhone's registration with the developer's relay,
/// whether Claude answers now and why not, and 登録を解除; with none, an
/// invite link to enter and the developer's own registration. On the
/// developer's iPhone, the relay's management: friends on or off (off
/// until the developer has checked Anthropic's terms), friends invited,
/// stopped, let back in or deleted, and 再開 after the credit or the spend
/// limit stopped it (nothing is bought).
struct ClaudeSettingsView: View {
    @ObservedObject private var link = ClaudeLinkStore.shared

    var body: some View {
        let _ = SettingsSlideMeter.drew("Claude")
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Anthropicの外部AI「Claude」を、Fieluaのチャットで使えます。使えるのは、開発者が招待した人だけです。")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("claude-lead")
                if let invite = link.pendingInvite {
                    ClaudeInviteCard(invite: invite)
                }
                if link.isRegistered {
                    ClaudeAccountCard()
                    if link.account?.isDeveloper == true { ClaudeAdminCard() }
                } else {
                    ClaudeJoinCard()
                    ClaudeDeveloperCard()
                }
                ClaudeNotes()
            }
            .padding(20)
        }
        .accessibilityIdentifier("claude-settings")
        // The keys and names typed here: a drag puts the keyboard away.
        .scrollDismissesKeyboard(.interactively)
        .settingsScroll()
        .onAppear { link.refresh() }
    }
}

/// What goes where, said plainly (the directive: an external AI, made clear).
private struct ClaudeNotes: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Claudeを選んだチャットでは、質問と、そのチャットのこれまでの文字のやりとりだけが、暗号化した通信で開発者の中継サーバーを通ってAnthropicに送られます。写真・ファイル・音声、ほかのチャット、Smart Memoryは送りません。")
            Text("中継サーバーは会話を保存も記録もしません。Anthropicは規約に沿って一定期間データを保持することがありますが、モデルの学習には使いません。Claudeの答えは誤りを含むことがあります。大事なことは確かめてください。")
            Text("ClaudeはAnthropicのAPIクレジットで動きます。クレジットがなくなると自動で止まり、追加購入はしません。")
        }
        .font(.caption).foregroundStyle(.secondary)
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityIdentifier("claude-notes")
    }
}

// MARK: - Registered

/// This iPhone's registration: the model, whether it answers, and 登録を解除.
private struct ClaudeAccountCard: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.closeSettings) private var closeSettings
    @State private var confirmLeave = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                ClaudeMark(size: 40)
                VStack(alignment: .leading, spacing: 3) {
                    Text(verbatim: link.target().modelName)
                        .font(.headline)
                        .accessibilityIdentifier("claude-model")
                    ClaudeStatusLine()
                }
                Spacer(minLength: 4)
            }
            if let problem = link.problem, link.state != .none {
                Label(problem, systemImage: "exclamationmark.circle")
                    .font(.subheadline).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("claude-problem")
            }
            if let account = link.account {
                VStack(alignment: .leading, spacing: 2) {
                    if account.isDeveloper { Text("開発者として登録") } else { Text("\(account.name)として登録") }
                    Text("中継サーバー: \(account.host)")
                    Text("登録した日: \(account.registeredAt.formatted(date: .abbreviated, time: .omitted))")
                }
                .font(.caption).foregroundStyle(.secondary)
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("claude-account")
            }
            Button {
                chats.newClaudeChat()
                closeSettings()
            } label: {
                Text("Claudeで会話を始める").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .fieluaProminentButton()
            .controlSize(.large)
            .disabled(chats.isGenerating)
            .accessibilityIdentifier("claude-start-chat")
            HStack(spacing: 10) {
                Button {
                    link.refresh()
                } label: {
                    Text("状態を確かめる").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(link.state == .checking)
                .accessibilityIdentifier("claude-check")
                Button(role: .destructive) {
                    confirmLeave = true
                } label: {
                    Text("登録を解除").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .accessibilityIdentifier("claude-leave")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-registered")
        .confirmationDialog("Claudeの登録を解除しますか？", isPresented: $confirmLeave, titleVisibility: .visible) {
            Button("登録を解除", role: .destructive) { Task { await link.leave() } }
                .accessibilityIdentifier("claude-leave-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("中継サーバーからもこのiPhoneの登録を消します。Claudeと話した会話は、このiPhoneに残ります。")
        }
    }
}

/// Whether Claude answers now, in a word and a dot.
struct ClaudeStatusLine: View {
    @ObservedObject private var link = ClaudeLinkStore.shared

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7).accessibilityHidden(true)
            Text(text).font(.caption).foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("claude-status")
    }

    private var color: Color {
        switch link.state {
        case .ready: return .green
        case .checking, .none: return Color.secondary.opacity(0.5)
        default: return Theme.caution
        }
    }

    private var text: String {
        switch link.state {
        case .ready: return String(localized: "使えます · 外部AI")
        case .checking: return String(localized: "確かめています…")
        case .unavailable(let reason): return reason.short
        case .revoked: return String(localized: "利用を止められています")
        case .removed: return String(localized: "登録が削除されました")
        case .unreachable: return String(localized: "接続できません")
        case .none: return String(localized: "未登録")
        }
    }
}

// MARK: - Joining

/// An invite link pasted, when it didn't open Fielua by itself.
private struct ClaudeJoinCard: View {
    @State private var text = ""
    @State private var problem: String?
    /// The pasted invite, shown before anything is sent.
    @State private var invite: ClaudeInvite?

    var body: some View {
        if let invite {
            ClaudeInviteCard(invite: invite) {
                self.invite = nil
                text = ""
            }
        } else {
            entry
        }
    }

    private var entry: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("招待リンクを入力")
                .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                .accessibilityAddTraits(.isHeader)
            Text("開発者から届いた招待リンクを開くと、Fieluaで登録できます。開かないときは、リンクをここに貼り付けてください。")
                .font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            TextField("https://…/join#…", text: $text)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(.horizontal, 14).frame(minHeight: 50)
                .fieluaCard(cornerRadius: 14)
                .accessibilityIdentifier("claude-invite-field")
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .accessibilityIdentifier("claude-invite-problem")
            }
            Button {
                if let read = ClaudeInvite(text, allowsLocal: ClaudeLinkStore.allowsLocal) {
                    problem = nil
                    invite = read
                } else {
                    problem = String(localized: "招待リンクとして読み取れません。届いたリンクをそのまま貼り付けてください。")
                }
            } label: {
                Text("確認する").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .fieluaSecondaryButton()
            .controlSize(.large)
            .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .accessibilityIdentifier("claude-invite-read")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-join")
    }
}

/// An invite, before anything is sent: whose relay, and what Claude is.
/// The same card in 設定 › Claude and in the sheet a link opens.
struct ClaudeInviteCard: View {
    let invite: ClaudeInvite
    var done: () -> Void = {}
    @ObservedObject private var link = ClaudeLinkStore.shared
    @State private var busy = false
    @State private var problem: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ClaudeMark(size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Claudeを使う招待").font(.headline)
                    Text(verbatim: invite.host).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("claude-invite-host")
                }
            }
            Text("登録すると、このiPhoneから開発者の中継サーバーを通してClaude（Anthropicの外部AI）を使えます。招待は一度だけ使えます。")
                .font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            if link.isRegistered {
                Text("今の登録はこの招待に置き換わります。")
                    .font(.caption).foregroundStyle(Theme.caution)
            }
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("claude-redeem-problem")
            }
            HStack(spacing: 10) {
                Button {
                    if link.pendingInvite == invite { link.pendingInvite = nil }
                    done()
                } label: {
                    Text("やめる").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .accessibilityIdentifier("claude-invite-cancel")
                Button {
                    busy = true
                    Task {
                        do {
                            try await link.redeem(invite)
                            done()
                        } catch {
                            problem = error.localizedDescription
                        }
                        busy = false
                    }
                } label: {
                    Group { if busy { Text("登録しています…") } else { Text("登録する") } }
                        .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaProminentButton()
                .controlSize(.large)
                .disabled(busy)
                .accessibilityIdentifier("claude-invite-accept")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-invite")
    }
}

/// The developer's own registration: the relay's address and the admin
/// key that the relay's ADMIN_TOKEN holds (made here, then pasted there).
private struct ClaudeDeveloperCard: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @State private var open = false
    @State private var server = ""
    @State private var key = ""
    @State private var copied = false
    @State private var busy = false
    @State private var problem: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                withAnimation(.smooth(duration: 0.25)) { open.toggle() }
            } label: {
                HStack {
                    Text("開発者として登録").font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                    Spacer()
                    Image(systemName: open ? "chevron.up" : "chevron.down")
                        .font(.system(size: 12, weight: .semibold)).foregroundStyle(.tertiary)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("claude-developer-toggle")
            if open { fields }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-developer")
    }

    @ViewBuilder private var fields: some View {
        Text("中継サーバー（Cloudflare Workers）を公開したあと、そのアドレスと管理キーで、このiPhoneを開発者として登録します。")
            .font(.subheadline).foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
        TextField("https://fielua-claude.….workers.dev", text: $server)
            .keyboardType(.URL)
            .textContentType(.URL)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .padding(.horizontal, 14).frame(minHeight: 50)
            .fieluaCard(cornerRadius: 14)
            .accessibilityIdentifier("claude-server-field")
        SecureField("管理キー（ADMIN_TOKEN）", text: $key)
            // A key, not a password: iOS doesn't offer to save it in
            // Passwords (it stays in this iPhone's keychain only).
            .textContentType(.oneTimeCode)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .padding(.horizontal, 14).frame(minHeight: 50)
            .fieluaCard(cornerRadius: 14)
            .accessibilityIdentifier("claude-admin-field")
        Button {
            key = ClaudeLinkStore.newAdminKey()
            ClaudeLinkStore.copySecret(key)
            copied = true
        } label: {
            Label("新しい管理キーを作ってコピー", systemImage: "key")
                .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
        }
        .fieluaSecondaryButton()
        .controlSize(.large)
        .accessibilityIdentifier("claude-admin-new")
        if copied {
            Text("コピーしました（このiPhoneだけ、10分で消えます）。CloudflareのWorkerの「変数とシークレット」に、シークレット ADMIN_TOKEN として貼り付けてから登録してください。")
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("claude-admin-copied")
        }
        if let problem {
            Text(problem).font(.caption).foregroundStyle(Theme.caution)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityIdentifier("claude-developer-problem")
        }
        Button {
            busy = true
            Task {
                do {
                    try await link.registerAsDeveloper(server: server, adminKey: key)
                    problem = nil
                    key = ""
                    // The page now shows the relay's management: no keyboard over it.
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                } catch {
                    problem = error.localizedDescription
                }
                busy = false
            }
        } label: {
            Group { if busy { Text("登録しています…") } else { Text("このiPhoneを開発者として登録") } }
                .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
        }
        .fieluaProminentButton()
        .controlSize(.large)
        .disabled(busy || server.isEmpty || key.count < 32)
        .accessibilityIdentifier("claude-developer-register")
    }
}

// MARK: - The developer's management

/// Friends on or off, invites, the people registered, and 再開.
private struct ClaudeAdminCard: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @State private var admin: ClaudeAdminState?
    @State private var problem: String?
    @State private var busy = false
    @State private var confirmFriends = false
    @State private var friendName = ""
    @State private var inviteLink: URL?
    @State private var removing: ClaudeAdminState.Person?
    @State private var key = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("開発者の管理")
                .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                .accessibilityAddTraits(.isHeader)
            if !link.hasAdminKey {
                keyEntry
            } else if let admin {
                manage(admin)
            } else {
                Text(problem ?? String(localized: "読み込んでいます…"))
                    .font(.subheadline).foregroundStyle(problem == nil ? Color.secondary : Theme.caution)
            }
            if let problem, admin != nil {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("claude-admin-problem")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-admin")
        .task(id: link.hasAdminKey) { await load() }
        .confirmationDialog("Anthropicの規約の確認は済みましたか？", isPresented: $confirmFriends, titleVisibility: .visible) {
            Button("確認済み・オンにする") { run { try await link.setFriendsEnabled(true) } }
                .accessibilityIdentifier("claude-friends-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("友人に使ってもらう前に、Anthropicの利用規約と利用ポリシーに合っているかを確かめてください。確かめるまでは、開発者だけが使えます。")
        }
        .confirmationDialog("この人の登録を削除しますか？", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }),
                            titleVisibility: .visible) {
            Button("削除", role: .destructive) {
                if let person = removing { run { try await link.delete(person) } }
            }
            .accessibilityIdentifier("claude-person-delete-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("その人の端末からはClaudeを使えなくなります。もう一度使うには、新しい招待が必要です。")
        }
    }

    private var keyEntry: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("このiPhoneに管理キーがありません。管理するには、CloudflareのADMIN_TOKENと同じキーを入れてください。")
                .font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            SecureField("管理キー（ADMIN_TOKEN）", text: $key)
                .textContentType(.oneTimeCode)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(.horizontal, 14).frame(minHeight: 50)
                .fieluaCard(cornerRadius: 14)
                .accessibilityIdentifier("claude-admin-key-field")
            Button {
                run { try await link.useAdminKey(key); key = "" }
            } label: {
                Text("管理キーを使う").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .fieluaSecondaryButton()
            .controlSize(.large)
            .disabled(busy || key.count < 32)
            .accessibilityIdentifier("claude-admin-key-use")
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
            }
        }
    }

    @ViewBuilder private func manage(_ admin: ClaudeAdminState) -> some View {
        if let paused = admin.paused {
            VStack(alignment: .leading, spacing: 8) {
                Label(paused.message, systemImage: "pause.circle")
                    .font(.subheadline).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Anthropic Consoleでクレジットと利用上限を確かめてから再開してください。Fieluaが購入や上限の変更をすることはありません。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Button {
                    run { try await link.resume() }
                } label: {
                    Text("Claudeを再開する").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
                }
                .fieluaProminentButton()
                .controlSize(.large)
                .disabled(busy)
                .accessibilityIdentifier("claude-resume")
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("claude-paused")
        }
        if !admin.configured {
            Text(ClaudeUnavailable.notConfigured.message)
                .font(.subheadline).foregroundStyle(Theme.caution)
        }
        Toggle(isOn: Binding(get: { admin.friendsEnabled }, set: { on in
            if on { confirmFriends = true } else { run { try await link.setFriendsEnabled(false) } }
        })) {
            VStack(alignment: .leading, spacing: 2) {
                Text("友人の利用")
                Group { if admin.friendsEnabled { Text("招待した友人もClaudeを使えます") } else { Text("オフ: 開発者だけが使えます") } }
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .disabled(busy)
        .accessibilityIdentifier("claude-friends")
        Divider()
        inviteSection
        if !admin.people.isEmpty {
            Divider()
            ForEach(admin.people) { person in personRow(person) }
        }
        if !admin.invites.isEmpty {
            Divider()
            ForEach(admin.invites) { invite in inviteRow(invite) }
        }
        Divider()
        Button(role: .destructive) {
            link.forgetAdminKey()
        } label: {
            Text("管理キーをこのiPhoneから消す").font(.footnote)
        }
        .buttonStyle(.plain).foregroundStyle(Theme.caution)
        .accessibilityIdentifier("claude-admin-forget")
    }

    @ViewBuilder private var inviteSection: some View {
        Text("友人を招待").font(.subheadline.weight(.semibold))
        TextField("友人の名前（管理用）", text: $friendName)
            .padding(.horizontal, 14).frame(minHeight: 46)
            .fieluaCard(cornerRadius: 14)
            .accessibilityIdentifier("claude-friend-name")
        Button {
            let name = friendName.trimmingCharacters(in: .whitespacesAndNewlines)
            run {
                inviteLink = try await link.invite(name: name)
                friendName = ""
            }
        } label: {
            Text("招待リンクを作る").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
        }
        .fieluaSecondaryButton()
        .controlSize(.large)
        .disabled(busy || friendName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        .accessibilityIdentifier("claude-friend-invite")
        if let inviteLink {
            VStack(alignment: .leading, spacing: 8) {
                Text("一度だけ使えて、72時間で無効になるリンクです。本人にだけ送ってください。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 10) {
                    ShareLink(item: inviteLink) {
                        Label("送る", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                    }
                    .fieluaProminentButton()
                    .accessibilityIdentifier("claude-friend-share")
                    Button {
                        ClaudeLinkStore.copySecret(inviteLink.absoluteString)
                    } label: {
                        Label("コピー", systemImage: "doc.on.doc").frame(maxWidth: .infinity)
                    }
                    .fieluaSecondaryButton()
                    .accessibilityIdentifier("claude-friend-copy")
                }
            }
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("claude-friend-link")
        }
    }

    private func personRow(_ person: ClaudeAdminState.Person) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: person.name).font(.body)
                Text(personDetail(person)).font(.caption).foregroundStyle(person.active ? Color.secondary : Theme.caution)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            // The developer's own registration is left alone here (登録を解除 above).
            if !person.isDeveloper {
                Button {
                    run { try await link.setActive(person, !person.active) }
                } label: {
                    if person.active { Text("止める") } else { Text("再開") }
                }
                .fieluaSecondaryButton()
                .disabled(busy)
                .accessibilityIdentifier("claude-person-toggle-\(person.name)")
                Button(role: .destructive) {
                    removing = person
                } label: {
                    Image(systemName: "trash").accessibilityLabel("削除")
                }
                .fieluaSecondaryButton()
                .disabled(busy)
                .accessibilityIdentifier("claude-person-delete-\(person.name)")
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-person-\(person.name)")
    }

    private func personDetail(_ person: ClaudeAdminState.Person) -> String {
        let role = person.isDeveloper ? String(localized: "開発者") : String(localized: "友人")
        let state = person.active ? String(localized: "使用可") : String(localized: "停止中")
        guard let used = person.lastUsed else { return "\(role) · \(state)" }
        return "\(role) · \(state) · " + String(localized: "最終利用 \(used.formatted(date: .abbreviated, time: .shortened))")
    }

    private func inviteRow(_ invite: ClaudeAdminState.OpenInvite) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: invite.name).font(.body)
                Text("招待中 · \(invite.expires.formatted(date: .abbreviated, time: .shortened))まで")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Button("取り消す") { run { try await link.cancel(invite) } }
                .fieluaSecondaryButton()
                .disabled(busy)
                .accessibilityIdentifier("claude-invite-withdraw-\(invite.name)")
        }
        .accessibilityElement(children: .contain)
    }

    /// One change at the relay, then the state again.
    private func run(_ change: @escaping () async throws -> Void) {
        busy = true
        Task {
            do {
                try await change()
                problem = nil
            } catch {
                problem = error.localizedDescription
            }
            await load()
            busy = false
        }
    }

    private func load() async {
        guard link.hasAdminKey else { admin = nil; return }
        do {
            admin = try await link.adminState()
        } catch {
            problem = error.localizedDescription
        }
    }
}

// MARK: - A link that opens Fielua

/// fielua://claude?server=..&code=.. (the relay's /join page): the invite
/// is shown before anything is sent, in a sheet, or in 設定 › Claude when
/// that is open.
struct ClaudeInviteHandler: ViewModifier {
    @ObservedObject private var link = ClaudeLinkStore.shared

    func body(content: Content) -> some View {
        content
            .onOpenURL { url in
                guard url.scheme == "fielua", url.host == "claude" else { return }
                link.pendingInvite = ClaudeInvite(url.absoluteString, allowsLocal: ClaudeLinkStore.allowsLocal)
            }
            .sheet(item: $link.pendingInvite) { invite in
                ScrollView {
                    ClaudeInviteCard(invite: invite) { link.pendingInvite = nil }
                        .padding(20)
                }
                .presentationDetents([.medium, .large])
            }
    }
}
