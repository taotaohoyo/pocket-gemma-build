import SwiftUI
import UIKit
import PocketCore

/// 設定 › Claude (1.1.0 (257), the user's directive of 2026-11-06 「Claude
/// API 接続」): this iPhone's registration with the developer's relay,
/// whether Claude answers now and why not, and 登録を解除; with none, an
/// invite link to enter and the developer's own registration. On the
/// developer's iPhone, the relay's management: friends on or off (off
/// until the developer has checked Anthropic's terms), friends invited,
/// stopped, let back in or deleted, and 再開 after the credit or the spend
/// limit stopped it (nothing is bought).
struct ClaudeSettingsView: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        let _ = SettingsSlideMeter.drew("Claude")
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let invite = link.pendingInvite {
                    ClaudeInviteCard(invite: invite).transition(.opacity)
                }
                if link.isRegistered {
                    ClaudeAccountCard().transition(.opacity)
                    if link.account?.isDeveloper == true { ClaudeAdminCard().transition(.opacity) }
                } else {
                    ClaudeJoinCard().transition(.opacity)
                    ClaudeDeveloperCard().transition(.opacity)
                }
            }
            .padding(20)
            // One card takes another's place (registered, 登録を解除, an
            // invite opened or answered) and the explanation comes and goes:
            // in one motion with the cards under it, where every one of
            // these was a cut before 1.1.0 (263).
            .animation(FieluaMotion.change(reduceMotion), value: link.isRegistered)
            .animation(FieluaMotion.change(reduceMotion), value: link.pendingInvite)
            .animation(FieluaMotion.change(reduceMotion), value: link.problem)
        }
        .sensoryFeedback(.success, trigger: link.isRegistered) { _, now in now }
        .accessibilityIdentifier("claude-settings")
        // The keys and names typed here: a drag puts the keyboard away.
        .scrollDismissesKeyboard(.interactively)
        .settingsScroll()
        .onAppear { link.refresh() }
    }
}

// MARK: - Registered

/// This iPhone's registration: the model, whether it answers, and 登録を解除.
private struct ClaudeAccountCard: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    // The chat's store is acted on, not observed (ChatPulse, 1.1.0 (263)).
    @ObservedObject private var pulse = ChatPulse.shared
    @Environment(\.chatHandle) private var chatHandle
    @Environment(\.closeSettings) private var closeSettings
    @State private var confirmLeave = false
    /// 状態を確かめる was pressed, until the relay has answered: the button
    /// shows that it works (the check as the page opens leaves it alone).
    @State private var asked = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                ClaudeMark(size: 40)
                VStack(alignment: .leading, spacing: 3) {
                    Text(verbatim: link.target().modelName)
                        .font(.headline)
                        .accessibilityIdentifier("claude-model")
                    ClaudeStatusLine()
                }
                Spacer(minLength: 4)
            }
            if let problem = link.problem, link.state != .none {
                Label(problem, systemImage: "exclamationmark.circle")
                    .font(.subheadline).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
                    .accessibilityIdentifier("claude-problem")
            }
            if let account = link.account {
                VStack(alignment: .leading, spacing: 2) {
                    if account.isDeveloper { Text("開発者として登録") } else { Text("\(account.name)として登録") }
                    Text("中継サーバー: \(account.host)")
                    Text("登録した日: \(account.registeredAt.formatted(date: .abbreviated, time: .omitted))")
                }
                .font(.caption).foregroundStyle(.secondary)
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("claude-account")
            }
            Button {
                chatHandle.store?.newClaudeChat()
                closeSettings()
            } label: {
                Text("Claudeで会話を始める").font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
            }
            .fieluaProminentButton()
            .controlSize(.large)
            .disabled(pulse.isGenerating || link.leaving)
            .accessibilityIdentifier("claude-start-chat")
            HStack(spacing: 10) {
                Button {
                    asked = true
                    link.refresh()
                } label: {
                    FieluaBusyLabel("状態を確かめる", busy: checking).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(checking || link.leaving)
                .accessibilityIdentifier("claude-check")
                // The relay is told first, which can take as long as the
                // connection waits when it can't be reached: the button
                // says so, and can't start a second one (1.1.0 (263)).
                Button(role: .destructive) {
                    confirmLeave = true
                } label: {
                    FieluaBusyLabel("登録を解除", busy: link.leaving).frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(link.leaving)
                .accessibilityIdentifier("claude-leave")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-registered")
        .onChange(of: link.state) { _, state in
            if state != .checking { asked = false }
        }
        .confirmationDialog("Claudeの登録を解除しますか？", isPresented: $confirmLeave, titleVisibility: .visible) {
            Button("登録を解除", role: .destructive) { Task { await link.leave() } }
                .accessibilityIdentifier("claude-leave-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("中継サーバーからもこのiPhoneの登録を消します。Claudeと話した会話は、このiPhoneに残ります。")
        }
    }

    private var checking: Bool { asked && link.state == .checking }
}

/// Whether Claude answers now, in a word and a dot.
struct ClaudeStatusLine: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7).accessibilityHidden(true)
            Text(text).font(.caption).foregroundStyle(.secondary)
                .contentTransition(.opacity)
        }
        .animation(FieluaMotion.change(reduceMotion), value: link.state)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("claude-status")
    }

    private var color: Color {
        switch link.state {
        case .ready: return Theme.positive
        case .checking, .none: return Color.secondary.opacity(0.5)
        default: return Theme.caution
        }
    }

    private var text: String {
        switch link.state {
        case .ready: return String(localized: "使えます · 外部AI")
        case .checking: return String(localized: "確かめています…")
        case .unavailable(let reason): return reason.short
        case .revoked: return String(localized: "利用を止められています")
        case .removed: return String(localized: "登録が削除されました")
        case .unreachable: return String(localized: "接続できません")
        case .none: return String(localized: "未登録")
        }
    }
}

// MARK: - Joining

/// An invite link pasted, when it didn't open Fielua by itself.
private struct ClaudeJoinCard: View {
    @State private var text = ""
    @State private var problem: String?
    /// The pasted invite, shown before anything is sent.
    @State private var invite: ClaudeInvite?
    @State private var refusals = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        if let invite {
            ClaudeInviteCard(invite: invite) {
                withAnimation(FieluaMotion.change(reduceMotion)) {
                    self.invite = nil
                    text = ""
                }
            }
            .transition(.opacity)
        } else {
            entry.transition(.opacity)
        }
    }

    private var entry: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("招待リンクを入力")
                .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                .accessibilityAddTraits(.isHeader)
            TextField("https://…/join#…", text: $text)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .fieluaField()
                .accessibilityIdentifier("claude-invite-field")
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
                    .accessibilityIdentifier("claude-invite-problem")
            }
            Button {
                let read = ClaudeInvite(text, allowsLocal: ClaudeLinkStore.allowsLocal)
                withAnimation(FieluaMotion.change(reduceMotion)) {
                    if let read {
                        problem = nil
                        invite = read
                    } else {
                        problem = String(localized: "招待リンクとして読み取れません。届いたリンクをそのまま貼り付けてください。")
                    }
                }
                if read == nil { refusals += 1 }
            } label: {
                Text("確認する").frame(maxWidth: .infinity)
            }
            .fieluaSecondaryButton()
            .controlSize(.large)
            .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .accessibilityIdentifier("claude-invite-read")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .sensoryFeedback(.error, trigger: refusals)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-join")
    }
}

/// An invite, before anything is sent: whose relay, and what Claude is.
/// The same card in 設定 › Claude and in the sheet a link opens.
struct ClaudeInviteCard: View {
    let invite: ClaudeInvite
    /// In the sheet a link opens, the card says 「登録しました」 itself before
    /// the sheet goes: it closed without a word until 1.1.0 (263). In
    /// 設定 › Claude the page says it, as the registration takes the card's place.
    var confirms = false
    var done: () -> Void = {}
    @ObservedObject private var link = ClaudeLinkStore.shared
    @ObservedObject private var pulse = ChatPulse.shared
    @Environment(\.chatHandle) private var chatHandle
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var busy = false
    @State private var problem: String?
    @State private var registered = false
    /// Whether a registration was here as 登録する was pressed (the store
    /// has the new one before it answers, and the line must not come then).
    @State private var replaced: Bool?
    @State private var failures = 0

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if registered {
                welcome.transition(.opacity)
            } else {
                question.transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .sensoryFeedback(.success, trigger: registered) { _, now in now }
        .sensoryFeedback(.error, trigger: failures)
        // The sheet stays while the relay is asked: swiped away, it would
        // register without a word after all.
        .interactiveDismissDisabled(confirms && busy)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-invite")
    }

    private var question: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ClaudeMark(size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Claudeを使う招待").font(.headline)
                    Text(verbatim: invite.host).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("claude-invite-host")
                }
            }
            if replaced ?? link.isRegistered {
                Text("今の登録はこの招待に置き換わります。")
                    .font(.caption).foregroundStyle(Theme.caution)
            }
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
                    .accessibilityIdentifier("claude-redeem-problem")
            }
            HStack(spacing: 10) {
                Button {
                    finish()
                } label: {
                    Text("やめる").frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(busy)
                .accessibilityIdentifier("claude-invite-cancel")
                Button {
                    busy = true
                    replaced = link.isRegistered
                    Task {
                        do {
                            try await link.redeem(invite)
                            if confirms {
                                withAnimation(FieluaMotion.change(reduceMotion)) { registered = true }
                            } else {
                                finish()
                            }
                        } catch {
                            withAnimation(FieluaMotion.change(reduceMotion)) { problem = error.localizedDescription }
                            replaced = nil
                            failures += 1
                        }
                        busy = false
                    }
                } label: {
                    FieluaBusyLabel("登録する", busy: busy).frame(maxWidth: .infinity)
                }
                .fieluaProminentButton()
                .controlSize(.large)
                .disabled(busy)
                .accessibilityIdentifier("claude-invite-accept")
            }
        }
    }

    /// Registered, in the sheet: a word, whether Claude answers, and the
    /// way into a chat, as the registered page offers.
    private var welcome: some View {
        VStack(spacing: 14) {
            FieluaSuccessMark(size: 44).padding(.top, 4)
            VStack(spacing: 4) {
                Text("登録しました").font(.headline)
                    .accessibilityAddTraits(.isHeader)
                ClaudeStatusLine()
            }
            VStack(spacing: 10) {
                Button {
                    chatHandle.store?.newClaudeChat()
                    finish()
                } label: {
                    Text("Claudeで会話を始める").frame(maxWidth: .infinity)
                }
                .fieluaProminentButton()
                .controlSize(.large)
                .disabled(pulse.isGenerating)
                .accessibilityIdentifier("claude-invite-start")
                Button {
                    finish()
                } label: {
                    Text("閉じる").frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .accessibilityIdentifier("claude-invite-done")
            }
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-invite-registered")
    }

    private func finish() {
        if link.pendingInvite == invite { link.pendingInvite = nil }
        done()
    }
}

/// The developer's own registration: the relay's address and the admin
/// key that the relay's ADMIN_TOKEN holds (made here, then pasted there).
private struct ClaudeDeveloperCard: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @State private var open = false
    @State private var server = ""
    @State private var key = ""
    @State private var copied = false
    @State private var busy = false
    @State private var problem: String?
    @State private var failures = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // The line that opens it is 設定's one part since 1.1.0 (263)
            // (its arrow was swapped for another, up for down, before).
            FieluaDisclosure("開発者として登録", open: $open, font: .footnote.weight(.semibold), quiet: true)
                .accessibilityIdentifier("claude-developer-toggle")
            if open {
                VStack(alignment: .leading, spacing: 10) { fields }
                    .transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .sensoryFeedback(.error, trigger: failures)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-developer")
    }

    @ViewBuilder private var fields: some View {
        TextField("https://fielua-claude.….workers.dev", text: $server)
            .keyboardType(.URL)
            .textContentType(.URL)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .fieluaField()
            .accessibilityIdentifier("claude-server-field")
        SecureField("管理キー（ADMIN_TOKEN）", text: $key)
            // A key, not a password: iOS doesn't offer to save it in
            // Passwords (it stays in this iPhone's keychain only).
            .textContentType(.oneTimeCode)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .fieluaField()
            .accessibilityIdentifier("claude-admin-field")
        // The button itself answers, for a moment (a 「コピーしました」 under
        // it stayed for good before 1.1.0 (263)).
        Button {
            key = ClaudeLinkStore.newAdminKey()
            ClaudeLinkStore.copySecret(key)
            copied = true
        } label: {
            FieluaCopyLabel(copied: copied, title: "新しい管理キーを作ってコピー", systemImage: "key")
                .frame(maxWidth: .infinity)
        }
        .fieluaSecondaryButton()
        .controlSize(.large)
        .fieluaConfirmation($copied)
        .accessibilityIdentifier("claude-admin-new")
        if let problem {
            Text(problem).font(.caption).foregroundStyle(Theme.caution)
                .fixedSize(horizontal: false, vertical: true)
                .transition(.opacity)
                .accessibilityIdentifier("claude-developer-problem")
        }
        Button {
            // The key leaves the field before the page changes, so iOS has
            // no password to offer to save (it is put back if this fails).
            // The keyboard goes as well: the relay's management comes next.
            let typed = key
            key = ""
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            busy = true
            Task {
                do {
                    try await link.registerAsDeveloper(server: server, adminKey: typed)
                    problem = nil
                } catch {
                    key = typed
                    withAnimation(FieluaMotion.change(reduceMotion)) { problem = error.localizedDescription }
                    failures += 1
                }
                busy = false
            }
        } label: {
            FieluaBusyLabel("このiPhoneを開発者として登録", busy: busy).frame(maxWidth: .infinity)
        }
        .fieluaProminentButton()
        .controlSize(.large)
        .disabled(busy || server.isEmpty || key.count < 32)
        .accessibilityIdentifier("claude-developer-register")
    }
}

// MARK: - The developer's management

/// Friends on or off, invites, the people registered, and 再開: with
/// the admin key, or with Face ID on an iPhone a developer's invite
/// registered (1.1.0 (262)), which asks before the first look and again
/// once 15 minutes have passed.
private struct ClaudeAdminCard: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var admin: ClaudeAdminState?
    @State private var problem: String?
    @State private var busy = false
    /// The button whose work runs while `busy`: its label shows it
    /// (FieluaBusyLabel). Every button only dimmed before 1.1.0 (263).
    @State private var working: String?
    /// 友人の利用 as it was just set, until the relay has answered: the
    /// switch stays where the finger put it (it sprang back for the length
    /// of the call before).
    @State private var friendsAsked: Bool?
    @State private var confirmFriends = false
    @State private var friendName = ""
    @State private var inviteLink: URL?
    @State private var linkCopied = false
    @State private var removing: ClaudeAdminState.Person?
    @State private var key = ""
    @State private var failures = 0

    /// What the card is made of: as it changes, the card changes in one
    /// motion (its parts were cut in and out before 1.1.0 (263)).
    private struct Parts: Equatable {
        var admin: ClaudeAdminState?
        var problem: String?
        var invite: URL?
        var manages: Bool
        var locked: Bool
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("開発者の管理")
                .font(.footnote.weight(.semibold)).foregroundStyle(.secondary)
                .accessibilityAddTraits(.isHeader)
            if !link.canManage {
                keyEntry.transition(.opacity)
            } else if let admin {
                VStack(alignment: .leading, spacing: 12) { manage(admin) }
                    .transition(.opacity)
            } else if link.needsUnlock {
                unlock.transition(.opacity)
            } else {
                loading.transition(.opacity)
            }
            if let problem, admin != nil {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
                    .accessibilityIdentifier("claude-admin-problem")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        .animation(FieluaMotion.change(reduceMotion),
                   value: Parts(admin: admin, problem: problem, invite: inviteLink, manages: link.canManage, locked: link.needsUnlock))
        .sensoryFeedback(.error, trigger: failures)
        .sensoryFeedback(.success, trigger: inviteLink) { _, now in now != nil }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-admin")
        .task(id: [link.hasAdminKey, link.canManage]) { await load() }
        .confirmationDialog("Anthropicの規約の確認は済みましたか？", isPresented: $confirmFriends, titleVisibility: .visible) {
            Button("確認済み・オンにする") {
                friendsAsked = true
                run("friends") { try await link.setFriendsEnabled(true) }
            }
            .accessibilityIdentifier("claude-friends-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("友人に使ってもらう前に、Anthropicの利用規約と利用ポリシーに合っているかを確かめてください。確かめるまでは、開発者だけが使えます。")
        }
        .confirmationDialog("この人の登録を削除しますか？", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }),
                            titleVisibility: .visible) {
            Button("削除", role: .destructive) {
                if let person = removing { run("delete-\(person.id)") { try await link.delete(person) } }
            }
            .accessibilityIdentifier("claude-person-delete-confirm")
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("その人の端末からはClaudeを使えなくなります。もう一度使うには、新しい招待が必要です。")
        }
    }

    private var keyEntry: some View {
        VStack(alignment: .leading, spacing: 10) {
            SecureField("管理キー（ADMIN_TOKEN）", text: $key)
                .textContentType(.oneTimeCode)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .fieluaField()
                .accessibilityIdentifier("claude-admin-key-field")
            Button {
                // Out of the field first, as on registering (no password to save).
                let typed = key
                key = ""
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                run("key") {
                    do { try await link.useAdminKey(typed) } catch { key = typed; throw error }
                }
            } label: {
                FieluaBusyLabel("管理キーを使う", busy: working == "key").frame(maxWidth: .infinity)
            }
            .fieluaSecondaryButton()
            .controlSize(.large)
            .disabled(busy || key.count < 32)
            .accessibilityIdentifier("claude-admin-key-use")
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
            }
            // Registered before 1.1.0 (262), or with a friend's invite: no Face ID key here.
            if link.isDeveloper {
                Text("開発者の招待でこのiPhoneを登録し直すと、\(ClaudeDeviceKey.method.name)で管理できます。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("claude-admin-faceid-hint")
            }
        }
    }

    /// Face ID (or the passcode) first, then the relay's management.
    private var unlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            Button {
                run("unlock") { admin = try await link.adminState() }
            } label: {
                FieluaBusyLabel("\(ClaudeDeviceKey.method.name)で管理を開く", systemImage: ClaudeDeviceKey.method.symbol,
                                busy: working == "unlock")
                    .frame(maxWidth: .infinity)
            }
            .fieluaSecondaryButton()
            .controlSize(.large)
            .disabled(busy)
            .accessibilityIdentifier("claude-admin-unlock")
            if let problem {
                Text(problem).font(.caption).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                    .transition(.opacity)
            }
        }
    }

    /// The relay is being asked, or could not be: a spinner by the words
    /// (the words alone before 1.1.0 (263)), and a way to ask again where
    /// there was none short of leaving the page.
    private var loading: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let problem {
                Text(problem).font(.subheadline).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                Button {
                    run("load") {}
                } label: {
                    Text("もう一度試す").frame(maxWidth: .infinity)
                }
                .fieluaSecondaryButton()
                .controlSize(.large)
                .disabled(busy)
                .accessibilityIdentifier("claude-admin-retry")
            } else {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text("読み込んでいます…").font(.subheadline).foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
            }
        }
    }

    @ViewBuilder private func manage(_ admin: ClaudeAdminState) -> some View {
        if let paused = admin.paused {
            VStack(alignment: .leading, spacing: 8) {
                Label(paused.message, systemImage: "pause.circle")
                    .font(.subheadline).foregroundStyle(Theme.caution)
                    .fixedSize(horizontal: false, vertical: true)
                Button {
                    run("resume") { try await link.resume() }
                } label: {
                    FieluaBusyLabel("Claudeを再開する", busy: working == "resume").frame(maxWidth: .infinity)
                }
                .fieluaProminentButton()
                .controlSize(.large)
                .disabled(busy)
                .accessibilityIdentifier("claude-resume")
            }
            .transition(.opacity)
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("claude-paused")
        }
        if !admin.configured {
            Text(ClaudeUnavailable.notConfigured.message)
                .font(.subheadline).foregroundStyle(Theme.caution)
        }
        Toggle(isOn: Binding(get: { friendsAsked ?? admin.friendsEnabled }, set: { on in
            // On only after the question's yes; off at once, and the switch
            // keeps its place while the relay is told.
            if on {
                confirmFriends = true
            } else {
                friendsAsked = false
                run("friends") { try await link.setFriendsEnabled(false) }
            }
        })) {
            VStack(alignment: .leading, spacing: 2) {
                Text("友人の利用")
                Group { if admin.friendsEnabled { Text("招待した友人もClaudeを使えます") } else { Text("オフ: 開発者だけが使えます") } }
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .disabled(busy)
        .accessibilityIdentifier("claude-friends")
        Divider()
        // The estimate of the credit left: the balance to count from (1.1.0 (260)).
        ClaudeCreditRow()
        Divider()
        inviteSection
        if !admin.people.isEmpty {
            Divider()
            ForEach(admin.people) { person in personRow(person).transition(.opacity) }
        }
        if !admin.invites.isEmpty {
            Divider()
            ForEach(admin.invites) { invite in inviteRow(invite).transition(.opacity) }
        }
        if link.hasAdminKey {
            Divider()
            // No question first: the key is the developer's own, and Face ID
            // (or the key again) opens the management after it.
            Button(role: .destructive) {
                link.forgetAdminKey()
            } label: {
                Text("管理キーをこのiPhoneから消す").font(.footnote)
                    .foregroundStyle(Theme.caution)
                    .fieluaTouchTarget(horizontal: 8)
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("claude-admin-forget")
        }
    }

    @ViewBuilder private var inviteSection: some View {
        Text("友人を招待").font(.subheadline.weight(.semibold))
        TextField("友人の名前（管理用）", text: $friendName)
            .fieluaField()
            .accessibilityIdentifier("claude-friend-name")
        Button {
            let name = friendName.trimmingCharacters(in: .whitespacesAndNewlines)
            run("invite") {
                inviteLink = try await link.invite(name: name)
                friendName = ""
            }
        } label: {
            FieluaBusyLabel("招待リンクを作る", busy: working == "invite").frame(maxWidth: .infinity)
        }
        .fieluaSecondaryButton()
        .controlSize(.large)
        .disabled(busy || friendName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        .accessibilityIdentifier("claude-friend-invite")
        if let inviteLink {
            VStack(alignment: .leading, spacing: 8) {
                Text("一度だけ使えて、72時間で無効になるリンクです。本人にだけ送ってください。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                // The pair at the card's full button height, and コピー answers
                // (a regular pair, and silence, before 1.1.0 (263)).
                HStack(spacing: 10) {
                    ShareLink(item: inviteLink) {
                        Label("送る", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity)
                    }
                    .fieluaProminentButton()
                    .controlSize(.large)
                    .accessibilityIdentifier("claude-friend-share")
                    Button {
                        ClaudeLinkStore.copySecret(inviteLink.absoluteString)
                        linkCopied = true
                    } label: {
                        FieluaCopyLabel(copied: linkCopied, short: true).frame(maxWidth: .infinity)
                    }
                    .fieluaSecondaryButton()
                    .controlSize(.large)
                    .fieluaConfirmation($linkCopied)
                    .accessibilityIdentifier("claude-friend-copy")
                }
            }
            .transition(.opacity)
            .accessibilityElement(children: .contain)
            .accessibilityIdentifier("claude-friend-link")
        }
    }

    private func personRow(_ person: ClaudeAdminState.Person) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: person.name).font(.body)
                Text(personDetail(person)).font(.caption).foregroundStyle(person.active ? Color.secondary : Theme.caution)
                    .contentTransition(.opacity)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            // The developer's own registration is left alone here (登録を解除 above).
            if !person.isDeveloper {
                Button {
                    run("active-\(person.id)") { try await link.setActive(person, !person.active) }
                } label: {
                    FieluaBusyLabel(person.active ? "止める" : "再開", busy: working == "active-\(person.id)")
                }
                .fieluaSecondaryButton()
                .disabled(busy)
                .accessibilityIdentifier("claude-person-toggle-\(person.name)")
                Button(role: .destructive) {
                    removing = person
                } label: {
                    ZStack {
                        Image(systemName: "trash").opacity(working == "delete-\(person.id)" ? 0 : 1)
                        if working == "delete-\(person.id)" { ProgressView().controlSize(.small) }
                    }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("削除")
                }
                .fieluaSecondaryButton()
                .disabled(busy)
                .accessibilityIdentifier("claude-person-delete-\(person.name)")
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("claude-person-\(person.name)")
    }

    private func personDetail(_ person: ClaudeAdminState.Person) -> String {
        let role = person.isDeveloper ? String(localized: "開発者") : String(localized: "友人")
        let state = person.active ? String(localized: "使用可") : String(localized: "停止中")
        guard let used = person.lastUsed else { return "\(role) · \(state)" }
        return "\(role) · \(state) · " + String(localized: "最終利用 \(used.formatted(date: .abbreviated, time: .shortened))")
    }

    private func inviteRow(_ invite: ClaudeAdminState.OpenInvite) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(verbatim: invite.name).font(.body)
                Text("招待中 · \(invite.expires.formatted(date: .abbreviated, time: .shortened))まで")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            Button {
                run("cancel-\(invite.id)") { try await link.cancel(invite) }
            } label: {
                FieluaBusyLabel("取り消す", busy: working == "cancel-\(invite.id)")
            }
            .fieluaSecondaryButton()
            .disabled(busy)
            .accessibilityIdentifier("claude-invite-withdraw-\(invite.name)")
        }
        .accessibilityElement(children: .contain)
    }

    /// One change at the relay, then the state again. `button` names the
    /// button that started it, for its label.
    private func run(_ button: String, _ change: @escaping () async throws -> Void) {
        busy = true
        working = button
        Task {
            do {
                try await change()
                problem = nil
            } catch is CancellationError {
                // Face ID cancelled: nothing to say.
            } catch {
                problem = error.localizedDescription
                failures += 1
            }
            await load()
            busy = false
            working = nil
            friendsAsked = nil
        }
    }

    /// The relay's state, unless that would ask Face ID unasked (then the button does).
    private func load() async {
        guard link.canManage, !link.needsUnlock else { admin = nil; return }
        do {
            admin = try await link.adminState()
        } catch is CancellationError {
        } catch {
            problem = error.localizedDescription
        }
    }
}

// MARK: - A link that opens Fielua

/// fielua://claude?server=..&code=.. (the relay's /join page): the invite
/// is shown before anything is sent, in a sheet, or in 設定 › Claude when
/// that is open.
struct ClaudeInviteHandler: ViewModifier {
    @ObservedObject private var link = ClaudeLinkStore.shared

    func body(content: Content) -> some View {
        content
            .onOpenURL { url in
                guard url.scheme == "fielua", url.host == "claude" else { return }
                link.pendingInvite = ClaudeInvite(url.absoluteString, allowsLocal: ClaudeLinkStore.allowsLocal)
            }
            .sheet(item: $link.pendingInvite) { invite in
                // On the paper of every other sheet, and the card says
                // 「登録しました」 before it goes (1.1.0 (263)).
                ScrollView {
                    ClaudeInviteCard(invite: invite, confirms: true) { link.pendingInvite = nil }
                        .padding(20)
                }
                .fieluaPageBackground()
                .presentationDetents([.medium, .large])
            }
    }
}
