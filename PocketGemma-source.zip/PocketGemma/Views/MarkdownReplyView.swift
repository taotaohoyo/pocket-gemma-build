import SwiftUI
import UIKit
import os
import PocketCore

/// A reply drawn from its Markdown, flat on the conversation as in ChatGPT.
/// The reply is split into top-level chunks, so while Gemma streams only the
/// last chunk is parsed again; earlier chunks come from the cache and skip
/// their bodies. The message text stays the original Markdown, which the
/// reply's menu copies.
struct MarkdownReplyView: View, Equatable {
    let text: String
    let isStreaming: Bool
    /// The reply arrived while this view showed it. Its earlier chunks then
    /// keep fading in what they were given when the next chunk begins,
    /// rather than the characters still in flight turning clear at once.
    @State private var streamedHere: Bool
    @State private var source = MarkdownReplySource()
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var voiceOver = UIAccessibility.isVoiceOverRunning
    @State private var pendingLink: URL?
    @ScaledMetric(relativeTo: .body) private var lineSpacing = MarkdownMetrics.lineSpacing

    init(text: String, isStreaming: Bool) {
        self.text = text
        self.isStreaming = isStreaming
        _streamedHere = State(initialValue: isStreaming)
    }

    var body: some View {
        let parts = chunks()
        // Blocks space themselves by what precedes them, across chunks too.
        let stack = VStack(alignment: .leading, spacing: 0) {
            #if POCKET_PREVIEW
            if PreviewProbe.on("--probe-flat") {
                MarkdownBlocksView(blocks: parts.flatMap(\.blocks))
            } else {
                ForEach(parts, id: \.index) { part in
                    MarkdownChunkView(chunk: part).equatable()
                }
            }
            #else
            ForEach(parts, id: \.index) { part in
                MarkdownChunkView(chunk: part).equatable()
            }
            #endif
        }
        .font(.body)
        .lineSpacing(lineSpacing)
        .environment(\.markdownReveal, !systemReduceMotion && !previewReduceMotion && !voiceOver && !Self.probeNoReveal)
        .environment(\.markdownReplySource, source)
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-no-link-dialog") { stack } else { linked(stack) }
        #else
        linked(stack)
        #endif
    }

    #if POCKET_PREVIEW
    private static let probeNoReveal = PreviewProbe.on("--probe-no-reveal")
    private static let probeLastChunkLive = PreviewProbe.on("--probe-last-chunk-live")
    #else
    private static let probeNoReveal = false
    private static let probeLastChunkLive = false
    #endif

    /// The same text in the same state lays out the same. The row remakes
    /// this view for each piece the model writes, while the text laid out so
    /// far changes at its own pace; only that change should have the reply
    /// chunked and parsed again.
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.text == rhs.text && lhs.isStreaming == rhs.isStreaming
    }

    /// Parsing time shows in Instruments under "markdown".
    private static let signposter = OSSignposter(subsystem: "PocketAI", category: "markdown")

    private func chunks() -> [MarkdownChunk] {
        let interval = Self.signposter.beginInterval("chunks")
        defer { Self.signposter.endInterval("chunks", interval) }
        source.text = text
        let chunks = MarkdownSource.chunks(text)
        let references = text.contains("]:") ? MarkdownSource.referenceDefinitions(text) : ""
        var parts: [MarkdownChunk] = []
        var previous: MarkdownBlockKind?
        let streamed = (isStreaming || streamedHere) && !Self.probeLastChunkLive
        for index in chunks.indices {
            let streaming = isStreaming && index == chunks.count - 1
            let document = MarkdownCache.document(chunks[index], references: references, streaming: streaming)
            guard !document.blocks.isEmpty else { continue }
            parts.append(MarkdownChunk(index: index, source: chunks[index], references: references, streaming: streaming,
                                       live: streamed || index == chunks.count - 1, previous: previous, blocks: document.blocks,
                                       openMath: document.openMathAtEnd))
            previous = document.blocks.last.map(MarkdownBlockKind.init)
        }
        return parts
    }

    private func linked(_ stack: some View) -> some View {
        stack
            .environment(\.openURL, OpenURLAction { url in
                guard MarkdownLinkPolicy.isAllowed(url) else { return .discarded }
                pendingLink = url
                return .handled
            })
            // Link text can say anything; show the real address before leaving.
            .confirmationDialog("リンクを開きますか？", isPresented: Binding(get: { pendingLink != nil },
                                                                   set: { if !$0 { pendingLink = nil } }),
                                titleVisibility: .visible, presenting: pendingLink) { url in
                Button("開く") { UIApplication.shared.open(url) }
                Button("リンクをコピー") { UIPasteboard.general.url = url }
                Button("キャンセル", role: .cancel) {}
            } message: { url in
                Text(verbatim: url.absoluteString)
            }
            .onReceive(NotificationCenter.default.publisher(for: UIAccessibility.voiceOverStatusDidChangeNotification)) { _ in
                voiceOver = UIAccessibility.isVoiceOverRunning
            }
    }
}

struct MarkdownChunk {
    let index: Int
    let source: String
    let references: String
    let streaming: Bool
    /// Text fades in as it arrives: the reply's last chunk, and every chunk
    /// of a reply that streamed in this view.
    let live: Bool
    /// The last block of the chunk above, which sets this chunk's top space.
    let previous: MarkdownBlockKind?
    let blocks: [MarkdownBlock]
    /// The last block is a formula still arriving.
    let openMath: Bool
}

private struct MarkdownChunkView: View, Equatable {
    let chunk: MarkdownChunk

    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.chunk.source == rhs.chunk.source && lhs.chunk.references == rhs.chunk.references
            && lhs.chunk.streaming == rhs.chunk.streaming && lhs.chunk.live == rhs.chunk.live
            && lhs.chunk.previous == rhs.chunk.previous
    }

    var body: some View {
        MarkdownBlocksView(blocks: chunk.blocks, live: chunk.live, streaming: chunk.streaming, previous: chunk.previous,
                           openMathAtEnd: chunk.openMath)
    }
}

/// Reply typography after ChatGPT's (measured from an iPhone screenshot):
/// 17pt body text on a 24pt line pitch, 16pt between paragraphs, headings
/// set well apart from what precedes them and close to what they introduce.
/// Spacing is at the default text size and scales with Dynamic Type.
enum MarkdownMetrics {
    static let lineSpacing: CGFloat = 3
    static let paragraphSpacing: CGFloat = 16
    static let itemSpacing: CGFloat = 6
    /// H1 to H6 at the default text size: 26, 22 and 20 as ChatGPT's app
    /// sets them (measured 2026-10-18), then down to body size.
    static let headingSizes: [CGFloat] = [26, 22, 20, 18, 17, 15]
    /// A list's text starts this far in, whatever its markers.
    static let markerColumn: CGFloat = 20
    static let markerGap: CGFloat = 6
    static let codeLinesShown = 40
    static let codeLinesCollapsed = 60
    static let tableRowsShown = 20
    static let tableRowsCollapsed = 30
    static let tableCellWidth: CGFloat = 240

    /// Space above a block, by the block before it. `nested` is inside a
    /// list item or a quote, where blocks sit closer.
    static func spacing(before block: MarkdownBlockKind, after previous: MarkdownBlockKind?, nested: Bool) -> CGFloat {
        guard let previous else { return 0 }
        if nested {
            switch (previous, block) {
            case (_, .list): return 4
            case (.heading, _): return 6
            default: return 10
            }
        }
        switch (previous, block) {
        case (.heading, .heading): return 10
        case (.rule, _), (_, .rule): return 20
        case (_, .heading(let level)): return level <= 2 ? 28 : 22
        case (.heading(let level), _): return level <= 2 ? 10 : 8
        default: return paragraphSpacing
        }
    }
}

/// What a block is, without its content, for spacing.
enum MarkdownBlockKind: Equatable {
    case paragraph, heading(Int), code, math, quote, list, table, image, rule, rich

    init(_ block: MarkdownBlock) {
        switch block {
        case .paragraph: self = .paragraph
        case .heading(let level, _): self = .heading(level)
        case .code: self = .code
        case .math: self = .math
        case .quote: self = .quote
        case .list: self = .list
        case .table: self = .table
        case .image: self = .image
        case .rule: self = .rule
        case .rich: self = .rich
        }
    }
}

/// Parsed chunks of finished text, shared by every bubble. A streaming
/// chunk changes with each token, so only its latest few parses are kept:
/// the view's body runs more often than the text changes.
enum MarkdownCache {
    private final class Entry {
        let document: MarkdownDocument
        init(_ document: MarkdownDocument) { self.document = document }
    }

    private static let documents: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 600
        cache.totalCostLimit = 8 * 1024 * 1024
        return cache
    }()

    private static let latest: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 4
        return cache
    }()

    static func document(_ source: String, references: String, streaming: Bool) -> MarkdownDocument {
        let key = (references.isEmpty ? source : source + "\u{0}" + references) as NSString
        let cache = streaming ? latest : documents
        if let entry = cache.object(forKey: key) { return entry.document }
        let document = MarkdownDocument(source, streaming: streaming, references: references)
        cache.setObject(Entry(document), forKey: key, cost: source.utf8.count)
        return document
    }

    static func purge() {
        documents.removeAllObjects()
        latest.removeAllObjects()
    }
}

/// Every cache the reply views keep, dropped together on a memory warning
/// so the model keeps its room.
@MainActor
enum MarkdownCaches {
    static func purgeAll() {
        MarkdownCache.purge()
        MarkdownMathRenderer.purge()
        MarkdownCodeColors.purge()
        MarkdownImageLoader.purge()
    }
}

extension EnvironmentValues {
    /// Whether arriving text fades in; off with Reduce Motion and VoiceOver.
    @Entry var markdownReveal = true
    /// The reply around a code block, table or formula, whose own menu
    /// takes the place of the reply's and so offers copying all of it.
    @Entry var markdownReplySource: MarkdownReplySource? = nil
}

/// The reply's Markdown for its blocks' menus. One object for the reply's
/// life, updated in place, so the environment does not change with each
/// token and blocks already drawn are not drawn again.
final class MarkdownReplySource {
    var text = ""
}

struct MarkdownBlocksView: View {
    let blocks: [MarkdownBlock]
    var live = false
    var streaming = false
    /// The block above these, in the chunk before.
    var previous: MarkdownBlockKind?
    var nested = false
    var depth = 0
    /// The last block is a `$$` formula still arriving.
    var openMathAtEnd = false
    @ScaledMetric(relativeTo: .body) private var scale: CGFloat = 1

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(blocks.indices, id: \.self) { index in
                let before = index == 0 ? previous : MarkdownBlockKind(blocks[index - 1])
                MarkdownBlockView(block: blocks[index], live: live, streaming: streaming, depth: depth,
                                  unfinishedMath: openMathAtEnd && index == blocks.count - 1)
                    .padding(.top, scale * MarkdownMetrics.spacing(before: MarkdownBlockKind(blocks[index]),
                                                                   after: before, nested: nested))
            }
        }
    }
}

private struct MarkdownBlockView: View {
    let block: MarkdownBlock
    let live: Bool
    let streaming: Bool
    let depth: Int
    let unfinishedMath: Bool

    var body: some View {
        switch block {
        case .paragraph(let text):
            MarkdownText(text: text, live: live, streaming: streaming)
        case .heading(let level, let text):
            MarkdownHeading(level: level, text: text, live: live, streaming: streaming)
        case .code(let language, let code):
            MarkdownCodeView(language: language, code: code, streaming: streaming)
        case .math(let latex):
            MarkdownMathBlock(latex: latex, unfinished: unfinishedMath)
        case .quote(let blocks):
            MarkdownBlocksView(blocks: blocks, live: live, streaming: streaming, nested: true, depth: depth,
                               openMathAtEnd: unfinishedMath)
                .foregroundStyle(.secondary)
                .padding(.leading, 14)
                .overlay(alignment: .leading) {
                    Capsule().fill(Theme.quoteBar).frame(width: 3).accessibilityHidden(true)
                }
                .accessibilityElement(children: .contain)
                .accessibilityLabel(Text(verbatim: "引用"))
        case .list(let ordered, let items):
            MarkdownListView(ordered: ordered, items: items, live: live, streaming: streaming, depth: depth,
                             openMathAtEnd: unfinishedMath)
        case .table(let table):
            MarkdownTableView(table: table)
        case .image(let url, let alt):
            MarkdownImageView(url: url, alt: alt)
        case .rule:
            Rectangle().fill(Theme.markdownLine.opacity(0.6)).frame(height: 1)
                .accessibilityHidden(true)
        case .rich(let rich):
            RichBlockView(block: rich, streaming: streaming).equatable()
        }
    }
}

/// H1 to H6: bold and larger than body text down to H3, so a heading never
/// reads as a bold sentence; H4 and H5 are semibold and H6 is quieter.
/// Each size (`MarkdownMetrics.headingSizes`) follows Dynamic Type.
private struct MarkdownHeading: View {
    let level: Int
    let text: AttributedString
    let live: Bool
    let streaming: Bool
    @ScaledMetric(relativeTo: .title) private var h1: CGFloat = MarkdownMetrics.headingSizes[0]
    @ScaledMetric(relativeTo: .title2) private var h2: CGFloat = MarkdownMetrics.headingSizes[1]
    @ScaledMetric(relativeTo: .title3) private var h3: CGFloat = MarkdownMetrics.headingSizes[2]
    @ScaledMetric(relativeTo: .headline) private var h4: CGFloat = MarkdownMetrics.headingSizes[3]
    @ScaledMetric(relativeTo: .body) private var h5: CGFloat = MarkdownMetrics.headingSizes[4]
    @ScaledMetric(relativeTo: .subheadline) private var h6: CGFloat = MarkdownMetrics.headingSizes[5]

    private var font: Font {
        switch level {
        case 1: return .system(size: h1, weight: .bold)
        case 2: return .system(size: h2, weight: .bold)
        case 3: return .system(size: h3, weight: .bold)
        case 4: return .system(size: h4, weight: .semibold)
        case 5: return .system(size: h5, weight: .semibold)
        default: return .system(size: h6, weight: .semibold)
        }
    }

    var body: some View {
        MarkdownText(text: text, live: live, streaming: streaming)
            .font(font)
            .lineSpacing(2)
            .foregroundStyle(level >= 6 ? HierarchicalShapeStyle.secondary : HierarchicalShapeStyle.primary)
            .accessibilityAddTraits(.isHeader)
    }
}

private struct MarkdownListView: View {
    let ordered: Bool
    let items: [MarkdownListItem]
    let live: Bool
    let streaming: Bool
    let depth: Int
    /// The last item ends with a `$$` formula still arriving.
    var openMathAtEnd = false

    @ScaledMetric(relativeTo: .body) private var scale: CGFloat = 1

    /// One width for every marker in the list, so each item's text starts
    /// at the same place: 20pt, or wider for numbers past 9.
    private var markerWidth: CGFloat {
        guard ordered else { return MarkdownMetrics.markerColumn * scale }
        let digits = String(items.map(\.ordinal).max() ?? 1).count
        return max(MarkdownMetrics.markerColumn, 6 + 10.5 * CGFloat(digits)) * scale
    }

    var body: some View {
        VStack(alignment: .leading, spacing: MarkdownMetrics.itemSpacing * scale) {
            ForEach(items.indices, id: \.self) { index in
                let item = items[index]
                HStack(alignment: .firstTextBaseline, spacing: MarkdownMetrics.markerGap * scale) {
                    marker(item).frame(width: markerWidth, alignment: ordered ? .trailing : .center)
                    MarkdownBlocksView(blocks: item.blocks, live: live, streaming: streaming,
                                       nested: true, depth: depth + 1,
                                       openMathAtEnd: openMathAtEnd && index == items.count - 1)
                }
            }
        }
    }

    @ViewBuilder private func marker(_ item: MarkdownListItem) -> some View {
        if let checked = item.checked {
            Image(systemName: checked ? "checkmark.square.fill" : "square")
                .foregroundStyle(checked ? Theme.accent : Color.secondary)
                .accessibilityLabel(checked ? "完了" : "未完了")
        } else if ordered {
            Text(verbatim: "\(item.ordinal).").monospacedDigit()
        } else {
            ListBullet(depth: depth)
        }
    }
}

/// A drawn bullet, a dot, ring or square by depth as in ChatGPT. Glyphs fell
/// back to Japanese fonts, where • shrank to a speck and ▪︎ became a heavy
/// block (1.0.62). It sits mid-height on the item's first line.
private struct ListBullet: View {
    let depth: Int
    @ScaledMetric(relativeTo: .body) private var em: CGFloat = 17

    var body: some View {
        let size = em * 0.32
        Group {
            switch depth {
            case 0: Circle().fill(.foreground)
            case 1: Circle().strokeBorder(.foreground, lineWidth: max(1, size * 0.2))
            default: Rectangle().fill(.foreground).padding(size * 0.08)
            }
        }
        .frame(width: size, height: size)
        .alignmentGuide(.firstTextBaseline) { $0[VerticalAlignment.center] + em * 0.34 }
        .accessibilityHidden(true)
    }
}

/// A block's inline text: Foundation's emphasis, strikethrough and code,
/// links underlined in the accent color, and inline math drawn as images.
struct MarkdownText: View {
    let text: AttributedString
    /// In a chunk whose text fades in as it arrives (`MarkdownChunk.live`).
    var live = false
    var streaming = false
    @Environment(\.markdownReveal) private var reveal
    @Environment(\.displayScale) private var displayScale
    @ScaledMetric(relativeTo: .body) private var mathSize: CGFloat = 17.5

    var body: some View {
        let styled = MarkdownInline.styled(text)
        if MarkdownInline.containsMath(styled) {
            MarkdownInlineMath(styled: styled, mathSize: mathSize, scale: displayScale)
        } else if live && reveal {
            RevealingRichText(text: styled, isStreaming: streaming)
        } else {
            #if POCKET_PREVIEW
            if PreviewProbe.on("--probe-string-text") { Text(verbatim: String(styled.characters)) } else { Text(styled) }
            #else
            Text(styled)
            #endif
        }
    }
}

@MainActor
enum MarkdownInline {
    private static let inlineCode: Color = Theme.inlineCode

    static func containsMath(_ text: AttributedString) -> Bool {
        text.runs.contains { $0[MarkdownMathAttribute.self] != nil }
    }

    static func styled(_ text: AttributedString) -> AttributedString {
        let needsStyle = text.runs.contains { run in
            run.link != nil || run.inlinePresentationIntent?.contains(.code) == true
        }
        guard needsStyle else { return text }
        var result = AttributedString()
        for run in text.runs {
            var piece = AttributedString(text[run.range])
            if run.inlinePresentationIntent?.contains(.code) == true {
                piece.backgroundColor = inlineCode
            }
            if run.link != nil {
                piece.underlineStyle = Text.LineStyle.single
            }
            result.append(piece)
        }
        return result
    }

    /// A line's text with its formulas drawn in, or a formula too wide for
    /// a line, which stands on its own.
    enum Piece {
        case text(Text)
        case wide(MarkdownMathRenderer.Rendered)
    }

    /// Formulas wider than this stand on a line of their own, where they
    /// scroll sideways; narrower ones fit any phone's line.
    static let widestInline: CGFloat = 240

    static func pieces(_ styled: AttributedString, mathSize: CGFloat, scale: CGFloat) -> [Piece] {
        var pieces: [Piece] = []
        var result = Text(verbatim: "")
        var hasText = false
        var pending = AttributedString()
        // Whitespace next to a formula on its own line (a soft break) would
        // be an empty line, so the text before it ends, and the text after it
        // starts, at a visible character.
        func flushPending(beforeWide: Bool) {
            guard !pending.characters.isEmpty else { return }
            var text = pending
            pending = AttributedString()
            if !hasText, case .some(.wide) = pieces.last { text = trimmed(text, leading: true, trailing: false) }
            if beforeWide { text = trimmed(text, leading: false, trailing: true) }
            guard !text.characters.isEmpty else { return }
            result = result + Text(text)
            hasText = true
        }
        func flushText() {
            guard hasText else { return }
            pieces.append(.text(result))
            result = Text(verbatim: "")
            hasText = false
        }
        for run in styled.runs {
            guard let math = run[MarkdownMathAttribute.self] else {
                pending.append(styled[run.range])
                continue
            }
            let outcome = MarkdownMathRenderer.render(math.latex, display: math.display, fontSize: mathSize, scale: scale)
            if case .success(let rendered) = outcome, rendered.size.width > widestInline {
                flushPending(beforeWide: true)
                flushText()
                pieces.append(.wide(rendered))
                continue
            }
            flushPending(beforeWide: false)
            switch outcome {
            case .success(let rendered):
                result = result + Text(rendered.image).baselineOffset(-rendered.descent)
            case .failure:
                result = result + Text(verbatim: math.latex).font(.system(size: mathSize * 0.9, design: .monospaced))
                    .accessibilityLabel(Text(verbatim: MarkdownMathRenderer.spokenLabel(math.latex, display: false)))
            }
            hasText = true
        }
        flushPending(beforeWide: false)
        flushText()
        return pieces
    }

    private static func trimmed(_ text: AttributedString, leading: Bool, trailing: Bool) -> AttributedString {
        var text = text
        if leading {
            guard let first = text.characters.firstIndex(where: { !$0.isWhitespace }) else { return AttributedString() }
            text.removeSubrange(text.startIndex..<first)
        }
        if trailing {
            guard let last = text.characters.lastIndex(where: { !$0.isWhitespace }) else { return AttributedString() }
            text.removeSubrange(text.characters.index(after: last)..<text.endIndex)
        }
        return text
    }
}

/// Inline text with its formulas drawn as images; a formula too wide for
/// a line goes on a line of its own and scrolls sideways.
private struct MarkdownInlineMath: View {
    let styled: AttributedString
    let mathSize: CGFloat
    let scale: CGFloat

    var body: some View {
        let pieces = MarkdownInline.pieces(styled, mathSize: mathSize, scale: scale)
        if pieces.count == 1, case .text(let text) = pieces[0] {
            text
        } else {
            VStack(alignment: .leading, spacing: 6) {
                ForEach(pieces.indices, id: \.self) { index in
                    switch pieces[index] {
                    case .text(let text): text
                    case .wide(let rendered): MarkdownMathImage(rendered: rendered)
                    }
                }
            }
        }
    }
}
