import SwiftUI
import UIKit
import PocketCore

/// A reply drawn from its Markdown inside the incoming bubble. The reply is
/// split into top-level chunks, so while Gemma streams only the last chunk is
/// parsed again; earlier chunks come from the cache and skip their bodies.
/// The message text stays the original Markdown, which the bubble copies.
struct MarkdownReplyView: View {
    let text: String
    let isStreaming: Bool
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var voiceOver = UIAccessibility.isVoiceOverRunning
    @State private var pendingLink: URL?

    var body: some View {
        let chunks = MarkdownSource.chunks(text)
        let references = text.contains("]:") ? MarkdownSource.referenceDefinitions(text) : ""
        let parts = chunks.indices.compactMap { index -> MarkdownChunk? in
            let streaming = isStreaming && index == chunks.count - 1
            let document = MarkdownCache.document(chunks[index], references: references, streaming: streaming)
            guard !document.blocks.isEmpty else { return nil }
            return MarkdownChunk(index: index, source: chunks[index], references: references, streaming: streaming,
                                 live: index == chunks.count - 1, blocks: document.blocks)
        }
        let stack = VStack(alignment: .leading, spacing: MarkdownMetrics.blockSpacing) {
            #if POCKET_PREVIEW
            if PreviewProbe.on("--probe-flat") {
                MarkdownBlocksView(blocks: parts.flatMap(\.blocks))
            } else {
                ForEach(parts, id: \.index) { part in
                    MarkdownChunkView(chunk: part).equatable()
                }
            }
            #else
            ForEach(parts, id: \.index) { part in
                MarkdownChunkView(chunk: part).equatable()
            }
            #endif
        }
        .environment(\.markdownReveal, !systemReduceMotion && !previewReduceMotion && !voiceOver && !Self.probeNoReveal)
        #if POCKET_PREVIEW
        if PreviewProbe.on("--probe-no-link-dialog") { stack } else { linked(stack) }
        #else
        linked(stack)
        #endif
    }

    #if POCKET_PREVIEW
    private static let probeNoReveal = PreviewProbe.on("--probe-no-reveal")
    #else
    private static let probeNoReveal = false
    #endif

    private func linked(_ stack: some View) -> some View {
        stack
            .environment(\.openURL, OpenURLAction { url in
                guard MarkdownLinkPolicy.isAllowed(url) else { return .discarded }
                pendingLink = url
                return .handled
            })
            // Link text can say anything; show the real address before leaving.
            .confirmationDialog("リンクを開きますか？", isPresented: Binding(get: { pendingLink != nil },
                                                                   set: { if !$0 { pendingLink = nil } }),
                                titleVisibility: .visible, presenting: pendingLink) { url in
                Button("開く") { UIApplication.shared.open(url) }
                Button("リンクをコピー") { UIPasteboard.general.url = url }
                Button("キャンセル", role: .cancel) {}
            } message: { url in
                Text(verbatim: url.absoluteString)
            }
            .onReceive(NotificationCenter.default.publisher(for: UIAccessibility.voiceOverStatusDidChangeNotification)) { _ in
                voiceOver = UIAccessibility.isVoiceOverRunning
            }
    }
}

struct MarkdownChunk {
    let index: Int
    let source: String
    let references: String
    let streaming: Bool
    /// The reply's last chunk, whose text fades in as it arrives.
    let live: Bool
    let blocks: [MarkdownBlock]
}

private struct MarkdownChunkView: View, Equatable {
    let chunk: MarkdownChunk

    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.chunk.source == rhs.chunk.source && lhs.chunk.references == rhs.chunk.references
            && lhs.chunk.streaming == rhs.chunk.streaming && lhs.chunk.live == rhs.chunk.live
    }

    var body: some View {
        MarkdownBlocksView(blocks: chunk.blocks, live: chunk.live, streaming: chunk.streaming)
    }
}

enum MarkdownMetrics {
    static let blockSpacing: CGFloat = 8
    static let itemSpacing: CGFloat = 4
    static let codeLinesShown = 40
    static let codeLinesCollapsed = 60
    static let tableRowsShown = 20
    static let tableRowsCollapsed = 30
    static let tableCellWidth: CGFloat = 240

    static func headingFont(_ level: Int) -> Font {
        switch level {
        case 1: return .title3.weight(.bold)
        case 2: return .headline
        case 3: return .callout.weight(.semibold)
        default: return .subheadline.weight(.semibold)
        }
    }
}

/// Parsed chunks of finished text, shared by every bubble. A streaming
/// chunk changes with each token, so it is parsed fresh.
enum MarkdownCache {
    private final class Entry {
        let document: MarkdownDocument
        init(_ document: MarkdownDocument) { self.document = document }
    }

    private static let documents: NSCache<NSString, Entry> = {
        let cache = NSCache<NSString, Entry>()
        cache.countLimit = 600
        return cache
    }()

    static func document(_ source: String, references: String, streaming: Bool) -> MarkdownDocument {
        guard !streaming else { return MarkdownDocument(source, streaming: true, references: references) }
        let key = (references.isEmpty ? source : source + "\u{0}" + references) as NSString
        if let entry = documents.object(forKey: key) { return entry.document }
        let document = MarkdownDocument(source, references: references)
        documents.setObject(Entry(document), forKey: key)
        return document
    }
}

extension EnvironmentValues {
    /// Whether arriving text fades in; off with Reduce Motion and VoiceOver.
    @Entry var markdownReveal = true
}

struct MarkdownBlocksView: View {
    let blocks: [MarkdownBlock]
    var live = false
    var streaming = false
    var spacing: CGFloat = MarkdownMetrics.blockSpacing
    var depth = 0

    var body: some View {
        VStack(alignment: .leading, spacing: spacing) {
            ForEach(blocks.indices, id: \.self) { index in
                MarkdownBlockView(block: blocks[index], live: live, streaming: streaming, depth: depth)
            }
        }
    }
}

private struct MarkdownBlockView: View {
    let block: MarkdownBlock
    let live: Bool
    let streaming: Bool
    let depth: Int

    var body: some View {
        switch block {
        case .paragraph(let text):
            MarkdownText(text: text, live: live, streaming: streaming)
        case .heading(let level, let text):
            MarkdownText(text: text, live: live, streaming: streaming)
                .font(MarkdownMetrics.headingFont(level))
                .foregroundStyle(level >= 6 ? HierarchicalShapeStyle.secondary : HierarchicalShapeStyle.primary)
                .padding(.top, 2)
                .accessibilityAddTraits(.isHeader)
        case .code(let language, let code):
            MarkdownCodeView(language: language, code: code, streaming: streaming)
        case .math(let latex):
            MarkdownMathBlock(latex: latex)
        case .quote(let blocks):
            MarkdownBlocksView(blocks: blocks, live: live, streaming: streaming, depth: depth)
                .foregroundStyle(.secondary)
                .padding(.leading, 12)
                .overlay(alignment: .leading) {
                    Capsule().fill(Theme.quoteBar).frame(width: 3).accessibilityHidden(true)
                }
        case .list(let ordered, let items):
            MarkdownListView(ordered: ordered, items: items, live: live, streaming: streaming, depth: depth)
        case .table(let table):
            MarkdownTableView(table: table)
        case .image(let url, let alt):
            MarkdownImageView(url: url, alt: alt)
        case .rule:
            Rectangle().fill(Theme.markdownLine).frame(height: 1).padding(.vertical, 4)
                .accessibilityHidden(true)
        }
    }
}

private struct MarkdownListView: View {
    let ordered: Bool
    let items: [MarkdownListItem]
    let live: Bool
    let streaming: Bool
    let depth: Int

    private var markerWidth: CGFloat {
        guard ordered else { return 14 }
        let digits = String(items.map(\.ordinal).max() ?? 1).count
        return 10 + 9 * CGFloat(digits)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: MarkdownMetrics.itemSpacing) {
            ForEach(items.indices, id: \.self) { index in
                let item = items[index]
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    marker(item).frame(minWidth: markerWidth, alignment: ordered ? .trailing : .center)
                    MarkdownBlocksView(blocks: item.blocks, live: live, streaming: streaming,
                                       spacing: MarkdownMetrics.itemSpacing, depth: depth + 1)
                }
            }
        }
    }

    @ViewBuilder private func marker(_ item: MarkdownListItem) -> some View {
        if let checked = item.checked {
            Image(systemName: checked ? "checkmark.square.fill" : "square")
                .foregroundStyle(checked ? Theme.accent : Color.secondary)
                .accessibilityLabel(checked ? "完了" : "未完了")
        } else if ordered {
            Text(verbatim: "\(item.ordinal).").monospacedDigit()
        } else {
            Text(verbatim: ["•", "◦", "▪︎"][min(depth, 2)]).accessibilityHidden(true)
        }
    }
}

/// A block's inline text: Foundation's emphasis, strikethrough and code,
/// links underlined in the accent color, and inline math drawn as images.
struct MarkdownText: View {
    let text: AttributedString
    /// In the reply's last chunk, where text arrives.
    var live = false
    var streaming = false
    @Environment(\.markdownReveal) private var reveal
    @ScaledMetric(relativeTo: .callout) private var mathSize: CGFloat = 16.5

    var body: some View {
        let styled = MarkdownInline.styled(text)
        if MarkdownInline.containsMath(styled) {
            MarkdownInline.text(styled, mathSize: mathSize)
        } else if live && reveal {
            RevealingRichText(text: styled, isStreaming: streaming)
        } else {
            #if POCKET_PREVIEW
            if PreviewProbe.on("--probe-string-text") { Text(verbatim: String(styled.characters)) } else { Text(styled) }
            #else
            Text(styled)
            #endif
        }
    }
}

@MainActor
enum MarkdownInline {
    private static let inlineCode: Color = Theme.inlineCode

    static func containsMath(_ text: AttributedString) -> Bool {
        text.runs.contains { $0[MarkdownMathAttribute.self] != nil }
    }

    static func styled(_ text: AttributedString) -> AttributedString {
        let needsStyle = text.runs.contains { run in
            run.link != nil || run.inlinePresentationIntent?.contains(.code) == true
        }
        guard needsStyle else { return text }
        var result = AttributedString()
        for run in text.runs {
            var piece = AttributedString(text[run.range])
            if run.inlinePresentationIntent?.contains(.code) == true {
                piece.backgroundColor = inlineCode
            }
            if run.link != nil {
                piece.underlineStyle = Text.LineStyle.single
            }
            result.append(piece)
        }
        return result
    }

    static func text(_ styled: AttributedString, mathSize: CGFloat) -> Text {
        var result = Text(verbatim: "")
        var pending = AttributedString()
        for run in styled.runs {
            if let math = run[MarkdownMathAttribute.self] {
                if !pending.characters.isEmpty {
                    result = result + Text(pending)
                    pending = AttributedString()
                }
                result = result + mathText(math, size: mathSize)
            } else {
                pending.append(styled[run.range])
            }
        }
        if !pending.characters.isEmpty { result = result + Text(pending) }
        return result
    }

    private static func mathText(_ math: MarkdownMath, size: CGFloat) -> Text {
        guard let rendered = MarkdownMathRenderer.render(math.latex, display: false, fontSize: size) else {
            return Text(verbatim: math.latex).font(.system(size: size * 0.9, design: .monospaced))
        }
        return Text(rendered.image).baselineOffset(-rendered.descent)
    }
}
