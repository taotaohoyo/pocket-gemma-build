import SwiftUI
import PocketCore

/// 初回起動 (user, 2026-10-24 21:23 UTC, 「Fielua — 初回起動オンボーディング実装
/// 指示書」): the welcome of 1.1.0 (157) and before, one screen of models,
/// becomes four steps, as iOS's own setup, five since 1.1.0 (182) with
/// 起動時のチャット (user, 2026-10-25 13:55 UTC). ようこそ is the one showy screen:
/// the orb of light blooming out of a small light, felt in the hand as it
/// grows (AuroraBloom, 1.1.0 (178)), and the wordmark appearing letter by
/// letter in the rainbow of the replies as it opens. Then
/// plain pages: the model (ModelStore's list, downloads and choice), the
/// keyboard style (設定 › キーボードと入力's own phones, ComposerStylePicker),
/// the chat a launch opens (its phones there too, LaunchChatPicker) and
/// 準備完了, which waits for the model and opens the chat. The model's
/// download runs on while the next pages are read. Each step reached is
/// saved, so a launch after Fielua was closed midway goes on from there;
/// the model, keyboard and launch choices are the settings themselves,
/// saved as they are made. No permission is asked for on the way. A setup
/// left at 準備完了 before 1.1.0 (182) goes on from 起動時のチャット, the
/// step that took its number.
enum OnboardingStep: Int, Hashable, CaseIterable {
    case welcome, model, keyboard, launch, ready
}

enum Onboarding {
    /// Which setup this is (user, 2026-10-25 12:04 UTC, 「スタートアップの全
    /// ユーザー向け初回表示制御」): every phone shows it once, a new one and
    /// one updated from 1.1.0 (179) or before alike, and once it has been
    /// finished no later build shows it again, whatever its number. Only a
    /// release the user asks to show the setup to everyone again gives it
    /// a new name here; every phone then shows that edition once too.
    /// 1.1.0 (217) is one (user, 2026-10-28 07:51 UTC, 「217では、初回起動
    /// 扱いになるように」): the setup of the new flower, after
    /// "2026-10-aurora-bloom" of 1.1.0 (181).
    static let edition: String = {
        #if POCKET_PREVIEW
        // UI tests: a later release with a new edition.
        if let flag = ProcessInfo.processInfo.arguments.first(where: { $0.hasPrefix("--startup-edition=") }) {
            return String(flag.dropFirst("--startup-edition=".count))
        }
        #endif
        return "2026-10-fielua-flower"
    }()
    /// The edition finished on this phone. UserDefaults keeps it through
    /// every update; only deleting Fielua forgets it.
    static let finishedKey = "onboarding-finished-edition"
    /// The step reached; absent before the first step on and after the end.
    static let stepKey = "onboarding-step-v1"
    /// The model whose download the setup started, so choosing another
    /// one on the way stops it.
    static let downloadKey = "onboarding-download-v1"
    /// Up to 1.1.0 (180): the setup finished for good (or skipped on a
    /// phone that had chats or a saved model), and 「初回起動扱いにする」's
    /// request. Neither counts for an edition.
    private static let oldKeys = ["model-startup-completed-v1", "model-startup-again-v1"]

    /// Whether this phone has yet to finish this edition; a setup closed
    /// midway goes on from its step.
    static var isDue: Bool { UserDefaults.standard.string(forKey: finishedKey) != edition }

    /// At launch, once.
    static func dueAtLaunch() -> Bool {
        for key in oldKeys { UserDefaults.standard.removeObject(forKey: key) }
        return isDue
    }

    /// 準備完了's はじめる: this edition is done on this phone, for good.
    static func finish() {
        UserDefaults.standard.set(edition, forKey: finishedKey)
        clear()
    }

    /// 開発者設定's 「初回起動扱いにする」: from the first step at the next
    /// launch.
    static func showAgain() {
        UserDefaults.standard.removeObject(forKey: finishedKey)
        clear()
    }
    /// The phone's memory.
    static var memory: DeviceCapacity {
        #if POCKET_PREVIEW
        // UI tests' phones: --memory-gb=N, all of it there to use.
        if let flag = ProcessInfo.processInfo.arguments.first(where: { $0.hasPrefix("--memory-gb=") }),
           let gigabytes = Double(flag.dropFirst("--memory-gb=".count)) {
            return DeviceCapacity(memoryBytes: UInt64(gigabytes * 1_000_000_000), freeDiskBytes: 0,
                                  processorCount: ProcessInfo.processInfo.processorCount, isPad: false)
        }
        #endif
        return DeviceOverview.memoryCapacity
    }
    /// The free space; it can keep the thread it is read on waiting.
    static var freeDisk: Int64 {
        #if POCKET_PREVIEW
        // UI tests' phone with room for E2B only.
        if ProcessInfo.processInfo.arguments.contains("--low-disk") { return 4_000_000_000 }
        #endif
        return DeviceOverview.freeDiskBytes
    }
    static func clear() {
        UserDefaults.standard.removeObject(forKey: stepKey)
        UserDefaults.standard.removeObject(forKey: downloadKey)
    }
}

struct OnboardingView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    @AppStorage(LaunchChatMode.storageKey) private var launchChat = LaunchChatMode.resume
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    private let onFinish: () -> Void
    @State private var path: [OnboardingStep]
    /// The model chosen on this setup; nil until a row is tapped, when the
    /// model already in use, saved or recommended is shown chosen.
    @State private var choice: String?
    /// Memory once, as the setup opens: what is free moves while a model
    /// downloads, and the recommendation and its note must not move with
    /// it. Free space once iOS has answered (off the main thread: reading
    /// it can keep the launch waiting).
    @State private var memory = Onboarding.memory
    @State private var freeDisk: Int64?
    /// The last error of a download, shown on 準備完了.
    @State private var failure: String?

    init(onFinish: @escaping () -> Void) {
        self.onFinish = onFinish
        let reached = OnboardingStep(rawValue: UserDefaults.standard.integer(forKey: Onboarding.stepKey)) ?? .welcome
        _path = State(initialValue: Array(OnboardingStep.allCases.dropFirst().prefix(reached.rawValue)))
    }

    /// Until the free space is known, every model is taken to fit.
    private var device: DeviceCapacity {
        DeviceCapacity(memoryBytes: memory.memoryBytes, freeDiskBytes: freeDisk ?? Int64.max / 4,
                       processorCount: memory.processorCount, isPad: memory.isPad,
                       availableMemoryBytes: memory.availableMemoryBytes)
    }
    /// Every model モデル管理 lists, E2B first (the user, 10:00 UTC
    /// 2026-10-28: 「スタートアップのモデル選択のところには全部のモデルを
    /// 選択可能な状態に」; until 1.1.0 (218) only E4B and E2B): E4B, the
    /// test versions 12B and Phi, Qwen3.5 and Qwen2.5, and Qwen3 0.6B while
    /// developer settings are on. The model in use stays on the list when
    /// it is saved (a phone set up before, shown the setup after an update,
    /// keeps the model it uses).
    private var models: [ModelSpec] {
        let all = [ModelSpec.e2b] + ModelSpec.visibleCatalog(developer: showDeveloperSettings).filter { $0.id != ModelSpec.e2b.id }
        let current = model.selectedModel
        guard !all.contains(current), model.isInstalled(current) || model.isWorking(on: current) else { return all }
        return all + [current]
    }
    /// Gemma 4 E2B, the first model of every new phone (fielua-reports
    /// Issue #1, 2026-10-28, 「初回E2Bセットアップ」): light enough for any
    /// phone, it reads photos, and the empty chat's try questions were
    /// tried on it. Until 1.1.0 (218) the setup recommended E4B wherever it
    /// had the memory to spare (ModelRecommendation); E4B is still on the
    /// list to choose, and in モデル管理.
    private var recommended: ModelSpec? { .e2b }
    /// What is chosen: this setup's choice, else the model in use when it
    /// is saved, on its way or was chosen before (a setup started again,
    /// or a phone set up before, shown the setup again: it keeps its model
    /// and downloads nothing), else a saved one, else E2B.
    private var selected: ModelSpec {
        if let choice, let spec = ModelSpec.find(choice) { return spec }
        let current = model.selectedModel
        let choseBefore = UserDefaults.standard.string(forKey: "selectedModelID") != nil
        if models.contains(current), model.isInstalled(current) || model.isWorking(on: current) || choseBefore {
            return current
        }
        return models.first(where: model.isInstalled) ?? recommended ?? .e2b
    }

    var body: some View {
        NavigationStack(path: $path) {
            OnboardingWelcome { path.append(.model) }
                .toolbar(.hidden, for: .navigationBar)
                .navigationDestination(for: OnboardingStep.self) { step in page(step) }
        }
        .onChange(of: path) { _, path in
            UserDefaults.standard.set((path.last ?? .welcome).rawValue, forKey: Onboarding.stepKey)
        }
        .task {
            freeDisk = await Task.detached(priority: .userInitiated) { Onboarding.freeDisk }.value
        }
        // Only a download that cannot start comes up as an alert, where it
        // was asked for; a later failure waits on 準備完了 with its retry.
        .onChange(of: model.error) { _, error in
            guard let error else { return }
            failure = error
            if path.last != .model { model.error = nil }
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(
            get: { model.error != nil && path.last == .model }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    @ViewBuilder private func page(_ step: OnboardingStep) -> some View {
        switch step {
        case .welcome, .model:
            OnboardingModelPage(models: models, device: device, recommended: recommended, selected: selected,
                                choose: { choice = $0.id }, onContinue: confirmModel)
        case .keyboard:
            OnboardingKeyboardPage(style: $style) { path.append(.launch) }
        case .launch:
            OnboardingLaunchPage(mode: $launchChat, style: style) { path.append(.ready) }
        case .ready:
            OnboardingReadyPage(spec: selected, style: style, launchChat: launchChat, failure: failure,
                                retry: retry, onStart: finish)
        }
    }

    private func confirmModel() {
        let spec = selected
        model.select(spec)
        // A download this setup started for a model no longer chosen stops.
        if let started = ModelSpec.find(UserDefaults.standard.string(forKey: Onboarding.downloadKey)),
           started.id != spec.id, model.isDownloading(started) {
            model.cancelDownload(started)
        }
        if !model.isInstalled(spec) && !model.isWorking(on: spec) {
            failure = nil
            model.download(spec)
            guard model.error == nil else { return }
            UserDefaults.standard.set(spec.id, forKey: Onboarding.downloadKey)
        }
        choice = spec.id
        path.append(.keyboard)
    }

    private func retry() {
        failure = nil
        model.error = nil
        model.download(selected)
        UserDefaults.standard.set(selected.id, forKey: Onboarding.downloadKey)
    }

    private func finish() {
        model.select(selected)
        chats.newChat(modelID: selected.id)
        Onboarding.finish()
        onFinish()
    }
}

// MARK: - ようこそ

private struct OnboardingWelcome: View {
    let onContinue: () -> Void
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    /// The light's first frame: Aurora Bloom's timeline counts from it.
    @State private var start: Date?
    @State private var shown = false
    @State private var haptics = BloomHaptics()
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 0)
            // The canvas holds the flower's glow around it: the wordmark
            // sits 28pt under the flower itself.
            WelcomeFlower(still: reduceMotion, start: start)
                .padding(.bottom, 28 - WelcomeFlower.margin)
            WelcomeWordmark(still: reduceMotion, start: start)
            Text("あなたの\(DeviceOverview.name)で、あなたの会話を。")
                .font(.body).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.top, 10)
                .opacity(shown ? 1 : 0)
            Spacer(minLength: 0)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background { PaperBackground().ignoresSafeArea() }
        .safeAreaBar(edge: .bottom) {
            // There from the first frame: nothing has to be waited for, and
            // what the haptics have left stops with it.
            OnboardingButton("続ける", id: "onboarding-welcome-continue") {
                haptics.stop("continue")
                onContinue()
            }
            .padding(.horizontal, 24).padding(.bottom, 12)
        }
        #if POCKET_PREVIEW
        .overlay(alignment: .topLeading) {
            if ProcessInfo.processInfo.arguments.contains("--haptics-trace") {
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityIdentifier("welcome-haptics-trace")
                    .accessibilityLabel(haptics.trace)
            }
        }
        #endif
        .task(id: scenePhase == .active) {
            // Once, when Fielua is in front: back from モデル the light is
            // as it was, and the haptics do not play again.
            guard start == nil, scenePhase == .active else { return }
            haptics.prepare()
            await WelcomeFlower.prepare()
            #if POCKET_PREVIEW
            await AuroraBloom.previewDelay()
            #endif
            guard !Task.isCancelled, scenePhase == .active else { return }
            start = .now
            // The light is there at once with Reduce Motion, and when the
            // phone is critically hot (OrbPace): one soft tap.
            haptics.play(reduceMotion || OrbPace.current == .still ? .still : .bloom)
            if reduceMotion {
                shown = true
            } else {
                withAnimation(.easeOut(duration: 0.7).delay(AuroraBloom.span(AuroraBloom.caption))) { shown = true }
            }
        }
        .onDisappear { haptics.stop("left") }
        .onChange(of: scenePhase) { _, phase in
            if start != nil && phase != .active { haptics.stop("inactive") }
        }
    }
}

/// Fielua's flower, large, opening (brand 2026-10-27, in place of Aurora
/// Bloom's orb of light): its petals come out of the centre one after
/// another (BloomingFlower) as a warm glow behind it swells while it opens
/// and settles, on Aurora Bloom's timeline, so the wordmark and the haptics
/// keep with it. It draws at the display's rate only while it opens and is
/// the still mark after; it is the still mark from the start with Reduce
/// Motion or when the phone is critically hot, and stops drawing while it
/// is off the screen or the app is not active.
private struct WelcomeFlower: View {
    /// The square drawn in, as the orb's was; the flower is 132pt across
    /// in its middle, the rest is the glow's room.
    static let canvas: CGFloat = 280
    static let flower: CGFloat = 132
    static var height: CGFloat { flower * FlowerGeometry.bounds.height / FlowerGeometry.bounds.width }
    /// From the flower's top and bottom to the canvas's (75pt, as from the
    /// orb's light, so everything below stays where it was).
    static var margin: CGFloat { (canvas - height) / 2 }
    /// When the glow has settled after the flower has opened.
    static let settled: TimeInterval = 2.6
    let still: Bool
    /// Aurora Bloom's start; no flower before it.
    let start: Date?
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.scenePhase) private var scenePhase
    @State private var pace = OrbPace.current
    @State private var onScreen = true
    @State private var opening = true

    var body: some View {
        // A ZStack, not a Group: a Group's modifiers go to its views, and
        // before the flower starts there is none to hold the frame or run
        // the task (1.1.0 (173) showed no light at all).
        ZStack {
            if let start {
                if still || pace == .still || !opening {
                    flower(at: Self.settled)
                } else {
                    TimelineView(.animation(minimumInterval: nil, paused: !(onScreen && scenePhase == .active))) { context in
                        flower(at: AuroraBloom.age(since: start, at: context.date))
                    }
                }
            } else {
                // Drawn once, unseen, before the flower opens, so its petals'
                // mesh gradients are ready and the first frames are on time
                // (the light's shader was compiled ahead in the same way).
                BloomingFlower(size: Self.flower, time: Self.settled).opacity(0.002)
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .task(id: start) {
            guard let start else { return }
            let left = start.addingTimeInterval(AuroraBloom.span(Self.settled)).timeIntervalSinceNow
            if left > 0 {
                do { try await Task.sleep(for: .seconds(left)) } catch { return }
            }
            opening = false
        }
    }

    /// Time for the unseen flower to be drawn once before the bloom starts.
    static func prepare() async {
        try? await Task.sleep(for: .milliseconds(150))
    }

    private func flower(at time: TimeInterval) -> some View {
        // The glow comes with the petals, a third more as the flower opens
        // (AuroraBloom.glow), and stays faint: on paper the light yellow,
        // under the threshold where the UI tests count colour; on charcoal
        // a trace of the yellow.
        let dark = colorScheme == .dark
        let strength = AuroraBloom.growth(at: time) * AuroraBloom.glow(at: time)
        let glow = dark ? Theme.brandYellow.opacity(0.11 * strength) : Theme.brandLight.opacity(0.34 * strength)
        // The petals' base sits a little below the flower's frame's middle.
        let base = UnitPoint(x: 0.5, y: (Self.margin - FlowerGeometry.bounds.minY * Self.flower / FlowerGeometry.bounds.width) / Self.canvas)
        return ZStack {
            Rectangle().fill(RadialGradient(colors: [glow, glow.opacity(0)], center: base,
                                            startRadius: 0, endRadius: Self.canvas / 2))
            BloomingFlower(size: Self.flower, time: time)
        }
    }
}

/// 「Fielua」, the brand's wordmark (FieluaWordmark's serif and warm taupe),
/// each letter coming into focus as it rises into place, in the replies'
/// golds (ReplyRevealStyle's colours across the word), which give way to the
/// wordmark's own colour. It begins as the flower is nearly open
/// (AuroraBloom.wordmark). Plain with Reduce Motion, as the replies.
private struct WelcomeWordmark: View {
    static var begin: TimeInterval { AuroraBloom.wordmark }
    static let spacing: TimeInterval = 0.085
    static let fade: TimeInterval = 0.7
    static let tint: TimeInterval = 1.6
    static let letters = 6
    /// When the last letter is in its own colour.
    static var end: TimeInterval { begin + spacing * Double(letters - 1) + max(fade, tint) }
    let still: Bool
    /// Aurora Bloom's start; the word keeps its place, unseen, until then.
    let start: Date?
    @Environment(\.colorScheme) private var colorScheme
    @State private var settled = false
    @State private var onScreen = true

    var body: some View {
        let word = Text(verbatim: "Fielua").font(.system(size: 46, weight: .regular, design: .serif))
        ZStack {
            if still || settled {
                word.foregroundStyle(Theme.wordmark)
            } else if let start {
                TimelineView(.animation(minimumInterval: nil, paused: !onScreen)) { context in
                    word.foregroundStyle(Theme.wordmark).textRenderer(WordmarkReveal(age: AuroraBloom.age(since: start, at: context.date),
                                                     dark: colorScheme == .dark))
                }
            } else {
                // Clear, so VoiceOver has the heading from the start.
                word.foregroundStyle(.clear)
            }
        }
        .accessibilityAddTraits(.isHeader)
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .task(id: start) {
            guard let start else { return }
            let left = start.addingTimeInterval(AuroraBloom.span(Self.end)).timeIntervalSinceNow
            if left > 0 {
                do { try await Task.sleep(for: .seconds(left)) } catch { return }
            }
            settled = true
        }
    }
}

private struct WordmarkReveal: TextRenderer {
    let age: TimeInterval
    let dark: Bool

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        var count = 0
        for line in layout { for run in line { count += run.count } }
        let stops = dark ? ReplyRevealStyle.darkStops : ReplyRevealStyle.lightStops
        var index = 0
        for line in layout {
            for run in line {
                for slice in run {
                    defer { index += 1 }
                    let own = age - (WelcomeWordmark.begin + Double(index) * WelcomeWordmark.spacing)
                    guard own > 0 else { continue }
                    var copy = context
                    let progress = min(own / WelcomeWordmark.fade, 1)
                    let opacity = progress * progress * (3 - 2 * progress)
                    if progress < 1 {
                        let remaining = 1 - progress
                        copy.opacity *= opacity
                        copy.translateBy(x: 0, y: 6 * remaining * remaining)
                        copy.addFilter(.blur(radius: 5 * remaining))
                    }
                    // Its place among the golds by its place in the word;
                    // the colour holds, then gives way.
                    let position = count > 1 ? Double(index) / Double(count - 1) * Double(stops.count - 1) : 0
                    let at = min(Int(position), stops.count - 2)
                    let mix = position - Double(at)
                    let from = stops[at], to = stops[at + 1]
                    let way = min(own / WelcomeWordmark.tint, 1)
                    let giving = max((way - 0.35) / 0.65, 0)
                    var share = 1 - giving * giving * (3 - 2 * giving)
                    share = ReplyRevealStyle.fadingShare(share, opacity: opacity, dark: dark)
                    if share > 0.01 {
                        copy.addFilter(.colorMatrix(ReplyRevealStyle.filter(ReplyRevealStyle.Tint(
                            red: from.red + (to.red - from.red) * mix,
                            green: from.green + (to.green - from.green) * mix,
                            blue: from.blue + (to.blue - from.blue) * mix, share: share))))
                    }
                    copy.draw(slice)
                }
            }
        }
    }
}

// MARK: - モデルを選ぶ

/// The models by series (fielua-reports Issue #7, the user's request of
/// 2026-11-12, 1.1.0 (269)): until 268 every model had a row of its own,
/// ten with developer settings, a list longer than the screen. Now the
/// card lists the series, Gemma, Qwen, LFM and Phi, each closed, and a
/// series opens in place to its models, closing the one open before.
/// Opening one chooses nothing and downloads nothing: a model's row
/// chooses, 続ける downloads, as before. The series that holds the choice
/// names it, so E2B, recommended and chosen, is there without opening
/// Gemma; the series with the recommended model and a series of test
/// versions say so before they are opened.
private struct OnboardingModelPage: View {
    @EnvironmentObject private var model: ModelStore
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    let models: [ModelSpec]
    let device: DeviceCapacity
    let recommended: ModelSpec?
    let selected: ModelSpec
    let choose: (ModelSpec) -> Void
    let onContinue: () -> Void
    /// The series shown open; none until one is tapped.
    @State private var open: String?

    private var fit: ModelFit { ModelRecommendation.fit(selected, device: device) }
    private var saved: Bool { model.isInstalled(selected) }
    private var groups: [ModelFamilyGroup] { ModelFamilyGroup.groups(models) }
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 28) {
                    OnboardingHeader(title: String(localized: "モデルを選ぶ"), detail: String(localized: "いつでも変更できます。"))
                    VStack(spacing: 0) {
                        ForEach(Array(groups.enumerated()), id: \.element.id) { index, group in
                            if index > 0 { Divider().padding(.leading, 68) }
                            familySection(group)
                        }
                    }
                    // The open series' wash keeps to the card's rounded
                    // corners when it is the last one (Phi).
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .fieluaCard(cornerRadius: 22, elevated: true)
                    notes
                }
                .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
                .frame(maxWidth: 560).frame(maxWidth: .infinity)
            }
            .scrollBounceBehavior(.basedOnSize)
            .accessibilityIdentifier("onboarding-model-list")
            .background(Theme.canvas, ignoresSafeAreaEdges: .all)
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaBar(edge: .bottom) {
                OnboardingButton("続ける", id: "onboarding-model-continue",
                                 enabled: !model.isRestoring && (saved || fit.hasDiskSpace), action: onContinue)
                    .padding(.horizontal, 24).padding(.bottom, 12)
            }
            .onAppear { model.refreshInstalled() }
            // A series opened low on the page shows its last model above
            // 続ける, scrolling no more than that takes (none when it shows).
            .onChange(of: open) { _, open in
                guard let open, let last = groups.first(where: { $0.id == open })?.models.last else { return }
                DispatchQueue.main.async {
                    withAnimation(FieluaMotion.disclose(reduceMotion)) { proxy.scrollTo(last.id, anchor: nil) }
                }
            }
        }
    }

    /// A series' row and, while it is open, its models under it on a
    /// faint wash, their names in line with the series' name.
    private func familySection(_ group: ModelFamilyGroup) -> some View {
        let isOpen = open == group.id
        return VStack(spacing: 0) {
            familyRow(group)
            // The models are always laid out at their own height, and while
            // the series is closed the frame around them is none tall. So
            // opening and closing, and one series closing while another
            // opens, unroll and roll them up under their series, top first,
            // and none ever draws over the next series' row. Closed, they
            // can't be tapped or reached by VoiceOver.
            VStack(spacing: 0) {
                ForEach(group.models) { spec in
                    Divider().padding(.leading, 68)
                    row(spec).id(spec.id)
                }
            }
            .background(Theme.ink.opacity(0.03))
            .fixedSize(horizontal: false, vertical: true)
            .opacity(isOpen ? 1 : 0)
            .frame(height: isOpen ? nil : 0, alignment: .top)
            .clipped()
            .allowsHitTesting(isOpen)
            .accessibilityHidden(!isOpen)
        }
    }

    /// A series: its mark, its name, and the model chosen in it or how
    /// many it has; the chevron turns down while it is open. Tapping it
    /// opens or closes it and chooses nothing.
    private func familyRow(_ group: ModelFamilyGroup) -> some View {
        let isOpen = open == group.id
        let line = familyLine(group)
        let badge = familyBadge(group)
        let coming = group.models.first { model.isDownloading($0) }
        return Button {
            withAnimation(FieluaMotion.disclose(reduceMotion)) { open = isOpen ? nil : group.id }
        } label: {
            HStack(spacing: 14) {
                ModelFamilyMark(group: group, size: 38)
                VStack(alignment: .leading, spacing: 4) {
                    // The badge beside the name where both fit, under it
                    // where they don't (the largest text), as a model's row.
                    ViewThatFits(in: .horizontal) {
                        HStack(alignment: .firstTextBaseline, spacing: 8) { familyName(group, badge: badge) }
                        VStack(alignment: .leading, spacing: 4) { familyName(group, badge: badge) }
                    }
                    Text(line).font(.subheadline).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                    // A model on its way shows it with the series closed too.
                    if let coming, !isOpen {
                        ProgressView(value: model.progress(for: coming)).fieluaStateTint().padding(.top, 2)
                    }
                }
                .layoutPriority(1)
                Spacer(minLength: 8)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.tertiary)
                    .rotationEffect(.degrees(isOpen ? 90 : 0))
                    .accessibilityHidden(true)
            }
            .padding(.horizontal, 16).padding(.vertical, 13)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(familyLabel(group, badge: badge))
        .accessibilityValue(familyValue(line, coming: coming, open: isOpen))
        .accessibilityHint(isOpen ? Text("モデルの一覧を閉じます") : Text("モデルの一覧を開きます"))
        .accessibilityAddTraits(.isButton)
        .accessibilityIdentifier("onboarding-family-\(group.key)")
    }

    private enum FamilyBadge { case recommended, testVersion }

    @ViewBuilder private func familyName(_ group: ModelFamilyGroup, badge: FamilyBadge?) -> some View {
        Text(verbatim: group.title).font(.headline).lineLimit(1)
        if badge == .recommended { recommendedBadge } else if badge == .testVersion { TestVersionBadge() }
    }

    /// おすすめ on the series of the recommended model (Gemma, for E2B);
    /// テスト版 on a series of test versions only (LFM, Phi).
    private func familyBadge(_ group: ModelFamilyGroup) -> FamilyBadge? {
        if group.contains(recommended?.id) { return .recommended }
        return group.isAllTestVersions ? .testVersion : nil
    }

    /// The model chosen in the series (「Gemma 4 E2Bを選択中」), else how
    /// many models it has and how many are on the phone.
    private func familyLine(_ group: ModelFamilyGroup) -> String {
        if group.contains(selected.id) { return String(localized: "\(selected.name)を選択中") }
        return group.summary { model.isInstalled($0) }
    }

    /// The series' line, a download of one of its models, and whether it
    /// is open: what VoiceOver says after the name.
    private func familyValue(_ line: String, coming: ModelSpec?, open: Bool) -> String {
        var spoken = line
        if let coming {
            let percent = Int((model.progress(for: coming) * 100).rounded(.down))
            // In the words of the model's own row: a download waiting for
            // Wi-Fi or a connection says so.
            let download: String
            switch model.downloadWait(for: coming) {
            case nil: download = String(localized: "\(coming.name) · ダウンロード中 \(percent)%")
            case .network: download = String(localized: "\(coming.name) · 接続待ち \(percent)%")
            default: download = String(localized: "\(coming.name) · Wi-Fi待ち \(percent)%")
            }
            spoken = String(localized: "\(spoken)、\(download)")
        }
        let state = open ? String(localized: "開いています") : String(localized: "閉じています")
        return String(localized: "\(spoken)、\(state)")
    }

    /// The series' name and its badge, as the model rows say theirs; the
    /// line and whether it is open are its value.
    private func familyLabel(_ group: ModelFamilyGroup, badge: FamilyBadge?) -> String {
        switch badge {
        case .recommended: return String(localized: "\(group.title)、おすすめ")
        case .testVersion: return String(localized: "\(group.title)、テスト版")
        case nil: return group.title
        }
    }

    /// The small word beside a recommended name, without standing out: a
    /// warm grey wash (the yellow is the chosen card's check).
    private var recommendedBadge: some View {
        Text("おすすめ").font(.caption2.weight(.semibold)).foregroundStyle(Theme.icon)
            .lineLimit(1)
            .padding(.horizontal, 7).padding(.vertical, 2)
            .background(Theme.ink.opacity(0.07), in: Capsule())
    }

    /// A model of an open series: smaller than the series' row, its mark
    /// centred under the series' mark and its name in line with the
    /// series' name, with its size, its state and the check.
    private func row(_ spec: ModelSpec) -> some View {
        let chosen = spec.id == selected.id
        let isRecommended = spec.id == recommended?.id
        return Button {
            guard !chosen else { return }
            withAnimation(FieluaMotion.choose) { choose(spec) }
        } label: {
            HStack(spacing: 14) {
                ModelMark(model: spec, size: 30).frame(width: 38)
                VStack(alignment: .leading, spacing: 3) {
                    // Beside the name where both fit; under it where the
                    // word is longer ("Recommended"), never breaking the name.
                    ViewThatFits(in: .horizontal) {
                        HStack(alignment: .firstTextBaseline, spacing: 8) { name(spec, recommended: isRecommended) }
                        VStack(alignment: .leading, spacing: 4) { name(spec, recommended: isRecommended) }
                    }
                    Text(detail(spec)).font(.footnote).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                    if model.isDownloading(spec) {
                        ProgressView(value: model.progress(for: spec)).fieluaStateTint().padding(.top, 2)
                    }
                }
                // The whole row's room for the name and its badge, not half.
                .layoutPriority(1)
                Spacer(minLength: 8)
                OnboardingCheck(on: chosen)
            }
            .padding(.horizontal, 16).padding(.vertical, 10)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .sensoryFeedback(.selection, trigger: chosen) { _, now in now }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(isRecommended ? String(localized: "\(spec.name)、おすすめ") : spec.name)
        .accessibilityValue(detail(spec))
        .accessibilityAddTraits(chosen ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("onboarding-model-\(spec.id)")
    }

    @ViewBuilder private func name(_ spec: ModelSpec, recommended: Bool) -> some View {
        Text(spec.name).font(.subheadline.weight(.semibold)).lineLimit(1)
        if recommended {
            recommendedBadge
        } else if spec.isTestVersion {
            // 12B and Phi, as in モデル管理.
            TestVersionBadge()
        }
    }

    /// The size and, when there is one, what the phone has of it.
    private func detail(_ spec: ModelSpec) -> String {
        if model.isInstalled(spec) { return String(localized: "\(spec.sizeLabel) · ダウンロード済み") }
        if model.isDownloading(spec) {
            let percent = Int((model.progress(for: spec) * 100).rounded(.down))
            // Short enough for one line beside the name and the check.
            switch model.downloadWait(for: spec) {
            case nil: return String(localized: "\(spec.sizeLabel) · ダウンロード中 \(percent)%")
            case .network: return String(localized: "\(spec.sizeLabel) · 接続待ち \(percent)%")
            default: return String(localized: "\(spec.sizeLabel) · Wi-Fi待ち \(percent)%")
            }
        }
        if model.isWorking(on: spec) { return String(localized: "\(spec.sizeLabel) · 確認しています") }
        return spec.sizeLabel
    }

    /// Only what stands in the way: the chosen model's memory, and the
    /// space its download needs (続ける waits for it). Quiet text; the
    /// small orange mark says it matters. And, for a model not saved yet,
    /// what 続ける starts: its download, its size, and that it needs the
    /// internet (1.1.0 (219)); its progress shows in its row and on 準備完了.
    @ViewBuilder private var notes: some View {
        if !saved && !model.isWorking(on: selected) && fit.hasDiskSpace {
            // The name on one line: "Gemma 4" and "E2B" are not split.
            let name = selected.name.replacingOccurrences(of: " ", with: "\u{00A0}")
            let text = String(localized: "続けると、\(name)（\(selected.sizeLabel)）のダウンロードを始めます。")
            Label {
                Text(text).foregroundStyle(.secondary)
            } icon: {
                Image(systemName: "arrow.down.circle").foregroundStyle(.secondary)
            }
            .font(.footnote)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
            .accessibilityIdentifier("onboarding-download-note")
        }
        // What モデル管理's card says of the chosen model, in its words:
        // a test version, a model that thinks first, and 12B where this
        // signature has no room for it (the sideload).
        if selected.isTestVersion {
            note(ModelSpec.testVersionNote, systemImage: "exclamationmark.triangle", id: "onboarding-test-version-note")
        }
        if selected.capabilities.reasons {
            Label("答える前に考えるため、返信が始まるまで時間がかかります。", systemImage: "brain")
                .font(.footnote).foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityIdentifier("onboarding-reasoning-note")
        }
        if selected.id == ModelSpec.gemma12B.id, !LargeModelProbe.twelveBFitsAtLaunch {
            note(String(localized: "この署名ではアドレス空間が足りないため、読み込めません。TestFlight版で使ってください。"),
                 systemImage: "exclamationmark.triangle", id: "onboarding-room-note")
        }
        if fit.memoryIsTight {
            note(memoryNote, systemImage: "memorychip", id: "onboarding-memory-note")
        }
        if !saved && !fit.hasDiskSpace {
            note(String(localized: "ダウンロードするには、あと\(shortfall)の空き容量が必要です。"),
                 systemImage: "externaldrive.badge.exclamationmark", id: "onboarding-disk-note")
        }
        // On cellular only, a download waits for Wi-Fi unless this is on
        // (the same switch as in モデル管理).
        if !saved && !model.network.hasWiFi && model.network.isOnline {
            VStack(alignment: .leading, spacing: 8) {
                Toggle("モバイル通信でもダウンロード", isOn: $model.allowsCellular)
                    .font(.subheadline.weight(.semibold)).fieluaStateTint()
                    .accessibilityIdentifier("onboarding-download-cellular-toggle")
                Text("オフのときは、Wi-Fiにつながってからダウンロードします（\(selected.name) \(selected.sizeLabel)）。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(16)
            .fieluaCard(cornerRadius: 18, elevated: true)
        }
    }

    /// A lighter model is named only when it has the memory to spare: the
    /// recommended one, when another is chosen. When no model has room,
    /// the recommended one is only the lightest, and none is offered.
    private var memoryNote: String {
        guard let recommended, recommended.id != selected.id,
              !ModelRecommendation.fit(recommended, device: device).memoryIsTight else {
            return String(localized: "この\(DeviceOverview.name)のメモリでは余裕がなく、返信が遅くなったり、アプリが終了したりすることがあります。")
        }
        // The name on one line: "Gemma 4" and "E2B" are not split.
        let lighter = recommended.name.replacingOccurrences(of: " ", with: "\u{00A0}")
        return String(localized: "この\(DeviceOverview.name)のメモリでは余裕がなく、返信が遅くなったり、アプリが終了したりすることがあります。\(lighter)なら余裕があります。")
    }

    /// What the download still needs: the model and 1 GB more
    /// (ModelRecommendation), less what is free, rounded up.
    private var shortfall: String {
        let needed = max(selected.byteCount + 1_000_000_000 - device.freeDiskBytes, 0)
        return ByteCountFormatter.string(fromByteCount: (needed + 9_999_999) / 10_000_000 * 10_000_000,
                                         countStyle: .decimal)
    }

    private func note(_ text: String, systemImage: String, id: String) -> some View {
        Label {
            Text(text).foregroundStyle(.secondary)
        } icon: {
            Image(systemName: systemImage).foregroundStyle(.orange)
        }
        .font(.footnote)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text)
        .accessibilityIdentifier(id)
    }
}

// MARK: - 入力スタイル

/// 設定 › キーボードと入力's two phones (ComposerStylePicker) as they are there,
/// in the same card, bound to the same setting: the chat follows the choice
/// at once. They start playing once the page has slid in.
private struct OnboardingKeyboardPage: View {
    @Binding var style: ComposerStyle
    let onContinue: () -> Void
    @State private var inView = false

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                OnboardingHeader(title: String(localized: "入力スタイルを選ぶ"), detail: String(localized: "いつでも変更できます。"))
                VStack(spacing: 14) {
                    ComposerStylePicker(selection: $style)
                    Text(style.previewCaption)
                        .font(.subheadline).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2, reservesSpace: true)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(18)
                .frame(maxWidth: .infinity)
                .fieluaCard(cornerRadius: 20, elevated: true)
                .environment(\.settingsPageInView, inView)
            }
            .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-keyboard")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaBar(edge: .bottom) {
            OnboardingButton("続ける", id: "onboarding-keyboard-continue", action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .task {
            // After the push, so the slide has the frames to itself.
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            inView = true
        }
        .onDisappear { inView = false }
    }
}

// MARK: - 起動時のチャット

/// 設定 › キーボードと入力's 起動時のチャット (LaunchChatPicker), as 入力スタイル's
/// page: two phones opening Fielua from the home screen, in the style just
/// chosen, bound to the setting itself. They start once the page has slid in.
private struct OnboardingLaunchPage: View {
    @Binding var mode: LaunchChatMode
    let style: ComposerStyle
    let onContinue: () -> Void
    @State private var inView = false

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                OnboardingHeader(title: String(localized: "起動時のチャット"), detail: String(localized: "いつでも変更できます。"))
                VStack(spacing: 14) {
                    LaunchChatPicker(selection: $mode, style: style)
                    Text(mode.previewCaption)
                        .font(.subheadline).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2, reservesSpace: true)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(18)
                .frame(maxWidth: .infinity)
                .fieluaCard(cornerRadius: 20, elevated: true)
                .environment(\.settingsPageInView, inView)
            }
            .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-launch")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaBar(edge: .bottom) {
            OnboardingButton("続ける", id: "onboarding-launch-continue", action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .task {
            // After the push, so the slide has the frames to itself.
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            inView = true
        }
        .onDisappear { inView = false }
    }
}

// MARK: - 準備完了

private struct OnboardingReadyPage: View {
    @EnvironmentObject private var model: ModelStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let spec: ModelSpec
    let style: ComposerStyle
    let launchChat: LaunchChatMode
    let failure: String?
    let retry: () -> Void
    let onStart: () -> Void

    private enum Phase { case ready, downloading, preparing, failed, waiting }
    private var phase: Phase {
        if model.isInstalled(spec) { return .ready }
        if model.isDownloading(spec) { return .downloading }
        if model.isRestoring || model.isWorking(on: spec) { return .preparing }
        return failure != nil ? .failed : .waiting
    }

    var body: some View {
        let phase = phase
        ScrollView {
            VStack(spacing: 28) {
                // A thin line in the accent colour, as the rest of the setup.
                Image(systemName: symbol(phase))
                    .font(.system(size: 56, weight: .light))
                    .foregroundStyle(color(phase))
                    .contentTransition(.symbolEffect(.replace))
                    .frame(height: 76)
                    .padding(.top, 12)
                    .accessibilityHidden(true)
                OnboardingHeader(title: title(phase), detail: detail(phase))
                VStack(spacing: 0) {
                    modelRow(phase)
                    Divider().padding(.leading, 68)
                    HStack(spacing: 14) {
                        Image(systemName: "keyboard").font(.system(size: 20)).foregroundStyle(.secondary)
                            .frame(width: 38, height: 38)
                        // Laid out like the model row: the pair is too wide for one line.
                        VStack(alignment: .leading, spacing: 3) {
                            Text("入力スタイル").font(.headline)
                            Text(style.title).font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                    }
                    .padding(.horizontal, 16).padding(.vertical, 14)
                    .accessibilityElement(children: .combine)
                    Divider().padding(.leading, 68)
                    HStack(spacing: 14) {
                        Image(systemName: "arrow.up.forward.app").font(.system(size: 20)).foregroundStyle(.secondary)
                            .frame(width: 38, height: 38)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("起動時のチャット").font(.headline)
                            Text(launchChat.title).font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                    }
                    .padding(.horizontal, 16).padding(.vertical, 14)
                    .accessibilityElement(children: .combine)
                    .accessibilityIdentifier("onboarding-ready-launch")
                }
                .fieluaCard(cornerRadius: 22, elevated: true)
            }
            .padding(.horizontal, 24).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
            .animation(FieluaMotion.step(reduceMotion), value: phase)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-ready")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.success, trigger: phase == .ready) { was, now in !was && now }
        .safeAreaBar(edge: .bottom) {
            VStack(spacing: 14) {
                switch phase {
                case .failed:
                    OnboardingButton("もう一度試す", id: "onboarding-ready-retry", action: retry)
                case .waiting:
                    OnboardingButton("ダウンロード", id: "onboarding-ready-retry", action: retry)
                default:
                    OnboardingButton("はじめる", id: "onboarding-ready-start", enabled: phase == .ready, action: onStart)
                }
                if phase != .ready {
                    // The chat shows the model's state and keeps the
                    // download going.
                    Button("先にチャットを開く", action: onStart)
                        .font(.subheadline)
                        .accessibilityIdentifier("onboarding-ready-later")
                }
            }
            .padding(.horizontal, 24).padding(.bottom, 12)
        }
    }

    private func modelRow(_ phase: Phase) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                ModelMark(model: spec, size: 38)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text(status(phase)).font(.subheadline).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                        .accessibilityIdentifier("onboarding-ready-status")
                }
                Spacer(minLength: 8)
                if phase == .preparing { ProgressView() }
            }
            if phase == .downloading {
                ProgressView(value: model.progress(for: spec)).fieluaStateTint()
                if let wait = model.downloadWait(for: spec),
                   let hint = wait.hint(received: model.progress(for: spec) >= 0.01, switchOn: model.allowsCellular) {
                    Label(hint, systemImage: wait == .cellularDenied ? "antenna.radiowaves.left.and.right.slash" : "wifi.exclamationmark")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 14)
        .accessibilityElement(children: .combine)
    }

    private func status(_ phase: Phase) -> String {
        switch phase {
        case .ready: return String(localized: "オフラインで利用できます")
        case .downloading:
            let percent = Int((model.progress(for: spec) * 100).rounded(.down))
            return model.downloadWait(for: spec) == nil ? String(localized: "ダウンロード中 · \(percent)%") : String(localized: "通信を待っています · \(percent)%")
        case .preparing: return model.isRestoring ? String(localized: "モデルを確認しています") : String(localized: "ファイルを確認しています")
        case .failed: return String(localized: "ダウンロードできませんでした")
        case .waiting: return String(localized: "\(spec.sizeLabel) · 未ダウンロード")
        }
    }

    private func title(_ phase: Phase) -> String {
        switch phase {
        case .ready: return String(localized: "準備が整いました")
        case .downloading: return String(localized: "ダウンロードしています")
        case .preparing: return String(localized: "準備しています")
        case .failed: return String(localized: "問題が発生しました")
        case .waiting: return String(localized: "モデルをダウンロード")
        }
    }

    private func detail(_ phase: Phase) -> String? {
        switch phase {
        case .ready: return nil
        case .downloading, .preparing: return String(localized: "ほかのアプリに切り替えても続きます。")
        case .failed: return failure
        case .waiting: return String(localized: "ダウンロードすると、会話を始められます。")
        }
    }

    private func symbol(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "checkmark.circle"
        case .failed: return "exclamationmark.circle"
        default: return "arrow.down.circle"
        }
    }

    private func color(_ phase: Phase) -> Color {
        switch phase {
        case .failed: return .orange
        default: return Theme.tint
        }
    }
}

// MARK: - Parts

/// A page's title and its one line, centred, as in iOS's setup.
private struct OnboardingHeader: View {
    let title: String
    let detail: String?

    var body: some View {
        VStack(spacing: 10) {
            Text(title).font(.largeTitle.bold())
                .multilineTextAlignment(.center)
                .accessibilityAddTraits(.isHeader)
            if let detail {
                Text(detail).font(.body).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .fixedSize(horizontal: false, vertical: true)
    }
}

/// The step's one action: Fielua's primary button (the brand yellow's
/// prominent glass with an ink label), full width.
private struct OnboardingButton: View {
    let title: LocalizedStringKey
    let id: String
    var enabled = true
    let action: () -> Void

    init(_ title: LocalizedStringKey, id: String, enabled: Bool = true, action: @escaping () -> Void) {
        self.title = title; self.id = id; self.enabled = enabled; self.action = action
    }

    var body: some View {
        FieluaPrimaryButton(title, enabled: enabled, action: action)
            .frame(maxWidth: 480)
            .accessibilityIdentifier(id)
    }
}

/// The choice mark of ComposerStylePicker: a filled check on the chosen
/// row, an empty ring on the others.
private struct OnboardingCheck: View {
    let on: Bool
    var body: some View { FieluaCheckMark(on: on) }
}
