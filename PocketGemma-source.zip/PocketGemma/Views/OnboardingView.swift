import SwiftUI
import PocketCore

/// 初回起動 (user, 2026-10-24 21:23 UTC, 「Fielua — 初回起動オンボーディング実装
/// 指示書」): the welcome of 1.1.0 (157) and before, one screen of models,
/// becomes four steps, as iOS's own setup. ようこそ is the one showy screen:
/// the app icon's orb of light opening up (AuroraOrbShader, larger) and the
/// wordmark appearing letter by letter in the rainbow of the replies. Then
/// plain pages: the model (ModelStore's list, downloads and choice), the
/// keyboard style (設定 › キーボードと入力's own phones, ComposerStylePicker)
/// and 準備完了, which waits for the model and opens the chat. The model's
/// download runs on while the next pages are read. Each step reached is
/// saved, so a launch after Fielua was closed midway goes on from there;
/// the model and keyboard choices are the settings themselves, saved as
/// they are made. No permission is asked for on the way.
enum OnboardingStep: Int, Hashable, CaseIterable {
    case welcome, model, keyboard, ready
}

enum Onboarding {
    /// The step reached; absent before the first step on and after the end.
    static let stepKey = "onboarding-step-v1"
    /// The model whose download the setup started, so choosing another
    /// one on the way stops it.
    static let downloadKey = "onboarding-download-v1"
    static var inProgress: Bool { UserDefaults.standard.object(forKey: stepKey) != nil }
    static func clear() {
        UserDefaults.standard.removeObject(forKey: stepKey)
        UserDefaults.standard.removeObject(forKey: downloadKey)
    }
}

struct OnboardingView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    private let onFinish: () -> Void
    @State private var path: [OnboardingStep]
    /// The model chosen on this setup; nil until a row is tapped, when the
    /// model already in use, saved or recommended is shown chosen.
    @State private var choice: String?
    /// Memory now, free space once iOS has answered (off the main thread:
    /// reading it can keep the launch waiting).
    private let memory = DeviceOverview.memoryCapacity
    @State private var freeDisk: Int64?
    /// The last error of a download, shown on 準備完了.
    @State private var failure: String?

    init(onFinish: @escaping () -> Void) {
        self.onFinish = onFinish
        let reached = OnboardingStep(rawValue: UserDefaults.standard.integer(forKey: Onboarding.stepKey)) ?? .welcome
        _path = State(initialValue: Array(OnboardingStep.allCases.dropFirst().prefix(reached.rawValue)))
    }

    /// Until the free space is known, every model is taken to fit.
    private var device: DeviceCapacity {
        DeviceCapacity(memoryBytes: memory.memoryBytes, freeDiskBytes: freeDisk ?? Int64.max / 4,
                       processorCount: memory.processorCount, isPad: memory.isPad,
                       availableMemoryBytes: memory.availableMemoryBytes)
    }
    private var models: [ModelSpec] { ModelSpec.visibleCatalog(developer: false) }
    private var recommended: ModelSpec? {
        ModelRecommendation.recommended(for: device, installedIDs: Set(models.filter(model.isInstalled).map(\.id)),
                                        includeDeveloperModels: false)
    }
    /// What is chosen: this setup's choice, else the model in use when it
    /// is saved, on its way or was chosen before (a setup started again),
    /// else a saved one, else the one for this device.
    private var selected: ModelSpec {
        if let choice, let spec = ModelSpec.find(choice) { return spec }
        let current = model.selectedModel
        let choseBefore = UserDefaults.standard.string(forKey: "selectedModelID") != nil
        if models.contains(current), model.isInstalled(current) || model.isWorking(on: current) || choseBefore {
            return current
        }
        return models.first(where: model.isInstalled) ?? recommended ?? .e2b
    }

    var body: some View {
        NavigationStack(path: $path) {
            OnboardingWelcome { path.append(.model) }
                .toolbar(.hidden, for: .navigationBar)
                .navigationDestination(for: OnboardingStep.self) { step in page(step) }
        }
        .onChange(of: path) { _, path in
            UserDefaults.standard.set((path.last ?? .welcome).rawValue, forKey: Onboarding.stepKey)
        }
        .task {
            freeDisk = await Task.detached(priority: .userInitiated) { DeviceOverview.freeDiskBytes }.value
        }
        // Only a download that cannot start comes up as an alert, where it
        // was asked for; a later failure waits on 準備完了 with its retry.
        .onChange(of: model.error) { _, error in
            guard let error else { return }
            failure = error
            if path.last != .model { model.error = nil }
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(
            get: { model.error != nil && path.last == .model }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    @ViewBuilder private func page(_ step: OnboardingStep) -> some View {
        switch step {
        case .welcome, .model:
            OnboardingModelPage(models: models, device: device, recommended: recommended, selected: selected,
                                choose: { choice = $0.id }, onContinue: confirmModel)
        case .keyboard:
            OnboardingKeyboardPage(style: $style) { path.append(.ready) }
        case .ready:
            OnboardingReadyPage(spec: selected, style: style, failure: failure,
                                retry: retry, onStart: finish)
        }
    }

    private func confirmModel() {
        let spec = selected
        model.select(spec)
        // A download this setup started for a model no longer chosen stops.
        if let started = ModelSpec.find(UserDefaults.standard.string(forKey: Onboarding.downloadKey)),
           started.id != spec.id, model.isDownloading(started) {
            model.cancelDownload(started)
        }
        if !model.isInstalled(spec) && !model.isWorking(on: spec) {
            failure = nil
            model.download(spec)
            guard model.error == nil else { return }
            UserDefaults.standard.set(spec.id, forKey: Onboarding.downloadKey)
        }
        choice = spec.id
        path.append(.keyboard)
    }

    private func retry() {
        failure = nil
        model.error = nil
        model.download(selected)
        UserDefaults.standard.set(selected.id, forKey: Onboarding.downloadKey)
    }

    private func finish() {
        model.select(selected)
        chats.newChat(modelID: selected.id)
        Onboarding.clear()
        onFinish()
    }
}

// MARK: - ようこそ

private struct OnboardingWelcome: View {
    let onContinue: () -> Void
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var shown = false
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 0)
            // The canvas holds the light's spill around it: the wordmark
            // sits 28pt under the light itself.
            WelcomeOrb(still: reduceMotion)
                .padding(.bottom, 28 - WelcomeOrb.margin)
            WelcomeWordmark(still: reduceMotion)
            Text("会話は、この\(DeviceOverview.name)の中だけで。")
                .font(.body).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.top, 10)
                .opacity(shown ? 1 : 0)
            Spacer(minLength: 0)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .safeAreaBar(edge: .bottom) {
            // There from the first frame: nothing has to be waited for.
            OnboardingButton("続ける", id: "onboarding-welcome-continue", action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .onAppear {
            guard !shown else { return }
            if reduceMotion { shown = true; return }
            withAnimation(.easeOut(duration: 0.7).delay(1.0)) { shown = true }
        }
    }
}

/// The app icon's orb of light (AuroraOrbShader's auroraWelcomeOrb: the
/// chat's light with an outline a point wide at this size), large: it opens
/// out of a small light with a soft spring and then breathes slowly, its
/// colours flowing as in the chat's thinking orb. It draws at the display's
/// rate while it opens and at the chat orb's pace (OrbPace) after, holds
/// the icon's still frame with Reduce Motion or when the phone is
/// critically hot, and stops drawing while it is off the screen or the app
/// is not active.
private struct WelcomeOrb: View {
    /// The square drawn in; the light is 0.46 of it across (the shader's
    /// light at full size), the rest is the colours' spill around it.
    static let canvas: CGFloat = 280
    /// From the light's edge to the canvas's.
    static let margin: CGFloat = canvas / 2 * (1 - 0.654 * 12 / 17)
    static let opening: TimeInterval = 1.4
    let still: Bool
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.scenePhase) private var scenePhase
    /// When the shader is ready, so the light opens from its start.
    @State private var started: Date?
    @State private var pace = OrbPace.current
    @State private var onScreen = true
    @State private var opening = true

    var body: some View {
        Group {
            if let started {
                if still || pace == .still {
                    light(at: 0, size: 1)
                } else {
                    TimelineView(.animation(minimumInterval: opening ? nil : pace.interval,
                                            paused: !(onScreen && scenePhase == .active))) { context in
                        let time = context.date.timeIntervalSince(started)
                        light(at: time, size: Self.size(at: time)).opacity(Self.opacity(at: time))
                    }
                }
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .task {
            // Shaders otherwise compile on first use, and the light would
            // show part-way open (AuroraOrbView.prepare).
            try? await ShaderLibrary.auroraWelcomeOrb(.float2(Self.canvas, Self.canvas), .float(0), .float(0), .float(1))
                .compile(as: .shapeStyle)
            started = .now
            do { try await Task.sleep(for: .seconds(Self.opening)) } catch { return }
            opening = false
        }
    }

    /// A critically damped spring from 30% to the full size, then a slow
    /// breath of 4%, full to begin with, so the one runs into the other.
    static func size(at time: TimeInterval) -> Double {
        let spring = 1 - (1 + 5 * time) * exp(-5 * time)
        let breath = 0.98 + 0.02 * cos(2 * Double.pi * time / 6)
        return (0.3 + 0.7 * spring) * breath
    }

    static func opacity(at time: TimeInterval) -> Double {
        let share = min(max(time / 0.6, 0), 1)
        return share * share * (3 - 2 * share)
    }

    private func light(at time: TimeInterval, size: Double) -> some View {
        let dark: Float = colorScheme == .dark ? 1 : 0
        return Rectangle().fill(ShaderLibrary.auroraWelcomeOrb(.float2(Self.canvas, Self.canvas), .float(Float(time)),
                                                               .float(dark), .float(Float(size))))
    }
}

/// 「Fielua」 in the sidebar's serif, each letter coming into focus as it
/// rises into place, in the replies' rainbow (ReplyRevealStyle's colours,
/// red to blue across the word), which gives way to the text's own colour.
/// Plain with Reduce Motion, as the replies.
private struct WelcomeWordmark: View {
    static let begin: TimeInterval = 0.5
    static let spacing: TimeInterval = 0.085
    static let fade: TimeInterval = 0.7
    static let tint: TimeInterval = 1.6
    static let letters = 6
    /// When the last letter is in its own colour.
    static var end: TimeInterval { begin + spacing * Double(letters - 1) + max(fade, tint) }
    let still: Bool
    @Environment(\.colorScheme) private var colorScheme
    @State private var started = Date()
    @State private var settled = false

    var body: some View {
        let word = Text(verbatim: "Fielua").font(.system(size: 46, weight: .semibold, design: .serif))
        Group {
            if still || settled {
                word
            } else {
                TimelineView(.animation) { context in
                    word.textRenderer(WordmarkReveal(age: context.date.timeIntervalSince(started),
                                                     dark: colorScheme == .dark))
                }
            }
        }
        .accessibilityAddTraits(.isHeader)
        .task {
            do { try await Task.sleep(for: .seconds(Self.end)) } catch { return }
            settled = true
        }
    }
}

private struct WordmarkReveal: TextRenderer {
    let age: TimeInterval
    let dark: Bool

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        var count = 0
        for line in layout { for run in line { count += run.count } }
        let stops = dark ? ReplyRevealStyle.darkStops : ReplyRevealStyle.lightStops
        var index = 0
        for line in layout {
            for run in line {
                for slice in run {
                    defer { index += 1 }
                    let own = age - (WelcomeWordmark.begin + Double(index) * WelcomeWordmark.spacing)
                    guard own > 0 else { continue }
                    var copy = context
                    let progress = min(own / WelcomeWordmark.fade, 1)
                    let opacity = progress * progress * (3 - 2 * progress)
                    if progress < 1 {
                        let remaining = 1 - progress
                        copy.opacity *= opacity
                        copy.translateBy(x: 0, y: 6 * remaining * remaining)
                        copy.addFilter(.blur(radius: 5 * remaining))
                    }
                    // Its place on the rainbow by its place in the word; the
                    // colour holds, then gives way.
                    let position = count > 1 ? Double(index) / Double(count - 1) * Double(stops.count - 1) : 0
                    let at = min(Int(position), stops.count - 2)
                    let mix = position - Double(at)
                    let from = stops[at], to = stops[at + 1]
                    let way = min(own / WelcomeWordmark.tint, 1)
                    let giving = max((way - 0.35) / 0.65, 0)
                    var share = 1 - giving * giving * (3 - 2 * giving)
                    share = ReplyRevealStyle.fadingShare(share, opacity: opacity, dark: dark)
                    if share > 0.01 {
                        copy.addFilter(.colorMatrix(ReplyRevealStyle.filter(ReplyRevealStyle.Tint(
                            red: from.red + (to.red - from.red) * mix,
                            green: from.green + (to.green - from.green) * mix,
                            blue: from.blue + (to.blue - from.blue) * mix, share: share))))
                    }
                    copy.draw(slice)
                }
            }
        }
    }
}

// MARK: - モデルを選択

private struct OnboardingModelPage: View {
    @EnvironmentObject private var model: ModelStore
    let models: [ModelSpec]
    let device: DeviceCapacity
    let recommended: ModelSpec?
    let selected: ModelSpec
    let choose: (ModelSpec) -> Void
    let onContinue: () -> Void

    private var fit: ModelFit { ModelRecommendation.fit(selected, device: device) }
    private var saved: Bool { model.isInstalled(selected) }

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                OnboardingHeader(title: "モデルを選択", detail: "あとから設定で変更できます。")
                VStack(spacing: 0) {
                    ForEach(Array(models.enumerated()), id: \.element.id) { index, spec in
                        if index > 0 { Divider().padding(.leading, 68) }
                        row(spec)
                    }
                }
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                notes
            }
            .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-model-list")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaBar(edge: .bottom) {
            OnboardingButton("続ける", id: "onboarding-model-continue",
                             enabled: !model.isRestoring && (saved || fit.hasDiskSpace), action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .onAppear { model.refreshInstalled() }
    }

    private func row(_ spec: ModelSpec) -> some View {
        let chosen = spec.id == selected.id
        let isRecommended = spec.id == recommended?.id
        return Button {
            guard !chosen else { return }
            withAnimation(.smooth(duration: 0.25)) { choose(spec) }
        } label: {
            HStack(spacing: 14) {
                ModelMark(model: spec, size: 38)
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        Text(spec.name).font(.headline)
                        if isRecommended {
                            Text("おすすめ").font(.caption.weight(.semibold)).foregroundStyle(Theme.accent)
                                .padding(.horizontal, 8).padding(.vertical, 2)
                                .background(Theme.accent.opacity(0.12), in: Capsule())
                        }
                    }
                    Text(detail(spec)).font(.subheadline).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                    if model.isDownloading(spec) {
                        ProgressView(value: model.progress(for: spec)).tint(Theme.accent).padding(.top, 2)
                    }
                }
                Spacer(minLength: 8)
                OnboardingCheck(on: chosen)
            }
            .padding(.horizontal, 16).padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .sensoryFeedback(.selection, trigger: chosen) { _, now in now }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(isRecommended ? "\(spec.name)、おすすめ" : spec.name)
        .accessibilityValue(detail(spec))
        .accessibilityAddTraits(chosen ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("onboarding-model-\(spec.id)")
    }

    /// The size and, when there is one, what the phone has of it.
    private func detail(_ spec: ModelSpec) -> String {
        if model.isInstalled(spec) { return "\(spec.sizeLabel) · 保存済み" }
        if model.isDownloading(spec) {
            let percent = Int((model.progress(for: spec) * 100).rounded(.down))
            // Short enough for one line beside the name and the check.
            switch model.downloadWait(for: spec) {
            case nil: return "\(spec.sizeLabel) · ダウンロード中 \(percent)%"
            case .network: return "\(spec.sizeLabel) · 接続待ち \(percent)%"
            default: return "\(spec.sizeLabel) · Wi-Fi待ち \(percent)%"
            }
        }
        if model.isWorking(on: spec) { return "\(spec.sizeLabel) · 確認しています" }
        return spec.sizeLabel
    }

    @ViewBuilder private var notes: some View {
        if fit.memoryIsTight {
            Label("このモデルはメモリの負荷が高く、返信が遅くなったり終了する場合があります。軽いモデルも選べます。", systemImage: "memorychip")
                .font(.footnote).foregroundStyle(.orange)
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityIdentifier("onboarding-memory-note")
        }
        if !saved && !fit.hasDiskSpace {
            Label("空き容量が足りません。モデルのサイズに加えて1 GBの空きが必要です。", systemImage: "externaldrive.badge.exclamationmark")
                .font(.footnote).foregroundStyle(.orange)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        // On cellular only, a download waits for Wi-Fi unless this is on
        // (the same switch as in モデル管理).
        if !saved && !model.network.hasWiFi && model.network.isOnline {
            VStack(alignment: .leading, spacing: 8) {
                Toggle("モバイル通信でもダウンロード", isOn: $model.allowsCellular)
                    .font(.subheadline.weight(.semibold))
                    .accessibilityIdentifier("onboarding-download-cellular-toggle")
                Text("オフのままだと、Wi-Fiにつながってからダウンロードします（\(selected.name) \(selected.sizeLabel)）。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(16)
            .background(Theme.card, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
    }
}

// MARK: - キーボードスタイル

/// 設定 › キーボードと入力's two phones (ComposerStylePicker) as they are there,
/// in the same card, bound to the same setting: the chat follows the choice
/// at once. They start playing once the page has slid in.
private struct OnboardingKeyboardPage: View {
    @Binding var style: ComposerStyle
    let onContinue: () -> Void
    @State private var inView = false

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                OnboardingHeader(title: "キーボードスタイル", detail: "あとから設定で変更できます。")
                VStack(spacing: 14) {
                    ComposerStylePicker(selection: $style)
                    Text(style.previewCaption)
                        .font(.subheadline).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2, reservesSpace: true)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(18)
                .frame(maxWidth: .infinity)
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                .environment(\.settingsPageInView, inView)
            }
            .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-keyboard")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaBar(edge: .bottom) {
            OnboardingButton("続ける", id: "onboarding-keyboard-continue", action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .task {
            // After the push, so the slide has the frames to itself.
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            inView = true
        }
        .onDisappear { inView = false }
    }
}

// MARK: - 準備完了

private struct OnboardingReadyPage: View {
    @EnvironmentObject private var model: ModelStore
    let spec: ModelSpec
    let style: ComposerStyle
    let failure: String?
    let retry: () -> Void
    let onStart: () -> Void

    private enum Phase { case ready, downloading, preparing, failed, waiting }
    private var phase: Phase {
        if model.isInstalled(spec) { return .ready }
        if model.isDownloading(spec) { return .downloading }
        if model.isRestoring || model.isWorking(on: spec) { return .preparing }
        return failure != nil ? .failed : .waiting
    }

    var body: some View {
        let phase = phase
        ScrollView {
            VStack(spacing: 28) {
                Image(systemName: symbol(phase))
                    .font(.system(size: 64, weight: .regular))
                    .foregroundStyle(color(phase))
                    .contentTransition(.symbolEffect(.replace))
                    .frame(height: 76)
                    .padding(.top, 12)
                    .accessibilityHidden(true)
                OnboardingHeader(title: title(phase), detail: detail(phase))
                VStack(spacing: 0) {
                    modelRow(phase)
                    Divider().padding(.leading, 68)
                    HStack(spacing: 14) {
                        Image(systemName: "keyboard").font(.system(size: 20)).foregroundStyle(.secondary)
                            .frame(width: 38, height: 38)
                        // Laid out like the model row: the pair is too wide for one line.
                        VStack(alignment: .leading, spacing: 3) {
                            Text("キーボードスタイル").font(.headline)
                            Text(style.title).font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                    }
                    .padding(.horizontal, 16).padding(.vertical, 14)
                    .accessibilityElement(children: .combine)
                }
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .padding(.horizontal, 24).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
            .animation(.smooth(duration: 0.35), value: phase)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-ready")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.success, trigger: phase == .ready) { was, now in !was && now }
        .safeAreaBar(edge: .bottom) {
            VStack(spacing: 14) {
                switch phase {
                case .failed:
                    OnboardingButton("もう一度試す", id: "onboarding-ready-retry", action: retry)
                case .waiting:
                    OnboardingButton("ダウンロード", id: "onboarding-ready-retry", action: retry)
                default:
                    OnboardingButton("はじめる", id: "onboarding-ready-start", enabled: phase == .ready, action: onStart)
                }
                if phase != .ready {
                    // The chat shows the model's state and keeps the
                    // download going.
                    Button("チャットを先に開く", action: onStart)
                        .font(.subheadline)
                        .accessibilityIdentifier("onboarding-ready-later")
                }
            }
            .padding(.horizontal, 24).padding(.bottom, 12)
        }
    }

    private func modelRow(_ phase: Phase) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                ModelMark(model: spec, size: 38)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text(status(phase)).font(.subheadline).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                        .accessibilityIdentifier("onboarding-ready-status")
                }
                Spacer(minLength: 8)
                if phase == .preparing { ProgressView() }
            }
            if phase == .downloading {
                ProgressView(value: model.progress(for: spec)).tint(Theme.accent)
                if let wait = model.downloadWait(for: spec),
                   let hint = wait.hint(received: model.progress(for: spec) >= 0.01, switchOn: model.allowsCellular) {
                    Label(hint, systemImage: wait == .cellularDenied ? "antenna.radiowaves.left.and.right.slash" : "wifi.exclamationmark")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 14)
        .accessibilityElement(children: .combine)
    }

    private func status(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "保存済み · オフラインで使えます"
        case .downloading:
            let percent = Int((model.progress(for: spec) * 100).rounded(.down))
            return model.downloadWait(for: spec) == nil ? "ダウンロード中 · \(percent)%" : "通信を待っています · \(percent)%"
        case .preparing: return model.isRestoring ? "保存状態を確認しています" : "ファイルを確認しています"
        case .failed: return "ダウンロードできませんでした"
        case .waiting: return "\(spec.sizeLabel) · まだダウンロードしていません"
        }
    }

    private func title(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "準備ができました"
        case .downloading: return "ダウンロードしています"
        case .preparing: return "準備しています"
        case .failed: return "問題が発生しました"
        case .waiting: return "モデルをダウンロード"
        }
    }

    private func detail(_ phase: Phase) -> String? {
        switch phase {
        case .ready: return nil
        case .downloading, .preparing: return "ほかのアプリに切り替えても続きます。"
        case .failed: return failure
        case .waiting: return "\(spec.name)（\(spec.sizeLabel)）を保存すると、会話を始められます。"
        }
    }

    private func symbol(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.circle"
        default: return "arrow.down.circle"
        }
    }

    private func color(_ phase: Phase) -> Color {
        switch phase {
        case .ready: return .green
        case .failed: return .orange
        default: return Theme.accent
        }
    }
}

// MARK: - Parts

/// A page's title and its one line, centred, as in iOS's setup.
private struct OnboardingHeader: View {
    let title: String
    let detail: String?

    var body: some View {
        VStack(spacing: 10) {
            Text(title).font(.largeTitle.bold())
                .multilineTextAlignment(.center)
                .accessibilityAddTraits(.isHeader)
            if let detail {
                Text(detail).font(.body).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .fixedSize(horizontal: false, vertical: true)
    }
}

/// The step's one action: the system's prominent glass, full width.
private struct OnboardingButton: View {
    let title: String
    let id: String
    var enabled = true
    let action: () -> Void

    init(_ title: String, id: String, enabled: Bool = true, action: @escaping () -> Void) {
        self.title = title; self.id = id; self.enabled = enabled; self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title).font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
        }
        .buttonStyle(.glassProminent)
        .buttonBorderShape(.capsule)
        .controlSize(.large)
        .disabled(!enabled)
        .frame(maxWidth: 480)
        .accessibilityIdentifier(id)
    }
}

/// The choice mark of ComposerStylePicker: a filled check on the chosen
/// row, an empty ring on the others.
private struct OnboardingCheck: View {
    let on: Bool
    var body: some View {
        Image(systemName: on ? "checkmark.circle.fill" : "circle")
            .font(.system(size: 22))
            .symbolRenderingMode(.palette)
            .foregroundStyle(on ? Color.white : Color(uiColor: .tertiaryLabel), Theme.accent)
            .contentTransition(.symbolEffect(.replace))
            .accessibilityHidden(true)
    }
}
