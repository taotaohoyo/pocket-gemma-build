import SwiftUI
import PocketCore

/// 初回起動 (user, 2026-10-24 21:23 UTC, 「Fielua — 初回起動オンボーディング実装
/// 指示書」): the welcome of 1.1.0 (157) and before, one screen of models,
/// becomes four steps, as iOS's own setup. ようこそ is the one showy screen:
/// the orb of light blooming out of a small light, felt in the hand as it
/// grows (AuroraBloom, 1.1.0 (178)), and the wordmark appearing letter by
/// letter in the rainbow of the replies as it opens. Then
/// plain pages: the model (ModelStore's list, downloads and choice), the
/// keyboard style (設定 › キーボードと入力's own phones, ComposerStylePicker)
/// and 準備完了, which waits for the model and opens the chat. The model's
/// download runs on while the next pages are read. Each step reached is
/// saved, so a launch after Fielua was closed midway goes on from there;
/// the model and keyboard choices are the settings themselves, saved as
/// they are made. No permission is asked for on the way.
enum OnboardingStep: Int, Hashable, CaseIterable {
    case welcome, model, keyboard, ready
}

enum Onboarding {
    /// Which setup this is (user, 2026-10-25 12:04 UTC, 「スタートアップの全
    /// ユーザー向け初回表示制御」): every phone shows it once, a new one and
    /// one updated from 1.1.0 (179) or before alike, and once it has been
    /// finished no later build shows it again, whatever its number. Only a
    /// release the user asks to show the setup to everyone again gives it
    /// a new name here; every phone then shows that edition once too.
    static let edition: String = {
        #if POCKET_PREVIEW
        // UI tests: a later release with a new edition.
        if let flag = ProcessInfo.processInfo.arguments.first(where: { $0.hasPrefix("--startup-edition=") }) {
            return String(flag.dropFirst("--startup-edition=".count))
        }
        #endif
        return "2026-10-aurora-bloom"
    }()
    /// The edition finished on this phone. UserDefaults keeps it through
    /// every update; only deleting Fielua forgets it.
    static let finishedKey = "onboarding-finished-edition"
    /// The step reached; absent before the first step on and after the end.
    static let stepKey = "onboarding-step-v1"
    /// The model whose download the setup started, so choosing another
    /// one on the way stops it.
    static let downloadKey = "onboarding-download-v1"
    /// Up to 1.1.0 (180): the setup finished for good (or skipped on a
    /// phone that had chats or a saved model), and 「初回起動扱いにする」's
    /// request. Neither counts for an edition.
    private static let oldKeys = ["model-startup-completed-v1", "model-startup-again-v1"]

    /// Whether this phone has yet to finish this edition; a setup closed
    /// midway goes on from its step.
    static var isDue: Bool { UserDefaults.standard.string(forKey: finishedKey) != edition }

    /// At launch, once.
    static func dueAtLaunch() -> Bool {
        for key in oldKeys { UserDefaults.standard.removeObject(forKey: key) }
        return isDue
    }

    /// 準備完了's はじめる: this edition is done on this phone, for good.
    static func finish() {
        UserDefaults.standard.set(edition, forKey: finishedKey)
        clear()
    }

    /// 開発者設定's 「初回起動扱いにする」: from the first step at the next
    /// launch.
    static func showAgain() {
        UserDefaults.standard.removeObject(forKey: finishedKey)
        clear()
    }
    /// The phone's memory.
    static var memory: DeviceCapacity {
        #if POCKET_PREVIEW
        // UI tests' phones: --memory-gb=N, all of it there to use.
        if let flag = ProcessInfo.processInfo.arguments.first(where: { $0.hasPrefix("--memory-gb=") }),
           let gigabytes = Double(flag.dropFirst("--memory-gb=".count)) {
            return DeviceCapacity(memoryBytes: UInt64(gigabytes * 1_000_000_000), freeDiskBytes: 0,
                                  processorCount: ProcessInfo.processInfo.processorCount, isPad: false)
        }
        #endif
        return DeviceOverview.memoryCapacity
    }
    /// The free space; it can keep the thread it is read on waiting.
    static var freeDisk: Int64 {
        #if POCKET_PREVIEW
        // UI tests' phone with room for E2B only.
        if ProcessInfo.processInfo.arguments.contains("--low-disk") { return 4_000_000_000 }
        #endif
        return DeviceOverview.freeDiskBytes
    }
    static func clear() {
        UserDefaults.standard.removeObject(forKey: stepKey)
        UserDefaults.standard.removeObject(forKey: downloadKey)
    }
}

struct OnboardingView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    private let onFinish: () -> Void
    @State private var path: [OnboardingStep]
    /// The model chosen on this setup; nil until a row is tapped, when the
    /// model already in use, saved or recommended is shown chosen.
    @State private var choice: String?
    /// Memory once, as the setup opens: what is free moves while a model
    /// downloads, and the recommendation and its note must not move with
    /// it. Free space once iOS has answered (off the main thread: reading
    /// it can keep the launch waiting).
    @State private var memory = Onboarding.memory
    @State private var freeDisk: Int64?
    /// The last error of a download, shown on 準備完了.
    @State private var failure: String?

    init(onFinish: @escaping () -> Void) {
        self.onFinish = onFinish
        let reached = OnboardingStep(rawValue: UserDefaults.standard.integer(forKey: Onboarding.stepKey)) ?? .welcome
        _path = State(initialValue: Array(OnboardingStep.allCases.dropFirst().prefix(reached.rawValue)))
    }

    /// Until the free space is known, every model is taken to fit.
    private var device: DeviceCapacity {
        DeviceCapacity(memoryBytes: memory.memoryBytes, freeDiskBytes: freeDisk ?? Int64.max / 4,
                       processorCount: memory.processorCount, isPad: memory.isPad,
                       availableMemoryBytes: memory.availableMemoryBytes)
    }
    /// Gemma, and the model in use when it is one of 開発者設定's and is
    /// saved: a phone set up before, shown the setup after an update,
    /// keeps the model it uses.
    private var models: [ModelSpec] {
        let gemma = ModelSpec.visibleCatalog(developer: false), current = model.selectedModel
        guard !gemma.contains(current), model.isInstalled(current) || model.isWorking(on: current) else { return gemma }
        return gemma + [current]
    }
    private var recommended: ModelSpec? {
        let gemma = ModelSpec.visibleCatalog(developer: false)
        return ModelRecommendation.recommended(for: device, installedIDs: Set(gemma.filter(model.isInstalled).map(\.id)),
                                               includeDeveloperModels: false)
    }
    /// What is chosen: this setup's choice, else the model in use when it
    /// is saved, on its way or was chosen before (a setup started again),
    /// else a saved one, else the one for this device.
    private var selected: ModelSpec {
        if let choice, let spec = ModelSpec.find(choice) { return spec }
        let current = model.selectedModel
        let choseBefore = UserDefaults.standard.string(forKey: "selectedModelID") != nil
        if models.contains(current), model.isInstalled(current) || model.isWorking(on: current) || choseBefore {
            return current
        }
        return models.first(where: model.isInstalled) ?? recommended ?? .e2b
    }

    var body: some View {
        NavigationStack(path: $path) {
            OnboardingWelcome { path.append(.model) }
                .toolbar(.hidden, for: .navigationBar)
                .navigationDestination(for: OnboardingStep.self) { step in page(step) }
        }
        .onChange(of: path) { _, path in
            UserDefaults.standard.set((path.last ?? .welcome).rawValue, forKey: Onboarding.stepKey)
        }
        .task {
            freeDisk = await Task.detached(priority: .userInitiated) { Onboarding.freeDisk }.value
        }
        // Only a download that cannot start comes up as an alert, where it
        // was asked for; a later failure waits on 準備完了 with its retry.
        .onChange(of: model.error) { _, error in
            guard let error else { return }
            failure = error
            if path.last != .model { model.error = nil }
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(
            get: { model.error != nil && path.last == .model }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    @ViewBuilder private func page(_ step: OnboardingStep) -> some View {
        switch step {
        case .welcome, .model:
            OnboardingModelPage(models: models, device: device, recommended: recommended, selected: selected,
                                choose: { choice = $0.id }, onContinue: confirmModel)
        case .keyboard:
            OnboardingKeyboardPage(style: $style) { path.append(.ready) }
        case .ready:
            OnboardingReadyPage(spec: selected, style: style, failure: failure,
                                retry: retry, onStart: finish)
        }
    }

    private func confirmModel() {
        let spec = selected
        model.select(spec)
        // A download this setup started for a model no longer chosen stops.
        if let started = ModelSpec.find(UserDefaults.standard.string(forKey: Onboarding.downloadKey)),
           started.id != spec.id, model.isDownloading(started) {
            model.cancelDownload(started)
        }
        if !model.isInstalled(spec) && !model.isWorking(on: spec) {
            failure = nil
            model.download(spec)
            guard model.error == nil else { return }
            UserDefaults.standard.set(spec.id, forKey: Onboarding.downloadKey)
        }
        choice = spec.id
        path.append(.keyboard)
    }

    private func retry() {
        failure = nil
        model.error = nil
        model.download(selected)
        UserDefaults.standard.set(selected.id, forKey: Onboarding.downloadKey)
    }

    private func finish() {
        model.select(selected)
        chats.newChat(modelID: selected.id)
        Onboarding.finish()
        onFinish()
    }
}

// MARK: - ようこそ

private struct OnboardingWelcome: View {
    let onContinue: () -> Void
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.scenePhase) private var scenePhase
    /// The light's first frame: Aurora Bloom's timeline counts from it.
    @State private var start: Date?
    @State private var shown = false
    @State private var haptics = BloomHaptics()
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 0)
            // The canvas holds the light's spill around it: the wordmark
            // sits 28pt under the light itself.
            WelcomeOrb(still: reduceMotion, start: start)
                .padding(.bottom, 28 - WelcomeOrb.margin)
            WelcomeWordmark(still: reduceMotion, start: start)
            Text("あなたの\(DeviceOverview.name)で、あなたの会話を。")
                .font(.body).foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.top, 10)
                .opacity(shown ? 1 : 0)
            Spacer(minLength: 0)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .safeAreaBar(edge: .bottom) {
            // There from the first frame: nothing has to be waited for, and
            // what the haptics have left stops with it.
            OnboardingButton("続ける", id: "onboarding-welcome-continue") {
                haptics.stop("continue")
                onContinue()
            }
            .padding(.horizontal, 24).padding(.bottom, 12)
        }
        #if POCKET_PREVIEW
        .overlay(alignment: .topLeading) {
            if ProcessInfo.processInfo.arguments.contains("--haptics-trace") {
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityElement()
                    .accessibilityIdentifier("welcome-haptics-trace")
                    .accessibilityLabel(haptics.trace)
            }
        }
        #endif
        .task(id: scenePhase == .active) {
            // Once, when Fielua is in front: back from モデル the light is
            // as it was, and the haptics do not play again.
            guard start == nil, scenePhase == .active else { return }
            haptics.prepare()
            await WelcomeOrb.prepare()
            #if POCKET_PREVIEW
            await AuroraBloom.previewDelay()
            #endif
            guard !Task.isCancelled, scenePhase == .active else { return }
            start = .now
            // The light is there at once with Reduce Motion, and when the
            // phone is critically hot (OrbPace): one soft tap.
            haptics.play(reduceMotion || OrbPace.current == .still ? .still : .bloom)
            if reduceMotion {
                shown = true
            } else {
                withAnimation(.easeOut(duration: 0.7).delay(AuroraBloom.span(AuroraBloom.caption))) { shown = true }
            }
        }
        .onDisappear { haptics.stop("left") }
        .onChange(of: scenePhase) { _, phase in
            if start != nil && phase != .active { haptics.stop("inactive") }
        }
    }
}

/// The app icon's orb of light (AuroraOrbShader's auroraWelcomeOrb: the
/// chat's light with an outline a point wide at any size), large. It
/// blooms (AuroraBloom): born a small light, it grows as its colours flow
/// faster, opens to its size as its glow spreads a little, and breathes
/// slowly after, its colours flowing as in the chat's thinking orb. It
/// draws at the display's rate while it blooms and at the chat orb's pace
/// (OrbPace) after, holds the icon's still frame with Reduce Motion or when
/// the phone is critically hot, and stops drawing while it is off the
/// screen or the app is not active.
private struct WelcomeOrb: View {
    /// The square drawn in; the light is 0.46 of it across (the shader's
    /// light at full size), the rest is the colours' spill around it.
    static let canvas: CGFloat = 280
    /// From the light's edge to the canvas's.
    static let margin: CGFloat = canvas / 2 * (1 - 0.654 * 12 / 17)
    let still: Bool
    /// Aurora Bloom's start; no light before it.
    let start: Date?
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.scenePhase) private var scenePhase
    @State private var pace = OrbPace.current
    @State private var onScreen = true
    @State private var blooming = true

    var body: some View {
        // A ZStack, not a Group: a Group's modifiers go to its views, and
        // before the light starts there is none to hold the frame or run
        // the task (1.1.0 (173) showed no light at all).
        ZStack {
            if let start {
                if still || pace == .still {
                    light(at: 0, size: 1, glow: 1)
                } else {
                    TimelineView(.animation(minimumInterval: blooming ? nil : pace.interval,
                                            paused: !(onScreen && scenePhase == .active))) { context in
                        let time = AuroraBloom.age(since: start, at: context.date)
                        light(at: AuroraBloom.flow(at: time), size: AuroraBloom.size(at: time),
                              glow: AuroraBloom.glow(at: time))
                            .opacity(AuroraBloom.opacity(at: time))
                    }
                }
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .onReceive(OrbPace.changes) { _ in pace = .current }
        .task(id: start) {
            // The display's rate until the glow has nearly settled.
            guard let start else { return }
            let left = start.addingTimeInterval(AuroraBloom.span(AuroraBloom.duration + 0.6)).timeIntervalSinceNow
            if left > 0 {
                do { try await Task.sleep(for: .seconds(left)) } catch { return }
            }
            blooming = false
        }
    }

    /// Shaders otherwise compile on first use, and the light would start
    /// part-way grown (AuroraOrbView.prepare).
    static func prepare() async {
        try? await ShaderLibrary.auroraWelcomeOrb(.float2(canvas, canvas), .float(0), .float(0), .float(1), .float(1))
            .compile(as: .shapeStyle)
    }

    private func light(at time: Double, size: Double, glow: Double) -> some View {
        let dark: Float = colorScheme == .dark ? 1 : 0
        return Rectangle().fill(ShaderLibrary.auroraWelcomeOrb(.float2(Self.canvas, Self.canvas), .float(Float(time)),
                                                               .float(dark), .float(Float(size)), .float(Float(glow))))
    }
}

/// 「Fielua」 in the sidebar's serif, each letter coming into focus as it
/// rises into place, in the replies' rainbow (ReplyRevealStyle's colours,
/// red to blue across the word), which gives way to the text's own colour.
/// It begins as the light is nearly grown (AuroraBloom.wordmark). Plain
/// with Reduce Motion, as the replies.
private struct WelcomeWordmark: View {
    static var begin: TimeInterval { AuroraBloom.wordmark }
    static let spacing: TimeInterval = 0.085
    static let fade: TimeInterval = 0.7
    static let tint: TimeInterval = 1.6
    static let letters = 6
    /// When the last letter is in its own colour.
    static var end: TimeInterval { begin + spacing * Double(letters - 1) + max(fade, tint) }
    let still: Bool
    /// Aurora Bloom's start; the word keeps its place, unseen, until then.
    let start: Date?
    @Environment(\.colorScheme) private var colorScheme
    @State private var settled = false
    @State private var onScreen = true

    var body: some View {
        let word = Text(verbatim: "Fielua").font(.system(size: 46, weight: .semibold, design: .serif))
        ZStack {
            if still || settled {
                word
            } else if let start {
                TimelineView(.animation(minimumInterval: nil, paused: !onScreen)) { context in
                    word.textRenderer(WordmarkReveal(age: AuroraBloom.age(since: start, at: context.date),
                                                     dark: colorScheme == .dark))
                }
            } else {
                // Clear, so VoiceOver has the heading from the start.
                word.foregroundStyle(.clear)
            }
        }
        .accessibilityAddTraits(.isHeader)
        .onAppear { onScreen = true }
        .onDisappear { onScreen = false }
        .task(id: start) {
            guard let start else { return }
            let left = start.addingTimeInterval(AuroraBloom.span(Self.end)).timeIntervalSinceNow
            if left > 0 {
                do { try await Task.sleep(for: .seconds(left)) } catch { return }
            }
            settled = true
        }
    }
}

private struct WordmarkReveal: TextRenderer {
    let age: TimeInterval
    let dark: Bool

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        var count = 0
        for line in layout { for run in line { count += run.count } }
        let stops = dark ? ReplyRevealStyle.darkStops : ReplyRevealStyle.lightStops
        var index = 0
        for line in layout {
            for run in line {
                for slice in run {
                    defer { index += 1 }
                    let own = age - (WelcomeWordmark.begin + Double(index) * WelcomeWordmark.spacing)
                    guard own > 0 else { continue }
                    var copy = context
                    let progress = min(own / WelcomeWordmark.fade, 1)
                    let opacity = progress * progress * (3 - 2 * progress)
                    if progress < 1 {
                        let remaining = 1 - progress
                        copy.opacity *= opacity
                        copy.translateBy(x: 0, y: 6 * remaining * remaining)
                        copy.addFilter(.blur(radius: 5 * remaining))
                    }
                    // Its place on the rainbow by its place in the word; the
                    // colour holds, then gives way.
                    let position = count > 1 ? Double(index) / Double(count - 1) * Double(stops.count - 1) : 0
                    let at = min(Int(position), stops.count - 2)
                    let mix = position - Double(at)
                    let from = stops[at], to = stops[at + 1]
                    let way = min(own / WelcomeWordmark.tint, 1)
                    let giving = max((way - 0.35) / 0.65, 0)
                    var share = 1 - giving * giving * (3 - 2 * giving)
                    share = ReplyRevealStyle.fadingShare(share, opacity: opacity, dark: dark)
                    if share > 0.01 {
                        copy.addFilter(.colorMatrix(ReplyRevealStyle.filter(ReplyRevealStyle.Tint(
                            red: from.red + (to.red - from.red) * mix,
                            green: from.green + (to.green - from.green) * mix,
                            blue: from.blue + (to.blue - from.blue) * mix, share: share))))
                    }
                    copy.draw(slice)
                }
            }
        }
    }
}

// MARK: - モデルを選ぶ

private struct OnboardingModelPage: View {
    @EnvironmentObject private var model: ModelStore
    let models: [ModelSpec]
    let device: DeviceCapacity
    let recommended: ModelSpec?
    let selected: ModelSpec
    let choose: (ModelSpec) -> Void
    let onContinue: () -> Void

    private var fit: ModelFit { ModelRecommendation.fit(selected, device: device) }
    private var saved: Bool { model.isInstalled(selected) }

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                OnboardingHeader(title: "モデルを選ぶ", detail: "いつでも変更できます。")
                VStack(spacing: 0) {
                    ForEach(Array(models.enumerated()), id: \.element.id) { index, spec in
                        if index > 0 { Divider().padding(.leading, 68) }
                        row(spec)
                    }
                }
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                notes
            }
            .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-model-list")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaBar(edge: .bottom) {
            OnboardingButton("続ける", id: "onboarding-model-continue",
                             enabled: !model.isRestoring && (saved || fit.hasDiskSpace), action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .onAppear { model.refreshInstalled() }
    }

    private func row(_ spec: ModelSpec) -> some View {
        let chosen = spec.id == selected.id
        let isRecommended = spec.id == recommended?.id
        return Button {
            guard !chosen else { return }
            withAnimation(.smooth(duration: 0.25)) { choose(spec) }
        } label: {
            HStack(spacing: 14) {
                ModelMark(model: spec, size: 38)
                VStack(alignment: .leading, spacing: 4) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text(spec.name).font(.headline)
                        if isRecommended {
                            // There without standing out: a small tinted word.
                            Text("おすすめ").font(.caption2.weight(.semibold)).foregroundStyle(Theme.accent)
                                .padding(.horizontal, 7).padding(.vertical, 2)
                                .background(Theme.accent.opacity(0.1), in: Capsule())
                        }
                    }
                    Text(detail(spec)).font(.subheadline).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                    if model.isDownloading(spec) {
                        ProgressView(value: model.progress(for: spec)).tint(Theme.accent).padding(.top, 2)
                    }
                }
                Spacer(minLength: 8)
                OnboardingCheck(on: chosen)
            }
            .padding(.horizontal, 16).padding(.vertical, 14)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .sensoryFeedback(.selection, trigger: chosen) { _, now in now }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(isRecommended ? "\(spec.name)、おすすめ" : spec.name)
        .accessibilityValue(detail(spec))
        .accessibilityAddTraits(chosen ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("onboarding-model-\(spec.id)")
    }

    /// The size and, when there is one, what the phone has of it.
    private func detail(_ spec: ModelSpec) -> String {
        if model.isInstalled(spec) { return "\(spec.sizeLabel) · ダウンロード済み" }
        if model.isDownloading(spec) {
            let percent = Int((model.progress(for: spec) * 100).rounded(.down))
            // Short enough for one line beside the name and the check.
            switch model.downloadWait(for: spec) {
            case nil: return "\(spec.sizeLabel) · ダウンロード中 \(percent)%"
            case .network: return "\(spec.sizeLabel) · 接続待ち \(percent)%"
            default: return "\(spec.sizeLabel) · Wi-Fi待ち \(percent)%"
            }
        }
        if model.isWorking(on: spec) { return "\(spec.sizeLabel) · 確認しています" }
        return spec.sizeLabel
    }

    /// Only what stands in the way: the chosen model's memory, and the
    /// space its download needs (続ける waits for it). Quiet text; the
    /// small orange mark says it matters.
    @ViewBuilder private var notes: some View {
        if fit.memoryIsTight {
            note(memoryNote, systemImage: "memorychip", id: "onboarding-memory-note")
        }
        if !saved && !fit.hasDiskSpace {
            note("ダウンロードするには、あと\(shortfall)の空き容量が必要です。",
                 systemImage: "externaldrive.badge.exclamationmark", id: "onboarding-disk-note")
        }
        // On cellular only, a download waits for Wi-Fi unless this is on
        // (the same switch as in モデル管理).
        if !saved && !model.network.hasWiFi && model.network.isOnline {
            VStack(alignment: .leading, spacing: 8) {
                Toggle("モバイル通信でもダウンロード", isOn: $model.allowsCellular)
                    .font(.subheadline.weight(.semibold))
                    .accessibilityIdentifier("onboarding-download-cellular-toggle")
                Text("オフのときは、Wi-Fiにつながってからダウンロードします（\(selected.name) \(selected.sizeLabel)）。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(16)
            .background(Theme.card, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
    }

    /// A lighter model is named only when it has the memory to spare: the
    /// recommended one, when another is chosen. When no model has room,
    /// the recommended one is only the lightest, and none is offered.
    private var memoryNote: String {
        let risk = "この\(DeviceOverview.name)のメモリでは余裕がなく、返信が遅くなったり、アプリが終了したりすることがあります。"
        guard let recommended, recommended.id != selected.id,
              !ModelRecommendation.fit(recommended, device: device).memoryIsTight else { return risk }
        // The name on one line: "Gemma 4" and "E2B" are not split.
        return risk + "\(recommended.name.replacingOccurrences(of: " ", with: "\u{00A0}"))なら余裕があります。"
    }

    /// What the download still needs: the model and 1 GB more
    /// (ModelRecommendation), less what is free, rounded up.
    private var shortfall: String {
        let needed = max(selected.byteCount + 1_000_000_000 - device.freeDiskBytes, 0)
        return ByteCountFormatter.string(fromByteCount: (needed + 9_999_999) / 10_000_000 * 10_000_000,
                                         countStyle: .decimal)
    }

    private func note(_ text: String, systemImage: String, id: String) -> some View {
        Label {
            Text(text).foregroundStyle(.secondary)
        } icon: {
            Image(systemName: systemImage).foregroundStyle(.orange)
        }
        .font(.footnote)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text)
        .accessibilityIdentifier(id)
    }
}

// MARK: - 入力スタイル

/// 設定 › キーボードと入力's two phones (ComposerStylePicker) as they are there,
/// in the same card, bound to the same setting: the chat follows the choice
/// at once. They start playing once the page has slid in.
private struct OnboardingKeyboardPage: View {
    @Binding var style: ComposerStyle
    let onContinue: () -> Void
    @State private var inView = false

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                OnboardingHeader(title: "入力スタイルを選ぶ", detail: "いつでも変更できます。")
                VStack(spacing: 14) {
                    ComposerStylePicker(selection: $style)
                    Text(style.previewCaption)
                        .font(.subheadline).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2, reservesSpace: true)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(18)
                .frame(maxWidth: .infinity)
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                .environment(\.settingsPageInView, inView)
            }
            .padding(.horizontal, 24).padding(.top, 8).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-keyboard")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaBar(edge: .bottom) {
            OnboardingButton("続ける", id: "onboarding-keyboard-continue", action: onContinue)
                .padding(.horizontal, 24).padding(.bottom, 12)
        }
        .task {
            // After the push, so the slide has the frames to itself.
            do { try await Task.sleep(for: .milliseconds(450)) } catch { return }
            inView = true
        }
        .onDisappear { inView = false }
    }
}

// MARK: - 準備完了

private struct OnboardingReadyPage: View {
    @EnvironmentObject private var model: ModelStore
    let spec: ModelSpec
    let style: ComposerStyle
    let failure: String?
    let retry: () -> Void
    let onStart: () -> Void

    private enum Phase { case ready, downloading, preparing, failed, waiting }
    private var phase: Phase {
        if model.isInstalled(spec) { return .ready }
        if model.isDownloading(spec) { return .downloading }
        if model.isRestoring || model.isWorking(on: spec) { return .preparing }
        return failure != nil ? .failed : .waiting
    }

    var body: some View {
        let phase = phase
        ScrollView {
            VStack(spacing: 28) {
                // A thin line in the accent colour, as the rest of the setup.
                Image(systemName: symbol(phase))
                    .font(.system(size: 56, weight: .light))
                    .foregroundStyle(color(phase))
                    .contentTransition(.symbolEffect(.replace))
                    .frame(height: 76)
                    .padding(.top, 12)
                    .accessibilityHidden(true)
                OnboardingHeader(title: title(phase), detail: detail(phase))
                VStack(spacing: 0) {
                    modelRow(phase)
                    Divider().padding(.leading, 68)
                    HStack(spacing: 14) {
                        Image(systemName: "keyboard").font(.system(size: 20)).foregroundStyle(.secondary)
                            .frame(width: 38, height: 38)
                        // Laid out like the model row: the pair is too wide for one line.
                        VStack(alignment: .leading, spacing: 3) {
                            Text("入力スタイル").font(.headline)
                            Text(style.title).font(.subheadline).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                    }
                    .padding(.horizontal, 16).padding(.vertical, 14)
                    .accessibilityElement(children: .combine)
                }
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            }
            .padding(.horizontal, 24).padding(.bottom, 24)
            .frame(maxWidth: 560).frame(maxWidth: .infinity)
            .animation(.smooth(duration: 0.35), value: phase)
        }
        .scrollBounceBehavior(.basedOnSize)
        .accessibilityIdentifier("onboarding-ready")
        .background(Theme.canvas, ignoresSafeAreaEdges: .all)
        .navigationBarTitleDisplayMode(.inline)
        .sensoryFeedback(.success, trigger: phase == .ready) { was, now in !was && now }
        .safeAreaBar(edge: .bottom) {
            VStack(spacing: 14) {
                switch phase {
                case .failed:
                    OnboardingButton("もう一度試す", id: "onboarding-ready-retry", action: retry)
                case .waiting:
                    OnboardingButton("ダウンロード", id: "onboarding-ready-retry", action: retry)
                default:
                    OnboardingButton("はじめる", id: "onboarding-ready-start", enabled: phase == .ready, action: onStart)
                }
                if phase != .ready {
                    // The chat shows the model's state and keeps the
                    // download going.
                    Button("先にチャットを開く", action: onStart)
                        .font(.subheadline)
                        .accessibilityIdentifier("onboarding-ready-later")
                }
            }
            .padding(.horizontal, 24).padding(.bottom, 12)
        }
    }

    private func modelRow(_ phase: Phase) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                ModelMark(model: spec, size: 38)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text(status(phase)).font(.subheadline).foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                        .accessibilityIdentifier("onboarding-ready-status")
                }
                Spacer(minLength: 8)
                if phase == .preparing { ProgressView() }
            }
            if phase == .downloading {
                ProgressView(value: model.progress(for: spec)).tint(Theme.accent)
                if let wait = model.downloadWait(for: spec),
                   let hint = wait.hint(received: model.progress(for: spec) >= 0.01, switchOn: model.allowsCellular) {
                    Label(hint, systemImage: wait == .cellularDenied ? "antenna.radiowaves.left.and.right.slash" : "wifi.exclamationmark")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal, 16).padding(.vertical, 14)
        .accessibilityElement(children: .combine)
    }

    private func status(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "オフラインで利用できます"
        case .downloading:
            let percent = Int((model.progress(for: spec) * 100).rounded(.down))
            return model.downloadWait(for: spec) == nil ? "ダウンロード中 · \(percent)%" : "通信を待っています · \(percent)%"
        case .preparing: return model.isRestoring ? "モデルを確認しています" : "ファイルを確認しています"
        case .failed: return "ダウンロードできませんでした"
        case .waiting: return "\(spec.sizeLabel) · 未ダウンロード"
        }
    }

    private func title(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "準備が整いました"
        case .downloading: return "ダウンロードしています"
        case .preparing: return "準備しています"
        case .failed: return "問題が発生しました"
        case .waiting: return "モデルをダウンロード"
        }
    }

    private func detail(_ phase: Phase) -> String? {
        switch phase {
        case .ready: return nil
        case .downloading, .preparing: return "ほかのアプリに切り替えても続きます。"
        case .failed: return failure
        case .waiting: return "ダウンロードすると、会話を始められます。"
        }
    }

    private func symbol(_ phase: Phase) -> String {
        switch phase {
        case .ready: return "checkmark.circle"
        case .failed: return "exclamationmark.circle"
        default: return "arrow.down.circle"
        }
    }

    private func color(_ phase: Phase) -> Color {
        switch phase {
        case .failed: return .orange
        default: return Theme.accent
        }
    }
}

// MARK: - Parts

/// A page's title and its one line, centred, as in iOS's setup.
private struct OnboardingHeader: View {
    let title: String
    let detail: String?

    var body: some View {
        VStack(spacing: 10) {
            Text(title).font(.largeTitle.bold())
                .multilineTextAlignment(.center)
                .accessibilityAddTraits(.isHeader)
            if let detail {
                Text(detail).font(.body).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .fixedSize(horizontal: false, vertical: true)
    }
}

/// The step's one action: the system's prominent glass, full width.
private struct OnboardingButton: View {
    let title: String
    let id: String
    var enabled = true
    let action: () -> Void

    init(_ title: String, id: String, enabled: Bool = true, action: @escaping () -> Void) {
        self.title = title; self.id = id; self.enabled = enabled; self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title).font(.headline).frame(maxWidth: .infinity).padding(.vertical, 6)
        }
        .buttonStyle(.glassProminent)
        .buttonBorderShape(.capsule)
        .controlSize(.large)
        .disabled(!enabled)
        .frame(maxWidth: 480)
        .accessibilityIdentifier(id)
    }
}

/// The choice mark of ComposerStylePicker: a filled check on the chosen
/// row, an empty ring on the others.
private struct OnboardingCheck: View {
    let on: Bool
    var body: some View {
        Image(systemName: on ? "checkmark.circle.fill" : "circle")
            .font(.system(size: 22))
            .symbolRenderingMode(.palette)
            .foregroundStyle(on ? Color.white : Color(uiColor: .tertiaryLabel), Theme.accent)
            .contentTransition(.symbolEffect(.replace))
            .accessibilityHidden(true)
    }
}
