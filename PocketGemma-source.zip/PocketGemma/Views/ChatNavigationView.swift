import SwiftUI
import UIKit

/// The conversation is the app's one screen. Its history sits underneath
/// in a sidebar: a swipe right (or the header button) slides the
/// conversation aside to reveal it, following the finger, as ChatGPT does.
/// On an iPad's full width the header button shows the history beside the
/// conversation instead, and puts it away again: the conversation moves
/// over and stays in use (HistoryDock, 1.1.0 (226)), keeping its size and
/// its lines (1.1.0 (242)).
struct ChatNavigationView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.horizontalSizeClass) private var sizeClass
    @Environment(\.displayScale) private var displayScale
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    /// 0 with the conversation in place, 1 with the sidebar fully open.
    @State private var reveal: CGFloat = 0
    /// The sidebar and the slid panel's dressing (veil, corners, shadow)
    /// exist from the first frame of a slide until the conversation has
    /// settled back in place. Tied to `reveal > 0` instead, they were
    /// removed the moment a close began and faded out where the finger let
    /// go while the conversation slid on (1.0.51 on device).
    @State private var sidebarShown = false
    /// Where the last slide settled, for the haptic tap.
    @State private var settledOpen = false
    @State private var dragOrigin: CGFloat?
    @State private var containerWidth: CGFloat = 402
    /// A stable reference, so the conversation is not re-rendered on every
    /// frame of the slide just because a new closure was passed down.
    @State private var sidebar = HistorySidebar()
    /// 開発者設定's check of the slid panel's dressing (PanelDressing).
    @AppStorage(PanelDressing.key) private var dressing = PanelDressing.standard
    /// The history beside the conversation on an iPad, as the person left it.
    @State private var dockOpen = UserDefaults.standard.bool(forKey: HistoryDock.storageKey)
    /// `docked` for the sidebar's actions: they keep the copy of this view
    /// they were made in, with the size class it had then.
    @State private var dockedNow = false

    /// An iPad's full width (not Slide Over or a narrow window): the history
    /// stands beside the conversation instead of under it.
    private var docked: Bool { UIDevice.current.userInterfaceIdiom == .pad && sizeClass == .regular }
    private var dockWidth: CGFloat { HistoryDock.width(containerWidth) }
    /// The conversation's column beside the history, the same whether the
    /// history shows or not.
    private var dockLayout: HistoryDockLayout {
        HistoryDockLayout(width: dockWidth, column: HistoryDock.column(containerWidth))
    }
    /// Preview only (`--dock-keep-history`): the history put away stays
    /// built, slid out of sight, to measure what building it again costs
    /// each time it shows.
    private var keepsDockedHistory: Bool {
        #if POCKET_PREVIEW
        PreviewProbe.on("--dock-keep-history")
        #else
        false
        #endif
    }

    /// ChatGPT leaves 92pt of the conversation showing (measured on a
    /// 402pt-wide iPhone).
    private var sidebarWidth: CGFloat { min(max(containerWidth - 92, 260), 360) }

    var body: some View {
        ZStack(alignment: .leading) {
            // Only built while any of it shows: hidden under the
            // conversation, its scroll view still reached accessibility and
            // took the conversation's hit tests (UI check, 1.0.50).
            if !docked && sidebarShown {
                HistoryView()
                    .frame(width: sidebarWidth)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                    // The sidebar brightens as it is uncovered.
                    .opacity(0.4 + 0.6 * reveal)
            }
            ChatView()
                // The sidebar's search keyboard must not lift the composer
                // in the strip of conversation left showing.
                .ignoresSafeArea(!docked && reveal > 0 ? .keyboard : [], edges: .bottom)
                .allowsHitTesting(docked || reveal == 0)
                .accessibilityHidden(!docked && reveal > 0)
                .overlay {
                    if !docked && sidebarShown {
                        if dressing.dressesPanel {
                            Theme.panelVeil.opacity(ChatMetrics.panelVeil * reveal)
                                .ignoresSafeArea()
                                .allowsHitTesting(false)
                                .accessibilityHidden(true)
                            // Rounded leading corners and a soft shadow while the
                            // conversation is moved aside. The corners are painted
                            // in the sidebar's color instead of masking the whole
                            // conversation, which would render it offscreen.
                            PanelCorners(radius: ChatMetrics.panelRadius)
                                .fill(Theme.sidebar, style: FillStyle(eoFill: true))
                                .ignoresSafeArea()
                                .allowsHitTesting(false)
                                .accessibilityHidden(true)
                            // The paint above also covers the panel's shadow
                            // where it falls into those corners, which left a
                            // square edge beside the rounded one (1.0.51 on
                            // device). Draw that part of the shadow again on top.
                            if dressing == .previous { CornerShadow(radius: ChatMetrics.panelRadius) }
                            else { CornerShade(radius: ChatMetrics.panelRadius) }
                        }
                        Color.clear.contentShape(Rectangle()).ignoresSafeArea()
                            .onTapGesture { setOpen(false) }
                            .accessibilityElement()
                            .accessibilityLabel("会話に戻る")
                            .accessibilityAddTraits(.isButton)
                            .accessibilityIdentifier("history-close")
                    }
                }
                .background {
                    // Beside the history the conversation is a plain page,
                    // edged by the history's hairline.
                    let panel = !docked && dressing.dressesPanel
                    RoundedRectangle(cornerRadius: docked ? 0 : ChatMetrics.panelRadius, style: .continuous)
                        .fill(Theme.chatBackground)
                        .shadow(color: panel ? ChatMetrics.panelShadow : .clear,
                                radius: panel ? ChatMetrics.panelShadowRadius : 0)
                        .ignoresSafeArea()
                }
                // Beside the history the conversation is not made narrower:
                // that laid every line out again on each frame of the slide,
                // and the text and the field moved and flickered while it
                // ran (1.1.0 (226), Hachimoto さん 2026-10-29). It keeps the
                // whole width and its column, and only what stands in the
                // column moves over, by half the history's width, to the
                // middle of what remains (BesideShift). A move is drawn,
                // not laid out again, and the conversation itself is not
                // asked for again (1.1.0 (242)).
                .offset(x: docked ? 0 : sidebarWidth * reveal)
            if docked && (dockOpen || keepsDockedHistory) {
                // Over the conversation's leading edge, which it covers: it
                // slides in from there on the same spring as the column
                // moves over.
                HistoryView()
                    .frame(width: dockWidth)
                    .frame(maxHeight: .infinity)
                    .overlay(alignment: .trailing) {
                        Rectangle().fill(Theme.inputBorder)
                            .frame(width: 1 / displayScale)
                            .ignoresSafeArea()
                            .accessibilityHidden(true)
                    }
                    // Kept (preview only): put away out of sight instead.
                    .offset(x: keepsDockedHistory && !dockOpen ? -dockWidth : 0)
                    .allowsHitTesting(dockOpen)
                    .accessibilityHidden(!dockOpen)
                    .transition(reduceMotion ? AnyTransition.opacity : AnyTransition.move(edge: .leading))
                    // Read before the conversation, as when it lay under it.
                    .accessibilitySortPriority(1)
            }
        }
        #if POCKET_PREVIEW
        .overlay(alignment: .bottomTrailing) {
            if PreviewProbe.on("--dock-meter") {
                DockMeterReadout().modifier(DockFrameProbe(progress: docked && dockOpen ? 1 : 0))
            }
        }
        #endif
        .background(Theme.sidebar)
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { containerWidth = $0 }
        .gesture(HistoryDrawerPan(isOpen: reveal > 0.5, enabled: !docked, onChanged: drag, onEnded: settle))
        .environment(\.historySidebar, sidebar)
        .environment(\.historyVisible, !docked && reveal > 0)
        .environment(\.historyBeside, docked ? dockOpen : nil)
        .environment(\.historyDockLayout, docked ? dockLayout : nil)
        .environment(\.historyBesideShift, docked && dockOpen ? dockWidth / 2 : 0)
        .onChange(of: docked, initial: true) { old, now in
            dockedNow = now
            // The drawer is the phone's: a window narrowed to it starts closed.
            if old != now { dragOrigin = nil; reveal = 0; sidebarShown = false }
        }
        .tint(Theme.tint)
        // A tap as each slide lands, open or closed.
        .sensoryFeedback(.impact(weight: .medium), trigger: settledOpen)
        .onAppear {
            sidebar.openAction = { dockedNow ? setDocked(true) : setOpen(true) }
            sidebar.toggleAction = { dockedNow ? setDocked(!dockOpen) : setOpen(true) }
            sidebar.selectAction = { open($0) }
            sidebar.composeAction = compose
        }
        .task { await AuroraOrbView.prepare() }
    }

    private func drag(_ translation: CGFloat) {
        let origin = dragOrigin ?? reveal
        dragOrigin = origin
        if !sidebarShown { sidebarShown = true }
        reveal = min(1, max(0, origin + translation / sidebarWidth))
    }

    /// Settle where the finger was heading, carrying its speed into the spring.
    private func settle(_ translation: CGFloat, _ velocity: CGFloat) {
        let origin = dragOrigin ?? reveal
        dragOrigin = nil
        let current = min(1, max(0, origin + translation / sidebarWidth))
        let projected = current + velocity * 0.2 / sidebarWidth
        setOpen(projected > 0.5, velocity: velocity)
    }

    private func setOpen(_ open: Bool, velocity: CGFloat = 0) {
        let target: CGFloat = open ? 1 : 0
        let distance = (target - reveal) * sidebarWidth
        let initial = abs(distance) > 1 ? velocity / distance : 0
        if open { sidebarShown = true }
        settledOpen = open
        withAnimation(reduceMotion ? ChatMotion.reducedMenu
                      : .interpolatingSpring(duration: 0.4, bounce: 0, initialVelocity: initial),
                      completionCriteria: .removed) {
            reveal = target
        } completion: {
            // A new slide may have started before this one finished.
            if reveal == 0 && dragOrigin == nil { sidebarShown = false }
        }
    }

    /// The history beside the conversation, shown or put away; kept for the
    /// next launch.
    private func setDocked(_ open: Bool) {
        guard open != dockOpen else { return }
        UserDefaults.standard.set(open, forKey: HistoryDock.storageKey)
        #if POCKET_PREVIEW
        let metered = PreviewProbe.on("--dock-meter")
        if metered { SettingsSlideMeter.shared.asked(); SettingsSlideMeter.shared.began() }
        #endif
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : .spring(duration: 0.4, bounce: 0),
                      completionCriteria: .removed) {
            dockOpen = open
        } completion: {
            #if POCKET_PREVIEW
            if metered { SettingsSlideMeter.shared.ended() }
            #endif
        }
    }

    /// Beside the conversation the history stays where it is.
    private func open(_ id: UUID) {
        guard !chats.isGenerating || id == chats.selectedID else { return }
        chats.select(id)
        if !dockedNow { setOpen(false) }
    }
    private func compose() {
        guard !chats.isGenerating else { return }
        chats.newChat()
        if !dockedNow { setOpen(false) }
    }
}

#if POCKET_PREVIEW
/// The dock's motion frame by frame, for the UI check's meter
/// (`--dock-meter`, SettingsSlideMeter): on the meter's own dot, on the
/// history's spring, its body runs for each frame of the slide and changes
/// nothing. As a geometry effect on the conversation it was also asked for
/// on SwiftUI's render thread, where the meter's main-thread check stopped
/// the app (UI check run 40840586355, as the field was typed in).
private struct DockFrameProbe: ViewModifier, Animatable {
    var progress: CGFloat
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        SettingsSlideMeter.shared.frame()
        return content
    }
}

/// The last slide's line from the meter, for the UI check.
private struct DockMeterReadout: View {
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("history-dock-meter")
            .accessibilityLabel(SettingsSlideMeter.shared.summary ?? "none")
            .allowsHitTesting(false)
    }
}
#endif

/// The iPad's history beside the conversation (1.1.0 (226), Hachimoto さん
/// 2026-10-28): the header's button shows it and puts it away, and while it
/// shows the conversation on its right is used as ever, typed in and sent
/// from. The phone keeps the drawer.
enum HistoryDock {
    static let storageKey = "history-docked-open-v1"
    /// About a third of the width, as an iPad's own sidebars.
    static func width(_ container: CGFloat) -> CGFloat { min(max(container * 0.3, 300), 360) }
    /// The conversation's column, its side gutters included (1.1.0 (242)):
    /// what is left beside the history, and no more than 760pt, so that in
    /// landscape the history comes and goes beside it with room to spare.
    /// It depends on the screen's width alone, never on whether the history
    /// shows, so no line of the conversation is laid out again when it does.
    static let maxColumn: CGFloat = 760
    static func column(_ container: CGFloat) -> CGFloat { min(container - width(container), maxColumn) }
}

/// How the conversation stands beside the iPad's history (1.1.0 (242)).
struct HistoryDockLayout: Equatable {
    /// The history's width.
    var width: CGFloat
    /// The conversation's column, its gutters included (HistoryDock.column).
    var column: CGFloat
}

/// Moves what stands in the conversation's column over with the iPad's
/// history (1.1.0 (242)): drawn there, not laid out again. Only this
/// modifier reads how far, so the conversation is not asked for again
/// when the history comes or goes, and the move rides the history's spring.
struct BesideShift: ViewModifier {
    /// 2 for what keeps to the conversation's leading edge, beside the
    /// history's.
    var factor: CGFloat = 1
    @Environment(\.historyBesideShift) private var shift
    func body(content: Content) -> some View {
        content.offset(x: shift * factor)
    }
}

/// Lets the conversation ask for the sidebar, and the sidebar open a
/// conversation, without handing either view new closures every frame.
@MainActor final class HistorySidebar {
    fileprivate var openAction: () -> Void = {}
    fileprivate var toggleAction: () -> Void = {}
    fileprivate var selectAction: (UUID) -> Void = { _ in }
    fileprivate var composeAction: () -> Void = {}
    func open() { openAction() }
    /// The header's button: on the phone it opens the drawer; beside the
    /// conversation it shows the history or puts it away.
    func toggle() { toggleAction() }
    func select(_ id: UUID) { selectAction(id) }
    func compose() { composeAction() }
}

extension EnvironmentValues {
    @Entry var historySidebar: HistorySidebar? = nil
    /// True while any of the history sidebar is showing over the phone's
    /// conversation (never while it stands beside it).
    @Entry var historyVisible = false
    /// On an iPad's full width, whether the history stands beside the
    /// conversation; nil with the phone's drawer.
    @Entry var historyBeside: Bool? = nil
    /// On an iPad's full width, the history's width and the conversation's
    /// column; nil with the phone's drawer.
    @Entry var historyDockLayout: HistoryDockLayout? = nil
    /// How far the conversation's column stands over beside the iPad's
    /// history: half the history's width while it shows, else 0
    /// (BesideShift).
    @Entry var historyBesideShift: CGFloat = 0
}

/// How the conversation slid aside for the history is dressed, chosen in
/// 開発者設定 to check the black conversation (2026-10-25): with another
/// app's Picture in Picture on screen, the lower half of the slid
/// conversation showed black on the phone while the history was open,
/// though not in screenshots, and not while the screen was recorded.
enum PanelDressing: String, CaseIterable {
    /// Veil, painted corners and shadow, the corners' shadow drawn alone
    /// in the app (CornerShade, 1.1.0 (190)).
    case standard
    /// As until 1.1.0 (186): the corners' shadow cut out of a black panel
    /// with a blend (CornerShadow).
    case previous
    /// Neither veil, corners nor shadow.
    case bare

    static let key = "panel-dressing-check-v1"
    var dressesPanel: Bool { self == .standard || self == .previous }

    fileprivate var title: String {
        switch self {
        case .standard: "標準（角の影だけを描く・1.1.0 (190) から）"
        case .previous: "以前の描き方（黒く塗って切り抜く）"
        case .bare: "飾りなし（薄い膜・丸い角・影なし）"
        }
    }
}

/// 開発者設定's choice of PanelDressing, to try each with another app's
/// Picture in Picture on screen. Developer-only and temporary, so its
/// words are not translated.
struct PanelDressingCard: View {
    @AppStorage(PanelDressing.key) private var dressing = PanelDressing.standard
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label { Text(verbatim: "履歴を開いたときの会話側") } icon: { Image(systemName: "sidebar.left") }
                .font(.headline)
            ForEach(PanelDressing.allCases, id: \.self) { choice in
                Button { dressing = choice } label: {
                    HStack {
                        Text(verbatim: choice.title).foregroundStyle(.primary)
                        Spacer(minLength: 8)
                        if dressing == choice { Image(systemName: "checkmark").foregroundStyle(Theme.tint) }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .font(.subheadline)
                .accessibilityAddTraits(dressing == choice ? .isSelected : [])
                .accessibilityIdentifier("panel-dressing-\(choice.rawValue)")
            }
            Text(verbatim: "ピクチャ・イン・ピクチャを出したまま履歴を開くと、右に残る会話側の下半分が黒くなる問題の確認用です。黒くなるかどうかを、それぞれで試せます。")
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }
}

/// The panel's shadow where it falls into its painted corners: a rounded
/// rectangle's shadow with the rectangle itself cut out, kept inside the
/// conversation's frame (outside it, the panel's own background casts it).
/// The shape casting it sits 1pt inside the cut-out: with the same outline,
/// the cut only removed part of each anti-aliased edge pixel and left a dark
/// hairline along the curve (1.0.52 on device).
private struct CornerShadow: View {
    let radius: CGFloat
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: radius, style: .continuous)
                .inset(by: 1)
                .fill(.black)
                .shadow(color: ChatMetrics.panelShadow, radius: ChatMetrics.panelShadowRadius)
            RoundedRectangle(cornerRadius: radius, style: .continuous)
                .fill(.black)
                .blendMode(.destinationOut)
        }
        .compositingGroup()
        .clipped()
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// The same shadow in the painted corners, drawn alone (1.1.0 (190)): each
/// corner is a small canvas that draws only the shadow of the panel's
/// outline, clipped to the corner outside the rounded shape, so nothing
/// dark is laid over the conversation to be cut away again. CornerShadow
/// filled the whole panel black and blended the panel out of it; with
/// another app's Picture in Picture on screen the phone showed that black
/// over the slid conversation (2026-10-25).
private struct CornerShade: View {
    let radius: CGFloat
    var body: some View {
        ZStack {
            corner(leading: true, top: true)
            corner(leading: true, top: false)
            corner(leading: false, top: true)
            corner(leading: false, top: false)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func corner(leading: Bool, top: Bool) -> some View {
        Canvas { context, size in
            // A square of the panel's outline with this corner at the
            // canvas's corner; its other corners lie beyond the shadow's
            // reach.
            let side = radius * 4
            let square = CGRect(x: leading ? 0 : size.width - side, y: top ? 0 : size.height - side,
                                width: side, height: side)
            let outline = RoundedRectangle(cornerRadius: radius, style: .continuous)
            var outside = Path(CGRect(origin: .zero, size: size))
            outside.addPath(outline.path(in: square))
            context.clip(to: outside, style: FillStyle(eoFill: true))
            // Cast from 1pt inside the outline, as CornerShadow's was.
            context.addFilter(.shadow(color: ChatMetrics.panelShadow, radius: ChatMetrics.panelShadowRadius,
                                      options: .shadowOnly))
            context.fill(outline.inset(by: 1).path(in: square), with: .color(.black))
        }
        .frame(width: radius, height: radius)
        .frame(maxWidth: .infinity, maxHeight: .infinity,
               alignment: Alignment(horizontal: leading ? .leading : .trailing, vertical: top ? .top : .bottom))
    }
}

/// The four corners outside a continuous rounded rectangle.
struct PanelCorners: Shape {
    var radius: CGFloat
    func path(in rect: CGRect) -> Path {
        var path = Path(rect)
        path.addPath(Path(roundedRect: rect, cornerRadius: radius, style: .continuous))
        return path
    }
}

/// A horizontal pan anywhere on the screen: rightward opens the sidebar,
/// leftward closes it. Vertical scrolling waits for it to fail, which it
/// does as soon as the movement is mostly vertical, so a sideways swipe
/// never scrolls the conversation. Horizontal strips (draft attachments)
/// keep their own swipes.
private struct HistoryDrawerPan: UIGestureRecognizerRepresentable {
    let isOpen: Bool
    /// Off while the history stands beside the conversation.
    let enabled: Bool
    let onChanged: (CGFloat) -> Void
    let onEnded: (CGFloat, CGFloat) -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.delegate = context.coordinator
        return pan
    }
    func updateUIGestureRecognizer(_ pan: UIPanGestureRecognizer, context: Context) {
        context.coordinator.isOpen = isOpen
        pan.isEnabled = enabled
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        let translation = pan.translation(in: pan.view).x
        switch pan.state {
        case .began, .changed: onChanged(translation)
        case .ended: onEnded(translation, pan.velocity(in: pan.view).x)
        case .cancelled, .failed: onEnded(translation, 0)
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var isOpen = false
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            guard abs(velocity.x) > abs(velocity.y) * 1.2 else { return false }
            return isOpen ? velocity.x < 0 : velocity.x > 0
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldBeRequiredToFailBy other: UIGestureRecognizer) -> Bool {
            guard let scroll = other.view as? UIScrollView, other === scroll.panGestureRecognizer else { return false }
            return scroll.contentSize.width <= scroll.bounds.width + 1
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            var view = touch.view
            while let current = view {
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

/// Keep the system edge-pop gesture when the chat draws its own contact header.
struct ChatBackSwipe: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> Controller { Controller() }
    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.scheduleConnection()
    }

    final class Controller: UIViewController, UIGestureRecognizerDelegate {
        private weak var connectedNavigation: UINavigationController?
        private var connections: [GestureConnection] = []
        private var connectionScheduled = false

        private final class GestureConnection {
            weak var gesture: UIGestureRecognizer?
            weak var previousDelegate: UIGestureRecognizerDelegate?
            init(_ gesture: UIGestureRecognizer) {
                self.gesture = gesture
                previousDelegate = gesture.delegate
            }
        }

        override func loadView() {
            view = UIView()
            view.isUserInteractionEnabled = false
        }
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            scheduleConnection()
        }
        override func didMove(toParent parent: UIViewController?) {
            super.didMove(toParent: parent)
            scheduleConnection()
        }
        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            scheduleConnection()
        }
        override func viewDidDisappear(_ animated: Bool) {
            super.viewDidDisappear(animated)
            disconnect()
        }

        // A SwiftUI background controller may appear before its destination is
        // connected to UIKit's navigation controller. Connect after that update,
        // and use the public containment tree if it is not a direct ancestor.
        func scheduleConnection() {
            guard !connectionScheduled else { return }
            connectionScheduled = true
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.connectionScheduled = false
                self.connect()
            }
        }
        private func connect() {
            guard let window = viewIfLoaded?.window,
                  let navigation = navigationController ?? findNavigation(in: window.rootViewController),
                  navigation.viewControllers.count > 1 else { return }
            if connectedNavigation !== navigation { disconnect() }
            connectedNavigation = navigation
            var gestures = [navigation.interactivePopGestureRecognizer].compactMap { $0 }
            if #available(iOS 26.0, *), let contentPop = navigation.interactiveContentPopGestureRecognizer {
                if let edgePop = navigation.interactivePopGestureRecognizer { contentPop.require(toFail: edgePop) }
                gestures.append(contentPop)
            }
            for gesture in gestures {
                if !connections.contains(where: { $0.gesture === gesture }) {
                    connections.append(GestureConnection(gesture))
                    #if DEBUG
                    gesture.addTarget(self, action: #selector(traceBackGesture(_:)))
                    #endif
                }
                gesture.delegate = self
                if gesture.state == .possible { gesture.isEnabled = true }
            }
        }
        private func findNavigation(in controller: UIViewController?) -> UINavigationController? {
            guard let controller else { return nil }
            if let navigation = controller as? UINavigationController,
               navigation.viewControllers.count > 1,
               navigation.viewIfLoaded?.window === viewIfLoaded?.window { return navigation }
            for child in controller.children.reversed() {
                if let navigation = findNavigation(in: child) { return navigation }
            }
            return nil
        }
        private func disconnect() {
            for connection in connections {
                #if DEBUG
                connection.gesture?.removeTarget(self, action: #selector(traceBackGesture(_:)))
                #endif
                if connection.gesture?.delegate === self {
                    connection.gesture?.delegate = connection.previousDelegate
                }
            }
            connections.removeAll()
            connectedNavigation = nil
        }
        #if DEBUG
        @objc private func traceBackGesture(_ gesture: UIGestureRecognizer) {
            guard ProcessInfo.processInfo.arguments.contains("--gesture-diagnostics"),
                  gesture.state == .began || gesture.state == .ended || gesture.state == .cancelled else { return }
            let coordinator = connectedNavigation?.transitionCoordinator
            print("Back gesture state=\(gesture.state.rawValue) controllers=\(connectedNavigation?.viewControllers.count ?? 0) progress=\(coordinator?.percentComplete ?? 0)")
            if gesture.state == .began {
                coordinator?.notifyWhenInteractionChanges { context in
                    print("Back interaction cancelled=\(context.isCancelled) progress=\(context.percentComplete)")
                }
            }
        }
        #endif
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let navigation = connectedNavigation else { return false }
            guard navigation.viewControllers.count > 1, navigation.transitionCoordinator == nil else { return false }
            if let pan = gestureRecognizer as? UIPanGestureRecognizer {
                let velocity = pan.velocity(in: navigation.view)
                return velocity.x > abs(velocity.y)
            }
            return true
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            guard let navigationView = connectedNavigation?.view else { return false }
            // Keep edge swipes away from the contact controls and composer.
            let y = touch.location(in: navigationView).y
            return y > navigationView.safeAreaInsets.top + 100
                && y < navigationView.bounds.height - navigationView.safeAreaInsets.bottom - 72
        }
    }
}
