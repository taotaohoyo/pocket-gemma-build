import SwiftUI
import UIKit

/// The conversation is the app's one screen. Its history sits underneath
/// in a sidebar: a swipe right (or the header button) slides the
/// conversation aside to reveal it, following the finger, as ChatGPT does.
struct ChatNavigationView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    /// 0 with the conversation in place, 1 with the sidebar fully open.
    @State private var reveal: CGFloat = 0
    /// The sidebar and the slid panel's dressing (veil, corners, shadow)
    /// exist from the first frame of a slide until the conversation has
    /// settled back in place. Tied to `reveal > 0` instead, they were
    /// removed the moment a close began and faded out where the finger let
    /// go while the conversation slid on (1.0.51 on device).
    @State private var sidebarShown = false
    /// Where the last slide settled, for the haptic tap.
    @State private var settledOpen = false
    @State private var dragOrigin: CGFloat?
    @State private var containerWidth: CGFloat = 402
    /// A stable reference, so the conversation is not re-rendered on every
    /// frame of the slide just because a new closure was passed down.
    @State private var sidebar = HistorySidebar()
    /// 開発者設定's check of the slid panel's dressing (PanelDressing).
    @AppStorage(PanelDressing.key) private var dressing = PanelDressing.standard

    /// ChatGPT leaves 92pt of the conversation showing (measured on a
    /// 402pt-wide iPhone).
    private var sidebarWidth: CGFloat { min(max(containerWidth - 92, 260), 360) }

    var body: some View {
        ZStack(alignment: .leading) {
            // Only built while any of it shows: hidden under the
            // conversation, its scroll view still reached accessibility and
            // took the conversation's hit tests (UI check, 1.0.50).
            if sidebarShown {
                HistoryView()
                    .frame(width: sidebarWidth)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                    // The sidebar brightens as it is uncovered.
                    .opacity(0.4 + 0.6 * reveal)
            }
            ChatView()
                // The sidebar's search keyboard must not lift the composer
                // in the strip of conversation left showing.
                .ignoresSafeArea(reveal > 0 ? .keyboard : [], edges: .bottom)
                .allowsHitTesting(reveal == 0)
                .accessibilityHidden(reveal > 0)
                .overlay {
                    if sidebarShown {
                        if dressing.dressesPanel {
                            Theme.panelVeil.opacity(ChatMetrics.panelVeil * reveal)
                                .ignoresSafeArea()
                                .allowsHitTesting(false)
                                .accessibilityHidden(true)
                            // Rounded leading corners and a soft shadow while the
                            // conversation is moved aside. The corners are painted
                            // in the sidebar's color instead of masking the whole
                            // conversation, which would render it offscreen.
                            PanelCorners(radius: ChatMetrics.panelRadius)
                                .fill(Theme.sidebar, style: FillStyle(eoFill: true))
                                .ignoresSafeArea()
                                .allowsHitTesting(false)
                                .accessibilityHidden(true)
                            // The paint above also covers the panel's shadow
                            // where it falls into those corners, which left a
                            // square edge beside the rounded one (1.0.51 on
                            // device). Draw that part of the shadow again on top.
                            if dressing == .previous { CornerShadow(radius: ChatMetrics.panelRadius) }
                            else { CornerShade(radius: ChatMetrics.panelRadius) }
                        }
                        Color.clear.contentShape(Rectangle()).ignoresSafeArea()
                            .onTapGesture { setOpen(false) }
                            .accessibilityElement()
                            .accessibilityLabel("会話に戻る")
                            .accessibilityAddTraits(.isButton)
                            .accessibilityIdentifier("history-close")
                    }
                }
                .background {
                    RoundedRectangle(cornerRadius: ChatMetrics.panelRadius, style: .continuous)
                        .fill(Theme.chatBackground)
                        .shadow(color: dressing.dressesPanel ? ChatMetrics.panelShadow : .clear,
                                radius: dressing.dressesPanel ? ChatMetrics.panelShadowRadius : 0)
                        .ignoresSafeArea()
                }
                .offset(x: sidebarWidth * reveal)
        }
        .background(Theme.sidebar)
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { containerWidth = $0 }
        .gesture(HistoryDrawerPan(isOpen: reveal > 0.5, onChanged: drag, onEnded: settle))
        .environment(\.historySidebar, sidebar)
        .environment(\.historyVisible, reveal > 0)
        .tint(Theme.accent)
        // A tap as each slide lands, open or closed.
        .sensoryFeedback(.impact(weight: .medium), trigger: settledOpen)
        .onAppear {
            sidebar.openAction = { setOpen(true) }
            sidebar.selectAction = { open($0) }
            sidebar.composeAction = compose
        }
        .task { await AuroraOrbView.prepare() }
    }

    private func drag(_ translation: CGFloat) {
        let origin = dragOrigin ?? reveal
        dragOrigin = origin
        if !sidebarShown { sidebarShown = true }
        reveal = min(1, max(0, origin + translation / sidebarWidth))
    }

    /// Settle where the finger was heading, carrying its speed into the spring.
    private func settle(_ translation: CGFloat, _ velocity: CGFloat) {
        let origin = dragOrigin ?? reveal
        dragOrigin = nil
        let current = min(1, max(0, origin + translation / sidebarWidth))
        let projected = current + velocity * 0.2 / sidebarWidth
        setOpen(projected > 0.5, velocity: velocity)
    }

    private func setOpen(_ open: Bool, velocity: CGFloat = 0) {
        let target: CGFloat = open ? 1 : 0
        let distance = (target - reveal) * sidebarWidth
        let initial = abs(distance) > 1 ? velocity / distance : 0
        if open { sidebarShown = true }
        settledOpen = open
        withAnimation(reduceMotion ? ChatMotion.reducedMenu
                      : .interpolatingSpring(duration: 0.4, bounce: 0, initialVelocity: initial),
                      completionCriteria: .removed) {
            reveal = target
        } completion: {
            // A new slide may have started before this one finished.
            if reveal == 0 && dragOrigin == nil { sidebarShown = false }
        }
    }

    private func open(_ id: UUID) {
        guard !chats.isGenerating || id == chats.selectedID else { return }
        chats.select(id)
        setOpen(false)
    }
    private func compose() {
        guard !chats.isGenerating else { return }
        chats.newChat()
        setOpen(false)
    }
}

/// Lets the conversation ask for the sidebar, and the sidebar open a
/// conversation, without handing either view new closures every frame.
@MainActor final class HistorySidebar {
    fileprivate var openAction: () -> Void = {}
    fileprivate var selectAction: (UUID) -> Void = { _ in }
    fileprivate var composeAction: () -> Void = {}
    func open() { openAction() }
    func select(_ id: UUID) { selectAction(id) }
    func compose() { composeAction() }
}

extension EnvironmentValues {
    @Entry var historySidebar: HistorySidebar? = nil
    /// True while any of the history sidebar is showing.
    @Entry var historyVisible = false
}

/// How the conversation slid aside for the history is dressed, chosen in
/// 開発者設定 to check the black conversation (2026-10-25): with another
/// app's Picture in Picture on screen, the lower half of the slid
/// conversation showed black on the phone while the history was open,
/// though not in screenshots, and not while the screen was recorded.
enum PanelDressing: String, CaseIterable {
    /// Veil, painted corners and shadow, the corners' shadow drawn alone
    /// in the app (CornerShade, 1.1.0 (190)).
    case standard
    /// As until 1.1.0 (186): the corners' shadow cut out of a black panel
    /// with a blend (CornerShadow).
    case previous
    /// Neither veil, corners nor shadow.
    case bare

    static let key = "panel-dressing-check-v1"
    var dressesPanel: Bool { self == .standard || self == .previous }

    fileprivate var title: String {
        switch self {
        case .standard: "標準（角の影だけを描く・1.1.0 (190) から）"
        case .previous: "以前の描き方（黒く塗って切り抜く）"
        case .bare: "飾りなし（薄い膜・丸い角・影なし）"
        }
    }
}

/// 開発者設定's choice of PanelDressing, to try each with another app's
/// Picture in Picture on screen. Developer-only and temporary, so its
/// words are not translated.
struct PanelDressingCard: View {
    @AppStorage(PanelDressing.key) private var dressing = PanelDressing.standard
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label { Text(verbatim: "履歴を開いたときの会話側") } icon: { Image(systemName: "sidebar.left") }
                .font(.headline)
            ForEach(PanelDressing.allCases, id: \.self) { choice in
                Button { dressing = choice } label: {
                    HStack {
                        Text(verbatim: choice.title).foregroundStyle(.primary)
                        Spacer(minLength: 8)
                        if dressing == choice { Image(systemName: "checkmark").foregroundStyle(Theme.accent) }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .font(.subheadline)
                .accessibilityAddTraits(dressing == choice ? .isSelected : [])
                .accessibilityIdentifier("panel-dressing-\(choice.rawValue)")
            }
            Text(verbatim: "ピクチャ・イン・ピクチャを出したまま履歴を開くと、右に残る会話側の下半分が黒くなる問題の確認用です。黒くなるかどうかを、それぞれで試せます。")
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}

/// The panel's shadow where it falls into its painted corners: a rounded
/// rectangle's shadow with the rectangle itself cut out, kept inside the
/// conversation's frame (outside it, the panel's own background casts it).
/// The shape casting it sits 1pt inside the cut-out: with the same outline,
/// the cut only removed part of each anti-aliased edge pixel and left a dark
/// hairline along the curve (1.0.52 on device).
private struct CornerShadow: View {
    let radius: CGFloat
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: radius, style: .continuous)
                .inset(by: 1)
                .fill(.black)
                .shadow(color: ChatMetrics.panelShadow, radius: ChatMetrics.panelShadowRadius)
            RoundedRectangle(cornerRadius: radius, style: .continuous)
                .fill(.black)
                .blendMode(.destinationOut)
        }
        .compositingGroup()
        .clipped()
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// The same shadow in the painted corners, drawn alone (1.1.0 (190)): each
/// corner is a small canvas that draws only the shadow of the panel's
/// outline, clipped to the corner outside the rounded shape, so nothing
/// dark is laid over the conversation to be cut away again. CornerShadow
/// filled the whole panel black and blended the panel out of it; with
/// another app's Picture in Picture on screen the phone showed that black
/// over the slid conversation (2026-10-25).
private struct CornerShade: View {
    let radius: CGFloat
    var body: some View {
        ZStack {
            corner(leading: true, top: true)
            corner(leading: true, top: false)
            corner(leading: false, top: true)
            corner(leading: false, top: false)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func corner(leading: Bool, top: Bool) -> some View {
        Canvas { context, size in
            // A square of the panel's outline with this corner at the
            // canvas's corner; its other corners lie beyond the shadow's
            // reach.
            let side = radius * 4
            let square = CGRect(x: leading ? 0 : size.width - side, y: top ? 0 : size.height - side,
                                width: side, height: side)
            let outline = RoundedRectangle(cornerRadius: radius, style: .continuous)
            var outside = Path(CGRect(origin: .zero, size: size))
            outside.addPath(outline.path(in: square))
            context.clip(to: outside, style: FillStyle(eoFill: true))
            // Cast from 1pt inside the outline, as CornerShadow's was.
            context.addFilter(.shadow(color: ChatMetrics.panelShadow, radius: ChatMetrics.panelShadowRadius,
                                      options: .shadowOnly))
            context.fill(outline.inset(by: 1).path(in: square), with: .color(.black))
        }
        .frame(width: radius, height: radius)
        .frame(maxWidth: .infinity, maxHeight: .infinity,
               alignment: Alignment(horizontal: leading ? .leading : .trailing, vertical: top ? .top : .bottom))
    }
}

/// The four corners outside a continuous rounded rectangle.
struct PanelCorners: Shape {
    var radius: CGFloat
    func path(in rect: CGRect) -> Path {
        var path = Path(rect)
        path.addPath(Path(roundedRect: rect, cornerRadius: radius, style: .continuous))
        return path
    }
}

/// A horizontal pan anywhere on the screen: rightward opens the sidebar,
/// leftward closes it. Vertical scrolling waits for it to fail, which it
/// does as soon as the movement is mostly vertical, so a sideways swipe
/// never scrolls the conversation. Horizontal strips (draft attachments)
/// keep their own swipes.
private struct HistoryDrawerPan: UIGestureRecognizerRepresentable {
    let isOpen: Bool
    let onChanged: (CGFloat) -> Void
    let onEnded: (CGFloat, CGFloat) -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.delegate = context.coordinator
        return pan
    }
    func updateUIGestureRecognizer(_ pan: UIPanGestureRecognizer, context: Context) {
        context.coordinator.isOpen = isOpen
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        let translation = pan.translation(in: pan.view).x
        switch pan.state {
        case .began, .changed: onChanged(translation)
        case .ended: onEnded(translation, pan.velocity(in: pan.view).x)
        case .cancelled, .failed: onEnded(translation, 0)
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var isOpen = false
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            guard abs(velocity.x) > abs(velocity.y) * 1.2 else { return false }
            return isOpen ? velocity.x < 0 : velocity.x > 0
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldBeRequiredToFailBy other: UIGestureRecognizer) -> Bool {
            guard let scroll = other.view as? UIScrollView, other === scroll.panGestureRecognizer else { return false }
            return scroll.contentSize.width <= scroll.bounds.width + 1
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            var view = touch.view
            while let current = view {
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

/// Keep the system edge-pop gesture when the chat draws its own contact header.
struct ChatBackSwipe: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> Controller { Controller() }
    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.scheduleConnection()
    }

    final class Controller: UIViewController, UIGestureRecognizerDelegate {
        private weak var connectedNavigation: UINavigationController?
        private var connections: [GestureConnection] = []
        private var connectionScheduled = false

        private final class GestureConnection {
            weak var gesture: UIGestureRecognizer?
            weak var previousDelegate: UIGestureRecognizerDelegate?
            init(_ gesture: UIGestureRecognizer) {
                self.gesture = gesture
                previousDelegate = gesture.delegate
            }
        }

        override func loadView() {
            view = UIView()
            view.isUserInteractionEnabled = false
        }
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            scheduleConnection()
        }
        override func didMove(toParent parent: UIViewController?) {
            super.didMove(toParent: parent)
            scheduleConnection()
        }
        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            scheduleConnection()
        }
        override func viewDidDisappear(_ animated: Bool) {
            super.viewDidDisappear(animated)
            disconnect()
        }

        // A SwiftUI background controller may appear before its destination is
        // connected to UIKit's navigation controller. Connect after that update,
        // and use the public containment tree if it is not a direct ancestor.
        func scheduleConnection() {
            guard !connectionScheduled else { return }
            connectionScheduled = true
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.connectionScheduled = false
                self.connect()
            }
        }
        private func connect() {
            guard let window = viewIfLoaded?.window,
                  let navigation = navigationController ?? findNavigation(in: window.rootViewController),
                  navigation.viewControllers.count > 1 else { return }
            if connectedNavigation !== navigation { disconnect() }
            connectedNavigation = navigation
            var gestures = [navigation.interactivePopGestureRecognizer].compactMap { $0 }
            if #available(iOS 26.0, *), let contentPop = navigation.interactiveContentPopGestureRecognizer {
                if let edgePop = navigation.interactivePopGestureRecognizer { contentPop.require(toFail: edgePop) }
                gestures.append(contentPop)
            }
            for gesture in gestures {
                if !connections.contains(where: { $0.gesture === gesture }) {
                    connections.append(GestureConnection(gesture))
                    #if DEBUG
                    gesture.addTarget(self, action: #selector(traceBackGesture(_:)))
                    #endif
                }
                gesture.delegate = self
                if gesture.state == .possible { gesture.isEnabled = true }
            }
        }
        private func findNavigation(in controller: UIViewController?) -> UINavigationController? {
            guard let controller else { return nil }
            if let navigation = controller as? UINavigationController,
               navigation.viewControllers.count > 1,
               navigation.viewIfLoaded?.window === viewIfLoaded?.window { return navigation }
            for child in controller.children.reversed() {
                if let navigation = findNavigation(in: child) { return navigation }
            }
            return nil
        }
        private func disconnect() {
            for connection in connections {
                #if DEBUG
                connection.gesture?.removeTarget(self, action: #selector(traceBackGesture(_:)))
                #endif
                if connection.gesture?.delegate === self {
                    connection.gesture?.delegate = connection.previousDelegate
                }
            }
            connections.removeAll()
            connectedNavigation = nil
        }
        #if DEBUG
        @objc private func traceBackGesture(_ gesture: UIGestureRecognizer) {
            guard ProcessInfo.processInfo.arguments.contains("--gesture-diagnostics"),
                  gesture.state == .began || gesture.state == .ended || gesture.state == .cancelled else { return }
            let coordinator = connectedNavigation?.transitionCoordinator
            print("Back gesture state=\(gesture.state.rawValue) controllers=\(connectedNavigation?.viewControllers.count ?? 0) progress=\(coordinator?.percentComplete ?? 0)")
            if gesture.state == .began {
                coordinator?.notifyWhenInteractionChanges { context in
                    print("Back interaction cancelled=\(context.isCancelled) progress=\(context.percentComplete)")
                }
            }
        }
        #endif
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let navigation = connectedNavigation else { return false }
            guard navigation.viewControllers.count > 1, navigation.transitionCoordinator == nil else { return false }
            if let pan = gestureRecognizer as? UIPanGestureRecognizer {
                let velocity = pan.velocity(in: navigation.view)
                return velocity.x > abs(velocity.y)
            }
            return true
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            guard let navigationView = connectedNavigation?.view else { return false }
            // Keep edge swipes away from the contact controls and composer.
            let y = touch.location(in: navigationView).y
            return y > navigationView.safeAreaInsets.top + 100
                && y < navigationView.bounds.height - navigationView.safeAreaInsets.bottom - 72
        }
    }
}
