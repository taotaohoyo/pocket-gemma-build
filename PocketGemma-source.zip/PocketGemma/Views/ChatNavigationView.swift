import SwiftUI
import UIKit

struct ChatNavigationView: View {
    @EnvironmentObject private var chats: ChatStore
    @State private var path: [UUID] = []
    @State private var restored = false

    var body: some View {
        NavigationStack(path: $path) {
            HistoryView(onOpen: open, onCompose: compose)
                .navigationDestination(for: UUID.self) { _ in ChatView() }
        }
        .tint(Theme.accent)
        .onAppear {
            guard !restored else { return }
            restored = true
            if let id = chats.selectedID {
                var transaction = Transaction()
                transaction.disablesAnimations = true
                withTransaction(transaction) { path = [id] }
            }
        }
    }

    private func open(_ id: UUID) {
        guard !chats.isGenerating || id == chats.selectedID else { return }
        chats.select(id)
        path.append(id)
    }
    private func compose() {
        guard !chats.isGenerating else { return }
        chats.newChat()
        if let id = chats.selectedID { path.append(id) }
    }
}

/// Keep the system edge-pop gesture when the chat draws its own contact header.
struct ChatBackSwipe: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> Controller { Controller() }
    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.scheduleConnection()
    }

    final class Controller: UIViewController, UIGestureRecognizerDelegate {
        private weak var connectedNavigation: UINavigationController?
        private var connections: [GestureConnection] = []
        private var connectionScheduled = false

        private final class GestureConnection {
            weak var gesture: UIGestureRecognizer?
            weak var previousDelegate: UIGestureRecognizerDelegate?
            init(_ gesture: UIGestureRecognizer) {
                self.gesture = gesture
                previousDelegate = gesture.delegate
            }
        }

        override func loadView() {
            view = UIView()
            view.isUserInteractionEnabled = false
        }
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            scheduleConnection()
        }
        override func didMove(toParent parent: UIViewController?) {
            super.didMove(toParent: parent)
            scheduleConnection()
        }
        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            scheduleConnection()
        }
        override func viewDidDisappear(_ animated: Bool) {
            super.viewDidDisappear(animated)
            disconnect()
        }

        // A SwiftUI background controller may appear before its destination is
        // connected to UIKit's navigation controller. Connect after that update,
        // and use the public containment tree if it is not a direct ancestor.
        func scheduleConnection() {
            guard !connectionScheduled else { return }
            connectionScheduled = true
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.connectionScheduled = false
                self.connect()
            }
        }
        private func connect() {
            guard let window = viewIfLoaded?.window,
                  let navigation = navigationController ?? findNavigation(in: window.rootViewController),
                  navigation.viewControllers.count > 1 else { return }
            if connectedNavigation !== navigation { disconnect() }
            connectedNavigation = navigation
            var gestures = [navigation.interactivePopGestureRecognizer].compactMap { $0 }
            if #available(iOS 26.0, *), let contentPop = navigation.interactiveContentPopGestureRecognizer {
                if let edgePop = navigation.interactivePopGestureRecognizer { contentPop.require(toFail: edgePop) }
                gestures.append(contentPop)
            }
            for gesture in gestures {
                if !connections.contains(where: { $0.gesture === gesture }) {
                    connections.append(GestureConnection(gesture))
                    #if DEBUG
                    gesture.addTarget(self, action: #selector(traceBackGesture(_:)))
                    #endif
                }
                gesture.delegate = self
                if gesture.state == .possible { gesture.isEnabled = true }
            }
        }
        private func findNavigation(in controller: UIViewController?) -> UINavigationController? {
            guard let controller else { return nil }
            if let navigation = controller as? UINavigationController,
               navigation.viewControllers.count > 1,
               navigation.viewIfLoaded?.window === viewIfLoaded?.window { return navigation }
            for child in controller.children.reversed() {
                if let navigation = findNavigation(in: child) { return navigation }
            }
            return nil
        }
        private func disconnect() {
            for connection in connections {
                #if DEBUG
                connection.gesture?.removeTarget(self, action: #selector(traceBackGesture(_:)))
                #endif
                if connection.gesture?.delegate === self {
                    connection.gesture?.delegate = connection.previousDelegate
                }
            }
            connections.removeAll()
            connectedNavigation = nil
        }
        #if DEBUG
        @objc private func traceBackGesture(_ gesture: UIGestureRecognizer) {
            guard ProcessInfo.processInfo.arguments.contains("--gesture-diagnostics"),
                  gesture.state == .began || gesture.state == .ended || gesture.state == .cancelled else { return }
            let coordinator = connectedNavigation?.transitionCoordinator
            print("Back gesture state=\(gesture.state.rawValue) controllers=\(connectedNavigation?.viewControllers.count ?? 0) progress=\(coordinator?.percentComplete ?? 0)")
            if gesture.state == .began {
                coordinator?.notifyWhenInteractionChanges { context in
                    print("Back interaction cancelled=\(context.isCancelled) progress=\(context.percentComplete)")
                }
            }
        }
        #endif
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let navigation = connectedNavigation else { return false }
            guard navigation.viewControllers.count > 1, navigation.transitionCoordinator == nil else { return false }
            if let pan = gestureRecognizer as? UIPanGestureRecognizer {
                let velocity = pan.velocity(in: navigation.view)
                return velocity.x > abs(velocity.y)
            }
            return true
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            guard let navigationView = connectedNavigation?.view else { return false }
            // Keep edge swipes away from the contact controls and composer.
            let y = touch.location(in: navigationView).y
            return y > navigationView.safeAreaInsets.top + 100
                && y < navigationView.bounds.height - navigationView.safeAreaInsets.bottom - 72
        }
    }
}
