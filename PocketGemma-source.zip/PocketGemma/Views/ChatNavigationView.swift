import SwiftUI
import UIKit

/// The conversation is the app's one screen. Its history sits underneath
/// in a sidebar: a swipe right (or the header button) slides the
/// conversation aside to reveal it, following the finger, as ChatGPT does.
/// On an iPad's full width the header button shows the history beside the
/// conversation instead, and puts it away again: the conversation moves
/// over and stays in use (HistoryDock, 1.1.0 (226)), keeping its size and
/// its lines (1.1.0 (242)). On the phone the two are layers, one behind the
/// other (1.1.0 (272), fielua-reports Issue #11, after ChatGPT's): the
/// conversation, in front, slides aside, paler, with its shadow on the
/// history, and the history comes forward from behind it, from a little
/// smaller and faint; closing, the conversation comes back over it and the
/// history sinks back. Both move frame by frame (HistoryDrawerMotion).
struct ChatNavigationView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.horizontalSizeClass) private var sizeClass
    @Environment(\.displayScale) private var displayScale
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    /// 0 with the conversation in place, 1 with the sidebar fully open:
    /// where the drawer is headed, or where a finger holds it. It changes at
    /// once; what is drawn follows (`drawn`).
    @State private var reveal: CGFloat = 0
    /// Where the drawer is drawn this frame: the conversation's slide and
    /// the history's lift (HistoryDrawerMotion).
    @State private var drawn = HistoryDrawerMotion.Frame(slide: 0, lift: 0)
    @State private var motion = HistoryDrawerMotion()
    /// The sidebar and the slid panel's dressing (veil, corners, shadow)
    /// exist from the first frame of a slide until the conversation has
    /// settled back in place. Tied to `reveal > 0` instead, they were
    /// removed the moment a close began and faded out where the finger let
    /// go while the conversation slid on (1.0.51 on device).
    @State private var sidebarShown = false
    /// From the moment a close begins until it has ended: the conversation
    /// goes on ignoring the keyboard. Picked from a search, the history's
    /// own keyboard was still up as the close began, and the composer rose
    /// above it in the strip and fell again once it went (1.1.0 (268)).
    @State private var closingAside = false
    /// Where the last slide settled, for the haptic tap.
    @State private var settledOpen = false
    @State private var dragOrigin: CGFloat?
    @State private var containerWidth: CGFloat = 402
    /// A stable reference, so the conversation is not re-rendered on every
    /// frame of the slide just because a new closure was passed down.
    @State private var sidebar = HistorySidebar()
    /// The history beside the conversation on an iPad, as the person left it.
    @State private var dockOpen = UserDefaults.standard.bool(forKey: HistoryDock.storageKey)
    /// `docked` for the sidebar's actions: they keep the copy of this view
    /// they were made in, with the size class it had then.
    @State private var dockedNow = false

    /// An iPad's full width (not Slide Over or a narrow window): the history
    /// stands beside the conversation instead of under it.
    private var docked: Bool { UIDevice.current.userInterfaceIdiom == .pad && sizeClass == .regular }
    private var dockWidth: CGFloat { HistoryDock.width(containerWidth) }
    /// The conversation's column beside the history, the same whether the
    /// history shows or not.
    private var dockLayout: HistoryDockLayout {
        HistoryDockLayout(width: dockWidth, column: HistoryDock.column(containerWidth))
    }
    /// Preview only (`--dock-keep-history`): the history put away stays
    /// built, slid out of sight, to measure what building it again costs
    /// each time it shows.
    private var keepsDockedHistory: Bool {
        #if POCKET_PREVIEW
        PreviewProbe.on("--dock-keep-history")
        #else
        false
        #endif
    }

    /// ChatGPT leaves 92pt of the conversation showing (measured on a
    /// 402pt-wide iPhone).
    private var sidebarWidth: CGFloat { min(max(containerWidth - 92, 260), 360) }

    var body: some View {
        ZStack(alignment: .leading) {
            // Only built while any of it shows: hidden under the
            // conversation, its scroll view still reached accessibility and
            // took the conversation's hit tests (UI check, 1.0.50).
            if !docked && sidebarShown {
                // It comes forward from behind the conversation where it
                // stands, from a little smaller and faint (1.1.0 (272));
                // with Reduce Motion it only fades. Drawn, never laid out:
                // its rows are not asked for again. Laid out past the
                // screen's edges, so the blur under its title and its
                // buttons meets them at every size (HistoryAtBack, 273).
                HistoryAtBack(width: sidebarWidth,
                              scale: HistoryDepth.scale(drawn.lift, reduced: reduceMotion),
                              opacity: HistoryDepth.opacity(drawn.lift))
            }
            ChatView()
                // The sidebar's search keyboard must not lift the composer
                // in the strip of conversation left showing.
                .ignoresSafeArea(!docked && (reveal > 0 || closingAside) ? .keyboard : [], edges: .bottom)
                .allowsHitTesting(docked || reveal == 0)
                .accessibilityHidden(!docked && reveal > 0)
                // Beside the history the conversation is not made narrower:
                // that laid every line out again on each frame of the slide,
                // and the text and the field moved and flickered while it
                // ran (1.1.0 (226), Hachimoto さん 2026-10-29). It keeps the
                // whole width and its column, and only what stands in the
                // column moves over, by half the history's width, to the
                // middle of what remains (BesideShift). A move is drawn,
                // not laid out again, and the conversation itself is not
                // asked for again (1.1.0 (242)).
                //
                // Slid aside for the phone's history, the conversation stays
                // its size, in front (1.1.0 (272): 268's step back and down
                // is gone, Hachimoto さん 2026-11-13). Its paper and the
                // paper's shadow are under it and the veil over it, each over
                // the whole screen. Its corners are all its own, never
                // painted over (painted, they hid what the history showed
                // there, Hachimoto さん 2026-11-12, 263): the paper rounds
                // (PanelPaper), and so does the header's blur
                // (PanelHeaderBackdrop), and the history and the panel's
                // shadow show beside them as they are. Nothing over the whole
                // conversation is masked, blended or made see-through
                // (offscreen, its blur and glass would flatten; 1.1.0 (190)'s
                // blend turned it black beside another app's Picture in
                // Picture).
                .overlay {
                    if !docked && sidebarShown {
                        // The veil keeps to the panel's round corners.
                        RoundedRectangle(cornerRadius: ChatMetrics.panelRadius, style: .continuous)
                            .fill(Theme.panelVeil.opacity(ChatMetrics.panelVeil * drawn.slide))
                            .ignoresSafeArea()
                            .allowsHitTesting(false)
                            .accessibilityHidden(true)
                    }
                }
                .background {
                    if docked {
                        // Beside the history the conversation is a plain
                        // page, edged by the history's hairline.
                        RoundedRectangle(cornerRadius: 0, style: .continuous)
                            .fill(Theme.chatBackground)
                            .shadow(color: .clear, radius: 0)
                            .ignoresSafeArea()
                    } else {
                        PanelPaper()
                            .ignoresSafeArea()
                            .allowsHitTesting(false)
                            .accessibilityHidden(true)
                    }
                }
                .overlay {
                    // The whole strip closes, from the screen's top to its foot.
                    if !docked && sidebarShown {
                        Color.clear.contentShape(Rectangle()).ignoresSafeArea()
                            .onTapGesture { setOpen(false) }
                            .accessibilityElement()
                            .accessibilityLabel("会話に戻る")
                            .accessibilityAddTraits(.isButton)
                            .accessibilityIdentifier("history-close")
                    }
                }
                .offset(x: docked ? 0 : sidebarWidth * drawn.slide)
            if docked && (dockOpen || keepsDockedHistory) {
                // Over the conversation's leading edge, which it covers: it
                // slides in from there on the same spring as the column
                // moves over.
                HistoryView()
                    .frame(width: dockWidth)
                    .frame(maxHeight: .infinity)
                    .overlay(alignment: .trailing) {
                        Rectangle().fill(Theme.inputBorder)
                            .frame(width: 1 / displayScale)
                            .ignoresSafeArea()
                            .accessibilityHidden(true)
                    }
                    // Kept (preview only): put away out of sight instead.
                    .offset(x: keepsDockedHistory && !dockOpen ? -dockWidth : 0)
                    .allowsHitTesting(dockOpen)
                    .accessibilityHidden(!dockOpen)
                    .transition(reduceMotion ? AnyTransition.opacity : AnyTransition.move(edge: .leading))
                    // Read before the conversation, as when it lay under it.
                    .accessibilitySortPriority(1)
            }
        }
        #if POCKET_PREVIEW
        .overlay(alignment: .bottomTrailing) {
            if PreviewProbe.on("--dock-meter") {
                DockMeterReadout().modifier(DockFrameProbe(progress: docked && dockOpen ? 1 : 0))
            }
            if DrawerProbe.on { DrawerProbeReadout() }
            if DrawerFilm.on { DrawerFilmReadout() }
            // `--scroll-anatomy`: the conversation's scroll view, read
            // here, out of the conversation that is hidden from
            // accessibility while the history shows (1.1.0 (276)).
            if PreviewProbe.on("--scroll-anatomy") { ScrollAnatomyReadout().frame(width: 1, height: 1).allowsHitTesting(false) }
            // `--menu-ghost`: the layers where the model pill stands (1.1.0 (277)).
            if MenuGhostProbe.on { MenuGhostReadout().frame(width: 1, height: 1).allowsHitTesting(false) }
        }
        // `--history-reveal-on-tap`, `--drawer-film-on-tap`: the drawer held
        // or filmed once the UI check has read a little way up the chat
        // with its own finger and taps here (1.1.0 (276), Issue #14).
        .overlay(alignment: .topTrailing) {
            if PreviewDrawerGo.on { PreviewDrawerGo { previewGo() }.padding(.top, 8).padding(.trailing, 8) }
        }
        #endif
        .background { Theme.sidebar.ignoresSafeArea() }
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { containerWidth = $0 }
        .gesture(HistoryDrawerPan(isOpen: reveal > 0.5, enabled: !docked, onChanged: drag, onEnded: settle))
        .environment(\.historySidebar, sidebar)
        .environment(\.historyVisible, !docked && reveal > 0)
        .environment(\.historySlid, !docked && sidebarShown)
        .environment(\.historyBeside, docked ? dockOpen : nil)
        .environment(\.historyDockLayout, docked ? dockLayout : nil)
        .environment(\.historyBesideShift, docked && dockOpen ? dockWidth / 2 : 0)
        .onChange(of: docked, initial: true) { old, now in
            dockedNow = now
            // The drawer is the phone's: a window narrowed to it starts closed.
            if old != now {
                dragOrigin = nil; reveal = 0; sidebarShown = false; closingAside = false
                sidebar.slid = false
                motion.place(at: 0)
            }
        }
        .tint(Theme.tint)
        // A tap as each slide lands, open or closed.
        .sensoryFeedback(.impact(weight: .medium), trigger: settledOpen)
        .onAppear {
            // Each frame of the drawer, drawn as it comes: no animation of
            // SwiftUI's carries it, so none can run ahead of it.
            motion.draw = { frame in
                var transaction = Transaction()
                transaction.disablesAnimations = true
                withTransaction(transaction) { drawn = frame }
            }
            #if POCKET_PREVIEW
            if DrawerProbe.slow { motion.timeScale = 15 }
            if DrawerFilm.on { motion.manual = true }
            if DrawerProbe.on { motion.trace = { time, frame in DrawerProbe.shared.frame(time, frame) } }
            #endif
            sidebar.openAction = { dockedNow ? setDocked(true) : setOpen(true) }
            sidebar.toggleAction = { dockedNow ? setDocked(!dockOpen) : setOpen(true) }
            sidebar.selectAction = { open($0) }
            sidebar.composeAction = compose
            #if POCKET_PREVIEW
            // `--history-reveal 0.3`: the drawer held that far open, for the
            // UI check's look at the slid conversation's corners.
            if !docked, !PreviewDrawerGo.on, let held = PreviewHistoryReveal.value { previewHold(held) }
            #endif
        }
        #if POCKET_PREVIEW
        // `--drawer-film`: the drawer's moves, frame by frame, for the UI
        // check's film of them (DrawerFilm).
        .task {
            guard DrawerFilm.on, !docked else { return }
            await DrawerFilm.shared.run(DrawerFilm.Controls(
                width: { sidebarWidth },
                open: { setOpen(true) },
                close: { setOpen(false) },
                drag: { drag($0) },
                release: { settle($0, $1) },
                select: {
                    // The longest chat other than the open one.
                    let others = chats.threads.filter { $0.id != chats.selectedID }
                    guard let id = others.max(by: { $0.messages.count < $1.messages.count })?.id else { return }
                    open(id)
                },
                step: { motion.advance(by: $0) }))
        }
        // `--drawer-stall <ms>`: the main thread kept busy as a slide begins,
        // as a chat changing under it can on the phone (DrawerProbe).
        .background { DrawerStall(reveal: reveal) }
        #endif
        .task { await AuroraOrbView.prepare() }
    }

    #if POCKET_PREVIEW
    private func previewHold(_ held: CGFloat) {
        sidebarShown = true; sidebar.slid = true; reveal = held; motion.place(at: held)
    }

    /// The UI check's tap (PreviewDrawerGo): the film starts, or the drawer
    /// is held as `--history-reveal` asks.
    private func previewGo() {
        if DrawerFilm.on { DrawerFilm.shared.go(); return }
        if !docked, let held = PreviewHistoryReveal.value { previewHold(held) }
    }
    #endif

    private func drag(_ translation: CGFloat) {
        // A slide still on its way is caught where it is drawn, not where
        // it was heading: the conversation would have jumped there under
        // the finger.
        let origin = dragOrigin ?? (sidebarShown ? min(1, max(0, motion.slide)) : reveal)
        dragOrigin = origin
        if !sidebarShown { showSidebar(true) }
        reveal = min(1, max(0, origin + translation / sidebarWidth))
        motion.hold(at: reveal, reduced: reduceMotion)
        // Swiped all the way shut under the finger: the history's search
        // keyboard goes away now, so the composer stays put for it as a
        // close by the button does (cleared as the sidebar goes).
        if reveal == 0 && origin > 0 { closingAside = true }
    }

    /// Settle where the finger was heading, carrying its speed into the spring.
    private func settle(_ translation: CGFloat, _ velocity: CGFloat) {
        let origin = dragOrigin ?? reveal
        dragOrigin = nil
        let current = min(1, max(0, origin + translation / sidebarWidth))
        let projected = current + velocity * 0.2 / sidebarWidth
        setOpen(projected > 0.5, velocity: velocity)
    }

    /// `velocity`: the finger's, in points a second, as it let go.
    private func setOpen(_ open: Bool, velocity: CGFloat? = nil) {
        let target: CGFloat = open ? 1 : 0
        if open { showSidebar(true) } else if reveal > 0 || motion.slide > 0 { closingAside = true }
        settledOpen = open
        reveal = target
        #if POCKET_PREVIEW
        DrawerProbe.shared.slide(open: open)
        DrawerProbe.shared.armStall()
        if DrawerProbe.swiftUISpring {
            // 270's way, for the UI check to compare: SwiftUI's spring.
            withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.drawer, completionCriteria: .removed) {
                drawn = HistoryDrawerMotion.Frame(slide: target, lift: target)
            } completion: {
                if reveal == 0 && dragOrigin == nil { showSidebar(false) }
            }
            return
        }
        #endif
        motion.run(to: target, velocity: velocity.map { $0 / sidebarWidth }, reduced: reduceMotion) {
            #if POCKET_PREVIEW
            DrawerProbe.shared.slideEnded()
            #endif
            // A new slide may have started before this one finished.
            if reveal == 0 && dragOrigin == nil { showSidebar(false) }
        }
    }

    /// The sidebar and the slid panel's dressing come and go without
    /// animation, whatever transaction the slide is asked for in: the
    /// conversation's paper rounds and squares its corners on this
    /// (ConversationPaper), never as the drawer moves.
    private func showSidebar(_ shown: Bool) {
        var transaction = Transaction(animation: nil)
        transaction.disablesAnimations = true
        withTransaction(transaction) {
            sidebarShown = shown
            if !shown { closingAside = false }
        }
        sidebar.slid = shown
    }

    /// The history beside the conversation, shown or put away; kept for the
    /// next launch.
    private func setDocked(_ open: Bool) {
        guard open != dockOpen else { return }
        UserDefaults.standard.set(open, forKey: HistoryDock.storageKey)
        #if POCKET_PREVIEW
        let metered = PreviewProbe.on("--dock-meter")
        if metered { SettingsSlideMeter.shared.asked(); SettingsSlideMeter.shared.began() }
        #endif
        withAnimation(reduceMotion ? ChatMotion.reducedMenu : ChatMotion.drawer,
                      completionCriteria: .removed) {
            dockOpen = open
        } completion: {
            #if POCKET_PREVIEW
            if metered { SettingsSlideMeter.shared.ended() }
            #endif
        }
    }

    /// Beside the conversation the history stays where it is.
    private func open(_ id: UUID) {
        guard !chats.isGenerating || id == chats.selectedID else { return }
        chats.select(id)
        if !dockedNow { setOpen(false) }
    }
    private func compose() {
        guard !chats.isGenerating else { return }
        chats.newChat()
        if !dockedNow { setOpen(false) }
    }
}

#if POCKET_PREVIEW
/// The dock's motion frame by frame, for the UI check's meter
/// (`--dock-meter`, SettingsSlideMeter): on the meter's own dot, on the
/// history's spring, its body runs for each frame of the slide and changes
/// nothing. As a geometry effect on the conversation it was also asked for
/// on SwiftUI's render thread, where the meter's main-thread check stopped
/// the app (UI check run 40840586355, as the field was typed in).
private struct DockFrameProbe: ViewModifier, Animatable {
    var progress: CGFloat
    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }
    func body(content: Content) -> some View {
        SettingsSlideMeter.shared.frame()
        return content
    }
}

/// How far `--history-reveal <fraction>` holds the drawer open, if asked.
private enum PreviewHistoryReveal {
    static let value: CGFloat? = {
        let arguments = ProcessInfo.processInfo.arguments
        guard let index = arguments.firstIndex(of: "--history-reveal"), index + 1 < arguments.count,
              let fraction = Double(arguments[index + 1]) else { return nil }
        return CGFloat(min(max(fraction, 0.05), 1))
    }()
}

/// The last slide's line from the meter, for the UI check.
private struct DockMeterReadout: View {
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("history-dock-meter")
            .accessibilityLabel(SettingsSlideMeter.shared.summary ?? "none")
            .allowsHitTesting(false)
    }
}
#endif

/// The iPad's history beside the conversation (1.1.0 (226), Hachimoto さん
/// 2026-10-28): the header's button shows it and puts it away, and while it
/// shows the conversation on its right is used as ever, typed in and sent
/// from. The phone keeps the drawer.
enum HistoryDock {
    static let storageKey = "history-docked-open-v1"
    /// About a third of the width, as an iPad's own sidebars.
    static func width(_ container: CGFloat) -> CGFloat { min(max(container * 0.3, 300), 360) }
    /// The conversation's column, its side gutters included (1.1.0 (242)):
    /// what is left beside the history, and no more than 760pt, so that in
    /// landscape the history comes and goes beside it with room to spare.
    /// It depends on the screen's width alone, never on whether the history
    /// shows, so no line of the conversation is laid out again when it does.
    static let maxColumn: CGFloat = 760
    static func column(_ container: CGFloat) -> CGFloat { min(container - width(container), maxColumn) }
}

/// How the conversation stands beside the iPad's history (1.1.0 (242)).
struct HistoryDockLayout: Equatable {
    /// The history's width.
    var width: CGFloat
    /// The conversation's column, its gutters included (HistoryDock.column).
    var column: CGFloat
}

/// Moves what stands in the conversation's column over with the iPad's
/// history (1.1.0 (242)): drawn there, not laid out again. Only this
/// modifier reads how far, so the conversation is not asked for again
/// when the history comes or goes, and the move rides the history's spring.
struct BesideShift: ViewModifier {
    /// 2 for what keeps to the conversation's leading edge, beside the
    /// history's.
    var factor: CGFloat = 1
    @Environment(\.historyBesideShift) private var shift
    func body(content: Content) -> some View {
        content.offset(x: shift * factor)
    }
}

/// Lets the conversation ask for the sidebar, and the sidebar open a
/// conversation, without handing either view new closures every frame.
@MainActor final class HistorySidebar {
    fileprivate var openAction: () -> Void = {}
    fileprivate var toggleAction: () -> Void = {}
    fileprivate var selectAction: (UUID) -> Void = { _ in }
    fileprivate var composeAction: () -> Void = {}
    /// The phone's history out from behind the conversation, its close
    /// included (`historySlid`), read where nothing need be drawn again.
    fileprivate(set) var slid = false
    func open() { openAction() }
    /// The header's button: on the phone it opens the drawer; beside the
    /// conversation it shows the history or puts it away.
    func toggle() { toggleAction() }
    func select(_ id: UUID) { selectAction(id) }
    func compose() { composeAction() }
}

extension EnvironmentValues {
    @Entry var historySidebar: HistorySidebar? = nil
    /// True while any of the history sidebar is showing over the phone's
    /// conversation (never while it stands beside it).
    @Entry var historyVisible = false
    /// True from the first frame of a slide aside for the phone's history
    /// until the conversation has settled back in place, the closing slide
    /// included (`historyVisible` ends as it begins): its paper's corners
    /// are round all that time (ConversationPaper), and since 1.1.0 (268)
    /// its header blur's top ones (PanelHeaderBackdrop).
    @Entry var historySlid = false
    /// On an iPad's full width, whether the history stands beside the
    /// conversation; nil with the phone's drawer.
    @Entry var historyBeside: Bool? = nil
    /// On an iPad's full width, the history's width and the conversation's
    /// column; nil with the phone's drawer.
    @Entry var historyDockLayout: HistoryDockLayout? = nil
    /// How far the conversation's column stands over beside the iPad's
    /// history: half the history's width while it shows, else 0
    /// (BesideShift).
    @Entry var historyBesideShift: CGFloat = 0
}

/// The conversation's paper (PaperBackground), in place. Slid aside for the
/// phone's history it is not drawn, and the panel's paper shows instead
/// (PanelPaper): that one rounds with the panel, so what the history shows
/// beside the bottom corners, the panel's shadow and the new chat button's
/// among it, runs on to the curve (1.1.0 (264)), and it is laid out over the
/// whole screen outside the conversation (1.1.0 (268)). The two change
/// places as a slide begins and once it has ended, never as it moves:
/// `historySlid` only ever changes without animation
/// (ChatNavigationView.showSidebar), and both read it. Both are laid out from
/// the screen's top leading corner, so the paper's grain does not move as
/// they change places. No transaction here takes an animation away: in
/// 1.1.0 (264) that also took the paper's own move with the conversation,
/// and as the history closed the paper went back in place at once, ahead of
/// the rest, and hid the history in one frame (Hachimoto さん's recording,
/// 2026-11-12).
struct ConversationPaper: View {
    @Environment(\.historySlid) private var slid
    var body: some View {
        PaperBackground()
            .opacity(slid ? 0 : 1)
            .ignoresSafeArea()
    }
}

/// The phone's history behind the conversation, a little smaller and
/// fainter while the drawer moves (1.1.0 (272)). Smaller about its middle,
/// it stood back from the screen's edges, and SwiftUI then let nothing in
/// it reach past its safe area, as 268's conversation stepping back had
/// shown (UI check run 43281887443): its scroll view stopped at the
/// status bar and the home indicator, and the soft blur under its title
/// and its buttons, with the chats under them, ended in a straight line
/// about 70pt from the screen's top and 45pt from its foot, only while the
/// drawer moved (Hachimoto さん's recording, 2026-11-13, fielua-reports
/// Issue #12). So it is laid out over the whole screen and past its top,
/// its foot and its leading edge, as far as its size at the back pulls
/// them in (HistoryDepth.reach), with the screen's insets, the keyboard's
/// too, given as its own (safeAreaPadding): nothing in it has to reach
/// past anything, and at every size its blur runs on to the screen's
/// edges. Its title, chats and buttons stand where they stood, and it is
/// smaller about the same point, the middle of where it stood. Only the
/// scale and the fade change as it moves: it is not laid out again.
///
/// The insets are measured, not asked for: inside a view that ignores the
/// safe area, as the whole screen's reader must, SwiftUI reports none (UI
/// check run 43437937904: the title went up under the status bar). The
/// outer reader stands where the history stood, in the safe area, the
/// keyboard's too, and how far it stands in from the screen is the insets.
private struct HistoryAtBack: View {
    let width: CGFloat
    let scale: CGFloat
    let opacity: Double

    var body: some View {
        GeometryReader { inside in
            GeometryReader { screen in
                placed(Placement(safe: inside.frame(in: .global), screen: screen.frame(in: .global), width: width))
            }
            .ignoresSafeArea()
        }
    }

    private func placed(_ placement: Placement) -> some View {
        HistoryView()
            .safeAreaPadding(placement.padding)
            .frame(width: placement.size.width, height: placement.size.height)
            .scaleEffect(scale, anchor: placement.anchor)
            .opacity(opacity)
            .position(placement.center)
    }

    /// Where the history is laid out, worked out apart from the view so
    /// the compiler's checks stay quick (UI check run 43447643074 ran out
    /// of time compiling it written inside the reader).
    struct Placement {
        /// The screen's insets, the keyboard's too, and the reach.
        let padding: EdgeInsets
        let size: CGSize
        /// The middle of where it stood in the safe area, in its own frame.
        let anchor: UnitPoint
        /// Its middle in the screen's frame.
        let center: CGPoint

        init(safe: CGRect, screen: CGRect, width: CGFloat) {
            // How far the safe area stands in from the screen's edges.
            let top: CGFloat = max(safe.minY - screen.minY, 0)
            let leading: CGFloat = max(safe.minX - screen.minX, 0)
            let bottom: CGFloat = max(screen.maxY - safe.maxY, 0)
            let height: CGFloat = screen.height
            let middle = CGPoint(x: leading + width / 2, y: (top + height - bottom) / 2)
            let reach: EdgeInsets = HistoryDepth.reach(from: middle, height: height)
            let laidWidth: CGFloat = reach.leading + leading + width
            let laidHeight: CGFloat = reach.top + height + reach.bottom
            padding = EdgeInsets(top: reach.top + top, leading: reach.leading + leading,
                                 bottom: reach.bottom + bottom, trailing: 0)
            size = CGSize(width: laidWidth, height: laidHeight)
            anchor = UnitPoint(x: (reach.leading + middle.x) / laidWidth, y: (reach.top + middle.y) / laidHeight)
            center = CGPoint(x: laidWidth / 2 - reach.leading, y: laidHeight / 2 - reach.top)
        }
    }
}

/// The slid panel's paper, round-cornered, and the soft shadow it casts on
/// the history (1.1.0 (268)), under the conversation, over the whole screen. In
/// place only the shadowed fill is drawn, out of sight: the conversation's
/// own paper covers it (ConversationPaper), and the grain is not drawn
/// twice.
private struct PanelPaper: View {
    @Environment(\.historySlid) private var slid
    var body: some View {
        let shape = RoundedRectangle(cornerRadius: ChatMetrics.panelRadius, style: .continuous)
        shape.fill(Theme.chatBackground)
            .shadow(color: ChatMetrics.panelShadow, radius: ChatMetrics.panelShadowRadius)
            .overlay {
                PaperBackground()
                    .clipShape(shape)
                    .opacity(slid ? 1 : 0)
            }
    }
}

/// The header's blur (ChatChromeBackdrop), its top corners round with the
/// slid panel's (1.1.0 (268)). They round and square on the same unanimated
/// turns as the paper's (ConversationPaper, `historySlid`), and only this
/// small view reads it, so the conversation is not asked for again when a
/// slide begins or ends. Until 268 those corners were painted in the
/// sidebar's colour over the panel: with the conversation stepping down,
/// the paint would have slid over the history's header.
struct PanelHeaderBackdrop: View {
    @Environment(\.historySlid) private var slid
    var body: some View {
        ChatChromeBackdrop(edge: .top, topRadius: slid ? ChatMetrics.panelRadius : 0)
    }
}

/// The conversation's scroll view, its corners round with the slid panel's
/// (1.1.0 (276), fielua-reports Issue #14). It runs from the screen's top
/// to its foot, under the header and under the composer, and its square
/// corners went on past the paper's round ones: read a little way up from
/// the end, the chats under the composer, and the soft blur over them,
/// stood on the history beside the panel's bottom corners, to a straight
/// edge, as the history opened and closed (Hachimoto さん's screenshots,
/// 2026-11-14; at the end nothing is under the composer, and it looked
/// right). The scroll view clips as it did, to round corners while the
/// panel is slid, on the same unanimated turns as the paper's
/// (ConversationPaper) and the header blur's (PanelHeaderBackdrop). It is
/// the scroll view's own clip, not a mask over the conversation, and only
/// this small view in it reads `historySlid`: the conversation is not asked
/// for again, and nothing moves in it.
struct PanelScrollCorners: View {
    @Environment(\.historySlid) private var slid
    var body: some View {
        PanelScrollClip(round: slid && !Self.off)
            .frame(width: 1, height: 1)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }

    /// Preview only (`--panel-scroll-corners-off`): square as in 275, for
    /// the UI check to compare.
    private static var off: Bool {
        #if POCKET_PREVIEW
        PreviewProbe.on("--panel-scroll-corners-off")
        #else
        false
        #endif
    }
}

private struct PanelScrollClip: UIViewRepresentable {
    let round: Bool
    func makeUIView(context: Context) -> PanelScrollClipView { PanelScrollClipView() }
    func updateUIView(_ view: PanelScrollClipView, context: Context) { view.round = round }
}

/// Finds the scroll view it is drawn in, as ElasticBubble does, and rounds
/// its corners where it reaches the screen's top or foot.
final class PanelScrollClipView: UIView {
    var round = false {
        didSet {
            guard round != oldValue else { return }
            apply()
            // The keyboard's room goes as a slide begins (the conversation
            // ignores it then), after this update: once more, laid out.
            DispatchQueue.main.async { [weak self] in self?.apply() }
        }
    }
    private weak var scroll: UIScrollView?

    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        isAccessibilityElement = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil else { return }
        var ancestor = superview
        while let view = ancestor {
            if let found = view as? UIScrollView { scroll = found; break }
            ancestor = view.superview
        }
        apply()
    }

    private func apply() {
        guard let scroll, let window = scroll.window else { return }
        var corners: CACornerMask = []
        if round {
            let seen = scroll.convert(scroll.bounds, to: window)
            let screen = window.bounds
            if abs(seen.width - screen.width) < 1 {
                if seen.minY <= screen.minY + 1 { corners.formUnion([.layerMinXMinYCorner, .layerMaxXMinYCorner]) }
                if seen.maxY >= screen.maxY - 1 { corners.formUnion([.layerMinXMaxYCorner, .layerMaxXMaxYCorner]) }
            }
        }
        let radius: CGFloat = corners.isEmpty ? 0 : ChatMetrics.panelRadius
        let layer = scroll.layer
        guard layer.cornerRadius != radius || (!corners.isEmpty && layer.maskedCorners != corners) else { return }
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        layer.cornerCurve = .continuous
        if !corners.isEmpty { layer.maskedCorners = corners }
        layer.cornerRadius = radius
        CATransaction.commit()
    }
}

/// A horizontal pan anywhere on the screen: rightward opens the sidebar,
/// leftward closes it. Vertical scrolling waits for it to fail, which it
/// does as soon as the movement is mostly vertical, so a sideways swipe
/// never scrolls the conversation. Horizontal strips (draft attachments)
/// keep their own swipes.
private struct HistoryDrawerPan: UIGestureRecognizerRepresentable {
    let isOpen: Bool
    /// Off while the history stands beside the conversation.
    let enabled: Bool
    let onChanged: (CGFloat) -> Void
    let onEnded: (CGFloat, CGFloat) -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.delegate = context.coordinator
        return pan
    }
    func updateUIGestureRecognizer(_ pan: UIPanGestureRecognizer, context: Context) {
        context.coordinator.isOpen = isOpen
        pan.isEnabled = enabled
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        let translation = pan.translation(in: pan.view).x
        switch pan.state {
        case .began, .changed: onChanged(translation)
        case .ended: onEnded(translation, pan.velocity(in: pan.view).x)
        case .cancelled, .failed: onEnded(translation, 0)
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var isOpen = false
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            guard abs(velocity.x) > abs(velocity.y) * 1.2 else { return false }
            return isOpen ? velocity.x < 0 : velocity.x > 0
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldBeRequiredToFailBy other: UIGestureRecognizer) -> Bool {
            guard let scroll = other.view as? UIScrollView, other === scroll.panGestureRecognizer else { return false }
            return scroll.contentSize.width <= scroll.bounds.width + 1
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            var view = touch.view
            while let current = view {
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

/// Keep the system edge-pop gesture when the chat draws its own contact header.
struct ChatBackSwipe: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> Controller { Controller() }
    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.scheduleConnection()
    }

    final class Controller: UIViewController, UIGestureRecognizerDelegate {
        private weak var connectedNavigation: UINavigationController?
        private var connections: [GestureConnection] = []
        private var connectionScheduled = false

        private final class GestureConnection {
            weak var gesture: UIGestureRecognizer?
            weak var previousDelegate: UIGestureRecognizerDelegate?
            init(_ gesture: UIGestureRecognizer) {
                self.gesture = gesture
                previousDelegate = gesture.delegate
            }
        }

        override func loadView() {
            view = UIView()
            view.isUserInteractionEnabled = false
        }
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            scheduleConnection()
        }
        override func didMove(toParent parent: UIViewController?) {
            super.didMove(toParent: parent)
            scheduleConnection()
        }
        override func viewDidLayoutSubviews() {
            super.viewDidLayoutSubviews()
            scheduleConnection()
        }
        override func viewDidDisappear(_ animated: Bool) {
            super.viewDidDisappear(animated)
            disconnect()
        }

        // A SwiftUI background controller may appear before its destination is
        // connected to UIKit's navigation controller. Connect after that update,
        // and use the public containment tree if it is not a direct ancestor.
        func scheduleConnection() {
            guard !connectionScheduled else { return }
            connectionScheduled = true
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.connectionScheduled = false
                self.connect()
            }
        }
        private func connect() {
            guard let window = viewIfLoaded?.window,
                  let navigation = navigationController ?? findNavigation(in: window.rootViewController),
                  navigation.viewControllers.count > 1 else { return }
            if connectedNavigation !== navigation { disconnect() }
            connectedNavigation = navigation
            var gestures = [navigation.interactivePopGestureRecognizer].compactMap { $0 }
            if #available(iOS 26.0, *), let contentPop = navigation.interactiveContentPopGestureRecognizer {
                if let edgePop = navigation.interactivePopGestureRecognizer { contentPop.require(toFail: edgePop) }
                gestures.append(contentPop)
            }
            for gesture in gestures {
                if !connections.contains(where: { $0.gesture === gesture }) {
                    connections.append(GestureConnection(gesture))
                    #if DEBUG
                    gesture.addTarget(self, action: #selector(traceBackGesture(_:)))
                    #endif
                }
                gesture.delegate = self
                if gesture.state == .possible { gesture.isEnabled = true }
            }
        }
        private func findNavigation(in controller: UIViewController?) -> UINavigationController? {
            guard let controller else { return nil }
            if let navigation = controller as? UINavigationController,
               navigation.viewControllers.count > 1,
               navigation.viewIfLoaded?.window === viewIfLoaded?.window { return navigation }
            for child in controller.children.reversed() {
                if let navigation = findNavigation(in: child) { return navigation }
            }
            return nil
        }
        private func disconnect() {
            for connection in connections {
                #if DEBUG
                connection.gesture?.removeTarget(self, action: #selector(traceBackGesture(_:)))
                #endif
                if connection.gesture?.delegate === self {
                    connection.gesture?.delegate = connection.previousDelegate
                }
            }
            connections.removeAll()
            connectedNavigation = nil
        }
        #if DEBUG
        @objc private func traceBackGesture(_ gesture: UIGestureRecognizer) {
            guard ProcessInfo.processInfo.arguments.contains("--gesture-diagnostics"),
                  gesture.state == .began || gesture.state == .ended || gesture.state == .cancelled else { return }
            let coordinator = connectedNavigation?.transitionCoordinator
            print("Back gesture state=\(gesture.state.rawValue) controllers=\(connectedNavigation?.viewControllers.count ?? 0) progress=\(coordinator?.percentComplete ?? 0)")
            if gesture.state == .began {
                coordinator?.notifyWhenInteractionChanges { context in
                    print("Back interaction cancelled=\(context.isCancelled) progress=\(context.percentComplete)")
                }
            }
        }
        #endif
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let navigation = connectedNavigation else { return false }
            guard navigation.viewControllers.count > 1, navigation.transitionCoordinator == nil else { return false }
            if let pan = gestureRecognizer as? UIPanGestureRecognizer {
                let velocity = pan.velocity(in: navigation.view)
                return velocity.x > abs(velocity.y)
            }
            return true
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            guard let navigationView = connectedNavigation?.view else { return false }
            // Keep edge swipes away from the contact controls and composer.
            let y = touch.location(in: navigationView).y
            return y > navigationView.safeAreaInsets.top + 100
                && y < navigationView.bounds.height - navigationView.safeAreaInsets.bottom - 72
        }
    }
}
