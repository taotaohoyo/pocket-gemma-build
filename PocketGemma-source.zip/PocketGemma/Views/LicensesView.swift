import SwiftUI

/// The open-source licenses of the code and fonts the app ships with, from
/// the packages' own files: the device build copies each package's LICENSE
/// into ThirdPartyLicenses (scripts/build-ios.sh), and SwiftMath's math
/// fonts carry theirs in its resource bundle.
struct LicensesView: View {
    var body: some View {
        List(OpenSourceLicense.all) { item in
            NavigationLink {
                LicenseTextView(item: item)
            } label: {
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name)
                    Text(item.license).font(.footnote).foregroundStyle(.secondary)
                }
            }
            .accessibilityIdentifier("license-\(item.file)")
        }
        // Over 設定's glass, as its other pages.
        .scrollContentBackground(.hidden)
        .navigationTitle("オープンソースライセンス").navigationBarTitleDisplayMode(.inline)
    }
}

private struct LicenseTextView: View {
    let item: OpenSourceLicense
    @State private var text: String?

    var body: some View {
        ScrollView {
            Text(verbatim: text ?? "")
                .font(.footnote)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
                .accessibilityIdentifier("license-text")
        }
        .navigationTitle(item.name).navigationBarTitleDisplayMode(.inline)
        .task { text = item.text() ?? "このビルドにはライセンス文が含まれていません。" }
    }
}

struct OpenSourceLicense: Identifiable {
    let name: String
    let license: String
    /// The file's name in ThirdPartyLicenses, or in SwiftMath's math font
    /// bundle when `inMathFonts`.
    let file: String
    var inMathFonts = false
    var id: String { file }

    static let all = [
        OpenSourceLicense(name: "LiteRT-LM", license: "Apache License 2.0", file: "LiteRT-LM.txt"),
        OpenSourceLicense(name: "SwiftMath", license: "MIT License", file: "SwiftMath.txt"),
        OpenSourceLicense(name: "Latin Modern Math・TeX Gyre Termes Math", license: "GUST Font License",
                          file: "GUST-FONT-LICENSE.txt", inMathFonts: true),
        OpenSourceLicense(name: "XITS Math ほかの数式フォント", license: "SIL Open Font License 1.1",
                          file: "OFL.txt", inMathFonts: true),
        OpenSourceLicense(name: "iosMath（MathChat）", license: "MIT License", file: "LICENSE", inMathFonts: true),
        OpenSourceLicense(name: "ZIPFoundation", license: "MIT License", file: "ZIPFoundation.txt"),
    ]

    func text() -> String? {
        let folder = inMathFonts ? Self.mathFonts : Bundle.main.bundleURL.appendingPathComponent("ThirdPartyLicenses")
        guard let url = folder?.appendingPathComponent(file) else { return nil }
        return try? String(contentsOf: url, encoding: .utf8)
    }

    /// SwiftMath's fonts, inside its package's resource bundle in the app.
    private static let mathFonts: URL? = {
        let items = (try? FileManager.default.contentsOfDirectory(at: Bundle.main.bundleURL,
                                                                  includingPropertiesForKeys: nil)) ?? []
        return items.filter { $0.pathExtension == "bundle" }
            .map { $0.appendingPathComponent("mathFonts.bundle") }
            .first { FileManager.default.fileExists(atPath: $0.path) }
    }()
}
