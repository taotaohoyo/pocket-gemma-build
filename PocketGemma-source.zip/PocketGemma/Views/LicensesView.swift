import SwiftUI

/// The open-source licenses of the code and fonts the app ships with, from
/// the packages' own files: the device build copies each package's LICENSE
/// into ThirdPartyLicenses (scripts/build-ios.sh), and SwiftMath's math
/// fonts carry theirs in its resource bundle.
struct LicensesView: View {
    @Environment(\.openSettingsPage) private var openPage
    var body: some View {
        let _ = SettingsSlideMeter.drew("ライセンス")
        // Rows in one of 設定's groups, as on its other pages. A List laid
        // its rows out again while the page faded in (its cells took their
        // own heights and margins only once shown, 2026-10-25); these are
        // laid out once, before the page comes.
        ScrollView {
            SettingsGroup {
                ForEach(OpenSourceLicense.all) { item in
                    if item.id != OpenSourceLicense.all.first?.id { Divider().padding(.leading, 16) }
                    row(item)
                }
            }
            .padding(20)
        }
        .settingsScroll()
    }

    private func row(_ item: OpenSourceLicense) -> some View {
        // Each text opens as 設定's next page, over the same glass.
        Button { openPage(.license(item.file)) } label: {
            HStack(spacing: 8) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name)
                    Text(item.license).font(.footnote).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.tertiary)
                    .accessibilityHidden(true)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 11)
            .frame(minHeight: 52)
            .contentShape(Rectangle())
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityIdentifier("license-\(item.file)")
    }
}

struct LicenseTextView: View {
    let item: OpenSourceLicense?
    @State private var text: String?
    init(file: String) { item = OpenSourceLicense.all.first { $0.file == file } }

    var body: some View {
        ScrollView {
            Text(verbatim: text ?? "")
                .font(.footnote)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(20)
                .accessibilityIdentifier("license-text")
        }
        .settingsScroll()
        .task { text = item?.text() ?? "このビルドにはライセンス文が含まれていません。" }
    }
}

struct OpenSourceLicense: Identifiable {
    let name: String
    let license: String
    /// The file's name in ThirdPartyLicenses, or in SwiftMath's math font
    /// bundle when `inMathFonts`.
    let file: String
    var inMathFonts = false
    var id: String { file }

    static let all = [
        OpenSourceLicense(name: "LiteRT-LM", license: "Apache License 2.0", file: "LiteRT-LM.txt"),
        OpenSourceLicense(name: "SwiftMath", license: "MIT License", file: "SwiftMath.txt"),
        OpenSourceLicense(name: "Latin Modern Math・TeX Gyre Termes Math", license: "GUST Font License",
                          file: "GUST-FONT-LICENSE.txt", inMathFonts: true),
        OpenSourceLicense(name: "XITS Math ほかの数式フォント", license: "SIL Open Font License 1.1",
                          file: "OFL.txt", inMathFonts: true),
        OpenSourceLicense(name: "iosMath（MathChat）", license: "MIT License", file: "LICENSE", inMathFonts: true),
        OpenSourceLicense(name: "ZIPFoundation", license: "MIT License", file: "ZIPFoundation.txt"),
    ]

    func text() -> String? {
        let folder = inMathFonts ? Self.mathFonts : Bundle.main.bundleURL.appendingPathComponent("ThirdPartyLicenses")
        guard let url = folder?.appendingPathComponent(file) else { return nil }
        return try? String(contentsOf: url, encoding: .utf8)
    }

    /// SwiftMath's fonts, inside its package's resource bundle in the app.
    private static let mathFonts: URL? = {
        let items = (try? FileManager.default.contentsOfDirectory(at: Bundle.main.bundleURL,
                                                                  includingPropertiesForKeys: nil)) ?? []
        return items.filter { $0.pathExtension == "bundle" }
            .map { $0.appendingPathComponent("mathFonts.bundle") }
            .first { FileManager.default.fileExists(atPath: $0.path) }
    }()
}
