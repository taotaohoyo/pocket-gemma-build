import SwiftUI
import PocketCore

/// The registered PC's models in the composer's model menu and the Smart
/// Mode genre menu (PCと接続, 1.1.0 (253)): a submenu named after the PC,
/// each model a checkable item that starts a chat answered by it, as the
/// phone's models start theirs. Nothing without a registered PC. Its own
/// view, so the chat's menus stay as shallow as they were (LAUNCH STACK).
struct PCModelMenuSection: View {
    @ObservedObject private var link = PCLinkStore.shared
    let current: PCChatTarget?
    let choose: (PCChatTarget) -> Void

    var body: some View {
        if let pc = link.paired {
            Section {
                Menu {
                    ForEach(link.models) { model in
                        Toggle(isOn: Binding(get: { current?.pcID == pc.pcID && current?.model == model.name },
                                             set: { if $0 { choose(PCChatTarget(pcID: pc.pcID, pcName: pc.pcName, model: model.name)) } })) {
                            Text(verbatim: model.shortName)
                            let detail = PCLinkStore.detail(model)
                            if !detail.isEmpty { Text(verbatim: detail) }
                        }
                        .accessibilityIdentifier("model-menu-pc-\(model.name)")
                    }
                    Section {
                        Button { link.refresh() } label: {
                            Text(link.models.isEmpty ? "PCのモデルを読み込む" : "一覧を更新")
                            Image(systemName: "arrow.clockwise")
                        }
                        .accessibilityIdentifier("model-menu-pc-refresh")
                    }
                } label: {
                    Text(verbatim: pc.pcName)
                    Text(subtitle(pc))
                    Image(systemName: "desktopcomputer")
                }
                .accessibilityIdentifier("model-menu-pc")
            }
        }
    }

    private func subtitle(_ pc: PCPairedPC) -> String {
        if let current, current.pcID == pc.pcID { return String(localized: "\(current.shortModel)を使用中") }
        switch link.connection {
        case .connected: return String(localized: "PCのモデル")
        case .checking: return String(localized: "確かめています…")
        default: return String(localized: "接続できません")
        }
    }
}

/// A PC chat's line under its model's name when the PC can't answer now,
/// so a question isn't sent into nothing. Quiet while it answers.
struct PCChatStateNote: View {
    @ObservedObject private var link = PCLinkStore.shared
    let target: PCChatTarget

    var body: some View {
        if let text {
            Text(text)
                .font(.system(size: 11)).foregroundStyle(Theme.caution)
                .multilineTextAlignment(.center)
                .accessibilityIdentifier("chat-pc-note")
        }
    }

    private var text: String? {
        guard link.paired?.pcID == target.pcID else { return String(localized: "このPCは登録されていません") }
        switch link.connection {
        case .unreachable: return String(localized: "PCに接続できません")
        case .wrongPC: return String(localized: "証明書が違うため接続をやめました")
        case .revoked: return String(localized: "PCで登録が削除されました")
        default: return nil
        }
    }
}

extension PCChatTarget {
    /// The model's name for the composer's pill, kept short.
    var pillName: String {
        let name = shortModel
        return name.count > 18 ? String(name.prefix(17)) + "…" : name
    }
}
