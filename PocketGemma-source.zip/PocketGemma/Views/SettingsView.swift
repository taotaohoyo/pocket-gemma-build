import SwiftUI
import UIKit
import UserNotifications

/// 設定 (2026-10-23, 設定画面UIリニューアル): a Liquid Glass sheet with the
/// app's name large at the top and six rows, each opening its page in the
/// same sheet. モデル管理 is the model list as it was (ModelView).
enum SettingsPage: Hashable {
    case models, keyboard, notifications, developer, about, licenses
    /// One license's text, by its file, from オープンソースライセンス.
    case license(String)

    /// The pages the six rows open (PCと接続 has none yet), in their order.
    static let measured: [SettingsPage] = [.models, .keyboard, .notifications, .about, .licenses]

    var title: String {
        switch self {
        case .models: "モデル管理"
        case .keyboard: "キーボード"
        case .notifications: "通知"
        case .developer: "開発者設定"
        case .about: "Fieluaの情報"
        case .licenses: "オープンソースライセンス"
        case .license(let file): OpenSourceLicense.all.first { $0.file == file }?.name ?? ""
        }
    }
}

/// Where the sheet opens: on its six rows, or, from the chat, on モデル管理
/// (at the web search card when the search note asked for the key).
enum SettingsStart {
    case home, models, webSearch
}

extension EnvironmentValues {
    /// Closes the whole sheet from any of its pages.
    @Entry var closeSettings = SettingsClose()
    /// Opens a page over the one showing, in the same sheet.
    @Entry var openSettingsPage = SettingsOpen()
    /// A page's list says how far it has scrolled, for the blur under the bar.
    @Entry var settingsScrolled = SettingsScrolled()
    /// The page is the one in view and at rest: not sliding in or out, nor
    /// carried by a swipe. キーボード's phones play only then.
    @Entry var settingsPageInView = true
}

// What the pages ask of the sheet, each one value for the whole visit: a
// closure made anew whenever the sheet changed counted as a new value, and
// every row and page drew again at the start of each slide.

struct SettingsClose: Equatable {
    fileprivate weak var navigation: SettingsNavigation?
    @MainActor func callAsFunction() { navigation?.dismiss() }
    static func == (a: Self, b: Self) -> Bool { a.navigation === b.navigation }
}

struct SettingsOpen: Equatable {
    fileprivate weak var navigation: SettingsNavigation?
    @MainActor func callAsFunction(_ page: SettingsPage) { navigation?.open(page) }
    static func == (a: Self, b: Self) -> Bool { a.navigation === b.navigation }
}

struct SettingsScrolled: Equatable {
    fileprivate weak var blur: SettingsBlur?
    fileprivate var depth = 0
    /// How far the list goes before it reaches the bar.
    fileprivate var start: CGFloat = 0
    @MainActor func callAsFunction(_ offset: CGFloat) { blur?.follow(offset, depth: depth, from: start) }
    static func == (a: Self, b: Self) -> Bool { a.blur === b.blur && a.depth == b.depth && a.start == b.start }
}

enum SettingsSheet {
    /// Short of full height iOS draws the sheet as Liquid Glass over the
    /// conversation. `--settings-large` (preview only) compares full height.
    static var detent: PresentationDetent {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-large") { return .large }
        #endif
        return .fraction(0.93)
    }
}

/// 設定画面の準備 in the developer diagnostics (1.0.127): from the sheet's
/// first build to the first main-thread turn after it appeared.
@Observable @MainActor final class SettingsOpening {
    private let startedAt = Date()
    private(set) var took: TimeInterval?
    func appeared() {
        guard took == nil else { return }
        DispatchQueue.main.async { self.took = Date().timeIntervalSince(self.startedAt) }
    }
}

/// The pages slide over the sheet's one glass instead of being pushed on a
/// navigation stack: on iOS 27 a pushed page was drawn opaque white, and
/// the page below it darkened while it came and went (device recording,
/// 1.1.0 (147)). Each page keeps its place underneath while another is
/// open, as a navigation stack would, and a swipe to the right goes back.
struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var navigation: SettingsNavigation
    @State private var opening = SettingsOpening()
    @State private var title = SettingsTitleScroll()
    @State private var width: CGFloat = 0

    init(start: SettingsStart = .home) {
        _navigation = State(initialValue: SettingsNavigation(path: start == .home ? [] : [.models],
                                                             webSearch: start == .webSearch))
    }

    var body: some View {
        let _ = SettingsSlideMeter.drew("シート")
        let path = navigation.path
        NavigationStack {
            ZStack {
                ForEach(levels) { level in
                    page(level.page)
                        .environment(\.settingsScrolled, SettingsScrolled(
                            blur: navigation.blur, depth: level.depth,
                            start: level.page == nil ? SettingsTitle.blurStart : 0))
                        .modifier(SettingsSlide(navigation: navigation, role: role(level), reduceMotion: reduceMotion,
                                                metered: level.depth == depth))
                        .allowsHitTesting(level.depth == depth)
                        .accessibilityHidden(level.depth != depth)
                        .zIndex(Double(level.depth))
                }
            }
            .overlay(alignment: .top) { chrome }
            .gesture(SettingsBackSwipe(enabled: !path.isEmpty) { translation in
                navigation.follow(width > 0 ? translation / width : 0)
            } ended: { translation, velocity in
                let progress = width > 0 ? translation / width : 0
                navigation.release(back: progress > 0.35 || (velocity > 500 && progress > 0.05))
            })
            .navigationTitle(path.last?.title ?? "Fielua")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if navigation.showsBack {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("戻る", systemImage: "chevron.backward") { navigation.back() }
                            .accessibilityIdentifier("settings-back")
                    }
                }
                // The titles are drawn over the pages, so they move with them.
                ToolbarItem(placement: .principal) { Color.clear.frame(width: 1, height: 1).accessibilityHidden(true) }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("閉じる", systemImage: "xmark", role: .close) { dismiss() }
                        .accessibilityIdentifier("settings-close")
                }
            }
        }
        .environment(\.closeSettings, SettingsClose(navigation: navigation))
        .environment(\.openSettingsPage, SettingsOpen(navigation: navigation))
        .presentationDetents([SettingsSheet.detent])
        .onAppear {
            navigation.dismiss = { dismiss() }
            opening.appeared()
            SettingsSlideMeter.shared.runner = { [weak navigation] in navigation?.measure() }
            #if POCKET_PREVIEW
            if PreviewProbe.on("--settings-back-demo") {
                // For the UI test's screenshots: a page in and back out
                // with nothing touched, so the test's own taps wait for none.
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak navigation] in navigation?.open(.keyboard) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 11) { [weak navigation] in navigation?.back() }
            }
            if PreviewProbe.on("--keyboard-preview-demo") {
                // キーボード's phones, opened with nothing touched: the UI
                // check only photographs them while they play.
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak navigation] in navigation?.open(.keyboard) }
            }
            #endif
        }
        .onChange(of: reduceMotion, initial: true) { navigation.reduceMotion = reduceMotion }
        #if POCKET_PREVIEW
        .overlay(alignment: .bottom) {
            if PreviewProbe.on("--settings-slide-meter") || PreviewProbe.on("--settings-perf") {
                SettingsSlideMeterProbe(navigation: navigation)
            }
        }
        #endif
    }

    @ViewBuilder private func page(_ page: SettingsPage?) -> some View {
        if page != nil, SettingsSlideMeter.shared.variant.emptyPages {
            // For the meter's comparison only: a page with nothing to draw.
            ScrollView { Color.clear.frame(height: 900) }.settingsScroll()
        } else {
            content(page)
        }
    }

    @ViewBuilder private func content(_ page: SettingsPage?) -> some View {
        switch page {
        case nil: SettingsHome(scroll: title)
        case .models: ModelView(showsWebSearch: navigation.opensAtWebSearch)
        case .keyboard: KeyboardSettingsView()
        case .notifications: NotificationSettingsView()
        case .developer: DeveloperSettingsView(opening: opening)
        case .about: AboutFieluaView()
        case .licenses: LicensesView()
        case .license(let file): LicenseTextView(file: file)
        }
    }

    /// The blur under the bar and each page's title, over the pages: the
    /// titles move with their pages, and the blur stays put and follows
    /// the page in view.
    private var chrome: some View {
        ZStack(alignment: .top) {
            SettingsBlurLayer(navigation: navigation, depth: depth, bar: title.barHeight)
            ForEach(levels) { level in
                Group {
                    if let page = level.page { SettingsPageTitle(text: page.title, bar: title.barHeight) }
                    else { SettingsTitle(scroll: title, reduceMotion: reduceMotion) }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .modifier(SettingsSlide(navigation: navigation, role: role(level), reduceMotion: reduceMotion))
                .accessibilityHidden(level.depth != depth)
                .zIndex(Double(level.depth))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .ignoresSafeArea(edges: .top)
        .allowsHitTesting(false)
        .onGeometryChange(for: CGFloat.self) { $0.safeAreaInsets.top } action: { title.barHeight = $0 }
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { width = $0 }
    }

    private var levels: [SettingsLevel] {
        [SettingsLevel(depth: 0, page: nil)] + navigation.path.enumerated().map { SettingsLevel(depth: $0.offset + 1, page: $0.element) }
    }
    private var depth: Int { navigation.path.count }
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    /// The top page, the one under it, or one out of sight underneath. Only
    /// the slide reads where the top page is, so the sheet itself is not
    /// made again for each frame of it.
    private func role(_ level: SettingsLevel) -> SettingsSlideRole {
        switch level.depth {
        case depth: .top
        case depth - 1: .under
        default: .rest
        }
    }
}

/// The sheet's pages and their slide. A page joins out of sight at the
/// right edge and starts sliding in only at the next frame, after the one
/// that builds it; going back, the page slides out first and leaves after.
/// So the slide's clock never runs while a frame that changes the pages is
/// being made: on the phone 148 lost the first 4 frames of every slide to
/// that frame and then held one, which read as a low frame rate.
@Observable @MainActor fileprivate final class SettingsNavigation {
    private(set) var path: [SettingsPage]
    private(set) var opensAtWebSearch: Bool
    /// Where the top page is: 0 in view, 1 out at the right edge (waiting
    /// to come in, or gone back out), between while it slides or a swipe
    /// carries it.
    private(set) var top: CGFloat = 0
    /// The back button, which comes and goes with the system's own
    /// animation of the bar as a page starts in or back to the rows is
    /// pressed, as in 148 to 151. From 152 the page was put in place
    /// without SwiftUI's animation and the button came and went with it,
    /// with none (device recording on 1.1.0 (156)).
    private(set) var showsBack: Bool
    let blur = SettingsBlur()
    @ObservationIgnored private let driver = SettingsSlideDriver()
    @ObservationIgnored var reduceMotion = false
    @ObservationIgnored var dismiss: () -> Void = {}
    @ObservationIgnored private var sliding = false
    #if POCKET_PREVIEW
    @ObservationIgnored private var refused = "なし"
    /// For the UI test's log: where the pages are and whether a tap is taken.
    var probeState: String {
        "ページ \(path.isEmpty ? "トップ" : path.map(\.title).joined(separator: "›"))・top \(top)・戻る \(showsBack)"
            + "・sliding \(sliding)・動かし中 \(driver.moving)・断った移動 \(refused)"
    }
    #endif

    init(path: [SettingsPage], webSearch: Bool) {
        self.path = path
        opensAtWebSearch = webSearch
        showsBack = !path.isEmpty
    }

    func open(_ page: SettingsPage, then done: @escaping () -> Void = {}) {
        guard !sliding, top == 0 else {
            #if POCKET_PREVIEW
            refused = "\(page.title)（sliding \(sliding)・top \(top)）"
            #endif
            return done()
        }
        sliding = true
        SettingsSlideMeter.shared.asked()
        blur.reset(path.count + 1)
        withoutAnimation {
            path.append(page)
            top = 1
        }
        SettingsNextFrame.run { [self] in
            // The button in its own update, a frame before the page moves:
            // in the page's would have given the page the button's animation.
            showBack(true)
            // Free for the next tap once the page has arrived, as SwiftUI's
            // animation was, while its last fraction of a point settles.
            slide(to: 0, arrived: { self.sliding = false }, completion: done)
        }
    }

    func back(then done: @escaping () -> Void = {}) {
        guard !sliding, !path.isEmpty else { return done() }
        sliding = true
        SettingsSlideMeter.shared.asked()
        if path.count == 1 { showBack(false) }
        SettingsNextFrame.run { [self] in leave(then: done) }
    }

    /// 開発者設定's 「ページ移動を計測」:
    /// from the six rows, each page in and back out twice, for each way of
    /// sliding the meter compares, then back to the page it started on.
    func measure() {
        let meter = SettingsSlideMeter.shared
        guard !sliding, !meter.running else { return }
        let started = path, rounds = 2
        meter.start()
        Task { @MainActor [self] in
            for _ in 0..<started.count where !path.isEmpty { await withCheckedContinuation { done in back { done.resume() } } }
            for variant in SettingsSlideMeter.Variant.allCases {
                meter.variant = variant
                for page in SettingsPage.measured {
                    for _ in 0..<rounds {
                        try? await Task.sleep(for: .milliseconds(450))
                        meter.next(page.title, opening: true)
                        await withCheckedContinuation { done in open(page) { done.resume() } }
                        try? await Task.sleep(for: .milliseconds(550))
                        meter.next(page.title, opening: false)
                        await withCheckedContinuation { done in back { done.resume() } }
                    }
                }
            }
            meter.finish(rounds: rounds)
            for page in started { await withCheckedContinuation { done in open(page) { done.resume() } } }
        }
    }

    /// A swipe to the right carries the top page with the finger.
    func follow(_ progress: CGFloat) {
        guard !sliding, !path.isEmpty else { return }
        driver.stop()
        withoutAnimation { top = min(max(progress, 0), 1) }
    }

    /// Let go: on out from where the finger left it, or back into view.
    func release(back: Bool) {
        guard !sliding, !path.isEmpty, top > 0 else { return }
        sliding = true
        SettingsSlideMeter.shared.asked()
        if back {
            if path.count == 1 { showBack(false) }
            leave()
        } else {
            slide(to: 0, arrived: { self.sliding = false }) {}
        }
    }

    private func leave(then done: @escaping () -> Void = {}) {
        slide(to: 1) { [self] in
            withoutAnimation {
                path.removeLast()
                top = 0
                if path.isEmpty { showsBack = false }
                // Back on the six rows, モデル管理 opens at its top again.
                if path.isEmpty { opensAtWebSearch = false }
            }
            sliding = false
            done()
        }
    }

    /// `arrived` when the slide has logically arrived (SwiftUI's own
    /// completion), `completion` once it has come to rest. A page that goes
    /// back leaves only at rest, so nothing jumps where it settles.
    private func slide(to target: CGFloat, arrived: @escaping () -> Void = {}, completion: @escaping () -> Void) {
        let meter = SettingsSlideMeter.shared
        meter.began()
        guard meter.variant.drivesItself else {
            // 152's way, kept for the meter's comparison: on the phone
            // SwiftUI moved it 60 times a second on a 120Hz screen.
            withAnimation(animation) { top = target } completion: {
                arrived()
                meter.ended()
                completion()
            }
            return
        }
        driver.run(from: top, to: target, motion: motion) { [self] value in
            withoutAnimation { top = value }
        } arrived: {
            arrived()
        } done: {
            meter.ended()
            completion()
        }
    }

    /// The slide's motion: the same as `animation`, worked out frame by frame.
    private var motion: SettingsSlideDriver.Motion {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-slow-pages") { return reduceMotion ? .ease(2) : .spring(Spring(duration: 3, bounce: 0)) }
        #endif
        return reduceMotion ? .ease(0.25) : .spring(Spring(duration: 0.42, bounce: 0))
    }

    private var animation: Animation {
        #if POCKET_PREVIEW
        // Slowed for the UI test's frames of a page coming and going.
        if PreviewProbe.on("--settings-slow-pages") { return reduceMotion ? .easeInOut(duration: 2) : .smooth(duration: 3) }
        #endif
        return reduceMotion ? .easeInOut(duration: 0.25) : .smooth(duration: 0.42)
    }

    private func showBack(_ shown: Bool) {
        guard showsBack != shown else { return }
        withAnimation(animation) { showsBack = shown }
    }

    private func withoutAnimation(_ change: () -> Void) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction, change)
    }
}

/// Moves a slide at the display's own beat (1.1.0 (153)). On the phone
/// SwiftUI's animation of the slide was drawn 60 times a second on the
/// 120Hz screen (152's meter: 26 frames, 60fps, longest gap 17ms), while
/// iOS's own sheets and scrolling ran at 120: it lost no frames, it only
/// asked for half as many. A display link asks for the screen's full rate,
/// and at each beat the slide is set where it will be when that frame
/// appears, on the same curve SwiftUI's animation used.
@MainActor final class SettingsSlideDriver: NSObject {
    enum Motion {
        case spring(Spring)
        case ease(TimeInterval)
    }

    private var link: CADisplayLink?
    private var startedAt: CFTimeInterval?
    private var from: CGFloat = 0
    private var to: CGFloat = 0
    private var motion = Motion.ease(0.25)
    private var step: (CGFloat) -> Void = { _ in }
    private var arrived: (() -> Void)?
    private var done: () -> Void = {}

    func run(from: CGFloat, to: CGFloat, motion: Motion, step: @escaping (CGFloat) -> Void,
             arrived: @escaping () -> Void, done: @escaping () -> Void) {
        link?.invalidate()
        self.from = from
        self.to = to
        self.motion = motion
        self.step = step
        self.arrived = arrived
        self.done = done
        startedAt = nil
        // The link keeps its target until it is invalidated.
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFrameRateRange = CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    #if POCKET_PREVIEW
    var moving: Bool { link != nil }
    #endif

    /// Stops where it is: a finger has taken the page.
    func stop() {
        link?.invalidate()
        link = nil
        step = { _ in }
        arrived = nil
        done = {}
    }

    @objc private func tick(_ link: CADisplayLink) {
        let start = startedAt ?? link.timestamp
        startedAt = start
        let time = link.targetTimestamp - start
        let (progress, finished) = Self.progress(motion, at: time)
        step(finished ? to : from + (to - from) * progress)
        if let arrived, finished || time >= Self.arrival(motion) {
            self.arrived = nil
            arrived()
        }
        guard finished else { return }
        let done = self.done
        stop()
        done()
    }

    /// When SwiftUI's animation would call itself complete: a spring at its
    /// duration, a few points short of rest.
    private static func arrival(_ motion: Motion) -> TimeInterval {
        switch motion {
        case .spring(let spring): spring.duration
        case .ease(let duration): duration
        }
    }

    /// How far along the slide is, 0 to 1, and whether it has come to rest
    /// (within a fifth of a point on the widest phone).
    private static func progress(_ motion: Motion, at time: TimeInterval) -> (CGFloat, Bool) {
        switch motion {
        case .spring(let spring):
            let value = spring.value(target: 1.0, time: time)
            return (CGFloat(value), time >= spring.settlingDuration || (time >= spring.duration && abs(1 - value) < 0.0004))
        case .ease(let duration):
            let t = min(max(time / duration, 0), 1)
            return (CGFloat(UnitCurve.easeInOut.value(at: t)), t >= 1)
        }
    }
}

/// Runs once at the display's next frame, after the frame being made now.
@MainActor private final class SettingsNextFrame: NSObject {
    private var link: CADisplayLink?
    private var body: (() -> Void)?

    static func run(_ body: @escaping () -> Void) {
        let next = SettingsNextFrame()
        next.body = body
        // The link keeps its target until it is invalidated.
        let link = CADisplayLink(target: next, selector: #selector(tick))
        next.link = link
        link.add(to: .main, forMode: .common)
    }

    @objc private func tick() {
        link?.invalidate()
        link = nil
        let body = self.body
        self.body = nil
        body?()
    }
}

#if POCKET_PREVIEW
/// The meter's last reading for the UI test's log, or, while 開発者設定's
/// measurement is tested, where the pages are once it has finished.
private struct SettingsSlideMeterProbe: View {
    let navigation: SettingsNavigation

    var body: some View {
        if !PreviewProbe.on("--settings-perf") {
            label(SettingsSlideMeter.shared.summary ?? "まだ移動していません", id: "settings-slide-meter")
        } else if SettingsSlideMeter.shared.running {
            label("計測中", id: "settings-nav-state")
        } else {
            // Read again twice a second, as `sliding` is not observed.
            TimelineView(.periodic(from: .now, by: 0.5)) { _ in
                label(navigation.probeState, id: "settings-nav-state")
            }
        }
    }

    private func label(_ text: String, id: String) -> some View {
        Text(text)
            .font(.system(size: 9)).padding(3).background(.background)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
            .accessibilityIdentifier(id).allowsHitTesting(false)
    }
}
#endif

private struct SettingsLevel: Hashable, Identifiable {
    let depth: Int
    let page: SettingsPage?
    var id: Self { self }
}

private enum SettingsSlideRole {
    case top, under, rest
}

/// Reads where the top page is for one page or title, so each frame of a
/// slide makes only these again, not the sheet or the pages.
private struct SettingsSlide: ViewModifier {
    let navigation: SettingsNavigation
    let role: SettingsSlideRole
    let reduceMotion: Bool
    var metered = false
    func body(content: Content) -> some View {
        let top = navigation.top
        let position: CGFloat = switch role {
        case .top: top
        case .under: top - 1
        case .rest: -1
        }
        // Changes only as a slide starts and ends, so only what reads it
        // (the キーボード phones) is made again.
        return content.modifier(SettingsSlideEffect(position: position, reduceMotion: reduceMotion, metered: metered))
            .environment(\.settingsPageInView, role == .top && top == 0)
    }
}

/// Where a page stands in the sheet: 0 in view, 1 out to the right (coming
/// or going), -1 under the page above it, a third of the way out to the
/// left. With no backing of its own, a page leaving fades out by halfway
/// and the one coming is whole by halfway, so the two never read on top of
/// each other. With Reduce Motion they crossfade in place.
private struct SettingsSlideEffect: ViewModifier, Animatable {
    var position: CGFloat
    let reduceMotion: Bool
    /// The top page tells the meter each frame it moves.
    var metered = false
    var animatableData: CGFloat {
        get { position }
        set { position = newValue }
    }
    func body(content: Content) -> some View {
        if metered { SettingsSlideMeter.shared.frame() }
        let shift = reduceMotion ? 0 : (position >= 0 ? position : position * 0.3)
        return content
            .opacity(opacity)
            .visualEffect { view, geometry in view.offset(x: geometry.size.width * shift, y: 0) }
    }
    private var opacity: Double {
        if reduceMotion { return 1 - min(abs(position), 1) }
        // For the meter's comparison only: whole or hidden, never between.
        if !SettingsSlideMeter.shared.variant.fades { return position >= 0 ? (position < 1 ? 1 : 0) : (position > -0.5 ? 1 : 0) }
        return position >= 0 ? min(max((1 - position) / 0.45, 0), 1) : min(max(1 + position / 0.55, 0), 1)
    }
}

/// A swipe to the right anywhere on a page goes back, following the finger.
/// Vertical scrolling waits for it to fail, which it does as soon as the
/// movement is mostly vertical (as the history drawer's pan). Segmented
/// pickers, sliders and switches keep their own sideways drags.
private struct SettingsBackSwipe: UIGestureRecognizerRepresentable {
    let enabled: Bool
    let changed: (CGFloat) -> Void
    let ended: (CGFloat, CGFloat) -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.delegate = context.coordinator
        return pan
    }
    func updateUIGestureRecognizer(_ pan: UIPanGestureRecognizer, context: Context) {
        pan.isEnabled = enabled
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        let translation = pan.translation(in: pan.view).x
        switch pan.state {
        case .began, .changed: changed(translation)
        case .ended: ended(translation, pan.velocity(in: pan.view).x)
        case .cancelled, .failed: ended(0, 0)
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            return velocity.x > 0 && velocity.x > abs(velocity.y) * 1.2
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldBeRequiredToFailBy other: UIGestureRecognizer) -> Bool {
            guard let scroll = other.view as? UIScrollView, other === scroll.panGestureRecognizer else { return false }
            return scroll.contentSize.width <= scroll.bounds.width + 1
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            var view = touch.view
            while let current = view {
                if current is UISegmentedControl || current is UISlider || current is UISwitch { return false }
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

// MARK: - The blur under the bar

/// Each open page's blur under the bar, from 0 to 1 by how far its list
/// has scrolled, by the page's depth in the sheet.
@Observable @MainActor fileprivate final class SettingsBlur {
    private(set) var strengths: [Int: CGFloat] = [:]
    /// Full once the list has gone 24pt under the bar past `start`.
    func follow(_ offset: CGFloat, depth: Int, from start: CGFloat) {
        let strength = min(max((offset - start) / 24, 0), 1)
        if strengths[depth] != strength { strengths[depth] = strength }
    }
    func reset(_ depth: Int) { strengths[depth] = 0 }
}

/// Reads the strengths itself, so scrolling redraws only the blur.
private struct SettingsBlurLayer: View {
    let navigation: SettingsNavigation
    let depth: Int
    let bar: CGFloat
    var body: some View {
        let _ = SettingsSlideMeter.drew("ぼかし")
        let blur = navigation.blur
        let shown = blur.strengths[depth] ?? 0, below = blur.strengths[depth - 1] ?? 0
        // The top page's place in its slide: the blur goes with the page in
        // view. Read only when the two differ, so a slide between two pages
        // at rest does not draw the blur again at every frame.
        let top = shown == below ? 0 : navigation.top
        SettingsTopBlur(strength: shown + (below - shown) * top)
            .frame(height: bar)
    }
}

/// The chat header's blur (ChatChromeBackdrop), from the sheet's top to
/// just below the bar, faded in as the list goes under it. At rest there is
/// nothing over the glass. It changes frame by frame between two pages.
private struct SettingsTopBlur: View, Animatable {
    var strength: CGFloat
    var animatableData: CGFloat {
        get { strength }
        set { strength = newValue }
    }
    var body: some View {
        // In 5% steps: each new strength masks the native blur again, too
        // much work for every frame of a slide at 120Hz.
        ChatChromeBackdrop(edge: .top, strength: 0.96 * (strength * 20).rounded() / 20, reachesScreenEdge: false)
    }
}

private struct SettingsScrollReport: ViewModifier {
    @Environment(\.settingsScrolled) private var scrolled
    func body(content: Content) -> some View {
        content
            // The blur above stands in for the system's edge effect.
            .scrollEdgeEffectHidden(true, for: .top)
            .onScrollGeometryChange(for: CGFloat.self) { $0.contentOffset.y + $0.contentInsets.top } action: { _, offset in
                scrolled(offset)
            }
    }
}

extension View {
    /// On each page's list: under the bar it blurs like the chat's header.
    func settingsScroll() -> some View { modifier(SettingsScrollReport()) }
}

/// A page's name in the middle of the bar, in line with its buttons.
private struct SettingsPageTitle: View {
    let text: String
    let bar: CGFloat
    var body: some View {
        let _ = SettingsSlideMeter.drew("ページ名")
        Text(text)
            .font(.headline)
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .frame(height: SettingsTitle.line)
            // Clear of the back and close buttons.
            .padding(.horizontal, 72)
            .offset(y: SettingsTitle.dock(bar: bar) - SettingsTitle.line / 2)
            .accessibilityAddTraits(.isHeader)
            .accessibilityIdentifier("settings-page-title")
    }
}

// MARK: - The six rows

private struct SettingsHome: View {
    let scroll: SettingsTitleScroll
    @Environment(\.settingsScrolled) private var scrolled
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// 開発者設定 is hidden while its switch is off: three swipes with three
    /// fingers, up or down, show it for this visit (as the switch was shown
    /// at the bottom of モデルと設定 before).
    @State private var developerRevealed = ProcessInfo.processInfo.arguments.contains("--developer-unlocked")
    @State private var revealSwipes = 0
    @State private var lastRevealSwipe = Date.distantPast

    var body: some View {
        let _ = SettingsSlideMeter.drew("トップ")
        let travel = scroll.travel
        ScrollView {
            // However short the list, it scrolls far enough for the title to
            // settle in the bar and stay there: one screen under the bar
            // plus the title's way up (run 286: measured from the list's
            // own frame, the room came out short and nothing scrolled).
            ZStack(alignment: .top) {
                Color.clear
                    .containerRelativeFrame(.vertical) { length, _ in length + travel }
                    .accessibilityHidden(true)
                rows
            }
        }
        // On the list itself: set over the title too, it would take the
        // title's own identifier.
        .accessibilityIdentifier("settings-home")
        .scrollTargetBehavior(SettingsTitleSnap(travel: snaps ? travel : 0))
        .scrollEdgeEffectHidden(true, for: .top)
        .onScrollGeometryChange(for: ScrollGeometry.self) { $0 } action: { _, geometry in
            scroll.follow(geometry)
            scrolled(scroll.offset)
        }
        .gesture(ThreeFingerVerticalSwipe { _ in registerRevealSwipe() })
        .onAppear {
            // Kept for this visit even after its switch is turned off.
            if showDeveloperSettings { developerRevealed = true }
        }
    }

    private var rows: some View {
        VStack(spacing: 24) {
            SettingsGroup {
                SettingsRow("モデル管理", icon: "square.stack.3d.up", page: .models)
                SettingsDivider()
                SettingsRow("キーボード", icon: "keyboard", page: .keyboard)
                SettingsDivider()
                SettingsRow("通知", icon: "bell", page: .notifications)
                SettingsDivider()
                SettingsLockedRow()
            }
            SettingsGroup {
                SettingsRow("Fieluaの情報", icon: "info.circle", page: .about)
                SettingsDivider()
                SettingsRow("オープンソースライセンス", icon: "doc.text", page: .licenses)
            }
            if showDeveloperSettings || developerRevealed {
                SettingsGroup {
                    SettingsRow("開発者設定", icon: "hammer", page: .developer)
                }
                .transition(.opacity)
            }
        }
        .padding(.horizontal, 20)
        // Room for the title, which is drawn over the list.
        .padding(.top, SettingsTitle.room)
        .padding(.bottom, 20)
    }

    /// Three swipes within 5 seconds. All the rows are always in view, so
    /// unlike モデルと設定's list there is no bottom to reach first.
    private func registerRevealSwipe() {
        guard !developerRevealed else { return }
        let now = Date()
        if now.timeIntervalSince(lastRevealSwipe) > 5 { revealSwipes = 0 }
        revealSwipes += 1; lastRevealSwipe = now
        guard revealSwipes >= 3 else { return }
        revealSwipes = 0
        withAnimation(.smooth(duration: 0.3)) { developerRevealed = true }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    private var snaps: Bool {
        #if POCKET_PREVIEW
        // The title's frames are photographed partway, where a snap would
        // never let it rest.
        if PreviewProbe.on("--settings-title-probe") { return false }
        #endif
        return true
    }
}

private struct SettingsGroup<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        VStack(spacing: 0) { content }
            .background(Theme.card)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct SettingsDivider: View {
    /// Under the text, past the icon's column, as iOS's lists do.
    var body: some View { Divider().padding(.leading, 58) }
}

private struct SettingsRow: View {
    let title: String
    let icon: String
    let page: SettingsPage
    @Environment(\.openSettingsPage) private var openPage
    init(_ title: String, icon: String, page: SettingsPage) { self.title = title; self.icon = icon; self.page = page }
    var body: some View {
        let _ = SettingsSlideMeter.drew("行")
        Button { openPage(page) } label: {
            SettingsRowLabel(title: title, icon: icon) {
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityIdentifier("settings-row-\(page)")
    }
}

/// PCと接続: shown for a later update; nothing behind it yet.
private struct SettingsLockedRow: View {
    var body: some View {
        Button {} label: {
            SettingsRowLabel(title: "PCと接続", icon: "laptopcomputer", note: "今後のアップデートで対応") {
                Image(systemName: "lock")
                    .font(.system(size: 15, weight: .medium))
            }
            .foregroundStyle(.secondary)
        }
        .buttonStyle(SettingsRowStyle())
        .disabled(true)
        .accessibilityIdentifier("settings-row-pc")
    }
}

private struct SettingsRowLabel<Trailing: View>: View {
    let title: String
    let icon: String
    var note: String?
    @ViewBuilder let trailing: Trailing
    var body: some View {
        HStack(spacing: 14) {
            // Line symbols in the text's own color: no accent.
            Image(systemName: icon)
                .font(.system(size: 19, weight: .regular))
                .frame(width: 28)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                if let note { Text(note).font(.footnote) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            trailing.accessibilityHidden(true)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(minHeight: 52)
        .contentShape(Rectangle())
    }
}

private struct SettingsRowStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(configuration.isPressed ? Color.primary.opacity(0.08) : Color.clear)
    }
}

// MARK: - The title

/// Read by the title alone, so scrolling redraws only the title.
@Observable @MainActor private final class SettingsTitleScroll {
    /// How far the list is scrolled up from rest; below 0 while pulled down.
    var offset: CGFloat = 0
    /// The bar's height over the list.
    var barHeight: CGFloat = 0
    var dock: CGFloat { SettingsTitle.dock(bar: barHeight) }
    var travel: CGFloat { max(SettingsTitle.rest(bar: barHeight) - dock, 0) }

    func follow(_ geometry: ScrollGeometry) {
        offset = geometry.contentOffset.y + geometry.contentInsets.top
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-title-probe") {
            probe = String(format: "offset %.1f content %.1f container %.1f insets %.1f/%.1f bar %.1f travel %.1f",
                           offset, geometry.contentSize.height, geometry.containerSize.height,
                           geometry.contentInsets.top, geometry.contentInsets.bottom, barHeight, travel)
        }
        #endif
    }
    #if POCKET_PREVIEW
    /// The measurements behind the title, for the UI test's log.
    var probe = ""
    #endif
}

/// 「Fielua」 over the list. At rest it is large under the bar; scrolling up
/// carries it up with the list while it shrinks, so it reaches the bar's
/// middle at the size of a bar title and stays there; back at the top it is
/// large again. One text all the way, so nothing swaps or jumps. With Reduce
/// Motion the large title scrolls away and the small one fades in instead.
private struct SettingsTitle: View {
    static let large: CGFloat = 34
    static let small: CGFloat = 17
    /// The large title's line in the list, above the first group.
    static let room: CGFloat = 72
    static let line: CGFloat = 44
    static func rest(bar: CGFloat) -> CGFloat { bar + room / 2 }
    /// The rows reach the blur under the bar about here.
    static let blurStart: CGFloat = 36
    /// In line with the bar's close button, which iOS sets a little below
    /// the bar's middle in a sheet (run 287: 2.9 pt).
    static func dock(bar: CGFloat) -> CGFloat { bar / 2 + 3 }

    let scroll: SettingsTitleScroll
    let reduceMotion: Bool

    var body: some View {
        let _ = SettingsSlideMeter.drew("タイトル")
        let offset = scroll.offset, dock = scroll.dock, travel = scroll.travel
        let rest = Self.rest(bar: scroll.barHeight)
        let progress = travel > 0 ? min(max(offset / travel, 0), 1) : 0
        Group {
            if reduceMotion {
                // One gone before the other comes, so they never show
                // stacked where the large one passes under the bar.
                ZStack(alignment: .top) {
                    title(Self.large)
                        .offset(y: rest - offset - Self.line / 2)
                        .opacity(max(1 - progress / 0.6, 0))
                    title(Self.small)
                        .offset(y: dock - Self.line / 2)
                        .opacity(max((progress - 0.5) / 0.5, 0))
                }
            } else {
                title(Self.large)
                    .scaleEffect(1 - (1 - Self.small / Self.large) * progress)
                    .offset(y: max(rest - offset, dock) - Self.line / 2)
            }
        }
        .allowsHitTesting(false)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Fielua")
        .accessibilityAddTraits(.isHeader)
        .accessibilityIdentifier("settings-title")
        #if POCKET_PREVIEW
        .accessibilityValue(scroll.probe)
        #endif
    }

    private func title(_ size: CGFloat) -> some View {
        // The sidebar's wordmark: Apple's own serif (New York).
        Text("Fielua")
            .font(.system(size: size, weight: .semibold, design: .serif))
            .lineLimit(1)
            .fixedSize()
            .frame(height: Self.line)
    }
}

/// Let go with the title partway and the list settles with it large or in
/// the bar, as iOS's own large titles do.
private struct SettingsTitleSnap: ScrollTargetBehavior {
    let travel: CGFloat
    func updateTarget(_ target: inout ScrollTarget, context: TargetContext) {
        let y = target.rect.minY
        guard travel > 0, y > 0, y < travel else { return }
        target.rect.origin.y = y < travel / 2 ? 0 : travel
    }
}

// MARK: - Pages

/// キーボード: the composer's type (入力欄のタイプ, 2026-10-23).
private struct KeyboardSettingsView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("キーボード")
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                ComposerStyleCard()
                LaunchKeyboardCard()
            }
            .padding(20)
        }
        .settingsScroll()
    }
}

/// 通知: the notification when a reply ends while Fielua is closed. Whether
/// it may appear is iOS's setting, so the page shows it and leads there.
private struct NotificationSettingsView: View {
    @Environment(\.openURL) private var openURL
    @Environment(\.scenePhase) private var scenePhase
    @State private var status: UNAuthorizationStatus?

    var body: some View {
        let _ = SettingsSlideMeter.drew("通知")
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("回答が終わったときの通知").font(.headline)
                    Spacer(minLength: 8)
                    Text(statusText).foregroundStyle(.secondary)
                        .accessibilityIdentifier("settings-notification-status")
                }
                Text("Fieluaを閉じている間に回答を書き終えると、通知でお知らせします。通知をタップすると、その会話が開きます。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if status == .notDetermined {
                    Text("初めてメッセージを送るときに、iOSが通知を許可するか確認します。")
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if let settings = URL(string: UIApplication.openNotificationSettingsURLString) {
                    Button("iOSの通知設定を開く") { openURL(settings) }
                        .font(.subheadline)
                        .accessibilityIdentifier("settings-notification-open")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
            .padding(20)
        }
        .settingsScroll()
        .task { await refresh() }
        // Back from iOS's settings, show what was chosen there.
        .onChange(of: scenePhase) { if scenePhase == .active { Task { await refresh() } } }
    }

    private var statusText: String {
        guard let status else { return "" }
        switch status {
        case .authorized, .provisional, .ephemeral: return "オン"
        case .denied: return "オフ"
        case .notDetermined: return "未設定"
        @unknown default: return ""
        }
    }

    private func refresh() async {
        status = await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
    }
}

/// Fieluaの情報: the name, the version, and where conversations are handled.
private struct AboutFieluaView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("情報")
        ScrollView {
            VStack(spacing: 24) {
                VStack(spacing: 6) {
                    Text("Fielua")
                        .font(.system(size: 34, weight: .semibold, design: .serif))
                        .accessibilityAddTraits(.isHeader)
                    Text("あなたの\(DeviceOverview.name)に、AIを。")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(.top, 8)
                HStack {
                    Text("バージョン")
                    Spacer(minLength: 12)
                    Text(Self.version).foregroundStyle(.secondary).textSelection(.enabled)
                        .accessibilityIdentifier("settings-about-version")
                }
                .padding(.horizontal, 16).frame(minHeight: 52)
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                Label("会話は、この端末の中で処理されます。",
                      systemImage: UIDevice.current.userInterfaceIdiom == .pad ? "ipad" : "iphone")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .settingsScroll()
    }

    static var version: String {
        let info = Bundle.main.infoDictionary
        switch (info?["CFBundleShortVersionString"] as? String, info?["CFBundleVersion"] as? String) {
        case let (short?, build?): return "\(short) (\(build))"
        case let (short?, nil): return short
        default: return "—"
        }
    }
}
