import SwiftUI
import UIKit
import UserNotifications
import PocketCore

/// 設定 (2026-10-23, 設定画面UIリニューアル): a Liquid Glass sheet with the
/// app's name large at the top and six rows, each opening its page in the
/// same sheet. モデル管理 is the model list as it was (ModelView). ウェブ検索
/// is the Tavily card that was at the end of モデル管理 (1.1.0 (230)).
enum SettingsPage: Hashable {
    case models, webSearch, keyboard, notifications, developer, about, licenses
    /// 試験機能を試してみる (1.1.0 (250), the user's ask of 2026-10-31
    /// 15:55 UTC): features still on trial, each on only while its switch
    /// is; Smart Mode for now.
    case experiments
    /// 会話履歴 (1.1.0 (251), the user's directive of 2026-10-31): the saved
    /// conversations, to choose and delete (ChatHistorySettingsView).
    case chatHistory
    /// PCと接続 (1.1.0 (253), the user's directive of 2026-11-01): the PC
    /// whose models this iPhone uses (PCLinkSettingsView). Locked before.
    case pcLink
    /// Claude (1.1.0 (257), the user's directive of 2026-11-06): this
    /// iPhone's registration with the developer's relay, and on the
    /// developer's iPhone its management (ClaudeSettingsView).
    case claude
    /// キーボードと入力's two choices, each on a page of its own (user,
    /// 2026-10-25 22:47 UTC).
    case composerStyle, launchChat
    /// One license's text, by its file, from オープンソースライセンス.
    case license(String)
    /// One series' models, by its name (Gemma, Qwen, LFM), from モデル管理
    /// (1.1.0 (279), fielua-reports Issue #17): their cards, as モデル管理
    /// listed them all until 278 (ModelFamilyView).
    case modelFamily(String)

    /// Its name large over its list, carried up into the bar as the list
    /// scrolls, as 設定's own (モデル管理, 1.1.0 (231), fielua-reports Issue
    /// #6); the other pages have theirs in the bar from the start.
    var hasLargeTitle: Bool { self == .models }

    /// The pages 「ページ移動を計測」 slides in and out, each after the ones
    /// before it in its list (1.1.0 (283), fielua-reports Issue #20: モデル管理
    /// and Gemma's page over it, ウェブ検索, 会話履歴 and the other rows).
    /// PCと接続 is left out: its page looks for PCs on the network.
    static let measuredRoutes: [[SettingsPage]] = [
        [.models], [.models, .modelFamily("Gemma")], [.webSearch], [.chatHistory], [.keyboard],
        [.notifications], [.experiments], [.claude], [.about], [.licenses],
    ]

    var title: String {
        switch self {
        case .models: String(localized: "モデル管理")
        case .webSearch: String(localized: "ウェブ検索")
        case .keyboard: String(localized: "キーボードと入力")
        case .notifications: String(localized: "通知")
        case .developer: String(localized: "開発者設定")
        case .experiments: String(localized: "試験機能を試してみる")
        case .chatHistory: String(localized: "会話履歴")
        case .pcLink: String(localized: "PCと接続")
        case .claude: "Claude"
        case .about: String(localized: "Fieluaの情報")
        case .licenses: String(localized: "オープンソースライセンス")
        case .composerStyle: String(localized: "入力スタイル")
        case .launchChat: String(localized: "起動時のチャット")
        // The license's own name, which fits the bar; whose it is heads the page (1.1.0 (263)).
        case .license(let file): OpenSourceLicense.all.first { $0.file == file }?.license ?? ""
        // The series' own name, as its row and the chat's menu say it.
        case .modelFamily(let family): family
        }
    }
}

/// Where the sheet opens: on its six rows, or, from the chat, on モデル管理,
/// or on ウェブ検索 when the search note asked for a connection. A model
/// not on the phone, chosen in the chat, opens its series' page over
/// モデル管理, at its download (1.1.0 (279)); 戻る goes to the series.
enum SettingsStart {
    case home, models, webSearch
    case modelFamily(String)

    fileprivate var path: [SettingsPage] {
        switch self {
        case .home: []
        case .models: [.models]
        case .webSearch: [.webSearch]
        case .modelFamily(let family): [.models, .modelFamily(family)]
        }
    }
}

extension EnvironmentValues {
    /// Closes the whole sheet from any of its pages.
    @Entry var closeSettings = SettingsClose()
    /// Opens a page over the one showing, in the same sheet.
    @Entry var openSettingsPage = SettingsOpen()
    /// A page's list says how far it has scrolled, for the blur under the bar.
    @Entry var settingsScrolled = SettingsScrolled()
    /// The page is the one in view and at rest: not sliding in or out, nor
    /// carried by a swipe. キーボード's phones play only then.
    @Entry var settingsPageInView = true
    /// The large name of the page that has one, which its list moves.
    @Entry var settingsLargeTitle: SettingsTitleScroll? = nil
}

// What the pages ask of the sheet, each one value for the whole visit: a
// closure made anew whenever the sheet changed counted as a new value, and
// every row and page drew again at the start of each slide.

struct SettingsClose: Equatable {
    fileprivate weak var navigation: SettingsNavigation?
    @MainActor func callAsFunction() { navigation?.dismiss() }
    static func == (a: Self, b: Self) -> Bool { a.navigation === b.navigation }
}

struct SettingsOpen: Equatable {
    fileprivate weak var navigation: SettingsNavigation?
    @MainActor func callAsFunction(_ page: SettingsPage) { navigation?.open(page) }
    static func == (a: Self, b: Self) -> Bool { a.navigation === b.navigation }
}

struct SettingsScrolled: Equatable {
    fileprivate weak var blur: SettingsBlur?
    fileprivate var depth = 0
    /// How far the list goes before it reaches the bar.
    fileprivate var start: CGFloat = 0
    @MainActor func callAsFunction(_ offset: CGFloat) { blur?.follow(offset, depth: depth, from: start) }
    static func == (a: Self, b: Self) -> Bool { a.blur === b.blur && a.depth == b.depth && a.start == b.start }
}

enum SettingsSheet {
    /// Short of full height iOS draws the sheet as Liquid Glass over the
    /// conversation. `--settings-large` (preview only) compares full height.
    static var detent: PresentationDetent {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-large") { return .large }
        #endif
        return .fraction(0.93)
    }
}

/// The sheet's paper: the conversation's own (PaperBackground, Theme's
/// chatBackground and its grain), whole, on every page of 設定 (1.1.0 (290),
/// Hachimoto さん's directive of 2026-11-16: 設定 looks like the chat it
/// opens over, light and dark). Until 289 iOS drew the sheet as Liquid
/// Glass, short of full height, and the chat's colour lay over it at 80%:
/// a paler, cooler tone than the chat's, with the glass at the rim. The
/// bar's buttons (戻る, 閉じる, a page's own) stay iOS's glass.
private struct SettingsPaper: View {
    var body: some View {
        PaperBackground()
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

/// The sheet is the chat's paper, not iOS's glass (1.1.0 (290)).
private struct SettingsSheetPaper: ViewModifier {
    func body(content: Content) -> some View {
        #if POCKET_PREVIEW
        // 289's glass, for the UI check's before and after.
        if SettingsPresentProbe.glass289 { return AnyView(content) }
        return AnyView(content.presentationBackground { SettingsPaper() })
        #else
        content.presentationBackground { SettingsPaper() }
        #endif
    }
}

#if POCKET_PREVIEW
/// 289's paper (`--settings-glass-289`): the chat's colour at 80% over
/// the glass, opaque with Reduce Transparency.
private struct SettingsPaper289: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var body: some View {
        Theme.chatBackground
            .opacity(reduceTransparency ? 1 : 0.8)
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}
#endif

/// While the sheet comes up: no animation from outside reaches its rows.
///
/// It takes the animation away and no more (1.1.0 (290)). Until 289 it also
/// set `disablesAnimations` over the sheet's whole content from its first
/// update: the flag that asks for a change with no animation at all. On
/// Hachimoto さん's iPhone (289, iOS 27.2) the sheet now and then came up whole
/// in one frame, with no rise. The simulator (iOS 26, Xcode 26.6) rose every
/// time with the flag and without it, so the flag stays one of the two
/// suspects (the other: the history held the sheet, HistorySettingsHost). The
/// animation alone keeps the rows still, as 1.1.0 (203) needed: the
/// keyboard's going down reached them as a transaction's animation
/// (fielua-reports design/settings-theme-unification-and-open-animation.md).
private struct SettingsStill: ViewModifier {
    let on: Bool
    func body(content: Content) -> some View {
        content.transaction { transaction in
            guard on else { return }
            transaction.animation = nil
            #if POCKET_PREVIEW
            // 289's way, for the UI check's before and after.
            if SettingsPresentProbe.still289 { transaction.disablesAnimations = true }
            #endif
        }
    }
}

/// 設定画面の準備 in the developer diagnostics (1.0.127): from the sheet's
/// first build to the first main-thread turn after it appeared.
@Observable @MainActor final class SettingsOpening {
    private let startedAt = Date()
    private(set) var took: TimeInterval?
    func appeared() {
        guard took == nil else { return }
        DispatchQueue.main.async { self.took = Date().timeIntervalSince(self.startedAt) }
    }
}

/// The pages slide over the sheet's one glass instead of being pushed on a
/// navigation stack: on iOS 27 a pushed page was drawn opaque white, and
/// the page below it darkened while it came and went (device recording,
/// 1.1.0 (147)). Each page keeps its place underneath while another is
/// open, as a navigation stack would, and a swipe to the right goes back.
struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @Environment(\.displayScale) private var displayScale
    @State private var navigation: SettingsNavigation
    @State private var opening = SettingsOpening()
    @State private var title = SettingsTitleScroll()
    /// モデル管理's large name (SettingsPage.hasLargeTitle).
    @State private var pageTitle = SettingsTitleScroll()
    @State private var width: CGFloat = 0
    /// Nothing in the sheet animates while it comes up. Laid out inside
    /// another animation (the keyboard going down as it opened), the sheet
    /// grew its rows from a sliver to their width (user's recording,
    /// 2026-10-26 16:01 UTC). The pages' slides keep their own clock.
    @State private var still = true

    init(start: SettingsStart = .home) {
        _navigation = State(initialValue: SettingsNavigation(path: start.path))
        #if POCKET_PREVIEW
        // For the UI check's comparison: the sheet as it came up before.
        if PreviewProbe.on("--settings-open-animated") { _still = State(initialValue: false) }
        #endif
    }

    var body: some View {
        let _ = SettingsSlideMeter.drew("シート")
        let path = navigation.path
        NavigationStack {
            ZStack {
                ForEach(levels) { level in
                    let large = level.page?.hasLargeTitle ?? true
                    page(level.page)
                        .environment(\.settingsScrolled, SettingsScrolled(
                            blur: navigation.blur, depth: level.depth,
                            start: large ? SettingsTitle.blurStart : 0))
                        .environment(\.settingsLargeTitle, level.page?.hasLargeTitle == true ? pageTitle : nil)
                        .modifier(SettingsSlide(navigation: navigation, role: role(level), reduceMotion: reduceMotion,
                                                metered: level.depth == depth, page: true))
                        .allowsHitTesting(level.depth == depth)
                        .accessibilityHidden(level.depth != depth)
                        .zIndex(Double(level.depth))
                }
            }
            // No paper of their own at rest: the pages lie on the sheet's
            // (`presentationBackground`, SettingsPaper), which stays still.
            // While one slides it has its own (SettingsSlidePaper, 1.1.0
            // (292)), cut to the sheet's outline measured here.
            .background { SettingsSheetProbe(navigation: navigation) }
            .coordinateSpace(.named(SettingsSheetOutline.space))
            #if POCKET_PREVIEW
            .background { if SettingsPresentProbe.glass289 { SettingsPaper289() } }
            #endif
            .overlay(alignment: .top) { chrome }
            // VoiceOver's two-finger scrub goes back one page, as 戻る does:
            // the pages are the sheet's own, so iOS knew of none to go back
            // to and closed all of 設定 (1.1.0 (263); UI review, 2026-11-11).
            // On the first page it closes the sheet, as before.
            .accessibilityAction(.escape) {
                if navigation.showsBack { navigation.back() } else { dismiss() }
            }
            .gesture(SettingsBackSwipe(enabled: !path.isEmpty) { translation in
                navigation.follow(width > 0 ? translation / width : 0)
            } ended: { translation, velocity in
                let progress = width > 0 ? translation / width : 0
                navigation.release(back: progress > 0.35 || (velocity > 500 && progress > 0.05))
            })
            .navigationTitle(path.last?.title ?? String(localized: "設定"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if navigation.showsBack {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("戻る", systemImage: "chevron.backward") { navigation.back() }
                            .accessibilityIdentifier("settings-back")
                    }
                }
                // The titles are drawn over the pages, so they move with them.
                ToolbarItem(placement: .principal) { Color.clear.frame(width: 1, height: 1).accessibilityHidden(true) }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("閉じる", systemImage: "xmark", role: .close) { dismiss() }
                        .accessibilityIdentifier("settings-close")
                }
            }
            // Inside as well: the stack's pages are laid out on their own.
            .modifier(SettingsStill(on: still))
        }
        .modifier(SettingsStill(on: still))
        .task {
            guard still else { return }
            try? await Task.sleep(for: .milliseconds(700))
            still = false
        }
        .environment(\.closeSettings, SettingsClose(navigation: navigation))
        .environment(\.openSettingsPage, SettingsOpen(navigation: navigation))
        // A page came or went: VoiceOver starts again at its top, once the
        // slide is over (it stayed on the row of the page before).
        .onChange(of: path.count) {
            guard UIAccessibility.isVoiceOverRunning else { return }
            Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(520))
                UIAccessibility.post(notification: .screenChanged, argument: nil)
            }
        }
        .presentationDetents([SettingsSheet.detent])
        .modifier(SettingsSheetPaper())
        .onAppear {
            navigation.dismiss = { dismiss() }
            opening.appeared()
            SettingsSlideMeter.shared.runner = { [weak navigation] in navigation?.measure() }
            #if POCKET_PREVIEW
            if PreviewProbe.on("--settings-back-demo") {
                // For the UI test's screenshots: a page in and back out
                // with nothing touched, so the test's own taps wait for none.
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak navigation] in navigation?.open(.keyboard) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 11) { [weak navigation] in navigation?.back() }
            }
            // The pages people go through, in and out by the app itself,
            // so the UI check films them with nothing asked of the app
            // meanwhile (1.1.0 (283), fielua-reports Issue #20).
            if PreviewProbe.on("--settings-route-demo") {
                Task { @MainActor [weak navigation] in
                    try? await Task.sleep(for: .seconds(4))
                    await navigation?.routeDemo()
                }
            }
            // 入力スタイル's or 起動時のチャット's phones, opened with nothing
            // touched: the UI check only photographs them while they play.
            // 4 s, so a slow simulator has finished asking for the sheet
            // first; then キーボードと入力 and its page, one after the other.
            // 設定's pages for the UI check's profile (1.1.0 (291)), once the
            // app has brought the sheet up and down ten times.
            if SettingsProfileDemo.routeNext {
                SettingsProfileDemo.routeNext = false
                Task { @MainActor [weak navigation] in
                    try? await Task.sleep(for: .seconds(2))
                    await navigation?.profileRoute()
                }
            }
            for (flag, page) in [("--keyboard-preview-demo", SettingsPage.composerStyle), ("--launch-settings-demo", .launchChat)]
            where PreviewProbe.on(flag) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [weak navigation] in
                    navigation?.open(.keyboard) { navigation?.open(page) }
                }
            }
            #endif
        }
        .onChange(of: reduceMotion, initial: true) { navigation.reduceMotion = reduceMotion }
        #if POCKET_PREVIEW
        .modifier(SettingsPresentProbing())
        .overlay(alignment: .bottom) {
            if PreviewProbe.on("--settings-slide-meter") || PreviewProbe.on("--settings-perf") {
                SettingsSlideMeterProbe(navigation: navigation)
            }
        }
        #endif
    }

    @ViewBuilder private func page(_ page: SettingsPage?) -> some View {
        if page != nil, SettingsSlideMeter.shared.variant.emptyPages {
            // For the meter's comparison only: a page with nothing to draw.
            ScrollView { Color.clear.frame(height: 900) }.settingsScroll()
        } else {
            content(page)
        }
    }

    @ViewBuilder private func content(_ page: SettingsPage?) -> some View {
        switch page {
        case nil: SettingsHome(scroll: title)
        case .models: ModelView()
        case .webSearch: WebSearchSettingsView()
        case .keyboard: KeyboardSettingsView()
        case .composerStyle: ComposerStyleSettingsView()
        case .launchChat: LaunchChatSettingsView()
        case .notifications: NotificationSettingsView()
        case .developer: DeveloperSettingsView(opening: opening)
        case .experiments: ExperimentsSettingsView()
        case .chatHistory: ChatHistorySettingsView()
        case .pcLink: PCLinkSettingsView()
        case .claude: ClaudeSettingsView()
        case .about: AboutFieluaView()
        case .licenses: LicensesView()
        case .license(let file): LicenseTextView(file: file)
        case .modelFamily(let family): ModelFamilyView(family: family)
        }
    }

    /// The blur under the bar and each page's title, over the pages: the
    /// titles move with their pages, and the blur stays put and follows
    /// the page in view.
    private var chrome: some View {
        ZStack(alignment: .top) {
            SettingsBlurLayer(navigation: navigation, depth: depth, bar: title.barHeight)
            ForEach(levels) { level in
                Group {
                    if let page = level.page, page.hasLargeTitle {
                        SettingsTitle(text: page.title, scroll: pageTitle, reduceMotion: reduceMotion, id: "settings-large-title")
                    } else if let page = level.page {
                        SettingsPageTitle(text: page.title, bar: title.barHeight)
                    } else {
                        SettingsTitle(text: String(localized: "設定"), scroll: title, reduceMotion: reduceMotion)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .modifier(SettingsSlide(navigation: navigation, role: role(level), reduceMotion: reduceMotion,
                                        name: barName(level.page)))
                .accessibilityHidden(level.depth != depth)
                .zIndex(Double(level.depth))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .ignoresSafeArea(edges: .top)
        .allowsHitTesting(false)
        .onGeometryChange(for: CGFloat.self) { $0.safeAreaInsets.top } action: {
            title.barHeight = $0
            pageTitle.barHeight = $0
        }
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: {
            width = $0
            navigation.pixels = $0 * displayScale
        }
    }

    /// A page's name as its slide reads it (1.1.0 (291)): the bar's own
    /// size for the pages' names, 17pt semibold for the large names docked.
    private func barName(_ page: SettingsPage?) -> SettingsBarName {
        let docked = UIFont.systemFont(ofSize: SettingsTitle.small, weight: .semibold)
        guard let page else { return SettingsBarName(String(localized: "設定"), font: docked, scroll: title) }
        if page.hasLargeTitle { return SettingsBarName(page.title, font: docked, scroll: pageTitle) }
        return SettingsBarName(page.title, font: .preferredFont(forTextStyle: .headline))
    }

    private var levels: [SettingsLevel] {
        [SettingsLevel(depth: 0, page: nil)] + navigation.path.enumerated().map { SettingsLevel(depth: $0.offset + 1, page: $0.element) }
    }
    private var depth: Int { navigation.path.count }
    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }

    /// The top page, the one under it, or one out of sight underneath. Only
    /// the slide reads where the top page is, so the sheet itself is not
    /// made again for each frame of it.
    private func role(_ level: SettingsLevel) -> SettingsSlideRole {
        switch level.depth {
        case depth: .top
        case depth - 1: .under
        default: .rest
        }
    }
}

/// The sheet's pages and their slide. A page joins out of sight at the
/// right edge and starts sliding in only at the next frame, after the one
/// that builds it; going back, the page slides out first and leaves after.
/// So the slide's clock never runs while a frame that changes the pages is
/// being made: on the phone 148 lost the first 4 frames of every slide to
/// that frame and then held one, which read as a low frame rate.
@Observable @MainActor fileprivate final class SettingsNavigation {
    private(set) var path: [SettingsPage]
    /// Where the top page is: 0 in view, 1 out at the right edge (waiting
    /// to come in, or gone back out), between while it slides or a swipe
    /// carries it.
    private(set) var top: CGFloat = 0
    /// The back button, which comes and goes with the system's own
    /// animation of the bar as a page starts in or back to the rows is
    /// pressed, as in 148 to 151. From 152 the page was put in place
    /// without SwiftUI's animation and the button came and went with it,
    /// with none (device recording on 1.1.0 (156)).
    private(set) var showsBack: Bool
    let blur = SettingsBlur()
    /// The sheet's edges and corners as the pages see them (1.1.0 (292)).
    var outline = SettingsSheetOutline()
    @ObservationIgnored private let driver = SettingsSlideDriver()
    @ObservationIgnored var reduceMotion = false
    /// The sheet's width in the screen's pixels: a slide moves the top page
    /// by whole ones (0 until the sheet has been laid out: as the curve says).
    @ObservationIgnored var pixels: CGFloat = 0
    @ObservationIgnored var dismiss: () -> Void = {}
    @ObservationIgnored private var sliding = false
    #if POCKET_PREVIEW
    @ObservationIgnored private var refused = "なし"
    /// For the UI test's log: where the pages are and whether a tap is taken.
    var probeState: String {
        "ページ \(path.isEmpty ? "トップ" : path.map(\.title).joined(separator: "›"))・top \(top)・戻る \(showsBack)"
            + "・sliding \(sliding)・動かし中 \(driver.moving)・断った移動 \(refused)"
    }
    #endif

    init(path: [SettingsPage]) {
        self.path = path
        showsBack = !path.isEmpty
    }

    func open(_ page: SettingsPage, then done: @escaping () -> Void = {}) {
        guard !sliding, top == 0 else {
            #if POCKET_PREVIEW
            refused = "\(page.title)（sliding \(sliding)・top \(top)）"
            #endif
            return done()
        }
        sliding = true
        SettingsSlideMeter.shared.asked()
        blur.reset(path.count + 1)
        withoutAnimation {
            path.append(page)
            top = 1
        }
        SettingsNextFrame.run { [self] in
            // The button in its own update, a frame before the page moves:
            // in the page's would have given the page the button's animation.
            showBack(true)
            // Free for the next tap once the page has arrived, as SwiftUI's
            // animation was, while its last fraction of a point settles.
            slide(to: 0, arrived: { self.sliding = false }, completion: done)
        }
    }

    func back(then done: @escaping () -> Void = {}) {
        guard !sliding, !path.isEmpty else { return done() }
        sliding = true
        SettingsSlideMeter.shared.asked()
        if path.count == 1 { showBack(false) }
        SettingsNextFrame.run { [self] in leave(then: done) }
    }

    /// 開発者設定's 「ページ移動を計測」:
    /// from the rows, each page in and back out twice, from the top of its
    /// list and again with the page underneath scrolled under the bar (1.1.0
    /// (283)), then back to the page it started on. A page reached through
    /// another (a series' page over モデル管理) has that one opened first,
    /// unmeasured.
    func measure() {
        let meter = SettingsSlideMeter.shared
        guard !sliding, !meter.running else { return }
        let started = path, rounds = 2
        meter.start()
        Task { @MainActor [self] in
            meter.next(nil, opening: false)
            for _ in 0..<started.count where !path.isEmpty { await goBack() }
            for variant in SettingsSlideMeter.Variant.measured {
                meter.variant = variant
                for condition in SettingsSlideMeter.Condition.allCases {
                    meter.condition = condition
                    for route in SettingsPage.measuredRoutes {
                        guard let page = route.last else { continue }
                        let name = route.map(\.title).joined(separator: "›")
                        meter.next(nil, opening: true)
                        for step in route.dropLast() {
                            try? await Task.sleep(for: .milliseconds(300))
                            await go(step)
                        }
                        for _ in 0..<rounds {
                            try? await Task.sleep(for: .milliseconds(450))
                            // Scrolled: the page underneath has its blur on,
                            // the page coming in none, as after scrolling a
                            // list and tapping one of its rows.
                            if condition == .scrolled { blur.pretendScrolled(depth: path.count) }
                            meter.next(name, opening: true)
                            await go(page)
                            try? await Task.sleep(for: .milliseconds(550))
                            // And going back from a page scrolled down to one
                            // at its top.
                            if condition == .scrolled {
                                blur.pretendScrolled(depth: path.count)
                                blur.reset(path.count - 1)
                            }
                            meter.next(name, opening: false)
                            await goBack()
                            blur.reset(path.count)
                        }
                        meter.next(nil, opening: false)
                        for _ in route.dropLast() {
                            try? await Task.sleep(for: .milliseconds(300))
                            await goBack()
                        }
                    }
                }
            }
            meter.finish(rounds: rounds)
            for page in started { await go(page) }
        }
    }

    #if POCKET_PREVIEW
    /// For the UI check (`--settings-route-demo`, 1.1.0 (283)): モデル管理,
    /// Gemma's page over it and back, ウェブ検索 and 会話履歴, each in and
    /// out at its own time. Before each slide a MENU-MARK line with the
    /// clock, for the recording's frames, and after it the meter's line,
    /// written to the app's tmp folder for the check to read.
    func routeDemo() async {
        // Slowed (`--settings-slow-pages`), 283's way (`--settings-slide-283`)
        // and 290's (`--settings-slide-290`) apart from the others in the
        // marks (1.1.0 (286), Issue #22; 1.1.0 (291)).
        let slow = PreviewProbe.on("--settings-slow-pages")
        let name = (PreviewProbe.on("--dark") ? "dark" : "light") + (reduceMotion ? "-reduced" : "")
            + (slow ? "-slow" : "") + (PreviewProbe.on("--settings-slide-283") ? "-283" : "")
            + (PreviewProbe.on("--settings-slide-290") ? "-290" : "") + (PreviewProbe.on("--settings-slide-291") ? "-291" : "")
        let steps: [(String, SettingsPage?)] = [
            ("models-open", .models), ("gemma-open", .modelFamily("Gemma")), ("gemma-back", nil), ("models-back", nil),
            ("web-open", .webSearch), ("web-back", nil), ("history-open", .chatHistory), ("history-back", nil),
        ]
        // 1.1.0 (292): the sheet's outline as the pages measured it, and
        // (`--settings-corner-layers`) how the windows' layers cut the
        // pages halfway through each slide and after it.
        let layers = PreviewProbe.on("--settings-corner-layers")
        var lines: [String] = [String(format: "SHEET-OUTLINE %@ frame=%@ top=%.1f bottom=%.1f corners=%@ page=%@", name,
                                      "\(outline.frame)", outline.top, outline.bottom, "\(outline.corners)",
                                      "\(SettingsCornerProbe.pageFrame)")]
        for (step, page) in steps {
            lines.append(String(format: "MENU-MARK settings-route-%@-%@ %.3f", name, step, Date().timeIntervalSince1970))
            let halfway: Task<String, Never>? = layers ? Task { @MainActor [self] in
                try? await Task.sleep(for: .milliseconds(slow ? 1100 : 110))
                return "top=\(String(format: "%.2f", top)) \(SettingsCornerProbe.layers())"
            } : nil
            if let page { await go(page) } else { await goBack() }
            if let halfway {
                let mid = await halfway.value
                lines.append("CORNER-LAYERS \(name) \(step) mid \(mid)")
                lines.append("CORNER-LAYERS \(name) \(step) rest \(SettingsCornerProbe.layers())")
            }
            try? await Task.sleep(for: .milliseconds(300))
            lines.append("ROUTE-METER \(name) \(step) \(SettingsSlideMeter.shared.summary ?? "-")")
            try? await Task.sleep(for: .milliseconds(1900))
        }
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("settings-route-marks.txt")
        let earlier = (try? String(contentsOf: file, encoding: .utf8)) ?? ""
        try? (earlier + lines.joined(separator: "\n") + "\n").write(to: file, atomically: true, encoding: .utf8)
    }

    /// For the UI check's profile (`--settings-profile-demo`, 1.1.0 (291)):
    /// モデル管理 in and out ten times, Gemma's page over it twice, then
    /// ウェブ検索, 会話履歴 and キーボードと入力 twice each, each slide's moments
    /// on the media clock (SettingsProfileDemo), then the sheet closed.
    func profileRoute() async {
        let models: [(String, SettingsPage?)] = [("models-open", .models), ("models-back", nil)]
        let gemma: [(String, SettingsPage?)] = [("models-open", .models), ("gemma-open", .modelFamily("Gemma")),
                                                ("gemma-back", nil), ("models-back", nil)]
        let others: [(String, SettingsPage?)] = [("web-open", .webSearch), ("web-back", nil), ("history-open", .chatHistory),
                                                 ("history-back", nil), ("keyboard-open", .keyboard), ("keyboard-back", nil)]
        let steps = Array(repeating: models, count: 10).flatMap { $0 } + Array(repeating: gemma, count: 2).flatMap { $0 }
            + Array(repeating: others, count: 2).flatMap { $0 }
        let meter = SettingsSlideMeter.shared
        var times: [String: Int] = [:]
        for (index, (step, page)) in steps.enumerated() {
            times[step, default: 0] += 1
            let time = times[step] ?? 1
            if SettingsProfileDemo.samples(step, time: time) { await SettingsProfileDemo.gate("\(step)-\(time)") }
            SettingsProfileDemo.mark("STEP \(index + 1) \(step)")
            if let page { await go(page) } else { await goBack() }
            try? await Task.sleep(for: .milliseconds(300))
            if let moments = meter.lastTimes {
                SettingsProfileDemo.mark(String(format: "SLIDE %ld %@ asked=%.4f first=%.4f last=%.4f",
                                                index + 1, step, moments.asked, moments.first, moments.last))
            }
            SettingsProfileDemo.mark("METER \(index + 1) \(step) \(meter.summary ?? "-")")
            try? await Task.sleep(for: .milliseconds(900))
        }
        await SettingsProfileDemo.finish { dismiss() }
    }
    #endif

    /// A page in, or the top one back out, for the measurement: on once it is at rest.
    private func go(_ page: SettingsPage) async {
        await withCheckedContinuation { done in open(page) { done.resume() } }
    }
    private func goBack() async {
        await withCheckedContinuation { done in back { done.resume() } }
    }

    /// A swipe to the right carries the top page with the finger.
    func follow(_ progress: CGFloat) {
        guard !sliding, !path.isEmpty else { return }
        driver.stop()
        withoutAnimation { top = min(max(progress, 0), 1) }
    }

    /// Let go: on out from where the finger left it, or back into view.
    func release(back: Bool) {
        guard !sliding, !path.isEmpty, top > 0 else { return }
        sliding = true
        SettingsSlideMeter.shared.asked()
        if back {
            if path.count == 1 { showBack(false) }
            leave()
        } else {
            slide(to: 0, arrived: { self.sliding = false }) {}
        }
    }

    private func leave(then done: @escaping () -> Void = {}) {
        slide(to: 1) { [self] in
            withoutAnimation {
                path.removeLast()
                top = 0
                if path.isEmpty { showsBack = false }
            }
            sliding = false
            done()
        }
    }

    /// `arrived` when the slide has logically arrived (SwiftUI's own
    /// completion), `completion` once it has come to rest. A page that goes
    /// back leaves only at rest, so nothing jumps where it settles.
    private func slide(to target: CGFloat, arrived: @escaping () -> Void = {}, completion: @escaping () -> Void) {
        let meter = SettingsSlideMeter.shared
        meter.began()
        guard meter.variant.drivesItself else {
            // 152's way, kept for the meter's comparison: on the phone
            // SwiftUI moved it 60 times a second on a 120Hz screen.
            withAnimation(animation) { top = target } completion: {
                arrived()
                meter.ended()
                completion()
            }
            return
        }
        driver.run(from: top, to: target, motion: motion) { [self] value in
            let place = settled(value)
            // Not one pixel further (most of a slide's last third, where the
            // curve creeps the last points home): nothing to make again, and
            // the screen already shows this frame (1.1.0 (283)).
            guard place != top else { return meter.stillBeat() }
            withoutAnimation { top = place }
        } arrived: {
            arrived()
        } done: {
            // The meter counts the last frame too, made after this beat.
            meter.lastBeat()
            completion()
            SettingsNextFrame.run { meter.ended() }
        }
    }

    /// Where a beat puts the top page: on the screen's pixel grid, so a beat
    /// that would move it by less than a pixel leaves everything as it is.
    /// The ends stay exact. Up to 282 every beat moved it, by as little as a
    /// thousandth of a point, and the sheet was made again for nothing.
    private func settled(_ value: CGFloat) -> CGFloat {
        guard pixels > 0, value > 0, value < 1, SettingsSlideMeter.shared.variant.settles else { return value }
        return (value * pixels).rounded() / pixels
    }

    /// The slide's motion: the same as `animation`, worked out frame by frame.
    private var motion: SettingsSlideDriver.Motion {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-slow-pages") { return reduceMotion ? .ease(2) : .spring(Spring(duration: 3, bounce: 0)) }
        #endif
        return reduceMotion ? .ease(0.25) : .spring(Spring(duration: 0.42, bounce: 0))
    }

    private var animation: Animation {
        #if POCKET_PREVIEW
        // Slowed for the UI test's frames of a page coming and going.
        if PreviewProbe.on("--settings-slow-pages") { return reduceMotion ? .easeInOut(duration: 2) : .smooth(duration: 3) }
        #endif
        return reduceMotion ? .easeInOut(duration: 0.25) : .smooth(duration: 0.42)
    }

    private func showBack(_ shown: Bool) {
        guard showsBack != shown else { return }
        withAnimation(animation) { showsBack = shown }
    }

    private func withoutAnimation(_ change: () -> Void) {
        var transaction = Transaction()
        transaction.disablesAnimations = true
        withTransaction(transaction, change)
    }
}

/// Moves a slide at the display's own beat (1.1.0 (153)). On the phone
/// SwiftUI's animation of the slide was drawn 60 times a second on the
/// 120Hz screen (152's meter: 26 frames, 60fps, longest gap 17ms), while
/// iOS's own sheets and scrolling ran at 120: it lost no frames, it only
/// asked for half as many. A display link asks for the screen's full rate,
/// and at each beat the slide is set where it will be when that frame
/// appears, on the same curve SwiftUI's animation used.
@MainActor final class SettingsSlideDriver: NSObject {
    enum Motion {
        case spring(Spring)
        case ease(TimeInterval)
    }

    private var link: CADisplayLink?
    private var startedAt: CFTimeInterval?
    private var from: CGFloat = 0
    private var to: CGFloat = 0
    private var motion = Motion.ease(0.25)
    private var step: (CGFloat) -> Void = { _ in }
    private var arrived: (() -> Void)?
    private var done: () -> Void = {}

    func run(from: CGFloat, to: CGFloat, motion: Motion, step: @escaping (CGFloat) -> Void,
             arrived: @escaping () -> Void, done: @escaping () -> Void) {
        link?.invalidate()
        self.from = from
        self.to = to
        self.motion = motion
        self.step = step
        self.arrived = arrived
        self.done = done
        startedAt = nil
        // The link keeps its target until it is invalidated.
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFrameRateRange = CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    #if POCKET_PREVIEW
    var moving: Bool { link != nil }
    #endif

    /// Stops where it is: a finger has taken the page.
    func stop() {
        link?.invalidate()
        link = nil
        step = { _ in }
        arrived = nil
        done = {}
    }

    @objc private func tick(_ link: CADisplayLink) {
        let start = startedAt ?? link.timestamp
        startedAt = start
        let time = link.targetTimestamp - start
        let (progress, finished) = Self.progress(motion, at: time)
        step(finished ? to : from + (to - from) * progress)
        if let arrived, finished || time >= Self.arrival(motion) {
            self.arrived = nil
            arrived()
        }
        guard finished else { return }
        let done = self.done
        stop()
        done()
    }

    /// When SwiftUI's animation would call itself complete: a spring at its
    /// duration, a few points short of rest.
    private static func arrival(_ motion: Motion) -> TimeInterval {
        switch motion {
        case .spring(let spring): spring.duration
        case .ease(let duration): duration
        }
    }

    /// How far along the slide is, 0 to 1, and whether it has come to rest
    /// (within a fifth of a point on the widest phone).
    private static func progress(_ motion: Motion, at time: TimeInterval) -> (CGFloat, Bool) {
        switch motion {
        case .spring(let spring):
            let value = spring.value(target: 1.0, time: time)
            return (CGFloat(value), time >= spring.settlingDuration || (time >= spring.duration && abs(1 - value) < 0.0004))
        case .ease(let duration):
            let t = min(max(time / duration, 0), 1)
            return (CGFloat(UnitCurve.easeInOut.value(at: t)), t >= 1)
        }
    }
}

/// Runs once at the display's next frame, after the frame being made now.
@MainActor private final class SettingsNextFrame: NSObject {
    private var link: CADisplayLink?
    private var body: (() -> Void)?

    static func run(_ body: @escaping () -> Void) {
        let next = SettingsNextFrame()
        next.body = body
        // The link keeps its target until it is invalidated.
        let link = CADisplayLink(target: next, selector: #selector(tick))
        next.link = link
        link.add(to: .main, forMode: .common)
    }

    @objc private func tick() {
        link?.invalidate()
        link = nil
        let body = self.body
        self.body = nil
        body?()
    }
}

#if POCKET_PREVIEW
/// The meter's last reading for the UI test's log, or, while 開発者設定's
/// measurement is tested, where the pages are once it has finished.
private struct SettingsSlideMeterProbe: View {
    let navigation: SettingsNavigation

    var body: some View {
        if !PreviewProbe.on("--settings-perf") {
            label(SettingsSlideMeter.shared.summary ?? "まだ移動していません", id: "settings-slide-meter")
        } else if SettingsSlideMeter.shared.running {
            label("計測中", id: "settings-nav-state")
        } else {
            // Read again twice a second, as `sliding` is not observed.
            TimelineView(.periodic(from: .now, by: 0.5)) { _ in
                label(navigation.probeState, id: "settings-nav-state")
            }
        }
    }

    private func label(_ text: String, id: String) -> some View {
        Text(text)
            .font(.system(size: 9)).padding(3).background(.background)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(text)
            .accessibilityIdentifier(id).allowsHitTesting(false)
    }
}
#endif

private struct SettingsLevel: Hashable, Identifiable {
    let depth: Int
    let page: SettingsPage?
    var id: Self { self }
}

private enum SettingsSlideRole {
    case top, under, rest
}

/// Reads where the top page is for one page or title, so each frame of a
/// slide makes only these again, not the sheet or the pages.
private struct SettingsSlide: ViewModifier {
    let navigation: SettingsNavigation
    let role: SettingsSlideRole
    let reduceMotion: Bool
    var metered = false
    /// A page, not its title over the bar: the page underneath tells the
    /// meter where it still shows under the top one, and is darkened by how
    /// much of it is covered (1.1.0 (291)).
    var page = false
    /// A page's name over the bar: fades before it reaches the bar's
    /// buttons (1.1.0 (291)).
    var name: SettingsBarName? = nil
    /// Where a page stands among the pages (1.1.0 (292)): the sheet's
    /// outline in its own space. It changes only with the sheet's size.
    @State private var frame: CGRect = .zero
    func body(content: Content) -> some View {
        // A page out of sight underneath does not read it at all, so it is
        // not made again for each frame of a slide two pages above it.
        let top = role == .rest ? 0 : navigation.top
        let position: CGFloat = switch role {
        case .top: top
        case .under: top - 1
        case .rest: -1
        }
        // The names over the bar have no outline.
        let outline = page ? navigation.outline.seen(from: frame) : SettingsPageOutline()
        // Changes only as a slide starts and ends, so only what reads it
        // (the キーボード phones, モデル管理's alert) is made again.
        return content
            .modifier(SettingsPageFrame(measures: page, frame: $frame))
            .modifier(SettingsSlideEffect(position: position, reduceMotion: reduceMotion, metered: metered,
                                          measuresOverlap: page && role == .under, shades: page, name: name,
                                          outline: outline))
            .environment(\.settingsPageInView, role == .top && top == 0)
    }
}

/// A page's frame among the pages (1.1.0 (292)), measured as it is laid
/// out, not as it slides; the names over the bar measure none.
private struct SettingsPageFrame: ViewModifier {
    let measures: Bool
    @Binding var frame: CGRect
    @ViewBuilder func body(content: Content) -> some View {
        if measures {
            content.onGeometryChange(for: CGRect.self) { $0.frame(in: .named(SettingsSheetOutline.space)) } action: {
                frame = $0
                #if POCKET_PREVIEW
                SettingsCornerProbe.pageFrame = $0
                #endif
            }
        } else {
            content
        }
    }
}

/// The sheet as its pages see it (1.1.0 (292)): its frame among the pages,
/// under the bar and below the last row too, and its corners as iOS gives
/// them for the sheet (`containerCornerInsets`). A page sliding in or out
/// is cut to it, so its corners are as round as the sheet's own.
struct SettingsSheetOutline: Equatable {
    static let space = "settings-pages"
    var frame: CGRect = .zero
    var corners = RectangleCornerInsets()
    /// The radius of the sheet's top corners and of its bottom ones; where
    /// iOS gives none, the cards' (FieluaRadius.card).
    var top: CGFloat { Self.radius(corners.topLeading, corners.topTrailing) }
    var bottom: CGFloat { Self.radius(corners.bottomLeading, corners.bottomTrailing) }
    private static func radius(_ leading: CGSize, _ trailing: CGSize) -> CGFloat {
        let given = max(min(leading.width, leading.height), min(trailing.width, trailing.height))
        return given > 0 ? given : FieluaRadius.card
    }
    /// The same in the space of a page standing at `page` among the pages.
    func seen(from page: CGRect) -> SettingsPageOutline {
        SettingsPageOutline(sheet: frame.offsetBy(dx: -page.minX, dy: -page.minY), top: top, bottom: bottom)
    }
}

/// The sheet's outline in a page's own space (1.1.0 (292)).
struct SettingsPageOutline: Equatable {
    var sheet: CGRect = .zero
    var top: CGFloat = 0
    var bottom: CGFloat = 0
    /// How far past the leading edge of the page on top the page underneath
    /// still shows: in that page's corners.
    var corner: CGFloat { max(top, bottom) }
}

/// A clear view out to the sheet's edges, behind the pages, that measures
/// the sheet for them (1.1.0 (292)).
private struct SettingsSheetProbe: View {
    let navigation: SettingsNavigation
    var body: some View {
        Color.clear
            .ignoresSafeArea()
            .onGeometryChange(for: SettingsSheetOutline.self) { proxy in
                SettingsSheetOutline(frame: proxy.frame(in: .named(SettingsSheetOutline.space)),
                                     corners: proxy.containerCornerInsets)
            } action: { navigation.outline = $0 }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

/// A page's own paper while it slides (1.1.0 (292)): the sheet's paper
/// (PaperBackground, out to the sheet's edges, its grain where the sheet's
/// is), so the page's rounded corners show against the page underneath.
/// At rest it is there but not drawn: the page lies on the sheet's own.
private struct SettingsSlidePaper: View {
    let shown: Bool
    var body: some View {
        PaperBackground()
            .ignoresSafeArea()
            .opacity(shown ? 1 : 0)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

/// Where a page stands in the sheet: 0 in view, 1 out to the right (coming
/// or going), -1 under the page above it, a third of the way out to the
/// left. With Reduce Motion they fade in place, one after the other.
///
/// Since 1.1.0 (286) (fielua-reports Issue #22) the top page covers the one
/// underneath, as a page of paper slid over another would: the page
/// underneath is cut where the top page begins and shows only to the left
/// of it, still going a third of the way out and fading as before, and the
/// top page comes in and goes out whole. Until 283 neither had a backing of
/// its own and both were partly see-through together: a third of the way
/// in, the rows of the page coming read over the rows of the page going
/// (Hachimoto さん's iPhone, 283 in dark, 設定 to ウェブ検索, モデル管理 and
/// 会話履歴). The sheet's paper and glass stay as they are: the cut is a
/// clip, not a backing, so the chat still shows through the glass as before.
///
/// Since 1.1.0 (291) the page underneath no longer fades as it goes: it
/// stays whole where it shows and is darkened by how much of it is
/// covered, as iOS's own pages are. Until 290 it was gone a little past
/// halfway, so swiped back the page coming showed as bare paper until then
/// (Hachimoto さん's recording beside 設定's own, 2026-11-16). How dark:
/// that recording's own pages, 13% black when wholly covered, none when
/// uncovered. The cut stays, so the two pages' rows still never read one
/// over the other. And the pages' names over the bar fade before they reach
/// 戻る or the close button, where until 290 the name of the page going
/// slid under the close button (the same recording, モデル管理).
///
/// Since 1.1.0 (292) the page on top, while it slides in or out, is cut to
/// the sheet's own outline, its leading corners as round as the sheet's
/// (top and bottom each its own), over a paper of its own; the page
/// underneath shows, darkened, in those corners. Until 291 the page had no
/// edge of its own: the page underneath was cut straight, and the page
/// coming met the sheet's top and bottom square (Hachimoto さん's directive
/// of 2026-11-17). Its content is cut by the same curve, so nothing of it
/// shows past the corners. At rest the page lies on the sheet's paper and
/// is cut by nothing, as before.
private struct SettingsSlideEffect: ViewModifier, Animatable {
    var position: CGFloat
    let reduceMotion: Bool
    /// The top page tells the meter each frame it moves.
    var metered = false
    /// The page underneath tells the meter where it shows under the top one.
    var measuresOverlap = false
    /// A page, darkened while it is partly covered (1.1.0 (291)).
    var shades = false
    /// A name over the bar, kept clear of the bar's buttons (1.1.0 (291)).
    var name: SettingsBarName? = nil
    /// A page: the sheet's outline in its own space (1.1.0 (292)).
    var outline = SettingsPageOutline()
    var animatableData: CGFloat {
        get { position }
        set { position = newValue }
    }
    func body(content: Content) -> some View {
        if metered { SettingsSlideMeter.shared.frame() }
        let shift = Self.shift(position, reduceMotion)
        let opacity = Self.opacity(position, reduceMotion)
        if opacity > 0, opacity < 1 { SettingsSlideMeter.shared.blended() }
        if measuresOverlap, position > -1, position < 0 { measureOverlap(opacity) }
        let shade = shades ? Self.shade(position, reduceMotion) : 0
        // How far a name stands in the bar; read only while it is moving, so
        // a page's scrolling does not make this again at rest.
        let half = name?.half ?? 0
        let docked = shift == 0 || opacity == 0 || !SettingsSlideMeter.shared.variant.keepsUnder ? 0 : (name?.docked ?? 0)
        // 1.1.0 (292): the page on top, while it slides, has the sheet's
        // outline and its own paper; the page underneath shows a little
        // further, in its corners.
        let rounded = shades && !outline.sheet.isEmpty && Self.rounds(position, reduceMotion)
        let beyond = shades && !outline.sheet.isEmpty && SettingsSlideMeter.shared.variant.rounds ? outline.corner : 0
        // Always there, so a page keeps its place in the view graph (and its
        // list where it was scrolled) as it goes from top to underneath; at
        // rest it cuts nothing.
        return content
            .background {
                if shades { SettingsSlidePaper(shown: rounded) }
            }
            .overlay {
                // The sheet's whole height, under the bar too, as iOS's own
                // shade; the cut below keeps it off the top page.
                if shade > 0 { Color.black.opacity(shade).ignoresSafeArea().allowsHitTesting(false) }
            }
            .clipShape(SettingsPageCut(share: Self.uncovered(position, reduceMotion), beyond: beyond,
                                       outline: rounded ? outline : nil))
            .opacity(opacity)
            .visualEffect { view, geometry in
                view.offset(x: geometry.size.width * shift, y: 0)
                    .opacity(docked > 0 ? Self.clearance(half: half, docked: docked, shift: shift, width: geometry.size.width) : 1)
            }
    }

    /// Whether the page on top has the sheet's outline (1.1.0 (292)): while
    /// it slides in or out, not at rest, and not with Reduce Motion, where
    /// it fades in place.
    private static func rounds(_ position: CGFloat, _ reduceMotion: Bool) -> Bool {
        position > 0 && position < 1 && !reduceMotion && SettingsSlideMeter.shared.variant.rounds
    }

    /// How dark the page underneath is: 13% black when wholly covered, as
    /// in the recording of iOS's own 設定, none when uncovered (1.1.0 (291)).
    private static func shade(_ position: CGFloat, _ reduceMotion: Bool) -> Double {
        guard position < 0, position > -1, !reduceMotion, SettingsSlideMeter.shared.variant.keepsUnder else { return 0 }
        return 0.13 * Double(-position)
    }

    /// A name's opacity as it moves along the bar (1.1.0 (291)): whole while
    /// its text is clear of 戻る and the close button (each 44pt, 16pt in
    /// from the sheet's edge), gone as it reaches either. It fades over the
    /// last 32pt before them, or over all the room it had at rest if that
    /// is less, so at rest it is always whole. `docked`: how far the name is
    /// in the bar; モデル管理's and 設定's large names below it are not faded.
    nonisolated private static func clearance(half: CGFloat, docked: CGFloat, shift: CGFloat, width: CGFloat) -> Double {
        let buttons: CGFloat = 62
        // No wider than its frame between the buttons (SettingsPageTitle).
        let text = min(half, max(width / 2 - 72, 0))
        let restRoom = width / 2 - text - buttons
        let room = restRoom - abs(shift) * width
        let clear = restRoom > 0 ? min(max(room / min(32, restRoom), 0), 1) : 0
        return Double(1 - docked * (1 - clear))
    }

    /// How far a page stands to the side, as a share of the sheet's width.
    private static func shift(_ position: CGFloat, _ reduceMotion: Bool) -> CGFloat {
        reduceMotion ? 0 : (position >= 0 ? position : position * 0.3)
    }

    /// How much of the page underneath, from its leading edge in its own
    /// place, the top page leaves in view: up to where the top page begins
    /// (at `position + 1` of the sheet's width; the page underneath stands
    /// `position * 0.3` of it to the left). Infinite: nothing is cut.
    private static func uncovered(_ position: CGFloat, _ reduceMotion: Bool) -> CGFloat {
        guard position < 0, !reduceMotion, SettingsSlideMeter.shared.variant.covers else { return .infinity }
        return max(1 + 0.7 * position, 0)
    }

    private static func opacity(_ position: CGFloat, _ reduceMotion: Bool) -> Double {
        let variant = SettingsSlideMeter.shared.variant
        if reduceMotion {
            // One after the other: the page going is gone by halfway, the
            // one coming starts there (1.1.0 (286)). Until 283 they crossed,
            // both half there in the same place halfway.
            let distance = Double(min(abs(position), 1))
            guard variant.covers else { return settled(1 - distance) }
            return settled(max(1 - 2 * distance, 0))
        }
        // For the meter's comparison only: whole or hidden, never between.
        if !variant.fades { return position >= 0 ? (position < 1 ? 1 : 0) : (position > -0.5 ? 1 : 0) }
        // The top page whole from its first pixel in to its last one out;
        // until 283 it was whole only from halfway in.
        if position >= 0, variant.covers { return position < 1 ? 1 : 0 }
        // 1.1.0 (291): the page underneath whole wherever it shows, hidden
        // once it is wholly covered (less than a point of it left).
        if variant.keepsUnder { return position > -0.998 ? 1 : 0 }
        return settled(position >= 0 ? min(max((1 - position) / 0.45, 0), 1) : min(max(1 + position / 0.55, 0), 1))
    }

    /// Within 2% of whole it is whole, within 2% of hidden hidden (1.1.0
    /// (283)). A page partly see-through is drawn apart and blended at each
    /// frame; going back, the page underneath crept from 98% to 100% over
    /// the slide's last third, drawn so at every 120Hz frame for no
    /// difference anyone could see.
    private static func settled(_ value: Double) -> Double {
        guard SettingsSlideMeter.shared.variant.settles else { return value }
        return value >= 0.98 ? 1 : value <= 0.02 ? 0 : value
    }

    /// For the meter (1.1.0 (286)): the width this page, underneath, still
    /// shows where the top page is, by the fainter one's opacity.
    private func measureOverlap(_ opacity: Double) {
        let top = position + 1
        let topOpacity = Self.opacity(top, reduceMotion)
        guard opacity > 0, topOpacity > 0 else { return }
        // In place with Reduce Motion: the whole width, where both show.
        let shared: CGFloat
        if reduceMotion {
            shared = 1
        } else {
            let right = min(Self.uncovered(position, reduceMotion), 1) + Self.shift(position, reduceMotion)
            shared = max(right - Self.shift(top, reduceMotion), 0)
        }
        SettingsSlideMeter.shared.overlapped(Double(shared) * min(opacity, topOpacity))
    }
}

/// What a page shows of itself (SettingsUncovered until 1.1.0 (291)).
/// Underneath: from far to the left of the page to `share` of its width,
/// and `beyond` points more, where the corners of the page on top leave it
/// in view (1.1.0 (292)); far above and below it. A plain rectangle, a
/// clip, not a mask drawn apart. On top while it slides (`outline`, 1.1.0
/// (292)): the sheet's outline from the page's own leading edge, its top
/// and bottom where the sheet's are and its corners as round, and on past
/// the page's trailing edge, where the sheet itself cuts it. At rest:
/// nothing is cut.
private struct SettingsPageCut: Shape {
    let share: CGFloat
    var beyond: CGFloat = 0
    var outline: SettingsPageOutline? = nil
    func path(in rect: CGRect) -> Path {
        let far: CGFloat = 100_000
        if let outline {
            let sheet = CGRect(x: rect.minX, y: outline.sheet.minY, width: 2 * rect.width, height: outline.sheet.height)
            return UnevenRoundedRectangle(topLeadingRadius: outline.top, bottomLeadingRadius: outline.bottom,
                                          bottomTrailingRadius: 0, topTrailingRadius: 0, style: .continuous).path(in: sheet)
        }
        let trailing = share.isFinite ? rect.minX + rect.width * share + beyond : far
        return Path(CGRect(x: -far, y: -far, width: trailing + far, height: 2 * far))
    }
}

/// A swipe to the right anywhere on a page goes back, following the finger.
/// Vertical scrolling waits for it to fail, which it does as soon as the
/// movement is mostly vertical (as the history drawer's pan). Segmented
/// pickers, sliders and switches keep their own sideways drags.
private struct SettingsBackSwipe: UIGestureRecognizerRepresentable {
    let enabled: Bool
    let changed: (CGFloat) -> Void
    let ended: (CGFloat, CGFloat) -> Void
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    func makeUIGestureRecognizer(context: Context) -> UIPanGestureRecognizer {
        let pan = UIPanGestureRecognizer()
        pan.maximumNumberOfTouches = 1
        pan.delegate = context.coordinator
        return pan
    }
    func updateUIGestureRecognizer(_ pan: UIPanGestureRecognizer, context: Context) {
        pan.isEnabled = enabled
    }
    func handleUIGestureRecognizerAction(_ pan: UIPanGestureRecognizer, context: Context) {
        let translation = pan.translation(in: pan.view).x
        switch pan.state {
        case .began, .changed: changed(translation)
        case .ended: ended(translation, pan.velocity(in: pan.view).x)
        case .cancelled, .failed: ended(0, 0)
        default: break
        }
    }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            guard let pan = gestureRecognizer as? UIPanGestureRecognizer else { return false }
            let velocity = pan.velocity(in: pan.view)
            return velocity.x > 0 && velocity.x > abs(velocity.y) * 1.2
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldBeRequiredToFailBy other: UIGestureRecognizer) -> Bool {
            guard let scroll = other.view as? UIScrollView, other === scroll.panGestureRecognizer else { return false }
            return scroll.contentSize.width <= scroll.bounds.width + 1
        }
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
            var view = touch.view
            while let current = view {
                if current is UISegmentedControl || current is UISlider || current is UISwitch { return false }
                if let scroll = current as? UIScrollView, scroll.contentSize.width > scroll.bounds.width + 1 { return false }
                view = current.superview
            }
            return true
        }
    }
}

// MARK: - The blur under the bar

/// Each open page's blur under the bar, from 0 to 1 by how far its list
/// has scrolled, by the page's depth in the sheet.
@Observable @MainActor fileprivate final class SettingsBlur {
    private(set) var strengths: [Int: CGFloat] = [:]
    /// Full once the list has gone 24pt under the bar past `start`.
    func follow(_ offset: CGFloat, depth: Int, from start: CGFloat) {
        let strength = min(max((offset - start) / 24, 0), 1)
        if strengths[depth] != strength { strengths[depth] = strength }
    }
    func reset(_ depth: Int) { strengths[depth] = 0 }
    /// For 「ページ移動を計測」: the page at this depth as if its list had
    /// gone under the bar, its blur whole.
    func pretendScrolled(depth: Int) { strengths[depth] = 1 }
}

/// Reads the strengths itself, so scrolling redraws only the blur.
private struct SettingsBlurLayer: View {
    let navigation: SettingsNavigation
    let depth: Int
    let bar: CGFloat
    var body: some View {
        let _ = SettingsSlideMeter.drew("ぼかし")
        let blur = navigation.blur
        let shown = blur.strengths[depth] ?? 0, below = blur.strengths[depth - 1] ?? 0
        // The top page's place in its slide: the blur goes with the page in
        // view. Read only when the two differ, so a slide between two pages
        // at rest does not draw the blur again at every frame.
        let top = shown == below ? 0 : navigation.top
        SettingsTopBlur(strength: shown + (below - shown) * top)
            .frame(height: bar)
    }
}

/// The chat header's blur (ChatChromeBackdrop), from the sheet's top to
/// just below the bar, faded in as the list goes under it. At rest there is
/// nothing over the glass. It changes frame by frame between two pages.
private struct SettingsTopBlur: View, Animatable {
    var strength: CGFloat
    var animatableData: CGFloat {
        get { strength }
        set { strength = newValue }
    }
    var body: some View {
        // In 5% steps: each new strength masks the native blur again, too
        // much work for every frame of a slide at 120Hz.
        ChatChromeBackdrop(edge: .top, strength: 0.96 * (strength * 20).rounded() / 20, reachesScreenEdge: false)
    }
}

private struct SettingsScrollReport: ViewModifier {
    @Environment(\.settingsScrolled) private var scrolled
    @Environment(\.settingsLargeTitle) private var largeTitle
    @ViewBuilder func body(content: Content) -> some View {
        let reported = content
            // The blur above stands in for the system's edge effect.
            .scrollEdgeEffectHidden(true, for: .top)
            .onScrollGeometryChange(for: CGFloat.self) { $0.contentOffset.y + $0.contentInsets.top } action: { _, offset in
                largeTitle?.offset = offset
                scrolled(offset)
            }
        if let largeTitle {
            // Let go partway, the name settles large or in the bar, as on
            // 設定's rows; opened again, it starts large.
            reported
                .scrollTargetBehavior(SettingsTitleSnap(travel: Self.snaps ? largeTitle.travel : 0))
                .onAppear { largeTitle.offset = 0 }
        } else {
            reported
        }
    }

    private static var snaps: Bool {
        #if POCKET_PREVIEW
        // As on 設定's rows: photographed partway, a snap would never let it rest.
        if PreviewProbe.on("--settings-title-probe") { return false }
        #endif
        return true
    }
}

extension View {
    /// On each page's list: under the bar it blurs like the chat's header.
    func settingsScroll() -> some View { modifier(SettingsScrollReport()) }
    /// Above the list of a page with a large name: the room the name rests in.
    func settingsTitleRoom() -> some View { padding(.top, SettingsTitle.room) }
}

/// A page's name, as its slide reads it (1.1.0 (291)): half its text's
/// width in the bar, and for 設定's and モデル管理's large names how far
/// they have gone up into the bar.
private struct SettingsBarName {
    let half: CGFloat
    /// The large name's scrolling; nil for a name always in the bar.
    let scroll: SettingsTitleScroll?
    init(_ text: String, font: UIFont, scroll: SettingsTitleScroll? = nil) {
        half = ceil((text as NSString).size(withAttributes: [.font: font]).width) / 2
        self.scroll = scroll
    }
    /// 1 in the bar, 0 large below it.
    @MainActor var docked: CGFloat {
        guard let scroll else { return 1 }
        return scroll.travel > 0 ? min(max(scroll.offset / scroll.travel, 0), 1) : 0
    }
}

/// A page's name in the middle of the bar, in line with its buttons.
private struct SettingsPageTitle: View {
    let text: String
    let bar: CGFloat
    var body: some View {
        let _ = SettingsSlideMeter.drew("ページ名")
        Text(text)
            .font(.headline)
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .frame(height: SettingsTitle.line)
            // Clear of the back and close buttons.
            .padding(.horizontal, 72)
            .offset(y: SettingsTitle.dock(bar: bar) - SettingsTitle.line / 2)
            .accessibilityAddTraits(.isHeader)
            .accessibilityIdentifier("settings-page-title")
    }
}

// MARK: - The six rows

private struct SettingsHome: View {
    let scroll: SettingsTitleScroll
    @Environment(\.settingsScrolled) private var scrolled
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// 開発者設定 is hidden while its switch is off: three swipes with three
    /// fingers, up or down, show it for this visit (as the switch was shown
    /// at the bottom of モデルと設定 before).
    @State private var developerRevealed = ProcessInfo.processInfo.arguments.contains("--developer-unlocked")
    @State private var revealSwipes = 0
    @State private var lastRevealSwipe = Date.distantPast

    var body: some View {
        let _ = SettingsSlideMeter.drew("トップ")
        let travel = scroll.travel
        ScrollView {
            // However short the list, it scrolls far enough for the title to
            // settle in the bar and stay there: one screen under the bar
            // plus the title's way up (run 286: measured from the list's
            // own frame, the room came out short and nothing scrolled).
            ZStack(alignment: .top) {
                Color.clear
                    .containerRelativeFrame(.vertical) { length, _ in length + travel }
                    .accessibilityHidden(true)
                rows
            }
        }
        // On the list itself: set over the title too, it would take the
        // title's own identifier.
        .accessibilityIdentifier("settings-home")
        .scrollTargetBehavior(SettingsTitleSnap(travel: snaps ? travel : 0))
        .scrollEdgeEffectHidden(true, for: .top)
        .onScrollGeometryChange(for: ScrollGeometry.self) { $0 } action: { _, geometry in
            scroll.follow(geometry)
            scrolled(scroll.offset)
        }
        .gesture(ThreeFingerVerticalSwipe { _ in registerRevealSwipe() })
        .onAppear {
            // Kept for this visit even after its switch is turned off.
            if showDeveloperSettings { developerRevealed = true }
        }
    }

    private var rows: some View {
        VStack(spacing: 24) {
            SettingsGroup {
                SettingsRow("モデル管理", icon: "square.stack.3d.up", page: .models)
                SettingsDivider()
                // The saved conversations, kept in the app alone since
                // 1.1.0 (251): chosen and deleted here.
                SettingsRow("会話履歴", icon: "clock.arrow.circlepath", page: .chatHistory)
                SettingsDivider()
                // Its own page since 1.1.0 (230), at the end of モデル管理 before.
                // The magnifier, as 言語 has the globe.
                SettingsRow("ウェブ検索", icon: "magnifyingglass", page: .webSearch)
                SettingsDivider()
                SettingsRow("キーボードと入力", icon: "keyboard", page: .keyboard)
                SettingsDivider()
                SettingsRow("通知", icon: "bell", page: .notifications)
                SettingsDivider()
                SettingsLanguageRow()
                SettingsDivider()
                SettingsPCRow()
                SettingsDivider()
                SettingsClaudeRow()
            }
            // Features on trial (1.1.0 (250)), apart from the settings that
            // stay: off until turned on there.
            SettingsGroup {
                SettingsRow("試験機能を試してみる", icon: "flask", page: .experiments)
            }
            SettingsGroup {
                SettingsRow("Fieluaの情報", icon: "info.circle", page: .about)
                SettingsDivider()
                SettingsRow("オープンソースライセンス", icon: "doc.text", page: .licenses)
            }
            if showDeveloperSettings || developerRevealed {
                SettingsGroup {
                    SettingsRow("開発者設定", icon: "hammer", page: .developer)
                }
                .transition(.opacity)
            }
        }
        .padding(.horizontal, 20)
        // Room for the title, which is drawn over the list.
        .padding(.top, SettingsTitle.room)
        .padding(.bottom, 20)
    }

    /// Three swipes within 5 seconds. All the rows are always in view, so
    /// unlike モデルと設定's list there is no bottom to reach first.
    private func registerRevealSwipe() {
        guard !developerRevealed else { return }
        let now = Date()
        if now.timeIntervalSince(lastRevealSwipe) > 5 { revealSwipes = 0 }
        revealSwipes += 1; lastRevealSwipe = now
        guard revealSwipes >= 3 else { return }
        revealSwipes = 0
        withAnimation(FieluaMotion.change(reduceMotion)) { developerRevealed = true }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    private var snaps: Bool {
        #if POCKET_PREVIEW
        // The title's frames are photographed partway, where a snap would
        // never let it rest.
        if PreviewProbe.on("--settings-title-probe") { return false }
        #endif
        return true
    }
}

struct SettingsGroup<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        VStack(spacing: 0) { content }
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .fieluaCard(cornerRadius: 20)
    }
}

private struct SettingsDivider: View {
    /// Under the text, past the icon's column, as iOS's lists do.
    var body: some View { Divider().padding(.leading, 58) }
}

private struct SettingsRow: View {
    let title: LocalizedStringKey
    let icon: String
    let page: SettingsPage
    @Environment(\.openSettingsPage) private var openPage
    init(_ title: LocalizedStringKey, icon: String, page: SettingsPage) { self.title = title; self.icon = icon; self.page = page }
    var body: some View {
        let _ = SettingsSlideMeter.drew("行")
        Button { openPage(page) } label: {
            SettingsRowLabel(title: title, icon: icon) {
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityIdentifier("settings-row-\(page)")
    }
}

/// A choice on a page under the six rows (キーボードと入力): its name, what
/// is chosen, and the page that chooses it, as in iOS's own lists. No icon,
/// as on オープンソースライセンス.
private struct SettingsValueRow: View {
    let title: LocalizedStringKey
    let value: String
    let page: SettingsPage
    @Environment(\.openSettingsPage) private var openPage
    init(_ title: LocalizedStringKey, value: String, page: SettingsPage) {
        self.title = title; self.value = value; self.page = page
    }
    var body: some View {
        let _ = SettingsSlideMeter.drew("行")
        Button { openPage(page) } label: {
            HStack(spacing: 8) {
                Text(title)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Group {
                    Text(verbatim: value)
                        .foregroundStyle(.secondary)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
                .accessibilityHidden(true)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .frame(minHeight: 52)
            .contentShape(Rectangle())
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityValue(Text(verbatim: value))
        .accessibilityIdentifier("settings-row-\(page)")
    }
}

/// 言語 (1.1.0 (183)): Fielua shows the language iOS has for it, set per
/// app in iOS's Settings (日本語, English, 简体中文, 한국어; others get
/// English). The row names it and opens Fielua's page there.
private struct SettingsLanguageRow: View {
    @Environment(\.openURL) private var openURL
    var body: some View {
        Button {
            if let settings = URL(string: UIApplication.openSettingsURLString) { openURL(settings) }
        } label: {
            SettingsRowLabel(title: "言語", icon: "globe") {
                HStack(spacing: 6) {
                    Text(verbatim: Self.current)
                        .foregroundStyle(.secondary)
                    Image(systemName: "arrow.up.forward")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
            }
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityIdentifier("settings-row-language")
        .accessibilityValue(Text(verbatim: Self.current))
        .accessibilityHint("iOSの設定で、Fieluaの言語を変更できます")
    }

    /// The language the app shows, in its own words.
    static var current: String {
        switch Bundle.main.preferredLocalizations.first ?? "ja" {
        case "en": "English"
        case "zh-Hans": "简体中文"
        case "zh-Hant": "繁體中文"
        case "ko": "한국어"
        default: "日本語"
        }
    }
}

/// PCと接続 (1.1.0 (253)): the registered PC's name, or 未登録, and its
/// page. Locked as 「今後のアップデートで対応」 before; the identifier stays.
private struct SettingsPCRow: View {
    @ObservedObject private var link = PCLinkStore.shared
    @Environment(\.openSettingsPage) private var openPage
    var body: some View {
        let _ = SettingsSlideMeter.drew("行")
        let value = link.paired?.pcName ?? String(localized: "未登録")
        Button { openPage(.pcLink) } label: {
            SettingsRowLabel(title: "PCと接続", icon: "laptopcomputer") {
                HStack(spacing: 6) {
                    Text(verbatim: value)
                        .lineLimit(1)
                        .foregroundStyle(.secondary)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
            }
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityValue(Text(verbatim: value))
        .accessibilityIdentifier("settings-row-pc")
    }
}

/// Claude (1.1.0 (257)): 使えます, why not, or 未登録, and its page.
private struct SettingsClaudeRow: View {
    @ObservedObject private var link = ClaudeLinkStore.shared
    @Environment(\.openSettingsPage) private var openPage
    var body: some View {
        let _ = SettingsSlideMeter.drew("行")
        let value: String = switch link.state {
        case .none: String(localized: "未登録")
        case .ready: String(localized: "使えます")
        case .checking: String(localized: "確かめています…")
        default: String(localized: "使えません")
        }
        Button { openPage(.claude) } label: {
            SettingsRowLabel(title: "Claude", icon: "cloud") {
                HStack(spacing: 6) {
                    Text(verbatim: value)
                        .lineLimit(1)
                        .foregroundStyle(.secondary)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.tertiary)
                }
            }
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityValue(Text(verbatim: value))
        .accessibilityIdentifier("settings-row-claude")
    }
}

struct SettingsRowLabel<Trailing: View>: View {
    let title: LocalizedStringKey
    let icon: String
    var note: LocalizedStringKey?
    /// A row that cannot be used yet keeps its icon in the row's grey.
    var quiet = false
    @ViewBuilder let trailing: Trailing
    var body: some View {
        HStack(spacing: 14) {
            // Line symbols in the warm grey (golden in 1.1.0 (212)).
            if quiet {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .regular))
                    .frame(width: 28)
                    .accessibilityHidden(true)
            } else {
                FieluaRowIcon(systemName: icon)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                if let note { Text(note).font(.footnote) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            trailing.accessibilityHidden(true)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(minHeight: 52)
        .contentShape(Rectangle())
    }
}

struct SettingsRowStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(isEnabled ? 1 : 0.45)
            .background(configuration.isPressed ? Theme.selection : Color.clear)
    }
}

// MARK: - The title

/// Read by the title alone, so scrolling redraws only the title.
@Observable @MainActor final class SettingsTitleScroll {
    /// How far the list is scrolled up from rest; below 0 while pulled down.
    var offset: CGFloat = 0
    /// The bar's height over the list.
    var barHeight: CGFloat = 0
    var dock: CGFloat { SettingsTitle.dock(bar: barHeight) }
    var travel: CGFloat { max(SettingsTitle.rest(bar: barHeight) - dock, 0) }

    func follow(_ geometry: ScrollGeometry) {
        offset = geometry.contentOffset.y + geometry.contentInsets.top
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-title-probe") {
            probe = String(format: "offset %.1f content %.1f container %.1f insets %.1f/%.1f bar %.1f travel %.1f",
                           offset, geometry.contentSize.height, geometry.containerSize.height,
                           geometry.contentInsets.top, geometry.contentInsets.bottom, barHeight, travel)
        }
        #endif
    }
    #if POCKET_PREVIEW
    /// The measurements behind the title, for the UI test's log.
    var probe = ""
    #endif
}

/// 「設定」 over the list (and モデル管理 over its own since 1.1.0 (231): the
/// sheet's pages are not pushed on a navigation stack, whose large titles
/// would need them to be). At rest it is large under the bar; scrolling up
/// carries it up with the list while it shrinks, so it reaches the bar's
/// middle at the size of a bar title and stays there; back at the top it is
/// large again. One text all the way, so nothing swaps or jumps. With Reduce
/// Motion the large title scrolls away and the small one fades in instead.
/// The flower and 「Fielua」 until 1.1.0 (214): the page's name leads now,
/// centred on the sheet like every page's name, and the mark stays for the
/// sidebar, the launch and Fieluaの情報 (user, 2026-10-27).
private struct SettingsTitle: View {
    static let large: CGFloat = 34
    static let small: CGFloat = 17
    /// The large title's line in the list, above the first group.
    static let room: CGFloat = 72
    static let line: CGFloat = 44
    static func rest(bar: CGFloat) -> CGFloat { bar + room / 2 }
    /// The rows reach the blur under the bar about here.
    static let blurStart: CGFloat = 36
    /// In line with the bar's close button, which iOS sets a little below
    /// the bar's middle in a sheet (run 287: 2.9 pt).
    static func dock(bar: CGFloat) -> CGFloat { bar / 2 + 3 }

    let text: String
    let scroll: SettingsTitleScroll
    let reduceMotion: Bool
    var id = "settings-title"

    var body: some View {
        let _ = SettingsSlideMeter.drew("タイトル")
        let offset = scroll.offset, dock = scroll.dock, travel = scroll.travel
        let rest = Self.rest(bar: scroll.barHeight)
        let progress = travel > 0 ? min(max(offset / travel, 0), 1) : 0
        Group {
            if reduceMotion {
                // One gone before the other comes, so they never show
                // stacked where the large one passes under the bar.
                ZStack(alignment: .top) {
                    title(Self.large)
                        .offset(y: rest - offset - Self.line / 2)
                        .opacity(max(1 - progress / 0.6, 0))
                    title(Self.small)
                        .offset(y: dock - Self.line / 2)
                        .opacity(max((progress - 0.5) / 0.5, 0))
                }
            } else {
                title(Self.large)
                    .scaleEffect(1 - (1 - Self.small / Self.large) * progress)
                    .offset(y: max(rest - offset, dock) - Self.line / 2)
            }
        }
        .allowsHitTesting(false)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text(verbatim: text))
        .accessibilityAddTraits(.isHeader)
        .accessibilityIdentifier(id)
        #if POCKET_PREVIEW
        .accessibilityValue(scroll.probe)
        #endif
    }

    private func title(_ size: CGFloat) -> some View {
        // Semibold as the pages' names (.headline), so docked at 17pt it is
        // one of them.
        Text(verbatim: text)
            .font(.system(size: size, weight: .semibold))
            .lineLimit(1)
            .frame(height: Self.line)
    }
}

/// Let go with the title partway and the list settles with it large or in
/// the bar, as iOS's own large titles do.
private struct SettingsTitleSnap: ScrollTargetBehavior {
    let travel: CGFloat
    func updateTarget(_ target: inout ScrollTarget, context: TargetContext) {
        let y = target.rect.minY
        guard travel > 0, y > 0, y < travel else { return }
        target.rect.origin.y = y < travel / 2 ? 0 : travel
    }
}

// MARK: - Pages

/// キーボードと入力 (キーボード until 1.1.0 (164)): the composer's type
/// (入力スタイル, 2026-10-23) and 起動時のチャット (1.1.0 (182), until then
/// 起動時にキーボードを開いておく). Since 1.1.0 (191) (user, 2026-10-25 22:47
/// UTC) two rows with what is chosen, as iOS's own settings show them; each
/// opens its phones on a page of their own, so nothing plays here.
private struct KeyboardSettingsView: View {
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    @AppStorage(LaunchChatMode.storageKey) private var mode = LaunchChatMode.resume
    var body: some View {
        let _ = SettingsSlideMeter.drew("キーボードと入力")
        ScrollView {
            SettingsGroup {
                SettingsValueRow("入力スタイル", value: style.title, page: .composerStyle)
                Divider().padding(.leading, 16)
                SettingsValueRow("起動時のチャット", value: mode.title, page: .launchChat)
            }
            .padding(20)
        }
        .settingsScroll()
    }
}

/// 入力スタイル (1.1.0 (191)): スタンダード and スマート side by side on their
/// phones, as on the setup's page; a tap chooses, and the chat follows at
/// once. The phones play while this page is in view and at rest.
private struct ComposerStyleSettingsView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("入力スタイル")
        ScrollView {
            ComposerStyleCard()
                .padding(20)
        }
        .settingsScroll()
        .scrollBounceBehavior(.basedOnSize)
    }
}

/// 起動時のチャット (1.1.0 (191)): 前回の会話 and 新しいチャット side by side,
/// each opening Fielua from a home screen in the 入力スタイル chosen. The
/// phones fit the page, so it scrolls only when the text is larger.
private struct LaunchChatSettingsView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("起動時のチャット")
        ScrollView {
            LaunchChatCard()
                .padding(20)
        }
        .settingsScroll()
        .scrollBounceBehavior(.basedOnSize)
    }
}

/// 通知: the notification when a reply ends while Fielua is closed. Whether
/// it may appear is iOS's setting, so the page shows it and leads there.
private struct NotificationSettingsView: View {
    @Environment(\.openURL) private var openURL
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    /// What iOS said the last time the page was open, until it has said
    /// again: 「オン」 came a moment after the page before 1.1.0 (263).
    @State private var status: UNAuthorizationStatus? = NotificationSettingsView.last
    private static var last: UNAuthorizationStatus?

    var body: some View {
        let _ = SettingsSlideMeter.drew("通知")
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("返信の通知").font(.headline)
                    Spacer(minLength: 8)
                    Text(statusText).foregroundStyle(.secondary)
                        .contentTransition(.opacity)
                        .accessibilityIdentifier("settings-notification-status")
                }
                Text("Fieluaを閉じている間に返信を書き終えると、お知らせします。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if status == .notDetermined {
                    Text("初めてメッセージを送るときに、許可を確認します。")
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .transition(.opacity)
                }
                if let settings = URL(string: UIApplication.openNotificationSettingsURLString) {
                    Button("iOSの通知設定を開く") { openURL(settings) }
                        .font(.subheadline)
                        .fieluaTextButton()
                        .accessibilityIdentifier("settings-notification-open")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18).fieluaCard(cornerRadius: 20)
            .animation(FieluaMotion.change(reduceMotion), value: status)
            .padding(20)
        }
        .settingsScroll()
        .task { await refresh() }
        // Back from iOS's settings, show what was chosen there.
        .onChange(of: scenePhase) { if scenePhase == .active { Task { await refresh() } } }
    }

    private var statusText: String {
        guard let status else { return "" }
        switch status {
        case .authorized, .provisional, .ephemeral: return String(localized: "オン")
        case .denied: return String(localized: "オフ")
        case .notDetermined: return String(localized: "未設定")
        @unknown default: return ""
        }
    }

    private func refresh() async {
        status = await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
        Self.last = status
    }
}

/// ウェブ検索 (1.1.0 (230), fielua-reports Issue #5): the Tavily card, as it
/// was at the end of モデル管理, on a page of its own.
/// 試験機能を試してみる (1.1.0 (250)): each feature on trial with its switch,
/// off until the person turns it on, and on only while it is. Smart Mode
/// (SmartModeCard), in モデル管理 in 1.1.0 (249).
private struct ExperimentsSettingsView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("試験機能")
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("開発中の機能を先に試せます。オンにしている間だけ使えます。")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("experiments-lead")
                SmartModeCard()
                // Smart Memory (1.1.0 (251)): a switch of its own.
                SmartMemoryCard()
            }
            .padding(20)
        }
        .accessibilityIdentifier("experiments-list")
        .settingsScroll()
    }
}

private struct WebSearchSettingsView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("ウェブ検索")
        ScrollView {
            WebSearchCard()
                .padding(20)
        }
        .accessibilityIdentifier("web-search-list")
        .settingsScroll()
    }
}

/// Fieluaの情報: the name, the version, and where conversations are handled.
private struct AboutFieluaView: View {
    var body: some View {
        let _ = SettingsSlideMeter.drew("情報")
        ScrollView {
            VStack(spacing: 24) {
                VStack(spacing: 6) {
                    FlowerMark(size: 76)
                        .padding(.bottom, 6)
                    Text("Fielua")
                        .font(FieluaType.brandTitle(34))
                        .foregroundStyle(Theme.wordmark)
                        .accessibilityAddTraits(.isHeader)
                    Text("あなたの\(DeviceOverview.name)に、AIを。")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(.top, 8)
                HStack {
                    Text("バージョン")
                    Spacer(minLength: 12)
                    Text(Self.version).foregroundStyle(.secondary).textSelection(.enabled)
                        .accessibilityIdentifier("settings-about-version")
                }
                .padding(.horizontal, 16).frame(minHeight: 52)
                .fieluaCard(cornerRadius: 20)
            }
            .padding(20)
        }
        .settingsScroll()
    }

    static var version: String {
        let info = Bundle.main.infoDictionary
        switch (info?["CFBundleShortVersionString"] as? String, info?["CFBundleVersion"] as? String) {
        case let (short?, build?): return "\(short) (\(build))"
        case let (short?, nil): return short
        default: return "—"
        }
    }
}

#if POCKET_PREVIEW
/// For the UI check (1.1.0 (292)): a page's frame among the pages, and the
/// layers in the app's windows that cut what they hold, a page's size or
/// more: a mask (drawn apart, then cut) or rounded corners of their own.
@MainActor enum SettingsCornerProbe {
    static var pageFrame: CGRect = .zero
    static func layers() -> String {
        var masks: [String] = [], rounded: [String] = []
        func walk(_ layer: CALayer) {
            let size = layer.bounds.size
            if size.width >= 150, size.height >= 150 {
                let where_ = "\(Int(size.width))x\(Int(size.height))@\(Int(layer.position.x)),\(Int(layer.position.y))"
                if let mask = layer.mask { masks.append("\(type(of: mask)):\(where_)") }
                if layer.masksToBounds, layer.cornerRadius > 0 {
                    rounded.append(String(format: "%.1f%@:%@", layer.cornerRadius,
                                          layer.cornerCurve == .continuous ? "c" : "", where_))
                }
            }
            layer.sublayers?.forEach(walk)
        }
        for scene in UIApplication.shared.connectedScenes {
            for window in (scene as? UIWindowScene)?.windows ?? [] { walk(window.layer) }
        }
        return "masks=[\(masks.joined(separator: " "))] rounded=[\(rounded.joined(separator: " "))]"
    }
}
#endif
