import SwiftUI
import UIKit
import UserNotifications

/// 設定 (2026-10-23, 設定画面UIリニューアル): a Liquid Glass sheet with the
/// app's name large at the top and six rows, each opening its page in the
/// same sheet. モデル管理 is the model list as it was (ModelView).
enum SettingsPage: Hashable {
    case models, keyboard, notifications, about, licenses
}

/// Where the sheet opens: on its six rows, or, from the chat, on モデル管理
/// (at the web search card when the search note asked for the key).
enum SettingsStart {
    case home, models, webSearch
}

extension EnvironmentValues {
    /// Closes the whole sheet from any of its pages; a page's own dismiss
    /// would only go back one page.
    @Entry var closeSettings: () -> Void = {}
}

enum SettingsSheet {
    /// Short of full height iOS draws the sheet as Liquid Glass over the
    /// conversation. `--settings-large` (preview only) compares full height.
    static var detent: PresentationDetent {
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-large") { return .large }
        #endif
        return .fraction(0.93)
    }
}

/// 設定画面の準備 in the developer diagnostics (1.0.127): from the sheet's
/// first build to the first main-thread turn after it appeared.
@Observable @MainActor final class SettingsOpening {
    private let startedAt = Date()
    private(set) var took: TimeInterval?
    func appeared() {
        guard took == nil else { return }
        DispatchQueue.main.async { self.took = Date().timeIntervalSince(self.startedAt) }
    }
}

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var path: [SettingsPage]
    @State private var opensAtWebSearch: Bool
    @State private var opening = SettingsOpening()

    init(start: SettingsStart = .home) {
        _path = State(initialValue: start == .home ? [] : [.models])
        _opensAtWebSearch = State(initialValue: start == .webSearch)
    }

    var body: some View {
        NavigationStack(path: $path) {
            SettingsHome()
                .navigationDestination(for: SettingsPage.self) { page in
                    switch page {
                    case .models: ModelView(showsWebSearch: opensAtWebSearch, opening: opening)
                    case .keyboard: KeyboardSettingsView()
                    case .notifications: NotificationSettingsView()
                    case .about: AboutFieluaView()
                    case .licenses: LicensesView().settingsPage("オープンソースライセンス")
                    }
                }
        }
        // Back on the six rows, モデル管理 opens at its top again.
        .onChange(of: path) { if path.isEmpty { opensAtWebSearch = false } }
        .environment(\.closeSettings, { dismiss() })
        .presentationDetents([SettingsSheet.detent])
        .onAppear { opening.appeared() }
    }
}

/// Each page in the sheet: its name in the bar and the close button, over
/// the sheet's own glass.
private struct SettingsPageChrome: ViewModifier {
    let title: String
    @Environment(\.closeSettings) private var close
    func body(content: Content) -> some View {
        content
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("閉じる", systemImage: "xmark", role: .close) { close() }
                        .accessibilityIdentifier("settings-close")
                }
            }
    }
}

extension View {
    func settingsPage(_ title: String) -> some View { modifier(SettingsPageChrome(title: title)) }
}

// MARK: - The six rows

private struct SettingsHome: View {
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var scroll = SettingsTitleScroll()

    var body: some View {
        let travel = scroll.travel
        ScrollView {
            // However short the list, it scrolls far enough for the title to
            // settle in the bar and stay there: one screen under the bar
            // plus the title's way up (run 286: measured from the list's
            // own frame, the room came out short and nothing scrolled).
            ZStack(alignment: .top) {
                Color.clear
                    .containerRelativeFrame(.vertical) { length, _ in length + travel }
                    .accessibilityHidden(true)
                rows
            }
        }
        // On the list itself: set over the title too, it would take the
        // title's own identifier.
        .accessibilityIdentifier("settings-home")
        .scrollTargetBehavior(SettingsTitleSnap(travel: snaps ? travel : 0))
        .onScrollGeometryChange(for: ScrollGeometry.self) { $0 } action: { _, geometry in scroll.follow(geometry) }
        .overlay(alignment: .top) {
            SettingsTitle(scroll: scroll, reduceMotion: systemReduceMotion || previewReduceMotion)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .ignoresSafeArea(edges: .top)
                .onGeometryChange(for: CGRect.self) { proxy in
                    CGRect(x: 0, y: proxy.frame(in: .global).minY, width: 0, height: proxy.safeAreaInsets.top)
                } action: { scroll.barHeight = $0.height; scroll.layerTop = $0.minY }
        }
        .settingsPage("Fielua")
        // The title is drawn over the list instead, so it can grow and shrink;
        // the bar's own title slot shows where the small one belongs.
        .toolbar {
            ToolbarItem(placement: .principal) {
                Color.clear.frame(width: 1, height: 1)
                    .accessibilityHidden(true)
                    .onGeometryChange(for: CGFloat.self) { $0.frame(in: .global).midY } action: { scroll.barMiddle = $0 }
            }
        }
    }

    private var rows: some View {
        VStack(spacing: 24) {
            SettingsGroup {
                SettingsRow("モデル管理", icon: "square.stack.3d.up", page: .models)
                SettingsDivider()
                SettingsRow("キーボード", icon: "keyboard", page: .keyboard)
                SettingsDivider()
                SettingsRow("通知", icon: "bell", page: .notifications)
                SettingsDivider()
                SettingsLockedRow()
            }
            SettingsGroup {
                SettingsRow("Fieluaの情報", icon: "info.circle", page: .about)
                SettingsDivider()
                SettingsRow("オープンソースライセンス", icon: "doc.text", page: .licenses)
            }
        }
        .padding(.horizontal, 20)
        // Room for the title, which is drawn over the list.
        .padding(.top, SettingsTitle.room)
        .padding(.bottom, 20)
    }

    private var snaps: Bool {
        #if POCKET_PREVIEW
        // The title's frames are photographed partway, where a snap would
        // never let it rest.
        if PreviewProbe.on("--settings-title-probe") { return false }
        #endif
        return true
    }
}

private struct SettingsGroup<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        VStack(spacing: 0) { content }
            .background(Theme.card)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

private struct SettingsDivider: View {
    /// Under the text, past the icon's column, as iOS's lists do.
    var body: some View { Divider().padding(.leading, 58) }
}

private struct SettingsRow: View {
    let title: String
    let icon: String
    let page: SettingsPage
    init(_ title: String, icon: String, page: SettingsPage) { self.title = title; self.icon = icon; self.page = page }
    var body: some View {
        NavigationLink(value: page) {
            SettingsRowLabel(title: title, icon: icon) {
                Image(systemName: "chevron.right")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .foregroundStyle(.primary)
        }
        .buttonStyle(SettingsRowStyle())
        .accessibilityIdentifier("settings-row-\(page)")
    }
}

/// PCと接続: shown for a later update; nothing behind it yet.
private struct SettingsLockedRow: View {
    var body: some View {
        Button {} label: {
            SettingsRowLabel(title: "PCと接続", icon: "laptopcomputer", note: "今後のアップデートで対応") {
                Image(systemName: "lock")
                    .font(.system(size: 15, weight: .medium))
            }
            .foregroundStyle(.secondary)
        }
        .buttonStyle(SettingsRowStyle())
        .disabled(true)
        .accessibilityIdentifier("settings-row-pc")
    }
}

private struct SettingsRowLabel<Trailing: View>: View {
    let title: String
    let icon: String
    var note: String?
    @ViewBuilder let trailing: Trailing
    var body: some View {
        HStack(spacing: 14) {
            // Line symbols in the text's own color: no accent.
            Image(systemName: icon)
                .font(.system(size: 19, weight: .regular))
                .frame(width: 28)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                if let note { Text(note).font(.footnote) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            trailing.accessibilityHidden(true)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(minHeight: 52)
        .contentShape(Rectangle())
    }
}

private struct SettingsRowStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(configuration.isPressed ? Color.primary.opacity(0.08) : Color.clear)
    }
}

// MARK: - The title

/// Read by the title alone, so scrolling redraws only the title.
@Observable @MainActor private final class SettingsTitleScroll {
    /// How far the list is scrolled up from rest; below 0 while pulled down.
    var offset: CGFloat = 0
    /// The bar's height over the list.
    var barHeight: CGFloat = 0
    /// The title's layer's top and the middle of the bar's title slot, on
    /// screen: the small title rests where iOS would put a bar title.
    var layerTop: CGFloat = 0
    var barMiddle: CGFloat = 0
    var dock: CGFloat {
        let slot = barMiddle - layerTop
        return slot > 0 && slot < barHeight ? slot : barHeight / 2
    }
    var travel: CGFloat { max(SettingsTitle.rest(bar: barHeight) - dock, 0) }

    func follow(_ geometry: ScrollGeometry) {
        offset = geometry.contentOffset.y + geometry.contentInsets.top
        #if POCKET_PREVIEW
        if PreviewProbe.on("--settings-title-probe") {
            probe = String(format: "offset %.1f content %.1f container %.1f insets %.1f/%.1f bar %.1f slot %.1f travel %.1f",
                           offset, geometry.contentSize.height, geometry.containerSize.height,
                           geometry.contentInsets.top, geometry.contentInsets.bottom, barHeight, barMiddle - layerTop, travel)
        }
        #endif
    }
    #if POCKET_PREVIEW
    /// The measurements behind the title, for the UI test's log.
    var probe = ""
    #endif
}

/// 「Fielua」 over the list. At rest it is large under the bar; scrolling up
/// carries it up with the list while it shrinks, so it reaches the bar's
/// middle at the size of a bar title and stays there; back at the top it is
/// large again. One text all the way, so nothing swaps or jumps. With Reduce
/// Motion the large title scrolls away and the small one fades in instead.
private struct SettingsTitle: View {
    static let large: CGFloat = 34
    static let small: CGFloat = 17
    /// The large title's line in the list, above the first group.
    static let room: CGFloat = 72
    static let line: CGFloat = 44
    static func rest(bar: CGFloat) -> CGFloat { bar + room / 2 }

    let scroll: SettingsTitleScroll
    let reduceMotion: Bool

    var body: some View {
        let offset = scroll.offset, dock = scroll.dock, travel = scroll.travel
        let rest = Self.rest(bar: scroll.barHeight)
        let progress = travel > 0 ? min(max(offset / travel, 0), 1) : 0
        Group {
            if reduceMotion {
                ZStack(alignment: .top) {
                    title(Self.large)
                        .offset(y: rest - offset - Self.line / 2)
                        .opacity(1 - progress)
                    title(Self.small)
                        .offset(y: dock - Self.line / 2)
                        .opacity(progress)
                }
            } else {
                title(Self.large)
                    .scaleEffect(1 - (1 - Self.small / Self.large) * progress)
                    .offset(y: max(rest - offset, dock) - Self.line / 2)
            }
        }
        .allowsHitTesting(false)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Fielua")
        .accessibilityAddTraits(.isHeader)
        .accessibilityIdentifier("settings-title")
        #if POCKET_PREVIEW
        .accessibilityValue(scroll.probe)
        #endif
    }

    private func title(_ size: CGFloat) -> some View {
        // The sidebar's wordmark: Apple's own serif (New York).
        Text("Fielua")
            .font(.system(size: size, weight: .semibold, design: .serif))
            .lineLimit(1)
            .fixedSize()
            .frame(height: Self.line)
    }
}

/// Let go with the title partway and the list settles with it large or in
/// the bar, as iOS's own large titles do.
private struct SettingsTitleSnap: ScrollTargetBehavior {
    let travel: CGFloat
    func updateTarget(_ target: inout ScrollTarget, context: TargetContext) {
        let y = target.rect.minY
        guard travel > 0, y > 0, y < travel else { return }
        target.rect.origin.y = y < travel / 2 ? 0 : travel
    }
}

// MARK: - Pages

/// キーボード: the composer's type (入力欄のタイプ, 2026-10-23).
private struct KeyboardSettingsView: View {
    var body: some View {
        ScrollView {
            ComposerStyleCard().padding(20)
        }
        .settingsPage("キーボード")
    }
}

/// 通知: the notification when a reply ends while Fielua is closed. Whether
/// it may appear is iOS's setting, so the page shows it and leads there.
private struct NotificationSettingsView: View {
    @Environment(\.openURL) private var openURL
    @Environment(\.scenePhase) private var scenePhase
    @State private var status: UNAuthorizationStatus?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("回答が終わったときの通知").font(.headline)
                    Spacer(minLength: 8)
                    Text(statusText).foregroundStyle(.secondary)
                        .accessibilityIdentifier("settings-notification-status")
                }
                Text("Fieluaを閉じている間に回答を書き終えると、通知でお知らせします。通知をタップすると、その会話が開きます。")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if status == .notDetermined {
                    Text("初めてメッセージを送るときに、iOSが通知を許可するか確認します。")
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if let settings = URL(string: UIApplication.openNotificationSettingsURLString) {
                    Button("iOSの通知設定を開く") { openURL(settings) }
                        .font(.subheadline)
                        .accessibilityIdentifier("settings-notification-open")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
            .padding(20)
        }
        .settingsPage("通知")
        .task { await refresh() }
        // Back from iOS's settings, show what was chosen there.
        .onChange(of: scenePhase) { if scenePhase == .active { Task { await refresh() } } }
    }

    private var statusText: String {
        guard let status else { return "" }
        switch status {
        case .authorized, .provisional, .ephemeral: return "オン"
        case .denied: return "オフ"
        case .notDetermined: return "未設定"
        @unknown default: return ""
        }
    }

    private func refresh() async {
        status = await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
    }
}

/// Fieluaの情報: the name, the version, and where conversations are handled.
private struct AboutFieluaView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                VStack(spacing: 6) {
                    Text("Fielua")
                        .font(.system(size: 34, weight: .semibold, design: .serif))
                        .accessibilityAddTraits(.isHeader)
                    Text("あなたの\(DeviceOverview.name)に、AIを。")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(.top, 8)
                HStack {
                    Text("バージョン")
                    Spacer(minLength: 12)
                    Text(Self.version).foregroundStyle(.secondary).textSelection(.enabled)
                        .accessibilityIdentifier("settings-about-version")
                }
                .padding(.horizontal, 16).frame(minHeight: 52)
                .background(Theme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                Label("会話は、この端末の中で処理されます。",
                      systemImage: UIDevice.current.userInterfaceIdiom == .pad ? "ipad" : "iphone")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .settingsPage("Fieluaの情報")
    }

    static var version: String {
        let info = Bundle.main.infoDictionary
        switch (info?["CFBundleShortVersionString"] as? String, info?["CFBundleVersion"] as? String) {
        case let (short?, build?): return "\(short) (\(build))"
        case let (short?, nil): return short
        default: return "—"
        }
    }
}
