import SwiftUI
import UniformTypeIdentifiers
import UIKit
import UIKit.UIGestureRecognizerSubclass
import os
import PocketCore

/// 設定's モデル管理 page (2026-10-23): the model list as it was when it was
/// the whole モデルと設定 sheet, with the settings that are not among 設定's
/// six rows below it. The developer switch and diagnostics are 開発者設定,
/// and web search 設定's Web検索 (1.1.0 (230)).
struct ModelView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.closeSettings) private var closeSettings
    @Environment(\.openURL) private var openURL
    @State private var showImporter = false
    @State private var importingModel: ModelSpec?
    @State private var showConfiguration = false
    @State private var automaticSelection: ModelSpec?
    /// 設定's 開発者設定 switch; while it is on, the developer-only models
    /// are listed here too.
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    @State private var pendingDeletion: ModelSpec?
    @State private var choosing = false
    /// The cards' facts need no free space, so the sheet doesn't wait for
    /// iOS to report it.
    private let device = DeviceOverview.memoryCapacity

    var body: some View {
        let _ = SettingsSlideMeter.drew("モデル管理")
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // The page's name is large above this line and goes up
                // into the bar with it (1.1.0 (231), fielua-reports Issue
                // #6); a first card said what the page is for from 227.
                Text("モデルのダウンロードや削除、端末に合うモデルの選択ができます。")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity)
                    .accessibilityIdentifier("model-page-lead")
                // The two tools are rows, as on 設定's first page, so the
                // cards below lead (two khaki capsules until 1.1.0 (214)).
                SettingsGroup {
                    Button { showConfiguration = true } label: {
                        SettingsRowLabel(title: "生成設定・システムプロンプト", icon: "slider.horizontal.3") {
                            Image(systemName: "chevron.right")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(.tertiary)
                        }
                        .foregroundStyle(.primary)
                    }
                    .buttonStyle(SettingsRowStyle())
                    .disabled(chats.isGenerating)
                    .accessibilityIdentifier("model-generation-settings")
                    Divider().padding(.leading, 58)
                    Button { selectAutomatically() } label: {
                        SettingsRowLabel(title: "この端末に合うモデルを選ぶ", icon: "sparkles") {
                            if choosing { ProgressView() }
                        }
                        .foregroundStyle(.primary)
                    }
                    .buttonStyle(SettingsRowStyle())
                    .disabled(chats.isGenerating || model.isBusy || choosing)
                    .accessibilityIdentifier("model-recommendations")
                }
                if let automaticSelection {
                    VStack(alignment: .leading, spacing: 5) {
                        Label("\(automaticSelection.name)を選びました", systemImage: "checkmark.circle")
                            .font(.subheadline).foregroundStyle(.primary)
                        Text("\(DeviceOverview.identifier) · メモリ \(Double(device.memoryBytes) / 1_000_000_000, specifier: "%.1f") GB · CPU \(device.processorCount)コア")
                            .font(.caption).foregroundStyle(.secondary)
                    }.accessibilityIdentifier("model-auto-result")
                }
                VStack(alignment: .leading, spacing: 4) {
                    FieluaSectionLabel("モデル")
                    // That the cards' words are estimates, said once (with
                    // the page's first card from 227 to 230).
                    Text("回答の速さと必要メモリは目安です。")
                        .font(.caption).foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                        .accessibilityIdentifier("model-estimate-note")
                }
                .padding(.top, 4)
                // E4B, E2B, the test version 12B and Qwen2.5 (1.1.0 (204)).
                ForEach(ModelSpec.visibleCatalog(developer: false)) { spec in modelCard(spec) }
                // A locked model, listed with nothing on its card to
                // press: none since 12B opened in 1.1.0 (204).
                ForEach(ModelSpec.lockedCatalog) { spec in lockedCard(spec) }
                // 入力欄のタイプ is 設定's キーボードと入力, and the licenses its own row.
                CellularDownloadCard()
                CloudHistoryCard()
                // The developer-only models stay with the others; the
                // switch and the diagnostics are 設定's 開発者設定.
                if showDeveloperSettings {
                    Text("開発者向け").font(.headline).accessibilityAddTraits(.isHeader)
                    ForEach(ModelSpec.catalog.filter(\.isDeveloperOnly)) { spec in modelCard(spec) }
                }
            }
            .padding([.horizontal, .bottom], 20)
            .settingsTitleRoom()
        }
        .accessibilityIdentifier("model-list")
        .settingsScroll()
        .onAppear { model.refreshInstalled() }
        .sheet(isPresented: $showConfiguration) {
            GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings, onSave: chats.updateSettings)
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [UTType(filenameExtension: "litertlm") ?? .data], allowsMultipleSelection: false) { result in
            defer { importingModel = nil }
            do {
                if let spec = importingModel, let url = try result.get().first { model.importModel(url, spec: spec) }
            } catch { model.error = error.localizedDescription }
        }
        .alert(pendingDeletion.map { String(localized: "\($0.name)を削除しますか？") } ?? "",
               isPresented: Binding(get: { pendingDeletion != nil }, set: { if !$0 { pendingDeletion = nil } }),
               presenting: pendingDeletion) { spec in
            Button("キャンセル", role: .cancel) {}
            Button("削除", role: .destructive) { delete(spec) }
        } message: { spec in
            Text(chats.currentModel.id == spec.id
                 ? "この会話で使っているモデルです。削除すると、もう一度ダウンロードするまで会話できません。"
                 : "\(spec.sizeLabel)の空きができます。使うときはもう一度ダウンロードしてください。")
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    private func modelCard(_ spec: ModelSpec) -> some View {
        let installed = model.isInstalled(spec)
        let current = chats.currentModel.id == spec.id
        let working = model.isWorking(on: spec)
        // Phase 2 (1.1.0 (214)): who it is (name, what it reads), what it is
        // for, its notes, how it fits this phone in words (1.1.0 (225): the
        // size moved there, as 保存容量 beside 必要メモリ), and one action. The
        // yellow is only on 「このモデルで会話を始める」; the rest is neutral.
        return VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                ModelMark(model: spec, size: 36)
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 8) {
                        Text(spec.name).font(.headline)
                        if spec.isTestVersion { TestVersionBadge() }
                    }
                    Text(ModelAttachmentPolicy(model: spec).summary).font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                if installed {
                    // The card's button says it is here (使用中 or 会話を始める);
                    // the golden check beside the bin is gone.
                    Button { pendingDeletion = spec } label: {
                        Image(systemName: "trash")
                            .font(.system(size: 16, weight: .regular))
                            .foregroundStyle(Theme.icon)
                            .frame(width: 36, height: 36)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.borderless)
                    .disabled(chats.isGenerating || working)
                    .accessibilityLabel("\(spec.name)を削除")
                    .accessibilityIdentifier("model-delete-\(spec.id)")
                }
            }
            Text(spec.summary).font(.subheadline)
            // Gemma 4 12B, open to everyone as a test version (1.1.0 (204)).
            if spec.isTestVersion {
                Label(ModelSpec.testVersionNote, systemImage: "exclamationmark.triangle")
                    .font(.caption).foregroundStyle(Theme.caution)
                    .accessibilityIdentifier("model-test-version-\(spec.id)")
            }
            // Phi-4-mini-reasoning thinks before every answer (1.1.0 (205)).
            if spec.capabilities.reasons {
                Label("答える前に考えるため、返信が始まるまで時間がかかります。", systemImage: "brain")
                    .font(.caption).foregroundStyle(.secondary)
                    .accessibilityIdentifier("model-reasoning-note-\(spec.id)")
            }
            if ModelAttachmentPolicy(model: spec).coarsePhotos {
                Label(ModelAttachmentPolicy.coarsePhotoNote, systemImage: "photo")
                    .font(.caption).foregroundStyle(.secondary)
            }
            if !spec.supportsCPU {
                Label("GPUだけで動きます。アプリが裏に回ると返信は止まり、開くと続きを書きます。", systemImage: "cpu")
                    .font(.caption).foregroundStyle(.secondary)
            }
            // 12B needs the room the developer 12B check needed (GemmaService
            // checks it before each start); the sideload's signature lacks it,
            // so its card says so there.
            if spec.id == ModelSpec.gemma12B.id, !LargeModelProbe.twelveBFitsAtLaunch {
                Label("この署名ではアドレス空間が足りないため、読み込めません。TestFlight版で使ってください。", systemImage: "exclamationmark.triangle")
                    .font(.caption).foregroundStyle(.orange)
                    .accessibilityIdentifier("model-room-note-\(spec.id)")
            }
            ModelFacts(spec: spec, fit: ModelRecommendation.fit(spec, device: device), device: device,
                       showsFileName: !installed && !working)
            if working {
                Text(model.statusText(for: spec)).font(.caption).foregroundStyle(.secondary)
                if model.isDownloading(spec) {
                    ProgressView(value: model.progress(for: spec)).fieluaStateTint()
                    if let wait = model.downloadWait(for: spec),
                       let hint = wait.hint(received: model.progress(for: spec) >= 0.01, switchOn: model.allowsCellular) {
                        Label(hint, systemImage: wait == .cellularDenied ? "antenna.radiowaves.left.and.right.slash" : "wifi.exclamationmark")
                            .font(.caption).foregroundStyle(.secondary)
                            .accessibilityIdentifier("model-download-wait-\(spec.id)")
                        if wait == .cellularDenied, let settings = URL(string: UIApplication.openSettingsURLString) {
                            Button("iOSの設定を開く") { openURL(settings) }.font(.caption)
                        }
                    }
                    Button("ダウンロードを中止") { model.cancelDownload(spec) }.font(.subheadline)
                        .accessibilityIdentifier("model-cancel-\(spec.id)")
                } else { ProgressView() }
            } else if installed {
                let use = Button {
                    model.select(spec)
                    chats.newChat(modelID: spec.id)
                    chats.releaseModelMemory()
                    closeSettings()
                } label: {
                    if current { Label("使用中", systemImage: "checkmark") } else { Text("このモデルで会話を始める") }
                }
                .disabled(current || chats.isGenerating)
                .accessibilityIdentifier("model-use-\(spec.id)")
                // The one in use says so quietly; the others offer the chat.
                if current { use.buttonStyle(FieluaStateTag()) } else { use.fieluaProminentButton() }
            } else {
                HStack(spacing: 16) {
                    // Several models can download at once; a file import
                    // waits while another file is being checked.
                    Button("ダウンロード") { model.download(spec) }
                        .fieluaSecondaryButton()
                        .disabled(model.isRestoring)
                        .accessibilityLabel("\(spec.name)をダウンロード")
                        .accessibilityIdentifier("model-download-\(spec.id)")
                    Button("ファイルから") {
                        importingModel = spec
                        showImporter = true
                    }
                    .buttonStyle(.borderless)
                    .disabled(model.isBusy)
                    .accessibilityLabel("\(spec.name)をファイルから取り込む")
                }
                .font(.subheadline)
                if model.network.waitsForWiFi(allowsCellular: model.allowsCellular) {
                    Label("Wi-Fiにつながるとダウンロードを始めます。", systemImage: "wifi.slash")
                        .font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("model-download-wifi-note-\(spec.id)")
                }
                // The file name to import is in the facts' 詳細 (1.1.0 (225)).
            }
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .fieluaCard(cornerRadius: 20)
    }
    /// A locked model: its name, size and a lock, with no button to choose,
    /// download or import it (ModelStore refuses those for it as well).
    private func lockedCard(_ spec: ModelSpec) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ModelMark(model: spec, size: 36).opacity(0.55)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline).foregroundStyle(.secondary)
                    Text(spec.sizeLabel).font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                Label("ロック中", systemImage: "lock.fill")
                    .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(Color.secondary.opacity(0.12), in: Capsule())
            }
            Text(spec.summary).font(.subheadline).foregroundStyle(.secondary)
            Label("ロック中のため、選択・ダウンロード・会話はできません。", systemImage: "lock")
                .font(.caption).foregroundStyle(.secondary)
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .fieluaCard(cornerRadius: 20)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("model-locked-\(spec.id)")
    }
    /// Unmaps the weights first: the engine may still hold the file open.
    private func delete(_ spec: ModelSpec) {
        Task {
            await chats.unloadModel()
            model.delete(spec)
        }
    }
    /// The free space is read off the main thread, so the list stays live
    /// while iOS answers.
    private func selectAutomatically() {
        choosing = true
        Task {
            let freeDisk = await Task.detached(priority: .userInitiated) { DeviceOverview.freeDiskBytes }.value
            choosing = false
            let capacity = DeviceOverview.capacity(freeDiskBytes: freeDisk)
            let installed = Set(ModelSpec.catalog.filter { model.isInstalled($0) }.map(\.id))
            guard let recommended = ModelRecommendation.recommended(for: capacity, installedIDs: installed,
                                                                    includeDeveloperModels: showDeveloperSettings) else {
                model.error = String(localized: "モデルをダウンロードするための空き容量が足りません。"); return
            }
            guard !chats.isGenerating, !model.isBusy else { return }
            model.select(recommended)
            chats.newChat(modelID: recommended.id)
            chats.releaseModelMemory()
            automaticSelection = recommended
            if !model.isInstalled(recommended) { model.download(recommended) }
        }
    }
}

/// 「テスト版」 beside a test version's name (Gemma 4 12B, 1.1.0 (204)), in
/// the shape of the locked card's ロック中.
struct TestVersionBadge: View {
    var body: some View {
        Text("テスト版")
            .font(.caption.weight(.semibold)).foregroundStyle(Theme.caution)
            .padding(.horizontal, 8).padding(.vertical, 2)
            .background(Theme.caution.opacity(0.14), in: Capsule())
            .fixedSize()
            .accessibilityIdentifier("model-test-version-badge")
    }
}

/// 設定's 開発者設定 (2026-10-24): shown by three three-finger swipes on
/// 設定's rows, with the switch at the top. Turned on, everything for
/// developers appears below it, as it did below the switch in モデルと設定,
/// so the switch stays under the finger.
struct DeveloperSettingsView: View {
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// The sheet's opening, for 診断をまとめて実行.
    let opening: SettingsOpening
    /// 診断をまとめて実行; nothing is measured or read for it until pressed.
    @State private var diagnostics: DeveloperSnapshot?
    @State private var diagnosing = false
    @State private var diagnosticsRun = 0
    @State private var showLargeModelProbe = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Toggle("開発者向けの設定項目を表示する",
                           isOn: $showDeveloperSettings.animation(.smooth(duration: 0.3)))
                        .fieluaStateTint()
                        .accessibilityIdentifier("developer-settings-toggle")
                    Text("オンの間は、モデル管理に開発者向けのモデルも並びます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18).fieluaCard(cornerRadius: 20)
                SettingsSlideMeterCard()
                if showDeveloperSettings {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("現在の実行方法: \(chats.currentSettings.backend.rawValue)。生成設定から変更できます。")
                            .font(.caption).foregroundStyle(.secondary)
                        Button("AIのメモリを解放する") { chats.releaseModelMemory() }
                            .font(.subheadline).disabled(chats.isGenerating)
                        HStack(spacing: 10) {
                            Button { runDiagnostics() } label: {
                                Label("診断をまとめて実行", systemImage: "stethoscope")
                            }
                            .font(.subheadline).disabled(diagnosing)
                            .accessibilityIdentifier("developer-diagnostics-run")
                            if diagnosing { ProgressView().controlSize(.small) }
                        }
                        Text(diagnostics?.summary(openTook: opening.took)
                             ?? "空き容量・メモリ・設定画面の開く速さを測り、下の推論の診断とダウンロードの記録を読み込みます。")
                            .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                            .accessibilityIdentifier("developer-diagnostics-result")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18).fieluaCard(cornerRadius: 20)
                    InferenceDiagnosticsCard(loadRequest: diagnosticsRun)
                    // Gemma 4 12B's check (LargeModelProbe): its own engine,
                    // apart from the chat.
                    VStack(alignment: .leading, spacing: 10) {
                        Label("12Bの動作確認", systemImage: "testtube.2").font(.headline)
                        Text("Gemma 4 12Bを、チャットとは別に1回だけ動かし、読み込み・速度・メモリを記録します。")
                            .font(.caption).foregroundStyle(.secondary)
                        Button { showLargeModelProbe = true } label: { Label("12Bの動作確認を開く", systemImage: "chevron.right") }
                            .font(.subheadline).accessibilityIdentifier("open-large-model-probe")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18).fieluaCard(cornerRadius: 20)
                    .sheet(isPresented: $showLargeModelProbe) { LargeModelProbeView() }
                    SendScreenLogCard(loadRequest: diagnosticsRun)
                    PanelDressingCard()
                    DownloadLogCard(loadRequest: diagnosticsRun)
                }
                FirstLaunchResetCard()
            }
            .padding(20)
        }
        .accessibilityIdentifier("developer-list")
        .settingsScroll()
    }

    /// Everything at once, off the main thread: reading the free space can
    /// keep iOS busy for seconds.
    private func runDiagnostics() {
        diagnosing = true
        diagnosticsRun += 1
        Task {
            diagnostics = await Task.detached(priority: .userInitiated) { DeveloperSnapshot.take() }.value
            diagnosing = false
        }
    }
}

/// 設定's page slides on this phone (SettingsSlideMeter): the last one, and
/// the measurement of every page's, to read or copy for a report.
private struct SettingsSlideMeterCard: View {
    var body: some View {
        let meter = SettingsSlideMeter.shared
        VStack(alignment: .leading, spacing: 10) {
            Text("ページ移動のなめらかさ").font(.headline)
            // The page's own slide in is the latest one.
            Text(meter.summary ?? "ページを移動すると、その動きの滑らかさをここに表示します。")
                .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                .accessibilityIdentifier("developer-slide-meter")
            HStack(spacing: 10) {
                Button { meter.runner?() } label: {
                    Label("ページ移動を計測（約2分）", systemImage: "speedometer")
                }
                .font(.subheadline).disabled(meter.running)
                .accessibilityIdentifier("developer-slide-measure")
                if meter.running { ProgressView().controlSize(.small) }
            }
            Text(meter.report ?? "設定トップから5つのページを開いて戻る動きを、152の動かし方と153の動かし方などで2回ずつ自動で行います。終わるとこの画面に戻り、結果を表示します。計測中は画面に触れないでください。")
                .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                .accessibilityIdentifier("developer-slide-report")
            if let report = meter.report {
                Button("結果をコピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = report }
                    .font(.subheadline)
                    .accessibilityIdentifier("developer-slide-copy")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }
}

/// 入力欄のタイプ (2026-10-23): 縮小型, the panel that folds into three
/// buttons while older messages are read, or 従来型, the plus and the one-
/// line field of earlier versions. The chat follows the choice at once.
/// The phones stand without a heading since 2026-10-25, on 入力スタイル's
/// own page since 1.1.0 (191).
struct ComposerStyleCard: View {
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Each type on a small phone, playing what it does (2026-10-24).
            ComposerStylePicker(selection: $style)
            // Two lines kept for both, so a choice never moves the card.
            Text(style.previewCaption)
                .font(.subheadline).foregroundStyle(.secondary)
                .lineLimit(2, reservesSpace: true)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }
}

/// 起動時のチャット (user, 2026-10-25): 前回の会話 or 新しいチャット, each on a
/// small phone opening Fielua from the home screen (LaunchChatPicker), in
/// the composer type chosen in 入力スタイル. It replaced 「起動時にキーボードを
/// 開いておく」, whose on is 新しいチャット now (LaunchChatMode.migrate). On
/// a page of its own since 1.1.0 (191), whose title names it, so the phones
/// stand without a heading, as 入力スタイル's.
struct LaunchChatCard: View {
    @AppStorage(LaunchChatMode.storageKey) private var mode = LaunchChatMode.resume
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            LaunchChatPicker(selection: $mode, style: style)
            // Two lines kept for both, so a choice never moves the card.
            Text(mode.previewCaption)
                .font(.subheadline).foregroundStyle(.secondary)
                .lineLimit(2, reservesSpace: true)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }
}

/// モバイル通信でもダウンロード (0.0.1 (132)). Off until turned on: each
/// model is several gigabytes.
struct CellularDownloadCard: View {
    @EnvironmentObject private var model: ModelStore
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // The switch alone (1.1.0 (230), fielua-reports Issue #5): the
            // paragraph on Wi-Fi, each model's size and the data plan is
            // gone. A waiting download still says what to do on its card.
            Toggle("モバイル通信でもダウンロード", isOn: $model.allowsCellular)
                .font(.headline).fieluaStateTint().accessibilityIdentifier("model-download-cellular-toggle")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
    }
}

/// The developer settings' figures, taken when asked for.
struct DeveloperSnapshot: Sendable {
    let freeDiskBytes: Int64
    let freeDiskSeconds: TimeInterval
    let availableMemoryBytes: UInt64
    let addressSpace: AddressSpace?

    static func take() -> Self {
        let start = Date()
        let free = DeviceOverview.freeDiskBytes
        let seconds = Date().timeIntervalSince(start)
        return Self(freeDiskBytes: free, freeDiskSeconds: seconds,
                    availableMemoryBytes: UInt64(os_proc_available_memory()), addressSpace: AddressSpace.current())
    }

    func summary(openTook: TimeInterval?) -> String {
        func gigabytes(_ bytes: UInt64) -> String { String(format: "%.2f GB", Double(bytes) / 1_000_000_000) }
        var lines = [
            openTook.map { String(format: "設定画面の準備: %.2f秒（作り始めてから最初の表示まで）", $0) } ?? "設定画面の準備: 計れませんでした",
            "空き容量: " + ByteCountFormatter.string(fromByteCount: freeDiskBytes, countStyle: .decimal)
                + String(format: "（iOSが答えるまで %.2f秒）", freeDiskSeconds),
            "使えるメモリ: " + gigabytes(availableMemoryBytes),
        ]
        if let space = addressSpace {
            lines.append("アドレス空間: 空き \(gigabytes(space.free)) · 最大の連続した空き \(gigabytes(space.largestFree))")
        }
        return lines.joined(separator: "\n")
    }
}

/// Three fingers moving up or down together. It watches touches without
/// claiming them until they lift, so the list keeps scrolling normally.
struct ThreeFingerVerticalSwipe: UIGestureRecognizerRepresentable {
    let action: (Date) -> Void
    func makeUIGestureRecognizer(context: Context) -> ThreeFingerVerticalRecognizer {
        let recognizer = ThreeFingerVerticalRecognizer()
        recognizer.cancelsTouchesInView = false
        recognizer.delaysTouchesBegan = false
        recognizer.delaysTouchesEnded = false
        recognizer.delegate = context.coordinator
        return recognizer
    }
    func handleUIGestureRecognizerAction(_ recognizer: ThreeFingerVerticalRecognizer, context: Context) {
        if recognizer.state == .ended, let start = recognizer.startedAt { action(start) }
    }
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}

final class ThreeFingerVerticalRecognizer: UIGestureRecognizer {
    private(set) var startedAt: Date?
    private var starts: [ObjectIdentifier: CGPoint] = [:]
    private var latest: [ObjectIdentifier: CGPoint] = [:]

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        for touch in touches {
            let point = touch.location(in: nil)
            starts[ObjectIdentifier(touch)] = point; latest[ObjectIdentifier(touch)] = point
        }
        if starts.count > 3 { state = .failed; return }
        if starts.count == 3, startedAt == nil { startedAt = Date() }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesMoved(touches, with: event)
        for touch in touches { latest[ObjectIdentifier(touch)] = touch.location(in: nil) }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesEnded(touches, with: event)
        for touch in touches { latest[ObjectIdentifier(touch)] = touch.location(in: nil) }
        let active = (event.allTouches ?? []).filter { $0.phase != .ended && $0.phase != .cancelled && starts[ObjectIdentifier($0)] != nil }
        guard active.isEmpty else { return }
        state = isSwipe ? .ended : .failed
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesCancelled(touches, with: event)
        state = .failed
    }
    /// The list's own scrolling must not cancel this observer.
    override func canBePrevented(by preventing: UIGestureRecognizer) -> Bool { false }
    override func reset() {
        super.reset()
        starts = [:]; latest = [:]; startedAt = nil
    }
    private var isSwipe: Bool {
        guard starts.count == 3, startedAt != nil else { return false }
        let moves = starts.compactMap { id, start in latest[id].map { CGPoint(x: $0.x - start.x, y: $0.y - start.y) } }
        guard moves.count == 3 else { return false }
        let dy = moves.map(\.y).reduce(0, +) / 3, dx = moves.map(\.x).reduce(0, +) / 3
        let together = moves.allSatisfy { ($0.y > 0) == (dy > 0) }
        return together && abs(dy) >= 50 && abs(dy) > abs(dx) * 1.5
    }
}
