import SwiftUI
import UniformTypeIdentifiers
import UIKit
import UIKit.UIGestureRecognizerSubclass
import PocketCore

struct ModelView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var showImporter = false
    @State private var importingModel: ModelSpec?
    @State private var showConfiguration = false
    @State private var automaticSelection: ModelSpec?
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// The developer switch is hidden while off. At the bottom of this screen,
    /// three downward three-finger swipes reveal it for this visit.
    @State private var developerRevealed = ProcessInfo.processInfo.arguments.contains("--developer-unlocked")
    @State private var atBottom = false
    /// When the list last stopped being at the bottom. A swipe that begins at
    /// the bottom scrolls the list before it ends, so the check uses the
    /// gesture's start time instead of the position at its end.
    @State private var leftBottomAt = Date.distantPast
    @State private var revealTick = 0
    @State private var revealSwipes = 0
    @State private var lastRevealSwipe = Date.distantPast
    @State private var pendingDeletion: ModelSpec?
    private let device = DeviceOverview.capacity

    var body: some View {
        NavigationStack {
          ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("あなたの\(DeviceOverview.name)に、AIを。")
                            .font(.title2.weight(.semibold))
                        Text("モデルを保存すれば、ネットがなくても会話できます。別のモデルを選ぶと新しい会話が開きます。")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Button { showConfiguration = true } label: {
                        Label("生成設定・システムプロンプト", systemImage: "slider.horizontal.3")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating)
                        .accessibilityIdentifier("model-generation-settings")
                    Button { selectAutomatically() } label: {
                        Label("この端末に合うモデルを選ぶ", systemImage: "sparkles")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating || model.isBusy)
                        .accessibilityIdentifier("model-recommendations")
                    if let automaticSelection {
                        VStack(alignment: .leading, spacing: 5) {
                            Label("\(automaticSelection.name)を自動選択しました", systemImage: "checkmark.circle.fill")
                                .font(.subheadline).foregroundStyle(.green)
                            Text("\(DeviceOverview.identifier) · メモリ \(Double(device.memoryBytes) / 1_000_000_000, specifier: "%.1f") GB · CPU \(device.processorCount)コア。空き容量と利用可能なメモリも確認しました。")
                                .font(.caption).foregroundStyle(.secondary)
                        }.accessibilityIdentifier("model-auto-result")
                    }
                    ForEach(ModelSpec.visibleCatalog(developer: false)) { spec in modelCard(spec) }
                    CloudHistoryCard()
                    if showDeveloperSettings || developerRevealed {
                        VStack(alignment: .leading, spacing: 8) {
                            Toggle("開発者向けの設定項目を表示する",
                                   isOn: $showDeveloperSettings.animation(.smooth(duration: 0.3)))
                                .accessibilityIdentifier("developer-settings-toggle")
                        }.padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                        .id("developer-toggle")
                    }
                    // Everything the switch adds appears below it, so the
                    // switch stays under the finger.
                    if showDeveloperSettings {
                        Text("開発者向け").font(.headline).accessibilityAddTraits(.isHeader)
                        ForEach(ModelSpec.catalog.filter(\.isDeveloperOnly)) { spec in modelCard(spec) }
                        VStack(alignment: .leading, spacing: 12) {
                            Text("現在の実行方法: \(chats.currentSettings.backend.rawValue)。生成設定から変更できます。")
                                .font(.caption).foregroundStyle(.secondary)
                            Button("AIのメモリを解放する") { chats.releaseModelMemory() }
                                .font(.subheadline).disabled(chats.isGenerating)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                        UpdateSourceCard()
                        InferenceDiagnosticsCard()
                        DownloadLogCard()
                    }
                    NavigationLink { LicensesView() } label: {
                        Label("オープンソースライセンス", systemImage: "doc.text")
                    }.font(.subheadline)
                        .accessibilityIdentifier("model-licenses")
                    Label("会話は、この端末の中で処理されます。", systemImage: device.isPad ? "ipad" : "iphone")
                        .font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("model-list-footer")
                }
                .padding(20)
            }
            .accessibilityIdentifier("model-list")
            .onScrollGeometryChange(for: Bool.self) { geometry in
                geometry.readingBottom >= geometry.contentSize.height - 40
            } action: { _, bottom in
                if atBottom && !bottom { leftBottomAt = Date() }
                atBottom = bottom
            }
            .gesture(ThreeFingerVerticalSwipe { startedAt in registerRevealSwipe(startedAt: startedAt) })
            .onChange(of: revealTick) {
                withAnimation(.smooth(duration: 0.35)) { proxy.scrollTo("developer-toggle", anchor: .center) }
            }
            .onAppear {
                model.refreshInstalled()
                // Keep the switch on screen for this visit even after it is turned off.
                if showDeveloperSettings { developerRevealed = true }
            }
            .background(Theme.canvas)
            .navigationTitle("モデルと設定").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
          }
        }
        .sheet(isPresented: $showConfiguration) {
            GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings, onSave: chats.updateSettings)
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [UTType(filenameExtension: "litertlm") ?? .data], allowsMultipleSelection: false) { result in
            defer { importingModel = nil }
            do {
                if let spec = importingModel, let url = try result.get().first { model.importModel(url, spec: spec) }
            } catch { model.error = error.localizedDescription }
        }
        .alert(pendingDeletion.map { "\($0.name)を削除しますか？" } ?? "",
               isPresented: Binding(get: { pendingDeletion != nil }, set: { if !$0 { pendingDeletion = nil } }),
               presenting: pendingDeletion) { spec in
            Button("キャンセル", role: .cancel) {}
            Button("削除", role: .destructive) { delete(spec) }
        } message: { spec in
            Text(chats.currentModel.id == spec.id
                 ? "この会話で使っているモデルです。削除すると、もう一度ダウンロードするまで会話できません。"
                 : "\(spec.sizeLabel)の空きができます。使うときはもう一度ダウンロードしてください。")
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    private func modelCard(_ spec: ModelSpec) -> some View {
        let installed = model.isInstalled(spec)
        let current = chats.currentModel.id == spec.id
        let working = model.isWorking(on: spec)
        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ModelMark(model: spec, size: 36)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text("\(spec.sizeLabel) · \(ModelAttachmentPolicy(model: spec).summary)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                if installed {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        .accessibilityLabel("保存済み")
                    Button { pendingDeletion = spec } label: {
                        Image(systemName: "trash")
                            .font(.system(size: 17, weight: .regular))
                            .foregroundStyle(.red)
                            .frame(width: 36, height: 36)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.borderless)
                    .disabled(chats.isGenerating || working)
                    .accessibilityLabel("\(spec.name)を削除")
                    .accessibilityIdentifier("model-delete-\(spec.id)")
                }
            }
            Text(spec.summary).font(.subheadline).foregroundStyle(.secondary)
            if ModelAttachmentPolicy(model: spec).photosSuspended {
                Label("写真は現在調整中です。写真にはE2Bをご利用ください。ファイルは読み込めます。", systemImage: "lock.fill")
                    .font(.caption).foregroundStyle(.secondary)
            }
            ModelFitGauges(fit: ModelRecommendation.fit(spec, device: device))
            if working {
                Text(model.statusText(for: spec)).font(.caption).foregroundStyle(.secondary)
                if model.isDownloading(spec) {
                    ProgressView(value: model.progress(for: spec)).tint(Theme.accent)
                    Button("ダウンロードを中止") { model.cancelDownload(spec) }.font(.subheadline)
                        .accessibilityIdentifier("model-cancel-\(spec.id)")
                } else { ProgressView() }
            } else if installed {
                Button(current ? "使用中" : "このモデルで会話を始める") {
                    model.select(spec)
                    chats.newChat(modelID: spec.id)
                    chats.releaseModelMemory()
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .disabled(current || chats.isGenerating)
                .accessibilityIdentifier("model-use-\(spec.id)")
            } else {
                HStack(spacing: 12) {
                    // Several models can download at once; a file import
                    // waits while another file is being checked.
                    Button("ダウンロード") { model.download(spec) }
                        .buttonStyle(.borderedProminent)
                        .disabled(model.isRestoring)
                        .accessibilityLabel("\(spec.name)をダウンロード")
                        .accessibilityIdentifier("model-download-\(spec.id)")
                    Button("ファイルから") {
                        importingModel = spec
                        showImporter = true
                    }
                    .buttonStyle(.bordered)
                    .disabled(model.isBusy)
                    .accessibilityLabel("\(spec.name)をファイルから取り込む")
                }
                .font(.subheadline)
                DisclosureGroup("取り込むファイル名") {
                    Text(spec.fileName).font(.caption).textSelection(.enabled)
                        .padding(.top, 4)
                }.font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
    /// Counts a run that starts at the bottom of the list; the swipes
    /// themselves may scroll it, so later swipes count within a short window.
    private func registerRevealSwipe(startedAt: Date) {
        let now = Date()
        if now.timeIntervalSince(lastRevealSwipe) > 5 { revealSwipes = 0 }
        let startedAtBottom = atBottom || leftBottomAt >= startedAt.addingTimeInterval(-0.15)
        guard startedAtBottom || revealSwipes > 0 else { return }
        revealSwipes += 1; lastRevealSwipe = now
        if revealSwipes >= 3 {
            revealSwipes = 0
            withAnimation(.smooth(duration: 0.25)) { developerRevealed = true }
            revealTick += 1
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        }
    }
    /// Unmaps the weights first: the engine may still hold the file open.
    private func delete(_ spec: ModelSpec) {
        Task {
            await chats.unloadModel()
            model.delete(spec)
        }
    }
    private func selectAutomatically() {
        let capacity = DeviceOverview.capacity
        let installed = Set(ModelSpec.catalog.filter { model.isInstalled($0) }.map(\.id))
        guard let recommended = ModelRecommendation.recommended(for: capacity, installedIDs: installed,
                                                                includeDeveloperModels: showDeveloperSettings) else {
            model.error = "モデルを保存するための空き容量が足りません。"; return
        }
        model.select(recommended)
        chats.newChat(modelID: recommended.id)
        chats.releaseModelMemory()
        automaticSelection = recommended
        if !model.isInstalled(recommended) { model.download(recommended) }
    }
}

/// Three fingers moving up or down together. It watches touches without
/// claiming them until they lift, so the list keeps scrolling normally.
struct ThreeFingerVerticalSwipe: UIGestureRecognizerRepresentable {
    let action: (Date) -> Void
    func makeUIGestureRecognizer(context: Context) -> ThreeFingerVerticalRecognizer {
        let recognizer = ThreeFingerVerticalRecognizer()
        recognizer.cancelsTouchesInView = false
        recognizer.delaysTouchesBegan = false
        recognizer.delaysTouchesEnded = false
        recognizer.delegate = context.coordinator
        return recognizer
    }
    func handleUIGestureRecognizerAction(_ recognizer: ThreeFingerVerticalRecognizer, context: Context) {
        if recognizer.state == .ended, let start = recognizer.startedAt { action(start) }
    }
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}

final class ThreeFingerVerticalRecognizer: UIGestureRecognizer {
    private(set) var startedAt: Date?
    private var starts: [ObjectIdentifier: CGPoint] = [:]
    private var latest: [ObjectIdentifier: CGPoint] = [:]

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        for touch in touches {
            let point = touch.location(in: nil)
            starts[ObjectIdentifier(touch)] = point; latest[ObjectIdentifier(touch)] = point
        }
        if starts.count > 3 { state = .failed; return }
        if starts.count == 3, startedAt == nil { startedAt = Date() }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesMoved(touches, with: event)
        for touch in touches { latest[ObjectIdentifier(touch)] = touch.location(in: nil) }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesEnded(touches, with: event)
        for touch in touches { latest[ObjectIdentifier(touch)] = touch.location(in: nil) }
        let active = (event.allTouches ?? []).filter { $0.phase != .ended && $0.phase != .cancelled && starts[ObjectIdentifier($0)] != nil }
        guard active.isEmpty else { return }
        state = isSwipe ? .ended : .failed
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesCancelled(touches, with: event)
        state = .failed
    }
    /// The list's own scrolling must not cancel this observer.
    override func canBePrevented(by preventing: UIGestureRecognizer) -> Bool { false }
    override func reset() {
        super.reset()
        starts = [:]; latest = [:]; startedAt = nil
    }
    private var isSwipe: Bool {
        guard starts.count == 3, startedAt != nil else { return false }
        let moves = starts.compactMap { id, start in latest[id].map { CGPoint(x: $0.x - start.x, y: $0.y - start.y) } }
        guard moves.count == 3 else { return false }
        let dy = moves.map(\.y).reduce(0, +) / 3, dx = moves.map(\.x).reduce(0, +) / 3
        let together = moves.allSatisfy { ($0.y > 0) == (dy > 0) }
        return together && abs(dy) >= 50 && abs(dy) > abs(dx) * 1.5
    }
}
