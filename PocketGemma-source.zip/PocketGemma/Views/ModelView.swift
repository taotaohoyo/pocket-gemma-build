import SwiftUI
import UniformTypeIdentifiers
import UIKit
import UIKit.UIGestureRecognizerSubclass
import os
import PocketCore

/// 設定's モデル管理 page (2026-10-23): the model list as it was when it was
/// the whole モデルと設定 sheet, with the settings that are not among 設定's
/// six rows below it. The developer switch and diagnostics are 開発者設定.
struct ModelView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.closeSettings) private var closeSettings
    @Environment(\.openURL) private var openURL
    /// Opened from the chat's web search note: shows the web search card.
    private let showsWebSearch: Bool
    @State private var showImporter = false
    @State private var importingModel: ModelSpec?
    @State private var showConfiguration = false
    @State private var automaticSelection: ModelSpec?
    /// 設定's 開発者設定 switch; while it is on, the developer-only models
    /// are listed here too.
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    @State private var pendingDeletion: ModelSpec?
    @State private var choosing = false
    /// The gauges need no free space, so the sheet doesn't wait for iOS to
    /// report it.
    private let device = DeviceOverview.memoryCapacity

    init(showsWebSearch: Bool = false) {
        self.showsWebSearch = showsWebSearch
    }

    var body: some View {
        let _ = SettingsSlideMeter.drew("モデル管理")
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // No lead-in: the cards and their buttons say what they
                    // do (2026-10-24). The app's line is on Fieluaの情報.
                    Button { showConfiguration = true } label: {
                        Label("生成設定・システムプロンプト", systemImage: "slider.horizontal.3")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating)
                        .accessibilityIdentifier("model-generation-settings")
                    Button { selectAutomatically() } label: {
                        Label("この端末に合うモデルを選ぶ", systemImage: "sparkles")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating || model.isBusy || choosing)
                        .accessibilityIdentifier("model-recommendations")
                    if let automaticSelection {
                        VStack(alignment: .leading, spacing: 5) {
                            Label("\(automaticSelection.name)を選びました", systemImage: "checkmark.circle.fill")
                                .font(.subheadline).foregroundStyle(.green)
                            Text("\(DeviceOverview.identifier) · メモリ \(Double(device.memoryBytes) / 1_000_000_000, specifier: "%.1f") GB · CPU \(device.processorCount)コア")
                                .font(.caption).foregroundStyle(.secondary)
                        }.accessibilityIdentifier("model-auto-result")
                    }
                    ForEach(ModelSpec.visibleCatalog(developer: false)) { spec in modelCard(spec) }
                    // 入力欄のタイプ is 設定's キーボードと入力, and the licenses its own row.
                    CellularDownloadCard()
                    CloudHistoryCard()
                    WebSearchCard().id("web-search-card")
                    // The developer-only models stay with the others; the
                    // switch and the diagnostics are 設定's 開発者設定.
                    if showDeveloperSettings {
                        Text("開発者向け").font(.headline).accessibilityAddTraits(.isHeader)
                        ForEach(ModelSpec.catalog.filter(\.isDeveloperOnly)) { spec in modelCard(spec) }
                    }
                    Label("会話は、この端末の中で処理されます。", systemImage: device.isPad ? "ipad" : "iphone")
                        .font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("model-list-footer")
                }
                .padding(20)
            }
            .accessibilityIdentifier("model-list")
            .settingsScroll()
            .onAppear {
                model.refreshInstalled()
                if showsWebSearch { DispatchQueue.main.async { proxy.scrollTo("web-search-card", anchor: .top) } }
            }
        }
        .sheet(isPresented: $showConfiguration) {
            GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings, onSave: chats.updateSettings)
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [UTType(filenameExtension: "litertlm") ?? .data], allowsMultipleSelection: false) { result in
            defer { importingModel = nil }
            do {
                if let spec = importingModel, let url = try result.get().first { model.importModel(url, spec: spec) }
            } catch { model.error = error.localizedDescription }
        }
        .alert(pendingDeletion.map { String(localized: "\($0.name)を削除しますか？") } ?? "",
               isPresented: Binding(get: { pendingDeletion != nil }, set: { if !$0 { pendingDeletion = nil } }),
               presenting: pendingDeletion) { spec in
            Button("キャンセル", role: .cancel) {}
            Button("削除", role: .destructive) { delete(spec) }
        } message: { spec in
            Text(chats.currentModel.id == spec.id
                 ? "この会話で使っているモデルです。削除すると、もう一度ダウンロードするまで会話できません。"
                 : "\(spec.sizeLabel)の空きができます。使うときはもう一度ダウンロードしてください。")
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    private func modelCard(_ spec: ModelSpec) -> some View {
        let installed = model.isInstalled(spec)
        let current = chats.currentModel.id == spec.id
        let working = model.isWorking(on: spec)
        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ModelMark(model: spec, size: 36)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text("\(spec.sizeLabel) · \(ModelAttachmentPolicy(model: spec).summary)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                if installed {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        .accessibilityLabel("ダウンロード済み")
                    Button { pendingDeletion = spec } label: {
                        Image(systemName: "trash")
                            .font(.system(size: 17, weight: .regular))
                            .foregroundStyle(.red)
                            .frame(width: 36, height: 36)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.borderless)
                    .disabled(chats.isGenerating || working)
                    .accessibilityLabel("\(spec.name)を削除")
                    .accessibilityIdentifier("model-delete-\(spec.id)")
                }
            }
            Text(spec.summary).font(.subheadline).foregroundStyle(.secondary)
            if ModelAttachmentPolicy(model: spec).coarsePhotos {
                Label(ModelAttachmentPolicy.coarsePhotoNote, systemImage: "photo")
                    .font(.caption).foregroundStyle(.secondary)
            }
            ModelFitGauges(fit: ModelRecommendation.fit(spec, device: device))
            if working {
                Text(model.statusText(for: spec)).font(.caption).foregroundStyle(.secondary)
                if model.isDownloading(spec) {
                    ProgressView(value: model.progress(for: spec)).tint(Theme.accent)
                    if let wait = model.downloadWait(for: spec),
                       let hint = wait.hint(received: model.progress(for: spec) >= 0.01, switchOn: model.allowsCellular) {
                        Label(hint, systemImage: wait == .cellularDenied ? "antenna.radiowaves.left.and.right.slash" : "wifi.exclamationmark")
                            .font(.caption).foregroundStyle(.secondary)
                            .accessibilityIdentifier("model-download-wait-\(spec.id)")
                        if wait == .cellularDenied, let settings = URL(string: UIApplication.openSettingsURLString) {
                            Button("iOSの設定を開く") { openURL(settings) }.font(.caption)
                        }
                    }
                    Button("ダウンロードを中止") { model.cancelDownload(spec) }.font(.subheadline)
                        .accessibilityIdentifier("model-cancel-\(spec.id)")
                } else { ProgressView() }
            } else if installed {
                Button(current ? "使用中" : "このモデルで会話を始める") {
                    model.select(spec)
                    chats.newChat(modelID: spec.id)
                    chats.releaseModelMemory()
                    closeSettings()
                }
                .buttonStyle(.borderedProminent)
                .disabled(current || chats.isGenerating)
                .accessibilityIdentifier("model-use-\(spec.id)")
            } else {
                HStack(spacing: 12) {
                    // Several models can download at once; a file import
                    // waits while another file is being checked.
                    Button("ダウンロード") { model.download(spec) }
                        .buttonStyle(.borderedProminent)
                        .disabled(model.isRestoring)
                        .accessibilityLabel("\(spec.name)をダウンロード")
                        .accessibilityIdentifier("model-download-\(spec.id)")
                    Button("ファイルから") {
                        importingModel = spec
                        showImporter = true
                    }
                    .buttonStyle(.bordered)
                    .disabled(model.isBusy)
                    .accessibilityLabel("\(spec.name)をファイルから取り込む")
                }
                .font(.subheadline)
                if model.network.waitsForWiFi(allowsCellular: model.allowsCellular) {
                    Label("Wi-Fiにつながるとダウンロードを始めます。", systemImage: "wifi.slash")
                        .font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("model-download-wifi-note-\(spec.id)")
                }
                DisclosureGroup("取り込むファイル名") {
                    Text(spec.fileName).font(.caption).textSelection(.enabled)
                        .padding(.top, 4)
                }.font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
    /// Unmaps the weights first: the engine may still hold the file open.
    private func delete(_ spec: ModelSpec) {
        Task {
            await chats.unloadModel()
            model.delete(spec)
        }
    }
    /// The free space is read off the main thread, so the list stays live
    /// while iOS answers.
    private func selectAutomatically() {
        choosing = true
        Task {
            let freeDisk = await Task.detached(priority: .userInitiated) { DeviceOverview.freeDiskBytes }.value
            choosing = false
            let capacity = DeviceOverview.capacity(freeDiskBytes: freeDisk)
            let installed = Set(ModelSpec.catalog.filter { model.isInstalled($0) }.map(\.id))
            guard let recommended = ModelRecommendation.recommended(for: capacity, installedIDs: installed,
                                                                    includeDeveloperModels: showDeveloperSettings) else {
                model.error = String(localized: "モデルをダウンロードするための空き容量が足りません。"); return
            }
            guard !chats.isGenerating, !model.isBusy else { return }
            model.select(recommended)
            chats.newChat(modelID: recommended.id)
            chats.releaseModelMemory()
            automaticSelection = recommended
            if !model.isInstalled(recommended) { model.download(recommended) }
        }
    }
}

/// 設定's 開発者設定 (2026-10-24): shown by three three-finger swipes on
/// 設定's rows, with the switch at the top. Turned on, everything for
/// developers appears below it, as it did below the switch in モデルと設定,
/// so the switch stays under the finger.
struct DeveloperSettingsView: View {
    @EnvironmentObject private var chats: ChatStore
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// The sheet's opening, for 診断をまとめて実行.
    let opening: SettingsOpening
    /// 診断をまとめて実行; nothing is measured or read for it until pressed.
    @State private var diagnostics: DeveloperSnapshot?
    @State private var diagnosing = false
    @State private var diagnosticsRun = 0

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Toggle("開発者向けの設定項目を表示する",
                           isOn: $showDeveloperSettings.animation(.smooth(duration: 0.3)))
                        .accessibilityIdentifier("developer-settings-toggle")
                    Text("オンの間は、モデル管理に開発者向けのモデルも並びます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                SettingsSlideMeterCard()
                if showDeveloperSettings {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("現在の実行方法: \(chats.currentSettings.backend.rawValue)。生成設定から変更できます。")
                            .font(.caption).foregroundStyle(.secondary)
                        Button("AIのメモリを解放する") { chats.releaseModelMemory() }
                            .font(.subheadline).disabled(chats.isGenerating)
                        HStack(spacing: 10) {
                            Button { runDiagnostics() } label: {
                                Label("診断をまとめて実行", systemImage: "stethoscope")
                            }
                            .font(.subheadline).disabled(diagnosing)
                            .accessibilityIdentifier("developer-diagnostics-run")
                            if diagnosing { ProgressView().controlSize(.small) }
                        }
                        Text(diagnostics?.summary(openTook: opening.took)
                             ?? "空き容量・メモリ・設定画面の開く速さを測り、下の推論の診断とダウンロードの記録を読み込みます。")
                            .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                            .accessibilityIdentifier("developer-diagnostics-result")
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                    InferenceDiagnosticsCard(loadRequest: diagnosticsRun)
                    SendScreenLogCard(loadRequest: diagnosticsRun)
                    DownloadLogCard(loadRequest: diagnosticsRun)
                }
                FirstLaunchResetCard()
            }
            .padding(20)
        }
        .accessibilityIdentifier("developer-list")
        .settingsScroll()
    }

    /// Everything at once, off the main thread: reading the free space can
    /// keep iOS busy for seconds.
    private func runDiagnostics() {
        diagnosing = true
        diagnosticsRun += 1
        Task {
            diagnostics = await Task.detached(priority: .userInitiated) { DeveloperSnapshot.take() }.value
            diagnosing = false
        }
    }
}

/// 設定's page slides on this phone (SettingsSlideMeter): the last one, and
/// the measurement of every page's, to read or copy for a report.
private struct SettingsSlideMeterCard: View {
    var body: some View {
        let meter = SettingsSlideMeter.shared
        VStack(alignment: .leading, spacing: 10) {
            Text("ページ移動のなめらかさ").font(.headline)
            // The page's own slide in is the latest one.
            Text(meter.summary ?? "ページを移動すると、その動きの滑らかさをここに表示します。")
                .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                .accessibilityIdentifier("developer-slide-meter")
            HStack(spacing: 10) {
                Button { meter.runner?() } label: {
                    Label("ページ移動を計測（約2分）", systemImage: "speedometer")
                }
                .font(.subheadline).disabled(meter.running)
                .accessibilityIdentifier("developer-slide-measure")
                if meter.running { ProgressView().controlSize(.small) }
            }
            Text(meter.report ?? "設定トップから5つのページを開いて戻る動きを、152の動かし方と153の動かし方などで2回ずつ自動で行います。終わるとこの画面に戻り、結果を表示します。計測中は画面に触れないでください。")
                .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                .accessibilityIdentifier("developer-slide-report")
            if let report = meter.report {
                Button("結果をコピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = report }
                    .font(.subheadline)
                    .accessibilityIdentifier("developer-slide-copy")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}

/// 入力欄のタイプ (2026-10-23): 縮小型, the panel that folds into three
/// buttons while older messages are read, or 従来型, the plus and the one-
/// line field of earlier versions. The chat follows the choice at once.
/// The phones stand without a heading since 2026-10-25.
struct ComposerStyleCard: View {
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Each type on a small phone, playing what it does (2026-10-24).
            ComposerStylePicker(selection: $style)
            // Two lines kept for both, so a choice never moves the card.
            Text(style.previewCaption)
                .font(.subheadline).foregroundStyle(.secondary)
                .lineLimit(2, reservesSpace: true)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}

/// 起動時のチャット (user, 2026-10-25): 前回の会話 or 新しいチャット, each on a
/// small phone opening Fielua from the home screen (LaunchChatPicker), in
/// the composer type chosen above. It replaced 「起動時にキーボードを開いて
/// おく」, whose on is 新しいチャット now (LaunchChatMode.migrate).
struct LaunchChatCard: View {
    @AppStorage(LaunchChatMode.storageKey) private var mode = LaunchChatMode.resume
    @AppStorage(ComposerStyle.storageKey) private var style = ComposerStyle.folding
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("起動時のチャット").font(.headline)
                .accessibilityAddTraits(.isHeader)
            LaunchChatPicker(selection: $mode, style: style)
            // Two lines kept for both, so a choice never moves the card.
            Text(mode.previewCaption)
                .font(.subheadline).foregroundStyle(.secondary)
                .lineLimit(2, reservesSpace: true)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
}

/// モバイル通信でもダウンロード (0.0.1 (132)). Off until turned on: each
/// model is several gigabytes.
struct CellularDownloadCard: View {
    @EnvironmentObject private var model: ModelStore
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle("モバイル通信でもダウンロード", isOn: $model.allowsCellular)
                .font(.headline).accessibilityIdentifier("model-download-cellular-toggle")
            Text("オフのときは、Wi-Fiにつながってからダウンロードします。モデルは1つで数GBあります（\(Self.sizes)）。料金プランのデータ量にご注意ください。")
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
    static var sizes: String {
        ModelSpec.visibleCatalog(developer: false).map { "\($0.name) \($0.sizeLabel)" }.formatted(.list(type: .and, width: .narrow))
    }
}

/// The developer settings' figures, taken when asked for.
struct DeveloperSnapshot: Sendable {
    let freeDiskBytes: Int64
    let freeDiskSeconds: TimeInterval
    let availableMemoryBytes: UInt64
    let addressSpace: AddressSpace?

    static func take() -> Self {
        let start = Date()
        let free = DeviceOverview.freeDiskBytes
        let seconds = Date().timeIntervalSince(start)
        return Self(freeDiskBytes: free, freeDiskSeconds: seconds,
                    availableMemoryBytes: UInt64(os_proc_available_memory()), addressSpace: AddressSpace.current())
    }

    func summary(openTook: TimeInterval?) -> String {
        func gigabytes(_ bytes: UInt64) -> String { String(format: "%.2f GB", Double(bytes) / 1_000_000_000) }
        var lines = [
            openTook.map { String(format: "設定画面の準備: %.2f秒（作り始めてから最初の表示まで）", $0) } ?? "設定画面の準備: 計れませんでした",
            "空き容量: " + ByteCountFormatter.string(fromByteCount: freeDiskBytes, countStyle: .decimal)
                + String(format: "（iOSが答えるまで %.2f秒）", freeDiskSeconds),
            "使えるメモリ: " + gigabytes(availableMemoryBytes),
        ]
        if let space = addressSpace {
            lines.append("アドレス空間: 空き \(gigabytes(space.free)) · 最大の連続した空き \(gigabytes(space.largestFree))")
        }
        return lines.joined(separator: "\n")
    }
}

/// Three fingers moving up or down together. It watches touches without
/// claiming them until they lift, so the list keeps scrolling normally.
struct ThreeFingerVerticalSwipe: UIGestureRecognizerRepresentable {
    let action: (Date) -> Void
    func makeUIGestureRecognizer(context: Context) -> ThreeFingerVerticalRecognizer {
        let recognizer = ThreeFingerVerticalRecognizer()
        recognizer.cancelsTouchesInView = false
        recognizer.delaysTouchesBegan = false
        recognizer.delaysTouchesEnded = false
        recognizer.delegate = context.coordinator
        return recognizer
    }
    func handleUIGestureRecognizerAction(_ recognizer: ThreeFingerVerticalRecognizer, context: Context) {
        if recognizer.state == .ended, let start = recognizer.startedAt { action(start) }
    }
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}

final class ThreeFingerVerticalRecognizer: UIGestureRecognizer {
    private(set) var startedAt: Date?
    private var starts: [ObjectIdentifier: CGPoint] = [:]
    private var latest: [ObjectIdentifier: CGPoint] = [:]

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        for touch in touches {
            let point = touch.location(in: nil)
            starts[ObjectIdentifier(touch)] = point; latest[ObjectIdentifier(touch)] = point
        }
        if starts.count > 3 { state = .failed; return }
        if starts.count == 3, startedAt == nil { startedAt = Date() }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesMoved(touches, with: event)
        for touch in touches { latest[ObjectIdentifier(touch)] = touch.location(in: nil) }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesEnded(touches, with: event)
        for touch in touches { latest[ObjectIdentifier(touch)] = touch.location(in: nil) }
        let active = (event.allTouches ?? []).filter { $0.phase != .ended && $0.phase != .cancelled && starts[ObjectIdentifier($0)] != nil }
        guard active.isEmpty else { return }
        state = isSwipe ? .ended : .failed
    }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesCancelled(touches, with: event)
        state = .failed
    }
    /// The list's own scrolling must not cancel this observer.
    override func canBePrevented(by preventing: UIGestureRecognizer) -> Bool { false }
    override func reset() {
        super.reset()
        starts = [:]; latest = [:]; startedAt = nil
    }
    private var isSwipe: Bool {
        guard starts.count == 3, startedAt != nil else { return false }
        let moves = starts.compactMap { id, start in latest[id].map { CGPoint(x: $0.x - start.x, y: $0.y - start.y) } }
        guard moves.count == 3 else { return false }
        let dy = moves.map(\.y).reduce(0, +) / 3, dx = moves.map(\.x).reduce(0, +) / 3
        let together = moves.allSatisfy { ($0.y > 0) == (dy > 0) }
        return together && abs(dy) >= 50 && abs(dy) > abs(dx) * 1.5
    }
}
