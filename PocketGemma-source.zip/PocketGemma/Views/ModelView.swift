import SwiftUI
import UniformTypeIdentifiers
import UIKit
import PocketCore

struct ModelView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var showImporter = false
    @State private var importingModel: ModelSpec?
    @State private var showConfiguration = false
    @State private var automaticSelection: ModelSpec?
    @AppStorage("show-developer-settings-v1") private var showDeveloperSettings = false
    /// The developer switch is hidden while off. At the bottom of this screen,
    /// three downward three-finger swipes reveal it for this visit.
    @State private var developerRevealed = ProcessInfo.processInfo.arguments.contains("--developer-unlocked")
    @State private var atBottom = false
    @State private var revealSwipes = 0
    @State private var lastRevealSwipe = Date.distantPast
    private let device = DeviceOverview.capacity

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("あなたの\(DeviceOverview.name)に、AIを。")
                            .font(.title2.weight(.semibold))
                        Text("モデルを保存すれば、ネットがなくても会話できます。別のモデルを選ぶと新しい会話が開きます。")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Button { showConfiguration = true } label: {
                        Label("生成設定・システムプロンプト", systemImage: "slider.horizontal.3")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating)
                        .accessibilityIdentifier("model-generation-settings")
                    Button { selectAutomatically() } label: {
                        Label("この端末に合うモデルを選ぶ", systemImage: "sparkles")
                    }.buttonStyle(.bordered).disabled(chats.isGenerating || model.isBusy)
                        .accessibilityIdentifier("model-recommendations")
                    if let automaticSelection {
                        VStack(alignment: .leading, spacing: 5) {
                            Label("\(automaticSelection.name)を自動選択しました", systemImage: "checkmark.circle.fill")
                                .font(.subheadline).foregroundStyle(.green)
                            Text("\(DeviceOverview.identifier) · メモリ \(Double(device.memoryBytes) / 1_000_000_000, specifier: "%.1f") GB · CPU \(device.processorCount)コア。空き容量と利用可能なメモリも確認しました。")
                                .font(.caption).foregroundStyle(.secondary)
                        }.accessibilityIdentifier("model-auto-result")
                    }
                    ForEach(ModelSpec.visibleCatalog(developer: showDeveloperSettings)) { spec in modelCard(spec) }
                    CloudHistoryCard()
                    if showDeveloperSettings || developerRevealed {
                        VStack(alignment: .leading, spacing: 8) {
                            Toggle("開発者向けの設定項目を表示する", isOn: $showDeveloperSettings)
                                .accessibilityIdentifier("developer-settings-toggle")
                        }.padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                    }
                    if showDeveloperSettings {
                        Text("開発者向け").font(.headline).accessibilityAddTraits(.isHeader)
                        VStack(alignment: .leading, spacing: 12) {
                            Text("現在の実行方法: \(chats.currentSettings.backend.rawValue)。生成設定から変更できます。")
                                .font(.caption).foregroundStyle(.secondary)
                            Button("AIのメモリを解放する") { chats.releaseModelMemory() }
                                .font(.subheadline).disabled(chats.isGenerating)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
                        UpdateSourceCard()
                        InferenceDiagnosticsCard()
                    }
                    Label("会話は、この端末の中で処理されます。", systemImage: device.isPad ? "ipad" : "iphone")
                        .font(.caption).foregroundStyle(.secondary)
                }
                .padding(20)
            }
            .accessibilityIdentifier("model-list")
            .onScrollGeometryChange(for: Bool.self) { geometry in
                geometry.contentOffset.y + geometry.containerSize.height - geometry.contentInsets.bottom
                    >= geometry.contentSize.height - 40
            } action: { _, bottom in atBottom = bottom }
            .gesture(ThreeFingerSwipeDown { registerRevealSwipe() })
            .onAppear { model.refreshInstalled() }
            .background(Theme.canvas)
            .navigationTitle("モデルと設定").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
        }
        .sheet(isPresented: $showConfiguration) {
            GenerationConfigView(model: chats.currentModel, settings: chats.currentSettings, onSave: chats.updateSettings)
        }
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [UTType(filenameExtension: "litertlm") ?? .data], allowsMultipleSelection: false) { result in
            defer { importingModel = nil }
            do {
                if let spec = importingModel, let url = try result.get().first { model.importModel(url, spec: spec) }
            } catch { model.error = error.localizedDescription }
        }
        .alert("モデルを準備できませんでした", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
            Button("閉じる") { model.error = nil }
        } message: { Text(model.error ?? "") }
    }

    private func modelCard(_ spec: ModelSpec) -> some View {
        let installed = model.isInstalled(spec)
        let current = chats.currentModel.id == spec.id
        let working = model.operationModelID == spec.id
        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ModelMark(model: spec, size: 36)
                VStack(alignment: .leading, spacing: 3) {
                    Text(spec.name).font(.headline)
                    Text("\(spec.sizeLabel) · \(ModelAttachmentPolicy(model: spec).summary)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                if installed {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                        .accessibilityLabel("保存済み")
                }
            }
            Text(spec.summary).font(.subheadline).foregroundStyle(.secondary)
            if ModelAttachmentPolicy(model: spec).isTemporarilyLocked {
                Label("添付は現在調整中です。画像にはE2Bをご利用ください。", systemImage: "lock.fill")
                    .font(.caption).foregroundStyle(.secondary)
            }
            ModelFitGauges(fit: ModelRecommendation.fit(spec, device: device))
            if working {
                Text(model.statusText).font(.caption).foregroundStyle(.secondary)
                if model.isDownloading {
                    ProgressView(value: model.progress).tint(Theme.accent)
                    Button("ダウンロードを中止") { model.cancelDownload() }.font(.subheadline)
                } else { ProgressView() }
            } else if installed {
                Button(current ? "使用中" : "このモデルで会話を始める") {
                    model.select(spec)
                    chats.newChat(modelID: spec.id)
                    chats.releaseModelMemory()
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .disabled(current || chats.isGenerating)
                .accessibilityIdentifier("model-use-\(spec.id)")
            } else {
                HStack(spacing: 12) {
                    Button("ダウンロード") { model.download(spec) }
                        .buttonStyle(.borderedProminent)
                        .accessibilityLabel("\(spec.name)をダウンロード")
                        .accessibilityIdentifier("model-download-\(spec.id)")
                    Button("ファイルから") {
                        importingModel = spec
                        showImporter = true
                    }
                    .buttonStyle(.bordered)
                    .accessibilityLabel("\(spec.name)をファイルから取り込む")
                }
                .font(.subheadline).disabled(model.isBusy)
                DisclosureGroup("取り込むファイル名") {
                    Text(spec.fileName).font(.caption).textSelection(.enabled)
                        .padding(.top, 4)
                }.font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
    }
    /// Counts only a run that starts at the bottom; the swipe itself scrolls
    /// the list a little, so later swipes count within a short window.
    private func registerRevealSwipe() {
        let now = Date()
        if now.timeIntervalSince(lastRevealSwipe) > 4 { revealSwipes = 0 }
        guard atBottom || revealSwipes > 0 else { return }
        revealSwipes += 1; lastRevealSwipe = now
        if revealSwipes >= 3 {
            revealSwipes = 0
            withAnimation(.smooth(duration: 0.25)) { developerRevealed = true }
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        }
    }
    private func selectAutomatically() {
        let capacity = DeviceOverview.capacity
        let installed = Set(ModelSpec.catalog.filter { model.isInstalled($0) }.map(\.id))
        guard let recommended = ModelRecommendation.recommended(for: capacity, installedIDs: installed,
                                                                includeDeveloperModels: showDeveloperSettings) else {
            model.error = "モデルを保存するための空き容量が足りません。"; return
        }
        model.select(recommended)
        chats.newChat(modelID: recommended.id)
        chats.releaseModelMemory()
        automaticSelection = recommended
        if !model.isInstalled(recommended) { model.download(recommended) }
    }
}

/// A three-finger downward swipe, recognized alongside the list's scrolling.
struct ThreeFingerSwipeDown: UIGestureRecognizerRepresentable {
    let action: () -> Void
    func makeUIGestureRecognizer(context: Context) -> UISwipeGestureRecognizer {
        let recognizer = UISwipeGestureRecognizer()
        recognizer.direction = .down
        recognizer.numberOfTouchesRequired = 3
        recognizer.delegate = context.coordinator
        return recognizer
    }
    func handleUIGestureRecognizerAction(_ recognizer: UISwipeGestureRecognizer, context: Context) {
        if recognizer.state == .ended { action() }
    }
    func makeCoordinator(converter: CoordinateSpaceConverter) -> Coordinator { Coordinator() }
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }
    }
}
