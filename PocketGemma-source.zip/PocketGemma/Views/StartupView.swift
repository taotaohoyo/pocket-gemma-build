import SwiftUI
import UIKit
import os
import Darwin
import PocketCore

enum DeviceOverview {
    static var capacity: DeviceCapacity { capacity(freeDiskBytes: freeDiskBytes) }
    /// Memory and processors only, for screens that don't show the free
    /// space: asking iOS for it can keep the main thread waiting, and the
    /// settings sheet asked on every open, before it could appear. Its free
    /// space reads 0.
    static var memoryCapacity: DeviceCapacity { capacity(freeDiskBytes: 0) }
    static func capacity(freeDiskBytes: Int64) -> DeviceCapacity {
        let available = UInt64(os_proc_available_memory())
        return DeviceCapacity(memoryBytes: ProcessInfo.processInfo.physicalMemory,
                              freeDiskBytes: freeDiskBytes,
                              processorCount: ProcessInfo.processInfo.processorCount,
                              isPad: UIDevice.current.userInterfaceIdiom == .pad,
                              availableMemoryBytes: available > 0 ? available : nil)
    }
    /// File system only, so it can be read off the main thread.
    static var freeDiskBytes: Int64 {
        // Application Support may not exist until the first model is saved.
        // Read the volume from the app's existing sandbox root on a fresh install.
        let url = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
        let values = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeAvailableCapacityKey])
        return values?.volumeAvailableCapacityForImportantUsage ?? Int64(values?.volumeAvailableCapacity ?? 0)
    }
    static var name: String { UIDevice.current.userInterfaceIdiom == .pad ? "iPad" : "iPhone" }
    static var identifier: String {
        var info = utsname(); uname(&info)
        return withUnsafeBytes(of: info.machine) { bytes in
            String(decoding: bytes.prefix { $0 != 0 }, as: UTF8.self)
        }
    }
}

struct ModelFitGauges: View {
    let fit: ModelFit
    var body: some View {
        VStack(spacing: 10) {
            // The two gauges compare the models with each other (E4B and
            // the smallest Qwen 3 are their 100%); their titles say so.
            gauge("モデルの重さ（推定）", value: fit.load, label: fit.loadLabel, color: fit.load >= 0.85 ? .orange : .mint)
            gauge("応答の速さ（目安）", value: fit.responsiveness, label: fit.speedLabel, color: .blue)
            Text("必要メモリの推定 \(fit.estimatedMemoryBytes / 1_000_000_000, specifier: "%.1f") GB / この端末の目安 \(fit.deviceMemoryBudgetBytes / 1_000_000_000, specifier: "%.1f") GB")
                .font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
        }.accessibilityElement(children: .combine)
    }
    private func gauge(_ title: String, value: Double, label: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack { Text(title); Spacer(); Text(label) }.font(.caption).foregroundStyle(.secondary)
            HStack(spacing: 3) {
                ForEach(0..<10) { index in
                    RoundedRectangle(cornerRadius: 3).fill(Double(index) < value * 10 ? color : Color.secondary.opacity(0.12))
                        .frame(height: 9)
                }
            }.accessibilityHidden(true)
        }
    }
}

/// The first launch's setup (OnboardingView) over the chat until it is
/// done, at a first launch and after 開発者設定's 「初回起動扱いにする」. It is
/// there from the first frame, without a cover sliding up, and gives way to
/// the chat beneath it by fading as it opens out a little.
struct StartupPresenter: ViewModifier {
    @AppStorage("model-startup-completed-v1") private var completed = false
    /// 開発者設定's 「初回起動扱いにする」 (FirstLaunchResetCard): the setup
    /// of a first launch at the next launch, from its first step, with the
    /// saved models, chats and settings as they are.
    @AppStorage(StartupPresenter.againKey) private var again = false
    private static let againKey = "model-startup-again-v1"
    /// Read once, at launch: set while Fielua runs, the setup waits for
    /// the next launch rather than coming over the settings.
    private static let againAtLaunch = UserDefaults.standard.bool(forKey: againKey)
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var showing = false
    /// Whether the setup covers the chat (LaunchKeyboard and the chat's
    /// notices wait it out).
    @MainActor static var presenting = false

    static func showAgain() {
        UserDefaults.standard.set(true, forKey: againKey)
        Onboarding.clear()
    }

    func body(content: Content) -> some View {
        content
            .accessibilityHidden(showing)
            .overlay {
                if showing {
                    OnboardingView(onFinish: finish)
                        .transition(systemReduceMotion || previewReduceMotion
                                    ? .opacity : .opacity.combined(with: .scale(scale: 1.04)))
                }
            }
            .onChange(of: showing, initial: true) { Self.presenting = showing }
            .onAppear {
                guard !completed || (Self.againAtLaunch && again) else { return }
                // againAtLaunch first, so it is read at launch.
                if Self.againAtLaunch && again {
                    showing = true
                    return
                }
                #if POCKET_PREVIEW
                showing = ProcessInfo.processInfo.arguments.contains("--startup")
                #else
                // Do not interrupt an established installation on update; a
                // setup closed midway goes on.
                if !Onboarding.inProgress
                    && (chats.threads.contains { !$0.messages.isEmpty } || ModelSpec.catalog.contains(where: model.isInstalled)) {
                    completed = true
                }
                showing = !completed
                #endif
            }
    }

    private func finish() {
        completed = true
        again = false
        withAnimation(.smooth(duration: 0.5)) { showing = false }
    }
}
