import SwiftUI
import UIKit
import os
import Darwin
import PocketCore

enum DeviceOverview {
    static var capacity: DeviceCapacity { capacity(freeDiskBytes: freeDiskBytes) }
    /// Memory and processors only, for screens that don't show the free
    /// space: asking iOS for it can keep the main thread waiting, and the
    /// settings sheet asked on every open, before it could appear. Its free
    /// space reads 0.
    static var memoryCapacity: DeviceCapacity { capacity(freeDiskBytes: 0) }
    static func capacity(freeDiskBytes: Int64) -> DeviceCapacity {
        let available = UInt64(os_proc_available_memory())
        return DeviceCapacity(memoryBytes: ProcessInfo.processInfo.physicalMemory,
                              freeDiskBytes: freeDiskBytes,
                              processorCount: ProcessInfo.processInfo.processorCount,
                              isPad: UIDevice.current.userInterfaceIdiom == .pad,
                              availableMemoryBytes: available > 0 ? available : nil)
    }
    /// File system only, so it can be read off the main thread.
    static var freeDiskBytes: Int64 {
        // Application Support may not exist until the first model is saved.
        // Read the volume from the app's existing sandbox root on a fresh install.
        let url = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
        let values = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeAvailableCapacityKey])
        return values?.volumeAvailableCapacityForImportantUsage ?? Int64(values?.volumeAvailableCapacity ?? 0)
    }
    static var name: String { UIDevice.current.userInterfaceIdiom == .pad ? "iPad" : "iPhone" }
    static var identifier: String {
        var info = utsname(); uname(&info)
        return withUnsafeBytes(of: info.machine) { bytes in
            String(decoding: bytes.prefix { $0 != 0 }, as: UTF8.self)
        }
    }
}

/// The setup (OnboardingView) over the chat until it is finished, once on
/// every phone for each of its editions (Onboarding.edition): at a first
/// launch, at the first launch after an update from a build before the
/// edition, and after 開発者設定's 「初回起動扱いにする」. It is there from
/// the first frame, without a cover sliding up, and gives way to the chat
/// beneath it by fading as it opens out a little.
extension EnvironmentValues {
    /// True while the setup covers the chat.
    @Entry var startupCovers = false
}

struct StartupPresenter: ViewModifier {
    /// Decided once, at launch: 「初回起動扱いにする」 pressed while Fielua
    /// runs waits for the next launch rather than coming over the settings.
    private static let dueAtLaunch = Onboarding.dueAtLaunch()
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var showing = false
    /// Whether the setup covers the chat (the chat's notices wait it out).
    @MainActor static var presenting = false
    /// Whether the setup comes over the chat at this launch: 起動時のチャット
    /// (LaunchChat) leaves the chat as it is then.
    static var coversLaunch: Bool { dueAtLaunch && Onboarding.isDue }

    /// 開発者設定's 「初回起動扱いにする」 (FirstLaunchResetCard): the setup
    /// at the next launch, from its first step, with the saved models,
    /// chats and settings as they are.
    static func showAgain() { Onboarding.showAgain() }

    func body(content: Content) -> some View {
        content
            .accessibilityHidden(showing)
            // The chat under the setup knows it is covered: its flower
            // rests there instead of moving unseen (1.1.0 (218)).
            .environment(\.startupCovers, showing)
            .overlay {
                if showing {
                    OnboardingView(onFinish: finish)
                        .transition(systemReduceMotion || previewReduceMotion
                                    ? .opacity : .opacity.combined(with: .scale(scale: 1.04)))
                }
            }
            .onChange(of: showing, initial: true) { Self.presenting = showing }
            // Once the setup is finished it stays finished, so it never
            // comes back on this launch either.
            .onAppear { showing = Self.dueAtLaunch && Onboarding.isDue }
    }

    private func finish() {
        withAnimation(FieluaMotion.cover) { showing = false }
    }
}
