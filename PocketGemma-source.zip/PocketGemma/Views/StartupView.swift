import SwiftUI
import UIKit
import os
import Darwin
import PocketCore

enum DeviceOverview {
    static var capacity: DeviceCapacity { capacity(freeDiskBytes: freeDiskBytes) }
    /// Memory and processors only, for screens that don't show the free
    /// space: asking iOS for it can keep the main thread waiting, and the
    /// settings sheet asked on every open, before it could appear. Its free
    /// space reads 0.
    static var memoryCapacity: DeviceCapacity { capacity(freeDiskBytes: 0) }
    static func capacity(freeDiskBytes: Int64) -> DeviceCapacity {
        let available = UInt64(os_proc_available_memory())
        return DeviceCapacity(memoryBytes: ProcessInfo.processInfo.physicalMemory,
                              freeDiskBytes: freeDiskBytes,
                              processorCount: ProcessInfo.processInfo.processorCount,
                              isPad: UIDevice.current.userInterfaceIdiom == .pad,
                              availableMemoryBytes: available > 0 ? available : nil)
    }
    /// File system only, so it can be read off the main thread.
    static var freeDiskBytes: Int64 {
        // Application Support may not exist until the first model is saved.
        // Read the volume from the app's existing sandbox root on a fresh install.
        let url = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
        let values = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey, .volumeAvailableCapacityKey])
        return values?.volumeAvailableCapacityForImportantUsage ?? Int64(values?.volumeAvailableCapacity ?? 0)
    }
    static var name: String { UIDevice.current.userInterfaceIdiom == .pad ? "iPad" : "iPhone" }
    static var identifier: String {
        var info = utsname(); uname(&info)
        return withUnsafeBytes(of: info.machine) { bytes in
            String(decoding: bytes.prefix { $0 != 0 }, as: UTF8.self)
        }
    }
}

struct StartupView: View {
    @EnvironmentObject private var model: ModelStore
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    private let device: DeviceCapacity
    private let onComplete: () -> Void
    @State private var selection: String
    init(device: DeviceCapacity = DeviceOverview.capacity, onComplete: @escaping () -> Void) {
        self.device = device; self.onComplete = onComplete
        _selection = State(initialValue: ModelRecommendation.recommended(for: device, includeDeveloperModels: false)?.id ?? ModelSpec.e2b.id)
    }
    private var selected: ModelSpec { ModelSpec.find(selection) ?? .e2b }
    private var fit: ModelFit { ModelRecommendation.fit(selected, device: device) }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        Image(systemName: "sparkles").font(.system(size: 42)).foregroundStyle(Theme.accent)
                        Text("この\(DeviceOverview.name)に、\nあなたのAIを。").font(.largeTitle.bold())
                        Text("モデルを保存したら、オフラインでも会話できます。端末に合わせたおすすめから選ぶことも、自分で選ぶこともできます。")
                            .font(.subheadline).foregroundStyle(.secondary)
                        Text("\(DeviceOverview.name) · メモリ \(Double(device.memoryBytes) / 1_000_000_000, specifier: "%.1f") GB · 空き \(ByteCountFormatter.string(fromByteCount: device.freeDiskBytes, countStyle: .decimal))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    ForEach(ModelSpec.visibleCatalog(developer: false)) { spec in
                        Button { withAnimation(.smooth(duration: 0.2)) { selection = spec.id } } label: {
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    ModelMark(model: spec, size: 36)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(spec.name).font(.headline)
                                        Text("\(spec.sizeLabel) · \(ModelAttachmentPolicy(model: spec).summary)")
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: selection == spec.id ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(selection == spec.id ? Theme.accent : Color.secondary)
                                }
                                if ModelRecommendation.recommended(for: device, includeDeveloperModels: false)?.id == spec.id {
                                    Label("この端末におすすめ", systemImage: "star.fill").font(.caption.weight(.semibold)).foregroundStyle(Theme.accent)
                                }
                                ModelFitGauges(fit: ModelRecommendation.fit(spec, device: device))
                            }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                                .background(Theme.card, in: RoundedRectangle(cornerRadius: 22))
                                .overlay { RoundedRectangle(cornerRadius: 22).stroke(selection == spec.id ? Theme.accent : .clear, lineWidth: 2) }
                        }.buttonStyle(.plain).foregroundStyle(.primary).accessibilityIdentifier("startup-model-\(spec.id)")
                    }
                    Text("ゲージはモデル間の相対比較です。必要メモリはモデルサイズからの推定、端末の目安はOSが報告するメモリ制約も考慮しています。速度は実測値ではありません。会話の長さ、画像、発熱によって動作は変わります。")
                        .font(.caption).foregroundStyle(.secondary)
                    if fit.memoryIsTight {
                        Label("このモデルはメモリの負荷が高く、返信が遅くなったり終了する場合があります。軽いモデルも選べます。", systemImage: "memorychip")
                            .font(.subheadline).foregroundStyle(.orange).accessibilityIdentifier("startup-memory-note")
                    }
                    // On cellular only, a download would wait for Wi-Fi
                    // unless this is turned on (the same switch as in
                    // モデルと設定).
                    if !model.network.hasWiFi && model.network.isOnline && !model.isInstalled(selected) {
                        VStack(alignment: .leading, spacing: 8) {
                            Toggle("モバイル通信でもダウンロード", isOn: $model.allowsCellular)
                                .font(.subheadline.weight(.semibold))
                                .accessibilityIdentifier("startup-download-cellular-toggle")
                            Text("いまはモバイル通信です。オフのままだと、Wi-Fiにつながってからダウンロードします（\(selected.name) \(selected.sizeLabel)）。")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(16).background(Theme.card, in: RoundedRectangle(cornerRadius: 18))
                    }
                    if !fit.hasDiskSpace && !model.isInstalled(selected) {
                        Text("空き容量が足りません。モデルサイズに加えて1 GBの空きが必要です。")
                            .font(.subheadline).foregroundStyle(.orange)
                    }
                }.padding(24).frame(maxWidth: 640).frame(maxWidth: .infinity)
            }.accessibilityIdentifier("startup-model-list")
                .background(Theme.canvas)
                .safeAreaInset(edge: .bottom) {
                    VStack(spacing: 10) {
                        Button(model.isInstalled(selected) ? "\(selected.name)で始める" : "\(selected.name)を選んで始める") {
                            model.select(selected)
                            chats.newChat(modelID: selected.id)
                            if !model.isInstalled(selected) { model.download(selected) }
                            guard model.error == nil else { return }
                            onComplete(); dismiss()
                        }.buttonStyle(.borderedProminent).controlSize(.large)
                            .disabled((!fit.hasDiskSpace && !model.isInstalled(selected)) || model.isBusy || chats.isGenerating)
                            .accessibilityIdentifier("startup-continue")
                        Button("あとで選ぶ") { onComplete(); dismiss() }.font(.subheadline)
                            .accessibilityIdentifier("startup-skip")
                    }.frame(maxWidth: .infinity).padding().background(Theme.canvas)
                }
                .navigationTitle("ようこそ").navigationBarTitleDisplayMode(.inline)
        }.interactiveDismissDisabled()
            .alert("モデルを準備できませんでした", isPresented: Binding(
                get: { model.error != nil }, set: { if !$0 { model.error = nil } })) {
                Button("閉じる") { model.error = nil }
            } message: { Text(model.error ?? "") }
    }
}

struct ModelFitGauges: View {
    let fit: ModelFit
    var body: some View {
        VStack(spacing: 10) {
            gauge("モデルの重さ（推定）", value: fit.load, label: fit.loadLabel, color: fit.load >= 0.85 ? .orange : .mint)
            Text("100% = Gemma 4 E4B。同じ基準でモデルの規模を比較します。")
                .font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
            gauge("相対的な応答速度（目安）", value: fit.responsiveness, label: fit.speedLabel, color: .blue)
            Text("100% = 最も小さいQwen 3。速度は実測値ではありません。")
                .font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
            Text("必要メモリの推定 \(fit.estimatedMemoryBytes / 1_000_000_000, specifier: "%.1f") GB / この端末の目安 \(fit.deviceMemoryBudgetBytes / 1_000_000_000, specifier: "%.1f") GB")
                .font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
        }.accessibilityElement(children: .combine)
    }
    private func gauge(_ title: String, value: Double, label: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack { Text(title); Spacer(); Text(label) }.font(.caption).foregroundStyle(.secondary)
            HStack(spacing: 3) {
                ForEach(0..<10) { index in
                    RoundedRectangle(cornerRadius: 3).fill(Double(index) < value * 10 ? color : Color.secondary.opacity(0.12))
                        .frame(height: 9)
                }
            }.accessibilityHidden(true)
        }
    }
}

struct StartupPresenter: ViewModifier {
    @AppStorage("model-startup-completed-v1") private var completed = false
    /// 開発者設定's 「初回起動扱いにする」 (FirstLaunchResetCard): the
    /// welcome of a first launch at the next launch, with the saved models
    /// and chats as they are.
    @AppStorage(StartupPresenter.againKey) private var again = false
    private static let againKey = "model-startup-again-v1"
    /// Read once, at launch: set while Fielua runs, the welcome waits for
    /// the next launch rather than coming over the settings.
    private static let againAtLaunch = UserDefaults.standard.bool(forKey: againKey)
    @EnvironmentObject private var chats: ChatStore
    @EnvironmentObject private var model: ModelStore
    @State private var showing = false

    static func showAgain() { UserDefaults.standard.set(true, forKey: againKey) }

    func body(content: Content) -> some View {
        content.fullScreenCover(isPresented: $showing) { StartupView { completed = true; again = false } }
            .onAppear {
                // againAtLaunch first, so it is read at launch.
                if Self.againAtLaunch && again {
                    showing = true
                    return
                }
                #if POCKET_PREVIEW
                showing = ProcessInfo.processInfo.arguments.contains("--startup") && !completed
                #else
                // Do not interrupt an established installation on update.
                if !completed && (chats.threads.contains { !$0.messages.isEmpty } || ModelSpec.catalog.contains(where: model.isInstalled)) {
                    completed = true
                }
                showing = !completed
                #endif
            }
    }
}
