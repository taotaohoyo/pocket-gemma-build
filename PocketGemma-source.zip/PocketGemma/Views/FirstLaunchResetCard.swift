import SwiftUI

/// 開発者設定's 「初回起動扱いにする」 (2026-10-24): Fielua on the iPhone
/// and its Apple Watch app go back to how they were before the watch app
/// was first opened, so the watch's one notification (WatchIntro) and the
/// watch app's first screen can be tried again. The chats, the models and
/// the settings stay: the model startup screen would only ask for a model
/// that is already saved.
struct FirstLaunchResetCard: View {
    @EnvironmentObject private var chats: ChatStore
    @State private var confirming = false
    @State private var done: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("初回起動").font(.headline)
            Button("初回起動扱いにする", systemImage: "arrow.counterclockwise") { confirming = true }
                .font(.subheadline)
                .disabled(chats.isGenerating)
                .accessibilityIdentifier("developer-first-launch")
            Text(done ?? "iPhoneとApple WatchのFieluaを、Watchアプリを初めて開く前の状態に戻します。Watchの紹介通知がもう一度届くようになり、Watchアプリは最初の画面から始まります。会話・モデル・設定はそのままです。")
                .font(.caption).foregroundStyle(.secondary)
                .accessibilityIdentifier("developer-first-launch-result")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
        .alert("初回起動扱いにしますか？", isPresented: $confirming) {
            Button("キャンセル", role: .cancel) {}
            Button("初回起動扱いにする", role: .destructive) { reset() }
        } message: {
            Text("Watchアプリの表示と、Watchアプリを使ったことの記録を消します。会話・モデル・設定は消えません。")
        }
    }

    private func reset() {
        #if POCKET_PREVIEW
        // The UI preview has no watch link.
        let watchTold = false
        #else
        WatchIntro.reset()
        let watchTold = WatchBridge.shared.resetWatch()
        #endif
        done = watchTold
            ? "初回起動扱いにしました。Watchアプリは次に開いたときに最初の画面に戻ります。紹介通知を見るには、Watchアプリを開かずにFieluaを閉じて、iPhoneをロックしたまま3分待ってください（通知の許可が必要です）。"
            : "iPhoneのFieluaを初回起動扱いにしました。このiPhoneにはFieluaのWatchアプリが入っていないため、紹介通知は届きません。"
    }
}
