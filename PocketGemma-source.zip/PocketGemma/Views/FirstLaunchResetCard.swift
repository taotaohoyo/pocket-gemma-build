import SwiftUI

/// 開発者設定's 「初回起動扱いにする」 (2026-10-24): Fielua on the iPhone
/// and its Apple Watch app go back to how they were at their first launch,
/// so the iPhone's welcome (StartupView), the watch's one notification
/// (WatchIntro) and the watch app's first screen can be tried again. The
/// chats, the models and the settings stay, so the welcome offers the
/// saved models as saved, with nothing to download again.
struct FirstLaunchResetCard: View {
    @EnvironmentObject private var chats: ChatStore
    @State private var confirming = false
    @State private var done: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("初回起動").font(.headline)
            Button("初回起動扱いにする", systemImage: "arrow.counterclockwise") { confirming = true }
                .font(.subheadline)
                .disabled(chats.isGenerating)
                .accessibilityIdentifier("developer-first-launch")
            Text(done ?? "iPhoneとApple WatchのFieluaを、初めて起動したときの状態に戻します。iPhoneは次の起動で「ようこそ」画面から始まり、Watchの紹介通知がもう一度届くようになります。Watchアプリは最初の画面から始まります。会話・モデル・設定はそのままです。")
                .font(.caption).foregroundStyle(.secondary)
                .accessibilityIdentifier("developer-first-launch-result")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
        .alert("初回起動扱いにしますか？", isPresented: $confirming) {
            Button("キャンセル", role: .cancel) {}
            Button("初回起動扱いにする", role: .destructive) { reset() }
        } message: {
            Text("次の起動で「ようこそ」画面を出し、Watchアプリの表示と、Watchアプリを使ったことの記録を消します。会話・モデル・設定は消えません。")
        }
    }

    private func reset() {
        StartupPresenter.showAgain()
        #if POCKET_PREVIEW
        // The UI preview has no watch link.
        let watchTold = false
        #else
        WatchIntro.reset()
        let watchTold = WatchBridge.shared.resetWatch()
        #endif
        let startup = "iPhoneのFieluaは、次に起動したとき（Appスイッチャーで上にスワイプして終了してから開いたとき）に「ようこそ」画面から始まります。"
        done = watchTold
            ? "初回起動扱いにしました。" + startup + "Watchアプリは次に開いたときに最初の画面に戻ります。紹介通知を見るには、Watchアプリを開かずにFieluaを閉じて、iPhoneをロックしたまま3分待ってください（通知の許可が必要です）。"
            : "初回起動扱いにしました。" + startup + "このiPhoneにはFieluaのWatchアプリが入っていないため、紹介通知は届きません。"
    }
}
