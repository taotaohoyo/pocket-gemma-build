import SwiftUI
import QuartzCore

/// The phone's history drawer, moved frame by frame at the display's own
/// beat (1.1.0 (272), fielua-reports Issue #11).
///
/// Until 270 the drawer rode SwiftUI's spring, which runs on the clock: it
/// starts as the tap is handled and is wherever its curve says when a frame
/// is finally drawn. When the main thread was busy as a close began (the
/// chat changing under it, a new chat made, the history's keyboard going)
/// the first frame that reached the screen was already at the end, and the
/// whole close showed in one frame (Hachimoto さん's recording on 270,
/// 2026-11-13, twice in four closes; one frame nearly closed in 268's own
/// UI check, as a search result was opened). Here a display link moves it:
/// each frame advances it by that frame's time, and by no more than two
/// frames' worth however long the frame before took, so a busy moment
/// slows the slide, never skips it. It starts from the first frame drawn
/// after the tap, at 120 a second where the screen can (as the settings'
/// pages since 1.1.0 (153)).
///
/// Two values are moved. `slide`: how far the conversation stands aside, 0
/// to 1. `lift`: how far the history has come up from behind it, 0 (back,
/// smaller and faint) to 1 (in place). The lift is its own spring: opening
/// it follows the slide a little behind, so the history comes forward as
/// the conversation uncovers it; closing it goes ahead, so the history
/// sinks back as the conversation comes over it. A finger holds the slide
/// and the lift follows close behind. Every change of course carries on
/// from where both are drawn and how fast they move: a finger catching a
/// slide, a tap reversing it, never a jump.
@MainActor final class HistoryDrawerMotion: NSObject {
    struct Frame: Equatable {
        var slide: CGFloat
        var lift: CGFloat
    }

    /// The conversation's slide (button, strip, a finger let go).
    static let slideResponse: CGFloat = 0.38
    /// The history coming forward, a little behind the slide.
    static let liftOpening: CGFloat = 0.5
    /// The history sinking back, ahead of the slide.
    static let liftClosing: CGFloat = 0.28
    /// The history following a finger.
    static let liftHeld: CGFloat = 0.1
    /// With Reduce Motion: a short slide, and the history fades with it.
    static let reducedResponse: CGFloat = 0.22
    /// A frame never moves the drawer on by more than this, in seconds.
    static let longestStep: CFTimeInterval = 1.0 / 30

    private(set) var slide: CGFloat = 0
    private var slideVelocity: CGFloat = 0
    private(set) var lift: CGFloat = 0
    private var liftVelocity: CGFloat = 0
    private var target: CGFloat = 0
    private var held = false
    private var reduced = false
    private var link: CADisplayLink?
    private var lastTime: CFTimeInterval?
    private var settled: (() -> Void)?
    /// Draws a frame: set by the drawer's view.
    var draw: (Frame) -> Void = { _ in }

    #if POCKET_PREVIEW
    /// The film (`--drawer-film`) steps the drawer itself, a sixtieth of a
    /// second a frame, and draws each frame before the next.
    var manual = false
    /// `--drawer-slow`: fifteen times as long, for the UI check's samples.
    var timeScale: CGFloat = 1
    /// Each frame's time and values, for the UI check (DRAWER-TRACE).
    var trace: ((CFTimeInterval, Frame) -> Void)?
    #endif

    /// True while it moves on its own.
    var moving: Bool { link != nil }

    /// Slides to `target` (0 closed, 1 open) from where it is drawn. A
    /// finger's speed on letting go, in widths a second, carries on.
    func run(to target: CGFloat, velocity: CGFloat? = nil, reduced: Bool, settled: @escaping () -> Void) {
        self.target = target
        self.reduced = reduced
        held = false
        if let velocity { slideVelocity = min(max(velocity, -12), 12) }
        if reduced { lift = slide; liftVelocity = 0 }
        self.settled = settled
        start()
    }

    /// A finger holds the slide here; the history follows it.
    func hold(at value: CGFloat, reduced: Bool) {
        self.reduced = reduced
        held = true
        settled = nil
        slide = value
        slideVelocity = 0
        target = value
        if reduced { lift = value; liftVelocity = 0 }
        draw(Frame(slide: slide, lift: lift))
        if abs(lift - slide) > 0.001 { start() }
    }

    /// Put at once where it is asked to stand (a window narrowed to the
    /// phone's drawer, the UI check's drawer held open).
    func place(at value: CGFloat) {
        stopLink()
        settled = nil
        held = false
        slide = value; lift = value; target = value
        slideVelocity = 0; liftVelocity = 0
        draw(Frame(slide: slide, lift: lift))
    }

    private func start() {
        #if POCKET_PREVIEW
        if manual { return }
        #endif
        guard link == nil else { return }
        lastTime = nil
        // The link keeps its target until it is invalidated.
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFrameRateRange = CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    private func stopLink() {
        link?.invalidate()
        link = nil
        lastTime = nil
    }

    @objc private func tick(_ link: CADisplayLink) {
        // Set for when this frame appears; the first one a frame on from
        // where it stands, however long the tap's turn took.
        let elapsed = link.targetTimestamp - (lastTime ?? link.timestamp)
        lastTime = link.targetTimestamp
        advance(by: elapsed)
    }

    /// Moves on by `elapsed` seconds (at most `longestStep`) and draws.
    /// Returns true once it has come to rest.
    @discardableResult
    func advance(by elapsed: CFTimeInterval) -> Bool {
        var step = CGFloat(min(max(elapsed, 0), Self.longestStep))
        #if POCKET_PREVIEW
        step /= timeScale
        #endif
        if !held {
            Self.spring(&slide, &slideVelocity, to: target,
                        response: reduced ? Self.reducedResponse : Self.slideResponse, over: step)
        }
        if reduced {
            lift = slide; liftVelocity = 0
        } else {
            let response = held ? Self.liftHeld : (target > 0.5 ? Self.liftOpening : Self.liftClosing)
            Self.spring(&lift, &liftVelocity, to: held ? slide : target, response: response, over: step)
        }
        let resting = (held || (abs(slide - target) < 0.0005 && abs(slideVelocity) < 0.01))
            && abs(lift - (held ? slide : target)) < 0.0005 && abs(liftVelocity) < 0.01
        if resting {
            if !held { slide = target; slideVelocity = 0 }
            lift = held ? slide : target; liftVelocity = 0
        }
        draw(Frame(slide: slide, lift: lift))
        #if POCKET_PREVIEW
        trace?(CACurrentMediaTime(), Frame(slide: slide, lift: lift))
        #endif
        if resting {
            stopLink()
            let settled = self.settled
            self.settled = nil
            settled?()
        }
        return resting
    }

    /// A critically damped spring, stepped exactly: no overshoot, and the
    /// same path whatever the frame rate.
    private static func spring(_ value: inout CGFloat, _ velocity: inout CGFloat, to target: CGFloat,
                               response: CGFloat, over time: CGFloat) {
        guard time > 0 else { return }
        let omega = 2 * .pi / response
        let offset = value - target
        let decay = exp(-omega * time)
        let carry = velocity + omega * offset
        value = target + (offset + carry * time) * decay
        velocity = (velocity - omega * carry * time) * decay
    }
}

/// How the history stands as it comes up from behind the conversation
/// (1.1.0 (272)): from a little smaller and faint to its place and size.
/// It does not slide in from the side: it comes forward where it stands.
enum HistoryDepth {
    /// Its size at the back.
    static let back: CGFloat = 0.94
    static func scale(_ lift: CGFloat, reduced: Bool) -> CGFloat {
        reduced ? 1 : back + (1 - back) * min(max(lift, 0), 1)
    }
    /// Faint at the back, whole a little past half way up.
    static func opacity(_ lift: CGFloat) -> Double {
        let part = Double(min(max(lift / 0.55, 0), 1))
        return part * part * (3 - 2 * part)
    }
}
