import SwiftUI
import PocketCore

/// A model's mark. Since 1.1.0 (282) (fielua-reports Issue #19) a model of
/// Gemma, Qwen or LFM shows its series' own mark (SeriesMark), the same in
/// モデル管理, on the first launch, at the chat's top and in the download's
/// Live Activity; its name is written beside it. Until 281 Gemma showed the
/// Google "G" logo (GemmaLogo) and the others their symbol on the brand's
/// yellow, which a model of another family still does (the symbol also
/// goes to the Live Activity as before).
struct ModelMark: View {
    let model: ModelSpec
    var size: CGFloat = 40
    private var colors: [Color] { [Theme.brandLight, Theme.brandYellow] }
    var symbol: String {
        switch model.id {
        case ModelSpec.e2b.id: return "sparkle"
        case ModelSpec.qwen3.id: return "bolt.fill"
        case ModelSpec.qwen25.id: return "cube.fill"
        case ModelSpec.phi4MiniReasoning.id: return "function"
        case ModelSpec.qwen35.id: return "globe"
        case ModelSpec.lfm3.id: return "drop.fill"
        case ModelSpec.lfm3VL.id: return "eye.fill"
        case ModelSpec.lfm3Omni.id: return "waveform"
        default: return "diamond.fill"
        }
    }
    var body: some View {
        if let series = ModelSeries(family: model.family) {
            SeriesMark(series: series, size: size)
        } else { generatedMark }
    }
    private var generatedMark: some View {
        Image(systemName: symbol).font(.system(size: size * 0.44, weight: .medium))
            .foregroundStyle(Theme.onAccent)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
            .accessibilityHidden(true)
    }
}
