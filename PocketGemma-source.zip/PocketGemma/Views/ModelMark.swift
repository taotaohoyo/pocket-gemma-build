import SwiftUI
import PocketCore

/// Separate artwork for each model; a family initial alone made E2B and E4B
/// indistinguishable in conversation history.
struct ModelMark: View {
    let model: ModelSpec
    var size: CGFloat = 40
    private var colors: [Color] {
        switch model.id {
        case ModelSpec.e2b.id: return [.mint, .teal]
        case ModelSpec.qwen3.id: return [.indigo, .purple]
        case ModelSpec.qwen25.id: return [.orange, .pink]
        // 1.1.0 (205)'s models, in the icon's rainbow colors.
        case ModelSpec.phi4MiniReasoning.id: return [.orange, .red]
        case ModelSpec.qwen35.id: return [.green, .teal]
        default: return [.cyan, .blue]
        }
    }
    var symbol: String {
        switch model.id {
        case ModelSpec.e2b.id: return "sparkle"
        case ModelSpec.qwen3.id: return "bolt.fill"
        case ModelSpec.qwen25.id: return "cube.fill"
        case ModelSpec.phi4MiniReasoning.id: return "function"
        case ModelSpec.qwen35.id: return "globe"
        default: return "diamond.fill"
        }
    }
    /// Gemma models show the owner-supplied logo asset (GemmaLogo), drawn
    /// bare like other model lists; other models keep the generated mark.
    private var logoAsset: String? { model.family == "Gemma" ? "GemmaLogo" : nil }
    var body: some View {
        if let logoAsset {
            Image(logoAsset).resizable().interpolation(.high).scaledToFit()
                .frame(width: size * 0.82, height: size * 0.82)
                .frame(width: size, height: size)
                .accessibilityHidden(true)
        } else { generatedMark }
    }
    private var generatedMark: some View {
        Image(systemName: symbol).font(.system(size: size * 0.44, weight: .medium))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
            .accessibilityHidden(true)
    }
}
