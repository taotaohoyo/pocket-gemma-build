import SwiftUI
import PocketCore

/// Separate artwork for each model; a family initial alone made E2B and E4B
/// indistinguishable in conversation history.
struct ModelMark: View {
    let model: ModelSpec
    var size: CGFloat = 40
    private var colors: [Color] {
        switch model.id {
        case ModelSpec.e2b.id: return [.mint, .teal]
        case ModelSpec.qwen3.id: return [.indigo, .purple]
        case ModelSpec.qwen25.id: return [.orange, .pink]
        default: return [.cyan, .blue]
        }
    }
    private var symbol: String {
        switch model.id {
        case ModelSpec.e2b.id: return "sparkle"
        case ModelSpec.qwen3.id: return "bolt.fill"
        case ModelSpec.qwen25.id: return "cube.fill"
        default: return "diamond.fill"
        }
    }
    var body: some View {
        Image(systemName: symbol).font(.system(size: size * 0.44, weight: .medium))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
            .accessibilityHidden(true)
    }
}
