import SwiftUI
import PocketCore

/// The phrase the Aurora Orb shows under it (ReplyGlimpse, 1.1.0 (297)), and
/// when it began to show.
struct GlimpseShown: Equatable {
    let text: String
    let since: Date
}

/// A reply row's glimpse plan and the wake it asked for, kept by reference so
/// neither redraws the row.
@MainActor final class ReplyGlimpseClock {
    private(set) lazy var plan = ReplyGlimpse(timeScale: ReplyGlimpseFilm.scale)
    private var wake: Task<Void, Never>?
    private var wakeAt: TimeInterval?

    /// Calls `step` at `time` (seconds since the reference date), in place
    /// of any earlier wake; nil cancels it.
    func wake(at time: TimeInterval?, _ step: @escaping @MainActor () -> Void) {
        guard time != wakeAt || wake == nil else { return }
        cancel()
        guard let time else { return }
        wakeAt = time
        wake = Task { @MainActor in
            let delay = time - Date().timeIntervalSinceReferenceDate
            if delay > 0 { try? await Task.sleep(for: .seconds(delay)) }
            guard !Task.isCancelled else { return }
            self.wake = nil
            self.wakeAt = nil
            step()
        }
    }

    func cancel() {
        wake?.cancel()
        wake = nil
        wakeAt = nil
    }
}

/// Whether a glimpse shows anywhere, so the developers' status line, which
/// stands in the same room under the last reply, steps aside for it.
@Observable @MainActor final class ReplyGlimpseBoard {
    static let shared = ReplyGlimpseBoard()
    private var count = 0
    var showing: Bool { count > 0 }
    func arrived() { count += 1 }
    func left() { count = max(count - 1, 0) }
}

/// The preview's slow motion for filming the glimpse frame by frame
/// (`--glimpse-slow-motion`): its times, and the orb's shrink with them, four
/// times as long. 1 in the app.
enum ReplyGlimpseFilm {
    #if POCKET_PREVIEW
    static let scale: Double = PreviewProbe.on("--glimpse-slow-motion") ? 4 : 1
    /// `--probe-glimpse-unseen`: the orb keeps the glimpse's times and no
    /// line is drawn, so the frames' check tells the line's own cost from
    /// the orb's longer stay.
    static let unseen = PreviewProbe.on("--probe-glimpse-unseen")
    #else
    static let scale: Double = 1
    static let unseen = false
    #endif
}

/// The glimpse under the orb: one line of the reply's own first words, small
/// and faint, in the room that is always under the last reply
/// (so nothing in the conversation moves). It rises a few points out of a soft
/// blur as it fades in, rests, and fades on up into the blur as the orb
/// leaves, gone before the reply's text begins (ReplyGlimpseMotion); with
/// Reduce Motion, or while the orb holds still for heat, it only fades. It
/// draws with the orb's clock, at its pace, and not at all while it rests.
/// It is not read by VoiceOver (the orb says the reply is being written, and
/// the reply itself is read), cannot be touched or copied, and gives way to
/// what Claude is doing (ClaudeActivityLine) in the same place.
struct ReplyGlimpseLine: View {
    let glimpse: GlimpseShown
    /// When the orb began to leave.
    let leavingSince: Date?

    /// How far the line's top tucks up into the reply's place, so it stands
    /// where ClaudeActivityLine does, under the orb's light.
    static let tuck: CGFloat = 2
    /// Room above and below the words, so their blur is never cut by the
    /// line's edge fade.
    static let blurRoom: CGFloat = 6

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @ObservedObject private var link = ClaudeLinkStore.shared
    @State private var resting = false
    @State private var yielded = false

    private var reduced: Bool { systemReduceMotion || previewReduceMotion || OrbPace.current == .still }

    var body: some View {
        let reduced = reduced
        // A phrase longer than the line fades out at its end rather than
        // being cut with an ellipsis; one that fits is drawn without the
        // fade, so nothing is laid over it (the first that fits is drawn).
        ViewThatFits(in: .horizontal) {
            words(reduced: reduced)
            words(reduced: reduced)
                .mask {
                    LinearGradient(stops: [.init(color: .black, location: 0), .init(color: .black, location: 0.86),
                                           .init(color: .clear, location: 1)],
                                   startPoint: .leading, endPoint: .trailing)
                }
        }
        .opacity(yielded ? 0 : 1)
        // Large text up to the room under the reply; larger sizes keep this.
        .dynamicTypeSize(...DynamicTypeSize.xxLarge)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        // Moving while it comes and while it goes, still in between.
        .task(id: leavingSince) {
            resting = false
            let motion = reduced
                ? (leavingSince == nil ? ReplyGlimpseMotion.appearReduced : ReplyGlimpseMotion.disappearReduced)
                : (leavingSince == nil ? ReplyGlimpseMotion.appear : ReplyGlimpseMotion.disappear)
            let start = leavingSince ?? glimpse.since
            let left = motion * ReplyGlimpseFilm.scale - Date().timeIntervalSince(start)
            // A frame past the end, so the last one drawn is the end's.
            try? await Task.sleep(for: .seconds(max(left, 0) + 0.1))
            guard !Task.isCancelled else { return }
            resting = true
        }
        .onChange(of: link.working != nil, initial: true) { _, working in
            guard working, !yielded else { return }
            // From a new task, as the orb's fades: changes that come while
            // the conversation streams come with animation turned off.
            Task { @MainActor in
                withAnimation(reduced ? ChatMotion.reducedMenu : ChatMotion.recolor) { yielded = true }
            }
        }
        .onAppear {
            ReplyGlimpseBoard.shared.arrived()
            #if POCKET_PREVIEW
            ReplyGlimpseLog.shared.line(true)
            #endif
        }
        .onDisappear {
            ReplyGlimpseBoard.shared.left()
            #if POCKET_PREVIEW
            ReplyGlimpseLog.shared.line(false)
            #endif
        }
    }

    /// The phrase as it looks now: drawn with the orb's clock while it comes
    /// and goes, not at all while it rests.
    private func words(reduced: Bool) -> some View {
        let ink = Theme.ink.opacity(colorScheme == .dark ? 0.36 : 0.46)
        return TimelineView(.animation(minimumInterval: OrbPace.current.interval, paused: resting)) { context in
            let look = ReplyGlimpseMotion.look(sinceShown: context.date.timeIntervalSince(glimpse.since),
                                               sinceLeaving: leavingSince.map { context.date.timeIntervalSince($0) },
                                               reduced: reduced, timeScale: ReplyGlimpseFilm.scale)
            Text(verbatim: glimpse.text)
                .font(.footnote)
                .lineLimit(1)
                .fixedSize()
                .foregroundStyle(ink)
                .modifier(SoftBlur(radius: look.blur))
                .opacity(look.opacity)
                .offset(y: look.offset)
        }
        .padding(.vertical, Self.blurRoom)
        .padding(.horizontal, ChatMetrics.replyInset)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// A blur only while there is one: none is laid over the words at rest.
private struct SoftBlur: ViewModifier {
    let radius: Double

    @ViewBuilder func body(content: Content) -> some View {
        if radius > 0.01 { content.blur(radius: radius) } else { content }
    }
}
