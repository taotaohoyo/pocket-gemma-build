import SwiftUI
import UIKit
import PhotosUI
import UniformTypeIdentifiers
import ImageIO
import AVFoundation
import PDFKit
import QuickLook
import PocketCore

enum AttachmentStorage {
    static var directory: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma/Attachments", isDirectory: true)
    }
    static func url(_ name: String) -> URL? {
        guard ChatAttachment.isSafeFileName(name) else { return nil }
        return directory.appendingPathComponent(name)
    }
    static func remove(_ attachment: ChatAttachment) {
        for name in Set([attachment.storedName, attachment.textSidecarName] + attachment.imageNames
                        + [attachment.thumbnailName].compactMap { $0 }) {
            if let url = url(name) { try? FileManager.default.removeItem(at: url) }
        }
    }
    /// The most text kept from one file. The model gets what fits a turn
    /// (excerpted), so this bounds memory and work, not what it reads.
    static let fullTextLimit = 512_000
    /// What a draft and older chats show and fall back to: the opening.
    static let openingLimit = 4_000
    static let textExtensions: Set<String> = ["txt", "text", "md", "markdown", "csv", "tsv", "json", "log", "yaml", "yml",
                                              "xml", "html", "htm", "swift", "py", "js", "css", "rtf"]
    static func fullText(_ attachment: ChatAttachment) -> String? {
        guard let url = url(attachment.textSidecarName) else { return nil }
        return try? String(contentsOf: url, encoding: .utf8)
    }
    /// What of each file fits this turn: all of it when it fits, else its
    /// opening and the passages around the question (DocumentExcerpt). A
    /// quarter of the input left (at most 2,000 bytes) stays for the recent
    /// conversation; a chart request's format note counts as input.
    static func excerpted(_ attachments: [ChatAttachment], question: String, settings: GenerationSettings) -> [ChatAttachment] {
        let fixed = question.utf8.count + (RichFormatGuide.guide(for: question)?.utf8.count ?? 0) + attachments.reduce(0) {
            $0 + $1.contextByteCost(visualTokenBudget: settings.visualTokenBudget) - ($1.extractedText?.utf8.count ?? 0) }
        let remaining = settings.inputByteBudget - fixed
        return excerpted(attachments, question: question, byteBudget: remaining - min(max(0, remaining) / 4, 2000))
    }
    static func excerpted(_ attachments: [ChatAttachment], question: String, byteBudget: Int) -> [ChatAttachment] {
        // Files and photos read as text; never an attachment the model sees as an image.
        let files = attachments.indices.filter { attachments[$0].extractedText != nil && attachments[$0].imageNames.isEmpty }
        let texts = files.map { fullText(attachments[$0]) ?? attachments[$0].extractedText ?? "" }
        let shares = DocumentExcerpt.shares(sizes: texts.map(\.utf8.count), budget: byteBudget)
        var result = attachments
        for (position, index) in files.enumerated() {
            let text = texts[position]
            let excerpt = DocumentExcerpt.select(text, question: question, byteBudget: shares[position])
            // Nothing fits: keep the opening, and the input check says so.
            guard !excerpt.text.isEmpty else { continue }
            result[index].extractedText = excerpt.text
            let pending = longFileNote(text.count)
            let earlier = (attachments[index].note ?? "").replacingOccurrences(of: pending, with: "")
                .trimmingCharacters(in: .whitespaces)
            let read = excerpt.isComplete ? nil
                : "全体（\(characterLabel(text.count))）のうち約\(max(1, Int(excerpt.coverage * 100)))%を、質問に関係しそうな部分を中心に読み込みました。"
            let note = [earlier.isEmpty ? nil : earlier, read].compactMap { $0 }.joined(separator: " ")
            result[index].note = note.isEmpty ? nil : note
        }
        return result
    }
    static func longFileNote(_ characters: Int) -> String {
        "長いファイルです（\(characterLabel(characters))）。送信するときに、質問に関係しそうな部分を選んで読み込みます。"
    }
    static func characterLabel(_ count: Int) -> String {
        if count < 1_000 { return "\(count)字" }
        if count < 10_000 { return "約\(count / 100 * 100)字" }
        return "約\(String(format: "%.1f", Double(count) / 10_000))万字"
    }
    static func importFile(_ source: URL, model: ModelSpec? = nil) async throws -> ChatAttachment {
        let policy = model.map(ModelAttachmentPolicy.init)
        if let policy, !policy.allowsAnyAttachment {
            throw ModelAttachmentPolicy.Unavailable(message: policy.guidance)
        }
        let accessed = source.startAccessingSecurityScopedResource()
        defer { if accessed { source.stopAccessingSecurityScopedResource() } }
        let values = try source.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .contentTypeKey])
        guard values.isRegularFile == true else { throw ImportError.unsupported }
        // File-provider URLs may have no extension, or report public.data.
        // ImageIO identifies the encoded bytes, so valid photos still reach
        // normalization instead of the plain-document importer. A file that
        // says it is text stays text: ImageIO also guesses formats without a
        // signature, such as TGA, from arbitrary bytes.
        let declared = values.contentType ?? UTType(filenameExtension: source.pathExtension)
        let imageType: UTType? = declared?.conforms(to: .text) == true ? nil : CGImageSourceCreateWithURL(source as CFURL, nil)
            .flatMap { CGImageSourceGetType($0) }
            .flatMap { UTType($0 as String) }
        let type = imageType ?? declared ?? .data
        let kind: ChatAttachment.Kind = type.conforms(to: .image) ? .image : (type.conforms(to: .movie) ? .video : .file)
        if let policy {
            guard (kind == .image && policy.allowsPhotos) || (kind == .file && policy.allowsDocuments) else {
                throw ModelAttachmentPolicy.Unavailable(message: policy.guidance)
            }
        }
        let size = values.fileSize ?? 0
        guard size > 0, size <= (kind == .video ? 100_000_000 : 20_000_000) else { throw ImportError.tooLarge }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let id = UUID()
        let fileExtension = imageType?.preferredFilenameExtension
            ?? (source.pathExtension.isEmpty ? "data" : source.pathExtension.lowercased())
        let name = id.uuidString + "." + fileExtension
        guard let destination = url(name) else { throw ImportError.unsupported }
        var copyError: NSError?
        var copied: Result<Void, Error>?
        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: source, options: [], error: &copyError) { readable in
            copied = Result { try FileManager.default.copyItem(at: readable, to: destination) }
        }
        if let copyError { throw copyError }
        guard let copied else { throw ImportError.unreadable }
        try copied.get()
        var attachment = ChatAttachment(id: id, kind: kind, name: source.lastPathComponent, storedName: name,
                                        byteCount: Int64(size))
        do {
            switch kind {
            case .image:
                let jpeg = id.uuidString + "-image.jpg"
                guard let sourceImage = CGImageSourceCreateWithURL(destination as CFURL, nil),
                      let image = thumbnail(sourceImage, maxPixels: 768) else { throw ImportError.unreadable }
                try writeJPEG(image, name: jpeg)
                attachment.thumbnailName = jpeg
                if policy?.readsPhotoText == true {
                    // A text-only model gets the text read from the photo on
                    // the device; the image itself never reaches it.
                    guard let page = thumbnail(sourceImage, maxPixels: 2048) else { throw ImportError.unreadable }
                    let text = try DocumentReader.recognizeText(page)
                    guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ImportError.noPhotoText }
                    try keepText(text, in: &attachment,
                                 notes: ["写真に写っている文字だけを端末内で読み取りました。写真の見た目はモデルに渡していません。"])
                } else {
                    attachment.imageNames = [jpeg]
                }
            case .video:
                let asset = AVURLAsset(url: destination)
                let assetDuration = try await asset.load(.duration)
                let duration = assetDuration.seconds
                guard duration.isFinite, duration > 0 else { throw ImportError.unreadable }
                attachment.duration = duration
                let generator = AVAssetImageGenerator(asset: asset)
                generator.appliesPreferredTrackTransform = true
                generator.maximumSize = CGSize(width: 768, height: 768)
                // Three representative scenes keep visual context and memory bounded.
                for (index, seconds) in [0.0, duration / 2, max(0, duration - 0.2)].enumerated() {
                    let result = try await generator.image(at: CMTime(seconds: seconds, preferredTimescale: 600))
                    let jpeg = id.uuidString + "-frame-\(index).jpg"
                    try writeJPEG(result.image, name: jpeg)
                    attachment.imageNames.append(jpeg)
                }
                attachment.thumbnailName = attachment.imageNames.first
                attachment.note = "動画は開始・中間・終了付近の3場面を読み込みます。音声は解析しません。"
            case .file:
                // Only text leaves this step: the model never gets the file's
                // bytes, its images or its embedded objects.
                let text: String
                var notes: [String] = []
                if type.conforms(to: .pdf) {
                    let result = try DocumentReader.pdf(destination, limit: fullTextLimit)
                    text = result.text; notes += [result.note].compactMap { $0 }
                } else if source.pathExtension.lowercased() == "docx" {
                    let result = try DocumentReader.word(destination, limit: fullTextLimit)
                    text = result.text; notes += [result.note].compactMap { $0 }
                } else {
                    guard type.conforms(to: .text) || textExtensions.contains(source.pathExtension.lowercased()) else { throw ImportError.unsupported }
                    let handle = try FileHandle(forReadingFrom: destination)
                    defer { try? handle.close() }
                    let data = try handle.read(upToCount: fullTextLimit) ?? Data()
                    if type.conforms(to: .rtf), let rich = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.rtf], documentAttributes: nil) {
                        text = rich.string
                    } else {
                        guard let value = decodeText(data) else { throw ImportError.unreadable }
                        text = value
                    }
                    if size > fullTextLimit { notes.append("ファイルの先頭\(characterLabel(text.count))までを対象にします。") }
                }
                try keepText(text, in: &attachment, notes: notes)
            }
            try policy?.validateNewAttachments([attachment])
            return attachment
        } catch { remove(attachment); throw error }
    }
    /// The whole text goes next to the attachment; the attachment holds its
    /// opening, and each turn takes what fits (excerpted).
    private static func keepText(_ text: String, in attachment: inout ChatAttachment, notes: [String]) throws {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ImportError.noText }
        guard !DocumentText.looksGarbled(text) else { throw ImportError.garbled }
        let text = GenerationSettings.prefix(text, byteLimit: fullTextLimit)
        guard let sidecar = url(attachment.textSidecarName) else { throw ImportError.unreadable }
        try Data(text.utf8).write(to: sidecar, options: .atomic)
        attachment.extractedText = GenerationSettings.prefix(text, byteLimit: openingLimit)
        let notes = notes + (text.utf8.count > openingLimit ? [longFileNote(text.count)] : [])
        attachment.note = notes.isEmpty ? nil : notes.joined(separator: " ")
    }
    private static func thumbnail(_ source: CGImageSource, maxPixels: Int) -> CGImage? {
        CGImageSourceCreateThumbnailAtIndex(source, 0, [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixels
        ] as CFDictionary)
    }
    private static func writeJPEG(_ image: CGImage, name: String) throws {
        guard let url = url(name), let data = UIImage(cgImage: image).jpegData(compressionQuality: 0.85) else { throw ImportError.unreadable }
        try data.write(to: url, options: .atomic)
    }
    private static func decodeText(_ data: Data) -> String? {
        // A bounded read can end inside the last encoded character. Remove
        // only that incomplete suffix, rather than misdetect the whole file.
        if data.starts(with: [0xff, 0xfe]) || data.starts(with: [0xfe, 0xff]) {
            for trim in [0, 2] where data.count > trim {
                if let text = String(data: data.dropLast(trim), encoding: .utf16) { return text }
            }
            return nil
        }
        for trim in 0...3 where data.count > trim {
            if let text = String(data: data.dropLast(trim), encoding: .utf8) { return text }
        }
        for trim in 0...1 where data.count > trim {
            if let text = String(data: data.dropLast(trim), encoding: .shiftJIS) { return text }
        }
        return nil
    }
    enum ImportError: LocalizedError {
        case unsupported, tooLarge, unreadable, noText, noPhotoText, garbled, locked
        var errorDescription: String? {
            switch self {
            case .unsupported: return "この形式は読み込めません。写真か、\(ModelAttachmentPolicy.documentFormats)のファイルを選んでください。"
            case .tooLarge: return "画像・ファイルは20MB、動画は100MBまで取り込めます。"
            case .unreadable: return "このファイルを読み込めませんでした。別の形式で保存してお試しください。"
            case .noText: return "本文の文字を読み取れませんでした。文字が入ったファイルか、文字が鮮明なPDFでお試しください。"
            case .noPhotoText: return "写真から文字を読み取れませんでした。このモデルは写真の見た目を理解できないため、文字が写った写真を選んでください。写真の内容を見るにはGemma 4 E2Bに切り替えてください。"
            case .garbled: return "文字化けしているため読み込めませんでした。UTF-8のテキストとして保存し直してお試しください。"
            case .locked: return "パスワードで保護されたPDFは読み込めません。保護を外したPDFでお試しください。"
            }
        }
    }
}

struct ChatPhotoPicker: UIViewControllerRepresentable {
    var selectionLimit = 3
    var inline = false
    let onSelect: ([URL]) -> Void
    let onError: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration()
        configuration.selectionLimit = selectionLimit
        configuration.filter = .images
        // UIKit embeds this controller as a child; its grid mode is .default
        // (.inline is a SwiftUI PhotosPickerStyle, not a PHPickerMode).
        configuration.mode = .default
        if inline { configuration.disabledCapabilities = [.collectionNavigation, .search] }
        configuration.selection = .ordered
        let controller = PHPickerViewController(configuration: configuration)
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: PHPickerViewController, context: Context) {}
    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ChatPhotoPicker
        init(_ parent: ChatPhotoPicker) { self.parent = parent }
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            if !parent.inline { picker.dismiss(animated: true) }
            Task { @MainActor in
                var urls: [URL] = []
                for result in results {
                    let provider = result.itemProvider
                    let types = provider.registeredTypeIdentifiers.filter {
                        guard let type = UTType($0) else { return false }
                        return type.conforms(to: .movie) || type.conforms(to: .image)
                    }
                    guard !types.isEmpty else {
                        parent.onError(AttachmentStorage.ImportError.unsupported.localizedDescription)
                        continue
                    }
                    do {
                        urls.append(try await stagedFile(from: provider, typeIdentifiers: types))
                    } catch { parent.onError(error.localizedDescription) }
                }
                parent.onSelect(urls)
            }
        }

        private func stagedFile(from provider: NSItemProvider, typeIdentifiers: [String]) async throws -> URL {
            try await withCheckedThrowingContinuation { continuation in
                func load(_ index: Int, lastError: Error?) {
                    guard index < typeIdentifiers.count else {
                        continuation.resume(throwing: lastError ?? AttachmentStorage.ImportError.unreadable)
                        return
                    }
                    let type = typeIdentifiers[index]
                    provider.loadFileRepresentation(forTypeIdentifier: type) { url, error in
                        do {
                            guard let url else { throw error ?? AttachmentStorage.ImportError.unreadable }
                            // Provider URLs expire when this callback returns; stage a copy now.
                            let fileExtension = url.pathExtension.isEmpty
                                ? (UTType(type)?.preferredFilenameExtension ?? "data")
                                : url.pathExtension
                            let staged = FileManager.default.temporaryDirectory
                                .appendingPathComponent(UUID().uuidString)
                                .appendingPathExtension(fileExtension)
                            try FileManager.default.copyItem(at: url, to: staged)
                            continuation.resume(returning: staged)
                        } catch {
                            // Providers sometimes advertise a generic UTI before
                            // the concrete HEIC/JPEG/MOV file representation.
                            load(index + 1, lastError: error)
                        }
                    }
                }
                load(0, lastError: nil)
            }
        }
    }
}

struct AttachmentCard: View {
    let attachment: ChatAttachment
    var compact = false
    @State private var image: UIImage?
    @State private var showPreview = false
    var body: some View {
        Button { showPreview = true } label: {
            if SentPhoto.shows(attachment) && !compact {
                SentPhoto(attachment: attachment, image: image)
            } else {
                VStack(alignment: .leading, spacing: 5) {
                    if attachment.thumbnailName != nil {
                        ZStack {
                            Color.secondary.opacity(0.08)
                            if let image { Image(uiImage: image).resizable().scaledToFit() }
                            else { Image(systemName: "photo").foregroundStyle(.secondary) }
                        }
                            // Reserve thumbnail bounds before asynchronous IO.
                            // Loading it must not change the row's measured height.
                            .frame(width: compact ? 64 : 200, height: compact ? 64 : 180)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay { if attachment.kind == .video { Image(systemName: "play.circle.fill").font(.title).foregroundStyle(.white).shadow(radius: 3) } }
                    }
                    if !compact || attachment.thumbnailName == nil { Label(attachment.name, systemImage: attachment.kind == .image ? "photo" : (attachment.kind == .video ? "video" : "doc.text"))
                        .font(.caption).lineLimit(1)
                        .frame(width: compact ? 130 : 200, alignment: .leading)
                        .frame(minHeight: compact ? 64 : 0)
                    }
                    if let note = attachment.note, !compact { Text(note).font(.caption2).fixedSize(horizontal: false, vertical: true).frame(maxWidth: 220) }
                }
                .background(compact ? Color.secondary.opacity(0.06) : .clear, in: RoundedRectangle(cornerRadius: 12))
                .padding(compact ? 0 : 6)
                .contentShape(Rectangle())
            }
        }
        .buttonStyle(.plain).accessibilityLabel("添付ファイルを開く: \(attachment.name)")
        .sheet(isPresented: $showPreview) {
            NavigationStack {
                AttachmentPreview(attachment: attachment).ignoresSafeArea(edges: .bottom)
                    .navigationTitle(attachment.name).navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { showPreview = false } } }
            }
        }
        .task(id: attachment.id) {
            guard let name = attachment.thumbnailName, let url = AttachmentStorage.url(name) else { return }
            let loaded = await Task.detached(priority: .utility) { UIImage(contentsOfFile: url.path) }.value
            if !Task.isCancelled { image = loaded }
        }
    }
}

/// A sent photo in the conversation, on its own: no bubble behind it, at
/// its own shape with the bubbles' rounded corners, as in iMessage
/// (2026-10-25). Its size comes from the saved image's header before the
/// image itself is read, so the row is measured once at its final height.
/// Videos and files stay in the message's bubble with their names.
struct SentPhoto: View {
    let attachment: ChatAttachment
    let image: UIImage?
    static let maxWidth: CGFloat = 220
    static let maxHeight: CGFloat = 260
    /// A long panorama or strip is cut to this, not drawn as a sliver.
    static let minSide: CGFloat = 72

    nonisolated static func shows(_ attachment: ChatAttachment) -> Bool {
        attachment.kind == .image && attachment.thumbnailName != nil
    }

    var body: some View {
        let size = Self.size(for: attachment.thumbnailName)
        VStack(alignment: .trailing, spacing: 4) {
            ZStack {
                Color.secondary.opacity(0.08)
                if let image { Image(uiImage: image).resizable().scaledToFill() }
                else { Image(systemName: "photo").foregroundStyle(.secondary) }
            }
            .frame(width: size.width, height: size.height)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            // A text-only model's note on what was read from the photo.
            if let note = attachment.note {
                Text(note).font(.caption2).foregroundStyle(.secondary)
                    .multilineTextAlignment(.trailing)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: Self.maxWidth, alignment: .trailing)
            }
        }
    }

    /// The photo's box: its own aspect within maxWidth by maxHeight. Read
    /// once per image from its header (no pixels) and kept.
    @MainActor static func size(for name: String?) -> CGSize {
        let square = CGSize(width: 200, height: 200)
        guard let name else { return square }
        if let known = sizes[name] { return known }
        guard let url = AttachmentStorage.url(name),
              let source = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary),
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
              let width = (properties[kCGImagePropertyPixelWidth] as? NSNumber)?.doubleValue,
              let height = (properties[kCGImagePropertyPixelHeight] as? NSNumber)?.doubleValue,
              width > 0, height > 0 else { return square }
        // The saved image is upright (written with its orientation applied).
        let scale = min(maxWidth / width, maxHeight / height)
        let box = CGSize(width: max(minSide, (width * scale).rounded()), height: max(minSide, (height * scale).rounded()))
        sizes[name] = box
        return box
    }
    @MainActor private static var sizes: [String: CGSize] = [:]
}

struct AttachmentPreview: UIViewControllerRepresentable {
    let attachment: ChatAttachment
    func makeCoordinator() -> Coordinator { Coordinator(attachment) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController(); controller.dataSource = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}
    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let attachment: ChatAttachment
        init(_ attachment: ChatAttachment) { self.attachment = attachment }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { AttachmentStorage.url(attachment.storedName) == nil ? 0 : 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            AttachmentStorage.url(attachment.storedName)! as NSURL
        }
    }
}

/// A photo from the inline PhotosPicker, staged to a temporary file because
/// the provider's URL is only valid inside the transfer callback.
struct PickedImageFile: Transferable {
    let url: URL
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .image) { received in
            let ext = received.file.pathExtension.isEmpty ? "jpg" : received.file.pathExtension
            let staged = FileManager.default.temporaryDirectory
                .appendingPathComponent("picked-\(UUID().uuidString).\(ext)")
            try FileManager.default.copyItem(at: received.file, to: staged)
            return PickedImageFile(url: staged)
        }
    }
}
