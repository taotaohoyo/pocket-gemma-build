import SwiftUI
import PocketCore

/// The Aurora Orb's row following the reply's text down, and the
/// conversation following both (1.1.0 (303), the user's directive of
/// 2026-11-20 「回答生成中の移動アニメーション改善」).
///
/// What 302 did, as the user's recording showed it frame by frame: the
/// text's view grew the moment its next line was laid out and pushed the
/// orb's row down under it in the same frame; the row's own 0.24 s spring
/// (ReplyLight.rowGlide) then eased it, fastest at its start, two thirds of
/// the first line's 34pt in two frames; the new line's first characters
/// were drawn over the orb a frame or two before it moved; and in a chat
/// taller than the page the scroll caught up 16 ms later
/// (ChatView.scheduleBottom), so at each line the orb sank for a frame and
/// the whole conversation jumped up a line.
///
/// Now the reply's row keeps the room under which the orb sits itself
/// (ReplyRoom): the text is laid out at once, as before, but the room
/// follows it along ReplyGlide's curve, and where the conversation follows
/// the reply the scroll view keeps its end in place as the room grows
/// (its size-change anchor, ChatScrollAnchoring), so the orb stays still
/// on the page while the text rises. Below the room's edge the text is not
/// drawn (ReplyTextClip): a new line shows as the orb makes room for it,
/// never over the orb or the point beside it.
@MainActor final class ReplyFollow {
    #if POCKET_PREVIEW
    /// UI checks only (`--probe-orb-302-motion`): 302's motion, to compare.
    nonisolated static let motion302 = PreviewProbe.on("--probe-orb-302-motion")
    /// UI checks only (`--probe-glide-noclip`): the text not cut at the
    /// room's edge, to tell what the cut costs as the first text is drawn.
    nonisolated static let unclipped = PreviewProbe.on("--probe-glide-noclip")
    #else
    nonisolated static let motion302 = false
    nonisolated static let unclipped = false
    #endif

    /// ChatView's: whether the conversation follows the reply (the person
    /// is at its end and not scrolling). Then the scroll view's size-change
    /// anchor keeps the end in place as the room grows (ChatScrollAnchoring).
    var follows: () -> Bool = { false }
    /// Until when (reference-date seconds) the row is moving: other
    /// follows of the conversation's end wait until then (and a little
    /// more), so that no scroll is asked for while the room changes
    /// (ChatView.scheduleBottom).
    private(set) var movingUntil: TimeInterval = 0
    private var lastStart: TimeInterval?

    /// The room under the reply's text grows (or shrinks) by `change`:
    /// `apply` sets it along the curve. Where the conversation follows the
    /// reply, nothing here scrolls it: the scroll view's anchor keeps its
    /// end in place as its content grows, frame by frame, so the orb stays
    /// still on the page and the text rises. A scroll to the end asked for
    /// in the same update held the app (runs 903, 904); one asked for after
    /// it found the end where it was then and lagged the curve (905).
    func move(by change: CGFloat, reduceMotion: Bool, _ apply: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        guard !reduceMotion else {
            // Reduce Motion: in place at once, the end kept with it in the
            // same frame (302 left it 16 ms behind, after a frame drawn).
            movingUntil = max(movingUntil, now)
            var transaction = Transaction()
            transaction.disablesAnimations = true
            withTransaction(transaction) { apply() }
            #if POCKET_PREVIEW
            GlideTrace.shared.moved(by: change, duration: 0, follows: follows())
            #endif
            return
        }
        let duration = ReplyGlide.duration(distance: Double(change), since: lastStart.map { now - $0 })
        lastStart = now
        movingUntil = max(movingUntil, now + duration)
        withAnimation(ReplyGlide.animation(duration: duration)) { apply() }
        #if POCKET_PREVIEW
        GlideTrace.shared.moved(by: change, duration: duration, follows: follows())
        #endif
    }
}

/// How a reply's room follows its text (ReplyRoom), kept apart from what
/// is drawn: the view's own state changes only when the room moves, so
/// measuring the text never makes the view again by itself.
@MainActor final class ReplyRoomKeeper {
    var room: ReplyRoom
    /// A look at a shorter text is due.
    var looking = false
    init(_ room: ReplyRoom) { self.room = room }
}

extension ReplyGlide {
    /// The curve as a SwiftUI animation over `duration`.
    static func animation(duration: TimeInterval) -> Animation {
        .timingCurve(curve.x1, curve.y1, curve.x2, curve.y2, duration: duration)
    }
}

extension EnvironmentValues {
    /// The conversation's ReplyFollow, for the reply being written.
    @Entry var replyFollow: ReplyFollow? = nil
}

/// What of a reply's text is drawn: down to `limit` below its top (the
/// room the orb's row keeps, and `ReplyLight.textClear` more), wide to the
/// sides and above for the writing light; all of it when `limit` is nil.
/// The limit moves with the room, in the room's transaction, so the edge
/// stays just above the orb wherever it is drawn.
struct ReplyTextClip: Shape {
    var limit: CGFloat?
    private static let open: CGFloat = 100_000

    var animatableData: CGFloat {
        get { limit ?? Self.open }
        set { limit = newValue }
    }

    func path(in rect: CGRect) -> Path {
        let side: CGFloat = 400
        // Never past the text's own bounds and the light's margin, also
        // while the limit opens up at the end (it goes to `open`): the cut
        // stays as small as the text it holds.
        let whole = rect.maxY + side
        let bottom = min(limit.map { rect.minY + $0 } ?? whole, whole)
        return Path(CGRect(x: rect.minX - side, y: rect.minY - side, width: rect.width + 2 * side,
                           height: max(bottom - (rect.minY - side), 0)))
    }
}

/// Where the reply's text ends while the orb's row makes room for it
/// (1.1.0 (304)): its characters and their writing light fade out over the
/// last `band` points above the room's edge (ReplyTextClip's limit) and
/// are not drawn beyond it, so nothing of the text reaches the orb or the
/// point beside it, as in 303, and the edge is never a straight line.
///
/// What 303 did (its CI frames, the user's recording of 2026-11-20): a new
/// line is laid out at once and its first characters start at once, while
/// the room reaches it along ReplyGlide's curve (0.30 to 0.48 s); until it
/// had, ReplyTextClip cut the line where the room's edge was, in a straight
/// line through its characters and their writing light, just above the
/// orb (a paragraph's first line, 16pt lower, came out from the top down).
/// The cut is the room's edge itself: it stays where it was, now drawn by
/// the text as it draws its characters (ReplyAppearanceRenderer), eased
/// with the room in the same transaction. ReplyTextClip still cuts what is
/// not text there (a list's markers wait for the edge, ReplyEdgeGate; a
/// code block's or a table's box is cut as in 303).
enum ReplyTextEdge {
    /// The reply's text (its blocks and lines) as the row lays it out.
    static let space = "reply-text"
    /// How far above the edge a line begins to fade (points): at rest the
    /// text's last line ends 15pt above the edge, 7pt above the fade.
    static let band: CGFloat = 8
    /// No edge, for the renderer's eased value.
    static let open: CGFloat = 100_000

    enum Place { case above, across, below }

    /// Where a line (its typographic bounds) is from the edge; a character
    /// rises into place from `ReplyRevealStyle.rise` lower.
    static func place(of line: CGRect, edge: CGFloat) -> Place {
        if line.minY >= edge { return .below }
        if line.maxY + ReplyRevealStyle.rise <= edge - band { return .above }
        return .across
    }

    /// A copy of `context` that draws through the edge's fade, for the
    /// lines across it; nil when none is.
    static func fading(_ context: GraphicsContext, layout: Text.Layout, edge: CGFloat) -> GraphicsContext? {
        var across = CGRect.null
        for line in layout {
            let bounds = line.typographicBounds.rect
            if place(of: bounds, edge: edge) == .across { across = across.union(bounds) }
        }
        guard !across.isNull else { return nil }
        var faded = context
        fade(&faded, across: across.insetBy(dx: -ReplyWritingLight.room, dy: -4), edge: edge)
        return faded
    }

    /// Draws what follows in `context` within `area` fully down to `band`
    /// above the edge, fading over the band (a smoothstep, in five stops),
    /// and nothing beyond the edge.
    static func fade(_ context: inout GraphicsContext, across area: CGRect, edge: CGFloat) {
        let start = edge - band
        let top = min(area.minY, start)
        let kept = CGRect(x: area.minX, y: top, width: area.width, height: max(edge - top, 0))
        context.clip(to: Path(kept))
        context.clipToLayer { mask in
            mask.fill(Path(CGRect(x: kept.minX, y: top, width: kept.width, height: max(start - top, 0))), with: .color(.white))
            mask.fill(Path(CGRect(x: kept.minX, y: start, width: kept.width, height: band)),
                      with: .linearGradient(Gradient(stops: stops), startPoint: CGPoint(x: 0, y: start),
                                            endPoint: CGPoint(x: 0, y: edge)))
        }
    }

    private static let stops: [Gradient.Stop] = {
        let places: [Double] = [0, 0.25, 0.5, 0.75, 1]
        return places.map { (at: Double) -> Gradient.Stop in
            let left = 1 - at
            return Gradient.Stop(color: Color.white.opacity(left * left * (3 - 2 * left)), location: CGFloat(at))
        }
    }()
}

extension EnvironmentValues {
    /// The room's edge in the reply's text (ReplyTextEdge.space), while the
    /// row cuts it there; nil elsewhere.
    @Entry var replyTextEdge: CGFloat? = nil
}

/// A list's marker (its number, bullet or box) where the room's edge cuts
/// the reply (1.1.0 (304)): drawn once the edge has passed below it, coming
/// in as the edge clears it, never cut (ReplyTextEdge).
struct ReplyEdgeGate: ViewModifier {
    @Environment(\.replyTextEdge) private var edge
    @State private var bottom: CGFloat?

    func body(content: Content) -> some View {
        #if POCKET_PREVIEW
        let _ = GlideTrace.shared.drew(.gate)
        #endif
        content
            .modifier(ReplyEdgeOpacity(edge: edge ?? ReplyTextEdge.open, bottom: edge == nil ? nil : bottom))
            .onGeometryChange(for: CGFloat?.self) { proxy in
                edge == nil ? nil : proxy.frame(in: .named(ReplyTextEdge.space)).maxY
            } action: { measured in
                if bottom != measured { bottom = measured }
            }
    }
}

/// The marker's opacity from where the edge is, eased with the room.
private struct ReplyEdgeOpacity: ViewModifier, Animatable {
    var edge: CGFloat
    let bottom: CGFloat?

    var animatableData: CGFloat {
        get { edge }
        set { edge = newValue }
    }

    func body(content: Content) -> some View {
        content.opacity(shown)
    }

    private var shown: Double {
        guard let bottom else { return 1 }
        let way = min(max((edge - bottom) / ReplyTextEdge.band, 0), 1)
        return Double(way * way * (3 - 2 * way))
    }
}

/// The reply's text cut at `limit` (ReplyTextClip), only in a row made for
/// a reply being written (`active`, fixed for the row's life).
struct ReplyTextCut: ViewModifier {
    let active: Bool
    let limit: CGFloat?

    @ViewBuilder func body(content: Content) -> some View {
        if active {
            content.clipShape(ReplyTextClip(limit: limit))
        } else {
            content
        }
    }
}

/// The reply's text laid out in the room the orb's row keeps for it
/// (`height`, nil: the text's own): the text keeps its own height and
/// overflows a shorter room downwards, where ReplyTextClip hides it.
struct ReplyRoomFrame: ViewModifier {
    let height: CGFloat?

    func body(content: Content) -> some View {
        // Eased by the room's transaction: the conversation's content size
        // follows it frame by frame, as the scroll view's anchor needs (a
        // layout at each frame of the motion changed nothing, run 907).
        content.frame(height: height, alignment: .top)
    }
}

/// 302's row motion (`--probe-orb-302-motion`): the row eased by
/// ReplyLight.rowGlide as the text is laid out, in a chat that fits.
struct ReplyRowMotion302: ViewModifier {
    let glides: Bool
    let shown: Int

    @ViewBuilder func body(content: Content) -> some View {
        if ReplyFollow.motion302 {
            content.animation(glides ? ReplyLight.rowGlide : nil, value: shown)
        } else {
            content
        }
    }
}
