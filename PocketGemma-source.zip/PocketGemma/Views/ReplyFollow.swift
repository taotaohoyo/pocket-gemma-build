import SwiftUI
import PocketCore

/// The Aurora Orb's row following the reply's text down, and the
/// conversation following both (1.1.0 (303), the user's directive of
/// 2026-11-20 「回答生成中の移動アニメーション改善」).
///
/// What 302 did, as the user's recording showed it frame by frame: the
/// text's view grew the moment its next line was laid out and pushed the
/// orb's row down under it in the same frame; the row's own 0.24 s spring
/// (ReplyLight.rowGlide) then eased it, fastest at its start, two thirds of
/// the first line's 34pt in two frames; the new line's first characters
/// were drawn over the orb a frame or two before it moved; and in a chat
/// taller than the page the scroll caught up 16 ms later
/// (ChatView.scheduleBottom), so at each line the orb sank for a frame and
/// the whole conversation jumped up a line.
///
/// Now the reply's row keeps the room under which the orb sits itself
/// (ReplyRoom): the text is laid out at once, as before, but the room
/// follows it along ReplyGlide's curve, and where the conversation follows
/// the reply the scroll view keeps its end in place as the room grows
/// (its size-change anchor, ChatScrollAnchoring), so the orb stays still
/// on the page while the text rises. Below the room's edge the text is not
/// drawn (ReplyTextClip): a new line shows as the orb makes room for it,
/// never over the orb or the point beside it.
@MainActor final class ReplyFollow {
    #if POCKET_PREVIEW
    /// UI checks only (`--probe-orb-302-motion`): 302's motion, to compare.
    nonisolated static let motion302 = PreviewProbe.on("--probe-orb-302-motion")
    #else
    nonisolated static let motion302 = false
    #endif

    /// ChatView's: whether the conversation follows the reply (the person
    /// is at its end and not scrolling). Then the scroll view's size-change
    /// anchor keeps the end in place as the room grows (ChatScrollAnchoring).
    var follows: () -> Bool = { false }
    /// Until when (reference-date seconds) the row is moving: other
    /// follows of the conversation's end wait until then (and a little
    /// more), so that no scroll is asked for while the room changes
    /// (ChatView.scheduleBottom).
    private(set) var movingUntil: TimeInterval = 0
    private var lastStart: TimeInterval?

    /// The room under the reply's text grows (or shrinks) by `change`:
    /// `apply` sets it along the curve. Where the conversation follows the
    /// reply, nothing here scrolls it: the scroll view's anchor keeps its
    /// end in place as its content grows, frame by frame, so the orb stays
    /// still on the page and the text rises. A scroll to the end asked for
    /// in the same update held the app (runs 903, 904); one asked for after
    /// it found the end where it was then and lagged the curve (905).
    func move(by change: CGFloat, reduceMotion: Bool, _ apply: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        guard !reduceMotion else {
            // Reduce Motion: in place at once, the end kept with it in the
            // same frame (302 left it 16 ms behind, after a frame drawn).
            movingUntil = max(movingUntil, now)
            var transaction = Transaction()
            transaction.disablesAnimations = true
            withTransaction(transaction) { apply() }
            #if POCKET_PREVIEW
            GlideTrace.shared.moved(by: change, duration: 0, follows: follows())
            #endif
            return
        }
        let duration = ReplyGlide.duration(distance: Double(change), since: lastStart.map { now - $0 })
        lastStart = now
        movingUntil = max(movingUntil, now + duration)
        withAnimation(ReplyGlide.animation(duration: duration)) { apply() }
        #if POCKET_PREVIEW
        GlideTrace.shared.moved(by: change, duration: duration, follows: follows())
        #endif
    }
}

/// How a reply's room follows its text (ReplyRoom), kept apart from what
/// is drawn: the view's own state changes only when the room moves, so
/// measuring the text never makes the view again by itself.
@MainActor final class ReplyRoomKeeper {
    var room: ReplyRoom
    /// A look at a shorter text is due.
    var looking = false
    init(_ room: ReplyRoom) { self.room = room }
}

extension ReplyGlide {
    /// The curve as a SwiftUI animation over `duration`.
    static func animation(duration: TimeInterval) -> Animation {
        .timingCurve(curve.x1, curve.y1, curve.x2, curve.y2, duration: duration)
    }
}

extension EnvironmentValues {
    /// The conversation's ReplyFollow, for the reply being written.
    @Entry var replyFollow: ReplyFollow? = nil
}

/// What of a reply's text is drawn: down to `limit` below its top (the
/// room the orb's row keeps, and `ReplyLight.textClear` more), wide to the
/// sides and above for the writing light; all of it when `limit` is nil.
/// The limit moves with the room, in the room's transaction, so the edge
/// stays just above the orb wherever it is drawn.
struct ReplyTextClip: Shape {
    var limit: CGFloat?
    private static let open: CGFloat = 100_000

    var animatableData: CGFloat {
        get { limit ?? Self.open }
        set { limit = newValue }
    }

    func path(in rect: CGRect) -> Path {
        let side: CGFloat = 400
        let bottom = limit.map { rect.minY + $0 } ?? rect.maxY + Self.open
        return Path(CGRect(x: rect.minX - side, y: rect.minY - side, width: rect.width + 2 * side,
                           height: max(bottom - (rect.minY - side), 0)))
    }
}

/// The reply's text laid out in the room the orb's row keeps for it
/// (`height`, nil: the text's own): the text keeps its own height and
/// overflows a shorter room downwards, where ReplyTextClip hides it.
struct ReplyRoomFrame: ViewModifier {
    let height: CGFloat?

    func body(content: Content) -> some View {
        // Eased by the room's transaction: the conversation's content size
        // follows it frame by frame, as the scroll view's anchor needs (a
        // layout at each frame of the motion changed nothing, run 907).
        content.frame(height: height, alignment: .top)
    }
}

/// 302's row motion (`--probe-orb-302-motion`): the row eased by
/// ReplyLight.rowGlide as the text is laid out, in a chat that fits.
struct ReplyRowMotion302: ViewModifier {
    let glides: Bool
    let shown: Int

    @ViewBuilder func body(content: Content) -> some View {
        if ReplyFollow.motion302 {
            content.animation(glides ? ReplyLight.rowGlide : nil, value: shown)
        } else {
            content
        }
    }
}
