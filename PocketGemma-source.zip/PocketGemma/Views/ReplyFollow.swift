import SwiftUI
import PocketCore

/// The Aurora Orb's row following the reply's text down, and the
/// conversation following both (1.1.0 (303), the user's directive of
/// 2026-11-20 「回答生成中の移動アニメーション改善」).
///
/// What 302 did, as the user's recording showed it frame by frame: the
/// text's view grew the moment its next line was laid out and pushed the
/// orb's row down under it in the same frame; the row's own 0.24 s spring
/// (ReplyLight.rowGlide) then eased it, fastest at its start, two thirds of
/// the first line's 34pt in two frames; the new line's first characters
/// were drawn over the orb a frame or two before it moved; and in a chat
/// taller than the page the scroll caught up 16 ms later
/// (ChatView.scheduleBottom), so at each line the orb sank for a frame and
/// the whole conversation jumped up a line.
///
/// Now the reply's row keeps the room under which the orb sits itself
/// (ReplyRoom): the text is laid out at once, as before, but the room
/// follows it along ReplyGlide's curve, and where the conversation follows
/// the reply it scrolls to its end along the same curve, begun as soon as
/// the scroll view has the new height (a frame at most after the room, at
/// the curve's quiet start), so the orb stays still on the page while the
/// text rises. Below the room's edge the text is not drawn (ReplyTextClip): a
/// new line shows as the orb makes room for it, never over the orb or the
/// point beside it.
@MainActor final class ReplyFollow {
    #if POCKET_PREVIEW
    /// UI checks only (`--probe-orb-302-motion`): 302's motion, to compare.
    nonisolated static let motion302 = PreviewProbe.on("--probe-orb-302-motion")
    /// UI checks only (`--probe-glide-anchor`): the room's height laid out
    /// frame by frame, the conversation kept at its end by the scroll
    /// view's own anchor rather than scrolled along.
    nonisolated static let anchored = PreviewProbe.on("--probe-glide-anchor")
    /// UI checks only: the first candidate's ways, each alone, to find what
    /// held the app (run 903): the room moved inside the layout that
    /// measured the text (`--probe-glide-sync`), the conversation scrolled
    /// at each line even where it fits (`--probe-glide-scroll-fits`), the
    /// text not cut at the room's edge (`--probe-glide-noclip`).
    nonisolated static let synchronous = PreviewProbe.on("--probe-glide-sync")
    nonisolated static let scrollsWhenFits = PreviewProbe.on("--probe-glide-scroll-fits")
    nonisolated static let unclipped = PreviewProbe.on("--probe-glide-noclip")
    /// (`--probe-glide-noframe`: the room only cuts the text; the row sits
    /// under the text's own height, as in 302, with no motion.)
    nonisolated static let unframed = PreviewProbe.on("--probe-glide-noframe")
    #else
    nonisolated static let motion302 = false
    nonisolated static let anchored = false
    nonisolated static let synchronous = false
    nonisolated static let scrollsWhenFits = false
    nonisolated static let unclipped = false
    nonisolated static let unframed = false
    #endif

    /// ChatView's: scrolls the conversation to its end, in the transaction
    /// it is called in (never the one that changes the room).
    var scrollToEnd: () -> Void = {}
    /// ChatView's: whether the conversation follows the reply (the person
    /// is at its end and not scrolling).
    var follows: () -> Bool = { false }
    /// How much taller the conversation can grow before it no longer fits
    /// where it is read (points; below zero, it already scrolls), from
    /// ChatView's scroll geometry. Where the reply's growth still fits,
    /// nothing scrolls: the row goes down the page.
    var spare: CGFloat = 0
    /// Until when (reference-date seconds) the row is moving: other
    /// follows of the conversation's end wait until then, or they would
    /// stop the scroll short (ChatView.scheduleBottom).
    private(set) var movingUntil: TimeInterval = 0
    private var lastStart: TimeInterval?

    /// The conversation's scroll the room's last move owes it: the
    /// animation it scrolls along (none under Reduce Motion), and when the
    /// room began to move.
    private var owed: (animation: Animation?, duration: TimeInterval, at: TimeInterval)?

    /// The room under the reply's text grows (or shrinks) by `change`:
    /// `apply` sets it along the curve, and the conversation, where it
    /// follows the reply, scrolls to its end along the same curve once the
    /// scroll view has the new height (contentLaidOut).
    ///
    /// Not in the same transaction: a scroll to the end asked for in the
    /// update that changes the content's size held the app (run 904, 100%
    /// of the main thread, animated or not, with or without the clip),
    /// where the same scroll from a later turn of the main queue, as 302's
    /// ChatView.scheduleBottom did, never has.
    func move(by change: CGFloat, reduceMotion: Bool, _ apply: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        let following = follows() && !Self.anchored && (change > spare - 1 || Self.scrollsWhenFits)
        guard !reduceMotion else {
            // Reduce Motion: in place at once, the conversation with it
            // (302 left it 16 ms behind, after a frame drawn).
            var transaction = Transaction()
            transaction.disablesAnimations = true
            withTransaction(transaction) { apply() }
            if following { owe(nil, duration: 0, at: now) }
            #if POCKET_PREVIEW
            GlideTrace.shared.moved(by: change, duration: 0, follows: following)
            #endif
            return
        }
        let duration = ReplyGlide.duration(distance: Double(change), since: lastStart.map { now - $0 })
        lastStart = now
        movingUntil = max(movingUntil, now + duration)
        let animation = ReplyGlide.animation(duration: duration)
        withAnimation(animation) { apply() }
        if following { owe(animation, duration: duration, at: now) }
        #if POCKET_PREVIEW
        GlideTrace.shared.moved(by: change, duration: duration, follows: following)
        #endif
    }

    private func owe(_ animation: Animation?, duration: TimeInterval, at now: TimeInterval) {
        owed = (animation, duration, now)
        // Should the scroll view not lay out again (nothing in its content
        // changed after all), the scroll still comes, a frame or so late.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.034) { [weak self] in self?.contentLaidOut() }
    }

    /// ChatView's scroll geometry changed (after the room's move, its
    /// content's new height): the scroll the move owes starts in the next
    /// turn of the main queue, outside the update that changed the size,
    /// along the same curve, so that it ends with the room's move. Started
    /// a frame later at the curve's quiet start (3% of the way at 33 ms),
    /// the orb is never more than a few tenths of a point off its place
    /// at first.
    func contentLaidOut() {
        guard let owed else { return }
        self.owed = nil
        DispatchQueue.main.async { [self] in
            guard follows() else { return }
            let left = owed.duration - (Date().timeIntervalSinceReferenceDate - owed.at)
            if owed.animation != nil, left > 0.08 {
                // The same curve over what is left of the room's move: it
                // ends with it (the curve's tail, where both are slow).
                withAnimation(ReplyGlide.animation(duration: left)) { scrollToEnd() }
            } else {
                var transaction = Transaction()
                transaction.disablesAnimations = true
                withTransaction(transaction) { scrollToEnd() }
            }
            #if POCKET_PREVIEW
            GlideTrace.shared.scrolled(late: Date().timeIntervalSinceReferenceDate - owed.at)
            #endif
        }
    }
}

/// How a reply's room follows its text (ReplyRoom), kept apart from what
/// is drawn: the view's own state changes only when the room moves, so
/// measuring the text never makes the view again by itself.
@MainActor final class ReplyRoomKeeper {
    var room: ReplyRoom
    /// A look at a shorter text is due.
    var looking = false
    init(_ room: ReplyRoom) { self.room = room }
}

extension ReplyGlide {
    /// The curve as a SwiftUI animation over `duration`.
    static func animation(duration: TimeInterval) -> Animation {
        .timingCurve(curve.x1, curve.y1, curve.x2, curve.y2, duration: duration)
    }
}

extension EnvironmentValues {
    /// The conversation's ReplyFollow, for the reply being written.
    @Entry var replyFollow: ReplyFollow? = nil
}

/// What of a reply's text is drawn: down to `limit` below its top (the
/// room the orb's row keeps, and `ReplyLight.textClear` more), wide to the
/// sides and above for the writing light; all of it when `limit` is nil.
/// The limit moves with the room, in the room's transaction, so the edge
/// stays just above the orb wherever it is drawn.
struct ReplyTextClip: Shape {
    var limit: CGFloat?
    private static let open: CGFloat = 100_000

    var animatableData: CGFloat {
        get { limit ?? Self.open }
        set { limit = newValue }
    }

    func path(in rect: CGRect) -> Path {
        let side: CGFloat = 400
        let bottom = limit.map { rect.minY + $0 } ?? rect.maxY + Self.open
        return Path(CGRect(x: rect.minX - side, y: rect.minY - side, width: rect.width + 2 * side,
                           height: max(bottom - (rect.minY - side), 0)))
    }
}

/// The reply's text laid out in the room the orb's row keeps for it
/// (`height`, nil: the text's own): the text keeps its own height and
/// overflows a shorter room downwards, where ReplyTextClip hides it.
struct ReplyRoomFrame: ViewModifier {
    let height: CGFloat?

    @ViewBuilder func body(content: Content) -> some View {
        if ReplyFollow.anchored {
            content.modifier(ReplyRoomLayout(height: height ?? 0, active: height != nil))
        } else if ReplyFollow.unframed {
            content
        } else {
            content.frame(height: height, alignment: .top)
        }
    }
}

/// `--probe-glide-anchor`: the room's height laid out again at each frame
/// of its motion (the conversation's size with it, which the scroll view's
/// anchor follows), rather than drawn there.
private struct ReplyRoomLayout: ViewModifier, Animatable {
    var height: CGFloat
    let active: Bool
    var animatableData: CGFloat {
        get { height }
        set { height = newValue }
    }

    func body(content: Content) -> some View {
        content.frame(height: active ? height : nil, alignment: .top)
    }
}

/// 302's row motion (`--probe-orb-302-motion`): the row eased by
/// ReplyLight.rowGlide as the text is laid out, in a chat that fits.
struct ReplyRowMotion302: ViewModifier {
    let glides: Bool
    let shown: Int

    @ViewBuilder func body(content: Content) -> some View {
        if ReplyFollow.motion302 {
            content.animation(glides ? ReplyLight.rowGlide : nil, value: shown)
        } else {
            content
        }
    }
}
