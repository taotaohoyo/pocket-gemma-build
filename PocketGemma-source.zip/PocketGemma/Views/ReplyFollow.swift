import SwiftUI
import PocketCore

/// The Aurora Orb's row following the reply's text down, and the
/// conversation following both (1.1.0 (303), the user's directive of
/// 2026-11-20 「回答生成中の移動アニメーション改善」).
///
/// What 302 did, as the user's recording showed it frame by frame: the
/// text's view grew the moment its next line was laid out and pushed the
/// orb's row down under it in the same frame; the row's own 0.24 s spring
/// (ReplyLight.rowGlide) then eased it, fastest at its start, two thirds of
/// the first line's 34pt in two frames; the new line's first characters
/// were drawn over the orb a frame or two before it moved; and in a chat
/// taller than the page the scroll caught up 16 ms later
/// (ChatView.scheduleBottom), so at each line the orb sank for a frame and
/// the whole conversation jumped up a line.
///
/// Now the reply's row keeps the room under which the orb sits itself
/// (ReplyRoom): the text is laid out at once, as before, but the room
/// follows it in one transaction this class makes, along ReplyGlide's
/// curve, and the conversation scrolls to its end in that same transaction
/// along the same curve, so the orb stays still on the page while the text
/// rises. Below the room's edge the text is not drawn (ReplyTextClip): a
/// new line shows as the orb makes room for it, never over the orb or the
/// point beside it.
@MainActor final class ReplyFollow {
    #if POCKET_PREVIEW
    /// UI checks only (`--probe-orb-302-motion`): 302's motion, to compare.
    nonisolated static let motion302 = PreviewProbe.on("--probe-orb-302-motion")
    /// UI checks only (`--probe-glide-anchor`): the room's height laid out
    /// frame by frame, the conversation kept at its end by the scroll
    /// view's own anchor rather than scrolled along.
    nonisolated static let anchored = PreviewProbe.on("--probe-glide-anchor")
    #else
    nonisolated static let motion302 = false
    nonisolated static let anchored = false
    #endif

    /// ChatView's: scrolls the conversation to its end, in the transaction
    /// it is called in.
    var scrollToEnd: () -> Void = {}
    /// ChatView's: whether the conversation follows the reply (the person
    /// is at its end and not scrolling).
    var follows: () -> Bool = { false }
    /// Until when (reference-date seconds) the row is moving: other
    /// follows of the conversation's end wait until then, or they would
    /// stop the scroll short (ChatView.scheduleBottom).
    private(set) var movingUntil: TimeInterval = 0
    private var lastStart: TimeInterval?

    /// The room under the reply's text grows (or shrinks) by `change`:
    /// `apply` sets it, in one transaction with the conversation's scroll.
    func move(by change: CGFloat, reduceMotion: Bool, _ apply: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        let following = follows() && !Self.anchored
        guard !reduceMotion else {
            // Reduce Motion: in place at once, the conversation with it in
            // the same frame (302 left it a frame behind).
            var transaction = Transaction()
            transaction.disablesAnimations = true
            withTransaction(transaction) {
                apply()
                if following { scrollToEnd() }
            }
            #if POCKET_PREVIEW
            GlideTrace.shared.moved(by: change, duration: 0, follows: following)
            #endif
            return
        }
        let duration = ReplyGlide.duration(distance: Double(change), since: lastStart.map { now - $0 })
        lastStart = now
        movingUntil = max(movingUntil, now + duration)
        withAnimation(ReplyGlide.animation(duration: duration)) {
            apply()
            if following { scrollToEnd() }
        }
        #if POCKET_PREVIEW
        GlideTrace.shared.moved(by: change, duration: duration, follows: following)
        #endif
    }
}

extension ReplyGlide {
    /// The curve as a SwiftUI animation over `duration`.
    static func animation(duration: TimeInterval) -> Animation {
        .timingCurve(curve.x1, curve.y1, curve.x2, curve.y2, duration: duration)
    }
}

extension EnvironmentValues {
    /// The conversation's ReplyFollow, for the reply being written.
    @Entry var replyFollow: ReplyFollow? = nil
}

/// What of a reply's text is drawn: down to `limit` below its top (the
/// room the orb's row keeps, and `ReplyLight.textClear` more), wide to the
/// sides and above for the writing light; all of it when `limit` is nil.
/// The limit moves with the room, in the room's transaction, so the edge
/// stays just above the orb wherever it is drawn.
struct ReplyTextClip: Shape {
    var limit: CGFloat?
    private static let open: CGFloat = 100_000

    var animatableData: CGFloat {
        get { limit ?? Self.open }
        set { limit = newValue }
    }

    func path(in rect: CGRect) -> Path {
        let side: CGFloat = 400
        let bottom = limit.map { rect.minY + $0 } ?? rect.maxY + Self.open
        return Path(CGRect(x: rect.minX - side, y: rect.minY - side, width: rect.width + 2 * side,
                           height: max(bottom - (rect.minY - side), 0)))
    }
}

/// The reply's text laid out in the room the orb's row keeps for it
/// (`height`, nil: the text's own): the text keeps its own height and
/// overflows a shorter room downwards, where ReplyTextClip hides it.
struct ReplyRoomFrame: ViewModifier {
    let height: CGFloat?

    @ViewBuilder func body(content: Content) -> some View {
        if ReplyFollow.anchored {
            content.modifier(ReplyRoomLayout(height: height ?? 0, active: height != nil))
        } else {
            content.frame(height: height, alignment: .top)
        }
    }
}

/// `--probe-glide-anchor`: the room's height laid out again at each frame
/// of its motion (the conversation's size with it, which the scroll view's
/// anchor follows), rather than drawn there.
private struct ReplyRoomLayout: ViewModifier, Animatable {
    var height: CGFloat
    let active: Bool
    var animatableData: CGFloat {
        get { height }
        set { height = newValue }
    }

    func body(content: Content) -> some View {
        content.frame(height: active ? height : nil, alignment: .top)
    }
}

/// 302's row motion (`--probe-orb-302-motion`): the row eased by
/// ReplyLight.rowGlide as the text is laid out, in a chat that fits.
struct ReplyRowMotion302: ViewModifier {
    let glides: Bool
    let shown: Int

    @ViewBuilder func body(content: Content) -> some View {
        if ReplyFollow.motion302 {
            content.animation(glides ? ReplyLight.rowGlide : nil, value: shown)
        } else {
            content
        }
    }
}
