import SwiftUI

/// 入力欄のタイプ's two choices as small monochrome phones, each playing
/// what its composer does when older messages are read, side by side on
/// one clock (user, 2026-10-24: キーボード設定のアニメーションプレビュー).
/// 縮小型: a finger draws the conversation down, the panel splits into the
/// voice, chat and latest buttons, and the chat button opens it again with
/// the keyboard. 従来型: the same drag, the field stays as it is and the
/// latest button rises out of it, and its tap goes back to the end. The
/// motion is the composer's own, drawn small and flat: ChatView's places
/// and sizes, the fold's path (ComposerMorphPath) and ChatMotion's springs
/// and curves. A tap on a phone chooses its type. It plays only while the
/// page is in view and at rest, so a page slide or a scroll never shares
/// its frames with it; with Reduce Motion each phone holds the moment that
/// tells the two apart.
struct ComposerStylePicker: View {
    @Binding var selection: ComposerStyle
    @Environment(\.settingsPageInView) private var pageInView
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var onScreen = true
    @State private var clock = ComposerDemoClock()
    #if POCKET_PREVIEW
    @State private var demoOver = false
    #endif

    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    private var playing: Bool {
        pageInView && onScreen && scenePhase == .active && !reduceMotion && plays
    }

    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            ForEach(ComposerStyle.allCases) { style in option(style) }
        }
        .frame(maxWidth: .infinity)
        .onScrollVisibilityChange(threshold: 0.1) { onScreen = $0 }
        .onChange(of: playing, initial: true) { _, playing in clock.set(playing: playing) }
        .task { await endDemo() }
    }

    #if POCKET_PREVIEW
    private var plays: Bool { ComposerDemo.plays && !demoOver }
    /// About two loops, then back to the start and still, so the UI check
    /// can ask the page things again.
    private func endDemo() async {
        guard ComposerDemo.plays else { return }
        do { try await Task.sleep(for: .seconds(14)) } catch { return }
        clock.reset()
        demoOver = true
    }
    #else
    private var plays: Bool { true }
    private func endDemo() async {}
    #endif

    private func option(_ style: ComposerStyle) -> some View {
        let selected = selection == style
        return Button {
            guard selection != style else { return }
            withAnimation(.smooth(duration: 0.3)) { selection = style }
        } label: {
            VStack(spacing: 10) {
                ComposerDemoPhone(style: style, clock: clock, playing: playing, still: reduceMotion)
                Text(style.title)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.primary)
                // As iOS's own choice of appearance: a filled check under
                // the chosen one, an empty ring under the other.
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 22))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(selected ? Color.white : Color(uiColor: .tertiaryLabel), Theme.accent)
                    .contentTransition(.symbolEffect(.replace))
            }
            .frame(maxWidth: 136)
            .contentShape(Rectangle())
        }
        .buttonStyle(ComposerStyleOptionStyle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(style.title)
        .accessibilityHint(style.previewHint)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("composer-style-\(style.rawValue)")
    }
}

extension ComposerStyle {
    /// What the phone shows, for VoiceOver.
    var previewHint: String {
        switch self {
        case .folding:
            "ボタンの列がある広い入力欄です。前のメッセージを読むと、音声入力・入力欄を開く・最新へ移動の3つの丸いボタンに縮み、入力欄を開くボタンで元に戻ります。"
        case .classic:
            "＋ボタンと細い入力欄です。前のメッセージを読んでも入力欄はそのままで、上に最新へ移動するボタンが出ます。"
        }
    }
}

/// Pressed, the phone and its name give a little, as a card does.
private struct ComposerStyleOptionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(duration: 0.25, bounce: 0.2), value: configuration.isPressed)
    }
}

enum ComposerDemo {
    /// The screen drawn, in its own points (a 6.3-inch iPhone, where the
    /// composer's places were measured), and the phone around it.
    static let screen = CGSize(width: 402, height: 874)
    static let bezel: CGFloat = 14
    static let phone = CGSize(width: screen.width + 2 * bezel, height: screen.height + 2 * bezel)
    static let screenRadius: CGFloat = 55
    static let loop: TimeInterval = 6
    #if POCKET_PREVIEW
    /// UI checks ask the page things, and XCUITest waits for an app's
    /// animations to end before each question; the phones hold still there
    /// unless a check comes to watch them.
    static let plays = PreviewProbe.on("--keyboard-preview-demo")
    #else
    static let plays = true
    #endif
}

/// The two phones' one time, read on each of their frames (not view state).
/// Paused, it holds where it was; it starts at the beginning of the loop.
@MainActor final class ComposerDemoClock {
    private var start: Date?
    private var held: TimeInterval = 0
    func set(playing: Bool) {
        if playing, start == nil { start = Date(timeIntervalSinceNow: -held) }
        if !playing, let start {
            held = Date().timeIntervalSince(start)
            self.start = nil
        }
    }
    func time(at date: Date) -> TimeInterval {
        guard let start else { return held }
        return max(0, date.timeIntervalSince(start))
    }
    #if POCKET_PREVIEW
    func reset() { start = nil; held = 0 }
    #endif
}

/// One phone: a Canvas redrawn on the display's beat while it plays, and
/// nothing at all while it does not.
private struct ComposerDemoPhone: View {
    let style: ComposerStyle
    let clock: ComposerDemoClock
    let playing: Bool
    let still: Bool
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let palette = ComposerDemoPalette(scheme)
        TimelineView(.animation(minimumInterval: nil, paused: !playing)) { context in
            let scene = still ? ComposerDemoScene.still(style) : ComposerDemoScene(style, at: clock.time(at: context.date))
            Canvas { ctx, size in
                ComposerDemoDrawing(scene: scene, palette: palette).draw(in: &ctx, size: size)
            } symbols: {
                ForEach(ComposerDemoSymbol.allCases, id: \.self) { symbol in
                    Image(systemName: symbol.name)
                        .font(.system(size: symbol.size, weight: symbol.weight))
                        .foregroundStyle(palette.symbol)
                        .tag(symbol)
                }
            }
        }
        .aspectRatio(ComposerDemo.phone.width / ComposerDemo.phone.height, contentMode: .fit)
        .accessibilityHidden(true)
    }
}

/// The symbols the phones draw, at the composer's sizes in the screen's
/// points, a quarter larger so they still read on the small screen.
enum ComposerDemoSymbol: String, CaseIterable {
    case plus, send, bolt, voice, chat, latest, jump

    var name: String {
        switch self {
        case .plus: "plus"
        case .send: "arrow.up"
        case .bolt: "bolt"
        case .voice: "waveform"
        case .chat: "message"
        case .latest, .jump: "arrow.down"
        }
    }
    var size: CGFloat {
        switch self {
        case .plus: 21
        case .send: 18
        case .bolt: 15
        case .voice, .chat: 24
        case .latest: 20
        case .jump: 25
        }
    }
    var weight: Font.Weight { self == .send ? .bold : .medium }
}

/// Monochrome, as the phones in iOS's own tips: the conversation and the
/// controls in greys of the screen's light or dark.
struct ComposerDemoPalette {
    let body, screen, island, text, bubble, glass, rim, chip, placeholder, symbol: Color
    let keyboard, key, finger, fingerRim: Color

    init(_ scheme: ColorScheme) {
        if scheme == .dark {
            body = Color(white: 0.3); screen = .black; island = .black
            text = Color(white: 0.24); bubble = Color(white: 0.4)
            glass = Color(white: 0.14); rim = Color(white: 0.3); chip = Color(white: 0.22)
            placeholder = Color(white: 0.3); symbol = Color(white: 0.86)
            keyboard = Color(white: 0.11); key = Color(white: 0.27)
            finger = Color(white: 0.92).opacity(0.3); fingerRim = Color.white.opacity(0.55)
        } else {
            body = Color(white: 0.16); screen = .white; island = .black
            text = Color(white: 0.87); bubble = Color(white: 0.72)
            glass = Color(white: 0.965); rim = Color(white: 0.8); chip = Color(white: 0.91)
            placeholder = Color(white: 0.8); symbol = Color(white: 0.28)
            keyboard = Color(white: 0.84); key = Color(white: 0.99)
            finger = Color(white: 0.35).opacity(0.32); fingerRim = Color.white.opacity(0.85)
        }
    }
}

/// Where everything is at one moment of the loop, in the screen's points.
struct ComposerDemoScene {
    struct Finger {
        var at: CGPoint
        var scale: CGFloat = 1
        var opacity: Double = 1
        /// The way it came, drawn only in the still picture.
        var trail: CGFloat = 0
    }

    let style: ComposerStyle
    /// How far the conversation has been drawn down toward older messages.
    var scroll: CGFloat = 0
    var finger: Finger?
    /// 縮小型: the fold's progress (ComposerMorphPath) and the keyboard.
    var fold: CGFloat = 0
    var keyboard: CGFloat = 0
    /// 従来型: the latest button out of the field (0 sunk in it, 1 in its
    /// place) and its arrow, while it is there at all.
    var jump: (rise: CGFloat, arrow: CGFloat)?
    /// Toward the empty screen, as the loop starts again.
    var veil: Double = 0

    init(style: ComposerStyle) { self.style = style }

    init(_ style: ComposerStyle, at elapsed: TimeInterval) {
        typealias Beat = ComposerDemoBeat
        self.style = style
        let cycle = Int(elapsed / ComposerDemo.loop)
        let t = elapsed - Double(cycle) * ComposerDemo.loop
        finger = Beat.finger(style, at: t)
        switch style {
        case .folding:
            scroll = Beat.drag(t)
            fold = Beat.fold(at: t)
            keyboard = Beat.keyboard(at: t)
            veil = Beat.veil(at: t, again: cycle > 0)
        case .classic:
            scroll = Beat.classicScroll(at: t)
            jump = Beat.jump(at: t)
        }
    }

    /// With Reduce Motion: the conversation drawn down, and what each type
    /// shows then, with the finger's way.
    static func still(_ style: ComposerStyle) -> ComposerDemoScene {
        var scene = ComposerDemoScene(style: style)
        scene.scroll = ComposerDemoBeat.travel
        scene.finger = Finger(at: ComposerDemoBeat.dragEnd, opacity: 0.9, trail: ComposerDemoBeat.travel * 0.8)
        switch style {
        case .folding: scene.fold = 1
        case .classic: scene.jump = (1, 1)
        }
        return scene
    }
}

/// The loop's timing, the same for both phones, and the composer's own
/// motion along it (seconds from the loop's start).
enum ComposerDemoBeat {
    /// The finger comes down, draws the conversation down, and lifts.
    static let fingerIn: TimeInterval = 0.85
    static let dragStart: TimeInterval = 1.05
    static let dragLength: TimeInterval = 1
    static let liftLength: TimeInterval = 0.25
    static let travel: CGFloat = 250
    static let dragFrom = CGPoint(x: 236, y: 372)
    static var dragEnd: CGPoint { CGPoint(x: dragFrom.x, y: dragFrom.y + travel) }
    /// Then taps: 縮小型's chat button, 従来型's latest button.
    static let tapIn: TimeInterval = 3.25
    static let press: TimeInterval = 3.45
    static let release: TimeInterval = 3.6
    static let tapOut: TimeInterval = 0.22
    /// 縮小型 fades back to its start, where 従来型 already is.
    static let veilOut: TimeInterval = 5.6
    static let veilIn: TimeInterval = 0.3

    /// ChatMotion.composerFold, composerUnfold, jumpRise, jumpSink and
    /// keyboardFollow (the jump's scroll to the end).
    static let foldSpring = Spring(duration: 0.75, bounce: 0.12)
    static let unfoldCurve = UnitCurve.bezier(startControlPoint: UnitPoint(x: 0.45, y: 0),
                                              endControlPoint: UnitPoint(x: 0.25, y: 1))
    static let unfoldLength: TimeInterval = 0.56
    static let riseSpring = Spring(duration: 0.42, bounce: 0.18)
    static let sinkSpring = Spring(duration: 0.38, bounce: 0)
    static let scrollSpring = Spring(duration: 0.3, bounce: 0)
    /// The system keyboard's own rise, close enough at this size.
    static let keyboardSpring = Spring(duration: 0.35, bounce: 0)

    /// 縮小型 folds once the drag has gone far enough with the end far
    /// enough below (ComposerFoldObserver, from the end: the larger of the
    /// two); 従来型's latest button shows past 32pt from the end
    /// (ChatScrollPolicy).
    static let foldsAt = time(atTravel: max(ChatMetrics.collapseTravel, ChatMetrics.collapseDistance))
    static let risesAt = time(atTravel: 32)

    static func drag(_ t: TimeInterval) -> CGFloat {
        travel * CGFloat(UnitCurve.easeInOut.value(at: clamp((t - dragStart) / dragLength)))
    }

    private static func time(atTravel distance: CGFloat) -> TimeInterval {
        var low = 0.0, high = 1.0
        for _ in 0..<32 {
            let middle = (low + high) / 2
            if travel * CGFloat(UnitCurve.easeInOut.value(at: middle)) < distance { low = middle } else { high = middle }
        }
        return dragStart + high * dragLength
    }

    static func fold(at t: TimeInterval) -> CGFloat {
        if t < foldsAt { return 0 }
        if t < release { return value(foldSpring, t - foldsAt) }
        return 1 - CGFloat(unfoldCurve.value(at: clamp((t - release) / unfoldLength)))
    }

    /// The chat button gives the field the keyboard as it opens.
    static func keyboard(at t: TimeInterval) -> CGFloat {
        t < release ? 0 : value(keyboardSpring, t - release)
    }

    static func veil(at t: TimeInterval, again: Bool) -> Double {
        if t >= veilOut { return UnitCurve.easeInOut.value(at: clamp((t - veilOut) / (ComposerDemo.loop - veilOut))) }
        if again && t < veilIn { return 1 - UnitCurve.easeInOut.value(at: clamp(t / veilIn)) }
        return 0
    }

    /// The latest button's tap goes back to the end, 16ms on (jumpToBottom).
    static func classicScroll(at t: TimeInterval) -> CGFloat {
        let drawn = drag(t)
        return t < release ? drawn : drawn * (1 - value(scrollSpring, t - release - 0.016))
    }

    /// ChatView.setJumpVisible: mounted sunk in the field, raised 16ms on,
    /// its arrow 150ms after that. Its tap hides it at once: the arrow
    /// goes, it sinks 60ms on, and its glass leaves 420ms after that.
    static func jump(at t: TimeInterval) -> (rise: CGFloat, arrow: CGFloat)? {
        guard t >= risesAt, t < release + 0.512 else { return nil }
        let raisedAt = risesAt + 0.016
        let rise = value(riseSpring, t - raisedAt)
        guard t >= release else {
            return (rise, CGFloat(UnitCurve.easeOut.value(at: clamp((t - raisedAt - 0.15) / 0.16))))
        }
        let arrow = 1 - CGFloat(UnitCurve.easeIn.value(at: clamp((t - release) / 0.08)))
        return (rise * (1 - value(sinkSpring, t - release - 0.06)), arrow)
    }

    static func finger(_ style: ComposerStyle, at t: TimeInterval) -> ComposerDemoScene.Finger? {
        if t >= fingerIn, t < dragStart + dragLength + liftLength {
            let appear = ease((t - fingerIn) / 0.18)
            let down = ease((t - dragStart + 0.08) / 0.08)
            let lift = ease((t - dragStart - dragLength) / liftLength)
            return .init(at: CGPoint(x: dragFrom.x, y: dragFrom.y + drag(t)),
                         scale: 1.15 - 0.15 * appear - 0.06 * down + 0.2 * lift, opacity: appear * (1 - lift))
        }
        if t >= tapIn, t < release + tapOut {
            let appear = ease((t - tapIn) / 0.15)
            let down = ease((t - press) / 0.1)
            let up = ease((t - release) / tapOut)
            let target = style == .folding ? ComposerDemoLayout.chatButton : ComposerDemoLayout.jumpCenter
            return .init(at: target, scale: 1.15 - 0.15 * appear - 0.12 * down + 0.2 * up, opacity: appear * (1 - up))
        }
        return nil
    }

    private static func value(_ spring: Spring, _ time: TimeInterval) -> CGFloat {
        time <= 0 ? 0 : CGFloat(spring.value(target: 1.0, time: time))
    }
    private static func clamp(_ x: Double) -> Double { min(1, max(0, x)) }
    private static func ease(_ x: Double) -> Double { UnitCurve.easeInOut.value(at: clamp(x)) }
}

/// ChatView's places on the screen the phones stand for, in its points:
/// a 12pt gutter, the bar 6pt above the 34pt home area.
enum ComposerDemoLayout {
    static let center: CGFloat = 201
    static let gutter = ChatMetrics.gutter
    static let barBottom: CGFloat = 874 - 34 - 6
    /// With the keyboard up (336pt), the bar rests 6pt above it.
    static let keyboardHeight: CGFloat = 336
    static let panelHeight: CGFloat = 100
    /// The folded buttons stand on the bar's bottom.
    static let chatButton = CGPoint(x: center, y: barBottom - ChatMetrics.morphButton / 2)
    /// 従来型: the field after the plus, and the latest button centered on
    /// the screen, `jumpLift` (24pt) above it, sinking 57pt into it.
    static let fieldTop = barBottom - ChatMetrics.control
    static let jumpCenter = CGPoint(x: center, y: fieldTop - ChatMetrics.jumpGap - ChatMetrics.control / 2)
    static let jumpSink: CGFloat = ChatMetrics.jumpGap + ChatMetrics.control / 2 + ChatMotion.jumpSunkDepth
}

/// The conversation both phones show: replies as lines, the user's turns
/// as bubbles, built upward from the latest at 0.
private enum ComposerDemoConversation {
    enum Kind { case line, bubble }
    static let items: [(kind: Kind, rect: CGRect)] = {
        var items: [(kind: Kind, rect: CGRect)] = []
        var bottom: CGFloat = 0
        func reply(_ lines: [CGFloat]) {
            for (index, fraction) in lines.reversed().enumerated() {
                let y = bottom - CGFloat(index + 1) * 24
                items.append((kind: .line, rect: CGRect(x: 18, y: y + 7, width: 366 * fraction, height: 10)))
            }
            bottom -= CGFloat(lines.count) * 24 + 14
        }
        func ask(_ width: CGFloat) {
            bottom -= 6
            items.append((kind: .bubble, rect: CGRect(x: 390 - width, y: bottom - 36, width: width, height: 36)))
            bottom -= 36 + 20
        }
        reply([0.62]); ask(150); reply([1, 1, 1, 0.45]); reply([1, 0.7]); ask(178)
        reply([1, 1, 1, 0.3]); reply([1, 0.66]); ask(136); reply([1, 1, 0.8]); ask(160)
        reply([1, 1, 1, 0.5]); reply([1, 0.72]); ask(120); reply([1, 1, 1, 0.4]); ask(150)
        return items
    }()
}

/// Draws one moment on the phone, scaled to the size it is given.
struct ComposerDemoDrawing {
    let scene: ComposerDemoScene
    let palette: ComposerDemoPalette
    private typealias L = ComposerDemoLayout
    private typealias Morph = ComposerMorphPath

    func draw(in context: inout GraphicsContext, size: CGSize) {
        let scale = size.width / ComposerDemo.phone.width
        guard scale > 0 else { return }
        context.scaleBy(x: scale, y: scale)
        // Outlines three quarters of a point wide on the screen.
        let hair = 0.75 / scale
        context.fill(Path(roundedRect: CGRect(origin: .zero, size: ComposerDemo.phone),
                          cornerRadius: ComposerDemo.screenRadius + ComposerDemo.bezel, style: .continuous),
                     with: .color(palette.body))
        var screen = context
        screen.translateBy(x: ComposerDemo.bezel, y: ComposerDemo.bezel)
        let bounds = CGRect(origin: .zero, size: ComposerDemo.screen)
        let shape = Path(roundedRect: bounds, cornerRadius: ComposerDemo.screenRadius, style: .continuous)
        screen.clip(to: shape)
        screen.fill(shape, with: .color(palette.screen))
        drawConversation(&screen)
        drawHeader(&screen, hair: hair)
        switch scene.style {
        case .folding: drawFoldingComposer(&screen, hair: hair)
        case .classic: drawClassicComposer(&screen, hair: hair)
        }
        if let finger = scene.finger { drawFinger(finger, in: &screen) }
        if scene.veil > 0 { screen.fill(Path(bounds), with: .color(palette.screen.opacity(scene.veil))) }
        // The Dynamic Island and the home indicator stay over everything.
        screen.fill(Path(roundedRect: CGRect(x: 138, y: 11, width: 126, height: 37), cornerRadius: 18.5),
                    with: .color(palette.island))
        screen.fill(Path(roundedRect: CGRect(x: 134, y: 860, width: 134, height: 5), cornerRadius: 2.5),
                    with: .color(palette.symbol.opacity(0.75)))
    }

    // MARK: Conversation and header

    private func drawConversation(_ context: inout GraphicsContext) {
        let end = (scene.style == .folding ? L.barBottom - L.panelHeight : L.fieldTop) - 18 + scene.scroll
        for item in ComposerDemoConversation.items {
            let rect = item.rect.offsetBy(dx: 0, dy: end)
            guard rect.maxY > 60, rect.minY < 874 else { continue }
            switch item.kind {
            case .line:
                context.fill(Path(roundedRect: rect, cornerRadius: 5), with: .color(palette.text))
            case .bubble:
                context.fill(Path(roundedRect: rect, cornerRadius: 18), with: .color(palette.bubble))
            }
        }
        // The feathered band under the header, as the chat's backdrop.
        context.fill(Path(CGRect(x: 0, y: 0, width: 402, height: 170)),
                     with: .linearGradient(Gradient(stops: [.init(color: palette.screen, location: 0),
                                                            .init(color: palette.screen, location: 0.58),
                                                            .init(color: palette.screen.opacity(0), location: 1)]),
                                           startPoint: .zero, endPoint: CGPoint(x: 0, y: 170)))
    }

    private func drawHeader(_ context: inout GraphicsContext, hair: CGFloat) {
        let ink = palette.symbol
        // The status bar: the time, then signal, Wi-Fi and battery.
        context.fill(Path(roundedRect: CGRect(x: 40, y: 23, width: 38, height: 13), cornerRadius: 6.5), with: .color(ink))
        for (x, width) in [(CGFloat(306), CGFloat(18)), (330, 16), (352, 26)] {
            context.fill(Path(roundedRect: CGRect(x: x, y: 24, width: width, height: 11), cornerRadius: 3),
                         with: .color(ink.opacity(0.55)))
        }
        // The history button, the model's mark and its name.
        glass(Path(ellipseIn: CGRect(x: 12, y: 70, width: 44, height: 44)), in: &context, hair: hair)
        var lines = Path()
        lines.move(to: CGPoint(x: 24.5, y: 87.5)); lines.addLine(to: CGPoint(x: 43.5, y: 87.5))
        lines.move(to: CGPoint(x: 24.5, y: 96.5)); lines.addLine(to: CGPoint(x: 37, y: 96.5))
        context.stroke(lines, with: .color(ink), style: StrokeStyle(lineWidth: 2.8, lineCap: .round))
        var mark = Path()
        mark.addArc(center: CGPoint(x: 201, y: 88), radius: 12, startAngle: .degrees(-35), endAngle: .degrees(300),
                    clockwise: false)
        mark.move(to: CGPoint(x: 201, y: 88)); mark.addLine(to: CGPoint(x: 213, y: 88))
        context.stroke(mark, with: .color(ink.opacity(0.6)), style: StrokeStyle(lineWidth: 5, lineCap: .butt))
        glass(Path(roundedRect: CGRect(x: 165, y: 115, width: 72, height: 22), cornerRadius: 11), in: &context, hair: hair)
        context.fill(Path(roundedRect: CGRect(x: 178, y: 122.5, width: 36, height: 7), cornerRadius: 3.5),
                     with: .color(ink.opacity(0.8)))
        context.fill(Path(roundedRect: CGRect(x: 219, y: 122.5, width: 5, height: 7), cornerRadius: 2),
                     with: .color(ink.opacity(0.45)))
    }

    // MARK: 縮小型

    private func drawFoldingComposer(_ context: inout GraphicsContext, hair: CGFloat) {
        let p = scene.fold, k = scene.keyboard
        let bottom = L.barBottom - k * (L.barBottom - (874 - L.keyboardHeight - 6))
        let clamped = min(1, max(0, p))
        let flatten = Morph.flatten(clamped)
        feather(above: bottom - (L.panelHeight - (L.panelHeight - ChatMetrics.morphButton) * flatten), in: &context)
        if k > 0 { drawKeyboard(top: 874 - L.keyboardHeight * k, in: &context) }

        // ComposerPanelMorph: the panel squeezed into a capsule that draws
        // in to the chat button.
        let width = 402 - 2 * L.gutter, height = L.panelHeight
        let stretch = Morph.stretch(clamped)
        let narrowed = width + (Morph.capsule - width) * Morph.narrow(clamped)
        let w = clamped > 0.0005 ? narrowed + (Morph.side - narrowed) * Morph.gatherIn(clamped) + 10 * stretch : width
        let h = clamped > 0.0005 ? height + (Morph.side - height) * flatten - 6 * stretch : height
        let radius = min(ChatMetrics.composerRadius + (Morph.side / 2 - ChatMetrics.composerRadius) * flatten, h / 2)
        var glassShape = Path(roundedRect: CGRect(x: L.center - w / 2, y: bottom - h, width: w, height: h),
                              cornerRadius: radius, style: .continuous)
        // ComposerButtonMorph: the voice and latest buttons travel out of
        // its ends, pulled thin while they part.
        if p > 0.0005 {
            let pull = Morph.stretch(p)
            let bw = Morph.side + 8 * pull, bh = Morph.side - 4 * pull
            let reach = Morph.outer(p) - 4 * pull
            for slot in [CGFloat(-1), 1] {
                let rect = CGRect(x: L.center + slot * reach - bw / 2, y: bottom - bh, width: bw, height: bh)
                glassShape = glassShape.union(Path(roundedRect: rect, cornerRadius: min(bw, bh) / 2, style: .continuous))
            }
        }
        glass(glassShape, in: &context, hair: hair)

        // The panel's text and row leave first and come back last.
        let content = 1 - Double(ChatMotion.step(0, 0.22, clamped))
        let row = 1 - Double(ChatMotion.step(0, 0.12, clamped))
        if content > 0 {
            var inside = context
            inside.opacity = content
            inside.fill(Path(roundedRect: CGRect(x: 29, y: bottom - height + 16.5, width: 104, height: 11), cornerRadius: 5.5),
                        with: .color(palette.placeholder))
        }
        if row > 0 {
            var buttons = context
            buttons.opacity = row
            let y = bottom - 30
            buttons.fill(Path(ellipseIn: CGRect(x: 24, y: y - 18, width: 36, height: 36)), with: .color(palette.chip))
            symbol(.plus, at: CGPoint(x: 42, y: y), in: &buttons)
            buttons.fill(Path(roundedRect: CGRect(x: 70, y: y - 18, width: 83, height: 36), cornerRadius: 18), with: .color(palette.chip))
            symbol(.bolt, at: CGPoint(x: 87, y: y), in: &buttons)
            buttons.fill(Path(roundedRect: CGRect(x: 97, y: y - 4.5, width: 30, height: 9), cornerRadius: 4.5),
                         with: .color(palette.symbol))
            buttons.fill(Path(roundedRect: CGRect(x: 165, y: y - 18, width: 64, height: 36), cornerRadius: 18), with: .color(palette.chip))
            buttons.fill(Path(roundedRect: CGRect(x: 180, y: y - 4.5, width: 32, height: 9), cornerRadius: 4.5),
                         with: .color(palette.symbol))
            buttons.fill(Path(ellipseIn: CGRect(x: 342, y: y - 17, width: 34, height: 34)), with: .color(palette.chip))
            symbol(.send, at: CGPoint(x: 359, y: y), opacity: 0.45, in: &buttons)
        }
        // Each symbol arrives as its drop takes shape.
        let y = bottom - ChatMetrics.morphButton / 2
        let outer = Double(ChatMotion.step(0.8, 0.98, p)), middle = Double(ChatMotion.step(0.62, 0.86, p))
        let reach = Morph.outer(p) - 4 * Morph.stretch(p)
        symbol(.voice, at: CGPoint(x: L.center - reach, y: y), scale: 0.6 + 0.4 * outer, opacity: outer, in: &context)
        symbol(.chat, at: CGPoint(x: L.center, y: y), scale: 0.6 + 0.4 * middle, opacity: middle, in: &context)
        symbol(.latest, at: CGPoint(x: L.center + reach, y: y), scale: 0.6 + 0.4 * outer, opacity: outer, in: &context)
    }

    private func drawKeyboard(top: CGFloat, in context: inout GraphicsContext) {
        context.fill(Path(roundedRect: CGRect(x: 0, y: top, width: 402, height: L.keyboardHeight + 40), cornerRadius: 28,
                          style: .continuous),
                     with: .color(palette.keyboard))
        let keys = palette.key
        for (x, width) in [(CGFloat(48), CGFloat(40)), (178, 46), (308, 44)] {
            context.fill(Path(roundedRect: CGRect(x: x, y: top + 19, width: width, height: 9), cornerRadius: 4.5),
                         with: .color(palette.symbol.opacity(0.3)))
        }
        let pitch: CGFloat = (402 - 12 + 5.6) / 10, side = pitch - 5.6
        func key(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat) {
            context.fill(Path(roundedRect: CGRect(x: x, y: top + y, width: width, height: 40), cornerRadius: 7), with: .color(keys))
        }
        for column in 0..<10 { key(6 + CGFloat(column) * pitch, 55, side) }
        for column in 0..<9 { key(6 + pitch / 2 + CGFloat(column) * pitch, 108, side) }
        key(6, 161, 44); key(352, 161, 44)
        for column in 0..<7 { key(6 + pitch * 1.5 + CGFloat(column) * pitch, 161, side) }
        key(6, 215, 44); key(56, 215, 44); key(106, 215, 196); key(308, 215, 88)
    }

    // MARK: 従来型

    private func drawClassicComposer(_ context: inout GraphicsContext, hair: CGFloat) {
        feather(above: L.fieldTop, in: &context)
        let y = L.barBottom - ChatMetrics.control / 2
        // The plus has a glass of its own; the field shares its with the
        // latest button that rises out of it.
        glass(Path(ellipseIn: CGRect(x: L.gutter, y: L.fieldTop, width: ChatMetrics.control, height: ChatMetrics.control)),
              in: &context, hair: hair)
        symbol(.plus, at: CGPoint(x: L.gutter + ChatMetrics.control / 2, y: y), in: &context)
        let fieldX = L.gutter + ChatMetrics.control + ChatMetrics.controlGap
        var glassShape = Path(roundedRect: CGRect(x: fieldX, y: L.fieldTop, width: 402 - L.gutter - fieldX,
                                                  height: ChatMetrics.control),
                              cornerRadius: ChatMetrics.control / 2, style: .continuous)
        var jumpAt: CGPoint?
        if let jump = scene.jump {
            // JumpSink: scaled about its center and moved down into the field.
            let scale = ChatMotion.jumpSunkScale + (1 - ChatMotion.jumpSunkScale) * jump.rise
            let center = CGPoint(x: L.jumpCenter.x, y: L.jumpCenter.y + L.jumpSink * (1 - jump.rise))
            let radius = ChatMetrics.control / 2 * scale
            glassShape = glassShape.union(Path(ellipseIn: CGRect(x: center.x - radius, y: center.y - radius,
                                                                 width: 2 * radius, height: 2 * radius)))
            jumpAt = center
        }
        glass(glassShape, in: &context, hair: hair)
        context.fill(Path(roundedRect: CGRect(x: fieldX + 15, y: y - 5.5, width: 104, height: 11), cornerRadius: 5.5),
                     with: .color(palette.placeholder))
        context.fill(Path(ellipseIn: CGRect(x: 353, y: y - 15, width: 30, height: 30)), with: .color(palette.chip))
        symbol(.send, at: CGPoint(x: 368, y: y), scale: 0.85, opacity: 0.45, in: &context)
        if let jump = scene.jump, let jumpAt {
            symbol(.jump, at: jumpAt, scale: 0.5 + 0.5 * jump.arrow, opacity: Double(jump.arrow), in: &context)
        }
    }

    // MARK: Pieces

    /// The bottom of the conversation fades under the bar, as in the chat.
    private func feather(above top: CGFloat, in context: inout GraphicsContext) {
        let from = top - 36
        context.fill(Path(CGRect(x: 0, y: from, width: 402, height: 874 - from)),
                     with: .linearGradient(Gradient(stops: [.init(color: palette.screen.opacity(0), location: 0),
                                                            .init(color: palette.screen.opacity(0.94), location: 48 / (874 - from)),
                                                            .init(color: palette.screen.opacity(0.94), location: 1)]),
                                           startPoint: CGPoint(x: 0, y: from), endPoint: CGPoint(x: 0, y: 874)))
    }

    /// A control's glass, flat: a light fill and a hairline edge.
    private func glass(_ shape: Path, in context: inout GraphicsContext, hair: CGFloat) {
        context.fill(shape, with: .color(palette.glass))
        context.stroke(shape, with: .color(palette.rim), lineWidth: hair)
    }

    private func symbol(_ symbol: ComposerDemoSymbol, at point: CGPoint, scale: CGFloat = 1, opacity: Double = 1,
                        in context: inout GraphicsContext) {
        guard opacity > 0.001, let resolved = context.resolveSymbol(id: symbol) else { return }
        var mark = context
        mark.opacity *= opacity
        mark.translateBy(x: point.x, y: point.y)
        mark.scaleBy(x: scale, y: scale)
        mark.draw(resolved, at: .zero, anchor: .center)
    }

    private func drawFinger(_ finger: ComposerDemoScene.Finger, in context: inout GraphicsContext) {
        guard finger.opacity > 0.001 else { return }
        var touch = context
        touch.opacity *= finger.opacity
        let radius = 26 * finger.scale
        if finger.trail > 0 {
            let trail = CGRect(x: finger.at.x - 26, y: finger.at.y - finger.trail, width: 52, height: finger.trail)
            touch.fill(Path(roundedRect: trail, cornerRadius: 26),
                       with: .linearGradient(Gradient(colors: [palette.finger.opacity(0), palette.finger.opacity(0.5)]),
                                             startPoint: CGPoint(x: 0, y: trail.minY), endPoint: CGPoint(x: 0, y: trail.maxY)))
        }
        let disc = Path(ellipseIn: CGRect(x: finger.at.x - radius, y: finger.at.y - radius, width: 2 * radius, height: 2 * radius))
        touch.fill(disc, with: .color(palette.finger))
        touch.stroke(disc, with: .color(palette.fingerRim), lineWidth: 2.5)
    }
}
