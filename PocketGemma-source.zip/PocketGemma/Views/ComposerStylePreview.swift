import SwiftUI

/// 入力欄のタイプ's two choices as small line drawings of an iPhone, as in
/// iOS's own Tips, each playing what its composer does when older messages
/// are read, side by side on one clock (user, 2026-10-24: キーボード設定の
/// アニメーションプレビュー; simplified the same day in 「キーボードと入力
/// UI改善・名称変更指示書」, given a lens in 1.1.0 (166) and (168), and
/// brushed up in 1.1.0 (170)). A finger draws a short conversation down and
/// the composer changes as in the chat: スタンダード's field stays as it is
/// and the latest button rises out of it, スマート's panel splits into the
/// voice, chat and latest buttons. Once the scroll has settled, the
/// composer lifts out of its place into a soft rounded lens, larger, while
/// the conversation steps back; only one composer is ever in view. It
/// holds there long enough to compare the two, goes back into its place,
/// and both fade back to their start together. The composer's motion is
/// its own, drawn small and flat: ChatView's places and sizes, the fold's
/// path (ComposerMorphPath) and ChatMotion's springs. A tap on a phone
/// chooses its type, with the selection tick. It plays only while the page
/// is in view and at rest, so a page slide or a scroll never shares its
/// frames with it; with Reduce Motion each phone holds the moment that
/// tells the two apart, in its lens.
struct ComposerStylePicker: View {
    @Binding var selection: ComposerStyle
    @Environment(\.settingsPageInView) private var pageInView
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var onScreen = true
    @State private var clock = ComposerDemoClock()
    #if POCKET_PREVIEW
    @State private var demoOver = false
    #endif

    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    private var playing: Bool {
        pageInView && onScreen && scenePhase == .active && !reduceMotion && plays
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ForEach(ComposerDemo.order) { style in option(style) }
        }
        .frame(maxWidth: .infinity)
        .sensoryFeedback(.selection, trigger: selection)
        .onScrollVisibilityChange(threshold: 0.1) { onScreen = $0 }
        .onChange(of: playing, initial: true) { _, playing in clock.set(playing: playing) }
        .task { await endDemo() }
    }

    #if POCKET_PREVIEW
    private var plays: Bool { ComposerDemo.plays && !demoOver }
    /// About two loops, then back to the start and still, so the UI check
    /// can ask the page things again.
    private func endDemo() async {
        guard ComposerDemo.plays else { return }
        do { try await Task.sleep(for: .seconds(14)) } catch { return }
        clock.reset()
        demoOver = true
    }
    #else
    private var plays: Bool { true }
    private func endDemo() async {}
    #endif

    private func option(_ style: ComposerStyle) -> some View {
        let selected = selection == style
        return Button {
            guard selection != style else { return }
            withAnimation(.smooth(duration: 0.3)) { selection = style }
        } label: {
            VStack(spacing: 10) {
                ComposerDemoPhone(style: style, clock: clock, playing: playing, still: reduceMotion)
                Text(style.title)
                    .font(.callout.weight(.semibold))
                    .foregroundStyle(.primary)
                // As iOS's own choice of appearance: a filled check under
                // the chosen one, an empty ring under the other.
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 22))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(selected ? Color.white : Color(uiColor: .tertiaryLabel), Theme.accent)
                    .contentTransition(.symbolEffect(.replace))
            }
            .frame(maxWidth: 156)
            .contentShape(Rectangle())
        }
        .buttonStyle(ComposerStyleOptionStyle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(style.title)
        .accessibilityHint(style.previewHint)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("composer-style-\(style.rawValue)")
    }
}

extension ComposerStyle {
    /// What the phones show, short and readable (user 2026-10-24 19:02
    /// UTC), under them in キーボードと入力 and in the first launch's setup.
    var previewCaption: String {
        switch self {
        case .folding: "スクロールすると、入力欄が3つの丸いボタンに分かれます。"
        case .classic: "スクロールしても入力欄はそのまま。最新へ戻るボタンが出ます。"
        }
    }

    /// What the phone shows, for VoiceOver.
    var previewHint: String {
        switch self {
        case .folding:
            "前のメッセージへスクロールすると、入力欄が音声入力・入力欄を開く・最新へ移動の3つの丸いボタンに分かれます。"
        case .classic:
            "＋ボタンと入力欄です。前のメッセージへスクロールしても入力欄はそのままで、最新へ移動のボタンが出ます。"
        }
    }
}

/// Pressed, the phone and its name give a little, as a card does.
private struct ComposerStyleOptionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(duration: 0.25, bounce: 0.2), value: configuration.isPressed)
    }
}

enum ComposerDemo {
    /// The screen drawn, in its own points (a 6.3-inch iPhone, where the
    /// composer's places were measured).
    static let screen = CGSize(width: 402, height: 874)
    static let screenRadius: CGFloat = 55
    static let loop: TimeInterval = 6
    /// スタンダード first, as the user's directive numbers them.
    static let order: [ComposerStyle] = [.classic, .folding]
    #if POCKET_PREVIEW
    /// UI checks ask the page things, and XCUITest waits for an app's
    /// animations to end before each question; the phones hold still there
    /// unless a check comes to watch them.
    static let plays = PreviewProbe.on("--keyboard-preview-demo")
    #else
    static let plays = true
    #endif
}

/// The two phones' one time, read on each of their frames (not view state).
/// Paused, it holds where it was; it starts at the beginning of the loop.
@MainActor final class ComposerDemoClock {
    private var start: Date?
    private var held: TimeInterval = 0
    func set(playing: Bool) {
        if playing, start == nil { start = Date(timeIntervalSinceNow: -held) }
        if !playing, let start {
            held = Date().timeIntervalSince(start)
            self.start = nil
        }
    }
    func time(at date: Date) -> TimeInterval {
        guard let start else { return held }
        return max(0, date.timeIntervalSince(start))
    }
    #if POCKET_PREVIEW
    func reset() { start = nil; held = 0 }
    #endif
}

/// One phone: a Canvas redrawn on the display's beat while it plays, and
/// nothing at all while it does not. Its outline is a thin line drawn apart
/// from the Canvas, so the frames never redraw it.
private struct ComposerDemoPhone: View {
    let style: ComposerStyle
    let clock: ComposerDemoClock
    let playing: Bool
    let still: Bool
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let palette = ComposerDemoPalette(scheme)
        TimelineView(.animation(minimumInterval: nil, paused: !playing)) { context in
            let scene = still ? ComposerDemoScene.still(style) : ComposerDemoScene(style, at: clock.time(at: context.date))
            Canvas { ctx, size in
                ComposerDemoDrawing(scene: scene, palette: palette).draw(in: &ctx, size: size)
            } symbols: {
                ForEach(ComposerDemoSymbol.allCases, id: \.self) { symbol in
                    Image(systemName: symbol.name)
                        .font(.system(size: symbol.size, weight: .medium))
                        .foregroundStyle(palette.symbol)
                        .tag(symbol)
                }
            }
        }
        .aspectRatio(ComposerDemo.screen.width / ComposerDemo.screen.height, contentMode: .fit)
        .overlay {
            ComposerDemoScreenShape().strokeBorder(palette.outline, lineWidth: 1)
        }
        .accessibilityHidden(true)
    }
}

/// The screen's outline at any size, its corners scaled with it.
struct ComposerDemoScreenShape: InsettableShape {
    var inset: CGFloat = 0

    func path(in rect: CGRect) -> Path {
        let radius = ComposerDemo.screenRadius * rect.width / ComposerDemo.screen.width
        return Path(roundedRect: rect.insetBy(dx: inset, dy: inset), cornerRadius: max(0, radius - inset),
                    style: .continuous)
    }

    func inset(by amount: CGFloat) -> ComposerDemoScreenShape {
        var shape = self
        shape.inset += amount
        return shape
    }
}

/// The few symbols the phones draw: スタンダード's plus and latest button,
/// スマート's three buttons, at the composer's sizes in the screen's points
/// a quarter larger, so they still read on the small screen.
enum ComposerDemoSymbol: String, CaseIterable {
    case plus, voice, chat, latest, jump

    var name: String {
        switch self {
        case .plus: "plus"
        case .voice: "waveform"
        case .chat: "message"
        case .latest, .jump: "arrow.down"
        }
    }
    var size: CGFloat {
        switch self {
        case .plus: 21
        case .voice, .chat: 24
        case .latest: 20
        case .jump: 25
        }
    }
}

/// Monochrome, as the drawings in iOS's own Tips: greys of the screen's
/// light or dark, the composer's glass a shade off the screen with a
/// hairline edge, its edge and symbols a little stronger than the
/// conversation's quiet bubbles, so the composer leads.
struct ComposerDemoPalette {
    let screen, outline, reply, ask, glass, rim, chip, placeholder, symbol, finger, fingerRim: Color
    /// How far the conversation steps back while the lens holds the
    /// composer: less on black, where its greys are already low.
    let stepBack: Double

    init(_ scheme: ColorScheme) {
        if scheme == .dark {
            // A shade lighter than the screen's own greys around it, so the
            // bubbles stand off the black (user 2026-10-24 20:02 UTC).
            screen = .black; outline = Color.white.opacity(0.3); stepBack = 0.3
            reply = Color(white: 0.18); ask = Color(white: 0.31)
            glass = Color(white: 0.12); rim = Color(white: 0.38); chip = Color(white: 0.22)
            placeholder = Color(white: 0.3); symbol = Color(white: 0.9)
            finger = Color(white: 0.92).opacity(0.36); fingerRim = Color.white.opacity(0.6)
        } else {
            screen = .white; outline = Color.black.opacity(0.2); stepBack = 0.45
            reply = Color(white: 0.945); ask = Color(white: 0.85)
            glass = Color(white: 0.955); rim = Color(white: 0.7); chip = Color(white: 0.87)
            placeholder = Color(white: 0.78); symbol = Color(white: 0.22)
            finger = Color(white: 0.3).opacity(0.38); fingerRim = Color.white.opacity(0.9)
        }
    }
}

/// Where everything is at one moment of the loop, in the screen's points.
struct ComposerDemoScene {
    struct Finger {
        var at: CGPoint
        var scale: CGFloat = 1
        var opacity: Double = 1
        /// The way it came, fading out behind it.
        var trail: CGFloat = 0
    }

    let style: ComposerStyle
    /// How far the conversation has been drawn down toward older messages.
    var scroll: CGFloat = 0
    var finger: Finger?
    /// スマート: the fold's progress (ComposerMorphPath).
    var fold: CGFloat = 0
    /// スタンダード: the latest button out of the field (0 sunk in it, 1 in
    /// its place) and its arrow, while it is there at all.
    var jump: (rise: CGFloat, arrow: CGFloat)?
    /// How far the loop's start has faded in over this moment.
    var restart: Double = 0
    /// The lens: 0 the composer in its place, 1 lifted out into the lens.
    var lens: CGFloat = 0

    init(style: ComposerStyle) { self.style = style }

    init(_ style: ComposerStyle, at elapsed: TimeInterval) {
        typealias Beat = ComposerDemoBeat
        self.style = style
        let t = elapsed.truncatingRemainder(dividingBy: ComposerDemo.loop)
        scroll = Beat.drag(t)
        finger = Beat.finger(at: t)
        restart = Beat.restart(at: t)
        lens = Beat.lens(at: t)
        switch style {
        case .folding: fold = Beat.fold(at: t)
        case .classic: jump = Beat.jump(at: t)
        }
    }

    /// With Reduce Motion: the conversation drawn down, and what each type
    /// shows then in the lens, with the finger's way, faint.
    static func still(_ style: ComposerStyle) -> ComposerDemoScene {
        var scene = ComposerDemoScene(style: style)
        scene.lens = 1
        scene.scroll = ComposerDemoBeat.travel
        scene.finger = Finger(at: ComposerDemoBeat.dragEnd, opacity: 0.6, trail: ComposerDemoBeat.travel * 0.6)
        switch style {
        case .folding: scene.fold = 1
        case .classic: scene.jump = (1, 1)
        }
        return scene
    }
}

/// The loop's timing, the same for both phones, and the composer's own
/// motion along it (seconds from the loop's start): at rest, a finger draws
/// the conversation down and lifts while the composer changes; once the
/// scroll and スマート's fold have settled, the lens lifts the composer out,
/// holds it to compare, puts it back, and both fade back to their start.
/// The drag is short enough that it is slowing to its end as スマート's
/// panel, a thin capsule by then, parts into its three buttons (user
/// 2026-10-24 20:02 UTC: show the split more clearly), so little else moves
/// then. Its length leaves no bubble's end showing past the lens's corners,
/// where a sliver reads as a second edge (200 left one at スマート's).
enum ComposerDemoBeat {
    static let fingerIn: TimeInterval = 0.5
    static let dragStart: TimeInterval = 0.7
    static let dragLength: TimeInterval = 0.85
    static let liftLength: TimeInterval = 0.25
    static let travel: CGFloat = 230
    static let dragFrom = CGPoint(x: 236, y: 210)
    static var dragEnd: CGPoint { CGPoint(x: dragFrom.x, y: dragFrom.y + travel) }
    static let restartFrom: TimeInterval = lensOutFrom + lensOutLength + 0.15
    static let restartLength: TimeInterval = 0.6

    /// The lens (the preview's own; user 2026-10-24 19:02 UTC: once the
    /// scroll has settled) lifts after the drag has ended, the finger gone
    /// and スマート's fold (from about 1.1 s, 1 s) at rest a moment as it
    /// is, and holds 1.6 s to compare.
    static let lensInFrom: TimeInterval = 2.4
    static let lensInLength: TimeInterval = 0.5
    static let lensOutFrom: TimeInterval = 4.5
    static let lensOutLength: TimeInterval = 0.45

    /// ChatMotion.composerFold and jumpRise. The fold is the app's spring
    /// (0.75 s, bounce 0.12) played a third slower, its path unchanged, so
    /// the capsule and the parting read on the small phone.
    static let foldSpring = Spring(duration: 1, bounce: 0.12)
    static let riseSpring = Spring(duration: 0.42, bounce: 0.18)

    /// スマート folds once the drag has gone far enough with the end far
    /// enough below (ComposerFoldObserver, from the end: the larger of the
    /// two); スタンダード's latest button shows past 32pt from the end
    /// (ChatScrollPolicy).
    static let foldsAt = time(atTravel: max(ChatMetrics.collapseTravel, ChatMetrics.collapseDistance))
    static let risesAt = time(atTravel: 32)

    static func drag(_ t: TimeInterval) -> CGFloat {
        travel * CGFloat(UnitCurve.easeInOut.value(at: clamp((t - dragStart) / dragLength)))
    }

    private static func time(atTravel distance: CGFloat) -> TimeInterval {
        var low = 0.0, high = 1.0
        for _ in 0..<32 {
            let middle = (low + high) / 2
            if travel * CGFloat(UnitCurve.easeInOut.value(at: middle)) < distance { low = middle } else { high = middle }
        }
        return dragStart + high * dragLength
    }

    static func fold(at t: TimeInterval) -> CGFloat {
        t < foldsAt ? 0 : value(foldSpring, t - foldsAt)
    }

    /// ChatView.setJumpVisible: mounted sunk in the field, raised 16ms on,
    /// its arrow 150ms after that.
    static func jump(at t: TimeInterval) -> (rise: CGFloat, arrow: CGFloat)? {
        guard t >= risesAt else { return nil }
        let raisedAt = risesAt + 0.016
        return (value(riseSpring, t - raisedAt), CGFloat(UnitCurve.easeOut.value(at: clamp((t - raisedAt - 0.15) / 0.16))))
    }

    static func restart(at t: TimeInterval) -> Double {
        ease((t - restartFrom) / restartLength)
    }

    static func lens(at t: TimeInterval) -> CGFloat {
        CGFloat(ease((t - lensInFrom) / lensInLength) - ease((t - lensOutFrom) / lensOutLength))
    }

    static func finger(at t: TimeInterval) -> ComposerDemoScene.Finger? {
        guard t >= fingerIn, t < dragStart + dragLength + liftLength else { return nil }
        let appear = ease((t - fingerIn) / 0.18)
        let down = ease((t - dragStart + 0.08) / 0.08)
        let lift = ease((t - dragStart - dragLength) / liftLength)
        let drawn = drag(t)
        return .init(at: CGPoint(x: dragFrom.x, y: dragFrom.y + drawn),
                     scale: 1.15 - 0.15 * appear - 0.06 * down + 0.2 * lift, opacity: appear * (1 - lift),
                     trail: min(drawn, 110) * CGFloat(1 - lift))
    }

    private static func value(_ spring: Spring, _ time: TimeInterval) -> CGFloat {
        time <= 0 ? 0 : CGFloat(spring.value(target: 1.0, time: time))
    }
    private static func clamp(_ x: Double) -> Double { min(1, max(0, x)) }
    private static func ease(_ x: Double) -> Double { UnitCurve.easeInOut.value(at: clamp(x)) }
}

/// ChatView's places on the screen the phones stand for, in its points:
/// a 12pt gutter, the bar 6pt above the 34pt home area.
enum ComposerDemoLayout {
    static let center: CGFloat = 201
    static let gutter = ChatMetrics.gutter
    static let barBottom: CGFloat = 874 - 34 - 6
    static let panelHeight: CGFloat = 100
    /// スタンダード: the field after the plus, and the latest button centered
    /// on the screen, `jumpLift` (24pt) above it, sinking 57pt into it.
    static let fieldTop = barBottom - ChatMetrics.control
    static let jumpCenter = CGPoint(x: center, y: fieldTop - ChatMetrics.jumpGap - ChatMetrics.control / 2)
    static let jumpSink: CGFloat = ChatMetrics.jumpGap + ChatMetrics.control / 2 + ChatMotion.jumpSunkDepth
}

/// The lens, in the screen's points: a soft, well rounded window that the
/// composer lifts out into, larger, on the screen's colour. It grows out of
/// the composer's own place (`frame`), and the composer there gives way to
/// it, so the two are never in view at once. It takes nine tenths of the
/// screen's width, inside the screen, so neither phone's lens reaches the
/// other's; スマート's three buttons fit with room all round, スタンダード's
/// latest button and field with room above and below.
enum ComposerDemoLens {
    static let power: CGFloat = 1.6
    static let rect = CGRect(x: 21, y: 588, width: 360, height: 248)
    static let radius: CGFloat = 96
    /// スタンダード's field is wider than the view: its ends are gone this far
    /// inside the sides, fading in over the inner half, so it never meets
    /// the edge.
    static let fade: CGFloat = 40
    /// The screen's colour around the edge, so the quiet conversation never
    /// touches it.
    static let margin: CGFloat = 14

    /// Where its view centres: スタンダード's latest button and field
    /// together, スマート's three buttons.
    static func focus(_ style: ComposerStyle) -> CGPoint {
        typealias L = ComposerDemoLayout
        switch style {
        case .folding:
            return CGPoint(x: L.center, y: L.barBottom - ChatMetrics.morphButton / 2)
        case .classic:
            return CGPoint(x: L.center, y: (L.jumpCenter.y - ChatMetrics.control / 2 + L.barBottom) / 2)
        }
    }

    /// Where the lens is and how much it enlarges, `p` of the way out: at 0
    /// the composer's own place at its own size, at 1 `rect` at `power`. It
    /// shows the same piece of the composer all the way.
    static func frame(_ style: ComposerStyle, at p: CGFloat) -> (rect: CGRect, power: CGFloat) {
        let home = focus(style)
        let now = 1 + (power - 1) * p
        let size = CGSize(width: rect.width / power * now, height: rect.height / power * now)
        let center = CGPoint(x: home.x + (rect.midX - home.x) * p, y: home.y + (rect.midY - home.y) * p)
        return (CGRect(x: center.x - size.width / 2, y: center.y - size.height / 2,
                       width: size.width, height: size.height), now)
    }

    /// How far the lens has taken over from the composer in its place: soon
    /// after it starts, while the two are still nearly one.
    static func takeover(_ p: CGFloat) -> Double { Double(min(1, p * 6)) }
}

/// The conversation both phones show, a few plain shapes: replies as soft
/// blocks on the left, the user's turns as bubbles on the right, built
/// upward from the latest at 0, about three in view at a time.
private enum ComposerDemoConversation {
    enum Kind { case reply, ask }
    static let items: [(kind: Kind, rect: CGRect)] = {
        var items: [(kind: Kind, rect: CGRect)] = []
        var bottom: CGFloat = 0
        func reply(_ width: CGFloat, _ height: CGFloat) {
            items.append((kind: .reply, rect: CGRect(x: 24, y: bottom - height, width: width, height: height)))
            bottom -= height + 36
        }
        func ask(_ width: CGFloat) {
            items.append((kind: .ask, rect: CGRect(x: 378 - width, y: bottom - 84, width: width, height: 84)))
            bottom -= 84 + 36
        }
        reply(300, 220); ask(200); reply(272, 170); ask(168); reply(312, 230); ask(214)
        return items
    }()
}

/// Draws one moment on the phone, scaled to the size it is given.
struct ComposerDemoDrawing {
    let scene: ComposerDemoScene
    let palette: ComposerDemoPalette
    private typealias L = ComposerDemoLayout
    private typealias Morph = ComposerMorphPath

    func draw(in context: inout GraphicsContext, size: CGSize) {
        let scale = size.width / ComposerDemo.screen.width
        guard scale > 0 else { return }
        context.scaleBy(x: scale, y: scale)
        // Outlines three quarters of a point wide on the screen.
        let hair = 0.75 / scale
        var screen = context
        let shape = Path(roundedRect: CGRect(origin: .zero, size: ComposerDemo.screen),
                         cornerRadius: ComposerDemo.screenRadius, style: .continuous)
        screen.clip(to: shape)
        let first = ComposerDemoDrawing(scene: ComposerDemoScene(scene.style, at: 0), palette: palette)
        if scene.restart >= 1 {
            first.drawScreen(shape, in: &screen, hair: hair)
        } else {
            drawScreen(shape, in: &screen, hair: hair)
            if scene.restart > 0 {
                // The start drawn whole over this moment, faded in as one layer.
                var start = screen
                start.opacity = scene.restart
                start.drawLayer { layer in first.drawScreen(shape, in: &layer, hair: hair) }
            }
        }
    }

    /// The screen at this moment, the soft top edge it keeps, and the lens
    /// with its composer.
    private func drawScreen(_ shape: Path, in context: inout GraphicsContext, hair: CGFloat) {
        context.fill(shape, with: .color(palette.screen))
        // While the lens holds the composer, the conversation steps back.
        var chat = context
        chat.opacity *= 1 - palette.stepBack * Double(scene.lens)
        drawConversation(&chat)
        drawComposer(in: &context, hair: hair, shown: 1 - ComposerDemoLens.takeover(scene.lens))
        // Older messages go under the top of the screen past a short fade,
        // deep enough that no sliver of one rests at the top like a mark.
        context.fill(Path(CGRect(x: 0, y: 0, width: 402, height: 112)),
                     with: .linearGradient(Gradient(stops: [.init(color: palette.screen, location: 0),
                                                            .init(color: palette.screen, location: 0.6),
                                                            .init(color: palette.screen.opacity(0), location: 1)]),
                                           startPoint: .zero, endPoint: CGPoint(x: 0, y: 112)))
        if let finger = scene.finger { drawFinger(finger, in: &context) }
        if scene.lens > 0.001 { drawLens(in: &context, hair: hair) }
    }

    /// The conversation's soft edge under the bar (not in the lens), and the
    /// composer, `shown` of the way in, as one layer while it fades.
    private func drawComposer(in context: inout GraphicsContext, hair: CGFloat, shown: Double = 1,
                              chatEdge: Bool = true) {
        if chatEdge { feather(above: featherTop, in: &context) }
        guard shown > 0.001 else { return }
        guard shown < 0.999 else { return drawBar(in: &context, hair: hair) }
        var bar = context
        bar.opacity *= shown
        bar.drawLayer { layer in drawBar(in: &layer, hair: hair) }
    }

    private func drawBar(in context: inout GraphicsContext, hair: CGFloat) {
        switch scene.style {
        case .folding: drawFoldingComposer(&context, hair: hair)
        case .classic: drawClassicComposer(&context, hair: hair)
        }
    }

    /// The top of the bar the conversation fades under.
    private var featherTop: CGFloat {
        switch scene.style {
        case .folding:
            let flatten = Morph.flatten(min(1, max(0, scene.fold)))
            return L.barBottom - (L.panelHeight - (L.panelHeight - ChatMetrics.morphButton) * flatten)
        case .classic:
            return L.fieldTop
        }
    }

    /// The lens: the composer lifted out of its place and drawn larger on
    /// the screen's own colour, inside a soft rounded edge with a hairline
    /// and no shade or glow. It grows out of the composer's own place, so at
    /// first it is the composer itself, and goes back into it the same way.
    private func drawLens(in context: inout GraphicsContext, hair: CGFloat) {
        typealias Lens = ComposerDemoLens
        let p = scene.lens
        let (rect, power) = Lens.frame(scene.style, at: p)
        let edge = Path(roundedRect: rect, cornerRadius: Lens.radius / Lens.power * power, style: .continuous)
        let focus = Lens.focus(scene.style)
        var lens = context
        lens.opacity *= Lens.takeover(p)
        lens.drawLayer { layer in
            layer.stroke(edge, with: .color(palette.screen), lineWidth: 2 * Lens.margin * p)
            var inside = layer
            inside.clip(to: edge)
            inside.fill(edge, with: .color(palette.screen))
            var view = inside
            view.translateBy(x: rect.midX, y: rect.midY)
            view.scaleBy(x: power, y: power)
            view.translateBy(x: -focus.x, y: -focus.y)
            drawComposer(in: &view, hair: hair, chatEdge: false)
            if scene.style == .classic {
                let fade = Lens.fade / Lens.power * power
                let ends = Gradient(stops: [.init(color: palette.screen, location: 0),
                                            .init(color: palette.screen, location: 0.5),
                                            .init(color: palette.screen.opacity(0), location: 1)])
                for (side, inward) in [(rect.minX, rect.minX + fade), (rect.maxX, rect.maxX - fade)] {
                    inside.fill(Path(CGRect(x: min(side, inward), y: rect.minY, width: fade, height: rect.height)),
                                with: .linearGradient(ends, startPoint: CGPoint(x: side, y: 0),
                                                      endPoint: CGPoint(x: inward, y: 0)))
                }
            }
            var rim = layer
            rim.opacity *= Double(p)
            rim.stroke(edge, with: .color(palette.outline), lineWidth: hair * 4 / 3)
        }
    }

    private func drawConversation(_ context: inout GraphicsContext) {
        let end = (scene.style == .folding ? L.barBottom - L.panelHeight : L.fieldTop) - 24 + scene.scroll
        for item in ComposerDemoConversation.items {
            let rect = item.rect.offsetBy(dx: 0, dy: end)
            guard rect.maxY > 0, rect.minY < 874 else { continue }
            switch item.kind {
            case .reply:
                context.fill(Path(roundedRect: rect, cornerRadius: 30, style: .continuous), with: .color(palette.reply))
            case .ask:
                context.fill(Path(roundedRect: rect, cornerRadius: rect.height / 2, style: .continuous),
                             with: .color(palette.ask))
            }
        }
    }

    // MARK: スマート

    private func drawFoldingComposer(_ context: inout GraphicsContext, hair: CGFloat) {
        let p = scene.fold
        let bottom = L.barBottom
        let clamped = min(1, max(0, p))
        let flatten = Morph.flatten(clamped)

        // ComposerPanelMorph: the panel squeezed into a capsule that draws
        // in to the chat button.
        let width = 402 - 2 * L.gutter, height = L.panelHeight
        let stretch = Morph.stretch(clamped)
        let narrowed = width + (Morph.capsule - width) * Morph.narrow(clamped)
        let w = clamped > 0.0005 ? narrowed + (Morph.side - narrowed) * Morph.gatherIn(clamped) + 10 * stretch : width
        let h = clamped > 0.0005 ? height + (Morph.side - height) * flatten - 6 * stretch : height
        let radius = min(ChatMetrics.composerRadius + (Morph.side / 2 - ChatMetrics.composerRadius) * flatten, h / 2)
        var glassShape = Path(roundedRect: CGRect(x: L.center - w / 2, y: bottom - h, width: w, height: h),
                              cornerRadius: radius, style: .continuous)
        // ComposerButtonMorph: the voice and latest buttons travel out of
        // its ends, pulled thin while they part.
        if p > 0.0005 {
            let pull = Morph.stretch(p)
            let bw = Morph.side + 8 * pull, bh = Morph.side - 4 * pull
            let reach = Morph.outer(p) - 4 * pull
            for slot in [CGFloat(-1), 1] {
                let rect = CGRect(x: L.center + slot * reach - bw / 2, y: bottom - bh, width: bw, height: bh)
                glassShape = glassShape.union(Path(roundedRect: rect, cornerRadius: min(bw, bh) / 2, style: .continuous))
            }
        }
        glass(glassShape, in: &context, hair: hair)

        // The panel's placeholder and its row of controls, as plain shapes,
        // leave first.
        let content = 1 - Double(ChatMotion.step(0, 0.22, clamped))
        let row = 1 - Double(ChatMotion.step(0, 0.12, clamped))
        if content > 0 {
            var inside = context
            inside.opacity = content
            inside.fill(Path(roundedRect: CGRect(x: 29, y: bottom - height + 16.5, width: 104, height: 11), cornerRadius: 5.5),
                        with: .color(palette.placeholder))
        }
        if row > 0 {
            var controls = context
            controls.opacity = row
            let y = bottom - 30
            controls.fill(Path(ellipseIn: CGRect(x: 24, y: y - 18, width: 36, height: 36)), with: .color(palette.chip))
            controls.fill(Path(roundedRect: CGRect(x: 70, y: y - 18, width: 83, height: 36), cornerRadius: 18), with: .color(palette.chip))
            controls.fill(Path(roundedRect: CGRect(x: 165, y: y - 18, width: 64, height: 36), cornerRadius: 18), with: .color(palette.chip))
            controls.fill(Path(ellipseIn: CGRect(x: 342, y: y - 17, width: 34, height: 34)), with: .color(palette.chip))
        }
        // Each symbol arrives as its drop takes shape.
        let y = bottom - ChatMetrics.morphButton / 2
        let outer = Double(ChatMotion.step(0.8, 0.98, p)), middle = Double(ChatMotion.step(0.62, 0.86, p))
        let reach = Morph.outer(p) - 4 * Morph.stretch(p)
        symbol(.voice, at: CGPoint(x: L.center - reach, y: y), scale: 0.6 + 0.4 * outer, opacity: outer, in: &context)
        symbol(.chat, at: CGPoint(x: L.center, y: y), scale: 0.6 + 0.4 * middle, opacity: middle, in: &context)
        symbol(.latest, at: CGPoint(x: L.center + reach, y: y), scale: 0.6 + 0.4 * outer, opacity: outer, in: &context)
    }

    // MARK: スタンダード

    private func drawClassicComposer(_ context: inout GraphicsContext, hair: CGFloat) {
        let y = L.barBottom - ChatMetrics.control / 2
        // The plus has a glass of its own; the field shares its with the
        // latest button that rises out of it.
        glass(Path(ellipseIn: CGRect(x: L.gutter, y: L.fieldTop, width: ChatMetrics.control, height: ChatMetrics.control)),
              in: &context, hair: hair)
        symbol(.plus, at: CGPoint(x: L.gutter + ChatMetrics.control / 2, y: y), in: &context)
        let fieldX = L.gutter + ChatMetrics.control + ChatMetrics.controlGap
        var glassShape = Path(roundedRect: CGRect(x: fieldX, y: L.fieldTop, width: 402 - L.gutter - fieldX,
                                                  height: ChatMetrics.control),
                              cornerRadius: ChatMetrics.control / 2, style: .continuous)
        var jumpAt: CGPoint?
        if let jump = scene.jump {
            // JumpSink: scaled about its center and moved down into the field.
            let scale = ChatMotion.jumpSunkScale + (1 - ChatMotion.jumpSunkScale) * jump.rise
            let center = CGPoint(x: L.jumpCenter.x, y: L.jumpCenter.y + L.jumpSink * (1 - jump.rise))
            let radius = ChatMetrics.control / 2 * scale
            glassShape = glassShape.union(Path(ellipseIn: CGRect(x: center.x - radius, y: center.y - radius,
                                                                 width: 2 * radius, height: 2 * radius)))
            jumpAt = center
        }
        glass(glassShape, in: &context, hair: hair)
        context.fill(Path(roundedRect: CGRect(x: fieldX + 15, y: y - 5.5, width: 104, height: 11), cornerRadius: 5.5),
                     with: .color(palette.placeholder))
        context.fill(Path(ellipseIn: CGRect(x: 353, y: y - 15, width: 30, height: 30)), with: .color(palette.chip))
        if let jump = scene.jump, let jumpAt {
            symbol(.jump, at: jumpAt, scale: 0.5 + 0.5 * jump.arrow, opacity: Double(jump.arrow), in: &context)
        }
    }

    // MARK: Pieces

    /// The bottom of the conversation fades under the bar, as in the chat.
    private func feather(above top: CGFloat, in context: inout GraphicsContext) {
        let from = top - 36
        context.fill(Path(CGRect(x: 0, y: from, width: 402, height: 874 - from)),
                     with: .linearGradient(Gradient(stops: [.init(color: palette.screen.opacity(0), location: 0),
                                                            .init(color: palette.screen.opacity(0.94), location: 48 / (874 - from)),
                                                            .init(color: palette.screen.opacity(0.94), location: 1)]),
                                           startPoint: CGPoint(x: 0, y: from), endPoint: CGPoint(x: 0, y: 874)))
    }

    /// A control's glass, flat: a fill a shade off the screen and a hairline
    /// edge.
    private func glass(_ shape: Path, in context: inout GraphicsContext, hair: CGFloat) {
        context.fill(shape, with: .color(palette.glass))
        context.stroke(shape, with: .color(palette.rim), lineWidth: hair)
    }

    private func symbol(_ symbol: ComposerDemoSymbol, at point: CGPoint, scale: CGFloat = 1, opacity: Double = 1,
                        in context: inout GraphicsContext) {
        guard opacity > 0.001, let resolved = context.resolveSymbol(id: symbol) else { return }
        var mark = context
        mark.opacity *= opacity
        mark.translateBy(x: point.x, y: point.y)
        mark.scaleBy(x: scale, y: scale)
        mark.draw(resolved, at: .zero, anchor: .center)
    }

    /// A fingertip, and the short way it has come fading out behind it.
    private func drawFinger(_ finger: ComposerDemoScene.Finger, in context: inout GraphicsContext) {
        guard finger.opacity > 0.001 else { return }
        var touch = context
        touch.opacity *= finger.opacity
        let radius = 31 * finger.scale
        if finger.trail > 1 {
            let trail = CGRect(x: finger.at.x - 31, y: finger.at.y - finger.trail, width: 62, height: finger.trail)
            touch.fill(Path(roundedRect: trail, cornerRadius: min(31, trail.height / 2)),
                       with: .linearGradient(Gradient(colors: [palette.finger.opacity(0), palette.finger.opacity(0.5)]),
                                             startPoint: CGPoint(x: 0, y: trail.minY), endPoint: CGPoint(x: 0, y: trail.maxY)))
        }
        let disc = Path(ellipseIn: CGRect(x: finger.at.x - radius, y: finger.at.y - radius, width: 2 * radius, height: 2 * radius))
        touch.fill(disc, with: .color(palette.finger))
        touch.stroke(disc, with: .color(palette.fingerRim), lineWidth: 3)
    }
}
