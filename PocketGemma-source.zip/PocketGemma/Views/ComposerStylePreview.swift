import SwiftUI

/// 入力欄のタイプ's two choices as small line drawings of an iPhone, as in
/// iOS's own Tips, each playing what its composer does when older messages
/// are read, side by side on one clock (user, 2026-10-24: キーボード設定の
/// アニメーションプレビュー; simplified the same day in 「キーボードと入力
/// UI改善・名称変更指示書」). A finger draws a short conversation down;
/// スタンダード's field stays as it is and the latest button rises out of
/// it, スマート's panel splits into the voice, chat and latest buttons; both
/// hold a moment and fade back to their start together. The composer's
/// motion is its own, drawn small and flat: ChatView's places and sizes,
/// the fold's path (ComposerMorphPath) and ChatMotion's springs. A tap on a
/// phone chooses its type. It plays only while the page is in view and at
/// rest, so a page slide or a scroll never shares its frames with it; with
/// Reduce Motion each phone holds the moment that tells the two apart.
struct ComposerStylePicker: View {
    @Binding var selection: ComposerStyle
    @Environment(\.settingsPageInView) private var pageInView
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion
    @Environment(\.chatPreviewReduceMotion) private var previewReduceMotion
    @State private var onScreen = true
    @State private var clock = ComposerDemoClock()
    #if POCKET_PREVIEW
    @State private var demoOver = false
    #endif

    private var reduceMotion: Bool { systemReduceMotion || previewReduceMotion }
    private var playing: Bool {
        pageInView && onScreen && scenePhase == .active && !reduceMotion && plays
    }

    var body: some View {
        HStack(alignment: .top, spacing: 20) {
            ForEach(ComposerDemo.order) { style in option(style) }
        }
        .frame(maxWidth: .infinity)
        .onScrollVisibilityChange(threshold: 0.1) { onScreen = $0 }
        .onChange(of: playing, initial: true) { _, playing in clock.set(playing: playing) }
        .task { await endDemo() }
    }

    #if POCKET_PREVIEW
    private var plays: Bool { ComposerDemo.plays && !demoOver }
    /// About two loops, then back to the start and still, so the UI check
    /// can ask the page things again.
    private func endDemo() async {
        guard ComposerDemo.plays else { return }
        do { try await Task.sleep(for: .seconds(14)) } catch { return }
        clock.reset()
        demoOver = true
    }
    #else
    private var plays: Bool { true }
    private func endDemo() async {}
    #endif

    private func option(_ style: ComposerStyle) -> some View {
        let selected = selection == style
        return Button {
            guard selection != style else { return }
            withAnimation(.smooth(duration: 0.3)) { selection = style }
        } label: {
            VStack(spacing: 10) {
                ComposerDemoPhone(style: style, clock: clock, playing: playing, still: reduceMotion)
                Text(style.title)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.primary)
                // As iOS's own choice of appearance: a filled check under
                // the chosen one, an empty ring under the other.
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 22))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(selected ? Color.white : Color(uiColor: .tertiaryLabel), Theme.accent)
                    .contentTransition(.symbolEffect(.replace))
            }
            .frame(maxWidth: 136)
            .contentShape(Rectangle())
        }
        .buttonStyle(ComposerStyleOptionStyle())
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(style.title)
        .accessibilityHint(style.previewHint)
        .accessibilityAddTraits(selected ? [.isButton, .isSelected] : .isButton)
        .accessibilityIdentifier("composer-style-\(style.rawValue)")
    }
}

extension ComposerStyle {
    /// What the phone shows, for VoiceOver.
    var previewHint: String {
        switch self {
        case .folding:
            "ボタンの列がある広い入力欄です。前のメッセージへスクロールすると、音声入力・入力欄を開く・最新へ移動の3つの丸いボタンに分かれます。"
        case .classic:
            "＋ボタンと細い入力欄です。前のメッセージへスクロールしても入力欄はそのままで、上に最新へ移動のボタンが出ます。"
        }
    }
}

/// Pressed, the phone and its name give a little, as a card does.
private struct ComposerStyleOptionStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(duration: 0.25, bounce: 0.2), value: configuration.isPressed)
    }
}

enum ComposerDemo {
    /// The screen drawn, in its own points (a 6.3-inch iPhone, where the
    /// composer's places were measured).
    static let screen = CGSize(width: 402, height: 874)
    static let screenRadius: CGFloat = 55
    static let loop: TimeInterval = 5
    /// スタンダード first, as the user's directive numbers them.
    static let order: [ComposerStyle] = [.classic, .folding]
    #if POCKET_PREVIEW
    /// UI checks ask the page things, and XCUITest waits for an app's
    /// animations to end before each question; the phones hold still there
    /// unless a check comes to watch them.
    static let plays = PreviewProbe.on("--keyboard-preview-demo")
    #else
    static let plays = true
    #endif
}

/// The two phones' one time, read on each of their frames (not view state).
/// Paused, it holds where it was; it starts at the beginning of the loop.
@MainActor final class ComposerDemoClock {
    private var start: Date?
    private var held: TimeInterval = 0
    func set(playing: Bool) {
        if playing, start == nil { start = Date(timeIntervalSinceNow: -held) }
        if !playing, let start {
            held = Date().timeIntervalSince(start)
            self.start = nil
        }
    }
    func time(at date: Date) -> TimeInterval {
        guard let start else { return held }
        return max(0, date.timeIntervalSince(start))
    }
    #if POCKET_PREVIEW
    func reset() { start = nil; held = 0 }
    #endif
}

/// One phone: a Canvas redrawn on the display's beat while it plays, and
/// nothing at all while it does not. Its outline is a thin line drawn apart
/// from the Canvas, so the frames never redraw it.
private struct ComposerDemoPhone: View {
    let style: ComposerStyle
    let clock: ComposerDemoClock
    let playing: Bool
    let still: Bool
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let palette = ComposerDemoPalette(scheme)
        TimelineView(.animation(minimumInterval: nil, paused: !playing)) { context in
            let scene = still ? ComposerDemoScene.still(style) : ComposerDemoScene(style, at: clock.time(at: context.date))
            Canvas { ctx, size in
                ComposerDemoDrawing(scene: scene, palette: palette).draw(in: &ctx, size: size)
            } symbols: {
                ForEach(ComposerDemoSymbol.allCases, id: \.self) { symbol in
                    Image(systemName: symbol.name)
                        .font(.system(size: symbol.size, weight: .medium))
                        .foregroundStyle(palette.symbol)
                        .tag(symbol)
                }
            }
        }
        .aspectRatio(ComposerDemo.screen.width / ComposerDemo.screen.height, contentMode: .fit)
        .overlay {
            ComposerDemoScreenShape().strokeBorder(palette.outline, lineWidth: 1)
        }
        .accessibilityHidden(true)
    }
}

/// The screen's outline at any size, its corners scaled with it.
struct ComposerDemoScreenShape: InsettableShape {
    var inset: CGFloat = 0

    func path(in rect: CGRect) -> Path {
        let radius = ComposerDemo.screenRadius * rect.width / ComposerDemo.screen.width
        return Path(roundedRect: rect.insetBy(dx: inset, dy: inset), cornerRadius: max(0, radius - inset),
                    style: .continuous)
    }

    func inset(by amount: CGFloat) -> ComposerDemoScreenShape {
        var shape = self
        shape.inset += amount
        return shape
    }
}

/// The few symbols the phones draw: スタンダード's plus and latest button,
/// スマート's three buttons, at the composer's sizes in the screen's points
/// a quarter larger, so they still read on the small screen.
enum ComposerDemoSymbol: String, CaseIterable {
    case plus, voice, chat, latest, jump

    var name: String {
        switch self {
        case .plus: "plus"
        case .voice: "waveform"
        case .chat: "message"
        case .latest, .jump: "arrow.down"
        }
    }
    var size: CGFloat {
        switch self {
        case .plus: 21
        case .voice, .chat: 24
        case .latest: 20
        case .jump: 25
        }
    }
}

/// Monochrome, as the drawings in iOS's own Tips: greys of the screen's
/// light or dark, the composer's glass a shade off the screen with a
/// hairline edge.
struct ComposerDemoPalette {
    let screen, outline, island, reply, ask, glass, rim, chip, placeholder, symbol, finger, fingerRim: Color

    init(_ scheme: ColorScheme) {
        if scheme == .dark {
            screen = .black; outline = Color.white.opacity(0.3); island = Color(white: 0.3)
            reply = Color(white: 0.15); ask = Color(white: 0.32)
            glass = Color(white: 0.12); rim = Color(white: 0.3); chip = Color(white: 0.22)
            placeholder = Color(white: 0.3); symbol = Color(white: 0.85)
            finger = Color(white: 0.92).opacity(0.36); fingerRim = Color.white.opacity(0.6)
        } else {
            screen = .white; outline = Color.black.opacity(0.2); island = Color(white: 0.18)
            reply = Color(white: 0.93); ask = Color(white: 0.8)
            glass = Color(white: 0.955); rim = Color(white: 0.78); chip = Color(white: 0.89)
            placeholder = Color(white: 0.8); symbol = Color(white: 0.3)
            finger = Color(white: 0.3).opacity(0.38); fingerRim = Color.white.opacity(0.9)
        }
    }
}

/// Where everything is at one moment of the loop, in the screen's points.
struct ComposerDemoScene {
    struct Finger {
        var at: CGPoint
        var scale: CGFloat = 1
        var opacity: Double = 1
        /// The way it came, fading out behind it.
        var trail: CGFloat = 0
    }

    let style: ComposerStyle
    /// How far the conversation has been drawn down toward older messages.
    var scroll: CGFloat = 0
    var finger: Finger?
    /// スマート: the fold's progress (ComposerMorphPath).
    var fold: CGFloat = 0
    /// スタンダード: the latest button out of the field (0 sunk in it, 1 in
    /// its place) and its arrow, while it is there at all.
    var jump: (rise: CGFloat, arrow: CGFloat)?
    /// How far the loop's start has faded in over this moment.
    var restart: Double = 0

    init(style: ComposerStyle) { self.style = style }

    init(_ style: ComposerStyle, at elapsed: TimeInterval) {
        typealias Beat = ComposerDemoBeat
        self.style = style
        let t = elapsed.truncatingRemainder(dividingBy: ComposerDemo.loop)
        scroll = Beat.drag(t)
        finger = Beat.finger(at: t)
        restart = Beat.restart(at: t)
        switch style {
        case .folding: fold = Beat.fold(at: t)
        case .classic: jump = Beat.jump(at: t)
        }
    }

    /// With Reduce Motion: the conversation drawn down, and what each type
    /// shows then, with the finger's way.
    static func still(_ style: ComposerStyle) -> ComposerDemoScene {
        var scene = ComposerDemoScene(style: style)
        scene.scroll = ComposerDemoBeat.travel
        scene.finger = Finger(at: ComposerDemoBeat.dragEnd, opacity: 0.9, trail: ComposerDemoBeat.travel * 0.6)
        switch style {
        case .folding: scene.fold = 1
        case .classic: scene.jump = (1, 1)
        }
        return scene
    }
}

/// The loop's timing, the same for both phones, and the composer's own
/// motion along it (seconds from the loop's start): at rest, a finger draws
/// the conversation down and lifts, the change holds, and both fade back to
/// their start.
enum ComposerDemoBeat {
    static let fingerIn: TimeInterval = 0.7
    static let dragStart: TimeInterval = 0.9
    static let dragLength: TimeInterval = 1
    static let liftLength: TimeInterval = 0.25
    static let travel: CGFloat = 250
    static let dragFrom = CGPoint(x: 236, y: 330)
    static var dragEnd: CGPoint { CGPoint(x: dragFrom.x, y: dragFrom.y + travel) }
    static let restartFrom: TimeInterval = 4.1
    static let restartLength: TimeInterval = 0.6

    /// ChatMotion.composerFold and jumpRise.
    static let foldSpring = Spring(duration: 0.75, bounce: 0.12)
    static let riseSpring = Spring(duration: 0.42, bounce: 0.18)

    /// スマート folds once the drag has gone far enough with the end far
    /// enough below (ComposerFoldObserver, from the end: the larger of the
    /// two); スタンダード's latest button shows past 32pt from the end
    /// (ChatScrollPolicy).
    static let foldsAt = time(atTravel: max(ChatMetrics.collapseTravel, ChatMetrics.collapseDistance))
    static let risesAt = time(atTravel: 32)

    static func drag(_ t: TimeInterval) -> CGFloat {
        travel * CGFloat(UnitCurve.easeInOut.value(at: clamp((t - dragStart) / dragLength)))
    }

    private static func time(atTravel distance: CGFloat) -> TimeInterval {
        var low = 0.0, high = 1.0
        for _ in 0..<32 {
            let middle = (low + high) / 2
            if travel * CGFloat(UnitCurve.easeInOut.value(at: middle)) < distance { low = middle } else { high = middle }
        }
        return dragStart + high * dragLength
    }

    static func fold(at t: TimeInterval) -> CGFloat {
        t < foldsAt ? 0 : value(foldSpring, t - foldsAt)
    }

    /// ChatView.setJumpVisible: mounted sunk in the field, raised 16ms on,
    /// its arrow 150ms after that.
    static func jump(at t: TimeInterval) -> (rise: CGFloat, arrow: CGFloat)? {
        guard t >= risesAt else { return nil }
        let raisedAt = risesAt + 0.016
        return (value(riseSpring, t - raisedAt), CGFloat(UnitCurve.easeOut.value(at: clamp((t - raisedAt - 0.15) / 0.16))))
    }

    static func restart(at t: TimeInterval) -> Double {
        ease((t - restartFrom) / restartLength)
    }

    static func finger(at t: TimeInterval) -> ComposerDemoScene.Finger? {
        guard t >= fingerIn, t < dragStart + dragLength + liftLength else { return nil }
        let appear = ease((t - fingerIn) / 0.18)
        let down = ease((t - dragStart + 0.08) / 0.08)
        let lift = ease((t - dragStart - dragLength) / liftLength)
        let drawn = drag(t)
        return .init(at: CGPoint(x: dragFrom.x, y: dragFrom.y + drawn),
                     scale: 1.15 - 0.15 * appear - 0.06 * down + 0.2 * lift, opacity: appear * (1 - lift),
                     trail: min(drawn, 110) * CGFloat(1 - lift))
    }

    private static func value(_ spring: Spring, _ time: TimeInterval) -> CGFloat {
        time <= 0 ? 0 : CGFloat(spring.value(target: 1.0, time: time))
    }
    private static func clamp(_ x: Double) -> Double { min(1, max(0, x)) }
    private static func ease(_ x: Double) -> Double { UnitCurve.easeInOut.value(at: clamp(x)) }
}

/// ChatView's places on the screen the phones stand for, in its points:
/// a 12pt gutter, the bar 6pt above the 34pt home area.
enum ComposerDemoLayout {
    static let center: CGFloat = 201
    static let gutter = ChatMetrics.gutter
    static let barBottom: CGFloat = 874 - 34 - 6
    static let panelHeight: CGFloat = 100
    /// スタンダード: the field after the plus, and the latest button centered
    /// on the screen, `jumpLift` (24pt) above it, sinking 57pt into it.
    static let fieldTop = barBottom - ChatMetrics.control
    static let jumpCenter = CGPoint(x: center, y: fieldTop - ChatMetrics.jumpGap - ChatMetrics.control / 2)
    static let jumpSink: CGFloat = ChatMetrics.jumpGap + ChatMetrics.control / 2 + ChatMotion.jumpSunkDepth
}

/// The conversation both phones show, a few plain shapes: replies as soft
/// blocks on the left, the user's turns as bubbles on the right, built
/// upward from the latest at 0, about three in view at a time.
private enum ComposerDemoConversation {
    enum Kind { case reply, ask }
    static let items: [(kind: Kind, rect: CGRect)] = {
        var items: [(kind: Kind, rect: CGRect)] = []
        var bottom: CGFloat = 0
        func reply(_ width: CGFloat, _ height: CGFloat) {
            items.append((kind: .reply, rect: CGRect(x: 24, y: bottom - height, width: width, height: height)))
            bottom -= height + 36
        }
        func ask(_ width: CGFloat) {
            items.append((kind: .ask, rect: CGRect(x: 378 - width, y: bottom - 84, width: width, height: 84)))
            bottom -= 84 + 36
        }
        reply(300, 220); ask(200); reply(272, 170); ask(168); reply(312, 230); ask(214)
        return items
    }()
}

/// Draws one moment on the phone, scaled to the size it is given.
struct ComposerDemoDrawing {
    let scene: ComposerDemoScene
    let palette: ComposerDemoPalette
    private typealias L = ComposerDemoLayout
    private typealias Morph = ComposerMorphPath

    func draw(in context: inout GraphicsContext, size: CGSize) {
        let scale = size.width / ComposerDemo.screen.width
        guard scale > 0 else { return }
        context.scaleBy(x: scale, y: scale)
        // Outlines three quarters of a point wide on the screen.
        let hair = 0.75 / scale
        var screen = context
        let shape = Path(roundedRect: CGRect(origin: .zero, size: ComposerDemo.screen),
                         cornerRadius: ComposerDemo.screenRadius, style: .continuous)
        screen.clip(to: shape)
        let first = ComposerDemoDrawing(scene: ComposerDemoScene(scene.style, at: 0), palette: palette)
        if scene.restart >= 1 {
            first.drawScreen(shape, in: &screen, hair: hair)
        } else {
            drawScreen(shape, in: &screen, hair: hair)
            if scene.restart > 0 {
                // The start drawn whole over this moment, faded in as one layer.
                var start = screen
                start.opacity = scene.restart
                start.drawLayer { layer in first.drawScreen(shape, in: &layer, hair: hair) }
            }
        }
        // The Dynamic Island, the one mark of the phone inside its outline.
        screen.fill(Path(roundedRect: CGRect(x: 138, y: 11, width: 126, height: 37), cornerRadius: 18.5),
                    with: .color(palette.island))
    }

    private func drawScreen(_ shape: Path, in context: inout GraphicsContext, hair: CGFloat) {
        context.fill(shape, with: .color(palette.screen))
        drawConversation(&context)
        switch scene.style {
        case .folding: drawFoldingComposer(&context, hair: hair)
        case .classic: drawClassicComposer(&context, hair: hair)
        }
        if let finger = scene.finger { drawFinger(finger, in: &context) }
    }

    private func drawConversation(_ context: inout GraphicsContext) {
        let end = (scene.style == .folding ? L.barBottom - L.panelHeight : L.fieldTop) - 24 + scene.scroll
        for item in ComposerDemoConversation.items {
            let rect = item.rect.offsetBy(dx: 0, dy: end)
            guard rect.maxY > 0, rect.minY < 874 else { continue }
            switch item.kind {
            case .reply:
                context.fill(Path(roundedRect: rect, cornerRadius: 30, style: .continuous), with: .color(palette.reply))
            case .ask:
                context.fill(Path(roundedRect: rect, cornerRadius: rect.height / 2, style: .continuous),
                             with: .color(palette.ask))
            }
        }
        // Older messages go under the top of the screen, past a short fade
        // below the island.
        context.fill(Path(CGRect(x: 0, y: 0, width: 402, height: 104)),
                     with: .linearGradient(Gradient(stops: [.init(color: palette.screen, location: 0),
                                                            .init(color: palette.screen, location: 0.6),
                                                            .init(color: palette.screen.opacity(0), location: 1)]),
                                           startPoint: .zero, endPoint: CGPoint(x: 0, y: 104)))
    }

    // MARK: スマート

    private func drawFoldingComposer(_ context: inout GraphicsContext, hair: CGFloat) {
        let p = scene.fold
        let bottom = L.barBottom
        let clamped = min(1, max(0, p))
        let flatten = Morph.flatten(clamped)
        feather(above: bottom - (L.panelHeight - (L.panelHeight - ChatMetrics.morphButton) * flatten), in: &context)

        // ComposerPanelMorph: the panel squeezed into a capsule that draws
        // in to the chat button.
        let width = 402 - 2 * L.gutter, height = L.panelHeight
        let stretch = Morph.stretch(clamped)
        let narrowed = width + (Morph.capsule - width) * Morph.narrow(clamped)
        let w = clamped > 0.0005 ? narrowed + (Morph.side - narrowed) * Morph.gatherIn(clamped) + 10 * stretch : width
        let h = clamped > 0.0005 ? height + (Morph.side - height) * flatten - 6 * stretch : height
        let radius = min(ChatMetrics.composerRadius + (Morph.side / 2 - ChatMetrics.composerRadius) * flatten, h / 2)
        var glassShape = Path(roundedRect: CGRect(x: L.center - w / 2, y: bottom - h, width: w, height: h),
                              cornerRadius: radius, style: .continuous)
        // ComposerButtonMorph: the voice and latest buttons travel out of
        // its ends, pulled thin while they part.
        if p > 0.0005 {
            let pull = Morph.stretch(p)
            let bw = Morph.side + 8 * pull, bh = Morph.side - 4 * pull
            let reach = Morph.outer(p) - 4 * pull
            for slot in [CGFloat(-1), 1] {
                let rect = CGRect(x: L.center + slot * reach - bw / 2, y: bottom - bh, width: bw, height: bh)
                glassShape = glassShape.union(Path(roundedRect: rect, cornerRadius: min(bw, bh) / 2, style: .continuous))
            }
        }
        glass(glassShape, in: &context, hair: hair)

        // The panel's placeholder and its row of controls, as plain shapes,
        // leave first.
        let content = 1 - Double(ChatMotion.step(0, 0.22, clamped))
        let row = 1 - Double(ChatMotion.step(0, 0.12, clamped))
        if content > 0 {
            var inside = context
            inside.opacity = content
            inside.fill(Path(roundedRect: CGRect(x: 29, y: bottom - height + 16.5, width: 104, height: 11), cornerRadius: 5.5),
                        with: .color(palette.placeholder))
        }
        if row > 0 {
            var controls = context
            controls.opacity = row
            let y = bottom - 30
            controls.fill(Path(ellipseIn: CGRect(x: 24, y: y - 18, width: 36, height: 36)), with: .color(palette.chip))
            controls.fill(Path(roundedRect: CGRect(x: 70, y: y - 18, width: 83, height: 36), cornerRadius: 18), with: .color(palette.chip))
            controls.fill(Path(roundedRect: CGRect(x: 165, y: y - 18, width: 64, height: 36), cornerRadius: 18), with: .color(palette.chip))
            controls.fill(Path(ellipseIn: CGRect(x: 342, y: y - 17, width: 34, height: 34)), with: .color(palette.chip))
        }
        // Each symbol arrives as its drop takes shape.
        let y = bottom - ChatMetrics.morphButton / 2
        let outer = Double(ChatMotion.step(0.8, 0.98, p)), middle = Double(ChatMotion.step(0.62, 0.86, p))
        let reach = Morph.outer(p) - 4 * Morph.stretch(p)
        symbol(.voice, at: CGPoint(x: L.center - reach, y: y), scale: 0.6 + 0.4 * outer, opacity: outer, in: &context)
        symbol(.chat, at: CGPoint(x: L.center, y: y), scale: 0.6 + 0.4 * middle, opacity: middle, in: &context)
        symbol(.latest, at: CGPoint(x: L.center + reach, y: y), scale: 0.6 + 0.4 * outer, opacity: outer, in: &context)
    }

    // MARK: スタンダード

    private func drawClassicComposer(_ context: inout GraphicsContext, hair: CGFloat) {
        feather(above: L.fieldTop, in: &context)
        let y = L.barBottom - ChatMetrics.control / 2
        // The plus has a glass of its own; the field shares its with the
        // latest button that rises out of it.
        glass(Path(ellipseIn: CGRect(x: L.gutter, y: L.fieldTop, width: ChatMetrics.control, height: ChatMetrics.control)),
              in: &context, hair: hair)
        symbol(.plus, at: CGPoint(x: L.gutter + ChatMetrics.control / 2, y: y), in: &context)
        let fieldX = L.gutter + ChatMetrics.control + ChatMetrics.controlGap
        var glassShape = Path(roundedRect: CGRect(x: fieldX, y: L.fieldTop, width: 402 - L.gutter - fieldX,
                                                  height: ChatMetrics.control),
                              cornerRadius: ChatMetrics.control / 2, style: .continuous)
        var jumpAt: CGPoint?
        if let jump = scene.jump {
            // JumpSink: scaled about its center and moved down into the field.
            let scale = ChatMotion.jumpSunkScale + (1 - ChatMotion.jumpSunkScale) * jump.rise
            let center = CGPoint(x: L.jumpCenter.x, y: L.jumpCenter.y + L.jumpSink * (1 - jump.rise))
            let radius = ChatMetrics.control / 2 * scale
            glassShape = glassShape.union(Path(ellipseIn: CGRect(x: center.x - radius, y: center.y - radius,
                                                                 width: 2 * radius, height: 2 * radius)))
            jumpAt = center
        }
        glass(glassShape, in: &context, hair: hair)
        context.fill(Path(roundedRect: CGRect(x: fieldX + 15, y: y - 5.5, width: 104, height: 11), cornerRadius: 5.5),
                     with: .color(palette.placeholder))
        context.fill(Path(ellipseIn: CGRect(x: 353, y: y - 15, width: 30, height: 30)), with: .color(palette.chip))
        if let jump = scene.jump, let jumpAt {
            symbol(.jump, at: jumpAt, scale: 0.5 + 0.5 * jump.arrow, opacity: Double(jump.arrow), in: &context)
        }
    }

    // MARK: Pieces

    /// The bottom of the conversation fades under the bar, as in the chat.
    private func feather(above top: CGFloat, in context: inout GraphicsContext) {
        let from = top - 36
        context.fill(Path(CGRect(x: 0, y: from, width: 402, height: 874 - from)),
                     with: .linearGradient(Gradient(stops: [.init(color: palette.screen.opacity(0), location: 0),
                                                            .init(color: palette.screen.opacity(0.94), location: 48 / (874 - from)),
                                                            .init(color: palette.screen.opacity(0.94), location: 1)]),
                                           startPoint: CGPoint(x: 0, y: from), endPoint: CGPoint(x: 0, y: 874)))
    }

    /// A control's glass, flat: a fill a shade off the screen and a hairline
    /// edge.
    private func glass(_ shape: Path, in context: inout GraphicsContext, hair: CGFloat) {
        context.fill(shape, with: .color(palette.glass))
        context.stroke(shape, with: .color(palette.rim), lineWidth: hair)
    }

    private func symbol(_ symbol: ComposerDemoSymbol, at point: CGPoint, scale: CGFloat = 1, opacity: Double = 1,
                        in context: inout GraphicsContext) {
        guard opacity > 0.001, let resolved = context.resolveSymbol(id: symbol) else { return }
        var mark = context
        mark.opacity *= opacity
        mark.translateBy(x: point.x, y: point.y)
        mark.scaleBy(x: scale, y: scale)
        mark.draw(resolved, at: .zero, anchor: .center)
    }

    /// A fingertip, and the short way it has come fading out behind it.
    private func drawFinger(_ finger: ComposerDemoScene.Finger, in context: inout GraphicsContext) {
        guard finger.opacity > 0.001 else { return }
        var touch = context
        touch.opacity *= finger.opacity
        let radius = 31 * finger.scale
        if finger.trail > 1 {
            let trail = CGRect(x: finger.at.x - 31, y: finger.at.y - finger.trail, width: 62, height: finger.trail)
            touch.fill(Path(roundedRect: trail, cornerRadius: min(31, trail.height / 2)),
                       with: .linearGradient(Gradient(colors: [palette.finger.opacity(0), palette.finger.opacity(0.5)]),
                                             startPoint: CGPoint(x: 0, y: trail.minY), endPoint: CGPoint(x: 0, y: trail.maxY)))
        }
        let disc = Path(ellipseIn: CGRect(x: finger.at.x - radius, y: finger.at.y - radius, width: 2 * radius, height: 2 * radius))
        touch.fill(disc, with: .color(palette.finger))
        touch.stroke(disc, with: .color(palette.fingerRim), lineWidth: 3)
    }
}
