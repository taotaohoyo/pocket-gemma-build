import SwiftUI
import PocketCore

/// The developer GPU start test (GPUStartTest): Qwen once on the GPU at a
/// chosen precision, one fixed question, its GPU messages in the diagnostics.
struct GPUStartTestView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @State private var modelID = ModelSpec.qwen3.id
    @State private var precision = GPUPrecision.modelDefault
    @State private var running = false
    @State private var result = ""
    /// One test per launch (ChatStore.gpuStartTestRan).
    private var testedThisLaunch: Bool {
        #if POCKET_PREVIEW
        return false
        #else
        return chats.gpuStartTestRan
        #endif
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Qwenを1回だけGPUで起動し、決まった質問「\(GPUStartTest.question)」に答えさせます。会話履歴と保存済みの設定は変えません。現在のAIのメモリを解放してから実行します。")
                        .font(.caption).foregroundStyle(.secondary)
                    Picker("モデル", selection: $modelID) {
                        Text("Qwen3 0.6B").tag(ModelSpec.qwen3.id)
                        Text("Qwen2.5 1.5B（比較用）").tag(ModelSpec.qwen25.id)
                    }.accessibilityIdentifier("gpu-test-model")
                    Picker("GPUの計算精度", selection: $precision) {
                        ForEach(GPUPrecision.allCases) { Text($0.title).tag($0) }
                    }.accessibilityIdentifier("gpu-test-precision")
                    Text("指定なしは1.0.104と同じ起動で、精度をランタイムとモデルファイルに任せます。GPUのメッセージと、各段階の時間・メモリ・アドレス空間を端末内の診断に記録します。")
                        .font(.caption).foregroundStyle(.secondary)
                }.disabled(running).fieluaFormSection()
                Section {
                    Text(testedThisLaunch
                         ? "この起動では試験済みです。正しく比べるため、アプリを完全に終了して開き直してから次の試験を実行してください。"
                         : "アプリを開き直した直後に、1回ずつ試してください。失敗した起動はメモリ領域を残すことがあり、次の試験やチャットに影響します。")
                        .font(.caption).foregroundStyle(testedThisLaunch ? HierarchicalShapeStyle.primary : HierarchicalShapeStyle.secondary)
                    Button(running ? "GPUで起動しています…" : "この設定で1回試す") { run() }
                        .disabled(running || chats.isGenerating || testedThisLaunch).accessibilityIdentifier("run-gpu-test")
                    if running { ProgressView() }
                    if !result.isEmpty { Text(result).font(.subheadline).textSelection(.enabled) }
                    ShareLink(item: InferenceDiagnostic.historyURL) { Label("比較結果と診断を共有", systemImage: "square.and.arrow.up") }
                }.fieluaFormSection()
            }
            .fieluaForm()
            .navigationTitle("GPU起動テスト").navigationBarTitleDisplayMode(.inline)
            // The cross every sheet closes with (「完了」 in words before 1.1.0 (263)).
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("閉じる", systemImage: "xmark", role: .close) { dismiss() }.disabled(running) } }
        }.interactiveDismissDisabled(running)
    }
    private func run() {
        #if POCKET_PREVIEW
        result = "UI検証用アプリではネイティブ推論を実行しません。"
        #else
        guard let spec = ModelSpec.find(modelID) else { return }
        running = true; result = ""
        Task {
            defer { running = false }
            do { result = try await chats.runGPUStartTest(model: spec, precision: precision) }
            catch { result = "GPU起動テスト失敗：\(error.localizedDescription)\n比較結果と診断を共有して、失敗段階とGPUのメッセージを確認してください。" }
        }
        #endif
    }
}
