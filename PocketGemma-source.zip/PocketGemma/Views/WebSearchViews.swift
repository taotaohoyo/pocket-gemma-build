import SwiftUI
import AuthenticationServices
import PocketCore

/// Above a reply that searched: what it sent. The query is all that left
/// the device, so the reply says so in its own words. While it searches
/// the globe pulses with the Aurora Orb's wait below it.
struct WebSearchHeader: View {
    let record: WebSearchRecord
    let generating: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Label {
            Text(title).fixedSize(horizontal: false, vertical: true)
        } icon: {
            Image(systemName: record.failedAll ? "exclamationmark.circle" : "globe")
                .symbolEffect(.pulse, options: .repeating, isActive: searching && !reduceMotion)
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("reply-web-search")
    }

    private var searching: Bool { generating && record.inProgress != nil }

    private var title: String {
        if generating, let query = record.inProgress { return String(localized: "「\(query)」をウェブで検索しています…") }
        let queries = record.queries.map { String(localized: "「\($0)」") }.formatted(.list(type: .and, width: .narrow))
        if record.failedAll {
            return Sentences.join([String(localized: "\(queries)を検索できませんでした。"), (record.failure ?? .unavailable).message])
        }
        // The pages it read don't name what was asked (iOS 27.2): the
        // reply couldn't confirm it from them, and the line says so.
        if let unconfirmed = record.unconfirmed, !unconfirmed.isEmpty {
            let names = unconfirmed.map { String(localized: "「\($0)」") }.formatted(.list(type: .and, width: .narrow))
            return String(localized: "\(queries)をウェブで検索しましたが、\(names)について書かれたページは見つかりませんでした")
        }
        return String(localized: "\(queries)をウェブで検索しました")
    }
}

/// Below a written reply: the pages its searches read, each opening in
/// Safari. Content, so no glass.
struct WebSearchSources: View {
    let sources: [WebSearchSource]

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("情報源").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                .padding(.bottom, 4)
                .accessibilityAddTraits(.isHeader)
            ForEach(Array(links.enumerated()), id: \.element.source.id) { index, item in
                Link(destination: item.url) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text("\(index + 1)").font(.caption2.weight(.semibold).monospacedDigit())
                            .foregroundStyle(.secondary).frame(minWidth: 14, alignment: .trailing)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(item.source.title).font(.footnote).foregroundStyle(.primary).lineLimit(1)
                            Text(item.source.site).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        Image(systemName: "arrow.up.right").font(.caption2.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                    .padding(.vertical, 5)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("\(item.source.title)、\(item.source.site)")
                .accessibilityHint("Safariで開きます")
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("reply-web-sources")
    }

    /// Only web pages open; at most six.
    private var links: [(source: WebSearchSource, url: URL)] {
        sources.prefix(6).compactMap { source in
            guard let url = URL(string: source.url), url.scheme == "https" || url.scheme == "http" else { return nil }
            return (source, url)
        }
    }
}

/// モデルと設定: connecting web search to Tavily. Signing up or in on
/// Tavily's own page (TavilyAccount, 1.1.0 (207)) comes first, in plain
/// words; the person's own API key stays under 「APIキーで接続」 for those
/// who have one.
struct WebSearchCard: View {
    @ObservedObject private var key = WebSearchKeyState.shared
    @Environment(\.webAuthenticationSession) private var webAuthenticationSession
    @State private var editing = false
    @State private var draft = ""
    @State private var message: String?
    @State private var confirmDelete = false
    @State private var showsKey = false
    @State private var connecting = false
    @State private var accountMessage: String?
    @State private var showsDashboard = false
    @State private var confirmDisconnect = false
    @FocusState private var fieldFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("ウェブ検索", systemImage: "globe").font(.headline)
            Text("＋メニューでオンにすると、Tavilyで検索します。送るのは検索語だけです。")
                .font(.caption).foregroundStyle(.secondary)
            account
            // A plain button rather than a DisclosureGroup, whose label
            // didn't open it when tapped in this card (run 40446689417).
            Button {
                withAnimation(.snappy) { showsKey.toggle() }
            } label: {
                HStack {
                    Text("APIキーで接続").font(.subheadline)
                    Spacer()
                    Image(systemName: "chevron.right").font(.footnote.weight(.semibold))
                        .rotationEffect(.degrees(showsKey ? 90 : 0))
                        .accessibilityHidden(true)
                }
                .contentShape(Rectangle())
            }
            .accessibilityIdentifier("web-search-key-disclosure")
            .accessibilityValue(showsKey ? Text("開いています") : Text("閉じています"))
            if showsKey { keyEntry }
            Text("Tavilyに登録すると、月1,000回まで検索できます。")
                .font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).fieluaCard(cornerRadius: 20)
        // A container, so its rows keep their own identifiers.
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("web-search-card")
    }

    // MARK: Signed in with a Tavily account

    @ViewBuilder private var account: some View {
        VStack(alignment: .leading, spacing: 10) {
            switch key.account {
            case .connected:
                Label("Tavilyに接続済み", systemImage: "checkmark.circle.fill")
                    .font(.subheadline)
                    // One element that reads its words, not the icon's
                    // 「選択済み」 (run 40449291247).
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel(Text("Tavilyに接続済み"))
                    .accessibilityIdentifier("web-search-account-state")
                Button("接続を解除", role: .destructive) { confirmDisconnect = true }
                    .font(.subheadline).disabled(connecting)
                    .accessibilityIdentifier("web-search-account-disconnect")
            case .needsSignIn:
                Label {
                    Text("Tavilyにもう一度ログインしてください")
                } icon: {
                    Image(systemName: "exclamationmark.circle.fill").foregroundStyle(.orange)
                }
                .font(.subheadline)
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(Text("Tavilyにもう一度ログインしてください"))
                .accessibilityIdentifier("web-search-account-state")
                Text("ログインの期限が切れたため、検索できません。").font(.caption).foregroundStyle(.secondary)
                HStack(spacing: 10) {
                    signInButton("ログイン", prominent: true, id: "web-search-account-sign-in")
                    Button("接続を解除", role: .destructive) { confirmDisconnect = true }
                        .fieluaSecondaryButton().disabled(connecting)
                        .accessibilityIdentifier("web-search-account-disconnect")
                }
            case .signedOut:
                if key.isSet {
                    Label("APIキーで接続済み", systemImage: "checkmark.circle.fill")
                        .font(.subheadline)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(Text("APIキーで接続済み"))
                        .accessibilityIdentifier("web-search-account-state")
                }
                HStack(spacing: 10) {
                    signInButton("新規登録", prominent: true, signUp: true, id: "web-search-account-sign-up")
                    signInButton("ログイン", prominent: false, id: "web-search-account-sign-in")
                }
                Text(key.isSet ? "ログインすると、APIキーの代わりにTavilyアカウントで検索します。"
                               : "Tavilyの画面で登録またはログインすると、自動でFieluaに戻ります。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            if connecting {
                HStack(spacing: 8) {
                    ProgressView()
                    Text("接続しています…").font(.caption).foregroundStyle(.secondary)
                }
                .accessibilityElement(children: .combine)
                .accessibilityIdentifier("web-search-account-progress")
            }
            if let accountMessage {
                Text(accountMessage).font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityIdentifier("web-search-account-message")
            }
            if showsDashboard {
                Link(destination: TavilyAccount.dashboard) {
                    Label("Tavilyのサイトを開く", systemImage: "arrow.up.right.square")
                }
                .font(.subheadline)
                .accessibilityHint("Safariで開きます")
            }
        }
        .animation(.smooth(duration: 0.25), value: key.account)
        .animation(.smooth(duration: 0.25), value: connecting)
        .confirmationDialog("Tavilyとの接続を解除しますか？", isPresented: $confirmDisconnect, titleVisibility: .visible) {
            Button("接続を解除", role: .destructive, action: disconnect)
        } message: {
            Text("ログイン情報を削除し、Tavilyとの接続を取り消します。")
        }
    }

    @ViewBuilder private func signInButton(_ title: LocalizedStringKey, prominent: Bool, signUp: Bool = false,
                                           id: String) -> some View {
        let button = Button { signIn(signUp: signUp) } label: {
            Text(title).font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity)
        }
        Group {
            if prominent { button.fieluaProminentButton() } else { button.fieluaSecondaryButton() }
        }
        .controlSize(.large)
        .disabled(connecting)
        .accessibilityHint(signUp ? Text("Tavilyの登録画面を開きます") : Text("Tavilyのログイン画面を開きます"))
        .accessibilityIdentifier(id)
    }

    /// Tavily's page in iOS's sign-in sheet, which comes back on its own.
    /// 新規登録 opens it at Tavily's sign-up (「Create Your Account」), ログイン
    /// at its sign-in; each links to the other (1.1.0 (223): both opened the
    /// sign-in). Ephemeral: no cookies shared with Safari, so after
    /// disconnecting another account can sign in, and nothing stays signed
    /// in on the web.
    private func signIn(signUp: Bool) {
        guard !connecting else { return }
        connecting = true
        accountMessage = nil
        showsDashboard = false
        Task {
            defer { connecting = false }
            do {
                let signIn = try await TavilyAccountSession.shared.beginSignIn(signUp: signUp)
                let callback = try await webAuthenticationSession.authenticate(
                    using: signIn.url, callback: .customScheme(TavilyAccount.callbackScheme),
                    preferredBrowserSession: .ephemeral, additionalHeaderFields: [:])
                switch try await TavilyAccountSession.shared.finishSignIn(callback: callback, signIn: signIn) {
                case .ready: accountMessage = String(localized: "Tavilyに接続しました。")
                case .limited(let failure): accountMessage = Sentences.join([String(localized: "Tavilyに接続しました。"), failure.message])
                }
            } catch let error as ASWebAuthenticationSessionError where error.code == .canceledLogin {
                // Tavily's page was closed: back to the card as it was.
            } catch {
                let failure = TavilySignInError(error)
                accountMessage = failure.message
                showsDashboard = failure == .cannotSearch
            }
        }
    }

    private func disconnect() {
        connecting = true
        accountMessage = nil
        showsDashboard = false
        Task {
            let confirmed = await TavilyAccountSession.shared.disconnect()
            connecting = false
            accountMessage = confirmed ? String(localized: "Tavilyとの接続を解除しました。")
                : String(localized: "この端末から接続を解除しました。Tavily側での取り消しは確認できませんでした。")
        }
    }

    // MARK: The person's own key

    @ViewBuilder private var keyEntry: some View {
        VStack(alignment: .leading, spacing: 12) {
            if key.isSet && !editing {
                Label(key.syncs ? "Tavilyのキー: 登録済み（iCloudキーチェーン）" : "Tavilyのキー: 登録済み（この端末のみ）",
                      systemImage: "checkmark.circle.fill")
                    .font(.subheadline)
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel(key.syncs ? Text("Tavilyのキー: 登録済み（iCloudキーチェーン）")
                                                  : Text("Tavilyのキー: 登録済み（この端末のみ）"))
                    .accessibilityIdentifier("web-search-key-state")
                HStack(spacing: 16) {
                    Button("変更") { message = nil; editing = true; fieldFocused = true }
                        .accessibilityIdentifier("web-search-key-change")
                    Button("削除", role: .destructive) { confirmDelete = true }
                        .accessibilityIdentifier("web-search-key-delete")
                }
                .font(.subheadline)
                if key.account == .connected {
                    Text("ログイン中は、このキーではなくTavilyアカウントで検索します。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            } else {
                HStack(spacing: 8) {
                    SecureField("TavilyのAPIキー", text: $draft)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .focused($fieldFocused)
                        .submitLabel(.done)
                        .onSubmit(save)
                        .font(.subheadline)
                        .padding(.horizontal, 12).padding(.vertical, 9)
                        .background(Theme.canvas, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .accessibilityIdentifier("web-search-key")
                    Button("登録", action: save)
                        .font(.subheadline.weight(.semibold))
                        .disabled(WebSearchKey.cleaned(draft) == nil)
                        .accessibilityIdentifier("web-search-key-save")
                }
                if editing {
                    Button("キャンセル") { draft = ""; editing = false; fieldFocused = false }
                        .font(.subheadline)
                }
            }
            Link(destination: WebSearch.keyPage) {
                Label("Tavilyでキーを取得", systemImage: "arrow.up.right.square")
            }
            .font(.subheadline)
            .accessibilityHint("Safariで開きます")
            .accessibilityIdentifier("web-search-key-page")
            Text("キーはiCloudキーチェーンに保存します。")
                .font(.caption).foregroundStyle(.secondary)
            if let message {
                Text(message).font(.caption).foregroundStyle(.secondary)
                    .accessibilityIdentifier("web-search-key-message")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .confirmationDialog("Tavilyのキーを削除しますか？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("削除", role: .destructive) {
                key.delete()
                message = String(localized: "キーを削除しました。ほかの端末からも削除されます。")
            }
        } message: {
            Text(key.account == .connected ? "ログイン中は、引き続きTavilyアカウントで検索します。" : "削除すると、ウェブ検索は使えなくなります。")
        }
    }

    private func save() {
        guard WebSearchKey.cleaned(draft) != nil else { return }
        switch key.save(draft) {
        case .synced: message = String(localized: "キーを登録しました。")
        case .thisDeviceOnly: message = String(localized: "キーを登録しました（この端末のみ）。")
        case .failed: message = String(localized: "キーを保存できませんでした。もう一度お試しください。")
        }
        draft = ""
        editing = false
        fieldFocused = false
    }
}
