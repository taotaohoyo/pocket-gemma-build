import SwiftUI
import PocketCore

/// Above a reply that searched: what it sent. The query is all that left
/// the device, so the reply says so in its own words.
struct WebSearchHeader: View {
    let record: WebSearchRecord
    let generating: Bool

    var body: some View {
        Label {
            Text(title).fixedSize(horizontal: false, vertical: true)
        } icon: {
            Image(systemName: failedAll ? "exclamationmark.circle" : "globe")
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("reply-web-search")
    }

    private var failedAll: Bool {
        guard let failed = record.failedQueries else { return false }
        return record.inProgress == nil && Set(failed) == Set(record.queries)
    }

    private var title: String {
        if generating, let query = record.inProgress { return "「\(query)」を検索しています…" }
        let queries = record.queries.map { "「\($0)」" }.joined(separator: "、")
        if failedAll { return "\(queries)を検索できませんでした" }
        let place = record.provider.map { "\($0.title)で" } ?? ""
        return "\(queries)を\(place)検索しました"
    }
}

/// Below a written reply: the pages its searches read, each opening in
/// Safari. Content, so no glass.
struct WebSearchSources: View {
    let sources: [WebSearchSource]

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("情報源").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                .padding(.bottom, 4)
                .accessibilityAddTraits(.isHeader)
            ForEach(Array(links.enumerated()), id: \.element.source.id) { index, item in
                Link(destination: item.url) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text("\(index + 1)").font(.caption2.weight(.semibold).monospacedDigit())
                            .foregroundStyle(.secondary).frame(minWidth: 14, alignment: .trailing)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(item.source.title).font(.footnote).foregroundStyle(.primary).lineLimit(1)
                            Text(item.source.site).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        Image(systemName: "arrow.up.right").font(.caption2.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                    .padding(.vertical, 5)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("\(item.source.title)、\(item.source.site)")
                .accessibilityHint("Safariで開きます")
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("reply-web-sources")
    }

    /// Only web pages open; at most six.
    private var links: [(source: WebSearchSource, url: URL)] {
        sources.prefix(6).compactMap { source in
            guard let url = URL(string: source.url), url.scheme == "https" || url.scheme == "http" else { return nil }
            return (source, url)
        }
    }
}

/// モデルと設定: where search goes, and the person's own Tavily key.
struct WebSearchCard: View {
    @State private var keySet = WebSearchKey.isSet
    @State private var draft = ""
    @State private var message: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("ウェブ検索", systemImage: "globe").font(.headline)
            Text("チャットの＋メニューでオンにした会話だけ、Gemmaが必要なときに検索します。送るのは検索語だけで、会話・写真・ファイルは送りません。ファイルを添付した会話では使えません。")
                .font(.caption).foregroundStyle(.secondary)
            Text(keySet ? "検索先: ウェブ全体（Tavilyの鍵を使用）" : "検索先: Wikipedia（鍵は不要）")
                .font(.subheadline)
                .accessibilityIdentifier("web-search-provider")
            if keySet {
                Button("Tavilyの鍵を削除", role: .destructive) {
                    WebSearchKey.delete()
                    keySet = WebSearchKey.isSet
                    message = "鍵を削除しました。検索はWikipediaに戻ります。"
                }
                .font(.subheadline)
            } else {
                HStack(spacing: 8) {
                    SecureField("TavilyのAPIキー（任意）", text: $draft)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .font(.subheadline)
                        .accessibilityIdentifier("web-search-key")
                    Button("保存") {
                        if WebSearchKey.save(draft) {
                            draft = ""
                            keySet = true
                            message = "鍵を保存しました。ウェブ全体を検索します。"
                        } else {
                            message = "鍵を保存できませんでした。空白のない鍵を入れてください。"
                        }
                    }
                    .font(.subheadline)
                    .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            Text("Tavily（tavily.com）に無料登録すると、月1,000回までウェブ全体を検索できます。鍵はこの端末のキーチェーンにだけ保存し、検索のときにTavilyへ送るだけです。")
                .font(.caption).foregroundStyle(.secondary)
            if let message { Text(message).font(.caption).foregroundStyle(.secondary) }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
        .accessibilityIdentifier("web-search-card")
    }
}
