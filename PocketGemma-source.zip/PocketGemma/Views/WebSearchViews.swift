import SwiftUI
import PocketCore

/// Above a reply that searched: what it sent. The query is all that left
/// the device, so the reply says so in its own words. While it searches
/// the globe pulses with the Aurora Orb's wait below it.
struct WebSearchHeader: View {
    let record: WebSearchRecord
    let generating: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Label {
            Text(title).fixedSize(horizontal: false, vertical: true)
        } icon: {
            Image(systemName: record.failedAll ? "exclamationmark.circle" : "globe")
                .symbolEffect(.pulse, options: .repeating, isActive: searching && !reduceMotion)
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("reply-web-search")
    }

    private var searching: Bool { generating && record.inProgress != nil }

    private var title: String {
        if generating, let query = record.inProgress { return String(localized: "「\(query)」をウェブで検索しています…") }
        let queries = record.queries.map { String(localized: "「\($0)」") }.formatted(.list(type: .and, width: .narrow))
        if record.failedAll {
            return Sentences.join([String(localized: "\(queries)を検索できませんでした。"), (record.failure ?? .unavailable).message])
        }
        return String(localized: "\(queries)をウェブで検索しました")
    }
}

/// Below a written reply: the pages its searches read, each opening in
/// Safari. Content, so no glass.
struct WebSearchSources: View {
    let sources: [WebSearchSource]

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("情報源").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                .padding(.bottom, 4)
                .accessibilityAddTraits(.isHeader)
            ForEach(Array(links.enumerated()), id: \.element.source.id) { index, item in
                Link(destination: item.url) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text("\(index + 1)").font(.caption2.weight(.semibold).monospacedDigit())
                            .foregroundStyle(.secondary).frame(minWidth: 14, alignment: .trailing)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(item.source.title).font(.footnote).foregroundStyle(.primary).lineLimit(1)
                            Text(item.source.site).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        Image(systemName: "arrow.up.right").font(.caption2.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                    .padding(.vertical, 5)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("\(item.source.title)、\(item.source.site)")
                .accessibilityHint("Safariで開きます")
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("reply-web-sources")
    }

    /// Only web pages open; at most six.
    private var links: [(source: WebSearchSource, url: URL)] {
        sources.prefix(6).compactMap { source in
            guard let url = URL(string: source.url), url.scheme == "https" || url.scheme == "http" else { return nil }
            return (source, url)
        }
    }
}

/// モデルと設定: the person's own Tavily key, to register, change or
/// delete, and where to get one.
struct WebSearchCard: View {
    @ObservedObject private var key = WebSearchKeyState.shared
    @State private var editing = false
    @State private var draft = ""
    @State private var message: String?
    @State private var confirmDelete = false
    @FocusState private var fieldFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("ウェブ検索", systemImage: "globe").font(.headline)
            Text("＋メニューでオンにしたチャットだけ、必要なときにTavilyで検索します。送るのは検索語だけで、会話・写真・ファイルは送りません。ファイルを添付した会話では使えません。")
                .font(.caption).foregroundStyle(.secondary)
            if key.isSet && !editing {
                Label(key.syncs ? "Tavilyのキー: 登録済み（iCloudキーチェーン）" : "Tavilyのキー: 登録済み（この端末のみ）",
                      systemImage: "checkmark.circle.fill")
                    .font(.subheadline)
                    .accessibilityIdentifier("web-search-key-state")
                HStack(spacing: 16) {
                    Button("変更") { message = nil; editing = true; fieldFocused = true }
                        .accessibilityIdentifier("web-search-key-change")
                    Button("削除", role: .destructive) { confirmDelete = true }
                        .accessibilityIdentifier("web-search-key-delete")
                }
                .font(.subheadline)
            } else {
                HStack(spacing: 8) {
                    SecureField("TavilyのAPIキー", text: $draft)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .focused($fieldFocused)
                        .submitLabel(.done)
                        .onSubmit(save)
                        .font(.subheadline)
                        .padding(.horizontal, 12).padding(.vertical, 9)
                        .background(Theme.canvas, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .accessibilityIdentifier("web-search-key")
                    Button("登録", action: save)
                        .font(.subheadline.weight(.semibold))
                        .disabled(WebSearchKey.cleaned(draft) == nil)
                        .accessibilityIdentifier("web-search-key-save")
                }
                if editing {
                    Button("キャンセル") { draft = ""; editing = false; fieldFocused = false }
                        .font(.subheadline)
                }
            }
            Link(destination: WebSearch.keyPage) {
                Label("Tavilyでキーを取得", systemImage: "arrow.up.right.square")
            }
            .font(.subheadline)
            .accessibilityHint("Safariで開きます")
            .accessibilityIdentifier("web-search-key-page")
            Text("Tavilyに無料登録すると、月1,000回まで検索できます（Tavilyのアカウントは18歳以上が対象）。キーはiCloudキーチェーンにだけ保存し、検索のときにTavilyへ直接送ります。Fieluaの運営側には送りません。")
                .font(.caption).foregroundStyle(.secondary)
            if let message {
                Text(message).font(.caption).foregroundStyle(.secondary)
                    .accessibilityIdentifier("web-search-key-message")
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18).background(Theme.card, in: RoundedRectangle(cornerRadius: 20))
        .confirmationDialog("Tavilyのキーを削除しますか？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("削除", role: .destructive) {
                key.delete()
                message = String(localized: "キーを削除しました。iCloudキーチェーンで同期しているほかの端末からも削除されます。")
            }
        } message: {
            Text("削除すると、ウェブ検索は使えなくなります。")
        }
        // A container, so its rows keep their own identifiers.
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("web-search-card")
    }

    private func save() {
        guard WebSearchKey.cleaned(draft) != nil else { return }
        switch key.save(draft) {
        case .synced: message = String(localized: "キーを登録しました。iCloudキーチェーンで同期します。")
        case .thisDeviceOnly: message = String(localized: "キーを登録しました。iCloudキーチェーンには保存できなかったため、この端末にだけ保存しています。")
        case .failed: message = String(localized: "キーを保存できませんでした。もう一度お試しください。")
        }
        draft = ""
        editing = false
        fieldFocused = false
    }
}
