import AVFoundation
import Observation
import PocketCore

/// The composer's recorder for a question spoken into the app (VoiceNote,
/// 1.1.0 (236)), for a model that hears one (LFM3-Omni 2B): 16 kHz mono
/// 16-bit WAV in the attachment folder, at most `VoiceNote.limit` long,
/// and its level while it records, for the recording strip. The recording
/// stays on the phone. The UI preview has no microphone to ask for: it
/// writes a quiet tone as long as the recording ran instead.
@MainActor @Observable
final class VoiceRecorder: NSObject, AVAudioRecorderDelegate {
    enum Phase: Equatable { case idle, asking, recording }
    enum Start: Equatable { case recording, denied, failed(String) }
    enum Outcome {
        case recorded(ChatAttachment)
        /// Shorter than `VoiceNote.shortest`: dropped.
        case tooShort
        case failed(String)
    }

    private(set) var phase: Phase = .idle
    /// Seconds recorded so far.
    private(set) var elapsed: Double = 0
    /// The latest levels, 0 to 1, oldest first.
    private(set) var levels: [Float] = Array(repeating: 0, count: VoiceRecorder.levelCount)
    static let levelCount = 28

    @ObservationIgnored private var recorder: AVAudioRecorder?
    @ObservationIgnored private var id = UUID()
    @ObservationIgnored private var began: Date?
    @ObservationIgnored private var meter: Task<Void, Never>?
    @ObservationIgnored private var finished: ((Outcome) -> Void)?
    @ObservationIgnored private var interruption: NSObjectProtocol?

    var isRecording: Bool { phase == .recording }

    /// Asks for the microphone the first time, then records until `stop`,
    /// `cancel` or the limit; `finished` gets the recording (or why there
    /// is none) when it ends by `stop` or the limit.
    func start(finished: @escaping (Outcome) -> Void) async -> Start {
        guard phase == .idle else { return .failed(String(localized: "録音を始められませんでした。")) }
        phase = .asking
        VoicePlayer.shared.stop()
        #if !POCKET_PREVIEW
        if AVAudioApplication.shared.recordPermission != .granted {
            let granted = AVAudioApplication.shared.recordPermission == .undetermined
                ? await AVAudioApplication.requestRecordPermission() : false
            guard granted, phase == .asking else { phase = .idle; return granted ? .failed("") : .denied }
        }
        #endif
        id = UUID()
        guard let url = AttachmentStorage.url(VoiceNote.storedName(id)) else { phase = .idle; return .failed("") }
        do {
            try FileManager.default.createDirectory(at: AttachmentStorage.directory, withIntermediateDirectories: true)
            #if !POCKET_PREVIEW
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .default)
            try session.setActive(true)
            let recorder = try AVAudioRecorder(url: url, settings: [
                AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: VoiceNote.sampleRate, AVNumberOfChannelsKey: 1,
                AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false,
            ])
            recorder.delegate = self
            recorder.isMeteringEnabled = true
            guard recorder.prepareToRecord(), recorder.record(forDuration: VoiceNote.limit) else {
                throw CocoaError(.fileWriteUnknown)
            }
            self.recorder = recorder
            // A call or Siri takes the microphone: what was said so far is kept.
            interruption = NotificationCenter.default.addObserver(forName: AVAudioSession.interruptionNotification,
                                                                  object: session, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.stop() }
            }
            #endif
        } catch {
            release()
            phase = .idle
            return .failed(String(localized: "録音を始められませんでした。") + "\n" + error.localizedDescription)
        }
        self.finished = finished
        began = Date()
        elapsed = 0
        levels = Array(repeating: 0, count: Self.levelCount)
        phase = .recording
        meter = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self, self.phase == .recording else { return }
                self.sample()
                do { try await Task.sleep(for: .milliseconds(50)) } catch { return }
            }
        }
        return .recording
    }

    /// Ends the recording and hands it on.
    func stop() {
        guard phase == .recording else { return }
        let seconds = min(VoiceNote.limit, elapsedNow)
        recorder?.stop()
        let handler = finished
        let outcome = Self.outcome(id: id, seconds: seconds)
        release()
        handler?(outcome)
    }

    /// Ends the recording and drops it.
    func cancel() {
        guard phase != .idle else { return }
        recorder?.stop()
        recorder?.deleteRecording()
        if let url = AttachmentStorage.url(VoiceNote.storedName(id)) { try? FileManager.default.removeItem(at: url) }
        release()
    }

    private var elapsedNow: Double {
        #if POCKET_PREVIEW
        return began.map { Date().timeIntervalSince($0) } ?? 0
        #else
        return recorder?.currentTime ?? 0
        #endif
    }

    private func sample() {
        if elapsedNow >= VoiceNote.limit { stop(); return }
        elapsed = elapsedNow
        var level: Float
        #if POCKET_PREVIEW
        level = Float(0.35 + 0.3 * sin(elapsed * 9) * sin(elapsed * 2.3))
        #else
        recorder?.updateMeters()
        // -50 dB and below is silence, 0 dB the loudest.
        level = ((recorder?.averagePower(forChannel: 0) ?? -160) + 50) / 50
        #endif
        level = min(1, max(0, level))
        levels = Array(levels.dropFirst()) + [level]
    }

    private func release() {
        meter?.cancel(); meter = nil
        if let interruption { NotificationCenter.default.removeObserver(interruption) }
        interruption = nil
        recorder = nil
        finished = nil
        began = nil
        phase = .idle
        #if !POCKET_PREVIEW
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        #endif
    }

    /// The recorded file as an attachment, its length read from the file.
    private static func outcome(id: UUID, seconds: Double) -> Outcome {
        guard let url = AttachmentStorage.url(VoiceNote.storedName(id)) else { return .failed("") }
        #if POCKET_PREVIEW
        try? PreviewTone.wav(seconds: seconds).write(to: url)
        #endif
        let length = (try? AVAudioFile(forReading: url)).map { Double($0.length) / $0.fileFormat.sampleRate } ?? seconds
        let bytes = ((try? FileManager.default.attributesOfItem(atPath: url.path)[.size]) as? NSNumber)?.int64Value ?? 0
        guard bytes > 0 else { return .failed(String(localized: "録音を保存できませんでした。")) }
        guard length >= VoiceNote.shortest else { try? FileManager.default.removeItem(at: url); return .tooShort }
        return .recorded(VoiceNote.attachment(id: id, seconds: min(length, VoiceNote.limit), byteCount: bytes))
    }

    /// The limit reached: the recorder ended by itself.
    nonisolated func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        let ended = ObjectIdentifier(recorder)
        Task { @MainActor in
            guard let current = self.recorder, ObjectIdentifier(current) == ended else { return }
            self.stop()
        }
    }

    nonisolated func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        let ended = ObjectIdentifier(recorder)
        Task { @MainActor in
            guard let current = self.recorder, ObjectIdentifier(current) == ended else { return }
            let handler = self.finished
            self.cancel()
            handler?(.failed(String(localized: "録音を保存できませんでした。")))
        }
    }
}

/// Plays a recording in the draft or the chat, one at a time.
@MainActor @Observable
final class VoicePlayer: NSObject, AVAudioPlayerDelegate {
    static let shared = VoicePlayer()
    /// The attachment playing now.
    private(set) var playing: UUID?
    @ObservationIgnored private var player: AVAudioPlayer?

    func toggle(_ attachment: ChatAttachment) {
        if playing == attachment.id { stop(); return }
        stop()
        guard let url = AttachmentStorage.url(attachment.storedName),
              let player = try? AVAudioPlayer(contentsOf: url) else { return }
        #if !POCKET_PREVIEW
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
        try? AVAudioSession.sharedInstance().setActive(true)
        #endif
        player.delegate = self
        guard player.play() else { return }
        self.player = player
        playing = attachment.id
    }

    func stop() {
        player?.stop()
        player = nil
        guard playing != nil else { return }
        playing = nil
        #if !POCKET_PREVIEW
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        #endif
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        let ended = ObjectIdentifier(player)
        Task { @MainActor in
            guard let current = self.player, ObjectIdentifier(current) == ended else { return }
            self.stop()
        }
    }
}

#if POCKET_PREVIEW
/// The preview's recording: a quiet 220 Hz tone, as VoiceRecorder's WAV.
enum PreviewTone {
    static func wav(seconds: Double) -> Data {
        let rate = Int(VoiceNote.sampleRate), count = Int(seconds * VoiceNote.sampleRate)
        var data = Data()
        func put<T: FixedWidthInteger>(_ value: T) { withUnsafeBytes(of: value.littleEndian) { data.append(contentsOf: $0) } }
        data.append(contentsOf: Array("RIFF".utf8)); put(UInt32(36 + count * 2))
        data.append(contentsOf: Array("WAVEfmt ".utf8)); put(UInt32(16)); put(UInt16(1)); put(UInt16(1))
        put(UInt32(rate)); put(UInt32(rate * 2)); put(UInt16(2)); put(UInt16(16))
        data.append(contentsOf: Array("data".utf8)); put(UInt32(count * 2))
        for index in 0..<count { put(Int16(sin(Double(index) * 2 * .pi * 220 / Double(rate)) * 3000)) }
        return data
    }
}
#endif
