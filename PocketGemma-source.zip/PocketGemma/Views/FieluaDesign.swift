import SwiftUI

// Fielua's shared parts (brand 2026-10-27). Colours are Theme's; spacing,
// corners, shadows and the parts below are the rest of the design system.
// A new screen builds from these instead of choosing its own values; the
// rules are written down in design/FIELUA-DESIGN.md. Phase 2 (1.1.0 (214))
// took colour out of them: the yellow is the main action's and a choice's,
// everything else is warm neutral.

/// Spacing on a 4pt grid.
enum FieluaSpace {
    static let xxs: CGFloat = 4
    static let xs: CGFloat = 8
    static let s: CGFloat = 12
    static let m: CGFloat = 16
    static let l: CGFloat = 20
    static let xl: CGFloat = 24
    static let xxl: CGFloat = 32
    /// A screen's side margin for cards and lists.
    static let page: CGFloat = 20
}

/// Corner radii, all continuous (squircle) corners.
enum FieluaRadius {
    /// Small chips, code blocks, thumbnails.
    static let small: CGFloat = 10
    /// Inline panels and inputs.
    static let medium: CGFloat = 14
    /// Cards and grouped rows.
    static let card: CGFloat = 20
    /// Large cards on onboarding pages.
    static let large: CGFloat = 24
}

/// The one shadow cards cast in light mode: low, soft and warm (a brown,
/// not grey), so a card reads as paper on paper. Dark mode has none; cards
/// stand out by tone there. Fainter and closer since 1.1.0 (214).
enum FieluaShadow {
    static let color = Color(red: 0.36, green: 0.27, blue: 0.13).opacity(0.05)
    static let radius: CGFloat = 8
    static let y: CGFloat = 2
}

/// Type roles. Body text is Apple's own (SF) for reading; the serif (New
/// York) is only for the wordmark and a few large brand titles.
enum FieluaType {
    /// A brand title (ようこそ's wordmark, 設定's title): New York.
    static func brandTitle(_ size: CGFloat) -> Font { .system(size: size, weight: .regular, design: .serif) }
    /// A page's heading (onboarding steps).
    static let pageTitle = Font.system(.largeTitle, design: .default).weight(.bold)
    /// A small section label above a group.
    static let sectionLabel = Font.footnote.weight(.semibold)
}

/// Motion outside the conversation (設定's cards, the sheets, Claude's and
/// the PC's pages), in one place since 1.1.0 (263): until then each card
/// chose its own (.snappy with a bounce here, .smooth(0.25) there, most of
/// them nothing at all). The conversation's own tokens are ChatMotion's.
/// Nothing here bounces: a card settles, it does not spring.
enum FieluaMotion {
    /// A card's content changing: a card taking another's place, a line
    /// coming or going, a row leaving a list.
    static func change(_ reduceMotion: Bool) -> Animation {
        reduceMotion ? .easeInOut(duration: 0.15) : .smooth(duration: 0.3)
    }
    /// A line that opens what is under it (詳細, APIキーで接続, a series on
    /// the first launch's モデルを選ぶ).
    static func disclose(_ reduceMotion: Bool) -> Animation {
        reduceMotion ? .easeInOut(duration: 0.15 * discloseSlowdown) : .smooth(duration: 0.28 * discloseSlowdown)
    }
    #if POCKET_PREVIEW
    /// `--slow-disclose` plays it ten times slower, so the UI check's
    /// back-to-back screenshots (about 0.2 s apart) sample a series opening
    /// and closing (1.1.0 (269)).
    private static let discloseSlowdown: Double = PreviewProbe.on("--slow-disclose") ? 10 : 1
    #else
    private static let discloseSlowdown: Double = 1
    #endif
    /// A button let go: its pressed tone fades (it comes at once).
    static let release = Animation.easeOut(duration: 0.2)
    /// A check taking or leaving its ring, and the wash of the row it chooses.
    static let mark = Animation.easeOut(duration: 0.18)
    /// A control's look following whether it can be pressed, and a label
    /// trading its words (コピー → コピーしました).
    static let tone = Animation.easeInOut(duration: 0.2)
    /// A picture of a choice giving under a finger.
    static let press = Animation.spring(duration: 0.25, bounce: 0.2)
    /// The frame of a choice moving to the one tapped during the setup.
    static let choose = Animation.smooth(duration: 0.25)
    /// A page of the setup changing what it tells (準備中 → 準備完了).
    static func step(_ reduceMotion: Bool) -> Animation {
        reduceMotion ? .easeInOut(duration: 0.15) : .smooth(duration: 0.35)
    }
    /// The setup lifting off the chat when it is done.
    static let cover = Animation.smooth(duration: 0.5)
    /// How long a 「コピーしました」 stays before the button is itself again.
    static let confirmation = Duration.seconds(1.6)
}

/// A control's sizes on a card.
enum FieluaControl {
    /// A card button's height at the regular size and at `.controlSize(.large)`.
    static let regular: CGFloat = 36
    static let large: CGFloat = 46
    /// The least a finger gets, whatever the control draws.
    static let target: CGFloat = 44
}

/// A group's name above it (モデル in モデル管理): small, quiet, in line with
/// the cards' text.
struct FieluaSectionLabel: View {
    let title: LocalizedStringKey
    init(_ title: LocalizedStringKey) { self.title = title }
    var body: some View {
        Text(title)
            .font(FieluaType.sectionLabel)
            .foregroundStyle(.secondary)
            .padding(.horizontal, 4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityAddTraits(.isHeader)
    }
}

// MARK: - Backgrounds

/// Paper: a warm flat colour with a grain too faint to notice as such
/// (about 3% contrast), drawn once and never animated, so it costs nothing
/// while scrolling. The grain stays still under scrolling content.
struct PaperBackground: View {
    var color: Color = Theme.chatBackground
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    var body: some View {
        color
            .overlay {
                if !reduceTransparency {
                    Image("PaperGrain").resizable(resizingMode: .tile)
                        .allowsHitTesting(false)
                }
            }
            .accessibilityHidden(true)
    }
}

extension View {
    /// A page or sheet with cards on it (構成, the developer tools): the
    /// canvas paper, a shade deeper than the cards, under the bars as well.
    /// iOS's own sheet and form background is a cool grey (the 生成設定
    /// sheet until 1.1.0 (215)); this keeps every screen on the same paper.
    func fieluaPageBackground() -> some View {
        background { PaperBackground(color: Theme.canvas).ignoresSafeArea() }
    }

    /// A Form on Fielua's paper: no system grey behind it, the canvas paper
    /// instead. Its sections take `.fieluaFormSection()`; inside a page
    /// that already has `.fieluaPageBackground()`, `.scrollContentBackground(.hidden)`
    /// is enough.
    func fieluaForm() -> some View {
        scrollContentBackground(.hidden).fieluaPageBackground()
    }

    /// A Form section's rows on the cards' warm white (raised charcoal at
    /// night) instead of iOS's white and grey, so they match the cards.
    func fieluaFormSection() -> some View {
        listRowBackground(Theme.card)
    }
}

// MARK: - Cards

/// A card: warm white with a hairline edge on paper; raised charcoal at
/// night. `elevated` adds the soft warm shadow, for cards on still pages
/// only: in 設定, whose pages slide at 120Hz, a shadow per card would be
/// drawn offscreen on every frame of the slide.
struct FieluaCardBackground<S: InsettableShape>: ViewModifier {
    var shape: S
    var fill: Color = Theme.card
    var elevated = false
    @Environment(\.colorScheme) private var colorScheme

    func body(content: Content) -> some View {
        content.background {
            if elevated && colorScheme != .dark {
                shape.fill(fill)
                    .overlay { shape.strokeBorder(Theme.cardStroke, lineWidth: 0.5) }
                    .shadow(color: FieluaShadow.color, radius: FieluaShadow.radius, y: FieluaShadow.y)
            } else {
                shape.fill(fill)
                    .overlay { shape.strokeBorder(Theme.cardStroke, lineWidth: 0.5) }
            }
        }
    }
}

extension View {
    /// The card behind this view, in rounded corners.
    func fieluaCard(cornerRadius: CGFloat = FieluaRadius.card, fill: Color = Theme.card,
                    elevated: Bool = false) -> some View {
        modifier(FieluaCardBackground(shape: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous),
                                      fill: fill, elevated: elevated))
    }

    /// Fielua's look for everything under it: the warm ink as the
    /// foreground (so .secondary and .tertiary are warm too) and the umber
    /// tint for system controls. Set once at the app's root.
    func fieluaAppearance() -> some View {
        foregroundStyle(Theme.ink).tint(Theme.tint)
    }
}

// MARK: - Buttons

/// The main action on a page (続ける, はじめる): a capsule of the system's
/// prominent glass in the brand yellow, its label in ink (9:1; the system's
/// white label would read at 1.5:1), full width.
struct FieluaPrimaryButton: View {
    let title: LocalizedStringKey
    var enabled = true
    let action: () -> Void

    init(_ title: LocalizedStringKey, enabled: Bool = true, action: @escaping () -> Void) {
        self.title = title; self.enabled = enabled; self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title).font(.headline)
                .foregroundStyle(enabled ? Theme.onAccent : Color.secondary)
                .frame(maxWidth: .infinity).padding(.vertical, 6)
        }
        .buttonStyle(.glassProminent)
        .buttonBorderShape(.capsule)
        .controlSize(.large)
        .tint(Theme.accent)
        .disabled(!enabled)
    }
}

/// A card's buttons, drawn here since 1.1.0 (263). The system's bordered
/// styles took the ink tint to both ends once disabled: gone on the light
/// card, a solid black capsule with a white label on the dark one, stronger
/// than the button that could be pressed; and the yellow one looked ready
/// while it was not (UI review, 2026-11-11). Every state has its own tone
/// here, the same in both modes: ready, pressed, and not yet.
struct FieluaCardButtonStyle: ButtonStyle {
    enum Kind { case prominent, secondary }
    let kind: Kind
    func makeBody(configuration: Configuration) -> some View {
        FieluaCardButtonBody(kind: kind, configuration: configuration)
    }
}

private struct FieluaCardButtonBody: View {
    let kind: FieluaCardButtonStyle.Kind
    let configuration: ButtonStyleConfiguration
    @Environment(\.isEnabled) private var enabled
    @Environment(\.controlSize) private var controlSize
    @Environment(\.font) private var font
    @Environment(\.colorSchemeContrast) private var contrast

    var body: some View {
        let large = controlSize == .large || controlSize == .extraLarge
        configuration.label
            // The caller's own font where it set one, as the system's styles.
            .font(font ?? .subheadline.weight(.semibold))
            .multilineTextAlignment(.center)
            .foregroundStyle(label)
            .padding(.horizontal, large ? 20 : 14)
            .frame(minHeight: large ? FieluaControl.large : FieluaControl.regular)
            .background(fill, in: Capsule())
            .overlay {
                // 「コントラストを上げる」: an edge, as the system's buttons get.
                if contrast == .increased { Capsule().strokeBorder(Theme.ink.opacity(enabled ? 0.6 : 0.3), lineWidth: 1) }
            }
            .fieluaTouchTarget()
            .animation(configuration.isPressed ? nil : FieluaMotion.release, value: configuration.isPressed)
            .animation(FieluaMotion.tone, value: enabled)
    }

    /// The ink in every state but the yellow's; a destructive role keeps it
    /// too (登録を解除), as the cards have had it.
    private var label: Color {
        guard enabled else { return Theme.ink.opacity(0.36) }
        return kind == .prominent ? Theme.onAccent : Theme.ink
    }

    private var fill: Color {
        guard enabled else { return Theme.ink.opacity(0.07) }
        switch kind {
        case .prominent: return configuration.isPressed ? Theme.accentPressed : Theme.accent
        // 0.17: the tone the system's bordered style gave the ink tint.
        case .secondary: return Theme.ink.opacity(configuration.isPressed ? 0.27 : 0.17)
        }
    }
}

/// A text button on a card (接続を解除, 設定を開く, ダウンロードを中止): the
/// umber of every tappable word, fainter while pressed or not available,
/// with a finger's room around the words.
struct FieluaTextButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        FieluaTextButtonBody(configuration: configuration)
    }
}

private struct FieluaTextButtonBody: View {
    let configuration: ButtonStyleConfiguration
    @Environment(\.isEnabled) private var enabled

    var body: some View {
        configuration.label
            .foregroundStyle(configuration.role == .destructive ? Color.red : Theme.tint)
            .opacity(enabled ? (configuration.isPressed ? 0.45 : 1) : 0.4)
            .fieluaTouchTarget(horizontal: 8)
            .animation(configuration.isPressed ? nil : FieluaMotion.release, value: configuration.isPressed)
    }
}

extension View {
    /// A card's main button: the brand yellow with an ink label (9:1).
    /// The system's white label on the yellow would read at 1.5:1.
    func fieluaProminentButton() -> some View {
        buttonStyle(FieluaCardButtonStyle(kind: .prominent))
    }

    /// A card's other buttons: a quiet warm grey fill with the ink label
    /// (pale amber until 1.1.0 (214)).
    func fieluaSecondaryButton() -> some View {
        buttonStyle(FieluaCardButtonStyle(kind: .secondary))
    }

    /// A card's text button (FieluaTextButtonStyle).
    func fieluaTextButton() -> some View {
        buttonStyle(FieluaTextButtonStyle())
    }

    /// A finger's room (44pt) for a control drawn smaller, without moving
    /// anything: the room reaches past the view's own frame, above and
    /// below (and to the sides by `horizontal`), and the layout keeps the
    /// size that is drawn. Inside a button's label or style, so the touch
    /// is the button's.
    func fieluaTouchTarget(horizontal: CGFloat = 0) -> some View {
        background {
            Color.clear
                .frame(minWidth: FieluaControl.target, minHeight: FieluaControl.target)
                .padding(.horizontal, -horizontal)
                .contentShape(Rectangle())
        }
    }

    /// A text field on a card or a sheet: one look since 1.1.0 (263)
    /// (three before: Claude's, Tavily's key and the PC's code each had
    /// their own height, corner and fill).
    func fieluaField() -> some View {
        padding(.horizontal, 14).frame(minHeight: 50)
            .fieluaCard(cornerRadius: FieluaRadius.medium)
    }

    /// A switch, a slider or a progress bar: the honey of a state that is
    /// on, so a switch's white knob stands out on its track in both modes
    /// and a slider's filled part reads as the amount set (the umber system
    /// tint is for text buttons, checks and the caret). Sliders since
    /// 1.1.0 (215), umber before.
    func fieluaStateTint() -> some View {
        tint(Theme.active)
    }
}

/// A chosen option's mark (a filled check) and an open ring for the others,
/// in the brand yellow with an ink check.
struct FieluaCheckMark: View {
    let on: Bool
    var size: CGFloat = 22
    var body: some View {
        Image(systemName: on ? "checkmark.circle.fill" : "circle")
            .font(.system(size: size))
            .symbolRenderingMode(.palette)
            .foregroundStyle(on ? Theme.onAccent : Color(uiColor: .tertiaryLabel), Theme.accent)
            .contentTransition(.symbolEffect(.replace))
            .accessibilityHidden(true)
    }
}

/// A line icon in a list row, in the warm grey (golden until 1.1.0 (214)):
/// the row's words lead, the icon only helps find them.
struct FieluaRowIcon: View {
    let systemName: String
    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: 18, weight: .regular))
            .foregroundStyle(Theme.icon)
            .frame(width: 28)
            .accessibilityHidden(true)
    }
}

/// A state where a card's action would be (使用中 on the model in use): a
/// quiet warm grey capsule, readable while its button is disabled (the
/// system's bordered style faded it to near nothing, UI check 1.1.0 (214)).
/// VoiceOver still hears a dimmed button.
struct FieluaStateTag: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(Theme.icon)
            // As tall as the button it stands in for, so a card keeps its
            // height when 「使う」 becomes 「使用中」.
            .padding(.horizontal, 14)
            .frame(minHeight: FieluaControl.regular)
            .background(Theme.ink.opacity(0.06), in: Capsule())
    }
}

// MARK: - Parts that answer

/// A button's label while its work runs: the words keep their place, so
/// the button keeps its width, and a small spinner stands on them. Until
/// 1.1.0 (263) most buttons only dimmed (招待リンクを作る, 登録を解除), or
/// changed their words and with them their width (登録する).
struct FieluaBusyLabel: View {
    let title: LocalizedStringKey
    let busy: Bool
    var systemImage: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init(_ title: LocalizedStringKey, systemImage: String? = nil, busy: Bool) {
        self.title = title; self.systemImage = systemImage; self.busy = busy
    }

    var body: some View {
        ZStack {
            Group {
                if let systemImage { Label(title, systemImage: systemImage) } else { Text(title) }
            }
            .opacity(busy ? 0 : 1)
            if busy { ProgressView().controlSize(.small).transition(.opacity) }
        }
        .animation(FieluaMotion.change(reduceMotion), value: busy)
        // One element that keeps the button's name while the words are hidden.
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(Text(title))
        .accessibilityValue(busy ? Text("処理中") : Text(verbatim: ""))
    }
}

/// Done, on a sheet or a card (a PC registered, an invite accepted): the
/// chosen option's check, large, which lands once as it comes. One mark
/// since 1.1.0 (263); the PC's stood still and Claude's sheet closed
/// without one.
struct FieluaSuccessMark: View {
    var size: CGFloat = 52
    @State private var landed = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Image(systemName: "checkmark.circle.fill")
            .font(.system(size: size))
            .symbolRenderingMode(.palette)
            .foregroundStyle(Theme.onAccent, Theme.accent)
            .symbolEffect(.bounce, options: .nonRepeating, value: landed)
            .task {
                // After the step's own fade, so the landing is seen.
                guard !reduceMotion else { return }
                try? await Task.sleep(for: .milliseconds(160))
                landed = true
            }
            .accessibilityHidden(true)
    }
}

/// コピー's label, which answers: 「コピーしました」 with a check for a moment
/// (as a code block's), then itself again. `fieluaConfirmation` on the
/// button gives the tap and sets it back.
struct FieluaCopyLabel: View {
    let copied: Bool
    var title: LocalizedStringKey = "コピー"
    var systemImage = "doc.on.doc"
    /// On a button too narrow for 「コピーしました」 (half a card's width):
    /// the words stay and the check alone answers.
    var short = false
    var body: some View {
        Label {
            Text(copied && !short ? "コピーしました" : title).contentTransition(.opacity)
        } icon: {
            Image(systemName: copied ? "checkmark" : systemImage).contentTransition(.symbolEffect(.replace))
        }
        .animation(FieluaMotion.tone, value: copied)
        .accessibilityLabel(copied ? Text("コピーしました") : Text(title))
    }
}

extension View {
    /// A confirmation that goes away by itself: a success tap as `shown`
    /// turns on, and off again after `FieluaMotion.confirmation`.
    func fieluaConfirmation(_ shown: Binding<Bool>) -> some View {
        sensoryFeedback(.success, trigger: shown.wrappedValue) { _, now in now }
            .task(id: shown.wrappedValue) {
                guard shown.wrappedValue else { return }
                try? await Task.sleep(for: FieluaMotion.confirmation)
                guard !Task.isCancelled else { return }
                shown.wrappedValue = false
            }
    }
}

/// A line that opens what is under it (モデル管理's 詳細, ウェブ検索's
/// APIキーで接続, Claude's 開発者として登録). One part since 1.1.0 (263):
/// before, two of the three sprang open with a bounce and the third swapped
/// its arrow for another. The arrow turns, in the grey of 設定's own arrows,
/// and nothing bounces. What it opens sits under it in the same stack, with
/// `.transition(.opacity)`.
struct FieluaDisclosure: View {
    let title: LocalizedStringKey
    @Binding var open: Bool
    var font: Font = .subheadline
    /// The words in the secondary grey (詳細 on a model's card).
    var quiet = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    init(_ title: LocalizedStringKey, open: Binding<Bool>, font: Font = .subheadline, quiet: Bool = false) {
        self.title = title; _open = open; self.font = font; self.quiet = quiet
    }

    var body: some View {
        Button {
            withAnimation(FieluaMotion.disclose(reduceMotion)) { open.toggle() }
        } label: {
            HStack(spacing: FieluaSpace.xs) {
                Text(title)
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.tertiary)
                    .rotationEffect(.degrees(open ? 90 : 0))
                    .accessibilityHidden(true)
            }
            .font(font)
            .foregroundStyle(quiet ? AnyShapeStyle(.secondary) : AnyShapeStyle(Theme.ink))
            .frame(minHeight: 28)
            .contentShape(Rectangle())
            .fieluaTouchTarget()
        }
        .buttonStyle(.plain)
        .accessibilityValue(open ? Text("開いています") : Text("閉じています"))
    }
}

// MARK: - Empty states

/// What an empty place shows: the flower, small and quiet, and at most one
/// short line. No instructions, no AI words. The empty chat's own flower is
/// LivingFlower (FlowerMark.swift), which lets a petal go now and then.
struct FieluaEmptyMark: View {
    var size: CGFloat = 56
    var body: some View {
        FlowerMark(size: size)
            .opacity(0.9)
            .accessibilityHidden(true)
    }
}
