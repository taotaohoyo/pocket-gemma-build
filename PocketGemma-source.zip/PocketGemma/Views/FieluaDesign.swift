import SwiftUI

// Fielua's shared parts (brand 2026-10-27). Colours are Theme's; spacing,
// corners, shadows and the parts below are the rest of the design system.
// A new screen builds from these instead of choosing its own values; the
// rules are written down in design/FIELUA-DESIGN.md. Phase 2 (1.1.0 (214))
// took colour out of them: the yellow is the main action's and a choice's,
// everything else is warm neutral.

/// Spacing on a 4pt grid.
enum FieluaSpace {
    static let xxs: CGFloat = 4
    static let xs: CGFloat = 8
    static let s: CGFloat = 12
    static let m: CGFloat = 16
    static let l: CGFloat = 20
    static let xl: CGFloat = 24
    static let xxl: CGFloat = 32
    /// A screen's side margin for cards and lists.
    static let page: CGFloat = 20
}

/// Corner radii, all continuous (squircle) corners.
enum FieluaRadius {
    /// Small chips, code blocks, thumbnails.
    static let small: CGFloat = 10
    /// Inline panels and inputs.
    static let medium: CGFloat = 14
    /// Cards and grouped rows.
    static let card: CGFloat = 20
    /// Large cards on onboarding pages.
    static let large: CGFloat = 24
}

/// The one shadow cards cast in light mode: low, soft and warm (a brown,
/// not grey), so a card reads as paper on paper. Dark mode has none; cards
/// stand out by tone there. Fainter and closer since 1.1.0 (214).
enum FieluaShadow {
    static let color = Color(red: 0.36, green: 0.27, blue: 0.13).opacity(0.05)
    static let radius: CGFloat = 8
    static let y: CGFloat = 2
}

/// Type roles. Body text is Apple's own (SF) for reading; the serif (New
/// York) is only for the wordmark and a few large brand titles.
enum FieluaType {
    /// A brand title (ようこそ's wordmark, 設定's title): New York.
    static func brandTitle(_ size: CGFloat) -> Font { .system(size: size, weight: .regular, design: .serif) }
    /// A page's heading (onboarding steps).
    static let pageTitle = Font.system(.largeTitle, design: .default).weight(.bold)
    /// A small section label above a group.
    static let sectionLabel = Font.footnote.weight(.semibold)
}

/// A group's name above it (モデル in モデル管理): small, quiet, in line with
/// the cards' text.
struct FieluaSectionLabel: View {
    let title: LocalizedStringKey
    init(_ title: LocalizedStringKey) { self.title = title }
    var body: some View {
        Text(title)
            .font(FieluaType.sectionLabel)
            .foregroundStyle(.secondary)
            .padding(.horizontal, 4)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityAddTraits(.isHeader)
    }
}

// MARK: - Backgrounds

/// Paper: a warm flat colour with a grain too faint to notice as such
/// (about 3% contrast), drawn once and never animated, so it costs nothing
/// while scrolling. The grain stays still under scrolling content.
struct PaperBackground: View {
    var color: Color = Theme.chatBackground
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    var body: some View {
        color
            .overlay {
                if !reduceTransparency {
                    Image("PaperGrain").resizable(resizingMode: .tile)
                        .allowsHitTesting(false)
                }
            }
            .accessibilityHidden(true)
    }
}

// MARK: - Cards

/// A card: warm white with a hairline edge on paper; raised charcoal at
/// night. `elevated` adds the soft warm shadow, for cards on still pages
/// only: in 設定, whose pages slide at 120Hz, a shadow per card would be
/// drawn offscreen on every frame of the slide.
struct FieluaCardBackground<S: InsettableShape>: ViewModifier {
    var shape: S
    var fill: Color = Theme.card
    var elevated = false
    @Environment(\.colorScheme) private var colorScheme

    func body(content: Content) -> some View {
        content.background {
            if elevated && colorScheme != .dark {
                shape.fill(fill)
                    .overlay { shape.strokeBorder(Theme.cardStroke, lineWidth: 0.5) }
                    .shadow(color: FieluaShadow.color, radius: FieluaShadow.radius, y: FieluaShadow.y)
            } else {
                shape.fill(fill)
                    .overlay { shape.strokeBorder(Theme.cardStroke, lineWidth: 0.5) }
            }
        }
    }
}

extension View {
    /// The card behind this view, in rounded corners.
    func fieluaCard(cornerRadius: CGFloat = FieluaRadius.card, fill: Color = Theme.card,
                    elevated: Bool = false) -> some View {
        modifier(FieluaCardBackground(shape: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous),
                                      fill: fill, elevated: elevated))
    }

    /// Fielua's look for everything under it: the warm ink as the
    /// foreground (so .secondary and .tertiary are warm too) and the umber
    /// tint for system controls. Set once at the app's root.
    func fieluaAppearance() -> some View {
        foregroundStyle(Theme.ink).tint(Theme.tint)
    }
}

// MARK: - Buttons

/// The main action on a page (続ける, はじめる): a capsule of the system's
/// prominent glass in the brand yellow, its label in ink (9:1; the system's
/// white label would read at 1.5:1), full width.
struct FieluaPrimaryButton: View {
    let title: LocalizedStringKey
    var enabled = true
    let action: () -> Void

    init(_ title: LocalizedStringKey, enabled: Bool = true, action: @escaping () -> Void) {
        self.title = title; self.enabled = enabled; self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title).font(.headline)
                .foregroundStyle(enabled ? Theme.onAccent : Color.secondary)
                .frame(maxWidth: .infinity).padding(.vertical, 6)
        }
        .buttonStyle(.glassProminent)
        .buttonBorderShape(.capsule)
        .controlSize(.large)
        .tint(Theme.accent)
        .disabled(!enabled)
    }
}

extension View {
    /// A card's main button: the brand yellow with an ink label (9:1).
    /// The system's white label on the yellow would read at 1.5:1.
    func fieluaProminentButton() -> some View {
        buttonStyle(.borderedProminent).tint(Theme.accent).foregroundStyle(Theme.onAccent)
    }

    /// A card's other buttons: a quiet warm grey fill with the ink label
    /// (pale amber until 1.1.0 (214)).
    func fieluaSecondaryButton() -> some View {
        buttonStyle(.bordered).tint(Theme.ink)
    }

    /// A switch or a progress bar: the honey of a state that is on, so a
    /// switch's white knob stands out on its track in both modes (the
    /// umber system tint is for text buttons, checks and the caret).
    func fieluaStateTint() -> some View {
        tint(Theme.active)
    }
}

/// A chosen option's mark (a filled check) and an open ring for the others,
/// in the brand yellow with an ink check.
struct FieluaCheckMark: View {
    let on: Bool
    var size: CGFloat = 22
    var body: some View {
        Image(systemName: on ? "checkmark.circle.fill" : "circle")
            .font(.system(size: size))
            .symbolRenderingMode(.palette)
            .foregroundStyle(on ? Theme.onAccent : Color(uiColor: .tertiaryLabel), Theme.accent)
            .contentTransition(.symbolEffect(.replace))
            .accessibilityHidden(true)
    }
}

/// A line icon in a list row, in the warm grey (golden until 1.1.0 (214)):
/// the row's words lead, the icon only helps find them.
struct FieluaRowIcon: View {
    let systemName: String
    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: 18, weight: .regular))
            .foregroundStyle(Theme.icon)
            .frame(width: 28)
            .accessibilityHidden(true)
    }
}

// MARK: - Empty states

/// What an empty place shows: the flower, small and quiet, and at most one
/// short line. No instructions, no AI words. The empty chat's own flower is
/// LivingFlower (FlowerMark.swift), which lets a petal go now and then.
struct FieluaEmptyMark: View {
    var size: CGFloat = 56
    var body: some View {
        FlowerMark(size: size)
            .opacity(0.9)
            .accessibilityHidden(true)
    }
}
