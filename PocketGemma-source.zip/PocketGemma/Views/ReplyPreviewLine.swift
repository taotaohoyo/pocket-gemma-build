import SwiftUI
import UIKit
import PocketCore

/// 生成中の一節 (1.1.0 (301)): the newest words the model has written,
/// faint beside the Aurora Orb while it writes on under the reply
/// (ReplyPreview decides which). In the footnote's size and the ink at
/// under half, so it never reads louder than the reply; each character
/// comes in from clear in the orb's gold and settles to the faint ink, the
/// way the reply's own text does, only quieter. A full phrase gives way by
/// rising a few points into a soft blur as the next comes up into its
/// place; when the reply is written it goes the same way with the orb.
/// With Reduce Motion, or when the phone is critically hot, phrases only
/// cross-fade. Never read aloud: the reply's own text is.
enum ReplyPreviewStyle {
    /// How much of the ink the words are drawn in: about 3:1 on paper and
    /// on charcoal, quieter than 状態の一行 (0.68) and the reply.
    static let inkShare = 0.5
    /// A character's fade in, its gold's hold and its way to the ink.
    static let fadeIn: TimeInterval = 0.35
    static let goldHold: TimeInterval = 0.15
    static let goldFade: TimeInterval = 0.6
    /// The characters of one read come one after another, this far apart
    /// at most, all within `spread`.
    static let spacing: TimeInterval = 0.035
    static let spread: TimeInterval = 0.3
    /// A phrase giving way: up this far into this much blur.
    static let rise: CGFloat = 5
    static let blur: CGFloat = 2.5
    /// A new phrase comes up from this far below.
    static let arrive: CGFloat = 4
    /// The words leaving with the orb at the reply's end.
    static let leave: TimeInterval = 0.4

    /// The gold of a character just written: as the reply's text's, toned
    /// for its faint ink.
    static func gold(dark: Bool) -> (red: Double, green: Double, blue: Double) {
        dark ? (1.0, 0.86, 0.55) : (0.80, 0.56, 0.05)
    }

    static func smooth(_ x: Double) -> Double {
        let s = min(max(x, 0), 1)
        return s * s * (3 - 2 * s)
    }
}

/// How the row lays a phrase out, to know when it fills its two lines: the
/// footnote font at the app's fixed text size (AppTextSize).
enum ReplyPreviewMeasure {
    static let font = UIFont.preferredFont(forTextStyle: .footnote,
                                           compatibleWith: UITraitCollection(preferredContentSizeCategory: AppTextSize.category(AppTextSize.size)))
    static var lineHeight: Double { Double(font.lineHeight) }

    /// The text's height in `width` points (a little less, so the phrase
    /// never breaks a line later than SwiftUI does).
    static func height(_ text: String, width: Double) -> Double {
        guard width > 8, !text.isEmpty else { return 0 }
        let rect = (text as NSString).boundingRect(with: CGSize(width: width - 4, height: .greatestFiniteMagnitude),
                                                   options: [.usesLineFragmentOrigin, .usesFontLeading],
                                                   attributes: [.font: font], context: nil)
        return Double(ceil(rect.height))
    }
}

/// The phrase (and the one giving way) at `now`, its first line's top at
/// the view's top less half its height, so it stays centred on the orb.
struct ReplyPreviewLine: View {
    let preview: ReplyPreview
    /// Changes whenever the phrase does, so a still frame is drawn again.
    let version: Int
    /// Reference-date seconds: the frame's, or the present for a still one.
    let now: TimeInterval
    let width: CGFloat
    /// Seconds since the orb began to close at the reply's end.
    let leaving: TimeInterval?
    let still: Bool

    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        let scale = preview.timeScale
        let gone = leaving.map { ReplyPreviewStyle.smooth($0 / (ReplyPreviewStyle.leave * scale)) } ?? 0
        ZStack(alignment: .topLeading) {
            if !still, let previous = preview.previous {
                let way = ReplyPreviewStyle.smooth((now - previous.at) / (ReplyPreview.swapDuration * scale))
                if way < 1 {
                    words(Text(previous.phrase.text))
                        .opacity(1 - way)
                        .blur(radius: ReplyPreviewStyle.blur * CGFloat(way))
                        .offset(y: centring(previous.phrase) - ReplyPreviewStyle.rise * CGFloat(way))
                }
            }
            if let current = preview.current {
                if still {
                    words(Text(current.text))
                        .offset(y: -CGFloat(current.height) / 2)
                        .id(current.number)
                        .transition(.opacity)
                } else {
                    let arriving = 1 - ReplyPreviewStyle.smooth((now - current.shownAt) / (ReplyPreview.swapDuration * scale))
                    words(marked(current))
                        .textRenderer(ReplyPreviewRenderer(now: now, dark: colorScheme == .dark, scale: scale))
                        .offset(y: centring(current) + ReplyPreviewStyle.arrive * CGFloat(arriving))
                }
            }
        }
        .frame(width: max(width, 1), alignment: .topLeading)
        .opacity(1 - gone)
        .blur(radius: still ? 0 : ReplyPreviewStyle.blur * CGFloat(gone))
        .offset(y: still ? 0 : -4 * CGFloat(gone))
        .animation(still ? .easeInOut(duration: 0.25) : nil, value: version)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func words(_ text: Text) -> some View {
        text
            .font(.footnote)
            .foregroundStyle(Theme.ink.opacity(ReplyPreviewStyle.inkShare))
            .lineLimit(ReplyPreview.lines)
            .frame(width: max(width, 1), alignment: .leading)
            .fixedSize(horizontal: false, vertical: true)
    }

    /// Up by half its height, easing as it grows to a second line.
    private func centring(_ phrase: ReplyPreview.Phrase) -> CGFloat {
        -CGFloat(ReplyPreview.height(of: phrase, at: now, timeScale: preview.timeScale)) / 2
    }

    /// The phrase with each piece marked with when it came.
    private func marked(_ phrase: ReplyPreview.Phrase) -> Text {
        let characters = Array(phrase.text)
        var result = Text(verbatim: "")
        var from = 0
        for piece in phrase.pieces {
            let to = min(piece.count, characters.count)
            guard to > from else { continue }
            let count = to - from
            let spacing = min(ReplyPreviewStyle.spacing, ReplyPreviewStyle.spread / Double(count)) * preview.timeScale
            result = result + Text(verbatim: String(characters[from..<to]))
                .customAttribute(ReplyPreviewArrival(at: piece.at, spacing: spacing))
            from = to
        }
        if from < characters.count {
            result = result + Text(verbatim: String(characters[from...]))
        }
        return result
    }
}

private struct ReplyPreviewArrival: TextAttribute {
    let at: TimeInterval
    let spacing: TimeInterval
}

/// Each character of a piece by how far along its own coming it is: from
/// clear, in the gold, to the faint ink. Characters of long-settled pieces
/// (time 0) are drawn as they are.
private struct ReplyPreviewRenderer: TextRenderer {
    let now: TimeInterval
    let dark: Bool
    let scale: Double

    func draw(layout: Text.Layout, in context: inout GraphicsContext) {
        let fadeIn = ReplyPreviewStyle.fadeIn * scale
        let hold = ReplyPreviewStyle.goldHold * scale
        let fade = ReplyPreviewStyle.goldFade * scale
        let settled = fadeIn + hold + fade
        let gold = ReplyPreviewStyle.gold(dark: dark)
        var piece: TimeInterval?
        var ordinal = 0
        for line in layout {
            for run in line {
                guard let mark = run[ReplyPreviewArrival.self], mark.at > 0 else {
                    context.draw(run)
                    piece = nil
                    continue
                }
                if mark.at != piece {
                    piece = mark.at
                    ordinal = 0
                }
                for slice in run {
                    let age = now - (mark.at + Double(ordinal) * mark.spacing)
                    ordinal += 1
                    if age >= settled {
                        context.draw(slice)
                        continue
                    }
                    guard age >= 0 else { continue }
                    var copy = context
                    let opacity = ReplyPreviewStyle.smooth(age / fadeIn)
                    copy.opacity *= opacity
                    let share = age < hold ? 1 : 1 - ReplyPreviewStyle.smooth((age - hold) / fade)
                    let mix = dark ? share * opacity : share
                    if mix > 0.01 {
                        var matrix = ColorMatrix()
                        let own = Float(1 - mix)
                        matrix.r1 = own
                        matrix.g2 = own
                        matrix.b3 = own
                        matrix.r4 = Float(mix * gold.red)
                        matrix.g4 = Float(mix * gold.green)
                        matrix.b4 = Float(mix * gold.blue)
                        copy.addFilter(.colorMatrix(matrix))
                    }
                    copy.draw(slice)
                }
            }
        }
    }
}
