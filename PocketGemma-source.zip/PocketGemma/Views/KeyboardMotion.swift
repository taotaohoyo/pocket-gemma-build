import UIKit

/// Whether the keyboard is on its way down, so a reply can wait for it
/// before the model starts on the GPU (1.1.0 (188)). A send puts the
/// keyboard away and starts the reply in the same moment; with another
/// app's Picture in Picture on screen that left the lower half of the
/// screen black and unanswering on the phone (2026-10-25), where the
/// keyboard had been.
@MainActor
final class KeyboardMotion {
    static let shared = KeyboardMotion()
    /// The longest a reply waits: iOS's keyboard takes about a third of a
    /// second to go down.
    static let longestWait: Duration = .milliseconds(500)
    private(set) var leaving = false
    private var waiting: [CheckedContinuation<Void, Never>] = []
    private var observers: [NSObjectProtocol] = []

    private init() {
        let center = NotificationCenter.default
        observers = [
            center.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.leaving = true }
            },
            center.addObserver(forName: UIResponder.keyboardDidHideNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.settle() }
            },
            center.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.settle() }
            },
        ]
    }

    /// The send is about to put the keyboard away (ChatView.send). iOS
    /// may tell of the keyboard leaving only after the reply has started.
    func expectHide() { leaving = true }

    /// Returns once the keyboard is down, at once when it isn't going
    /// down, and after `longestWait` at the latest.
    func settled() async {
        guard leaving else { return }
        let timeout = Task { [weak self] in
            try? await Task.sleep(for: Self.longestWait)
            self?.settle()
        }
        await withCheckedContinuation { waiting.append($0) }
        timeout.cancel()
    }

    private func settle() {
        leaving = false
        let resumed = waiting
        waiting = []
        resumed.forEach { $0.resume() }
    }
}
