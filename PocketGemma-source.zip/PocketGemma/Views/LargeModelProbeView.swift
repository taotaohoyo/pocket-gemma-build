import SwiftUI
import UIKit
import PocketCore

/// Where the developer 12B check keeps its file, cache and records: apart
/// from the chat's models (AppFiles.models), until モデル管理's 12B takes
/// the file over (ModelStore). The file sits in Documents/Verification, so
/// it shows in the Files app and can be deleted there too.
enum LargeModelProbeFiles {
    private static var root: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PocketGemma/LargeModelProbe", isDirectory: true)
    }
    static var folder: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Verification", isDirectory: true)
    }
    /// The check's own copy of the file.
    static var ownModel: URL { folder.appendingPathComponent(LargeModelProbe.model.fileName) }
    /// The file the check reads: the chat's verified 12B once モデル管理 has
    /// it (ModelStore takes the check's file over), otherwise its own.
    static var model: URL { chatModel ?? ownModel }
    private static var chatModel: URL? {
        #if POCKET_PREVIEW
        return nil
        #else
        return AppFiles.hasVerifiedModel(.gemma12B) ? AppFiles.model(.gemma12B) : nil
        #endif
    }
    /// Hidden until checked; the same volume as Documents, so finishing is a rename.
    static var pending: URL { root.appendingPathComponent("download.pending") }
    static var resumeData: URL { root.appendingPathComponent("download.resume") }
    private static var receipt: URL { root.appendingPathComponent("verified.txt") }
    static func cache(_ backend: LargeModelProbe.Backend) -> URL {
        root.appendingPathComponent("Cache/\(backend.rawValue)", isDirectory: true)
    }
    static var log: LargeModelProbe.Log { LargeModelProbe.Log(url: root.appendingPathComponent("records.json")) }
    /// The 12B comparison's (LargeModelChatCompare) records and caches.
    static var compareLog: LargeModelChatCompare.Log { LargeModelChatCompare.Log(url: root.appendingPathComponent("compare.json")) }
    static var compareCache: URL { root.appendingPathComponent("CompareCache", isDirectory: true) }

    /// The check's own pinned file, checked once (size and SHA-256) and
    /// unchanged since.
    static var ownFileReady: Bool {
        guard let receipt = try? String(contentsOf: receipt, encoding: .utf8), receipt == LargeModelProbe.model.sha256,
              let size = (try? FileManager.default.attributesOfItem(atPath: ownModel.path)[.size]) as? NSNumber else { return false }
        return size.int64Value == LargeModelProbe.model.byteCount
    }
    static var isReady: Bool { chatModel != nil || ownFileReady }

    static func prepare() throws {
        for folder in [root, folder] {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            // Gigabytes that can be downloaded again stay out of backups.
            var url = folder, values = URLResourceValues()
            values.isExcludedFromBackup = true
            try url.setResourceValues(values)
        }
    }

    /// After ModelStore moved the check's file to the chat's models: the
    /// rest of the check's files go as with `deleteFiles`.
    static func handedOver() { deleteFiles() }

    /// Call only with a file whose size and SHA-256 were checked (ModelValidator,
    /// or the native probe's pinned download).
    static func installVerified(_ file: URL) throws {
        try prepare()
        if FileManager.default.fileExists(atPath: ownModel.path) { try FileManager.default.removeItem(at: ownModel) }
        try FileManager.default.moveItem(at: file, to: ownModel)
        try LargeModelProbe.model.sha256.write(to: receipt, atomically: true, encoding: .utf8)
    }

    static func cacheBytes(_ backend: LargeModelProbe.Backend? = nil) -> Int64 {
        let folders = backend.map { [cache($0)] } ?? LargeModelProbe.Backend.allCases.map(cache)
        return folders.reduce(Int64(0)) { total, folder in
            let files = FileManager.default.enumerator(at: folder, includingPropertiesForKeys: [.fileSizeKey])
            var bytes: Int64 = 0
            while let file = files?.nextObject() as? URL {
                bytes += Int64((try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
            }
            return total + bytes
        }
    }

    /// The check's own file, its cache and any partial download; the
    /// records stay, and so does the chat's 12B.
    static func deleteFiles() {
        try? FileManager.default.removeItem(at: receipt)
        for url in [ownModel, pending, resumeData, root.appendingPathComponent("Cache", isDirectory: true), compareCache] {
            try? FileManager.default.removeItem(at: url)
        }
    }
}

/// The 12B file's download for the check: a foreground session of its own,
/// so the chat models' background downloads and their Live Activity never
/// see it. It needs the screen on; an interrupted download keeps what it
/// received and goes on from there.
@MainActor
final class LargeModelDownload: NSObject, ObservableObject {
    @Published private(set) var progress: Double?
    @Published private(set) var verifying = false
    @Published private(set) var canResume = FileManager.default.fileExists(atPath: LargeModelProbeFiles.resumeData.path)
    @Published var error: String?
    @Published private(set) var ready = LargeModelProbeFiles.isReady
    private var task: URLSessionDownloadTask?
    private lazy var session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)

    var isRunning: Bool { progress != nil || verifying }

    func start() {
        #if POCKET_PREVIEW
        error = "UI検証用アプリではダウンロードしません。"
        #else
        guard !isRunning, !ready else { return }
        do {
            try LargeModelProbeFiles.prepare()
            let spec = LargeModelProbe.model
            let resume = try? Data(contentsOf: LargeModelProbeFiles.resumeData)
            if resume == nil, DeviceOverview.freeDiskBytes < spec.byteCount + 2_000_000_000 {
                error = "空き容量が足りません。12Bのファイル（\(spec.sizeLabel)）に加えて2 GB以上の空きが必要です。"
                return
            }
            error = nil
            progress = 0
            task = resume.map { session.downloadTask(withResumeData: $0) } ?? session.downloadTask(with: spec.downloadURL)
            try? FileManager.default.removeItem(at: LargeModelProbeFiles.resumeData)
            canResume = false
            UIApplication.shared.isIdleTimerDisabled = true
            task?.resume()
        } catch { self.error = error.localizedDescription }
        #endif
    }

    /// Keeps what was received, so the next start goes on from there.
    func stop() {
        task?.cancel(byProducingResumeData: { data in
            Task { @MainActor in self.keep(resume: data) }
        })
    }

    func delete() {
        guard !isRunning else { return }
        LargeModelProbeFiles.deleteFiles()
        canResume = false
        refresh()
    }

    func refresh() { ready = LargeModelProbeFiles.isReady }

    private func keep(resume data: Data?) {
        UIApplication.shared.isIdleTimerDisabled = false
        progress = nil; task = nil
        if let data {
            try? data.write(to: LargeModelProbeFiles.resumeData, options: .atomic)
            canResume = true
        }
    }

    private func verify() {
        verifying = true
        Task {
            do {
                try await Task.detached(priority: .userInitiated) {
                    try ModelValidator.validate(LargeModelProbeFiles.pending, spec: LargeModelProbe.model)
                    try LargeModelProbeFiles.installVerified(LargeModelProbeFiles.pending)
                }.value
            } catch {
                try? FileManager.default.removeItem(at: LargeModelProbeFiles.pending)
                self.error = error.localizedDescription
            }
            verifying = false
            ready = LargeModelProbeFiles.isReady
        }
    }
}

extension LargeModelDownload: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                                totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let expected = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : LargeModelProbe.model.byteCount
        let fraction = min(1, Double(totalBytesWritten) / Double(expected))
        Task { @MainActor in
            if let shown = self.progress, fraction - shown > 0.002 || fraction == 1 { self.progress = fraction }
        }
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let status = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0
        var failure: String?
        if (200...299).contains(status) {
            do {
                // URLSession removes its temporary file when this returns.
                if FileManager.default.fileExists(atPath: LargeModelProbeFiles.pending.path) {
                    try FileManager.default.removeItem(at: LargeModelProbeFiles.pending)
                }
                try FileManager.default.moveItem(at: location, to: LargeModelProbeFiles.pending)
            } catch { failure = error.localizedDescription }
        } else { failure = "ダウンロードに失敗しました（HTTP \(status)）。" }
        let result = failure
        Task { @MainActor in
            UIApplication.shared.isIdleTimerDisabled = false
            self.progress = nil; self.task = nil
            if let result { self.error = result } else { self.verify() }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error else { return }
        let nsError = error as NSError
        let resume = nsError.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        let cancelled = nsError.code == NSURLErrorCancelled
        Task { @MainActor in
            // A stop keeps its resume data in stop()'s handler.
            guard self.progress != nil else { return }
            self.keep(resume: resume)
            if !cancelled {
                self.error = "ダウンロードが中断しました。" + (resume == nil ? "" : "「続きからダウンロード」で再開できます。") + "\n" + error.localizedDescription
            }
        }
    }
}

/// 開発者設定's 12Bの動作確認 (2026-10-26): download the pinned Gemma 4 12B
/// file into its own folder, start it once on the CPU or the GPU with one
/// fixed question, and keep what happened. The 12B stays locked in the
/// chats whatever this finds.
struct LargeModelProbeView: View {
    @EnvironmentObject private var chats: ChatStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var download = LargeModelDownload()
    @State private var backend = LargeModelProbe.Backend.cpu
    @State private var running = false
    @State private var records: [LargeModelProbe.Record] = []
    @State private var confirmDeletion = false
    @State private var comparing = false
    @State private var compareRecords: [LargeModelChatCompare.Record] = []

    private var ranThisLaunch: Bool {
        #if POCKET_PREVIEW
        return false
        #else
        return LargeModelProbeRunner.runsThisLaunch > 0
        #endif
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Gemma 4 12Bを1回だけ起動し、決まった質問「\(LargeModelProbe.question)」に答えさせて、読み込み・速度・メモリ・失敗の理由を記録します。チャットとは別に動かし、会話履歴と保存済みの設定は変えません。現在のAIのメモリを解放してから実行します。")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(LaunchMemory.atLaunch.entitlementSummary + "\n" + LaunchMemory.atLaunch.memorySummary)
                        .font(.caption).textSelection(.enabled)
                }
                Section("ファイル") {
                    LabeledContent(LargeModelProbe.model.name, value: !download.ready ? LargeModelProbe.model.sizeLabel
                                   : LargeModelProbeFiles.ownFileReady ? "ダウンロード済み" : "モデル管理のファイルを使用")
                        .accessibilityIdentifier("probe-12b-file")
                    if let progress = download.progress {
                        ProgressView(value: progress) { Text("ダウンロード中 \(Int(progress * 100))%") }.tint(Theme.tint)
                        Text("画面を開いたままお待ちください。止めても、受け取った分から続けられます。")
                            .font(.caption).foregroundStyle(.secondary)
                        Button("ダウンロードを止める", role: .cancel) { download.stop() }
                    } else if download.verifying {
                        HStack { ProgressView(); Text("ファイルを確認しています…").font(.subheadline) }
                    } else if !download.ready {
                        Button(download.canResume ? "続きからダウンロード" : "12Bをダウンロード（\(LargeModelProbe.model.sizeLabel)）") { download.start() }
                            .accessibilityIdentifier("probe-12b-download")
                        Text("保存先: このiPhone › Fielua › Verification。チャットのモデルとは別の場所です。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    if download.ready || download.canResume {
                        Button("12Bのファイルとキャッシュを削除", role: .destructive) { confirmDeletion = true }
                            .disabled(running || download.isRunning)
                    }
                    if let error = download.error { Text(error).font(.caption).foregroundStyle(.red) }
                }
                Section("実行") {
                    Picker("実行方法", selection: $backend) {
                        ForEach(LargeModelProbe.Backend.allCases) { Text($0.title).tag($0) }
                    }.pickerStyle(.segmented).accessibilityIdentifier("probe-12b-backend")
                    Text("まずCPUで試してください。GPUは重みをメモリに置くため、iOSがアプリを終了することがあります。その場合も、開き直すとどの段階で終わったかがここに残ります。Context \(LargeModelProbe.contextTokens)・回答は最大\(LargeModelProbe.maxOutputTokens)トークンです。")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(ranThisLaunch
                         ? "この起動では確認済みです。正しく測るため、アプリを完全に終了して開き直してから次を実行してください。"
                         : "アプリを開き直した直後に、1回ずつ実行してください。")
                        .font(.caption).foregroundStyle(ranThisLaunch ? HierarchicalShapeStyle.primary : HierarchicalShapeStyle.secondary)
                    Button(running ? "12Bを動かしています…" : "\(backend.title)で1回試す") { run() }
                        .disabled(running || !download.ready || download.isRunning || chats.isGenerating || ranThisLaunch)
                        .accessibilityIdentifier("probe-12b-run")
                    if running { ProgressView() }
                }
                if download.ready {
                    // LargeModelChatCompare: which GPU setting 1.1.0 (200)'s
                    // garbled 12B replies need, in one run.
                    Section("チャットの設定で比べる") {
                        Text("12BをGPUで\(LargeModelChatCompare.engines.count)回起動し、Context（1024・4096）、重みの準備を待つ設定（ベンチマークモード）、32ビットを1つずつ変えて、確認の質問と「\(LargeModelChatCompare.hello)」に答えさせます。「こんにちはー！」はチャットと同じ12Bの設定で送ります。10分ほどかかります。画面を開いたまま、ロックしないでください。")
                            .font(.caption).foregroundStyle(.secondary)
                        Button(comparing ? "比べています…" : "\(LargeModelChatCompare.engines.count)通りで比べる") { compare() }
                            .disabled(running || comparing || download.isRunning || chats.isGenerating)
                            .accessibilityIdentifier("compare-12b-run")
                        if comparing { ProgressView() }
                        ForEach(compareRecords) { record in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(record.date.formatted(date: .abbreviated, time: .shortened)).font(.caption.weight(.semibold))
                                Text(record.summary).font(.caption).textSelection(.enabled)
                            }
                        }
                        if !compareRecords.isEmpty {
                            Button("比較の結果をコピー", systemImage: "doc.on.doc") {
                                UIPasteboard.general.string = compareRecords.map { $0.date.formatted(.iso8601) + "\n" + $0.summary }
                                    .joined(separator: "\n\n")
                            }
                            .accessibilityIdentifier("compare-12b-copy")
                        }
                    }
                }
                Section("結果") {
                    if records.isEmpty {
                        Text("まだ記録はありません。").font(.caption).foregroundStyle(.secondary)
                    }
                    ForEach(records) { record in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(record.date.formatted(date: .abbreviated, time: .shortened)).font(.caption.weight(.semibold))
                            Text(record.summary).font(.caption).textSelection(.enabled)
                        }
                    }
                    if !records.isEmpty {
                        Button("結果をコピー", systemImage: "doc.on.doc") { UIPasteboard.general.string = report }
                            .accessibilityIdentifier("probe-12b-copy")
                    }
                }
            }
            .navigationTitle("12Bの動作確認").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() }.disabled(running || comparing) } }
            .alert("12Bのファイルを削除しますか？", isPresented: $confirmDeletion) {
                Button("キャンセル", role: .cancel) {}
                Button("削除", role: .destructive) { download.delete() }
            } message: { Text("ダウンロードした12Bとキャッシュを削除します。記録は残ります。") }
            .task { reload() }
        }
        .interactiveDismissDisabled(running || comparing || download.isRunning)
    }

    /// Every record in full, with the native lines, for a report.
    private var report: String {
        records.map { record in
            ([record.date.formatted(.iso8601), record.appVersion, record.device, record.summary]
             + (record.nativeLines.isEmpty ? [] : ["ネイティブログ:"] + record.nativeLines)).joined(separator: "\n")
        }.joined(separator: "\n\n")
    }

    private func reload() {
        records = LargeModelProbeFiles.log.load()
        compareRecords = LargeModelProbeFiles.compareLog.load()
        download.refresh()
    }

    private func compare() {
        #if POCKET_PREVIEW
        download.error = "UI検証用アプリではネイティブ推論を実行しません。"
        #else
        comparing = true
        // The GPU stops when the app leaves the screen.
        UIApplication.shared.isIdleTimerDisabled = true
        Task {
            defer { comparing = false; UIApplication.shared.isIdleTimerDisabled = false; reload() }
            _ = try? await chats.runLargeModelChatCompare()
        }
        // Each reply is saved as it comes.
        Task {
            while comparing {
                compareRecords = LargeModelProbeFiles.compareLog.load()
                try? await Task.sleep(for: .seconds(2))
            }
        }
        #endif
    }

    private func run() {
        #if POCKET_PREVIEW
        download.error = "UI検証用アプリではネイティブ推論を実行しません。"
        #else
        running = true
        Task {
            defer { running = false; reload() }
            _ = try? await chats.runLargeModelProbe(backend: backend)
        }
        #endif
    }
}
