"""Render the app icon: the five-colour banded orb on a frosted tile, for the light, dark
and tinted home screen. The orb is the one of 1.0.122 to 1.1.0 (174); since 1.1.0 (176) its
glow is lighter and closer, so the orb reads sharp on the home screen. The earlier icons and
their scripts are kept in design/legacy. Needs numpy, scipy and Pillow."""
import json
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter

root = Path(__file__).resolve().parents[1]
catalog = root / "PocketGemma/Assets.xcassets"
icons = catalog / "AppIcon.appiconset"
SS, FINAL = 2048, 1024            # rendered at twice the size, then downsampled
RADIUS = 0.315                    # orb radius as a fraction of the canvas

# Blue (top left) to red (bottom right) as diagonal bands, so red never meets blue.
STOPS = [(0.00, "#1d7ff5"), (0.27, "#20ab5d"), (0.50, "#f8c01a"),
         (0.68, "#f1ab28"), (0.92, "#e35c4f"), (1.00, "#e35c4f")]

M1 = np.array([[0.4122214708, 0.5363325363, 0.0514459929],
               [0.2119034982, 0.6806995451, 0.1073969566],
               [0.0883024619, 0.2817188376, 0.6299787005]])
M2 = np.array([[0.2104542553, 0.7936177850, -0.0040720468],
               [1.9779984951, -2.4285922050, 0.4505937099],
               [0.0259040371, 0.7827717662, -0.8086757660]])


def hex_rgb(h):
    return np.array([int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)])


def to_linear(c):
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def to_srgb(c):
    c = np.clip(c, 0, 1)
    return np.where(c <= 0.0031308, c * 12.92, 1.055 * c ** (1 / 2.4) - 0.055)


def lin_to_lab(c):
    return np.cbrt(c @ M1.T) @ M2.T


def lab_to_lin(lab):
    return ((lab @ np.linalg.inv(M2).T) ** 3) @ np.linalg.inv(M1).T


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def ramp(t):
    """OKLab stops through a smoothed lookup table, so no crease shows at a stop."""
    keys = np.array([k for k, _ in STOPS])
    labs = np.array([lin_to_lab(to_linear(hex_rgb(h))) for _, h in STOPS])
    grid = np.linspace(0, 1, 2001)
    lut = np.stack([gaussian_filter(np.interp(grid, keys, labs[:, c]), 50, mode="nearest")
                    for c in range(3)], -1)
    return lut[np.clip((t * 2000).astype(int), 0, 2000)]


def orb(n):
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    R = RADIUS * n
    u = (xx - (n - 1) / 2) / R
    v = -(yy - (n - 1) / 2) / R
    r = np.hypot(u, v)

    # Silk: the bands run to the lower right and their edges ripple in long S-curves.
    along = u * 0.91 - v * 0.41
    across = u * 0.41 + v * 0.91
    across += 0.19 * np.sin(1.8 * along + 0.7) + 0.05 * np.sin(4.3 * along - 1.3) - 0.06 * along ** 2
    lab = ramp(np.clip(0.5 - 0.5 * across / 0.82, 0, 1))
    base = np.clip(lab_to_lin(lab), 0, 1)

    # Soft sheen along two ripples, strongest in the middle of the orb.
    sheen = (np.exp(-((across + 0.02) / 0.085) ** 2) * np.exp(-((along + 0.05) / 0.62) ** 2)
             * (0.65 + 0.35 * np.sin(2.6 * along + 1.2))
             + 0.75 * np.exp(-((across + 0.40) / 0.055) ** 2) * np.exp(-((along - 0.30) / 0.42) ** 2))
    inner = 1 - smoothstep(0.6, 1.0, r)
    lab[..., 0] += 0.07 * sheen * inner
    lab[..., 1:] *= (1 - 0.30 * sheen * inner)[..., None]

    # A lighter rim and a thin, crisp glass edge.
    rim = smoothstep(0.84, 1.0, r) ** 1.8
    line = np.exp(-((r - 0.986) / 0.007) ** 2)
    lab[..., 0] += 0.05 * rim + 0.13 * line
    lab[..., 1:] *= (1 - 0.08 * rim - 0.55 * line)[..., None]

    alpha = np.clip((1 - r) * R / 1.6 + 0.5, 0, 1)
    return np.clip(lab_to_lin(lab), 0, 1), alpha, base


def blur(img, n, sigma, low=256):
    """Gaussian blur at low resolution, scaled back up; returns (colour channels, last channel)."""
    def resize(a, size, method):
        return np.asarray(Image.fromarray(a.astype(np.float32)).resize((size, size), method))
    small = np.stack([resize(img[..., c], low, Image.Resampling.BOX) for c in range(img.shape[-1])], -1)
    small = np.stack([gaussian_filter(small[..., c], sigma * low, mode="nearest")
                      for c in range(small.shape[-1])], -1)
    big = np.stack([resize(small[..., c], n, Image.Resampling.BICUBIC)
                    for c in range(small.shape[-1])], -1).astype(np.float64)
    return big[..., :-1], big[..., -1]


def render(mode, n=SS):
    rgb, alpha, base = orb(n)
    # The orb's colours spill outward as light: on white like tinted frosted glass, on black as glow.
    # A quarter of 1.0.122's near glow and under half its far glow, each reaching 0.6 as far.
    src = np.dstack([base * alpha[..., None], alpha])
    g1, a1 = blur(src, n, 0.015 if mode == "dark" else 0.021)
    g2, a2 = blur(src, n, 0.06)
    hue = g2 / np.clip(a2, 1e-5, None)[..., None]
    hue /= np.clip(hue.max(-1, keepdims=True), 1e-5, None)

    y = (np.mgrid[0:n, 0:n][0] / (n - 1))[..., None]
    if mode == "light":
        bg = to_linear(hex_rgb("#fbfbfd")) * (1 - y) + to_linear(hex_rgb("#f1f2f7")) * y
        k = np.clip(0.175 * a1 + 0.52 * a2, 0, 0.9)[..., None]
        out = bg * (1 - k + k * hue)
        halo = np.clip(blur(alpha[..., None], n, 0.010, low=512)[1] - alpha, 0, 1)[..., None]
        out = out * (1 - 0.12 * halo) + 0.12 * halo
    else:
        bg = to_linear(hex_rgb("#0d0c14")) * (1 - y) + to_linear(hex_rgb("#040407")) * y
        out = bg + hue * (0.25 * a1 + 0.0315 * a2)[..., None]
    out = out * (1 - alpha[..., None]) + rgb * alpha[..., None]
    image = Image.fromarray((to_srgb(out) * 255 + 0.5).astype(np.uint8))
    return image.resize((FINAL, FINAL), Image.Resampling.LANCZOS)


def tinted(dark):
    """Grayscale for the tinted home screen: iOS colours it, so keep the bands as light and shade."""
    gray = np.asarray(dark.convert("L")).astype(np.float64) / 255
    gray = np.clip((gray - 0.03) / (np.percentile(gray, 99.7) - 0.03), 0, 1) ** 1.15
    return Image.fromarray((gray * 255 + 0.5).astype(np.uint8)).convert("RGB")


icons.mkdir(parents=True, exist_ok=True)
render("light").save(icons / "AppIcon.png")
dark = render("dark")
dark.save(icons / "AppIcon-Dark.png")
tinted(dark).save(icons / "AppIcon-Tinted.png")
(icons / "Contents.json").write_text(json.dumps({
    "images": [
        {"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"},
        {"appearances": [{"appearance": "luminosity", "value": "dark"}],
         "filename": "AppIcon-Dark.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"},
        {"appearances": [{"appearance": "luminosity", "value": "tinted"}],
         "filename": "AppIcon-Tinted.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"},
    ],
    "info": {"author": "xcode", "version": 1},
}, indent=2))
print(icons)
