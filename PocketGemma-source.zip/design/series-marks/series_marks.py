#!/usr/bin/env python3
"""Fielua's own marks for the model series: Gemma, Qwen and LFM.

fielua-reports Issue #19 (2026-11-15): marks that call each series to mind
without using, tracing or retouching anyone's logo. Chosen by the user from
the preview of 2026-11-15 as look A (the symbol in a round paper tile), for
every place a model's mark shows.

  Gemma: a softly cut gem seen from above (a rounded hexagon, its table and
         six crown facets lit from the upper left) and two grains of light
         in Fielua's yellow.
  Qwen:  two rounded planes laid over each other at different angles; where
         they overlap the colour turns lighter, like light through two panes.
  LFM:   a drop leaning as if it had just started to flow, in three layers
         divided by soft curves.

Everything is plain geometry on a 100 x 100 canvas: polygons, cubic curves,
circles, two-stop linear gradients and clips. This script bakes every
transform into the coordinates and writes

  PocketGemma/Views/SeriesMarkArt.swift   (the app and the Live Activity)
  --svg DIR: <series>-<light|dark>.svg    (to look at, or to compare)

so the app draws exactly what was previewed. Run from the source root:

  python3 design/series-marks/series_marks.py
  python3 design/series-marks/series_marks.py --svg build/series-marks
"""
import math
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
SWIFT = ROOT / "PocketGemma/Views/SeriesMarkArt.swift"

# ----------------------------------------------------------------- colours --
# Light tiles sit on Fielua's paper cards (#FFFDF9), dark ones on #221F1B.
TILE = {"light": dict(tile=("#FBF8F2", "#F1EBE0"), rim="#E6DED0"),
        "dark": dict(tile=("#2C2823", "#24211D"), rim="#3A352E")}
PAL = {
    "gemma": {
        "light": dict(ramp=["#2F62C8", "#4B7EDF", "#6E9AEC", "#97B8F4", "#C4D7FA"],
                      table=("#F4F8FF", "#C9DBFB"), glint="#FFFFFF", grain="#F5C542"),
        "dark": dict(ramp=["#3E70D6", "#5A8BE8", "#7EA6F2", "#A5C2F7", "#D2E1FC"],
                     table=("#EAF1FF", "#B9CFF8"), glint="#FFFFFF", grain="#F7CF5A"),
    },
    "qwen": {
        "light": dict(back=("#8B7CE8", "#6E5DD8"), front=("#5B4BC9", "#4636B0"), overlap=("#C9C0FA", "#A99CF2")),
        "dark": dict(back=("#9C8EF0", "#7F6FE4"), front=("#6A5AD8", "#5444C2"), overlap=("#DCD5FD", "#B9AEF7")),
    },
    "lfm": {
        "light": dict(layers=[("#A6E3D3", "#7FD3BF"), ("#3FB49B", "#2A9C86"), ("#17766A", "#0F5E57")], sheen="#FFFFFF"),
        "dark": dict(layers=[("#B9EDDF", "#8EDCC8"), ("#4CC4A9", "#36AD94"), ("#1F8C7D", "#177369")], sheen="#FFFFFF"),
    },
}
# How large each symbol is drawn in its tile: by eye, so the three read as
# the same size.
SCALE = {"gemma": 1.13, "qwen": 1.17, "lfm": 1.04}
# LFM's drop is tall and leans right, so its middle is not its box's: it
# moves left and down until the drop's weight sits in the tile's middle and
# its tip keeps clear of the edge (the user's note, 2026-11-15 12:45 UTC).
LFM_SHIFT = (-2.9, 3.2)


def rgba(hex_, alpha=1.0):
    h = hex_.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), alpha)


def mix(c1, c2, t):
    a, b = rgba(c1), rgba(c2)
    return "#" + "".join(f"{round(a[i] + (b[i] - a[i]) * t):02X}" for i in range(3))


# ---------------------------------------------------------------- geometry --
# A path is a list of steps: ("M", x, y), ("L", x, y), ("C", x1, y1, x2, y2, x, y), ("Z",).

def rounded_polygon(points, r):
    """A convex polygon with rounded corners (each corner one cubic)."""
    n, steps = len(points), []
    for i in range(n):
        p0, p1, p2 = points[i - 1], points[i], points[(i + 1) % n]
        v1 = (p0[0] - p1[0], p0[1] - p1[1]); l1 = math.hypot(*v1)
        v2 = (p2[0] - p1[0], p2[1] - p1[1]); l2 = math.hypot(*v2)
        ang = math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2))))
        t = min(r / math.tan(ang / 2), l1 / 2, l2 / 2)
        a = (p1[0] + v1[0] / l1 * t, p1[1] + v1[1] / l1 * t)
        b = (p1[0] + v2[0] / l2 * t, p1[1] + v2[1] / l2 * t)
        k = 0.55
        c1 = (a[0] + (p1[0] - a[0]) * k, a[1] + (p1[1] - a[1]) * k)
        c2 = (b[0] + (p1[0] - b[0]) * k, b[1] + (p1[1] - b[1]) * k)
        steps.append(("M" if i == 0 else "L", *a))
        steps.append(("C", *c1, *c2, *b))
    return steps + [("Z",)]


def polygon(points):
    return [("M", *points[0])] + [("L", *p) for p in points[1:]] + [("Z",)]


def ellipse(cx, cy, rx, ry, deg=0.0):
    k = 0.5522847498
    pts = [(rx, 0), (rx, ry * k), (rx * k, ry), (0, ry), (-rx * k, ry), (-rx, ry * k), (-rx, 0),
           (-rx, -ry * k), (-rx * k, -ry), (0, -ry), (rx * k, -ry), (rx, -ry * k), (rx, 0)]
    m = rotation(deg, cx, cy)
    pts = [apply(m, (cx + x, cy + y)) for x, y in pts]
    steps = [("M", *pts[0])]
    for i in range(1, 13, 3):
        steps.append(("C", *pts[i], *pts[i + 1], *pts[i + 2]))
    return steps + [("Z",)]


def circle(cx, cy, r):
    return ellipse(cx, cy, r, r)


def bar(a, b, width):
    """A straight stroke from a to b with butt ends, as a filled quad."""
    dx, dy = b[0] - a[0], b[1] - a[1]; l = math.hypot(dx, dy)
    nx, ny = -dy / l * width / 2, dx / l * width / 2
    return polygon([(a[0] + nx, a[1] + ny), (b[0] + nx, b[1] + ny), (b[0] - nx, b[1] - ny), (a[0] - nx, a[1] - ny)])


def parse(d):
    """The few absolute commands used below: M, L, C, Z."""
    tokens = d.replace(",", " ").replace("M", " M ").replace("L", " L ").replace("C", " C ").replace("Z", " Z ").split()
    steps, i = [], 0
    while i < len(tokens):
        op = tokens[i]; i += 1
        if op == "Z":
            steps.append(("Z",)); continue
        count = {"M": 2, "L": 2, "C": 6}[op]
        while True:
            steps.append((op, *[float(t) for t in tokens[i:i + count]])); i += count
            if i >= len(tokens) or tokens[i] in "MLCZ":
                break
            op = "L" if op == "M" else op
    return steps


# Affine matrices (a, b, c, d, e, f): x' = a x + c y + e, y' = b x + d y + f.
def mul(m, n):
    a, b, c, d, e, f = m; A, B, C, D, E, F = n
    return (a * A + c * B, b * A + d * B, a * C + c * D, b * C + d * D, a * E + c * F + e, b * E + d * F + f)


def rotation(deg, cx=0.0, cy=0.0):
    t = math.radians(deg); co, si = math.cos(t), math.sin(t)
    return mul(mul((1, 0, 0, 1, cx, cy), (co, si, -si, co, 0, 0)), (1, 0, 0, 1, -cx, -cy))


def translation(x, y):
    return (1, 0, 0, 1, x, y)


def scaling(k, cx=50.0, cy=50.0):
    return mul(mul((1, 0, 0, 1, cx, cy), (k, 0, 0, k, 0, 0)), (1, 0, 0, 1, -cx, -cy))


IDENTITY = (1, 0, 0, 1, 0, 0)


def apply(m, p):
    a, b, c, d, e, f = m
    return (a * p[0] + c * p[1] + e, b * p[0] + d * p[1] + f)


def moved(steps, m):
    out = []
    for s in steps:
        if s[0] == "Z":
            out.append(s); continue
        pts = [apply(m, (s[i], s[i + 1])) for i in range(1, len(s), 2)]
        out.append((s[0], *[v for p in pts for v in p]))
    return out


def bounds(steps):
    xs, ys, last = [], [], None
    for s in steps:
        if s[0] in "ML":
            last = (s[1], s[2]); xs.append(s[1]); ys.append(s[2])
        elif s[0] == "C":
            p0, p1, p2, p3 = last, (s[1], s[2]), (s[3], s[4]), (s[5], s[6])
            for k in range(1, 401):
                t = k / 400; u = 1 - t
                xs.append(u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0])
                ys.append(u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1])
            last = p3
    return min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)


def bbox_gradient(steps, x1, y1, x2, y2):
    """SVG's objectBoundingBox gradient on `steps` as the same gradient in the
    canvas's own space (iso-lines stay where the bounding box put them)."""
    bx, by, w, h = bounds(steps)
    vx, vy = x2 - x1, y2 - y1
    p1 = (bx + w * x1, by + h * y1)
    nx, ny = vx / w, vy / h
    k = (vx * vx + vy * vy) / (nx * nx + ny * ny)
    return p1, (p1[0] + nx * k, p1[1] + ny * k)


class Layer:
    def __init__(self, steps, paints, clip=None, even_odd=False, rim=False):
        self.steps, self.paints, self.clip, self.even_odd, self.rim = steps, paints, clip, even_odd, rim


def solid(colors, alpha=1.0):
    return {mode: ("solid", rgba(colors[mode], alpha)) for mode in colors}


def linear(steps, colors, x1=0.0, y1=0.0, x2=0.0, y2=1.0):
    start, end = bbox_gradient(steps, x1, y1, x2, y2)
    return {mode: ("linear", rgba(c[0]), rgba(c[1]), start, end) for mode, c in colors.items()}


def per_mode(key, family=None, pick=lambda v: v):
    source = PAL[family] if family else TILE
    return {mode: pick(source[mode][key]) for mode in ("light", "dark")}


# ------------------------------------------------------------------- marks --
def tile_layers():
    disc = circle(50, 50, 49.6)
    ring = circle(50, 50, 49.6) + circle(50, 50, 48.8)
    return [Layer(disc, linear(disc, per_mode("tile"))),
            Layer(ring, solid(per_mode("rim")), even_odd=True, rim=True)]


def gemma_layers(m):
    cx, cy, R, r, a0 = 50, 51, 32, 17, -60
    outer = [(cx + R * math.cos(math.radians(a0 + 60 * i)), cy + R * math.sin(math.radians(a0 + 60 * i))) for i in range(6)]
    inner = [(cx - 1.2 + r * math.cos(math.radians(a0 + 60 * i)), cy - 1.6 + r * math.sin(math.radians(a0 + 60 * i)))
             for i in range(6)]
    hexagon = moved(rounded_polygon(outer, 6.5), m)
    layers = [Layer(hexagon, solid(per_mode("ramp", "gemma", lambda v: v[0])), clip=hexagon)]
    light = math.radians(-125)  # from the upper left
    for i in range(6):
        a, b = outer[i], outer[(i + 1) % 6]
        ia, ib = inner[i], inner[(i + 1) % 6]
        mid = math.atan2((a[1] + b[1]) / 2 - cy, (a[0] + b[0]) / 2 - cx)
        lum = 0.14 + 0.78 * (0.5 + 0.5 * math.cos(mid - light))

        def facet(ramp, lum=lum):
            idx = lum * (len(ramp) - 1.001)
            return mix(ramp[int(idx)], ramp[int(idx) + 1], idx - int(idx))
        # Past the rounded rim, so the clip makes the edge.
        ea = (cx + (a[0] - cx) * 1.15, cy + (a[1] - cy) * 1.15)
        eb = (cx + (b[0] - cx) * 1.15, cy + (b[1] - cy) * 1.15)
        layers.append(Layer(moved(polygon([ea, eb, ib, ia]), m), solid(per_mode("ramp", "gemma", facet)), clip=hexagon))
    table = moved(rounded_polygon(inner, 3), m)
    layers.append(Layer(table, linear(table, per_mode("table", "gemma"), 0.2, 0, 0.8, 1), clip=hexagon))
    for i in range(6):  # thin light seams between the facets
        layers.append(Layer(moved(bar(inner[i], outer[i], 1.1), m), solid({"light": "#FFFFFF", "dark": "#FFFFFF"}, 0.35),
                            clip=hexagon))
    layers.append(Layer(moved(ellipse(cx - 6, cy - 7.5, 4.2, 2.6, -30), m), solid(per_mode("glint", "gemma"), 0.9)))
    layers.append(Layer(moved(circle(75.5, 25, 4.2), m), solid(per_mode("grain", "gemma"))))
    layers.append(Layer(moved(circle(82.5, 35, 2.1), m), solid(per_mode("grain", "gemma"), 0.75)))
    return layers


def pane(cx, cy, w, h, deg):
    a = math.radians(deg); ca, sa = math.cos(a), math.sin(a)
    return [(cx + dx * ca - dy * sa, cy + dx * sa + dy * ca) for dx, dy in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2))]


def qwen_layers(m):
    back = moved(rounded_polygon(pane(40.5, 43, 35, 35, 16), 7), m)
    front = moved(rounded_polygon(pane(59.5, 57.5, 35, 35, -10), 7), m)
    return [Layer(back, linear(back, per_mode("back", "qwen"), 0, 0, 1, 1)),
            Layer(front, linear(front, per_mode("front", "qwen"), 0, 0, 1, 1)),
            Layer(front, linear(front, per_mode("overlap", "qwen"), 0, 0, 1, 1), clip=back)]


def lfm_layers(m):
    m = mul(m, translation(*LFM_SHIFT))
    k = 3  # the drop's shoulder
    drop = parse(f"M50,13 C{54.5 + k},{26 - k * 0.3} 76,{38.5 - k} 76,58.5 C76,72.9 64.4,84 50,84 "
                 f"C35.6,84 24,72.9 24,58.5 C24,{38.5 - k} {45.5 - k},{26 - k * 0.3} 50,13Z")
    # SVG's rotate(15 50 58.5) translate(1 -4.5): the translation first.
    drop = moved(drop, mul(m, mul(rotation(15, 50, 58.5), translation(1, -4.5))))
    top = moved(polygon([(0, 0), (100, 0), (100, 100), (0, 100)]), m)
    middle = moved(parse("M0,60 C20,66 34,46 52,48 C70,50 80,36 100,30 L100,100 L0,100Z"), m)
    bottom = moved(parse("M0,80 C20,84 36,66 55,68 C73,70 84,58 100,52 L100,100 L0,100Z"), m)
    layers = [Layer(s, linear(s, per_mode("layers", "lfm", lambda v, i=i: v[i]), 0, 0, 1, 1), clip=drop)
              for i, s in enumerate((top, middle, bottom))]
    layers.append(Layer(moved(ellipse(42, 44, 5.2, 3, -35), m), solid(per_mode("sheen", "lfm"), 0.8), clip=drop))
    return layers


def mark(series):
    m = scaling(SCALE[series])
    return tile_layers() + {"gemma": gemma_layers, "qwen": qwen_layers, "lfm": lfm_layers}[series](m)


SERIES = ("gemma", "qwen", "lfm")


# --------------------------------------------------------------------- SVG --
def n(v):
    return f"{v:.3f}".rstrip("0").rstrip(".")


def d_of(steps):
    return " ".join(s[0] if s[0] == "Z" else s[0] + " ".join(f"{n(s[i])},{n(s[i + 1])}" for i in range(1, len(s), 2))
                    for s in steps)


def css(c):
    return f"rgba({c[0]},{c[1]},{c[2]},{c[3]})"


_svg_count = [0]


def svg(series, mode, size=100):
    _svg_count[0] += 1
    tag = f"{series}{mode}{_svg_count[0]}"  # ids stay unique when many marks share a page
    defs, body = [], []
    for i, layer in enumerate(mark(series)):
        paint = layer.paints[mode]
        if paint[0] == "solid":
            fill = css(paint[1])
        else:
            gid = f"{tag}g{i}"
            defs.append(f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" x1="{n(paint[3][0])}" '
                        f'y1="{n(paint[3][1])}" x2="{n(paint[4][0])}" y2="{n(paint[4][1])}">'
                        f'<stop offset="0" stop-color="{css(paint[1])}"/><stop offset="1" stop-color="{css(paint[2])}"/>'
                        f'</linearGradient>')
            fill = f"url(#{gid})"
        clip = ""
        if layer.clip:
            defs.append(f'<clipPath id="{tag}c{i}"><path d="{d_of(layer.clip)}"/></clipPath>')
            clip = f' clip-path="url(#{tag}c{i})"'
        rule = ' fill-rule="evenodd"' if layer.even_odd else ""
        body.append(f'<path d="{d_of(layer.steps)}" fill="{fill}"{rule}{clip}/>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="{size}" height="{size}">'
            f'<defs>{"".join(defs)}</defs>{"".join(body)}</svg>')


# ------------------------------------------------------------------- Swift --
def swift_steps(steps):
    out = []
    for s in steps:
        if s[0] == "Z":
            out.append(".close")
        elif s[0] == "M":
            out.append(f".move({n(s[1])}, {n(s[2])})")
        elif s[0] == "L":
            out.append(f".line({n(s[1])}, {n(s[2])})")
        else:
            out.append(".curve(" + ", ".join(n(v) for v in s[1:]) + ")")
    lines, line = [], ""
    for item in out:
        if len(line) + len(item) > 104:
            lines.append(line.rstrip()); line = ""
        line += item + ", "
    lines.append(line.rstrip().rstrip(","))
    return "[\n" + ",\n".join("                " + l.rstrip(",") for l in lines) + "\n            ]"


def swift_colour(c):
    return f"0x{c[0]:02X}{c[1]:02X}{c[2]:02X}, {n(c[3])}"


def swift_paint(p):
    if p[0] == "solid":
        return f".solid({swift_colour(p[1])})"
    return (f".linear({swift_colour(p[1])}, {swift_colour(p[2])}, "
            f"from: ({n(p[3][0])}, {n(p[3][1])}), to: ({n(p[4][0])}, {n(p[4][1])}))")


def swift():
    parts = []
    for series in SERIES:
        layers = []
        for layer in mark(series):
            extra = ""
            if layer.clip:
                extra += f",\n            clip: {swift_steps(layer.clip)}"
            if layer.even_odd:
                extra += ", evenOdd: true"
            if layer.rim:
                extra += ", rim: true"
            layers.append(f"        Layer(\n            {swift_steps(layer.steps)},\n"
                          f"            light: {swift_paint(layer.paints['light'])},\n"
                          f"            dark: {swift_paint(layer.paints['dark'])}{extra})")
        parts.append(f"    static let {series}: [Layer] = [\n" + ",\n".join(layers) + "\n    ]")
    return ("// Generated by design/series-marks/series_marks.py (fielua-reports Issue #19).\n"
            "// Do not edit by hand: change the script and run it again.\n\n"
            "import CoreGraphics\n\n"
            "extension SeriesMarkArt {\n" + "\n\n".join(parts) + "\n}\n")


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--svg":
        folder = pathlib.Path(sys.argv[2]); folder.mkdir(parents=True, exist_ok=True)
        for series in SERIES:
            for mode in ("light", "dark"):
                (folder / f"{series}-{mode}.svg").write_text(svg(series, mode))
        print(f"wrote {folder}")
    else:
        SWIFT.write_text(swift())
        print(f"wrote {SWIFT.relative_to(ROOT)}")
