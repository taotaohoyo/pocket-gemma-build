import SwiftUI
import UIKit
import PocketCore

/// UI checks only (`--glide-trace`, 1.1.0 (303)): where a reply's Aurora
/// Orb and the top of its text were on the screen at each frame the app
/// drew, from the send until the orb has gone, and each move of the orb's
/// row (ReplyFollow). Every line goes to tmp/glide-trace.txt in the app's
/// container (the check prints them, GLIDE lines); a summary goes to the
/// check (`glide-trace`): how far the orb went back up, how much it moved
/// while the reply was written, how long its first move took.
///
/// Positions are the views' as drawn (their layers' presentation), in the
/// window, from small views in the orb's row and at the text's top
/// (GlideMarker).
@MainActor final class GlideTrace: NSObject, ObservableObject {
    static let shared = GlideTrace()
    static let on = PreviewProbe.on("--glide-trace")
    /// `--glide-case <name>`: the case's name in the file.
    static let name: String = {
        let arguments = ProcessInfo.processInfo.arguments
        guard let index = arguments.firstIndex(of: "--glide-case"), index + 1 < arguments.count else { return "case" }
        return arguments[index + 1]
    }()

    enum Role { case orb, text }

    @Published private(set) var summary = "none"
    private weak var orbView: UIView?
    private weak var textView: UIView?
    private var link: CADisplayLink?
    private var start: CFTimeInterval = 0
    private var stopAt: CFTimeInterval?
    private var samples: [(t: Double, orb: Double?, text: Double?)] = []
    private var moves: [(t: Double, change: Double, duration: Double, follows: Bool)] = []
    private var heights: [(t: Double, height: Double)] = []
    private var firstText: Double?

    func register(_ view: UIView, as role: Role) {
        guard Self.on else { return }
        switch role {
        case .orb:
            orbView = view
            begin()
        case .text:
            textView = view
        }
    }

    func unregister(_ view: UIView, as role: Role) {
        guard Self.on else { return }
        if role == .orb, orbView === view {
            orbView = nil
            stopAt = CACurrentMediaTime() + 1.5
        }
        if role == .text, textView === view { textView = nil }
    }

    private func begin() {
        stopAt = nil
        guard link == nil else { return }
        start = CACurrentMediaTime()
        samples = []; moves = []; heights = []; firstText = nil
        GlideLog.shared.begin(at: start)
        GlideLog.shared.write("CASE \(Self.name) epoch " + String(format: "%.3f", Date().timeIntervalSince1970) + "\n")
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    /// The reply's first text, from the row (orbWrites).
    func textBegan() {
        guard Self.on, link != nil, firstText == nil else { return }
        let t = CACurrentMediaTime() - start
        firstText = t
        GlideLog.shared.write(String(format: "F %.4f\n", t))
    }

    /// The reply's text laid out this tall (the row's, now and in 302).
    func laidOut(height: CGFloat) {
        guard Self.on, link != nil else { return }
        let t = CACurrentMediaTime() - start
        guard heights.last.map({ abs($0.height - Double(height)) > 0.25 }) ?? true else { return }
        heights.append((t, Double(height)))
        GlideLog.shared.write(String(format: "H %.4f %.2f\n", t, Double(height)))
    }

    /// A move of the orb's row (ReplyFollow.move).
    func moved(by change: CGFloat, duration: TimeInterval, follows: Bool) {
        guard Self.on, link != nil else { return }
        let t = CACurrentMediaTime() - start
        moves.append((t, Double(change), duration, follows))
        GlideLog.shared.write(String(format: "M %.4f %.2f %.3f %d\n", t, Double(change), duration, follows ? 1 : 0))
    }

    /// The conversation's scroll the move owed it, begun `late` seconds
    /// after the room's move (ReplyFollow.contentLaidOut).
    func scrolled(late: TimeInterval) {
        guard Self.on, link != nil else { return }
        let t = CACurrentMediaTime() - start
        GlideLog.shared.write(String(format: "S2 %.4f %.4f\n", t, late))
    }

    private func y(of view: UIView?) -> Double? {
        guard let view, let window = view.window else { return nil }
        let layer = view.layer.presentation() ?? view.layer
        let root = window.layer.presentation() ?? window.layer
        let seen = layer.convert(layer.bounds, to: root)
        return Double(seen.midY)
    }

    @objc private func tick(_ link: CADisplayLink) {
        let now = CACurrentMediaTime()
        let t = now - start
        let orb = y(of: orbView), text = y(of: textView)
        let last = samples.last
        // Every frame while anything moves, and the last still one before.
        let moved = last.map { previous in
            abs((previous.orb ?? -1) - (orb ?? -1)) > 0.01 || abs((previous.text ?? -1) - (text ?? -1)) > 0.01
        } ?? true
        samples.append((t, orb, text))
        if moved {
            GlideLog.shared.write(String(format: "S %.4f %@ %@\n", t, orb.map { String(format: "%.2f", $0) } ?? "-",
                                         text.map { String(format: "%.2f", $0) } ?? "-"))
        }
        if let stopAt, now >= stopAt { finish() }
    }

    private func finish() {
        link?.invalidate()
        link = nil
        stopAt = nil
        summary = makeSummary()
        GlideLog.shared.write("END \(summary)\n")
        GlideLog.shared.flush()
    }

    /// While the reply was written (its first text until its last move has
    /// ended): how far the orb went back up at most, its range, the
    /// fastest it went between two frames, and its first move's time from
    /// a tenth to nine tenths of the way.
    private func makeSummary() -> String {
        // 302 made no moves of its own: its row followed the text's height
        // (H lines) with a 0.24 s spring, settled in about 0.4 s.
        let grown = heights.filter { $0.height > 0.5 }
        let begun = firstText ?? moves.first?.t ?? grown.first?.t ?? 0
        let ended = max(moves.map { $0.t + $0.duration }.max() ?? begun, (grown.last?.t ?? begun) + 0.45) + 0.05
        let writing = samples.filter { $0.t >= begun - 0.02 && $0.t <= ended }.compactMap { sample in
            sample.orb.map { (t: sample.t, y: $0) }
        }
        var back = 0.0, fastest = 0.0
        var lowest = -Double.infinity
        for (index, sample) in writing.enumerated() {
            lowest = max(lowest, sample.y)
            back = max(back, lowest - sample.y)
            if index > 0 {
                let previous = writing[index - 1]
                let gap = sample.t - previous.t
                if gap > 0.001 { fastest = max(fastest, abs(sample.y - previous.y) / gap) }
            }
        }
        let range = (writing.map { $0.y }.max() ?? 0) - (writing.map { $0.y }.min() ?? 0)
        var rise = -1.0, jump = 0.0
        let firstMove = moves.first.map { (t: $0.t, duration: $0.duration) }
            ?? grown.first.map { (t: $0.t, duration: 0.4) }
        if let first = firstMove {
            let before = samples.last { $0.t <= first.t && $0.orb != nil }?.orb
            let after = samples.last { $0.t <= first.t + first.duration + 0.1 && $0.orb != nil }?.orb
            if let before, let after, abs(after - before) > 4 {
                let way = after - before
                func reached(_ share: Double) -> Double? {
                    samples.first { sample in
                        guard sample.t >= first.t, let y = sample.orb else { return false }
                        return (y - before) / way >= share
                    }?.t
                }
                let tenth = reached(0.1), most = reached(0.9)
                if let tenth, let most { rise = most - tenth }
                // The largest share of the way between two frames drawn.
                let path = samples.filter { $0.t >= first.t - 0.02 && $0.t <= first.t + first.duration + 0.1 }
                    .compactMap { $0.orb }
                for index in path.indices.dropFirst() { jump = max(jump, abs(path[index] - path[index - 1]) / abs(way)) }
            }
        }
        let frames = samples.filter { $0.t >= begun && $0.t <= ended }.count
        let seconds = max(ended - begun, 0.001)
        return String(format: "case %@ samples %ld frames %ld fps %.1f moves %ld back %.2f range %.1f fastest %.0f firstRise %.3f firstJump %.2f",
                      Self.name, samples.count, frames, Double(frames) / seconds, moves.count, back, range, fastest, rise, jump)
    }
}

/// The trace's file (tmp/glide-trace.txt in the app's container), written
/// from a queue of its own every half second, so that what was noted is
/// there even if the main thread is held (run 903: the app stayed busy and
/// nothing was written). Also each time the reply's text was measured and
/// what its room did (L lines), at most 400 a second (LOOP lines count the
/// rest).
final class GlideLog: @unchecked Sendable {
    static let shared = GlideLog()
    private let lock = NSLock()
    private var pending = ""
    private var start: CFTimeInterval = 0
    private var window = 0, inWindow = 0, dropped = 0
    private let queue = DispatchQueue(label: "glide-log")
    private var timer: DispatchSourceTimer?
    private let file = FileManager.default.temporaryDirectory.appendingPathComponent("glide-trace.txt")

    func begin(at start: CFTimeInterval) {
        lock.lock(); self.start = start; lock.unlock()
        guard timer == nil else { return }
        let timer = DispatchSource.makeTimerSource(queue: queue)
        timer.schedule(deadline: .now() + 0.5, repeating: 0.5)
        timer.setEventHandler { [weak self] in self?.flush() }
        timer.resume()
        self.timer = timer
    }

    func write(_ line: String) {
        lock.lock(); pending += line; lock.unlock()
    }

    /// The reply's text measured `height` tall; what its room does.
    private let on = PreviewProbe.on("--glide-trace")

    func laidOut(height: Double, step: ReplyRoom.Step) {
        guard on else { return }
        lock.lock(); defer { lock.unlock() }
        let t = CACurrentMediaTime() - start
        let second = Int(t)
        if second != window {
            if dropped > 0 { pending += "LOOP \(window) \(dropped)\n" }
            window = second; inWindow = 0; dropped = 0
        }
        inWindow += 1
        guard inWindow <= 400 else { dropped += 1; return }
        let what: String
        switch step {
        case .none: what = "none"
        case .settle(let h): what = String(format: "settle %.2f", h)
        case .move(let a, let b): what = String(format: "move %.2f %.2f", a, b)
        case .wait(let until): what = String(format: "wait %.3f", until - Date().timeIntervalSinceReferenceDate)
        }
        pending += String(format: "L %.4f %.2f %@\n", t, height, what)
    }

    func flush() {
        lock.lock()
        let text = pending
        pending = ""
        lock.unlock()
        guard !text.isEmpty, let data = text.data(using: .utf8) else { return }
        queue.async { [file] in
            if let handle = try? FileHandle(forWritingTo: file) {
                handle.seekToEndOfFile(); handle.write(data); try? handle.close()
            } else {
                try? data.write(to: file)
            }
        }
    }
}

/// A point in a reply's row (the orb's centre) or at its text's top, for
/// GlideTrace to find on the screen.
struct GlideMarker: UIViewRepresentable {
    let role: GlideTrace.Role

    final class Marker: UIView {
        var role: GlideTrace.Role = .orb
        override func didMoveToWindow() {
            super.didMoveToWindow()
            if window != nil { GlideTrace.shared.register(self, as: role) } else { GlideTrace.shared.unregister(self, as: role) }
        }
    }

    func makeUIView(context: Context) -> Marker {
        let view = Marker(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        view.role = role
        view.isUserInteractionEnabled = false
        view.backgroundColor = .clear
        return view
    }

    func updateUIView(_ view: Marker, context: Context) {}
}

/// The trace's summary, for the check to read: "none" until the orb has
/// gone and a second and a half more.
struct PreviewGlideTrace: View {
    @ObservedObject private var log = GlideTrace.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("glide-trace")
            .accessibilityLabel(log.summary)
    }
}
