// Separate simulator target. No model, network, or user archive is accessed.
import SwiftUI
import Combine
import PocketCore

@MainActor final class ChatStore: ObservableObject {
    @Published var threads: [ChatThread]
    @Published var selectedID: UUID?
    @Published var isGenerating = false
    @Published var isStopping = false
    @Published var status = ""
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings()).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }
    private var reply: Task<Void, Never>?

    init() {
        if ProcessInfo.processInfo.arguments.contains("--reset-startup") {
            UserDefaults.standard.removeObject(forKey: "model-startup-completed-v1")
        }
        var thread = ChatThread()
        if ProcessInfo.processInfo.arguments.contains("--e2b") { thread.modelID = ModelSpec.e2b.id }
        thread.messages = [ChatMessage(role: .user, text: "画面の動きを確認"),
            ChatMessage(role: .assistant, text: "これはUI検証用のサンプル会話です。実際のAI推論は実行していません。")]
        if ProcessInfo.processInfo.arguments.contains("--long-chat") {
            // --longer-chat: more messages than ChatView lays out eagerly.
            let exchanges = ProcessInfo.processInfo.arguments.contains("--longer-chat") ? 40 : 12
            thread.messages = (1...exchanges).flatMap { index in
                [ChatMessage(role: .user, text: "長い会話の確認 \(index)"),
                 ChatMessage(role: .assistant, text: "スクロールの確認です。過去の返信を読んでいるときには、自動で末尾へ戻りません。入力欄から現れる下向きのボタンで最新の返信へ移動できます。\n\n日本語の折り返しと、上のヘッダーに文章が重ならないことを確認します。")]
            }
            thread.messages.append(ChatMessage(role: .assistant, text: "最新の返信です。ここまで戻りました。"))
        }
        if ProcessInfo.processInfo.arguments.contains("--tall-bubble") {
            let paragraphs = (1...8).map { index in
                "長い返信の表示確認 \(index)\n文章が画面より長くなっても、吹き出しの角丸と余白を揃えます。上下の操作部分には内容が透け、本文だけが自然にぼけていきます。スクロールしながらヘッダーと入力欄の境目を確認するためのサンプル文章です。"
            }.joined(separator: "\n\n")
            thread.messages = [
                ChatMessage(role: .user, text: "こんにちは"),
                ChatMessage(role: .assistant, text: "こんにちは！😊"),
                ChatMessage(role: .assistant, text: "短い返信の角丸も確認します。"),
                ChatMessage(role: .user, text: "長い返信も見せて"),
                ChatMessage(role: .assistant, text: paragraphs)
            ]
        }
        if ProcessInfo.processInfo.arguments.contains("--markdown-sample") {
            thread.messages = [ChatMessage(role: .user, text: "Markdownの表示を確認"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.wide),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.sample)]
        }
        if ProcessInfo.processInfo.arguments.contains("--markdown-article") {
            thread.messages = [ChatMessage(role: .user, text: "長文のMarkdownを表示して"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.article)]
        }
        if ProcessInfo.processInfo.arguments.contains("--restore-fixture-chat"),
           let saved = try? ChatArchive(fileURL: PreviewAttachments.archive).load(), !saved.isEmpty {
            threads = saved
        } else { threads = [thread] }
        if ProcessInfo.processInfo.arguments.contains("--history-fixture") {
            // Older conversations for the history sidebar's layout review.
            for (index, title) in ["旅行の持ち物リスト", "カメムシ対策", "英語メールの添削をお願いします", "夕飯のレシピ",
                                   "写真に写っている花の名前", "iPhoneのバッテリー設定"].enumerated() {
                var older = ChatThread()
                older.messages = [ChatMessage(role: .user, text: title), ChatMessage(role: .assistant, text: "サンプルの返信です。")]
                older.updatedAt = Date().addingTimeInterval(-Double(index + 1) * 3600)
                threads.append(older)
            }
        }
        selectedID = threads.first?.id
        if ProcessInfo.processInfo.arguments.contains("--reset-settings") {
            GenerationPreferences.save([:]); configurations = [:]
            UserDefaults.standard.removeObject(forKey: "show-developer-settings-v1")
        }
    }
    var messages: [ChatMessage] { threads.first { $0.id == selectedID }?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(threads.first { $0.id == selectedID }?.modelID) ?? .e4b }
    func select(_ id: UUID) { if !isGenerating || id == selectedID { selectedID = id } }
    func newChat(modelID: String? = nil) {
        guard !isGenerating else { return }
        let thread = ChatThread(modelID: modelID ?? currentModel.id)
        threads.insert(thread, at: 0)
        selectedID = thread.id
    }
    func delete(_ id: UUID) {
        guard !isGenerating else { return }
        threads.removeAll { $0.id == id }
        if selectedID == id { selectedID = threads.first?.id }
    }
    @discardableResult func send(_ text: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        do { try ModelAttachmentPolicy(model: currentModel).validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        let text = text.isEmpty && !attachments.isEmpty ? "添付した内容を説明してください。" : text
        guard !isGenerating, !text.isEmpty, let ti = threads.firstIndex(where: { $0.id == selectedID }) else { return false }
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[ti].messages.append(ChatMessage(id: messageID, role: .user, text: text, attachments: attachments))
        threads[ti].messages.append(assistant)
        threads[ti].updatedAt = Date()
        isGenerating = true
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
            try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
        }
        status = "UI検証用のサンプルを表示しています…"
        reply = Task {
            do { try await Task.sleep(for: .milliseconds(900)) } catch { return }
            let slow = ProcessInfo.processInfo.arguments.contains("--slow-reply")
            let mediaSummary = attachments.map { item in
                switch item.kind {
                case .image: return "画像\(item.imageNames.count)枚"
                case .video: return "動画\(item.imageNames.count)場面"
                case .file: return "本文: \(item.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")"
                }
            }.joined(separator: "・")
            let stress = ProcessInfo.processInfo.arguments.contains("--layout-stress")
            let chunks = stress ? (1...12).map { index in
                "レイアウト検証\(index)：長文と画像を含む返信を生成しています。**太字の記法**、日本語の折り返し、絵文字😊を含みます。過去の会話を読む操作と、入力欄の高さ変更が重なっても、バブル同士の配置を保ちます。\n\n"
            } : !attachments.isEmpty ? ["添付の読み込み確認: ", mediaSummary]
                : ProcessInfo.processInfo.arguments.contains("--token-stream") ? PreviewTokenStream.chunks
                : ProcessInfo.processInfo.arguments.contains("--markdown-stream") ? PreviewMarkdown.chunks
                : ProcessInfo.processInfo.arguments.contains("--growing-reply") ? (1...12).map { "返信の確認\($0)：日本語の長い文章が少しずつ増えても、表示位置が上下に跳ねず、過去の返信も読めます。\n" }
                : slow ? ["新しい文字が", "ぼやけた状態から", "少しずつ", "くっきり表示されます。", "\nすでに読んだ文章は", "鮮明なままです。", "日本語と絵文字も", "そのまま表示します。😊"]
                : ["プレビュー用", "の返信です。", "入力欄・吹き出し・", "スクロールを確認できます。"]
            for chunk in chunks {
                guard let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) else { return }
                threads[ti].messages[mi].text += chunk
                let tokens = ProcessInfo.processInfo.arguments.contains("--token-stream")
                let markdown = ProcessInfo.processInfo.arguments.contains("--markdown-stream")
                do { try await Task.sleep(for: .milliseconds(stress ? 700 : slow ? 450 : tokens ? 60 : markdown ? 40 : 130)) } catch { return }
            }
            if let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) {
                threads[ti].messages[mi].state = .complete
            }
            isGenerating = false
            status = ""
            if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
                try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
            }
        }
        return true
    }
    func stop() {
        reply?.cancel()
        if let ti = threads.firstIndex(where: { $0.id == selectedID }), let mi = threads[ti].messages.indices.last {
            threads[ti].messages[mi].state = .stopped
        }
        isGenerating = false
        status = ""
    }
    func releaseModelMemory() {}
    func unloadModel() async {}
    func mergeBackup(_ incoming: [ChatThread]) {
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
    }
}

@MainActor final class ModelStore: ObservableObject {
    @Published var error: String?
    @Published var selectedModel = ModelSpec.e4b
    let isReady = true, isBusy = false, isRestoring = false
    func isDownloading(_ spec: ModelSpec) -> Bool { false }
    func isWorking(on spec: ModelSpec) -> Bool { false }
    func progress(for spec: ModelSpec) -> Double { 0 }
    func statusText(for spec: ModelSpec) -> String { "UI検証用・モデル未使用" }
    @Published private(set) var installedIDs: Set<String> = [ModelSpec.e4b.id, ModelSpec.e2b.id, ModelSpec.qwen3.id]
    func isInstalled(_ spec: ModelSpec) -> Bool { installedIDs.contains(spec.id) }
    func delete(_ spec: ModelSpec) { installedIDs.remove(spec.id) }
    func refreshInstalled() {}
    func select(_ spec: ModelSpec) { selectedModel = spec }
    func download(_ spec: ModelSpec) {}
    func cancelDownload(_ spec: ModelSpec) {}
    func importModel(_ url: URL, spec: ModelSpec) {}
}

@main struct PreviewApp: App {
    @StateObject private var chats = ChatStore()
    @StateObject private var model = ModelStore()
    private let arguments = ProcessInfo.processInfo.arguments
    var body: some Scene {
        WindowGroup {
            ChatNavigationView().modifier(StartupPresenter()).environmentObject(chats).environmentObject(model)
                .modifier(PreviewMetricsSwitch(enabled: arguments.contains("--layout-metrics")))
                .environment(\.chatPreviewReduceMotion, arguments.contains("--reduce-motion"))
                .dynamicTypeSize(arguments.contains("--large-type") ? .accessibility3 : .large)
                .preferredColorScheme(arguments.contains("--dark") ? .dark : .light)
                .overlay(alignment: .top) {
                    if arguments.contains("--elastic-diagnostics") { ElasticProbeView() }
                    if arguments.contains("--cloud-fixture") { PreviewCloudCheck() }
                    if arguments.contains("--download-activity") { PreviewDownloadActivity() }
                    if arguments.contains("--pull-snapshot") { PullSnapshotView() }
                }
        }
    }
}

private struct PreviewMetricsSwitch: ViewModifier {
    let enabled: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if enabled { content.modifier(PreviewLayoutMetrics()) } else { content }
    }
}


/// A reply streamed like the on-device model: a few characters at a time,
/// with Markdown list items, growing from one line to about one screen.
enum PreviewTokenStream {
    static let text = """
    テスト、ですね！😊

    どのようなテストをしたいですか？例えば、以下のようなものが考えられます。

    1. **知識の確認テスト**（例：歴史、科学、語彙など）
    2. **簡単なクイズ**（雑学など）
    3. **文章の作成テスト**（文章を書く練習など）
    4. **特定のトピックについての質問応答テスト**

    もしよろしければ、**「〇〇についてのクイズを出して」**とか、**「算数の問題を出して」**といった具体的なご要望を教えてください！

    それとも、**「まずは何か一つ出して」**といった感じで始めても大丈夫ですよ！
    """
    static var chunks: [String] {
        var result: [String] = []
        var current = ""
        for character in text {
            current.append(character)
            if current.count == 3 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}

/// Every Markdown feature replies render, finished (`--markdown-sample`) or
/// streamed a few characters at a time (`--markdown-stream`).
enum PreviewMarkdown {
    static let sample = #"""
    ## Markdownの表示

    **太字**、*斜体*、~~取り消し線~~、`インラインコード`、[リンク](https://www.apple.com/jp/) を使えます。

    > 引用文です。**強調**や `code` も入ります。

    1. 準備する
    2. 実行する
       - [x] 完了した項目
       - [ ] まだの項目

    | モデル | 速度 | メモリ | 画像 |
    |:--|--:|--:|:-:|
    | E2B | 速い | 0.6 GB | ○ |
    | E4B | 普通 | 0.85 GB | 調整中 |

    ```swift
    struct Greeting {
        let name = "Pocket AI" // 名前
        func text() -> String { "こんにちは、\(name)さん" }
    }
    ```

    二次方程式の解は $x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$ です。

    $$
    \int_0^1 x^2\,dx = \frac{1}{3}
    $$

    ---

    ![サンプル画像](https://example.com/sample.png)
    """#

    /// A long reply like ChatGPT's (`--markdown-article`): every heading
    /// level, long paragraphs, nested and two-digit numbered lists, a quote,
    /// rules, a table and code, for the spacing and alignment review.
    static let article = #"""
    # 2035年のAIと暮らし

    AIが身近になった未来を想像しながら、見出し・リスト・表・コードの表示を確かめる長文です。段落が長くなっても、左右の余白をそろえたまま自然に折り返して読めるかを確認します。

    ここは2つ目の段落です。**太字の強調**と見出しの違い、*斜体*、~~取り消し線~~、`インラインコード` が本文の中で読みやすく並ぶかを見ます。

    ## 第1章：朝のルーティン

    朝7時、目覚ましより先にAIがカーテンを開けます。今日の予定と天気を短くまとめて読み上げ、通勤経路の混雑も先回りして知らせてくれます。

    ### 出かける前の準備

    1. 天気を確認する
    2. 持ち物をそろえる
       - 傘（午後から雨）
       - 充電器
         - USB-Cケーブル
         - モバイルバッテリー
    3. 家を出る時間を決める

    #### 確認するところ

    - 箇条書きの記号と本文の頭がそろっているか
    - 長い項目でも、2行目が記号の下に回り込まず、本文の頭にそろって折り返されるかを確かめるための少し長めの項目です
    - [x] チェック済みの項目
    - [ ] まだの項目

    ##### H5 の小見出し

    本文と同じくらいの大きさでも、**太字の文**とは区別できるかを見ます。

    ###### H6 の補足

    > AIは道具であり、使い方を決めるのは人です。
    > 引用は左の線と文字の色で本文と分けます。

    ---

    ## 第2章：数字で見る変化

    | 項目 | 2025年 | 2035年 |
    |:--|--:|--:|
    | AIを毎日使う人 | 30% | 85% |
    | 平均通勤時間 | 45分 | 28分 |

    ```python
    def greet(name):
        return f"おはよう、{name}さん"
    ```

    10. 二桁の番号
    11. の項目も
    12. 本文の頭がそろうか

    最後の段落です。表やコードのあとでも、段落の間隔が同じに保たれるかを確認します。
    """#

    static var wide: String {
        let code = (1...35).map { "def step_\($0)(x):\n    return x + \($0)  # \($0)番目" }.joined(separator: "\n")
        return """
        横に長い表と長いコードの確認です。

        | 項目 | 1月 | 2月 | 3月 | 4月 | 5月 | 6月 | 合計 |
        |---|--:|--:|--:|--:|--:|--:|--:|
        | 売上 | 120 | 135 | 150 | 160 | 172 | 180 | 917 |
        | 費用 | 80 | 82 | 90 | 95 | 99 | 101 | 547 |

        ```python
        \(code)
        ```
        """
    }

    static var chunks: [String] {
        var result: [String] = []
        var current = ""
        for character in sample {
            current.append(character)
            if current.count == 4 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}
