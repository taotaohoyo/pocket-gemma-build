// Separate simulator target. No model, network, or user archive is accessed.
import SwiftUI
import Combine
import PocketCore

@MainActor final class ChatStore: ObservableObject {
    @Published var threads: [ChatThread]
    @Published var selectedID: UUID?
    @Published var isGenerating = false
    @Published var isStopping = false
    @Published var status = ""
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings()).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }
    private var reply: Task<Void, Never>?

    init() {
        if ProcessInfo.processInfo.arguments.contains("--reset-startup") {
            UserDefaults.standard.removeObject(forKey: "model-startup-completed-v1")
        }
        var thread = ChatThread()
        if ProcessInfo.processInfo.arguments.contains("--e2b") { thread.modelID = ModelSpec.e2b.id }
        thread.messages = [ChatMessage(role: .user, text: "画面の動きを確認"),
            ChatMessage(role: .assistant, text: "これはUI検証用のサンプル会話です。実際のAI推論は実行していません。")]
        if ProcessInfo.processInfo.arguments.contains("--long-chat") {
            thread.messages = (1...12).flatMap { index in
                [ChatMessage(role: .user, text: "長い会話の確認 \(index)"),
                 ChatMessage(role: .assistant, text: "スクロールの確認です。過去の返信を読んでいるときには、自動で末尾へ戻りません。入力欄から現れる下向きのボタンで最新の返信へ移動できます。\n\n日本語の折り返しと、上のヘッダーに文章が重ならないことを確認します。")]
            }
            thread.messages.append(ChatMessage(role: .assistant, text: "最新の返信です。ここまで戻りました。"))
        }
        if ProcessInfo.processInfo.arguments.contains("--tall-bubble") {
            let paragraphs = (1...8).map { index in
                "長い返信の表示確認 \(index)\n文章が画面より長くなっても、吹き出しの角丸と余白を揃えます。上下の操作部分には内容が透け、本文だけが自然にぼけていきます。スクロールしながらヘッダーと入力欄の境目を確認するためのサンプル文章です。"
            }.joined(separator: "\n\n")
            thread.messages = [
                ChatMessage(role: .user, text: "こんにちは"),
                ChatMessage(role: .assistant, text: "こんにちは！😊"),
                ChatMessage(role: .assistant, text: "短い返信の角丸も確認します。"),
                ChatMessage(role: .user, text: "長い返信も見せて"),
                ChatMessage(role: .assistant, text: paragraphs)
            ]
        }
        if ProcessInfo.processInfo.arguments.contains("--restore-fixture-chat"),
           let saved = try? ChatArchive(fileURL: PreviewAttachments.archive).load(), !saved.isEmpty {
            threads = saved
        } else { threads = [thread] }
        selectedID = threads.first?.id
        if ProcessInfo.processInfo.arguments.contains("--reset-settings") {
            GenerationPreferences.save([:]); configurations = [:]
            UserDefaults.standard.removeObject(forKey: "show-developer-settings-v1")
        }
    }
    var messages: [ChatMessage] { threads.first { $0.id == selectedID }?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(threads.first { $0.id == selectedID }?.modelID) ?? .e4b }
    func select(_ id: UUID) { if !isGenerating || id == selectedID { selectedID = id } }
    func newChat(modelID: String? = nil) {
        guard !isGenerating else { return }
        let thread = ChatThread(modelID: modelID ?? currentModel.id)
        threads.insert(thread, at: 0)
        selectedID = thread.id
    }
    func delete(_ id: UUID) {
        guard !isGenerating else { return }
        threads.removeAll { $0.id == id }
        if selectedID == id { selectedID = threads.first?.id }
    }
    @discardableResult func send(_ text: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        do { try ModelAttachmentPolicy(model: currentModel).validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        let text = text.isEmpty && !attachments.isEmpty ? "添付した内容を説明してください。" : text
        guard !isGenerating, !text.isEmpty, let ti = threads.firstIndex(where: { $0.id == selectedID }) else { return false }
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[ti].messages.append(ChatMessage(id: messageID, role: .user, text: text, attachments: attachments))
        threads[ti].messages.append(assistant)
        threads[ti].updatedAt = Date()
        isGenerating = true
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
            try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
        }
        status = "UI検証用のサンプルを表示しています…"
        reply = Task {
            do { try await Task.sleep(for: .milliseconds(900)) } catch { return }
            let slow = ProcessInfo.processInfo.arguments.contains("--slow-reply")
            let mediaSummary = attachments.map { item in
                switch item.kind {
                case .image: return "画像\(item.imageNames.count)枚"
                case .video: return "動画\(item.imageNames.count)場面"
                case .file: return "本文: \(item.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")"
                }
            }.joined(separator: "・")
            let stress = ProcessInfo.processInfo.arguments.contains("--layout-stress")
            let chunks = stress ? (1...12).map { index in
                "レイアウト検証\(index)：長文と画像を含む返信を生成しています。**太字の記法**、日本語の折り返し、絵文字😊を含みます。過去の会話を読む操作と、入力欄の高さ変更が重なっても、バブル同士の配置を保ちます。\n\n"
            } : !attachments.isEmpty ? ["添付の読み込み確認: ", mediaSummary]
                : ProcessInfo.processInfo.arguments.contains("--growing-reply") ? (1...12).map { "返信の確認\($0)：日本語の長い文章が少しずつ増えても、表示位置が上下に跳ねず、過去の返信も読めます。\n" }
                : slow ? ["新しい文字が", "ぼやけた状態から", "少しずつ", "くっきり表示されます。", "\nすでに読んだ文章は", "鮮明なままです。", "日本語と絵文字も", "そのまま表示します。😊"]
                : ["プレビュー用", "の返信です。", "入力欄・吹き出し・", "スクロールを確認できます。"]
            for chunk in chunks {
                guard let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) else { return }
                threads[ti].messages[mi].text += chunk
                do { try await Task.sleep(for: .milliseconds(stress ? 700 : slow ? 450 : 130)) } catch { return }
            }
            if let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) {
                threads[ti].messages[mi].state = .complete
            }
            isGenerating = false
            status = ""
            if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
                try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
            }
        }
        return true
    }
    func stop() {
        reply?.cancel()
        if let ti = threads.firstIndex(where: { $0.id == selectedID }), let mi = threads[ti].messages.indices.last {
            threads[ti].messages[mi].state = .stopped
        }
        isGenerating = false
        status = ""
    }
    func releaseModelMemory() {}
    func mergeBackup(_ incoming: [ChatThread]) {
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
    }
}

@MainActor final class ModelStore: ObservableObject {
    @Published var error: String?
    @Published var selectedModel = ModelSpec.e4b
    let operationModelID: String? = nil
    let isReady = true, isBusy = false, isDownloading = false, isVerifying = false, isRestoring = false
    let progress = 0.0
    let statusText = "UI検証用・モデル未使用"
    func isInstalled(_ spec: ModelSpec) -> Bool { spec.id == ModelSpec.e4b.id || spec.id == ModelSpec.e2b.id || spec.id == ModelSpec.qwen3.id }
    func select(_ spec: ModelSpec) { selectedModel = spec }
    func download(_ spec: ModelSpec) {}
    func cancelDownload() {}
    func importModel(_ url: URL, spec: ModelSpec) {}
}

@main struct PreviewApp: App {
    @StateObject private var chats = ChatStore()
    @StateObject private var model = ModelStore()
    private let arguments = ProcessInfo.processInfo.arguments
    var body: some Scene {
        WindowGroup {
            ChatNavigationView().modifier(StartupPresenter()).environmentObject(chats).environmentObject(model)
                .modifier(PreviewMetricsSwitch(enabled: arguments.contains("--layout-metrics")))
                .environment(\.chatPreviewReduceMotion, arguments.contains("--reduce-motion"))
                .dynamicTypeSize(arguments.contains("--large-type") ? .accessibility3 : .large)
                .preferredColorScheme(arguments.contains("--dark") ? .dark : .light)
                .overlay(alignment: .top) {
                    if arguments.contains("--elastic-diagnostics") { ElasticProbeView() }
                    if arguments.contains("--cloud-fixture") { PreviewCloudCheck() }
                }
        }
    }
}

private struct PreviewMetricsSwitch: ViewModifier {
    let enabled: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if enabled { content.modifier(PreviewLayoutMetrics()) } else { content }
    }
}
