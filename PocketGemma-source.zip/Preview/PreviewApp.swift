// Separate simulator target. No model, network, or user archive is accessed.
import SwiftUI
import UIKit
import Combine
import PocketCore

@MainActor final class ChatStore: ObservableObject {
    @Published var threads: [ChatThread]
    @Published var selectedID: UUID?
    @Published var isGenerating = false
    @Published var isStopping = false
    @Published var status = ""
    @Published var error: String?
    @Published private var configurations = GenerationPreferences.load()
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings(for: currentModel)).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }
    /// As the app's ChatStore: E4B's 高速・深く (and さらに深く), saved with its
    /// settings.
    var photoDetail: PhotoDetail { currentSettings.photoDetail }
    func setPhotoDetail(_ detail: PhotoDetail) {
        guard !isGenerating, currentModel.photoDetails.contains(detail) else { return }
        var settings = currentSettings
        settings.photoDetail = detail
        updateSettings(settings)
    }
    private var reply: Task<Void, Never>?
    /// As the app's ChatStore: the chat's web search switch. The preview
    /// never reaches the network; a search here is a fixed sample.
    var webSearchOn: Bool { threads.first { $0.id == selectedID }?.webSearch == true }
    var webSearchBlocked: Bool { WebSearchPolicy.blockedByFiles(messages) }
    var webSearchOffered: Bool { WebSearchPolicy.offers(currentModel) }
    func setWebSearch(_ on: Bool) {
        guard !isGenerating, let index = threads.firstIndex(where: { $0.id == selectedID }) else { return }
        threads[index].webSearch = on ? true : nil
    }

    init() {
        if ProcessInfo.processInfo.arguments.contains("--reset-startup") {
            UserDefaults.standard.removeObject(forKey: "model-startup-completed-v1")
        }
        var thread = ChatThread()
        if ProcessInfo.processInfo.arguments.contains("--e2b") { thread.modelID = ModelSpec.e2b.id }
        if ProcessInfo.processInfo.arguments.contains("--qwen3") { thread.modelID = ModelSpec.qwen3.id }
        thread.messages = [ChatMessage(role: .user, text: "画面の動きを確認"),
            ChatMessage(role: .assistant, text: "これはUI検証用のサンプル会話です。実際のAI推論は実行していません。")]
        if ProcessInfo.processInfo.arguments.contains("--long-chat") {
            // --longer-chat: more messages than ChatView lays out eagerly.
            let exchanges = ProcessInfo.processInfo.arguments.contains("--longer-chat") ? 40 : 12
            thread.messages = (1...exchanges).flatMap { index in
                [ChatMessage(role: .user, text: "長い会話の確認 \(index)"),
                 ChatMessage(role: .assistant, text: "スクロールの確認です。過去の返信を読んでいるときには、自動で末尾へ戻りません。入力欄から現れる下向きのボタンで最新の返信へ移動できます。\n\n日本語の折り返しと、上のヘッダーに文章が重ならないことを確認します。")]
            }
            thread.messages.append(ChatMessage(role: .assistant, text: "最新の返信です。ここまで戻りました。"))
        }
        if ProcessInfo.processInfo.arguments.contains("--tall-bubble") {
            let paragraphs = (1...8).map { index in
                "長い返信の表示確認 \(index)\n文章が画面より長くなっても、吹き出しの角丸と余白を揃えます。上下の操作部分には内容が透け、本文だけが自然にぼけていきます。スクロールしながらヘッダーと入力欄の境目を確認するためのサンプル文章です。"
            }.joined(separator: "\n\n")
            thread.messages = [
                ChatMessage(role: .user, text: "こんにちは"),
                ChatMessage(role: .assistant, text: "こんにちは！😊"),
                ChatMessage(role: .assistant, text: "短い返信の角丸も確認します。"),
                ChatMessage(role: .user, text: "長い返信も見せて"),
                ChatMessage(role: .assistant, text: paragraphs)
            ]
        }
        if ProcessInfo.processInfo.arguments.contains("--markdown-sample") {
            thread.messages = [ChatMessage(role: .user, text: "Markdownの表示を確認"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.wide),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.sample)]
        }
        if ProcessInfo.processInfo.arguments.contains("--wide-table") {
            thread.messages = [ChatMessage(role: .user, text: "横に長い表を見せて"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.wideTable)]
        }
        if ProcessInfo.processInfo.arguments.contains("--chart-sample") {
            thread.messages = [ChatMessage(role: .user, text: "グラフで見せて"),
                               ChatMessage(role: .assistant, text: PreviewCharts.first),
                               ChatMessage(role: .assistant, text: PreviewCharts.second)]
        }
        // --web-search: the chat's search on; --web-search-sample: a reply
        // that searched, with its pages. --web-search-key saves a sample
        // Tavily key in the keychain and --web-search-no-key removes it.
        if ProcessInfo.processInfo.arguments.contains("--web-search-key") { WebSearchKeyState.shared.save("tvly-preview-sample") }
        if ProcessInfo.processInfo.arguments.contains("--web-search-no-key") { WebSearchKeyState.shared.delete() }
        if ProcessInfo.processInfo.arguments.contains("--web-search") { thread.webSearch = true }
        if ProcessInfo.processInfo.arguments.contains("--web-search-sample") {
            var answer = ChatMessage(role: .assistant, text: "東京スカイツリーの高さは**634メートル**です。2012年に開業した電波塔で、自立式の電波塔としては世界一の高さです。")
            answer.webSearch = PreviewWebSearch.record(query: "東京スカイツリー 高さ")
            thread.messages = [ChatMessage(role: .user, text: "スカイツリーの高さは？"), answer]
        }
        if ProcessInfo.processInfo.arguments.contains("--markdown-article") {
            thread.messages = [ChatMessage(role: .user, text: "長文のMarkdownを表示して"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.article)]
        }
        if ProcessInfo.processInfo.arguments.contains("--restore-fixture-chat"),
           let saved = try? ChatArchive(fileURL: PreviewAttachments.archive).load(), !saved.isEmpty {
            threads = saved
        } else { threads = [thread] }
        if ProcessInfo.processInfo.arguments.contains("--history-fixture") {
            // Older conversations for the history sidebar's layout review.
            for (index, title) in ["旅行の持ち物リスト", "カメムシ対策", "英語メールの添削をお願いします", "夕飯のレシピ",
                                   "写真に写っている花の名前", "iPhoneのバッテリー設定"].enumerated() {
                var older = ChatThread()
                older.messages = [ChatMessage(role: .user, text: title), ChatMessage(role: .assistant, text: "サンプルの返信です。")]
                older.updatedAt = Date().addingTimeInterval(-Double(index + 1) * 3600)
                threads.append(older)
            }
        }
        selectedID = threads.first?.id
        if ProcessInfo.processInfo.arguments.contains("--reset-settings") {
            GenerationPreferences.save([:]); configurations = [:]
            UserDefaults.standard.removeObject(forKey: "show-developer-settings-v1")
        }
        // Each launch starts with 縮小型, so a check that chose 従来型 leaves
        // the next one the composer it expects; `--classic-composer` starts
        // with 従来型, `--keep-composer-style` with the type chosen before.
        if ProcessInfo.processInfo.arguments.contains("--classic-composer") {
            UserDefaults.standard.set(ComposerStyle.classic.rawValue, forKey: ComposerStyle.storageKey)
        } else if !ProcessInfo.processInfo.arguments.contains("--keep-composer-style") {
            UserDefaults.standard.removeObject(forKey: ComposerStyle.storageKey)
        }
        // The developer models, as if the switch in the model list were on,
        // for this launch only (a registered default is not saved).
        if ProcessInfo.processInfo.arguments.contains("--developer-settings") {
            UserDefaults.standard.removeObject(forKey: "show-developer-settings-v1")
            UserDefaults.standard.register(defaults: ["show-developer-settings-v1": true])
        }
    }
    var messages: [ChatMessage] { threads.first { $0.id == selectedID }?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(threads.first { $0.id == selectedID }?.modelID) ?? .e4b }
    func select(_ id: UUID) { if !isGenerating || id == selectedID { selectedID = id } }
    func newChat(modelID: String? = nil) {
        guard !isGenerating else { return }
        let thread = ChatThread(modelID: modelID ?? currentModel.id)
        threads.insert(thread, at: 0)
        selectedID = thread.id
    }
    func delete(_ id: UUID) {
        guard !isGenerating else { return }
        threads.removeAll { $0.id == id }
        if selectedID == id { selectedID = threads.first?.id }
    }
    @discardableResult func send(_ text: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        do { try ModelAttachmentPolicy(model: currentModel).validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        let text = text.isEmpty && !attachments.isEmpty ? "添付した内容を説明してください。" : text
        guard !isGenerating, !text.isEmpty, let ti = threads.firstIndex(where: { $0.id == selectedID }) else { return false }
        let assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        threads[ti].messages.append(ChatMessage(id: messageID, role: .user, text: text, attachments: attachments))
        threads[ti].messages.append(assistant)
        threads[ti].updatedAt = Date()
        isGenerating = true
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
            try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
        }
        status = "UI検証用のサンプルを表示しています…"
        let searches = WebSearchPolicy.searches(enabled: threads[ti].webSearch == true, keyed: WebSearchKeyState.shared.isSet,
                                                model: currentModel, messages: threads[ti].messages.dropLast(2).map { $0 },
                                                attachments: attachments)
        // --orb-wait: a long wait before the first token, a line break that
        // draws nothing, then the text 0.3 s later as from a model, so the
        // Aurora Orb can be checked while it waits, as it shrinks away from
        // the first token, and holding the text back until it has gone.
        let orbWait = ProcessInfo.processInfo.arguments.contains("--orb-wait")
        reply = Task {
            if searches, let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) {
                // A sample search: the query shows, then the pages, as from
                // the app's search (no network in the preview).
                // --web-search-offline: the search finds no connection.
                var record = WebSearchRecord()
                record.add(query: text, sources: [], failure: nil)
                record.inProgress = text
                threads[ti].messages[mi].webSearch = record
                status = "ウェブを検索しています…"
                do { try await Task.sleep(for: .milliseconds(1200)) } catch { return }
                if ProcessInfo.processInfo.arguments.contains("--web-search-offline") {
                    record.inProgress = nil
                    record.add(query: text, sources: [], failure: .offline)
                    threads[ti].messages[mi].webSearch = record
                    status = "検索できませんでした。端末の中だけで答えています…"
                } else {
                    threads[ti].messages[mi].webSearch = PreviewWebSearch.record(query: text)
                    status = "検索結果を読んでいます…"
                }
            }
            do { try await Task.sleep(for: .milliseconds(orbWait ? 9000 : 900)) } catch { return }
            // --paragraph-stream: two paragraphs at a model's pace, the
            // break inside one piece, to watch the first paragraph's last
            // characters while the second one starts.
            let paragraphs = ProcessInfo.processInfo.arguments.contains("--paragraph-stream")
            let slow = ProcessInfo.processInfo.arguments.contains("--slow-reply")
            let mediaSummary = attachments.map { item -> String in
                switch item.kind {
                case .image where item.imageNames.isEmpty:
                    // One line, so the check finds the whole reply in one text.
                    let text = item.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    return "写真の文字: " + text.replacingOccurrences(of: "\n", with: " ")
                case .image: return "画像\(item.imageNames.count)枚"
                case .video: return "動画\(item.imageNames.count)場面"
                case .file: return "本文: \(item.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")"
                }
            }.joined(separator: "・")
            let stress = ProcessInfo.processInfo.arguments.contains("--layout-stress")
            let chunks: [String] = stress ? (1...12).map { index in
                "レイアウト検証\(index)：長文と画像を含む返信を生成しています。**太字の記法**、日本語の折り返し、絵文字😊を含みます。過去の会話を読む操作と、入力欄の高さ変更が重なっても、バブル同士の配置を保ちます。\n\n"
            } : !attachments.isEmpty ? ["添付の読み込み確認: ", mediaSummary]
                : orbWait ? ["\n", "こんにちは。", "オーロラの", "確認です。"]
                : ProcessInfo.processInfo.arguments.contains("--token-stream") ? PreviewTokenStream.chunks
                : ProcessInfo.processInfo.arguments.contains("--markdown-stream") ? PreviewMarkdown.chunks
                : ProcessInfo.processInfo.arguments.contains("--chart-stream")
                    ? PreviewCharts.chunks(wrapped: ProcessInfo.processInfo.arguments.contains("--chart-wrapped"))
                : ProcessInfo.processInfo.arguments.contains("--growing-reply") ? (1...12).map { "返信の確認\($0)：日本語の長い文章が少しずつ増えても、表示位置が上下に跳ねず、過去の返信も読めます。\n" }
                : paragraphs ? PreviewMarkdown.paragraphStream
                : slow ? ["新しい文字が", "ぼやけた状態から", "少しずつ", "くっきり表示されます。", "\nすでに読んだ文章は", "鮮明なままです。", "日本語と絵文字も", "そのまま表示します。😊"]
                : ["プレビュー用", "の返信です。", "入力欄・吹き出し・", "スクロールを確認できます。"]
            for chunk in chunks {
                guard let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) else { return }
                threads[ti].messages[mi].text += chunk
                let tokens = ProcessInfo.processInfo.arguments.contains("--token-stream")
                let markdown = ProcessInfo.processInfo.arguments.contains("--markdown-stream")
                let charts = ProcessInfo.processInfo.arguments.contains("--chart-stream")
                let delay: Int = orbWait && chunk == "\n" ? 300 : stress ? 700 : paragraphs ? 150 : slow ? 450 : tokens ? 60 : markdown ? 40 : charts ? 200 : 130
                do { try await Task.sleep(for: .milliseconds(delay)) } catch { return }
            }
            if let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) {
                threads[ti].messages[mi].state = .complete
            }
            isGenerating = false
            status = ""
            if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
                try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
            }
        }
        return true
    }
    func stop() {
        reply?.cancel()
        if let ti = threads.firstIndex(where: { $0.id == selectedID }), let mi = threads[ti].messages.indices.last {
            threads[ti].messages[mi].state = .stopped
        }
        isGenerating = false
        status = ""
    }
    func releaseModelMemory() {}
    func unloadModel() async {}
    func mergeBackup(_ incoming: [ChatThread]) {
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
    }
}

/// The preview's fixed search results.
enum PreviewWebSearch {
    static func record(query: String) -> WebSearchRecord {
        var record = WebSearchRecord()
        record.add(query: query, sources: [
            WebSearchSource(title: "東京スカイツリー", url: "https://ja.wikipedia.org/wiki/%E6%9D%B1%E4%BA%AC%E3%82%B9%E3%82%AB%E3%82%A4%E3%83%84%E3%83%AA%E3%83%BC", site: "ja.wikipedia.org"),
            WebSearchSource(title: "電波塔", url: "https://ja.wikipedia.org/wiki/%E9%9B%BB%E6%B3%A2%E5%A1%94", site: "ja.wikipedia.org")
        ], failure: nil)
        return record
    }
}

@MainActor final class ModelStore: ObservableObject {
    @Published var error: String?
    @Published var selectedModel = ModelSpec.e4b
    let isReady = true, isBusy = false, isRestoring = false
    /// `--cellular-only`: on cellular without Wi-Fi. `--download-waits`: E2B
    /// is downloading at 0%, so it waits for Wi-Fi until the switch is on.
    let network = ProcessInfo.processInfo.arguments.contains("--cellular-only")
        ? DownloadNetwork(hasWiFi: false, isOnline: true, cellularDenied: false) : .unknown
    @Published private var downloading: Set<String> =
        ProcessInfo.processInfo.arguments.contains("--download-waits") ? [ModelSpec.e2b.id] : []
    @Published private var cellularIDs: Set<String> = []
    @Published var allowsCellular = UserDefaults.standard.bool(forKey: ModelDownload.cellularKey) {
        didSet {
            UserDefaults.standard.set(allowsCellular, forKey: ModelDownload.cellularKey)
            // As the app: a download still at 0% starts again with the choice.
            cellularIDs = allowsCellular ? downloading : []
        }
    }
    init() {
        if ProcessInfo.processInfo.arguments.contains("--reset-settings") {
            UserDefaults.standard.removeObject(forKey: ModelDownload.cellularKey)
            allowsCellular = false
        }
        cellularIDs = allowsCellular ? downloading : []
    }
    func isDownloading(_ spec: ModelSpec) -> Bool { downloading.contains(spec.id) }
    func isWorking(on spec: ModelSpec) -> Bool { isDownloading(spec) }
    func progress(for spec: ModelSpec) -> Double { 0 }
    func downloadWait(for spec: ModelSpec) -> DownloadWait? {
        isDownloading(spec) ? network.wait(usesCellular: cellularIDs.contains(spec.id)) : nil
    }
    func statusText(for spec: ModelSpec) -> String {
        guard isDownloading(spec) else { return "UI検証用・モデル未使用" }
        return downloadWait(for: spec)?.status(name: spec.name, percent: 0) ?? "\(spec.name)をダウンロード中 · 0%"
    }
    @Published private(set) var installedIDs: Set<String> = ProcessInfo.processInfo.arguments.contains("--download-waits")
        ? [ModelSpec.e4b.id, ModelSpec.qwen3.id] : [ModelSpec.e4b.id, ModelSpec.e2b.id, ModelSpec.qwen3.id]
    func isInstalled(_ spec: ModelSpec) -> Bool { installedIDs.contains(spec.id) }
    func delete(_ spec: ModelSpec) { installedIDs.remove(spec.id) }
    func refreshInstalled() {}
    func select(_ spec: ModelSpec) { selectedModel = spec }
    func download(_ spec: ModelSpec) {}
    func cancelDownload(_ spec: ModelSpec) {}
    func importModel(_ url: URL, spec: ModelSpec) {}
}

@main struct PreviewApp: App {
    @StateObject private var chats = ChatStore()
    @StateObject private var model = ModelStore()
    private let arguments = ProcessInfo.processInfo.arguments
    init() {
        // As the TestFlight build on the phone, with the address space for
        // さらに深く; --narrow-address-space is an install without it.
        PhotoDetail.offer(atLaunch: ProcessInfo.processInfo.arguments.contains("--narrow-address-space")
                          ? nil : AddressSpace.current())
    }
    var body: some Scene {
        WindowGroup {
            ChatNavigationView().modifier(StartupPresenter()).environmentObject(chats).environmentObject(model)
                .modifier(PreviewMetricsSwitch(enabled: arguments.contains("--layout-metrics")))
                .environment(\.chatPreviewReduceMotion, arguments.contains("--reduce-motion"))
                .dynamicTypeSize(arguments.contains("--large-type") ? .accessibility3 : .large)
                .preferredColorScheme(arguments.contains("--dark") ? .dark : .light)
                .modifier(NarrowPhone(enabled: arguments.contains("--narrow-phone")))
                .overlay(alignment: .top) {
                    if arguments.contains("--elastic-diagnostics") { ElasticProbeView() }
                    if arguments.contains("--cloud-fixture") { PreviewCloudCheck() }
                    if arguments.contains("--download-activity") { PreviewDownloadActivity() }
                    if arguments.contains("--pull-snapshot") { PullSnapshotView() }
                    if arguments.contains("--show-pasteboard") { PreviewPasteboard() }
                }
        }
    }
}

/// What the app last copied, for UI tests to read (`--show-pasteboard`).
private struct PreviewPasteboard: View {
    @State private var copied = ""
    @State private var seen = UIPasteboard.general.changeCount
    private let tick = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    var body: some View {
        Text(verbatim: "コピー \(copied.count)文字").font(.caption2).padding(2).background(.background)
            .accessibilityLabel(Text(verbatim: copied.isEmpty ? "なし" : copied))
            .accessibilityIdentifier("preview-pasteboard").allowsHitTesting(false)
            .onReceive(NotificationCenter.default.publisher(for: UIPasteboard.changedNotification)) { _ in read() }
            .onReceive(tick) { _ in read() }
    }
    /// Only what this app copied after launch.
    private func read() {
        guard UIPasteboard.general.changeCount != seen else { return }
        seen = UIPasteboard.general.changeCount
        copied = UIPasteboard.general.string ?? ""
    }
}

private struct PreviewMetricsSwitch: ViewModifier {
    let enabled: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if enabled { content.modifier(PreviewLayoutMetrics()) } else { content }
    }
}

/// The narrowest iPhone's width, 375pt, centered in the simulator's
/// (`--narrow-phone`).
private struct NarrowPhone: ViewModifier {
    let enabled: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if enabled { content.frame(width: 375) } else { content }
    }
}


/// A reply streamed like the on-device model: a few characters at a time,
/// with Markdown list items, growing from one line to about one screen.
enum PreviewTokenStream {
    static let text = """
    テスト、ですね！😊

    どのようなテストをしたいですか？例えば、以下のようなものが考えられます。

    1. **知識の確認テスト**（例：歴史、科学、語彙など）
    2. **簡単なクイズ**（雑学など）
    3. **文章の作成テスト**（文章を書く練習など）
    4. **特定のトピックについての質問応答テスト**

    もしよろしければ、**「〇〇についてのクイズを出して」**とか、**「算数の問題を出して」**といった具体的なご要望を教えてください！

    それとも、**「まずは何か一つ出して」**といった感じで始めても大丈夫ですよ！
    """
    static var chunks: [String] {
        var result: [String] = []
        var current = ""
        for character in text {
            current.append(character)
            if current.count == 3 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}

/// Every Markdown feature replies render, finished (`--markdown-sample`) or
/// streamed a few characters at a time (`--markdown-stream`).
enum PreviewMarkdown {
    /// Two paragraphs, the break inside one piece (`--paragraph-stream`).
    static let paragraphStream: [String] = ["最初の段落では、", "新しい文字が", "虹色で現れて、", "書いている位置に",
                                            "沿って流れながら", "少しずつ", "いつもの文字の色へ", "戻っていきます。\n\n次の",
                                            "段落が始まっても、", "前の段落の", "色の変化は", "途切れません。"]

    /// A table wider than the screen between prose, a quote and a long
    /// line of code (`--wide-table`).
    static let wideTable = #"""
    表の前の文章です。

    | 項目 | 1月 | 2月 | 3月 | 4月 | 5月 | 6月 | 7月 | 8月 | 9月 | 10月 | 11月 | 12月 | 合計 |
    |:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
    | 売上 | 1,200 | 1,350 | 1,100 | 1,420 | 1,380 | 1,500 | 1,610 | 1,580 | 1,450 | 1,520 | 1,700 | 1,890 | 17,700 |
    | 費用 | 820 | 870 | 790 | 900 | 880 | 940 | 990 | 1,010 | 930 | 960 | 1,050 | 1,120 | 11,260 |
    | 利益 | 380 | 480 | 310 | 520 | 500 | 560 | 620 | 570 | 520 | 560 | 650 | 770 | 6,440 |

    > 引用は画面の幅に収まります。

    表の後の文章です。表を左右に動かしても、この文章は動きません。

    ```swift
    let note = "横に長いコードの行は、コードブロックの中だけで横にスクロールします。"
    ```
    """#

    static let sample = #"""
    ## Markdownの表示

    **太字**、*斜体*、~~取り消し線~~、`インラインコード`、[リンク](https://www.apple.com/jp/) を使えます。

    > 引用文です。**強調**や `code` も入ります。

    1. 準備する
    2. 実行する
       - [x] 完了した項目
       - [ ] まだの項目

    | モデル | 速度 | メモリ | 画像 |
    |:--|--:|--:|:-:|
    | E2B | 速い | 0.6 GB | ○ |
    | E4B | 普通 | 0.85 GB | 調整中 |

    ```swift
    struct Greeting {
        let name = "Fielua" // 名前
        func text() -> String { "こんにちは、\(name)さん" }
    }
    ```

    二次方程式の解は $x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$ です。

    $$
    \int_0^1 x^2\,dx = \frac{1}{3}
    $$

    就活は $\text{自己分析} \times \text{企業研究}$ の掛け算です。

    $$
    \text{自己分析} \times \text{企業研究} \times \text{行動} = \text{内定}
    $$

    $$利益率 = \frac{利益}{売上} × 100$$

    導関数 $f'(x)$、$利益率 = 20%$、$\operatorname{argmax}_x \dfrac{x}{2}$ も読めます。

    $$
    \begin{align*}
    a &= b + c \\
    d &= e \times f
    \end{align*}
    $$

    連立方程式も描けます。

    $$
    \begin{cases}
    x + y = 5 \\
    x - y = 1
    \end{cases}
    $$

    区切り記号のない書き方も数式になります。
    \begin{cases} x+y=5 \\ x-y=1 \end{cases}

    **LaTeX形式:**
    \begin{aligned}
    a &= b+c \\
    x &= y+z
    \end{aligned}

    文中の \begin{cases} と \end{cases} や `\begin{aligned}` は文字のままです。

    幅の広い式 $\sum_{i=1}^{n} \frac{(x_i - \bar{x})^2}{n - 1} + \int_0^\infty e^{-t^2}\,dt + \lim_{x \to 0} \frac{\sin x}{x}$ は行を分けて表示します。

    $$ \xrightarrow{x} y $$

    ---

    ![サンプル画像](https://example.com/sample.png)
    """#

    /// A long reply like ChatGPT's (`--markdown-article`): every heading
    /// level, long paragraphs, nested and two-digit numbered lists, a quote,
    /// rules, a table and code, for the spacing and alignment review.
    static let article = #"""
    # 2035年のAIと暮らし

    AIが身近になった未来を想像しながら、見出し・リスト・表・コードの表示を確かめる長文です。段落が長くなっても、左右の余白をそろえたまま自然に折り返して読めるかを確認します。

    ここは2つ目の段落です。**太字の強調**と見出しの違い、*斜体*、~~取り消し線~~、`インラインコード` が本文の中で読みやすく並ぶかを見ます。

    ## 第1章：朝のルーティン

    朝7時、目覚ましより先にAIがカーテンを開けます。今日の予定と天気を短くまとめて読み上げ、通勤経路の混雑も先回りして知らせてくれます。

    ### 出かける前の準備

    1. 天気を確認する
    2. 持ち物をそろえる
       - 傘（午後から雨）
       - 充電器
         - USB-Cケーブル
         - モバイルバッテリー
    3. 家を出る時間を決める

    #### 確認するところ

    - 箇条書きの記号と本文の頭がそろっているか
    - 長い項目でも、2行目が記号の下に回り込まず、本文の頭にそろって折り返されるかを確かめるための少し長めの項目です
    - [x] チェック済みの項目
    - [ ] まだの項目

    ##### H5 の小見出し

    本文と同じくらいの大きさでも、**太字の文**とは区別できるかを見ます。

    ###### H6 の補足

    > AIは道具であり、使い方を決めるのは人です。
    > 引用は左の線と文字の色で本文と分けます。

    ---

    ## 第2章：数字で見る変化

    | 項目 | 2025年 | 2035年 |
    |:--|--:|--:|
    | AIを毎日使う人 | 30% | 85% |
    | 平均通勤時間 | 45分 | 28分 |

    ```python
    def greet(name):
        return f"おはよう、{name}さん"
    ```

    10. 二桁の番号
    11. の項目も
    12. 本文の頭がそろうか

    最後の段落です。表やコードのあとでも、段落の間隔が同じに保たれるかを確認します。
    """#

    static var wide: String {
        let code = (1...35).map { "def step_\($0)(x):\n    return x + \($0)  # \($0)番目" }.joined(separator: "\n")
        return """
        横に長い表と長いコードの確認です。

        | 項目 | 1月 | 2月 | 3月 | 4月 | 5月 | 6月 | 合計 |
        |---|--:|--:|--:|--:|--:|--:|--:|
        | 売上 | 120 | 135 | 150 | 160 | 172 | 180 | 917 |
        | 費用 | 80 | 82 | 90 | 95 | 99 | 101 | 547 |

        ```python
        \(code)
        ```

        言語名のないコードは、見て分かるときだけ言語を付けます。

        ```
        {"model": "E2B", "memory": 0.6, "vision": true}
        ```
        """
    }

    static var chunks: [String] {
        var result: [String] = []
        var current = ""
        for character in sample {
            current.append(character)
            if current.count == 4 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}
