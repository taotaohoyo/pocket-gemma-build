// Separate simulator target. No model or user archive is accessed; the network
// only for Tavily's sign-in page and its calls (WebSearchCard, 1.1.0 (207)).
import SwiftUI
import UIKit
import Combine
import PocketCore

@MainActor final class ChatStore: ObservableObject {
    @Published var threads: [ChatThread]
    /// As the app's: kept for the next launch's 前回の会話.
    @Published var selectedID: UUID? {
        didSet { if selectedID != oldValue { LaunchChatPlan.remember(selectedID) } }
    }
    @Published var isGenerating = false
    @Published var isStopping = false
    @Published var status = ""
    @Published var error: String?
    var openedFromNotification = false
    @Published private var configurations = GenerationPreferences.load()
    var currentSettings: GenerationSettings { (configurations[currentModel.id] ?? GenerationSettings(for: currentModel)).normalized(for: currentModel) }
    func updateSettings(_ settings: GenerationSettings) {
        configurations[currentModel.id] = settings.normalized(for: currentModel)
        GenerationPreferences.save(configurations)
    }
    /// As the app's ChatStore: E4B's 高速 and じっくり考える, saved with its
    /// settings, and whether じっくり考える runs as 深く on this launch.
    var photoDetail: PhotoDetail { currentSettings.photoDetail.choice }
    var deeperFallsBack: Bool { !isSmart && currentSettings.deeperFallsBack(on: currentModel) }
    func setPhotoDetail(_ detail: PhotoDetail) {
        guard !isGenerating, currentModel.photoDetails.contains(detail) else { return }
        var settings = currentSettings
        settings.photoDetail = detail
        updateSettings(settings)
    }
    private var reply: Task<Void, Never>?
    /// As the app's ChatStore: the chat's web search switch. The preview
    /// never reaches the network; a search here is a fixed sample.
    var webSearchOn: Bool { threads.first { $0.id == selectedID }?.webSearch == true }
    var webSearchBlocked: Bool { WebSearchPolicy.blockedByFiles(messages) }
    var webSearchOffered: Bool {
        guard isSmart else { return WebSearchPolicy.offers(currentModel) }
        return SmartPlanner.starters.contains { PreviewModels.installed.contains($0) }
    }

    // MARK: Smart Mode, as the app's ChatStore (1.1.0 (249))

    func isSmartChat(_ thread: ChatThread) -> Bool { SmartMode.isOn && thread.modelPinned != true }
    var isSmart: Bool { threads.first { $0.id == selectedID }.map(isSmartChat) ?? SmartMode.isOn }
    var current: ChatThread? { threads.first { $0.id == selectedID } }
    var genre: SmartGenre { current?.genre ?? .auto }
    func setGenre(_ genre: SmartGenre) {
        guard let index = threads.firstIndex(where: { $0.id == selectedID }) else { return }
        threads[index].genre = genre
    }
    func unpinModel() {
        guard let index = threads.firstIndex(where: { $0.id == selectedID }) else { return }
        threads[index].modelPinned = nil
    }
    var attachmentModel: ModelSpec {
        guard isSmart else { return currentModel }
        return SmartPlanner.attachmentModel(context: smartContext(current: currentModel))
    }
    var canAnswer: Bool {
        if PreviewModels.installed.contains(currentModel.id) { return true }
        guard isSmart else { return false }
        return SmartPlanner.restingModel(preferred: currentModel, context: smartContext(current: currentModel)) != nil
    }
    var lastSmartReply: SmartReply? { messages.last { $0.role == .assistant }?.smart }
    /// `--smart-prefers-small`: a phone whose memory is tight for E4B.
    private func smartContext(current: ModelSpec, searchBlocked: Bool = false) -> SmartPlanner.Context {
        SmartPlanner.Context(current: current, installed: PreviewModels.installed,
                             developer: UserDefaults.standard.bool(forKey: DeveloperUnlock.developerSettingsKey),
                             prefersSmall: ProcessInfo.processInfo.arguments.contains("--smart-prefers-small"),
                             searchReady: WebSearchKeyState.shared.isReady, searchBlocked: searchBlocked)
    }
    func setWebSearch(_ on: Bool) {
        guard !isGenerating, let index = threads.firstIndex(where: { $0.id == selectedID }) else { return }
        threads[index].webSearch = on ? true : nil
    }

    init() {
        // --probe-table-pop: a streaming table's rows as 1.1.0 (244) showed
        // them, each waiting until its line ended with a pipe.
        if ProcessInfo.processInfo.arguments.contains("--probe-table-pop") {
            MarkdownSource.holdsTableRowsWhole = true
        }
        if ProcessInfo.processInfo.arguments.contains("--reset-startup") {
            Onboarding.showAgain()
        }
        // A phone updated from 1.1.0 (179), where the setup was finished
        // (or skipped, the phone having chats and models).
        if ProcessInfo.processInfo.arguments.contains("--updated-from-179") {
            UserDefaults.standard.set(true, forKey: "model-startup-completed-v1")
        }
        // UI checks of anything but the setup start on a phone that has
        // finished it; --startup leaves it as the phone has it.
        if !ProcessInfo.processInfo.arguments.contains("--startup") {
            Onboarding.finish()
        }
        // --stable-chat-id: the sample chats keep their ids from launch to
        // launch, as saved chats do, for 起動時のチャット's checks.
        let stable = ProcessInfo.processInfo.arguments.contains("--stable-chat-id")
        func sampleID(_ index: Int) -> UUID {
            stable ? UUID(uuidString: String(format: "00000000-0000-0000-0000-%012d", index + 1))! : UUID()
        }
        var thread = ChatThread(id: sampleID(0))
        if ProcessInfo.processInfo.arguments.contains("--e2b") { thread.modelID = ModelSpec.e2b.id }
        if ProcessInfo.processInfo.arguments.contains("--qwen3") { thread.modelID = ModelSpec.qwen3.id }
        // --gemma12b: a chat with the test version 12B, saved (1.1.0 (204)).
        if ProcessInfo.processInfo.arguments.contains("--gemma12b") { thread.modelID = ModelSpec.gemma12B.id }
        // --omni: a chat with LFM3-Omni 2B, saved, for the voice input (1.1.0 (236)).
        if ProcessInfo.processInfo.arguments.contains("--omni") { thread.modelID = ModelSpec.lfm3Omni.id }
        thread.messages = [ChatMessage(role: .user, text: "画面の動きを確認"),
            ChatMessage(role: .assistant, text: "これはUI検証用のサンプル会話です。実際のAI推論は実行していません。")]
        if ProcessInfo.processInfo.arguments.contains("--long-chat") {
            // --longer-chat: more messages than ChatView lays out eagerly.
            let exchanges = ProcessInfo.processInfo.arguments.contains("--longer-chat") ? 40 : 12
            thread.messages = (1...exchanges).flatMap { index in
                [ChatMessage(role: .user, text: "長い会話の確認 \(index)"),
                 ChatMessage(role: .assistant, text: "スクロールの確認です。過去の返信を読んでいるときには、自動で末尾へ戻りません。入力欄から現れる下向きのボタンで最新の返信へ移動できます。\n\n日本語の折り返しと、上のヘッダーに文章が重ならないことを確認します。")]
            }
            thread.messages.append(ChatMessage(role: .assistant, text: "最新の返信です。ここまで戻りました。"))
        }
        if ProcessInfo.processInfo.arguments.contains("--tall-bubble") {
            let paragraphs = (1...8).map { index in
                "長い返信の表示確認 \(index)\n文章が画面より長くなっても、吹き出しの角丸と余白を揃えます。上下の操作部分には内容が透け、本文だけが自然にぼけていきます。スクロールしながらヘッダーと入力欄の境目を確認するためのサンプル文章です。"
            }.joined(separator: "\n\n")
            thread.messages = [
                ChatMessage(role: .user, text: "こんにちは"),
                ChatMessage(role: .assistant, text: "こんにちは！😊"),
                ChatMessage(role: .assistant, text: "短い返信の角丸も確認します。"),
                ChatMessage(role: .user, text: "長い返信も見せて"),
                ChatMessage(role: .assistant, text: paragraphs)
            ]
        }
        if ProcessInfo.processInfo.arguments.contains("--markdown-sample") {
            thread.messages = [ChatMessage(role: .user, text: "Markdownの表示を確認"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.wide),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.sample)]
        }
        if ProcessInfo.processInfo.arguments.contains("--wide-table") {
            thread.messages = [ChatMessage(role: .user, text: "横に長い表を見せて"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.wideTable)]
        }
        if ProcessInfo.processInfo.arguments.contains("--long-tables") {
            // --long-tables-part=plain keeps the headings and paragraphs
            // alone, =0, =1 or =2 them and that one table.
            let part = ProcessInfo.processInfo.arguments.first { $0.hasPrefix("--long-tables-part=") }
                .map { String($0.dropFirst("--long-tables-part=".count)) }
            // --long-tables-variant= changes the check table for the UI
            // check's layout probes: nobox (未 for ☐), twocol (no 完了
            // column) or short (its long cells cut short).
            let variant = ProcessInfo.processInfo.arguments.first { $0.hasPrefix("--long-tables-variant=") }
                .map { String($0.dropFirst("--long-tables-variant=".count)) }
            thread.messages = [ChatMessage(role: .user, text: "カフェの開業準備の資料を作って"),
                               ChatMessage(role: .assistant,
                                           text: PreviewMarkdown.longTables(PreviewMarkdown.longTables(part: part), variant: variant))]
        }
        if ProcessInfo.processInfo.arguments.contains("--chart-sample") {
            thread.messages = [ChatMessage(role: .user, text: "グラフで見せて"),
                               ChatMessage(role: .assistant, text: PreviewCharts.first),
                               ChatMessage(role: .assistant, text: PreviewCharts.second)]
        }
        // --web-search: the chat's search on; --web-search-sample: a reply
        // that searched, with its pages. --web-search-key saves a sample
        // Tavily key in the keychain and --web-search-no-key removes it.
        // --web-search-no-key: no connection at all, so no Tavily sign-in
        // either. --tavily-account saves a sample sign-in (its tokens are
        // made up: Tavily turns them down), --tavily-account-expired one
        // Tavily asked to sign in again, --tavily-signed-out removes it.
        if ProcessInfo.processInfo.arguments.contains("--web-search-key") { WebSearchKeyState.shared.save("tvly-preview-sample") }
        if ProcessInfo.processInfo.arguments.contains("--web-search-no-key") {
            WebSearchKeyState.shared.delete()
            TavilyAccountKeychain().delete()
        }
        if ProcessInfo.processInfo.arguments.contains("--tavily-signed-out") { TavilyAccountKeychain().delete() }
        if ProcessInfo.processInfo.arguments.contains("--tavily-account") {
            TavilyAccountKeychain().save(TavilyAccountRecord(clientID: "preview-client", accessToken: "preview-access-token",
                                                             refreshToken: "preview-refresh-token",
                                                             expiresAt: Date().addingTimeInterval(3600)))
        }
        if ProcessInfo.processInfo.arguments.contains("--tavily-account-expired") {
            TavilyAccountKeychain().save(TavilyAccountRecord(clientID: "preview-client", needsSignIn: true))
        }
        if ProcessInfo.processInfo.arguments.contains("--web-search") { thread.webSearch = true }
        if ProcessInfo.processInfo.arguments.contains("--web-search-sample") {
            var answer = ChatMessage(role: .assistant, text: "東京スカイツリーの高さは**634メートル**です。2012年に開業した電波塔で、自立式の電波塔としては世界一の高さです。")
            answer.webSearch = PreviewWebSearch.record(query: "東京スカイツリー 高さ")
            thread.messages = [ChatMessage(role: .user, text: "スカイツリーの高さは？"), answer]
        }
        if ProcessInfo.processInfo.arguments.contains("--markdown-article") {
            thread.messages = [ChatMessage(role: .user, text: "長文のMarkdownを表示して"),
                               ChatMessage(role: .assistant, text: PreviewMarkdown.article)]
        }
        if ProcessInfo.processInfo.arguments.contains("--restore-fixture-chat"),
           let saved = try? ChatArchive(fileURL: PreviewAttachments.archive).load(), !saved.isEmpty {
            threads = saved
        } else { threads = [thread] }
        if ProcessInfo.processInfo.arguments.contains("--history-fixture") {
            // Older conversations for the history sidebar's layout review.
            for (index, title) in ["旅行の持ち物リスト", "カメムシ対策", "英語メールの添削をお願いします", "夕飯のレシピ",
                                   "写真に写っている花の名前", "iPhoneのバッテリー設定"].enumerated() {
                var older = ChatThread(id: sampleID(index + 1))
                older.messages = [ChatMessage(role: .user, text: title), ChatMessage(role: .assistant, text: "サンプルの返信です。")]
                older.updatedAt = Date().addingTimeInterval(-Double(index + 1) * 3600)
                threads.append(older)
            }
        }
        if ProcessInfo.processInfo.arguments.contains("--memory-fixture") {
            // Earlier conversations for Smart Memory's checks (1.1.0 (251)):
            // a cat's birthday, a line of code, and one about nothing asked.
            let earlier: [(String, String, String)] = [
                ("猫の名前と誕生日", "うちの猫の名前はミケで、誕生日は3月14日です。覚えておいてね。",
                 "ミケちゃん、3月14日生まれなんですね。覚えておきます。"),
                ("Pythonでリストを逆にする", "Pythonでリストを逆順にするには？",
                 "`items.reverse()` でその場で逆にできます。新しいリストが欲しいときは `items[::-1]` です。"),
                ("夕飯の献立", "夕飯の献立を考えて", "鶏の照り焼き、ほうれん草のおひたし、味噌汁はいかがでしょう。")
            ]
            for (index, chat) in earlier.enumerated() {
                var older = ChatThread(id: sampleID(20 + index), modelID: ModelSpec.e2b.id)
                older.messages = [ChatMessage(role: .user, text: chat.1), ChatMessage(role: .assistant, text: chat.2)]
                older.updatedAt = Date().addingTimeInterval(-Double(index + 1) * 86_400)
                threads.append(older)
            }
        }
        // 起動時のチャット starts each launch as on a phone that never chose
        // (前回の会話), with no last chat or kept text: `--launch-chat=new`
        // starts with 新しいチャット, `--legacy-keyboard-at-launch` (=off) with
        // 1.1.0 (181)'s 起動時にキーボードを開いておく on (off) to carry over,
        // and `--keep-launch-chat` keeps what the launch before left.
        let arguments = ProcessInfo.processInfo.arguments
        if !arguments.contains("--keep-launch-chat") {
            for key in [LaunchChatMode.storageKey, LaunchChatMode.legacyKeyboardKey, LaunchChatPlan.lastOpenKey,
                        LaunchDrafts.storageKey, LaunchDrafts.storageKey + "-order"] {
                UserDefaults.standard.removeObject(forKey: key)
            }
        }
        if arguments.contains("--launch-chat=new") {
            UserDefaults.standard.set(LaunchChatMode.newChat.rawValue, forKey: LaunchChatMode.storageKey)
        }
        if let legacy = arguments.first(where: { $0.hasPrefix("--legacy-keyboard-at-launch") }) {
            UserDefaults.standard.removeObject(forKey: LaunchChatMode.storageKey)
            UserDefaults.standard.set(!legacy.hasSuffix("=off"), forKey: LaunchChatMode.legacyKeyboardKey)
        }
        LaunchChatMode.migrate()
        // --onboarding-step=launch: the setup opens on 起動時のチャット.
        if arguments.contains("--onboarding-step=launch") {
            UserDefaults.standard.set(OnboardingStep.launch.rawValue, forKey: Onboarding.stepKey)
        }
        selectedID = LaunchChatPlan.opening(threads, lastOpen: LaunchChatPlan.lastOpen())
        if ProcessInfo.processInfo.arguments.contains("--reset-settings") {
            GenerationPreferences.save([:]); configurations = [:]
            UserDefaults.standard.removeObject(forKey: "show-developer-settings-v1")
        }
        // Each launch starts with 縮小型, so a check that chose 従来型 leaves
        // the next one the composer it expects; `--classic-composer` starts
        // with 従来型, `--keep-composer-style` with the type chosen before.
        if ProcessInfo.processInfo.arguments.contains("--classic-composer") {
            UserDefaults.standard.set(ComposerStyle.classic.rawValue, forKey: ComposerStyle.storageKey)
        } else if !ProcessInfo.processInfo.arguments.contains("--keep-composer-style") {
            UserDefaults.standard.removeObject(forKey: ComposerStyle.storageKey)
        }
        // The developer models, as if the switch in the model list were on,
        // for this launch only (a registered default is not saved).
        if ProcessInfo.processInfo.arguments.contains("--developer-settings") {
            UserDefaults.standard.removeObject(forKey: "show-developer-settings-v1")
            UserDefaults.standard.register(defaults: ["show-developer-settings-v1": true])
        }
        // Smart Mode (1.1.0 (249)) is off in the app until turned on in
        // 設定 › 試験機能を試してみる (since 250); here it starts off unless
        // `--smart-mode` turns it on, whatever an earlier launch saved.
        // `--smart-pinned`: the sample chat's model was chosen by the person.
        UserDefaults.standard.set(arguments.contains("--smart-mode"), forKey: SmartMode.storageKey)
        // Smart Memory (1.1.0 (251)) as well: off unless `--smart-memory`.
        UserDefaults.standard.set(arguments.contains("--smart-memory"), forKey: SmartMemory.storageKey)
        if arguments.contains("--smart-pinned"), let index = threads.indices.first { threads[index].modelPinned = true }
        // `--smart-genre=<raw value>`: the sample chat's genre.
        if let raw = arguments.first(where: { $0.hasPrefix("--smart-genre=") }).map({ String($0.dropFirst("--smart-genre=".count)) }),
           let genre = SmartGenre(rawValue: raw), let index = threads.indices.first {
            threads[index].genre = genre
        }
        LaunchChat.choose(in: self)
    }
    var messages: [ChatMessage] { threads.first { $0.id == selectedID }?.messages ?? [] }
    var currentModel: ModelSpec { ModelSpec.find(threads.first { $0.id == selectedID }?.modelID) ?? .e4b }
    func select(_ id: UUID) {
        guard threads.contains(where: { $0.id == id }) else { return }
        if !isGenerating || id == selectedID { selectedID = id }
    }
    func newChat(modelID: String? = nil, pinned: Bool = false) {
        guard !isGenerating else { return }
        var modelID = modelID ?? currentModel.id
        if SmartMode.isOn && !pinned, let spec = ModelSpec.find(modelID),
           let resting = SmartPlanner.restingModel(preferred: spec, context: smartContext(current: spec)) {
            modelID = resting.id
        }
        var thread = ChatThread(modelID: modelID)
        thread.modelPinned = pinned ? true : nil
        threads.insert(thread, at: 0)
        selectedID = thread.id
    }
    func delete(_ id: UUID) { deleteChats([id]) }
    /// As the app's ChatStore (1.1.0 (251)): the chats chosen go, the open
    /// one for a new chat; no files here.
    @discardableResult func deleteChats(_ ids: Set<UUID>) -> Bool {
        guard !isGenerating, !ids.isEmpty else { return false }
        let plan = ChatDeletion.plan(deleting: ids, from: threads)
        guard !plan.deleted.isEmpty else { return false }
        let openGone = selectedID.map(plan.deleted.contains) ?? true
        threads = plan.remaining
        if openGone { selectedID = nil; newChat() }
        return true
    }
    func smartMemoryChanged(_ on: Bool) {}
    @discardableResult func send(_ text: String, messageID: UUID = UUID(), attachments: [ChatAttachment] = []) -> Bool {
        let alone = text.isEmpty && attachments.contains { [.image, .video, .audio].contains($0.kind) }
        let spoken = attachments.contains { $0.kind == .audio }
        let text = text.isEmpty && !attachments.isEmpty ? (spoken ? VoiceNote.ask : "添付した内容を説明してください。") : text
        guard !isGenerating, !text.isEmpty, let ti = threads.firstIndex(where: { $0.id == selectedID }) else { return false }
        // Smart Mode's choice, as the app's: the model and its tuning, kept
        // with the reply and named at its end for the UI check.
        var smart: SmartReply?
        if isSmartChat(threads[ti]) {
            let thread = threads[ti]
            let context = smartContext(current: ModelSpec.find(thread.modelID) ?? .e4b,
                                       searchBlocked: WebSearchPolicy.blockedByFiles(thread.messages, adding: attachments))
            let request = SmartPlanner.Request(genre: thread.genre, prompt: text, attachments: attachments.map(\.kind),
                                               earlier: thread.attachmentKinds,
                                               earlierDetail: thread.messages.last { $0.smart != nil }?.smart?.tuning.photoDetail)
            switch SmartPlanner.plan(request, in: context) {
            case .success(let plan):
                smart = plan.reply(genre: thread.genre)
            case .failure(let unavailable):
                error = unavailable.message; return false
            }
        }
        let model = smart.flatMap { ModelSpec.find($0.modelID) } ?? currentModel
        do { try ModelAttachmentPolicy(model: model).validateNewAttachments(attachments) }
        catch { self.error = error.localizedDescription; return false }
        if let smart { threads[ti].modelID = smart.modelID }
        // No model here: a video reads as analyzed at once, as the app's
        // reply leaves it (GemmaService.analyze), so its note can be seen.
        var attachments = attachments
        for index in attachments.indices {
            guard var video = attachments[index].video else { continue }
            for scene in video.scenes.indices { video.scenes[scene].caption = "サンプルの場面" }
            for part in video.parts.indices where video.soundSkipped == nil {
                video.parts[part].text = "サンプルの書き起こし"; video.parts[part].audio = nil
            }
            attachments[index].video = video
            attachments[index].note = VideoDigest.note(video, sent: true)
        }
        var assistant = ChatMessage(role: .assistant, text: "", state: .generating)
        assistant.smart = smart
        // Smart Memory, as the app's (SmartMemoryStore) but at once: the
        // earlier exchanges found are kept with the reply, and its end names
        // their chats for the UI check (MEMORY lines).
        var memoryIndex = SmartMemoryIndex()
        if SmartMemory.isOn { memoryIndex.sync(threads) }
        let memoryNote = SmartMemory.isOn
            ? SmartMemoryNote.build(memoryIndex.search(text, excluding: Set(threads[ti].messages.map(\.id))),
                                    threads: threads, question: text, byteBudget: 1_600)
            : nil
        assistant.memory = memoryNote.map { MemoryRecall(sources: $0.sources) }
        let recalled = (memoryNote?.sources ?? []).compactMap { source in threads.first { $0.id == source.thread }?.title }
        var asked = ChatMessage(id: messageID, role: .user, text: text, attachments: attachments)
        if alone { asked.hidesText = true }
        threads[ti].messages.append(asked)
        threads[ti].messages.append(assistant)
        threads[ti].updatedAt = Date()
        isGenerating = true
        if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
            try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
        }
        status = "UI検証用のサンプルを表示しています…"
        let searches = WebSearchPolicy.searches(enabled: smart?.searched ?? (threads[ti].webSearch == true),
                                                keyed: WebSearchKeyState.shared.isReady,
                                                model: model, messages: threads[ti].messages.dropLast(2).map { $0 },
                                                attachments: attachments, asked: text)
        // --orb-wait: a long wait before the first token, a line break that
        // draws nothing, then the text 0.3 s later as from a model, so the
        // Aurora Orb can be checked while it waits, as it shrinks away from
        // the first token, and holding the text back until it has gone.
        let orbWait = ProcessInfo.processInfo.arguments.contains("--orb-wait")
        reply = Task {
            if searches, let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) {
                // A sample search: the query shows, then the pages, as from
                // the app's search (no network in the preview).
                // --web-search-offline: the search finds no connection.
                var record = WebSearchRecord()
                record.add(query: text, sources: [], failure: nil)
                record.inProgress = text
                threads[ti].messages[mi].webSearch = record
                status = "ウェブを検索しています…"
                do { try await Task.sleep(for: .milliseconds(1200)) } catch { return }
                if ProcessInfo.processInfo.arguments.contains("--web-search-offline") {
                    record.inProgress = nil
                    record.add(query: text, sources: [], failure: .offline)
                    threads[ti].messages[mi].webSearch = record
                    status = "検索できませんでした。端末の中だけで答えています…"
                } else if ProcessInfo.processInfo.arguments.contains("--web-search-unconfirmed") {
                    // --web-search-unconfirmed: no page named the version
                    // asked (1.1.0 (208)).
                    record.inProgress = nil
                    record.unconfirmed = ["iOS 27.9"]
                    threads[ti].messages[mi].webSearch = record
                    status = "検索結果を読んでいます…"
                } else {
                    threads[ti].messages[mi].webSearch = PreviewWebSearch.record(query: text)
                    status = "検索結果を読んでいます…"
                }
            }
            do { try await Task.sleep(for: .milliseconds(orbWait ? 9000 : 900)) } catch { return }
            // --paragraph-stream: two paragraphs at a model's pace, the
            // break inside one piece, to watch the first paragraph's last
            // characters while the second one starts.
            let paragraphs = ProcessInfo.processInfo.arguments.contains("--paragraph-stream")
            let slow = ProcessInfo.processInfo.arguments.contains("--slow-reply")
            // --instant-reply: the whole reply comes with its end, in one
            // change, as a short reply can on the phone (1.1.0 (189)).
            let instant = ProcessInfo.processInfo.arguments.contains("--instant-reply")
            let mediaSummary = attachments.map { item -> String in
                switch item.kind {
                case .image where item.imageNames.isEmpty:
                    // One line, so the check finds the whole reply in one text.
                    let text = item.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    return "写真の文字: " + text.replacingOccurrences(of: "\n", with: " ")
                case .image: return "画像\(item.imageNames.count)枚"
                case .video:
                    // The scenes picked, and the sound's parts (1.1.0 (194)).
                    guard let video = item.video else { return "動画\(item.imageNames.count)場面" }
                    let sound = video.sound == .parts && video.soundSkipped == nil ? "音声\(video.parts.count)区間" : "音声なし"
                    return "動画\(video.scenes.count)場面・\(sound)"
                case .file: return "本文: \(item.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")"
                case .audio: return "音声\(VoiceNote.clock(item.duration ?? 0))"
                }
            }.joined(separator: "・")
            let stress = ProcessInfo.processInfo.arguments.contains("--layout-stress")
            let chunks: [String] = stress ? (1...12).map { index in
                "レイアウト検証\(index)：長文と画像を含む返信を生成しています。**太字の記法**、日本語の折り返し、絵文字😊を含みます。過去の会話を読む操作と、入力欄の高さ変更が重なっても、バブル同士の配置を保ちます。\n\n"
            } : !attachments.isEmpty ? ["添付の読み込み確認: ", mediaSummary]
                : orbWait ? ["\n", "こんにちは。", "オーロラの", "確認です。"]
                : ProcessInfo.processInfo.arguments.contains("--token-stream") ? PreviewTokenStream.chunks
                : ProcessInfo.processInfo.arguments.contains("--markdown-stream") ? PreviewMarkdown.chunks
                : ProcessInfo.processInfo.arguments.contains("--table-stream") ? PreviewMarkdown.tableChunks
                : ProcessInfo.processInfo.arguments.contains("--table-plan-stream") ? PreviewMarkdown.planChunks
                : ProcessInfo.processInfo.arguments.contains("--chart-stream")
                    ? PreviewCharts.chunks(wrapped: ProcessInfo.processInfo.arguments.contains("--chart-wrapped"))
                : ProcessInfo.processInfo.arguments.contains("--growing-reply") ? (1...12).map { "返信の確認\($0)：日本語の長い文章が少しずつ増えても、表示位置が上下に跳ねず、過去の返信も読めます。\n" }
                : paragraphs ? PreviewMarkdown.paragraphStream
                : instant ? ["すぐに書き終えた返信です。"]
                : slow ? ["新しい文字が", "ぼやけた状態から", "少しずつ", "くっきり表示されます。", "\nすでに読んだ文章は", "鮮明なままです。", "日本語と絵文字も", "そのまま表示します。😊"]
                : ["プレビュー用", "の返信です。", "入力欄・吹き出し・", "スクロールを確認できます。"]
            // A Smart Mode reply ends with its choice, a paragraph of its
            // own, for the UI check (SMART lines).
            let smartNamed = smart.map { reply in
                chunks + ["\n\nSmart: " + ([reply.genreLine, reply.summary] + reply.notices.map(\.rawValue)).joined(separator: " / ")]
            } ?? chunks
            let named = SmartMemory.isOn ? smartNamed + ["\n\nMemory: " + (recalled.isEmpty ? "なし" : recalled.joined(separator: " / "))]
                : smartNamed
            // --frame-trace: the screen's frames while the reply is written.
            let frames = ProcessInfo.processInfo.arguments.contains("--frame-trace") ? FrameGapCounter() : nil
            frames?.start()
            for chunk in named {
                guard let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) else { return }
                threads[ti].messages[mi].text += chunk
                let tokens = ProcessInfo.processInfo.arguments.contains("--token-stream")
                let markdown = ProcessInfo.processInfo.arguments.contains("--markdown-stream")
                    || ProcessInfo.processInfo.arguments.contains("--table-stream")
                let charts = ProcessInfo.processInfo.arguments.contains("--chart-stream")
                // About 37 characters a second, as E4B wrote its plan on the phone.
                let plan = ProcessInfo.processInfo.arguments.contains("--table-plan-stream")
                let delay: Int = orbWait && chunk == "\n" ? 300 : stress ? 700 : paragraphs ? 150 : slow ? 450 : tokens ? 60
                    : markdown ? 40 : charts ? 200 : plan ? 80 : 130
                if instant { continue }
                do { try await Task.sleep(for: .milliseconds(delay)) } catch { return }
            }
            if let frames {
                // A second more, for the last characters' fade.
                Task { @MainActor in
                    try? await Task.sleep(for: .seconds(1))
                    frames.stop()
                    StreamFrameLog.shared.summary = frames.summary
                }
            }
            if let mi = threads[ti].messages.firstIndex(where: { $0.id == assistant.id }) {
                threads[ti].messages[mi].state = .complete
            }
            isGenerating = false
            status = ""
            if ProcessInfo.processInfo.arguments.contains("--attachment-fixtures") {
                try? ChatArchive(fileURL: PreviewAttachments.archive).save(threads)
            }
        }
        return true
    }
    func stop() {
        reply?.cancel()
        if let ti = threads.firstIndex(where: { $0.id == selectedID }), let mi = threads[ti].messages.indices.last {
            threads[ti].messages[mi].state = .stopped
        }
        isGenerating = false
        status = ""
    }
    func releaseModelMemory() {}
    func unloadModel() async {}
    func mergeBackup(_ incoming: [ChatThread]) {
        threads = HistoryMerge.merge(local: threads, incoming: incoming)
    }
}

/// The models saved in the preview, for both stores: `--fresh-install`, no
/// model saved yet, as on a new phone; `--gemma12b`: 12B saved as well;
/// `--omni`, LFM3-Omni 2B; `--smart-only-e2b`: E2B alone, `--smart-no-e4b`
/// every one but E4B (Smart Mode's checks).
enum PreviewModels {
    static var installed: Set<String> = {
        let arguments = ProcessInfo.processInfo.arguments
        if arguments.contains("--smart-only-e2b") { return [ModelSpec.e2b.id] }
        var ids: Set<String> = arguments.contains("--fresh-install") ? []
            : arguments.contains("--download-waits")
            ? [ModelSpec.e4b.id, ModelSpec.qwen3.id] : [ModelSpec.e4b.id, ModelSpec.e2b.id, ModelSpec.qwen3.id]
        if arguments.contains("--gemma12b") { ids.insert(ModelSpec.gemma12B.id) }
        if arguments.contains("--omni") { ids.insert(ModelSpec.lfm3Omni.id) }
        if arguments.contains("--smart-no-e4b") { ids.remove(ModelSpec.e4b.id) }
        return ids
    }()
}

/// The preview's fixed search results.
enum PreviewWebSearch {
    static func record(query: String) -> WebSearchRecord {
        var record = WebSearchRecord()
        record.add(query: query, sources: [
            WebSearchSource(title: "東京スカイツリー", url: "https://ja.wikipedia.org/wiki/%E6%9D%B1%E4%BA%AC%E3%82%B9%E3%82%AB%E3%82%A4%E3%83%84%E3%83%AA%E3%83%BC", site: "ja.wikipedia.org"),
            WebSearchSource(title: "電波塔", url: "https://ja.wikipedia.org/wiki/%E9%9B%BB%E6%B3%A2%E5%A1%94", site: "ja.wikipedia.org")
        ], failure: nil)
        return record
    }
}

@MainActor final class ModelStore: ObservableObject {
    @Published var error: String?
    @Published var selectedModel = ModelSpec.e4b
    let isReady = true, isBusy = false, isRestoring = false
    /// `--cellular-only`: on cellular without Wi-Fi. `--download-waits`: E2B
    /// is downloading at 0%, so it waits for Wi-Fi until the switch is on.
    let network = ProcessInfo.processInfo.arguments.contains("--cellular-only")
        ? DownloadNetwork(hasWiFi: false, isOnline: true, cellularDenied: false) : .unknown
    @Published private var downloading: Set<String> =
        ProcessInfo.processInfo.arguments.contains("--download-waits") ? [ModelSpec.e2b.id] : []
    @Published private var cellularIDs: Set<String> = []
    @Published var allowsCellular = UserDefaults.standard.bool(forKey: ModelDownload.cellularKey) {
        didSet {
            UserDefaults.standard.set(allowsCellular, forKey: ModelDownload.cellularKey)
            // As the app: a download still at 0% starts again with the choice.
            cellularIDs = allowsCellular ? downloading : []
        }
    }
    init() {
        if ProcessInfo.processInfo.arguments.contains("--reset-settings") {
            UserDefaults.standard.removeObject(forKey: ModelDownload.cellularKey)
            allowsCellular = false
        }
        cellularIDs = allowsCellular ? downloading : []
    }
    func isDownloading(_ spec: ModelSpec) -> Bool { downloading.contains(spec.id) }
    func isWorking(on spec: ModelSpec) -> Bool { isDownloading(spec) }
    func progress(for spec: ModelSpec) -> Double { progress[spec.id] ?? 0 }
    /// A download's share, as the app's ModelStore reports it.
    @Published private var progress: [String: Double] = [:]
    private var attempts = 0
    func downloadWait(for spec: ModelSpec) -> DownloadWait? {
        isDownloading(spec) ? network.wait(usesCellular: cellularIDs.contains(spec.id)) : nil
    }
    /// As the app (1.1.0 (240)): `--download-stalls`, a running download
    /// has received nothing for a while. The preview's downloads end with
    /// the alert only, so no model card keeps a failure line.
    func isWaitingForData(_ spec: ModelSpec) -> Bool {
        isDownloading(spec) && ProcessInfo.processInfo.arguments.contains("--download-stalls")
    }
    let failures: [String: String] = [:]
    func statusText(for spec: ModelSpec) -> String {
        guard isDownloading(spec) else { return "UI検証用・モデル未使用" }
        return downloadWait(for: spec)?.status(name: spec.name, percent: 0) ?? String(localized: "\(spec.name)をダウンロード中 · \(0)%")
    }
    /// `--fresh-install`: no model saved yet, as on a new phone.
    /// `--gemma12b`: 12B saved as well; `--omni`, LFM3-Omni 2B.
    /// The chat store reads them too (PreviewModels.installed).
    @Published private(set) var installedIDs: Set<String> = PreviewModels.installed {
        didSet { PreviewModels.installed = installedIDs }
    }
    func isInstalled(_ spec: ModelSpec) -> Bool { installedIDs.contains(spec.id) }
    func delete(_ spec: ModelSpec) { installedIDs.remove(spec.id) }
    func refreshInstalled() {}
    func select(_ spec: ModelSpec) { selectedModel = spec }
    /// No network in the preview. `--download-progress`: a download fills
    /// in about six seconds and the model is saved. `--download-fails`:
    /// the first one stops after 1.5 s with the app's error, the next
    /// one fills.
    func download(_ spec: ModelSpec) {
        let arguments = ProcessInfo.processInfo.arguments
        guard !isDownloading(spec), !isInstalled(spec),
              arguments.contains("--download-progress") || arguments.contains("--download-fails") else { return }
        attempts += 1
        let fails = arguments.contains("--download-fails") && attempts == 1
        downloading.insert(spec.id)
        progress[spec.id] = 0
        Task {
            for step in 1...20 {
                do { try await Task.sleep(for: .milliseconds(300)) } catch { return }
                guard downloading.contains(spec.id) else { return }
                if fails && step == 5 {
                    downloading.remove(spec.id); progress[spec.id] = nil
                    error = "ダウンロードを完了できませんでした。\nインターネット接続がオフラインのようです。"
                    return
                }
                progress[spec.id] = Double(step) / 20
            }
            downloading.remove(spec.id); progress[spec.id] = nil
            installedIDs.insert(spec.id)
        }
    }
    func cancelDownload(_ spec: ModelSpec) { downloading.remove(spec.id); progress[spec.id] = nil }
    func importModel(_ url: URL, spec: ModelSpec) {}
}

@main struct PreviewApp: App {
    @StateObject private var chats = ChatStore()
    @StateObject private var model = ModelStore()
    private let arguments = ProcessInfo.processInfo.arguments
    init() {
        // How deep the main thread's stack goes while the chat opens (1.1.0
        // (239)): marked before the first view, read after it is on screen.
        if ProcessInfo.processInfo.arguments.contains("--stack-probe") {
            StackProbe.paint()
            for seconds in [1.0, 3.0, 6.0] {
                DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { StackProbe.log("after \(Int(seconds))s") }
            }
        }
        // As the TestFlight build on the phone, with the address space for
        // じっくり考える; --narrow-address-space is an install without it,
        // where じっくり考える runs as 深く and the chat says so.
        let space = ProcessInfo.processInfo.arguments.contains("--narrow-address-space") ? nil : AddressSpace.current()
        PhotoDetail.offer(atLaunch: space)
        VideoSound.offer(atLaunch: space)
        LargeModelProbe.offer(atLaunch: space)
        // The iPad's history beside the chat starts put away each launch;
        // `--keep-history-dock` keeps what the launch before left. Here,
        // before the first view reads it.
        if !ProcessInfo.processInfo.arguments.contains("--keep-history-dock") {
            UserDefaults.standard.removeObject(forKey: HistoryDock.storageKey)
        }
    }
    var body: some Scene {
        WindowGroup {
            ChatNavigationView().modifier(StartupPresenter()).environmentObject(chats).environmentObject(model)
                .modifier(PreviewMetricsSwitch(enabled: arguments.contains("--layout-metrics")))
                .environment(\.chatPreviewReduceMotion, arguments.contains("--reduce-motion"))
                .dynamicTypeSize(arguments.contains("--large-type") ? .accessibility3 : .large)
                // As the app: iOS's 文字サイズ does not reach it. --large-type
                // above stays for the layouts at the largest sizes.
                .modifier(FixedTextSize())
                .fieluaAppearance()
                .preferredColorScheme(arguments.contains("--dark") ? .dark : .light)
                .modifier(NarrowPhone(enabled: arguments.contains("--narrow-phone")))
                .overlay(alignment: .top) {
                    if arguments.contains("--elastic-diagnostics") { ElasticProbeView() }
                    if arguments.contains("--cloud-fixture") { PreviewCloudCheck() }
                    if arguments.contains("--download-activity") { PreviewDownloadActivity() }
                    if arguments.contains("--pull-snapshot") { PullSnapshotView() }
                    if arguments.contains("--show-pasteboard") { PreviewPasteboard() }
                    if arguments.contains("--show-text-size") { PreviewTextSize() }
                    if arguments.contains("--reply-trace") { PreviewReplyTrace() }
                    if arguments.contains("--table-trace") { PreviewTableTrace() }
                    if arguments.contains("--frame-trace") { PreviewFrameTrace() }
                }
                .overlay(alignment: .topTrailing) {
                    if arguments.contains("--pip-video") { PreviewPictureInPicture() }
                }
        }
    }
}

/// iOS's 文字サイズ and the size the window scene gives UIKit, for UI tests
/// to read (`--show-text-size`); set iOS's with
/// `-UIPreferredContentSizeCategoryName <category>`.
private struct PreviewTextSize: View {
    @State private var scene = ""
    var body: some View {
        Text(verbatim: "文字 \(scene)").font(.system(size: 9)).padding(2).background(.background)
            .accessibilityLabel(Text(verbatim: "iOS \(UIApplication.shared.preferredContentSizeCategory.rawValue) app \(scene)"))
            .accessibilityIdentifier("preview-text-size").allowsHitTesting(false)
            .task {
                // Once FixedTextSize has set the scene's trait and UIKit has
                // passed it on.
                try? await Task.sleep(for: .milliseconds(500))
                let windowScene = UIApplication.shared.connectedScenes.first { $0 is UIWindowScene } as? UIWindowScene
                scene = windowScene?.traitCollection.preferredContentSizeCategory.rawValue ?? "none"
            }
    }
}

/// What the app last copied, for UI tests to read (`--show-pasteboard`).
private struct PreviewPasteboard: View {
    @State private var copied = ""
    @State private var seen = UIPasteboard.general.changeCount
    private let tick = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    var body: some View {
        Text(verbatim: "コピー \(copied.count)文字").font(.caption2).padding(2).background(.background)
            .accessibilityLabel(Text(verbatim: copied.isEmpty ? "なし" : copied))
            .accessibilityIdentifier("preview-pasteboard").allowsHitTesting(false)
            .onReceive(NotificationCenter.default.publisher(for: UIPasteboard.changedNotification)) { _ in read() }
            .onReceive(tick) { _ in read() }
    }
    /// Only what this app copied after launch.
    private func read() {
        guard UIPasteboard.general.changeCount != seen else { return }
        seen = UIPasteboard.general.changeCount
        copied = UIPasteboard.general.string ?? ""
    }
}

private struct PreviewMetricsSwitch: ViewModifier {
    let enabled: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if enabled { content.modifier(PreviewLayoutMetrics()) } else { content }
    }
}

/// The narrowest iPhone's width, 375pt, centered in the simulator's
/// (`--narrow-phone`).
private struct NarrowPhone: ViewModifier {
    let enabled: Bool
    @ViewBuilder func body(content: Content) -> some View {
        if enabled { content.frame(width: 375) } else { content }
    }
}


/// A reply streamed like the on-device model: a few characters at a time,
/// with Markdown list items, growing from one line to about one screen.
enum PreviewTokenStream {
    static let text = """
    テスト、ですね！😊

    どのようなテストをしたいですか？例えば、以下のようなものが考えられます。

    1. **知識の確認テスト**（例：歴史、科学、語彙など）
    2. **簡単なクイズ**（雑学など）
    3. **文章の作成テスト**（文章を書く練習など）
    4. **特定のトピックについての質問応答テスト**

    もしよろしければ、**「〇〇についてのクイズを出して」**とか、**「算数の問題を出して」**といった具体的なご要望を教えてください！

    それとも、**「まずは何か一つ出して」**といった感じで始めても大丈夫ですよ！
    """
    static var chunks: [String] {
        var result: [String] = []
        var current = ""
        for character in text {
            current.append(character)
            if current.count == 3 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}

/// Every Markdown feature replies render, finished (`--markdown-sample`) or
/// streamed a few characters at a time (`--markdown-stream`).
enum PreviewMarkdown {
    /// Two paragraphs, the break inside one piece (`--paragraph-stream`).
    static let paragraphStream: [String] = ["最初の段落では、", "新しい文字が", "虹色で現れて、", "書いている位置に",
                                            "沿って流れながら", "少しずつ", "いつもの文字の色へ", "戻っていきます。\n\n次の",
                                            "段落が始まっても、", "前の段落の", "色の変化は", "途切れません。"]

    /// A table wider than the screen between prose, a quote and a long
    /// line of code (`--wide-table`).
    /// Tables a little wider than the screen at their columns' own widths,
    /// as E2B writes them: a long Japanese column beside a short one, a
    /// check column, and English with four columns (`--long-tables`, and
    /// streamed a few characters at a time with `--table-stream`). Up to
    /// 219 each scrolled sideways and hid its right edge.
    static let longTables = #"""
    ### 3. 物件・内装・設備計画

    | 項目 | 詳細な検討事項 |
    |:--|:--|
    | **物件選定** | 人通り、駅からの距離、家賃と保証金、周辺の競合店を比べて、無理なく払える場所を選びます。 |
    | **内装デザイン** | コンセプトに合う色と照明、席の数と通路の広さ、居心地のよさと回転率のバランスを決めます。 |
    | **厨房設備の選定** | エスプレッソマシン、冷蔵庫、製氷機、食洗機など、メニューに必要な機器と予算を一覧にします。 |
    | **工事と引き渡し** | 内装工事の見積もりを2〜3社で比べ、保健所の基準に合う配置かを工事の前に確かめます。 |

    ### 4. 運営体制の構築

    開店の1か月前までに、スタッフの採用と研修の計画を立てます。

    | 項目 | 確認事項 | 完了 |
    | :--- | :--- | :--- |
    | **店舗環境** | 内装デザインの最終確認、動線チェック、衛生管理体制の確立 | ☐ |
    | **設備** | 全ての機器の動作確認、在庫管理システムのテスト | ☐ |
    | **広報** | SNSアカウントの準備、プレスリリース（あれば）、オープニングイベントの企画 | ☐ |

    | Item | Owner | Notes | Due |
    |:--|:--|:--|--:|
    | Espresso machine | Kenji | Compare two suppliers' maintenance contracts before signing | Nov 15 |
    | Opening flyer | Aiko | Print 500 copies on recycled paper and hand them out at the station | Nov 28 |

    表の後の文章です。表は画面の幅に収まり、この文章と重なりません。
    """#

    static func longTables(part: String?) -> String {
        guard let part else { return longTables }
        var table = -1
        return longTables.components(separatedBy: "\n\n").filter { block in
            guard block.hasPrefix("|") else { return true }
            table += 1
            return part == String(table)
        }.joined(separator: "\n\n")
    }

    static func longTables(_ text: String, variant: String?) -> String {
        switch variant {
        case "nobox": return text.replacingOccurrences(of: "| ☐ |", with: "| 未 |")
        case "twocol":
            return text.replacingOccurrences(of: " 完了 |", with: "").replacingOccurrences(of: " :--- |\n", with: "\n")
                .replacingOccurrences(of: " ☐ |", with: "")
        case "short":
            return text.replacingOccurrences(of: "、動線チェック、衛生管理体制の確立", with: "")
                .replacingOccurrences(of: "、在庫管理システムのテスト", with: "")
                .replacingOccurrences(of: "、プレスリリース（あれば）、オープニングイベントの企画", with: "")
        default: return text
        }
    }

    /// --table-plan-stream: a plan as Gemma 4 E4B wrote one on the phone
    /// (2026-10-29), four columns with rows that leave the day empty, three
    /// characters at a time (1.1.0 (245)).
    static let planTable = #"""
    ### 春の京都1泊2日旅行プラン

    | 日程 | 時間帯 | 行動・訪問先 | ポイント・備考 |
    | :--- | :--- | :--- | :--- |
    | **1日目** | 午前 | 京都駅到着、ホテルへ移動・荷物預け | 観光の拠点となるホテルにチェックイン（または荷物を預ける） |
    | | 昼食 | 祇園周辺で京料理や湯豆腐などを楽しむ | 春の味覚を取り入れたランチがおすすめ |
    | | 午後 | 祇園・花見小路通散策、八坂神社仏閣巡り | 伝統的な街並みを散策し、春の雰囲気を楽しむ |
    | | 夕方 | 清水寺へ移動、清水の舞台を眺める | 夕暮れ時の景色も美しいです。 |
    | | 夕食 | 先斗町や木屋町通で京料理や居酒屋を楽しむ | 鴨川沿いの風情あるお店がおすすめです。 |
    | **2日目** | 午前 | 嵐山へ移動、竹林の小径を散策 | 早朝の散策が最も美しいです。 |
    | | 昼食 | 嵐山周辺で食事処を利用 | お蕎麦や湯豆腐など、地元の味覚を堪能。 |
    | | 午後 | 金閣寺（鹿苑寺）へ移動、見学 | 黄金に輝く舎利殿は春の光に映えます。 |

    **プランニングのポイント**

    - **移動手段：** 市内観光はバスや地下鉄、徒歩を組み合わせるのが効率的です。
    - **予約：** 人気の飲食店や宿泊施設は早めの予約をおすすめします。
    """#

    /// The same plan with its table written as lines of text, the cells of
    /// a row side by side (`--probe-table-as-text`), for the frames beside
    /// the table's.
    static var planText: String {
        planTable.split(separator: "\n", omittingEmptySubsequences: false).compactMap { line -> String? in
            guard line.hasPrefix("|") else { return String(line) }
            guard !line.allSatisfy({ "|-: ".contains($0) }) else { return nil }
            return line.split(separator: "|").map { $0.trimmingCharacters(in: .whitespaces) }
                .filter { !$0.isEmpty }.joined(separator: "　")
        }.joined(separator: "\n")
    }

    static var planChunks: [String] {
        var result: [String] = []
        var current = ""
        let plan = ProcessInfo.processInfo.arguments.contains("--probe-table-as-text") ? planText : planTable
        for character in plan {
            current.append(character)
            if current.count == 3 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }

    static var tableChunks: [String] {
        var result: [String] = []
        var current = ""
        for character in longTables {
            current.append(character)
            if current.count == 4 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }

    static let wideTable = #"""
    表の前の文章です。

    | 項目 | 1月 | 2月 | 3月 | 4月 | 5月 | 6月 | 7月 | 8月 | 9月 | 10月 | 11月 | 12月 | 合計 |
    |:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
    | 売上 | 1,200 | 1,350 | 1,100 | 1,420 | 1,380 | 1,500 | 1,610 | 1,580 | 1,450 | 1,520 | 1,700 | 1,890 | 17,700 |
    | 費用 | 820 | 870 | 790 | 900 | 880 | 940 | 990 | 1,010 | 930 | 960 | 1,050 | 1,120 | 11,260 |
    | 利益 | 380 | 480 | 310 | 520 | 500 | 560 | 620 | 570 | 520 | 560 | 650 | 770 | 6,440 |

    > 引用は画面の幅に収まります。

    表の後の文章です。表を左右に動かしても、この文章は動きません。

    ```swift
    let note = "横に長いコードの行は、コードブロックの中だけで横にスクロールします。"
    ```
    """#

    static let sample = #"""
    ## Markdownの表示

    **太字**、*斜体*、~~取り消し線~~、`インラインコード`、[リンク](https://www.apple.com/jp/) を使えます。

    > 引用文です。**強調**や `code` も入ります。

    1. 準備する
    2. 実行する
       - [x] 完了した項目
       - [ ] まだの項目

    | モデル | 速度 | メモリ | 画像 |
    |:--|--:|--:|:-:|
    | E2B | 速い | 0.6 GB | ○ |
    | E4B | 普通 | 0.85 GB | 調整中 |

    ```swift
    struct Greeting {
        let name = "Fielua" // 名前
        func text() -> String { "こんにちは、\(name)さん" }
    }
    ```

    二次方程式の解は $x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$ です。

    $$
    \int_0^1 x^2\,dx = \frac{1}{3}
    $$

    就活は $\text{自己分析} \times \text{企業研究}$ の掛け算です。

    $$
    \text{自己分析} \times \text{企業研究} \times \text{行動} = \text{内定}
    $$

    $$利益率 = \frac{利益}{売上} × 100$$

    導関数 $f'(x)$、$利益率 = 20%$、$\operatorname{argmax}_x \dfrac{x}{2}$ も読めます。

    $$
    \begin{align*}
    a &= b + c \\
    d &= e \times f
    \end{align*}
    $$

    連立方程式も描けます。

    $$
    \begin{cases}
    x + y = 5 \\
    x - y = 1
    \end{cases}
    $$

    区切り記号のない書き方も数式になります。
    \begin{cases} x+y=5 \\ x-y=1 \end{cases}

    **LaTeX形式:**
    \begin{aligned}
    a &= b+c \\
    x &= y+z
    \end{aligned}

    文中の \begin{cases} と \end{cases} や `\begin{aligned}` は文字のままです。

    幅の広い式 $\sum_{i=1}^{n} \frac{(x_i - \bar{x})^2}{n - 1} + \int_0^\infty e^{-t^2}\,dt + \lim_{x \to 0} \frac{\sin x}{x}$ は行を分けて表示します。

    $$ \xrightarrow{x} y $$

    ---

    ![サンプル画像](https://example.com/sample.png)
    """#

    /// A long reply like ChatGPT's (`--markdown-article`): every heading
    /// level, long paragraphs, nested and two-digit numbered lists, a quote,
    /// rules, a table and code, for the spacing and alignment review.
    static let article = #"""
    # 2035年のAIと暮らし

    AIが身近になった未来を想像しながら、見出し・リスト・表・コードの表示を確かめる長文です。段落が長くなっても、左右の余白をそろえたまま自然に折り返して読めるかを確認します。

    ここは2つ目の段落です。**太字の強調**と見出しの違い、*斜体*、~~取り消し線~~、`インラインコード` が本文の中で読みやすく並ぶかを見ます。

    ## 第1章：朝のルーティン

    朝7時、目覚ましより先にAIがカーテンを開けます。今日の予定と天気を短くまとめて読み上げ、通勤経路の混雑も先回りして知らせてくれます。

    ### 出かける前の準備

    1. 天気を確認する
    2. 持ち物をそろえる
       - 傘（午後から雨）
       - 充電器
         - USB-Cケーブル
         - モバイルバッテリー
    3. 家を出る時間を決める

    #### 確認するところ

    - 箇条書きの記号と本文の頭がそろっているか
    - 長い項目でも、2行目が記号の下に回り込まず、本文の頭にそろって折り返されるかを確かめるための少し長めの項目です
    - [x] チェック済みの項目
    - [ ] まだの項目

    ##### H5 の小見出し

    本文と同じくらいの大きさでも、**太字の文**とは区別できるかを見ます。

    ###### H6 の補足

    > AIは道具であり、使い方を決めるのは人です。
    > 引用は左の線と文字の色で本文と分けます。

    ---

    ## 第2章：数字で見る変化

    | 項目 | 2025年 | 2035年 |
    |:--|--:|--:|
    | AIを毎日使う人 | 30% | 85% |
    | 平均通勤時間 | 45分 | 28分 |

    ```python
    def greet(name):
        return f"おはよう、{name}さん"
    ```

    10. 二桁の番号
    11. の項目も
    12. 本文の頭がそろうか

    最後の段落です。表やコードのあとでも、段落の間隔が同じに保たれるかを確認します。
    """#

    static var wide: String {
        let code = (1...35).map { "def step_\($0)(x):\n    return x + \($0)  # \($0)番目" }.joined(separator: "\n")
        return """
        横に長い表と長いコードの確認です。

        | 項目 | 1月 | 2月 | 3月 | 4月 | 5月 | 6月 | 合計 |
        |---|--:|--:|--:|--:|--:|--:|--:|
        | 売上 | 120 | 135 | 150 | 160 | 172 | 180 | 917 |
        | 費用 | 80 | 82 | 90 | 95 | 99 | 101 | 547 |

        ```python
        \(code)
        ```

        言語名のないコードは、見て分かるときだけ言語を付けます。

        ```
        {"model": "E2B", "memory": 0.6, "vision": true}
        ```
        """
    }

    static var chunks: [String] {
        var result: [String] = []
        var current = ""
        for character in sample {
            current.append(character)
            if current.count == 4 { result.append(current); current = "" }
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}
