import SwiftUI
import UIKit
import PocketCore

/// UI checks only (`--reply-trace`): each time a reply's row says in its
/// place that it ended with no text (停止しました, 返信できませんでした), the
/// reply's state and how many characters it had. A short reply that ended
/// while the Aurora Orb was still leaving said 停止しました until its text
/// showed (2026-10-25, 1.1.0 (189)).
@MainActor final class ReplyPlaceholderLog: ObservableObject {
    static let shared = ReplyPlaceholderLog()
    @Published private(set) var lines: [String] = []
    func note(_ line: String) { lines.append(line) }
}

/// On the text in a reply's place: notes when it starts to say the reply
/// ended with no text.
struct ReplyPlaceholderTrace: ViewModifier {
    let shows: Bool
    let state: ReplyState
    let characters: Int
    func body(content: Content) -> some View {
        content.onChange(of: shows, initial: true) { _, shows in
            guard shows, PreviewProbe.on("--reply-trace") else { return }
            ReplyPlaceholderLog.shared.note("\(state.rawValue) \(characters)")
        }
    }
}

/// The notes so far, for the check to read: "none" until there is one.
struct PreviewReplyTrace: View {
    @ObservedObject private var log = ReplyPlaceholderLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-placeholder-trace")
            .accessibilityLabel(log.lines.isEmpty ? "none" : log.lines.joined(separator: ", "))
    }
}

/// UI checks only (`--glimpse-trace`): the Aurora Orb's glimpse of the
/// latest reply (1.1.0 (297)): when its first text came (seconds since
/// 1970, the check's clock too), and as seconds after it the phrase it
/// showed, when the glimpse's line came and went, when the orb began to
/// leave and when it had gone (the reply's text may begin then), with the
/// reply's state. A reply stopped before any text has no first text ("-").
@MainActor final class ReplyGlimpseLog: ObservableObject {
    static let shared = ReplyGlimpseLog()
    @Published private(set) var summary = "none"
    private var first: Date?
    private var parts: [String] = []
    private let on = PreviewProbe.on("--glimpse-trace")

    func firstText() {
        guard on, first == nil || parts.last?.hasPrefix("gone") == true else { return }
        let now = Date()
        first = now
        parts = [String(format: "first@%.3f", now.timeIntervalSince1970)]
        publish()
    }

    /// The glimpse's line came into the row, or left it.
    func line(_ shown: Bool) {
        guard on else { return }
        parts.append("line \(shown ? "on" : "off") \(since())")
        publish()
    }

    func shown(_ phrase: String) {
        guard on else { return }
        parts.append("phrase \(since()) 「\(phrase)」")
        publish()
    }

    func orb(_ phase: String, state: String) {
        guard on else { return }
        parts.append("\(phase) \(since()) \(state)")
        publish()
    }

    private func since() -> String {
        first.map { String(format: "%.2f", Date().timeIntervalSince($0)) } ?? "-"
    }

    private func publish() { summary = parts.joined(separator: "; ") }
}

/// The glimpse's notes so far, for the check to read.
struct PreviewGlimpseTrace: View {
    @ObservedObject private var log = ReplyGlimpseLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-glimpse-trace")
            .accessibilityLabel(log.summary)
    }
}

/// UI checks only (`--table-trace`): a reply table's height each time it
/// changes, so a check can see that it only grows while it is written. As
/// 1.1.0 (244) streamed a table (`--probe-table-pop`), a row showed a cell
/// or two, went, and came back whole: the table grew and shrank by a row.
@MainActor final class TableGrowthLog: ObservableObject {
    static let shared = TableGrowthLog()
    @Published private(set) var summary = "none"
    private var height: CGFloat = 0
    private var rows = 0
    private var grew = 0, shrank = 0, rowsBack = 0, whileWritten = 0
    private var largestGrowth: CGFloat = 0, largestShrink: CGFloat = 0

    func note(height: CGFloat, rows: Int, streaming: Bool) {
        let change = height - self.height
        guard abs(change) > 0.5 else { return }
        if change > 0 { grew += 1; largestGrowth = max(largestGrowth, change) }
        if change < 0 { shrank += 1; largestShrink = max(largestShrink, -change) }
        if rows < self.rows { rowsBack += 1 }
        if streaming { whileWritten += 1 }
        self.height = height
        self.rows = rows
        summary = String(format: "grew %d shrank %d rowsBack %d written %d largestGrowth %.0f largestShrink %.0f rows %d height %.0f",
                         grew, shrank, rowsBack, whileWritten, largestGrowth, largestShrink, rows, height)
    }
}

/// UI checks only (`--frame-trace`): the screen's frames on the main thread
/// while a reply is written and a second after, and those that came more
/// than half a frame late, as a busy main thread makes them (1.1.0 (245)).
@MainActor final class FrameGapCounter: NSObject {
    private var frames = 0, late = 0
    private var slowest: CFTimeInterval = 0
    private var link: CADisplayLink?
    private var first: CFTimeInterval = 0, previous: CFTimeInterval = 0

    func start() {
        guard link == nil else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    func stop() {
        link?.invalidate()
        link = nil
    }

    var summary: String {
        let seconds = previous - first
        return String(format: "frames %d seconds %.1f fps %.1f late %d slowest %.0f ms",
                      frames, seconds, seconds > 0 ? Double(frames) / seconds : 0, late, slowest * 1000)
    }

    @objc private func tick(_ link: CADisplayLink) {
        defer { previous = link.timestamp }
        guard previous > 0 else { first = link.timestamp; return }
        let gap = link.timestamp - previous
        frames += 1
        if gap > (link.targetTimestamp - link.timestamp) * 1.5 { late += 1 }
        slowest = max(slowest, gap)
    }
}

@MainActor final class StreamFrameLog: ObservableObject {
    static let shared = StreamFrameLog()
    @Published var summary = "none"
}

/// The last reply's frames, for the check to read: "none" until it ended.
struct PreviewFrameTrace: View {
    @ObservedObject private var log = StreamFrameLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("stream-frame-trace")
            .accessibilityLabel(log.summary)
    }
}

/// The table's notes so far, for the check to read: "none" until there is one.
struct PreviewTableTrace: View {
    @ObservedObject private var log = TableGrowthLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("table-growth-trace")
            .accessibilityLabel(log.summary)
    }
}
