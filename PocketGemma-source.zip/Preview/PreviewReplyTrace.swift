import SwiftUI
import PocketCore

/// UI checks only (`--reply-trace`): each time a reply's row says in its
/// place that it ended with no text (停止しました, 返信できませんでした), the
/// reply's state and how many characters it had. A short reply that ended
/// while the Aurora Orb was still leaving said 停止しました until its text
/// showed (2026-10-25, 1.1.0 (189)).
@MainActor final class ReplyPlaceholderLog: ObservableObject {
    static let shared = ReplyPlaceholderLog()
    @Published private(set) var lines: [String] = []
    func note(_ line: String) { lines.append(line) }
}

/// On the text in a reply's place: notes when it starts to say the reply
/// ended with no text.
struct ReplyPlaceholderTrace: ViewModifier {
    let shows: Bool
    let state: ReplyState
    let characters: Int
    func body(content: Content) -> some View {
        content.onChange(of: shows, initial: true) { _, shows in
            guard shows, PreviewProbe.on("--reply-trace") else { return }
            ReplyPlaceholderLog.shared.note("\(state.rawValue) \(characters)")
        }
    }
}

/// The notes so far, for the check to read: "none" until there is one.
struct PreviewReplyTrace: View {
    @ObservedObject private var log = ReplyPlaceholderLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-placeholder-trace")
            .accessibilityLabel(log.lines.isEmpty ? "none" : log.lines.joined(separator: ", "))
    }
}

/// UI checks only (`--table-trace`): a reply table's height each time it
/// changes, so a check can see that it only grows while it is written. As
/// 1.1.0 (244) streamed a table (`--probe-table-pop`), a row showed a cell
/// or two, went, and came back whole: the table grew and shrank by a row.
@MainActor final class TableGrowthLog: ObservableObject {
    static let shared = TableGrowthLog()
    @Published private(set) var summary = "none"
    private var height: CGFloat = 0
    private var rows = 0
    private var grew = 0, shrank = 0, rowsBack = 0, whileWritten = 0
    private var largestGrowth: CGFloat = 0, largestShrink: CGFloat = 0

    func note(height: CGFloat, rows: Int, streaming: Bool) {
        let change = height - self.height
        guard abs(change) > 0.5 else { return }
        if change > 0 { grew += 1; largestGrowth = max(largestGrowth, change) }
        if change < 0 { shrank += 1; largestShrink = max(largestShrink, -change) }
        if rows < self.rows { rowsBack += 1 }
        if streaming { whileWritten += 1 }
        self.height = height
        self.rows = rows
        summary = String(format: "grew %d shrank %d rowsBack %d written %d largestGrowth %.0f largestShrink %.0f rows %d height %.0f",
                         grew, shrank, rowsBack, whileWritten, largestGrowth, largestShrink, rows, height)
    }
}

/// The table's notes so far, for the check to read: "none" until there is one.
struct PreviewTableTrace: View {
    @ObservedObject private var log = TableGrowthLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("table-growth-trace")
            .accessibilityLabel(log.summary)
    }
}
