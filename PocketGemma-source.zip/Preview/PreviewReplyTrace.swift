import SwiftUI
import UIKit
import PocketCore

/// UI checks only (`--reply-trace`): each time a reply's row says in its
/// place that it ended with no text (停止しました, 返信できませんでした), the
/// reply's state and how many characters it had. A short reply that ended
/// while the Aurora Orb was still leaving said 停止しました until its text
/// showed (2026-10-25, 1.1.0 (189)).
@MainActor final class ReplyPlaceholderLog: ObservableObject {
    static let shared = ReplyPlaceholderLog()
    @Published private(set) var lines: [String] = []
    func note(_ line: String) { lines.append(line) }
}

/// On the text in a reply's place: notes when it starts to say the reply
/// ended with no text.
struct ReplyPlaceholderTrace: ViewModifier {
    let shows: Bool
    let state: ReplyState
    let characters: Int
    func body(content: Content) -> some View {
        content.onChange(of: shows, initial: true) { _, shows in
            guard shows, PreviewProbe.on("--reply-trace") else { return }
            ReplyPlaceholderLog.shared.note("\(state.rawValue) \(characters)")
        }
    }
}

/// The notes so far, for the check to read: "none" until there is one.
struct PreviewReplyTrace: View {
    @ObservedObject private var log = ReplyPlaceholderLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-placeholder-trace")
            .accessibilityLabel(log.lines.isEmpty ? "none" : log.lines.joined(separator: ", "))
    }
}

/// UI checks only (`--table-trace`): a reply table's height each time it
/// changes, so a check can see that it only grows while it is written. As
/// 1.1.0 (244) streamed a table (`--probe-table-pop`), a row showed a cell
/// or two, went, and came back whole: the table grew and shrank by a row.
@MainActor final class TableGrowthLog: ObservableObject {
    static let shared = TableGrowthLog()
    @Published private(set) var summary = "none"
    private var height: CGFloat = 0
    private var rows = 0
    private var grew = 0, shrank = 0, rowsBack = 0, whileWritten = 0
    private var largestGrowth: CGFloat = 0, largestShrink: CGFloat = 0

    func note(height: CGFloat, rows: Int, streaming: Bool) {
        let change = height - self.height
        guard abs(change) > 0.5 else { return }
        if change > 0 { grew += 1; largestGrowth = max(largestGrowth, change) }
        if change < 0 { shrank += 1; largestShrink = max(largestShrink, -change) }
        if rows < self.rows { rowsBack += 1 }
        if streaming { whileWritten += 1 }
        self.height = height
        self.rows = rows
        summary = String(format: "grew %d shrank %d rowsBack %d written %d largestGrowth %.0f largestShrink %.0f rows %d height %.0f",
                         grew, shrank, rowsBack, whileWritten, largestGrowth, largestShrink, rows, height)
    }
}

/// UI checks only (`--frame-trace`): the screen's frames on the main thread
/// while a reply is written and a second after, and those that came more
/// than half a frame late, as a busy main thread makes them (1.1.0 (245)).
@MainActor final class FrameGapCounter: NSObject {
    private var frames = 0, late = 0
    private var slowest: CFTimeInterval = 0
    private var link: CADisplayLink?
    private var first: CFTimeInterval = 0, previous: CFTimeInterval = 0

    func start() {
        guard link == nil else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    func stop() {
        link?.invalidate()
        link = nil
    }

    var summary: String {
        let seconds = previous - first
        return String(format: "frames %d seconds %.1f fps %.1f late %d slowest %.0f ms",
                      frames, seconds, seconds > 0 ? Double(frames) / seconds : 0, late, slowest * 1000)
    }

    @objc private func tick(_ link: CADisplayLink) {
        defer { previous = link.timestamp }
        guard previous > 0 else { first = link.timestamp; return }
        let gap = link.timestamp - previous
        frames += 1
        if gap > (link.targetTimestamp - link.timestamp) * 1.5 { late += 1 }
        slowest = max(slowest, gap)
    }
}

@MainActor final class StreamFrameLog: ObservableObject {
    static let shared = StreamFrameLog()
    @Published var summary = "none"
}

/// The last reply's frames, for the check to read: "none" until it ended.
struct PreviewFrameTrace: View {
    @ObservedObject private var log = StreamFrameLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("stream-frame-trace")
            .accessibilityLabel(log.summary)
    }
}

/// The table's notes so far, for the check to read: "none" until there is one.
struct PreviewTableTrace: View {
    @ObservedObject private var log = TableGrowthLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("table-growth-trace")
            .accessibilityLabel(log.summary)
    }
}

/// UI checks only (`--preview-trace`), 生成中の一節 (1.1.0 (301)): each
/// phrase the reply's row shows beside the orb and when (seconds after
/// the reply's first text), whether its words were all in the reply as
/// the model had written it by then (in order, spaces aside: nothing made
/// up, nothing ahead), anything shown before the text began, when the
/// reply ended and when the row went. The check reads it once the reply
/// is done; "none" until then.
@MainActor final class ReplyPreviewLog: ObservableObject {
    static let shared = ReplyPreviewLog()
    @Published private(set) var summary = "none"
    private var began: Date?
    private var ended: Double?
    private var written: Double?
    private var gone: Double?
    private var phrases: [(number: Int, at: Double, text: String)] = []
    private var changes = 0, foreign = 0, early = 0, longest = 0

    private func seconds(_ date: Date = Date()) -> Double { began.map { date.timeIntervalSince($0) } ?? -1 }

    func began(at date: Date) {
        began = date; ended = nil; written = nil; gone = nil
        phrases = []; changes = 0; foreign = 0; early = 0; longest = 0
    }

    func shown(number: Int, text: String, source: String) {
        guard PreviewProbe.on("--preview-trace") else { return }
        if began == nil { early += 1 }
        changes += 1
        if !Self.inOrder(text, in: source) { foreign += 1 }
        longest = max(longest, text.count)
        if phrases.last?.number != number { phrases.append((number, seconds(), text)) } else { phrases[phrases.count - 1].text = text }
        publish()
    }

    func ended(at date: Date) {
        guard PreviewProbe.on("--preview-trace"), began != nil, ended == nil else { return }
        ended = seconds(date)
        publish(final: true)
    }

    /// The reply's text all laid out (ReplyPacer caught up).
    func written(at date: Date) {
        guard PreviewProbe.on("--preview-trace"), began != nil, written == nil else { return }
        written = seconds(date)
    }

    func gone(at date: Date) {
        guard PreviewProbe.on("--preview-trace"), began != nil else { return }
        gone = seconds(date)
        publish(final: true)
    }

    private func publish(final: Bool = false) {
        guard final else { return }
        let lives = zip(phrases.dropFirst(), phrases).map { $0.at - $1.at }
        let texts = phrases.map { String(format: "%d@%.2f「%@」", $0.number, $0.at, String($0.text.prefix(48))) }
        summary = String(format: "phrases %d changes %d foreign %d early %d longest %d shortestLife %.2f ended %.2f written %.2f gone %.2f | ",
                         phrases.count, changes, foreign, early, longest, lives.min() ?? -1, ended ?? -1, written ?? -1, gone ?? -1)
            + texts.joined(separator: " | ")
    }

    /// Every character of `text` but spaces in `source`, in order.
    static func inOrder(_ text: String, in source: String) -> Bool {
        var rest = source[...]
        for character in text where !character.isWhitespace {
            guard let found = rest.firstIndex(of: character) else { return false }
            rest = rest[rest.index(after: found)...]
        }
        return true
    }
}

/// The phrases' record, for the check to read.
struct PreviewPhraseTrace: View {
    @ObservedObject private var log = ReplyPreviewLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-preview-trace")
            .accessibilityLabel(log.summary)
    }
}
