import SwiftUI
import PocketCore

/// UI checks only (`--reply-trace`): each time a reply's row says in its
/// place that it ended with no text (停止しました, 返信できませんでした), the
/// reply's state and how many characters it had. A short reply that ended
/// while the Aurora Orb was still leaving said 停止しました until its text
/// showed (2026-10-25, 1.1.0 (189)).
@MainActor final class ReplyPlaceholderLog: ObservableObject {
    static let shared = ReplyPlaceholderLog()
    @Published private(set) var lines: [String] = []
    func note(_ line: String) { lines.append(line) }
}

/// On the text in a reply's place: notes when it starts to say the reply
/// ended with no text.
struct ReplyPlaceholderTrace: ViewModifier {
    let shows: Bool
    let state: ReplyState
    let characters: Int
    func body(content: Content) -> some View {
        content.onChange(of: shows, initial: true) { _, shows in
            guard shows, PreviewProbe.on("--reply-trace") else { return }
            ReplyPlaceholderLog.shared.note("\(state.rawValue) \(characters)")
        }
    }
}

/// The notes so far, for the check to read: "none" until there is one.
struct PreviewReplyTrace: View {
    @ObservedObject private var log = ReplyPlaceholderLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-placeholder-trace")
            .accessibilityLabel(log.lines.isEmpty ? "none" : log.lines.joined(separator: ", "))
    }
}
