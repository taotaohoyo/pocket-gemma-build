import SwiftUI
import UIKit
import PocketCore

/// UI checks only (`--reply-trace`): each time a reply's row says in its
/// place that it ended with no text (停止しました, 返信できませんでした), the
/// reply's state and how many characters it had. A short reply that ended
/// while the Aurora Orb was still leaving said 停止しました until its text
/// showed (2026-10-25, 1.1.0 (189)).
@MainActor final class ReplyPlaceholderLog: ObservableObject {
    static let shared = ReplyPlaceholderLog()
    @Published private(set) var lines: [String] = []
    func note(_ line: String) { lines.append(line) }
}

/// On the text in a reply's place: notes when it starts to say the reply
/// ended with no text.
struct ReplyPlaceholderTrace: ViewModifier {
    let shows: Bool
    let state: ReplyState
    let characters: Int
    func body(content: Content) -> some View {
        content.onChange(of: shows, initial: true) { _, shows in
            guard shows, PreviewProbe.on("--reply-trace") else { return }
            ReplyPlaceholderLog.shared.note("\(state.rawValue) \(characters)")
        }
    }
}

/// The notes so far, for the check to read: "none" until there is one.
struct PreviewReplyTrace: View {
    @ObservedObject private var log = ReplyPlaceholderLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-placeholder-trace")
            .accessibilityLabel(log.lines.isEmpty ? "none" : log.lines.joined(separator: ", "))
    }
}

/// UI checks only (`--table-trace`): a reply table's height each time it
/// changes, so a check can see that it only grows while it is written. As
/// 1.1.0 (244) streamed a table (`--probe-table-pop`), a row showed a cell
/// or two, went, and came back whole: the table grew and shrank by a row.
@MainActor final class TableGrowthLog: ObservableObject {
    static let shared = TableGrowthLog()
    @Published private(set) var summary = "none"
    private var height: CGFloat = 0
    private var rows = 0
    private var grew = 0, shrank = 0, rowsBack = 0, whileWritten = 0
    private var largestGrowth: CGFloat = 0, largestShrink: CGFloat = 0

    func note(height: CGFloat, rows: Int, streaming: Bool) {
        let change = height - self.height
        guard abs(change) > 0.5 else { return }
        if change > 0 { grew += 1; largestGrowth = max(largestGrowth, change) }
        if change < 0 { shrank += 1; largestShrink = max(largestShrink, -change) }
        if rows < self.rows { rowsBack += 1 }
        if streaming { whileWritten += 1 }
        self.height = height
        self.rows = rows
        summary = String(format: "grew %d shrank %d rowsBack %d written %d largestGrowth %.0f largestShrink %.0f rows %d height %.0f",
                         grew, shrank, rowsBack, whileWritten, largestGrowth, largestShrink, rows, height)
    }
}

/// UI checks only (`--frame-trace`): the screen's frames on the main thread
/// while a reply is written and a second after, and those that came more
/// than half a frame late, as a busy main thread makes them (1.1.0 (245)).
@MainActor final class FrameGapCounter: NSObject {
    private var frames = 0, late = 0
    private var slowest: CFTimeInterval = 0
    private var link: CADisplayLink?
    private var first: CFTimeInterval = 0, previous: CFTimeInterval = 0

    func start() {
        guard link == nil else { return }
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    func stop() {
        link?.invalidate()
        link = nil
    }

    var summary: String {
        let seconds = previous - first
        return String(format: "frames %d seconds %.1f fps %.1f late %d slowest %.0f ms",
                      frames, seconds, seconds > 0 ? Double(frames) / seconds : 0, late, slowest * 1000)
    }

    @objc private func tick(_ link: CADisplayLink) {
        defer { previous = link.timestamp }
        guard previous > 0 else { first = link.timestamp; return }
        let gap = link.timestamp - previous
        frames += 1
        if gap > (link.targetTimestamp - link.timestamp) * 1.5 { late += 1 }
        slowest = max(slowest, gap)
    }
}

@MainActor final class StreamFrameLog: ObservableObject {
    static let shared = StreamFrameLog()
    @Published var summary = "none"
}

/// The last reply's frames, for the check to read: "none" until it ended.
struct PreviewFrameTrace: View {
    @ObservedObject private var log = StreamFrameLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("stream-frame-trace")
            .accessibilityLabel(log.summary)
    }
}

/// The table's notes so far, for the check to read: "none" until there is one.
struct PreviewTableTrace: View {
    @ObservedObject private var log = TableGrowthLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("table-growth-trace")
            .accessibilityLabel(log.summary)
    }
}

/// UI checks only (`--preview-trace`), 要点 (1.1.0 (302)): each point the
/// reply's row shows beside the orb, when (seconds after the reply's first
/// text) and from what (summary, topics, structure); how many were the
/// reply's own words cut out (`copies`: ReplyPointCheck.isCopy against
/// the text laid out by then), how many held a word or a number the text
/// laid out by then did not (`foreign`: every word of a topic or
/// structure point in it; a summary's words by ReplyPointCheck.grounded),
/// anything shown before the text began, how many characters were laid
/// out when the first came, when the reply ended and when the row went;
/// and whether Apple's on-device model could be asked
/// (ReplyPointWriter.availability). The check reads it once the reply is
/// done; "none" until then.
@MainActor final class ReplyPreviewLog: ObservableObject {
    static let shared = ReplyPreviewLog()
    @Published private(set) var summary = "none"
    private var began: Date?
    private var ended: Double?
    private var written: Double?
    private var gone: Double?
    private var phrases: [(number: Int, at: Double, text: String, kind: String)] = []
    private var copies = 0, foreign = 0, early = 0, firstAfter = -1
    private var model = ""
    /// What Apple's on-device model (or its stand-in) answered each time
    /// it was asked, and whether ReplyPointCheck let it show.
    private var asks: [String] = []

    private func seconds(_ date: Date = Date()) -> Double { began.map { date.timeIntervalSince($0) } ?? -1 }

    func began(at date: Date) {
        began = date; ended = nil; written = nil; gone = nil
        phrases = []; copies = 0; foreign = 0; early = 0; firstAfter = -1; asks = []
        model = String(describing: ReplyPointWriter.shared.availability).replacingOccurrences(of: " ", with: "_")
    }

    func shown(number: Int, text: String, kind: String, source: String) {
        guard PreviewProbe.on("--preview-trace") else { return }
        if began == nil { early += 1 }
        let plain = ReplyPreviewText.plain(source)
        if ReplyPointCheck.isCopy(text, of: plain) { copies += 1 }
        if !Self.inSource(text, kind: kind, source: plain) { foreign += 1 }
        if phrases.isEmpty { firstAfter = plain.count }
        phrases.append((number, seconds(), text, kind))
        publish()
    }

    /// The model was asked: its answer (or why there was none), and
    /// whether it passed ReplyPointCheck.
    func asked(answer: String?, failure: String?, passed: Bool, seconds taken: Double) {
        guard PreviewProbe.on("--preview-trace") else { return }
        let said = answer.map { text -> String in
            let line = text.replacingOccurrences(of: "\n", with: " ").replacingOccurrences(of: "|", with: "/")
            return "「" + String(line.prefix(40)) + "」"
        } ?? "×" + (failure ?? "nil")
        asks.append(String(format: "%.2f %@ %@ %.2fs", seconds(), said, passed ? "ok" : "refused", taken))
    }

    func ended(at date: Date) {
        guard PreviewProbe.on("--preview-trace"), began != nil, ended == nil else { return }
        ended = seconds(date)
        publish(final: true)
    }

    /// The reply's text all laid out (ReplyPacer caught up).
    func written(at date: Date) {
        guard PreviewProbe.on("--preview-trace"), began != nil, written == nil else { return }
        written = seconds(date)
    }

    func gone(at date: Date) {
        guard PreviewProbe.on("--preview-trace"), began != nil else { return }
        gone = seconds(date)
        publish(final: true)
    }

    private func publish(final: Bool = false) {
        guard final else { return }
        let lives = zip(phrases.dropFirst(), phrases).map { $0.at - $1.at }
        let kinds = Dictionary(grouping: phrases, by: \.kind).map { "\($0.key)=\($0.value.count)" }.sorted().joined(separator: ",")
        let texts = phrases.map { String(format: "%d@%.2f[%@]「%@」", $0.number, $0.at, $0.kind, $0.text) }
        summary = String(format: "points %d kinds %@ copies %d foreign %d early %d firstAfter %d shortestLife %.2f ended %.2f written %.2f gone %.2f model %@ | ",
                         phrases.count, kinds.isEmpty ? "-" : kinds, copies, foreign, early, firstAfter, lives.min() ?? -1,
                         ended ?? -1, written ?? -1, gone ?? -1, model)
            + texts.joined(separator: " | ")
            + (asks.isEmpty ? "" : " || asks " + asks.joined(separator: " / "))
    }

    /// A topic or structure point's words all in the text (its labels
    /// aside: 表, のコード, 数式, グラフ, など), a summary's grounded in it.
    static func inSource(_ point: String, kind: String, source: String) -> Bool {
        if kind == "summary" { return ReplyPointCheck.grounded(point, in: source) }
        var rest = point
        for label in ["表：", "Table: ", " のコード", " code", "数式", "グラフ", "Formula", "Chart", "など"] {
            rest = rest.replacingOccurrences(of: label, with: "・")
        }
        let words = rest.components(separatedBy: CharacterSet(charactersIn: "・：: ·,")).filter { !$0.isEmpty }
        let lowered = source.lowercased()
        return words.allSatisfy { word in
            word == "Swift" || word == "コード" || lowered.contains(word.lowercased())
        }
    }
}

/// UI checks only (`--points-model-stub`): what Apple's on-device model
/// might answer for the sample's passages (PreviewOrbSample), the point
/// for the newest thing a passage tells; one of them the passage's own
/// words cut out, which ReplyPointCheck must refuse (the structure's
/// point shows instead).
enum PreviewReplyPoints {
    static let answers: [(words: String, answer: String)] = [
        ("薬の候補", "身近な研究の例"),
        ("実用化", "実用化までの課題"),
        ("重ね合わせた状態", "0と1を同時に重ね合わせた状態"),
        ("極低温", "壊れやすい量子状態への対策"),
        ("量子ビットという", "量子ビットで同時に計算"),
    ]

    static func answer(for passage: String) -> String? {
        var best: (at: String.Index, answer: String)?
        for (words, answer) in answers {
            guard let found = passage.range(of: words, options: .backwards) else { continue }
            if best == nil || found.lowerBound > best!.at { best = (found.lowerBound, answer) }
        }
        return best?.answer
    }
}

/// The points' record, for the check to read.
struct PreviewPhraseTrace: View {
    @ObservedObject private var log = ReplyPreviewLog.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("reply-preview-trace")
            .accessibilityLabel(log.summary)
    }
}
