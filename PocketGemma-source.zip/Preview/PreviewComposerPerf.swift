import SwiftUI
import UIKit

/// `--composer-perf` (1.1.0 (275), fielua-reports #13): each time
/// スタンダード's bar opens into the panel or closes again, what it took,
/// for the UI check to compare 274 with 275 (`--standard-springs-274
/// --composer-writes-274` are 274's springs and writes):
/// - the frames its motion drew (ComposerPanelMorph's body runs once a
///   frame while the corners round in or out), the longest wait between
///   two, and when the corners were half way, nine tenths of the way and
///   there, after the motion was asked for;
/// - the display's beats the main thread was too busy to answer, and how
///   busy it was meanwhile (as SettingsSlideMeter, 1.1.0 (153));
/// - how often the chat's whole body ran (ChatView.body), the field laid
///   itself out, and the chat's state was written, and by what;
/// - the keyboard's notice: how long after the motion began, and its own
///   length.
/// One line a motion, read through an accessibility element (Readout). The
/// simulator draws at most 60 frames a second: what the phone's 120Hz
/// does is for the phone to show.
@Observable @MainActor final class ComposerPerfProbe {
    static let shared = ComposerPerfProbe()
    static let on = PreviewProbe.on("--composer-perf")
    private static let slowdown: Double = PreviewProbe.on("--slow-standard") ? 5 : 1

    private(set) var lines: [String] = []
    @ObservationIgnored private var motions = 0
    @ObservationIgnored private var start: CFTimeInterval?
    @ObservationIgnored private var opening = true
    @ObservationIgnored private var frames: [(CFTimeInterval, CGFloat)] = []
    @ObservationIgnored private var bodies = 0
    @ObservationIgnored private var layouts = 0
    @ObservationIgnored private var writes: [String: Int] = [:]
    @ObservationIgnored private var keyboardNote = "なし"
    @ObservationIgnored private var beats: [CFTimeInterval] = []
    @ObservationIgnored private var beat: CFTimeInterval = 1.0 / 60
    @ObservationIgnored private var busy: [(CFTimeInterval, CFTimeInterval)] = []
    @ObservationIgnored private var wokeAt: CFTimeInterval?
    @ObservationIgnored private var observers: [CFRunLoopObserver] = []
    @ObservationIgnored private var link: ComposerPerfBeat?
    @ObservationIgnored private var notes: [String] = []

    /// setStandardOpen: a motion begins.
    func began(open: Bool) {
        guard Self.on else { return }
        if start != nil { ended() }
        watchMainThread()
        motions += 1
        let motion = motions
        let now = CACurrentMediaTime()
        start = now
        opening = open
        frames = []
        bodies = 0
        layouts = 0
        writes = [:]
        keyboardNote = "なし"
        beats = []
        busy = []
        wokeAt = now
        link?.stop()
        link = ComposerPerfBeat { [weak self] time, length in
            self?.beats.append(time)
            if length > 0 { self?.beat = length }
        }
        let length = 0.9 * Self.slowdown
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(length))
            if motion == self.motions { self.ended() }
        }
    }

    /// ComposerPanelMorph's body: one frame of the motion, with its corners.
    func frame(radius: CGFloat) {
        guard let start, CACurrentMediaTime() - start < 2 * Self.slowdown else { return }
        let now = CACurrentMediaTime()
        if let last = frames.last, now - last.0 < 0.002 { frames[frames.count - 1] = (now, radius); return }
        frames.append((now, radius))
    }

    /// ChatView.body ran.
    func drew() { if start != nil { bodies += 1 } }
    /// The field laid itself out.
    func laidOut() { if start != nil { layouts += 1 } }
    /// The chat's state written for the composer.
    func wrote(_ what: String) { if start != nil { writes[what, default: 0] += 1 } }

    /// The keyboard's notice, while a motion is measured.
    func keyboard(_ note: Notification, showing: Bool) {
        guard Self.on else { return }
        let duration = (note.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double) ?? 0
        let end = (note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue ?? .zero
        let text = String(format: "%@ %.0fms 高さ%.0f", showing ? "出る" : "下がる", duration * 1000, end.height)
        if let start {
            keyboardNote = String(format: "%+.0fms ", (CACurrentMediaTime() - start) * 1000) + text
        } else {
            note(text)
        }
    }

    /// Anything else worth a line: the keyboard pulled, the conversation tapped.
    func note(_ text: String) {
        guard Self.on else { return }
        let at = start.map { String(format: "（動きから %+.0fms）", (CACurrentMediaTime() - $0) * 1000) } ?? ""
        append("note " + text + at)
    }

    private func append(_ line: String) {
        lines.append(line)
        if lines.count > 40 { lines.removeFirst(lines.count - 40) }
    }

    private func ended() {
        guard let start else { return }
        self.start = nil
        link?.stop()
        link = nil
        if let woke = wokeAt { busy.append((woke, CACurrentMediaTime())); wokeAt = nil }
        let variant = PreviewProbe.on("--standard-springs-274") ? "274" : "275"
        let kind = opening ? "open" : "close"
        // The corners: 26pt (the bar's round ends) and 22pt (the panel's).
        let from: CGFloat = opening ? ChatMetrics.standardBar / 2 : ChatMetrics.composerRadius
        let to: CGFloat = opening ? ChatMetrics.composerRadius : ChatMetrics.standardBar / 2
        // From the first frame that moved to the first one there: what
        // the body drew after that is not the motion's.
        var moving = Array(frames.drop { abs($0.1 - from) <= 0.001 })
        if let there = moving.firstIndex(where: { abs($0.1 - to) <= 0.001 }) { moving = Array(moving[...there]) }
        func reached(_ share: CGFloat) -> String {
            guard let hit = frames.first(where: { abs($0.1 - from) >= abs(to - from) * share }) else { return "-" }
            return String(format: "%.0f", (hit.0 - start) * 1000)
        }
        var gap = 0.0, over = 0
        for (earlier, later) in zip(moving, moving.dropFirst()) {
            let wait = later.0 - earlier.0
            gap = max(gap, wait)
            if wait > beat * 1.5 { over += 1 }
        }
        let first = moving.first?.0 ?? start, last = moving.last?.0 ?? start
        let inMotion = beats.filter { $0 >= first && $0 <= last }
        let missed = zip(inMotion.dropFirst(), inMotion).map { max(Int((($0 - $1) / beat).rounded()) - 1, 0) }.reduce(0, +)
        let span = max(last - first, 0.001)
        let load = busy.map { min($0.1, last) - max($0.0, first) }.filter { $0 > 0 }.reduce(0, +) / span
        let longest = busy.filter { $0.1 > first && $0.0 < last }.map { $0.1 - $0.0 }.max() ?? 0
        let written = writes.isEmpty ? "なし" : writes.sorted { $0.key < $1.key }.map { "\($0.key)\($0.value)" }.joined(separator: " ")
        let points = moving.prefix(40).map { String(format: "%.0f:%.1f", ($0.0 - start) * 1000, $0.1) }.joined(separator: " ")
        append(String(format: "perf %@ %@ frames %d first %.0fms half %@ ninety %@ done %@ gap %.0fms late %d missed %d main %.0f%% longest %.0fms",
                      variant, kind, moving.count, (first - start) * 1000, reached(0.5), reached(0.9), reached(0.995),
                      gap * 1000, over, missed, load * 100, longest * 1000)
               + " body \(bodies) layouts \(layouts) writes \(written) keyboard \(keyboardNote) | \(points)")
    }

    /// Busy from each wake of the main run loop to its next sleep.
    private func watchMainThread() {
        guard observers.isEmpty else { return }
        let woke = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.afterWaiting.rawValue,
                                                      true, CFIndex.min) { _, _ in
            MainActor.assumeIsolated {
                let probe = ComposerPerfProbe.shared
                if probe.start != nil { probe.wokeAt = CACurrentMediaTime() }
            }
        }
        let sleeps = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.beforeWaiting.rawValue,
                                                        true, CFIndex.max) { _, _ in
            MainActor.assumeIsolated {
                let probe = ComposerPerfProbe.shared
                guard probe.start != nil, let woke = probe.wokeAt else { return }
                probe.busy.append((woke, CACurrentMediaTime()))
                probe.wokeAt = nil
            }
        }
        for observer in [woke, sleeps].compactMap({ $0 }) {
            CFRunLoopAddObserver(CFRunLoopGetMain(), observer, .commonModes)
            observers.append(observer)
        }
    }

    /// The lines, for the UI check to read.
    struct Readout: View {
        var body: some View {
            Color.clear.frame(width: 1, height: 1)
                .accessibilityElement()
                .accessibilityIdentifier("composer-perf")
                .accessibilityLabel(ComposerPerfProbe.shared.lines.joined(separator: " || "))
                .allowsHitTesting(false)
        }
    }
}

/// The display's beats while a motion is measured: a beat the main thread
/// was too busy to answer is a frame it could not draw.
@MainActor private final class ComposerPerfBeat: NSObject {
    private var link: CADisplayLink?
    private let onBeat: (CFTimeInterval, CFTimeInterval) -> Void

    init(onBeat: @escaping (CFTimeInterval, CFTimeInterval) -> Void) {
        self.onBeat = onBeat
        super.init()
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.preferredFrameRateRange = CAFrameRateRange(minimum: 30, maximum: 120, preferred: 120)
        link.add(to: .main, forMode: .common)
        self.link = link
    }

    func stop() {
        link?.invalidate()
        link = nil
    }

    @objc private func tick(_ link: CADisplayLink) {
        onBeat(link.timestamp, link.targetTimestamp - link.timestamp)
    }
}
