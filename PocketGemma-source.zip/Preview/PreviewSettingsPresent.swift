import SwiftUI
import UIKit

/// `--settings-present-probe` (1.1.0 (290)): how 設定's sheet came up and
/// went down, each time, for the UI check. On Hachimoto さん's iPhone (289,
/// iOS 27.2, 2026-11-16) the sheet opened from the history's gear rose
/// with its animation the first time and, after the history had been
/// closed and opened again, stood there whole in one frame, the dimming
/// behind it too; it always went down with its animation.
///
/// For each opening: what the presenter asked with (the transaction the
/// sheet's switch changed in), the transaction the sheet's own content was
/// first made in, whether UIKit's transition was animated and for how long
/// (the presented controller's transition coordinator as the sheet joins
/// the window), and where the sheet stood on screen at each display beat
/// while it rose and fell (the presentation layers, so a transition run by
/// the render server is read as drawn, however late the simulator's main
/// thread is). Lines go to tmp/settings-present.txt in the app's container,
/// on the Mac's clock, which the UI check prints beside its MENU-MARK lines.
@MainActor final class SettingsPresentProbe {
    static let shared = SettingsPresentProbe()
    static let on = PreviewProbe.on("--settings-present-probe")
    /// 289's way, for the before and after in one run: the history's own
    /// copy of the sheet, made again with each opening of the drawer.
    static let historyHost289 = PreviewProbe.on("--settings-host-289")
    /// 289's way: nothing in the sheet may animate (`disablesAnimations`)
    /// for its first 0.7 s (SettingsStill since 1.1.0 (203)).
    static let still289 = PreviewProbe.on("--settings-still-289")
    /// 289's sheet: iOS's glass under the chat's colour at 80%.
    static let glass289 = PreviewProbe.on("--settings-glass-289")

    private let file = FileManager.default.temporaryDirectory.appendingPathComponent("settings-present.txt")
    private(set) var opens = 0
    /// The content's first transaction is noted once per opening.
    private var contentNoted = -1

    func write(_ line: String) {
        guard Self.on else { return }
        // The media clock too (1.1.0 (291)), for the profile's windows.
        let stamped = String(format: "%.3f m%.4f ", Date().timeIntervalSince1970, CACurrentMediaTime()) + line + "\n"
        if let handle = try? FileHandle(forWritingTo: file) {
            handle.seekToEndOfFile()
            handle.write(Data(stamped.utf8))
            try? handle.close()
        } else {
            try? stamped.write(to: file, atomically: true, encoding: .utf8)
        }
    }

    /// The presenter's switch changed in this transaction.
    func asked(_ host: String, shown: Bool, _ transaction: Transaction) {
        guard Self.on else { return }
        if shown { opens += 1 }
        write("SETTINGS-ASKED open=\(opens) host=\(host) shown=\(shown) \(Self.describe(transaction))")
    }

    /// The sheet's content passed a transaction: the first of each opening is noted.
    func content(_ transaction: Transaction) {
        guard Self.on, contentNoted != opens else { return }
        contentNoted = opens
        write("SETTINGS-CONTENT open=\(opens) \(Self.describe(transaction))")
    }

    static func describe(_ transaction: Transaction) -> String {
        "disables=\(transaction.disablesAnimations) animation=\(transaction.animation == nil ? "none" : "some")"
            + " continuous=\(transaction.isContinuous)"
    }
}

/// Watches the sheet it is in: placed behind 設定's pages.
struct SettingsPresentWatch: UIViewRepresentable {
    func makeUIView(context: Context) -> SettingsPresentWatchView { SettingsPresentWatchView() }
    func updateUIView(_ view: SettingsPresentWatchView, context: Context) {}
}

final class SettingsPresentWatchView: UIView {
    private var link: CADisplayLink?
    private weak var sheet: UIViewController?
    private var open = 0
    /// Where the sheet stood at each beat, since it joined the window or
    /// since it began to move down.
    private var beats: [(time: CFTimeInterval, y: CGFloat)] = []
    private var phase = "rise"
    private var restY: CGFloat?
    private var stillSince: CFTimeInterval?

    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        isAccessibilityElement = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil { begin() } else { end() }
    }

    private func begin() {
        guard link == nil else { return }
        var responder: UIResponder? = self
        var controller: UIViewController?
        while let next = responder {
            if let found = next as? UIViewController { controller = found; break }
            responder = next.next
        }
        while let parent = controller?.parent { controller = parent }
        sheet = controller
        open = SettingsPresentProbe.shared.opens
        let coordinator = controller?.transitionCoordinator
        let presenting = controller?.presentingViewController.map { String(describing: type(of: $0)) } ?? "none"
        SettingsPresentProbe.shared.write("SETTINGS-PRESENT open=\(open) coordinator=\(coordinator != nil)"
            + " animated=\(coordinator?.isAnimated.description ?? "-")"
            + String(format: " duration=%.3f", coordinator?.transitionDuration ?? 0)
            + " being=\(controller?.isBeingPresented ?? false) uiAnimations=\(UIView.areAnimationsEnabled)"
            + " presenting=\(presenting)")
        phase = "rise"
        beats = []
        restY = nil
        stillSince = nil
        let link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link.add(to: .main, forMode: .common)
        self.link = link
        tick(link)
    }

    private func end() {
        if !beats.isEmpty { report(gone: true) }
        link?.invalidate()
        link = nil
    }

    /// The sheet's top on screen as drawn now: its view's presentation
    /// layer in the window's, so the container UIKit moves is counted.
    private func sheetTop() -> CGFloat? {
        guard let view = sheet?.view, let window = view.window else { return nil }
        let layer = view.layer.presentation() ?? view.layer
        let target = window.layer.presentation() ?? window.layer
        return layer.convert(layer.bounds, to: target).minY
    }

    @objc private func tick(_ link: CADisplayLink) {
        guard let y = sheetTop() else { return }
        let now = CACurrentMediaTime()
        switch phase {
        case "rise":
            beats.append((now, y))
            if let last = beats.dropLast().last, abs(last.y - y) < 0.25 {
                if stillSince == nil { stillSince = last.time }
            } else {
                stillSince = nil
            }
            if let since = stillSince, now - since > 0.35 {
                restY = y
                report(gone: false)
                phase = "rest"
                beats = []
            }
        case "rest":
            // Going down: from the first beat it has left its place.
            if let rest = restY, y - rest > 0.5 {
                phase = "fall"
                beats = [(now, rest), (now, y)]
            }
        default:
            beats.append((now, y))
        }
    }

    /// The beats of one rise or fall: how many showed the sheet between
    /// where it started and where it ended, how long that took, and the
    /// places themselves (points, milliseconds from the first beat).
    private func report(gone: Bool) {
        guard let first = beats.first, let last = beats.last else { return }
        let end = last.y
        let between = beats.filter { abs($0.y - end) > 1 && abs($0.y - first.y) > 1 }.count
        let moving = beats.filter { abs($0.y - end) > 1 }
        let span = (moving.last?.time ?? first.time) - first.time
        let list = beats.prefix(60).map { String(format: "%.0f:%.1f", ($0.time - first.time) * 1000, $0.y) }.joined(separator: ",")
        let name = phase == "fall" ? "SETTINGS-FALL" : "SETTINGS-RISE"
        SettingsPresentProbe.shared.write("\(name) open=\(open) between=\(between) beats=\(beats.count)"
            + String(format: " from=%.1f to=%.1f span=%.0fms", first.y, end, span * 1000)
            + (gone ? " (left the window)" : "") + " at=\(list)")
    }
}

/// The watch and the content's first transaction, only with the probe on.
struct SettingsPresentProbing: ViewModifier {
    func body(content: Content) -> some View {
        if SettingsPresentProbe.on {
            content
                .background {
                    SettingsPresentWatch().frame(width: 1, height: 1)
                        .allowsHitTesting(false).accessibilityHidden(true)
                }
                .transaction { SettingsPresentProbe.shared.content($0) }
        } else {
            content
        }
    }
}
