import Foundation

/// Replies with charts between prose (`--chart-sample`), and one streamed a
/// few characters at a time like the model writes it (`--chart-stream`),
/// also inside a ```markdown fence as Gemma E2B wrote it on the phone
/// (`--chart-wrapped`).
/// The numbers are samples for the layout review, not facts.
enum PreviewCharts {
    /// Upright bars, a line through twelve months and a pie with its legend.
    static let first = #"""
    主要都市の人口を比べると、東京が大きく上回ります。

    ```chart
    {"type":"bar","title":"主要都市の人口（サンプル）","unit":"万人","data":[{"label":"東京","value":1400},{"label":"横浜","value":377},{"label":"大阪","value":275},{"label":"名古屋","value":233},{"label":"札幌","value":196}]}
    ```

    気温は夏に向けて上がり、冬に向けて下がります。

    ```chart
    {"type":"line","title":"東京の月別平均気温","unit":"℃","data":[{"label":"1月","value":5.4},{"label":"2月","value":6.1},{"label":"3月","value":9.4},{"label":"4月","value":14.3},{"label":"5月","value":18.8},{"label":"6月","value":21.9},{"label":"7月","value":25.7},{"label":"8月","value":26.9},{"label":"9月","value":23.3},{"label":"10月","value":18.0},{"label":"11月","value":12.5},{"label":"12月","value":7.7}]}
    ```

    1日の24時間の使い方の例です。

    ```chart
    {"type":"pie","title":"1日の時間の使い方","unit":"時間","data":[{"label":"睡眠","value":7},{"label":"仕事","value":8},{"label":"家事","value":2},{"label":"食事","value":2},{"label":"自由時間","value":5}]}
    ```

    グラフの後の文章です。
    """#

    /// Bars on their side (more items, a long label), two series, and data
    /// that cannot be drawn, shown as its source.
    static let second = #"""
    地方別の店舗数です。

    ```chart
    {"type":"bar","title":"地方別の店舗数（サンプル）","unit":"店","data":[{"label":"北海道・東北","value":42},{"label":"関東","value":128},{"label":"中部","value":67},{"label":"近畿","value":85},{"label":"中国・四国","value":31},{"label":"九州・沖縄","value":49},{"label":"海外（アジア太平洋地域）","value":12}]}
    ```

    2年分の四半期の売上を比べます。

    ```chart
    {"type":"bar","title":"四半期の売上（サンプル）","unit":"億円","series":["2024年","2025年"],"data":[{"label":"Q1","values":[12.5,14.1]},{"label":"Q2","values":[13.2,15.8]},{"label":"Q3","values":[11.8,13.9]},{"label":"Q4","values":[15.4,17.2]}]}
    ```

    次のデータは数値が壊れています。

    ```chart
    {"type":"bar","title":"壊れたデータ","data":[{"label":"A","value":"たくさん"}]}
    ```

    表示できないデータの後の文章です。
    """#

    /// Prose, then a chart's data in pieces of about ten characters, then
    /// prose after it.
    static func chunks(wrapped: Bool) -> [String] {
        let block = #"""
        ```chart
        {"type":"bar","title":"果物の売上（サンプル）","unit":"個","data":[{"label":"りんご","value":120},{"label":"みかん","value":95},{"label":"ぶどう","value":60},{"label":"もも","value":48}]}
        ```
        """#
        let chart = wrapped ? "```markdown\n" + block + "\n```" : block
        var pieces = ["果物の売上を", "グラフにしました。", "\n\n"]
        var current = ""
        for character in chart {
            current.append(character)
            if current.count == 10 { pieces.append(current); current = "" }
        }
        if !current.isEmpty { pieces.append(current) }
        return pieces + ["\n\n", "グラフの後の", "説明です。", "りんごが", "いちばん多く", "売れています。"]
    }
}
