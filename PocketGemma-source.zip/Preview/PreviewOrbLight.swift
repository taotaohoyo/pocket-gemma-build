import Foundation

/// UI checks only: replies for the Aurora Orb's light (its motes, 1.1.0
/// (298)), at a model's pace after a wait, so the orb breathes with its
/// motes while the model thinks, leaves at the first text, and the text
/// follows once it has gone, as in 1.1.0 (296).
/// `--orb-long` a long think (8 s) and a long reply at about 55 characters
/// a second; `--orb-short` a one-line reply after 1.5 s; `--orb-quick` a
/// one-line reply whose first text comes 0.45 s after the send;
/// `--orb-stop` stopped while it thinks (4 s), as 停止する stops it, with
/// no text; `--orb-fail` failing while it thinks (4 s), with no text.
/// With `--orb-slow-motion` the orb's own time runs four times slower
/// (OrbFilm) and the model writes four times slower too, after a longer
/// wait, so a film shows the motes grown in.
enum PreviewOrbLight {
    struct Reply {
        /// The reply's text, in the pieces it comes in.
        let chunks: [String]
        /// Milliseconds between pieces, and before the first.
        let delay: Int
        let wait: Int
        /// It fails, or is stopped, after this many pieces (0: before any).
        var failsAfter: Int? = nil
        var stopsAfter: Int? = nil
    }

    static let long = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。\n\nただし、まだ誤りが多く、実用化には時間がかかると考えられています。いまは、誤りを直す技術と、少ない量子ビットでも役立つ使い方の両方が研究されています。\n\nこれからの数年で、どの分野から使われ始めるのかが注目されています。"
    static let short = "はい、できます。どうぞお使いください。"

    /// The reply the launch asked for, if any.
    static var current: Reply? {
        let on = PreviewProbe.on
        let slow = on("--orb-slow-motion") ? 4 : 1
        if on("--orb-long") { return Reply(chunks: pieces(long, size: 3), delay: 55 * slow, wait: slow > 1 ? 12000 : 8000) }
        if on("--orb-short") { return Reply(chunks: pieces(short, size: 2), delay: 70 * slow, wait: 1500) }
        if on("--orb-quick") { return Reply(chunks: pieces(short, size: 2), delay: 70 * slow, wait: 450) }
        if on("--orb-stop") { return Reply(chunks: pieces(long, size: 3), delay: 55, wait: 4000, stopsAfter: 0) }
        if on("--orb-fail") { return Reply(chunks: pieces(long, size: 3), delay: 55, wait: 4000, failsAfter: 0) }
        return nil
    }

    /// The text cut into pieces of `size` characters, as tokens come.
    private static func pieces(_ text: String, size: Int) -> [String] {
        var result: [String] = []
        var rest = Substring(text)
        while !rest.isEmpty {
            result.append(String(rest.prefix(size)))
            rest = rest.dropFirst(size)
        }
        return result
    }
}
