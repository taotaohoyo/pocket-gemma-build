import Darwin
import Foundation

/// `--stack-probe` (1.1.0 (239)): how deep the main thread's stack goes
/// while the chat opens. 1.1.0 (238) crashed at launch on the phone, whose
/// main thread has 1 MB of stack: building the composer's types took the
/// rest of it (TestFlight crash log, 2026-10-29). The simulator gives the
/// main thread 8 MB, so the UI checks opened the chat as usual. The probe
/// fills the unused stack with a pattern before the first view is made and
/// later finds the deepest word that changed; scripts/check-launch-stack.sh
/// reads the `STACK-PEAK` lines.
enum StackProbe {
    private static let pattern: UInt64 = 0x5A5A_C3C3_5A5A_C3C3
    private static var painted: (low: UInt, high: UInt)?

    /// Before the first view: everything from 64 KB below this frame down
    /// to 64 KB above the stack's end.
    static func paint() {
        let thread = pthread_self()
        let top = UInt(bitPattern: pthread_get_stackaddr_np(thread))
        let size = UInt(pthread_get_stacksize_np(thread))
        var marker = 0
        let here = withUnsafeMutablePointer(to: &marker) { UInt(bitPattern: $0) }
        let high = (here - 64 * 1024) & ~UInt(7)
        let low = (top - size + 64 * 1024) & ~UInt(7)
        guard high > low, let start = UnsafeMutablePointer<UInt64>(bitPattern: low) else { return }
        start.initialize(repeating: pattern, count: Int((high - low) / 8))
        painted = (low, high)
        report("STACK-PROBE main-thread-stack=\(size) used-at-launch=\(top - here)")
    }

    /// The deepest the main thread has gone since `paint`, in bytes below
    /// the stack's top.
    static func peak() -> UInt? {
        guard let (low, high) = painted, let words = UnsafePointer<UInt64>(bitPattern: low) else { return nil }
        let top = UInt(bitPattern: pthread_get_stackaddr_np(pthread_self()))
        let count = Int((high - low) / 8)
        var index = 0
        while index < count && words[index] == pattern { index += 1 }
        return top - (low + UInt(index) * 8)
    }

    /// The peak so far, `when` naming the moment.
    static func log(_ when: String) {
        guard let peak = peak() else { return }
        report("STACK-PEAK \(when) bytes=\(peak) kb=\(peak / 1024)")
    }

    private static func report(_ line: String) {
        FileHandle.standardError.write(Data((line + "\n").utf8))
        NSLog("%@", line)
    }
}
