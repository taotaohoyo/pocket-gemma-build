import SwiftUI
import UIKit

/// `--drawer-film <look>`: the phone's history drawer filmed frame by frame
/// (1.1.0 (272), fielua-reports Issue #11), for the UI check to make a
/// sixty-frames-a-second film of it (scripts/drawer-film.swift). The
/// simulator on the check's machine draws only now and then, so its own
/// recording skips frames the phone would show; here the drawer is stepped
/// a sixtieth of a second at a time, as the phone's display link would, and
/// each step is drawn and kept before the next. The finger is the app's
/// own: the same calls a swipe makes, at a steady pace. Frames go to
/// tmp/drawer-film/<look>-<film>/ in the app's container.
@Observable @MainActor final class DrawerFilm {
    static let shared = DrawerFilm()
    static let on = PreviewProbe.on("--drawer-film")
    /// light, dark or reduced: the films' names start with it.
    static let look: String = {
        let arguments = ProcessInfo.processInfo.arguments
        guard let index = arguments.firstIndex(of: "--drawer-film"), index + 1 < arguments.count,
              !arguments[index + 1].hasPrefix("--") else { return "light" }
        return arguments[index + 1]
    }()

    /// What the film asks of the drawer: the same calls the header button,
    /// the strip, a finger and a row make.
    struct Controls {
        let width: () -> CGFloat
        let open: () -> Void
        let close: () -> Void
        let drag: (CGFloat) -> Void
        let release: (CGFloat, CGFloat) -> Void
        let select: () -> Void
        /// Moves the drawer on by the time given; true once it rests.
        let step: (CFTimeInterval) -> Bool
    }

    /// For the UI check: "done" and the frames kept, once the films end,
    /// then each film's reach (Reach).
    private(set) var state = "filming"
    @ObservationIgnored private var frames = 0
    @ObservationIgnored private var folder: URL?
    @ObservationIgnored private var index = 0
    @ObservationIgnored private var reach = Reach()
    @ObservationIgnored private var reaches: [String] = []

    /// How far the history's scroll view, and so its blur under its title
    /// and its buttons, falls short of the screen's top, foot and leading
    /// edge over a film's frames, at its worst (1.1.0 (273), fielua-reports
    /// Issue #12): in 272 it stopped at the safe area while the drawer
    /// moved, about 70pt down and 45pt up.
    struct Reach {
        var top: CGFloat = 0, foot: CGFloat = 0, leading: CGFloat = 0, frames = 0
        mutating func add(_ seen: CGRect, in screen: CGRect) {
            top = max(top, seen.minY - screen.minY)
            foot = max(foot, screen.maxY - seen.maxY)
            leading = max(leading, seen.minX - screen.minX)
            frames += 1
        }
        var line: String { String(format: "top %.1f foot %.1f leading %.1f frames %ld", top, foot, leading, frames) }
    }
    private static let frameTime: CFTimeInterval = 1.0 / 60

    func run(_ controls: Controls) async {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("drawer-film", isDirectory: true)
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        // The launch settles first (the startup's own motion, the chat).
        try? await Task.sleep(for: .seconds(2.5))
        let width = controls.width()
        var films: [(String, () async -> Void)] = [
            ("open", {
                await self.still(4)
                controls.open()
                await self.settle(controls)
            }),
            ("close", {
                await self.still(4)
                controls.close()
                await self.settle(controls)
            }),
        ]
        if Self.look == "light" {
            films += [
                // A finger takes it a little past half way at a steady pace
                // and lets go moving: it carries on open.
                ("swipe-open", {
                    await self.still(2)
                    for step in 1...18 {
                        controls.drag(width * 0.55 * CGFloat(step) / 18)
                        _ = await self.tick(controls)
                    }
                    controls.release(width * 0.55, 600)
                    await self.settle(controls)
                }),
                ("swipe-close", {
                    await self.still(2)
                    for step in 1...14 {
                        controls.drag(-width * 0.4 * CGFloat(step) / 14)
                        _ = await self.tick(controls)
                    }
                    controls.release(-width * 0.4, -700)
                    await self.settle(controls)
                }),
                // Opening, caught by a finger on the way and taken back.
                ("catch-reverse", {
                    await self.still(2)
                    controls.open()
                    for _ in 0..<10 { _ = await self.tick(controls) }
                    for step in 0...10 {
                        controls.drag(-width * 0.25 * CGFloat(step) / 10)
                        _ = await self.tick(controls)
                    }
                    controls.release(-width * 0.25, -500)
                    await self.settle(controls)
                }),
                // Taps one after another: open, close on the way, open again.
                ("rapid", {
                    await self.still(2)
                    controls.open()
                    for _ in 0..<8 { _ = await self.tick(controls) }
                    controls.close()
                    for _ in 0..<8 { _ = await self.tick(controls) }
                    controls.open()
                    await self.settle(controls)
                    controls.close()
                    await self.settle(controls)
                }),
                // A long chat chosen from the history: it closes over it.
                ("select", {
                    controls.open()
                    await self.settle(controls, film: false)
                    await self.still(4)
                    controls.select()
                    await self.settle(controls)
                }),
            ]
        }
        for (name, film) in films {
            let folder = root.appendingPathComponent("\(Self.look)-\(name)", isDirectory: true)
            try? FileManager.default.removeItem(at: folder)
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            self.folder = folder
            index = 0
            reach = Reach()
            await film()
            self.folder = nil
            reaches.append("\(name) \(reach.line)")
            try? await Task.sleep(for: .milliseconds(300))
        }
        state = (["done \(frames)"] + reaches).joined(separator: " | ")
    }

    /// One frame of the drawer: moved on a sixtieth of a second and drawn.
    private func tick(_ controls: Controls, film: Bool = true) async -> Bool {
        let resting = controls.step(Self.frameTime)
        if film { await shoot() } else { try? await Task.sleep(for: .milliseconds(20)) }
        return resting
    }

    /// Until it has rested for a few frames (at most three seconds).
    private func settle(_ controls: Controls, film: Bool = true) async {
        var still = 0
        for _ in 0..<180 {
            if await tick(controls, film: film) { still += 1 } else { still = 0 }
            if still >= 6 { return }
        }
    }

    /// Frames with nothing moving, before a film's move.
    private func still(_ count: Int) async {
        for _ in 0..<count { await shoot() }
    }

    private func shoot() async {
        // The step's state is drawn in the next update.
        try? await Task.sleep(for: .milliseconds(30))
        guard let folder,
              let window = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .flatMap(\.windows)
                .first(where: \.isKeyWindow) else { return }
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1.5
        format.opaque = true
        let image = UIGraphicsImageRenderer(size: window.bounds.size, format: format).image { _ in
            _ = window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
        }
        let url = folder.appendingPathComponent(String(format: "%04ld.jpg", index))
        try? image.jpegData(compressionQuality: 0.85)?.write(to: url)
        if let seen = Self.historyScroll(in: window) { reach.add(seen, in: window.bounds) }
        index += 1
        frames += 1
    }

    /// The history's scroll view where the screen shows it, its size at the
    /// back included: the tall one on the screen's leading half, narrower
    /// than the screen (the conversation's is the screen's width).
    private static func historyScroll(in window: UIWindow) -> CGRect? {
        var found: CGRect?
        func visit(_ view: UIView) {
            guard !view.isHidden else { return }
            if let scroll = view as? UIScrollView, !(scroll is UITextView) {
                let seen = scroll.convert(scroll.bounds, to: window)
                if seen.height > window.bounds.height / 2, seen.width < window.bounds.width * 0.95,
                   seen.midX < window.bounds.midX, seen.height > (found?.height ?? 0) { found = seen }
            }
            view.subviews.forEach(visit)
        }
        visit(window)
        return found
    }
}

/// `--history-scrolled`: the history's list starts a little way down, a
/// chat under its title's blur as others are under its buttons' (1.1.0
/// (273), fielua-reports Issue #12, as on Hachimoto さん's phone).
struct PreviewHistoryScroll: ViewModifier {
    static let on = PreviewProbe.on("--history-scrolled")
    @State private var position = ScrollPosition(edge: .top)
    func body(content: Content) -> some View {
        if Self.on {
            content
                .scrollPosition($position)
                .onAppear { position.scrollTo(y: 70) }
        } else {
            content
        }
    }
}

/// The film's state, for the UI check to wait on.
struct DrawerFilmReadout: View {
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("drawer-film")
            .accessibilityLabel(DrawerFilm.shared.state)
            .allowsHitTesting(false)
    }
}
