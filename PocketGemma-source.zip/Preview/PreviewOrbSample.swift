import Foundation

/// UI checks only: the screens for the Aurora Orb's design sample (the
/// user's directive of 2026-11-19: a moving sample is made and approved
/// before any new orb motion is built). `--orb-sample` a reply whose first
/// text comes 6 s after the send, at about 55 characters a second, that
/// then stays in writing for 20 s with all its text on screen;
/// `--orb-plate` draws nothing where the orb is (its place kept), so the
/// sample's own light can be laid over the real screen.
enum PreviewOrbSample {
    struct Reply {
        /// The reply's text, in the pieces it comes in.
        let chunks: [String]
        /// Milliseconds between pieces, before the first, and in writing
        /// after the last.
        let delay: Int
        let wait: Int
        let hold: Int
    }

    static let text = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。\n\nただし、まだ誤りが多く、実用化には時間がかかると考えられています。"

    static var current: Reply? {
        guard PreviewProbe.on("--orb-sample") else { return nil }
        // The reply light's checks (2026-11-19): a quick reply, a long
        // think, a long text, and the sample's own text sooner.
        let quick = PreviewProbe.on("--orb-quick")
        let long = PreviewProbe.on("--orb-long-text")
        let body = quick ? "はい、できます。" : long ? ([text] + Array(repeating: more, count: 3)).joined(separator: "\n\n")
            : PreviewProbe.on("--orb-markdown") ? markdown : text
        var pieces: [String] = []
        var rest = Substring(body)
        while !rest.isEmpty {
            pieces.append(String(rest.prefix(3)))
            rest = rest.dropFirst(3)
        }
        let wait = quick ? 400 : PreviewProbe.on("--orb-long-think") ? 12000 : PreviewProbe.on("--orb-soon") ? 3000 : 6000
        let hold = PreviewProbe.on("--orb-hold-short") ? 1500 : 20000
        return Reply(chunks: pieces, delay: 55, wait: wait, hold: hold)
    }

    /// A reply with a heading, emphasis, a list, inline code, a code block
    /// and line breaks inside a paragraph, for the writing light (1.1.0
    /// (300), `--orb-markdown`).
    static let markdown = "## 量子コンピュータのしくみ\n\n量子コンピュータは、**量子ビット**を使って計算します。\n\n"
        + "- 重ね合わせ：0と1を同時に持てます\n- もつれ：離れた量子ビットが結びつきます\n\n"
        + "```swift\nlet qubit = Qubit()\nqubit.apply(.hadamard)\n```\n\n"
        + "ふつうのコンピュータとは、`ビット`の扱い方が違います。\n改行のあとも、\n同じ光で書き続けます。"

    /// The long text's further paragraphs.
    static let more = "量子ビットは、0と1を同時に重ね合わせた状態を持てます。この性質を使うと、ある種の問題では、いまのコンピュータよりずっと少ない手順で答えに近づけます。ただ、量子の状態はとても壊れやすく、周りの熱や振動でもすぐに乱れてしまいます。そのため、装置を極低温に冷やしたり、誤りを見つけて直す仕組みを重ねたりする研究が続いています。"

    /// The stage the sample's reply waits in (ChatStore.status), and a
    /// long think's second stage after 4 s (`--orb-long-think`).
    static let firstStage = "返信を考えています…"
    static let laterStage: (after: Int, status: String)? = PreviewProbe.on("--orb-long-think") ? (4000, "じっくり考えています…") : nil
    /// The reply fails as its first text was due (`--orb-fail`); it is
    /// stopped half-way through the wait (`--orb-stop-thinking`) or 1.2 s
    /// into its writing (`--orb-stop-writing`).
    static let fails = PreviewProbe.on("--orb-fail")
    static let stopThinking = PreviewProbe.on("--orb-stop-thinking")
    static let stopWriting = PreviewProbe.on("--orb-stop-writing")

    static let plate = PreviewProbe.on("--orb-plate")
}
