import Foundation

/// UI checks only: the screens for the Aurora Orb's design sample (the
/// user's directive of 2026-11-19: a moving sample is made and approved
/// before any new orb motion is built). `--orb-sample` a reply whose first
/// text comes 6 s after the send, at about 55 characters a second, that
/// then stays in writing for 20 s with all its text on screen;
/// `--orb-plate` draws nothing where the orb is (its place kept), so the
/// sample's own light can be laid over the real screen.
enum PreviewOrbSample {
    struct Reply {
        /// The reply's text, in the pieces it comes in.
        let chunks: [String]
        /// Milliseconds between pieces, before the first, and in writing
        /// after the last.
        let delay: Int
        let wait: Int
        let hold: Int
    }

    static let text = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。\n\nただし、まだ誤りが多く、実用化には時間がかかると考えられています。"

    static var current: Reply? {
        guard PreviewProbe.on("--orb-sample") else { return nil }
        var pieces: [String] = []
        var rest = Substring(text)
        while !rest.isEmpty {
            pieces.append(String(rest.prefix(3)))
            rest = rest.dropFirst(3)
        }
        return Reply(chunks: pieces, delay: 55, wait: 6000, hold: 20000)
    }

    static let plate = PreviewProbe.on("--orb-plate")
}
