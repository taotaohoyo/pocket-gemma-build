import Foundation

// Synthetic resources belong only to the simulator preview target. The
// production app does not compile these import shortcuts or test fixtures.
enum PreviewAttachments {
    static let names = ["sample-image", "sample-video", "sample-document", "sample-text", "sample-sjis", "sample-utf16", "sample-word", "sample-scan", "sample-oversize", "sample-unsupported", "sample-markdown", "sample-data"]
    static let extensions = ["png", "mp4", "pdf", "txt", "txt", "txt", "docx", "pdf", "docx", "bin", "md", "json"]
    static func url(_ name: String) -> URL? {
        guard let index = names.firstIndex(of: name) else { return nil }
        return Bundle.main.url(forResource: name, withExtension: extensions[index])
    }
    static var archive: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("fixture-chats.json")
    }
}
