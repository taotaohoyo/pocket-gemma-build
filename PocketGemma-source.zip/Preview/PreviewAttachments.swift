import UIKit

// Synthetic resources belong only to the simulator preview target. The
// production app does not compile these import shortcuts or test fixtures.
enum PreviewAttachments {
    static let names = ["sample-image", "sample-video", "sample-document", "sample-text", "sample-sjis", "sample-utf16", "sample-word", "sample-scan", "sample-oversize", "sample-unsupported", "sample-markdown", "sample-data", "sample-photo-text"]
    static let extensions = ["png", "mp4", "pdf", "txt", "txt", "txt", "docx", "pdf", "docx", "bin", "md", "json", "png"]
    static func url(_ name: String) -> URL? {
        guard let index = names.firstIndex(of: name) else { return nil }
        if name == "sample-photo-text" { return photoWithText() }
        return Bundle.main.url(forResource: name, withExtension: extensions[index])
    }
    /// A photo with printed text, drawn here so the on-device text
    /// recognition reads Japanese with the simulator's own fonts.
    private static func photoWithText() -> URL? {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("sample-photo-text.png")
        let image = UIGraphicsImageRenderer(size: CGSize(width: 1000, height: 600)).image { context in
            UIColor(white: 0.96, alpha: 1).setFill(); context.fill(CGRect(x: 0, y: 0, width: 1000, height: 600))
            let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 72, weight: .bold),
                                                              .foregroundColor: UIColor.black]
            ("会議は木曜日の10時" as NSString).draw(at: CGPoint(x: 80, y: 160), withAttributes: attributes)
            ("ROOM 4721" as NSString).draw(at: CGPoint(x: 80, y: 320), withAttributes: attributes)
        }
        guard let data = image.pngData(), (try? data.write(to: url, options: .atomic)) != nil else { return nil }
        return url
    }
    static var archive: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("fixture-chats.json")
    }
}
