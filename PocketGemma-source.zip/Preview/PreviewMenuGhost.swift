import SwiftUI
import UIKit

/// `--menu-ghost`: what the screen holds where スタンダード's model pill
/// stands, layer by layer, for the UI check (1.1.0 (277), fielua-reports
/// Issue #15). On Hachimoto さん's iPhone (iOS 27.2, 2026-11-14) the pill's
/// glass and its 「E2B」 stayed whole in the closing bar for 0.3–0.5 s after
/// the model menu had been opened and closed, then went at once; without
/// the menu they faded. Each time the keyboard starts down or up, the
/// layers there are noted every 40 ms for 0.7 s, and otherwise four times
/// a second when they change: the pill's glass and text, a portal or the
/// menu's morph there, each where it is as drawn (mid-animation) and the
/// opacity it is drawn with after all its ancestors' (describe); and
/// anywhere on screen, whether the menu's morph and platter are there.
/// Lines go to tmp/menu-ghost.txt in the app's container, with the Mac's
/// clock, which the UI check prints beside its MENU-MARK lines; an
/// accessibility label would be read with every query of the check.
/// The chat adds its own events (the bar, the field's keys, the pill menus
/// renewed: `event`).
@MainActor final class MenuGhostProbe {
    static let shared = MenuGhostProbe()
    static let on = PreviewProbe.on("--menu-ghost")

    /// The model pill as laid out (ChatView.modelMenu), in the window.
    var pill: CGRect = .zero {
        didSet {
            guard pill.width > 0, pill != oldValue else { return }
            pills.append(pill); if pills.count > 6 { pills.removeFirst() }
            write("pill \(Self.rect(pill))")
        }
    }
    private var pills: [CGRect] = []
    private var observers: [NSObjectProtocol] = []
    private var ticker: Timer?
    private var films = 0
    private var last = ""
    private let file = FileManager.default.temporaryDirectory.appendingPathComponent("menu-ghost.txt")

    func start() {
        guard Self.on, observers.isEmpty else { return }
        write("launch " + ProcessInfo.processInfo.arguments.dropFirst().joined(separator: " "))
        let center = NotificationCenter.default
        for (name, event) in [(UIResponder.keyboardWillHideNotification, "kb-hide"),
                              (UIResponder.keyboardWillShowNotification, "kb-show")] {
            observers.append(center.addObserver(forName: name, object: nil, queue: .main) { _ in
                MainActor.assumeIsolated { MenuGhostProbe.shared.film(event) }
            })
        }
        ticker = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { _ in
            MainActor.assumeIsolated { MenuGhostProbe.shared.note("tick", onlyChanges: true) }
        }
    }

    /// Something the chat did (the bar opened or closed, the field's keys,
    /// the pill menus renewed), on its own line.
    func event(_ what: String) {
        guard Self.on else { return }
        write("event \(what)")
    }

    private var filmed: [String: CFTimeInterval] = [:]

    private func film(_ event: String) {
        // The simulator, and a menu over the keyboard, repeat the notices:
        // one film at a time for each.
        let now = CACurrentMediaTime()
        if let last = filmed[event], now - last < 0.8 { return }
        filmed[event] = now
        films += 1
        let tag = "\(event)-\(films)", start = now
        for ms in stride(from: 0, through: 720, by: 40) {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(ms) / 1000) {
                MainActor.assumeIsolated {
                    let at = Int(((CACurrentMediaTime() - start) * 1000).rounded())
                    MenuGhostProbe.shared.note("\(tag) +\(at)ms", onlyChanges: false)
                }
            }
        }
    }

    private func note(_ tag: String, onlyChanges: Bool) {
        guard pill.width > 0 else { return }
        let began = CACurrentMediaTime()
        let seen = describe()
        if onlyChanges && seen == last { return }
        last = seen
        write("\(tag) took=\(Int(((CACurrentMediaTime() - began) * 1000).rounded()))ms \(seen)")
    }

    private func write(_ line: String) {
        let text = String(format: "%.3f ", Date().timeIntervalSince1970) + line + "\n"
        guard let data = text.data(using: .utf8) else { return }
        if let handle = try? FileHandle(forWritingTo: file) {
            handle.seekToEndOfFile(); handle.write(data); try? handle.close()
        } else {
            try? data.write(to: file)
        }
    }

    /// Where a ghost could be: every place the pill has stood lately (the
    /// opened panel's row and the bar's line), and between them.
    private var area: CGRect {
        guard var all = pills.first else { return .zero }
        for p in pills { all = all.union(p) }
        return all.insetBy(dx: -10, dy: -10)
    }

    private static func name(_ object: AnyObject?) -> String {
        guard let object else { return "-" }
        return String(describing: type(of: object))
    }
    private static func rect(_ r: CGRect) -> String {
        String(format: "%.0f,%.0f,%.0fx%.0f", r.minX, r.minY, r.width, r.height)
    }
    private static func seen(_ r: CGRect, _ e: Float, _ inMenu: Bool) -> String {
        (inMenu ? "*" : "") + rect(r) + String(format: " %.2f", e)
    }
    private static let menuWords = ["ContextMenu", "Portal", "Platter", "Morph", "MenuView", "Matched"]

    /// One line: the pill's glass (g), its text (t), a portal showing it
    /// (P), the morph's views (m), each where it is drawn and the opacity
    /// it is drawn with (* when inside the menu's morph); whether the
    /// menu's morph is there (morph=…) and its platter; other layers there.
    private func describe() -> String {
        let windows = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap(\.windows)
        let area = area
        let pillWidth = pills.map(\.width).max() ?? 80, pillHeight = pills.map(\.height).max() ?? 36
        var glass: [String] = [], text: [String] = [], portals: [String] = [], magic: [String] = []
        var others: Set<String> = [], morph: [String] = [], platters: [String] = []
        for window in windows where !window.isHidden {
            let root = window.layer.presentation() ?? window.layer
            func visit(_ model: CALayer, _ inherited: Float, _ inMenu: Bool) {
                let layer = model.presentation() ?? model
                let effective = model.isHidden ? 0 : inherited * layer.opacity
                let seen = layer.convert(layer.bounds, to: root)
                let kind = Self.name(model), view = Self.name(model.delegate)
                let menuish = Self.menuWords.contains { kind.contains($0) || view.contains($0) }
                let inMenu = inMenu || view.contains("MorphAnimationContainer") || view.contains("ContextMenu")
                if effective > 0.01 {
                    if view.contains("MorphAnimationContainer") { morph.append(Self.seen(seen, effective, false)) }
                    if (view.contains("Platter") || view.contains("ContextMenuView")) && platters.count < 3 {
                        platters.append(view + " " + Self.seen(seen, effective, false))
                    }
                }
                if effective > 0.03, seen.intersects(area), seen.width >= 6, seen.height >= 6,
                   seen.width <= pillWidth + 70, seen.height <= pillHeight + 40 {
                    let entry = Self.seen(seen, effective, inMenu)
                    if kind == "SDFLayer" && view == "_UIInheritedView" { glass.append(entry) }
                    else if kind == "CGDrawingLayer" { text.append(entry) }
                    else if kind == "CAPortalLayer" { portals.append(entry) }
                    else if view.hasPrefix("_UIMagicMorph") { if magic.count < 4 { magic.append(String(view.dropFirst(13)) + " " + entry) } }
                    else if layer.contents != nil || (layer.backgroundColor?.alpha ?? 0) > 0.01 || menuish,
                            !["CABackdropLayer", "SDFPortalLayer", "SDFLayer", "CASDFLayer"].contains(kind) {
                        others.insert("\(view)/\(kind)")
                    }
                }
                guard effective > 0.001 else { return }
                for sub in model.sublayers ?? [] { visit(sub, effective, inMenu) }
            }
            visit(window.layer, 1, false)
        }
        func list(_ items: [String]) -> String { "[" + items.prefix(4).joined(separator: "; ") + "]" }
        return "g=\(list(glass)) t=\(list(text)) P=\(list(portals)) m=\(list(magic))"
            + " morph=\(morph.isEmpty ? "no" : "yes") platter=\(list(platters))"
            + (others.isEmpty ? "" : " other=\(list(others.sorted()))")
    }
}

/// Starts the probe with the chat; draws nothing.
struct MenuGhostReadout: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        MenuGhostProbe.shared.start()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        view.isUserInteractionEnabled = false
        view.isAccessibilityElement = false
        return view
    }
    func updateUIView(_ view: UIView, context: Context) {}
}
