import SwiftUI
import UIKit

/// `--menu-ghost`: what the screen holds where スタンダード's model pill
/// stands, layer by layer, for the UI check (1.1.0 (277), fielua-reports
/// Issue #15). On Hachimoto さん's iPhone (iOS 27.2, 2026-11-14) the pill's
/// glass and its 「E2B」 stayed whole in the closing bar for 0.3–0.5 s after
/// the model menu had been opened and closed, then went at once; without
/// the menu they faded. Each time the keyboard starts down or up, the
/// layers there are noted every 40 ms for 0.7 s, and otherwise four times
/// a second when they change: the pill's glass and text, a portal or the
/// menu's morph there, each where it is as drawn (mid-animation) and the
/// opacity it is drawn with after all its ancestors' (describe); and
/// anywhere on screen, whether the menu's morph and platter are there.
/// Lines go to tmp/menu-ghost.txt in the app's container, with the Mac's
/// clock, which the UI check prints beside its MENU-MARK lines; an
/// accessibility label would be read with every query of the check.
/// The chat adds its own events (the bar, the field's keys, the pill menus
/// renewed: `event`).
///
/// `--keys-in-menu-close` (1.1.0 (287), Issue #15 back in 286): the
/// keyboard sent away by the app itself, as a tap on the chat does
/// (`keysAway`, the chat's conversationTapped), 0.25 s after the model
/// menu has gone, while its glass is still closing into the pill and iOS
/// still shows the pill through its copy. On Hachimoto さん's iPhone the
/// tap came about 0.6 s after the menu's close; the UI check's taps wait
/// for the app to settle, which is after that copy has gone, so they
/// cannot. The first two closes only; later ones leave the keyboard up.
/// Each film then counts the model pill's glass layers in the chat,
/// hidden ones too (pills=): the old pills taken out at once leave one;
/// kept until the close's spring ends (281–286), two.
@MainActor final class MenuGhostProbe {
    static let shared = MenuGhostProbe()
    static let on = PreviewProbe.on("--menu-ghost")
    static let keysInMenuClose = PreviewProbe.on("--keys-in-menu-close")
    /// Which way and look this launch is, for the marks' names.
    private static let variant = (PreviewProbe.on("--pill-renew-281") ? "286" : "287") + (PreviewProbe.on("--dark") ? "-dark" : "")
    /// Set by the chat: lets the keys go as a tap on the chat does.
    var keysAway: (() -> Void)?
    private var watch: Timer?
    private var menuSeen = false
    private var keysSent = 0
    /// Per film: the most pill glasses seen, and the last time two were.
    private var filmPills: [String: (most: Int, twoAt: Int)] = [:]

    /// The model pill as laid out (ChatView.modelMenu), in the window.
    var pill: CGRect = .zero {
        didSet {
            guard pill.width > 0, pill != oldValue else { return }
            pills.append(pill); if pills.count > 6 { pills.removeFirst() }
            write("pill \(Self.rect(pill))")
        }
    }
    private var pills: [CGRect] = []
    private var observers: [NSObjectProtocol] = []
    private var ticker: Timer?
    private var films = 0
    private var last = ""
    private let file = FileManager.default.temporaryDirectory.appendingPathComponent("menu-ghost.txt")

    func start() {
        guard Self.on, observers.isEmpty else { return }
        write("launch " + ProcessInfo.processInfo.arguments.dropFirst().joined(separator: " "))
        let center = NotificationCenter.default
        for (name, event) in [(UIResponder.keyboardWillHideNotification, "kb-hide"),
                              (UIResponder.keyboardWillShowNotification, "kb-show")] {
            observers.append(center.addObserver(forName: name, object: nil, queue: .main) { _ in
                MainActor.assumeIsolated { MenuGhostProbe.shared.film(event) }
            })
        }
        ticker = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { _ in
            MainActor.assumeIsolated { MenuGhostProbe.shared.note("tick", onlyChanges: true) }
        }
        if Self.keysInMenuClose {
            watch = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { _ in
                MainActor.assumeIsolated { MenuGhostProbe.shared.watchMenu() }
            }
        }
    }

    /// Whether the menu itself is on screen, and its morph (the glass
    /// closing into the pill, with the pill's copy) still there.
    private func menuViews() -> (menu: Bool, morph: Bool) {
        var menu = false, morph = false
        func visit(_ view: UIView, _ inherited: Float) {
            let opacity = view.isHidden ? 0 : inherited * (view.layer.presentation()?.opacity ?? view.layer.opacity)
            let name = Self.name(view)
            if name.contains("MorphAnimationContainer") { morph = true }
            if name == "_UIContextMenuView", opacity > 0.05 { menu = true }
            for sub in view.subviews { visit(sub, opacity) }
        }
        for window in UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).flatMap(\.windows)
            where !window.isHidden { visit(window, 1) }
        return (menu, morph)
    }

    /// `--keys-in-menu-close`: once the menu has gone, the keys sent away
    /// 0.25 s later, with a mark for the UI check's frames.
    private func watchMenu() {
        let seen = menuViews()
        if seen.menu {
            if !menuSeen { menuSeen = true; event("menu shows") }
            return
        }
        guard menuSeen else { return }
        menuSeen = false
        event("menu gone, its morph \(seen.morph ? "still closing" : "ended")")
        guard keysSent < 2 else { return }
        keysSent += 1
        let n = keysSent
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            MainActor.assumeIsolated {
                let probe = MenuGhostProbe.shared
                let morph = probe.menuViews().morph
                probe.write("MENU-MARK keys-away-\(Self.variant)-\(n) " + String(format: "%.3f", Date().timeIntervalSince1970))
                probe.event("keys away \(n), the menu's morph \(morph ? "still closing (its copy of the pill there)" : "ended")")
                probe.keysAway?()
            }
        }
    }

    /// The model pill's glass layers in the chat, hidden ones too, outside
    /// the menu's own views: one pill, or the old one still there too.
    private func pillGlasses() -> [String] {
        let windows = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap(\.windows)
        var found: [String] = []
        for window in windows where !window.isHidden {
            let root = window.layer
            func visit(_ model: CALayer, _ inherited: Float, _ hidden: Bool) {
                let view = Self.name(model.delegate)
                if view.contains("MorphAnimationContainer") || view.contains("ContextMenu") { return }
                let layer = model.presentation() ?? model
                let effective = inherited * layer.opacity
                let isHidden = hidden || model.isHidden
                if Self.name(model) == "SDFLayer" && view == "_UIInheritedView" {
                    let seen = layer.convert(layer.bounds, to: root.presentation() ?? root)
                    if seen.width >= 50, seen.width <= 110, seen.height >= 28, seen.height <= 44 {
                        found.append(Self.rect(seen) + String(format: " %.2f", isHidden ? 0 : effective) + (isHidden ? "h" : ""))
                    }
                }
                for sub in model.sublayers ?? [] { visit(sub, effective, isHidden) }
            }
            visit(root, 1, false)
        }
        return found
    }

    /// Something the chat did (the bar opened or closed, the field's keys,
    /// the pill menus renewed), on its own line.
    func event(_ what: String) {
        guard Self.on else { return }
        write("event \(what)")
    }

    private var filmed: [String: CFTimeInterval] = [:]

    private func film(_ event: String) {
        // The simulator, and a menu over the keyboard, repeat the notices:
        // one film at a time for each.
        let now = CACurrentMediaTime()
        if let last = filmed[event], now - last < 0.8 { return }
        filmed[event] = now
        films += 1
        let tag = "\(event)-\(films)", start = now
        for ms in stride(from: 0, through: 720, by: 40) {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(ms) / 1000) {
                MainActor.assumeIsolated {
                    let at = Int(((CACurrentMediaTime() - start) * 1000).rounded())
                    let probe = MenuGhostProbe.shared
                    probe.note("\(tag) +\(at)ms", onlyChanges: false)
                    guard Self.keysInMenuClose else { return }
                    // The pills there now: one, or the old ones not yet gone.
                    let pills = probe.pillGlasses()
                    probe.write("PILLS \(tag) +\(at)ms n=\(pills.count) [" + pills.joined(separator: "; ") + "]")
                    var seen = probe.filmPills[tag] ?? (most: 0, twoAt: -1)
                    seen.most = max(seen.most, pills.count)
                    if pills.count >= 2 { seen.twoAt = at }
                    probe.filmPills[tag] = seen
                    if ms == 720 {
                        probe.write("VERDICT \(tag) most=\(seen.most) two-until=" + (seen.twoAt < 0 ? "never" : "+\(seen.twoAt)ms"))
                    }
                }
            }
        }
    }

    private func note(_ tag: String, onlyChanges: Bool) {
        guard pill.width > 0 else { return }
        let began = CACurrentMediaTime()
        let seen = describe()
        if onlyChanges && seen == last { return }
        last = seen
        write("\(tag) took=\(Int(((CACurrentMediaTime() - began) * 1000).rounded()))ms \(seen)")
    }

    private func write(_ line: String) {
        let text = String(format: "%.3f ", Date().timeIntervalSince1970) + line + "\n"
        guard let data = text.data(using: .utf8) else { return }
        if let handle = try? FileHandle(forWritingTo: file) {
            handle.seekToEndOfFile(); handle.write(data); try? handle.close()
        } else {
            try? data.write(to: file)
        }
    }

    /// Where a ghost could be: every place the pill has stood lately (the
    /// opened panel's row and the bar's line), and between them.
    private var area: CGRect {
        guard var all = pills.first else { return .zero }
        for p in pills { all = all.union(p) }
        return all.insetBy(dx: -10, dy: -10)
    }

    private static func name(_ object: AnyObject?) -> String {
        guard let object else { return "-" }
        return String(describing: type(of: object))
    }
    private static func rect(_ r: CGRect) -> String {
        String(format: "%.0f,%.0f,%.0fx%.0f", r.minX, r.minY, r.width, r.height)
    }
    private static func seen(_ r: CGRect, _ e: Float, _ inMenu: Bool) -> String {
        (inMenu ? "*" : "") + rect(r) + String(format: " %.2f", e)
    }
    private static let menuWords = ["ContextMenu", "Portal", "Platter", "Morph", "MenuView", "Matched"]

    /// One line: the pill's glass (g), its text (t), a portal showing it
    /// (P), the morph's views (m), each where it is drawn and the opacity
    /// it is drawn with (* when inside the menu's morph); whether the
    /// menu's morph is there (morph=…) and its platter; other layers there.
    private func describe() -> String {
        let windows = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap(\.windows)
        let area = area
        let pillWidth = pills.map(\.width).max() ?? 80, pillHeight = pills.map(\.height).max() ?? 36
        var glass: [String] = [], text: [String] = [], portals: [String] = [], magic: [String] = []
        var others: Set<String> = [], morph: [String] = [], platters: [String] = []
        for window in windows where !window.isHidden {
            let root = window.layer.presentation() ?? window.layer
            func visit(_ model: CALayer, _ inherited: Float, _ inMenu: Bool) {
                let layer = model.presentation() ?? model
                let effective = model.isHidden ? 0 : inherited * layer.opacity
                let seen = layer.convert(layer.bounds, to: root)
                let kind = Self.name(model), view = Self.name(model.delegate)
                let menuish = Self.menuWords.contains { kind.contains($0) || view.contains($0) }
                let inMenu = inMenu || view.contains("MorphAnimationContainer") || view.contains("ContextMenu")
                if effective > 0.01 {
                    if view.contains("MorphAnimationContainer") { morph.append(Self.seen(seen, effective, false)) }
                    if (view.contains("Platter") || view.contains("ContextMenuView")) && platters.count < 3 {
                        platters.append(view + " " + Self.seen(seen, effective, false))
                    }
                }
                if effective > 0.03, seen.intersects(area), seen.width >= 6, seen.height >= 6,
                   seen.width <= pillWidth + 70, seen.height <= pillHeight + 40 {
                    let entry = Self.seen(seen, effective, inMenu)
                    if kind == "SDFLayer" && view == "_UIInheritedView" { glass.append(entry) }
                    else if kind == "CGDrawingLayer" { text.append(entry) }
                    else if kind == "CAPortalLayer" { portals.append(entry) }
                    else if view.hasPrefix("_UIMagicMorph") { if magic.count < 4 { magic.append(String(view.dropFirst(13)) + " " + entry) } }
                    else if layer.contents != nil || (layer.backgroundColor?.alpha ?? 0) > 0.01 || menuish,
                            !["CABackdropLayer", "SDFPortalLayer", "SDFLayer", "CASDFLayer"].contains(kind) {
                        others.insert("\(view)/\(kind)")
                    }
                }
                guard effective > 0.001 else { return }
                for sub in model.sublayers ?? [] { visit(sub, effective, inMenu) }
            }
            visit(window.layer, 1, false)
        }
        func list(_ items: [String]) -> String { "[" + items.prefix(4).joined(separator: "; ") + "]" }
        return "g=\(list(glass)) t=\(list(text)) P=\(list(portals)) m=\(list(magic))"
            + " morph=\(morph.isEmpty ? "no" : "yes") platter=\(list(platters))"
            + (others.isEmpty ? "" : " other=\(list(others.sorted()))")
    }
}

/// Starts the probe with the chat; draws nothing.
struct MenuGhostReadout: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        MenuGhostProbe.shared.start()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        view.isUserInteractionEnabled = false
        view.isAccessibilityElement = false
        return view
    }
    func updateUIView(_ view: UIView, context: Context) {}
}
