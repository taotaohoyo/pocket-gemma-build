import SwiftUI
import UIKit

/// `--menu-ghost`: what the screen holds where スタンダード's model pill
/// stands, layer by layer, for the UI check (1.1.0 (277), fielua-reports
/// Issue #15). On Hachimoto さん's iPhone (iOS 27.2, 2026-11-14) the pill's
/// glass and its 「E2B」 stayed whole in the closing bar for 0.3–0.5 s after
/// the model menu had been opened and closed, then went at once; without
/// the menu they faded. Each time the keyboard starts down or up, the
/// layers there are noted every 40 ms for 0.7 s, and otherwise four times
/// a second when they change: their class and their view's, where they
/// are as drawn (mid-animation), their own opacity and the opacity they
/// are drawn with after all their ancestors', and their animations; and
/// anywhere on screen, the views of a context menu, a portal or a platter.
/// Lines go to tmp/menu-ghost.txt in the app's container, with the Mac's
/// clock, which the UI check prints beside its MENU-MARK lines; an
/// accessibility label would be read with every query of the check.
@MainActor final class MenuGhostProbe {
    static let shared = MenuGhostProbe()
    static let on = PreviewProbe.on("--menu-ghost")

    /// The model pill as laid out (ChatView.modelMenu), in the window.
    var pill: CGRect = .zero {
        didSet {
            guard pill.width > 0, pill != oldValue else { return }
            pills.append(pill); if pills.count > 6 { pills.removeFirst() }
            write("pill \(Self.rect(pill))")
        }
    }
    private var pills: [CGRect] = []
    private var observers: [NSObjectProtocol] = []
    private var ticker: Timer?
    private var films = 0
    private var last = ""
    private let file = FileManager.default.temporaryDirectory.appendingPathComponent("menu-ghost.txt")

    func start() {
        guard Self.on, observers.isEmpty else { return }
        write("launch " + ProcessInfo.processInfo.arguments.dropFirst().joined(separator: " "))
        let center = NotificationCenter.default
        for (name, event) in [(UIResponder.keyboardWillHideNotification, "kb-hide"),
                              (UIResponder.keyboardWillShowNotification, "kb-show")] {
            observers.append(center.addObserver(forName: name, object: nil, queue: .main) { _ in
                MainActor.assumeIsolated { MenuGhostProbe.shared.film(event) }
            })
        }
        ticker = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { _ in
            MainActor.assumeIsolated { MenuGhostProbe.shared.note("tick", onlyChanges: true) }
        }
    }

    private func film(_ event: String) {
        films += 1
        let tag = "\(event)-\(films)", start = CACurrentMediaTime()
        for ms in stride(from: 0, through: 720, by: 40) {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(ms) / 1000) {
                MainActor.assumeIsolated {
                    let at = Int(((CACurrentMediaTime() - start) * 1000).rounded())
                    MenuGhostProbe.shared.note("\(tag) +\(at)ms", onlyChanges: false)
                }
            }
        }
    }

    private func note(_ tag: String, onlyChanges: Bool) {
        guard pill.width > 0 else { return }
        let began = CACurrentMediaTime()
        let seen = describe()
        if onlyChanges && seen == last { return }
        last = seen
        write("\(tag) took=\(Int(((CACurrentMediaTime() - began) * 1000).rounded()))ms \(seen)")
    }

    private func write(_ line: String) {
        let text = String(format: "%.3f ", Date().timeIntervalSince1970) + line + "\n"
        guard let data = text.data(using: .utf8) else { return }
        if let handle = try? FileHandle(forWritingTo: file) {
            handle.seekToEndOfFile(); handle.write(data); try? handle.close()
        } else {
            try? data.write(to: file)
        }
    }

    /// Where a ghost could be: every place the pill has stood lately (the
    /// opened panel's row and the bar's line), and between them.
    private var area: CGRect {
        guard var all = pills.first else { return .zero }
        for p in pills { all = all.union(p) }
        return all.insetBy(dx: -10, dy: -10)
    }

    private static func name(_ object: AnyObject?) -> String {
        guard let object else { return "-" }
        return String(describing: type(of: object))
    }
    private static func rect(_ r: CGRect) -> String {
        String(format: "%.0f,%.0f,%.0fx%.0f", r.minX, r.minY, r.width, r.height)
    }
    private static let menuWords = ["ContextMenu", "Portal", "Platter", "Morph", "MenuView", "Matched"]

    private func describe() -> String {
        let windows = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap(\.windows)
        let area = area
        let pillWidth = pills.map(\.width).max() ?? 80, pillHeight = pills.map(\.height).max() ?? 36
        var found: [String] = [], menus: [String] = []
        for window in windows where !window.isHidden {
            let root = window.layer.presentation() ?? window.layer
            func visit(_ model: CALayer, _ inherited: Float) {
                let layer = model.presentation() ?? model
                let effective = model.isHidden ? 0 : inherited * layer.opacity
                let seen = layer.convert(layer.bounds, to: root)
                let kind = Self.name(model), view = Self.name(model.delegate)
                let menuish = Self.menuWords.contains { kind.contains($0) || view.contains($0) }
                if menuish, effective > 0.01, menus.count < 14 {
                    menus.append("\(view)/\(kind)[\(Self.rect(seen))] e=\(String(format: "%.2f", effective))")
                }
                if effective > 0.03, seen.intersects(area), seen.width >= 6, seen.height >= 6,
                   seen.width <= pillWidth + 70, seen.height <= pillHeight + 40, found.count < 24 {
                    let draws = layer.contents != nil || (layer.backgroundColor?.alpha ?? 0) > 0.01 || menuish
                        || ["Backdrop", "Glass", "SDF", "Shadow", "Filter", "Text", "Shape"].contains { kind.contains($0) || view.contains($0) }
                    if draws {
                        let animations = (model.animationKeys() ?? []).prefix(3).joined(separator: "+")
                        found.append("\(view)/\(kind)[\(Self.rect(seen))] o=\(String(format: "%.2f", layer.opacity)) e=\(String(format: "%.2f", effective))"
                                     + (animations.isEmpty ? "" : " anim=\(animations)"))
                    }
                }
                // Nothing under a layer drawn with no opacity shows, except
                // through a portal, which is a layer of its own here.
                guard effective > 0.001 else { return }
                for sub in model.sublayers ?? [] { visit(sub, effective) }
            }
            visit(window.layer, 1)
        }
        return "area=\(Self.rect(area)) pill: " + (found.isEmpty ? "none" : found.joined(separator: " ; "))
            + " | menus: " + (menus.isEmpty ? "none" : menus.joined(separator: " ; "))
    }
}

/// Starts the probe with the chat; draws nothing.
struct MenuGhostReadout: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        MenuGhostProbe.shared.start()
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        view.isUserInteractionEnabled = false
        view.isAccessibilityElement = false
        return view
    }
    func updateUIView(_ view: UIView, context: Context) {}
}
