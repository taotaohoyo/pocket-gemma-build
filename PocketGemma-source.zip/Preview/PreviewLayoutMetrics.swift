// Simulator-only metadata. No chat text, images, model or user data is logged.
import SwiftUI
import UIKit

struct PreviewBubbleFrames: PreferenceKey {
    static let defaultValue: [UUID: CGRect] = [:]
    static func reduce(value: inout [UUID: CGRect], nextValue: () -> [UUID: CGRect]) {
        value.merge(nextValue(), uniquingKeysWith: { _, newest in newest })
    }
}

@MainActor private final class PreviewLayoutRecorder: NSObject, ObservableObject {
    private var link: CADisplayLink?
    private var previous: CFTimeInterval = 0
    private var frameSamples = 0
    private var longestFrameInterval: Double = 0
    private var geometrySamples = 0
    private var maxOverlap: CGFloat = 0
    private var minGap: CGFloat = .greatestFiniteMagnitude
    @Published var report = "{}"

    func start() {
        guard link == nil else { return }
        previous = 0
        let link = CADisplayLink(target: self, selector: #selector(frame(_:)))
        link.add(to: .main, forMode: .common); self.link = link
    }
    func stop() { link?.invalidate(); link = nil }
    @objc private func frame(_ link: CADisplayLink) {
        if previous > 0 {
            frameSamples += 1
            longestFrameInterval = max(longestFrameInterval, link.timestamp - previous)
        }
        previous = link.timestamp
    }
    func observe(_ frames: [UUID: CGRect]) {
        let rows = frames.values.filter { !$0.isEmpty && !$0.isInfinite && !$0.isNull }.sorted { $0.minY < $1.minY }
        guard rows.count > 1 else { return }
        geometrySamples += 1
        for pair in zip(rows, rows.dropFirst()) {
            let gap = pair.1.minY - pair.0.maxY
            minGap = min(minGap, gap)
            maxOverlap = max(maxOverlap, -gap)
        }
    }
    func export() {
        let data: [String: Any] = ["scope": "Simulator UI preview; no native inference",
            "geometrySamples": geometrySamples, "maximumLayoutOverlapPoints": Double(maxOverlap),
            "minimumLayoutGapPoints": minGap == .greatestFiniteMagnitude ? 0 : Double(minGap),
            "displayLinkSamples": frameSamples, "longestMainDisplayLinkIntervalMs": longestFrameInterval * 1000]
        if let bytes = try? JSONSerialization.data(withJSONObject: data, options: [.sortedKeys]),
           let json = String(data: bytes, encoding: .utf8) { report = json }
    }
}

struct PreviewLayoutMetrics: ViewModifier {
    @StateObject private var recorder = PreviewLayoutRecorder()
    func body(content: Content) -> some View {
        content.onPreferenceChange(PreviewBubbleFrames.self) { recorder.observe($0) }
            .overlay(alignment: .topTrailing) {
                Button("計測を保存") { recorder.export() }
                    .font(.caption2).padding(3).background(.regularMaterial)
                    .accessibilityIdentifier("layout-metrics-export")
                    .accessibilityValue(recorder.report)
            }
            .onAppear { recorder.start() }.onDisappear { recorder.stop() }
    }
}
