import SwiftUI
import UIKit

/// The UI check's tap that holds the drawer (`--history-reveal-on-tap`
/// with `--history-reveal`) or starts its film (`--drawer-film-on-tap`)
/// once it has read a little way up the chat with its own finger (1.1.0
/// (276), fielua-reports Issue #14). A held drawer from launch, or a film
/// on a timer, would not wait for the finger. At the header's empty
/// trailing end, as large as its buttons: with a 6pt one at the screen's
/// trailing edge, the check's taps never held the drawer nor started a
/// film (UI check run 43566687051).
struct PreviewDrawerGo: View {
    static let filmWaits = PreviewProbe.on("--drawer-film-on-tap")
    static let on = filmWaits || PreviewProbe.on("--history-reveal-on-tap")
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Color.clear.frame(width: 44, height: 44).contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("drawer-go")
        .accessibilityIdentifier("drawer-go")
    }
}

/// `--scroll-anatomy`: the conversation's scroll view as UIKit has it, for
/// the UI check (1.1.0 (276), Issue #14): where the screen shows it, how
/// far it is scrolled, its clip and its corners, and the views of the
/// scroll edge effect, by their class names, with where they are and
/// whether they are in the scroll view. Read when asked, so it is never
/// out of date; the conversation itself is hidden from accessibility
/// while the history shows, and this is not in it.
struct ScrollAnatomyReadout: UIViewRepresentable {
    func makeUIView(context: Context) -> ScrollAnatomyView { ScrollAnatomyView() }
    func updateUIView(_ view: ScrollAnatomyView, context: Context) {}
}

final class ScrollAnatomyView: UIView {
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        isAccessibilityElement = true
        accessibilityIdentifier = "chat-scroll-anatomy"
        isUserInteractionEnabled = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var intrinsicContentSize: CGSize { CGSize(width: 1, height: 1) }

    override var accessibilityLabel: String? {
        get { Self.describe(in: window) }
        set {}
    }

    private static func name(_ view: UIView) -> String { String(describing: type(of: view)) }
    private static func rect(_ r: CGRect) -> String {
        String(format: "%.1f,%.1f,%.1f,%.1f", r.minX, r.minY, r.width, r.height)
    }

    /// The conversation's scroll view: the tallest as wide as the screen
    /// (the history's is narrower).
    static func conversation(in window: UIWindow) -> UIScrollView? {
        var found: UIScrollView?
        var foundHeight: CGFloat = 0
        func visit(_ view: UIView) {
            if let scroll = view as? UIScrollView, !(scroll is UITextView), !scroll.isHidden {
                let seen = scroll.convert(scroll.bounds, to: window)
                if abs(seen.width - window.bounds.width) < 1, seen.height > window.bounds.height / 2, seen.height > foundHeight {
                    found = scroll; foundHeight = seen.height
                }
            }
            view.subviews.forEach(visit)
        }
        visit(window)
        return found
    }

    static func describe(in window: UIWindow?) -> String {
        guard let window else { return "no window" }
        guard let scroll = conversation(in: window) else { return "no scroll" }
        var parts: [String] = []
        let seen = scroll.convert(scroll.bounds, to: window)
        parts.append("scroll " + rect(seen) + String(format: " offset %.1f content %.1f inset %.1f,%.1f", scroll.contentOffset.y,
                                                    scroll.contentSize.height, scroll.adjustedContentInset.top,
                                                    scroll.adjustedContentInset.bottom))
        parts.append(String(format: "radius %.1f", scroll.layer.cornerRadius)
                     + " corners \(scroll.layer.maskedCorners.rawValue) clips \(scroll.clipsToBounds ? 1 : 0)"
                     + " curve \(scroll.layer.cornerCurve.rawValue)")
        parts.append(String(format: "screen %.0fx%.0f", window.bounds.width, window.bounds.height))
        // The scroll view's own subviews other than its content's.
        let own = scroll.subviews.map { "\(name($0))[\(rect($0.convert($0.bounds, to: window)))]" }
        parts.append("subviews " + own.prefix(12).joined(separator: " "))
        if let parent = scroll.superview {
            let siblings = parent.subviews.filter { $0 !== scroll }
                .map { "\(name($0))[\(rect($0.convert($0.bounds, to: window)))]" }
            parts.append("parent \(name(parent)) siblings " + siblings.prefix(10).joined(separator: " "))
        }
        // The scroll edge effect's views, wherever they are.
        var edges: [String] = []
        func visit(_ view: UIView) {
            let n = name(view)
            if n.localizedCaseInsensitiveContains("pocket") || n.localizedCaseInsensitiveContains("edgeeffect") {
                let inside = view.isDescendant(of: scroll)
                edges.append("\(n)[\(rect(view.convert(view.bounds, to: window)))] in=\(inside ? 1 : 0) hidden=\(view.isHidden ? 1 : 0) alpha=\(String(format: "%.2f", view.alpha))")
            }
            view.subviews.forEach(visit)
        }
        visit(window)
        parts.append("edges " + (edges.isEmpty ? "none" : edges.prefix(16).joined(separator: " ")))
        return parts.joined(separator: " | ")
    }
}
