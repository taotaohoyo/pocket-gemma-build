import ActivityKit
import SwiftUI
import PocketCore

/// `--download-activity`: starts the model download Live Activity with
/// made-up progress, so a UI test can photograph the Dynamic Island from
/// the Home Screen. The result is shown for the test to read. With
/// `--download-activity-two`, E2B downloads at the same time with its own one.
/// With `--download-background`, the figure moves every second for a minute
/// and the result counts the moves made while the app was in the background;
/// `--keep-alive` keeps the app running with the app's silent sound.
struct PreviewDownloadActivity: View {
    @State private var result = "starting"
    var body: some View {
        Text("live-activity: \(result)")
            .font(.caption2)
            .accessibilityIdentifier("download-activity-status")
            .task { await run() }
    }

    private func run() async {
        for old in Activity<ModelDownloadAttributes>.activities { await old.end(nil, dismissalPolicy: .immediate) }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { result = "disabled"; return }
        let starts: [(spec: ModelSpec, fraction: Double)] = ProcessInfo.processInfo.arguments.contains("--download-activity-two")
            ? [(.e4b, 0.42), (.e2b, 0.18)] : [(.e4b, 0.42)]
        func state(step: Int) -> ModelDownloadAttributes.ContentState {
            let downloads = starts.map { spec, fraction in
                ModelDownloadAttributes.Download(modelID: spec.id, modelName: spec.name, showsGemmaLogo: true,
                                                 symbol: ModelMark(model: spec).symbol,
                                                 fraction: fraction + Double(step) * 0.01, phase: .downloading)
            }
            return .init(fraction: downloads[0].fraction, phase: .downloading, downloads: downloads)
        }
        let spec = starts[0].spec
        do {
            // One activity for every download, as the app does.
            let activity = try Activity.request(attributes: ModelDownloadAttributes(modelID: spec.id, modelName: spec.name,
                                                                                    showsGemmaLogo: true,
                                                                                    symbol: ModelMark(model: spec).symbol),
                                                content: ActivityContent(state: state(step: 0), staleDate: nil, relevanceScore: 100))
            result = starts.count == 1 ? "started" : "started \(starts.count)"
            let arguments = ProcessInfo.processInfo.arguments
            guard arguments.contains("--download-background") else {
                for step in 1...18 {
                    try await Task.sleep(for: .seconds(1))
                    await activity.update(ActivityContent(state: state(step: step), staleDate: nil, relevanceScore: 100))
                }
                return
            }
            if arguments.contains("--keep-alive") { BackgroundKeepAlive.shared.start() }
            defer { BackgroundKeepAlive.shared.stop() }
            var inBackground = 0
            for step in 1...55 {
                try await Task.sleep(for: .seconds(1))
                if UIApplication.shared.applicationState == .background { inBackground += 1 }
                result = "background \(inBackground)" + (BackgroundKeepAlive.shared.failure.map { " sound failed: \($0)" } ?? "")
                await activity.update(ActivityContent(state: state(step: step), staleDate: nil, relevanceScore: 100))
            }
        } catch { result = "failed \(error.localizedDescription)" }
    }
}
