import ActivityKit
import BackgroundTasks
import SwiftUI
import PocketCore

/// `--download-activity`: starts the model download Live Activity with
/// made-up progress, so a UI test can photograph the Dynamic Island from
/// the Home Screen. The result is shown for the test to read. With
/// `--download-activity-two`, E2B downloads at the same time with its own one.
/// With `--download-activity-continued`, it also asks iOS for the
/// continued-processing task, as a download the person starts does, to see
/// how iOS's own display and the app's share the island.
struct PreviewDownloadActivity: View {
    @State private var result = "starting"
    @State private var continuedResult = "none"
    @State private var continued: BGContinuedProcessingTask?
    var body: some View {
        VStack {
            Text("live-activity: \(result)")
                .font(.caption2)
                .accessibilityIdentifier("download-activity-status")
            Text("continued: \(continuedResult)")
                .font(.caption2)
                .accessibilityIdentifier("download-continued-status")
        }
        .task { await run() }
    }

    private func run() async {
        for old in Activity<ModelDownloadAttributes>.activities { await old.end(nil, dismissalPolicy: .immediate) }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { result = "disabled"; return }
        let starts: [(spec: ModelSpec, fraction: Double)] = ProcessInfo.processInfo.arguments.contains("--download-activity-two")
            ? [(.e4b, 0.42), (.e2b, 0.18)] : [(.e4b, 0.42)]
        func state(step: Int) -> ModelDownloadAttributes.ContentState {
            let downloads = starts.map { spec, fraction in
                ModelDownloadAttributes.Download(modelID: spec.id, modelName: spec.name, showsGemmaLogo: true,
                                                 symbol: ModelMark(model: spec).symbol,
                                                 fraction: fraction + Double(step) * 0.01, phase: .downloading,
                                                 byteCount: spec.byteCount)
            }
            return .init(fraction: downloads[0].fraction, phase: .downloading, downloads: downloads)
        }
        let spec = starts[0].spec
        if ProcessInfo.processInfo.arguments.contains("--download-activity-continued") { requestContinued(spec) }
        do {
            // One activity for every download, as the app does.
            let activity = try Activity.request(attributes: ModelDownloadAttributes(modelID: spec.id, modelName: spec.name,
                                                                                    showsGemmaLogo: true,
                                                                                    symbol: ModelMark(model: spec).symbol),
                                                content: ActivityContent(state: state(step: 0), staleDate: nil, relevanceScore: 100))
            result = starts.count == 1 ? "started" : "started \(starts.count)"
            for step in 1...18 {
                try await Task.sleep(for: .seconds(1))
                let next = state(step: step)
                await activity.update(ActivityContent(state: next, staleDate: nil, relevanceScore: 100))
                if let continued, let first = next.downloads?.first {
                    continued.progress.completedUnitCount = Int64(first.fraction * 990)
                    continued.updateTitle("\(first.modelName)をダウンロード", subtitle: "\(first.percent)%")
                }
            }
            continued?.setTaskCompleted(success: true)
        } catch { result = "failed \(error.localizedDescription)" }
    }

    private func requestContinued(_ spec: ModelSpec) {
        let identifier = "app.pocketgemma.preview.model-download." + UUID().uuidString
        let registered = BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: .main) { task in
            MainActor.assumeIsolated {
                guard let task = task as? BGContinuedProcessingTask else { task.setTaskCompleted(success: false); return }
                task.progress.totalUnitCount = 1000
                task.expirationHandler = {
                    Task { @MainActor in continuedResult = "expired"; continued = nil }
                }
                continued = task
                continuedResult = "running"
            }
        }
        guard registered else { continuedResult = "unregistered"; return }
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: "\(spec.name)をダウンロード", subtitle: "42%")
        request.strategy = .fail
        do {
            try BGTaskScheduler.shared.submit(request)
            continuedResult = "submitted"
        } catch { continuedResult = "refused \((error as NSError).code)" }
    }
}
