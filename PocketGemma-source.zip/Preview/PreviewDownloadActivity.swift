import ActivityKit
import SwiftUI
import PocketCore

/// `--download-activity`: starts the model download Live Activity with
/// made-up progress, so a UI test can photograph the Dynamic Island from
/// the Home Screen. The result is shown for the test to read. With
/// `--download-activity-two`, E2B downloads at the same time with its own one.
struct PreviewDownloadActivity: View {
    @State private var result = "starting"
    var body: some View {
        Text("live-activity: \(result)")
            .font(.caption2)
            .accessibilityIdentifier("download-activity-status")
            .task { await run() }
    }

    private func run() async {
        for old in Activity<ModelDownloadAttributes>.activities { await old.end(nil, dismissalPolicy: .immediate) }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { result = "disabled"; return }
        var downloads: [(spec: ModelSpec, start: Double)] = [(.e4b, 0.42)]
        if ProcessInfo.processInfo.arguments.contains("--download-activity-two") { downloads.append((.e2b, 0.18)) }
        do {
            let activities = try downloads.map { spec, start in
                try Activity.request(attributes: ModelDownloadAttributes(modelID: spec.id, modelName: spec.name,
                                                                         showsGemmaLogo: true,
                                                                         symbol: ModelMark(model: spec).symbol),
                                     content: ActivityContent(state: .init(fraction: start, phase: .downloading),
                                                              staleDate: nil, relevanceScore: 100))
            }
            result = activities.count == 1 ? "started" : "started \(activities.count)"
            for step in 1...18 {
                try await Task.sleep(for: .seconds(1))
                for (activity, download) in zip(activities, downloads) {
                    let fraction = download.start + Double(step) * 0.01
                    await activity.update(ActivityContent(state: .init(fraction: fraction, phase: .downloading),
                                                          staleDate: nil, relevanceScore: 100))
                }
            }
        } catch { result = "failed \(error.localizedDescription)" }
    }
}
