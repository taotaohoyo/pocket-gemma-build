import ActivityKit
import SwiftUI
import PocketCore

/// `--download-activity`: starts the model download Live Activity with
/// made-up progress, so a UI test can photograph the Dynamic Island from
/// the Home Screen. The result is shown for the test to read.
struct PreviewDownloadActivity: View {
    @State private var result = "starting"
    var body: some View {
        Text("live-activity: \(result)")
            .font(.caption2)
            .accessibilityIdentifier("download-activity-status")
            .task { await run() }
    }

    private func run() async {
        for old in Activity<ModelDownloadAttributes>.activities { await old.end(nil, dismissalPolicy: .immediate) }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { result = "disabled"; return }
        let spec = ModelSpec.e4b
        let attributes = ModelDownloadAttributes(modelID: spec.id, modelName: spec.name, showsGemmaLogo: true,
                                                 symbol: ModelMark(model: spec).symbol)
        var fraction = 0.42
        do {
            let activity = try Activity.request(attributes: attributes, content: ActivityContent(
                state: .init(fraction: fraction, phase: .downloading), staleDate: nil, relevanceScore: 100))
            result = "started"
            while fraction < 0.6 {
                try await Task.sleep(for: .seconds(1))
                fraction += 0.01
                await activity.update(ActivityContent(state: .init(fraction: fraction, phase: .downloading),
                                                      staleDate: nil, relevanceScore: 100))
            }
        } catch { result = "failed \(error.localizedDescription)" }
    }
}
