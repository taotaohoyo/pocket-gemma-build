// Simulator-only send review. Captures the rendered window for a short time
// after each send, so overlap during animations (which layout anchors cannot
// see) can be reviewed frame by frame. Only the preview's sample text is shown.
import UIKit

@MainActor final class PreviewSendFrames: NSObject {
    static let shared = PreviewSendFrames()
    static var enabled: Bool { ProcessInfo.processInfo.arguments.contains("--send-frames") }
    private var link: CADisplayLink?
    private var started: CFTimeInterval = 0
    private var frames: [(ms: Int, image: UIImage)] = []
    private var tick = 0
    private var sendIndex = 0
    private let duration: CFTimeInterval = 1.5
    private let thumbnailScale: CGFloat = 0.4

    func start() {
        guard Self.enabled, link == nil else { return }
        sendIndex += 1; frames = []; tick = 0; started = 0
        let link = CADisplayLink(target: self, selector: #selector(frame(_:)))
        link.add(to: .main, forMode: .common); self.link = link
    }

    @objc private func frame(_ link: CADisplayLink) {
        if started == 0 { started = link.timestamp }
        let elapsed = link.timestamp - started
        tick += 1
        // Every second display frame keeps the sheet readable.
        if tick % 2 == 1, let window = UIApplication.shared.connectedScenes
            .compactMap({ ($0 as? UIWindowScene)?.keyWindow }).first {
            let size = CGSize(width: window.bounds.width * thumbnailScale, height: window.bounds.height * thumbnailScale)
            let format = UIGraphicsImageRendererFormat(); format.scale = 1
            let image = UIGraphicsImageRenderer(size: size, format: format).image { _ in
                window.drawHierarchy(in: CGRect(origin: .zero, size: size), afterScreenUpdates: false)
            }
            frames.append((Int(elapsed * 1000), image))
        }
        if elapsed >= duration { link.invalidate(); self.link = nil; writeSheet() }
    }

    private func writeSheet() {
        guard let first = frames.first?.image else { return }
        let columns = 6, rows = (frames.count + columns - 1) / columns
        let cell = first.size, label: CGFloat = 14
        let size = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let format = UIGraphicsImageRendererFormat(); format.scale = 1
        let sheet = UIGraphicsImageRenderer(size: size, format: format).image { context in
            UIColor.black.setFill(); context.fill(CGRect(origin: .zero, size: size))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: cell.width * CGFloat(index % columns),
                                     y: (cell.height + label) * CGFloat(index / columns))
                ("\(frame.ms)ms" as NSString).draw(at: origin, withAttributes: [
                    .font: UIFont.monospacedDigitSystemFont(ofSize: 11, weight: .medium), .foregroundColor: UIColor.white])
                frame.image.draw(in: CGRect(origin: CGPoint(x: origin.x, y: origin.y + label), size: cell))
            }
        }
        let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("send-frames", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let name = "\(ProcessInfo.processInfo.environment["SEND_FRAMES_LABEL"] ?? "send")-\(sendIndex).jpg"
        try? sheet.jpegData(compressionQuality: 0.55)?.write(to: folder.appendingPathComponent(name))
        frames = []
    }
}
