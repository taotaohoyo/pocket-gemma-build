import SwiftUI
import QuartzCore

/// UI checks only (`--orb-cost`, 1.1.0 (304)): what one frame of each of
/// the reply light's layers costs to draw here, as 303 drew them and as
/// 304 does, light and dark: the broad field (303: its halo in it and its
/// reach from each direction's rim alone; 304: no halo, its reach from the
/// rim round about each direction), the orb (303: auroraOrb, 52pt; 304:
/// auroraReplyOrb with the halo, 72pt) and an empty layer of each size
/// (what drawing anything costs here). Each is drawn at the screen's 3x by
/// ImageRenderer `rounds` times at moments a frame apart, after a few
/// unmeasured ones; the median time a frame, in milliseconds, and the
/// share of its pixels lit (so a layer that drew nothing shows). The
/// summary goes to the check (`orb-cost`).
@MainActor final class OrbCost: ObservableObject {
    static let shared = OrbCost()
    static let on = PreviewProbe.on("--orb-cost")
    @Published private(set) var summary = "none"
    private var started = false
    private let rounds = 40

    func run() {
        guard Self.on, !started else { return }
        started = true
        Task { @MainActor in
            await AuroraOrbView.prepare()
            await ReplyLight.prepare()
            try? await Task.sleep(for: .seconds(1))
            var parts: [String] = []
            for dark in [false, true] {
                for layer in Layer.allCases {
                    let (ms, lit) = measure(layer, dark: dark)
                    parts.append(String(format: "%@-%@ %.2f ms lit %.3f", layer.rawValue, dark ? "dark" : "light", ms, lit))
                    await Task.yield()
                }
            }
            summary = "cost " + parts.joined(separator: " | ")
        }
    }

    enum Layer: String, CaseIterable {
        case field303, field304, fieldEmpty, orb303, orb304, orbEmpty
    }

    private func measure(_ layer: Layer, dark: Bool) -> (Double, Double) {
        var times: [Double] = []
        var lit = 0.0
        for round in 0..<(rounds + 4) {
            // A writing moment, a frame apart each round.
            let time = 1.0 + Double(round) / 60
            let renderer = ImageRenderer(content: view(layer, dark: dark, time: time))
            renderer.scale = 3
            let begun = CACurrentMediaTime()
            let image = renderer.cgImage
            let took = CACurrentMediaTime() - begun
            if round >= 4 { times.append(took * 1000) }
            if round == rounds + 3, let image { lit = Self.litShare(image) }
        }
        times.sort()
        return (times.isEmpty ? -1 : times[times.count / 2], lit)
    }

    @ViewBuilder private func view(_ layer: Layer, dark: Bool, time: Double) -> some View {
        let d: Float = dark ? 1 : 0
        let size = 0.75
        switch layer {
        case .field303, .field304:
            let modern = layer == .field304
            Rectangle()
                .fill(ShaderLibrary.auroraField(.float2(64, 76), .float2(32.0 / 3, 32), .float(3), .float(Float(time)),
                                                .float(d), .float(0.5), .float(0.6),
                                                .float(Float(AuroraOrbView.lightRadius * size)),
                                                .float(modern ? 0 : 1), .float(1), .float(modern ? 1 : 0)))
                .frame(width: 64, height: 76)
                .drawingGroup()
                .scaleEffect(3, anchor: .topLeading)
                .frame(width: 192, height: 228, alignment: .topLeading)
        case .fieldEmpty:
            Rectangle().fill(Color.white.opacity(0.01))
                .frame(width: 64, height: 76)
                .drawingGroup()
                .scaleEffect(3, anchor: .topLeading)
                .frame(width: 192, height: 228, alignment: .topLeading)
        case .orb303:
            Rectangle()
                .fill(ShaderLibrary.auroraOrb(.float2(52, 52), .float(Float(time)), .float(d), .float(Float(size))))
                .frame(width: 52, height: 52)
        case .orb304:
            Rectangle()
                .fill(ShaderLibrary.auroraReplyOrb(.float2(72, 72), .float(Float(time)), .float(d), .float(Float(size)),
                                                   .float(1), .float(0.5), .float(1), .float(1)))
                .frame(width: 72, height: 72)
        case .orbEmpty:
            Rectangle().fill(Color.white.opacity(0.01)).frame(width: 72, height: 72)
        }
    }

    /// The share of the image's pixels with any alpha.
    private static func litShare(_ image: CGImage) -> Double {
        let width = image.width, height = image.height
        guard width > 0, height > 0 else { return 0 }
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let drawn: Bool = pixels.withUnsafeMutableBytes { buffer in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return 0 }
        var count = 0
        for index in stride(from: 3, to: pixels.count, by: 4) where pixels[index] > 2 { count += 1 }
        return Double(count) / Double(width * height)
    }
}

/// The cost's summary, for the check to read: "none" until measured.
struct PreviewOrbCost: View {
    @ObservedObject private var cost = OrbCost.shared
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("orb-cost")
            .accessibilityLabel(cost.summary)
            .onAppear { cost.run() }
    }
}
