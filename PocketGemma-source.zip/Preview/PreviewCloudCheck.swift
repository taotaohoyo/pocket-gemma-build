import SwiftUI
import PocketCore

/// Runs production backup IO against a synthetic local File Provider folder,
/// then (1.1.0 (252)) against a local folder standing in for Fielua's iCloud
/// container. No iCloud account, model, remote upload or personal archive is
/// involved.
struct PreviewCloudCheck: View {
    @State private var result = "バックアップ検証中"
    var body: some View {
        Text(result).font(.caption).padding(4).background(.background)
            .accessibilityIdentifier("backup-report").allowsHitTesting(false)
            .task { await run() }
    }
    @MainActor private func run() async {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let container = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let cloud = CloudHistoryStore.shared
        var attachment: ChatAttachment?
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            guard let url = PreviewAttachments.url("sample-text") else { throw CocoaError(.fileReadNoSuchFile) }
            let imported = try await Task.detached { try await AttachmentStorage.importFile(url) }.value
            attachment = imported
            var initial = ChatThread(modelID: ModelSpec.e4b.id)
            initial.messages = [ChatMessage(role: .user, text: "backup fixture", attachments: [imported])]
            cloud.configure(folder)
            await cloud.saveNow([initial])
            guard cloud.lastSaved != nil, cloud.error == nil else { throw CocoaError(.fileWriteUnknown) }
            initial.messages.append(ChatMessage(role: .assistant, text: "latest snapshot"))
            initial.updatedAt = Date()
            cloud.schedule([initial])
            try await Task.sleep(for: .milliseconds(3600))
            let restored = try await cloud.restore()
            guard restored.first?.messages.last?.text == "latest snapshot",
                  restored.first?.messages.first?.media.first?.extractedText?.contains("日本語") == true,
                  FileManager.default.fileExists(atPath: AttachmentStorage.url(imported.storedName)!.path) else { throw CocoaError(.fileReadCorruptFile) }
            // Verify media recovery itself, not merely the archive's filenames.
            AttachmentStorage.remove(imported)
            _ = try await cloud.restore()
            guard FileManager.default.fileExists(atPath: AttachmentStorage.url(imported.storedName)!.path) else { throw CocoaError(.fileReadNoSuchFile) }

            // Fielua's own iCloud: the folder backup moves there on its next
            // save, and the folder's copies stay.
            await cloud.usePreviewContainer(container)
            initial.messages.append(ChatMessage(role: .user, text: "private cloud"))
            initial.updatedAt = Date()
            await cloud.saveNow([initial])
            guard cloud.privateCloud, cloud.error == nil, cloud.lastSaved != nil,
                  cloud.earlierFolderName == folder.lastPathComponent else { throw CocoaError(.fileWriteUnknown) }
            let backup = PrivateBackup(container: container)
            let devices = try FileManager.default.contentsOfDirectory(at: backup.root, includingPropertiesForKeys: nil)
            guard devices.count == 1, let device = devices.first,
                  FileManager.default.fileExists(atPath: device.appendingPathComponent(PrivateBackup.archiveName).path),
                  FileManager.default.fileExists(atPath: device.appendingPathComponent(PrivateBackup.attachmentsName)
                    .appendingPathComponent(imported.storedName).path),
                  // Nothing in the container's Documents folder, which iCloud Drive would list.
                  !FileManager.default.fileExists(atPath: container.appendingPathComponent("Documents").path)
            else { throw CocoaError(.fileReadNoSuchFile) }
            AttachmentStorage.remove(imported)
            let fromCloud = try await cloud.restore()
            guard fromCloud.first?.messages.last?.text == "private cloud",
                  FileManager.default.fileExists(atPath: AttachmentStorage.url(imported.storedName)!.path) else { throw CocoaError(.fileReadCorruptFile) }
            // The earlier folder still reads, without the newest message.
            let fromFolder = try await cloud.restoreEarlierFolder()
            guard fromFolder.first?.messages.last?.text == "latest snapshot" else { throw CocoaError(.fileReadCorruptFile) }
            // A deleted chat leaves the iCloud backup with its attachments.
            await cloud.saveNow([])
            let media = try FileManager.default.contentsOfDirectory(atPath: device.appendingPathComponent(PrivateBackup.attachmentsName).path)
            guard cloud.error == nil, media.isEmpty,
                  try ChatArchive(fileURL: device.appendingPathComponent(PrivateBackup.archiveName)).load().isEmpty
            else { throw CocoaError(.fileWriteUnknown) }
            result = "バックアップ検証成功: 自動保存・最新会話・添付の復元・専用 iCloud"
        } catch { result = "バックアップ検証失敗: \(error.localizedDescription)" }
        if let attachment { AttachmentStorage.remove(attachment) }
        await cloud.usePreviewContainer(nil)
        cloud.disable()
        try? FileManager.default.removeItem(at: folder)
        try? FileManager.default.removeItem(at: container)
    }
}
