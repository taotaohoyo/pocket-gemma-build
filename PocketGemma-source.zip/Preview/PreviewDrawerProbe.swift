import SwiftUI
import UIKit

/// `--drawer-probe`: the screen as it shows a few moments into each slide
/// of the phone's history drawer, for the UI check (1.1.0 (265)).
/// XCUITest's screenshots wait until a slide has ended, so the app looks
/// at itself: for the length of a slide it draws its window as it is on
/// screen and reads the brightness every 10pt across, 45% of the way
/// down. In 1.1.0 (264) the conversation's paper went back in place as
/// a close began, ahead of the rest of the conversation, and hid the
/// history at once (Hachimoto さん's recording, 2026-11-12).
///
/// The samples are taken one after another, each 40ms after the last one
/// was read, so the slide draws its frames in between: taken all at once
/// they kept the main thread and saw only the slide's first frame (the
/// first runs of 265's check). With `--drawer-slow` the drawer runs the
/// same spring fifteen times as long, so a slow simulator, sampling only
/// every 200-300ms, still sees it go through the middle, frame by frame
/// (five times as long gave a slow runner only two samples in between).
@Observable @MainActor final class DrawerProbe {
    static let shared = DrawerProbe()
    static let on = PreviewProbe.on("--drawer-probe")
    static let slow = PreviewProbe.on("--drawer-slow")
    private(set) var lines: [String] = []
    private var slides = 0

    /// As a slide begins, opening or closing.
    func slide(open: Bool) {
        guard Self.on else { return }
        slides += 1
        let slide = slides
        let start = CACurrentMediaTime()
        let length = Self.slow ? 7.5 : 0.5
        Task { @MainActor in
            while CACurrentMediaTime() - start < length, slide == self.slides {
                try? await Task.sleep(for: .milliseconds(40))
                self.sample(open: open, start: start)
            }
        }
    }

    private func sample(open: Bool, start: CFTimeInterval) {
        guard let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap(\.windows)
            .first(where: \.isKeyWindow),
              let space = CGColorSpace(name: CGColorSpace.sRGB) else { return }
        let size = window.bounds.size
        let width = Int(size.width), row = Int(size.height * 0.45)
        guard width > 20, row > 0 else { return }
        // One row of the window, 45% of the way down: the bitmap is one
        // pixel high, so little is drawn.
        var pixels = [UInt8](repeating: 0, count: width * 4)
        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: 1,
                                          bitsPerComponent: 8, bytesPerRow: width * 4, space: space,
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return false }
            // UIKit's way up, with the window's row at the bitmap's one.
            context.translateBy(x: 0, y: 1)
            context.scaleBy(x: 1, y: -1)
            context.translateBy(x: 0, y: -CGFloat(row))
            UIGraphicsPushContext(context)
            defer { UIGraphicsPopContext() }
            return window.drawHierarchy(in: CGRect(origin: .zero, size: size), afterScreenUpdates: false)
        }
        var values: [String] = []
        for x in stride(from: 10, to: width, by: 10) {
            let index = x * 4
            let luma = 0.299 * Double(pixels[index]) + 0.587 * Double(pixels[index + 1])
                + 0.114 * Double(pixels[index + 2])
            values.append(String(Int(luma.rounded())))
        }
        let elapsed = Int(((CACurrentMediaTime() - start) * 1000).rounded())
        lines.append("\(open ? "open" : "close") \(elapsed)ms\(drawn ? "" : " undrawn"): "
                     + values.joined(separator: " "))
    }
}

/// The probe's lines, for the UI check to read.
struct DrawerProbeReadout: View {
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("drawer-probe")
            .accessibilityLabel(DrawerProbe.shared.lines.joined(separator: " | "))
            .allowsHitTesting(false)
    }
}
