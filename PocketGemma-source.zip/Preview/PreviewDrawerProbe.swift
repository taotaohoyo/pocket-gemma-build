import SwiftUI
import UIKit

/// `--drawer-probe`: the screen as it shows a few moments into each slide
/// of the phone's history drawer, for the UI check (1.1.0 (265)).
/// XCUITest's screenshots wait until a slide has ended, so the app looks
/// at itself: for the length of a slide it draws its window as it is on
/// screen and reads the brightness every 10pt across, 45% of the way
/// down. In 1.1.0 (264) the conversation's paper went back in place as
/// a close began, ahead of the rest of the conversation, and hid the
/// history at once (Hachimoto さん's recording, 2026-11-12).
///
/// The samples are taken one after another, each 40ms after the last one
/// was read, so the slide draws its frames in between: taken all at once
/// they kept the main thread and saw only the slide's first frame (the
/// first runs of 265's check). With `--drawer-slow` the drawer runs the
/// same spring fifteen times as long, so a slow simulator, sampling only
/// every 200-300ms, still sees it go through the middle, frame by frame
/// (five times as long gave a slow runner only two samples in between).
@Observable @MainActor final class DrawerProbe {
    static let shared = DrawerProbe()
    static let on = PreviewProbe.on("--drawer-probe")
    static let slow = PreviewProbe.on("--drawer-slow")
    private(set) var lines: [String] = []
    private var slides = 0

    /// As a slide begins, opening or closing.
    func slide(open: Bool) {
        guard Self.on else { return }
        slides += 1
        let slide = slides
        let start = CACurrentMediaTime()
        let length = Self.slow ? 7.5 : 0.5
        let layouts = ChromeBlurLayouts.count
        Task { @MainActor in
            while CACurrentMediaTime() - start < length, slide == self.slides {
                try? await Task.sleep(for: .milliseconds(40))
                self.sample(open: open, start: start)
            }
            // How often the header's blur was laid out anew through the
            // slide (1.1.0 (268)): moved and scaled, it must not be.
            if slide == self.slides {
                self.lines.append("\(open ? "open" : "close")-layouts: \(ChromeBlurLayouts.count - layouts)")
            }
        }
    }

    private func sample(open: Bool, start: CFTimeInterval) {
        guard let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap(\.windows)
            .first(where: \.isKeyWindow),
              let space = CGColorSpace(name: CGColorSpace.sRGB) else { return }
        let size = window.bounds.size
        let width = Int(size.width), row = Int(size.height * 0.45)
        guard width > 20, row > 0 else { return }
        // One row of the window, 45% of the way down: the bitmap is one
        // pixel high, so little is drawn.
        var pixels = [UInt8](repeating: 0, count: width * 4)
        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: 1,
                                          bitsPerComponent: 8, bytesPerRow: width * 4, space: space,
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return false }
            // UIKit's way up, with the window's row at the bitmap's one.
            context.translateBy(x: 0, y: 1)
            context.scaleBy(x: 1, y: -1)
            context.translateBy(x: 0, y: -CGFloat(row))
            UIGraphicsPushContext(context)
            defer { UIGraphicsPopContext() }
            return window.drawHierarchy(in: CGRect(origin: .zero, size: size), afterScreenUpdates: false)
        }
        var values: [String] = []
        for x in stride(from: 10, to: width, by: 10) {
            let index = x * 4
            let luma = 0.299 * Double(pixels[index]) + 0.587 * Double(pixels[index + 1])
                + 0.114 * Double(pixels[index + 2])
            values.append(String(Int(luma.rounded())))
        }
        let elapsed = Int(((CACurrentMediaTime() - start) * 1000).rounded())
        lines.append("\(open ? "open" : "close") \(elapsed)ms\(drawn ? "" : " undrawn"): "
                     + values.joined(separator: " "))
        // And one column 8pt in from the trailing edge, down the top quarter,
        // for where the conversation's top edge stands as it steps back and
        // down (1.1.0 (268)): the strip of conversation left showing at the
        // trailing edge runs through it all the way. Its top is where the
        // sidebar's colour ends going down, in points. Only above the
        // safe area's top: the edge never comes lower (drop + depth of the
        // safe area, about 31pt), and the header's mark and words, which
        // the column crosses mid-slide, never come higher.
        let height = min(Int(size.height * 0.25), Int(window.safeAreaInsets.top.rounded(.down)))
        let full = Int(size.height), column = size.width - 8
        guard height > 6, full > 60 else { return }
        // The whole column in one drawing, for the top and the foot.
        var pixelColumn = [UInt8](repeating: 0, count: full * 4)
        let drawnColumn = pixelColumn.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: 1, height: full,
                                          bitsPerComponent: 8, bytesPerRow: 4, space: space,
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return false }
            context.translateBy(x: 0, y: CGFloat(full))
            context.scaleBy(x: 1, y: -1)
            context.translateBy(x: -column, y: 0)
            UIGraphicsPushContext(context)
            defer { UIGraphicsPopContext() }
            return window.drawHierarchy(in: CGRect(origin: .zero, size: size), afterScreenUpdates: false)
        }
        let lumas: [Double] = (0..<full).map { y in
            let index = y * 4
            return 0.299 * Double(pixelColumn[index]) + 0.587 * Double(pixelColumn[index + 1])
                + 0.114 * Double(pixelColumn[index + 2])
        }
        // The first point down that turns lighter than all above it: the
        // sidebar there darkens towards the panel under its shadow, now
        // that the panel's paper reaches past the header (1.1.0 (268), UI
        // check run 43288716310), and the veiled header blur over the
        // paper is lighter than both (in light only by 1 to 3 than the
        // sidebar itself, so not the first change from the top's colour).
        var top = 0, rise = 0.0, lowest = lumas[0]
        for y in 1..<height {
            if lumas[y] - lowest >= 3 {
                rise = lumas[y] - lowest
                top = y
                break
            }
            lowest = min(lowest, lumas[y])
        }
        // Its foot: how far up from the screen's foot the conversation's
        // paper ends, the first point going up lighter than the sidebar
        // there (the panel's shadow only darkens it), within 48pt; 99 when
        // there is none (closed, the column is all conversation). About
        // 13pt fully open; a paper drawn only within the safe area stops
        // 34pt up and more.
        var foot = 99
        for y in stride(from: full - 2, through: full - 48, by: -1) where lumas[y] - lumas[full - 1] >= 1.5 {
            foot = full - 1 - y
            break
        }
        let kind = open ? "open" : "close"
        let down = stride(from: 0, to: height, by: 6).map { String(Int(lumas[$0].rounded())) }
        lines.append("\(kind)-top \(elapsed)ms\(drawnColumn ? "" : " undrawn"): \(top) rise \(Int(rise.rounded()))")
        lines.append("\(kind)-foot \(elapsed)ms: \(foot)")
        lines.append("\(kind)-column \(elapsed)ms: " + down.joined(separator: " "))
    }
}

/// The probe's lines, for the UI check to read.
struct DrawerProbeReadout: View {
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("drawer-probe")
            .accessibilityLabel(DrawerProbe.shared.lines.joined(separator: " | "))
            .allowsHitTesting(false)
    }
}
