import SwiftUI
import UIKit

/// `--drawer-probe`: the screen as it shows a few moments into each slide
/// of the phone's history drawer, for the UI check (1.1.0 (265)).
/// XCUITest's screenshots wait until a slide has ended, so the app looks
/// at itself: every 30ms for the length of a slide it draws its window as
/// it is on screen and reads the brightness every 20pt across, 45% of the
/// way down. In 1.1.0 (264) the conversation's paper went back in place as
/// a close began, ahead of the rest of the conversation, and hid the
/// history at once (Hachimoto さん's recording, 2026-11-12).
@Observable @MainActor final class DrawerProbe {
    static let shared = DrawerProbe()
    static let on = PreviewProbe.on("--drawer-probe")
    private(set) var lines: [String] = []

    /// As a slide begins, opening or closing.
    func slide(open: Bool) {
        guard Self.on else { return }
        let start = CACurrentMediaTime()
        for step in 1...13 {
            Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(30 * step))
                self.sample(open: open, start: start)
            }
        }
    }

    private func sample(open: Bool, start: CFTimeInterval) {
        guard let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap(\.windows)
            .first(where: \.isKeyWindow),
              let space = CGColorSpace(name: CGColorSpace.sRGB) else { return }
        let size = window.bounds.size
        let width = Int(size.width), height = Int(size.height)
        guard width > 20, height > 0 else { return }
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height,
                                          bitsPerComponent: 8, bytesPerRow: width * 4, space: space,
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
            else { return false }
            // UIKit's way up: the first row in memory is the window's top.
            context.translateBy(x: 0, y: CGFloat(height))
            context.scaleBy(x: 1, y: -1)
            UIGraphicsPushContext(context)
            defer { UIGraphicsPopContext() }
            return window.drawHierarchy(in: CGRect(origin: .zero, size: size), afterScreenUpdates: false)
        }
        let row = Int(Double(height) * 0.45)
        var values: [String] = []
        for x in stride(from: 10, to: width, by: 20) {
            let index = (row * width + x) * 4
            let luma = 0.299 * Double(pixels[index]) + 0.587 * Double(pixels[index + 1])
                + 0.114 * Double(pixels[index + 2])
            values.append(String(Int(luma.rounded())))
        }
        let elapsed = Int(((CACurrentMediaTime() - start) * 1000).rounded())
        lines.append("\(open ? "open" : "close") \(elapsed)ms\(drawn ? "" : " undrawn"): "
                     + values.joined(separator: " "))
    }
}

/// The probe's lines, for the UI check to read.
struct DrawerProbeReadout: View {
    var body: some View {
        Color.clear.frame(width: 1, height: 1)
            .accessibilityElement()
            .accessibilityIdentifier("drawer-probe")
            .accessibilityLabel(DrawerProbe.shared.lines.joined(separator: " | "))
            .allowsHitTesting(false)
    }
}
