import SwiftUI
import QuartzCore

/// `--settings-profile-demo` (1.1.0 (291)): 設定 opened and closed by the
/// app itself, as Hachimoto さん goes there (the history, its gear, 閉じる, the
/// chat, the history again), then its pages in and out, モデル管理 most of
/// all, while the UI check samples the app's main thread at chosen moments
/// (fielua-reports design/settings-transition-performance.md). Nothing is
/// asked of the app by the test meanwhile.
///
/// Each moment is noted on the media clock (CACurrentMediaTime) in
/// tmp/settings-profile-marks.txt. Instruments' Time Profiler did not
/// record on CI's Macs (runs 43924676622 and 43930074980: xctrace attached
/// and never wrote its trace), so the UI check runs macOS's `sample` on the
/// app instead, the same kind of call stacks every millisecond, for two
/// seconds around each chosen moment: before it the app writes the
/// moment's name to tmp/settings-profile-want.txt and waits until the check
/// has started sampling (tmp/settings-profile-go-<name>), at most 40 s.
@MainActor enum SettingsProfileDemo {
    static let on = PreviewProbe.on("--settings-profile-demo")
    /// The sheet's next opening runs the pages' part.
    static var routeNext = false
    /// How many times the sheet comes up and goes down.
    static let cycles = 10

    private static let folder = FileManager.default.temporaryDirectory
    private static let file = folder.appendingPathComponent("settings-profile-marks.txt")

    static func mark(_ line: String) {
        let stamped = String(format: "%.4f ", CACurrentMediaTime()) + line + "\n"
        if let handle = try? FileHandle(forWritingTo: file) {
            handle.seekToEndOfFile()
            handle.write(Data(stamped.utf8))
            try? handle.close()
        } else {
            try? stamped.write(to: file, atomically: true, encoding: .utf8)
        }
    }

    /// Waits until the UI check samples the moment about to come.
    static func gate(_ name: String) async {
        let go = folder.appendingPathComponent("settings-profile-go-\(name)")
        try? (name + "\n").write(to: folder.appendingPathComponent("settings-profile-want.txt"), atomically: true, encoding: .utf8)
        let deadline = CACurrentMediaTime() + 40
        while !FileManager.default.fileExists(atPath: go.path), CACurrentMediaTime() < deadline {
            try? await Task.sleep(for: .milliseconds(20))
        }
        mark((FileManager.default.fileExists(atPath: go.path) ? "SAMPLED " : "UNSAMPLED ") + name)
    }

    /// The history opened, 設定 from its gear, 閉じる, the history closed,
    /// again and again; then 設定 once more for its pages. The first
    /// openings, the tenth and the second closing are sampled.
    static func run(drawer: @escaping (Bool) -> Void, sheet: @escaping (Bool) -> Void) async {
        try? await Task.sleep(for: .seconds(3))
        for cycle in 1...cycles {
            drawer(true)
            try? await Task.sleep(for: .milliseconds(900))
            if [1, 2, 3, cycles].contains(cycle) { await gate("sheet-open-\(cycle)") }
            mark("SHEET-OPEN \(cycle)")
            sheet(true)
            try? await Task.sleep(for: .milliseconds(2200))
            if cycle == 2 { await gate("sheet-close-\(cycle)") }
            mark("SHEET-CLOSE \(cycle)")
            sheet(false)
            try? await Task.sleep(for: .milliseconds(1100))
            drawer(false)
            try? await Task.sleep(for: .milliseconds(900))
        }
        routeNext = true
        mark("SHEET-OPEN route")
        sheet(true)
    }

    /// The pages' slides that are sampled: モデル管理's first three in and
    /// its first back, Gemma's page's first two in and first back, and the
    /// first of each other page.
    static func samples(_ step: String, time: Int) -> Bool {
        switch step {
        case "models-open": time <= 3
        case "gemma-open": time <= 2
        case "models-back", "gemma-back", "web-open", "history-open", "keyboard-open": time == 1
        default: false
        }
    }

    /// Called by the sheet once its pages have come and gone.
    static func finish(close: () -> Void) async {
        mark("SHEET-CLOSE route")
        close()
        try? await Task.sleep(for: .milliseconds(1500))
        mark("DONE")
    }
}
