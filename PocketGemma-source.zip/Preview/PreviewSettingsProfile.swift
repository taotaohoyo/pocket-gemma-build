import SwiftUI
import QuartzCore

/// `--settings-profile-demo` (1.1.0 (291)): 設定 opened and closed by the
/// app itself, as Hachimoto さん goes there (the history, its gear, 閉じる, the
/// chat, the history again), then its pages in and out, モデル管理 most of
/// all, while the UI check records Instruments' Time Profiler on the app
/// (fielua-reports design/settings-transition-performance.md). Nothing is
/// asked of the app by the test meanwhile.
///
/// Each moment is noted on the media clock (CACurrentMediaTime) in
/// tmp/settings-profile-marks.txt. The profile has a clock of its own, so
/// the app also spins its main thread for 40 ms in `syncPulse` at the start
/// and at the end: the samples inside it put the two clocks side by side.
@MainActor enum SettingsProfileDemo {
    static let on = PreviewProbe.on("--settings-profile-demo")
    /// The sheet's next opening runs the pages' part.
    static var routeNext = false
    /// How many times the sheet comes up and goes down.
    static let cycles = 10

    private static let file = FileManager.default.temporaryDirectory.appendingPathComponent("settings-profile-marks.txt")

    static func mark(_ line: String) {
        let stamped = String(format: "%.4f ", CACurrentMediaTime()) + line + "\n"
        if let handle = try? FileHandle(forWritingTo: file) {
            handle.seekToEndOfFile()
            handle.write(Data(stamped.utf8))
            try? handle.close()
        } else {
            try? stamped.write(to: file, atomically: true, encoding: .utf8)
        }
    }

    /// The two clocks side by side: the media clock while the main thread
    /// is held here, where the profile's samples name this function.
    static func pulse(_ label: String) {
        let start = CACurrentMediaTime()
        fieluaProfileSyncPulse(until: start + 0.04)
        mark(String(format: "SYNC %@ start=%.4f end=%.4f date=%.4f", label, start, CACurrentMediaTime(), Date().timeIntervalSince1970))
    }

    /// The history opened, 設定 from its gear, 閉じる, the history closed,
    /// again and again; then 設定 once more for its pages.
    static func run(drawer: @escaping (Bool) -> Void, sheet: @escaping (Bool) -> Void) async {
        // Time for the UI check to attach the profiler.
        try? await Task.sleep(for: .seconds(14))
        pulse("start")
        for cycle in 1...cycles {
            drawer(true)
            try? await Task.sleep(for: .milliseconds(900))
            mark("SHEET-OPEN \(cycle)")
            sheet(true)
            try? await Task.sleep(for: .milliseconds(2200))
            mark("SHEET-CLOSE \(cycle)")
            sheet(false)
            try? await Task.sleep(for: .milliseconds(1100))
            drawer(false)
            try? await Task.sleep(for: .milliseconds(900))
        }
        routeNext = true
        mark("SHEET-OPEN route")
        sheet(true)
    }

    /// Called by the sheet once its pages have come and gone.
    static func finish(close: () -> Void) async {
        mark("SHEET-CLOSE route")
        close()
        try? await Task.sleep(for: .milliseconds(1500))
        pulse("end")
        mark("DONE")
    }
}

/// Held busy for the profile's clock (SettingsProfileDemo.pulse); its name
/// is what the summary looks for in the samples.
@inline(never) @_optimize(none)
func fieluaProfileSyncPulse(until end: CFTimeInterval) {
    var spins = 0
    while CACurrentMediaTime() < end { spins &+= 1 }
    if spins == -1 { print(spins) }
}
