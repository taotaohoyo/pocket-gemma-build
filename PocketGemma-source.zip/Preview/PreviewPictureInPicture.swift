import SwiftUI
import UIKit
import AVKit
import AVFoundation

/// UI checks only (`--pip-video`): a short looping video, made at launch,
/// that the check puts into Picture in Picture, so a send can be checked
/// with a PiP window over the chat. On the phone another app's PiP turned
/// the lower half black after a send (2026-10-25, 1.1.0 (184)).
struct PreviewPictureInPicture: View {
    @StateObject private var pip = PreviewPiP()
    var body: some View {
        HStack(spacing: 8) {
            PlayerLayerView(pip: pip).frame(width: 96, height: 54)
            Button("PiP") { pip.start() }
                .font(.caption2).buttonStyle(.bordered)
                .accessibilityIdentifier("pip-start")
            Text(verbatim: pip.state).font(.system(size: 9))
                .accessibilityIdentifier("pip-state")
        }
        .padding(4).background(.background)
        .padding(.top, 50)
        .task { await pip.prepare() }
    }
}

@MainActor private final class PreviewPiP: NSObject, ObservableObject, AVPictureInPictureControllerDelegate {
    @Published var state = "準備中"
    let playerLayer = AVPlayerLayer()
    private var player: AVQueuePlayer?
    private var looper: AVPlayerLooper?
    private var controller: AVPictureInPictureController?
    private var possible: NSKeyValueObservation?

    func prepare() async {
        guard player == nil else { return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
            let url = try await Self.makeVideo()
            let player = AVQueuePlayer()
            player.isMuted = true
            looper = AVPlayerLooper(player: player, templateItem: AVPlayerItem(url: url))
            playerLayer.player = player
            player.play()
            self.player = player
            guard AVPictureInPictureController.isPictureInPictureSupported(),
                  let controller = AVPictureInPictureController(playerLayer: playerLayer) else {
                state = "PiP非対応"; return
            }
            controller.delegate = self
            self.controller = controller
            state = "待機"
            possible = controller.observe(\.isPictureInPicturePossible, options: [.initial, .new]) { [weak self] controller, _ in
                let can = controller.isPictureInPicturePossible
                Task { @MainActor in
                    guard let self, self.state == "待機" || self.state == "開始できる" else { return }
                    self.state = can ? "開始できる" : "待機"
                }
            }
        } catch {
            state = "失敗 \((error as NSError).code)"
        }
    }

    func start() { controller?.startPictureInPicture() }

    nonisolated func pictureInPictureControllerDidStartPictureInPicture(_ controller: AVPictureInPictureController) {
        Task { @MainActor in self.state = "表示中" }
    }
    nonisolated func pictureInPictureController(_ controller: AVPictureInPictureController,
                                                failedToStartPictureInPictureWithError error: Error) {
        let code = (error as NSError).code
        Task { @MainActor in self.state = "開始失敗 \(code)" }
    }
    nonisolated func pictureInPictureControllerDidStopPictureInPicture(_ controller: AVPictureInPictureController) {
        Task { @MainActor in self.state = "終了" }
    }

    /// Two seconds of colour that changes each frame, 320×180 at 30 fps.
    private static func makeVideo() async throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("pip-check.mp4")
        try? FileManager.default.removeItem(at: url)
        let writer = try AVAssetWriter(outputURL: url, fileType: .mp4)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: 320, AVVideoHeightKey: 180])
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: 320, kCVPixelBufferHeightKey as String: 180])
        writer.add(input)
        writer.startWriting()
        writer.startSession(atSourceTime: .zero)
        for frame in 0..<60 {
            while !input.isReadyForMoreMediaData { try await Task.sleep(for: .milliseconds(5)) }
            guard let pool = adaptor.pixelBufferPool else { break }
            var made: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &made)
            guard let buffer = made else { break }
            CVPixelBufferLockBaseAddress(buffer, [])
            if let base = CVPixelBufferGetBaseAddress(buffer) {
                let bytes = CVPixelBufferGetBytesPerRow(buffer) * CVPixelBufferGetHeight(buffer)
                let pixels = base.bindMemory(to: UInt32.self, capacity: bytes / 4)
                let blue = UInt32(40 + frame * 3), green = UInt32(200 - frame * 2)
                let colour = 0xFF00_0000 | (UInt32(30) << 16) | (green << 8) | blue
                for index in 0..<(bytes / 4) { pixels[index] = colour }
            }
            CVPixelBufferUnlockBaseAddress(buffer, [])
            adaptor.append(buffer, withPresentationTime: CMTime(value: CMTimeValue(frame), timescale: 30))
        }
        input.markAsFinished()
        await writer.finishWriting()
        return url
    }
}

private struct PlayerLayerView: UIViewRepresentable {
    let pip: PreviewPiP
    func makeUIView(context: Context) -> PlayerHost {
        let view = PlayerHost()
        view.playerLayer = pip.playerLayer
        return view
    }
    func updateUIView(_ view: PlayerHost, context: Context) {}
}

private final class PlayerHost: UIView {
    var playerLayer: AVPlayerLayer? {
        didSet { if let playerLayer { layer.addSublayer(playerLayer) } }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        playerLayer?.frame = bounds
    }
}
