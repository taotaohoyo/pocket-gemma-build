import SwiftUI

/// Launch switches that turn one suspect off at a time, for finding what
/// froze the preview app while a long chat scrolled up (UI check, 1.0.59).
enum PreviewProbe {
    private static let arguments = Set(ProcessInfo.processInfo.arguments)
    static func on(_ flag: String) -> Bool { arguments.contains(flag) }
}

/// The reply bubble's text selection, which `--probe-no-selection` removes.
struct ProbeTextSelection: ViewModifier {
    func body(content: Content) -> some View {
        if PreviewProbe.on("--probe-no-selection") { content } else { content.textSelection(.enabled) }
    }
}
