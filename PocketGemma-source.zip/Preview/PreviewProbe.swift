import Foundation

/// Launch switches that turn one suspect off at a time, for finding what
/// froze the preview app while a long chat scrolled up (UI check, 1.0.59).
enum PreviewProbe {
    private static let arguments = Set(ProcessInfo.processInfo.arguments)
    static func on(_ flag: String) -> Bool { arguments.contains(flag) }
}
