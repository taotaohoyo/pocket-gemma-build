import Foundation

/// UI checks only: replies for the Aurora Orb's glimpse (1.1.0 (297)), at a
/// model's pace after a short wait, so the orb breathes, shows the reply's
/// first words under it, leaves, and the text follows.
/// `--glimpse-long` a long reply at about 55 characters a second;
/// `--glimpse-short` a one-line reply that ends while its phrase shows;
/// `--glimpse-markdown` a heading, bold words and a list;
/// `--glimpse-code` a reply that begins with code (no glimpse);
/// `--glimpse-slow` a slow model, about 16 characters a second;
/// `--glimpse-fail` the long reply failing about a second after its first
/// text, while its phrase shows; `--glimpse-stop` the long reply stopped
/// 0.6 s after its first text, as 停止する stops it;
/// `--glimpse-english` an English reply. With `--glimpse-slow-motion` the
/// model writes four times slower too, so the glimpse's slowed times
/// still fall while it writes.
enum PreviewGlimpse {
    struct Reply {
        /// The reply's text, in the pieces it comes in.
        let chunks: [String]
        /// Milliseconds between pieces, and before the first.
        let delay: Int
        let wait: Int
        /// It fails, or is stopped, after this many pieces.
        var failsAfter: Int? = nil
        var stopsAfter: Int? = nil
    }

    static let long = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。\n\nただし、まだ誤りが多く、実用化には時間がかかると考えられています。いまは、誤りを直す技術と、少ない量子ビットでも役立つ使い方の両方が研究されています。\n\nこれからの数年で、どの分野から使われ始めるのかが注目されています。"
    static let short = "はい、できます。どうぞお使いください。"
    static let markdown = "## 量子コンピュータとは\n\n**量子ビット**を使って計算する、新しい仕組みのコンピュータです。\n\n- 薬の候補探し\n- 物流の最適化\n"
    static let code = "```swift\nlet answer = 42\nprint(answer)\n```\n\nこのコードは、答えを表示します。"
    static let english = "Quantum computers use qubits, which can hold many states at once. They may help with chemistry and logistics, but errors are still common."

    /// The glimpse reply the launch asked for, if any.
    static var current: Reply? {
        let on = PreviewProbe.on
        let slow = on("--glimpse-slow-motion") ? 4 : 1
        if on("--glimpse-long") { return Reply(chunks: pieces(long, size: 3), delay: 55 * slow, wait: 1500) }
        if on("--glimpse-short") { return Reply(chunks: pieces(short, size: 2), delay: 70 * slow, wait: 1500) }
        if on("--glimpse-markdown") { return Reply(chunks: pieces(markdown, size: 2), delay: 50 * slow, wait: 1500) }
        if on("--glimpse-code") { return Reply(chunks: pieces(code, size: 2), delay: 50 * slow, wait: 1500) }
        if on("--glimpse-slow") {
            let first = String(long.prefix { $0 != "\n" })
            return Reply(chunks: pieces(first, size: 1), delay: 62 * slow, wait: 1500)
        }
        if on("--glimpse-fail") { return Reply(chunks: pieces(long, size: 3), delay: 55 * slow, wait: 1500, failsAfter: 18) }
        if on("--glimpse-stop") { return Reply(chunks: pieces(long, size: 3), delay: 55 * slow, wait: 1500, stopsAfter: 11) }
        if on("--glimpse-english") { return Reply(chunks: pieces(english, size: 4), delay: 55 * slow, wait: 1500) }
        return nil
    }

    /// The text cut into pieces of `size` characters, as tokens come.
    private static func pieces(_ text: String, size: Int) -> [String] {
        var result: [String] = []
        var rest = Substring(text)
        while !rest.isEmpty {
            result.append(String(rest.prefix(size)))
            rest = rest.dropFirst(size)
        }
        return result
    }
}
