import XCTest

/// PCと接続 (1.1.0 (253)) against the stand-in PC that scripts/check-ui.sh
/// starts for the pc-link scope (scripts/fake-fielua-pc.py): the same
/// Fielua Link v1 as Fielua for Windows, over TLS 1.3 to its own
/// certificate, on this Mac. Registration with the connection code and the
/// six digits, the PC's models, a chat answered by the PC with the earlier
/// turns it was given, a stop, back to the phone's model, and 接続を解除
/// with the chats kept. From 1.1.0 (254): the PC chosen in the list (the
/// stand-in listed as Bonjour would), digits that differ withdrawing the
/// registration, the same digits approved on both screens, and what the
/// page says when the registered PC doesn't answer. Screenshots as SHOT
/// pc-*, lines as PC-LINK.
final class PCLinkUITests: XCTestCase {
    /// As check-ui.sh starts the stand-in PC.
    private let address = "127.0.0.1:47870"
    private let code = "24681357"

    @MainActor func testPCLinkRegisterChatStopAndUnpair() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--pc-link-reset"]
        app.launch()

        // 設定 › PCと接続, no PC yet.
        openPCLink(app)
        XCTAssertTrue(app.buttons["pc-link-code"].waitForExistence(timeout: 5))
        capture("pc-link-empty", app: app)

        // The connection code and the PC's address, then the six digits.
        app.buttons["pc-link-code"].tap()
        let codeField = app.textFields["pc-pair-code"]
        XCTAssertTrue(codeField.waitForExistence(timeout: 5))
        codeField.tap(); codeField.typeText(code)
        let addressField = app.textFields["pc-pair-address"]
        addressField.tap(); addressField.typeText(address)
        capture("pc-pair-code", app: app)
        app.buttons["pc-pair-connect"].tap()
        let number = app.staticTexts["pc-pair-number"]
        XCTAssertTrue(number.waitForExistence(timeout: 15), "the PC answered and both sides have the six digits")
        // check-ui.sh compares it with the stand-in PC's FAKE-PC SAS line.
        print("PC-LINK number=\(number.label)")
        capture("pc-pair-number", app: app)
        // The same digits here; the stand-in PC approves a few seconds
        // later, as its person would. Registered once both have.
        let match = app.buttons["pc-pair-match"]
        XCTAssertTrue(match.waitForExistence(timeout: 5))
        match.tap()
        let done = app.staticTexts["pc-pair-done"]
        XCTAssertTrue(done.waitForExistence(timeout: 30), "approved on the PC")
        print("PC-LINK paired '\(done.label)'")
        capture("pc-pair-done", app: app)
        app.buttons["pc-pair-finish"].tap()

        // The PC, whether it answers, and its models.
        XCTAssertTrue(app.staticTexts["pc-link-name"].waitForExistence(timeout: 5))
        let use = app.buttons["pc-link-use-gemma3:4b"]
        XCTAssertTrue(use.waitForExistence(timeout: 15), "the PC's models are listed")
        let status = app.descendants(matching: .any).matching(identifier: "pc-link-status").firstMatch
        print("PC-LINK status='\(status.exists ? status.label : "none")' models=\(app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'pc-link-use-'")).count)")
        capture("pc-link-paired", app: app)
        use.tap()
        // The sheet closes onto the history it was opened from (as モデル管理's
        // このモデルで会話を始める does); back to the new chat.
        let veil = app.descendants(matching: .any)["history-close"]
        if veil.waitForExistence(timeout: 3) { veil.tap() }

        // A chat answered by the PC.
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 8))
        Thread.sleep(forTimeInterval: 0.8)
        let line = app.staticTexts["chat-model-line"]
        print("PC-LINK chat line='\(line.exists ? line.label : "none")' header='\(String(describing: app.buttons["chat-model-settings"].value))'")
        capture("pc-chat-empty", app: app)
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        let first = app.staticTexts["テスト用のPCが答えています。受け取った発言は1件です。"]
        XCTAssertTrue(first.waitForExistence(timeout: 20), "the PC's reply streamed in")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10) || app.buttons["chat-add-menu"].exists)
        capture("pc-chat-reply", app: app)

        // Stopped while the PC writes: what came stays, marked stopped.
        input.tap(); input.typeText("長く話して")
        app.buttons["送信する"].tap()
        let stop = app.buttons["停止する"]
        XCTAssertTrue(stop.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 3)
        stop.tap()
        XCTAssertTrue(app.staticTexts["停止しました"].waitForExistence(timeout: 10), "the reply stopped")
        capture("pc-chat-stopped", app: app)

        // The next question gets the first exchange and itself: a stopped
        // reply and its question are not sent back.
        Thread.sleep(forTimeInterval: 1)
        input.tap(); input.typeText("もう一度")
        app.buttons["送信する"].tap()
        let third = app.staticTexts["テスト用のPCが答えています。受け取った発言は3件です。"]
        XCTAssertTrue(third.waitForExistence(timeout: 20), "the earlier complete exchange went with the question")
        capture("pc-chat-context", app: app)

        // The model menu has the PC's models; a phone model starts a chat on
        // the phone again.
        input.tap()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 5))
        print("PC-LINK pill='\(chip.label)' value='\(String(describing: chip.value))'")
        chip.tap()
        let pcMenu = menuItem("model-menu-pc", "テスト用PC", app)
        XCTAssertTrue(pcMenu.waitForExistence(timeout: 4), "the PC's models are in the model menu")
        print("PC-LINK model menu pc='\(pcMenu.label)'")
        capture("pc-model-menu", app: app)
        let gemma = menuItem("model-menu-gemma", "Gemma 4", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        gemma.tap()
        let e4b = menuItem("model-menu-gemma-4-e4b", "Gemma 4 E4B", app)
        XCTAssertTrue(e4b.waitForExistence(timeout: 3))
        e4b.tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        let phoneLine = app.staticTexts["chat-model-line"]
        print("PC-LINK back on the phone line='\(phoneLine.exists ? phoneLine.label : "none")'")
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 10),
                      "the phone's model answers")
        capture("pc-back-on-phone", app: app)

        // 接続を解除: the PC forgets this iPhone, the chats stay.
        openPCLink(app)
        unpair(app)
        capture("pc-link-unpaired", app: app)
        app.buttons["settings-close"].tap()
        XCTAssertTrue(gone(app.buttons["pc-link-code"], timeout: 4))

        // The PC chat is still in the history (ChatStore never removes it).
        let sidebar = app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
        if !sidebar.waitForExistence(timeout: 2) { app.buttons["会話一覧を開く"].tap() }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        let named = sidebar.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "こんにちは")).count
        print("PC-LINK history after unpair: \(named) rows name こんにちは")
        capture("pc-history-after-unpair", app: app)
    }

    /// 1.1.0 (254): the PC chosen in the list. Digits said to differ end
    /// it on both sides; the same digits, approved on the PC and here,
    /// register it.
    @MainActor func testPCLinkChoosingThePCConfirmsOnBothScreens() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--pc-link-reset", "--pc-link-found=\(address)"]
        app.launch()
        openPCLink(app)
        let row = app.buttons["pc-link-found-fakepc0123456789"]
        XCTAssertTrue(row.waitForExistence(timeout: 8), "the PC on this network is listed")
        capture("pc-link-found", app: app)

        // Digits that differ: nothing is registered, and the PC is told.
        row.tap()
        let number = app.staticTexts["pc-pair-number"]
        XCTAssertTrue(number.waitForExistence(timeout: 15), "the PC answered without a code")
        print("PC-LINK number=\(number.label)")
        capture("pc-pair-select-number", app: app)
        app.buttons["pc-pair-mismatch"].tap()
        let failed = app.staticTexts["pc-pair-failed"]
        XCTAssertTrue(failed.waitForExistence(timeout: 8))
        print("PC-LINK mismatch '\(failed.label)'")
        capture("pc-pair-mismatch", app: app)

        // Again, the same digits here, then the PC's approval.
        app.buttons["pc-pair-retry"].tap()
        XCTAssertTrue(number.waitForExistence(timeout: 15))
        print("PC-LINK number=\(number.label)")
        app.buttons["pc-pair-match"].tap()
        let waiting = app.descendants(matching: .any).matching(identifier: "pc-pair-waiting").firstMatch
        print("PC-LINK waiting for the PC=\(waiting.waitForExistence(timeout: 3))")
        capture("pc-pair-select-waiting", app: app)
        let done = app.staticTexts["pc-pair-done"]
        XCTAssertTrue(done.waitForExistence(timeout: 30), "approved on the PC as well")
        print("PC-LINK paired by choosing '\(done.label)'")
        app.buttons["pc-pair-finish"].tap()
        XCTAssertTrue(app.buttons["pc-link-use-gemma3:4b"].waitForExistence(timeout: 15), "the PC's models are listed")
        let status = app.descendants(matching: .any).matching(identifier: "pc-link-status").firstMatch
        print("PC-LINK chosen status='\(status.exists ? status.label : "none")'")
        capture("pc-link-paired-chosen", app: app)
        unpair(app)
    }

    /// 1.1.0 (254): a registered PC that doesn't answer (nothing listens at
    /// its address): the page says what the iPhone can see, first with the
    /// PC's hotspot as the network it last answered on, then without.
    @MainActor func testPCLinkSilentPCSaysWhatToCheck() {
        continueAfterFailure = false
        for (seed, shot) in [("127.0.0.1:47879,192.168.137.0/24", "pc-link-silent-hotspot"),
                             ("127.0.0.1:47879", "pc-link-silent")] {
            let app = PreviewApp()
            app.launchArguments = ["--reset-settings", "--pc-link-seed-silent=\(seed)"]
            app.launch()
            openPCLink(app)
            let problem = app.staticTexts["pc-link-problem"]
            XCTAssertTrue(problem.waitForExistence(timeout: 30), "the page says what to check")
            let status = app.descendants(matching: .any).matching(identifier: "pc-link-status").firstMatch
            print("PC-LINK silent seed=\(seed) status='\(status.exists ? status.label : "none")' problem='\(problem.label)'")
            capture(shot, app: app)
            unpair(app)
            app.terminate()
        }
    }

    // MARK: Helpers

    /// 接続を解除 on the page, through its dialog.
    @MainActor private func unpair(_ app: XCUIApplication) {
        let unpair = app.buttons["pc-link-unpair"]
        XCTAssertTrue(unpair.waitForExistence(timeout: 5))
        unpair.tap()
        // The dialog's own button; by its label (the last of the two) if
        // iOS's dialog leaves the identifier out.
        // iOS 26's dialog can list its button twice: the one that takes a tap.
        let confirms = app.buttons.matching(identifier: "pc-link-unpair-confirm")
        var confirm = confirms.firstMatch
        if confirm.waitForExistence(timeout: 4) {
            confirm = confirms.allElementsBoundByIndex.first { $0.isHittable } ?? confirm
        } else {
            let named = app.buttons.matching(NSPredicate(format: "label == %@", "接続を解除"))
            confirm = named.element(boundBy: max(named.count - 1, 0))
        }
        print("PC-LINK unpair dialog buttons=\(confirms.count) '\(confirm.label)'")
        confirm.tap()
        XCTAssertTrue(app.buttons["pc-link-code"].waitForExistence(timeout: 8), "no PC registered")
    }

    @MainActor private func openPCLink(_ app: XCUIApplication) {
        let history = app.buttons["会話一覧を開く"]
        XCTAssertTrue(history.waitForExistence(timeout: 10))
        history.tap()
        let gear = app.buttons["history-settings"]
        XCTAssertTrue(gear.waitForExistence(timeout: 4))
        gear.tap()
        let row = app.buttons["settings-row-pc"]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        // Read before the tap: the row is gone once its page is open.
        print("PC-LINK row value=\(String(describing: row.value))")
        row.tap()
        XCTAssertTrue(app.navigationBars["PCと接続"].waitForExistence(timeout: 4))
    }

    @MainActor private func menuItem(_ id: String, _ title: String, _ app: XCUIApplication) -> XCUIElement {
        guard !title.isEmpty else { return app.buttons[id] }
        return app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                                id, title, title + ",")).firstMatch
    }

    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed || !element.exists
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
