import XCTest

/// A question spoken into the chat (1.1.0 (236)), in the preview app,
/// which records a quiet tone instead of the microphone (VoiceRecorder):
/// with LFM3-Omni 2B and nothing to send, send is the waveform; a tap
/// records under the recording strip, the red stop ends it and the
/// recording joins the draft, playable, and is sent as a voice message;
/// 録音をやめる drops it. The folded composer's waveform records on Omni
/// and, on another model, says which model hears a voice. Light and dark
/// (SHOT voice-*), VOICE lines for review.
final class VoiceInputUITests: XCTestCase {
    @MainActor func testVoiceInputLight() { voiceInput("light", []) }
    @MainActor func testVoiceInputDark() { voiceInput("dark", ["--dark"]) }
    @MainActor func testFoldedVoiceButtonLight() { foldedVoice("light", []) }

    @MainActor private func voiceInput(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--omni"] + flags; app.launch()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 10))
        XCTAssertEqual(chip.value as? String, "LFM3-Omni 2B")
        let record = app.buttons["話しかける"]
        XCTAssertTrue(record.waitForExistence(timeout: 5), "with nothing to send, send is the waveform")
        XCTAssertTrue(record.isEnabled)
        XCTAssertFalse(app.buttons["送信する"].exists)
        Thread.sleep(forTimeInterval: 0.8)
        capture("voice-\(variant)-idle", app: app)
        print("VOICE \(variant) idle record=\(record.frame)")

        // Dropped: nothing joins the draft.
        record.tap()
        let stop = app.buttons["録音を止める"]
        XCTAssertTrue(stop.waitForExistence(timeout: 5))
        let strip = app.descendants(matching: .any)["voice-recording"]
        XCTAssertTrue(strip.waitForExistence(timeout: 3), "the recording strip shows over the field")
        Thread.sleep(forTimeInterval: 0.6)
        app.buttons["録音をやめる"].tap()
        XCTAssertTrue(record.waitForExistence(timeout: 5), "dropped: the waveform again")
        XCTAssertFalse(app.buttons["voice-note"].exists, "nothing joined the draft")

        // Recorded: it joins the draft, and send takes it.
        record.tap()
        XCTAssertTrue(stop.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 2.2)
        capture("voice-\(variant)-recording", app: app)
        print("VOICE \(variant) recording strip=\(strip.frame) label='\(strip.label)' value='\(strip.value as? String ?? "")' stop=\(stop.frame)")
        stop.tap()
        let staged = app.buttons["voice-note"]
        XCTAssertTrue(staged.waitForExistence(timeout: 5), "the recording joins the draft")
        XCTAssertTrue(staged.label.hasPrefix("音声 0:0"), staged.label)
        XCTAssertFalse(strip.exists)
        let send = app.buttons["送信する"]
        XCTAssertTrue(send.waitForExistence(timeout: 3)); XCTAssertTrue(send.isEnabled)
        XCTAssertFalse(record.exists, "one recording a send")
        Thread.sleep(forTimeInterval: 0.6)
        capture("voice-\(variant)-staged", app: app)
        print("VOICE \(variant) staged label='\(staged.label)' frame=\(staged.frame) send=\(send.frame)")
        staged.tap()
        Thread.sleep(forTimeInterval: 0.4)
        print("VOICE \(variant) playing value='\(staged.value as? String ?? "")'")
        staged.tap()
        send.tap()
        let reply = app.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", "音声0:0")).firstMatch
        XCTAssertTrue(reply.waitForExistence(timeout: 15), "the reply had the recording")
        XCTAssertTrue(record.waitForExistence(timeout: 15), "after the reply, the waveform again")
        Thread.sleep(forTimeInterval: 1.0)
        let sent = app.buttons.matching(identifier: "voice-note").firstMatch
        XCTAssertTrue(sent.exists, "the sent recording stays in its message")
        capture("voice-\(variant)-sent", app: app)
        print("VOICE \(variant) sent label='\(sent.label)' frame=\(sent.frame) reply='\(reply.label.prefix(120))'")

        // The model menu says what Omni takes in, in LFM (1.1.0 (269)),
        // whose line names it in use.
        chip.tap()
        let lfm = app.buttons["model-menu-lfm"]
        XCTAssertTrue(lfm.waitForExistence(timeout: 3))
        print("VOICE \(variant) menu lfm label='\(lfm.label)'")
        XCTAssertTrue(lfm.label.contains("LFM3-Omni 2Bを使用中"), lfm.label)
        lfm.tap()
        let omni = app.buttons.matching(NSPredicate(format: "identifier == %@ OR label BEGINSWITH %@",
                                                    "model-menu-lfm3-omni-2b", "LFM3-Omni 2B")).firstMatch
        XCTAssertTrue(omni.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture("voice-\(variant)-menu", app: app)
        print("VOICE \(variant) menu omni label='\(omni.label)' value='\(omni.value as? String ?? "")'")
    }

    /// Folded: on Omni the waveform opens the panel and records; on E4B it
    /// says which model hears a voice.
    @MainActor private func foldedVoice(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let omniApp = PreviewApp(); omniApp.launchArguments = ["--reset-settings", "--omni", "--long-chat", "--fold-button"] + flags
        omniApp.launch()
        XCTAssertTrue(omniApp.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        omniApp.buttons["probe-fold"].tap()
        let voice = omniApp.buttons["composer-voice"]
        XCTAssertTrue(voice.waitForExistence(timeout: 6))
        Thread.sleep(forTimeInterval: 1.5)
        voice.tap()
        XCTAssertTrue(omniApp.buttons["録音を止める"].waitForExistence(timeout: 6), "the panel opens recording")
        XCTAssertTrue(omniApp.descendants(matching: .any)["voice-recording"].exists)
        Thread.sleep(forTimeInterval: 1.2)
        capture("voice-\(variant)-folded-omni", app: omniApp)
        omniApp.buttons["録音を止める"].tap()
        XCTAssertTrue(omniApp.buttons["voice-note"].waitForExistence(timeout: 5))
        omniApp.terminate()

        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--long-chat", "--fold-button"] + flags
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["話しかける"].exists, "E4B hears no voice: send stays send")
        Thread.sleep(forTimeInterval: 1.0)
        app.buttons["probe-fold"].tap()
        XCTAssertTrue(app.buttons["composer-voice"].waitForExistence(timeout: 6))
        Thread.sleep(forTimeInterval: 1.5)
        app.buttons["composer-voice"].tap()
        let alert = app.alerts["音声入力"]
        XCTAssertTrue(alert.waitForExistence(timeout: 5))
        let message = alert.staticTexts.containing(NSPredicate(format: "label CONTAINS %@", "LFM3-Omni 2B")).firstMatch
        XCTAssertTrue(message.exists, "it names the model that hears a voice")
        XCTAssertTrue(alert.buttons["LFM3-Omni 2Bに切り替える"].exists)
        capture("voice-\(variant)-folded-guide", app: app)
        print("VOICE \(variant) guide '\(message.label)' buttons=\(alert.buttons.allElementsBoundByIndex.map(\.label))")
        alert.buttons["閉じる"].tap()
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
