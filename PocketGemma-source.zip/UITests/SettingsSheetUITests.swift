import XCTest

/// 設定's sheet (1.1.0 (290), Hachimoto さん's directive of 2026-11-16):
/// it comes up with its rise every time, from the history's gear right
/// after launch, again from the same history, after the history has been
/// closed and opened again, after a chat chosen in it, and from the chat's
/// model menu; and its paper is the chat's own, light and dark, on its
/// rows and on モデル管理, 会話履歴 and ウェブ検索, with the bar's buttons on
/// glass. Each way is tried as 289 had it and as now, one after the other
/// in the same run.
///
/// The app notes how each opening went (`--settings-present-probe`,
/// tmp/settings-present.txt, printed by the UI check as PRESENT lines):
/// whether UIKit's transition was animated and where the sheet stood at
/// each display beat while it rose and fell. The test's own MENU-MARK
/// lines time the frames cut from the recording.
final class SettingsSheetUITests: XCTestCase {
    /// 289 whole; 289's sheet held by the history, the rest now; 289's
    /// still sheet, held where it is now; and now.
    private static let riseVariants: [(name: String, flags: [String])] = [
        ("289", ["--settings-host-289", "--settings-still-289", "--settings-glass-289"]),
        ("host289", ["--settings-host-289"]),
        ("still289", ["--settings-still-289"]),
        ("290", []),
    ]

    @MainActor func testSettingsSheetRisesEveryTime() { risesEveryTime(Self.riseVariants) }

    /// Only as the app is now (1.1.0 (291)): the sheet still rises every
    /// time after the pages' slides changed.
    @MainActor func testSettingsSheetRisesEveryTimeNow() { risesEveryTime([("291", [])]) }

    @MainActor private func risesEveryTime(_ variants: [(name: String, flags: [String])]) {
        continueAfterFailure = true
        executionTimeAllowance = 420
        for variant in variants {
            let app = PreviewApp()
            app.launchArguments = ["--reset-settings", "--history-fixture", "--settings-present-probe"] + variant.flags
            app.launch()
            let open = app.buttons["会話一覧を開く"]
            XCTAssertTrue(open.waitForExistence(timeout: 10), "\(variant.name): the chat is up")
            Thread.sleep(forTimeInterval: 1.2)
            func history() {
                open.tap()
                XCTAssertTrue(sidebar(app).waitForExistence(timeout: 4), "\(variant.name): the history is open")
                Thread.sleep(forTimeInterval: 1.0)
            }
            // Right after launch, the history's first time.
            history()
            rise("\(variant.name)-1-first", app: app) { app.buttons["history-settings"].tap() }
            // Again from the same history.
            rise("\(variant.name)-2-again", app: app) { app.buttons["history-settings"].tap() }
            // The history closed and opened again.
            let strip = app.buttons["history-close"]
            XCTAssertTrue(strip.waitForExistence(timeout: 3))
            strip.tap()
            XCTAssertTrue(gone(sidebar(app), timeout: 4), "\(variant.name): the history has closed")
            Thread.sleep(forTimeInterval: 1.0)
            history()
            rise("\(variant.name)-3-reopened", app: app) { app.buttons["history-settings"].tap() }
            // A chat chosen in the history, then the history again.
            let chat = app.buttons["会話を開く: カメムシ対策"]
            XCTAssertTrue(chat.waitForExistence(timeout: 3), "\(variant.name): an older chat in the history")
            chat.tap()
            XCTAssertTrue(gone(sidebar(app), timeout: 4))
            Thread.sleep(forTimeInterval: 1.2)
            history()
            rise("\(variant.name)-4-after-chat", app: app) { app.buttons["history-settings"].tap() }
            // From the chat's model menu (モデルを管理), the chat's own copy.
            strip.tap()
            XCTAssertTrue(gone(sidebar(app), timeout: 4))
            Thread.sleep(forTimeInterval: 1.0)
            let pill = app.buttons["composer-model"]
            if pill.waitForExistence(timeout: 4) {
                pill.tap()
                let manage = app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                                              "model-menu-manage", "モデルを管理", "モデルを管理,")).firstMatch
                XCTAssertTrue(manage.waitForExistence(timeout: 3), "\(variant.name): モデルを管理 in the model menu")
                for _ in 0..<4 where !manage.isHittable { app.collectionViews.firstMatch.swipeUp() }
                Thread.sleep(forTimeInterval: 0.8)
                rise("\(variant.name)-5-model-menu", app: app) { manage.tap() }
            }
            // And the history once more after that.
            history()
            rise("\(variant.name)-6-history-last", app: app) { app.buttons["history-settings"].tap() }
            app.terminate()
        }
    }

    /// One opening and closing of 設定, by `tap`, each at a mark.
    /// 設定 sampled (1.1.0 (291), Hachimoto さん's directive of 2026-11-16 on
    /// how 設定's transitions feel): the app brings the history and 設定 up
    /// and down ten times by itself, then slides モデル管理 in and out ten
    /// times, Gemma's page over it, ウェブ検索, 会話履歴 and キーボードと入力
    /// (`--settings-profile-demo`), with nothing asked of it by the test
    /// meanwhile. Before the moments chosen it waits for the UI check to
    /// start macOS's `sample` on it (SettingsProfileDemo.gate); the check
    /// adds up each sample's main thread (scripts/sample-summary.py, SAMPLE
    /// lines). Instruments' Time Profiler did not record on CI's Macs. Twice:
    /// the series' marks drawn as shapes as until 290
    /// (`--series-mark-layers`), then as one picture each (291).
    @MainActor func testSettingsTransitionsProfiled() {
        continueAfterFailure = false
        executionTimeAllowance = 1700
        for way in [["--series-mark-layers"], []] {
            let app = PreviewApp()
            app.launchArguments = ["--reset-settings", "--history-fixture", "--settings-present-probe", "--settings-profile-demo"] + way
            app.launch()
            XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 12), "The chat is up")
            // 3 s, ten openings of about 5.1 s, 2 s, forty slides of about
            // 1.85 s each and the close: nothing is asked of the app
            // meanwhile. Then, as the samples take their time to be written,
            // looked for every 15 s.
            Thread.sleep(forTimeInterval: 3 + 10 * 5.2 + 2 + 40 * 1.85 + 6)
            let done = app.descendants(matching: .any).matching(identifier: "settings-profile-done").firstMatch
            for _ in 0..<40 where !done.exists { Thread.sleep(forTimeInterval: 15) }
            XCTAssertTrue(done.exists, "\(way): the app went through 設定 by itself")
            XCTAssertFalse(app.buttons["settings-close"].exists, "\(way): 設定 has closed once its pages have come and gone")
            app.terminate()
        }
    }

    @MainActor private func rise(_ name: String, app: XCUIApplication, tap: () -> Void) {
        menuMark("present-\(name)")
        tap()
        let close = app.buttons["settings-close"]
        XCTAssertTrue(close.waitForExistence(timeout: 6), "\(name): 設定 is open")
        // Past the rise and the probe's rest (0.35 s still).
        Thread.sleep(forTimeInterval: 1.8)
        menuMark("dismiss-\(name)")
        close.tap()
        XCTAssertTrue(gone(close, timeout: 5), "\(name): 設定 has closed")
        Thread.sleep(forTimeInterval: 1.2)
        print("SETTINGS-ROUND \(name) done")
    }

    /// The sheet's paper against the chat's, light and dark, 289's glass
    /// and now: the chat, then 設定's rows, モデル管理, 会話履歴 and ウェブ検索
    /// photographed (SHOT settings-paper-*), and the colour of a patch of
    /// paper on each (SETTINGS-PAPER lines, the median of each channel):
    /// beside the chat's at the screen's leading edge, and under each
    /// sheet's bar, where nothing is drawn on the paper.
    @MainActor func testSettingsPaperMatchesTheChat() {
        continueAfterFailure = true
        executionTimeAllowance = 420
        for mode in ["light", "dark"] {
            for (variant, flags) in [("289", ["--settings-glass-289"]), ("290", [String]())] {
                let name = "\(mode)-\(variant)"
                let app = PreviewApp()
                app.launchArguments = ["--reset-settings", "--history-fixture"] + (mode == "dark" ? ["--dark"] : []) + flags
                app.launch()
                let open = app.buttons["会話一覧を開く"]
                XCTAssertTrue(open.waitForExistence(timeout: 10))
                Thread.sleep(forTimeInterval: 1.5)
                let window = app.windows.firstMatch.frame
                let chat = paper(in: CGRect(x: 2, y: window.height * 0.45, width: 8, height: 120))
                capture("settings-paper-\(name)-0-chat", app: app)
                open.tap()
                XCTAssertTrue(sidebar(app).waitForExistence(timeout: 4))
                Thread.sleep(forTimeInterval: 1.0)
                app.buttons["history-settings"].tap()
                let close = app.buttons["settings-close"]
                XCTAssertTrue(close.waitForExistence(timeout: 6))
                Thread.sleep(forTimeInterval: 1.6)
                var line = "SETTINGS-PAPER \(name) chat=\(chat)"
                line += " rows=\(barPaper(close: close.frame, window: window))"
                capture("settings-paper-\(name)-1-rows", app: app)
                for (row, title) in [("models", "モデル管理"), ("chatHistory", "会話履歴"), ("webSearch", "ウェブ検索")] {
                    let button = app.buttons["settings-row-\(row)"]
                    XCTAssertTrue(button.waitForExistence(timeout: 4), "\(name): the \(title) row")
                    button.tap()
                    XCTAssertTrue(app.navigationBars[title].waitForExistence(timeout: 4), "\(name): \(title) is open")
                    Thread.sleep(forTimeInterval: 1.2)
                    let back = app.buttons["settings-back"]
                    XCTAssertTrue(back.exists, "\(name): 戻る on \(title)")
                    line += " \(row)=\(barPaper(close: close.frame, window: window))"
                    capture("settings-paper-\(name)-\(row)", app: app)
                    back.tap()
                    XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 4), "\(name): back on the rows")
                    Thread.sleep(forTimeInterval: 1.0)
                }
                print(line)
                close.tap()
                XCTAssertTrue(gone(close, timeout: 5))
                app.terminate()
            }
        }
    }

    /// Under the bar, beside the close button's foot: clear of the buttons,
    /// the titles and the rows on every page.
    @MainActor private func barPaper(close: CGRect, window: CGRect) -> String {
        paper(in: CGRect(x: window.width * 0.2, y: close.maxY + 3, width: window.width * 0.16, height: 6))
    }

    /// The median red, green and blue of a patch of the screen, in points.
    @MainActor private func paper(in rect: CGRect) -> String {
        let shot = XCUIScreen.main.screenshot().image
        guard let image = shot.cgImage, shot.size.width > 0 else { return "none" }
        let scale = CGFloat(image.width) / shot.size.width
        let pixels = CGRect(x: rect.minX * scale, y: rect.minY * scale, width: rect.width * scale, height: rect.height * scale).integral
        guard let crop = image.cropping(to: pixels) else { return "none" }
        let width = crop.width, height = crop.height
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(crop, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn, width * height > 0 else { return "none" }
        func median(_ channel: Int) -> Int {
            let values = stride(from: channel, to: bytes.count, by: 4).map { Int(bytes[$0]) }.sorted()
            return values[values.count / 2]
        }
        return String(format: "#%02X%02X%02X", median(0), median(1), median(2))
    }

    private func menuMark(_ name: String) {
        print(String(format: "MENU-MARK %@ %.3f", name, Date().timeIntervalSince1970))
    }

    @MainActor private func sidebar(_ app: XCUIApplication) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
    }

    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval = 3) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed || !element.exists
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
