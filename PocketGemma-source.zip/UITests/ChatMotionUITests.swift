import XCTest

final class ChatMotionUITests: XCTestCase {
    /// Stability gate after rolling back end-visibility observation. The stricter
    /// jump-button test below stays unchanged and its known failure is retained.
    @MainActor func testManualScrollAndComposerRemainResponsiveAfterGrowingReply() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--growing-reply", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Stability check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        XCTAssertEqual(input.value as? String, "")
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        let reading = app.scrollViews["chat-conversation"]
        func swipe(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, app.textViews["chat-input"].frame.minY - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipe(up: false); swipe(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        swipe(up: true); swipe(up: true)
        capture("manual-scroll-stability", app: app)
        // An input/edit after both drag directions proves that the event loop
        // still services interaction instead of spinning in lazy placement.
        input.tap(); input.typeText("Still responsive")
        XCTAssertEqual(input.value as? String, "Still responsive")
        XCTAssertTrue(app.keyboards.firstMatch.exists)
        capture("composer-responsive-after-manual-scroll", app: app)
    }

    @MainActor func testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition() throws {
        try mixedAttachmentStream([])
    }
    /// Probe: the same with every message a lazy row, as before 1.0.70.
    @MainActor func testProbeMixedAttachmentAllLazy() throws { try mixedAttachmentStream(["--probe-all-lazy"]) }
    /// Probe: the latest messages as one item of the lazy stack, as in 1.0.71.
    @MainActor func testProbeMixedAttachmentEagerItem() throws { try mixedAttachmentStream(["--probe-eager-item"]) }

    @MainActor private func mixedAttachmentStream(_ flags: [String]) throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--e2b", "--long-chat", "--attachment-fixtures", "--layout-stress", "--layout-metrics"] + flags
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        importFixture("sample-image", extension: "png", app: app)
        let draft = app.descendants(matching: .any).matching(identifier: "draft-attachments").firstMatch
        XCTAssertTrue(draft.waitForExistence(timeout: 5))
        XCTAssertLessThanOrEqual(draft.frame.height, 84)
        let preview = app.buttons["添付ファイルを開く: sample-image.png"]
        XCTAssertTrue(preview.exists)
        XCTAssertLessThanOrEqual(preview.frame.height, 76)
        capture("compact-image-draft", app: app)
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Layout stress")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["回答を停止する"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let reading = app.scrollViews["chat-conversation"]
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        reading.swipeDown(); reading.swipeDown()
        let jumpShown = app.buttons["chat-jump-latest"].waitForExistence(timeout: 4)
        let suffix = flags.isEmpty ? "" : "-probe"
        let swipedInk = readingInk(app)
        print("MIXED after-swipes\(suffix) ink=\(swipedInk) jump=\(jumpShown) \(debug.label.prefix(200))")
        capture("mixed-after-swipes" + suffix, app: app)
        XCTAssertTrue(jumpShown)
        XCTAssertGreaterThan(swipedInk, Self.drawnInk, "Scrolled up during a reply, the conversation must stay drawn")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 15))
        let streamedInk = readingInk(app)
        print("MIXED after-stream\(suffix) ink=\(streamedInk) jump=\(app.buttons["chat-jump-latest"].exists) \(debug.label.prefix(200))")
        capture("mixed-after-stream" + suffix, app: app)
        XCTAssertTrue(app.buttons["chat-jump-latest"].exists, "Finishing a stream must not move an older-message reader")
        XCTAssertGreaterThan(streamedInk, Self.drawnInk, "The finished reply must leave the conversation drawn")
        app.buttons["chat-jump-latest"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "レイアウト検証12：")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["layout-metrics-export"].tap()
        let json = try XCTUnwrap(app.buttons["layout-metrics-export"].value as? String)
        let data = try XCTUnwrap(json.data(using: .utf8))
        let metrics = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        // Keep the observations even when a layout assertion fails.
        let attachment = XCTAttachment(data: data, uniformTypeIdentifier: "public.json")
        attachment.name = "ui-layout-and-main-display-link-metrics"; attachment.lifetime = .keepAlways; add(attachment)
        XCTAssertGreaterThan((metrics["geometrySamples"] as? Int) ?? 0, 3)
        XCTAssertEqual((metrics["maximumLayoutOverlapPoints"] as? Double) ?? -1, 0, accuracy: 0.5)
        XCTAssertGreaterThan((metrics["displayLinkSamples"] as? Int) ?? 0, 0)
        capture("mixed-attachment-stream-layout", app: app)
    }

    @MainActor func testInlinePhotoDockAndRepeatedMenuOpenClose() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--e2b"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        // Let launch settle and each menu finish opening before the outside
        // tap, as the glass morph test does; a tap mid-morph can be dropped.
        Thread.sleep(forTimeInterval: 1.0)
        for _ in 0..<3 {
            app.buttons["chat-add-menu"].tap()
            XCTAssertTrue(menuItem("chat-attach-photos", "写真", app).waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            dismissMenu(menuItem("chat-attach-photos", "写真", app), app: app)
        }
        app.buttons["chat-add-menu"].tap(); menuItem("chat-attach-photos", "写真", app).tap()
        let dock = app.descendants(matching: .any).matching(identifier: "photo-dock").firstMatch
        XCTAssertTrue(dock.waitForExistence(timeout: 5))
        XCTAssertLessThan(dock.frame.height, app.frame.height * 0.5)
        XCTAssertGreaterThan(dock.frame.minY, app.buttons["chat-model-settings"].frame.maxY)
        XCTAssertTrue(app.textViews["chat-input"].isHittable)
        // Messages leaves clear room between the field and the card.
        sleep(1)
        let field = app.descendants(matching: .any)["chat-composer"]
        let gap = dock.frame.minY - field.frame.maxY
        print("PHOTO-SHEET gap: field=\(field.frame.maxY) sheet=\(dock.frame.minY) gap=\(gap)")
        capture("inline-photo-grid", app: app)
        // iMessage-style: tapping a photo adds it to the draft immediately.
        // First use shows the system's one-time "Private Access to Photos" note.
        let privacyOK = app.buttons["OK"]
        if privacyOK.waitForExistence(timeout: 12) { privacyOK.tap() }
        // The grid is a remote system view; its cells are not hittable
        // elements, so tap the first cell's center by coordinate.
        // While the library loads, the only image is the spinner.
        let loading = dock.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "読み込み中")).firstMatch
        if loading.exists {
            _ = XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"),
                                                                 object: loading)], timeout: 15)
        }
        let photo = dock.images.firstMatch
        let picked = photo.waitForExistence(timeout: 10)
        if picked {
            // The first tap can land while the grid is still settling, so
            // allow one more.
            let draft = app.descendants(matching: .any)["draft-attachments"]
            photo.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            if !draft.waitForExistence(timeout: 6) {
                print("PHOTO-SHEET first tap missed: photo=\(photo.frame) sheet=\(dock.frame)")
                photo.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            }
            XCTAssertTrue(draft.waitForExistence(timeout: 8),
                          "A tapped photo must appear in the draft without a confirm step")
            capture("inline-photo-picked", app: app)
        }
        // The card is a sheet, as in Messages: swiping up grows it to full
        // height and swiping down returns it to the compact card.
        let compactHeight = dock.frame.height
        let origin = app.coordinate(withNormalizedOffset: .zero)
        func drag(fromY y: CGFloat, by dy: CGFloat) {
            origin.withOffset(CGVector(dx: dock.frame.midX, dy: y))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: dock.frame.midX, dy: y + dy)),
                       withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        // Does a swipe on the grid itself resize the sheet? The grid is a
        // remote view, so this is reported rather than required.
        drag(fromY: dock.frame.midY + 40, by: -200)
        sleep(1)
        let afterGridSwipe = dock.frame.height
        print("PHOTO-SHEET grid swipe up: compact=\(compactHeight) after=\(afterGridSwipe)")
        if afterGridSwipe < compactHeight + 80 {
            // The grabber at the top edge always resizes the sheet.
            drag(fromY: dock.frame.minY + 6, by: -300)
            sleep(1)
        }
        let expandedHeight = dock.frame.height
        print("PHOTO-SHEET expanded: height=\(expandedHeight) top=\(dock.frame.minY)")
        XCTAssertGreaterThan(expandedHeight, compactHeight + 80,
                             "The card grows to full height (compact \(compactHeight), now \(expandedHeight))")
        // With a photo picked, full height shows Messages' done check.
        let done = app.buttons["photo-done"]
        if picked {
            XCTAssertTrue(done.waitForExistence(timeout: 3), "The done check appears once a photo is picked")
            print("PHOTO-SHEET done: frame=\(done.frame) sheet=\(dock.frame)")
        }
        capture("expanded-inline-photo-grid", app: app)
        drag(fromY: dock.frame.minY + 6, by: expandedHeight - compactHeight)
        sleep(1)
        print("PHOTO-SHEET collapsed: exists=\(dock.exists) height=\(dock.frame.height)")
        XCTAssertTrue(dock.exists, "Swiping down from full height returns to the card")
        XCTAssertEqual(dock.frame.height, compactHeight, accuracy: 4)
        XCTAssertFalse(done.exists, "The compact card is the bare grid")
        capture("photo-sheet-collapsed", app: app)
        if picked {
            // Done closes the picker and keeps the photo in the draft.
            drag(fromY: dock.frame.minY + 6, by: -300)
            XCTAssertTrue(done.waitForExistence(timeout: 3))
            done.tap()
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: dock)
            waitForExpectations(timeout: 4)
            XCTAssertTrue(app.descendants(matching: .any)["draft-attachments"].exists)
            app.buttons["chat-add-menu"].tap(); menuItem("chat-attach-photos", "写真", app).tap()
            XCTAssertTrue(dock.waitForExistence(timeout: 5))
        }
        // Like the keyboard it replaces, the panel closes when the field is tapped.
        app.textViews["chat-input"].tap()
        expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: dock)
        waitForExpectations(timeout: 4)
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
        // Checked last so a miss still leaves every screenshot above.
        XCTAssertEqual(gap, 21, accuracy: 3, "The card keeps Messages' gap below the field")
    }

    @MainActor func testHistorySettingsAndDeveloperVisibilityPersist() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--reset-settings"]; app.launch()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["history-settings"].tap()
        let toggle = app.switches["developer-settings-toggle"]
        // Hidden until revealed (three-finger swipes at the bottom; the test
        // build reveals it with a launch argument).
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 4))
        XCTAssertFalse(toggle.exists)
        app.terminate(); app.launchArguments = ["--developer-unlocked"]; app.launch()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap(); app.buttons["history-settings"].tap()
        revealModelControl(toggle, app: app)
        XCTAssertEqual(toggle.value as? String, "0")
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists)
        XCTAssertFalse(app.staticTexts["推論の診断"].exists)
        // AltStore updates and memory release are developer-only items.
        XCTAssertFalse(app.descendants(matching: .any)["update-source-card"].exists)
        XCTAssertFalse(app.buttons["AIのメモリを解放する"].exists)
        XCTAssertFalse(app.staticTexts["Claudeについて"].exists)
        capture("daily-settings-developer-off", app: app)
        let switchTop = toggle.frame.minY
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        XCTAssertTrue(app.staticTexts["推論の診断"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR developer switch top before \(switchTop) after on \(toggle.frame.minY)")
        XCTAssertEqual(toggle.frame.minY, switchTop, accuracy: 1, "What the switch adds appears below it")
        capture("history-developer-on", app: app)
        XCTAssertTrue(app.descendants(matching: .any)["update-source-card"].exists)
        XCTAssertTrue(app.buttons["AIのメモリを解放する"].exists)
        XCTAssertTrue(app.buttons["model-use-qwen3-06b"].exists, "Developer settings make Qwen usable")
        capture("developer-settings-visible", app: app)
        app.buttons["完了"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 1, "Opening settings must not create a chat")
        app.terminate(); app.launchArguments = []; app.launch()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap(); app.buttons["history-settings"].tap()
        revealModelControl(toggle, app: app)
        XCTAssertEqual(toggle.value as? String, "1")
        let onTop = toggle.frame.minY
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "0")
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertFalse(app.staticTexts["推論の診断"].exists)
        print("HISTORY-SIDEBAR developer switch top before \(onTop) after off \(toggle.frame.minY)")
        XCTAssertTrue(toggle.isHittable)
        // Turned off, the list ends at its last line: no empty page below it
        // (1.0.53 kept the taller list's height).
        let list = app.scrollViews["model-list"], footer = app.descendants(matching: .any)["model-list-footer"]
        for _ in 0..<4 { list.swipeUp() }
        Thread.sleep(forTimeInterval: 1)
        print("HISTORY-SIDEBAR model list end: footer=\(footer.frame) list=\(list.frame)")
        capture("history-developer-off-end", app: app)
        XCTAssertTrue(footer.isHittable, "The list's last line is on screen at its end")
        XCTAssertLessThan(list.frame.maxY - footer.frame.maxY, 140, "No blank space below the last line")
        app.buttons["完了"].tap(); app.buttons["history-settings"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertFalse(app.segmentedControls["execution-backend"].exists)
        XCTAssertFalse(app.textFields["setting-TopK"].exists)
        XCTAssertEqual(app.textFields["setting-Max Tokens"].value as? String, "4096")
        capture("basic-generation-settings", app: app)
    }

    @MainActor private func revealModelControl(_ control: XCUIElement, app: XCUIApplication) {
        for _ in 0..<15 { if control.exists && control.isHittable { break }; app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(control.isHittable)
    }

    @MainActor func testModelDeleteAsksFirstAndOffersDownloadAgain() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        let delete = app.buttons["model-delete-gemma-4-e2b"]
        revealModelControl(delete, app: app)
        capture("history-model-delete-button", app: app)
        delete.tap()
        let confirm = app.alerts.buttons["削除"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        capture("history-model-delete-alert", app: app)
        confirm.tap()
        XCTAssertTrue(app.buttons["model-download-gemma-4-e2b"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["model-delete-gemma-4-e2b"].exists)
        XCTAssertTrue(app.buttons["model-delete-gemma-4-e4b"].exists, "Other models keep theirs")
        capture("history-model-deleted", app: app)
    }

    /// The download's Live Activity from the Home Screen: the model's mark
    /// on the left of the Dynamic Island, the percentage on the right.
    @MainActor func testDownloadLiveActivityInDynamicIsland() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--download-activity"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-compact", height: 140)
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = "history-download-home"; screen.lifetime = .keepAlways; add(screen)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-expanded", height: 260)
        app.activate()
    }

    /// Two models at once share one activity: one model on each side of the
    /// island, and a row for each when it is pressed.
    @MainActor func testTwoDownloadLiveActivitiesInDynamicIsland() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--download-activity", "--download-activity-two"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started 2")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-two", height: 140)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-two-expanded", height: 260)
        app.activate()
    }

    /// Pulling past the end of a conversation, as in ChatGPT: a ring fills,
    /// turns into the new chat button, and letting go opens a new chat.
    @MainActor func testPullPastEndOpensNewChat() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--pull-snapshot"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let first = app.staticTexts["画面の動きを確認"]
        XCTAssertTrue(first.waitForExistence(timeout: 3))
        sleep(1)
        // A short pull springs back and keeps the conversation.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.6))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)),
                   withVelocity: .slow, thenHoldForDuration: 0.3)
        Thread.sleep(forTimeInterval: 1.2)
        XCTAssertTrue(first.exists, "A short pull keeps the conversation")
        XCTAssertFalse(app.staticTexts["メッセージを送って会話を始めましょう"].exists)
        // A long pull fills the ring; letting go there opens a new chat.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.72))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.22)),
                   withVelocity: .slow, thenHoldForDuration: 0.8)
        let snapshots = app.descendants(matching: .any)["pull-snapshots"]
        XCTAssertTrue(snapshots.waitForExistence(timeout: 3))
        print("HISTORY-SIDEBAR pull: \(snapshots.label)")
        capture("history-pull-snapshots", app: app)
        let snapshotCount = snapshots.label
        snapshots.tap()
        XCTAssertTrue(app.staticTexts["メッセージを送って会話を始めましょう"].waitForExistence(timeout: 3))
        XCTAssertFalse(first.exists, "The pull opened a new, empty chat")
        capture("history-pull-new-chat", app: app)
        XCTAssertEqual(snapshotCount, "pull snapshots 2", "The ring half full, then the button")
    }

    @MainActor private func captureScreenTop(_ name: String, height: CGFloat) {
        let image = XCUIScreen.main.screenshot().image
        guard let full = image.cgImage,
              let top = full.cropping(to: CGRect(x: 0, y: 0, width: CGFloat(full.width),
                                                 height: min(CGFloat(full.height), height * image.scale))) else { return }
        let attachment = XCTAttachment(image: UIImage(cgImage: top, scale: image.scale, orientation: .up))
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    @MainActor func testE4BAttachmentLocksAndE2BSwitchKeepDraft() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        input.tap(); input.typeText("Keep my draft")
        app.buttons["chat-add-menu"].tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 3))
        // System menu rows do not expose the "調整中" subtitle to XCUITest;
        // the lock is verified by the guidance that tapping opens below.
        XCTAssertTrue(menuItem("chat-attach-files", "ファイル", app).exists)
        XCTAssertTrue(menuItem("chat-attach-camera", "カメラ", app).exists)
        capture("e4b-locked-attachments", app: app)
        photos.tap()
        XCTAssertTrue(app.buttons["E2Bで新しい会話を開く"].waitForExistence(timeout: 3))
        app.buttons["E2Bで新しい会話を開く"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4))
        XCTAssertEqual(input.value as? String, "Keep my draft")
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        app.buttons["chat-add-menu"].tap()
        XCTAssertTrue(menuItem("chat-attach-photos", "写真", app).waitForExistence(timeout: 3))
        menuItem("chat-attach-photos", "写真", app).tap()
        // E2B: photos opens the inline picker, not the locked-item guidance.
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "photo-dock").firstMatch
            .waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["E2Bで新しい会話を開く"].exists)
        capture("e2b-attachments-available", app: app)
    }

    @MainActor func testSwitchFromE2BWithDraftAttachmentCannotSendToE4B() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--e2b", "--attachment-fixtures"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-image", app: app)
        XCTAssertTrue(app.buttons["添付を外す: sample-image.png"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        let e4b = app.buttons["model-use-gemma-4-e4b"]
        XCTAssertTrue(e4b.waitForExistence(timeout: 4)); e4b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.buttons["添付を外す: sample-image.png"].exists)
        XCTAssertFalse(app.buttons["送信する"].isEnabled)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Text still works")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Text still works"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 6))
        capture("e4b-text-after-attachment-switch", app: app)
    }

    @MainActor func testLargeTypeReducedMotionAttachmentMenuRemainsUsable() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--large-type", "--reduce-motion", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 4)); XCTAssertTrue(photos.isHittable)
        XCTAssertGreaterThanOrEqual(photos.frame.height, 44)
        capture("large-type-dark-locked-menu", app: app)
        photos.tap()
        XCTAssertTrue(app.buttons["E2Bで新しい会話を開く"].waitForExistence(timeout: 4))
        capture("large-type-attachment-guide", app: app)
        // Confirmation dialogs can adapt to a popover. UIKit omits the
        // cancel button there and exposes a native dismiss region instead.
        if app.buttons["閉じる"].exists { app.buttons["閉じる"].tap() }
        else if app.buttons["Cancel"].exists { app.buttons["Cancel"].tap() }
        else {
            let dismiss = app.otherElements["PopoverDismissRegion"]
            XCTAssertTrue(dismiss.waitForExistence(timeout: 3)); dismiss.tap()
        }
        XCTAssertFalse(app.buttons["E2Bで新しい会話を開く"].exists)
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].exists, "Dismissing must not switch models")
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
    }

    @MainActor func testFirstLaunchModelChoiceAndCompletionPersist() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--startup", "--reset-startup"]
        app.launch()
        XCTAssertTrue(app.buttons["startup-skip"].waitForExistence(timeout: 10))
        capture("first-launch-models", app: app)
        // Only Gemma is offered at first launch; Qwen is developer-only.
        XCTAssertFalse(app.buttons["startup-model-qwen3-06b"].exists)
        let choice = app.buttons["startup-model-gemma-4-e2b"]
        let list = app.scrollViews["startup-model-list"]
        for _ in 0..<5 {
            if choice.exists && choice.isHittable && choice.frame.minY >= list.frame.minY
                && choice.frame.maxY < app.buttons["startup-continue"].frame.minY { break }
            list.swipeUp()
        }
        XCTAssertTrue(choice.isHittable); choice.tap()
        capture("first-launch-qwen-gauges", app: app)
        XCTAssertTrue(app.buttons["startup-continue"].isEnabled)
        app.buttons["startup-continue"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 5))
        app.terminate(); app.launchArguments = ["--startup"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["startup-skip"].exists)
    }

    @MainActor func testShortConversationAndGrowingReplyStayStableWithKeyboard() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--growing-reply", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        let firstY = modelName.frame.minY
        input.typeText("Short send")
        XCTAssertEqual(modelName.frame.minY, firstY, accuracy: 3, "Typing in a short chat must not reposition its content")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Short send"].waitForExistence(timeout: 4))
        XCTAssertEqual(input.value as? String, "")
        XCTAssertFalse(app.keyboards.firstMatch.exists, "Successful send must close the keyboard")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        // E4B no longer shows an attachment note above the field.
        XCTAssertFalse(app.buttons["chat-switch-e2b"].exists)
        func readingBottom() -> CGFloat { input.frame.minY }
        XCTAssertLessThanOrEqual(reply.frame.maxY, readingBottom())
        capture("short-send-long-reply-keyboard", app: app)
        let reading = app.scrollViews["chat-conversation"]
        // The scroll view extends behind the bars and keyboard. Its default
        // swipe coordinates can hit those controls instead of the text area.
        func swipeReading(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, readingBottom() - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipeReading(up: false); swipeReading(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        for _ in 0..<8 {
            if reply.exists && reply.frame.maxY <= readingBottom()
                && reply.frame.maxY > readingBottom() - 32 { break }
            swipeReading(up: true)
        }
        let observations: [String: Any] = ["replyBottom": reply.frame.maxY,
            "inputTop": input.frame.minY,
            "readingBottom": readingBottom(), "jumpVisible": app.buttons["chat-jump-latest"].exists]
        if let bytes = try? JSONSerialization.data(withJSONObject: observations, options: .sortedKeys) {
            let evidence = XCTAttachment(data: bytes, uniformTypeIdentifier: "public.json")
            evidence.name = "manual-bottom-and-composer-geometry"; evidence.lifetime = .keepAlways; add(evidence)
        }
        capture("manual-return-bottom-geometry", app: app)
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        print("SCROLL-DEBUG after manual return:", debug.label)
        XCTAssertLessThanOrEqual(reply.frame.maxY, readingBottom())
        XCTAssertGreaterThan(reply.frame.maxY, readingBottom() - 32, "Manual scrolling must reach the reply's end above the actual composer")
        let hidden = NSPredicate(format: "exists == false")
        let result = XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: hidden, object: app.buttons["chat-jump-latest"])], timeout: 4)
        XCTAssertEqual(result, .completed, "Jump control stays after a manual return. \(debug.label) replyBottom=\(reply.frame.maxY) readingBottom=\(readingBottom())")
        capture("manual-return-no-jump", app: app)
    }

    @MainActor func testHistorySidebarSlide() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--history-fixture"]; app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        let sidebar = historySidebar(app)
        if sidebar.exists { print("HISTORY-SIDEBAR exposed while closed: \(sidebar.debugDescription.prefix(1500))") }
        XCTAssertFalse(sidebar.exists)
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)
        // The sidebar's controls line up with the conversation's own.
        let headerMidY = open.frame.midY, plusMidY = app.buttons["chat-add-menu"].frame.midY

        // A swipe right on the conversation slides it aside, as ChatGPT does.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.45))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.46)))
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        print("HISTORY-SIDEBAR open: sidebar=\(sidebar.frame) app=\(app.frame)")
        print("HISTORY-SIDEBAR conversation exposed while open: header=\(open.exists) reading=\(app.scrollViews["chat-conversation"].exists) input=\(app.textViews["chat-input"].exists)")
        XCTAssertEqual(sidebar.frame.minX, 0, accuracy: 1)
        XCTAssertEqual(sidebar.frame.width, app.frame.width - 92, accuracy: 1, "92pt of the conversation stays in view")
        let compose = app.buttons["history-compose"], settings = app.buttons["history-settings"]
        print("HISTORY-SIDEBAR buttons: compose=\(compose.frame) settings=\(settings.frame) search=\(app.buttons["history-search"].frame)")
        XCTAssertTrue(compose.isHittable)
        XCTAssertEqual(compose.frame.height, 48, accuracy: 1)
        XCTAssertLessThan(compose.frame.minX, sidebar.frame.width * 0.2, "New chat sits at the bottom leading corner")
        XCTAssertGreaterThan(compose.frame.minY, app.frame.height * 0.85)
        XCTAssertGreaterThan(settings.frame.minX, compose.frame.maxX)
        XCTAssertLessThanOrEqual(settings.frame.maxX, sidebar.frame.maxX)
        let search = app.buttons["history-search"]
        XCTAssertEqual(compose.frame.minX - sidebar.frame.minX, 24, accuracy: 1)
        XCTAssertEqual(sidebar.frame.maxX - settings.frame.maxX, 24, accuracy: 1)
        XCTAssertEqual(search.frame.maxX, settings.frame.maxX, accuracy: 1)
        XCTAssertEqual(search.frame.midY, headerMidY, accuracy: 1, "Search sits level with the conversation's header button")
        print("HISTORY-SIDEBAR levels: header=\(headerMidY) search=\(search.frame.midY) plus=\(plusMidY) compose=\(compose.frame.midY)")
        // The simulator's plus frame can be 54pt tall (see the menu test),
        // so its center is only a rough reference here.
        XCTAssertEqual(compose.frame.midY, plusMidY, accuracy: 6, "New chat sits level with the conversation's plus button")
        XCTAssertEqual(settings.frame.midY, compose.frame.midY, accuracy: 1)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 7)
        capture("history-open", app: app)

        // A long press lifts just the row's rounded shape and offers delete.
        app.buttons["会話を開く: 夕飯のレシピ"].press(forDuration: 1.2)
        let deleteItem = app.buttons["削除"]
        XCTAssertTrue(deleteItem.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR row menu: delete=\(deleteItem.frame)")
        capture("history-row-menu", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.3, dy: 0.8)).tap()
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: deleteItem)], timeout: 3)
        XCTAssertTrue(sidebar.exists)

        // Tapping the strip of conversation slides it back. The strip is
        // the visible part of a screen-wide element, so tap by coordinate.
        XCTAssertTrue(app.descendants(matching: .any)["history-close"].exists)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        wait(for: [closed], timeout: 3)

        // The header button opens it too; frames taken during the slide.
        open.tap()
        for index in 0..<3 { capture("history-motion-\(index)", app: app) }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)

        // Search filters by title and message text.
        app.buttons["history-search"].tap()
        let field = app.textFields["history-search-field"]
        // Frames while the field grows out of the search circle.
        for index in 0..<3 { capture("history-search-motion-\(index)", app: app) }
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        sleep(1)
        let close = app.buttons["history-search-close"]
        print("HISTORY-SIDEBAR search: field=\(field.frame) close=\(close.frame)")
        XCTAssertEqual(close.frame.maxX, settings.frame.maxX, accuracy: 1, "The search circle stays put as the close button")
        XCTAssertEqual(field.frame.midY, close.frame.midY, accuracy: 1)
        field.tap(); field.typeText("カメムシ")
        XCTAssertTrue(app.buttons["会話を開く: カメムシ対策"].waitForExistence(timeout: 3))
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 1)
        capture("history-search", app: app)
        app.buttons["history-search-close"].tap()
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 7)

        // A swipe left closes it.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.7, dy: 0.5))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.1, dy: 0.51)))
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)], timeout: 3)

        // Opening an older conversation slides back to it.
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        app.buttons["会話を開く: 夕飯のレシピ"].tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["夕飯のレシピ"].waitForExistence(timeout: 3))

        // New chat: an empty conversation, and the sidebar closes.
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        compose.tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        XCTAssertFalse(app.staticTexts["夕飯のレシピ"].exists)

        app.terminate(); app.launchArguments = ["--history-fixture", "--dark"]; app.launch()
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        capture("history-dark", app: app)
    }

    @MainActor func testMenuSendAndInteractiveBack() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--gesture-diagnostics"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertEqual(menu.frame.height, 44, accuracy: 1)
        XCTAssertEqual(menu.frame.width, 44, accuracy: 1)
        let controlHeight = menu.frame.height
        menu.tap()
        capture("after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("expanded-menu", app: app)
        app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 3))
        input.tap()
        input.typeText("Animation check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Animation check"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 5))
        capture("sent-message-keyboard", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["会話を開く: Animation check"].tap()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
        // A swipe right on the conversation slides the history out.
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.45))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.46))
        start.press(forDuration: 0.1, thenDragTo: end)
        capture("after-history-swipe", app: app)
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        capture("conversation-list", app: app)
        XCTAssertEqual(app.descendants(matching: .any).matching(identifier: "history-sidebar").count, 1)
        for _ in 0..<2 {
            app.buttons["会話を開く: Animation check"].tap()
            XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
            app.buttons["会話一覧を開く"].tap()
            XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
            XCTAssertEqual(app.descendants(matching: .any).matching(identifier: "history-sidebar").count, 1)
        }
        XCTAssertGreaterThanOrEqual(app.buttons["history-compose"].frame.height, controlHeight - 1)
    }

    @MainActor func testLongConversationJumpControlAndHeader() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        capture("long-chat-latest", app: app)
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 3))
        XCTAssertEqual(jump.frame.height, 44, accuracy: 1)
        XCTAssertLessThan(jump.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
        XCTAssertEqual(jump.frame.midX, app.windows.firstMatch.frame.midX, accuracy: 1, "Jump control is centered")
        XCTAssertFalse(app.buttons["chat-switch-e2b"].exists, "No attachment note above the field")
        XCTAssertLessThan(jump.frame.maxY, app.textViews["chat-input"].frame.minY,
                          "Jump control sits just above the field")
        capture("jump-from-composer", app: app)
        jump.tap()
        let disappeared = NSPredicate(format: "exists == false")
        expectation(for: disappeared, evaluatedWith: jump)
        waitForExpectations(timeout: 4)
        capture("jump-returned-to-latest", app: app)
        // Selectable reply text is reading content, not a tappable control.
        // Check its actual viewport bounds rather than XCTest's hit point.
        let latest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(latest.exists)
        XCTAssertGreaterThan(latest.frame.width, 0)
        XCTAssertGreaterThan(latest.frame.height, 0)
        XCTAssertGreaterThanOrEqual(latest.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(latest.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
    }

    @MainActor func testStreamingReplyRemainsReadableAndFinishes() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--slow-reply"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Text animation")
        app.buttons["送信する"].tap()
        let partial = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "新しい文字が")).firstMatch
        XCTAssertTrue(partial.waitForExistence(timeout: 5))
        capture("reply-revealing", app: app)
        let finished = app.staticTexts["新しい文字がぼやけた状態から少しずつくっきり表示されます。\nすでに読んだ文章は鮮明なままです。日本語と絵文字もそのまま表示します。😊"]
        XCTAssertTrue(finished.waitForExistence(timeout: 8))
        expectation(for: NSPredicate(format: "exists == false"),
                    evaluatedWith: app.buttons["回答を停止する"])
        waitForExpectations(timeout: 3)
        capture("reply-fully-clear", app: app)
        XCTAssertTrue(app.staticTexts["Text animation"].exists)
    }

    @MainActor func testDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--dark", "--reduce-motion", "--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        capture("dark-after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["モデルと設定"].waitForExistence(timeout: 3))
        capture("dark-reduced-motion-menu", app: app)
        dismissMenu(app.buttons["モデルと設定"], app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        reading.swipeDown()
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
        capture("dark-glass-scrolling", app: app)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Glass check")
        XCTAssertTrue(app.buttons["送信する"].isHittable)
        capture("dark-glass-keyboard", app: app)
    }

    @MainActor func testModelCatalogSwitchPreservesGemmaHistory() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        capture("model-catalog", app: app)
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists, "Qwen is hidden unless developer settings are on")
        let use = app.buttons["model-use-gemma-4-e2b"]
        for _ in 0..<8 {
            if use.isHittable { break }
            app.scrollViews["model-list"].swipeUp()
        }
        XCTAssertTrue(use.isHittable)
        capture("model-qwen-ready", app: app)
        use.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.staticTexts["画面の動きを確認"].exists)
        capture("qwen-new-chat", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 3))
        app.buttons["会話を開く: 画面の動きを確認"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["画面の動きを確認"].exists)
        capture("gemma-history-preserved", app: app)
    }

    @MainActor func testTallReplyBubbleAndFeatheredChrome() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--tall-bubble"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["chat-model-settings"].isHittable)
        capture("tall-bubble-bottom", app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        capture("light-feathered-chrome", app: app)
        menu.tap()
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("light-feathered-menu", app: app)
        dismissMenu(app.buttons["新しい会話"], app: app)
        let greeting = app.staticTexts["こんにちは"].firstMatch
        for _ in 0..<10 {
            if greeting.exists && greeting.frame.minY >= reading.frame.minY
                && greeting.frame.maxY < menu.frame.minY { break }
            reading.swipeDown()
        }
        XCTAssertTrue(greeting.exists)
        XCTAssertGreaterThan(greeting.frame.width, 0)
        XCTAssertLessThan(greeting.frame.width, reading.frame.width * 0.75)
        capture("short-bubble-shapes", app: app)
    }

    @MainActor func testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll() { sendFromOlderMessages([]) }

    /// Probe rounds 5-6 (df83ad6, 8175ec2): this test froze at the first
    /// swipe after the second send with and without the rows' transition,
    /// scroll spring and explicit ids, and with plain replies; an eager
    /// VStack passed. ChatView now lays out the latest messages eagerly.
    @MainActor func testProbeSendOlderBaseline() { sendFromOlderMessages([], probe: "baseline") }
    @MainActor func testProbeSendOlderPlainReplies() {
        sendFromOlderMessages(["--probe-plain-replies"], probe: "plain-replies")
    }

    /// 81 messages: the older 40 stay lazy rows above the eager block.
    @MainActor func testProbeLongerChatScrollsThroughLazyRows() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat", "--longer-chat"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Longer chat send")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["Longer chat send"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        let older = app.staticTexts["長い会話の確認 18"].firstMatch
        for _ in 0..<16 {
            if older.exists && older.isHittable { break }
            reading.swipeDown()
        }
        XCTAssertTrue(older.exists, "Scrolled into the lazy rows")
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 5))
        let ink = readingInk(app)
        print("PROBE longer-chat ink=\(ink)")
        XCTAssertGreaterThan(ink, Self.drawnInk, "The lazy rows must be drawn")
        capture("probe-longer-chat-older", app: app)
        app.buttons["chat-jump-latest"].tap()
        Thread.sleep(forTimeInterval: 1.5)
        XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
        capture("probe-longer-chat-latest", app: app)
        print("PROBE longer-chat passed")
    }

    @MainActor private func sendFromOlderMessages(_ flags: [String], probe: String? = nil) {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = XCUIApplication()
            app.launchArguments = ["--long-chat"] + flags + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
            XCTAssertGreaterThan(readingInk(app), Self.drawnInk, "Older messages must be drawn")
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap(); input.typeText("Send scroll regression\nSecond line\nThird line")
            let beforeHeight = input.frame.height
            app.buttons["送信する"].tap()
            let sent = app.staticTexts["Send scroll regression\nSecond line\nThird line"].firstMatch
            XCTAssertTrue(sent.waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
            XCTAssertLessThan(input.frame.height, beforeHeight)
            XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
            XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
            capture(dark ? "dark-send-scroll-settled" : "light-send-scroll-settled", app: app)
            input.tap(); input.typeText("Second send still works")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts["Second send still works"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["chat-jump-latest"].isHittable)
            let ink = readingInk(app)
            print("PROBE send-older ink after second send dark=\(dark) ink=\(ink)")
            XCTAssertGreaterThan(ink, Self.drawnInk, "Older messages must be drawn after two sends")
            app.buttons["chat-jump-latest"].tap()
            capture(dark ? "dark-second-send-responsive" : "light-second-send-responsive", app: app)
            app.terminate()
        }
        if let probe { print("PROBE send-older \(probe) passed") }
    }

    @MainActor func testGenerationSettingsCancelSaveAndPromptPersist() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--reset-settings"]
        app.launch()
        openConfiguration(app)
        let topK = app.textFields["setting-TopK"]
        revealConfigurationControl(topK, app: app)
        XCTAssertTrue(app.staticTexts["setting-help-TopK"].exists)
        XCTAssertEqual(topK.value as? String, "40")
        replace(topK, with: "12")
        app.buttons["キャンセル"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "40", "Cancel must discard draft settings")
        revealConfigurationControl(topK, app: app)
        replace(topK, with: "12")
        let cpu = app.segmentedControls["execution-backend"].buttons["CPU"]
        revealConfigurationControl(cpu, app: app)
        cpu.tap()
        XCTAssertTrue(cpu.isSelected, "CPU must be selected before saving")
        let visionCPU = app.segmentedControls["vision-execution-backend"].buttons["CPU"]
        let visionGPU = app.segmentedControls["vision-execution-backend"].buttons["GPU"]
        revealConfigurationControl(visionCPU, app: app)
        XCTAssertTrue(visionCPU.isSelected, "New vision settings default to CPU without changing the main backend")
        visionGPU.tap()
        XCTAssertTrue(visionGPU.isSelected)
        XCTAssertTrue(cpu.isSelected, "Vision GPU must not change the main CPU preference")
        let thinking = app.switches["enable-thinking"]
        let speculation = app.switches["enable-speculation"]
        revealConfigurationControl(thinking, app: app)
        XCTAssertTrue(thinking.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-thinking"].exists)
        // SwiftUI exposes the labeled row as the switch's accessibility frame.
        // Tap the visible switch at the trailing edge rather than its label.
        thinking.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertTrue(speculation.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-speculation"].exists)
        speculation.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(speculation.value as? String, "1")
        capture("model-configuration-controls", app: app)
        app.segmentedControls.buttons["システムプロンプト"].tap()
        let prompt = app.textViews["system-prompt-input"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        replace(prompt, with: "Reply briefly in Japanese.")
        capture("custom-system-prompt", app: app)
        app.buttons["configuration-save"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "12")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
        app.buttons["configuration-save"].tap()
        app.terminate()
        app.launchArguments = []
        app.launch()
        openConfiguration(app)
        XCTAssertEqual(topK.value as? String, "12", "Saved model configuration must survive relaunch")
        capture("saved-model-configuration", app: app)
        revealConfigurationControl(cpu, app: app)
        XCTAssertTrue(cpu.isSelected)
        revealConfigurationControl(visionGPU, app: app)
        XCTAssertTrue(visionGPU.isSelected, "The independently saved vision backend must survive relaunch")
        revealConfigurationControl(thinking, app: app)
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertEqual(speculation.value as? String, "1")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
    }

    @MainActor func testImagePdfTextImportsPreviewAndArchiveRestore() throws {
        throw XCTSkip("Legacy unverified media formats are intentionally unavailable in1.0.19; covered by attachment policy and lock tests.")
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--attachment-fixtures"]
        app.launch()
        importFixture("sample-image", extension: "png", app: app)
        importFixture("sample-document", extension: "pdf", app: app)
        app.buttons["添付ファイルを開く: sample-document.pdf"].tap()
        XCTAssertTrue(app.navigationBars["sample-document.pdf"].waitForExistence(timeout: 4))
        capture("pdf-preview", app: app)
        app.buttons["完了"].tap()
        importFixture("sample-text", extension: "txt", app: app)
        capture("image-and-files-ready", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 画像1枚・本文: PDF fixture content・本文: 日本語の添付テスト😊"].waitForExistence(timeout: 6))
        capture("image-and-files-sent", app: app)
        app.terminate()
        app.launchArguments = ["--attachment-fixtures", "--restore-fixture-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-document.pdf"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-text.txt"].exists)
        capture("attachment-archive-restored", app: app)
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction("sample-unsupported", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 4))
        app.alerts.buttons["閉じる"].tap()
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        importFixture("sample-sjis", extension: "txt", app: app)
        importFixture("sample-utf16", extension: "txt", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: 日本語の添付確認・本文: 日本語UTF16😊"].waitForExistence(timeout: 6))
    }

    @MainActor func testVideoImportSamplesThreeScenesAndDraftRemoval() throws {
        throw XCTSkip("Legacy unverified media formats are intentionally unavailable in1.0.19; covered by attachment policy and lock tests.")
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--attachment-fixtures", "--dark"]
        app.launch()
        importFixture("sample-video", extension: "mp4", app: app)
        capture("video-draft", app: app)
        app.buttons["添付を外す: sample-video.mp4"].tap()
        XCTAssertFalse(app.buttons["添付ファイルを開く: sample-video.mp4"].exists)
        importFixture("sample-video", extension: "mp4", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 動画3場面"].waitForExistence(timeout: 6))
        XCTAssertTrue(app.staticTexts["動画は開始・中間・終了付近の3場面を読み込みます。音声は解析しません。"].exists)
        capture("video-three-scenes-sent", app: app)
    }

    @MainActor func testWordScannedPdfAndOversizeImports() throws {
        throw XCTSkip("Legacy unverified media formats are intentionally unavailable in1.0.19; covered by attachment policy and lock tests.")
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--attachment-fixtures"]; app.launch()
        importFixture("sample-word", extension: "docx", app: app)
        importFixture("sample-scan", extension: "pdf", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: Word本文の確認😊・本文: SCAN PDF 123"].waitForExistence(timeout: 12))
        capture("word-and-scanned-pdf-read", app: app)
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-oversize", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["添付ファイルを開く: sample-oversize.docx"].exists)
    }

    @MainActor func testComposerClearsJapaneseEmojiAndDismissesKeyboardOnEverySend() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch(); XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        for text in ["日本語の送信😊", "次のメッセージ\n二行目"] {
            input.tap(); input.typeText(text)
            XCTAssertEqual(input.value as? String, text, "Typing must retain the committed Japanese text before send")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts[text].waitForExistence(timeout: 4))
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: app.keyboards.firstMatch)
            waitForExpectations(timeout: 4)
            XCTAssertEqual(input.value as? String, "")
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["送信する"].isEnabled)
        }
        capture("japanese-draft-cleared-keyboard-closed", app: app)
    }

    @MainActor func testAutomaticDeviceChoiceAndCloudBackupOptIn() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch(); XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap(); app.buttons["model-recommendations"].tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "model-auto-result").firstMatch.waitForExistence(timeout: 4))
        XCTAssertFalse(app.buttons["startup-continue"].exists, "Automatic choice must not open a manual picker")
        capture("automatic-device-model-selection", app: app)
        let toggle = app.switches["cloud-history-toggle"]
        let list = app.scrollViews["model-list"]
        for _ in 0..<14 { if toggle.isHittable { break }; list.swipeUp() }
        XCTAssertTrue(toggle.isHittable); XCTAssertEqual(toggle.value as? String, "0")
        toggle.tap()
        let cancel = app.buttons["Cancel"].firstMatch.exists ? app.buttons["Cancel"].firstMatch : app.buttons["キャンセル"].firstMatch
        XCTAssertTrue(cancel.waitForExistence(timeout: 5)); cancel.tap()
        XCTAssertEqual(toggle.value as? String, "0", "Canceling folder access must leave cloud storage off")
        capture("icloud-backup-optional", app: app)
    }

    @MainActor func testBackupWritesLatestSnapshotAndRestoresAttachments() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--cloud-fixture"]; app.launch()
        XCTAssertTrue(app.staticTexts["バックアップ検証成功: 自動保存・最新会話・添付の復元"].waitForExistence(timeout: 15))
        capture("backup-local-file-provider-roundtrip", app: app)
    }

    @MainActor func testNativeBubbleInertiaStillWorksAfterSendAndRespectsReduceMotion() throws {
        throw XCTSkip("The UIKit layer driver was retired in1.0.20. Pure SwiftUI row geometry and non-overlap are checked by the mixed attachment streaming test.")
        continueAfterFailure = false
        for reduced in [false, true] {
            let app = XCUIApplication(); app.launchArguments = ["--long-chat", "--elastic-diagnostics"] + (reduced ? ["--reduce-motion"] : []); app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let input = app.textViews["chat-input"]
            input.tap(); input.typeText("Bounce check"); app.buttons["送信する"].tap()
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            let report = app.staticTexts["elastic-report"]
            if reduced { XCTAssertTrue(report.label.contains("バウンズ待機")) }
            else {
                XCTAssertTrue(report.label.contains("バウンズ動作を確認"), "Actual rendered row layers must have moved after a drag")
                expectation(for: NSPredicate(format: "label CONTAINS %@", "静止"), evaluatedWith: report)
                waitForExpectations(timeout: 4)
            }
            capture(reduced ? "bubble-inertia-disabled" : "bubble-inertia-after-send", app: app)
            app.terminate()
        }
    }

    @MainActor func testVisionProbeScreenSeparatesRealJPEGAndComponentTests() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        let button = app.buttons["open-vision-probe"]
        for _ in 0..<10 where !button.isHittable { app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(button.isHittable); button.tap()
        XCTAssertTrue(app.buttons["run-vision-probe"].waitForExistence(timeout: 5))
        app.buttons["run-vision-probe"].tap()
        XCTAssertTrue(app.staticTexts["UI検証用アプリではネイティブ推論を実行しません。"].waitForExistence(timeout: 3))
        capture("vision-minimal-probe-controls", app: app)
    }

    @MainActor private func importFixture(_ name: String, extension suffix: String, app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction(name, app: app)
        XCTAssertTrue(app.buttons["添付ファイルを開く: \(name).\(suffix)"].waitForExistence(timeout: 8))
    }

    /// Device-like token stream (a few characters at a time, Markdown list)
    /// in a new chat. The reply stays shorter than the screen for seconds, so
    /// the rows must never move down; on device they dropped to a bottom-
    /// aligned position mid-reply and crept back up.
    @MainActor func testTokenStreamFirstReplyNeverMovesDown() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--token-stream"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["テスト"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.5)
        var positions: [CGFloat] = []
        let start = Date()
        while Date().timeIntervalSince(start) < 9 {
            if sent.exists { positions.append(sent.frame.minY) }
        }
        let down = zip(positions, positions.dropFirst()).map { $1 - $0 }.max() ?? 0
        XCTAssertLessThanOrEqual(down, 3, "Rows moved down while the reply streamed: \(positions)")
    }

    /// New chat, first reply growing past one screen: following the reply may
    /// move the rows up, but they must never move back down. On device they
    /// alternated between a top- and a bottom-aligned position every chunk.
    @MainActor func testGrowingFirstReplyNeverMovesBackDown() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--growing-reply"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["テスト"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        var positions: [CGFloat] = []
        for _ in 0..<30 {
            if sent.exists { positions.append(sent.frame.minY) }
            Thread.sleep(forTimeInterval: 0.1)
        }
        let backDown = zip(positions, positions.dropFirst()).map { $1 - $0 }.max() ?? 0
        XCTAssertLessThanOrEqual(backDown, 3, "Rows moved back down while the reply grew: \(positions)")
    }

    /// New chat, first reply: while a short reply streams in, the rows must
    /// stay where they are. On device they jumped between a top- and a
    /// bottom-aligned position with every streamed chunk.
    @MainActor func testFirstReplyInNewChatDoesNotJump() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--slow-reply"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        XCTAssertTrue(modelName.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)   // keyboard closed, reply about to start
        var positions: [CGFloat] = []
        for _ in 0..<20 {
            positions.append(modelName.frame.minY)
            Thread.sleep(forTimeInterval: 0.15)
        }
        let spread = (positions.max() ?? 0) - (positions.min() ?? 0)
        XCTAssertLessThanOrEqual(spread, 3, "Rows moved while the first reply streamed: \(positions)")
    }

    /// The Aurora Orb holds the reply's place while the model works: it
    /// shows as soon as the message is sent, keeps its mist moving, stays
    /// while the reply holds only a line break, and gives way to the first
    /// text on its line without moving the rows.
    @MainActor func testAuroraOrbWaitsForFirstVisibleText() {
        auroraOrb("light", arguments: ["--orb-wait"])
    }

    @MainActor func testAuroraOrbInDarkMode() {
        auroraOrb("dark", arguments: ["--orb-wait", "--dark"])
    }

    /// With Reduce Motion the orb holds one still frame.
    @MainActor func testAuroraOrbHoldsStillWithReduceMotion() {
        auroraOrb("still", arguments: ["--orb-wait", "--reduce-motion"])
    }

    /// From send to first text (preview --orb-wait: a line break 9 s after
    /// the send, the text 0.3 s later), measured from screenshots. The orb
    /// breathes between 24pt and 12pt, shrinks away over 0.7 s from the
    /// line break, and the text waits until it has gone. Element queries
    /// wait for the app to settle and ran out the wait while the orb drew
    /// (1.0.82 CI), so only one is made while it shows.
    @MainActor private func auroraOrb(_ variant: String, arguments: [String]) {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = arguments; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("オーロラ")
        // Under the header and above the composer, the orb is the only
        // colour on the left and the sent bubble the only blue on the right.
        let screen = app.frame.size
        let top = max(app.buttons["会話一覧を開く"].frame.maxY, app.buttons["chat-model-settings"].frame.maxY) + 8
        let left = CGRect(x: 0, y: top, width: 200, height: screen.height - 130 - top)
        let right = CGRect(x: screen.width / 2, y: top, width: screen.width / 2, height: left.height)
        let orb = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "AIが回答を作成しています")).firstMatch
        let tapped = Date()
        app.buttons["送信する"].tap()
        let sent = Date().timeIntervalSince(tapped)

        var readings: [OrbReading] = []
        var foundLine: (centre: CGPoint, bounds: CGRect, background: Int)?   // the orb settled on its line
        var recent: [(t: Double, area: ScreenArea)] = []
        var changes: [Double] = []
        var strip: [(t: Double, image: UIImage)] = []
        var waitShot: UIImage?, textShot: UIImage?
        var labelled: Bool?, labelSeconds = 0.0
        var foundText: Double?, textY = CGFloat.nan
        while Date().timeIntervalSince(tapped) < 30 {
            let t = Date().timeIntervalSince(tapped)
            let shot = XCUIScreen.main.screenshot().image
            guard let image = shot.cgImage, let area = ScreenArea(image, left, screenWidth: screen.width),
                  let side = ScreenArea(image, right, screenWidth: screen.width) else {
                XCTFail("Could not read a screenshot"); return
            }
            let colour = area.colour()
            if foundLine == nil, t >= sent + 0.8, colour.count >= 250 {
                let blank = CGRect(x: colour.bounds.maxX + 8, y: colour.centre.y - 9,
                                   width: 192 - colour.bounds.maxX, height: 18)
                foundLine = (colour.centre, colour.bounds, area.meanLuma(in: blank))
            }
            var ink = 0.0
            if let line = foundLine {
                // Right of the orb on its line: blank until the text comes.
                let band = CGRect(x: line.bounds.maxX + 8, y: line.centre.y - 9,
                                  width: 192 - line.bounds.maxX, height: 18)
                ink = area.ink(in: band, background: line.background).share
                if foundText == nil, ink > 0.02 { foundText = t }
                if foundText == nil, colour.count >= 60 {
                    // How much the mist changed over about a second. Shots
                    // can come 1 s apart while the simulator is busy (the
                    // dark run of 1.0.86 made 13 in 13 s), so pairs may be
                    // up to 2.5 s apart.
                    if let earlier = recent.last(where: { t - $0.t >= 0.8 }), t - earlier.t <= 2.5 {
                        changes.append(area.change(from: earlier.area, in: line.bounds.insetBy(dx: -4, dy: -4)))
                    }
                    recent.append((t, area))
                    recent.removeAll { t - $0.t > 2.5 }
                    if strip.count < 8, t - (strip.last?.t ?? 0) >= 1,
                       let crop = orbCrop(shot, around: line.centre, side: 64, screenWidth: screen.width) {
                        strip.append((t, crop))
                    }
                    if waitShot == nil, t >= sent + 2 { waitShot = shot }
                }
            }
            readings.append(OrbReading(t: t, colour: colour.count, ink: ink, bubble: side.blueTop()))
            if labelled == nil, foundLine != nil, foundText == nil, t >= sent + 1.5 {
                let start = Date()
                labelled = orb.exists
                labelSeconds = Date().timeIntervalSince(start)
            }
            if let line = foundLine, let textAt = foundText, textShot == nil, t >= textAt + 1.2 {
                textShot = shot
                let row = CGRect(x: line.bounds.minX - 4, y: line.centre.y - 16, width: 200 - line.bounds.minX, height: 32)
                textY = area.ink(in: row, background: line.background).centreY
            }
            if let textAt = foundText, t >= textAt + 2 { break }
        }

        if !strip.isEmpty { attachOrbStrip("orb-strip-\(variant)", frames: strip) }
        for (name, image) in [("wait", waitShot), ("text", textShot)] {
            guard let image else { continue }
            let attachment = XCTAttachment(image: image)
            attachment.name = "orb-\(variant)-\(name)"
            attachment.lifetime = .keepAlways
            add(attachment)
        }
        let gaps = zip(readings.dropFirst(), readings).map { later, earlier in later.t - earlier.t }
        let every = gaps.isEmpty ? 0 : gaps.reduce(0, +) / Double(gaps.count)
        let label = labelled.map { $0 ? "yes" : "no" } ?? "-"
        print(String(format: "ORB %@ tap=%.2f text=%.2f shots=%ld every=%.2f label=%@ in %.2f",
                     variant, sent, foundText ?? -1, readings.count, every, label, labelSeconds))
        var timeline: [String] = []
        for reading in readings {
            let bubble = reading.bubble.map { String(format: "%.0f", Double($0)) } ?? "-"
            timeline.append(String(format: "%.1f:%ld/%.2f/", reading.t, reading.colour, reading.ink) + bubble)
        }
        print("ORB \(variant) timeline (s:colour/ink/bubble) " + timeline.joined(separator: " "))
        let sortedChanges = changes.sorted()
        let median = sortedChanges.isEmpty ? -1 : sortedChanges[sortedChanges.count / 2]
        print(String(format: "ORB %@ change min=%.2f median=%.2f max=%.2f orbY=%.1f textY=%.1f", variant,
                     sortedChanges.first ?? -1, median, sortedChanges.last ?? -1,
                     Double(foundLine?.centre.y ?? -1), Double(textY)))
        print("ORB \(variant) orb bounds \(String(describing: foundLine?.bounds))")

        // The sent bubble flies up from the composer, and the orb shows
        // with it as it lands.
        guard let landed = readings.last?.bubble,
              let arrival = readings.first(where: { $0.bubble.map { abs($0 - landed) <= 2 } ?? false }) else {
            XCTFail("The sent message never showed"); return
        }
        XCTAssertLessThanOrEqual(arrival.t - sent, 2, "The sent message must show at once")
        guard let line = foundLine, let textAt = foundText else { XCTFail("The reply's text never showed"); return }
        // The orb shows from then until the first token, down to a 12pt
        // light (about 110 points² of colour) at the bottom of its breath.
        // It then shrinks away over 0.7 s, the text clears from a blur in
        // 0.32 s, and shots come every 0.3-0.7 s, so the last 1.2 s before
        // the text reads is left out.
        let waiting = readings.filter { $0.t >= arrival.t + 0.3 && $0.t < textAt - 1.2 }
        let missing = waiting.filter { $0.colour < 60 }.map(\.t)
        XCTAssertTrue(missing.isEmpty, "The orb must show from the send until the first token; it was missing at \(missing) s")
        // The text waits until the orb has gone, so no shot has both.
        let both = readings.filter { $0.ink > 0.02 && $0.colour >= 60 }.map(\.t)
        XCTAssertTrue(both.isEmpty, "The text must wait until the orb has gone; both showed at \(both) s")
        let after = readings.filter { $0.t >= textAt + 0.6 }
        XCTAssertFalse(after.isEmpty)
        XCTAssertLessThanOrEqual(after.map(\.colour).max() ?? 0, 10, "No colour of the orb may stay behind the text")
        XCTAssertGreaterThanOrEqual(changes.count, 3, "Too few shots of the orb to measure its motion")
        if variant == "still" {
            XCTAssertLessThan(sortedChanges.last ?? 0, 0.3, "With Reduce Motion the orb holds still")
        } else {
            XCTAssertGreaterThan(sortedChanges.first ?? 0, 1, "The orb's mist must keep moving")
        }
        XCTAssertLessThanOrEqual(abs(textY - line.centre.y), 4, "The text must take the orb's line")
        let tops = readings.filter { $0.t >= arrival.t }.compactMap(\.bubble)
        XCTAssertGreaterThan(tops.count, readings.count / 2, "The sent bubble must stay in view")
        XCTAssertLessThanOrEqual((tops.max() ?? 0) - (tops.min() ?? 0), 2, "Rows moved while the orb gave way")
        XCTAssertEqual(labelled, true, "VoiceOver must read the orb as the reply being written")
        XCTAssertFalse(orb.exists, "Nothing of the orb may stay for VoiceOver once the text shows")
        let reply = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "こんにちは")).firstMatch
        XCTAssertTrue(reply.waitForExistence(timeout: 3))
        app.terminate()
    }

    /// Recording-oriented: send with the keyboard open, twice, in a long
    /// chat. Pauses isolate each send in interaction.mp4 for frame review of
    /// the keyboard dismissal, the follow-to-bottom scroll and the new bubble.
    @MainActor func testSendWithKeyboardOpenMotion() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat"]; app.launch()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        for text in ["送信の動きを確認します", "もう一度送信します"] {
            input.tap(); input.typeText(text)
            Thread.sleep(forTimeInterval: 0.8)
            app.buttons["送信する"].tap()
            Thread.sleep(forTimeInterval: 2.5)
            capture("after-send", app: app)
            XCTAssertTrue(app.staticTexts[text].exists || app.otherElements[text].exists
                          || app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch.exists)
        }
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists, "Sending must leave the latest message in view")
    }

    /// Recording-oriented check of the plus menu (a native Menu, so iOS
    /// owns the morph). Pauses isolate each open and close in interaction.mp4.
    @MainActor func testPlusMenuGlassMorphOpenCloseAndInterruption() {
        continueAfterFailure = false
        for arguments in [["--e2b"], ["--e2b", "--dark"]] {
            let app = XCUIApplication(); app.launchArguments = arguments; app.launch()
            let plus = app.buttons["chat-add-menu"]
            XCTAssertTrue(plus.waitForExistence(timeout: 10))
            let restingFrame = plus.frame
            Thread.sleep(forTimeInterval: 1.0)
            for _ in 0..<2 {
                plus.tap()
                let photos = menuItem("chat-attach-photos", "写真", app)
                XCTAssertTrue(photos.waitForExistence(timeout: 3))
                Thread.sleep(forTimeInterval: 1.2)
                capture("plus-menu-open\(arguments.contains("--dark") ? "-dark" : "")", app: app)
                dismissMenu(photos, app: app)
                Thread.sleep(forTimeInterval: 1.2)
            }
            // Open and dismiss immediately: the system reverses mid-flight.
            plus.tap()
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
            Thread.sleep(forTimeInterval: 1.2)
            XCTAssertFalse(menuItem("chat-attach-photos", "写真", app).exists)
            XCTAssertEqual(plus.frame.minX, restingFrame.minX, accuracy: 1)
            XCTAssertEqual(plus.frame.minY, restingFrame.minY, accuracy: 1)
            XCTAssertTrue(plus.isHittable)
            XCTAssertTrue(app.textViews["chat-input"].isHittable)
        }
    }

    @MainActor private func chooseMenuAction(_ name: String, app: XCUIApplication) {
        let button = menuItem(name, name, app)
        XCTAssertTrue(button.waitForExistence(timeout: 3))
        for _ in 0..<6 {
            if button.isHittable { break }
            app.collectionViews.firstMatch.swipeUp()
        }
        XCTAssertTrue(button.isHittable); button.tap()
    }

    /// System menu rows may expose either the identifier or only the title
    /// (possibly followed by the "調整中" subtitle) to XCUITest.
    @MainActor private func menuItem(_ id: String, _ title: String, _ app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                         id, title, title + ",")).firstMatch
    }

    @MainActor private func isLocked(_ item: XCUIElement) -> Bool {
        (item.value as? String) == "現在調整中" || item.label.contains("調整中")
    }

    /// Tap outside the menu, on the conversation, and wait for it to close.
    @MainActor private func dismissMenu(_ item: XCUIElement, app: XCUIApplication) {
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        let gone = NSPredicate(format: "exists == false")
        let wait = XCTNSPredicateExpectation(predicate: gone, object: item)
        XCTAssertEqual(XCTWaiter().wait(for: [wait], timeout: 3), .completed, "menu should close")
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
    }

    @MainActor private func openConfiguration(_ app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.buttons["model-generation-settings"].waitForExistence(timeout: 3))
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(app.textFields["setting-Max Tokens"].waitForExistence(timeout: 3))
    }

    @MainActor private func replace(_ field: XCUIElement, with text: String) {
        field.tap()
        // Place the caret after the last line, including a multi-line editor.
        field.coordinate(withNormalizedOffset: CGVector(dx: 0.95, dy: 0.9)).tap()
        let old = field.value as? String ?? ""
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count) + text)
    }

    @MainActor private func revealConfigurationControl(_ control: XCUIElement, app: XCUIApplication) {
        let form = app.collectionViews["generation-configuration"]
        XCTAssertTrue(form.waitForExistence(timeout: 3))
        for _ in 0..<12 {
            let bounds = form.frame
            let keyboard = app.keyboards.firstMatch
            let bottom = min(bounds.maxY, keyboard.exists ? keyboard.frame.minY : app.frame.maxY) - 16
            if control.exists && control.isHittable && control.frame.minY >= bounds.minY + 8 && control.frame.maxY <= bottom { return }
            // SwiftUI can report offscreen segmented buttons as hittable. Drag the
            // visible Form gutter above the keyboard instead of swiping the app.
            let height = max(1, bottom - bounds.minY)
            let start = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: height * 0.8))
            let end = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: height * 0.15))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Configuration control must be fully visible before interaction: \(control.identifier)")
    }

    /// Frames of the jump control's motion, for review without a recording:
    /// rising after a scroll up, and fusing back after a tap. Both the
    /// E2B and E4B layouts are covered; both now sink into the field.
    @MainActor func testJumpControlMotionFrames() {
        continueAfterFailure = false
        for (variant, arguments) in [("e2b", ["--long-chat", "--e2b"]), ("e4b", ["--long-chat"])] {
            let app = XCUIApplication()
            app.launchArguments = arguments
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            XCTAssertTrue(reading.waitForExistence(timeout: 3))
            reading.swipeDown()
            captureStrip("jump-strip-\(variant)-rise")
            let jump = app.buttons["chat-jump-latest"]
            XCTAssertTrue(jump.waitForExistence(timeout: 3))
            XCTAssertEqual(jump.frame.midX, app.windows.firstMatch.frame.midX, accuracy: 1)
            jump.tap()
            captureStrip("jump-strip-\(variant)-fuse")
            let hidden = NSPredicate(format: "exists == false")
            expectation(for: hidden, evaluatedWith: jump)
            waitForExpectations(timeout: 4)
            capture("jump-\(variant)-settled", app: app)
            app.terminate()
        }
    }

    /// Screenshots taken back to back (they do not wait for the app to go
    /// idle), cropped to the composer area and laid out on one sheet.
    @MainActor private func captureStrip(_ name: String, count: Int = 12) {
        var frames: [UIImage] = []
        var times: [Double] = []
        let start = Date()
        for _ in 0..<count {
            frames.append(XCUIScreen.main.screenshot().image)
            times.append(Date().timeIntervalSince(start))
        }
        guard let first = frames.first else { return }
        let size = first.size
        let crop = CGRect(x: 0, y: size.height * 0.58, width: size.width, height: size.height * 0.36)
        let factor: CGFloat = 0.5
        let cell = CGSize(width: crop.width * factor, height: crop.height * factor)
        let label: CGFloat = 14, columns = 4
        let rows = (frames.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.black.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width,
                                     y: CGFloat(index / columns) * (cell.height + label))
                let target = CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height)
                context.cgContext.saveGState()
                context.cgContext.clip(to: target)
                frame.draw(in: CGRect(x: target.minX - crop.minX * factor, y: target.minY - crop.minY * factor,
                                      width: size.width * factor, height: size.height * factor))
                context.cgContext.restoreGState()
                (String(format: "%d  %.0f ms", index, times[index] * 1000) as NSString)
                    .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// A copy of a screenshot's square around a point, at full resolution.
    /// Drawn into its own image, so the whole screenshot is not kept.
    private func orbCrop(_ shot: UIImage, around centre: CGPoint, side: CGFloat, screenWidth: CGFloat) -> UIImage? {
        guard let image = shot.cgImage, screenWidth > 0 else { return nil }
        let scale = CGFloat(image.width) / screenWidth
        let rect = CGRect(x: (centre.x - side / 2) * scale, y: (centre.y - side / 2) * scale,
                          width: side * scale, height: side * scale).integral
        guard let crop = image.cropping(to: rect) else { return nil }
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: CGSize(width: crop.width, height: crop.height), format: format).image { _ in
            UIImage(cgImage: crop).draw(at: .zero)
        }
    }

    /// The orb's crops laid out on one sheet with their times after the
    /// send, to review its motion.
    @MainActor private func attachOrbStrip(_ name: String, frames: [(t: Double, image: UIImage)]) {
        let columns = 4
        let label: CGFloat = 14
        let cell = frames[0].image.size
        let rows = (frames.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width,
                                     y: CGFloat(index / columns) * (cell.height + label))
                frame.image.draw(in: CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height))
                (String(format: "%ld  %.1f s", index, frame.t) as NSString)
                    .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor private func historySidebar(_ app: XCUIApplication) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
    }

    /// Opening chats from history, between a long Markdown chat and short
    /// ones, lands at each chat's end, never below its last message. On
    /// device (1.0.58) a chat sometimes opened past its end, and touching it
    /// then counted as the pull that opens a new chat.
    @MainActor func testOpeningChatsFromHistoryLandsAtTheEnd() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--markdown-sample", "--history-fixture"]; app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        func value(_ key: String) -> Double? {
            let label = debug.label
            guard let range = label.range(of: key + "=") else { return nil }
            return Double(label[range.upperBound...].prefix { "-0123456789.".contains($0) })
        }
        func pastEnd() -> Double? {
            guard let content = value("content"), let offset = value("offset"), let container = value("container"),
                  let top = value("insetTop") else { return nil }
            return offset + top + container - max(content, container)
        }
        for (index, title) in ["夕飯のレシピ", "Markdownの表示を確認", "カメムシ対策", "Markdownの表示を確認"].enumerated() {
            open.tap()
            let row = app.buttons["会話を開く: \(title)"]
            XCTAssertTrue(row.waitForExistence(timeout: 3), title)
            row.tap()
            Thread.sleep(forTimeInterval: 1.2)
            let past = pastEnd()
            print("HISTORY-OPEN \(title) past=\(past.map { String(format: "%.1f", $0) } ?? "?") \(debug.label.prefix(160))")
            capture("markdown-history-open-\(index)", app: app)
            XCTAssertLessThanOrEqual(past ?? 0, 8, "\(title) opened below its last message")
            XCTAssertGreaterThanOrEqual(past ?? 0, -8, "\(title) opened above its latest message")
            let content = value("content")
            // A small touch on the conversation must never open a new chat.
            let reading = app.scrollViews["chat-conversation"]
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.45))
                .press(forDuration: 0.1, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.47)))
            Thread.sleep(forTimeInterval: 0.8)
            XCTAssertFalse(app.staticTexts["メッセージを送って会話を始めましょう"].exists, "A touch opened a new chat")
            // The conversation is still open (a new chat would be empty).
            XCTAssertGreaterThan(value("content") ?? 0, (content ?? 0) * 0.5, "\(title) is still open")
            XCTAssertLessThanOrEqual(pastEnd() ?? 0, 8, "\(title) stays at its end after a touch")
        }
    }

    /// Probe (1.0.59): scrolling up in the long chat froze the preview app
    /// at full CPU in the send-motion check. Each variant turns suspects off;
    /// a variant that prints its PROBE line did not freeze.
    // Round 1 (f73c481): all-off and plain-replies passed; no link dialog, no
    // reveal, a shared scroll view and no pull each still froze. So it is
    // the Markdown reply itself. Round 2 narrows that down.
    // Round 2 (346d01d): no text selection, flat blocks and plain-string
    // text all still froze. Round 3 samples the frozen app's main thread.
    @MainActor func testProbeLongChatScrollBaseline() { probeLongChatScroll("baseline", []) }
    @MainActor func testProbeLongChatScrollNoSelection() { probeLongChatScroll("no-selection", ["--probe-no-selection"]) }
    @MainActor func testProbeLongChatScrollFlat() { probeLongChatScroll("flat", ["--probe-flat"]) }
    @MainActor func testProbeLongChatScrollStringText() { probeLongChatScroll("string-text", ["--probe-string-text", "--probe-no-reveal"]) }

    // Round 4 (1.0.67): with full-width replies the plain scroll-up passes,
    // but scrolling up right after a send still froze (send test). The
    // keyboard is open then and the drag dismisses it interactively.
    @MainActor func testProbeKeyboardImmediately() {
        probeLongChatScroll("keyboard-immediately", ["--probe-dismiss-immediately"], keyboard: true)
    }
    @MainActor func testProbeKeyboardInteractive() { probeLongChatScroll("keyboard-interactive", [], keyboard: true) }
    @MainActor func testProbeKeyboardNever() {
        probeLongChatScroll("keyboard-never", ["--probe-keep-keyboard"], keyboard: true)
    }
    @MainActor func testProbeKeyboardSent() { probeLongChatScroll("keyboard-sent", [], keyboard: true, send: true) }

    @MainActor private func probeLongChatScroll(_ name: String, _ flags: [String], keyboard: Bool = false, send: Bool = false) {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat"] + flags; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        if keyboard {
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
            if send {
                input.typeText("Probe send\nSecond line")
                app.buttons["送信する"].tap()
                XCTAssertTrue(app.staticTexts["Probe send\nSecond line"].firstMatch.waitForExistence(timeout: 4))
                XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
            }
            print("PROBE \(name) keyboard-before-scroll=\(app.keyboards.firstMatch.exists)")
        }
        let start = Date()
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        let shown = jump.waitForExistence(timeout: 5)
        print("PROBE \(name) seconds=\(String(format: "%.1f", Date().timeIntervalSince(start))) jump=\(shown)")
        capture("probe-\(name)", app: app)
        XCTAssertTrue(shown)
        app.terminate()
    }

    /// Markdown replies: headings, emphasis, quote, lists and checklist,
    /// table, highlighted code with a copy button, math, rule and a
    /// tap-to-load image, in light mode. A link asks before it opens.
    @MainActor func testMarkdownReplyRendersEveryBlock() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--markdown-sample"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-bottom", app: app)
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "サンプル画像")).firstMatch.exists,
                      "The image shows as a card to tap, not loaded by itself")
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "**")).count, 0, "Raw bold markers")
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "```")).count, 0, "Raw code fences")
        let copies = app.buttons.matching(identifier: "code-copy")
        print("MARKDOWN-NOTE copy buttons: \(copies.count)")
        var copy = copies.allElementsBoundByIndex.last { $0.isHittable }
        // The sample's math below the code block has grown past a screen
        // (1.0.77), so the block is pulled back into view first.
        var pulls = 0
        while copy == nil, pulls < 5 {
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
                .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7)))
            Thread.sleep(forTimeInterval: 0.6)
            copy = copies.allElementsBoundByIndex.last { $0.isHittable }
            pulls += 1
        }
        print("MARKDOWN-NOTE pulls to reach the copy button: \(pulls)")
        XCTAssertNotNil(copy, "The Swift block's copy button")
        copy?.tap()
        Thread.sleep(forTimeInterval: 0.3)
        capture("markdown-copied", app: app)
        // The screenshot shows the change; XCTest's accessibility snapshot
        // of the label can lag behind it, so this is only noted.
        let copied = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "コピーしました")).firstMatch
        print("MARKDOWN-NOTE copied label seen: \(copied.waitForExistence(timeout: 2))")
        // A short pull, so the reply's first lines clear the header.
        reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
            .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55)))
        Thread.sleep(forTimeInterval: 0.8)
        capture("markdown-top", app: app)
        let link = app.links["リンク"].firstMatch
        XCTAssertTrue(link.waitForExistence(timeout: 2), "Links are exposed as links")
        if link.isHittable {
            link.tap()
            XCTAssertTrue(app.staticTexts["リンクを開きますか？"].waitForExistence(timeout: 3), "A link asks before leaving the app")
            capture("markdown-link-confirm", app: app)
            // iOS 26 shows it as a popover without a cancel button; a tap
            // outside dismisses it.
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.62)).tap()
            XCTAssertTrue(app.staticTexts["リンクを開きますか？"].waitForNonExistence(timeout: 3))
        } else {
            print("MARKDOWN-NOTE link not hittable: \(link.frame)")
        }
        reading.swipeDown(); reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-wide", app: app)
        XCTAssertTrue(app.buttons["残り30行を表示"].exists || app.staticTexts["残り30行を表示"].exists,
                      "Long code shows its first lines until expanded")
    }

    @MainActor func testMarkdownReplyInDarkMode() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--markdown-sample", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-bottom", app: app)
        reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-middle", app: app)
        reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-top", app: app)
    }

    /// Phase 5: a formula, a table and a code block each offer their own
    /// copy menu on a long press, prose keeps the reply's menu, and
    /// VoiceOver reads formulas in words and cells with their column's header.
    @MainActor func testMarkdownCopyMenusAndVoiceOverLabels() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--markdown-sample"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        let any = app.descendants(matching: .any)
        func labels(_ prefix: String) -> [String] {
            any.matching(NSPredicate(format: "label BEGINSWITH %@", prefix)).allElementsBoundByIndex.prefix(10).map(\.label)
        }
        print("MARKDOWN-NOTE formula labels: \(labels("数式、"))")
        print("MARKDOWN-NOTE table labels: \(labels("表、"))")
        print("MARKDOWN-NOTE code labels: \(labels("コード、"))")
        XCTAssertTrue(any.matching(NSPredicate(format: "label == %@", "数式、0 から 1 までの積分 x の 2 乗 dx イコール 3 分の 1"))
            .firstMatch.exists, "A formula reads in words")
        XCTAssertTrue(any.matching(NSPredicate(format: "label == %@", "モデル、E2B")).firstMatch.exists,
                      "A cell reads with its column's header")

        // Between the header and the composer, where a touch reaches the reply.
        let top = app.buttons["chat-model-settings"].frame.maxY + 24
        let bottom = any["chat-composer"].frame.minY - 24
        func reach(_ query: XCUIElementQuery, _ name: String, room: CGFloat = 0) -> XCUIElement? {
            for pull in 0..<8 {
                if let element = query.allElementsBoundByIndex.last(where: { element in
                    element.frame.width > 0 && element.frame.midY > top && element.frame.midY + room < bottom
                }) {
                    print("MARKDOWN-NOTE \(name) reached after \(pull) pulls at \(element.frame)")
                    return element
                }
                reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.35))
                    .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.6)))
                Thread.sleep(forTimeInterval: 0.6)
            }
            return nil
        }
        func menu(_ item: String, also others: [String], shot: String) {
            XCTAssertTrue(app.buttons[item].waitForExistence(timeout: 4), "\(item) in the menu")
            for other in others { XCTAssertTrue(app.buttons[other].exists, "\(other) in the menu") }
            capture(shot, app: app)
            app.buttons[item].tap()
            XCTAssertTrue(app.buttons[item].waitForNonExistence(timeout: 3), "The menu closes")
            Thread.sleep(forTimeInterval: 0.4)
        }

        let formula = reach(any.matching(identifier: "math-block"), "formula")
        XCTAssertNotNil(formula, "A formula block on screen")
        formula?.press(forDuration: 1.2)
        menu("LaTeXをコピー", also: ["返信全体をコピー"], shot: "markdown-menu-math")

        let copy = reach(app.buttons.matching(identifier: "code-copy"), "code", room: 80)
        XCTAssertNotNil(copy, "The Swift block's copy button")
        copy?.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).withOffset(CGVector(dx: -120, dy: 50))
            .press(forDuration: 1.2)
        menu("返信全体をコピー", also: ["ファイルとして共有"], shot: "markdown-menu-code")

        let cell = reach(any.matching(NSPredicate(format: "label == %@", "モデル、E2B")), "table")
        XCTAssertNotNil(cell, "The table on screen")
        cell?.press(forDuration: 1.2)
        menu("表をコピー", also: ["Markdownでコピー", "返信全体をコピー"], shot: "markdown-menu-table")

        // Prose keeps the reply's own menu, which copies all of it.
        reading.swipeUp(); reading.swipeUp(); reading.swipeUp()
        Thread.sleep(forTimeInterval: 0.6)
        let prose = reach(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "連立方程式も描けます")), "prose")
        XCTAssertNotNil(prose, "A paragraph on screen")
        prose?.press(forDuration: 1.2)
        menu("コピー", also: [], shot: "markdown-menu-reply")
    }

    /// A long reply with every heading level, nested and numbered lists, a
    /// quote, a table and code, flat on the conversation: its top, middle
    /// and end, light and dark, for the spacing and alignment review.
    @MainActor func testMarkdownLongArticleLayout() {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = XCUIApplication()
            app.launchArguments = ["--markdown-article"] + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            XCTAssertTrue(reading.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.6)
            let name = dark ? "markdown-article-dark" : "markdown-article"
            capture("\(name)-end", app: app)
            XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "#")).count, 0, "Raw heading markers")
            XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "**")).count, 0, "Raw bold markers")
            reading.swipeDown()
            Thread.sleep(forTimeInterval: 0.8)
            capture("\(name)-middle", app: app)
            // At the very top, where the reply must start below the header.
            // The history list holds the same title, so look in the chat only.
            let request = reading.staticTexts["長文のMarkdownを表示して"].firstMatch
            for _ in 0..<5 where !(request.exists && request.frame.minY > 100) {
                reading.swipeDown()
                Thread.sleep(forTimeInterval: 0.5)
            }
            XCTAssertTrue(reading.staticTexts["2035年のAIと暮らし"].firstMatch.exists, "The H1 heading")
            Thread.sleep(forTimeInterval: 0.6)
            capture("\(name)-top", app: app)
            app.terminate()
        }
    }

    /// While the reply streams, unfinished syntax never shows: no raw bold
    /// markers, code fences or half links, and the rows never jump down.
    @MainActor func testMarkdownStreamingNeverShowsRawSyntax() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--markdown-stream"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("表示テスト")
        app.buttons["送信する"].tap()
        let sent = Date()
        XCTAssertTrue(app.buttons["回答を停止する"].waitForExistence(timeout: 10))
        // How long each accessibility snapshot takes while the reply streams
        // tells a slow runner from a busy main thread.
        print("MARKDOWN-NOTE stop button seen \(Date().timeIntervalSince(sent)) s after the send")
        var shots = 0
        var checks = 0
        let start = Date()
        while app.buttons["回答を停止する"].exists && Date().timeIntervalSince(start) < 20 {
            checks += 1
            let raw = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@ OR label CONTAINS %@ OR label CONTAINS %@",
                                                           "**", "```", "](http"))
            XCTAssertEqual(raw.count, 0, "Raw Markdown while streaming: \(raw.allElementsBoundByIndex.map(\.label))")
            if Date().timeIntervalSince(start) > Double(shots) * 1.6 + 1, shots < 4 {
                capture("markdown-stream-\(shots)", app: app); shots += 1
            }
        }
        print("MARKDOWN-NOTE stream loop: \(checks) checks and \(shots) shots in \(Date().timeIntervalSince(start)) s")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        print("MARKDOWN-NOTE reply finished \(Date().timeIntervalSince(sent)) s after the send")
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-stream-done", app: app)
        XCTAssertTrue(app.staticTexts["表示テスト"].exists || app.staticTexts["表示テスト"].waitForExistence(timeout: 2))
    }

    /// Below this share of non-background pixels the conversation is blank.
    /// Text and bubbles cover several percent of the reading area.
    static let drawnInk = 0.005

    /// Share of pixels that differ from the background in the conversation,
    /// between the header and the jump control. Accessibility frames stay
    /// in place when rows are not drawn, so hit tests alone miss a blank
    /// screen (the eager block as one lazy item, 1.0.71).
    @MainActor private func readingInk(_ app: XCUIApplication) -> Double {
        let shot = XCUIScreen.main.screenshot().image
        guard let image = shot.cgImage, app.frame.width > 0 else { return -1 }
        let scale = CGFloat(image.width) / app.frame.width
        let top = app.buttons["chat-model-settings"].frame.maxY + 12
        let bottom = app.descendants(matching: .any)["chat-composer"].frame.minY - 90
        guard bottom > top + 40,
              let region = image.cropping(to: CGRect(x: 0, y: top * scale, width: CGFloat(image.width),
                                                     height: (bottom - top) * scale).integral) else { return -1 }
        let width = 300, height = max(1, width * region.height / max(1, region.width))
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(region, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return -1 }
        var luma: [Int] = []
        luma.reserveCapacity(width * height)
        for index in stride(from: 0, to: pixels.count, by: 4) {
            let red = 299 * Int(pixels[index])
            let green = 587 * Int(pixels[index + 1])
            let blue = 114 * Int(pixels[index + 2])
            luma.append((red + green + blue) / 1000)
        }
        let background: Int = luma.sorted()[luma.count / 2]
        let marked: Int = luma.filter { abs($0 - background) > 60 }.count
        return Double(marked) / Double(luma.count)
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}

/// One screenshot in the Aurora Orb test: seconds after the send tap, the
/// orb's colour in points², the share of text right of it on its line, and
/// the top of the sent bubble.
private struct OrbReading {
    let t: Double
    let colour: Int
    let ink: Double
    let bubble: CGFloat?
}

/// An area of a screenshot read at one pixel per point, to measure what is
/// drawn there without querying the app.
private struct ScreenArea {
    let frame: CGRect
    private let width: Int
    private let height: Int
    private let bytes: [UInt8]

    init?(_ shot: CGImage, _ frame: CGRect, screenWidth: CGFloat) {
        guard screenWidth > 0, frame.width >= 1, frame.height >= 1 else { return nil }
        let scale = CGFloat(shot.width) / screenWidth
        let rect = CGRect(x: frame.minX * scale, y: frame.minY * scale,
                          width: frame.width * scale, height: frame.height * scale).integral
        guard let crop = shot.cropping(to: rect) else { return nil }
        let width = Int(frame.width), height = Int(frame.height)
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(crop, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return nil }
        self.frame = CGRect(origin: frame.origin, size: CGSize(width: width, height: height))
        self.width = width
        self.height = height
        self.bytes = bytes
    }

    /// The clearly coloured pixels, where text and the conversation are
    /// black, white or grey: how many, their middle and their bounds.
    func colour() -> (count: Int, centre: CGPoint, bounds: CGRect) {
        var count = 0, sumX = 0, sumY = 0
        var minX = Int.max, maxX = Int.min, minY = Int.max, maxY = Int.min
        for y in 0..<height {
            for x in 0..<width where Self.chroma(pixel(x, y)) > 50 {
                count += 1; sumX += x; sumY += y
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard count > 0 else { return (0, .zero, .null) }
        let centre = CGPoint(x: frame.minX + CGFloat(sumX) / CGFloat(count) + 0.5,
                             y: frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5)
        let bounds = CGRect(x: frame.minX + CGFloat(minX), y: frame.minY + CGFloat(minY),
                            width: CGFloat(maxX - minX + 1), height: CGFloat(maxY - minY + 1))
        return (count, centre, bounds)
    }

    /// Share of a band's pixels that are text, grey to black on a light
    /// background or light on a dark one, and the middle of that text.
    func ink(in rect: CGRect, background: Int) -> (share: Double, centreY: CGFloat) {
        let (columns, rows) = span(rect)
        var count = 0, sumY = 0
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) < 60, abs(Self.luma(value) - background) > 80 { count += 1; sumY += y }
            }
        }
        let share = Double(count) / Double(max(1, columns.count * rows.count))
        return (share, count == 0 ? .nan : frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5)
    }

    func meanLuma(in rect: CGRect) -> Int {
        let (columns, rows) = span(rect)
        var total = 0
        for y in rows {
            for x in columns { total += Self.luma(pixel(x, y)) }
        }
        return total / max(1, columns.count * rows.count)
    }

    /// The top of the sent bubble: the first row with some blue in it.
    func blueTop() -> CGFloat? {
        for y in 0..<height {
            var blue = 0
            for x in 0..<width {
                let value = pixel(x, y)
                if value.blue > 180, value.blue - value.red > 120 { blue += 1 }
            }
            if blue >= 3 { return frame.minY + CGFloat(y) }
        }
        return nil
    }

    /// Mean change of colour from an earlier reading of the same area, over
    /// the pixels coloured in either.
    func change(from earlier: ScreenArea, in rect: CGRect) -> Double {
        let (columns, rows) = span(rect)
        var total = 0, count = 0
        for y in rows {
            for x in columns {
                let now = pixel(x, y), then = earlier.pixel(x, y)
                guard Self.chroma(now) > 50 || Self.chroma(then) > 50 else { continue }
                total += abs(now.red - then.red) + abs(now.green - then.green) + abs(now.blue - then.blue)
                count += 3
            }
        }
        return count == 0 ? 0 : Double(total) / Double(count)
    }

    /// The pixels inside a rectangle given in screen points.
    private func span(_ rect: CGRect) -> (columns: Range<Int>, rows: Range<Int>) {
        guard !rect.isNull else { return (0..<0, 0..<0) }
        let x0 = min(width, max(0, Int((rect.minX - frame.minX).rounded(.down))))
        let x1 = min(width, max(x0, Int((rect.maxX - frame.minX).rounded(.up))))
        let y0 = min(height, max(0, Int((rect.minY - frame.minY).rounded(.down))))
        let y1 = min(height, max(y0, Int((rect.maxY - frame.minY).rounded(.up))))
        return (x0..<x1, y0..<y1)
    }

    private func pixel(_ x: Int, _ y: Int) -> (red: Int, green: Int, blue: Int) {
        let index = (y * width + x) * 4
        return (Int(bytes[index]), Int(bytes[index + 1]), Int(bytes[index + 2]))
    }

    private static func chroma(_ value: (red: Int, green: Int, blue: Int)) -> Int {
        max(value.red, value.green, value.blue) - min(value.red, value.green, value.blue)
    }

    private static func luma(_ value: (red: Int, green: Int, blue: Int)) -> Int {
        (299 * value.red + 587 * value.green + 114 * value.blue) / 1000
    }
}
