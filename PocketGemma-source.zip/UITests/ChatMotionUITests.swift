import XCTest

final class ChatMotionUITests: XCTestCase {
    /// Stability gate after rolling back end-visibility observation. The stricter
    /// jump-button test below stays unchanged and its known failure is retained.
    @MainActor func testManualScrollAndComposerRemainResponsiveAfterGrowingReply() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--growing-reply", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Stability check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        XCTAssertEqual(input.value as? String, "")
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        let reading = app.scrollViews["chat-conversation"]
        func swipe(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, app.textViews["chat-input"].frame.minY - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipe(up: false); swipe(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        swipe(up: true); swipe(up: true)
        capture("manual-scroll-stability", app: app)
        // An input/edit after both drag directions proves that the event loop
        // still services interaction instead of spinning in lazy placement.
        input.tap(); input.typeText("Still responsive")
        XCTAssertEqual(input.value as? String, "Still responsive")
        XCTAssertTrue(app.keyboards.firstMatch.exists)
        capture("composer-responsive-after-manual-scroll", app: app)
    }

    @MainActor func testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition() throws {
        try mixedAttachmentStream([])
    }
    /// Probe: the same with every message a lazy row, as before 1.0.70.
    @MainActor func testProbeMixedAttachmentAllLazy() throws { try mixedAttachmentStream(["--probe-all-lazy"]) }
    /// Probe: the latest messages as one item of the lazy stack, as in 1.0.71.
    @MainActor func testProbeMixedAttachmentEagerItem() throws { try mixedAttachmentStream(["--probe-eager-item"]) }

    @MainActor private func mixedAttachmentStream(_ flags: [String]) throws {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--e2b", "--long-chat", "--attachment-fixtures", "--layout-stress", "--layout-metrics"] + flags
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        importFixture("sample-image", extension: "png", app: app)
        let draft = app.descendants(matching: .any).matching(identifier: "draft-attachments").firstMatch
        XCTAssertTrue(draft.waitForExistence(timeout: 5))
        XCTAssertLessThanOrEqual(draft.frame.height, 84)
        let preview = app.buttons["添付ファイルを開く: sample-image.png"]
        XCTAssertTrue(preview.exists)
        XCTAssertLessThanOrEqual(preview.frame.height, 76)
        capture("compact-image-draft", app: app)
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Layout stress")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["停止する"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let reading = app.scrollViews["chat-conversation"]
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        reading.swipeDown(); reading.swipeDown()
        let jumpShown = app.buttons["chat-jump-latest"].waitForExistence(timeout: 4)
        let suffix = flags.isEmpty ? "" : "-probe"
        let swipedInk = readingInk(app)
        print("MIXED after-swipes\(suffix) ink=\(swipedInk) jump=\(jumpShown) \(debug.label.prefix(200))")
        capture("mixed-after-swipes" + suffix, app: app)
        XCTAssertTrue(jumpShown)
        XCTAssertGreaterThan(swipedInk, Self.drawnInk, "Scrolled up during a reply, the conversation must stay drawn")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 15))
        let streamedInk = readingInk(app)
        print("MIXED after-stream\(suffix) ink=\(streamedInk) jump=\(app.buttons["chat-jump-latest"].exists) \(debug.label.prefix(200))")
        capture("mixed-after-stream" + suffix, app: app)
        XCTAssertTrue(app.buttons["chat-jump-latest"].exists, "Finishing a stream must not move an older-message reader")
        XCTAssertGreaterThan(streamedInk, Self.drawnInk, "The finished reply must leave the conversation drawn")
        app.buttons["chat-jump-latest"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "レイアウト検証12：")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["layout-metrics-export"].tap()
        let json = try XCTUnwrap(app.buttons["layout-metrics-export"].value as? String)
        let data = try XCTUnwrap(json.data(using: .utf8))
        let metrics = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        // Keep the observations even when a layout assertion fails.
        let attachment = XCTAttachment(data: data, uniformTypeIdentifier: "public.json")
        attachment.name = "ui-layout-and-main-display-link-metrics"; attachment.lifetime = .keepAlways; add(attachment)
        XCTAssertGreaterThan((metrics["geometrySamples"] as? Int) ?? 0, 3)
        XCTAssertEqual((metrics["maximumLayoutOverlapPoints"] as? Double) ?? -1, 0, accuracy: 0.5)
        XCTAssertGreaterThan((metrics["displayLinkSamples"] as? Int) ?? 0, 0)
        capture("mixed-attachment-stream-layout", app: app)
    }

    @MainActor func testInlinePhotoDockAndRepeatedMenuOpenClose() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        // Let launch settle and each menu finish opening before the outside
        // tap, as the glass morph test does; a tap mid-morph can be dropped.
        Thread.sleep(forTimeInterval: 1.0)
        for _ in 0..<3 {
            app.buttons["chat-add-menu"].tap()
            XCTAssertTrue(menuItem("chat-attach-photos", "写真", app).waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            dismissMenu(menuItem("chat-attach-photos", "写真", app), app: app)
        }
        app.buttons["chat-add-menu"].tap(); menuItem("chat-attach-photos", "写真", app).tap()
        let dock = app.descendants(matching: .any).matching(identifier: "photo-dock").firstMatch
        XCTAssertTrue(dock.waitForExistence(timeout: 5))
        // Where the sheet and the composer sit as it opens and a moment
        // later (the two-row composer's checks found the dock 874pt tall).
        print("PHOTO-SHEET opened: dock=\(dock.frame) composer=\(app.descendants(matching: .any)["chat-composer"].frame)")
        capture("composer-photo-dock", app: app)
        // The system's "Private Access to Photos" note covers the grid once
        // it loads; while it shows, the dock read screen-sized (874pt) though
        // the card on screen was compact. Measure once it is dismissed.
        let privacyNote = app.buttons["OK"]
        let noted = privacyNote.waitForExistence(timeout: 12)
        print("PHOTO-SHEET privacy note: shown=\(noted) dock=\(dock.frame)")
        if noted { privacyNote.tap(); sleep(1) }
        print("PHOTO-SHEET later: dock=\(dock.frame) composer=\(app.descendants(matching: .any)["chat-composer"].frame)")
        capture("composer-photo-dock-later", app: app)
        XCTAssertLessThan(dock.frame.height, app.frame.height * 0.5)
        XCTAssertGreaterThan(dock.frame.minY, app.buttons["chat-model-settings"].frame.maxY)
        XCTAssertTrue(app.textViews["chat-input"].isHittable)
        // Messages leaves clear room between the field and the card.
        sleep(1)
        let field = app.descendants(matching: .any)["chat-composer"]
        let gap = dock.frame.minY - field.frame.maxY
        print("PHOTO-SHEET gap: field=\(field.frame.maxY) sheet=\(dock.frame.minY) gap=\(gap)")
        capture("inline-photo-grid", app: app)
        // iMessage-style: tapping a photo adds it to the draft immediately.
        // The privacy note was handled above; tap it if it shows again late.
        let privacyOK = app.buttons["OK"]
        if privacyOK.waitForExistence(timeout: 2) { privacyOK.tap() }
        // The grid is a remote system view; its cells are not hittable
        // elements, so tap the first cell's center by coordinate.
        // While the library loads, the only image is the spinner.
        let loading = dock.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "読み込み中")).firstMatch
        if loading.exists {
            _ = XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"),
                                                                 object: loading)], timeout: 15)
        }
        let photo = dock.images.firstMatch
        let picked = photo.waitForExistence(timeout: 10)
        if picked {
            // The first tap can land while the grid is still settling, so
            // allow one more.
            let draft = app.descendants(matching: .any)["draft-attachments"]
            photo.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            if !draft.waitForExistence(timeout: 6) {
                print("PHOTO-SHEET first tap missed: photo=\(photo.frame) sheet=\(dock.frame)")
                photo.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            }
            XCTAssertTrue(draft.waitForExistence(timeout: 8),
                          "A tapped photo must appear in the draft without a confirm step")
            capture("inline-photo-picked", app: app)
        }
        // The card is a sheet, as in Messages: swiping up grows it to full
        // height and swiping down returns it to the compact card.
        let compactHeight = dock.frame.height
        let origin = app.coordinate(withNormalizedOffset: .zero)
        func drag(fromY y: CGFloat, by dy: CGFloat) {
            origin.withOffset(CGVector(dx: dock.frame.midX, dy: y))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: dock.frame.midX, dy: y + dy)),
                       withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        // Does a swipe on the grid itself resize the sheet? The grid is a
        // remote view, so this is reported rather than required.
        drag(fromY: dock.frame.midY + 40, by: -200)
        sleep(1)
        let afterGridSwipe = dock.frame.height
        print("PHOTO-SHEET grid swipe up: compact=\(compactHeight) after=\(afterGridSwipe)")
        if afterGridSwipe < compactHeight + 80 {
            // The grabber at the top edge always resizes the sheet.
            drag(fromY: dock.frame.minY + 6, by: -300)
            sleep(1)
        }
        let expandedHeight = dock.frame.height
        print("PHOTO-SHEET expanded: height=\(expandedHeight) top=\(dock.frame.minY)")
        XCTAssertGreaterThan(expandedHeight, compactHeight + 80,
                             "The card grows to full height (compact \(compactHeight), now \(expandedHeight))")
        // With a photo picked, full height shows Messages' done check.
        let done = app.buttons["photo-done"]
        if picked {
            XCTAssertTrue(done.waitForExistence(timeout: 3), "The done check appears once a photo is picked")
            print("PHOTO-SHEET done: frame=\(done.frame) sheet=\(dock.frame)")
        }
        capture("expanded-inline-photo-grid", app: app)
        drag(fromY: dock.frame.minY + 6, by: expandedHeight - compactHeight)
        sleep(1)
        print("PHOTO-SHEET collapsed: exists=\(dock.exists) height=\(dock.frame.height)")
        XCTAssertTrue(dock.exists, "Swiping down from full height returns to the card")
        XCTAssertEqual(dock.frame.height, compactHeight, accuracy: 4)
        XCTAssertFalse(done.exists, "The compact card is the bare grid")
        capture("photo-sheet-collapsed", app: app)
        if picked {
            // Done closes the picker and keeps the photo in the draft.
            drag(fromY: dock.frame.minY + 6, by: -300)
            XCTAssertTrue(done.waitForExistence(timeout: 3))
            done.tap()
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: dock)
            waitForExpectations(timeout: 4)
            XCTAssertTrue(app.descendants(matching: .any)["draft-attachments"].exists)
            app.buttons["chat-add-menu"].tap(); menuItem("chat-attach-photos", "写真", app).tap()
            XCTAssertTrue(dock.waitForExistence(timeout: 5))
        }
        // Like the keyboard it replaces, the panel closes when the field is tapped.
        app.textViews["chat-input"].tap()
        expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: dock)
        waitForExpectations(timeout: 4)
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
        // Checked last so a miss still leaves every screenshot above.
        XCTAssertEqual(gap, 21, accuracy: 3, "The card keeps Messages' gap below the field")
    }

    @MainActor func testHistorySettingsAndDeveloperVisibilityPersist() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        openSettingsFromHistory(app)
        let row = app.buttons["settings-row-developer"], toggle = app.switches["developer-settings-toggle"]
        // 開発者設定 is hidden until revealed (three three-finger swipes on
        // 設定's rows; the test build reveals it with a launch argument).
        XCTAssertTrue(app.buttons["settings-row-licenses"].waitForExistence(timeout: 3))
        XCTAssertFalse(row.exists)
        app.terminate(); app.launchArguments = ["--developer-unlocked"]; app.launch()
        openSettingsFromHistory(app)
        XCTAssertTrue(row.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR developer row \(row.frame) licenses \(app.buttons["settings-row-licenses"].frame)")
        capture("settings-developer-row", app: app)
        openSettingsRow("developer", title: "開発者設定", app: app)
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        XCTAssertEqual(toggle.value as? String, "0")
        XCTAssertFalse(app.staticTexts["推論の診断"].exists)
        // Memory release is a developer-only item.
        XCTAssertFalse(app.buttons["AIのメモリを解放する"].exists)
        XCTAssertFalse(app.staticTexts["Claudeについて"].exists)
        capture("daily-settings-developer-off", app: app)
        let switchTop = toggle.frame.minY
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        XCTAssertTrue(app.staticTexts["推論の診断"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR developer switch top before \(switchTop) after on \(toggle.frame.minY)")
        XCTAssertEqual(toggle.frame.minY, switchTop, accuracy: 1, "What the switch adds appears below it")
        capture("history-developer-on", app: app)
        XCTAssertFalse(app.descendants(matching: .any)["update-source-card"].exists, "The AltStore update card is gone")
        XCTAssertTrue(app.buttons["AIのメモリを解放する"].exists)
        capture("developer-settings-visible", app: app)
        // Nothing is measured or read for the diagnostics until asked: one
        // button takes the free space, memory and opening time and loads the
        // two records.
        XCTAssertTrue(app.staticTexts["「診断をまとめて実行」で読み込みます。"].firstMatch.exists)
        let runAll = app.buttons["developer-diagnostics-run"]
        revealModelControl(runAll, in: "developer-list", app: app)
        runAll.tap()
        let result = app.staticTexts["developer-diagnostics-result"]
        expectation(for: NSPredicate(format: "label CONTAINS %@", "iOSが答えるまで"), evaluatedWith: result)
        waitForExpectations(timeout: 8)
        print("HISTORY-SIDEBAR diagnostics: \(result.label.replacingOccurrences(of: "\n", with: " / "))")
        // Both records are read with it.
        expectation(for: NSPredicate(format: "exists == false"),
                    evaluatedWith: app.staticTexts["「診断をまとめて実行」で読み込みます。"].firstMatch)
        waitForExpectations(timeout: 5)
        capture("history-developer-diagnostics", app: app)
        // The developer-only models are listed with the others.
        app.buttons["settings-back"].tap()
        openSettingsRow("models", title: "モデル管理", app: app)
        XCTAssertTrue(app.buttons["model-use-qwen3-06b"].exists, "Developer settings make Qwen usable")
        app.buttons["settings-close"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 1, "Opening settings must not create a chat")
        // Left on, 開発者設定 stays after a relaunch.
        app.terminate(); app.launchArguments = []; app.launch()
        openSettingsFromHistory(app)
        XCTAssertTrue(row.waitForExistence(timeout: 3), "On, 開発者設定 stays in 設定")
        openSettingsRow("developer", title: "開発者設定", app: app)
        XCTAssertEqual(toggle.value as? String, "1")
        let onTop = toggle.frame.minY
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "0")
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertFalse(app.staticTexts["推論の診断"].exists)
        print("HISTORY-SIDEBAR developer switch top before \(onTop) after off \(toggle.frame.minY)")
        XCTAssertTrue(toggle.isHittable)
        // Turned off, the model list ends at its last line: no empty page
        // below it (1.0.53 kept the taller list's height).
        app.buttons["settings-back"].tap()
        openSettingsRow("models", title: "モデル管理", app: app)
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists)
        // iCloud's line is the list's last since web search has its own
        // page (1.1.0 (230)).
        let list = app.scrollViews["model-list"], footer = app.staticTexts[Self.cloudHistoryLine]
        // Six swipes: 12B and Qwen2.5 are listed for everyone (1.1.0 (204)).
        for _ in 0..<6 { list.swipeUp() }
        Thread.sleep(forTimeInterval: 1)
        print("HISTORY-SIDEBAR model list end: footer=\(footer.frame) list=\(list.frame)")
        capture("history-developer-off-end", app: app)
        XCTAssertTrue(footer.isHittable, "The list's last line is on screen at its end")
        XCTAssertLessThan(list.frame.maxY - footer.frame.maxY, 140, "No blank space below the last line")
        // Off, 開発者設定 is hidden again the next time 設定 opens.
        app.buttons["settings-close"].tap(); app.buttons["history-settings"].tap()
        XCTAssertTrue(app.buttons["settings-row-licenses"].waitForExistence(timeout: 4))
        XCTAssertFalse(row.exists, "Off, 開発者設定 is hidden again")
        openSettingsRow("models", title: "モデル管理", app: app)
        app.buttons["model-generation-settings"].tap()
        XCTAssertFalse(app.segmentedControls["execution-backend"].exists)
        XCTAssertFalse(app.textFields["setting-TopK"].exists)
        XCTAssertEqual(app.textFields["setting-Max Tokens"].value as? String, "4096")
        capture("basic-generation-settings", app: app)
    }

    /// Settings lists the open-source licenses and shows each text. The math
    /// fonts' licenses come from SwiftMath's own bundle; the packages'
    /// LICENSE files are added by the device build only (build-ios.sh).
    @MainActor func testOpenSourceLicensesShowTheirTexts() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch()
        openSettingsFromChat(app)
        // 設定's own row now, below Fieluaの情報.
        openSettingsRow("licenses", title: "オープンソースライセンス", app: app)
        capture("markdown-licenses", app: app)
        app.buttons["license-GUST-FONT-LICENSE.txt"].tap()
        let text = app.descendants(matching: .any)["license-text"]
        expectation(for: NSPredicate(format: "label CONTAINS %@", "GUST Font License"), evaluatedWith: text)
        waitForExpectations(timeout: 3)
        capture("markdown-license-text", app: app)
    }

    @MainActor private func revealModelControl(_ control: XCUIElement, in list: String = "model-list", app: XCUIApplication) {
        for _ in 0..<15 { if control.exists && control.isHittable { break }; app.scrollViews[list].swipeUp() }
        XCTAssertTrue(control.isHittable)
    }

    /// 設定's 開発者設定 (shown by --developer-unlocked) with its switch on.
    @MainActor private func turnOnDeveloperSettings(_ app: XCUIApplication) {
        openSettingsFromChat(app)
        openSettingsRow("developer", title: "開発者設定", app: app)
        let toggle = app.switches["developer-settings-toggle"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
    }

    @MainActor func testModelDeleteAsksFirstAndOffersDownloadAgain() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch()
        openModelList(app)
        let delete = app.buttons["model-delete-gemma-4-e2b"]
        revealModelControl(delete, app: app)
        capture("history-model-delete-button", app: app)
        delete.tap()
        let confirm = app.alerts.buttons["削除"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        capture("history-model-delete-alert", app: app)
        confirm.tap()
        XCTAssertTrue(app.buttons["model-download-gemma-4-e2b"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["model-delete-gemma-4-e2b"].exists)
        XCTAssertTrue(app.buttons["model-delete-gemma-4-e4b"].exists, "Other models keep theirs")
        capture("history-model-deleted", app: app)
    }

    /// The download's Live Activity from the Home Screen: the model's mark
    /// on the left of the Dynamic Island, the percentage on the right.
    @MainActor func testDownloadLiveActivityInDynamicIsland() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--download-activity"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-compact", height: 140)
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = "history-download-home"; screen.lifetime = .keepAlways; add(screen)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-expanded", height: 260)
        app.activate()
    }

    /// A Qwen download: the island shows the model's mark from the app's
    /// model list (Qwen2.5's cube) on the left, the percentage on the right.
    @MainActor func testQwenDownloadLiveActivityInDynamicIsland() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--download-activity", "--download-activity-qwen"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR qwen \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-qwen", height: 140)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-qwen-expanded", height: 260)
        app.activate()
    }

    /// Two models at once share one activity: one model on each side of the
    /// island, and a row for each when it is pressed.
    @MainActor func testTwoDownloadLiveActivitiesInDynamicIsland() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--download-activity", "--download-activity-two"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started 2")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-two", height: 140)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-two-expanded", height: 260)
        app.activate()
    }

    /// Pulling past the end of a conversation, as in ChatGPT: a ring fills,
    /// turns into the new chat button, and letting go opens a new chat.
    @MainActor func testPullPastEndOpensNewChat() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--pull-snapshot"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let first = app.staticTexts["画面の動きを確認"]
        XCTAssertTrue(first.waitForExistence(timeout: 3))
        sleep(1)
        // A short pull springs back and keeps the conversation.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.6))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)),
                   withVelocity: .slow, thenHoldForDuration: 0.3)
        Thread.sleep(forTimeInterval: 1.2)
        XCTAssertTrue(first.exists, "A short pull keeps the conversation")
        XCTAssertFalse(app.descendants(matching: .any)["chat-empty"].exists)
        // A long pull fills the ring; letting go there opens a new chat.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.72))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.22)),
                   withVelocity: .slow, thenHoldForDuration: 0.8)
        let snapshots = app.descendants(matching: .any)["pull-snapshots"]
        XCTAssertTrue(snapshots.waitForExistence(timeout: 3))
        print("HISTORY-SIDEBAR pull: \(snapshots.label)")
        capture("history-pull-snapshots", app: app)
        let snapshotCount = snapshots.label
        snapshots.tap()
        XCTAssertTrue(app.descendants(matching: .any)["chat-empty"].waitForExistence(timeout: 3))
        XCTAssertFalse(first.exists, "The pull opened a new, empty chat")
        capture("history-pull-new-chat", app: app)
        XCTAssertEqual(snapshotCount, "pull snapshots 2", "The ring half full, then the button")
    }

    @MainActor private func captureScreenTop(_ name: String, height: CGFloat) {
        let image = XCUIScreen.main.screenshot().image
        guard let full = image.cgImage,
              let top = full.cropping(to: CGRect(x: 0, y: 0, width: CGFloat(full.width),
                                                 height: min(CGFloat(full.height), height * image.scale))) else { return }
        let attachment = XCTAttachment(image: UIImage(cgImage: top, scale: image.scale, orientation: .up))
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    /// E4B (the default model) takes photos at 70 image tokens: the photo
    /// item opens the inline picker as E2B's does, and the draft stays.
    @MainActor func testE4BPhotosOpenThePickerAndKeepTheDraft() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        input.tap(); input.typeText("Keep my draft")
        app.buttons["chat-add-menu"].tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 3))
        XCTAssertTrue(menuItem("chat-attach-files", "ファイル", app).exists)
        XCTAssertTrue(menuItem("chat-attach-video", "動画", app).exists)
        // No カメラ since 1.1.0 (191) (user, 2026-10-25).
        XCTAssertFalse(menuItem("chat-attach-camera", "カメラ", app).exists, "カメラ is gone")
        capture("e4b-attachments-available", app: app)
        photos.tap()
        // Photos opens the inline picker, not the locked-item guidance.
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "photo-dock").firstMatch
            .waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["E2Bで新しいチャットを開く"].exists)
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].exists, "Photos must not switch models")
        XCTAssertEqual(input.value as? String, "Keep my draft")
        capture("e4b-photo-dock", app: app)
    }

    @MainActor func testSwitchFromE2BWithDraftAttachmentCannotSendToE4B() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--attachment-fixtures"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        // E2B's menu has no カメラ either since 1.1.0 (191).
        XCTAssertTrue(menuItem("chat-attach-photos", "写真", app).waitForExistence(timeout: 3))
        XCTAssertFalse(menuItem("chat-attach-camera", "カメラ", app).exists, "カメラ is gone for E2B too")
        chooseMenuAction("sample-image", app: app)
        XCTAssertTrue(app.buttons["添付を外す: sample-image.png"].waitForExistence(timeout: 10))
        openModelList(app)
        let e4b = app.buttons["model-use-gemma-4-e4b"]
        XCTAssertTrue(e4b.waitForExistence(timeout: 4)); e4b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["添付を外す: sample-image.png"].waitForNonExistence(timeout: 3))
        XCTAssertFalse(app.buttons["送信する"].isEnabled)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Text still works")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Text still works"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 6))
        capture("e4b-text-after-attachment-switch", app: app)
    }

    @MainActor func testLargeTypeReducedMotionAttachmentMenuRemainsUsable() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--large-type", "--reduce-motion", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 4)); XCTAssertTrue(photos.isHittable)
        // The system menu sets its rows' height: an unlocked one-line row was
        // 42pt in the simulator (run 39441056590); a locked row's 調整中
        // subtitle makes it taller. The row must lie whole on the screen.
        XCTAssertTrue(app.windows.firstMatch.frame.contains(photos.frame), "\(photos.frame)")
        capture("large-type-dark-attachment-menu", app: app)
        // カメラ is gone since 1.1.0 (191) and 動画 opens since 1.1.0 (192),
        // so nothing in E4B's menu is locked any more: no guide to check.
        XCTAssertFalse(menuItem("chat-attach-camera", "カメラ", app).exists)
        let video = menuItem("chat-attach-video", "動画", app)
        XCTAssertTrue(video.isHittable)
        dismissMenu(photos, app: app)
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].exists, "Dismissing must not switch models")
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
    }

    /// The app keeps the default text size whatever iOS's 文字サイズ says
    /// (2026-10-23). SwiftUI takes it from FixedTextSize; the composer's
    /// field and the plus menu's rows are UIKit's, so with iOS at its
    /// largest and at its smallest size they must measure as at iOS's
    /// default.
    @MainActor func testTextSizeIgnoresIOSLargestSize() {
        textSizeIgnoresIOS("UICTContentSizeCategoryAccessibilityXXXL", variant: "largest")
    }
    @MainActor func testTextSizeIgnoresIOSSmallestSize() {
        textSizeIgnoresIOS("UICTContentSizeCategoryXS", variant: "smallest")
    }

    @MainActor private func textSizeIgnoresIOS(_ category: String, variant: String) {
        continueAfterFailure = false
        let app = PreviewApp()
        let base = textSizeMeasures(app, category: nil, name: "composer-text-size-default")
        let set = textSizeMeasures(app, category: category, name: "composer-text-size-\(variant)")
        XCTAssertTrue(set.probe.hasPrefix("iOS \(category) "), "iOS's size reached the app: \(set.probe)")
        XCTAssertEqual(set.field, base.field, accuracy: 0.5, "The composer's field")
        XCTAssertEqual(set.row, base.row, accuracy: 0.5, "The plus menu's row")
    }

    /// The probe's text, the composer field's height and the plus menu's
    /// 写真 row height, at iOS's `category` (its default when nil).
    @MainActor private func textSizeMeasures(_ app: XCUIApplication, category: String?, name: String)
        -> (probe: String, field: CGFloat, row: CGFloat) {
        app.launchArguments = Self.keepOpen + ["--markdown-article", "--show-text-size"]
            + (category.map { ["-UIPreferredContentSizeCategoryName", $0] } ?? [])
        app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        // The probe reads the window scene's trait half a second in.
        let probe = app.staticTexts["preview-text-size"]
        XCTAssertTrue(probe.waitForExistence(timeout: 3))
        let read = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", " app UICT"), object: probe)
        XCTAssertEqual(XCTWaiter().wait(for: [read], timeout: 4), .completed, probe.label)
        XCTAssertTrue(probe.label.hasSuffix(" app UICTContentSizeCategoryL"), "The scene's size: \(probe.label)")
        let field = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture(name, app: app)
        plus.tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.6)
        capture("\(name)-menu", app: app)
        print("TEXT-SIZE \(name) probe=\(probe.label) field=\(field.frame) row=\(photos.frame)")
        let measures = (probe: probe.label, field: field.frame.height, row: photos.frame.height)
        app.terminate()
        return measures
    }

    /// E4B's 高速・じっくり考える replaces its image-token picker in the
    /// developer configuration (1.1.0 (248): two modes, 深く no longer
    /// offered), and a saved じっくり考える survives a relaunch.
    @MainActor func testE4BPhotoDetailIsSavedWithTheModel() {
        continueAfterFailure = false
        // Developer settings come from the launch argument, not the unlock
        // path other cases cover: through it this case took 141s on a slow
        // runner in run 41204660865, past its 120s bound.
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--developer-settings"]; app.launch()
        openConfiguration(app)
        let detail = app.buttons["photo-detail"]
        func shown() -> String { "\(detail.label) \(detail.value as? String ?? "")" }
        revealConfigurationControl(detail, app: app)
        XCTAssertFalse(app.buttons["visual-token-budget"].exists, "The photo detail sets E4B's image tokens")
        XCTAssertTrue(shown().contains("高速"), shown())
        detail.tap()
        let deeper = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        XCTAssertTrue(deeper.waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "深く")).firstMatch.exists,
                       "深く is no longer offered")
        deeper.tap()
        XCTAssertTrue(shown().contains("じっくり考える"), shown())
        // The form only scrolls down here, so each mode checks thinking below
        // the picker once: じっくり考える always thinks, 高速 never.
        let thinking = app.switches["enable-thinking"]
        revealConfigurationControl(thinking, app: app)
        XCTAssertFalse(thinking.isEnabled, "じっくり考える always thinks")
        XCTAssertEqual(thinking.value as? String, "1")
        capture("e4b-photo-detail-deeper", app: app)
        app.buttons["configuration-save"].tap()
        app.terminate(); app.launchArguments = ["--developer-settings"]; app.launch()
        openConfiguration(app)
        revealConfigurationControl(detail, app: app)
        XCTAssertTrue(shown().contains("じっくり考える"), "A saved じっくり考える must survive a relaunch: \(shown())")
        detail.tap()
        let fast = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "高速")).firstMatch
        XCTAssertTrue(fast.waitForExistence(timeout: 3)); fast.tap()
        XCTAssertTrue(shown().contains("高速"), shown())
        revealConfigurationControl(thinking, app: app)
        XCTAssertFalse(thinking.isEnabled, "高速 never thinks")
        XCTAssertEqual(thinking.value as? String, "0")
        capture("e4b-photo-detail-fast-no-thinking", app: app)
    }

    /// じっくり考える (さらに深く until 1.1.0 (247)) with the address space for
    /// it, as on the TestFlight build, always thinks: the configuration
    /// shows the thinking switch on and fixed. Saved, it stays じっくり考える
    /// on a launch without the room, where it runs as 深く at 140 and never
    /// thinks: the switch shows off and fixed, and the help says why. A
    /// case of its own, since with a third launch the case above came within
    /// a few seconds of its 120s bound (125s in run 39697821838).
    @MainActor func testE4BDeeperAlwaysThinks() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--developer-settings"]; app.launch()
        openConfiguration(app)
        let detail = app.buttons["photo-detail"]
        func shown() -> String { "\(detail.label) \(detail.value as? String ?? "")" }
        revealConfigurationControl(detail, app: app)
        XCTAssertTrue(shown().contains("高速"), shown())
        detail.tap()
        let deeper = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        XCTAssertTrue(deeper.waitForExistence(timeout: 3)); deeper.tap()
        XCTAssertTrue(shown().contains("じっくり考える（280）"), shown())
        let thinking = app.switches["enable-thinking"]
        revealConfigurationControl(thinking, app: app)
        XCTAssertFalse(thinking.isEnabled, "じっくり考える always thinks")
        XCTAssertEqual(thinking.value as? String, "1")
        capture("e4b-photo-detail-deeper-thinking", app: app)
        app.buttons["configuration-save"].tap()
        app.terminate(); app.launchArguments = ["--developer-settings", "--narrow-address-space"]; app.launch()
        openConfiguration(app)
        revealConfigurationControl(detail, app: app)
        print("REPLY-MODES config-fallback detail='\(shown())'")
        XCTAssertTrue(shown().contains("じっくり考える（140）"), "Saved, it stays じっくり考える, at 140 without the room: \(shown())")
        revealConfigurationControl(thinking, app: app)
        let help = app.staticTexts["setting-help-enable-thinking"]
        print("REPLY-MODES config-fallback thinking=\(thinking.value as? String ?? "") enabled=\(thinking.isEnabled) help='\(help.label)'")
        XCTAssertFalse(thinking.isEnabled, "Without the room it never thinks")
        XCTAssertEqual(thinking.value as? String, "0")
        XCTAssertTrue(help.label.contains("じっくり考えるでも使いません"), help.label)
        capture("e4b-photo-detail-deeper-fallback", app: app)
    }

    /// 1.1.0 (248), the user's directive of 2026-10-31: where the launch
    /// lacks the address space for じっくり考える, it is still offered and
    /// chosen, but runs as 深く without thinking, never unannounced: the
    /// chat says so under the model's name, the pill shows a caution sign
    /// and says so to VoiceOver, and the menu ends with a dimmed row that
    /// says so. Changing the mode keeps the chat's messages, light and dark.
    @MainActor func testE4BDeeperFallbackSaysItDoesNotThink() {
        continueAfterFailure = false
        let app = PreviewApp()
        let pill = app.buttons["composer-photo-detail"], note = app.descendants(matching: .any)["chat-reply-mode-note"]
        let fast = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "高速")).firstMatch
        let deeper = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        let fallback = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "今は考える処理を使えません")).firstMatch
        let fallbackValue = "じっくり考える。今は考える処理を使えません"
        app.launchArguments = ["--reset-settings", "--narrow-address-space"]; app.launch()
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        XCTAssertEqual(pill.value as? String, "高速")
        XCTAssertFalse(note.exists, "高速 runs as itself: no note")
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        XCTAssertTrue(deeper.waitForExistence(timeout: 3), "じっくり考える is offered without the room too")
        XCTAssertTrue(fast.exists)
        XCTAssertFalse(fallback.exists, "No note while 高速 is chosen")
        deeper.tap()
        XCTAssertTrue(gone(deeper))
        XCTAssertEqual(pill.value as? String, fallbackValue)
        XCTAssertTrue(note.waitForExistence(timeout: 3), "The chat says it answers without thinking")
        print("REPLY-MODES fallback note='\(note.label)' pill=\(pill.frame) value='\(pill.value as? String ?? "")'")
        XCTAssertEqual(note.label, "アドレス空間が足りないため、じっくり考えるでも今は考えずに答えます。")
        Thread.sleep(forTimeInterval: 0.6)
        capture("reply-modes-fallback-chat-light", app: app)
        pill.tap()
        XCTAssertTrue(fallback.waitForExistence(timeout: 3), "The menu says so")
        print("REPLY-MODES fallback menu-row='\(fallback.label)' enabled=\(fallback.isEnabled)")
        XCTAssertFalse(fallback.isEnabled, "A note, not a choice")
        // Its second line (the note) is the row's subtitle, seen in the
        // shot; the label holds the title alone.
        XCTAssertEqual(fallback.label, "今は考える処理を使えません")
        Thread.sleep(forTimeInterval: 0.8)
        capture("reply-modes-fallback-menu-light", app: app)
        deeper.tap()
        XCTAssertTrue(gone(deeper))
        app.terminate()
        // Saved, じっくり考える stays chosen; a long chat in dark mode keeps
        // its messages through 高速 and back.
        app.launchArguments = ["--narrow-address-space", "--long-chat", "--dark"]; app.launch()
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        XCTAssertEqual(pill.value as? String, fallbackValue)
        let latest = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "最新の返信です")).firstMatch
        XCTAssertTrue(latest.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.0)
        capture("reply-modes-fallback-pill-dark", app: app)
        for (item, value) in [(fast, "高速"), (deeper, fallbackValue)] {
            pill.tap()
            XCTAssertTrue(item.waitForExistence(timeout: 3))
            // Opened on じっくり考える, so the dark menu shows the fallback row.
            if item == fast { capture("reply-modes-fallback-menu-dark", app: app) }
            item.tap()
            XCTAssertTrue(gone(item))
            XCTAssertEqual(pill.value as? String, value)
            XCTAssertTrue(latest.exists, "\(value): the chat keeps its messages")
        }
    }

    /// The two modes and the note without the room in English, as in the
    /// app's other languages (String Catalog): Fast and Think Deeply.
    @MainActor func testE4BReplyModesInEnglish() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["-AppleLanguages", "(en)", "--reset-settings", "--narrow-address-space"]; app.launch()
        let pill = app.buttons["composer-photo-detail"], note = app.descendants(matching: .any)["chat-reply-mode-note"]
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        XCTAssertEqual(pill.value as? String, "Fast")
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        let deeper = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Think Deeply")).firstMatch
        XCTAssertTrue(deeper.waitForExistence(timeout: 3))
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Fast")).firstMatch.exists)
        deeper.tap()
        XCTAssertTrue(gone(deeper))
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        print("REPLY-MODES en note='\(note.label)' value='\(pill.value as? String ?? "")'")
        XCTAssertEqual(pill.value as? String, "Think Deeply. Thinking isn't available right now")
        XCTAssertEqual(note.label, "There isn’t enough address space, so Think Deeply answers without thinking for now.")
        Thread.sleep(forTimeInterval: 0.6)
        capture("reply-modes-fallback-chat-en", app: app)
        pill.tap()
        let fallback = app.buttons["composer-photo-detail-fallback"]
        XCTAssertTrue(fallback.waitForExistence(timeout: 3))
        XCTAssertEqual(fallback.label, "Thinking isn't available right now")
        Thread.sleep(forTimeInterval: 0.6)
        capture("reply-modes-fallback-menu-en", app: app)
    }

    /// 初回起動 (2026-10-24, 初回起動オンボーディング): on a phone with no
    /// model, ようこそ's orb and wordmark opening (screenshots as quick as
    /// they come), モデル with every model of モデル管理 and E2B recommended
    /// and chosen (1.1.0 (219)), its download's size and the internet it
    /// needs said before 続ける starts it, 入力スタイル's phones bound to the
    /// setting, 準備完了 waiting for the download and then opening the chat
    /// with the model and the composer chosen and the try questions over
    /// the field; once, never again.
    @MainActor func testOnboardingFirstLaunchDownloadsAndOpensTheChat() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--fresh-install", "--download-progress",
                               "--haptics-trace", "--bloom-delay"]
        app.launch()
        captureBloom("onboarding-bloom-light", app: app)
        let played = trace(app, containing: "finished", timeout: 3)
        XCTAssertTrue(played.contains("bloom finished, played 7 of 7"), played)
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.2)
        capture("onboarding-1-welcome-light", app: app)
        captureOrb("onboarding-orb-light", app: app)
        welcome.tap()
        // The models by series (1.1.0 (269)): Gemma, Qwen, LFM and Phi,
        // closed; Gemma names E2B, recommended and chosen.
        let gemma = app.buttons["onboarding-family-gemma"]
        XCTAssertTrue(gemma.waitForExistence(timeout: 5))
        XCTAssertTrue(gemma.label.contains("おすすめ"), gemma.label)
        XCTAssertTrue((gemma.value as? String ?? "").replacingOccurrences(of: "\u{00A0}", with: " ").contains("Gemma 4 E2Bを選択中"),
                      "\(gemma.value ?? "")")
        let downloadNote = app.descendants(matching: .any)["onboarding-download-note"]
        XCTAssertTrue(downloadNote.exists)
        let said = downloadNote.label.replacingOccurrences(of: "\u{00A0}", with: " ")
        XCTAssertTrue(said.contains("Gemma 4 E2B") && said.contains("GB") && said.contains("ダウンロード"), said)
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-2-model-light", app: app)
        // Every model モデル管理 lists, in its series, E2B first; Qwen3 0.6B
        // only with developer settings.
        var listed: [String] = []
        for (key, ids) in [("qwen", ["qwen35-4b", "qwen25-15b"]), ("lfm", ["lfm3-17b", "lfm3-vl-2b", "lfm3-omni-2b"]),
                           ("phi", ["phi-4-mini-reasoning"]), ("gemma", ["gemma-4-e2b", "gemma-4-e4b", "gemma-4-12b"])] {
            openOnboardingSeries(key, app)
            for id in ids {
                let row = app.buttons["onboarding-model-\(id)"]
                XCTAssertTrue(row.waitForExistence(timeout: 3), "\(id) is in \(key)")
                // Read while its series is open: opening the next closes it.
                listed.append("\(row.identifier)|\(row.label)")
            }
            XCTAssertFalse(app.buttons["onboarding-model-qwen3-06b"].exists, "Qwen3 0.6B is developer-only")
        }
        print("ONBOARDING models " + listed.joined(separator: " "))
        let e4b = app.buttons["onboarding-model-gemma-4-e4b"], e2b = app.buttons["onboarding-model-gemma-4-e2b"]
        XCTAssertLessThan(e2b.frame.minY, e4b.frame.minY, "E2B first")
        XCTAssertTrue(e2b.label.contains("おすすめ") && e2b.isSelected, "E2B, recommended and chosen")
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND identifier != %@",
                                                    "onboarding-model-", "onboarding-model-continue")).allElementsBoundByIndex
        XCTAssertEqual(rows.filter { $0.label.contains("おすすめ") }.count, 1, "One recommended model")
        XCTAssertEqual(rows.filter(\.isSelected).count, 1)
        // Any of them can be chosen; the note follows the choice.
        e4b.tap()
        XCTAssertTrue(e4b.isSelected && !e2b.isSelected)
        XCTAssertTrue(downloadNote.label.replacingOccurrences(of: "\u{00A0}", with: " ").contains("Gemma 4 E4B"), downloadNote.label)
        e2b.tap()
        XCTAssertTrue(e2b.isSelected && !e4b.isSelected)
        app.buttons["onboarding-model-continue"].tap()
        // The download runs on while the next page is read.
        let classic = app.buttons["composer-style-classic"], folding = app.buttons["composer-style-folding"]
        XCTAssertTrue(classic.waitForExistence(timeout: 5))
        XCTAssertTrue(folding.isSelected, "The setting as it is: スマート")
        classic.tap()
        XCTAssertTrue(classic.isSelected && !folding.isSelected)
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-3-keyboard-light", app: app)
        app.buttons["onboarding-keyboard-continue"].tap()
        // 起動時のチャット (1.1.0 (182)): the setting as it is, then chosen.
        let resume = app.buttons["launch-chat-resume"], newChat = app.buttons["launch-chat-newChat"]
        XCTAssertTrue(newChat.waitForExistence(timeout: 5))
        XCTAssertTrue(resume.isSelected, "前回の会話 until another is chosen")
        XCTAssertEqual(resume.label, "前回の会話")
        XCTAssertEqual(newChat.label, "新しいチャット")
        XCTAssertLessThan(resume.frame.maxX, newChat.frame.minX, "前回の会話 on the left")
        newChat.tap()
        XCTAssertTrue(newChat.isSelected && !resume.isSelected)
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-4-launch-light", app: app)
        app.buttons["onboarding-launch-continue"].tap()
        let start = app.buttons["onboarding-ready-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 5))
        let launchRow = app.descendants(matching: .any)["onboarding-ready-launch"].firstMatch
        XCTAssertTrue(launchRow.exists && launchRow.label.contains("新しいチャット"), launchRow.label)
        let status = app.staticTexts["onboarding-ready-status"].firstMatch
        print("ONBOARDING ready-status \(status.label) start-enabled=\(start.isEnabled)")
        capture("onboarding-4-ready-downloading-light", app: app)
        expectation(for: NSPredicate(format: "isEnabled == true"), evaluatedWith: start)
        waitForExpectations(timeout: 10)
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-5-ready-light", app: app)
        XCTAssertFalse(app.buttons["onboarding-ready-later"].exists, "Nothing to skip once ready")
        start.tap()
        let composer = app.descendants(matching: .any)["chat-composer"]
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 5))
        XCTAssertTrue(gone(app.buttons["onboarding-ready-start"]))
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 3), "The chosen model's chat")
        // スタンダード is one bar, 52 pt, since 1.1.0 (255).
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "スタンダード's one bar, as chosen")
        // The empty chat offers its try questions (1.1.0 (219)).
        XCTAssertTrue(app.buttons["chat-try-math"].waitForExistence(timeout: 4), "The try questions over the field")
        XCTAssertTrue(app.buttons["chat-try-summary"].exists && app.buttons["chat-try-document"].exists)
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-6-chat-light", app: app)
        app.terminate(); app.launchArguments = ["--startup", "--keep-composer-style", "--haptics-trace"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["onboarding-welcome-continue"].exists, "Once")
        XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "welcome-haptics-trace").firstMatch.exists,
                       "No bloom, no haptics at a normal launch")
    }

    /// モデルを選ぶ by series (1.1.0 (269), fielua-reports Issue #7): the
    /// card lists Gemma, Qwen, LFM and Phi, closed, above 続ける on one
    /// screen; Gemma names E2B, chosen and recommended, and LFM and Phi say
    /// they are test versions. A series opens in place to its models and
    /// closes the one open before; opening one chooses and downloads
    /// nothing: a model's row chooses, and its series then names it. Phi,
    /// opened at the bottom, shows its row above 続ける. After 続ける, back
    /// on the page, the closed series shows its model's download. Light
    /// with frames of a series opening, of another taking its place and of
    /// one closing (--slow-disclose, SHOT onboarding-series-strip-*); dark
    /// with the largest text on the narrowest phone's width; an iPad.
    /// ONBOARDING-SERIES lines.
    @MainActor func testOnboardingSeriesOpenAndClose() { onboardingSeries("light", ["--slow-disclose", "--download-progress"]) }
    @MainActor func testOnboardingSeriesDarkLargeTextNarrow() {
        onboardingSeries("dark-large-narrow", ["--dark", "--large-type", "--narrow-phone"])
    }
    @MainActor func testOnboardingSeriesOnIPad() { onboardingSeries("ipad", []) }

    @MainActor private func onboardingSeries(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let slow = flags.contains("--slow-disclose")
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--fresh-install"] + flags
        app.launch()
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10)); welcome.tap()
        let next = app.buttons["onboarding-model-continue"]
        let list = app.scrollViews["onboarding-model-list"]
        let keys = ["gemma", "qwen", "lfm", "phi"]
        let series = keys.map { app.buttons["onboarding-family-\($0)"] }
        let gemma = series[0], qwen = series[1], lfm = series[2], phi = series[3]
        XCTAssertTrue(gemma.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        func plain(_ element: XCUIElement) -> String { (element.value as? String ?? "").replacingOccurrences(of: "\u{00A0}", with: " ") }
        func log(_ step: String) {
            print("ONBOARDING-SERIES \(variant) \(step) " + zip(keys, series).map { key, row in
                "\(key)='\(row.label)'|'\(plain(row))'|\(row.frame.integral)" }.joined(separator: " ") + " continue=\(next.frame.integral)")
        }
        // On the large text the list scrolls: the element comes up above 続ける.
        func reveal(_ element: XCUIElement) {
            for _ in 0..<6 {
                if element.exists && element.isHittable && element.frame.maxY <= next.frame.minY + 1 && element.frame.minY >= 40 { return }
                if element.exists && element.frame.minY < 40 { list.swipeDown() } else { list.swipeUp() }
            }
        }
        func modelRows() -> [XCUIElement] {
            app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND identifier != %@",
                                             "onboarding-model-", "onboarding-model-continue")).allElementsBoundByIndex
        }
        // A screenshot strip of the card while a series moves.
        func strip(_ name: String, tapping row: XCUIElement) {
            let window = app.windows.firstMatch.frame
            let top = max(0, gemma.frame.minY - 12) / window.height
            let height = min(1 - top, (next.frame.minY - gemma.frame.minY + 12) / window.height)
            row.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            captureStrip("onboarding-series-strip-\(variant)-\(name)", count: 20, top: top, height: height)
        }
        func tapSeries(_ row: XCUIElement, strip name: String? = nil) {
            reveal(row)
            if slow, let name { strip(name, tapping: row) } else { row.tap() }
        }
        log("closed")
        XCTAssertEqual(modelRows().count, 0, "Only the series at first")
        for row in series { XCTAssertTrue(row.exists && !isOpenSeries(row), row.identifier) }
        for (a, b) in zip(series, series.dropFirst()) {
            XCTAssertLessThan(a.frame.minY, b.frame.minY, "\(a.identifier), then \(b.identifier)")
        }
        if !flags.contains("--large-type") {
            XCTAssertLessThan(phi.frame.maxY, next.frame.minY, "The four series fit above 続ける")
        }
        XCTAssertTrue(gemma.label.contains("おすすめ"), gemma.label)
        XCTAssertTrue(plain(gemma).contains("Gemma 4 E2Bを選択中"), plain(gemma))
        XCTAssertTrue(lfm.label.contains("テスト版") && phi.label.contains("テスト版"), "LFM and Phi are test versions")
        XCTAssertFalse(qwen.label.contains("テスト版") || qwen.label.contains("おすすめ"), qwen.label)
        XCTAssertTrue(plain(qwen).contains("2モデル"), plain(qwen))
        let note = app.descendants(matching: .any)["onboarding-download-note"]
        func noted(_ name: String) -> Bool { note.label.replacingOccurrences(of: "\u{00A0}", with: " ").contains(name) }
        XCTAssertTrue(note.exists && noted("Gemma 4 E2B"), note.label)
        Thread.sleep(forTimeInterval: 0.4)
        capture("onboarding-series-\(variant)-1-closed", app: app)

        // Qwen opens to its models and chooses nothing.
        tapSeries(qwen, strip: "open")
        let qwen35 = app.buttons["onboarding-model-qwen35-4b"], qwen25 = app.buttons["onboarding-model-qwen25-15b"]
        XCTAssertTrue(qwen35.waitForExistence(timeout: 6) && qwen25.exists)
        XCTAssertFalse(app.buttons["onboarding-model-qwen3-06b"].exists, "Qwen3 0.6B is developer-only")
        XCTAssertTrue(isOpenSeries(qwen))
        XCTAssertLessThan(qwen.frame.maxY, qwen35.frame.minY + 1, "Its models under it")
        XCTAssertLessThan(qwen35.frame.minY, qwen25.frame.minY, "Qwen3.5, then Qwen2.5")
        XCTAssertLessThan(qwen25.frame.maxY, lfm.frame.minY + 1, "LFM moved down below them")
        XCTAssertFalse(qwen35.isSelected || qwen25.isSelected, "Opening a series chooses nothing")
        XCTAssertTrue(noted("Gemma 4 E2B") && plain(gemma).contains("Gemma 4 E2Bを選択中"), "…and downloads nothing")
        log("qwen-open")
        Thread.sleep(forTimeInterval: 0.4)
        capture("onboarding-series-\(variant)-2-qwen", app: app)

        // Gemma opens and Qwen closes: one series open at a time.
        tapSeries(gemma, strip: "switch")
        let e2b = app.buttons["onboarding-model-gemma-4-e2b"], e4b = app.buttons["onboarding-model-gemma-4-e4b"]
        let twelve = app.buttons["onboarding-model-gemma-4-12b"]
        XCTAssertTrue(e2b.waitForExistence(timeout: 6) && e4b.exists && twelve.exists)
        XCTAssertTrue(gone(qwen35) && !isOpenSeries(qwen), "Qwen closed")
        XCTAssertLessThan(e2b.frame.minY, e4b.frame.minY, "E2B first")
        XCTAssertLessThan(e4b.frame.minY, twelve.frame.minY, "12B, the test version, last")
        XCTAssertTrue(e2b.label.contains("おすすめ") && e2b.isSelected, "E2B, recommended and chosen")
        XCTAssertEqual(modelRows().filter(\.isSelected).count, 1)
        log("gemma-open")
        Thread.sleep(forTimeInterval: 0.4)
        capture("onboarding-series-\(variant)-3-gemma", app: app)
        // A model's row chooses, and its series names it.
        reveal(e4b); e4b.tap()
        XCTAssertTrue(e4b.isSelected && !e2b.isSelected)
        XCTAssertTrue(plain(gemma).contains("Gemma 4 E4Bを選択中"), plain(gemma))
        XCTAssertTrue(noted("Gemma 4 E4B"), note.label)

        // LFM: its three test versions; the choice can move to one of them.
        tapSeries(lfm)
        let omni = app.buttons["onboarding-model-lfm3-omni-2b"]
        for id in ["lfm3-17b", "lfm3-vl-2b", "lfm3-omni-2b"] {
            XCTAssertTrue(app.buttons["onboarding-model-\(id)"].waitForExistence(timeout: 6), "\(id) is in LFM")
        }
        XCTAssertTrue(gone(e4b), "Gemma closed")
        XCTAssertTrue(plain(gemma).contains("Gemma 4 E4Bを選択中"), "Closed, Gemma still names the choice")
        reveal(omni); omni.tap()
        XCTAssertTrue(omni.isSelected)
        XCTAssertTrue(plain(lfm).contains("LFM3-Omni 2Bを選択中"), plain(lfm))
        XCTAssertFalse(plain(gemma).contains("を選択中"), "The choice left Gemma: \(plain(gemma))")
        XCTAssertTrue(plain(gemma).contains("3モデル"), plain(gemma))
        let testNote = app.descendants(matching: .any)["onboarding-test-version-note"]
        XCTAssertTrue(testNote.waitForExistence(timeout: 2), "A test version chosen says so")
        log("lfm-omni")
        Thread.sleep(forTimeInterval: 0.4)
        capture("onboarding-series-\(variant)-4-lfm", app: app)

        // Phi, at the bottom: its row comes up above 続ける.
        tapSeries(phi)
        let reasoning = app.buttons["onboarding-model-phi-4-mini-reasoning"]
        XCTAssertTrue(reasoning.waitForExistence(timeout: 6))
        Thread.sleep(forTimeInterval: slow ? 3.5 : 0.8)
        print("ONBOARDING-SERIES \(variant) phi-row \(reasoning.frame.integral) continue=\(next.frame.integral) hittable=\(reasoning.isHittable)")
        if !flags.contains("--large-type") {
            XCTAssertTrue(reasoning.isHittable && reasoning.frame.maxY <= next.frame.minY + 1, "Phi's model above 続ける")
        }
        capture("onboarding-series-\(variant)-5-phi", app: app)
        // Closed again: every series closed, the choice kept.
        tapSeries(phi, strip: "close")
        XCTAssertTrue(gone(reasoning) && !isOpenSeries(phi))
        XCTAssertEqual(modelRows().count, 0, "Every series closed")
        XCTAssertTrue(plain(lfm).contains("LFM3-Omni 2Bを選択中"), "The choice is kept: \(plain(lfm))")
        log("closed-again")

        // Back to E2B; 続ける starts its download, as before.
        tapSeries(gemma)
        XCTAssertTrue(e2b.waitForExistence(timeout: 6))
        reveal(e2b); e2b.tap()
        XCTAssertTrue(e2b.isSelected && plain(gemma).contains("Gemma 4 E2Bを選択中"))
        reveal(next); next.tap()
        let keyboard = app.buttons["onboarding-keyboard-continue"]
        XCTAssertTrue(keyboard.waitForExistence(timeout: 5), "On to 入力スタイル")
        guard flags.contains("--download-progress") else { return }
        // Back on the page with E2B on its way: closed, Gemma shows it.
        app.navigationBars.buttons.firstMatch.tap()
        XCTAssertTrue(gemma.waitForExistence(timeout: 5))
        if isOpenSeries(gemma) { tapSeries(gemma) }
        XCTAssertTrue(gone(e2b))
        let closedSays = plain(gemma)
        capture("onboarding-series-\(variant)-6-downloading", app: app)
        openOnboardingSeries("gemma", app)
        let rowSays = e2b.value as? String ?? ""
        print("ONBOARDING-SERIES \(variant) downloading gemma='\(closedSays)' e2b='\(rowSays)'")
        // Unless it finished first: then the row says it is saved.
        XCTAssertTrue(closedSays.contains("ダウンロード中") || rowSays.contains("ダウンロード済み"),
                      "The closed series says E2B is on its way: \(closedSays) / \(rowSays)")
        XCTAssertTrue(e2b.isSelected)
    }

    /// Closed midway, the setup goes on at the step it was on; a download
    /// that stops shows why and goes again from 準備完了, and the chat can be
    /// opened before the model is there.
    @MainActor func testOnboardingResumesAndRetriesAFailedDownload() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--fresh-install", "--download-fails"]
        app.launch()
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10)); welcome.tap()
        let next = app.buttons["onboarding-model-continue"]
        XCTAssertTrue(next.waitForExistence(timeout: 5)); next.tap()
        XCTAssertTrue(app.buttons["onboarding-keyboard-continue"].waitForExistence(timeout: 5))
        app.terminate()
        app.launchArguments = ["--startup", "--fresh-install", "--download-fails"]; app.launch()
        let keyboard = app.buttons["onboarding-keyboard-continue"]
        XCTAssertTrue(keyboard.waitForExistence(timeout: 10), "Back at 入力スタイル")
        capture("onboarding-7-resumed", app: app)
        keyboard.tap()
        continueLaunchStep(app)
        // The download of the launch before ended with it.
        let retry = app.buttons["onboarding-ready-retry"]
        XCTAssertTrue(retry.waitForExistence(timeout: 5))
        XCTAssertEqual(retry.label, "ダウンロード")
        retry.tap()
        expectation(for: NSPredicate(format: "label == %@", "もう一度試す"), evaluatedWith: retry)
        waitForExpectations(timeout: 8)
        XCTAssertTrue(app.staticTexts["インターネット接続がオフラインのようです。"].exists
                      || app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "オフライン")).count > 0,
                      "Why it stopped")
        XCTAssertFalse(app.alerts.firstMatch.exists, "On the page, not as an alert")
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-8-ready-failed", app: app)
        retry.tap()
        let start = app.buttons["onboarding-ready-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["onboarding-ready-later"].exists, "The chat can open before the model is there")
        expectation(for: NSPredicate(format: "isEnabled == true"), evaluatedWith: start)
        waitForExpectations(timeout: 10)
        start.tap()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.alerts.firstMatch.exists, "No leftover notice in the chat")
    }

    /// Dark, on a phone that has its models already: the model in use and
    /// the keyboard style in use are chosen, ダウンロード済み needs no download, and
    /// 準備完了 is ready at once.
    @MainActor func testOnboardingDarkWithSavedModelsNeedsNoDownload() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--dark", "--classic-composer", "--bloom-delay"]
        app.launch()
        captureBloom("onboarding-bloom-dark", app: app)
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        capture("onboarding-1-welcome-dark", app: app)
        captureOrb("onboarding-orb-dark", app: app)
        welcome.tap()
        // Its series names the model in use before it is opened (1.1.0 (269)).
        let gemma = app.buttons["onboarding-family-gemma"]
        XCTAssertTrue(gemma.waitForExistence(timeout: 5))
        XCTAssertTrue((gemma.value as? String ?? "").replacingOccurrences(of: "\u{00A0}", with: " ").contains("Gemma 4 E4Bを選択中"),
                      "\(gemma.value ?? "")")
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-2-model-dark", app: app)
        openOnboardingSeries("gemma", app)
        let e4b = app.buttons["onboarding-model-gemma-4-e4b"]
        XCTAssertTrue(e4b.waitForExistence(timeout: 5))
        XCTAssertTrue(e4b.isSelected, "The model in use")
        XCTAssertTrue((e4b.value as? String ?? "").contains("ダウンロード済み"), "\(e4b.value ?? "")")
        let note = app.descendants(matching: .any)["onboarding-memory-note"]
        print("ONBOARDING-NOTES dark e4b=\(e4b.label) memory=\(note.exists ? note.label : "none") gemma=\(gemma.value ?? "")")
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-2b-model-gemma-dark", app: app)
        app.buttons["onboarding-model-continue"].tap()
        let classic = app.buttons["composer-style-classic"]
        XCTAssertTrue(classic.waitForExistence(timeout: 5))
        XCTAssertTrue(classic.isSelected, "The keyboard style in use")
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-3-keyboard-dark", app: app)
        app.buttons["onboarding-keyboard-continue"].tap()
        let resume = app.buttons["launch-chat-resume"]
        XCTAssertTrue(resume.waitForExistence(timeout: 5) && resume.isSelected)
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-4-launch-dark", app: app)
        app.buttons["onboarding-launch-continue"].tap()
        let start = app.buttons["onboarding-ready-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 5))
        XCTAssertTrue(start.isEnabled, "A saved model needs no download")
        Thread.sleep(forTimeInterval: 0.6)
        capture("onboarding-5-ready-dark", app: app)
        // Back and forth keeps the choices.
        app.navigationBars.buttons.firstMatch.tap()
        XCTAssertTrue(resume.waitForExistence(timeout: 3) && resume.isSelected)
        app.navigationBars.buttons.firstMatch.tap()
        XCTAssertTrue(classic.waitForExistence(timeout: 3) && classic.isSelected)
        app.buttons["onboarding-keyboard-continue"].tap()
        continueLaunchStep(app)
        XCTAssertTrue(start.waitForExistence(timeout: 3))
        start.tap()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 5))
    }

    /// モデル's notes (1.1.0 (179), オンボーディングの文言): where neither Gemma
    /// has memory to spare, E2B is recommended and no note offers a lighter
    /// model; where E2B has room, E4B's note names it; with room for both,
    /// E2B is still recommended and chosen (1.1.0 (219): every new phone
    /// starts on E2B), and E4B has no note. With space for E2B only, E4B's
    /// note says how much more it needs, and 続ける waits. A test version
    /// chosen says so.
    @MainActor func testOnboardingMemoryAndSpaceNotes() {
        continueAfterFailure = false
        let app = PreviewApp()
        let memory = app.descendants(matching: .any)["onboarding-memory-note"]
        let disk = app.descendants(matching: .any)["onboarding-disk-note"]
        let next = app.buttons["onboarding-model-continue"]
        let e4b = app.buttons["onboarding-model-gemma-4-e4b"], e2b = app.buttons["onboarding-model-gemma-4-e2b"]
        func open(_ arguments: [String]) {
            app.terminate()
            app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--fresh-install"] + arguments
            app.launch()
            let welcome = app.buttons["onboarding-welcome-continue"]
            XCTAssertTrue(welcome.waitForExistence(timeout: 10)); welcome.tap()
            openOnboardingSeries("gemma", app)
            XCTAssertTrue(e2b.waitForExistence(timeout: 5) && e4b.exists)
        }
        func log(_ name: String) {
            print("ONBOARDING-NOTES \(name) e4b=\(e4b.label)|\(e4b.value ?? "")|\(e4b.isSelected) "
                  + "e2b=\(e2b.label)|\(e2b.value ?? "")|\(e2b.isSelected) memory=\(memory.exists ? memory.label : "none") "
                  + "disk=\(disk.exists ? disk.label : "none") continue=\(next.isEnabled)")
        }

        open(["--memory-gb=6"])
        log("6gb")
        XCTAssertTrue(e2b.label.contains("おすすめ") && e2b.isSelected, "The lightest, as nothing has room")
        XCTAssertTrue(memory.exists)
        XCTAssertFalse(memory.label.contains("なら余裕があります"), memory.label)
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-notes-1-no-room", app: app)
        e4b.tap()
        log("6gb-e4b")
        XCTAssertTrue(memory.exists)
        XCTAssertFalse(memory.label.contains("なら余裕があります"), "E2B has no room either: \(memory.label)")

        open(["--memory-gb=8", "--dark"])
        log("8gb")
        XCTAssertTrue(e2b.label.contains("おすすめ") && e2b.isSelected)
        XCTAssertFalse(memory.exists, "E2B has room")
        e4b.tap()
        XCTAssertTrue(memory.waitForExistence(timeout: 2))
        log("8gb-e4b")
        XCTAssertTrue(memory.label.replacingOccurrences(of: "\u{00A0}", with: " ").contains("Gemma 4 E2Bなら余裕があります"),
                      memory.label)
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-notes-2-room-for-e2b-dark", app: app)

        open(["--memory-gb=12"])
        log("12gb")
        XCTAssertTrue(e2b.label.contains("おすすめ") && e2b.isSelected, "E2B for every new phone")
        XCTAssertFalse(e4b.label.contains("おすすめ"))
        XCTAssertFalse(memory.exists)
        e4b.tap()
        log("12gb-e4b")
        XCTAssertFalse(memory.exists, "Both have room")
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-notes-3-room-for-both", app: app)
        let twelve = app.buttons["onboarding-model-gemma-4-12b"]
        let list = app.scrollViews["onboarding-model-list"]
        for _ in 0..<3 where !twelve.isHittable { list.swipeUp() }
        twelve.tap()
        let testVersion = app.descendants(matching: .any)["onboarding-test-version-note"]
        XCTAssertTrue(twelve.isSelected && testVersion.waitForExistence(timeout: 2), "12B, chosen, says it is a test version")
        let room = app.descendants(matching: .any)["onboarding-room-note"]
        print("ONBOARDING-NOTES 12gb-12b \(twelve.label)|\(twelve.value ?? "") test=\(testVersion.label) "
              + "room=\(room.exists ? room.label : "none") memory=\(memory.exists ? memory.label : "none") continue=\(next.isEnabled)")
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-notes-3b-12b", app: app)

        open(["--memory-gb=12", "--low-disk"])
        XCTAssertTrue(e2b.label.contains("おすすめ"), "E4B does not fit on the disk")
        e4b.tap()
        XCTAssertTrue(disk.waitForExistence(timeout: 3))
        log("disk-e4b")
        XCTAssertTrue(disk.label.contains("あと"), disk.label)
        XCTAssertFalse(next.isEnabled, "続ける waits for the space")
        Thread.sleep(forTimeInterval: 0.5)
        capture("onboarding-notes-4-space", app: app)
        e2b.tap()
        XCTAssertTrue(gone(disk))
        XCTAssertTrue(next.isEnabled)
    }

    /// Aurora Bloom's haptics (1.1.0 (178)), read from the welcome's trace
    /// (the simulator has no haptics, so it counts the beats by their
    /// times): 続ける part-way through the bloom stops what has not played,
    /// and so does Fielua going inactive, and nothing plays again after.
    /// With Reduce Motion the light is there at once and holds still, with
    /// one soft tap. XCUITest waits for the light to settle before each
    /// touch, so --slow-bloom plays it four times as slow for the touches
    /// to land part-way (the trace counts on its timeline).
    @MainActor func testWelcomeBloomHapticsStopWithContinueAndWhenInactive() {
        continueAfterFailure = false
        let app = PreviewApp()
        let fresh = ["--startup", "--reset-startup", "--reset-settings", "--fresh-install", "--haptics-trace", "--bloom-delay",
                     "--slow-bloom"]
        app.launchArguments = fresh
        app.launch()
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        let continuePoint = welcome.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))
        XCTAssertTrue(waitForWelcomeLight(app), "The welcome's light never drew")
        continuePoint.tap()
        XCTAssertTrue(app.buttons["onboarding-model-continue"].waitForExistence(timeout: 5))
        app.navigationBars.buttons.firstMatch.tap()
        let skipped = trace(app, containing: "stopped", timeout: 5)
        print("BLOOM-HAPTICS continue: \(skipped)")
        XCTAssertTrue(skipped.contains("bloom stopped (continue)"), skipped)
        XCTAssertFalse(skipped.contains("played 7 of 7"), "Stopped part-way: \(skipped)")
        Thread.sleep(forTimeInterval: 3)
        XCTAssertEqual(trace(app, containing: "", timeout: 1), skipped, "Nothing plays after")
        capture("onboarding-bloom-back", app: app)

        app.terminate(); app.launchArguments = fresh; app.launch()
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        XCTAssertTrue(waitForWelcomeLight(app), "The welcome's light never drew")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 1.5)
        app.activate()
        let away = trace(app, containing: "stopped", timeout: 5)
        print("BLOOM-HAPTICS inactive: \(away)")
        XCTAssertTrue(away.contains("bloom stopped (inactive)") || away.contains("bloom stopped (system)"), away)
        XCTAssertFalse(away.contains("played 7 of 7"), "Stopped part-way: \(away)")
        Thread.sleep(forTimeInterval: 3)
        XCTAssertEqual(trace(app, containing: "", timeout: 1), away, "Nothing plays after")

        app.terminate(); app.launchArguments = fresh + ["--reduce-motion"]; app.launch()
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        let still = trace(app, containing: "finished", timeout: 15)
        print("BLOOM-HAPTICS reduce motion: \(still)")
        XCTAssertTrue(still.contains("still finished, played 2 of 2"), still)
        let wordmark = app.staticTexts["Fielua"]
        XCTAssertTrue(wordmark.exists)
        let canvas = CGRect(x: wordmark.frame.midX - 140, y: wordmark.frame.minY + 47.4 - 280, width: 280, height: 280)
        guard let first = XCUIScreen.main.screenshot().image.cgImage,
              let before = ScreenArea(first, canvas, screenWidth: app.frame.width) else { return XCTFail("No screenshot") }
        Thread.sleep(forTimeInterval: 1.5)
        guard let second = XCUIScreen.main.screenshot().image.cgImage,
              let after = ScreenArea(second, canvas, screenWidth: app.frame.width) else { return XCTFail("No screenshot") }
        let size = after.colour()
        let change = after.change(from: before, in: canvas)
        print(String(format: "BLOOM-HAPTICS reduce motion light %d pt², %.0fx%.0f, change %.2f",
                     size.count, size.bounds.width, size.bounds.height, change))
        XCTAssertGreaterThan(size.bounds.width, 110, "The light at its size at once")
        XCTAssertLessThan(change, 1, "Still with Reduce Motion")
        capture("onboarding-bloom-reduced-light", app: app)
    }

    /// スタートアップの全ユーザー向け初回表示制御 (1.1.0 (181)): the setup
    /// is shown once on every phone for its edition (Onboarding.edition),
    /// on a phone updated from 1.1.0 (179) as well, where the setup had
    /// been finished, with the saved model in use and the keyboard style
    /// as they were and nothing to download; closed midway it goes on from
    /// its step; once finished no later launch shows it (a later build
    /// keeps the edition), until a release with a new edition, which is
    /// shown once more, and once only.
    @MainActor func testStartupOncePerEditionForEveryone() {
        continueAfterFailure = false
        let app = PreviewApp()
        let welcome = app.buttons["onboarding-welcome-continue"]
        let chat = app.buttons["chat-add-menu"]
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--updated-from-179", "--classic-composer"]
        app.launch()
        XCTAssertTrue(welcome.waitForExistence(timeout: 10), "Shown once after the update from 179")
        print("STARTUP-EDITION updated from 179: welcome shown")
        welcome.tap()
        openOnboardingSeries("gemma", app)
        let e4b = app.buttons["onboarding-model-gemma-4-e4b"]
        XCTAssertTrue(e4b.waitForExistence(timeout: 5))
        XCTAssertTrue(e4b.isSelected, "The model in use")
        XCTAssertTrue((e4b.value as? String ?? "").contains("ダウンロード済み"), "\(e4b.value ?? "")")
        app.buttons["onboarding-model-continue"].tap()
        let classic = app.buttons["composer-style-classic"]
        XCTAssertTrue(classic.waitForExistence(timeout: 5))
        XCTAssertTrue(classic.isSelected, "The keyboard style in use")

        // Closed midway: the next launch goes on from 入力スタイル.
        app.terminate(); app.launchArguments = ["--startup", "--keep-composer-style"]; app.launch()
        XCTAssertTrue(classic.waitForExistence(timeout: 10), "Goes on from its step")
        XCTAssertFalse(welcome.exists, "Not from the start")
        XCTAssertTrue(classic.isSelected, "The keyboard style in use")
        print("STARTUP-EDITION resumed at the keyboard step")
        capture("startup-edition-resumed", app: app)
        app.buttons["onboarding-keyboard-continue"].tap()
        continueLaunchStep(app)
        let start = app.buttons["onboarding-ready-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 5))
        XCTAssertTrue(start.isEnabled, "A saved model needs no download")
        start.tap()
        XCTAssertTrue(chat.waitForExistence(timeout: 5))

        // Finished: the next launches, and later builds with the same
        // edition, open the chat.
        for launch in 1...2 {
            app.terminate(); app.launch()
            XCTAssertTrue(chat.waitForExistence(timeout: 10))
            Thread.sleep(forTimeInterval: 1)
            XCTAssertFalse(welcome.exists, "Never again for this edition (launch \(launch))")
        }
        print("STARTUP-EDITION finished: not shown on 2 later launches")
        capture("startup-edition-finished", app: app)

        // A release that shows the setup to everyone again: once more.
        app.terminate(); app.launchArguments = ["--startup", "--keep-composer-style", "--startup-edition=next"]; app.launch()
        XCTAssertTrue(welcome.waitForExistence(timeout: 10), "A new edition is shown once")
        welcome.tap()
        let next = app.buttons["onboarding-model-continue"]
        XCTAssertTrue(next.waitForExistence(timeout: 5)); next.tap()
        XCTAssertTrue(classic.waitForExistence(timeout: 5) && classic.isSelected, "The keyboard style in use")
        app.buttons["onboarding-keyboard-continue"].tap()
        continueLaunchStep(app)
        XCTAssertTrue(start.waitForExistence(timeout: 5)); start.tap()
        XCTAssertTrue(chat.waitForExistence(timeout: 5))
        app.terminate(); app.launch()
        XCTAssertTrue(chat.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1)
        XCTAssertFalse(welcome.exists, "The new edition once only")
        print("STARTUP-EDITION new edition: shown once, then not")
    }

    /// 開発者設定 「初回起動扱いにする」 (2026-10-24): the setup comes back
    /// at the next launch from its first step, with the saved models and
    /// chats as they are, and not over the settings it was pressed in.
    @MainActor func testFirstLaunchResetShowsTheWelcomeAgain() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-startup", "--reset-settings", "--developer-unlocked"]
        app.launch()
        openSettingsFromChat(app)
        XCTAssertFalse(app.buttons["onboarding-welcome-continue"].exists)
        openSettingsRow("developer", title: "開発者設定", app: app)
        let reset = app.buttons["developer-first-launch"]
        let developerList = app.scrollViews["developer-list"]
        XCTAssertTrue(developerList.waitForExistence(timeout: 3))
        for _ in 0..<6 where !(reset.exists && reset.isHittable) { developerList.swipeUp() }
        XCTAssertTrue(reset.isHittable)
        capture("first-launch-reset-card", app: app)
        reset.tap()
        let confirm = app.alerts.buttons["初回起動扱いにする"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        capture("first-launch-reset-alert", app: app)
        confirm.tap()
        let result = app.staticTexts["developer-first-launch-result"]
        XCTAssertTrue(result.waitForExistence(timeout: 3))
        XCTAssertTrue(result.label.contains("次に起動したとき"), result.label)
        Thread.sleep(forTimeInterval: 0.6)
        capture("first-launch-reset-done", app: app)
        XCTAssertFalse(app.buttons["onboarding-welcome-continue"].exists, "The setup waits for the next launch")
        app.terminate(); app.launchArguments = ["--startup", "--haptics-trace"]; app.launch()
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        // Aurora Bloom plays again, haptics and all.
        let bloom = trace(app, containing: "bloom", timeout: 10)
        XCTAssertTrue(bloom.contains("bloom began") || bloom.contains("bloom finished"), bloom)
        Thread.sleep(forTimeInterval: 2.5)
        capture("first-launch-reset-welcome", app: app)
        welcome.tap()
        let next = app.buttons["onboarding-model-continue"]
        XCTAssertTrue(next.waitForExistence(timeout: 5)); next.tap()
        app.buttons["onboarding-keyboard-continue"].tap()
        continueLaunchStep(app)
        let start = app.buttons["onboarding-ready-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 5))
        XCTAssertTrue(start.isEnabled, "A saved model starts without a download")
        start.tap()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 5))
        app.terminate(); app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["onboarding-welcome-continue"].exists, "Once")
    }

    @MainActor func testShortConversationAndGrowingReplyStayStableWithKeyboard() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--growing-reply", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        let firstY = modelName.frame.minY
        input.typeText("Short send")
        XCTAssertEqual(modelName.frame.minY, firstY, accuracy: 3, "Typing in a short chat must not reposition its content")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Short send"].waitForExistence(timeout: 4))
        XCTAssertEqual(input.value as? String, "")
        XCTAssertFalse(app.keyboards.firstMatch.exists, "Successful send must close the keyboard")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        // E4B no longer shows an attachment note above the field.
        XCTAssertFalse(app.buttons["chat-switch-e2b"].exists)
        func readingBottom() -> CGFloat { input.frame.minY }
        XCTAssertLessThanOrEqual(reply.frame.maxY, readingBottom())
        capture("short-send-long-reply-keyboard", app: app)
        let reading = app.scrollViews["chat-conversation"]
        // The scroll view extends behind the bars and keyboard. Its default
        // swipe coordinates can hit those controls instead of the text area.
        func swipeReading(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, readingBottom() - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipeReading(up: false); swipeReading(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        for _ in 0..<8 {
            if reply.exists && reply.frame.maxY <= readingBottom()
                && reply.frame.maxY > readingBottom() - 32 { break }
            swipeReading(up: true)
        }
        let observations: [String: Any] = ["replyBottom": reply.frame.maxY,
            "inputTop": input.frame.minY,
            "readingBottom": readingBottom(), "jumpVisible": app.buttons["chat-jump-latest"].exists]
        if let bytes = try? JSONSerialization.data(withJSONObject: observations, options: .sortedKeys) {
            let evidence = XCTAttachment(data: bytes, uniformTypeIdentifier: "public.json")
            evidence.name = "manual-bottom-and-composer-geometry"; evidence.lifetime = .keepAlways; add(evidence)
        }
        capture("manual-return-bottom-geometry", app: app)
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        print("SCROLL-DEBUG after manual return:", debug.label)
        XCTAssertLessThanOrEqual(reply.frame.maxY, readingBottom())
        XCTAssertGreaterThan(reply.frame.maxY, readingBottom() - 32, "Manual scrolling must reach the reply's end above the actual composer")
        let hidden = NSPredicate(format: "exists == false")
        let result = XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: hidden, object: app.buttons["chat-jump-latest"])], timeout: 4)
        XCTAssertEqual(result, .completed, "Jump control stays after a manual return. \(debug.label) replyBottom=\(reply.frame.maxY) readingBottom=\(readingBottom())")
        capture("manual-return-no-jump", app: app)
    }

    @MainActor func testHistorySidebarSlide() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--history-fixture"]; app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        let sidebar = historySidebar(app)
        if sidebar.exists { print("HISTORY-SIDEBAR exposed while closed: \(sidebar.debugDescription.prefix(1500))") }
        XCTAssertFalse(sidebar.exists)
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)
        // The sidebar's controls line up with the conversation's own.
        let headerMidY = open.frame.midY, plusMidY = app.buttons["chat-add-menu"].frame.midY

        // A swipe right on the conversation slides it aside, as ChatGPT does.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.45))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.46)))
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        print("HISTORY-SIDEBAR open: sidebar=\(sidebar.frame) app=\(app.frame)")
        print("HISTORY-SIDEBAR conversation exposed while open: header=\(open.exists) reading=\(app.scrollViews["chat-conversation"].exists) input=\(app.textViews["chat-input"].exists)")
        XCTAssertEqual(sidebar.frame.minX, 0, accuracy: 1)
        XCTAssertEqual(sidebar.frame.width, app.frame.width - 92, accuracy: 1, "92pt of the conversation stays in view")
        let compose = app.buttons["history-compose"], settings = app.buttons["history-settings"]
        print("HISTORY-SIDEBAR buttons: compose=\(compose.frame) settings=\(settings.frame) search=\(app.buttons["history-search"].frame)")
        XCTAssertTrue(compose.isHittable)
        XCTAssertEqual(compose.frame.height, 48, accuracy: 1)
        XCTAssertLessThan(compose.frame.minX, sidebar.frame.width * 0.2, "New chat sits at the bottom leading corner")
        XCTAssertGreaterThan(compose.frame.minY, app.frame.height * 0.85)
        XCTAssertGreaterThan(settings.frame.minX, compose.frame.maxX)
        XCTAssertLessThanOrEqual(settings.frame.maxX, sidebar.frame.maxX)
        let search = app.buttons["history-search"]
        XCTAssertEqual(compose.frame.minX - sidebar.frame.minX, 24, accuracy: 1)
        XCTAssertEqual(sidebar.frame.maxX - settings.frame.maxX, 24, accuracy: 1)
        XCTAssertEqual(search.frame.maxX, settings.frame.maxX, accuracy: 1)
        XCTAssertEqual(search.frame.midY, headerMidY, accuracy: 1, "Search sits level with the conversation's header button")
        print("HISTORY-SIDEBAR levels: header=\(headerMidY) search=\(search.frame.midY) plus=\(plusMidY) compose=\(compose.frame.midY)")
        // The simulator's plus frame can be 54pt tall (see the menu test),
        // so its center is only a rough reference here. The two-row panel
        // (Phase UI-1) puts the plus about 8pt above the new-chat button.
        XCTAssertEqual(compose.frame.midY, plusMidY, accuracy: 10, "New chat sits level with the conversation's plus button")
        XCTAssertEqual(settings.frame.midY, compose.frame.midY, accuracy: 1)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 7)
        capture("history-open", app: app)
        // The sidebar's title is the app's name (Fielua since 1.0.123).
        let title = app.staticTexts["Fielua"]
        print("HISTORY-SIDEBAR title: Fielua=\(title.exists) PocketAI=\(app.staticTexts["Pocket AI"].exists)")
        XCTAssertTrue(title.exists, "The sidebar's title is the app's name")

        // A long press lifts just the row's rounded shape and offers delete.
        app.buttons["会話を開く: 夕飯のレシピ"].press(forDuration: 1.2)
        let deleteItem = app.buttons["削除"]
        XCTAssertTrue(deleteItem.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR row menu: delete=\(deleteItem.frame)")
        capture("history-row-menu", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.3, dy: 0.8)).tap()
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: deleteItem)], timeout: 3)
        // The menu's item leaves the tree as the menu starts to close; let
        // it finish before the next tap (run 40243928939, on a slow
        // simulator, missed the close below).
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertTrue(sidebar.exists)

        // Tapping the strip of conversation slides it back. The strip is
        // the visible part of a screen-wide element, so tap by coordinate.
        XCTAssertTrue(app.descendants(matching: .any)["history-close"].exists)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        if XCTWaiter().wait(for: [closed], timeout: 3) != .completed {
            capture("history-close-missed", app: app)
            print("HISTORY-SIDEBAR close missed: sidebar=\(sidebar.frame) close=\(app.descendants(matching: .any)["history-close"].exists) menus=\(app.menus.count) delete=\(deleteItem.exists)")
            XCTFail("Tapping the conversation strip closes the history")
        }

        // The header button opens it too; frames taken during the slide.
        open.tap()
        for index in 0..<3 { capture("history-motion-\(index)", app: app) }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)

        // Search filters by title and message text.
        app.buttons["history-search"].tap()
        let field = app.textFields["history-search-field"]
        // Frames while the field grows out of the search circle.
        for index in 0..<3 { capture("history-search-motion-\(index)", app: app) }
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        sleep(1)
        let close = app.buttons["history-search-close"]
        print("HISTORY-SIDEBAR search: field=\(field.frame) close=\(close.frame)")
        XCTAssertEqual(close.frame.maxX, settings.frame.maxX, accuracy: 1, "The search circle stays put as the close button")
        XCTAssertEqual(field.frame.midY, close.frame.midY, accuracy: 1)
        field.tap(); field.typeText("カメムシ")
        XCTAssertTrue(app.buttons["会話を開く: カメムシ対策"].waitForExistence(timeout: 3))
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 1)
        capture("history-search", app: app)
        app.buttons["history-search-close"].tap()
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 7)

        // A swipe left closes it.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.7, dy: 0.5))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.1, dy: 0.51)))
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        if XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)],
                            timeout: 3) != .completed {
            capture("history-swipe-missed", app: app)
            print("HISTORY-SIDEBAR swipe missed: sidebar=\(sidebar.frame) keyboards=\(app.keyboards.count) "
                  + "search=\(app.textFields["history-search-field"].exists) close=\(app.descendants(matching: .any)["history-close"].exists)")
            XCTFail("A swipe left closes the history")
        }

        // Opening an older conversation slides back to it.
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        app.buttons["会話を開く: 夕飯のレシピ"].tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["夕飯のレシピ"].waitForExistence(timeout: 3))

        // New chat: an empty conversation, and the sidebar closes.
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        compose.tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        XCTAssertFalse(app.staticTexts["夕飯のレシピ"].exists)

        app.terminate(); app.launchArguments = ["--history-fixture", "--dark"]; app.launch()
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        capture("history-dark", app: app)
    }

    /// The iPad's history beside the conversation (1.1.0 (226)), on the
    /// largest iPad Pro (scope ipad-history): the header's button shows the
    /// history and puts it away; while it shows, the conversation on its
    /// right is typed in and sent from, and opening a chat or a new one
    /// keeps it there. The choice is kept for the next launch. Landscape,
    /// as with a Magic Keyboard, then portrait in dark (HISTORY-SIDEBAR
    /// ipad lines, SHOT ipad-*).
    @MainActor func testHistoryBesideTheChatOnIPad() throws {
        try XCTSkipUnless(UIDevice.current.userInterfaceIdiom == .pad, "The history stands beside the chat on an iPad only")
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .landscapeLeft
        addTeardownBlock { XCUIDevice.shared.orientation = .portrait }
        let app = PreviewApp(); app.launchArguments = ["--history-fixture"]; app.launch()
        let toggle = app.buttons["chat-history"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 10))
        sleep(1)
        let sidebar = historySidebar(app)
        let input = app.textViews["chat-input"]
        let rows = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:"))
        print("HISTORY-SIDEBAR ipad closed: app=\(app.frame) toggle=\(toggle.frame) label=\(toggle.label) input=\(input.frame) sidebar=\(sidebar.exists)")
        XCTAssertGreaterThan(app.frame.width, app.frame.height, "Landscape")
        XCTAssertFalse(sidebar.exists)
        XCTAssertEqual(toggle.label, "会話一覧を開く")
        let closedInput = input.frame
        capture("ipad-history-closed", app: app)

        // The header's button: the history slides in beside the conversation.
        toggle.tap()
        for index in 0..<3 {
            let frame = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
            frame.name = "ipad-history-motion-\(index)"; frame.lifetime = .keepAlways; add(frame)
        }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        let width = min(max(app.frame.width * 0.3, 300), 360)
        let veil = app.descendants(matching: .any)["history-close"]
        print("HISTORY-SIDEBAR ipad open: sidebar=\(sidebar.frame) toggle=\(toggle.frame) label=\(toggle.label) input=\(input.frame) veil=\(veil.exists) rows=\(rows.count)")
        XCTAssertEqual(sidebar.frame.minX, 0, accuracy: 1)
        XCTAssertEqual(sidebar.frame.width, width, accuracy: 1)
        XCTAssertEqual(toggle.label, "会話一覧を閉じる")
        XCTAssertGreaterThanOrEqual(toggle.frame.minX, sidebar.frame.maxX, "The button stays with the conversation")
        // The conversation keeps its column and moves over by half the
        // history's width, to the middle of what is left (1.1.0 (242)).
        XCTAssertEqual(input.frame.minX - closedInput.minX, width / 2, accuracy: 2, "The conversation moves over by half the history's width")
        XCTAssertEqual(input.frame.width, closedInput.width, accuracy: 1, "The field keeps its width")
        XCTAssertEqual(input.frame.midX, (sidebar.frame.maxX + app.frame.maxX) / 2, accuracy: 30, "The field stays in the middle of the conversation")
        XCTAssertGreaterThan(input.frame.minX, sidebar.frame.maxX)
        XCTAssertLessThanOrEqual(input.frame.maxX, app.frame.maxX + 1)
        XCTAssertFalse(veil.exists, "Nothing lies over the conversation")
        XCTAssertEqual(rows.count, 7)
        capture("ipad-history-open", app: app)

        // Typed in and sent from while the history shows.
        input.tap(); input.typeText("並べたまま送信")
        let send = app.buttons["送信する"]
        if !send.waitForExistence(timeout: 3) {
            let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
            screen.name = "ipad-history-send-missing"; screen.lifetime = .keepAlways; add(screen)
            let low = app.buttons.allElementsBoundByIndex.filter { $0.frame.minY > app.frame.height * 0.6 }
            print("HISTORY-SIDEBAR ipad send missing: value=\(String(describing: input.value)) input=\(input.frame) "
                  + "keyboards=\(app.keyboards.count) "
                  + "buttons=\(low.map { "\($0.identifier)|\($0.label)|\($0.frame)" })")
            XCTFail("The send button shows once something is typed beside the history")
        }
        XCTAssertTrue(send.isHittable)
        send.tap()
        XCTAssertTrue(app.staticTexts["並べたまま送信"].waitForExistence(timeout: 5))
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "スクロールを確認できます")).firstMatch
        XCTAssertTrue(reply.waitForExistence(timeout: 15))
        XCTAssertTrue(send.waitForExistence(timeout: 15))
        print("HISTORY-SIDEBAR ipad sent: sidebar=\(sidebar.exists) input=\(input.frame) value=\(String(describing: input.value)) rows=\(rows.count)")
        XCTAssertTrue(sidebar.exists, "Sending keeps the history beside the conversation")
        XCTAssertEqual(input.value as? String, "")
        capture("ipad-history-sent", app: app)

        // Opening another chat from it keeps it there.
        let older = app.staticTexts["夕飯のレシピ"]
        XCTAssertFalse(older.exists)
        app.buttons["会話を開く: 夕飯のレシピ"].tap()
        XCTAssertTrue(older.waitForExistence(timeout: 3))
        sleep(1)
        print("HISTORY-SIDEBAR ipad opened chat: sidebar=\(sidebar.exists) sent=\(app.staticTexts["並べたまま送信"].exists)")
        XCTAssertTrue(sidebar.exists, "Opening a chat keeps the history beside it")
        XCTAssertFalse(app.staticTexts["並べたまま送信"].exists)
        capture("ipad-history-opened-chat", app: app)

        // So does a new chat from its button.
        app.buttons["history-compose"].tap()
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: older)], timeout: 3)
        XCTAssertTrue(sidebar.exists, "A new chat keeps the history beside it")

        // The button again: the history goes and the conversation takes the width.
        toggle.tap()
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)], timeout: 3)
        sleep(1)
        print("HISTORY-SIDEBAR ipad put away: label=\(toggle.label) input=\(input.frame) closed=\(closedInput)")
        XCTAssertEqual(toggle.label, "会話一覧を開く")
        XCTAssertEqual(input.frame.minX, closedInput.minX, accuracy: 2)
        capture("ipad-history-put-away", app: app)

        // iPadOS's own keys for a sidebar, ⌃⌘S (read only: the simulator's
        // keyboard may not reach the app's key commands).
        app.typeKey("s", modifierFlags: [.command, .control])
        let byKeys = sidebar.waitForExistence(timeout: 2)
        print("HISTORY-SIDEBAR ipad shortcut: shown=\(byKeys)")
        if !byKeys { toggle.tap(); XCTAssertTrue(sidebar.waitForExistence(timeout: 3)) }

        // Kept for the next launch; portrait, in dark.
        app.terminate()
        XCUIDevice.shared.orientation = .portrait
        app.launchArguments = ["--history-fixture", "--keep-history-dock", "--dark"]; app.launch()
        XCTAssertTrue(toggle.waitForExistence(timeout: 10))
        sleep(1)
        let portraitWidth = min(max(app.frame.width * 0.3, 300), 360)
        print("HISTORY-SIDEBAR ipad relaunch: app=\(app.frame) sidebar=\(sidebar.exists) \(sidebar.frame) input=\(input.frame) label=\(toggle.label)")
        XCTAssertLessThan(app.frame.width, app.frame.height, "Portrait")
        XCTAssertTrue(sidebar.exists, "The history beside the conversation is kept for the next launch")
        XCTAssertEqual(sidebar.frame.width, portraitWidth, accuracy: 1)
        XCTAssertGreaterThan(input.frame.minX, sidebar.frame.maxX)
        capture("ipad-history-portrait-dark", app: app)
    }

    /// What showing and putting away the iPad's history costs beside a long
    /// conversation (1.1.0 (242), Hachimoto さん 2026-10-29: the chat and the
    /// field were laid out again and it felt heavy): the meter's frames, the
    /// main thread's load and the views drawn again on the way, and where
    /// the conversation's text and the field stand before and after; in
    /// landscape twice, then in portrait. The session recording's frames
    /// come from the MENU-MARK dock-* lines (HISTORY-SIDEBAR ipad-cost
    /// lines, SHOT ipad-cost-*).
    @MainActor func testHistoryDockCostOnIPad() throws {
        try XCTSkipUnless(UIDevice.current.userInterfaceIdiom == .pad, "The history stands beside the chat on an iPad only")
        // Every step is measured, also after one that fails.
        continueAfterFailure = true
        XCUIDevice.shared.orientation = .landscapeLeft
        addTeardownBlock { XCUIDevice.shared.orientation = .portrait }
        let app = PreviewApp()
        app.launchArguments = ["--history-fixture", "--long-chat", "--longer-chat", "--dock-meter"]
        app.launch()
        let toggle = app.buttons["chat-history"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 10))
        sleep(2)
        let sidebar = historySidebar(app)
        let meter = app.descendants(matching: .any)["history-dock-meter"]
        let input = app.textViews["chat-input"]
        let scroll = app.descendants(matching: .any)["scroll-debug"]
        let latest = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "最新の返信です")).firstMatch
        let paragraphs = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "スクロールの確認です"))
        XCTAssertTrue(latest.waitForExistence(timeout: 5))
        func texts() -> (latest: CGRect, paragraph: CGRect, input: CGRect) {
            let count = paragraphs.count
            return (latest.frame, count > 0 ? paragraphs.element(boundBy: count - 1).frame : .zero, input.frame)
        }
        func shot(_ name: String) {
            let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
            attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
        }
        /// The views the meter counted drawn again while it moved.
        func redrawn(_ label: String) -> String {
            guard let start = label.range(of: "移動中の描き直し "),
                  let end = label.range(of: "・動き出す前", range: start.upperBound..<label.endIndex) else { return "?" }
            return String(label[start.upperBound..<end.lowerBound])
        }
        /// The long chat's older rows are estimated, and its height settles
        /// for a while after launch (2-5pt a step, run 40837941661): wait
        /// until it holds still, so that only the toggle is measured.
        func settle(_ step: String) {
            var last = "", same = 0
            for _ in 0..<15 {
                let content = (scroll.exists ? scroll.label : "").split(separator: " ").first { $0.hasPrefix("content=") }.map(String.init) ?? ""
                if content == last { same += 1; if same >= 2 { return } } else { same = 0; last = content }
                sleep(1)
            }
            print("HISTORY-SIDEBAR ipad-cost \(step) settle: still changing \(last)")
        }
        func toggleDock(_ step: String, opening: Bool) {
            settle(step)
            let before = texts()
            let scrollBefore = scroll.exists ? scroll.label : "none"
            print(String(format: "MENU-MARK dock-%@ %.3f", step, Date().timeIntervalSince1970))
            toggle.tap()
            if opening { XCTAssertTrue(sidebar.waitForExistence(timeout: 3)) }
            // Kept built (`--dock-keep-history`), it stays in the tree, out of reach.
            else { wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false OR hittable == false"), object: sidebar)], timeout: 3) }
            sleep(2)
            let after = texts()
            let label = meter.exists ? meter.label : "no meter"
            print("HISTORY-SIDEBAR ipad-cost \(step): \(label)")
            print("HISTORY-SIDEBAR ipad-cost \(step) text: latest \(before.latest) -> \(after.latest) paragraph \(before.paragraph) -> \(after.paragraph) input \(before.input) -> \(after.input) app=\(app.frame)")
            print("HISTORY-SIDEBAR ipad-cost \(step) scroll: \(scrollBefore) -> \(scroll.exists ? scroll.label : "none")")
            shot("ipad-cost-\(step)")
            // No message is drawn again on the way (1.1.0 (242); 226 drew
            // every bubble on each frame). The conversation's own view may
            // run once or twice as its scroll view reports (run 40840586355).
            let drawn = redrawn(label)
            XCTAssertFalse(drawn.contains("吹き出し"), "No message is drawn again on the way (\(step)): \(drawn)")
            // 1.1.0 (242): no line is laid out again and nothing scrolls;
            // the column only moves over by half the history's width.
            let half = min(max(app.frame.width * 0.3, 300), 360) / 2 * (opening ? 1 : -1)
            XCTAssertEqual(after.paragraph.height, before.paragraph.height, accuracy: 1, "The reply keeps its lines (\(step))")
            XCTAssertEqual(after.paragraph.width, before.paragraph.width, accuracy: 1, "The reply keeps its width (\(step))")
            XCTAssertEqual(after.paragraph.minY, before.paragraph.minY, accuracy: 2, "The conversation does not scroll (\(step))")
            XCTAssertEqual(after.latest.minY, before.latest.minY, accuracy: 2, "The latest reply stays where it was (\(step))")
            XCTAssertEqual(after.paragraph.minX - before.paragraph.minX, half, accuracy: 2, "The column moves over by half the history (\(step))")
            XCTAssertEqual(after.input.width, before.input.width, accuracy: 1, "The field keeps its width (\(step))")
        }
        shot("ipad-cost-landscape-closed")
        toggleDock("open-landscape", opening: true)
        toggleDock("close-landscape", opening: false)
        toggleDock("open-landscape-2", opening: true)
        toggleDock("close-landscape-2", opening: false)
        XCUIDevice.shared.orientation = .portrait
        sleep(2)
        toggleDock("open-portrait", opening: true)
        toggleDock("close-portrait", opening: false)

        // For comparison: the history kept built while put away, so that
        // only its slide is left of what showing it costs.
        app.terminate()
        XCUIDevice.shared.orientation = .landscapeLeft
        app.launchArguments.append("--dock-keep-history")
        app.launch()
        XCTAssertTrue(toggle.waitForExistence(timeout: 10))
        sleep(2)
        XCTAssertTrue(latest.waitForExistence(timeout: 5))
        toggleDock("open-kept", opening: true)
        toggleDock("close-kept", opening: false)
        toggleDock("open-kept-2", opening: true)
        toggleDock("close-kept-2", opening: false)
    }

    /// The conversation slid aside for the history, at its corners
    /// (Hachimoto さん 2026-11-12, on 1.1.0 (263)): its bottom corners were
    /// painted in the sidebar's flat colour, so what the history showed
    /// there, the new chat button's shadow as the drawer slid over it,
    /// stopped in a straight line at the conversation's edge. Held a third
    /// open and fully open, light and dark: just left and just right of the
    /// edge, beside each leading corner's curve, the history reads the same
    /// (PANEL-CORNER lines); the bottom corner is round, the paper gone from
    /// its tip, and the paper reaches the screen's foot; and the slid
    /// conversation is not black. The corners are attached at the screen's
    /// own pixels (corner-*). Since 1.1.0 (272) the conversation keeps its
    /// size and place, its top at the screen's top, and the history is the
    /// one that stands back: held a third open, its title is smaller, where
    /// the history's own smaller size puts it (HISTORY-DEPTH lines), not
    /// moved in it as the history's safe area would move it if lost.
    @MainActor func testSlidPanelCornersShowTheHistory() {
        continueAfterFailure = true
        for dark in [false, true] {
            var openTitle: CGRect?, openSidebar: CGRect?
            for held in [1.0, 0.3] {
                let app = PreviewApp()
                app.launchArguments = ["--history-fixture", "--history-reveal", String(held)] + (dark ? ["--dark"] : [])
                app.launch()
                let sidebar = historySidebar(app)
                XCTAssertTrue(sidebar.waitForExistence(timeout: 10), "The drawer is held open")
                sleep(2)
                let screen = app.frame.size
                let title = app.staticTexts["Fielua"]
                let look = (dark ? "dark" : "light") + "-" + (held < 1 ? "third" : "open")
                print("HISTORY-DEPTH \(look): sidebar=\(sidebar.frame) title=\(title.exists ? title.frame : .zero)")
                if held >= 1 {
                    openTitle = title.exists ? title.frame : nil
                    openSidebar = sidebar.frame
                } else if let openTitle, let openSidebar, title.exists {
                    // Smaller about the history's middle (HistoryDepth).
                    let scale = 0.94 + 0.06 * CGFloat(held)
                    let middle = CGPoint(x: openSidebar.midX, y: openSidebar.midY)
                    let expected = CGPoint(x: middle.x + (openTitle.midX - middle.x) * scale,
                                           y: middle.y + (openTitle.midY - middle.y) * scale)
                    print("HISTORY-DEPTH \(look): title \(title.frame) expected mid " + String(format: "%.1f,%.1f", expected.x, expected.y)
                          + String(format: " height %.1f of %.1f", title.frame.height, openTitle.height))
                    XCTAssertEqual(title.frame.height / openTitle.height, scale, accuracy: 0.025,
                                   "The history stands back a little smaller (\(look))")
                    XCTAssertEqual(title.frame.midY, expected.y, accuracy: 6,
                                   "The history's title stays in its place in it as it stands back (\(look))")
                    XCTAssertEqual(title.frame.midX, expected.x, accuracy: 6,
                                   "The history's title stays in its place in it as it stands back (\(look))")
                }
                guard let shot = XCUIScreen.main.screenshot().image.cgImage else {
                    XCTFail("No screenshot"); app.terminate(); continue
                }
                let scale = CGFloat(shot.width) / screen.width
                // The sidebar is 92pt short of the screen's width.
                let edge = ((screen.width - 92) * CGFloat(held)).rounded()
                func luma(_ x: CGFloat, _ y: CGFloat) -> Double {
                    RGBAPixels(shot, CGRect(x: x - 0.5, y: y - 0.5, width: 1, height: 1), scale: scale)?.meanLuma ?? -1
                }
                // The conversation keeps its size and place (1.1.0 (272)):
                // its top at the screen's top, its foot at the screen's foot.
                // Its paper reaches the foot, lighter there than the history
                // beside it, past the corner's curve (UI check run
                // 43275399807 caught it short, under the composer).
                let footPaper = luma(edge + 80, screen.height - 3), footHistory = luma(max(4, edge - 30), screen.height - 3)
                print("PANEL-CORNER \(look) " + String(format: "foot paper %.0f history %.0f", footPaper, footHistory))
                XCTAssertGreaterThanOrEqual(abs(footPaper - footHistory), 1.5, "The conversation's paper reaches its foot (\(look))")
                capture("history-depth-held-\(look)", app: app)
                let corners: [(String, [CGFloat])] = [("top", [3, 8, 14]),
                                                       ("bottom", [screen.height - 22, screen.height - 14, screen.height - 8, screen.height - 3])]
                for (corner, rows) in corners {
                    var readings: [String] = []
                    var step = 0.0
                    for y in rows {
                        let outside = luma(edge - 1.5, y), inside = luma(edge + 1.5, y)
                        step = max(step, abs(inside - outside))
                        readings.append(String(format: "y%.0f %.0f|%.0f", y, outside, inside))
                    }
                    print("PANEL-CORNER \(look) \(corner) edge \(Int(edge)): " + readings.joined(separator: " ")
                          + String(format: " step %.1f", step))
                    XCTAssertLessThanOrEqual(step, 4, "The history runs on past the conversation's \(corner) edge (\(look))")
                    let crop = CGRect(x: max(0, edge - 50), y: corner == "top" ? 0 : screen.height - 110,
                                      width: 130, height: 110)
                    if let piece = shot.cropping(to: CGRect(x: crop.minX * scale, y: crop.minY * scale,
                                                            width: crop.width * scale, height: crop.height * scale).integral) {
                        let attachment = XCTAttachment(image: UIImage(cgImage: piece))
                        attachment.name = "corner-\(look)-\(corner)"
                        attachment.lifetime = .keepAlways
                        add(attachment)
                    }
                }
                let tip = luma(edge + 4, screen.height - 4), paper = luma(edge + 60, screen.height * 0.6)
                print("PANEL-CORNER \(look) " + String(format: "tip %.0f paper %.0f", tip, paper))
                if !dark {
                    XCTAssertLessThan(tip, paper - 5, "The conversation's bottom corner is round (\(look))")
                    if let strip = RGBAPixels(shot, CGRect(x: edge + 10, y: 120, width: screen.width - edge - 10,
                                                           height: screen.height - 240), scale: scale) {
                        print("PANEL-CORNER \(look) " + String(format: "strip %.1f", strip.meanLuma))
                        XCTAssertGreaterThan(strip.meanLuma, 150, "The slid conversation is not black (\(look))")
                    }
                }
                app.terminate()
            }
        }
    }

    /// Opening and closing the history slide the whole conversation, its
    /// paper with it, through every point in between (Hachimoto さん's
    /// recording, 2026-11-12, on 1.1.0 (264)): there the paper went back in
    /// place as a close began, ahead of the rest of the conversation, and
    /// hid the history at once, so the slide looked skipped. XCUITest's
    /// screenshots wait for a slide to end, so the app samples its own
    /// screen through each slide, one row 45% of the way down every 10pt
    /// (`--drawer-probe`, DRAWER-PROBE lines), with the drawer fifteen times
    /// as slow (`--drawer-slow`). In each sample the paper starts where the
    /// history's darker colour and its text end (the edge); through a slide
    /// that edge moves one way only, and stands at several points between
    /// closed and open on the way. And since 1.1.0 (272) the drawer's own
    /// frames (trace lines): no frame moves it far, and the history comes
    /// forward behind the conversation opening and sinks back ahead of it
    /// closing, its lift never ahead of the slide.
    @MainActor func testClosingHistorySlidesThePaperWithTheConversation() {
        continueAfterFailure = true
        let app = PreviewApp()
        app.launchArguments = ["--history-fixture", "--drawer-probe", "--drawer-slow"]
        app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        let sidebar = historySidebar(app)
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
        // Slowed fifteen times, the history's lift comes to rest about
        // twelve and a half seconds on (1.1.0 (272)).
        sleep(15)
        // The strip of conversation left showing closes it.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)
        XCTAssertEqual(XCTWaiter().wait(for: [closed], timeout: 25), .completed, "The history closes")
        sleep(2)
        let probe = app.descendants(matching: .any)["drawer-probe"]
        XCTAssertTrue(probe.waitForExistence(timeout: 3))
        let lines = probe.label.components(separatedBy: " | ").filter { !$0.isEmpty }
        for line in lines { print("DRAWER-PROBE \(line)") }
        let width = Int(app.frame.width), openEdge = width - 92
        for kind in ["open", "close"] {
            // Where the paper starts in each sample, in points.
            let edges = drawerEdges(lines, kind)
            print("DRAWER-PROBE \(kind) edges: \(edges.map(String.init).joined(separator: " "))")
            XCTAssertGreaterThanOrEqual(edges.count, 8, "The app sampled its screen through the \(kind)")
            let between = Set(edges.filter { $0 > 30 && $0 < openEdge - 20 })
            XCTAssertGreaterThanOrEqual(between.count, 4,
                                        "The \(kind) goes through the middle, the history showing beside the paper all the way")
            for (earlier, later) in zip(edges, edges.dropFirst()) {
                if kind == "open" {
                    XCTAssertGreaterThanOrEqual(later, earlier - 10, "The open never goes back (\(edges))")
                } else {
                    XCTAssertLessThanOrEqual(later, earlier + 10, "The close never goes back (\(edges))")
                }
            }
            // Where the paper ends going up the trailing column (DRAWER-PROBE
            // <kind>-foot, points up from the foot), for the record: drawn
            // only within its safe area it stopped 34pt up (UI check run
            // 43275399807). Since 1.1.0 (272) the conversation is neither
            // smaller nor lower as it slides, only aside, so its paper
            // reaches the foot as it does closed; the column now meets its
            // rounded corner early in a slide and the composer's edge
            // later (run 43360091745), and the paper's foot is checked
            // where it rests (testSlidPanelCornersShowTheHistory) and in
            // every frame of the film (testHistoryDrawerFilm).
            let feet = lines.filter { $0.hasPrefix("\(kind)-foot ") }
                .compactMap { $0.split(separator: ":").last?.split(separator: " ").first.flatMap { Int($0) } }
            print("DRAWER-PROBE \(kind) feet: \(feet.map(String.init).joined(separator: " "))")
            if let layouts = lines.first(where: { $0.hasPrefix("\(kind)-layouts:") })?
                .split(separator: " ").last.flatMap({ Int($0) }) {
                XCTAssertLessThanOrEqual(layouts, 2, "The header's blur is moved, not laid out anew, through the \(kind)")
            }
            // The drawer's frames (1.1.0 (272)).
            guard let trace = drawerTrace(lines, kind) else {
                XCTFail("The drawer's frames were traced through the \(kind)"); continue
            }
            print("DRAWER-TRACE \(kind): frames \(trace.frames.count) firststep \(trace.firstStep) step \(trace.step)")
            // Slowed, it keeps to the clock, so a frame the simulator drew
            // late moves it further; its steps at full speed through a
            // stall are checked in testDrawerKeepsEveryFrameThroughAStall.
            XCTAssertGreaterThanOrEqual(trace.frames.count, 40, "The \(kind) is drawn in many frames")
            if let last = trace.frames.last {
                let target: CGFloat = kind == "open" ? 1 : 0
                XCTAssertEqual(last.slide, target, accuracy: 0.001, "The \(kind) ends in place")
                XCTAssertEqual(last.lift, target, accuracy: 0.001, "The history ends in place after the \(kind)")
            }
            // Opening, the history comes forward behind the conversation;
            // closing, it sinks back ahead of it: never ahead of the slide.
            let ahead = trace.frames.map { $0.lift - $0.slide }.max() ?? 0
            XCTAssertLessThanOrEqual(ahead, 0.02, "The history's lift keeps behind the slide through the \(kind)")
            let midway = trace.frames.filter { $0.slide > 0.3 && $0.slide < 0.7 }
            let lag = midway.map { $0.slide - $0.lift }.max() ?? 0
            print("DRAWER-TRACE \(kind): midway \(midway.count) lag " + String(format: "%.3f", lag))
            XCTAssertGreaterThanOrEqual(lag, 0.05, "Midway through the \(kind) the history stands further back than the slide")
        }
        app.terminate()
    }

    /// A slide that begins while the main thread is busy is still shown
    /// through every point in between (1.1.0 (272), Hachimoto さん's
    /// recording on 270, 2026-11-13: two closes of four showed in one
    /// frame). `--drawer-stall 450` keeps the update a slide begins in busy
    /// for 450ms (DrawerStall), as a long chat opening under the closing
    /// history, or a new chat, can on the phone. The drawer's own motion
    /// starts at the first frame drawn after it and moves at most two
    /// frames' worth a frame: its first frame barely moves, and no frame
    /// moves it far however late it comes (its trace, DRAWER-STALL). For
    /// comparison, 270's way (`--drawer-swiftui`, SwiftUI's spring) is run
    /// the same and its samples printed: in run 43364246624 it went from
    /// closed to open, and back, between two samples.
    @MainActor func testDrawerKeepsEveryFrameThroughAStall() {
        continueAfterFailure = true
        var betweens: [String: Int] = [:]
        for way in ["frames", "swiftui"] {
            let app = PreviewApp()
            app.launchArguments = ["--history-fixture", "--drawer-probe", "--drawer-stall", "450"]
                + (way == "swiftui" ? ["--drawer-swiftui"] : [])
            app.launch()
            let open = app.buttons["会話一覧を開く"]
            XCTAssertTrue(open.waitForExistence(timeout: 10))
            sleep(1)
            let sidebar = historySidebar(app)
            open.tap()
            XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
            sleep(2)
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
            let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)
            XCTAssertEqual(XCTWaiter().wait(for: [closed], timeout: 8), .completed, "The history closes (\(way))")
            sleep(1)
            let probe = app.descendants(matching: .any)["drawer-probe"]
            XCTAssertTrue(probe.waitForExistence(timeout: 3))
            let lines = probe.label.components(separatedBy: " | ").filter { !$0.isEmpty }
            for line in lines { print("DRAWER-STALL \(way) \(line)") }
            let openEdge = Int(app.frame.width) - 92
            for kind in ["open", "close"] {
                let edges = drawerEdges(lines, kind)
                let between = Set(edges.filter { $0 > 30 && $0 < openEdge - 20 }).count
                betweens["\(way)-\(kind)"] = between
                print("DRAWER-STALL \(way) \(kind) edges: \(edges.map(String.init).joined(separator: " ")) between \(between)")
                guard way == "frames" else { continue }
                // The samples are for the record: the check's simulator takes
                // one about every 300ms (run 43364246624), so two can fall
                // either side of the slide's middle. Every frame drawn is in
                // the trace.
                if let trace = drawerTrace(lines, kind) {
                    print("DRAWER-STALL \(kind) trace: frames \(trace.frames.count) first \(trace.firstMilliseconds)ms firststep \(trace.firstStep) step \(trace.step)")
                    XCTAssertGreaterThanOrEqual(trace.firstMilliseconds, 400, "The stall held the \(kind)'s first frame back")
                    XCTAssertLessThanOrEqual(trace.firstStep, 0.15, "After the stall the \(kind) starts from where it stood")
                    XCTAssertLessThanOrEqual(trace.step, 0.2, "No frame of the \(kind) jumps")
                    XCTAssertGreaterThanOrEqual(trace.frames.count, 12, "The \(kind) is drawn in many frames")
                } else {
                    XCTFail("The drawer's frames were traced through the \(kind)")
                }
            }
            app.terminate()
        }
        print("DRAWER-STALL between: " + betweens.sorted { $0.key < $1.key }.map { "\($0.key)=\($0.value)" }.joined(separator: " "))
    }

    /// The paper's edge in each DRAWER-PROBE row sample of a slide, in points.
    private func drawerEdges(_ lines: [String], _ kind: String) -> [Int] {
        lines.filter { $0.hasPrefix(kind + " ") }.compactMap { line in
            guard let values = line.split(separator: ":").last?.split(separator: " ").compactMap({ Int($0) }),
                  values.count > 20 else { return nil }
            let start = (0..<values.count).first { index in values[index...].allSatisfy { $0 >= 242 } } ?? values.count
            return 10 + start * 10
        }
    }

    /// The drawer's frames through a slide, from its trace line (1.1.0 (272)).
    private func drawerTrace(_ lines: [String], _ kind: String)
        -> (frames: [(slide: CGFloat, lift: CGFloat)], firstMilliseconds: Int, firstStep: Double, step: Double)? {
        guard let line = lines.first(where: { $0.hasPrefix("trace-\(kind) frames") }),
              let colon = line.firstIndex(of: ":") else { return nil }
        let head = line[..<colon].split(separator: " ")
        func value(after word: String) -> String? {
            guard let index = head.firstIndex(where: { $0 == word }), index + 1 < head.count else { return nil }
            return String(head[index + 1])
        }
        let first = Int((value(after: "first") ?? "0").replacingOccurrences(of: "ms", with: "")) ?? 0
        let firstStep = Double(value(after: "firststep") ?? "") ?? 1
        let step = Double(value(after: "step") ?? "") ?? 1
        let frames: [(slide: CGFloat, lift: CGFloat)] = line[line.index(after: colon)...].split(separator: " ").compactMap { point in
            let parts = point.split(separator: ":")
            guard parts.count == 2 else { return nil }
            let values = parts[1].split(separator: "/").compactMap { Double($0) }
            guard values.count == 2 else { return nil }
            return (CGFloat(values[0]), CGFloat(values[1]))
        }
        return (frames, first, firstStep, step)
    }

    /// The phone's history drawer filmed a sixtieth of a second a frame
    /// (1.1.0 (272), fielua-reports Issue #11): the app steps its drawer
    /// and keeps each frame (`--drawer-film`, DrawerFilm), and the UI check
    /// makes films of them (scripts/drawer-film.swift, SHOT
    /// drawer-film-*.mp4). Opening by the header button, closing by the
    /// strip, swipes both ways, a slide caught and taken back, taps one
    /// after another and a long chat chosen from the history; then open and
    /// close in dark and with Reduce Motion.
    @MainActor func testHistoryDrawerFilm() {
        continueAfterFailure = true
        for look in ["light", "dark", "reduced"] {
            let app = PreviewApp()
            app.launchArguments = ["--history-fixture", "--drawer-film", look]
                + (look == "dark" ? ["--dark"] : look == "reduced" ? ["--reduce-motion"] : [])
            app.launch()
            let film = app.descendants(matching: .any)["drawer-film"]
            XCTAssertTrue(film.waitForExistence(timeout: 15), "The film starts (\(look))")
            let done = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label BEGINSWITH 'done'"), object: film)
            XCTAssertEqual(XCTWaiter().wait(for: [done], timeout: 300), .completed, "The film ends (\(look))")
            print("DRAWER-FILM \(look): \(film.label)")
            app.terminate()
        }
    }

    /// The history's open and close as one motion (1.1.0 (268), Hachimoto
    /// さん 2026-11-12, after ChatGPT's): the conversation steps back and
    /// down, a little paler, as the history comes in from the left, and
    /// comes forward again as it closes. The session recording keeps every
    /// frame (scope history-slide, MENU-MARK drawer-* lines, sheets
    /// composer-video-drawer-*): by the header button and the strip, by a
    /// swipe and by a swipe let go a third of the way (it goes back), with
    /// the keyboard up and a draft that stays, in dark, and with Reduce
    /// Motion, where the depth gives way to the slide and the fade alone.
    @MainActor func testHistoryDepthFrames() {
        continueAfterFailure = true
        for (variant, flags) in [("light", [String]()), ("dark", ["--dark"]), ("reduced", ["--reduce-motion"])] {
            let app = PreviewApp(); app.launchArguments = ["--history-fixture"] + flags
            app.launch()
            let open = app.buttons["会話一覧を開く"]
            XCTAssertTrue(open.waitForExistence(timeout: 10))
            let sidebar = historySidebar(app)
            let strip = app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5))
            func closes(_ how: String) {
                let gone = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)
                XCTAssertEqual(XCTWaiter().wait(for: [gone], timeout: 8), .completed, "The history closes (\(variant), \(how))")
            }
            Thread.sleep(forTimeInterval: 1.5)
            menuMark("drawer-\(variant)-open"); open.tap()
            XCTAssertTrue(sidebar.waitForExistence(timeout: 5), "The history opens (\(variant))")
            Thread.sleep(forTimeInterval: 1.6)
            capture("history-depth-\(variant)-open", app: app)
            menuMark("drawer-\(variant)-close"); strip.tap()
            closes("strip")
            Thread.sleep(forTimeInterval: 1.6)
            guard variant == "light" else { app.terminate(); continue }

            // A swipe right opens it at the finger's pace, a swipe left closes it.
            let left = app.coordinate(withNormalizedOffset: CGVector(dx: 0.15, dy: 0.45))
            menuMark("drawer-swipe-open")
            left.press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.46)),
                       withVelocity: .fast, thenHoldForDuration: 0)
            XCTAssertTrue(sidebar.waitForExistence(timeout: 5), "A swipe opens the history")
            Thread.sleep(forTimeInterval: 1.6)
            menuMark("drawer-swipe-close")
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.5))
                .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.1, dy: 0.51)),
                       withVelocity: .fast, thenHoldForDuration: 0)
            closes("swipe")
            Thread.sleep(forTimeInterval: 1.6)
            // Let go a third of the way, held still: it settles back closed.
            menuMark("drawer-swipe-partial")
            left.press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.42, dy: 0.46)),
                       withVelocity: .slow, thenHoldForDuration: 0.4)
            closes("let go")
            Thread.sleep(forTimeInterval: 1.6)

            // With the keyboard up and a draft: the keyboard goes, the draft stays.
            let input = app.textViews["chat-input"]
            XCTAssertTrue(input.waitForExistence(timeout: 3))
            input.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
            input.typeText("下書きはそのまま")
            Thread.sleep(forTimeInterval: 1)
            menuMark("drawer-keyboard-open"); open.tap()
            XCTAssertTrue(sidebar.waitForExistence(timeout: 5), "The history opens over the keyboard")
            Thread.sleep(forTimeInterval: 1.6)
            capture("history-depth-keyboard-open", app: app)
            menuMark("drawer-keyboard-close"); strip.tap()
            closes("keyboard")
            Thread.sleep(forTimeInterval: 1.6)
            XCTAssertEqual(input.value as? String, "下書きはそのまま", "The draft is kept through the history")
            capture("history-depth-keyboard-after", app: app)

            // Closed by a search result with the history's own keyboard up:
            // the conversation comes back whole, its field in its place.
            let fieldTop = input.frame.minY
            open.tap()
            XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
            Thread.sleep(forTimeInterval: 1)
            app.buttons["history-search"].tap()
            let search = app.textFields["history-search-field"]
            XCTAssertTrue(search.waitForExistence(timeout: 3))
            search.tap(); search.typeText("カメムシ")
            let result = app.buttons["会話を開く: カメムシ対策"]
            XCTAssertTrue(result.waitForExistence(timeout: 3))
            menuMark("drawer-search-close"); result.tap()
            closes("search result")
            Thread.sleep(forTimeInterval: 1.6)
            capture("history-depth-search-after", app: app)
            XCTAssertEqual(input.frame.minY, fieldTop, accuracy: 2, "The field is back in its place after the history's search")
            app.terminate()
        }
    }

    @MainActor func testMenuSendAndInteractiveBack() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--gesture-diagnostics"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        // The plus is its 36pt glass circle, which is also its target: a
        // tap near its edge opens the menu.
        XCTAssertEqual(menu.frame.height, 36, accuracy: 1)
        XCTAssertEqual(menu.frame.width, 36, accuracy: 1)
        let controlHeight: CGFloat = 44
        menu.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.12)).tap()
        capture("after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["新しいチャット"].waitForExistence(timeout: 3), "The plus answers near its edge")
        capture("expanded-menu", app: app)
        app.buttons["新しいチャット"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 3))
        input.tap()
        input.typeText("Animation check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Animation check"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 5))
        capture("sent-message-keyboard", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["会話を開く: Animation check"].tap()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
        // A swipe right on the conversation slides the history out.
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.45))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.46))
        start.press(forDuration: 0.1, thenDragTo: end)
        capture("after-history-swipe", app: app)
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        capture("conversation-list", app: app)
        XCTAssertEqual(app.descendants(matching: .any).matching(identifier: "history-sidebar").count, 1)
        for _ in 0..<2 {
            app.buttons["会話を開く: Animation check"].tap()
            XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
            app.buttons["会話一覧を開く"].tap()
            XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
            XCTAssertEqual(app.descendants(matching: .any).matching(identifier: "history-sidebar").count, 1)
        }
        XCTAssertGreaterThanOrEqual(app.buttons["history-compose"].frame.height, controlHeight - 1)
    }

    @MainActor func testLongConversationJumpControlAndHeader() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        capture("long-chat-latest", app: app)
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 3))
        XCTAssertEqual(jump.frame.height, 44, accuracy: 1)
        XCTAssertLessThan(jump.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
        XCTAssertEqual(jump.frame.midX, app.windows.firstMatch.frame.midX, accuracy: 1, "Jump control is centered")
        XCTAssertFalse(app.buttons["chat-switch-e2b"].exists, "No attachment note above the field")
        XCTAssertLessThan(jump.frame.maxY, app.textViews["chat-input"].frame.minY,
                          "Jump control sits just above the field")
        capture("jump-from-composer", app: app)
        jump.tap()
        let disappeared = NSPredicate(format: "exists == false")
        expectation(for: disappeared, evaluatedWith: jump)
        waitForExpectations(timeout: 4)
        capture("jump-returned-to-latest", app: app)
        // Selectable reply text is reading content, not a tappable control.
        // Check its actual viewport bounds rather than XCTest's hit point.
        let latest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(latest.exists)
        XCTAssertGreaterThan(latest.frame.width, 0)
        XCTAssertGreaterThan(latest.frame.height, 0)
        XCTAssertGreaterThanOrEqual(latest.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(latest.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
    }

    @MainActor func testStreamingReplyRemainsReadableAndFinishes() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--slow-reply"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Text animation")
        app.buttons["送信する"].tap()
        let partial = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "新しい文字が")).firstMatch
        XCTAssertTrue(partial.waitForExistence(timeout: 5))
        // Quick shots of the reply's first lines while its characters flow
        // in, to review the fade, rise and stagger (markdown-reveal-strip).
        revealStrip("markdown-reveal-strip", app: app, around: partial.frame)
        capture("reply-revealing", app: app)
        let finished = app.staticTexts["新しい文字がぼやけた状態から少しずつくっきり表示されます。\nすでに読んだ文章は鮮明なままです。日本語と絵文字もそのまま表示します。😊"]
        XCTAssertTrue(finished.waitForExistence(timeout: 8))
        expectation(for: NSPredicate(format: "exists == false"),
                    evaluatedWith: app.buttons["停止する"])
        waitForExpectations(timeout: 3)
        capture("reply-fully-clear", app: app)
        XCTAssertTrue(app.staticTexts["Text animation"].exists)
    }

    /// A paragraph's last characters, still in the rainbow when the next
    /// paragraph starts, keep fading to their own colour instead of turning
    /// clear at once: every chunk of a streamed reply keeps its reveal. The
    /// old behaviour (only the last chunk revealing) runs second, for
    /// comparison; only the first run is asserted.
    @MainActor func testParagraphBreakKeepsRainbowFlowing() {
        continueAfterFailure = false
        guard let kept = paragraphBreakReveal("markdown-reveal-paragraph", arguments: ["--paragraph-stream"]) else {
            return XCTFail("The paragraph break was not captured")
        }
        let old = paragraphBreakReveal("markdown-reveal-paragraph-old",
                                       arguments: ["--paragraph-stream", "--probe-last-chunk-live"])
        print(String(format: "MARKDOWN-NOTE paragraph break: rainbow in the first paragraph %ld -> %ld pt² (fixed), ",
                     kept.before, kept.at)
              + (old.map { String(format: "%ld -> %ld pt² (old)", $0.before, $0.at) } ?? "old run not captured"))
        if kept.gap <= 0.45 {
            XCTAssertGreaterThanOrEqual(kept.at, 30, "The first paragraph's rainbow vanished when the second began")
        }
    }

    /// Streams two paragraphs and screenshots them as quick as they come;
    /// returns the coloured area of the first paragraph in the shot before
    /// and in the first shot where the second paragraph shows its rainbow,
    /// and the time between those shots. (Grey below the reply is the
    /// preview's status line, so only colour marks the second paragraph.)
    @MainActor private func paragraphBreakReveal(_ name: String,
                                                 arguments: [String]) -> (before: Int, at: Int, gap: Double)? {
        let app = PreviewApp()
        app.launchArguments = arguments
        app.launch()
        defer { app.terminate() }
        // A new chat, where the rows stay still while the reply streams.
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("Paragraphs")
        app.buttons["送信する"].tap()
        let first = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "最初の段落では")).firstMatch
        guard first.waitForExistence(timeout: 5) else { return nil }
        let screen = app.frame
        let left = first.frame.minX
        let firstTop = first.frame.minY
        let region = CGRect(x: max(0, left - 4), y: max(0, first.frame.minY - 6),
                            width: screen.width - 2 * max(0, left - 4), height: 160)
        var shots: [(t: Double, area: ScreenArea, crop: UIImage)] = []
        let start = Date()
        while Date().timeIntervalSince(start) < 4.5, shots.count < 40 {
            let t = Date().timeIntervalSince(start)
            guard let image = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(image, region, screenWidth: screen.width) else { continue }
            let scale = CGFloat(image.width) / screen.width
            let pixels = CGRect(x: region.minX * scale, y: region.minY * scale,
                                width: region.width * scale, height: region.height * scale).integral
            guard let cropped = image.cropping(to: pixels) else { continue }
            // A copy at two pixels a point, so the full screenshot is let go.
            let format = UIGraphicsImageRendererFormat()
            format.scale = 2
            let crop = UIGraphicsImageRenderer(size: region.size, format: format).image { _ in
                UIImage(cgImage: cropped).draw(in: CGRect(origin: .zero, size: region.size))
            }
            shots.append((t, area, crop))
        }
        let second = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "次の段落が")).firstMatch
        guard second.waitForExistence(timeout: 8) else { return nil }
        let top = second.frame.minY
        print(String(format: "MARKDOWN-NOTE %@ first paragraph top %.1f then %.1f, second at %.1f, region %.1f-%.1f",
                     name, firstTop, first.frame.minY, top, region.minY, region.maxY))
        guard top > region.minY + 12, top < region.maxY - 8 else { return nil }
        // From the paragraph's own top, clear of the sent bubble's blue above.
        let above = CGRect(x: region.minX, y: firstTop, width: region.width, height: top - 2 - firstTop)
        let below = CGRect(x: region.minX, y: top, width: region.width, height: region.maxY - top)
        let readings = shots.map { shot in
            (t: shot.t, above: shot.area.marks(in: above, background: 255).colour,
             below: shot.area.marks(in: below, background: 255))
        }
        print("MARKDOWN-NOTE \(name) " + readings.map {
            String(format: "%.2fs %ld|%ld+%ld", $0.t, $0.above, $0.below.colour, $0.below.ink)
        }.joined(separator: " "))
        guard let k = readings.firstIndex(where: { $0.below.colour >= 20 }), k > 0 else { return nil }
        // The shots around the break on one sheet.
        let picked = Array(shots[max(0, k - 4)..<min(shots.count, k + 6)])
        let label: CGFloat = 16
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        let sheetSize = CGSize(width: region.width, height: (region.height + label) * CGFloat(picked.count))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, shot) in picked.enumerated() {
                let y = CGFloat(index) * (region.height + label)
                shot.crop.draw(in: CGRect(x: 0, y: y + label, width: region.width, height: region.height))
                (String(format: "%.0f ms", shot.t * 1000) as NSString)
                    .draw(at: CGPoint(x: 4, y: y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 12), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        return (readings[k - 1].above, readings[k].above, readings[k].t - readings[k - 1].t)
    }

    @MainActor func testDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--dark", "--reduce-motion", "--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        capture("dark-after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["新しいチャット"].waitForExistence(timeout: 3))
        capture("dark-reduced-motion-menu", app: app)
        dismissMenu(app.buttons["新しいチャット"], app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        reading.swipeDown()
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
        capture("dark-glass-scrolling", app: app)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Glass check")
        XCTAssertTrue(app.buttons["送信する"].isHittable)
        capture("dark-glass-keyboard", app: app)
    }

    @MainActor func testModelCatalogSwitchPreservesGemmaHistory() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launch()
        openModelList(app)
        capture("model-catalog", app: app)
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists, "Qwen is hidden unless developer settings are on")
        let use = app.buttons["model-use-gemma-4-e2b"]
        for _ in 0..<8 {
            if use.isHittable { break }
            app.scrollViews["model-list"].swipeUp()
        }
        XCTAssertTrue(use.isHittable)
        capture("model-qwen-ready", app: app)
        use.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.staticTexts["画面の動きを確認"].exists)
        capture("qwen-new-chat", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 3))
        app.buttons["会話を開く: 画面の動きを確認"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["画面の動きを確認"].exists)
        capture("gemma-history-preserved", app: app)
    }

    @MainActor func testTallReplyBubbleAndFeatheredChrome() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--tall-bubble"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["chat-model-settings"].isHittable)
        capture("tall-bubble-bottom", app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        capture("light-feathered-chrome", app: app)
        menu.tap()
        XCTAssertTrue(app.buttons["新しいチャット"].waitForExistence(timeout: 3))
        capture("light-feathered-menu", app: app)
        dismissMenu(app.buttons["新しいチャット"], app: app)
        let greeting = app.staticTexts["こんにちは"].firstMatch
        for _ in 0..<10 {
            if greeting.exists && greeting.frame.minY >= reading.frame.minY
                && greeting.frame.maxY < menu.frame.minY { break }
            reading.swipeDown()
        }
        XCTAssertTrue(greeting.exists)
        XCTAssertGreaterThan(greeting.frame.width, 0)
        XCTAssertLessThan(greeting.frame.width, reading.frame.width * 0.75)
        capture("short-bubble-shapes", app: app)
    }

    @MainActor func testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll() { sendFromOlderMessages([]) }

    /// Probe rounds 5-6 (df83ad6, 8175ec2): this test froze at the first
    /// swipe after the second send with and without the rows' transition,
    /// scroll spring and explicit ids, and with plain replies; an eager
    /// VStack passed. ChatView now lays out the latest messages eagerly.
    @MainActor func testProbeSendOlderBaseline() { sendFromOlderMessages([], probe: "baseline") }
    @MainActor func testProbeSendOlderPlainReplies() {
        sendFromOlderMessages(["--probe-plain-replies"], probe: "plain-replies")
    }

    /// 81 messages: the older 40 stay lazy rows above the eager block.
    @MainActor func testProbeLongerChatScrollsThroughLazyRows() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--long-chat", "--longer-chat"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Longer chat send")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["Longer chat send"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        let older = app.staticTexts["長い会話の確認 18"].firstMatch
        for _ in 0..<16 {
            if older.exists && older.isHittable { break }
            reading.swipeDown()
        }
        XCTAssertTrue(older.exists, "Scrolled into the lazy rows")
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 5))
        let ink = readingInk(app)
        print("PROBE longer-chat ink=\(ink)")
        XCTAssertGreaterThan(ink, Self.drawnInk, "The lazy rows must be drawn")
        capture("probe-longer-chat-older", app: app)
        app.buttons["chat-jump-latest"].tap()
        Thread.sleep(forTimeInterval: 1.5)
        XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
        capture("probe-longer-chat-latest", app: app)
        print("PROBE longer-chat passed")
    }

    @MainActor private func sendFromOlderMessages(_ flags: [String], probe: String? = nil) {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = PreviewApp()
            app.launchArguments = Self.keepOpen + ["--long-chat"] + flags + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
            XCTAssertGreaterThan(readingInk(app), Self.drawnInk, "Older messages must be drawn")
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap(); input.typeText("Send scroll regression\nSecond line\nThird line")
            let beforeHeight = input.frame.height
            app.buttons["送信する"].tap()
            let sent = app.staticTexts["Send scroll regression\nSecond line\nThird line"].firstMatch
            XCTAssertTrue(sent.waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
            XCTAssertLessThan(input.frame.height, beforeHeight)
            XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
            XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
            capture(dark ? "dark-send-scroll-settled" : "light-send-scroll-settled", app: app)
            input.tap(); input.typeText("Second send still works")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts["Second send still works"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["chat-jump-latest"].isHittable)
            let ink = readingInk(app)
            print("PROBE send-older ink after second send dark=\(dark) ink=\(ink)")
            XCTAssertGreaterThan(ink, Self.drawnInk, "Older messages must be drawn after two sends")
            app.buttons["chat-jump-latest"].tap()
            capture(dark ? "dark-second-send-responsive" : "light-second-send-responsive", app: app)
            app.terminate()
        }
        if let probe { print("PROBE send-older \(probe) passed") }
    }

    @MainActor func testGenerationSettingsCancelSaveAndPromptPersist() {
        continueAfterFailure = false
        let app = PreviewApp()
        // TopK and the backends are shown with developer settings only.
        // E2B's settings: E4B starts in 高速, which never thinks (1.0.119),
        // and testE4BPhotoDetailIsSavedWithTheModel checks E4B's two modes.
        app.launchArguments = ["--reset-settings", "--developer-settings", "--e2b"]
        app.launch()
        openConfiguration(app)
        let topK = app.textFields["setting-TopK"]
        revealConfigurationControl(topK, app: app)
        XCTAssertTrue(app.staticTexts["setting-help-TopK"].exists)
        XCTAssertEqual(topK.value as? String, "40")
        replace(topK, with: "12")
        app.buttons["キャンセル"].tap()
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "40", "Cancel must discard draft settings")
        revealConfigurationControl(topK, app: app)
        replace(topK, with: "12")
        let cpu = app.segmentedControls["execution-backend"].buttons["CPU"]
        revealConfigurationControl(cpu, app: app)
        cpu.tap()
        XCTAssertTrue(cpu.isSelected, "CPU must be selected before saving")
        let visionCPU = app.segmentedControls["vision-execution-backend"].buttons["CPU"]
        let visionGPU = app.segmentedControls["vision-execution-backend"].buttons["GPU"]
        revealConfigurationControl(visionCPU, app: app)
        XCTAssertTrue(visionCPU.isSelected, "New vision settings default to CPU without changing the main backend")
        visionGPU.tap()
        XCTAssertTrue(visionGPU.isSelected)
        XCTAssertTrue(cpu.isSelected, "Vision GPU must not change the main CPU preference")
        let thinking = app.switches["enable-thinking"]
        let speculation = app.switches["enable-speculation"]
        revealConfigurationControl(thinking, app: app)
        XCTAssertTrue(thinking.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-thinking"].exists)
        // SwiftUI exposes the labeled row as the switch's accessibility frame.
        // Tap the visible switch at the trailing edge rather than its label.
        thinking.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertTrue(speculation.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-speculation"].exists)
        speculation.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(speculation.value as? String, "1")
        capture("model-configuration-controls", app: app)
        app.segmentedControls.buttons["システムプロンプト"].tap()
        let prompt = app.textViews["system-prompt-input"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        replace(prompt, with: "Reply briefly in Japanese.")
        capture("custom-system-prompt", app: app)
        app.buttons["configuration-save"].tap()
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "12")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
        app.buttons["configuration-save"].tap()
        app.terminate()
        app.launchArguments = ["--developer-settings", "--e2b"]
        app.launch()
        openConfiguration(app)
        XCTAssertEqual(topK.value as? String, "12", "Saved model configuration must survive relaunch")
        capture("saved-model-configuration", app: app)
        revealConfigurationControl(cpu, app: app)
        XCTAssertTrue(cpu.isSelected)
        revealConfigurationControl(visionGPU, app: app)
        XCTAssertTrue(visionGPU.isSelected, "The independently saved vision backend must survive relaunch")
        revealConfigurationControl(thinking, app: app)
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertEqual(speculation.value as? String, "1")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
    }

    /// E4B (the default model): documents are read into text on device and
    /// sent as text.
    @MainActor func testDocumentImportsPreviewAndArchiveRestore() throws {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--attachment-fixtures"]
        app.launch()
        importFixture("sample-document", extension: "pdf", app: app)
        app.buttons["添付ファイルを開く: sample-document.pdf"].tap()
        XCTAssertTrue(app.navigationBars["sample-document.pdf"].waitForExistence(timeout: 4))
        capture("pdf-preview", app: app)
        app.buttons["閉じる"].tap()
        importFixture("sample-text", extension: "txt", app: app)
        importFixture("sample-data", extension: "json", app: app)
        capture("documents-ready", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: PDF fixture content・本文: 日本語の添付テスト😊・本文: {\"項目\": \"JSONの添付テスト\"}"].waitForExistence(timeout: 6))
        capture("documents-sent", app: app)
        app.terminate()
        app.launchArguments = ["--attachment-fixtures", "--restore-fixture-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-document.pdf"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-data.json"].exists)
        capture("attachment-archive-restored", app: app)
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction("sample-unsupported", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 4))
        app.alerts.buttons["閉じる"].tap()
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        importFixture("sample-sjis", extension: "txt", app: app)
        importFixture("sample-utf16", extension: "txt", app: app)
        importFixture("sample-markdown", extension: "md", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: 日本語の添付確認・本文: 日本語UTF16😊・本文: Markdownの添付テスト"].waitForExistence(timeout: 6))
    }

    /// Qwen takes text only: the plus menu has no photo, camera, file or
    /// video item, only the conversation actions. A file that still reaches
    /// the chat (a test fixture) is refused with the guide, which offers E2B
    /// and keeps the draft when switching.
    @MainActor func testQwenOffersNoAttachments() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--qwen3", "--attachment-fixtures"]
        app.launch()
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        let newChat = menuItem("新しいチャット", "新しいチャット", app)
        XCTAssertTrue(newChat.waitForExistence(timeout: 3))
        // 会話一覧 and 設定 left the plus menu in 1.1.0 (224).
        XCTAssertFalse(menuItem("会話一覧", "会話一覧", app).exists)
        XCTAssertFalse(menuItem("設定", "設定", app).exists)
        for (id, title) in [("chat-attach-photos", "写真"), ("chat-attach-camera", "カメラ"),
                            ("chat-attach-files", "ファイル"), ("chat-attach-video", "動画")] {
            XCTAssertFalse(menuItem(id, title, app).exists, "\(title) must not be offered to Qwen")
        }
        capture("qwen-attachment-menu", app: app)
        chooseMenuAction("sample-text", app: app)
        XCTAssertTrue(app.buttons["E2Bで新しいチャットを開く"].waitForExistence(timeout: 3))
        func guide(_ text: String) -> Bool {
            app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch.exists
        }
        XCTAssertTrue(guide("テキスト専用")); XCTAssertTrue(guide("写真やファイル"))
        capture("qwen-attachment-guidance", app: app)
        if app.buttons["閉じる"].exists { app.buttons["閉じる"].tap() }
        else if app.buttons["Cancel"].exists { app.buttons["Cancel"].tap() }
        else { app.otherElements["PopoverDismissRegion"].tap() }
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].exists, "Dismissing must not switch models")
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Text still works")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Text still works"].waitForExistence(timeout: 4))
        capture("qwen-text-only-sent", app: app)
        // The menu's fixtures wait for the preview reply to finish.
        expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: app.buttons["停止する"])
        waitForExpectations(timeout: 10)
        input.tap(); input.typeText("Keep my draft")
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-text", app: app)
        XCTAssertTrue(app.buttons["E2Bで新しいチャットを開く"].waitForExistence(timeout: 3))
        app.buttons["E2Bで新しいチャットを開く"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4))
        XCTAssertEqual(input.value as? String, "Keep my draft")
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
    }

    /// 動画 (1.1.0 (192), (194)): the plus menu's item is open; with a video
    /// in the draft a second one waits, as one video is analyzed at a time,
    /// and the item says so. A video in the draft can be taken out. The
    /// two-second sample without sound comes in as four scenes and no
    /// sound, and the sent one's note says what was analyzed. Sent with
    /// nothing typed, it stands alone as a photo does, with no bubble and
    /// no ask (1.1.0 (198)).
    @MainActor func testVideoImportSamplesThreeScenesAndDraftRemoval() throws {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--attachment-fixtures", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        let video = menuItem("chat-attach-video", "動画", app)
        XCTAssertTrue(video.waitForExistence(timeout: 4))
        XCTAssertFalse(isLocked(video), "動画 must be open: \(video.label) \(String(describing: video.value))")
        XCTAssertTrue(video.isEnabled)
        capture("video-menu-open", app: app)
        dismissMenu(video, app: app)
        importFixture("sample-video", extension: "mp4", app: app)
        capture("video-draft", app: app)
        app.buttons["chat-add-menu"].tap()
        let full = menuItem("chat-attach-video", "動画", app)
        XCTAssertTrue(full.waitForExistence(timeout: 4))
        // The row's subtitle says why; the system menu may leave it out of
        // the row's accessibility, so the shot shows it.
        capture("video-menu-full", app: app)
        print("VIDEO-MENU full label=\(full.label) value=\(String(describing: full.value)) enabled=\(full.isEnabled)")
        XCTAssertFalse(full.isEnabled, "one video at a time")
        dismissMenu(full, app: app)
        app.buttons["添付を外す: sample-video.mp4"].tap()
        // The row leaves at the panel's pace since 1.1.0 (263), not in one frame.
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-video.mp4"].waitForNonExistence(timeout: 3))
        importFixture("sample-video", extension: "mp4", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 動画4場面・音声なし"].waitForExistence(timeout: 6))
        let note = app.staticTexts["解析済み: 映像4場面 · 音声なし。"]
        XCTAssertTrue(note.exists)
        XCTAssertFalse(app.staticTexts["添付した内容を説明してください。"].exists, "The ask is not shown")
        let sent = app.buttons["添付ファイルを開く: sample-video.mp4"]
        let window = app.windows.firstMatch.frame
        print("SENT-VIDEO video=\(sent.frame) note=\(note.frame) window=\(window)")
        XCTAssertLessThanOrEqual(sent.frame.width, 221, "Within a photo's box")
        XCTAssertGreaterThan(sent.frame.midX, window.midX, "On the sender's side")
        XCTAssertGreaterThan(note.frame.minY, sent.frame.minY + 60, "The note under the picture")
        Thread.sleep(forTimeInterval: 0.6)
        capture("video-analyzed-sent", app: app)
    }

    @MainActor func testWordScannedPdfAndOversizeImports() throws {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--attachment-fixtures"]; app.launch()
        importFixture("sample-word", extension: "docx", app: app)
        importFixture("sample-scan", extension: "pdf", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: Word本文の確認😊・本文: SCAN PDF 123"].waitForExistence(timeout: 12))
        capture("word-and-scanned-pdf-read", app: app)
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-oversize", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["添付ファイルを開く: sample-oversize.docx"].exists)
    }

    @MainActor func testComposerClearsJapaneseEmojiAndDismissesKeyboardOnEverySend() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch(); XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        for text in ["日本語の送信😊", "次のメッセージ\n二行目"] {
            input.tap(); input.typeText(text)
            XCTAssertEqual(input.value as? String, text, "Typing must retain the committed Japanese text before send")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts[text].waitForExistence(timeout: 4))
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: app.keyboards.firstMatch)
            waitForExpectations(timeout: 4)
            XCTAssertEqual(input.value as? String, "")
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["送信する"].isEnabled)
        }
        capture("japanese-draft-cleared-keyboard-closed", app: app)
    }

    @MainActor func testAutomaticDeviceChoiceAndCloudBackupOptIn() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch()
        openModelList(app); app.buttons["model-recommendations"].tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "model-auto-result").firstMatch.waitForExistence(timeout: 4))
        XCTAssertFalse(app.buttons["onboarding-model-continue"].exists, "Automatic choice must not open a manual picker")
        capture("automatic-device-model-selection", app: app)
        let toggle = app.switches["cloud-history-toggle"]
        let list = app.scrollViews["model-list"]
        for _ in 0..<14 { if toggle.isHittable { break }; list.swipeUp() }
        XCTAssertTrue(toggle.isHittable); XCTAssertEqual(toggle.value as? String, "0")
        toggle.tap()
        let cancel = app.buttons["Cancel"].firstMatch.exists ? app.buttons["Cancel"].firstMatch : app.buttons["キャンセル"].firstMatch
        // The folder picker is a system view; on a busy runner it has taken
        // over 5 s to come up (1.1.0 (252), 1 run in 3).
        XCTAssertTrue(cancel.waitForExistence(timeout: 12)); cancel.tap()
        XCTAssertEqual(toggle.value as? String, "0", "Canceling folder access must leave cloud storage off")
        capture("icloud-backup-optional", app: app)
    }

    /// 1.1.0 (252): with Fielua's own iCloud (a local folder standing in for
    /// the container), the switch turns the backup on without a folder to
    /// choose, says the Files app does not show it, and a backup that went to
    /// a folder before moves, naming the folder whose copies stay.
    @MainActor func testBackupGoesToFieluasOwnICloud() {
        continueAfterFailure = false
        var app = PreviewApp(); app.launchArguments = ["--private-cloud"]; app.launch()
        openModelList(app)
        var toggle = app.switches["cloud-history-toggle"]
        for _ in 0..<14 { if toggle.isHittable { break }; app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(toggle.isHittable); XCTAssertEqual(toggle.value as? String, "0")
        XCTAssertTrue(app.staticTexts["会話と添付を、Fielua 専用の iCloud の保存場所に自動でバックアップします。「ファイル」アプリには表示されません。"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["表示されないだけで、守られ方は iCloud のほかのデータと同じです。iPhone の設定の iCloud ストレージから確認・削除できます。"].exists)
        print("ICLOUD toggle '\(toggle.label)'")
        capture("icloud-private-off", app: app)
        toggle.tap()
        XCTAssertTrue(app.staticTexts["保存先: Fielua 専用の iCloud"].waitForExistence(timeout: 5))
        let saved = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "最終書き込み")).firstMatch
        XCTAssertTrue(saved.waitForExistence(timeout: 10), "The first save is written")
        XCTAssertFalse(app.buttons["Cancel"].exists || app.buttons["キャンセル"].exists, "No folder to choose")
        XCTAssertEqual(toggle.value as? String, "1")
        XCTAssertFalse(app.buttons["保存先を変更"].exists)
        XCTAssertFalse(app.buttons["cloud-history-restore-earlier"].exists)
        capture("icloud-private-on", app: app)
        app.terminate()

        app = PreviewApp(); app.launchArguments = ["--private-cloud=moved"]; app.launch()
        openModelList(app)
        toggle = app.switches["cloud-history-toggle"]
        for _ in 0..<14 { if toggle.isHittable { break }; app.scrollViews["model-list"].swipeUp() }
        XCTAssertEqual(toggle.value as? String, "1")
        XCTAssertTrue(app.staticTexts["保存先: Fielua 専用の iCloud"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["前の保存先「Fielua Backup」のコピーは残っていて、「ファイル」アプリから見えます。Fielua は削除しません。"].exists)
        let movedSave = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "最終書き込み")).firstMatch
        XCTAssertTrue(movedSave.waitForExistence(timeout: 10), "The moved backup is written")
        let earlier = app.buttons["cloud-history-restore-earlier"]
        for _ in 0..<4 { if earlier.isHittable { break }; app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(earlier.isHittable)
        capture("icloud-private-moved", app: app)
        earlier.tap()
        let confirm = app.buttons["前の保存先から復元"].firstMatch
        XCTAssertTrue(app.staticTexts["前の保存先のバックアップの会話を、今の会話に追加します。"].waitForExistence(timeout: 4))
        print("ICLOUD earlier restore dialog shown, confirm exists \(confirm.exists)")
        capture("icloud-private-earlier-restore", app: app)
    }

    @MainActor func testBackupWritesLatestSnapshotAndRestoresAttachments() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--cloud-fixture"]; app.launch()
        XCTAssertTrue(app.staticTexts["バックアップ検証成功: 自動保存・最新会話・添付の復元・専用 iCloud"].waitForExistence(timeout: 30))
        capture("backup-local-file-provider-roundtrip", app: app)
    }

    @MainActor func testNativeBubbleInertiaStillWorksAfterSendAndRespectsReduceMotion() throws {
        throw XCTSkip("The UIKit layer driver was retired in1.0.20. Pure SwiftUI row geometry and non-overlap are checked by the mixed attachment streaming test.")
        continueAfterFailure = false
        for reduced in [false, true] {
            let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--long-chat", "--elastic-diagnostics"] + (reduced ? ["--reduce-motion"] : []); app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let input = app.textViews["chat-input"]
            input.tap(); input.typeText("Bounce check"); app.buttons["送信する"].tap()
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            let report = app.staticTexts["elastic-report"]
            if reduced { XCTAssertTrue(report.label.contains("バウンズ待機")) }
            else {
                XCTAssertTrue(report.label.contains("バウンズ動作を確認"), "Actual rendered row layers must have moved after a drag")
                expectation(for: NSPredicate(format: "label CONTAINS %@", "静止"), evaluatedWith: report)
                waitForExpectations(timeout: 4)
            }
            capture(reduced ? "bubble-inertia-disabled" : "bubble-inertia-after-send", app: app)
            app.terminate()
        }
    }

    @MainActor func testVisionProbeScreenSeparatesRealJPEGAndComponentTests() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch()
        openModelList(app)
        let button = app.buttons["open-vision-probe"]
        for _ in 0..<10 where !button.isHittable { app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(button.isHittable); button.tap()
        XCTAssertTrue(app.buttons["run-vision-probe"].waitForExistence(timeout: 5))
        app.buttons["run-vision-probe"].tap()
        XCTAssertTrue(app.staticTexts["UI検証用アプリではネイティブ推論を実行しません。"].waitForExistence(timeout: 3))
        capture("vision-minimal-probe-controls", app: app)
    }

    /// The developer GPU start test opens from the diagnostics card with its
    /// model and precision choices; the preview runs no native inference.
    @MainActor func testGPUStartTestScreenOpensFromDeveloperDiagnostics() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--developer-unlocked"]; app.launch()
        turnOnDeveloperSettings(app)
        let open = app.buttons["open-gpu-test"]
        revealModelControl(open, in: "developer-list", app: app)
        open.tap()
        XCTAssertTrue(app.navigationBars["GPU起動テスト"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "日本の首都はどこですか")).firstMatch.exists,
                      "The screen names its one fixed question")
        let run = app.buttons["run-gpu-test"]
        XCTAssertTrue(run.waitForExistence(timeout: 3))
        capture("gpu-start-test-controls", app: app)
        run.tap()
        XCTAssertTrue(app.staticTexts["UI検証用アプリではネイティブ推論を実行しません。"].waitForExistence(timeout: 3))
        capture("gpu-start-test-preview-run", app: app)
        app.navigationBars["GPU起動テスト"].buttons["閉じる"].tap()
        XCTAssertTrue(open.waitForExistence(timeout: 4))
        // Back to the daily settings for the tests that follow.
        app.terminate(); app.launchArguments = ["--reset-settings"]; app.launch()
    }

    @MainActor private func importFixture(_ name: String, extension suffix: String, app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction(name, app: app)
        XCTAssertTrue(app.buttons["添付ファイルを開く: \(name).\(suffix)"].waitForExistence(timeout: 8))
    }

    /// Device-like token stream (a few characters at a time, Markdown list)
    /// in a new chat. The reply stays shorter than the screen for seconds, so
    /// the rows must never move down; on device they dropped to a bottom-
    /// aligned position mid-reply and crept back up.
    @MainActor func testTokenStreamFirstReplyNeverMovesDown() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--token-stream"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["テスト"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.5)
        var positions: [CGFloat] = []
        let start = Date()
        while Date().timeIntervalSince(start) < 9 {
            if sent.exists { positions.append(sent.frame.minY) }
        }
        let down = zip(positions, positions.dropFirst()).map { $1 - $0 }.max() ?? 0
        XCTAssertLessThanOrEqual(down, 3, "Rows moved down while the reply streamed: \(positions)")
    }

    /// New chat, first reply growing past one screen: following the reply may
    /// move the rows up, but they must never move back down. On device they
    /// alternated between a top- and a bottom-aligned position every chunk.
    @MainActor func testGrowingFirstReplyNeverMovesBackDown() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--growing-reply"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["テスト"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        var positions: [CGFloat] = []
        for _ in 0..<30 {
            if sent.exists { positions.append(sent.frame.minY) }
            Thread.sleep(forTimeInterval: 0.1)
        }
        let backDown = zip(positions, positions.dropFirst()).map { $1 - $0 }.max() ?? 0
        XCTAssertLessThanOrEqual(backDown, 3, "Rows moved back down while the reply grew: \(positions)")
    }

    /// New chat, first reply: while a short reply streams in, the rows must
    /// stay where they are. On device they jumped between a top- and a
    /// bottom-aligned position with every streamed chunk.
    @MainActor func testFirstReplyInNewChatDoesNotJump() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--slow-reply"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        XCTAssertTrue(modelName.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)   // keyboard closed, reply about to start
        var positions: [CGFloat] = []
        for _ in 0..<20 {
            positions.append(modelName.frame.minY)
            Thread.sleep(forTimeInterval: 0.15)
        }
        let spread = (positions.max() ?? 0) - (positions.min() ?? 0)
        XCTAssertLessThanOrEqual(spread, 3, "Rows moved while the first reply streamed: \(positions)")
    }

    /// The Aurora Orb holds the reply's place while the model works: it
    /// shows as soon as the message is sent, keeps its mist moving, stays
    /// while the reply holds only a line break, and gives way to the first
    /// text on its line without moving the rows.
    @MainActor func testAuroraOrbWaitsForFirstVisibleText() {
        auroraOrb("light", arguments: ["--orb-wait"])
    }

    @MainActor func testAuroraOrbInDarkMode() {
        auroraOrb("dark", arguments: ["--orb-wait", "--dark"])
    }

    /// With Reduce Motion the orb holds one still frame.
    @MainActor func testAuroraOrbHoldsStillWithReduceMotion() {
        auroraOrb("still", arguments: ["--orb-wait", "--reduce-motion"])
    }

    /// A short reply that ends while the Aurora Orb is still leaving (the
    /// preview's reply ends 0.52 s after its first text, the orb leaves
    /// over 0.7 s), or with its first text (--instant-reply), never says
    /// 停止しました in its place: the orb leaves to the end and the text
    /// follows. On the phone a reply that ended 0.1 s after its first text
    /// said 停止しました until its text showed (2026-10-25). A reply stopped
    /// before any text still says it. The row notes each time it says so
    /// (--reply-trace; ORB reply-end lines), frames of the reply's line
    /// from the send as orb-reply-end-strip-*.
    @MainActor func testShortReplyNeverSaysStoppedBeforeItsText() {
        continueAfterFailure = false
        func trace(_ app: XCUIApplication) -> String {
            let element = app.descendants(matching: .any).matching(identifier: "reply-placeholder-trace").firstMatch
            return element.exists ? element.label : "missing"
        }
        for (variant, extra, words) in [("ends-while-orb-leaves", [String](), "スクロールを確認できます"),
                                        ("ends-with-first-text", ["--instant-reply"], "すぐに書き終えた返信です")] {
            let app = PreviewApp(); app.launchArguments = ["--reply-trace"] + extra; app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
            let input = app.textViews["chat-input"]
            XCTAssertTrue(input.waitForExistence(timeout: 5))
            input.tap(); input.typeText("短い返信")
            let tapped = Date()
            app.buttons["送信する"].tap()
            let sent = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "短い返信")).firstMatch
            XCTAssertTrue(sent.waitForExistence(timeout: 3))
            // The reply's first line, under the sent bubble.
            let width = app.frame.width
            let band = CGRect(x: 0, y: sent.frame.maxY, width: width, height: 80)
            var frames: [(t: Double, image: UIImage)] = []
            // The first text comes 0.9 s after the send; screenshots as
            // quick as they come until the text has long shown.
            while Date().timeIntervalSince(tapped) < 3.4 {
                let t = Date().timeIntervalSince(tapped)
                let shot = XCUIScreen.main.screenshot().image
                if t >= 0.7, frames.count < 20, let crop = bandCrop(shot, band, screenWidth: width) {
                    frames.append((t, crop))
                }
            }
            let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", words)).firstMatch
            XCTAssertTrue(reply.waitForExistence(timeout: 5), "The reply's text shows")
            let notes = trace(app)
            print("ORB reply-end \(variant) placeholder=\(notes) frames=\(frames.count)")
            if !frames.isEmpty { attachOrbStrip("orb-reply-end-strip-\(variant)", frames: frames) }
            capture("orb-reply-end-\(variant)", app: app)
            XCTAssertEqual(notes, "none", "\(variant): the reply's place said it ended with no text")
            app.terminate()
        }
        // Stopped while the orb waits (--orb-wait: 9 s): it says so.
        let app = PreviewApp(); app.launchArguments = ["--reply-trace", "--orb-wait"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("止める")
        app.buttons["送信する"].tap()
        let stop = app.buttons["停止する"]
        XCTAssertTrue(stop.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.5)
        stop.tap()
        XCTAssertTrue(app.staticTexts["停止しました"].waitForExistence(timeout: 5))
        let notes = trace(app)
        print("ORB reply-end stopped-before-text placeholder=\(notes)")
        capture("orb-reply-end-stopped-before-text", app: app)
        XCTAssertEqual(notes, "stopped 0")
    }

    /// A screenshot's band across the screen (points), at half its pixels.
    private func bandCrop(_ shot: UIImage, _ band: CGRect, screenWidth: CGFloat) -> UIImage? {
        guard let image = shot.cgImage, screenWidth > 0 else { return nil }
        let scale = CGFloat(image.width) / screenWidth
        let rect = CGRect(x: band.minX * scale, y: band.minY * scale,
                          width: band.width * scale, height: band.height * scale).integral
        guard let crop = image.cropping(to: rect) else { return nil }
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let size = CGSize(width: crop.width / 2, height: crop.height / 2)
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            UIImage(cgImage: crop).draw(in: CGRect(origin: .zero, size: size))
        }
    }

    /// From send to first text (preview --orb-wait: a line break 9 s after
    /// the send, the text 0.3 s later), measured from screenshots. The orb
    /// breathes between 24pt and 12pt, shrinks away over 0.7 s from the
    /// line break, and the text waits until it has gone. Element queries
    /// wait for the app to settle and ran out the wait while the orb drew
    /// (1.0.82 CI), so only one is made while it shows.
    @MainActor private func auroraOrb(_ variant: String, arguments: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = arguments; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("オーロラ")
        // Under the header and above the composer, the orb is the only
        // colour on the left and the sent bubble the only blue on the right.
        let screen = app.frame.size
        let top = max(app.buttons["会話一覧を開く"].frame.maxY, app.buttons["chat-model-settings"].frame.maxY) + 8
        let left = CGRect(x: 0, y: top, width: 200, height: screen.height - 130 - top)
        let right = CGRect(x: screen.width / 2, y: top, width: screen.width / 2, height: left.height)
        let orb = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "返信を書いています")).firstMatch
        let tapped = Date()
        app.buttons["送信する"].tap()
        let sent = Date().timeIntervalSince(tapped)

        var readings: [OrbReading] = []
        var foundLine: (centre: CGPoint, bounds: CGRect, background: Int)?   // the orb settled on its line
        var recent: [(t: Double, area: ScreenArea)] = []
        var changes: [Double] = []
        var strip: [(t: Double, image: UIImage)] = []
        var waitShot: UIImage?, textShot: UIImage?
        var labelled: Bool?, labelSeconds = 0.0
        var foundText: Double?, textY = CGFloat.nan
        while Date().timeIntervalSince(tapped) < 30 {
            let t = Date().timeIntervalSince(tapped)
            let shot = XCUIScreen.main.screenshot().image
            guard let image = shot.cgImage, let area = ScreenArea(image, left, screenWidth: screen.width),
                  let side = ScreenArea(image, right, screenWidth: screen.width) else {
                XCTFail("Could not read a screenshot"); return
            }
            let colour = area.colour()
            if foundLine == nil, t >= sent + 0.8, colour.count >= 250 {
                let blank = CGRect(x: colour.bounds.maxX + 8, y: colour.centre.y - 9,
                                   width: 192 - colour.bounds.maxX, height: 18)
                foundLine = (colour.centre, colour.bounds, area.meanLuma(in: blank))
            }
            var ink = 0.0
            if let line = foundLine {
                // Right of the orb on its line: blank until the text comes.
                let band = CGRect(x: line.bounds.maxX + 8, y: line.centre.y - 9,
                                  width: 192 - line.bounds.maxX, height: 18)
                ink = area.ink(in: band, background: line.background).share
                if foundText == nil, ink > 0.02 { foundText = t }
                if foundText == nil, colour.count >= 60 {
                    // How much the mist changed over about a second. Shots
                    // can come 1 s apart while the simulator is busy (the
                    // dark run of 1.0.86 made 13 in 13 s), so pairs may be
                    // up to 2.5 s apart.
                    if let earlier = recent.last(where: { t - $0.t >= 0.8 }), t - earlier.t <= 2.5 {
                        changes.append(area.change(from: earlier.area, in: line.bounds.insetBy(dx: -4, dy: -4)))
                    }
                    recent.append((t, area))
                    recent.removeAll { t - $0.t > 2.5 }
                    if strip.count < 8, t - (strip.last?.t ?? 0) >= 1,
                       let crop = orbCrop(shot, around: line.centre, side: 64, screenWidth: screen.width) {
                        strip.append((t, crop))
                    }
                    if waitShot == nil, t >= sent + 2 { waitShot = shot }
                }
            }
            readings.append(OrbReading(t: t, colour: colour.count, ink: ink, bubble: side.blueTop()))
            if labelled == nil, foundLine != nil, foundText == nil, t >= sent + 1.5 {
                let start = Date()
                labelled = orb.exists
                labelSeconds = Date().timeIntervalSince(start)
            }
            if let line = foundLine, let textAt = foundText, textShot == nil, t >= textAt + 1.2 {
                textShot = shot
                let row = CGRect(x: line.bounds.minX - 4, y: line.centre.y - 16, width: 200 - line.bounds.minX, height: 32)
                textY = area.ink(in: row, background: line.background).centreY
            }
            if let textAt = foundText, t >= textAt + 2 { break }
        }

        if !strip.isEmpty { attachOrbStrip("orb-strip-\(variant)", frames: strip) }
        for (name, image) in [("wait", waitShot), ("text", textShot)] {
            guard let image else { continue }
            let attachment = XCTAttachment(image: image)
            attachment.name = "orb-\(variant)-\(name)"
            attachment.lifetime = .keepAlways
            add(attachment)
        }
        let gaps = zip(readings.dropFirst(), readings).map { later, earlier in later.t - earlier.t }
        let every = gaps.isEmpty ? 0 : gaps.reduce(0, +) / Double(gaps.count)
        let label = labelled.map { $0 ? "yes" : "no" } ?? "-"
        print(String(format: "ORB %@ tap=%.2f text=%.2f shots=%ld every=%.2f label=%@ in %.2f",
                     variant, sent, foundText ?? -1, readings.count, every, label, labelSeconds))
        var timeline: [String] = []
        for reading in readings {
            let bubble = reading.bubble.map { String(format: "%.0f", Double($0)) } ?? "-"
            timeline.append(String(format: "%.1f:%ld/%.2f/", reading.t, reading.colour, reading.ink) + bubble)
        }
        print("ORB \(variant) timeline (s:colour/ink/bubble) " + timeline.joined(separator: " "))
        let sortedChanges = changes.sorted()
        let median = sortedChanges.isEmpty ? -1 : sortedChanges[sortedChanges.count / 2]
        print(String(format: "ORB %@ change min=%.2f median=%.2f max=%.2f orbY=%.1f textY=%.1f", variant,
                     sortedChanges.first ?? -1, median, sortedChanges.last ?? -1,
                     Double(foundLine?.centre.y ?? -1), Double(textY)))
        print("ORB \(variant) orb bounds \(String(describing: foundLine?.bounds))")

        // The sent bubble flies up from the composer, and the orb shows
        // with it as it lands.
        guard let landed = readings.last?.bubble,
              let arrival = readings.first(where: { $0.bubble.map { abs($0 - landed) <= 2 } ?? false }) else {
            XCTFail("The sent message never showed"); return
        }
        XCTAssertLessThanOrEqual(arrival.t - sent, 2, "The sent message must show at once")
        guard let line = foundLine, let textAt = foundText else { XCTFail("The reply's text never showed"); return }
        // The orb shows from then until the first token, down to a 12pt
        // light (about 110 points² of colour) at the bottom of its breath.
        // It then shrinks away over 0.7 s, the text is laid out at a pace
        // and each character clears in 0.22 s, so its ink reads 0.1-0.5 s
        // after the orb has gone, and shots come every 0.3-1 s (the light
        // run of 1.0.88 had a 0.9 s gap just there), so the last 1.6 s
        // before the text reads is left out.
        let waiting = readings.filter { $0.t >= arrival.t + 0.3 && $0.t < textAt - 1.6 }
        let missing = waiting.filter { $0.colour < 60 }.map(\.t)
        XCTAssertTrue(missing.isEmpty, "The orb must show from the send until the first token; it was missing at \(missing) s")
        // The text waits until the orb has gone, so no shot has both.
        let both = readings.filter { $0.ink > 0.02 && $0.colour >= 60 }.map(\.t)
        XCTAssertTrue(both.isEmpty, "The text must wait until the orb has gone; both showed at \(both) s")
        let after = readings.filter { $0.t >= textAt + 0.6 }
        XCTAssertFalse(after.isEmpty)
        XCTAssertLessThanOrEqual(after.map(\.colour).max() ?? 0, 10, "No colour of the orb may stay behind the text")
        XCTAssertGreaterThanOrEqual(changes.count, 3, "Too few shots of the orb to measure its motion")
        if variant == "still" {
            XCTAssertLessThan(sortedChanges.last ?? 0, 0.3, "With Reduce Motion the orb holds still")
        } else {
            XCTAssertGreaterThan(sortedChanges.first ?? 0, 1, "The orb's mist must keep moving")
        }
        XCTAssertLessThanOrEqual(abs(textY - line.centre.y), 4, "The text must take the orb's line")
        let tops = readings.filter { $0.t >= arrival.t }.compactMap(\.bubble)
        XCTAssertGreaterThan(tops.count, readings.count / 2, "The sent bubble must stay in view")
        XCTAssertLessThanOrEqual((tops.max() ?? 0) - (tops.min() ?? 0), 2, "Rows moved while the orb gave way")
        XCTAssertEqual(labelled, true, "VoiceOver must read the orb as the reply being written")
        XCTAssertFalse(orb.exists, "Nothing of the orb may stay for VoiceOver once the text shows")
        let reply = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "こんにちは")).firstMatch
        XCTAssertTrue(reply.waitForExistence(timeout: 3))
        app.terminate()
    }

    /// Recording-oriented: send with the keyboard open, twice, in a long
    /// chat. Pauses isolate each send in interaction.mp4 for frame review of
    /// the keyboard dismissal, the follow-to-bottom scroll and the new bubble.
    @MainActor func testSendWithKeyboardOpenMotion() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--long-chat"]; app.launch()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        for text in ["送信の動きを確認します", "もう一度送信します"] {
            input.tap(); input.typeText(text)
            Thread.sleep(forTimeInterval: 0.8)
            app.buttons["送信する"].tap()
            Thread.sleep(forTimeInterval: 2.5)
            capture("after-send", app: app)
            XCTAssertTrue(app.staticTexts[text].exists || app.otherElements[text].exists
                          || app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch.exists)
        }
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists, "Sending must leave the latest message in view")
    }

    /// A send while a video plays in Picture in Picture (on the phone,
    /// another app's PiP left the lower half black and unanswering after a
    /// send, 2026-10-25), and 送信直後の画面の記録 (1.1.0 (184)): whole-screen
    /// shots after each send (SHOT pip-*), whether a tap on the field still
    /// brings the keyboard (PIP-SEND lines), and the record read back in
    /// 開発者設定 after a relaunch, so a blocked screen cannot hide it
    /// (SEND-LOG lines).
    @MainActor func testSendWithPictureInPictureAndTheSendRecord() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--pip-video"]; app.launch()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        let state = app.staticTexts["pip-state"]
        XCTAssertTrue(state.waitForExistence(timeout: 10))
        let ready = NSPredicate(format: "label == %@ OR label BEGINSWITH %@ OR label BEGINSWITH %@", "開始できる", "失敗", "PiP非対応")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: ready, object: state)], timeout: 20)
        print("PIP-SEND before start: \(state.label)")
        if state.label == "開始できる" {
            app.buttons["pip-start"].tap()
            let shown = NSPredicate(format: "label == %@ OR label BEGINSWITH %@", "表示中", "開始失敗")
            _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: shown, object: state)], timeout: 10)
        }
        print("PIP-SEND after start: \(state.label)")
        Thread.sleep(forTimeInterval: 1.5)
        captureScreen("pip-before-send")
        var answered: [Bool] = []
        for round in 1...2 {
            input.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
            input.typeText("ピクチャ・イン・ピクチャ中の送信\(round)")
            Thread.sleep(forTimeInterval: 0.8)
            captureScreen("pip-keyboard-\(round)")
            app.buttons["送信する"].tap()
            Thread.sleep(forTimeInterval: 0.6)
            captureScreen("pip-after-send-\(round)-a")
            Thread.sleep(forTimeInterval: 2.4)
            captureScreen("pip-after-send-\(round)-b")
            // The lower half still takes a tap: the field brings the keyboard back.
            input.tap()
            let up = app.keyboards.firstMatch.waitForExistence(timeout: 4)
            answered.append(up)
            print("PIP-SEND round \(round): keyboard after tapping the field \(up) · pip \(state.label)")
            captureScreen("pip-tap-after-send-\(round)")
            if round == 1 { Thread.sleep(forTimeInterval: 11) }
        }
        Thread.sleep(forTimeInterval: 11)
        app.terminate(); app.launchArguments = ["--developer-unlocked"]; app.launch()
        turnOnDeveloperSettings(app)
        let runAll = app.buttons["developer-diagnostics-run"]
        revealModelControl(runAll, in: "developer-list", app: app)
        runAll.tap()
        let log = app.staticTexts["send-screen-log"]
        XCTAssertTrue(log.waitForExistence(timeout: 6))
        for line in log.label.split(separator: "\n") { print("SEND-LOG \(line)") }
        XCTAssertTrue(log.label.contains("送信 2"), "Both sends are recorded")
        XCTAssertTrue(log.label.contains("まとめ:"))
        XCTAssertTrue(log.label.contains("ウィンドウ:"))
        XCTAssertEqual(answered, [true, true], "After each send a tap on the field brings the keyboard")
    }

    /// The whole screen, iOS's windows included (a PiP window, the keyboard).
    @MainActor private func captureScreen(_ name: String) {
        let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    /// Recording-oriented check of the plus menu (a native Menu, so iOS
    /// owns the morph). Pauses isolate each open and close in interaction.mp4.
    @MainActor func testPlusMenuGlassMorphOpenCloseAndInterruption() {
        continueAfterFailure = false
        for arguments in [["--e2b"], ["--e2b", "--dark"]] {
            let app = PreviewApp(); app.launchArguments = arguments; app.launch()
            let plus = app.buttons["chat-add-menu"]
            XCTAssertTrue(plus.waitForExistence(timeout: 10))
            let restingFrame = plus.frame
            Thread.sleep(forTimeInterval: 1.0)
            for _ in 0..<2 {
                plus.tap()
                let photos = menuItem("chat-attach-photos", "写真", app)
                XCTAssertTrue(photos.waitForExistence(timeout: 3))
                Thread.sleep(forTimeInterval: 1.2)
                capture("plus-menu-open\(arguments.contains("--dark") ? "-dark" : "")", app: app)
                dismissMenu(photos, app: app)
                Thread.sleep(forTimeInterval: 1.2)
            }
            // Open and dismiss immediately: the system reverses mid-flight.
            plus.tap()
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
            Thread.sleep(forTimeInterval: 1.2)
            XCTAssertFalse(menuItem("chat-attach-photos", "写真", app).exists)
            XCTAssertEqual(plus.frame.minX, restingFrame.minX, accuracy: 1)
            XCTAssertEqual(plus.frame.minY, restingFrame.minY, accuracy: 1)
            XCTAssertTrue(plus.isHittable)
            XCTAssertTrue(app.textViews["chat-input"].isHittable)
        }
    }

    @MainActor private func chooseMenuAction(_ name: String, app: XCUIApplication) {
        let button = menuItem(name, name, app)
        // A long menu (the attachment fixtures) builds its lower rows only
        // once scrolled to, so a missing row is looked for further down.
        if !button.waitForExistence(timeout: 3) {
            XCTAssertTrue(app.collectionViews.firstMatch.exists, "The menu is open")
        }
        for _ in 0..<6 {
            if button.exists && button.isHittable { break }
            app.collectionViews.firstMatch.swipeUp()
        }
        XCTAssertTrue(button.isHittable, "\(name) is in the menu"); button.tap()
    }

    /// System menu rows may expose either the identifier or only the title
    /// (possibly followed by the "調整中" subtitle) to XCUITest.
    @MainActor private func menuItem(_ id: String, _ title: String, _ app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                         id, title, title + ",")).firstMatch
    }

    /// The model menu by series (1.1.0 (269), fielua-reports Issue #7): the
    /// pill's menu lists Gemma, Qwen, LFM and Phi, each a submenu; a
    /// model's item is there once its series is opened.
    @MainActor private func openModelSeries(_ key: String, _ title: String, _ app: XCUIApplication,
                                            file: StaticString = #filePath, line: UInt = #line) {
        let series = menuItem("model-menu-\(key)", title, app)
        XCTAssertTrue(series.waitForExistence(timeout: 3), "the \(title) series", file: file, line: line)
        series.tap()
    }

    /// モデルを選ぶ by series (1.1.0 (269)): a model's row is there only
    /// while its series is open. Opens it, unless it is open already.
    @MainActor private func openOnboardingSeries(_ key: String, _ app: XCUIApplication,
                                                 file: StaticString = #filePath, line: UInt = #line) {
        let series = app.buttons["onboarding-family-\(key)"]
        XCTAssertTrue(series.waitForExistence(timeout: 5), "the \(key) series", file: file, line: line)
        guard !isOpenSeries(series) else { return }
        series.tap()
        XCTAssertTrue(isOpenSeries(series), "\(key) opens: \(series.value ?? "")", file: file, line: line)
    }

    /// A series row says whether it is open in its value, after its line.
    @MainActor private func isOpenSeries(_ series: XCUIElement) -> Bool {
        let value = series.value as? String ?? ""
        return value.hasSuffix("開いています") || value.hasSuffix("Expanded")
    }

    @MainActor private func isLocked(_ item: XCUIElement) -> Bool {
        (item.value as? String) == "現在調整中" || item.label.contains("調整中")
    }

    /// Tap outside the menu, on the conversation, and wait for it to close.
    @MainActor private func dismissMenu(_ item: XCUIElement, app: XCUIApplication) {
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        let gone = NSPredicate(format: "exists == false")
        let wait = XCTNSPredicateExpectation(predicate: gone, object: item)
        XCTAssertEqual(XCTWaiter().wait(for: [wait], timeout: 3), .completed, "menu should close")
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
    }

    /// The header's model mark opens the current model's settings.
    @MainActor private func openConfiguration(_ app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.textFields["setting-Max Tokens"].waitForExistence(timeout: 3))
    }

    /// モバイル通信でもダウンロード (0.0.1 (132)): on cellular only, a
    /// download at 0% says it waits for Wi-Fi and points to the switch;
    /// turning it on starts it again, and a relaunch (dark) keeps the choice.
    /// Here モデル管理 comes from the model menu's モデルを管理.
    @MainActor func testCellularDownloadSwitchStartsAWaitingDownload() {
        cellularDownloadSwitch(tag: "") { self.openModelList($0) }
    }

    /// The same from 設定 › モデル管理, opened from the history (1.1.0 (224)).
    @MainActor func testCellularDownloadSwitchFromSettings() {
        cellularDownloadSwitch(tag: "-settings") {
            self.openSettingsFromHistory($0)
            self.openSettingsRow("models", title: "モデル管理", app: $0)
        }
    }

    @MainActor private func cellularDownloadSwitch(tag: String, open: (XCUIApplication) -> Void) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--cellular-only", "--download-waits"]; app.launch()
        open(app)
        let wait = app.descendants(matching: .any).matching(identifier: "model-download-wait-gemma-4-e2b").firstMatch
        revealModelControl(wait, app: app)
        print("CELLULAR\(tag) wait hint: \(wait.label)")
        XCTAssertTrue(wait.label.contains("「モバイル通信でもダウンロード」をオン"))
        XCTAssertTrue(app.staticTexts["Gemma 4 E2BはWi-Fiを待っています · 0%"].exists)
        capture("cellular-download-waiting\(tag)", app: app)
        let toggle = app.switches["model-download-cellular-toggle"]
        revealModelControl(toggle, app: app)
        XCTAssertEqual(toggle.value as? String, "0", "off until turned on")
        capture("cellular-download-switch-off\(tag)", app: app)
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        XCTAssertFalse(wait.exists, "the download starts again with cellular")
        XCTAssertTrue(app.staticTexts["Gemma 4 E2Bをダウンロード中 · 0%"].exists)
        capture("cellular-download-switch-on\(tag)", app: app)
        app.terminate(); app.launchArguments = ["--cellular-only", "--dark"]; app.launch()
        open(app)
        revealModelControl(toggle, app: app)
        XCTAssertEqual(toggle.value as? String, "1", "the choice is kept")
        print("CELLULAR\(tag) dark before tap: \(toggle.frame) hittable=\(toggle.isHittable)")
        capture("cellular-download-switch-on-dark\(tag)", app: app)
        let tapped = Date()
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        let off = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value == %@", "0"), object: toggle)
        let result = XCTWaiter().wait(for: [off], timeout: 8)
        print("CELLULAR\(tag) dark after tap: \(result.rawValue) in \(String(format: "%.1f", Date().timeIntervalSince(tapped))) s value=\(String(describing: toggle.value)) frame=\(toggle.frame)")
        capture("cellular-download-switch-off-dark\(tag)", app: app)
        XCTAssertEqual(toggle.value as? String, "0")
    }

    /// The first launch on cellular only offers the same switch for the
    /// chosen model, and only while it is not saved.
    @MainActor func testFirstLaunchOnCellularOffersTheSwitch() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--cellular-only", "--download-waits"]
        app.launch()
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10)); welcome.tap()
        openOnboardingSeries("gemma", app)
        let choice = app.buttons["onboarding-model-gemma-4-e2b"]
        XCTAssertTrue(choice.waitForExistence(timeout: 5))
        choice.tap()
        let toggle = app.switches["onboarding-download-cellular-toggle"]
        let list = app.scrollViews["onboarding-model-list"]
        for _ in 0..<5 {
            if toggle.exists && toggle.isHittable && toggle.frame.maxY < app.buttons["onboarding-model-continue"].frame.minY { break }
            list.swipeUp()
        }
        XCTAssertTrue(toggle.isHittable)
        XCTAssertEqual(toggle.value as? String, "0")
        capture("cellular-download-first-launch", app: app)
        let saved = app.buttons["onboarding-model-gemma-4-e4b"]
        for _ in 0..<5 { if saved.exists && saved.isHittable { break }; list.swipeDown() }
        saved.tap()
        XCTAssertFalse(toggle.exists, "a saved model needs no download")
    }

    /// 設定 (2026-10-23, 設定画面UIリニューアル): from the history's gear, a
    /// glass sheet with 「Fielua」 large at the top and the six rows in order;
    /// each opens its page in the sheet and goes back (PCと接続 too since
    /// 1.1.0 (253), locked before), and a swipe down closes the sheet. Screenshots as SHOT settings-new-*,
    /// the title's and the close button's frames as SETTINGS-TOUR lines.
    @MainActor func testSettingsSheetRowsLight() { settingsSheet("light", arguments: ["--reset-settings"]) }
    @MainActor func testSettingsSheetRowsDark() { settingsSheet("dark", arguments: ["--reset-settings", "--dark"]) }
    /// The same sheet at full height, to compare its background.
    @MainActor func testSettingsSheetFullHeightProbe() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--settings-large"]; app.launch()
        openSettingsFromHistory(app)
        Thread.sleep(forTimeInterval: 0.8)
        capture("settings-new-large-home", app: app)
        openSettingsRow("models", title: "モデル管理", app: app)
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-new-large-models", app: app)
    }

    @MainActor private func settingsSheet(_ name: String, arguments: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = arguments; app.launch()
        let title = openSettingsFromHistory(app)
        Thread.sleep(forTimeInterval: 0.8)
        // ウェブ検索 second since 1.1.0 (230).
        // Claude after PCと接続 since 1.1.0 (257).
        let ids = ["models", "webSearch", "keyboard", "notifications", "pc", "claude", "about", "licenses"]
        let rows = ids.map { app.buttons["settings-row-\($0)"] }
        for (row, next) in zip(rows, rows.dropFirst()) {
            XCTAssertLessThan(row.frame.midY, next.frame.midY, "The rows in their order")
        }
        XCTAssertFalse(app.buttons["settings-row-developer"].exists, "開発者設定 stays hidden until revealed")
        let close = app.buttons["settings-close"]
        print("SETTINGS-TOUR \(name) home title=\(title.frame) close=\(close.frame) rows=\(rows.map { $0.frame })")
        capture("settings-new-\(name)-home", app: app)
        let pc = rows[4]
        print("SETTINGS-TOUR \(name) pc label=\(pc.label) value=\(String(describing: pc.value)) enabled=\(pc.isEnabled)")
        XCTAssertTrue(pc.isEnabled, "PCと接続 opens its page (1.1.0 (253))")
        for (id, page) in [("models", "モデル管理"), ("webSearch", "ウェブ検索"), ("keyboard", "キーボードと入力"),
                           ("notifications", "通知"), ("pc", "PCと接続"), ("claude", "Claude"), ("about", "Fieluaの情報"),
                           ("licenses", "オープンソースライセンス")] {
            openSettingsRow(id, title: page, app: app)
            Thread.sleep(forTimeInterval: 0.6)
            capture("settings-new-\(name)-\(id)", app: app)
            let bar = app.navigationBars[page]
            let back = bar.buttons.matching(NSPredicate(format: "identifier != %@", "settings-close")).firstMatch
            XCTAssertTrue(back.exists, "\(page) goes back")
            back.tap()
            XCTAssertTrue(gone(bar))
            XCTAssertTrue(rows[0].waitForExistence(timeout: 3))
        }
        // Pulled down from its top, the sheet closes.
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
        start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: 560)),
                    withVelocity: .fast, thenHoldForDuration: 0)
        XCTAssertTrue(gone(rows[0], timeout: 4), "A swipe down closes the sheet")
        XCTAssertTrue(historySidebar(app).exists)
    }

    /// The device check of 1.1.0 (147): on iOS 27 a page opened opaque white
    /// and the sheet darkened while it came and went. Pages now slide over
    /// the sheet's one glass. Frames of a page coming, going back with the
    /// button and going back with a swipe are cut from the session
    /// recording (MENU-MARK settings-*), and a scrolled page and the rows
    /// with the title in the bar show the blur under it (SHOT settings-blur-*).
    @MainActor func testSettingsPagesSlideLight() { settingsSlide("light", arguments: ["--reset-settings", "--settings-slide-meter"]) }
    @MainActor func testSettingsPagesSlideDark() { settingsSlide("dark", arguments: ["--reset-settings", "--dark", "--settings-slide-meter"]) }

    @MainActor private func settingsSlide(_ name: String, arguments: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = arguments; app.launch()
        openSettingsFromHistory(app)
        Thread.sleep(forTimeInterval: 1)
        let models = app.buttons["settings-row-models"], back = app.buttons["settings-back"]
        XCTAssertFalse(back.exists, "No back button on the rows")
        // How the last slide ran: from the tap to its first move, its frames
        // and its longest gap between two (SettingsSlideMeter).
        func meter(_ slide: String) {
            let reading = app.staticTexts["settings-slide-meter"]
            if reading.waitForExistence(timeout: 2) { print("SLIDE-METER \(name) \(slide): \(reading.label)") }
        }
        func drag(_ list: XCUIElement, _ dy: CGFloat) {
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: dy)),
                        withVelocity: .slow, thenHoldForDuration: 0.4)
            Thread.sleep(forTimeInterval: 1)
        }
        menuMark("settings-push-\(name)"); models.tap()
        XCTAssertTrue(app.navigationBars["モデル管理"].waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 2)
        meter("push models")
        capture("settings-blur-\(name)-models-top", app: app)
        drag(app.scrollViews["model-list"], -260)
        capture("settings-blur-\(name)-models", app: app)
        menuMark("settings-pop-\(name)"); back.tap()
        XCTAssertTrue(gone(app.navigationBars["モデル管理"]))
        XCTAssertTrue(models.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 2)
        meter("pop models")
        let home = app.scrollViews["settings-home"]
        drag(home, -260)
        capture("settings-blur-\(name)-home", app: app)
        drag(home, 110)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        Thread.sleep(forTimeInterval: 1.5)
        meter("push keyboard")
        // A swipe to the right goes back, the page following the finger.
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.12, dy: 0.62))
        menuMark("settings-swipe-\(name)")
        start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: app.frame.width * 0.6, dy: 0)),
                    withVelocity: .slow, thenHoldForDuration: 0.2)
        XCTAssertTrue(gone(app.navigationBars["キーボードと入力"]), "A swipe to the right goes back")
        XCTAssertTrue(models.waitForExistence(timeout: 3))
        XCTAssertFalse(back.exists)
        Thread.sleep(forTimeInterval: 1)
        meter("swipe keyboard")
    }

    /// The back button comes in with a page and goes as back is pressed on
    /// the bar's own animation, not at once (1.1.0 (156) on the phone).
    /// Slowed pages, opened and closed by the app itself so no tap waits
    /// for the motion; the button's place is photographed throughout and
    /// how blue and how bright it is printed as SETTINGS-PERF lines.
    @MainActor func testSettingsBackButtonComesAndGoesWithThePage() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--settings-slow-pages", "--settings-back-demo"]; app.launch()
        openSettingsFromHistory(app)
        // Where the back button stands: the close button's place, mirrored.
        let close = app.buttons["settings-close"].frame, width = app.frame.width
        let place = CGRect(x: width - close.maxX, y: close.minY, width: close.width, height: close.height)
        let started = Date()
        var lines: [String] = [], blues: [Double] = []
        func sample(until seconds: TimeInterval) {
            while Date().timeIntervalSince(started) < seconds {
                let time = Date().timeIntervalSince(started)
                guard let image = XCUIScreen.main.screenshot().image.cgImage else { continue }
                let scale = CGFloat(image.width) / width
                let crop = CGRect(x: place.minX * scale, y: place.minY * scale,
                                  width: place.width * scale, height: place.height * scale).integral
                guard let part = image.cropping(to: crop),
                      let context = CGContext(data: nil, width: 8, height: 8, bitsPerComponent: 8, bytesPerRow: 32,
                                              space: CGColorSpaceCreateDeviceRGB(),
                                              bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { continue }
                context.interpolationQuality = .medium
                context.draw(part, in: CGRect(x: 0, y: 0, width: 8, height: 8))
                guard let data = context.data?.assumingMemoryBound(to: UInt8.self) else { continue }
                var red = 0.0, green = 0.0, blue = 0.0
                for pixel in 0..<64 {
                    red += Double(data[pixel * 4]); green += Double(data[pixel * 4 + 1]); blue += Double(data[pixel * 4 + 2])
                }
                blues.append((blue - red) / 64)
                lines.append(String(format: "%.2fs 青 %.0f 明るさ %.0f", time, (blue - red) / 64,
                                    (0.3 * red + 0.59 * green + 0.11 * blue) / 64))
            }
        }
        // The page comes in about 5 s after the sheet opens and goes back
        // at about 11 s, each over about 3 s. Nothing is asked of the app
        // meanwhile: a query waits for its animations to end (run
        // 40048313091 asked at 6.5 s and found the page already going).
        sample(until: 17)
        for line in lines { print("SETTINGS-PERF 戻るボタン \(line)") }
        let before = blues.prefix(3).min() ?? 0
        XCTAssertGreaterThan((blues.max() ?? 0) - before, 3, "The blue chevron came")
        XCTAssertLessThan(abs((blues.last ?? 0) - before), 3, "and went")
        XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.buttons["settings-back"].exists, "No back button on the rows")
    }

    /// 開発者設定's 「ページ移動を計測」 as on the phone (SettingsSlideMeter):
    /// tapped on its card, each page in and back out twice for each way of
    /// sliding, then back on 開発者設定 with the table. Nothing is asked of
    /// the app while it runs, so the main thread's numbers are the app's
    /// own; the table is printed as SETTINGS-PERF lines and photographed.
    @MainActor func testSettingsPageSlidesMeasured() {
        continueAfterFailure = false
        // Past the usual two minutes (the scope raises the cap to match).
        executionTimeAllowance = 300
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--developer-unlocked", "--settings-perf"]; app.launch()
        openSettingsFromHistory(app)
        openSettingsRow("developer", title: "開発者設定", app: app)
        let measure = app.buttons["developer-slide-measure"]
        XCTAssertTrue(measure.waitForExistence(timeout: 3))
        for _ in 0..<6 { if measure.isHittable { break }; app.swipeUp() }
        measure.tap()
        // About two and a half minutes in the simulator; asking earlier
        // would put the test's own queries on the app's main thread.
        Thread.sleep(forTimeInterval: 140)
        let state = app.descendants(matching: .any).matching(identifier: "settings-nav-state").firstMatch
        for _ in 0..<20 {
            if state.exists, state.label != "計測中" { break }
            Thread.sleep(forTimeInterval: 5)
        }
        // The sheet goes back to 開発者設定 on its own.
        let back = app.navigationBars["開発者設定"].waitForExistence(timeout: 4)
        print("SETTINGS-PERF 計測後 \(state.exists ? state.label : "（表示なし）")")
        let report = app.descendants(matching: .any).matching(identifier: "developer-slide-report").firstMatch
        let text = report.exists ? report.label : ""
        for line in text.split(separator: "\n") { print("SETTINGS-PERF \(line)") }
        capture("settings-perf-report", app: app)
        XCTAssertTrue(back, "The sheet is back on 開発者設定")
        XCTAssertTrue(text.hasPrefix("ページ移動の計測"), "The measurement finished: \(text.prefix(80))")
        // Every page still opens and goes back afterwards.
        app.buttons["settings-back"].tap()
        let keyboard = app.buttons["settings-row-keyboard"]
        XCTAssertTrue(keyboard.waitForExistence(timeout: 4))
        keyboard.tap()
        let opened = app.navigationBars["キーボードと入力"].waitForExistence(timeout: 4)
        print("SETTINGS-PERF 次のタップ後 \(state.exists ? state.label : "（表示なし）")")
        XCTAssertTrue(opened, "A row opens its page after the measurement")
    }

    @discardableResult
    @MainActor private func openSettingsFromHistory(_ app: XCUIApplication) -> XCUIElement {
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["history-settings"].tap()
        let title = app.descendants(matching: .any).matching(identifier: "settings-title").firstMatch
        XCTAssertTrue(title.waitForExistence(timeout: 5))
        return title
    }

    /// The title (「設定」 since 1.1.0 (214), 「Fielua」 before) shrinks into
    /// the bar as the rows scroll up, stays there,
    /// and grows back at the top: the sheet's top band after each small
    /// drag on one image (SHOT settings-title-strip-*), the title's frame as
    /// SETTINGS-TOUR lines. The probe argument keeps the list from settling,
    /// so each step rests where the drag left it.
    @MainActor func testSettingsTitleShrinksIntoTheBar() { settingsTitleStrip("light", arguments: []) }
    @MainActor func testSettingsTitleReducedMotion() { settingsTitleStrip("reduced-dark", arguments: ["--reduce-motion", "--dark"]) }

    @MainActor private func settingsTitleStrip(_ name: String, arguments: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--settings-title-probe"] + arguments; app.launch()
        let title = openSettingsFromHistory(app)
        let home = app.scrollViews["settings-home"]
        Thread.sleep(forTimeInterval: 0.8)
        var shots: [UIImage] = [], labels: [String] = []
        func shoot(_ step: String) {
            Thread.sleep(forTimeInterval: 0.35)
            shots.append(XCUIScreen.main.screenshot().image)
            labels.append("\(step)  y \(Int(title.frame.midY)) h \(Int(title.frame.height))")
            print("SETTINGS-TOUR \(name) \(step) title=\(title.frame) \(title.value as? String ?? "")")
        }
        func drag(_ dy: CGFloat) {
            let start = home.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: dy)),
                        withVelocity: .slow, thenHoldForDuration: 0.4)
        }
        shoot("rest")
        for step in 1...7 { drag(-22); shoot("up\(step)") }
        drag(-120); shoot("further")
        for step in 1...4 { drag(30); shoot("down\(step)") }
        // Not much further: pulled far below its top, the sheet would close.
        drag(90); shoot("top")
        let band = min(home.frame.minY, app.buttons["settings-close"].frame.minY - 10)
        settingsBandSheet("settings-title-strip-\(name)", shots: shots, labels: labels, band: band)
    }

    /// Let go partway and the list settles with the title large or in the
    /// bar, never in between.
    @MainActor func testSettingsTitleSettles() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        let title = openSettingsFromHistory(app)
        let home = app.scrollViews["settings-home"]
        Thread.sleep(forTimeInterval: 0.8)
        func drag(_ dy: CGFloat, hold: TimeInterval = 0) {
            let start = home.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: dy)),
                        withVelocity: .slow, thenHoldForDuration: hold)
            Thread.sleep(forTimeInterval: 1.2)
        }
        let rest = title.frame.midY
        drag(-260, hold: 0.4)
        let docked = title.frame.midY
        print("SETTINGS-TOUR settle rest=\(rest) docked=\(docked) close=\(app.buttons["settings-close"].frame)")
        XCTAssertLessThan(docked, rest - 30, "Scrolled up, the title sits in the bar")
        // Back to the top; pulled much further, the sheet would close.
        drag(110)
        XCTAssertEqual(title.frame.midY, rest, accuracy: 2, "Back at the top, the title is large again")
        for dy in [-24.0, -36.0, -48.0, -60.0] {
            drag(CGFloat(dy))
            let y = title.frame.midY
            print("SETTINGS-TOUR settle after \(dy): title=\(title.frame)")
            XCTAssertTrue(abs(y - rest) < 3 || abs(y - docked) < 3, "Let go at \(dy), the title settles (\(y))")
            drag(110)
        }
    }

    /// The sheet's top band from each screenshot, three to a row, labelled.
    @MainActor private func settingsBandSheet(_ name: String, shots: [UIImage], labels: [String], band top: CGFloat) {
        guard let first = shots.first else { return }
        let size = first.size
        let crop = CGRect(x: 0, y: max(0, top - 8), width: size.width, height: 190)
        let factor: CGFloat = 0.75, label: CGFloat = 16, columns = 3
        let cell = CGSize(width: crop.width * factor, height: crop.height * factor)
        let rows = (shots.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.black.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, shot) in shots.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width, y: CGFloat(index / columns) * (cell.height + label))
                let target = CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height)
                context.cgContext.saveGState()
                context.cgContext.clip(to: target.insetBy(dx: 1, dy: 1))
                shot.draw(in: CGRect(x: target.minX - crop.minX * factor, y: target.minY - crop.minY * factor,
                                     width: size.width * factor, height: size.height * factor))
                context.cgContext.restoreGState()
                (labels[index] as NSString).draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                                                 withAttributes: [.font: UIFont.systemFont(ofSize: 11), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// モデル管理 from top to bottom and the 構成 sheet's two tabs (SHOT
    /// settings-models-*): light, and with the developer settings.
    @MainActor func testSettingsTourLight() { settingsTour("light", arguments: ["--reset-settings"]) }
    @MainActor func testSettingsTourDeveloper() {
        settingsTour("developer", arguments: ["--reset-settings", "--developer-unlocked"], developer: true)
    }

    @MainActor private func settingsTour(_ name: String, arguments: [String], developer: Bool = false) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = arguments; app.launch()
        let list = app.scrollViews["model-list"]
        if developer {
            // 開発者設定 page by page, then モデル管理 with Qwen.
            turnOnDeveloperSettings(app)
            XCTAssertTrue(app.staticTexts["推論の診断"].waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.6)
            capture("settings-developer-page-1", app: app)
            let developerList = app.scrollViews["developer-list"]
            for page in 2...4 {
                developerList.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.85))
                    .press(forDuration: 0.05, thenDragTo: developerList.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.25)),
                           withVelocity: .slow, thenHoldForDuration: 0.4)
                capture("settings-developer-page-\(page)", app: app)
            }
            app.buttons["settings-back"].tap()
            openSettingsRow("models", title: "モデル管理", app: app)
            Thread.sleep(forTimeInterval: 0.6)
            capture("settings-models-\(name)-1", app: app)
        } else {
            openModelList(app)
            let configuration = app.buttons["model-generation-settings"]
            XCTAssertTrue(configuration.waitForExistence(timeout: 3))
            capture("settings-models-\(name)-1", app: app)
            configuration.tap()
            XCTAssertTrue(app.segmentedControls["configuration-tabs"].waitForExistence(timeout: 4))
            capture("settings-models-\(name)-config-model", app: app)
            app.segmentedControls["configuration-tabs"].buttons["システムプロンプト"].tap()
            capture("settings-models-\(name)-config-prompt", app: app)
            app.buttons["キャンセル"].tap()
            XCTAssertTrue(configuration.waitForExistence(timeout: 4))
        }
        // Page by page with a slow drag held at its end, so the list moves
        // by the drag alone and each page overlaps the one before.
        let footer = app.staticTexts[Self.cloudHistoryLine]
        var page = 1
        while page < 12 && footer.frame.maxY > list.frame.maxY - 1 {
            list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.85))
                .press(forDuration: 0.05, thenDragTo: list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.25)),
                       withVelocity: .slow, thenHoldForDuration: 0.4)
            page += 1
            capture("settings-models-\(name)-\(page)", app: app)
        }
        print("SETTINGS-TOUR \(name) pages \(page) list \(list.frame) footer \(footer.frame)")
    }

    /// モデル管理, from the model menu's モデルを管理 (the plus menu has no
    /// 設定 since 1.1.0 (224)). 入力欄のクラシック shows the menu while typing.
    @MainActor private func openModelList(_ app: XCUIApplication) {
        let menu = app.buttons["composer-model"]
        if !menu.waitForExistence(timeout: 10) { app.textViews["chat-input"].tap() }
        XCTAssertTrue(menu.waitForExistence(timeout: 4), "The model menu is there")
        menu.tap()
        chooseMenuAction("model-menu-manage", app: app)
        XCTAssertTrue(app.navigationBars["モデル管理"].waitForExistence(timeout: 5))
    }

    /// 設定 on its rows, from the chat: モデル管理, then back.
    @MainActor private func openSettingsFromChat(_ app: XCUIApplication) {
        openModelList(app)
        app.buttons["settings-back"].tap()
        XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 4), "設定 is on its rows")
    }

    /// 設定 opens on its six rows; a row opens its page in the same sheet.
    @MainActor private func openSettingsRow(_ id: String, title: String, app: XCUIApplication) {
        let row = app.buttons["settings-row-\(id)"]
        XCTAssertTrue(row.waitForExistence(timeout: 5), "設定 is open on its rows")
        row.tap()
        XCTAssertTrue(app.navigationBars[title].waitForExistence(timeout: 4))
    }

    @MainActor private func replace(_ field: XCUIElement, with text: String) {
        field.tap()
        // Place the caret after the last line, including a multi-line editor.
        field.coordinate(withNormalizedOffset: CGVector(dx: 0.95, dy: 0.9)).tap()
        let old = field.value as? String ?? ""
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count) + text)
    }

    @MainActor private func revealConfigurationControl(_ control: XCUIElement, app: XCUIApplication) {
        let form = app.collectionViews["generation-configuration"]
        XCTAssertTrue(form.waitForExistence(timeout: 3))
        // The Form scrolls under the model's name and the tabs, so its
        // visible part starts below them.
        let tabs = app.segmentedControls["configuration-tabs"]
        XCTAssertTrue(tabs.waitForExistence(timeout: 3))
        for _ in 0..<12 {
            let bounds = form.frame
            let top = max(bounds.minY, tabs.frame.maxY)
            let keyboard = app.keyboards.firstMatch
            let bottom = min(bounds.maxY, keyboard.exists ? keyboard.frame.minY : app.frame.maxY) - 16
            if control.exists && control.isHittable && control.frame.minY >= top + 8 && control.frame.maxY <= bottom { return }
            // SwiftUI can report offscreen segmented buttons as hittable. Drag the
            // visible Form gutter above the keyboard instead of swiping the app.
            let height = max(1, bottom - top)
            let origin = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: top - bounds.minY))
            let start = origin.withOffset(CGVector(dx: 0, dy: height * 0.8))
            let end = origin.withOffset(CGVector(dx: 0, dy: height * 0.15))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Configuration control must be fully visible before interaction: \(control.identifier)")
    }

    /// Frames of the jump control's motion, for review without a recording:
    /// rising after a scroll up, and fusing back after a tap. Both the
    /// E2B and E4B layouts are covered; both now sink into the field.
    @MainActor func testJumpControlMotionFrames() {
        continueAfterFailure = false
        for (variant, arguments) in [("e2b", ["--long-chat", "--e2b"]), ("e4b", ["--long-chat"])] {
            let app = PreviewApp()
            app.launchArguments = Self.keepOpen + arguments
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            XCTAssertTrue(reading.waitForExistence(timeout: 3))
            reading.swipeDown()
            captureStrip("jump-strip-\(variant)-rise")
            let jump = app.buttons["chat-jump-latest"]
            XCTAssertTrue(jump.waitForExistence(timeout: 3))
            XCTAssertEqual(jump.frame.midX, app.windows.firstMatch.frame.midX, accuracy: 1)
            jump.tap()
            captureStrip("jump-strip-\(variant)-fuse")
            let hidden = NSPredicate(format: "exists == false")
            expectation(for: hidden, evaluatedWith: jump)
            waitForExpectations(timeout: 4)
            capture("jump-\(variant)-settled", app: app)
            app.terminate()
        }
    }

    // MARK: - Composer: two rows, folded into three buttons (Phase UI-1)

    /// The composer at rest: one glass panel with one line of text right
    /// above the plus and send, and the same with the keyboard up. Each
    /// further line grows the panel by its own height, deleting it shrinks
    /// the panel back, and past six lines the text scrolls inside it.
    @MainActor func testComposerTwoRowsWithAndWithoutKeyboard() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let panel = app.descendants(matching: .any)["chat-composer"]
        let input = app.textViews["chat-input"]
        let send = app.buttons["送信する"]
        func checkRows(_ state: String) {
            let window = app.windows.firstMatch.frame
            print("COMPOSER \(state) panel=\(panel.frame) input=\(input.frame) plus=\(menu.frame) send=\(send.frame)")
            XCTAssertEqual(panel.frame.width, window.width - 24, accuracy: 1, "\(state): the panel spans the screen")
            XCTAssertLessThanOrEqual(input.frame.maxY, menu.frame.minY + 1, "\(state): the text sits above the buttons")
            // The plus's 36pt circle sits in the 44pt row right under the
            // text: no empty row between them.
            XCTAssertLessThanOrEqual(menu.frame.minY - input.frame.maxY, 7, "\(state): no gap above the buttons")
            XCTAssertEqual(menu.frame.midY, send.frame.midY, accuracy: 1, "\(state): plus and send share the lower row")
            XCTAssertLessThan(menu.frame.midX, panel.frame.midX, "\(state): plus on the left")
            XCTAssertGreaterThan(send.frame.midX, panel.frame.midX, "\(state): send on the right")
            XCTAssertGreaterThanOrEqual(menu.frame.minX, panel.frame.minX - 1)
            XCTAssertLessThanOrEqual(send.frame.maxX, panel.frame.maxX + 1)
            XCTAssertLessThanOrEqual(send.frame.maxY, panel.frame.maxY + 1)
        }
        checkRows("rest")
        let rest = panel.frame.height
        XCTAssertEqual(rest, 100, accuracy: 2, "At rest one line of text and the button row")
        XCTAssertEqual(menu.frame.width, 36, accuracy: 1); XCTAssertEqual(menu.frame.height, 36, accuracy: 1)
        capture("composer-rest", app: app)
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        checkRows("keyboard")
        XCTAssertEqual(panel.frame.height, rest, accuracy: 1, "The keyboard adds no height")
        XCTAssertLessThanOrEqual(panel.frame.maxY, app.keyboards.firstMatch.frame.minY, "The panel rides above the keyboard")
        capture("composer-keyboard", app: app)
        input.typeText("1行目")
        XCTAssertEqual(panel.frame.height, rest, accuracy: 1, "One line keeps the panel at rest")
        input.typeText("\n2行目")
        sleep(1)
        let twoLines = panel.frame.height, line = twoLines - rest
        print("COMPOSER line=\(line)")
        XCTAssertGreaterThan(line, 15, "A second line grows the panel")
        XCTAssertLessThan(line, 30, "by one line, not a row of empty space")
        checkRows("two-lines")
        capture("composer-two-lines", app: app)
        input.typeText("\n3行目")
        sleep(1)
        XCTAssertEqual(panel.frame.height, twoLines + line, accuracy: 2, "A third line grows it by one more")
        checkRows("three-lines")
        capture("composer-three-lines", app: app)
        input.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: 4))
        sleep(1)
        XCTAssertEqual(panel.frame.height, twoLines, accuracy: 1, "Deleting the line shrinks it back")
        input.typeText("\n3行目\n4行目\n5行目\n6行目\n7行目\n8行目\n9行目")
        sleep(1)
        let capped = panel.frame.height
        input.typeText("\n10行目\n11行目")
        sleep(1)
        XCTAssertEqual(panel.frame.height, capped, accuracy: 1, "Past six lines the text scrolls inside the panel")
        XCTAssertLessThan(capped, app.frame.height * 0.4)
        checkRows("long-text")
        capture("composer-long-text", app: app)
    }

    /// Reading older messages folds the composer into the voice, chat and
    /// latest buttons. Scrolling back down, and reaching the end, keep it
    /// folded (at the end the latest button flows into the chat button);
    /// only the chat button unfolds it, with the keyboard up and the draft
    /// ready to continue without another tap.
    @MainActor func testComposerFoldsIntoThreeButtonsAndOnlyChatUnfolds() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--long-chat"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("下書きの続き")
        let voice = app.buttons["composer-voice"], chat = app.buttons["composer-expand"]
        let latest = app.buttons["composer-jump"]
        XCTAssertFalse(chat.exists, "The folded buttons are hidden while the panel shows")
        dragReading(app, towardOlder: true)
        XCTAssertTrue(chat.waitForExistence(timeout: 4), "Reading older messages folds the composer")
        Thread.sleep(forTimeInterval: 1.0)
        XCTAssertTrue(gone(menu), "The panel's controls leave with it")
        XCTAssertFalse(app.keyboards.firstMatch.exists, "Folding puts the keyboard away")
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists, "No separate jump control while folded")
        let window = app.windows.firstMatch.frame
        print("COMPOSER folded voice=\(voice.frame) chat=\(chat.frame) latest=\(latest.frame)")
        for button in [voice, chat, latest] {
            XCTAssertTrue(button.isHittable)
            XCTAssertEqual(button.frame.width, 48, accuracy: 1)
            XCTAssertEqual(button.frame.height, 48, accuracy: 1)
            XCTAssertEqual(button.frame.midY, chat.frame.midY, accuracy: 1, "One row")
        }
        XCTAssertEqual(chat.frame.midX, window.midX, accuracy: 1, "The chat button is centered")
        XCTAssertEqual(chat.frame.midX - voice.frame.midX, 72, accuracy: 1, "Voice on the left")
        XCTAssertEqual(latest.frame.midX - chat.frame.midX, 72, accuracy: 1, "Latest on the right")
        XCTAssertEqual(voice.label, "音声入力")
        XCTAssertEqual(chat.label, "入力欄を開く")
        XCTAssertEqual(latest.label, "最新のメッセージへ移動")
        capture("composer-folded", app: app)
        // Back toward the end: still folded.
        dragReading(app, towardOlder: false)
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertTrue(chat.exists, "Scrolling down does not unfold")
        XCTAssertFalse(menu.exists)
        // Away from the end again, the latest button goes to the end, flows
        // into the chat button there and leaves the composer folded.
        dragReading(app, towardOlder: true)
        XCTAssertTrue(latest.waitForExistence(timeout: 3), "Away from the end the latest button is back")
        Thread.sleep(forTimeInterval: 0.8)
        latest.tap()
        Thread.sleep(forTimeInterval: 1.5)
        XCTAssertTrue(gone(latest), "At the end it is taken into the chat button")
        let newest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(newest.exists)
        XCTAssertLessThanOrEqual(newest.frame.maxY, chat.frame.minY, "The latest reply rests above the buttons")
        XCTAssertTrue(chat.exists, "Reaching the end keeps the composer folded")
        XCTAssertFalse(menu.exists)
        XCTAssertEqual(chat.frame.midX - window.midX, 36, accuracy: 1, "The two left close up around the middle")
        XCTAssertEqual(chat.frame.midX - voice.frame.midX, 72, accuracy: 1)
        capture("composer-folded-at-latest", app: app)
        // One tap: the panel returns with the keyboard and the draft,
        // unfolding from where the chat button is.
        menuMark("light-unfold-gathered"); chat.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3), "The chat button brings the keyboard at once")
        XCTAssertTrue(menu.waitForExistence(timeout: 3))
        XCTAssertTrue(gone(chat), "The buttons leave once they have merged")
        XCTAssertEqual(input.value as? String, "下書きの続き", "The draft is kept")
        // No tap on the field first: it already has the keyboard.
        input.typeText("です")
        XCTAssertEqual(input.value as? String, "下書きの続きです")
        capture("composer-unfolded-keyboard", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["下書きの続きです"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        XCTAssertTrue(menu.exists, "Sending keeps the panel")
        XCTAssertFalse(chat.exists)
    }

    /// スマート入力欄 after an unfold (user's report, 2026-10-27): folded,
    /// the chat button opens the panel with the keyboard, and then the plus,
    /// 検索, 深く and model buttons must each answer a tap, with the keyboard
    /// up and again once it is down, and so must the jump control above the
    /// panel, where it is seen. Taps land by coordinate, as a finger does.
    /// UNFOLD-ROW lines say which answered; `before` is 1.1.0 (205)'s
    /// unfold (`--unfold-as-205`) and only prints, for comparison.
    @MainActor func testSmartComposerRowAnswersAfterUnfold() { smartRowAfterUnfold("now", [], strict: true) }
    @MainActor func testSmartComposerRowAfterUnfoldBefore() {
        smartRowAfterUnfold("before", ["--unfold-as-205"], strict: false)
    }

    @MainActor private func smartRowAfterUnfold(_ variant: String, _ flags: [String], strict: Bool) {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--long-chat", "--reset-settings", "--web-search-key", "--web-search"] + flags
        app.launch()
        let plus = app.buttons["chat-add-menu"], search = app.buttons["composer-web-search"]
        let detail = app.buttons["composer-photo-detail"], model = app.buttons["composer-model"]
        let chat = app.buttons["composer-expand"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertTrue(search.waitForExistence(timeout: 3), "Search is on for this chat")
        XCTAssertTrue(detail.exists); XCTAssertTrue(model.exists)
        let photos = menuItem("chat-attach-photos", "写真", app)
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        let outside = app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35))
        var missed: [String] = []
        func center(_ element: XCUIElement) -> XCUICoordinate {
            element.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))
        }
        func answers(_ phase: String, _ name: String, _ button: XCUIElement, opening item: XCUIElement) {
            print("UNFOLD-ROW \(variant) \(phase) \(name) hittable=\(button.isHittable) frame=\(button.frame)")
            center(button).tap()
            let opened = item.waitForExistence(timeout: 3)
            print("UNFOLD-ROW \(variant) \(phase) \(name) \(opened ? "answered" : "NO-ANSWER")")
            guard opened else {
                missed.append("\(phase)-\(name)")
                capture("composer-unfold-row-\(variant)-\(phase)-\(name)-missed", app: app)
                return
            }
            Thread.sleep(forTimeInterval: 0.6)
            outside.tap()
            _ = gone(item)
            Thread.sleep(forTimeInterval: 0.6)
        }
        // 検索 turns search off; the plus menu turns it on again for the
        // next round.
        func searchAnswers(_ phase: String) {
            print("UNFOLD-ROW \(variant) \(phase) search hittable=\(search.isHittable) frame=\(search.frame)")
            center(search).tap()
            let off = gone(search)
            print("UNFOLD-ROW \(variant) \(phase) search \(off ? "answered" : "NO-ANSWER")")
            guard off else {
                missed.append("\(phase)-search")
                capture("composer-unfold-row-\(variant)-\(phase)-search-missed", app: app)
                return
            }
            center(plus).tap()
            let toggle = webSearchItem(app)
            if toggle.waitForExistence(timeout: 3) { toggle.tap() }
            if !search.waitForExistence(timeout: 3) { print("UNFOLD-ROW \(variant) \(phase) search not back on") }
            Thread.sleep(forTimeInterval: 0.6)
        }
        func row(_ phase: String) {
            answers(phase, "plus", plus, opening: photos)
            answers(phase, "detail", detail, opening: deep)
            answers(phase, "model", model, opening: gemma)
            searchAnswers(phase)
        }
        // Before any fold, as a check of the taps themselves.
        Thread.sleep(forTimeInterval: 1.0)
        answers("rest", "plus", plus, opening: photos)
        dragReading(app, towardOlder: true)
        XCTAssertTrue(chat.waitForExistence(timeout: 4), "Reading older messages folds the composer")
        Thread.sleep(forTimeInterval: 1.2)
        XCTAssertTrue(gone(plus), "The row leaves with the panel")
        capture("composer-unfold-row-\(variant)-folded", app: app)
        chat.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3), "The chat button brings the keyboard")
        XCTAssertTrue(plus.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1.5)
        capture("composer-unfold-row-\(variant)-keyboard-up", app: app)
        // The jump control rises 24pt above the panel; its target is a
        // separate element, which must stand where the control is seen.
        let field = app.descendants(matching: .any)["chat-composer"]
        let target = app.buttons["chat-jump-latest"]
        if target.exists {
            let seen = CGPoint(x: app.windows.firstMatch.frame.midX, y: field.frame.minY - 42)
            print("UNFOLD-ROW \(variant) jump seen=\(seen) target=\(target.frame) field=\(field.frame) keyboard=\(app.keyboards.firstMatch.frame)")
            app.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: seen.x, dy: seen.y)).tap()
            let jumped = gone(target, timeout: 3)
            print("UNFOLD-ROW \(variant) keyboard-up jump \(jumped ? "answered" : "NO-ANSWER")")
            if !jumped {
                missed.append("keyboard-up-jump")
                capture("composer-unfold-row-\(variant)-keyboard-up-jump-missed", app: app)
            }
            Thread.sleep(forTimeInterval: 0.8)
        } else {
            print("UNFOLD-ROW \(variant) keyboard-up jump not shown")
        }
        row("keyboard-up")
        // The keyboard down, the panel still open: through the history and back.
        app.buttons["chat-history"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.8)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertTrue(gone(historySidebar(app), timeout: 4))
        XCTAssertTrue(gone(app.keyboards.firstMatch, timeout: 4), "The keyboard is down")
        XCTAssertFalse(chat.exists, "The panel is still open")
        Thread.sleep(forTimeInterval: 1.0)
        capture("composer-unfold-row-\(variant)-keyboard-down", app: app)
        row("keyboard-down")
        print("UNFOLD-ROW \(variant) missed=\(missed.isEmpty ? "none" : missed.joined(separator: ","))")
        guard strict else { return }
        XCTAssertEqual(missed, [], "Every button of the row answers after the unfold")
        // The unfold's record in 開発者設定: its touches, read back after a
        // relaunch (UNFOLD-ROW record lines).
        app.terminate(); app.launchArguments = ["--developer-unlocked"]; app.launch()
        turnOnDeveloperSettings(app)
        let runAll = app.buttons["developer-diagnostics-run"]
        revealModelControl(runAll, in: "developer-list", app: app)
        runAll.tap()
        let log = app.staticTexts["send-screen-log"]
        XCTAssertTrue(log.waitForExistence(timeout: 6))
        for line in log.label.split(separator: "\n") { print("UNFOLD-ROW record \(line)") }
        XCTAssertTrue(log.label.contains("タッチ ("), "The unfold's touches are recorded")
        XCTAssertTrue(log.label.contains("下の列"), "and what a tap on the row reaches")
    }

    /// Folded at the end of the chat, the latest button flows into the
    /// chat button; reading up draws it back out. Its own tap goes to the
    /// end, where it flows in again, and the composer stays folded until the
    /// chat button is tapped. A small move near the end changes nothing
    /// (integrated directive, 2026-10-21, section 4). The session recording
    /// keeps the frames (scope jump-tuck, MENU-MARK lines).
    @MainActor func testFoldedLatestButtonFlowsIntoTheChatButton() {
        continueAfterFailure = false
        for (variant, flags) in [("light", [String]()), ("dark", ["--dark"])] {
            let app = PreviewApp(); app.launchArguments = ["--long-chat"] + flags; app.launch()
            let menu = app.buttons["chat-add-menu"]
            XCTAssertTrue(menu.waitForExistence(timeout: 10))
            let voice = app.buttons["composer-voice"], chat = app.buttons["composer-expand"]
            let latest = app.buttons["composer-jump"]
            dragReading(app, towardOlder: true)
            XCTAssertTrue(chat.waitForExistence(timeout: 4), "Reading older messages folds the composer")
            Thread.sleep(forTimeInterval: 1.2)
            XCTAssertTrue(latest.isHittable, "Away from the end the latest button stands apart")
            XCTAssertEqual(latest.frame.midX - chat.frame.midX, 72, accuracy: 1)
            let middle = app.windows.firstMatch.frame.midX
            // Its tap goes to the end, where it flows into the chat button.
            let point = latest.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))
            menuMark("\(variant)-absorb"); point.tap()
            XCTAssertTrue(gone(latest, timeout: 4), "At the end it is taken into the chat button")
            Thread.sleep(forTimeInterval: 0.6)
            XCTAssertTrue(chat.isHittable); XCTAssertTrue(voice.isHittable)
            XCTAssertEqual((voice.frame.midX + chat.frame.midX) / 2, middle, accuracy: 1,
                           "The voice and chat buttons close up around the middle")
            XCTAssertEqual(chat.frame.midX - middle, 36, accuracy: 1)
            XCTAssertEqual(chat.frame.width, 48, accuracy: 1, "and settles to its size")
            XCTAssertEqual(voice.frame.width, 48, accuracy: 1)
            XCTAssertEqual(chat.frame.midX - voice.frame.midX, 72, accuracy: 1, "with the same gap")
            XCTAssertFalse(menu.exists, "Reaching the end does not open the composer")
            print("COMPOSER tuck-\(variant) absorbed voice=\(voice.frame) chat=\(chat.frame)")
            capture("composer-tuck-\(variant)-absorbed", app: app)
            // A small move near the end leaves it inside.
            nudgeReading(app, by: 55)
            Thread.sleep(forTimeInterval: 1.0)
            XCTAssertFalse(latest.exists, "A small move near the end does not draw it out")
            // Reading up from the end draws it back out of the chat button.
            let (from, to) = readingDrag(app, towardOlder: true)
            menuMark("\(variant)-split"); from.press(forDuration: 0.05, thenDragTo: to)
            XCTAssertTrue(latest.waitForExistence(timeout: 3), "Reading up draws it out again")
            Thread.sleep(forTimeInterval: 1.0)
            XCTAssertTrue(latest.isHittable)
            XCTAssertEqual(latest.frame.midX - chat.frame.midX, 72, accuracy: 1, "Back in its place")
            XCTAssertEqual(chat.frame.midX, middle, accuracy: 1, "and the other two in theirs")
            XCTAssertEqual(chat.frame.midX - voice.frame.midX, 72, accuracy: 1)
            XCTAssertEqual(latest.frame.width, 48, accuracy: 1)
            XCTAssertEqual(chat.frame.width, 48, accuracy: 1)
            XCTAssertFalse(menu.exists, "Reading up keeps the composer folded")
            print("COMPOSER tuck-\(variant) split chat=\(chat.frame) latest=\(latest.frame)")
            capture("composer-tuck-\(variant)-split", app: app)
            // Only the chat button opens the composer, with the keyboard.
            chat.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
            XCTAssertTrue(menu.waitForExistence(timeout: 3))
            app.terminate()
        }
    }

    /// Folding follows the reader's finger only: the keyboard, a send, the
    /// reply's own following and a small nudge never fold the composer.
    @MainActor func testComposerStaysOpenThroughKeyboardSendAndStreaming() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--long-chat", "--growing-reply"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let chat = app.buttons["composer-expand"]
        let input = app.textViews["chat-input"]
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertFalse(chat.exists, "The keyboard does not fold the composer")
        input.typeText("Keyboard and stream")
        app.buttons["送信する"].tap()
        for _ in 0..<6 {
            Thread.sleep(forTimeInterval: 0.5)
            XCTAssertFalse(chat.exists, "Following the reply does not fold the composer")
        }
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        XCTAssertFalse(chat.exists)
        XCTAssertTrue(menu.exists)
        // A slow nudge of a few points toward older messages is not reading them.
        let reading = app.scrollViews["chat-conversation"]
        let origin = app.coordinate(withNormalizedOffset: .zero)
        let y = reading.frame.minY + reading.frame.height * 0.4
        origin.withOffset(CGVector(dx: reading.frame.midX, dy: y))
            .press(forDuration: 0.2, thenDragTo: origin.withOffset(CGVector(dx: reading.frame.midX, dy: y + 30)),
                   withVelocity: 80, thenHoldForDuration: 0.3)
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertFalse(chat.exists, "A nudge does not fold the composer")
        XCTAssertTrue(menu.exists)
        capture("composer-after-stream", app: app)
    }

    /// The voice button says there is no voice input yet instead of
    /// pretending, and can open the field for the keyboard's dictation.
    @MainActor func testComposerVoiceButtonSaysThereIsNoVoiceInputYet() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--long-chat"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        dragReading(app, towardOlder: true)
        let voice = app.buttons["composer-voice"]
        XCTAssertTrue(voice.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 1.0)
        voice.tap()
        let note = app.alerts["音声入力"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        XCTAssertTrue(note.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "まだ音声での会話に対応していません"))
                        .firstMatch.exists)
        capture("composer-voice-note", app: app)
        note.buttons["閉じる"].tap()
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertTrue(app.buttons["composer-expand"].exists, "Closing the note keeps the composer folded")
        voice.tap()
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        note.buttons["入力欄を開く"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 3))
        XCTAssertTrue(gone(app.buttons["composer-expand"]))
    }

    /// ブランド刷新 (2026-10-27): the chat in Fielua's paper and yellow, light
    /// and dark, for review (SHOT redesign-*): a Markdown reply, the
    /// keyboard up with a draft (the send button in yellow), the history
    /// sidebar with the flower beside the wordmark, an empty chat's flower,
    /// the model menu, a reply with its web pages, and the thinking orb in
    /// the flower's golds.
    @MainActor func testRedesignChatLight() { redesignChat(dark: false) }
    @MainActor func testRedesignChatDark() { redesignChat(dark: true) }

    /// 設定 in the new design, light and dark (SHOT redesign-*): its rows
    /// under the page name 「設定」 (the flower and wordmark until 1.1.0
    /// (214)), モデル管理 with its web search card,
    /// and Fieluaの情報 with the large flower.
    @MainActor func testRedesignSettingsLight() { redesignSettings(dark: false) }
    @MainActor func testRedesignSettingsDark() { redesignSettings(dark: true) }

    @MainActor private func redesignChat(dark: Bool) {
        continueAfterFailure = false
        let scheme = dark ? "dark" : "light"
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--markdown-sample", "--history-fixture"] + (dark ? ["--dark"] : [])
        app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1)
        capture("redesign-\(scheme)-chat-markdown", app: app)
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap()
        input.typeText("花の名前を教えて")
        Thread.sleep(forTimeInterval: 1)
        let send = app.buttons["送信する"]
        print("REDESIGN \(scheme) keyboard: input=\(input.frame) send=\(send.exists ? "\(send.frame)" : "-")")
        capture("redesign-\(scheme)-chat-keyboard", app: app)
        // The sidebar, from the header button (the keyboard goes down).
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        open.tap()
        let sidebar = historySidebar(app)
        XCTAssertTrue(sidebar.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 1)
        let title = app.staticTexts["Fielua"]
        print("REDESIGN \(scheme) sidebar: \(sidebar.frame) title=\(title.exists ? "\(title.frame)" : "missing")")
        XCTAssertTrue(title.exists, "The sidebar's wordmark is still the text Fielua")
        capture("redesign-\(scheme)-sidebar", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        // An empty chat: the flower in the middle of the paper.
        plus.tap()
        chooseMenuAction("新しいチャット", app: app)
        XCTAssertTrue(app.descendants(matching: .any)["chat-empty"].waitForExistence(timeout: 5))
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        Thread.sleep(forTimeInterval: 1)
        capture("redesign-\(scheme)-empty-chat", app: app)
        let chip = app.buttons["composer-model"]
        if chip.waitForExistence(timeout: 3) {
            chip.tap()
            let gemma = menuItem("model-menu-gemma", "Gemma", app)
            XCTAssertTrue(gemma.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            capture("redesign-\(scheme)-model-menu", app: app)
            dismissMenu(gemma, app: app)
        } else {
            print("REDESIGN \(scheme) model chip not shown in an empty chat")
        }

        // A reply that searched the web, then the orb while a reply waits.
        app.terminate()
        app.launchArguments = ["--reset-settings", "--web-search-sample", "--orb-wait"] + (dark ? ["--dark"] : [])
        app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1)
        capture("redesign-\(scheme)-chat-sources", app: app)
        input.tap(); input.typeText("ありがとう")
        send.tap()
        Thread.sleep(forTimeInterval: 2.5)
        let waiting = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        waiting.name = "redesign-\(scheme)-orb"; waiting.lifetime = .keepAlways; add(waiting)
        let stop = app.buttons["停止する"]
        XCTAssertTrue(stop.waitForExistence(timeout: 3))
        stop.tap()
    }

    @MainActor private func redesignSettings(dark: Bool) {
        continueAfterFailure = false
        let scheme = dark ? "dark" : "light"
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--web-search-no-key"] + (dark ? ["--dark"] : [])
        app.launch()
        openSettingsFromChat(app)
        XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        // The sheet's title (the sidebar's 「Fielua」 is in the tree too).
        let title = app.descendants(matching: .any)["settings-title"].firstMatch
        print("REDESIGN \(scheme) settings title: \(title.exists ? "\(title.frame)" : "missing")")
        capture("redesign-\(scheme)-settings-home", app: app)
        openSettingsRow("models", title: "モデル管理", app: app)
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-\(scheme)-settings-models", app: app)
        app.swipeUp(); Thread.sleep(forTimeInterval: 0.4); app.swipeUp()
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-\(scheme)-settings-models-lower", app: app)
        app.buttons["settings-back"].tap()
        XCTAssertTrue(app.buttons["settings-row-about"].waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.6)
        openSettingsRow("about", title: "Fieluaの情報", app: app)
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-\(scheme)-settings-about", app: app)
    }

    /// The empty chat's flower, always moving (1.1.0 (215); in 214 it stood
    /// still between petals and looked almost still on the phone).
    /// --living-flower-calm keeps petals from leaving for a minute, so these
    /// frames are the breathing and the petals' opening and closing alone:
    /// screenshots as quick as they come, of the flower's colours. It comes
    /// in with no jump, keeps changing from frame to frame and swells and
    /// shrinks visibly, never jumps between frames, and draws at most 30
    /// frames a second, and keeps moving with only the keyboard up (typing:
    /// testLivingFlowerLeavesWhileTyping*) (REDESIGN flower lines, SHOT
    /// redesign-flower-*-breath).
    @MainActor func testLivingFlowerBreathesLight() { livingFlowerBreathes(dark: false) }
    @MainActor func testLivingFlowerBreathesDark() { livingFlowerBreathes(dark: true) }

    /// Now and then a petal leaves, drifts off turning in the air and a new
    /// one grows (--living-flower-quick: the first 1.5 s after the flower
    /// starts to move, then 2 s apart): a petal goes beyond the flower's
    /// bounds and the flower is whole again after it, at most 60 frames a
    /// second while it flies (SHOT redesign-flower-*-frames).
    @MainActor func testLivingFlowerLight() { livingFlowerDrifts(dark: false) }
    @MainActor func testLivingFlowerDark() { livingFlowerDrifts(dark: true) }

    /// With Reduce Motion the empty chat's flower holds still and draws
    /// nothing.
    @MainActor func testLivingFlowerHoldsStillWithReduceMotion() {
        livingFlowerHoldsStill(["--reduce-motion"], name: "reduced")
    }

    /// In Low Power Mode (--low-power: the simulator cannot turn it on) the
    /// flower holds still and draws nothing, as it does while the phone is
    /// hot.
    @MainActor func testLivingFlowerRestsInLowPower() {
        livingFlowerHoldsStill(["--low-power"], name: "low power")
    }

    /// Out of the app and back: the flower drew nothing while the app was
    /// away, and comes back in from rest with no jump.
    @MainActor func testLivingFlowerResumesAfterBackground() {
        continueAfterFailure = false
        // The flower at rest, for the comparison: with Reduce Motion it is
        // the still mark, which the resting flower matches (typing no longer
        // shows it at rest: it goes away, 1.1.0 (216)).
        let reduced = PreviewApp()
        reduced.launchArguments = ["--reset-settings", "--reduce-motion"]
        reduced.launch()
        openEmptyChat(reduced)
        let rest = flowerReadings(reduced, seconds: 1)
        reduced.terminate()
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--living-flower-calm", "--living-flower-probe"]
        app.launch()
        openEmptyChat(app)
        Thread.sleep(forTimeInterval: 4)
        let before = flowerProbe(app), leaving = Date()
        XCTAssertTrue(before.state.contains("running=1"), "It moves: \(before.state)")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 6)
        app.activate()
        // One screenshot at once, then the frame count, then the rest.
        let firstBack = flowerReadings(app, seconds: 0.01)
        let after = flowerProbe(app), away = Date().timeIntervalSince(leaving)
        let back = firstBack + flowerReadings(app, seconds: 5)
        guard let resting = rest.last, let first = back.first else { return XCTFail("No screenshots") }
        logFlower(back, "background back")
        print(String(format: "REDESIGN flower background: %.1f s from leaving to back, frames %d (%.0f if it never stopped), rests %d -> %d, first back %.0f vs rest %.0f",
                     away, after.frames - before.frames, 28 * away, before.rests, after.rests, first.mass, resting.mass))
        // It stopped drawing while away: the frames are its settling (1.25 s)
        // and the moments on the way out and back, not the 6 s away.
        XCTAssertGreaterThan(after.rests, before.rests, "It stopped while the app was away (\(after.state))")
        XCTAssertLessThan(Double(after.frames - before.frames), 30 * (away - 4), "Nothing drawn while the app was away")
        // Within the first second the motion is a third in at most (a
        // swing of 2.5% of the 7.5% in full).
        XCTAssertLessThan(abs(first.mass - resting.mass) / resting.mass, 0.04, "It comes back from rest")
        checkSmooth(back, "background back")
        XCTAssertGreaterThanOrEqual(back.filter { $0.time.timeIntervalSince(first.time) > 1.5 && !$0.same(as: first) }.count, 2,
                                    "It moves again")
    }

    @MainActor private func livingFlowerBreathes(dark: Bool) {
        continueAfterFailure = false
        let scheme = dark ? "dark" : "light"
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--living-flower-calm", "--living-flower-probe"] + (dark ? ["--dark"] : [])
        app.launch()
        openEmptyChat(app)
        let readings = flowerReadings(app, seconds: 10)
        guard let start = readings.first else { return XCTFail("No screenshots") }
        logFlower(readings, "\(scheme) breath")
        XCTAssertGreaterThan(start.count, 300, "The flower shows")
        // A screenshot and its reading take 0.4 to 0.9 s on the runner.
        XCTAssertGreaterThanOrEqual(readings.count, 10)
        checkSmooth(readings, "\(scheme) breath")
        // In full from 3 s on.
        let full = readings.filter { $0.time.timeIntervalSince(start.time) >= 3 }
        let held = zip(full, full.dropFirst()).filter { $0.same(as: $1) }.count
        print(String(format: "REDESIGN flower %@ breath: frames %d, swing %.3f, held %d of %d", scheme,
                     readings.count, swing(full), held, max(0, full.count - 1)))
        XCTAssertGreaterThan(swing(full), 0.04, "It swells and shrinks visibly")
        XCTAssertLessThanOrEqual(Double(held), Double(max(0, full.count - 1)) * 0.15, "It keeps moving")
        let budget = flowerRate(app, seconds: 4)
        print(String(format: "REDESIGN flower %@ breath: %.1f frames a second (%@)", scheme, budget.rate, budget.state))
        XCTAssertTrue(budget.state.contains("running=1"))
        XCTAssertGreaterThan(budget.rate, 5, "It draws while it moves")
        XCTAssertLessThan(budget.rate, 35, "At most 30 frames a second")
        flowerSheet(Array(stride(from: 0, to: full.count, by: max(1, full.count / 16)).map { full[$0] }.prefix(16)),
                    name: "redesign-flower-\(scheme)-breath")

        // With only the keyboard up it keeps moving (typing: livingFlowerLeaves).
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap()
        Thread.sleep(forTimeInterval: 1.5)
        let keyboardUp = flowerReadings(app, seconds: 1.5)
        XCTAssertGreaterThan(Set(keyboardUp.map { Int($0.mass) }).count, 1, "Still moving with only the keyboard up")
    }

    /// While the person types the flower shrinks and fades away and nothing
    /// is drawn; with the text deleted it grows back in and moves again;
    /// after typing and deleting in quick turns, each halfway through the
    /// last change, it is back and moving; once a message is sent it is gone
    /// and draws nothing (1.1.0 (216)). The going and coming are also cut
    /// from the session recording frame by frame (FLOWER-MARK lines,
    /// scripts/flower-frames.swift: how much of the flower's colour each
    /// recorded frame shows, so a jump would be one big step), REDESIGN
    /// flower lines and SHOT redesign-flower-*-typing, -sent.
    @MainActor func testLivingFlowerLeavesWhileTypingLight() { livingFlowerLeaves(dark: false) }
    @MainActor func testLivingFlowerLeavesWhileTypingDark() { livingFlowerLeaves(dark: true) }

    /// With Reduce Motion the still flower only fades out while the person
    /// types and fades back in as it was, drawing nothing.
    @MainActor func testLivingFlowerLeavesWithReduceMotion() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--reduce-motion", "--living-flower-probe"]
        app.launch()
        openEmptyChat(app)
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap()
        Thread.sleep(forTimeInterval: 2)
        guard let before = flowerReadings(app, seconds: 0.01).first else { return XCTFail("No screenshots") }
        input.typeText("花")
        Thread.sleep(forTimeInterval: 0.8)
        let gone = flowerReadings(app, seconds: 1)
        input.typeText(XCUIKeyboardKey.delete.rawValue)
        Thread.sleep(forTimeInterval: 0.8)
        let back = flowerReadings(app, seconds: 1.5)
        let budget = flowerRate(app, seconds: 1)
        print(String(format: "REDESIGN flower reduced leaves: colour before %d, while typing %d at most, back %d frames, the same %d, %.1f frames a second (%@)",
                     before.count, gone.map(\.count).max() ?? -1, back.count, back.filter { $0.same(as: before) }.count,
                     budget.rate, budget.state))
        XCTAssertGreaterThan(before.count, 300, "The flower shows")
        XCTAssertFalse(gone.isEmpty)
        XCTAssertTrue(gone.allSatisfy { $0.count < 40 }, "Gone while typing")
        XCTAssertFalse(back.isEmpty)
        XCTAssertTrue(back.allSatisfy { $0.same(as: before) }, "The same still flower again")
        XCTAssertEqual(budget.rate, 0, "Nothing drawn with Reduce Motion")
    }

    @MainActor private func livingFlowerLeaves(dark: Bool) {
        continueAfterFailure = false
        let scheme = dark ? "dark" : "light"
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--living-flower-calm", "--living-flower-probe"] + (dark ? ["--dark"] : [])
        app.launch()
        openEmptyChat(app)
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap()
        // The keyboard up and the motion in.
        Thread.sleep(forTimeInterval: 3)
        guard let before = flowerReadings(app, seconds: 1).last else { return XCTFail("No screenshots") }
        XCTAssertGreaterThan(before.count, 300, "The flower shows")
        // The recording's frames are read here: the flower with room to breathe.
        let box = before.bounds.insetBy(dx: -24, dy: -24)
        func mark(_ name: String, span: Double) {
            print(String(format: "FLOWER-MARK %@-%@ %.3f %.1f %.1f %.1f %.1f %.1f %.1f", name, scheme, Date().timeIntervalSince1970,
                         span, box.minX, box.minY, box.width, box.height, app.frame.width))
        }

        // Typing: it shrinks and fades away, then nothing is drawn.
        mark("type", span: 1.6)
        input.typeText("花")
        Thread.sleep(forTimeInterval: 1)
        let gone = flowerReadings(app, seconds: 1.5)
        let idle = flowerRate(app, seconds: 2)
        print(String(format: "REDESIGN flower %@ leaves: %d frames, colour %d at most, %.1f frames a second (%@)", scheme,
                     gone.count, gone.map(\.count).max() ?? -1, idle.rate, idle.state))
        XCTAssertFalse(gone.isEmpty)
        XCTAssertTrue(gone.allSatisfy { $0.count < 40 }, "Gone while typing")
        XCTAssertTrue(idle.state.contains("running=0") && idle.state.contains("away=1"), "Nothing drawn while typing: \(idle.state)")
        XCTAssertEqual(idle.rate, 0, "Nothing drawn while typing")
        capture("redesign-flower-\(scheme)-typing", app: app)

        // The text deleted: it grows back in and moves again.
        mark("clear", span: 1.6)
        input.typeText(XCUIKeyboardKey.delete.rawValue)
        let back = flowerReadings(app, seconds: 4)
        let backState = flowerProbe(app).state
        guard let first = back.first, let returned = back.last else { return XCTFail("No screenshots") }
        logFlower(back, "\(scheme) back")
        // After its grow-in (0.65 s), while its motion comes in.
        let settled = back.filter { $0.time.timeIntervalSince(first.time) > 1 }
        print(String(format: "REDESIGN flower %@ back: colour %d (before typing %d), weight %.0f vs %.0f (%@)", scheme,
                     returned.count, before.count, returned.mass, before.mass, backState))
        XCTAssertGreaterThan(returned.count, 300, "Back once the text is gone")
        XCTAssertLessThan(abs(returned.mass - before.mass) / before.mass, 0.2, "Its own size again")
        checkSmooth(settled, "\(scheme) back")
        XCTAssertGreaterThanOrEqual(zip(settled, settled.dropFirst()).filter { !$0.same(as: $1) }.count, 2, "It moves again")
        XCTAssertTrue(backState.contains("running=1") && backState.contains("away=0"), "Drawing again: \(backState)")

        // Typing and deleting in quick turns: a letter and its deletion in
        // one go, the flower turning back a moment into going, then a letter
        // left a little longer. It ends back and moving (and the recording
        // shows no jump).
        mark("flip", span: 3.6)
        input.typeText("a" + XCUIKeyboardKey.delete.rawValue)
        Thread.sleep(forTimeInterval: 0.2)
        input.typeText("b")
        Thread.sleep(forTimeInterval: 0.15)
        input.typeText(XCUIKeyboardKey.delete.rawValue)
        Thread.sleep(forTimeInterval: 0.2)
        let after = flowerReadings(app, seconds: 3)
        guard let start = after.first, let end = after.last else { return XCTFail("No screenshots") }
        logFlower(after, "\(scheme) flip")
        let tail = after.filter { $0.time.timeIntervalSince(start.time) > 1 }
        XCTAssertGreaterThan(end.count, 300, "Back after quick turns")
        checkSmooth(tail, "\(scheme) flip")
        XCTAssertGreaterThanOrEqual(zip(tail, tail.dropFirst()).filter { !$0.same(as: $1) }.count, 1, "It moves again")

        // Sent: the chat goes on without the flower, and nothing is drawn.
        input.typeText("花")
        Thread.sleep(forTimeInterval: 1)
        mark("send", span: 2)
        app.buttons["送信する"].tap()
        Thread.sleep(forTimeInterval: 2)
        let sent = flowerRate(app, seconds: 2)
        print(String(format: "REDESIGN flower %@ sent: %.1f frames a second (%@)", scheme, sent.rate, sent.state))
        XCTAssertTrue(sent.state.contains("shown=0"), "No flower once the message is sent: \(sent.state)")
        XCTAssertEqual(sent.rate, 0, "Nothing drawn once the message is sent")
        capture("redesign-flower-\(scheme)-sent", app: app)
    }

    @MainActor private func livingFlowerDrifts(dark: Bool) {
        continueAfterFailure = false
        let scheme = dark ? "dark" : "light"
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--living-flower-quick", "--living-flower-probe"] + (dark ? ["--dark"] : [])
        app.launch()
        openEmptyChat(app)
        let readings = flowerReadings(app, seconds: 16)
        let probe = flowerProbe(app)
        guard !readings.isEmpty else { return XCTFail("No screenshots") }
        logFlower(readings, "\(scheme) drift")
        // The flower's own bounds: the middle of what the frames show.
        func median(_ values: [CGFloat]) -> CGFloat { values.sorted()[values.count / 2] }
        let home = CGRect(x: median(readings.map(\.bounds.minX)), y: median(readings.map(\.bounds.minY)),
                          width: 0, height: 0)
        let homeMax = CGPoint(x: median(readings.map(\.bounds.maxX)), y: median(readings.map(\.bounds.maxY)))
        let mass = median(readings.map { CGFloat($0.mass) })
        func beyond(_ reading: FlowerReading) -> CGFloat {
            max(home.minX - reading.bounds.minX, reading.bounds.maxX - homeMax.x,
                home.minY - reading.bounds.minY, reading.bounds.maxY - homeMax.y)
        }
        let flying = readings.indices.filter { beyond(readings[$0]) > 6 }
        let reach = readings.map(beyond).max() ?? 0
        print(String(format: "REDESIGN flower %@ drift: frames %d, flying %d, reach %.0f pt, %@", scheme,
                     readings.count, flying.count, reach, probe.state))
        XCTAssertGreaterThan(readings[0].count, 300, "The flower shows")
        // At night the petal fades by 70% of its way, so it shows in fewer
        // frames; the app's own count says the petals kept coming.
        XCTAssertGreaterThanOrEqual(probe.drifts, 2, "Petals left one after another")
        XCTAssertGreaterThanOrEqual(flying.count, dark ? 1 : 3, "A petal flew")
        XCTAssertGreaterThan(reach, 8, "A petal left the flower's bounds")
        // Whole again after the first petal.
        if let first = flying.first, let end = flying.first(where: { $0 >= first && !flying.contains($0 + 1) }) ?? flying.last {
            XCTAssertTrue(readings.indices.contains { $0 > end && beyond(readings[$0]) < 2.5
                                                        && abs(CGFloat(readings[$0].mass) - mass) / mass < 0.1 },
                          "Whole again after the petal")
        }
        let budget = flowerRate(app, seconds: 4)
        print(String(format: "REDESIGN flower %@ drift: %.1f frames a second (%@)", scheme, budget.rate, budget.state))
        XCTAssertGreaterThan(budget.rate, 5, "It draws while it moves")
        XCTAssertLessThan(budget.rate, 66, "At most 60 frames a second")
        let start = max(0, (flying.first ?? 0) - 1)
        flowerSheet(Array(readings[start...].prefix(16)), name: "redesign-flower-\(scheme)-frames")
    }

    @MainActor private func livingFlowerHoldsStill(_ arguments: [String], name: String) {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--living-flower-quick", "--living-flower-probe"] + arguments
        app.launch()
        openEmptyChat(app)
        let readings = flowerReadings(app, seconds: 6)
        guard let first = readings.first else { return XCTFail("No screenshots") }
        let moving = readings.filter { !$0.same(as: first) }
        let budget = flowerRate(app, seconds: 2)
        print("REDESIGN flower \(name): frames \(readings.count), moving \(moving.count), bounds \(first.bounds), \(budget.state)")
        XCTAssertGreaterThan(first.count, 300, "The flower shows")
        XCTAssertGreaterThanOrEqual(readings.count, 6)
        XCTAssertTrue(moving.isEmpty, "Still (\(name))")
        XCTAssertTrue(budget.state.contains("running=0"), "Nothing drawn (\(name)): \(budget.state)")
        XCTAssertEqual(budget.rate, 0, "Nothing drawn (\(name))")
    }

    /// No jump between frames: the flower's weight and its middle change
    /// no faster than the breathing and the petals can move them (at most
    /// 0.11 of the weight a second in a simulation, and about 0.6pt),
    /// allowing about three times that for the screenshots' uneven timing.
    @MainActor private func checkSmooth(_ readings: [FlowerReading], _ name: String) {
        var worst = (mass: 0.0, centre: 0.0)
        for (a, b) in zip(readings, readings.dropFirst()) {
            let seconds = max(b.time.timeIntervalSince(a.time), 0.05)
            let mass = abs(b.mass - a.mass) / max(a.mass, 1) / seconds
            let centre = hypot(b.massCentre.x - a.massCentre.x, b.massCentre.y - a.massCentre.y) / seconds
            worst = (max(worst.mass, mass), max(worst.centre, Double(centre)))
        }
        print(String(format: "REDESIGN flower %@ smooth: weight %.3f a second, middle %.2f pt a second at most", name, worst.mass, worst.centre))
        XCTAssertLessThan(worst.mass, 0.3, "No jump in the flower's size (\(name))")
        XCTAssertLessThan(worst.centre, 2, "No jump in the flower's place (\(name))")
    }

    /// How much the flower's weight swings over these frames, of its mean.
    private func swing(_ readings: [FlowerReading]) -> Double {
        let masses = readings.map(\.mass)
        guard let low = masses.min(), let high = masses.max(), !masses.isEmpty else { return 0 }
        return (high - low) / max(masses.reduce(0, +) / Double(masses.count), 1)
    }

    @MainActor private func logFlower(_ readings: [FlowerReading], _ name: String) {
        guard let start = readings.first else { return }
        for reading in readings {
            print(String(format: "REDESIGN flower %@ t=%.2f weight %.0f middle %.2f,%.2f %d pt² bounds %.0f,%.0f %.0fx%.0f", name,
                         reading.time.timeIntervalSince(start.time), reading.mass, reading.massCentre.x, reading.massCentre.y,
                         reading.count, reading.bounds.minX, reading.bounds.minY, reading.bounds.width, reading.bounds.height))
        }
    }

    /// The flower's state and frames from its probe (--living-flower-probe).
    @MainActor private func flowerProbe(_ app: XCUIApplication) -> (state: String, frames: Int, rests: Int, drifts: Int) {
        let probe = app.descendants(matching: .any)["living-flower-probe"].firstMatch
        guard probe.waitForExistence(timeout: 3) else { XCTFail("No flower probe"); return ("", 0, 0, 0) }
        let label = probe.label
        func value(_ key: String) -> Int {
            label.components(separatedBy: " ").first { $0.hasPrefix(key + "=") }
                .flatMap { Int($0.dropFirst(key.count + 1).filter(\.isNumber)) } ?? 0
        }
        return (label, value("frames"), value("rests"), value("drifts"))
    }

    @MainActor private func flowerRate(_ app: XCUIApplication, seconds: TimeInterval) -> (rate: Double, state: String) {
        let first = flowerProbe(app), begin = Date()
        Thread.sleep(forTimeInterval: seconds)
        let last = flowerProbe(app)
        return (Double(last.frames - first.frames) / Date().timeIntervalSince(begin), last.state)
    }

    /// Up to 16 frames of the flower in a sheet, each labelled with its time.
    @MainActor private func flowerSheet(_ picks: [FlowerReading], name: String) {
        guard let first = picks.first, !first.bounds.isNull else { return }
        let tile = first.bounds.insetBy(dx: -46, dy: -46).integral
        let sheet = UIGraphicsImageRenderer(size: CGSize(width: tile.width * 4, height: tile.height * 4)).image { context in
            UIColor.gray.setFill(); context.fill(CGRect(x: 0, y: 0, width: tile.width * 4, height: tile.height * 4))
            for (index, frame) in picks.enumerated() {
                let origin = CGPoint(x: CGFloat(index % 4) * tile.width, y: CGFloat(index / 4) * tile.height)
                if let image = frame.area.image(of: tile) {
                    UIImage(cgImage: image).draw(in: CGRect(origin: origin, size: tile.size))
                }
                let label = String(format: "%.2f s", frame.time.timeIntervalSince(first.time))
                (label as NSString).draw(at: CGPoint(x: origin.x + 6, y: origin.y + 4),
                                         withAttributes: [.font: UIFont.systemFont(ofSize: 11), .foregroundColor: UIColor.gray])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    // MARK: 体験型おすすめ質問 (1.1.0 (219))

    /// An empty chat with its model saved: 「試してみる」 and three chips in
    /// one row over the field, the flower in the middle, with the keyboard
    /// down and up; one letter typed puts them away with the flower and
    /// deleting it brings them back; a chip sends its whole question at
    /// once through the chat's send (the question is the person's message,
    /// the preview's stand-in reply follows), the chips and the flower go,
    /// and the chat goes on as any other and is in the history (TRY lines,
    /// SHOT try-*). Dark on a 375pt phone too.
    @MainActor func testTryQuestionsLight() { tryQuestions(dark: false) }
    @MainActor func testTryQuestionsDarkOnANarrowPhone() { tryQuestions(dark: true, narrow: true) }

    /// The chips give way: no chip in an empty chat whose model is not
    /// saved (「モデルを準備する」 is there instead), and none while 「前回の
    /// 会話に戻る」 is over the field; they come once it has gone.
    @MainActor func testTryQuestionsGiveWay() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--fresh-install"]
        app.launch()
        openEmptyChat(app)
        XCTAssertTrue(app.buttons["モデルを準備する"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["chat-try-math"].exists, "No chip that could not send")
        XCTAssertEqual(tryState(app), "none")
        capture("try-no-model", app: app)
        app.terminate()
        app.launchArguments = ["--reset-settings", "--launch-chat=new", "--history-fixture"]
        app.launch()
        let back = app.buttons["chat-launch-return"]
        XCTAssertTrue(back.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.2)
        XCTAssertTrue(back.isHittable)
        print("TRY give-way launch-return=\(back.frame) state=\(tryState(app))")
        XCTAssertEqual(tryState(app), "hidden", "「前回の会話に戻る」 comes first")
        capture("try-launch-return", app: app)
        let input = app.textViews["chat-input"]
        input.typeText("a")
        XCTAssertTrue(gone(back))
        input.typeText(XCUIKeyboardKey.delete.rawValue)
        XCTAssertTrue(waitTryState(app, "shown"), "Back once the capsule has gone")
    }

    /// With the chat's web search on (and a key), a try question is still
    /// answered on the phone alone: its reply searched nothing, and the
    /// chat's switch is left on.
    @MainActor func testTryQuestionDoesNotSearch() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--e2b", "--web-search-key"]; app.launch()
        openEmptyChat(app)
        // As the person would: once the chips have come.
        XCTAssertTrue(waitTryState(app, "shown"))
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-web-search"]
        plus.tap()
        let toggle = webSearchItem(app)
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        print("TRY search item type=\(toggle.elementType.rawValue) id=\(toggle.identifier) label=\(toggle.label) value=\(String(describing: toggle.value)) frame=\(toggle.frame)")
        capture("try-search-menu", app: app)
        toggle.tap()
        let on = pill.waitForExistence(timeout: 3)
        print("TRY search after-tap pill=\(on) menu-open=\(toggle.exists) state=\(tryState(app)) composer-buttons=\(app.descendants(matching: .any)["chat-composer"].firstMatch.buttons.allElementsBoundByIndex.map(\.identifier))")
        if !on { capture("try-search-after-tap", app: app) }
        XCTAssertTrue(on, "Search is on in this chat")
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        XCTAssertTrue(waitTryState(app, "shown"))
        app.buttons["chat-try-summary"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "次の文を3つのポイントに要約してください。"))
                        .firstMatch.waitForExistence(timeout: 5), "The question as sent")
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 8))
        let header = app.descendants(matching: .any).matching(identifier: "reply-web-search").firstMatch
        print("TRY search header=\(header.exists) pill=\(pill.exists)")
        XCTAssertFalse(header.exists, "Nothing was searched")
        XCTAssertTrue(pill.exists, "The chat's search is still on")
        capture("try-no-search", app: app)
    }

    @MainActor private func tryQuestions(dark: Bool, narrow: Bool = false) {
        continueAfterFailure = false
        let name = (dark ? "dark" : "light") + (narrow ? "-narrow" : "")
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings"] + (dark ? ["--dark"] : []) + (narrow ? ["--narrow-phone"] : [])
        app.launch()
        openEmptyChat(app)
        let chips = ["math", "summary", "document"].map { app.buttons["chat-try-\($0)"] }
        let field = app.descendants(matching: .any)["chat-composer"].firstMatch
        let input = app.textViews["chat-input"]
        XCTAssertTrue(chips[0].waitForExistence(timeout: 5))
        XCTAssertTrue(waitTryState(app, "shown"))
        XCTAssertEqual(chips.map(\.label), ["数学を解く", "文章を要約", "資料を作る"])
        XCTAssertTrue(app.staticTexts["試してみる"].exists)
        func placed(_ when: String) {
            let width = app.windows.firstMatch.frame.width
            print("TRY \(name) \(when) chips=\(chips.map { "\($0.frame)" }) field=\(field.frame) width=\(width)")
            for chip in chips {
                XCTAssertTrue(chip.isHittable, "\(chip.label) \(when)")
                XCTAssertLessThanOrEqual(chip.frame.maxY, field.frame.minY + 1, "Over the field \(when)")
                XCTAssertGreaterThanOrEqual(chip.frame.minX, 0); XCTAssertLessThanOrEqual(chip.frame.maxX, width)
                XCTAssertEqual(chip.frame.midY, chips[0].frame.midY, accuracy: 1, "One row \(when)")
            }
            XCTAssertLessThan(chips[0].frame.maxX, chips[1].frame.minX)
            XCTAssertLessThan(chips[1].frame.maxX, chips[2].frame.minX)
        }
        placed("rest")
        Thread.sleep(forTimeInterval: 0.6)
        capture("try-\(name)-empty", app: app)
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.2)
        XCTAssertEqual(tryState(app), "shown", "Still there with the keyboard up")
        placed("keyboard")
        capture("try-\(name)-keyboard", app: app)
        input.typeText("a")
        XCTAssertTrue(waitTryState(app, "hidden"), "Typing puts them away")
        Thread.sleep(forTimeInterval: 0.8)
        print("TRY \(name) typing field=\(field.frame) math=\(chips[0].frame) hittable=\(chips[0].isHittable)")
        capture("try-\(name)-typing", app: app)
        input.typeText(XCUIKeyboardKey.delete.rawValue)
        XCTAssertTrue(waitTryState(app, "shown"), "An empty field brings them back")
        Thread.sleep(forTimeInterval: 0.8)
        placed("back")
        chips[0].tap()
        let asked = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "48個のお菓子を6人で同じ数ずつ分けると1人何個？"))
        XCTAssertTrue(asked.firstMatch.waitForExistence(timeout: 5), "The chip's whole question is the person's message")
        XCTAssertTrue(waitTryState(app, "none"), "Sent: the chips are gone")
        XCTAssertFalse(app.descendants(matching: .any)["chat-empty"].exists, "A chat with a message")
        let replyText = "プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"
        XCTAssertTrue(app.staticTexts[replyText].waitForExistence(timeout: 8), "The chat's own reply path")
        Thread.sleep(forTimeInterval: 0.6)
        capture("try-\(name)-sent", app: app)
        // The chat goes on as any other.
        input.tap(); input.typeText("ありがとう")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["ありがとう"].waitForExistence(timeout: 5))
        let replies = app.staticTexts.matching(NSPredicate(format: "label == %@", replyText))
        expectation(for: NSPredicate(format: "count == 2"), evaluatedWith: replies)
        waitForExpectations(timeout: 10)
        XCTAssertEqual(tryState(app), "none")
        app.buttons["chat-history"].tap()
        let row = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く: 48個のお菓子")).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 5), "In the history as any chat")
        capture("try-\(name)-history", app: app)
    }

    /// The try chips' state from the preview's probe (shown, hidden, none).
    @MainActor private func tryState(_ app: XCUIApplication) -> String {
        app.descendants(matching: .any)["chat-try-state"].firstMatch.label
    }

    @MainActor private func waitTryState(_ app: XCUIApplication, _ state: String, timeout: TimeInterval = 4) -> Bool {
        let probe = app.descendants(matching: .any)["chat-try-state"].firstMatch
        let wait = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", state), object: probe)
        return XCTWaiter().wait(for: [wait], timeout: timeout) == .completed || probe.label == state
    }

    /// A new chat, its flower alone on the screen (the keyboard down).
    @MainActor private func openEmptyChat(_ app: XCUIApplication) {
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        chooseMenuAction("新しいチャット", app: app)
        XCTAssertTrue(app.descendants(matching: .any)["chat-empty"].waitForExistence(timeout: 5))
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        // Until the menu and the keyboard have gone, so the flower stays in
        // its place while it is read.
        Thread.sleep(forTimeInterval: 1)
    }

    private struct FlowerReading {
        let time: Date
        let area: ScreenArea
        let count: Int
        let centre: CGPoint
        let bounds: CGRect
        /// The flower's weight: its colour summed over its pixels, which
        /// changes smoothly as it moves by less than a point.
        let mass: Double
        let massCentre: CGPoint
        func same(as other: FlowerReading) -> Bool {
            abs(count - other.count) <= 2 && abs(centre.x - other.centre.x) < 0.2 && abs(centre.y - other.centre.y) < 0.2
                && bounds == other.bounds && abs(mass - other.mass) <= max(4, mass * 0.001)
        }
    }

    /// The coloured pixels between the chat's header and its composer (an
    /// empty chat's only colour is the flower), as quick as screenshots come.
    @MainActor private func flowerReadings(_ app: XCUIApplication, seconds: TimeInterval) -> [FlowerReading] {
        let top = app.buttons["chat-model-settings"].frame.maxY + 4
        let bottom = app.descendants(matching: .any)["chat-composer"].frame.minY - 4
        let region = CGRect(x: 0, y: top, width: app.frame.width, height: max(1, bottom - top))
        var readings: [FlowerReading] = []
        let begin = Date()
        while Date().timeIntervalSince(begin) < seconds {
            guard let shot = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(shot, region, screenWidth: app.frame.width) else { break }
            let flower = area.colourAndWeight()
            readings.append(FlowerReading(time: Date(), area: area, count: flower.count, centre: flower.centre, bounds: flower.bounds,
                                          mass: flower.mass, massCentre: flower.massCentre))
        }
        return readings
    }

    /// 構成 on the paper (1.1.0 (215); iOS's grey and white until then):
    /// the page beside the cards and the cards themselves are Fielua's warm
    /// colours, light and dark, a slider moves its value, and the system
    /// prompt's page and field are the same paper and card (REDESIGN config
    /// lines, SHOT redesign-*-config-*).
    @MainActor func testConfigSheetOnPaperLight() { configSheetOnPaper(dark: false) }
    @MainActor func testConfigSheetOnPaperDark() { configSheetOnPaper(dark: true) }

    @MainActor private func configSheetOnPaper(dark: Bool) {
        continueAfterFailure = false
        let scheme = dark ? "dark" : "light"
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--developer-settings"] + (dark ? ["--dark"] : [])
        app.launch()
        let open = app.buttons["chat-model-settings"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        open.tap()
        let tabs = app.segmentedControls["configuration-tabs"]
        XCTAssertTrue(tabs.waitForExistence(timeout: 4))
        let field = app.textFields["setting-Max Tokens"]
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-\(scheme)-config-model", app: app)
        guard let shot = XCUIScreen.main.screenshot().image.cgImage,
              let screen = ScreenArea(shot, app.frame, screenWidth: app.frame.width) else { return XCTFail("No screenshot") }
        // Beside the first card, and inside it left of its words.
        let page = screen.meanColour(in: CGRect(x: 3, y: field.frame.midY - 3, width: 6, height: 6))
        let card = screen.meanColour(in: CGRect(x: 23, y: field.frame.midY - 3, width: 6, height: 6))
        let save = app.buttons["configuration-save"].frame
        let check = screen.meanColour(in: save.insetBy(dx: save.width * 0.3, dy: save.height * 0.3))
        let ring = screen.meanColour(in: CGRect(x: save.minX + 3, y: save.midY - 2, width: 4, height: 4))
        print(String(format: "REDESIGN config %@: page %.0f,%.0f,%.0f card %.0f,%.0f,%.0f save middle %.0f,%.0f,%.0f edge %.0f,%.0f,%.0f",
                     scheme, page.red, page.green, page.blue, card.red, card.green, card.blue,
                     check.red, check.green, check.blue, ring.red, ring.green, ring.blue))
        checkPaper(page: page, card: card, dark: dark, name: "モデル構成")

        // A slider moves its value.
        let slider = app.sliders.firstMatch
        XCTAssertTrue(slider.waitForExistence(timeout: 3))
        let before = field.value as? String
        slider.adjust(toNormalizedSliderPosition: 0.15)
        Thread.sleep(forTimeInterval: 0.6)
        let after = field.value as? String
        print("REDESIGN config \(scheme): Max Tokens \(before ?? "?") -> \(after ?? "?")")
        XCTAssertNotEqual(before, after, "The slider sets the value")
        capture("redesign-\(scheme)-config-slider", app: app)
        // The developer settings further down: switches and segmented controls on the cards.
        app.swipeUp()
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-\(scheme)-config-developer", app: app)

        tabs.buttons["システムプロンプト"].tap()
        let prompt = app.textViews["system-prompt-input"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-\(scheme)-config-prompt", app: app)
        guard let second = XCUIScreen.main.screenshot().image.cgImage,
              let promptScreen = ScreenArea(second, app.frame, screenWidth: app.frame.width) else { return XCTFail("No screenshot") }
        let box = prompt.frame
        let promptPage = promptScreen.meanColour(in: CGRect(x: 3, y: box.midY - 3, width: 6, height: 6))
        let promptCard = promptScreen.meanColour(in: CGRect(x: box.minX + 4, y: box.maxY - 14, width: 8, height: 6))
        print(String(format: "REDESIGN config %@ prompt: page %.0f,%.0f,%.0f field %.0f,%.0f,%.0f", scheme,
                     promptPage.red, promptPage.green, promptPage.blue, promptCard.red, promptCard.green, promptCard.blue))
        checkPaper(page: promptPage, card: promptCard, dark: dark, name: "システムプロンプト")
        app.buttons["configuration-cancel"].tap()
        XCTAssertTrue(gone(tabs), "キャンセル closes the sheet")
    }

    /// Fielua's paper and card, not iOS's cool greys: warm (more red than
    /// blue), the card lighter than the page by day and raised at night.
    private func checkPaper(page: (red: Double, green: Double, blue: Double), card: (red: Double, green: Double, blue: Double),
                            dark: Bool, name: String) {
        func luma(_ c: (red: Double, green: Double, blue: Double)) -> Double { 0.299 * c.red + 0.587 * c.green + 0.114 * c.blue }
        if dark {
            XCTAssertGreaterThanOrEqual(page.red - page.blue, 1, "\(name): the page is warm charcoal")
            XCTAssertLessThan(luma(page), 30, "\(name): the page is dark")
            XCTAssertGreaterThanOrEqual(card.red - card.blue, 3, "\(name): the card is warm charcoal")
            XCTAssertGreaterThan(luma(card) - luma(page), 6, "\(name): the card is raised")
        } else {
            XCTAssertGreaterThanOrEqual(page.red - page.blue, 6, "\(name): the page is warm paper")
            XCTAssertGreaterThanOrEqual(card.red - card.blue, 3, "\(name): the card is warm white")
            XCTAssertGreaterThan(luma(card) - luma(page), 4, "\(name): the card stands out from the page")
        }
    }

    /// The developer tools' sheets (GPU起動テスト here) on the same paper.
    @MainActor func testDeveloperTestSheetOnPaper() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--developer-settings"]
        app.launch()
        openSettingsFromChat(app)
        openSettingsRow("developer", title: "開発者設定", app: app)
        let button = app.buttons["open-gpu-test"]
        XCTAssertTrue(button.waitForExistence(timeout: 4))
        let list = app.scrollViews["developer-list"]
        var tries = 0
        while !button.isHittable && tries < 6 {
            list.swipeUp(velocity: .slow)
            tries += 1
        }
        button.tap()
        let run = app.buttons["run-gpu-test"]
        XCTAssertTrue(run.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.8)
        capture("redesign-light-developer-gpu-test", app: app)
        guard let shot = XCUIScreen.main.screenshot().image.cgImage,
              let screen = ScreenArea(shot, app.frame, screenWidth: app.frame.width) else { return XCTFail("No screenshot") }
        let page = screen.meanColour(in: CGRect(x: 3, y: run.frame.midY - 3, width: 6, height: 6))
        let card = screen.meanColour(in: CGRect(x: 23, y: run.frame.midY - 3, width: 6, height: 6))
        print(String(format: "REDESIGN config gpu test: page %.0f,%.0f,%.0f card %.0f,%.0f,%.0f",
                     page.red, page.green, page.blue, card.red, card.green, card.blue))
        checkPaper(page: page, card: card, dark: false, name: "GPU起動テスト")
    }

    /// 文言の整理 (2026-10-24): the everyday chat with its new words, for
    /// review (SHOT wording-*): the plus menu, an empty chat that shows only
    /// the model's name, the model menu, the orb with no status line under
    /// it, a reply stopped before its first text, the web search note, and
    /// a reply stopped partway. Two launches, to stay in a test's 120 s.
    @MainActor func testWordingChatScreens() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--orb-wait", "--web-search-no-key"]; app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        XCTAssertTrue(menuItem("新しいチャット", "新しいチャット", app).waitForExistence(timeout: 3))
        XCTAssertFalse(menuItem("設定", "設定", app).exists, "No 設定 in the plus menu (1.1.0 (224))")
        XCTAssertFalse(menuItem("会話一覧", "会話一覧", app).exists, "No 会話一覧 in the plus menu (1.1.0 (224))")
        Thread.sleep(forTimeInterval: 0.6)
        capture("wording-plus-menu", app: app)
        chooseMenuAction("新しいチャット", app: app)
        XCTAssertTrue(app.descendants(matching: .any)["chat-empty"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["メッセージを送って会話を始めましょう"].exists)
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        print("WORDING placeholder: \(input.placeholderValue ?? "-") value: \(input.value as? String ?? "-")")
        capture("wording-empty-chat", app: app)
        let chip = app.buttons["composer-model"]
        if chip.waitForExistence(timeout: 3) {
            chip.tap()
            let gemma = menuItem("model-menu-gemma", "Gemma", app)
            XCTAssertTrue(gemma.waitForExistence(timeout: 3))
            gemma.tap()
            let e2b = menuItem("model-menu-gemma-4-e2b", "Gemma 4 E2B", app)
            XCTAssertTrue(e2b.waitForExistence(timeout: 3))
            print("WORDING model menu E2B: \(e2b.label)")
            Thread.sleep(forTimeInterval: 0.8)
            capture("wording-model-menu", app: app)
            dismissMenu(e2b, app: app)
        } else {
            print("WORDING model chip not shown in an empty chat")
        }
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        // The orb alone while the reply waits (preview --orb-wait: 9 s),
        // with no words under it; one query while it draws.
        Thread.sleep(forTimeInterval: 2.5)
        let waiting = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        waiting.name = "wording-orb-waiting"; waiting.lifetime = .keepAlways; add(waiting)
        XCTAssertFalse(app.staticTexts["UI検証用のサンプルを表示しています…"].exists, "No status line under the orb")
        let stop = app.buttons["停止する"]
        XCTAssertTrue(stop.waitForExistence(timeout: 3))
        stop.tap()
        // Said once, in the reply's place (the screenshot shows it; the
        // row's combined element and its text may both carry the words).
        XCTAssertTrue(app.staticTexts["停止しました"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["回答を停止しました"].exists)
        XCTAssertFalse(app.staticTexts["停止した回答"].exists)
        print("WORDING stopped-empty elements: \(app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "停止しました")).allElementsBoundByIndex.map { "\($0.elementType.rawValue)@\(Int($0.frame.minY))" })")
        capture("wording-stopped-empty", app: app)
        plus.tap()
        let search = webSearchItem(app)
        XCTAssertTrue(search.waitForExistence(timeout: 3))
        print("WORDING web search item: \(search.label)")
        capture("wording-plus-menu-after-reply", app: app)
        search.tap()
        // The note's title since 1.1.0 (207), its message since 224.
        let note = app.alerts["ウェブ検索にはTavilyへの接続が必要です"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        XCTAssertTrue(note.staticTexts["設定でTavilyに登録またはログインしてください。"].exists)
        capture("wording-web-search-note", app: app)
        note.buttons["キャンセル"].tap()

        // A long reply (--layout-stress: twelve paragraphs 0.7 s apart),
        // stopped once its first paragraph shows.
        app.terminate(); app.launchArguments = ["--reset-settings", "--layout-stress"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap(); chooseMenuAction("新しいチャット", app: app)
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("途中で止める")
        app.buttons["送信する"].tap()
        let partial = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "レイアウト検証1")).firstMatch
        XCTAssertTrue(partial.waitForExistence(timeout: 8))
        stop.tap()
        // The text written so far, with 停止しました under it.
        XCTAssertTrue(app.staticTexts["停止しました"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.2)
        print("WORDING stopped partway: \(partial.label)")
        capture("wording-stopped-partial", app: app)
    }

    /// 文言の整理 (2026-10-24): 設定's pages and the model's settings with
    /// their new words, and the welcome, for review (SHOT wording-*).
    @MainActor func testWordingSettingsScreens() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        openSettingsFromChat(app)
        XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        capture("wording-settings-home", app: app)
        openSettingsRow("models", title: "モデル管理", app: app)
        Thread.sleep(forTimeInterval: 0.8)
        capture("wording-settings-models", app: app)
        let list = app.scrollViews["model-list"]
        for index in 1...3 {
            list.swipeUp(); Thread.sleep(forTimeInterval: 0.8)
            capture("wording-settings-models-\(index)", app: app)
        }
        app.buttons["settings-back"].tap()
        openSettingsRow("notifications", title: "通知", app: app)
        Thread.sleep(forTimeInterval: 0.8)
        capture("wording-settings-notifications", app: app)
        app.buttons["settings-back"].tap()
        openSettingsRow("about", title: "Fieluaの情報", app: app)
        Thread.sleep(forTimeInterval: 0.8)
        capture("wording-settings-about", app: app)
        app.buttons["settings-close"].tap()
        openConfiguration(app)
        Thread.sleep(forTimeInterval: 0.6)
        capture("wording-configuration", app: app)
        app.segmentedControls["configuration-tabs"].buttons["システムプロンプト"].tap()
        Thread.sleep(forTimeInterval: 0.6)
        capture("wording-system-prompt", app: app)
        app.buttons["キャンセル"].tap()

        app.terminate(); app.launchArguments = ["--startup", "--reset-startup"]; app.launch()
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.2)
        capture("wording-welcome", app: app)
        welcome.tap()
        XCTAssertTrue(app.buttons["onboarding-model-continue"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        capture("wording-welcome-lower", app: app)
    }

    /// A sent photo stands on its own (2026-10-25): no bubble behind it, at
    /// its own shape with rounded corners, above the text's bubble with its
    /// edge in line, and a tap still opens it. Light and dark as SHOT
    /// composer-sent-photo-*, the frames as SENT-PHOTO lines.
    @MainActor func testSentPhotoStandsWithoutABubble() {
        continueAfterFailure = false
        for dark in [false, true] {
            let name = dark ? "dark" : "light"
            let app = PreviewApp()
            app.launchArguments = ["--e2b", "--attachment-fixtures"] + (dark ? ["--dark"] : [])
            app.launch()
            importFixture("sample-image", extension: "png", app: app)
            let input = app.textViews["chat-input"]
            input.tap(); input.typeText("Photo check")
            app.buttons["送信する"].tap()
            // The preview answers a photo in two short pieces, over before
            // 停止する can be seen; its words say the reply has ended.
            let reply = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "添付の読み込み確認")).firstMatch
            XCTAssertTrue(reply.waitForExistence(timeout: 10), "The reply ends")
            let photo = app.buttons["添付ファイルを開く: sample-image.png"]
            XCTAssertTrue(photo.waitForExistence(timeout: 5))
            let text = app.staticTexts["Photo check"]
            let window = app.windows.firstMatch.frame
            print("SENT-PHOTO \(name) photo=\(photo.frame) text=\(text.exists ? "\(text.frame)" : "none") window=\(window)")
            XCTAssertLessThanOrEqual(photo.frame.width, 221, "Within the photo's box")
            XCTAssertLessThanOrEqual(photo.frame.height, 261, "Within the photo's box")
            XCTAssertGreaterThan(photo.frame.midX, window.midX, "On the sender's side")
            if text.exists {
                XCTAssertLessThanOrEqual(photo.frame.maxY, text.frame.minY, "Above the text's bubble")
            }
            Thread.sleep(forTimeInterval: 0.6)
            capture("composer-sent-photo-\(name)", app: app)
            photo.tap()
            let done = app.buttons["閉じる"]
            XCTAssertTrue(done.waitForExistence(timeout: 5), "A tap still opens the photo")
            Thread.sleep(forTimeInterval: 0.6)
            capture("composer-sent-photo-preview-\(name)", app: app)
            done.tap()
            XCTAssertTrue(gone(done))
            // Sent with nothing typed (1.1.0 (198)): the photo alone, and
            // not the ask written for it, which only the model gets.
            importFixture("sample-image", extension: "png", app: app)
            XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "draft-attachments").firstMatch.waitForExistence(timeout: 5))
            app.buttons["送信する"].tap()
            let replies = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "添付の読み込み確認"))
            let deadline = Date().addingTimeInterval(10)
            while replies.count < 2 && Date() < deadline { Thread.sleep(forTimeInterval: 0.2) }
            XCTAssertEqual(replies.count, 2, "The second reply ends")
            XCTAssertFalse(app.staticTexts["添付した内容を説明してください。"].exists, "The ask is not shown")
            let photos = app.buttons.matching(NSPredicate(format: "label == %@", "添付ファイルを開く: sample-image.png"))
            let alone = photos.element(boundBy: photos.count - 1)
            print("SENT-PHOTO-ALONE \(name) photo=\(alone.frame) photos=\(photos.count) window=\(window)")
            XCTAssertLessThanOrEqual(alone.frame.width, 221, "Within the photo's box")
            XCTAssertGreaterThan(alone.frame.midX, window.midX, "On the sender's side")
            Thread.sleep(forTimeInterval: 0.6)
            capture("composer-sent-photo-alone-\(name)", app: app)
            app.terminate()
        }
    }

    /// オープンソースライセンス fades in with its rows already in place
    /// (2026-10-25): the slide is cut from the session recording (MENU-MARK
    /// settings-licenses-in-*), the rows' frames are printed as LICENSES
    /// lines as the page lands and after it rested, and the page as SHOT
    /// settings-licenses-*.
    @MainActor func testLicensesPageFadesInWithItsRowsInPlace() {
        continueAfterFailure = false
        for dark in [false, true] {
            let name = dark ? "dark" : "light"
            let app = PreviewApp(); app.launchArguments = ["--reset-settings"] + (dark ? ["--dark"] : []); app.launch()
            openSettingsFromHistory(app)
            Thread.sleep(forTimeInterval: 1)
            let row = app.buttons["settings-row-licenses"]
            XCTAssertTrue(row.waitForExistence(timeout: 5))
            menuMark("settings-licenses-in-\(name)")
            row.tap()
            XCTAssertTrue(app.navigationBars["オープンソースライセンス"].waitForExistence(timeout: 4))
            let rows = OpenSourceLicenseFiles.all.map { app.buttons["license-\($0)"] }
            let landed = rows.map(\.frame)
            Thread.sleep(forTimeInterval: 1.5)
            let rested = rows.map(\.frame)
            print("LICENSES \(name) landed=\(landed) rested=\(rested)")
            XCTAssertTrue(rows.allSatisfy(\.exists), "Every license has its row")
            for (a, b) in zip(landed, rested) {
                XCTAssertEqual(a.minY, b.minY, accuracy: 0.5, "A row stays where it landed")
                XCTAssertEqual(a.height, b.height, accuracy: 0.5, "A row keeps its height")
            }
            for (upper, lower) in zip(rested, rested.dropFirst()) {
                XCTAssertLessThanOrEqual(upper.maxY, lower.minY + 1, "The rows in order, apart")
            }
            capture("settings-licenses-\(name)", app: app)
            rows[0].tap()
            XCTAssertTrue(app.descendants(matching: .any)["license-text"].waitForExistence(timeout: 4), "A row opens its text")
            app.terminate()
        }
    }

    /// 入力欄のタイプ's phones (2026-10-24): スタンダード and スマート side by
    /// side, playing on one clock while 入力スタイル is in view (its own page
    /// under キーボードと入力 since 1.1.0 (191)). The app opens the page by
    /// itself 4 s after the sheet (`--keyboard-preview-demo`) and
    /// nothing is asked of it while they play, since a query waits for the
    /// app's animations: screenshots as quick as they come for one loop and
    /// a half, cropped to the phones and stacked twelve to a sheet with
    /// their times (SHOT settings-keyboard-preview-frames-light-N). The
    /// demo stands still after about two loops; then a tap on スタンダード's
    /// phone chooses it, and it is still chosen after a relaunch, through
    /// the rows キーボードと入力 and 入力スタイル.
    @MainActor func testComposerStylePreviewsPlayTogether() {
        continueAfterFailure = false
        let app = keyboardPreviewFrames("light", arguments: ["--reset-settings", "--keyboard-preview-demo"], seconds: 12)
        XCTAssertTrue(app.navigationBars["入力スタイル"].exists, "The demo opened 入力スタイル")
        let folding = app.buttons["composer-style-folding"], classic = app.buttons["composer-style-classic"]
        XCTAssertTrue(folding.waitForExistence(timeout: 6))
        XCTAssertEqual(folding.label, "スマート")
        XCTAssertEqual(classic.label, "スタンダード")
        XCTAssertTrue(folding.isSelected, "スマート until another is chosen")
        XCTAssertFalse(classic.isSelected)
        print("KEYBOARD-PREVIEW folding=\(folding.frame) classic=\(classic.frame)")
        XCTAssertEqual(folding.frame.width, classic.frame.width, accuracy: 1, "The same size")
        XCTAssertEqual(folding.frame.minY, classic.frame.minY, accuracy: 1, "Side by side")
        XCTAssertLessThan(classic.frame.maxX, folding.frame.minX, "スタンダード first")
        capture("settings-keyboard-preview-light", app: app)
        print("KEYBOARD-PREVIEW before tap hittable=\(classic.isHittable) title=\(app.navigationBars.firstMatch.identifier)")
        classic.tap()
        let chosen = XCTNSPredicateExpectation(predicate: NSPredicate(format: "isSelected == true"), object: classic)
        let tapped = XCTWaiter().wait(for: [chosen], timeout: 3) == .completed
        print("KEYBOARD-PREVIEW after tap classic=\(classic.isSelected) folding=\(folding.isSelected)")
        capture("settings-keyboard-preview-classic-chosen", app: app)
        XCTAssertTrue(tapped, "A tap on the phone chooses its type")
        XCTAssertFalse(folding.isSelected)
        app.terminate(); app.launchArguments = ["--keep-composer-style"]; app.launch()
        openSettingsFromHistory(app)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        openSettingsRow("composerStyle", title: "入力スタイル", app: app)
        XCTAssertTrue(app.buttons["composer-style-classic"].isSelected, "The choice is kept")
    }

    /// The same in dark mode, one loop.
    @MainActor func testComposerStylePreviewsDark() {
        continueAfterFailure = false
        let app = keyboardPreviewFrames("dark", arguments: ["--reset-settings", "--keyboard-preview-demo", "--dark"],
                                        seconds: 10.5)
        XCTAssertTrue(app.buttons["composer-style-folding"].waitForExistence(timeout: 6))
        capture("settings-keyboard-preview-dark", app: app)
    }

    /// With Reduce Motion each phone holds still on what tells the two
    /// apart: スマート's three buttons, スタンダード's field with the latest
    /// button above it, and the finger's way down.
    @MainActor func testComposerStylePreviewsReduceMotion() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--keyboard-preview-demo", "--reduce-motion"]; app.launch()
        openSettingsFromHistory(app)
        XCTAssertTrue(app.navigationBars["入力スタイル"].waitForExistence(timeout: 8))
        let folding = app.buttons["composer-style-folding"], classic = app.buttons["composer-style-classic"]
        XCTAssertTrue(folding.waitForExistence(timeout: 3))
        XCTAssertTrue(folding.isSelected)
        Thread.sleep(forTimeInterval: 1)
        capture("settings-keyboard-preview-reduced", app: app)
        classic.tap()
        XCTAssertTrue(classic.isSelected)
        XCTAssertFalse(folding.isSelected)
    }

    /// キーボードと入力 as two rows (user, 2026-10-25 22:47 UTC, 1.1.0 (191)):
    /// 入力スタイル and 起動時のチャット, each with what is chosen and no phones.
    /// Each row opens its page, whose two phones stand side by side and fit
    /// it whole with their words, and back; a choice there shows on its row
    /// at once and is kept after a relaunch. A swipe to the right goes back
    /// from a page to the rows. KEYBOARD-SETTINGS lines, SHOT
    /// settings-keyboard-list-*, -style-*, -launch-*.
    @MainActor func testKeyboardSettingsListOpensEachChoice() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        openSettingsFromHistory(app)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        let styleRow = app.buttons["settings-row-composerStyle"], launchRow = app.buttons["settings-row-launchChat"]
        XCTAssertTrue(styleRow.waitForExistence(timeout: 3) && launchRow.exists)
        print("KEYBOARD-SETTINGS list style='\(styleRow.label)' '\(styleRow.value as? String ?? "")' \(styleRow.frame) "
              + "launch='\(launchRow.label)' '\(launchRow.value as? String ?? "")' \(launchRow.frame)")
        XCTAssertEqual(styleRow.label, "入力スタイル")
        XCTAssertEqual(styleRow.value as? String, "スマート")
        XCTAssertEqual(launchRow.label, "起動時のチャット")
        XCTAssertEqual(launchRow.value as? String, "前回の会話")
        XCTAssertLessThanOrEqual(styleRow.frame.maxY, launchRow.frame.minY + 1, "入力スタイル first")
        XCTAssertFalse(app.buttons["composer-style-folding"].exists, "No phones on the rows' page")
        XCTAssertFalse(app.buttons["launch-chat-resume"].exists)
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-keyboard-list-light", app: app)

        // 入力スタイル: its phones, a choice, and back to the rows.
        let window = app.windows.firstMatch.frame
        openSettingsRow("composerStyle", title: "入力スタイル", app: app)
        let classic = app.buttons["composer-style-classic"], folding = app.buttons["composer-style-folding"]
        XCTAssertTrue(folding.waitForExistence(timeout: 3) && folding.isSelected)
        let styleCaption = app.staticTexts["スクロールすると、入力欄が3つの丸いボタンに分かれます。"]
        print("KEYBOARD-SETTINGS style classic=\(classic.frame) folding=\(folding.frame) "
              + "caption=\(styleCaption.exists ? styleCaption.frame : .zero) window=\(window)")
        XCTAssertEqual(classic.frame.minY, folding.frame.minY, accuracy: 1, "Side by side")
        XCTAssertLessThan(classic.frame.maxX, folding.frame.minX, "スタンダード first")
        XCTAssertTrue(styleCaption.exists && styleCaption.frame.maxY < window.maxY - 20, "Whole on the page, no scroll")
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-keyboard-style-light", app: app)
        classic.tap()
        XCTAssertTrue(classic.isSelected && !folding.isSelected)
        app.buttons["settings-back"].tap()
        XCTAssertTrue(gone(app.navigationBars["入力スタイル"]))
        XCTAssertTrue(app.navigationBars["キーボードと入力"].waitForExistence(timeout: 4))
        XCTAssertEqual(styleRow.value as? String, "スタンダード", "The row shows the choice at once")

        // 起動時のチャット likewise.
        openSettingsRow("launchChat", title: "起動時のチャット", app: app)
        let resume = app.buttons["launch-chat-resume"], newChat = app.buttons["launch-chat-newChat"]
        XCTAssertTrue(resume.waitForExistence(timeout: 3) && resume.isSelected)
        let launchCaption = app.staticTexts["最後に開いていた会話を、入力途中の文章ごと表示します。"]
        print("KEYBOARD-SETTINGS launch resume=\(resume.frame) new=\(newChat.frame) "
              + "caption=\(launchCaption.exists ? launchCaption.frame : .zero)")
        XCTAssertEqual(resume.frame.minY, newChat.frame.minY, accuracy: 1, "Side by side")
        XCTAssertLessThan(resume.frame.maxX, newChat.frame.minX, "前回の会話 on the left")
        XCTAssertTrue(launchCaption.exists && launchCaption.frame.maxY < window.maxY - 20, "Whole on the page, no scroll")
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-keyboard-launch-light", app: app)
        newChat.tap()
        XCTAssertTrue(newChat.isSelected && !resume.isSelected)
        // A swipe to the right goes back, as from the six rows' pages.
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.12, dy: 0.62))
        start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: app.frame.width * 0.6, dy: 0)),
                    withVelocity: .slow, thenHoldForDuration: 0.2)
        XCTAssertTrue(gone(app.navigationBars["起動時のチャット"]), "A swipe to the right goes back")
        XCTAssertTrue(app.navigationBars["キーボードと入力"].waitForExistence(timeout: 4))
        XCTAssertEqual(launchRow.value as? String, "新しいチャット", "The row shows the choice at once")
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-keyboard-list-chosen", app: app)
        app.buttons["settings-back"].tap()
        XCTAssertTrue(app.buttons["settings-row-keyboard"].waitForExistence(timeout: 4), "Back on the six rows")

        // Both kept after a relaunch, which opens a new chat now.
        app.terminate(); app.launchArguments = ["--keep-composer-style", "--keep-launch-chat"]; app.launch()
        XCTAssertTrue(app.descendants(matching: .any)["chat-empty"].waitForExistence(timeout: 10), "新しいチャット, as chosen")
        openSettingsFromChat(app)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        XCTAssertTrue(styleRow.waitForExistence(timeout: 3))
        XCTAssertEqual(styleRow.value as? String, "スタンダード", "Kept")
        XCTAssertEqual(launchRow.value as? String, "新しいチャット", "Kept")
        openSettingsRow("launchChat", title: "起動時のチャット", app: app)
        XCTAssertTrue(newChat.waitForExistence(timeout: 3) && newChat.isSelected)
    }

    /// Dark, with Reduce Motion so each phone holds its moment: 起動時のチャット's
    /// phones draw the 入力スタイル chosen, スタンダード's plus and one-line
    /// field, and スマート's panel after a change on 入力スタイル's page (1.1.0
    /// (191)). SHOT settings-keyboard-*-dark*.
    @MainActor func testKeyboardSettingsDarkLaunchPhonesFollowTheStyle() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--dark", "--reduce-motion", "--classic-composer"]; app.launch()
        openSettingsFromHistory(app)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        let styleRow = app.buttons["settings-row-composerStyle"]
        XCTAssertTrue(styleRow.waitForExistence(timeout: 3))
        XCTAssertEqual(styleRow.value as? String, "スタンダード")
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-keyboard-list-dark", app: app)
        openSettingsRow("launchChat", title: "起動時のチャット", app: app)
        XCTAssertTrue(app.buttons["launch-chat-newChat"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1)
        capture("settings-keyboard-launch-dark-standard", app: app)
        app.buttons["settings-back"].tap()
        openSettingsRow("composerStyle", title: "入力スタイル", app: app)
        let folding = app.buttons["composer-style-folding"]
        XCTAssertTrue(folding.waitForExistence(timeout: 3))
        folding.tap()
        XCTAssertTrue(folding.isSelected)
        Thread.sleep(forTimeInterval: 0.8)
        capture("settings-keyboard-style-dark", app: app)
        app.buttons["settings-back"].tap()
        XCTAssertTrue(app.navigationBars["キーボードと入力"].waitForExistence(timeout: 4))
        XCTAssertEqual(styleRow.value as? String, "スマート")
        openSettingsRow("launchChat", title: "起動時のチャット", app: app)
        XCTAssertTrue(app.buttons["launch-chat-newChat"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1)
        capture("settings-keyboard-launch-dark-smart", app: app)
    }

    /// 起動時のチャット's phones on 設定's page (1.1.0 (191)), opened by the app
    /// itself (`--launch-settings-demo`) with nothing asked of it while they
    /// play: both open Fielua from the home screen on one clock, as on the
    /// setup's page, in the 入力スタイル chosen (スマート). Frames as SHOT
    /// settings-keyboard-preview-frames-launch-N.
    @MainActor func testLaunchChatSettingsPreviewsPlay() {
        continueAfterFailure = false
        let app = keyboardPreviewFrames("launch", arguments: ["--reset-settings", "--launch-settings-demo"], seconds: 12.5,
                                        rest: 22.5)
        XCTAssertTrue(app.navigationBars["起動時のチャット"].exists, "The demo opened 起動時のチャット")
        let resume = app.buttons["launch-chat-resume"], newChat = app.buttons["launch-chat-newChat"]
        XCTAssertTrue(resume.waitForExistence(timeout: 6) && resume.isSelected)
        XCTAssertFalse(newChat.isSelected)
        capture("settings-keyboard-launch-after-demo", app: app)
    }

    @MainActor private func keyboardPreviewFrames(_ name: String, arguments: [String], seconds: TimeInterval,
                                                  rest stillAt: TimeInterval = 20.5) -> XCUIApplication {
        let app = PreviewApp(); app.launchArguments = arguments; app.launch()
        openSettingsFromHistory(app)
        // Each screenshot is cut down to the phones' band of the page at
        // once, so a loop's worth of whole screens is never kept.
        func cell(_ shot: XCUIScreenshot) -> UIImage? {
            guard let image = shot.image.cgImage else { return nil }
            let width = CGFloat(image.width), height = CGFloat(image.height)
            let crop = CGRect(x: width * 0.1, y: height * 0.28, width: width * 0.8, height: height * 0.42).integral
            guard let part = image.cropping(to: crop) else { return nil }
            let size = CGSize(width: 400, height: (400 * crop.height / crop.width).rounded())
            let format = UIGraphicsImageRendererFormat()
            format.scale = 1
            return UIGraphicsImageRenderer(size: size, format: format).image { _ in
                UIImage(cgImage: part).draw(in: CGRect(origin: .zero, size: size))
            }
        }
        let started = Date()
        var frames: [(time: Double, image: UIImage)] = []
        while Date().timeIntervalSince(started) < seconds {
            let time = Date().timeIntervalSince(started)
            if let image = cell(XCUIScreen.main.screenshot()) { frames.append((time, image)) }
        }
        print("KEYBOARD-PREVIEW \(name) frames=\(frames.count) over \(String(format: "%.1f", seconds))s")
        let columns = 4, perSheet = 12, label: CGFloat = 18
        for (sheetIndex, start) in stride(from: 0, to: frames.count, by: perSheet).enumerated() {
            let part = Array(frames[start..<min(start + perSheet, frames.count)])
            guard let cellSize = part.first?.image.size else { continue }
            let rows = (part.count + columns - 1) / columns
            let format = UIGraphicsImageRendererFormat()
            format.scale = 1
            let sheetSize = CGSize(width: cellSize.width * CGFloat(columns), height: (cellSize.height + label) * CGFloat(rows))
            let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
                UIColor.black.setFill()
                context.fill(CGRect(origin: .zero, size: sheetSize))
                for (index, frame) in part.enumerated() {
                    let origin = CGPoint(x: CGFloat(index % columns) * cellSize.width,
                                         y: CGFloat(index / columns) * (cellSize.height + label))
                    frame.image.draw(at: CGPoint(x: origin.x, y: origin.y + label))
                    (String(format: "%.2f s", frame.time) as NSString)
                        .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                              withAttributes: [.font: UIFont.systemFont(ofSize: 13), .foregroundColor: UIColor.white])
                }
            }
            let attachment = XCTAttachment(image: sheet)
            attachment.name = "settings-keyboard-preview-frames-\(name)-\(sheetIndex + 1)"
            attachment.lifetime = .keepAlways
            add(attachment)
        }
        // The phones stand still about 14 s after the page came, 4.6 s
        // after the sheet (キーボードと入力 first, since 1.1.0 (191)); only
        // then is the app asked anything.
        let rest = stillAt - Date().timeIntervalSince(started)
        if rest > 0 { Thread.sleep(forTimeInterval: rest) }
        return app
    }

    /// 起動時のチャット 新しいチャット (1.1.0 (182)): a launch opens a new chat
    /// with the keyboard up and 「前回の会話に戻る」 centred over the field;
    /// going to the home screen and back changes nothing; the capsule opens
    /// the chat of before. At the next launch, typing in the new chat puts
    /// it away. Frames as LAUNCH-CHAT lines, screens as SHOT launch-chat-*.
    @MainActor func testLaunchChatNewChatOpensWithTheKeyboardAndAWayBack() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--launch-chat=new"]; app.launch()
        let back = app.buttons["chat-launch-return"], last = app.staticTexts["画面の動きを確認"]
        let empty = app.descendants(matching: .any)["chat-empty"], input = app.textViews["chat-input"]
        let composer = app.descendants(matching: .any)["chat-composer"]
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 6), "The launch brings the keyboard")
        XCTAssertTrue(empty.waitForExistence(timeout: 2), "In a new chat")
        XCTAssertFalse(last.exists)
        XCTAssertEqual(input.value(forKey: "hasKeyboardFocus") as? Bool, true, "The field is ready to type")
        XCTAssertTrue(back.waitForExistence(timeout: 3), "A way back to the chat of before")
        XCTAssertEqual(back.label, "前回の会話に戻る")
        Thread.sleep(forTimeInterval: 0.8)
        let window = app.windows.firstMatch.frame, keyboard = app.keyboards.firstMatch.frame
        print("LAUNCH-CHAT new light capsule=\(back.frame) composer=\(composer.frame) keyboard=\(keyboard) window=\(window)")
        XCTAssertTrue(back.isHittable)
        XCTAssertLessThanOrEqual(back.frame.maxY, composer.frame.minY + 1, "Over the field")
        XCTAssertEqual(back.frame.midX, window.midX, accuracy: 2, "Centred")
        XCTAssertLessThanOrEqual(composer.frame.maxY, keyboard.minY + 1, "The field on the keyboard")
        capture("launch-chat-new-light", app: app)
        // To the home screen and back: the same chat, as it was.
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 1.5)
        app.activate()
        XCTAssertTrue(empty.waitForExistence(timeout: 5), "Coming back keeps the new chat")
        XCTAssertTrue(back.waitForExistence(timeout: 3), "And its way back")
        XCTAssertFalse(last.exists)
        back.tap()
        XCTAssertTrue(last.waitForExistence(timeout: 4), "The chat of before")
        XCTAssertTrue(gone(back))
        XCTAssertFalse(empty.exists)
        Thread.sleep(forTimeInterval: 0.8)
        capture("launch-chat-returned-light", app: app)
        app.terminate(); app.launchArguments = ["--keep-launch-chat"]; app.launch()
        XCTAssertTrue(back.waitForExistence(timeout: 8), "Kept: every launch")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.6)
        input.typeText("新しい質問")
        XCTAssertTrue(gone(back), "Gone once the new chat is typed in")
        Thread.sleep(forTimeInterval: 0.6)
        print("LAUNCH-CHAT typed composer=\(composer.frame)")
        capture("launch-chat-typing-light", app: app)
    }

    /// The same in dark with スタンダード: the capsule above its bar, which the
    /// keyboard has opened into the panel (1.1.0 (255); until 254 above its
    /// pills).
    @MainActor func testLaunchChatNewChatDarkStandard() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--launch-chat=new", "--classic-composer", "--dark"]; app.launch()
        let back = app.buttons["chat-launch-return"]
        let composer = app.descendants(matching: .any)["chat-composer"], model = app.buttons["composer-model"]
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 6))
        XCTAssertTrue(back.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1)
        print("LAUNCH-CHAT new dark standard capsule=\(back.frame) composer=\(composer.frame) model=\(model.frame)")
        XCTAssertGreaterThan(composer.frame.height, 90, "Opened with the keyboard")
        XCTAssertTrue(model.isHittable)
        XCTAssertLessThanOrEqual(back.frame.maxY, composer.frame.minY + 1, "Above スタンダード's panel")
        capture("launch-chat-new-standard-dark", app: app)
    }

    /// 前回の会話 (the setting until another is chosen): a launch opens the
    /// chat last open, here one opened from the history, with the text left
    /// in its field and the keyboard down; coming back from the home screen
    /// leaves it so.
    @MainActor func testLaunchChatResumeOpensTheLastChatWithItsText() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--history-fixture", "--stable-chat-id"]; app.launch()
        let open = app.buttons["会話一覧を開く"], input = app.textViews["chat-input"]
        let latest = app.staticTexts["画面の動きを確認"], older = app.staticTexts["夕飯のレシピ"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        XCTAssertTrue(latest.exists, "The latest chat at first")
        open.tap()
        let row = app.buttons["会話を開く: 夕飯のレシピ"]
        XCTAssertTrue(row.waitForExistence(timeout: 3)); row.tap()
        XCTAssertTrue(older.waitForExistence(timeout: 3))
        input.tap(); input.typeText("材料も教えて")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 1.5)
        app.terminate()
        app.launchArguments = ["--keep-launch-chat", "--history-fixture", "--stable-chat-id"]; app.launch()
        XCTAssertTrue(older.waitForExistence(timeout: 10), "The chat last open")
        XCTAssertFalse(latest.exists)
        Thread.sleep(forTimeInterval: 1)
        print("LAUNCH-CHAT resume field=\(input.value ?? "")")
        XCTAssertEqual(input.value as? String, "材料も教えて", "With the text left in its field")
        XCTAssertFalse(app.keyboards.firstMatch.exists, "前回の会話: the keyboard stays down")
        XCTAssertFalse(app.buttons["chat-launch-return"].exists)
        capture("launch-chat-resume-light", app: app)
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 1.5)
        app.activate()
        XCTAssertTrue(older.waitForExistence(timeout: 5), "Coming back changes nothing")
        XCTAssertEqual(input.value as? String, "材料も教えて")
    }

    /// 1.1.0 (181)'s 「起動時にキーボードを開いておく」 carries over (1.1.0
    /// (182)): on, the phone opens in 新しいチャット, and キーボードと入力 shows
    /// 起動時のチャット with 新しいチャット chosen, on its row and on its page
    /// (1.1.0 (191)), with no switch left to contradict it. A choice there
    /// is kept, this launch staying as it is; off carries over as 前回の会話.
    /// 設定 with the keyboard up (user's recording, 2026-10-26 16:01 UTC: now
    /// and then the rows grew from a sliver to their width as the sheet
    /// rose), from the model menu's モデルを管理 since the plus menu lost its
    /// 設定 (1.1.0 (224)). Each opening is cut from the session recording
    /// (MENU-MARK, SHOT composer-video-settings-open-*): as before (the sheet
    /// taking the keyboard, its rows free to animate), with one of the two
    /// changes alone, and as now; as now also 構成 from the header with the
    /// keyboard up, and 設定 without it. SETTINGS-OPEN lines: the rows' frame
    /// and the keyboard once the sheet has closed.
    @MainActor func testSettingsOpensWholeWithTheKeyboardUp() {
        continueAfterFailure = false
        let settings = (menu: "composer-model", id: "model-menu-manage", title: "モデルを管理")
        let variants: [(name: String, flags: [String], rounds: Int)] = [
            ("before", ["--settings-open-keep-keyboard", "--settings-open-animated"], 2),
            ("still-only", ["--settings-open-keep-keyboard"], 1),
            ("keyboard-only", ["--settings-open-animated"], 1),
            ("now", [], 2)]
        for variant in variants {
            let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--launch-chat=new"] + variant.flags; app.launch()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 8), "The launch brings the keyboard")
            Thread.sleep(forTimeInterval: 0.8)
            for round in 1...variant.rounds {
                settingsOpening("settings-open-\(variant.name)-\(round)", from: settings, app: app)
            }
            if variant.name == "now" {
                // 構成 from the header, which put the keyboard down first already.
                let input = app.textViews["chat-input"]
                if !app.keyboards.firstMatch.exists { input.tap() }
                XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 4))
                Thread.sleep(forTimeInterval: 0.8)
                menuMark("settings-open-now-config")
                app.buttons["chat-model-settings"].tap()
                let tabs = app.segmentedControls["configuration-tabs"]
                XCTAssertTrue(tabs.waitForExistence(timeout: 5))
                Thread.sleep(forTimeInterval: 2.6)
                print("SETTINGS-OPEN settings-open-now-config tabs=\(tabs.frame)")
                app.buttons["キャンセル"].tap()
                XCTAssertTrue(gone(tabs, timeout: 4))
            }
            app.terminate()
        }
        // Without the keyboard: as it opened before.
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        XCTAssertTrue(app.buttons[settings.menu].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        settingsOpening("settings-open-plain", from: settings, app: app, keyboard: false)
    }

    /// The same opening asked for inside an animation, a stand-in for the
    /// keyboard's fall (on the simulator the keyboard is down before the
    /// sheet comes, so the recording above never caught it): the rows free
    /// to animate, then as now. SHOT composer-video-settings-anim-*.
    @MainActor func testSettingsOpenedInsideAnAnimation() {
        continueAfterFailure = false
        let settings = (menu: "composer-model", id: "model-menu-manage", title: "モデルを管理")
        for (name, flags) in [("before", ["--settings-open-animated"]), ("now", [])] {
            let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--settings-open-in-animation"] + flags; app.launch()
            XCTAssertTrue(app.buttons[settings.menu].waitForExistence(timeout: 10))
            Thread.sleep(forTimeInterval: 0.8)
            settingsOpening("settings-anim-\(name)", from: settings, app: app, keyboard: false)
            app.terminate()
        }
    }

    /// Opens 設定 from a menu at a mark, waits out the recording's span, and
    /// closes it again.
    @MainActor private func settingsOpening(_ name: String, from: (menu: String, id: String, title: String),
                                            app: XCUIApplication, keyboard: Bool = true) {
        let input = app.textViews["chat-input"]
        if keyboard {
            if !app.keyboards.firstMatch.exists { input.tap() }
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 4), "\(name): the keyboard is up")
            Thread.sleep(forTimeInterval: 0.6)
        } else {
            XCTAssertFalse(app.keyboards.firstMatch.exists, "\(name): no keyboard")
        }
        app.buttons[from.menu].tap()
        let item = menuItem(from.id, from.title, app)
        XCTAssertTrue(item.waitForExistence(timeout: 3), "\(name): \(from.title) in the menu")
        for _ in 0..<4 where !item.isHittable { app.collectionViews.firstMatch.swipeUp() }
        Thread.sleep(forTimeInterval: 0.8)
        menuMark(name)
        item.tap()
        let close = app.buttons["settings-close"]
        XCTAssertTrue(close.waitForExistence(timeout: 5), "\(name): 設定 is open")
        // Past the frames cut from the recording (3 s from the mark).
        Thread.sleep(forTimeInterval: 2.6)
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH %@", "settings-row-")).allElementsBoundByIndex
            .prefix(2).map(\.frame)
        let models = app.navigationBars["モデル管理"].exists
        if name.hasSuffix("now-1") || name.hasSuffix("plain") { capture(name, app: app) }
        close.tap()
        XCTAssertTrue(gone(close, timeout: 4), "\(name): closed")
        Thread.sleep(forTimeInterval: 1.2)
        let focus = input.value(forKey: "hasKeyboardFocus") as? Bool ?? false
        print("SETTINGS-OPEN \(name) rows=\(rows) models-page=\(models) keyboard-after=\(app.keyboards.firstMatch.exists) focus-after=\(focus)")
    }

    @MainActor func testLaunchChatCarriesOverTheKeyboardSwitch() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--legacy-keyboard-at-launch"]; app.launch()
        let last = app.staticTexts["画面の動きを確認"], empty = app.descendants(matching: .any)["chat-empty"]
        let back = app.buttons["chat-launch-return"]
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 6), "On: a new chat with the keyboard, as before")
        XCTAssertTrue(empty.exists)
        XCTAssertTrue(back.waitForExistence(timeout: 3))
        openSettingsFromChat(app)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        let launchRow = app.buttons["settings-row-launchChat"]
        XCTAssertTrue(launchRow.waitForExistence(timeout: 3))
        XCTAssertEqual(launchRow.value as? String, "新しいチャット", "On became 新しいチャット, on its row")
        XCTAssertFalse(app.buttons["composer-style-folding"].exists, "The phones are on their own pages")
        XCTAssertFalse(app.switches["keyboard-at-launch-toggle"].exists, "No switch to contradict the choice")
        openSettingsRow("launchChat", title: "起動時のチャット", app: app)
        let resume = app.buttons["launch-chat-resume"], newChat = app.buttons["launch-chat-newChat"]
        XCTAssertTrue(newChat.waitForExistence(timeout: 3))
        XCTAssertTrue(newChat.isSelected, "On became 新しいチャット")
        XCTAssertFalse(resume.isSelected)
        Thread.sleep(forTimeInterval: 0.6)
        print("LAUNCH-CHAT settings resume=\(resume.frame) new=\(newChat.frame)")
        capture("launch-chat-settings-light", app: app)
        resume.tap()
        XCTAssertTrue(resume.isSelected && !newChat.isSelected)
        app.buttons["settings-close"].tap()
        XCTAssertTrue(gone(app.navigationBars["起動時のチャット"]))
        XCTAssertTrue(empty.exists, "This launch stays as it is")
        app.terminate(); app.launchArguments = ["--keep-launch-chat"]; app.launch()
        XCTAssertTrue(last.waitForExistence(timeout: 10), "前回の会話, as chosen")
        Thread.sleep(forTimeInterval: 1.5)
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        XCTAssertFalse(back.exists)
        openSettingsFromChat(app)
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        XCTAssertTrue(launchRow.waitForExistence(timeout: 3))
        XCTAssertEqual(launchRow.value as? String, "前回の会話")
        openSettingsRow("launchChat", title: "起動時のチャット", app: app)
        XCTAssertTrue(resume.waitForExistence(timeout: 3) && resume.isSelected, "The choice is kept")
        app.terminate(); app.launchArguments = ["--legacy-keyboard-at-launch=off"]; app.launch()
        XCTAssertTrue(last.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.5)
        XCTAssertFalse(app.keyboards.firstMatch.exists, "Off: the chat as it was")
        XCTAssertFalse(back.exists)
    }

    /// 起動時のチャット's phones on the setup's page (1.1.0 (182)), opened on
    /// it (`--onboarding-step=launch`): both open Fielua from the home screen
    /// on one clock, then 前回の会話's conversation stands beside 新しいチャット's
    /// keyboard and capsule. Nothing is asked of the app while they play:
    /// screenshots as quick as they come for a loop and more, cut down to
    /// the phones, twelve to a sheet with their times (SHOT
    /// launch-chat-preview-frames-light-N), スマート. Then the choice, 続ける
    /// and 準備完了's row.
    @MainActor func testLaunchChatPreviewsPlayTogether() {
        continueAfterFailure = false
        let app = launchPreviewFrames("light", arguments: [], seconds: 10)
        let resume = app.buttons["launch-chat-resume"], newChat = app.buttons["launch-chat-newChat"]
        XCTAssertTrue(newChat.waitForExistence(timeout: 6))
        print("LAUNCH-CHAT preview resume=\(resume.frame) new=\(newChat.frame)")
        XCTAssertEqual(resume.frame.width, newChat.frame.width, accuracy: 1, "The same size")
        XCTAssertEqual(resume.frame.minY, newChat.frame.minY, accuracy: 1, "Side by side")
        XCTAssertLessThan(resume.frame.maxX, newChat.frame.minX, "前回の会話 on the left")
        XCTAssertTrue(resume.isSelected, "前回の会話 until another is chosen")
        capture("launch-chat-preview-light", app: app)
        newChat.tap()
        XCTAssertTrue(newChat.isSelected && !resume.isSelected)
        app.buttons["onboarding-launch-continue"].tap()
        let row = app.descendants(matching: .any)["onboarding-ready-launch"].firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        XCTAssertTrue(row.label.contains("新しいチャット"), row.label)
        capture("launch-chat-preview-ready-light", app: app)
    }

    /// The same in dark with スタンダード, one loop.
    @MainActor func testLaunchChatPreviewsDarkStandard() {
        continueAfterFailure = false
        let app = launchPreviewFrames("dark", arguments: ["--classic-composer", "--dark"], seconds: 8.5)
        XCTAssertTrue(app.buttons["launch-chat-resume"].waitForExistence(timeout: 6))
        capture("launch-chat-preview-dark", app: app)
    }

    /// With Reduce Motion each phone holds what tells the two apart: the
    /// conversation, and the new chat with its keyboard and capsule.
    @MainActor func testLaunchChatPreviewsReduceMotion() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--onboarding-step=launch",
                               "--launch-preview-demo", "--reduce-motion"]
        app.launch()
        let resume = app.buttons["launch-chat-resume"], newChat = app.buttons["launch-chat-newChat"]
        XCTAssertTrue(resume.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1)
        capture("launch-chat-preview-reduced", app: app)
        newChat.tap()
        XCTAssertTrue(newChat.isSelected && !resume.isSelected)
    }

    /// 構成 (user 17:51 UTC 2026-10-25): iOS's checkmark in place of OK, and
    /// モデル構成 and システムプロンプト under one control that stays while they
    /// change, so its glass glides from one to the other. Strips of the tabs
    /// from the tap as SHOT config-tabs-*, screens as SHOT config-*.
    @MainActor func testConfigurationCheckmarkAndTabsGlide() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        app.buttons["chat-model-settings"].tap()
        let save = app.buttons["configuration-save"], tabs = app.segmentedControls["configuration-tabs"]
        XCTAssertTrue(tabs.waitForExistence(timeout: 4))
        XCTAssertTrue(save.exists)
        XCTAssertEqual(save.label, "保存")
        XCTAssertLessThan(abs(save.frame.width - save.frame.height), 12, "A round checkmark: \(save.frame)")
        Thread.sleep(forTimeInterval: 0.6)
        capture("config-sheet-light", app: app)
        let screen = app.frame.height
        let band = (top: (tabs.frame.minY - 24) / screen, height: (tabs.frame.height + 120) / screen)
        tabs.coordinate(withNormalizedOffset: CGVector(dx: 0.75, dy: 0.5)).tap()
        captureStrip("config-tabs-to-prompt", count: 8, top: band.top, height: band.height)
        XCTAssertTrue(app.textViews["system-prompt-input"].waitForExistence(timeout: 3))
        capture("config-prompt-light", app: app)
        tabs.coordinate(withNormalizedOffset: CGVector(dx: 0.25, dy: 0.5)).tap()
        captureStrip("config-tabs-to-model", count: 8, top: band.top, height: band.height)
        XCTAssertTrue(app.textFields["setting-Max Tokens"].waitForExistence(timeout: 3))
        tabs.buttons["システムプロンプト"].tap()
        XCTAssertTrue(app.textViews["system-prompt-input"].waitForExistence(timeout: 3))
        let made = app.descendants(matching: .any)["configuration-tabs-made"].firstMatch
        print("CONFIG tabs made=\(made.label) save=\(save.frame) label=\(save.label)")
        XCTAssertEqual(made.label, "1", "The tabs stay one control through the changes")
        save.tap()
        XCTAssertTrue(gone(tabs), "保存 closes the sheet")
    }

    @MainActor private func launchPreviewFrames(_ name: String, arguments: [String], seconds: TimeInterval) -> XCUIApplication {
        let app = PreviewApp()
        app.launchArguments = ["--startup", "--reset-startup", "--reset-settings", "--onboarding-step=launch",
                               "--launch-preview-demo"] + arguments
        app.launch()
        // Each screenshot is cut down to the phones' band of the page at
        // once, so a loop's worth of whole screens is never kept.
        func cell(_ shot: XCUIScreenshot) -> UIImage? {
            guard let image = shot.image.cgImage else { return nil }
            let width = CGFloat(image.width), height = CGFloat(image.height)
            let crop = CGRect(x: width * 0.06, y: height * 0.25, width: width * 0.88, height: height * 0.49).integral
            guard let part = image.cropping(to: crop) else { return nil }
            let size = CGSize(width: 400, height: (400 * crop.height / crop.width).rounded())
            let format = UIGraphicsImageRendererFormat()
            format.scale = 1
            return UIGraphicsImageRenderer(size: size, format: format).image { _ in
                UIImage(cgImage: part).draw(in: CGRect(origin: .zero, size: size))
            }
        }
        let started = Date()
        var frames: [(time: Double, image: UIImage)] = []
        while Date().timeIntervalSince(started) < seconds {
            let time = Date().timeIntervalSince(started)
            if let image = cell(XCUIScreen.main.screenshot()) { frames.append((time, image)) }
        }
        print("LAUNCH-CHAT preview \(name) frames=\(frames.count) over \(String(format: "%.1f", seconds))s")
        let columns = 4, perSheet = 12, label: CGFloat = 18
        for (sheetIndex, start) in stride(from: 0, to: frames.count, by: perSheet).enumerated() {
            let part = Array(frames[start..<min(start + perSheet, frames.count)])
            guard let cellSize = part.first?.image.size else { continue }
            let rows = (part.count + columns - 1) / columns
            let format = UIGraphicsImageRendererFormat()
            format.scale = 1
            let sheetSize = CGSize(width: cellSize.width * CGFloat(columns), height: (cellSize.height + label) * CGFloat(rows))
            let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
                UIColor.black.setFill()
                context.fill(CGRect(origin: .zero, size: sheetSize))
                for (index, frame) in part.enumerated() {
                    let origin = CGPoint(x: CGFloat(index % columns) * cellSize.width,
                                         y: CGFloat(index / columns) * (cellSize.height + label))
                    frame.image.draw(at: CGPoint(x: origin.x, y: origin.y + label))
                    (String(format: "%.2f s", frame.time) as NSString)
                        .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                              withAttributes: [.font: UIFont.systemFont(ofSize: 13), .foregroundColor: UIColor.white])
                }
            }
            let attachment = XCTAttachment(image: sheet)
            attachment.name = "launch-chat-preview-frames-\(name)-\(sheetIndex + 1)"
            attachment.lifetime = .keepAlways
            add(attachment)
        }
        // The phones stand still about 16 s after the page came; only then
        // is the app asked anything.
        let rest = 19.5 - Date().timeIntervalSince(started)
        if rest > 0 { Thread.sleep(forTimeInterval: rest) }
        return app
    }

    /// 起動時のチャット (1.1.0 (182)), the step after 入力スタイル: as it is.
    @MainActor private func continueLaunchStep(_ app: XCUIApplication) {
        let next = app.buttons["onboarding-launch-continue"]
        XCTAssertTrue(next.waitForExistence(timeout: 5), "起動時のチャット after 入力スタイル")
        next.tap()
    }

    /// 入力欄のタイプ (2026-10-23): 従来型, chosen in モデルと設定, is the
    /// plus and a one-line field at rest. While it is typed in, the 高速 and
    /// model pills rise above it and work as in 縮小型; the choice is kept.
    /// Since 1.1.0 (255) only with `--standard-as-254` (testStandardBar...).
    @MainActor func testClassicComposerFromSettingsShowsPillsWhileTyping() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--standard-as-254"]; app.launch()
        openSettingsFromChat(app)
        // 入力欄のタイプ is 設定's キーボードと入力 › 入力スタイル.
        openSettingsRow("keyboard", title: "キーボードと入力", app: app)
        openSettingsRow("composerStyle", title: "入力スタイル", app: app)
        // Each type is a small phone to tap (2026-10-24).
        let folding = app.buttons["composer-style-folding"], classic = app.buttons["composer-style-classic"]
        XCTAssertTrue(folding.waitForExistence(timeout: 3))
        XCTAssertTrue(folding.isSelected, "縮小型 until another is chosen")
        classic.tap()
        XCTAssertTrue(classic.isSelected)
        XCTAssertFalse(folding.isSelected)
        capture("composer-type-settings", app: app)
        app.buttons["settings-close"].tap()
        let plus = app.buttons["chat-add-menu"], composer = app.descendants(matching: .any)["chat-composer"]
        let input = app.textViews["chat-input"], send = app.buttons["送信する"]
        let model = app.buttons["composer-model"], mode = app.buttons["composer-photo-detail"]
        XCTAssertTrue(gone(app.navigationBars["入力スタイル"]))
        XCTAssertTrue(plus.waitForExistence(timeout: 3))
        print("COMPOSER classic-rest plus=\(plus.frame) composer=\(composer.frame) send=\(send.frame)")
        XCTAssertLessThanOrEqual(composer.frame.height, 46, "One line thin at rest")
        XCTAssertLessThanOrEqual(plus.frame.maxX, composer.frame.minX, "The plus beside the field")
        XCTAssertEqual(plus.frame.midY, composer.frame.midY, accuracy: 1)
        XCTAssertTrue(send.frame.minX > composer.frame.midX && send.frame.maxX <= composer.frame.maxX + 0.5, "Send inside the field")
        XCTAssertFalse(model.exists, "No pills at rest")
        XCTAssertFalse(app.buttons["composer-expand"].exists)
        capture("composer-type-classic-rest", app: app)
        input.tap(); input.typeText("従来型の下書き")
        XCTAssertTrue(model.waitForExistence(timeout: 3), "The pills rise while typing")
        Thread.sleep(forTimeInterval: 0.9)
        print("COMPOSER classic-typing mode=\(mode.frame) model=\(model.frame) composer=\(composer.frame) plus=\(plus.frame)")
        XCTAssertTrue(mode.exists, "E4B has 高速・深く")
        XCTAssertLessThanOrEqual(model.frame.maxY, composer.frame.minY + 0.5, "Above the field")
        // The field's glass starts 12pt after the plus's 44pt column (its
        // element starts at the text, 14pt further in).
        let fieldEdge = plus.frame.midX + 22 + 12
        XCTAssertEqual(mode.frame.minX, fieldEdge, accuracy: 1, "Lined up with the field")
        XCTAssertGreaterThanOrEqual(model.frame.minX - mode.frame.maxX, 7.5, "高速 and the model pill stand apart")
        XCTAssertLessThanOrEqual(composer.frame.height, 46, "Still one line")
        capture("composer-type-classic-typing", app: app)
        model.tap()
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("COMPOSER classic-model-menu focus=\(String(describing: input.value(forKey: "hasKeyboardFocus"))) keyboard=\(app.keyboards.firstMatch.exists)")
        capture("composer-type-classic-model-menu", app: app)
        gemma.tap()
        let e2b = menuItem("model-menu-gemma-4-e2b", "Gemma 4 E2B", app)
        XCTAssertTrue(e2b.waitForExistence(timeout: 3))
        e2b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4), "E2B opens a new chat")
        XCTAssertEqual(input.value as? String, "従来型の下書き", "The draft's text comes along")
        XCTAssertTrue(gone(model), "The keyboard leaves with the switch, and the pills with it")
        input.tap()
        XCTAssertTrue(model.waitForExistence(timeout: 3))
        XCTAssertEqual(model.value as? String, "Gemma 4 E2B")
        XCTAssertFalse(mode.exists, "E2B has no 高速・深く")
        // Past the drops' rise, once the pills stand in their place.
        Thread.sleep(forTimeInterval: 0.9)
        XCTAssertEqual(model.frame.minX, fieldEdge, accuracy: 1)
        capture("composer-type-classic-e2b-typing", app: app)
        // The choice is kept across launches.
        app.terminate(); app.launchArguments = ["--keep-composer-style", "--standard-as-254"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertLessThanOrEqual(composer.frame.height, 46)
        XCTAssertFalse(model.exists)
    }

    /// 従来型 in dark mode over a long chat: reading older messages folds
    /// nothing; the jump control rises out of the field, centered on the
    /// screen, and takes the reader back. Web search on shows a globe in
    /// the field at rest, which turns it off.
    @MainActor func testClassicComposerDarkJumpAndWebSearch() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--classic-composer", "--standard-as-254", "--long-chat", "--dark", "--web-search-key"]; app.launch()
        let plus = app.buttons["chat-add-menu"], composer = app.descendants(matching: .any)["chat-composer"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        dragReading(app, towardOlder: true)
        dragReading(app, towardOlder: true)
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 4), "The jump control rises out of the field")
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertFalse(app.buttons["composer-expand"].exists, "従来型 never folds")
        XCTAssertTrue(app.textViews["chat-input"].exists)
        print("COMPOSER classic-jump jump=\(jump.frame) composer=\(composer.frame) screen=\(app.frame)")
        XCTAssertEqual(jump.frame.midX, app.frame.midX, accuracy: 1, "Centered on the screen")
        XCTAssertLessThan(jump.frame.maxY, composer.frame.minY)
        capture("composer-type-classic-dark-jump", app: app)
        jump.tap()
        XCTAssertTrue(gone(jump, timeout: 5), "Back at the end, it sinks into the field")
        plus.tap()
        let toggle = webSearchItem(app)
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        toggle.tap()
        let globe = app.buttons["composer-web-search"]
        XCTAssertTrue(globe.waitForExistence(timeout: 3), "Search on shows in the field at rest")
        Thread.sleep(forTimeInterval: 0.6)
        print("COMPOSER classic-search globe=\(globe.frame) composer=\(composer.frame)")
        XCTAssertTrue(composer.frame.contains(CGPoint(x: globe.frame.midX, y: globe.frame.midY)), "Inside the field")
        XCTAssertLessThanOrEqual(composer.frame.height, 46)
        capture("composer-type-classic-dark-search", app: app)
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Dark draft")
        XCTAssertTrue(app.buttons["composer-model"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.9)
        capture("composer-type-classic-dark-typing", app: app)
        globe.tap()
        XCTAssertTrue(gone(globe), "The globe turns search off")
    }

    /// 従来型's pills rise out of the field as drops of its glass and sink
    /// back into it as the keyboard leaves (user, 2026-10-23), frame by
    /// frame from the session recording (scope composer-type, MENU-MARK
    /// lines): light, dark, and dark with reduced motion, where they fade.
    @MainActor func testClassicPillsRiseAndSinkFrames() {
        continueAfterFailure = false
        for (variant, flags) in [("light", [String]()), ("dark", ["--dark"]), ("reduced", ["--dark", "--reduce-motion"])] {
            // A drag on the conversation, past its end so the jump control
            // stays away, puts the keyboard away at once, as sending does,
            // without a reply's work in the frames. It starts above the
            // pills: one that starts on a pill scrolls nothing (run 274).
            let app = PreviewApp()
            app.launchArguments = ["--classic-composer", "--standard-as-254", "--long-chat", "--probe-dismiss-immediately"]
                + flags; app.launch()
            let input = app.textViews["chat-input"], model = app.buttons["composer-model"]
            XCTAssertTrue(input.waitForExistence(timeout: 10))
            Thread.sleep(forTimeInterval: 1.2)
            menuMark("classic-\(variant)-rise"); input.tap()
            XCTAssertTrue(model.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 1.6)
            capture("composer-type-frames-\(variant)-up", app: app)
            input.typeText("水")
            Thread.sleep(forTimeInterval: 0.8)
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: app.frame.midX, dy: model.frame.minY - 60))
            menuMark("classic-\(variant)-sink")
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: -160)))
            XCTAssertTrue(gone(model), "The pills sink into the field with the keyboard")
            Thread.sleep(forTimeInterval: 1.2)
            capture("composer-type-frames-\(variant)-down", app: app)
            XCTAssertEqual(input.value as? String, "水", "The draft stays")
            app.terminate()
        }
    }

    /// スタンダード (1.1.0 (255), user directive 2026-11-03): at rest one bar,
    /// the plus inside it at its leading end in a circle of its own, send at
    /// its trailing end, no pills; a tap where a pill will be is the text's.
    /// Typed in, it opens into スマート's panel, every control where スマート's
    /// is with the keyboard up; the model menu answers, and as the keyboard
    /// goes it is one bar again. The plus menu opens from the bar without
    /// the keyboard. The choice is kept.
    @MainActor func testStandardBarOpensIntoTheSmartPanel() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        let plus = app.buttons["chat-add-menu"], composer = app.descendants(matching: .any)["chat-composer"]
        let input = app.textViews["chat-input"], send = app.buttons["送信する"]
        let model = app.buttons["composer-model"], mode = app.buttons["composer-photo-detail"]
        let keyboard = app.keyboards.firstMatch
        let names = ["composer", "plus", "mode", "model", "send"]
        func frames() -> [CGRect] { [composer.frame, plus.frame, mode.frame, model.frame, send.frame] }
        // スマート typed in: the frames スタンダード must open into.
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        input.tap(); input.typeText("下書き")
        XCTAssertTrue(keyboard.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1.0)
        let smart = frames()
        print("COMPOSER standard smart-typing " + zip(names, smart).map { "\($0.0)=\($0.1)" }.joined(separator: " "))
        capture("composer-standard-smart-typing", app: app)
        app.terminate()

        app.launchArguments = ["--reset-settings", "--classic-composer"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        let bar = composer.frame
        print("COMPOSER standard rest composer=\(bar) plus=\(plus.frame) send=\(send.frame) input=\(input.frame) "
              + "model=\(model.exists ? "\(model.frame) hittable=\(model.isHittable)" : "none")")
        XCTAssertFalse(keyboard.exists)
        XCTAssertEqual(bar.height, 52, accuracy: 1, "One bar at rest")
        XCTAssertTrue(bar.contains(CGPoint(x: plus.frame.midX, y: plus.frame.midY)), "The plus inside the bar")
        XCTAssertEqual(plus.frame.midY, bar.midY, accuracy: 1, "On the bar's line")
        XCTAssertEqual(plus.frame.midX - bar.minX, 26, accuracy: 1, "Its circle concentric with the bar's round end")
        XCTAssertEqual(bar.maxX - send.frame.midX, 26, accuracy: 1, "Send at the other end")
        XCTAssertEqual(send.frame.midY, bar.midY, accuracy: 1)
        XCTAssertGreaterThanOrEqual(input.frame.minX, plus.frame.maxX, "The text after the plus")
        XCTAssertLessThanOrEqual(input.frame.maxX, send.frame.minX, "and before send")
        XCTAssertFalse(app.buttons["composer-expand"].exists, "スタンダード never folds")
        capture("composer-standard-rest", app: app)

        // The bar's middle, where the pills will stand, is the text's at rest.
        app.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: bar.minX + bar.width * 0.4, dy: bar.midY)).tap()
        XCTAssertTrue(keyboard.waitForExistence(timeout: 3), "The text takes a tap on the bar")
        XCTAssertFalse(app.buttons["model-menu-gemma"].exists, "No menu from a pill that is away")
        input.typeText("下書き")
        Thread.sleep(forTimeInterval: 1.0)
        let opened = frames()
        print("COMPOSER standard typing " + zip(names, opened).map { "\($0.0)=\($0.1)" }.joined(separator: " "))
        for (index, name) in names.enumerated() {
            XCTAssertEqual(opened[index].minX, smart[index].minX, accuracy: 1, "\(name): where スマート's is")
            XCTAssertEqual(opened[index].minY, smart[index].minY, accuracy: 1, "\(name): where スマート's is")
            XCTAssertEqual(opened[index].width, smart[index].width, accuracy: 1, "\(name): as wide as スマート's")
            XCTAssertEqual(opened[index].height, smart[index].height, accuracy: 1, "\(name): as tall as スマート's")
        }
        XCTAssertTrue(model.isHittable && mode.isHittable, "E4B's 高速・深く and the model")
        capture("composer-standard-typing", app: app)
        model.tap()
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3), "The model menu answers")
        Thread.sleep(forTimeInterval: 0.6)
        print("COMPOSER standard model-menu keyboard=\(keyboard.exists)")
        capture("composer-standard-model-menu", app: app)
        gemma.tap()
        let e2b = menuItem("model-menu-gemma-4-e2b", "Gemma 4 E2B", app)
        XCTAssertTrue(e2b.waitForExistence(timeout: 3))
        e2b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4), "E2B opens a new chat")
        XCTAssertTrue(gone(keyboard, timeout: 4), "The keyboard leaves with the switch")
        Thread.sleep(forTimeInterval: 0.9)
        print("COMPOSER standard closed composer=\(composer.frame) text=\(String(describing: input.value))")
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "One bar again")
        XCTAssertEqual(composer.frame.minX, bar.minX, accuracy: 1)
        capture("composer-standard-closed", app: app)
        // The plus at rest: its menu, the keyboard staying away.
        plus.tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 3), "The plus menu opens from the bar")
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertFalse(keyboard.exists, "without the keyboard")
        capture("composer-standard-plus-menu", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.25)).tap()
        XCTAssertTrue(gone(photos))
        // The choice is kept across launches.
        app.terminate(); app.launchArguments = ["--keep-composer-style"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "Still スタンダード")
    }

    /// スタンダード in dark mode over a long chat: reading older messages
    /// folds nothing; the jump control rises out of the bar, centered on the
    /// screen, and takes the reader back. Search on: its pill stays in the
    /// bar at rest, after the plus, the text after it, and turns search
    /// off. A send closes the bar with the keyboard.
    @MainActor func testStandardBarDarkJumpSearchAndSend() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--classic-composer", "--long-chat", "--dark", "--web-search-key"]; app.launch()
        let plus = app.buttons["chat-add-menu"], composer = app.descendants(matching: .any)["chat-composer"]
        let input = app.textViews["chat-input"], keyboard = app.keyboards.firstMatch
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        dragReading(app, towardOlder: true)
        dragReading(app, towardOlder: true)
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 4), "The jump control rises out of the bar")
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertFalse(app.buttons["composer-expand"].exists, "スタンダード never folds")
        print("COMPOSER standard-jump jump=\(jump.frame) composer=\(composer.frame) screen=\(app.frame)")
        XCTAssertEqual(jump.frame.midX, app.frame.midX, accuracy: 1, "Centered on the screen")
        XCTAssertLessThan(jump.frame.maxY, composer.frame.minY)
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1)
        capture("composer-standard-dark-jump", app: app)
        jump.tap()
        XCTAssertTrue(gone(jump, timeout: 5), "Back at the end, it sinks into the bar")
        plus.tap()
        let toggle = webSearchItem(app)
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        toggle.tap()
        let globe = app.buttons["composer-web-search"]
        XCTAssertTrue(globe.waitForExistence(timeout: 3), "Search on shows in the bar at rest")
        Thread.sleep(forTimeInterval: 0.8)
        print("COMPOSER standard-search globe=\(globe.frame) plus=\(plus.frame) input=\(input.frame) composer=\(composer.frame)")
        XCTAssertTrue(composer.frame.contains(CGPoint(x: globe.frame.midX, y: globe.frame.midY)), "Inside the bar")
        XCTAssertGreaterThanOrEqual(globe.frame.minX, plus.frame.maxX - 1, "After the plus")
        XCTAssertGreaterThanOrEqual(input.frame.minX, globe.frame.maxX, "The text after it")
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1)
        capture("composer-standard-dark-search", app: app)
        globe.tap()
        XCTAssertTrue(gone(globe), "The pill turns search off")
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertEqual(input.frame.minX, plus.frame.maxX + 12, accuracy: 1, "The text back after the plus")
        input.tap(); input.typeText("Dark draft")
        XCTAssertTrue(app.buttons["composer-model"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1.0)
        print("COMPOSER standard-dark-typing composer=\(composer.frame)")
        XCTAssertGreaterThan(composer.frame.height, 90, "Open while typed in")
        capture("composer-standard-dark-typing", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Dark draft"].waitForExistence(timeout: 5), "Sent")
        XCTAssertTrue(gone(keyboard, timeout: 4))
        Thread.sleep(forTimeInterval: 0.9)
        print("COMPOSER standard-dark-sent composer=\(composer.frame)")
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "One bar again after the send")
        capture("composer-standard-dark-sent", app: app)
    }

    /// スタンダード's bar opening into the panel as the keyboard comes and
    /// closing as it goes, frame by frame from the session recording (scope
    /// composer-type, MENU-MARK standard-* lines): light, dark, and dark
    /// with reduced motion. The draft stays.
    @MainActor func testStandardBarOpensAndClosesFrames() {
        continueAfterFailure = true
        for (variant, flags) in [("light", [String]()), ("dark", ["--dark"]), ("reduced", ["--dark", "--reduce-motion"])] {
            // A drag on the conversation, past its end so the jump control
            // stays away, puts the keyboard away at once, as sending does.
            // Without --probe-no-pull a drag that far can fill the ring that
            // opens a new chat, which takes the draft with the old chat
            // (run 41592129318, dark: its frame sheet shows 新しいチャット).
            let app = PreviewApp()
            app.launchArguments = ["--classic-composer", "--long-chat", "--probe-dismiss-immediately", "--probe-no-pull"] + flags
            app.launch()
            let input = app.textViews["chat-input"], composer = app.descendants(matching: .any)["chat-composer"]
            let keyboard = app.keyboards.firstMatch
            func log(_ step: String) {
                print("COMPOSER standard-frames \(variant) \(step) text=\(String(describing: input.value)) composer=\(composer.frame)")
            }
            XCTAssertTrue(input.waitForExistence(timeout: 10))
            Thread.sleep(forTimeInterval: 1.2)
            menuMark("standard-\(variant)-open"); input.tap()
            XCTAssertTrue(keyboard.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 1.4)
            capture("composer-standard-frames-\(variant)-open", app: app)
            input.typeText("水")
            Thread.sleep(forTimeInterval: 0.6)
            log("typed")
            capture("composer-standard-frames-\(variant)-typed", app: app)
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: app.frame.midX, dy: composer.frame.minY - 60))
            menuMark("standard-\(variant)-close")
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: -160)))
            XCTAssertTrue(gone(keyboard), "It closes with the keyboard")
            Thread.sleep(forTimeInterval: 1.2)
            log("closed")
            XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "One bar again")
            capture("composer-standard-frames-\(variant)-closed", app: app)
            XCTAssertEqual(input.value as? String, "水", "The draft stays")
            app.terminate()
        }
    }

    /// スタンダード on the iPad in landscape, its own keyboard (no hardware
    /// keyboard counted): one bar at rest across the conversation's column,
    /// opening into the panel as it is typed in, as スマート's; a send closes
    /// it again.
    @MainActor func testStandardBarOnTheIPad() {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .landscapeLeft
        addTeardownBlock { XCUIDevice.shared.orientation = .portrait }
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--classic-composer"]; app.launch()
        let plus = app.buttons["chat-add-menu"], composer = app.descendants(matching: .any)["chat-composer"]
        let input = app.textViews["chat-input"], send = app.buttons["送信する"], model = app.buttons["composer-model"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        print("COMPOSER ipad-standard rest composer=\(composer.frame) plus=\(plus.frame) send=\(send.frame) "
              + "input=\(input.frame) screen=\(app.frame) keyboards=\(app.keyboards.count)")
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "One bar at rest")
        XCTAssertTrue(composer.frame.contains(CGPoint(x: plus.frame.midX, y: plus.frame.midY)), "The plus inside the bar")
        XCTAssertEqual(plus.frame.midY, composer.frame.midY, accuracy: 1)
        capture("hwkb-standard-ipad-rest", app: app)
        input.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
        Thread.sleep(forTimeInterval: 1.4)
        input.typeText("iPad draft")
        Thread.sleep(forTimeInterval: 0.8)
        print("COMPOSER ipad-standard typing composer=\(composer.frame) plus=\(plus.frame) model=\(model.frame) "
              + "send=\(send.frame) input=\(input.frame) keyboards=\(app.keyboards.count)")
        XCTAssertGreaterThan(composer.frame.height, 90, "Open while typed in")
        XCTAssertTrue(model.isHittable)
        XCTAssertGreaterThan(model.frame.minY, input.frame.minY, "The row below the text, as in スマート")
        capture("hwkb-standard-ipad-typing", app: app)
        send.tap()
        XCTAssertTrue(app.staticTexts["iPad draft"].waitForExistence(timeout: 5), "Sent")
        Thread.sleep(forTimeInterval: 1.4)
        print("COMPOSER ipad-standard sent composer=\(composer.frame) keyboards=\(app.keyboards.count)")
        capture("hwkb-standard-ipad-sent", app: app)
        XCTAssertEqual(composer.frame.height, 52, accuracy: 1, "One bar again after the send")
    }

    /// Web search (2026-10-22): off until the plus menu turns it on for the
    /// chat; a pill beside the plus then says so and turns it off. A sent
    /// question shows what it searched, then the pages under the reply.
    @MainActor func testWebSearchSwitchPillAndSources() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--web-search-key"]; app.launch()
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-web-search"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertFalse(pill.exists, "Search is off until the chat turns it on")
        plus.tap()
        let toggle = webSearchItem(app)
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        print("WEB-SEARCH menu item: \(toggle.elementType.rawValue) label=\(toggle.label) value=\(String(describing: toggle.value))")
        capture("web-search-menu-off", app: app)
        toggle.tap()
        XCTAssertTrue(pill.waitForExistence(timeout: 3))
        XCTAssertTrue(pill.isHittable)
        print("WEB-SEARCH pill: \(pill.frame) plus=\(plus.frame)")
        capture("web-search-pill", app: app)
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("東京スカイツリーの高さ")
        app.buttons["送信する"].tap()
        // While it searches: the query with the globe, the Aurora Orb's
        // line below (XCUIScreen, as element queries wait for the orb).
        Thread.sleep(forTimeInterval: 0.5)
        let searching = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        searching.name = "web-search-searching"; searching.lifetime = .keepAlways; add(searching)
        let header = app.descendants(matching: .any).matching(identifier: "reply-web-search").firstMatch
        XCTAssertTrue(header.waitForExistence(timeout: 4))
        let sources = app.descendants(matching: .any).matching(identifier: "reply-web-sources").firstMatch
        XCTAssertTrue(sources.waitForExistence(timeout: 20))
        print("WEB-SEARCH header after: \(header.label) sources=\(sources.frame)")
        XCTAssertTrue(header.label.contains("ウェブで検索しました"), header.label)
        XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label BEGINSWITH %@", "東京スカイツリー、"))
                        .firstMatch.exists, "The page opens from its own row")
        capture("web-search-sources", app: app)
        XCTAssertTrue(pill.waitForExistence(timeout: 4))
        pill.tap()
        XCTAssertTrue(gone(pill), "The pill turns search off")
        plus.tap()
        XCTAssertTrue(webSearchItem(app).waitForExistence(timeout: 3))
        capture("web-search-menu-after-off", app: app)
        dismissMenu(webSearchItem(app), app: app)
    }

    /// A reply that searched, in dark mode; a search with no connection says
    /// so; Qwen offers no search at all.
    @MainActor func testWebSearchSourcesDarkOfflineAndQwenOffersNone() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--web-search", "--web-search-sample", "--web-search-key", "--web-search-offline", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "reply-web-sources").firstMatch.waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["composer-web-search"].exists)
        capture("web-search-sources-dark", app: app)
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("今日のニュース")
        app.buttons["送信する"].tap()
        let failed = app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "インターネットに接続できません")).firstMatch
        XCTAssertTrue(failed.waitForExistence(timeout: 10))
        print("WEB-SEARCH offline: \(failed.label)")
        capture("web-search-offline-dark", app: app)
        app.terminate()
        app.launchArguments = ["--qwen3", "--web-search", "--web-search-key"]; app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["composer-web-search"].exists, "Qwen never searches")
        plus.tap()
        XCTAssertTrue(menuItem("新しいチャット", "新しいチャット", app).waitForExistence(timeout: 3))
        XCTAssertFalse(webSearchItem(app).exists, "Qwen's menu has no search")
        capture("web-search-qwen-menu", app: app)
    }

    /// No page named the version asked (1.1.0 (208)): the line above the
    /// reply says so, not only that it searched.
    @MainActor func testWebSearchSaysWhenNoPageNamedTheVersion() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--web-search", "--web-search-key", "--web-search-unconfirmed"]; app.launch()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        input.tap(); input.typeText("iOS 27.9はいつ出るの")
        app.buttons["送信する"].tap()
        let header = app.descendants(matching: .any).matching(identifier: "reply-web-search").firstMatch
        let line = NSPredicate(format: "label CONTAINS %@", "について書かれたページは見つかりませんでした")
        XCTAssertTrue(app.descendants(matching: .any).matching(line).firstMatch.waitForExistence(timeout: 10))
        print("WEB-SEARCH unconfirmed: \(header.label)")
        XCTAssertTrue(header.label.contains("「iOS 27.9」"), header.label)
        capture("web-search-unconfirmed", app: app)
    }

    /// Not connected, the plus menu says where to connect, 設定 opens on
    /// ウェブ検索 (モデル管理's last card until 1.1.0 (230)) with 新規登録 and
    /// ログイン first, and a key entered under 「APIキーで接続」 is
    /// registered and kept when a change is cancelled (1.1.0 (207)); back
    /// goes to 設定's rows.
    @MainActor func testWebSearchKeyGuidanceAndRegister() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--web-search-no-key"]; app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        let item = webSearchItem(app)
        XCTAssertTrue(item.waitForExistence(timeout: 3))
        print("WEB-SEARCH no-key menu item: \(item.elementType.rawValue) label=\(item.label)")
        capture("web-search-menu-no-key", app: app)
        item.tap()
        let note = app.alerts["ウェブ検索にはTavilyへの接続が必要です"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        capture("web-search-key-note", app: app)
        note.buttons["設定を開く"].tap()
        // Straight to ウェブ検索 (1.1.0 (230)).
        XCTAssertTrue(app.navigationBars["ウェブ検索"].waitForExistence(timeout: 5))
        let signUp = app.buttons["web-search-account-sign-up"]
        XCTAssertTrue(signUp.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertTrue(signUp.isHittable, "設定 opens on ウェブ検索")
        XCTAssertTrue(app.buttons["web-search-account-sign-in"].isHittable)
        capture("web-search-card-empty", app: app)
        let field = app.secureTextFields["web-search-key"]
        XCTAssertFalse(field.exists, "the key waits under 「APIキーで接続」")
        app.buttons["APIキーで接続"].tap()
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "web-search-key-page").firstMatch.exists)
        capture("web-search-card-key-open", app: app)
        field.tap(); field.typeText("  tvly-ui-test-key\n")
        let state = app.descendants(matching: .any).matching(identifier: "web-search-key-state").firstMatch
        XCTAssertTrue(state.waitForExistence(timeout: 4))
        let message = app.descendants(matching: .any).matching(identifier: "web-search-key-message").firstMatch
        print("WEB-SEARCH key state: \(state.label) message=\(message.label)")
        let connected = app.descendants(matching: .any).matching(identifier: "web-search-account-state").firstMatch
        XCTAssertTrue(connected.waitForExistence(timeout: 3))
        print("WEB-SEARCH card state with a key: \(connected.label)")
        capture("web-search-card-registered", app: app)
        app.buttons["web-search-key-change"].tap()
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        app.buttons["キャンセル"].tap()
        XCTAssertTrue(state.waitForExistence(timeout: 3), "Cancelling a change keeps the key")
        app.buttons["settings-back"].tap()
        XCTAssertTrue(gone(app.navigationBars["ウェブ検索"]))
        XCTAssertTrue(app.buttons["settings-row-webSearch"].waitForExistence(timeout: 3), "Back is 設定's rows")
        capture("web-search-back-to-settings", app: app)
    }

    /// A fresh launch reads a saved key back from the keychain; once deleted
    /// in 設定 › ウェブ検索, the next launch finds none. Kept apart from the
    /// guidance test, whose first launch and typing already take most of a
    /// test's 120 seconds.
    @MainActor func testWebSearchKeyReadBackAndDelete() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--web-search-key", "--tavily-signed-out"]; app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        app.terminate(); app.launchArguments = ["--e2b"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        XCTAssertTrue(webSearchItem(app).waitForExistence(timeout: 3))
        print("WEB-SEARCH keyed menu item after relaunch: \(webSearchItem(app).elementType.rawValue) label=\(webSearchItem(app).label)")
        capture("web-search-menu-key-read-back", app: app)
        dismissMenu(webSearchItem(app), app: app)
        openWebSearchPage(app)
        let disclosure = app.buttons["APIキーで接続"]
        for _ in 0..<5 where !disclosure.waitForExistence(timeout: 1.5) { app.swipeUp() }
        disclosure.tap()
        let delete = app.buttons["web-search-key-delete"]
        for _ in 0..<3 where !delete.waitForExistence(timeout: 1.5) { app.swipeUp() }
        XCTAssertTrue(delete.exists, "The saved key was read back")
        let stateText = app.descendants(matching: .any).matching(NSPredicate(format: "label BEGINSWITH %@", "Tavilyのキー:")).firstMatch
        print("WEB-SEARCH key read back: \(stateText.label)")
        XCTAssertTrue(stateText.exists, "the card says the key is registered")
        delete.tap()
        let confirm = app.buttons.matching(NSPredicate(format: "label == %@ AND identifier != %@",
                                                       "削除", "web-search-key-delete")).firstMatch
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        confirm.tap()
        let field = app.secureTextFields["web-search-key"]
        XCTAssertTrue(field.waitForExistence(timeout: 4))
        XCTAssertTrue(gone(stateText))
        let message = app.descendants(matching: .any).matching(identifier: "web-search-key-message").firstMatch
        print("WEB-SEARCH after delete: \(message.label)")
        capture("web-search-card-deleted", app: app)
        app.terminate(); app.launchArguments = ["--e2b"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        openWebSearchPage(app)
        for _ in 0..<5 where !disclosure.waitForExistence(timeout: 1.5) { app.swipeUp() }
        disclosure.tap()
        for _ in 0..<3 where !field.waitForExistence(timeout: 1.5) { app.swipeUp() }
        print("WEB-SEARCH after relaunch: field=\(field.exists) state=\(stateText.exists ? stateText.label : "-")")
        capture("web-search-card-after-relaunch", app: app)
        XCTAssertTrue(field.exists, "The deleted key stays deleted")
        XCTAssertFalse(stateText.exists)
    }

    /// 新規登録 opens Tavily's own sign-up page (「Create Your Account」) in
    /// iOS's sign-in sheet, and ログイン its sign-in page (「Welcome」), over
    /// the network as on a phone (mcp.tavily.com registers the app, then
    /// Tavily's page). Closing the sheet comes back to the card as it was,
    /// with no message (1.1.0 (207); until 1.1.0 (223) 新規登録 opened the
    /// sign-in page too). No account is made: that needs a person.
    @MainActor func testTavilySignUpAndSignInOpenTheirOwnPages() {
        // Tavily's page is live: whatever it does, the sheet's close is
        // still checked.
        continueAfterFailure = true
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--web-search-no-key"]; app.launch()
        openWebSearchCardFromTheMenu(app)
        let signUp = app.buttons["web-search-account-sign-up"]
        let signIn = app.buttons["web-search-account-sign-in"]
        XCTAssertTrue(signUp.waitForExistence(timeout: 5))
        capture("web-search-tavily-card-signed-out", app: app)
        let service = XCUIApplication(bundleIdentifier: "com.apple.SafariViewService")
        let sheets = [app, service]
        let createsAccount = sheets.flatMap { [$0.staticTexts["Create Your Account"], $0.staticTexts["Create your account"],
                                               $0.links["Log in"], $0.staticTexts["Already have an account?"]] }
        let signsIn = sheets.flatMap { [$0.staticTexts["Welcome"], $0.links["Sign up"]] }

        func open(_ button: XCUIElement, expecting page: [XCUIElement], notExpecting other: [XCUIElement], name: String) {
            button.tap()
            // An ephemeral session asks no 「サインインに使用」 question; if
            // iOS asks anyway, go on.
            let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
            firstExisting([springboard.buttons["Continue"], springboard.buttons["続ける"]], timeout: 3)?.tap()
            let shown = firstExisting(page, timeout: 30)
            captureScreen("web-search-tavily-\(name)-page")
            print("WEB-SEARCH TAVILY \(name) page: \(shown.map { "\($0.elementType.rawValue) \($0.label)" } ?? "not found")")
            if shown == nil { print("WEB-SEARCH TAVILY \(name) tree: \(service.debugDescription.prefix(4000))") }
            XCTAssertNotNil(shown, "\(button.label) opens Tavily's \(name) page in the sheet")
            let wrong = firstExisting(other, timeout: 1)
            print("WEB-SEARCH TAVILY \(name) page shows the other page's: \(wrong.map(\.label) ?? "none")")
            XCTAssertNil(wrong, "\(button.label) opens its own page, not the other one")
            // The sheet's own close button (iOS's, in the system's
            // language); Fielua's settings sheet behind it has one too.
            let cancel = firstExisting(["キャンセル", "Cancel", "閉じる", "Close", "完了", "Done"].map { service.buttons[$0] }, timeout: 5)
            print("WEB-SEARCH TAVILY close: \(cancel.map { "\($0.label) \($0.frame)" } ?? "-")")
            XCTAssertNotNil(cancel, "the sheet can be closed")
            cancel?.tap()
            XCTAssertTrue(button.waitForExistence(timeout: 8), "closing Tavily's page comes back to the card")
            let message = app.descendants(matching: .any).matching(identifier: "web-search-account-message").firstMatch
            XCTAssertFalse(message.exists, "closing the page is not an error")
            XCTAssertTrue(gone(app.descendants(matching: .any).matching(identifier: "web-search-account-progress").firstMatch))
        }

        open(signUp, expecting: createsAccount, notExpecting: signsIn, name: "sign-up")
        capture("web-search-tavily-card-after-sign-up-cancel", app: app)
        open(signIn, expecting: signsIn, notExpecting: createsAccount, name: "sign-in")
        capture("web-search-tavily-card-after-cancel", app: app)
    }

    /// Signed in (made-up tokens): the plus menu has the switch and the card
    /// says connected; 接続を解除 asks first, then the card is back to
    /// 新規登録/ログイン and stays so after a relaunch. A sign-in Tavily asked
    /// to renew shows ログイン again, in the card and the menu (1.1.0 (207)).
    @MainActor func testTavilyConnectedDisconnectAndSignInAgain() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--web-search-no-key", "--tavily-account"]; app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        let item = webSearchItem(app)
        XCTAssertTrue(item.waitForExistence(timeout: 3))
        print("WEB-SEARCH TAVILY connected menu item: \(item.elementType.rawValue) label=\(item.label)")
        capture("web-search-tavily-menu-connected", app: app)
        // Signed in, the row is the switch: it turns search on (the pill),
        // with no 「接続が必要」 note.
        item.tap()
        let pill = app.buttons["composer-web-search"]
        XCTAssertTrue(pill.waitForExistence(timeout: 3), "signed in, the menu's row turns search on")
        XCTAssertFalse(app.alerts["ウェブ検索にはTavilyへの接続が必要です"].exists)
        capture("web-search-tavily-pill", app: app)
        openWebSearchPage(app)
        let disconnect = app.buttons["web-search-account-disconnect"]
        for _ in 0..<5 where !disconnect.waitForExistence(timeout: 1.5) { app.swipeUp() }
        let state = app.descendants(matching: .any).matching(identifier: "web-search-account-state").firstMatch
        print("WEB-SEARCH TAVILY connected card: \(state.label)")
        XCTAssertTrue(state.label.contains("Tavilyに接続済み"))
        capture("web-search-tavily-card-connected", app: app)
        disconnect.tap()
        let confirm = app.buttons.matching(NSPredicate(format: "label == %@ AND identifier != %@",
                                                       "接続を解除", "web-search-account-disconnect")).firstMatch
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        capture("web-search-tavily-disconnect-confirm", app: app)
        confirm.tap()
        let message = app.descendants(matching: .any).matching(identifier: "web-search-account-message").firstMatch
        XCTAssertTrue(message.waitForExistence(timeout: 25))
        print("WEB-SEARCH TAVILY after disconnect: \(message.label)")
        XCTAssertTrue(app.buttons["web-search-account-sign-up"].waitForExistence(timeout: 3))
        capture("web-search-tavily-card-disconnected", app: app)
        app.terminate(); app.launchArguments = ["--e2b", "--tavily-account-expired"]; app.launch()
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        XCTAssertTrue(item.waitForExistence(timeout: 3))
        // iOS's menu gives its rows' subtitles (here 「Tavilyにもう一度
        // ログインすると使えます」) no element or value of their own (runs
        // 40451519658, 40454145193): the screenshot shows it; the card
        // below checks the state.
        print("WEB-SEARCH TAVILY expired menu item: \(item.elementType.rawValue) label=\(item.label)")
        Thread.sleep(forTimeInterval: 0.6)
        capture("web-search-tavily-menu-expired", app: app)
        item.tap()
        let note = app.alerts["ウェブ検索にはTavilyへの接続が必要です"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        note.buttons["設定を開く"].tap()
        let signIn = app.buttons["web-search-account-sign-in"]
        XCTAssertTrue(signIn.waitForExistence(timeout: 6))
        print("WEB-SEARCH TAVILY expired card: \(state.label)")
        XCTAssertTrue(state.label.contains("もう一度ログイン"))
        XCTAssertTrue(app.buttons["web-search-account-disconnect"].exists)
        capture("web-search-tavily-card-expired", app: app)
    }

    /// No connection: ログイン says so and the card stays as it was.
    @MainActor func testTavilySignInWithoutAConnection() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--e2b", "--web-search-no-key", "--tavily-offline"]; app.launch()
        openWebSearchCardFromTheMenu(app)
        let signIn = app.buttons["web-search-account-sign-in"]
        XCTAssertTrue(signIn.waitForExistence(timeout: 5))
        signIn.tap()
        let message = app.descendants(matching: .any).matching(identifier: "web-search-account-message").firstMatch
        XCTAssertTrue(message.waitForExistence(timeout: 10))
        print("WEB-SEARCH TAVILY offline sign-in: \(message.label)")
        XCTAssertTrue(message.label.contains("インターネットに接続できません"))
        XCTAssertTrue(app.buttons["web-search-account-sign-up"].exists)
        capture("web-search-tavily-offline", app: app)
    }

    /// The plus menu's ウェブ検索 row while not connected, then its alert's
    /// 設定を開く: 設定 on ウェブ検索 (1.1.0 (230); モデル管理 at its card before).
    @MainActor private func openWebSearchCardFromTheMenu(_ app: XCUIApplication) {
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        let item = webSearchItem(app)
        XCTAssertTrue(item.waitForExistence(timeout: 3))
        item.tap()
        let note = app.alerts["ウェブ検索にはTavilyへの接続が必要です"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        note.buttons["設定を開く"].tap()
        XCTAssertTrue(app.navigationBars["ウェブ検索"].waitForExistence(timeout: 5))
    }

    /// 設定's ウェブ検索 from the history's 設定, as a person finds it.
    @MainActor private func openWebSearchPage(_ app: XCUIApplication) {
        openSettingsFromHistory(app)
        openSettingsRow("webSearch", title: "ウェブ検索", app: app)
    }

    /// The iCloud card's line, モデル管理's last while iCloud is off (the
    /// folder backup's caption, which since 1.1.0 (251) says the Files app
    /// shows its copies).
    static let cloudHistoryLine = "会話と添付を、指定したフォルダに自動でバックアップします。バックアップは「ファイル」アプリから見えます。"

    /// 設定's ウェブ検索 row (1.1.0 (230), fielua-reports Issue #5): its page
    /// holds the Tavily card that ended モデル管理 (新規登録, ログイン, APIキー
    /// で接続) with no heading of its own, and back returns to the rows;
    /// モデル管理 now ends at iCloud, and モバイル通信でもダウンロード is the
    /// switch alone, still working. Light, then dark after a relaunch
    /// (SHOT settings-web-search-*, settings-models-end-*).
    @MainActor func testWebSearchPageFromSettings() {
        continueAfterFailure = false
        let app = PreviewApp()
        for name in ["light", "dark"] {
            app.launchArguments = ["--reset-settings", "--web-search-no-key"] + (name == "dark" ? ["--dark"] : [])
            app.launch()
            openWebSearchPage(app)
            let signUp = app.buttons["web-search-account-sign-up"], signIn = app.buttons["web-search-account-sign-in"]
            let disclosure = app.buttons["web-search-key-disclosure"]
            XCTAssertTrue(signUp.waitForExistence(timeout: 4))
            Thread.sleep(forTimeInterval: 0.6)
            XCTAssertTrue(signUp.isHittable && signIn.isHittable && disclosure.isHittable, "The whole card is on the page")
            let card = app.descendants(matching: .any).matching(identifier: "web-search-card").firstMatch
            // The page's name, 「ウェブ検索」 since 1.1.0 (237), is in the bar
            // only, not again as the card's heading.
            for text in app.staticTexts.matching(NSPredicate(format: "label == %@", "ウェブ検索")).allElementsBoundByIndex {
                XCTAssertLessThan(text.frame.midY, card.frame.minY, "No heading in the card repeats the page's name")
            }
            print("WEB-SEARCH settings page \(name): card=\(card.frame) sign-up=\(signUp.frame) title=\(app.navigationBars["ウェブ検索"].frame)")
            capture("settings-web-search-\(name)", app: app)
            disclosure.tap()
            XCTAssertTrue(app.secureTextFields["web-search-key"].waitForExistence(timeout: 3))
            XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "web-search-key-page").firstMatch.exists)
            capture("settings-web-search-\(name)-key-open", app: app)
            app.buttons["settings-back"].tap()
            XCTAssertTrue(gone(app.navigationBars["ウェブ検索"]))
            XCTAssertTrue(app.buttons["settings-row-webSearch"].waitForExistence(timeout: 3), "Back is 設定's rows")
            openSettingsRow("models", title: "モデル管理", app: app)
            let toggle = app.switches["model-download-cellular-toggle"]
            revealModelControl(toggle, app: app)
            let paragraph = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "料金プラン")).firstMatch
            XCTAssertFalse(paragraph.exists, "The cellular switch has no paragraph under it")
            let before = toggle.value as? String
            toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
            XCTAssertNotEqual(toggle.value as? String, before, "The switch still switches")
            toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
            XCTAssertEqual(toggle.value as? String, before)
            let footer = app.staticTexts[Self.cloudHistoryLine]
            revealModelControl(footer, app: app)
            Thread.sleep(forTimeInterval: 0.6)
            XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "web-search-card").firstMatch.exists,
                           "モデル管理 no longer holds web search")
            print("WEB-SEARCH settings models end \(name): cellular=\(toggle.frame) footer=\(footer.frame)")
            capture("settings-models-end-\(name)", app: app)
            app.terminate()
        }
    }

    @MainActor private func firstExisting(_ elements: [XCUIElement], timeout: TimeInterval) -> XCUIElement? {
        let deadline = Date().addingTimeInterval(timeout)
        repeat {
            if let found = elements.first(where: \.exists) { return found }
            Thread.sleep(forTimeInterval: 0.5)
        } while Date() < deadline
        return nil
    }

    @MainActor private func webSearchItem(_ app: XCUIApplication) -> XCUIElement {
        app.descendants(matching: .any).matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                                             "chat-web-search", "ウェブ検索", "ウェブ検索,")).firstMatch
    }

    /// Dark mode with Reduce Motion: the panel and the buttons cross-fade in
    /// place, and both still work. Opening another chat brings the panel.
    @MainActor func testComposerFoldInDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--long-chat", "--dark", "--reduce-motion"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        capture("composer-rest-dark-reduced", app: app)
        dragReading(app, towardOlder: true)
        let chat = app.buttons["composer-expand"]
        XCTAssertTrue(chat.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertTrue(gone(menu))
        XCTAssertTrue(app.buttons["composer-voice"].isHittable)
        XCTAssertTrue(app.buttons["composer-jump"].isHittable)
        capture("composer-folded-dark-reduced", app: app)
        // At the end the latest button fades in place and the other two
        // slide over to the middle.
        let voice = app.buttons["composer-voice"], middle = app.windows.firstMatch.frame.midX
        menuMark("dark-reduced-absorb"); app.buttons["composer-jump"].tap()
        XCTAssertTrue(gone(app.buttons["composer-jump"], timeout: 4))
        Thread.sleep(forTimeInterval: 0.5)
        XCTAssertEqual(chat.frame.midX - middle, 36, accuracy: 1)
        XCTAssertEqual(middle - voice.frame.midX, 36, accuracy: 1)
        XCTAssertTrue(voice.isHittable)
        XCTAssertFalse(menu.exists, "Reaching the end does not open the composer")
        capture("composer-tuck-dark-reduced", app: app)
        chat.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        XCTAssertTrue(menu.waitForExistence(timeout: 3))
        capture("composer-unfolded-dark-reduced", app: app)
        // Fold again, then start a new chat from the history: it opens with
        // the panel, ready to type.
        dragReading(app, towardOlder: true)
        XCTAssertTrue(chat.waitForExistence(timeout: 4))
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["history-compose"].tap()
        XCTAssertTrue(menu.waitForExistence(timeout: 4), "A new chat opens with the panel")
        XCTAssertTrue(gone(chat))
    }

    /// E4B only: a 高速・じっくり考える pill beside the plus shows the saved
    /// choice and changes it from its menu; E2B and Qwen have none.
    @MainActor func testComposerPhotoDetailPillOnlyForE4B() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let pill = app.buttons["composer-photo-detail"]
        XCTAssertTrue(pill.waitForExistence(timeout: 3), "E4B offers the photo detail")
        print("COMPOSER photo-detail pill=\(pill.frame) plus=\(menu.frame) value=\(pill.value ?? "")")
        XCTAssertEqual(pill.value as? String, "高速")
        XCTAssertEqual(pill.frame.midY, menu.frame.midY, accuracy: 1, "On the plus's row")
        XCTAssertGreaterThanOrEqual(pill.frame.minX, menu.frame.maxX - 1, "Right of the plus")
        XCTAssertLessThan(pill.frame.maxX, app.buttons["送信する"].frame.minX)
        capture("composer-photo-detail", app: app)
        // Let launch settle before opening the menu, as the plus menu checks do.
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        XCTAssertTrue(deep.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-photo-detail-menu", app: app)
        deep.tap()
        XCTAssertTrue(gone(deep))
        XCTAssertEqual(pill.value as? String, "じっくり考える")
        app.terminate()
        for flags in [["--e2b"], ["--qwen3"]] {
            app.launchArguments = flags; app.launch()
            XCTAssertTrue(menu.waitForExistence(timeout: 10))
            XCTAssertFalse(pill.exists, "\(flags): only E4B offers it")
            app.terminate()
        }
    }

    // MARK: Smart Mode (1.1.0 (249), the user's directive of 2026-10-31)

    /// One question in the chat, as the person sends it, and Smart Mode's
    /// choice the preview's reply ends with (SMART lines).
    @MainActor private func askSmart(_ text: String, expect choice: String, send: String = "送信する", app: XCUIApplication) {
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText(text)
        app.buttons[send].tap()
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", choice)).firstMatch
        let found = reply.waitForExistence(timeout: 12)
        // Read a value only from what is there: without Smart Mode (the
        // Smart Memory tests) there is no genre pill, and asking a missing
        // element for its value fails the test.
        let model = app.buttons["chat-model-settings"], genre = app.buttons["composer-genre"]
        print("SMART asked='\(text)' expected='\(choice)' found=\(found) model=\(model.exists ? ((model.value as? String) ?? "") : "none")"
              + " genre=\(genre.exists ? ((genre.value as? String) ?? "") : "none")")
        XCTAssertTrue(found, "'\(text)' answered as \(choice)")
        XCTAssertTrue(app.buttons[send].waitForExistence(timeout: 10), "The reply ended")
    }

    @MainActor private func chooseGenre(_ title: String, app: XCUIApplication) {
        let pill = app.buttons["composer-genre"]
        XCTAssertTrue(pill.waitForExistence(timeout: 5))
        pill.tap()
        let item = menuItem(title, title, app)
        XCTAssertTrue(item.waitForExistence(timeout: 3), "\(title) in the genre menu")
        item.tap()
        XCTAssertTrue(gone(item))
    }

    /// In place of the reply mode and the model, one genre pill beside the
    /// plus, 自動 at first; its menu lists the seven genres. A genre named
    /// applies from the next question, also when changed while a reply is
    /// written, which goes on as it began; 自動 reads each question; the
    /// chat moves to the model chosen. A new chat starts on 自動 and the chat
    /// it left keeps its genre.
    @MainActor func testSmartModeGenreChoosesTheModelAndTheReply() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--smart-mode", "--e2b", "--slow-reply"]; app.launch()
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-genre"], send = app.buttons["送信する"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertTrue(pill.waitForExistence(timeout: 3), "The genre pill")
        XCTAssertEqual(pill.value as? String, "自動")
        XCTAssertFalse(app.buttons["composer-photo-detail"].exists, "No reply mode in a Smart Mode chat")
        XCTAssertFalse(app.buttons["composer-model"].exists, "No model menu in a Smart Mode chat")
        print("SMART pill=\(pill.frame) plus=\(plus.frame) send=\(send.frame)")
        XCTAssertEqual(pill.frame.midY, plus.frame.midY, accuracy: 1, "On the plus's row")
        XCTAssertGreaterThanOrEqual(pill.frame.minX, plus.frame.maxX - 1, "Right of the plus")
        XCTAssertLessThan(pill.frame.maxX, send.frame.minX)
        let line = app.staticTexts["chat-model-line"]
        XCTAssertTrue(line.exists)
        XCTAssertEqual(line.label, "質問に合わせて自動で選びます")
        capture("smart-composer", app: app)
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        let math = menuItem("数学", "数学", app)
        XCTAssertTrue(math.waitForExistence(timeout: 3))
        for title in ["自動", "推論", "数学", "文章要約", "ファイル要約", "プログラミング", "ウェブ検索"] {
            XCTAssertTrue(menuItem(title, title, app).exists, "\(title) in the menu")
        }
        Thread.sleep(forTimeInterval: 0.8)
        capture("smart-genre-menu", app: app)
        math.tap()
        XCTAssertTrue(gone(math))
        XCTAssertEqual(pill.value as? String, "数学")
        // Changed while the reply is written: the reply goes on as it began.
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("こんにちは")
        send.tap()
        chooseGenre("自動", app: app)
        XCTAssertEqual(pill.value as? String, "自動")
        let first = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Smart: 数学 / Gemma 4 E4B · 考えてから返信")).firstMatch
        XCTAssertTrue(first.waitForExistence(timeout: 12), "The reply sent under 数学 kept it")
        XCTAssertTrue(send.waitForExistence(timeout: 10))
        // The chat moved from E2B to E4B (the reply says so); its top stays
        // Fielua's (1.1.0 (251)).
        XCTAssertEqual(app.buttons["chat-model-settings"].value as? String, "Fielua", "The top stays Fielua's as the model moves")
        askSmart("2x + 3 = 11 を解いて", expect: "Smart: 自動 · 数学 / Gemma 4 E4B · 考えてから返信", app: app)
        askSmart("こんにちは", expect: "Smart: 自動 · 会話 / Gemma 4 E4B · 速さを優先", app: app)
        capture("smart-replies", app: app)
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        Thread.sleep(forTimeInterval: 0.8)
        pill.tap()
        let last = app.buttons.matching(NSPredicate(format: "identifier == %@ OR label BEGINSWITH %@",
                                                    "composer-genre-last", "Gemma 4 E4B · 速さを優先")).firstMatch
        XCTAssertTrue(last.waitForExistence(timeout: 3), "The menu says what the last reply was answered with")
        print("SMART last-row label='\(last.label)'")
        Thread.sleep(forTimeInterval: 0.8)
        capture("smart-genre-menu-last", app: app)
        let programming = menuItem("プログラミング", "プログラミング", app)
        programming.tap()
        XCTAssertTrue(gone(programming))
        XCTAssertEqual(pill.value as? String, "プログラミング")
        // A new chat starts on 自動; the chat left keeps プログラミング.
        openEmptyChat(app)
        XCTAssertEqual(pill.value as? String, "自動", "A new chat starts on 自動")
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 3))
        app.buttons["会話を開く: 画面の動きを確認"].tap()
        XCTAssertTrue(app.staticTexts["画面の動きを確認"].waitForExistence(timeout: 3))
        XCTAssertTrue(pill.waitForExistence(timeout: 3))
        XCTAssertEqual(pill.value as? String, "プログラミング", "The chat kept its genre")
        capture("smart-genre-restored", app: app)
    }

    /// Dark mode in English: the pill and its menu in the app's words.
    @MainActor func testSmartModeInDarkModeInEnglish() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["-AppleLanguages", "(en)", "--reset-settings", "--smart-mode", "--dark"]; app.launch()
        let pill = app.buttons["composer-genre"]
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        XCTAssertEqual(pill.value as? String, "Auto")
        XCTAssertEqual(pill.label, "Question Type")
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        let item = menuItem("Programming", "Programming", app)
        XCTAssertTrue(item.waitForExistence(timeout: 3))
        for title in ["Auto", "Reasoning", "Math", "Summarize Text", "Summarize File", "Web Search"] {
            XCTAssertTrue(menuItem(title, title, app).exists, "\(title) in the menu")
        }
        Thread.sleep(forTimeInterval: 0.8)
        capture("smart-genre-menu-dark-en", app: app)
        item.tap()
        XCTAssertTrue(gone(item))
        askSmart("hello", expect: "Smart: Programming / Gemma 4 E4B · Thinks First", send: "Send", app: app)
        capture("smart-reply-dark-en", app: app)
    }

    /// ウェブ検索 asks for the Tavily connection as the plus menu does; with
    /// it, the genre's questions search, and 自動's never do.
    @MainActor func testSmartModeWebSearchUsesTheConnection() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--smart-mode", "--web-search-no-key"]; app.launch()
        let pill = app.buttons["composer-genre"]
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        chooseGenre("ウェブ検索", app: app)
        let alert = app.alerts["ウェブ検索にはTavilyへの接続が必要です"]
        XCTAssertTrue(alert.waitForExistence(timeout: 3), "The connection's note")
        capture("smart-search-needs-connection", app: app)
        alert.buttons["キャンセル"].tap()
        XCTAssertEqual(pill.value as? String, "自動", "Not chosen without the connection")
        app.terminate()
        app.launchArguments = ["--reset-settings", "--smart-mode", "--web-search-key"]; app.launch()
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        chooseGenre("ウェブ検索", app: app)
        XCTAssertEqual(pill.value as? String, "ウェブ検索")
        capture("smart-search-on", app: app)
        let headers = app.descendants(matching: .any).matching(identifier: "reply-web-search")
        askSmart("スカイツリーの高さは？", expect: "Smart: ウェブ検索 / Gemma 4 E4B · 標準", app: app)
        XCTAssertEqual(headers.count, 1, "The genre's question searched")
        chooseGenre("自動", app: app)
        askSmart("最新のニュースを教えて", expect: "Smart: 自動 · 会話", app: app)
        XCTAssertEqual(headers.count, 1, "自動 never searches")
        capture("smart-search-auto", app: app)
    }

    /// A chat whose model the person chose keeps its reply mode and model
    /// menu, and may go back to Smart Mode from that menu; モデル管理's switch
    /// turns Smart Mode off for every chat.
    @MainActor func testSmartModeLeavesAChosenModelAndTurnsOff() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--smart-mode", "--smart-pinned"]; app.launch()
        let model = app.buttons["composer-model"], pill = app.buttons["composer-genre"]
        XCTAssertTrue(model.waitForExistence(timeout: 10), "A chosen model keeps its menu")
        XCTAssertTrue(app.buttons["composer-photo-detail"].exists, "and E4B's reply mode")
        XCTAssertFalse(pill.exists)
        Thread.sleep(forTimeInterval: 1.0)
        model.tap()
        let back = menuItem("model-menu-smart", "質問に合わせて自動で選ぶ", app)
        XCTAssertTrue(back.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("smart-pinned-model-menu", app: app)
        back.tap()
        XCTAssertTrue(pill.waitForExistence(timeout: 3), "Smart Mode's again")
        XCTAssertFalse(model.exists)
        Thread.sleep(forTimeInterval: 0.8)
        pill.tap()
        chooseMenuAction("composer-genre-manage", app: app)
        XCTAssertTrue(app.navigationBars["モデル管理"].waitForExistence(timeout: 5))
        // The switch is in 設定's 試験機能を試してみる since 1.1.0 (250).
        XCTAssertFalse(app.switches["model-smart-mode-toggle"].exists, "Not in モデル管理")
        app.buttons["settings-back"].tap()
        openSettingsRow("experiments", title: "試験機能を試してみる", app: app)
        let toggle = app.switches["model-smart-mode-toggle"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        XCTAssertEqual(toggle.value as? String, "1", "On, as this chat's launch turned it on")
        XCTAssertTrue(app.staticTexts["model-smart-mode-caption"].exists)
        XCTAssertTrue(app.staticTexts["experiments-lead"].exists)
        Thread.sleep(forTimeInterval: 0.6)
        capture("smart-settings-on", app: app)
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "0")
        capture("smart-settings-off", app: app)
        app.buttons["settings-close"].tap()
        XCTAssertTrue(model.waitForExistence(timeout: 5), "Off: the model menu is back")
        XCTAssertFalse(pill.exists)
        XCTAssertTrue(app.buttons["composer-photo-detail"].exists)
        capture("smart-off-composer", app: app)
    }

    /// 試験機能を試してみる (1.1.0 (250)): Smart Mode is off until its switch
    /// there is turned on; on, the next chat has the genre pill.
    @MainActor func testExperimentsPageTurnsSmartModeOn() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"]; app.launch()
        let model = app.buttons["composer-model"], pill = app.buttons["composer-genre"]
        XCTAssertTrue(model.waitForExistence(timeout: 10), "Off: the model menu as before")
        XCTAssertFalse(pill.exists)
        openSettingsFromChat(app)
        let row = app.buttons["settings-row-experiments"], about = app.buttons["settings-row-about"]
        XCTAssertTrue(row.exists)
        XCTAssertLessThan(app.buttons["settings-row-pc"].frame.midY, row.frame.midY, "After the first rows")
        XCTAssertLessThan(row.frame.midY, about.frame.midY, "Before Fieluaの情報")
        Thread.sleep(forTimeInterval: 0.6)
        capture("smart-settings-home", app: app)
        openSettingsRow("experiments", title: "試験機能を試してみる", app: app)
        let toggle = app.switches["model-smart-mode-toggle"]
        XCTAssertTrue(toggle.waitForExistence(timeout: 3))
        XCTAssertEqual(toggle.value as? String, "0", "Off until turned on")
        Thread.sleep(forTimeInterval: 0.6)
        capture("smart-experiments-off", app: app)
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        app.buttons["settings-close"].tap()
        XCTAssertTrue(pill.waitForExistence(timeout: 5), "On: the genre pill")
        XCTAssertFalse(model.exists)
        XCTAssertEqual(pill.value as? String, "自動")
    }

    // MARK: 会話履歴, Smart Memory and Fielua at the top (1.1.0 (251))

    /// A chat history row of 設定 › 会話履歴, by its chat's title.
    @MainActor private func historyRow(_ title: String, _ app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier == %@ AND label == %@", "chat-history-row", title)).firstMatch
    }

    /// 設定's 会話履歴, under モデル管理, lists the saved chats; several are
    /// chosen, all or none with one button, and deleting asks first with
    /// their count. Cancelled, nothing goes; confirmed, only the two chosen
    /// go, here and in the history sidebar. HISTORY lines; SHOT history-*.
    /// 1.1.0 (252), the user's screenshot of 251: chosen chats next to each
    /// other share one wash, with no rounded corners overlapping between them
    /// (rows touch: no gap and no overlap), and the last chat still scrolls
    /// clear of the delete button.
    @MainActor func testChatHistoryChosenRowsShareOneWash() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--history-fixture", "--long-history"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        openSettingsFromChat(app)
        openSettingsRow("chatHistory", title: "会話履歴", app: app)
        let rows = app.buttons.matching(identifier: "chat-history-row")
        XCTAssertTrue(rows.firstMatch.waitForExistence(timeout: 3))
        app.buttons["chat-history-select-all"].tap()
        let delete = app.buttons["chat-history-delete"]
        XCTAssertTrue(delete.label.hasSuffix("件を削除"))
        Thread.sleep(forTimeInterval: 0.8)
        let frames = rows.allElementsBoundByIndex.prefix(6).map(\.frame)
        print("HISTORY-WASH rows \(frames.map { "\(Int($0.minY))-\(Int($0.maxY))" })")
        for (upper, lower) in zip(frames, frames.dropFirst()) {
            XCTAssertEqual(upper.maxY, lower.minY, accuracy: 1, "Chosen rows meet edge to edge")
        }
        capture("history-settings-all-chosen", app: app)
        // A chat in the middle of the run left out: the washes on both sides
        // round off at it.
        rows.element(boundBy: 2).tap()
        Thread.sleep(forTimeInterval: 0.6)
        capture("history-settings-run-split", app: app)
        let list = app.scrollViews["chat-history-list"]
        for _ in 0..<8 { list.swipeUp() }
        Thread.sleep(forTimeInterval: 1.0)
        let last = rows.allElementsBoundByIndex.max { $0.frame.maxY < $1.frame.maxY }
        print("HISTORY-BAR last row=\(last?.frame ?? .zero) delete=\(delete.frame)")
        XCTAssertLessThanOrEqual(last?.frame.maxY ?? .infinity, delete.frame.minY + 1, "The last chat scrolls clear of the delete button")
        capture("history-settings-bottom", app: app)
    }

    @MainActor func testChatHistoryDeletesTheChosenChats() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--history-fixture"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        openSettingsFromChat(app)
        let row = app.buttons["settings-row-chatHistory"]
        XCTAssertTrue(row.exists, "会話履歴 on 設定's first page")
        XCTAssertLessThan(app.buttons["settings-row-models"].frame.midY, row.frame.midY, "Under モデル管理")
        XCTAssertLessThan(row.frame.midY, app.buttons["settings-row-webSearch"].frame.midY, "Above ウェブ検索")
        Thread.sleep(forTimeInterval: 0.6)
        capture("history-settings-home", app: app)
        openSettingsRow("chatHistory", title: "会話履歴", app: app)
        let rows = app.buttons.matching(identifier: "chat-history-row")
        XCTAssertTrue(rows.firstMatch.waitForExistence(timeout: 3))
        let before = rows.count
        print("HISTORY rows=\(before) titles=\(rows.allElementsBoundByIndex.map(\.label))")
        XCTAssertGreaterThanOrEqual(before, 7, "The six older chats and the sample")
        let delete = app.buttons["chat-history-delete"], all = app.buttons["chat-history-select-all"]
        XCTAssertFalse(delete.isEnabled, "Nothing chosen yet")
        XCTAssertEqual(all.label, "すべて選択")
        all.tap()
        XCTAssertEqual(all.label, "選択を解除")
        XCTAssertEqual(delete.label, "\(before)件を削除")
        all.tap()
        XCTAssertEqual(all.label, "すべて選択")
        XCTAssertFalse(delete.isEnabled, "None chosen again")
        for title in ["カメムシ対策", "夕飯のレシピ"] {
            let item = historyRow(title, app)
            XCTAssertTrue(item.exists, title)
            item.tap()
            XCTAssertTrue(item.isSelected, "\(title) chosen")
        }
        XCTAssertEqual(delete.label, "2件を削除")
        Thread.sleep(forTimeInterval: 0.6)
        capture("history-settings-chosen", app: app)
        delete.tap()
        let alert = app.alerts["2件の会話を削除しますか？"]
        XCTAssertTrue(alert.waitForExistence(timeout: 3), "Asks first, with the count")
        Thread.sleep(forTimeInterval: 0.5)
        capture("history-settings-confirm", app: app)
        alert.buttons["キャンセル"].tap()
        XCTAssertTrue(gone(alert))
        XCTAssertEqual(rows.count, before, "Cancelled: nothing goes")
        delete.tap()
        XCTAssertTrue(alert.waitForExistence(timeout: 3))
        alert.buttons["削除"].tap()
        XCTAssertTrue(gone(historyRow("カメムシ対策", app)))
        XCTAssertFalse(historyRow("夕飯のレシピ", app).exists)
        XCTAssertEqual(rows.count, before - 2, "Only the two chosen go")
        for title in ["旅行の持ち物リスト", "英語メールの添削をお願いします", "写真に写っている花の名前", "iPhoneのバッテリー設定"] {
            XCTAssertTrue(historyRow(title, app).exists, "\(title) stays")
        }
        XCTAssertFalse(delete.isEnabled, "Nothing chosen after deleting")
        print("HISTORY after=\(rows.count)")
        Thread.sleep(forTimeInterval: 0.5)
        capture("history-settings-after", app: app)
        app.buttons["settings-close"].tap()
        let sidebar = app.buttons["会話一覧を開く"]
        XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
        sidebar.tap()
        XCTAssertTrue(app.buttons["会話を開く: 旅行の持ち物リスト"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["会話を開く: カメムシ対策"].exists, "Gone from the sidebar too")
        XCTAssertFalse(app.buttons["会話を開く: 夕飯のレシピ"].exists)
    }

    /// The chat open on screen deleted from 会話履歴: a new chat opens, and
    /// the other chats stay. In dark mode, for its look.
    @MainActor func testChatHistoryDeletingTheOpenChatStartsANewOne() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--history-fixture", "--dark"]; app.launch()
        let sidebar = app.buttons["会話一覧を開く"]
        XCTAssertTrue(sidebar.waitForExistence(timeout: 10))
        sidebar.tap()
        let chat = app.buttons["会話を開く: カメムシ対策"]
        XCTAssertTrue(chat.waitForExistence(timeout: 3))
        chat.tap()
        XCTAssertTrue(app.staticTexts["カメムシ対策"].waitForExistence(timeout: 5), "The chat is open")
        openSettingsFromChat(app)
        openSettingsRow("chatHistory", title: "会話履歴", app: app)
        let item = historyRow("カメムシ対策", app)
        XCTAssertTrue(item.waitForExistence(timeout: 3))
        item.tap()
        Thread.sleep(forTimeInterval: 0.5)
        capture("history-settings-dark", app: app)
        app.buttons["chat-history-delete"].tap()
        let alert = app.alerts["1件の会話を削除しますか？"]
        XCTAssertTrue(alert.waitForExistence(timeout: 3))
        alert.buttons["削除"].tap()
        XCTAssertTrue(gone(item))
        XCTAssertTrue(historyRow("夕飯のレシピ", app).exists)
        app.buttons["settings-close"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["chat-empty"].waitForExistence(timeout: 5), "A new chat is open")
        XCTAssertFalse(app.staticTexts["カメムシ対策"].exists)
        Thread.sleep(forTimeInterval: 0.5)
        capture("history-after-open-deleted", app: app)
    }

    /// The 「過去の会話を参照」 menus: by their words too, so the reply around
    /// one is never taken for it.
    @MainActor private func memoryChipQuery(_ app: XCUIApplication) -> XCUIElementQuery {
        app.buttons.matching(NSPredicate(format: "identifier == %@ AND label BEGINSWITH %@", "reply-memory-sources", "過去の会話を参照"))
    }

    /// The 「過去の会話を参照」 lines on screen, top first, one per reply: a
    /// menu can show as more than one element with its identifier, so they
    /// are told apart by where they are.
    @MainActor private func memoryChips(_ app: XCUIApplication) -> [XCUIElement] {
        var rows = Set<Int>(), chips: [XCUIElement] = []
        for chip in memoryChipQuery(app).allElementsBoundByIndex where chip.exists {
            if rows.insert(Int(chip.frame.midY.rounded())).inserted { chips.append(chip) }
        }
        return chips.sorted { $0.frame.minY < $1.frame.minY }
    }

    /// 試験機能を試してみる's Smart Memory: off until turned on, apart from
    /// Smart Mode's switch. Off, a question gets nothing of the earlier
    /// chats; on, the earlier chat that bears on it (MEMORY lines).
    @MainActor func testExperimentsPageTurnsSmartMemoryOn() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--memory-fixture"]; app.launch()
        openEmptyChat(app)
        askSmart("ミケの誕生日はいつだっけ？", expect: "プレビュー用", app: app)
        XCTAssertFalse(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Memory:")).firstMatch.exists, "Off: nothing recalled")
        XCTAssertFalse(memoryChipQuery(app).firstMatch.exists)
        openSettingsFromChat(app)
        openSettingsRow("experiments", title: "試験機能を試してみる", app: app)
        let memory = app.switches["experiments-smart-memory-toggle"], smart = app.switches["model-smart-mode-toggle"]
        XCTAssertTrue(memory.waitForExistence(timeout: 3))
        XCTAssertEqual(memory.value as? String, "0", "Off until turned on")
        XCTAssertGreaterThan(memory.frame.minY, smart.frame.maxY, "Under Smart Mode's card")
        memory.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(memory.value as? String, "1")
        XCTAssertEqual(smart.value as? String, "0", "Smart Mode stays as it was")
        Thread.sleep(forTimeInterval: 0.6)
        capture("memory-experiments-on", app: app)
        app.buttons["settings-close"].tap()
        askSmart("ミケの誕生日を教えて", expect: "Memory: うちの猫の名前はミケ", app: app)
        print("MEMORY on: recalled the cat's chat")
    }

    /// Smart Memory on: a question about an earlier chat gets it (the reply
    /// names it, and under it 「過去の会話を参照 · 1件」, whose menu opens
    /// that chat); one about nothing asked before gets nothing. Deleted in
    /// 会話履歴, the chat is no longer named under the reply nor found again.
    @MainActor func testSmartMemoryRecallsAndForgetsADeletedChat() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--memory-fixture", "--smart-memory"]; app.launch()
        openEmptyChat(app)
        askSmart("ミケの誕生日はいつだっけ？", expect: "Memory: うちの猫の名前はミケ", app: app)
        let chip = memoryChipQuery(app).firstMatch
        XCTAssertTrue(chip.waitForExistence(timeout: 3), "Under the reply")
        print("MEMORY chip elements=\(memoryChipQuery(app).count) rows=\(memoryChips(app).count) label='\(chip.label)'")
        XCTAssertEqual(chip.label, "過去の会話を参照 · 1件")
        XCTAssertEqual(memoryChips(app).count, 1)
        askSmart("Pythonでリストを逆順にする書き方は？", expect: "Memory: Pythonでリストを逆順にするには？", app: app)
        askSmart("明日の天気は晴れるかな", expect: "Memory: なし", app: app)
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        Thread.sleep(forTimeInterval: 0.8)
        capture("memory-replies", app: app)
        print("MEMORY chips=\(memoryChips(app).count) elements=\(memoryChipQuery(app).count)")
        XCTAssertEqual(memoryChips(app).count, 2, "Two replies were given earlier chats")
        guard let first = memoryChips(app).first else { return }
        first.tap()
        let source = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "うちの猫の名前はミケ")).firstMatch
        XCTAssertTrue(source.waitForExistence(timeout: 3), "The menu names the chat")
        Thread.sleep(forTimeInterval: 0.6)
        capture("memory-sources-menu", app: app)
        // Closed without opening it.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.15)).tap()
        XCTAssertTrue(gone(source))
        openSettingsFromChat(app)
        openSettingsRow("chatHistory", title: "会話履歴", app: app)
        let cat = app.buttons.matching(NSPredicate(format: "identifier == %@ AND label BEGINSWITH %@", "chat-history-row", "うちの猫の名前はミケ")).firstMatch
        XCTAssertTrue(cat.waitForExistence(timeout: 3))
        cat.tap()
        app.buttons["chat-history-delete"].tap()
        let alert = app.alerts["1件の会話を削除しますか？"]
        XCTAssertTrue(alert.waitForExistence(timeout: 3))
        alert.buttons["削除"].tap()
        XCTAssertTrue(gone(cat))
        app.buttons["settings-close"].tap()
        XCTAssertTrue(app.textViews["chat-input"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        print("MEMORY chips after deleting=\(memoryChips(app).count)")
        XCTAssertEqual(memoryChips(app).count, 1, "The deleted chat is no longer named")
        askSmart("ミケの誕生日をもう一度教えて", expect: "Memory: なし", app: app)
        capture("memory-after-delete", app: app)
        // The menu of the Python reply opens its chat.
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        Thread.sleep(forTimeInterval: 0.8)
        guard let python = memoryChips(app).first else { return XCTFail("The Python reply's line") }
        python.tap()
        let pythonChat = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Pythonでリストを逆順にするには？")).firstMatch
        XCTAssertTrue(pythonChat.waitForExistence(timeout: 3))
        pythonChat.tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "items.reverse()")).firstMatch.waitForExistence(timeout: 5),
                      "That chat opened")
    }

    /// A Smart Mode chat shows Fielua's icon and name at the top, from a new
    /// chat on, whatever genre or model answers; a chat whose model was
    /// chosen, and every chat with Smart Mode off, the model as before.
    @MainActor func testSmartModeChatShowsFieluaAtTheTop() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--smart-mode", "--e2b"]; app.launch()
        let header = app.buttons["chat-model-settings"]
        XCTAssertTrue(header.waitForExistence(timeout: 10))
        openEmptyChat(app)
        XCTAssertEqual(header.value as? String, "Fielua", "A new chat, before its first question")
        capture("smart-header-new", app: app)
        askSmart("2x + 3 = 11 を解いて", expect: "Smart: 自動 · 数学 / Gemma 4 E4B", app: app)
        XCTAssertEqual(header.value as? String, "Fielua", "The model moved to E4B; the top did not")
        chooseGenre("プログラミング", app: app)
        XCTAssertEqual(header.value as? String, "Fielua", "Any genre")
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        Thread.sleep(forTimeInterval: 0.8)
        capture("smart-header-replied", app: app)
        app.terminate()
        app.launchArguments = ["--reset-settings", "--smart-mode", "--e2b", "--dark"]; app.launch()
        XCTAssertTrue(header.waitForExistence(timeout: 10))
        XCTAssertEqual(header.value as? String, "Fielua")
        Thread.sleep(forTimeInterval: 1.0)
        capture("smart-header-dark", app: app)
        app.terminate()
        for flags in [["--smart-mode", "--smart-pinned", "--e2b"], ["--e2b"]] {
            app.launchArguments = ["--reset-settings"] + flags; app.launch()
            XCTAssertTrue(header.waitForExistence(timeout: 10))
            XCTAssertEqual(header.value as? String, "Gemma 4 E2B", "\(flags): the model, as before")
            app.terminate()
        }
    }

    /// Without the address space for thinking with photos, a careful
    /// question with a photo answers without thinking, and the reply's
    /// menu says so; the photo goes at 140 on E4B (the reply's choice).
    @MainActor func testSmartModePhotoWithoutTheRoomSaysItDoesNotThink() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--smart-mode", "--narrow-address-space", "--attachment-fixtures"]; app.launch()
        XCTAssertTrue(app.buttons["composer-genre"].waitForExistence(timeout: 10))
        importFixture("sample-image", extension: "png", app: app)
        askSmart("この数式を解いて", expect: "Smart: 自動 · 数学 / Gemma 4 E4B · 標準 / noThinkingWithPhotos", app: app)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Smart: 自動 · 数学")).firstMatch
        if app.keyboards.firstMatch.exists { app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)).tap() }
        Thread.sleep(forTimeInterval: 0.8)
        reply.press(forDuration: 1.0)
        let notice = app.buttons.matching(NSPredicate(format: "label == %@", "アドレス空間が足りないため、考えずに答えます。")).firstMatch
        XCTAssertTrue(notice.waitForExistence(timeout: 3), "The reply's menu says it did not think")
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Gemma 4 E4B · 標準")).firstMatch.exists)
        Thread.sleep(forTimeInterval: 0.6)
        capture("smart-reply-menu-no-room", app: app)
    }

    /// じっくり考える (1.1.0 (248), さらに深く before) where the launch has the
    /// address space for it (the preview, as the TestFlight build on the
    /// phone): the menu offers it second, and its pill keeps the row, 8pt
    /// from the plus and the model pill and clear of the send button, with
    /// its name at the app's text size (fixed since 2026-10-23) on a 402pt
    /// phone and on a 375pt one, where the name may be cut to じっくり. The
    /// pill stays a 36pt capsule. Two launches a case: with four, one case
    /// took 128s, past its 120s bound (run 39703164025).
    @MainActor func testComposerDeeperPillKeepsTheRow() {
        continueAfterFailure = false
        let app = PreviewApp()
        let pill = app.buttons["composer-photo-detail"]
        let deeper = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        app.launchArguments = ["--reset-settings"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertTrue(pill.waitForExistence(timeout: 3))
        // Let launch settle before opening the menu, as the plus menu checks do.
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        XCTAssertTrue(deeper.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-deeper-menu", app: app)
        deeper.tap()
        XCTAssertTrue(gone(deeper))
        XCTAssertEqual(pill.value as? String, "じっくり考える")
        Thread.sleep(forTimeInterval: 0.6)
        let wide = deeperPillKeepsTheRow("default", spare: 8, app: app)
        XCTAssertGreaterThan(wide.width, 2 * wide.height, "On 402pt the pill names its mode")
        app.terminate()
        // The saved choice on a 375pt-wide phone.
        app.launchArguments = ["--narrow-phone"]; app.launch()
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        XCTAssertEqual(pill.value as? String, "じっくり考える")
        Thread.sleep(forTimeInterval: 1.0)
        let named = deeperPillKeepsTheRow("narrow-phone", spare: 7.5, app: app)
        XCTAssertGreaterThan(named.width, 2 * named.height, "On 375pt the pill names its mode")
    }

    /// On a 375pt-wide phone with the largest text no name fits, so the pill
    /// shows its symbol alone. An install without the address space offers
    /// 高速 and じっくり考える too, and a saved じっくり考える stays chosen
    /// there, with a caution sign for its symbol, and the menu's last row
    /// says it answers without thinking.
    @MainActor func testComposerDeeperPillOnANarrowPhone() {
        continueAfterFailure = false
        let app = PreviewApp()
        let pill = app.buttons["composer-photo-detail"]
        let deeper = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        app.launchArguments = ["--reset-settings", "--large-type", "--narrow-phone"]; app.launch()
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        XCTAssertTrue(deeper.waitForExistence(timeout: 3)); deeper.tap()
        XCTAssertTrue(gone(deeper))
        XCTAssertEqual(pill.value as? String, "じっくり考える")
        Thread.sleep(forTimeInterval: 0.6)
        let symbol = deeperPillKeepsTheRow("narrow-large-type", spare: 7.5, app: app)
        XCTAssertLessThan(symbol.width, 2 * symbol.height, "No name fits: the symbol alone")
        app.terminate()
        // Without the room the saved じっくり考える stays, and says so.
        app.launchArguments = ["--narrow-address-space", "--large-type", "--narrow-phone"]; app.launch()
        XCTAssertTrue(pill.waitForExistence(timeout: 10))
        XCTAssertEqual(pill.value as? String, "じっくり考える。今は考える処理を使えません")
        Thread.sleep(forTimeInterval: 1.0)
        deeperPillKeepsTheRow("narrow-fallback-large-type", spare: 7.5, app: app)
        pill.tap()
        let fast = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "高速")).firstMatch
        XCTAssertTrue(fast.waitForExistence(timeout: 3))
        XCTAssertTrue(deeper.exists, "Offered without the room too")
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "今は考える処理を使えません")).firstMatch.exists)
        capture("composer-deeper-narrow-menu", app: app)
        fast.tap()
        XCTAssertTrue(gone(fast))
        XCTAssertEqual(pill.value as? String, "高速")
    }

    /// The 返事のモード pill on the plus's row: a 36pt capsule exactly 8pt
    /// from the plus and the model pill, and `spare` before the send button.
    /// A capsule narrower than the room the row gave it floats there (44pt
    /// either side in run 39697821838). The symbol alone and its chevron make
    /// a capsule under twice as wide as it is tall (59 by 36pt); 深く's name
    /// with the largest text made it 132pt wide.
    @discardableResult @MainActor
    private func deeperPillKeepsTheRow(_ variant: String, spare: CGFloat, app: XCUIApplication) -> CGRect {
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-photo-detail"]
        let model = app.buttons["composer-model"], send = app.buttons["送信する"]
        print("COMPOSER deeper-\(variant) plus=\(plus.frame) pill=\(pill.frame) model=\(model.frame) send=\(send.frame) window=\(app.windows.firstMatch.frame)")
        XCTAssertEqual(pill.frame.midY, plus.frame.midY, accuracy: 1, "\(variant): on the plus's row")
        XCTAssertEqual(model.frame.midY, plus.frame.midY, accuracy: 1, "\(variant): on the plus's row")
        XCTAssertEqual(pill.frame.height, 36, accuracy: 0.5, "\(variant): the 36pt capsule")
        XCTAssertEqual(pill.frame.minX - plus.frame.maxX, 8, accuracy: 0.5, "\(variant): 8pt from the plus")
        XCTAssertEqual(model.frame.minX - pill.frame.maxX, 8, accuracy: 0.5, "\(variant): 8pt from the model pill")
        XCTAssertGreaterThanOrEqual(send.frame.minX - model.frame.maxX, spare, "\(variant): room before the send button")
        capture("composer-deeper-\(variant)-row", app: app)
        return pill.frame
    }

    /// The model pill (beside 高速 for E4B, in its place for E2B) opens a
    /// system menu: Gemma 4 is a submenu of E2B and E4B, the family alone
    /// switches nothing, and the current model has the check. Choosing E2B
    /// opens a new chat with it and keeps the draft's text. Qwen is listed
    /// only with developer settings. The header opens the current model's
    /// generation settings. The plus and the pills never touch.
    @MainActor func testComposerModelMenuLight() { composerModelMenu("light", []) }
    @MainActor func testComposerModelMenuDark() { composerModelMenu("dark", ["--dark"]) }

    /// Gemma 4 12B and Qwen2.5 1.5B for everyone (1.1.0 (204), the user's
    /// 22:01 UTC 2026-10-26): without developer settings the model menu
    /// lists Qwen2.5 after Gemma 4, Qwen3 still left out, and 12B under
    /// Gemma 4, after E2B and E4B, as an item to choose whose subtitle starts
    /// with テスト版 (the shot shows it: the system menu leaves subtitles out
    /// of the label). A tap on 12B opens モデル管理 at its download, where its
    /// card has the テスト版 badge and note, and Qwen2.5's card is among the
    /// others; a 12B chat says it is a test version under the model's name.
    /// Light, dark as the sideload (whose 12B card says to use TestFlight),
    /// and in English.
    @MainActor func testOpenTwelveBLight() { openTwelveB("light", []) }
    @MainActor func testOpenTwelveBDark() { openTwelveB("dark", ["--dark", "--narrow-address-space"]) }
    @MainActor func testOpenTwelveBInEnglish() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["-AppleLanguages", "(en)", "--reset-settings", "--gemma12b"]; app.launch()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 10))
        XCTAssertEqual(chip.value as? String, "Gemma 4 12B")
        let note = app.descendants(matching: .any)["chat-test-version-note"]
        XCTAssertTrue(note.waitForExistence(timeout: 3), "a 12B chat says it is a test version")
        Thread.sleep(forTimeInterval: 0.5)
        capture("composer-chat-open-12b-en", app: app)
        print("COMPOSER open-12b-en chat note='\(note.label)' frame=\(note.frame)")
        XCTAssertEqual(note.label, "This is a beta, so it may not always work correctly.")
        chip.tap()
        // The series (1.1.0 (269)), their lines in English.
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        let qwen = menuItem("model-menu-qwen", "Qwen", app)
        XCTAssertTrue(qwen.exists, "Qwen, a series of its own")
        print("COMPOSER open-12b-en series gemma='\(gemma.label)' qwen='\(qwen.label)' lfm='\(menuItem("model-menu-lfm", "LFM", app).label)' phi='\(menuItem("model-menu-phi", "Phi", app).label)'")
        XCTAssertTrue(gemma.label.contains("Using 12B"), gemma.label)
        XCTAssertTrue(qwen.label.contains("2 models"), qwen.label)
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-open-12b-en-series", app: app)
        gemma.tap()
        let twelve = menuItem("model-menu-gemma-4-12b", "Gemma 4 12B", app)
        XCTAssertTrue(twelve.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-open-12b-en-menu", app: app)
        print("COMPOSER open-12b-en menu label='\(twelve.label)' value='\(twelve.value as? String ?? "")' selected=\(twelve.isSelected)")
        XCTAssertTrue(twelve.isEnabled)
        // dismissMenu waits for a Japanese label; here the menu just closes.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        XCTAssertTrue(gone(twelve), "menu should close")
        // 設定 is the history's (the plus menu has none).
        let history = app.buttons["chat-history"]
        XCTAssertTrue(history.waitForExistence(timeout: 5))
        history.tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["history-settings"].tap()
        openSettingsRow("models", title: "Models", app: app)
        // Every test version's card has the badge (12B, LFM, Phi): any says Beta.
        let badge = app.descendants(matching: .any).matching(identifier: "model-test-version-badge").firstMatch
        let cardNote = app.descendants(matching: .any)["model-test-version-gemma-4-12b"]
        revealModelControl(cardNote, app: app)
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-open-12b-en", app: app)
        print("COMPOSER open-12b-en badge='\(badge.label)' note='\(cardNote.label)' use='\(app.buttons["model-use-gemma-4-12b"].label)'")
        XCTAssertEqual(badge.label, "Beta")
        XCTAssertTrue(cardNote.label.contains("beta"), cardNote.label)
    }

    @MainActor private func openTwelveB(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"] + flags; app.launch()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 10))
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B")
        chip.tap()
        // Qwen2.5 is in Qwen, a series after Gemma (1.1.0 (269)).
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        let qwen = menuItem("model-menu-qwen", "Qwen", app)
        XCTAssertTrue(qwen.exists)
        XCTAssertGreaterThan(qwen.frame.minY, gemma.frame.minY, "Qwen follows Gemma")
        XCTAssertFalse(app.buttons["model-menu-qwen25-15b"].exists, "A series' models only once it is opened")
        print("COMPOSER open-12b-\(variant) series gemma='\(gemma.label)' qwen='\(qwen.label)'")
        qwen.tap()
        let qwen25 = menuItem("model-menu-qwen25-15b", "Qwen2.5 1.5B", app)
        XCTAssertTrue(qwen25.waitForExistence(timeout: 3), "Qwen2.5 is listed without developer settings")
        XCTAssertFalse(app.buttons["model-menu-qwen3-06b"].exists, "Qwen3 stays a developer's")
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-open-12b-\(variant)-menu", app: app)
        print("COMPOSER open-12b-\(variant) qwen25 label='\(qwen25.label)' value='\(qwen25.value as? String ?? "")' enabled=\(qwen25.isEnabled)")
        XCTAssertTrue(qwen25.isEnabled)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        XCTAssertTrue(gone(qwen25), "menu should close")
        chip.tap()
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        gemma.tap()
        let e2b = menuItem("model-menu-gemma-4-e2b", "Gemma 4 E2B", app)
        let e4b = menuItem("model-menu-gemma-4-e4b", "Gemma 4 E4B", app)
        let twelve = menuItem("model-menu-gemma-4-12b", "Gemma 4 12B", app)
        XCTAssertTrue(twelve.waitForExistence(timeout: 3), "12B is in Gemma")
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-open-12b-\(variant)-submenu", app: app)
        print("COMPOSER open-12b-\(variant) menu label='\(twelve.label)' value='\(twelve.value as? String ?? "")' enabled=\(twelve.isEnabled) frame=\(twelve.frame) e2b=\(e2b.frame) e4b=\(e4b.frame)")
        XCTAssertTrue(twelve.isEnabled, "12B can be chosen")
        XCTAssertGreaterThan(e4b.frame.minY, e2b.frame.minY, "E2B, then E4B")
        XCTAssertGreaterThan(twelve.frame.minY, e4b.frame.minY, "12B after E2B and E4B")
        // Not downloaded in the UI check app: its tap opens モデル管理.
        twelve.tap()
        let download = app.buttons["model-download-gemma-4-12b"]
        XCTAssertTrue(download.waitForExistence(timeout: 5), "モデル管理 opens with 12B to download")
        revealModelControl(download, app: app)
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-open-12b-\(variant)-card", app: app)
        let badge = app.descendants(matching: .any)["model-test-version-badge"]
        let note = app.descendants(matching: .any)["model-test-version-gemma-4-12b"]
        let room = app.descendants(matching: .any)["model-room-note-gemma-4-12b"]
        print("COMPOSER open-12b-\(variant) badge='\(badge.label)' badge-frame=\(badge.frame) note='\(note.label)' room=\(room.exists)")
        XCTAssertEqual(badge.label, "テスト版", "テスト版 beside the name")
        XCTAssertEqual(note.label, "テスト版のため、不具合がある場合があります。")
        XCTAssertEqual(room.exists, flags.contains("--narrow-address-space"), "the room note only where the signature lacks the room")
        XCTAssertFalse(app.descendants(matching: .any)["model-locked-gemma-4-12b"].exists, "no locked card")
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B", "the chat keeps its model until 12B is saved")
        // Qwen2.5's card is with the others, to download.
        let qwenDownload = app.buttons["model-download-qwen25-15b"]
        revealModelControl(qwenDownload, app: app)
        XCTAssertFalse(app.staticTexts["開発者向け"].exists, "no developer section without developer settings")
        XCTAssertFalse(app.buttons["model-download-qwen3-06b"].exists)
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists)
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-open-qwen25-\(variant)-card", app: app)
        // A 12B chat says it is a test version under the model's name.
        app.terminate()
        app.launchArguments = ["--gemma12b"] + flags; app.launch()
        let note12 = app.descendants(matching: .any)["chat-test-version-note"]
        XCTAssertTrue(note12.waitForExistence(timeout: 10), "a 12B chat says it is a test version")
        XCTAssertEqual(chip.value as? String, "Gemma 4 12B")
        Thread.sleep(forTimeInterval: 0.5)
        capture("composer-chat-open-12b-\(variant)", app: app)
        print("COMPOSER open-12b-\(variant) chat note='\(note12.label)' frame=\(note12.frame)")
        XCTAssertEqual(note12.label, "テスト版のため、不具合がある場合があります。")
    }

    /// Phi-4-mini-reasoning and Qwen3.5 4B for everyone (1.1.0 (205), the
    /// user's directive of 22:19 UTC 2026-10-26): the model menu lists them
    /// after Gemma 4 and before Qwen2.5. A tap on Phi, not saved in the UI
    /// check app, opens モデル管理 at its download, where its card says it
    /// thinks before answering; Qwen3.5's card is with the others. Both
    /// cards read テキスト: they take no photos, videos or files. Light and
    /// dark.
    @MainActor func testNewModelsLight() { newModels("light", []) }
    @MainActor func testNewModelsDark() { newModels("dark", ["--dark"]) }

    @MainActor private func newModels(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"] + flags; app.launch()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 10))
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B")
        chip.tap()
        // By series (1.1.0 (269)): Gemma, Qwen, LFM, Phi.
        let series = [("gemma", "Gemma"), ("qwen", "Qwen"), ("lfm", "LFM"), ("phi", "Phi")].map { menuItem("model-menu-\($0.0)", $0.1, app) }
        XCTAssertTrue(series[0].waitForExistence(timeout: 3))
        for item in series { XCTAssertTrue(item.exists, item.identifier) }
        for (a, b) in zip(series, series.dropFirst()) { XCTAssertGreaterThan(b.frame.minY, a.frame.minY, "\(b.identifier) after \(a.identifier)") }
        XCTAssertFalse(app.buttons["model-menu-phi-4-mini-reasoning"].exists || app.buttons["model-menu-qwen35-4b"].exists,
                       "No model of a closed series")
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-new-models-\(variant)-menu", app: app)
        print("COMPOSER new-models-\(variant) series " + series.map { "\($0.identifier)='\($0.label)' frame=\($0.frame)" }.joined(separator: " "))
        series[1].tap()
        let qwen35 = menuItem("model-menu-qwen35-4b", "Qwen3.5 4B", app)
        let qwen25 = menuItem("model-menu-qwen25-15b", "Qwen2.5 1.5B", app)
        XCTAssertTrue(qwen35.waitForExistence(timeout: 3), "Qwen3.5 is listed without developer settings")
        XCTAssertTrue(qwen25.exists)
        XCTAssertFalse(app.buttons["model-menu-qwen3-06b"].exists, "Qwen3 stays a developer's")
        XCTAssertGreaterThan(qwen25.frame.minY, qwen35.frame.minY, "Qwen3.5, then Qwen2.5")
        XCTAssertTrue(qwen35.isEnabled)
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-new-models-\(variant)-qwen", app: app)
        print("COMPOSER new-models-\(variant) qwen35 label='\(qwen35.label)' frame=\(qwen35.frame) qwen25=\(qwen25.frame)")
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        XCTAssertTrue(gone(qwen35), "menu should close")
        // LFM: its three test versions.
        chip.tap()
        openModelSeries("lfm", "LFM", app)
        let lfm = [("lfm3-17b", "LFM3 1.7B"), ("lfm3-vl-2b", "LFM3-VL 2B"), ("lfm3-omni-2b", "LFM3-Omni 2B")].map { menuItem("model-menu-\($0.0)", $0.1, app) }
        XCTAssertTrue(lfm[0].waitForExistence(timeout: 3))
        // An item's label is its name alone; テスト版 is its subtitle (the shot).
        for item in lfm { XCTAssertTrue(item.exists && item.isEnabled, "\(item.identifier) '\(item.label)'") }
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-new-models-\(variant)-lfm", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        XCTAssertTrue(gone(lfm[0]), "menu should close")
        // Phi, not saved in the UI check app: its tap opens モデル管理.
        chip.tap()
        openModelSeries("phi", "Phi", app)
        let phi = menuItem("model-menu-phi-4-mini-reasoning", "Phi-4-mini-reasoning", app)
        XCTAssertTrue(phi.waitForExistence(timeout: 3), "Phi is listed without developer settings")
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-new-models-\(variant)-phi", app: app)
        print("COMPOSER new-models-\(variant) phi label='\(phi.label)' frame=\(phi.frame)")
        XCTAssertTrue(phi.isEnabled)
        phi.tap()
        let download = app.buttons["model-download-phi-4-mini-reasoning"]
        XCTAssertTrue(download.waitForExistence(timeout: 5), "モデル管理 opens with Phi to download")
        revealModelControl(download, app: app)
        let note = app.descendants(matching: .any)["model-reasoning-note-phi-4-mini-reasoning"]
        XCTAssertTrue(note.exists, "Phi's card says it thinks first")
        XCTAssertEqual(note.label, "答える前に考えるため、返信が始まるまで時間がかかります。")
        // Phi is a test version: its later turns were unsteady on the CPU (205).
        XCTAssertTrue(app.descendants(matching: .any)["model-test-version-phi-4-mini-reasoning"].exists, "Phi's card says テスト版")
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-new-models-\(variant)-phi", app: app)
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B", "the chat keeps its model until Phi is saved")
        let qwenDownload = app.buttons["model-download-qwen35-4b"]
        revealModelControl(qwenDownload, app: app)
        XCTAssertTrue(qwenDownload.exists, "Qwen3.5's card is with the others, to download")
        XCTAssertFalse(app.descendants(matching: .any)["model-reasoning-note-qwen35-4b"].exists)
        XCTAssertFalse(app.descendants(matching: .any)["model-test-version-qwen35-4b"].exists, "Qwen3.5 is no test version")
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-new-models-\(variant)-qwen35", app: app)
        print("COMPOSER new-models-\(variant) phi-note='\(note.label)' qwen35-download=\(qwenDownload.frame)")
    }

    /// モデル管理's name (1.1.0 (231), fielua-reports Issue #6): large over
    /// the list with one line under it on opening, carried up into the bar
    /// as the list scrolls, where it lines up with 閉じる, large again back
    /// at the top, and large again the next time the page opens; 戻る and
    /// 閉じる work with it in the bar. The sheet's top band at each step on
    /// one image (SHOT settings-model-title-strip-*), the frames as
    /// SETTINGS-TOUR model-title lines. Light, dark with Reduce Motion (the
    /// large name scrolls away and the small one fades in), and an iPad.
    @MainActor func testModelPageLargeTitle() { modelPageLargeTitle("light", []) }
    @MainActor func testModelPageLargeTitleDarkReducedMotion() { modelPageLargeTitle("reduced-dark", ["--dark", "--reduce-motion"]) }
    @MainActor func testModelPageLargeTitleOnIPad() { modelPageLargeTitle("ipad", []) }

    @MainActor private func modelPageLargeTitle(_ name: String, _ arguments: [String]) {
        continueAfterFailure = false
        let reduced = arguments.contains("--reduce-motion")
        // The probe keeps the list where each drag leaves it (no settling),
        // as for 設定's own title strip.
        let app = PreviewApp(); app.launchArguments = ["--reset-settings", "--settings-title-probe"] + arguments; app.launch()
        openSettingsFromHistory(app)
        openSettingsRow("models", title: "モデル管理", app: app)
        let title = app.descendants(matching: .any)["settings-large-title"]
        let lead = app.descendants(matching: .any)["model-page-lead"]
        let list = app.scrollViews["model-list"]
        let back = app.buttons["settings-back"], close = app.buttons["settings-close"]
        XCTAssertTrue(title.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.8)
        var shots: [UIImage] = [], labels: [String] = []
        func shoot(_ step: String) {
            Thread.sleep(forTimeInterval: 0.35)
            shots.append(XCUIScreen.main.screenshot().image)
            labels.append("\(step)  y \(Int(title.frame.midY)) h \(Int(title.frame.height))")
            print("SETTINGS-TOUR model-title \(name) \(step) title=\(title.frame) lead=\(lead.frame) back=\(back.isHittable) close=\(close.isHittable)")
            XCTAssertTrue(back.isHittable && close.isHittable, "戻る and 閉じる stay usable (\(step))")
        }
        func drag(_ dy: CGFloat) {
            let start = list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: dy)),
                        withVelocity: .slow, thenHoldForDuration: 0.4)
        }
        let rest = title.frame.midY, leadRest = lead.frame.minY
        print("SETTINGS-TOUR model-title \(name) close=\(close.frame) back=\(back.frame) list=\(list.frame)")
        XCTAssertEqual(title.label, "モデル管理")
        XCTAssertTrue(lead.isHittable, "The line under the name shows on opening")
        if !reduced {
            XCTAssertGreaterThan(rest, close.frame.maxY, "On opening, the name is large under the bar")
            XCTAssertLessThan(rest, lead.frame.minY, "The line is under the name")
        }
        shoot("rest")
        for step in 1...5 { drag(-22); shoot("up\(step)") }
        drag(-140); shoot("further")
        if !reduced {
            XCTAssertEqual(title.frame.midY, close.frame.midY, accuracy: 6, "Scrolled up, the name sits in the bar, in line with 閉じる")
        }
        XCTAssertLessThan(lead.frame.maxY, close.frame.maxY + 12, "The line has gone up with the list")
        for step in 1...4 { drag(40); shoot("down\(step)") }
        // Just to the top, as the line shows how far is left: pulled far
        // below it, the sheet would close.
        drag(max(leadRest - lead.frame.minY, 0) + 20); shoot("top")
        if !reduced { XCTAssertEqual(title.frame.midY, rest, accuracy: 3, "Back at the top, the name is large again") }
        XCTAssertTrue(lead.isHittable, "Back at the top, the line shows again")
        let band = min(list.frame.minY, close.frame.minY - 10)
        settingsBandSheet("settings-model-title-strip-\(name)", shots: shots, labels: labels, band: band)
        // In the bar, 戻る goes back to 設定's rows; opened again the name is
        // large, and with it in the bar 閉じる closes the sheet.
        drag(-260)
        back.tap()
        XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 4), "戻る works with the name in the bar")
        XCTAssertTrue(gone(app.navigationBars["モデル管理"]))
        openSettingsRow("models", title: "モデル管理", app: app)
        Thread.sleep(forTimeInterval: 0.8)
        print("SETTINGS-TOUR model-title \(name) reopened title=\(title.frame) rest=\(rest)")
        if !reduced { XCTAssertEqual(title.frame.midY, rest, accuracy: 3, "Opened again, the name is large") }
        capture("settings-model-title-\(name)-reopened", app: app)
        drag(-260)
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-model-title-\(name)-docked", app: app)
        close.tap()
        XCTAssertTrue(gone(app.navigationBars["モデル管理"], timeout: 4), "閉じる works with the name in the bar")
    }

    /// モデル管理's cards in words (1.1.0 (225), fielua-reports Issue #4):
    /// the two gauges are gone; each card says 回答の速さ in one of five
    /// words, or 未評価 for a model nobody timed on an iPhone (Qwen2.5),
    /// 端末への負担 in one of three, 必要メモリ and 保存容量 apart, and under
    /// 詳細 what the words rest on; that they are estimates is said once,
    /// above the cards (1.1.0 (231); in the page's first card from 227),
    /// under the page's large name and its line. Opened from the model menu
    /// at Qwen2.5's download, then read from the top. Light, dark, English,
    /// and an iPad (iPadへの負担). COMPOSER model-facts lines; SHOT
    /// settings-model-facts-*.
    @MainActor func testModelCardFactsLight() { modelCardFacts("light", []) }
    @MainActor func testModelCardFactsDark() { modelCardFacts("dark", ["--dark"]) }
    @MainActor func testModelCardFactsInEnglish() { modelCardFacts("en", ["-AppleLanguages", "(en)"]) }
    @MainActor func testModelCardFactsOnIPad() { modelCardFacts("ipad", []) }

    @MainActor private func modelCardFacts(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let english = flags.contains("(en)")
        // The iPad case runs on its own iPad simulator (check-ui.sh).
        let pad = variant == "ipad"
        let app = PreviewApp(); app.launchArguments = flags + ["--reset-settings"]; app.launch()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 10))
        chip.tap()
        XCTAssertTrue(menuItem("model-menu-gemma", "Gemma", app).waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-model-facts-\(variant)-0-series", app: app)
        openModelSeries("qwen", "Qwen", app)
        let qwen25 = menuItem("model-menu-qwen25-15b", "Qwen2.5 1.5B", app)
        XCTAssertTrue(qwen25.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture("settings-model-facts-\(variant)-0-qwen", app: app)
        qwen25.tap()
        let download = app.buttons["model-download-qwen25-15b"]
        XCTAssertTrue(download.waitForExistence(timeout: 5), "モデル管理 opens at Qwen2.5's download")
        let speedTitle = english ? "Reply Speed" : "回答の速さ"
        let burdenTitle = english ? (pad ? "Load on iPad" : "Load on iPhone") : (pad ? "iPadへの負担" : "iPhoneへの負担")
        let words = english ? ["Very Slow", "Slow", "Fast", "Very Fast", "Ultra Fast", "Not Rated"]
            : ["かなりゆっくり", "ゆっくり", "速い", "とても速い", "高速", "未評価"]
        let burdens = english ? ["Low", "Moderate", "High"] : ["小さい", "普通", "大きい"]
        // The word a row says after its name: VoiceOver joins the two with
        // 「、」 in Japanese and ", " in English.
        func value(_ row: XCUIElement, _ title: String) -> String {
            row.label.replacingOccurrences(of: title, with: "").trimmingCharacters(in: CharacterSet(charactersIn: ", 、"))
        }
        func fact(_ kind: String, _ id: String) -> XCUIElement { app.descendants(matching: .any)["model-\(kind)-\(id)"] }
        // Qwen2.5 has no iPhone figure: 未評価, not a guess.
        let unrated = fact("speed", "qwen25-15b")
        revealModelFact(unrated, app: app)
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-model-facts-\(variant)-qwen25", app: app)
        XCTAssertEqual(value(unrated, speedTitle), words[5], unrated.label)
        // Under the page's large name, one line on what the page is for;
        // above the cards, once, that the words are estimates (the page's
        // first card said both from 227 to 230). Dragged back only until
        // they show: four swipes down could reach the top early and pull
        // the iPad's small sheet closed (228's iPad run).
        let note = app.descendants(matching: .any)["model-estimate-note"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        revealModelFact(note, app: app)
        XCTAssertEqual(note.label, english ? "Reply speed and memory needed are estimates." : "回答の速さと必要メモリは目安です。")
        let lead = app.descendants(matching: .any)["model-page-lead"]
        revealModelFact(lead, app: app)
        XCTAssertEqual(lead.label, english ? "Download and delete models, and pick one that suits your device."
                                           : "モデルのダウンロードや削除、端末に合うモデルの選択ができます。")
        XCTAssertFalse(app.descendants(matching: .any)["model-page-intro"].exists, "The first card is gone")
        XCTAssertFalse(app.descendants(matching: .any)["model-speed-note-gemma-4-e4b"].exists)
        let title = app.descendants(matching: .any)["settings-large-title"]
        print("COMPOSER model-facts-\(variant) title='\(title.label)' \(title.frame) lead=\(lead.frame) note=\(note.frame)")
        XCTAssertEqual(title.label, english ? "Models" : "モデル管理")
        Thread.sleep(forTimeInterval: 0.5)
        capture("settings-model-facts-\(variant)-intro", app: app)
        // E4B, then E2B, then the test version 12B, Phi and Qwen3.5.
        let expected: [(String, Int)] = [("gemma-4-e4b", 3), ("gemma-4-e2b", 4), ("gemma-4-12b", 2),
                                         ("phi-4-mini-reasoning", 0), ("qwen35-4b", 1)]
        for (index, (id, word)) in expected.enumerated() {
            let speed = fact("speed", id), burden = fact("burden", id)
            revealModelFact(burden, app: app)
            let memory = fact("memory", id), storage = fact("storage", id)
            print("COMPOSER model-facts-\(variant) \(id) speed='\(speed.label)' burden='\(burden.label)' memory='\(memory.label)' storage='\(storage.label)'")
            XCTAssertEqual(value(speed, speedTitle), words[word], speed.label)
            XCTAssertTrue(burden.label.hasPrefix(burdenTitle), burden.label)
            XCTAssertTrue(burdens.contains(value(burden, burdenTitle)), burden.label)
            if index == 0 {
                XCTAssertTrue(memory.label.hasSuffix("5.2 GB"), memory.label)
                XCTAssertTrue(storage.label.hasSuffix("3.66 GB"), storage.label)
                Thread.sleep(forTimeInterval: 0.5)
                capture("settings-model-facts-\(variant)-top", app: app)
            }
            if index == 1 {
                // The spec's example: 必要メモリ 4.0 GB, apart from the 2.59 GB file.
                XCTAssertTrue(memory.label.hasSuffix("4.0 GB"), memory.label)
                XCTAssertTrue(storage.label.hasSuffix("2.59 GB"), storage.label)
                let details = app.descendants(matching: .any)["model-details-gemma-4-e2b"]
                revealModelFact(details, app: app)
                details.tap()
                let basis = app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@",
                    english ? "the distributor's figure" : "配布元の公開値")).firstMatch
                XCTAssertTrue(basis.waitForExistence(timeout: 3), "詳細 says what 高速 rests on")
                revealModelFact(basis, app: app)
                Thread.sleep(forTimeInterval: 0.6)
                capture("settings-model-facts-\(variant)-e2b-details", app: app)
                print("COMPOSER model-facts-\(variant) e2b-details basis='\(basis.label)'")
            }
            if id == "phi-4-mini-reasoning" {
                Thread.sleep(forTimeInterval: 0.5)
                capture("settings-model-facts-\(variant)-phi", app: app)
            }
        }
        // The gauges' words are gone from the page.
        for old in ["モデルの重さ（推定）", "応答の速さ（目安）", "Model Load (Estimated)", "Response Speed (Approx.)"] {
            XCTAssertFalse(app.staticTexts[old].exists, old)
        }
    }

    /// Scrolls モデル管理 until the element is on screen, whichever way it is.
    @MainActor private func revealModelFact(_ element: XCUIElement, app: XCUIApplication) {
        let list = app.scrollViews["model-list"]
        for _ in 0..<16 {
            if element.exists && element.isHittable { break }
            if element.exists && element.frame.maxY < list.frame.minY + 80 {
                list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
                    .press(forDuration: 0.05, thenDragTo: list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.75)))
            } else {
                list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.75))
                    .press(forDuration: 0.05, thenDragTo: list.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)))
            }
        }
        XCTAssertTrue(element.isHittable, "\(element.identifier) on screen")
    }

    @MainActor private func composerModelMenu(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--reset-settings"] + flags; app.launch()
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-photo-detail"]
        let chip = app.buttons["composer-model"], send = app.buttons["送信する"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertTrue(chip.waitForExistence(timeout: 3))
        print("COMPOSER chips-\(variant) plus=\(plus.frame) pill=\(pill.frame) model=\(chip.frame) send=\(send.frame) composer=\(app.descendants(matching: .any)["chat-composer"].frame)")
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B")
        // Each frame is the button's glass shape: they stand 8pt apart.
        XCTAssertGreaterThanOrEqual(pill.frame.minX - plus.frame.maxX, 7.5, "The plus and 高速 stand apart")
        XCTAssertGreaterThanOrEqual(chip.frame.minX - pill.frame.maxX, 7.5, "高速 and the model pill stand apart")
        XCTAssertEqual(chip.frame.midY, plus.frame.midY, accuracy: 1, "On the plus's row")
        XCTAssertLessThan(chip.frame.maxX, send.frame.minX)
        capture("composer-model-\(variant)-pills", app: app)
        // The header: the current model's settings, not the model list.
        app.buttons["chat-model-settings"].tap()
        let owner = app.staticTexts["configuration-model"]
        XCTAssertTrue(owner.waitForExistence(timeout: 4))
        XCTAssertEqual(owner.label, "Gemma 4 E4Bの設定")
        XCTAssertTrue(app.textFields["setting-Max Tokens"].exists)
        XCTAssertFalse(app.navigationBars["モデル管理"].exists)
        capture("composer-model-\(variant)-header-settings", app: app)
        // The Form reaches up under the model's name and the tabs.
        let form = app.collectionViews["generation-configuration"]
        let tabs = app.segmentedControls["configuration-tabs"]
        print("COMPOSER settings-\(variant) form=\(form.frame) tabs=\(tabs.frame)")
        app.buttons["キャンセル"].tap()
        XCTAssertTrue(gone(owner))
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Keep this draft")
        Thread.sleep(forTimeInterval: 1.0)
        chip.tap()
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["model-menu-qwen3-06b"].exists, "Qwen only with developer settings")
        XCTAssertTrue(menuItem("model-menu-manage", "モデルを管理", app).exists)
        // The series (1.1.0 (269)): Gemma names the model in use, the
        // others how many models they have.
        let series = [("qwen", "Qwen"), ("lfm", "LFM"), ("phi", "Phi")].map { menuItem("model-menu-\($0.0)", $0.1, app) }
        XCTAssertTrue(gemma.label.contains("E4Bを使用中"), gemma.label)
        for item in series { XCTAssertTrue(item.exists && item.label.contains("モデル") && !item.label.contains("使用中"), "\(item.identifier) '\(item.label)'") }
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-model-\(variant)-menu", app: app)
        print("COMPOSER model-menu-\(variant) gemma=\(gemma.label) frame=\(gemma.frame) " + series.map { "\($0.identifier)='\($0.label)'" }.joined(separator: " "))
        // The series opens its submenu and switches nothing.
        gemma.tap()
        let e2b = menuItem("model-menu-gemma-4-e2b", "Gemma 4 E2B", app)
        let e4b = menuItem("model-menu-gemma-4-e4b", "Gemma 4 E4B", app)
        XCTAssertTrue(e2b.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-model-\(variant)-gemma-submenu", app: app)
        print("COMPOSER model-submenu-\(variant) e2b=\(e2b.label) selected=\(e2b.isSelected) e4b=\(e4b.label) selected=\(e4b.isSelected) e2bFrame=\(e2b.frame) e4bFrame=\(e4b.frame)")
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B", "Gemma alone must not switch")
        // The check is read at the end, after the rest has run.
        let checks = [e4b.isSelected, !e2b.isSelected]
        e2b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4), "E2B opens a new chat")
        XCTAssertEqual(chip.value as? String, "Gemma 4 E2B")
        XCTAssertFalse(pill.exists, "E2B has no 高速・深く; the model pill takes its place")
        XCTAssertEqual(input.value as? String, "Keep this draft", "The draft's text comes along")
        print("COMPOSER model-e2b-\(variant) plus=\(plus.frame) model=\(chip.frame)")
        XCTAssertLessThanOrEqual(plus.frame.maxX, chip.frame.minX + 0.5)
        capture("composer-model-\(variant)-e2b", app: app)
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(owner.waitForExistence(timeout: 4))
        XCTAssertEqual(owner.label, "Gemma 4 E2Bの設定", "The header follows the switch")
        app.buttons["キャンセル"].tap()
        XCTAssertTrue(gone(owner))
        // Back to E4B from the menu: the earlier chat stays in the history.
        chip.tap()
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        gemma.tap()
        XCTAssertTrue(e4b.waitForExistence(timeout: 3))
        let switchedCheck = e2b.isSelected && !e4b.isSelected
        print("COMPOSER model-submenu-\(variant) after switch e2b=\(e2b.isSelected) e4b=\(e4b.isSelected)")
        e4b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 4))
        XCTAssertTrue(pill.waitForExistence(timeout: 3), "高速・深く comes back with E4B")
        app.terminate()
        // Developer settings list Qwen after Gemma 4.
        app.launchArguments = ["--developer-settings"] + flags; app.launch()
        XCTAssertTrue(chip.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        chip.tap()
        let qwenSeries = menuItem("model-menu-qwen", "Qwen", app)
        XCTAssertTrue(qwenSeries.waitForExistence(timeout: 3))
        XCTAssertGreaterThan(qwenSeries.frame.minY, gemma.frame.minY, "Qwen follows Gemma")
        XCTAssertTrue(qwenSeries.label.contains("3モデル"), "Qwen3 0.6B joins Qwen: \(qwenSeries.label)")
        qwenSeries.tap()
        let qwen = menuItem("model-menu-qwen3-06b", "Qwen3 0.6B", app)
        let qwen35 = menuItem("model-menu-qwen35-4b", "Qwen3.5 4B", app)
        XCTAssertTrue(qwen.waitForExistence(timeout: 3), "Developer settings list Qwen3 in Qwen")
        XCTAssertTrue(menuItem("model-menu-qwen25-15b", "Qwen2.5 1.5B", app).exists)
        XCTAssertGreaterThan(qwen.frame.minY, qwen35.frame.minY, "Qwen3.5, then Qwen3")
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-model-\(variant)-developer-menu", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        XCTAssertTrue(gone(qwen))
        XCTAssertEqual(chip.value as? String, "Gemma 4 E4B")
        XCTAssertEqual(checks, [true, true], "E4B has the check, E2B none")
        XCTAssertTrue(switchedCheck, "After the switch E2B has the check")
        // With developer settings the list is long enough to scroll: its
        // first card passes under the name and the tabs and fades there
        // instead of being cut by a line (device, 1.0.114).
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.textFields["setting-TopK"].waitForExistence(timeout: 4))
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.8))
            .press(forDuration: 0.05, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.62)))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-model-\(variant)-settings-scrolled", app: app)
        app.buttons["キャンセル"].tap()
    }

    /// Frames of the fold and the unfold, played five times slower
    /// (`--slow-composer`) so back-to-back screenshots sample the glass as
    /// it splits and merges.
    @MainActor func testComposerMorphFramesLight() { composerMorphFrames("light", []) }
    @MainActor func testComposerMorphFramesDark() { composerMorphFrames("dark", ["--dark"]) }

    @MainActor private func composerMorphFrames(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        // A drag would return only after the morph had finished, so a
        // preview-only target (`--fold-button`) starts the fold.
        let app = PreviewApp(); app.launchArguments = ["--long-chat", "--slow-composer", "--fold-button"] + flags
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        app.buttons["probe-fold"].tap()
        captureStrip("composer-strip-\(variant)-fold", count: 24, top: 0.64, height: 0.36)
        let chat = app.buttons["composer-expand"]
        XCTAssertTrue(chat.waitForExistence(timeout: 6))
        Thread.sleep(forTimeInterval: 2.0)
        capture("composer-folded-\(variant)", app: app)
        chat.tap()
        captureStrip("composer-strip-\(variant)-unfold", count: 16, top: 0.36, height: 0.64)
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 6))
    }

    /// The plus and 高速 menus opened and closed again and again, by a tap
    /// outside and by a choice, with and without the keyboard: the screen
    /// behind them must come back as it was (device report on 1.0.111).
    @MainActor func testComposerMenusLeaveTheScreenAsItWasLight() { composerMenuCycles("light", [], rounds: 2) }
    @MainActor func testComposerMenusLeaveTheScreenAsItWasDark() { composerMenuCycles("dark", ["--dark"], rounds: 1) }

    /// The plus and 高速 menus opened and closed while the session recording
    /// runs, for the frames in between (scope menu-video): the row over the
    /// panel, then the 1.0.114 row inside the panel's glass, in light mode
    /// where the phone showed an afterimage, then the row in dark mode.
    /// MENU-MARK lines time each tap for scripts/menu-frames.swift.
    @MainActor func testComposerMenuFrames() {
        continueAfterFailure = false
        for (variant, flags) in [("light", [String]()), ("dark", ["--dark"])] {
            let app = PreviewApp(); app.launchArguments = ["--long-chat", "--reset-settings"] + flags
            app.launch()
            let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-photo-detail"]
            XCTAssertTrue(plus.waitForExistence(timeout: 10))
            XCTAssertTrue(pill.waitForExistence(timeout: 3))
            print("COMPOSER frames-\(variant) plus=\(plus.frame) pill=\(pill.frame)")
            let points = [("plus", plus.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))),
                          ("detail", pill.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)))]
            let outside = app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35))
            Thread.sleep(forTimeInterval: 1.5)
            for (name, point) in points {
                menuMark("\(variant)-\(name)-open"); point.tap()
                Thread.sleep(forTimeInterval: 1.6)
                if name == "plus" { capture("composer-frames-\(variant)-plus-open", app: app) }
                menuMark("\(variant)-\(name)-close"); outside.tap()
                Thread.sleep(forTimeInterval: 1.6)
            }
            capture("composer-frames-\(variant)-after", app: app)
            XCTAssertTrue(plus.isHittable)
            let input = app.textViews["chat-input"]
            XCTAssertTrue(input.isHittable)
            // A second line of text grows the panel, deleting it shrinks the
            // panel back, both with the keyboard up.
            input.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
            input.typeText("1行目")
            Thread.sleep(forTimeInterval: 1.2)
            menuMark("\(variant)-grow"); input.typeText("\n2行目")
            Thread.sleep(forTimeInterval: 1.6)
            menuMark("\(variant)-shrink"); input.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: 4))
            Thread.sleep(forTimeInterval: 1.6)
            app.terminate()
        }
    }

    private func menuMark(_ name: String) {
        print(String(format: "MENU-MARK %@ %.3f", name, Date().timeIntervalSince1970))
    }

    /// Menu queries are slow (a case of eight cycles took 200 s), so the
    /// rounds are few: closed by a tap outside, then じっくり考える picked,
    /// then with the keyboard up 高速 picked again.
    @MainActor private func composerMenuCycles(_ variant: String, _ flags: [String], rounds: Int) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--long-chat", "--reset-settings"] + flags
        app.launch()
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-photo-detail"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertTrue(pill.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1.5)
        let before = XCUIScreen.main.screenshot().image
        capture("composer-menus-\(variant)-before", app: app)
        let outside = app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35))
        let photos = menuItem("chat-attach-photos", "写真", app)
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        let fast = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "高速")).firstMatch
        func settled(_ label: String, against reference: UIImage) {
            Thread.sleep(forTimeInterval: 0.8)
            let after = XCUIScreen.main.screenshot().image
            print(String(format: "COMPOSER menus-%@ %@ header=%.1f reading=%.1f composer=%.1f", variant, label,
                         screenDifference(reference, after, from: 0, to: 0.16),
                         screenDifference(reference, after, from: 0.16, to: 0.76),
                         screenDifference(reference, after, from: 0.76, to: 1)))
            XCTAssertTrue(plus.isHittable, "\(label): the plus is back")
            XCTAssertTrue(app.textViews["chat-input"].isHittable, "\(label): the field is back")
        }
        func closed(_ item: XCUIElement, _ label: String) {
            if gone(item) { return }
            capture("composer-menus-\(variant)-\(label)-still-open", app: app)
            // Which element still answers to the row's query, and where
            // (runs 39536326226 and 39539688227: the shot showed it closed).
            print("COMPOSER still-open \(label) hittable=\(item.isHittable) frame=\(item.frame)")
            print("COMPOSER still-open element " + item.debugDescription.replacingOccurrences(of: "\n", with: " | "))
            print("COMPOSER still-open collections=\(app.collectionViews.count) menus=\(app.menus.count) keyboard=\(app.keyboards.count)")
            XCTFail("\(label): the menu must close")
        }
        for round in 1...rounds {
            plus.tap()
            XCTAssertTrue(photos.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            if round == 1 { capture("composer-menus-\(variant)-plus-open", app: app) }
            outside.tap()
            if round == 1 { captureStrip("composer-menus-\(variant)-plus-close-strip", count: 8, top: 0, height: 1) }
            closed(photos, "plus-\(round)")
            settled("plus-\(round)", against: before)
            capture("composer-menus-\(variant)-after-plus-\(round)", app: app)
            pill.tap()
            XCTAssertTrue(deep.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            if round == 1 { capture("composer-menus-\(variant)-detail-open", app: app) }
            if round == 2 { deep.tap() } else { outside.tap() }
            if round == 1 { captureStrip("composer-menus-\(variant)-detail-close-strip", count: 8, top: 0, height: 1) }
            closed(deep, "detail-\(round)")
            settled("detail-\(round)", against: before)
            capture("composer-menus-\(variant)-after-detail-\(round)", app: app)
        }
        XCTAssertEqual(pill.value as? String, rounds >= 2 ? "じっくり考える" : "高速")
        // The same with the keyboard up.
        let input = app.textViews["chat-input"]
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.0)
        let typing = XCUIScreen.main.screenshot().image
        capture("composer-menus-\(variant)-keyboard-before", app: app)
        plus.tap()
        XCTAssertTrue(photos.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-menus-\(variant)-keyboard-plus-open", app: app)
        outside.tap()
        closed(photos, "keyboard-plus")
        settled("keyboard-plus", against: typing)
        capture("composer-menus-\(variant)-keyboard-after-plus", app: app)
        pill.tap()
        XCTAssertTrue(fast.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-menus-\(variant)-keyboard-detail-open", app: app)
        if rounds >= 2 { fast.tap() } else { outside.tap() }
        closed(fast, "keyboard-detail")
        settled("keyboard-detail", against: typing)
        XCTAssertEqual(pill.value as? String, "高速")
        capture("composer-menus-\(variant)-keyboard-after-detail", app: app)
    }

    /// Mean difference (0-255 per channel) between two screenshots across
    /// a band of the screen, given as parts of its height.
    @MainActor private func screenDifference(_ first: UIImage, _ second: UIImage, from top: CGFloat, to bottom: CGFloat) -> Double {
        let width = 120, height = 260
        func sample(_ image: UIImage) -> [UInt8]? {
            guard let cgImage = image.cgImage else { return nil }
            var bytes = [UInt8](repeating: 0, count: width * height * 4)
            let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
                guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                              bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                              bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
                context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
                return true
            }
            return drawn ? bytes : nil
        }
        guard let a = sample(first), let b = sample(second) else { return -1 }
        // The buffer's first row is the top of the screen.
        let rows = Int(top * CGFloat(height))..<Int(bottom * CGFloat(height))
        var total = 0, count = 0
        for row in rows {
            for column in 0..<width {
                let index = (row * width + column) * 4
                for channel in 0..<3 { total += abs(Int(a[index + channel]) - Int(b[index + channel])) }
                count += 3
            }
        }
        return count == 0 ? 0 : Double(total) / Double(count)
    }

    /// Waits for an element to leave the screen and the accessibility tree.
    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval = 3) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        // A slow snapshot can outlast the wait though the element has gone
        // (run 39697821838: the menu closed in the strip's first frame, and
        // the next query found no match), so it looks once more.
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed || !element.exists
    }

    /// A drag through the reading area only, clear of the header, the
    /// composer and the keyboard. Toward older messages moves the finger down.
    @MainActor private func dragReading(_ app: XCUIApplication, towardOlder: Bool) {
        let (from, to) = readingDrag(app, towardOlder: towardOlder)
        from.press(forDuration: 0.05, thenDragTo: to)
    }

    /// A slow, short drag that leaves no coast: `points` toward older
    /// messages (the finger moves down).
    @MainActor private func nudgeReading(_ app: XCUIApplication, by points: CGFloat) {
        let reading = app.scrollViews["chat-conversation"]
        let origin = app.coordinate(withNormalizedOffset: .zero)
        let y = reading.frame.minY + reading.frame.height * 0.4
        origin.withOffset(CGVector(dx: reading.frame.midX, dy: y))
            .press(forDuration: 0.2, thenDragTo: origin.withOffset(CGVector(dx: reading.frame.midX, dy: y + points)),
                   withVelocity: 80, thenHoldForDuration: 0.3)
    }

    /// dragReading's two ends, found before the drag so it can be timed.
    @MainActor private func readingDrag(_ app: XCUIApplication, towardOlder: Bool) -> (XCUICoordinate, XCUICoordinate) {
        let reading = app.scrollViews["chat-conversation"]
        let any = app.descendants(matching: .any)
        let edges = [any["chat-composer"], app.buttons["composer-expand"], app.keyboards.firstMatch]
            .filter { $0.exists }.map { $0.frame.minY }
        let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
        let bottom = min(reading.frame.maxY, edges.min() ?? reading.frame.maxY) - 20
        XCTAssertGreaterThan(bottom - top, 120)
        let origin = app.coordinate(withNormalizedOffset: .zero)
        let x = reading.frame.midX
        let upper = top + (bottom - top) * 0.15, lower = top + (bottom - top) * 0.9
        return (origin.withOffset(CGVector(dx: x, dy: towardOlder ? upper : lower)),
                origin.withOffset(CGVector(dx: x, dy: towardOlder ? lower : upper)))
    }

    /// Screenshots taken back to back (they do not wait for the app to go
    /// idle), cropped to the composer area (`top` and `height` as parts of
    /// the screen) and laid out on one sheet.
    @MainActor private func captureStrip(_ name: String, count: Int = 12, top: CGFloat = 0.58, height: CGFloat = 0.36) {
        var frames: [UIImage] = []
        var times: [Double] = []
        let start = Date()
        for _ in 0..<count {
            frames.append(XCUIScreen.main.screenshot().image)
            times.append(Date().timeIntervalSince(start))
        }
        guard let first = frames.first else { return }
        let size = first.size
        let crop = CGRect(x: 0, y: size.height * top, width: size.width, height: size.height * height)
        let factor: CGFloat = 0.5
        let cell = CGSize(width: crop.width * factor, height: crop.height * factor)
        let label: CGFloat = 14, columns = 4
        let rows = (frames.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.black.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width,
                                     y: CGFloat(index / columns) * (cell.height + label))
                let target = CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height)
                context.cgContext.saveGState()
                context.cgContext.clip(to: target)
                frame.draw(in: CGRect(x: target.minX - crop.minX * factor, y: target.minY - crop.minY * factor,
                                      width: size.width * factor, height: size.height * factor))
                context.cgContext.restoreGState()
                (String(format: "%d  %.0f ms", index, times[index] * 1000) as NSString)
                    .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// A copy of a screenshot's square around a point, at full resolution.
    /// Drawn into its own image, so the whole screenshot is not kept.
    private func orbCrop(_ shot: UIImage, around centre: CGPoint, side: CGFloat, screenWidth: CGFloat) -> UIImage? {
        guard let image = shot.cgImage, screenWidth > 0 else { return nil }
        let scale = CGFloat(image.width) / screenWidth
        let rect = CGRect(x: (centre.x - side / 2) * scale, y: (centre.y - side / 2) * scale,
                          width: side * scale, height: side * scale).integral
        guard let crop = image.cropping(to: rect) else { return nil }
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: CGSize(width: crop.width, height: crop.height), format: format).image { _ in
            UIImage(cgImage: crop).draw(at: .zero)
        }
    }

    /// The orb's crops laid out on one sheet with their times after the
    /// send, to review its motion.
    @MainActor private func attachOrbStrip(_ name: String, frames: [(t: Double, image: UIImage)]) {
        let columns = 4
        let label: CGFloat = 14
        let cell = frames[0].image.size
        let rows = (frames.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width,
                                     y: CGFloat(index / columns) * (cell.height + label))
                frame.image.draw(in: CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height))
                (String(format: "%ld  %.1f s", index, frame.t) as NSString)
                    .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor private func historySidebar(_ app: XCUIApplication) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
    }

    /// Opening chats from history, between a long Markdown chat and short
    /// ones, lands at each chat's end, never below its last message. On
    /// device (1.0.58) a chat sometimes opened past its end, and touching it
    /// then counted as the pull that opens a new chat.
    @MainActor func testOpeningChatsFromHistoryLandsAtTheEnd() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--markdown-sample", "--history-fixture"]; app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        func value(_ key: String) -> Double? {
            let label = debug.label
            guard let range = label.range(of: key + "=") else { return nil }
            return Double(label[range.upperBound...].prefix { "-0123456789.".contains($0) })
        }
        func pastEnd() -> Double? {
            guard let content = value("content"), let offset = value("offset"), let container = value("container"),
                  let top = value("insetTop") else { return nil }
            return offset + top + container - max(content, container)
        }
        for (index, title) in ["夕飯のレシピ", "Markdownの表示を確認", "カメムシ対策", "Markdownの表示を確認"].enumerated() {
            open.tap()
            let row = app.buttons["会話を開く: \(title)"]
            XCTAssertTrue(row.waitForExistence(timeout: 3), title)
            row.tap()
            Thread.sleep(forTimeInterval: 1.2)
            let past = pastEnd()
            print("HISTORY-OPEN \(title) past=\(past.map { String(format: "%.1f", $0) } ?? "?") \(debug.label.prefix(160))")
            capture("markdown-history-open-\(index)", app: app)
            XCTAssertLessThanOrEqual(past ?? 0, 8, "\(title) opened below its last message")
            XCTAssertGreaterThanOrEqual(past ?? 0, -8, "\(title) opened above its latest message")
            let content = value("content")
            // A small touch on the conversation must never open a new chat.
            let reading = app.scrollViews["chat-conversation"]
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.45))
                .press(forDuration: 0.1, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.47)))
            Thread.sleep(forTimeInterval: 0.8)
            XCTAssertFalse(app.descendants(matching: .any)["chat-empty"].exists, "A touch opened a new chat")
            // The conversation is still open (a new chat would be empty).
            XCTAssertGreaterThan(value("content") ?? 0, (content ?? 0) * 0.5, "\(title) is still open")
            XCTAssertLessThanOrEqual(pastEnd() ?? 0, 8, "\(title) stays at its end after a touch")
        }
    }

    /// Probe (1.0.59): scrolling up in the long chat froze the preview app
    /// at full CPU in the send-motion check. Each variant turns suspects off;
    /// a variant that prints its PROBE line did not freeze.
    // Round 1 (f73c481): all-off and plain-replies passed; no link dialog, no
    // reveal, a shared scroll view and no pull each still froze. So it is
    // the Markdown reply itself. Round 2 narrows that down.
    // Round 2 (346d01d): no text selection, flat blocks and plain-string
    // text all still froze. Round 3 samples the frozen app's main thread.
    @MainActor func testProbeLongChatScrollBaseline() { probeLongChatScroll("baseline", []) }
    @MainActor func testProbeLongChatScrollNoSelection() { probeLongChatScroll("no-selection", ["--probe-no-selection"]) }
    @MainActor func testProbeLongChatScrollFlat() { probeLongChatScroll("flat", ["--probe-flat"]) }
    @MainActor func testProbeLongChatScrollStringText() { probeLongChatScroll("string-text", ["--probe-string-text", "--probe-no-reveal"]) }

    // Round 4 (1.0.67): with full-width replies the plain scroll-up passes,
    // but scrolling up right after a send still froze (send test). The
    // keyboard is open then and the drag dismisses it interactively.
    @MainActor func testProbeKeyboardImmediately() {
        probeLongChatScroll("keyboard-immediately", ["--probe-dismiss-immediately"], keyboard: true)
    }
    @MainActor func testProbeKeyboardInteractive() { probeLongChatScroll("keyboard-interactive", [], keyboard: true) }
    @MainActor func testProbeKeyboardNever() {
        probeLongChatScroll("keyboard-never", ["--probe-keep-keyboard"], keyboard: true)
    }
    @MainActor func testProbeKeyboardSent() { probeLongChatScroll("keyboard-sent", [], keyboard: true, send: true) }

    @MainActor private func probeLongChatScroll(_ name: String, _ flags: [String], keyboard: Bool = false, send: Bool = false) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--long-chat"] + flags; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        if keyboard {
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
            if send {
                input.typeText("Probe send\nSecond line")
                app.buttons["送信する"].tap()
                XCTAssertTrue(app.staticTexts["Probe send\nSecond line"].firstMatch.waitForExistence(timeout: 4))
                XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
            }
            print("PROBE \(name) keyboard-before-scroll=\(app.keyboards.firstMatch.exists)")
        }
        let start = Date()
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        let shown = jump.waitForExistence(timeout: 5)
        print("PROBE \(name) seconds=\(String(format: "%.1f", Date().timeIntervalSince(start))) jump=\(shown)")
        capture("probe-\(name)", app: app)
        XCTAssertTrue(shown)
        app.terminate()
    }

    /// Markdown replies: headings, emphasis, quote, lists and checklist,
    /// table, highlighted code with a copy button, math, rule and a
    /// tap-to-load image, in light mode. A link asks before it opens.
    @MainActor func testMarkdownReplyRendersEveryBlock() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--markdown-sample"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-bottom", app: app)
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "サンプル画像")).firstMatch.exists,
                      "The image shows as a card to tap, not loaded by itself")
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "**")).count, 0, "Raw bold markers")
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "```")).count, 0, "Raw code fences")
        let copies = app.buttons.matching(identifier: "code-copy")
        print("MARKDOWN-NOTE copy buttons: \(copies.count)")
        var copy = copies.allElementsBoundByIndex.last { $0.isHittable }
        // The sample's math below the code block has grown past a screen
        // (1.0.77), so the block is pulled back into view first.
        var pulls = 0
        while copy == nil, pulls < 5 {
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
                .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7)))
            Thread.sleep(forTimeInterval: 0.6)
            copy = copies.allElementsBoundByIndex.last { $0.isHittable }
            pulls += 1
        }
        print("MARKDOWN-NOTE pulls to reach the copy button: \(pulls)")
        XCTAssertNotNil(copy, "The Swift block's copy button")
        copy?.tap()
        Thread.sleep(forTimeInterval: 0.3)
        capture("markdown-copied", app: app)
        // The screenshot shows the change; XCTest's accessibility snapshot
        // of the label can lag behind it, so this is only noted.
        let copied = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "コピーしました")).firstMatch
        print("MARKDOWN-NOTE copied label seen: \(copied.waitForExistence(timeout: 2))")
        // A short pull, so the reply's first lines clear the header.
        reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
            .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55)))
        Thread.sleep(forTimeInterval: 0.8)
        capture("markdown-top", app: app)
        let link = app.links["リンク"].firstMatch
        XCTAssertTrue(link.waitForExistence(timeout: 2), "Links are exposed as links")
        // The pull's momentum varies; a link left under the header and the
        // status bar takes no tap, so pull a little more until it clears.
        let header = app.buttons["chat-model-settings"].frame.maxY
        var nudges = 0
        while link.frame.minY < header + 8, nudges < 3 {
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
                .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.45)))
            Thread.sleep(forTimeInterval: 0.8)
            nudges += 1
        }
        print("MARKDOWN-NOTE link at \(link.frame.minY) below the header at \(header) after \(nudges) more pulls")
        if link.isHittable {
            link.tap()
            XCTAssertTrue(app.staticTexts["リンクを開きますか？"].waitForExistence(timeout: 3), "A link asks before leaving the app")
            capture("markdown-link-confirm", app: app)
            // iOS 26 shows it as a popover without a cancel button; a tap
            // outside dismisses it.
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.62)).tap()
            XCTAssertTrue(app.staticTexts["リンクを開きますか？"].waitForNonExistence(timeout: 3))
        } else {
            print("MARKDOWN-NOTE link not hittable: \(link.frame)")
        }
        reading.swipeDown(); reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-wide", app: app)
        XCTAssertTrue(app.buttons["残り30行を表示"].exists || app.staticTexts["残り30行を表示"].exists,
                      "Long code shows its first lines until expanded")
    }

    @MainActor func testMarkdownReplyInDarkMode() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--markdown-sample", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-bottom", app: app)
        reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-middle", app: app)
        reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-top", app: app)
    }

    /// Phase 5: a formula, a table and a code block each offer their own
    /// copy menu on a long press, prose keeps the reply's menu, and
    /// VoiceOver reads formulas in words and cells with their column's header.
    @MainActor func testMarkdownCopyMenusAndVoiceOverLabels() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = Self.keepOpen + ["--markdown-sample"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        let any = app.descendants(matching: .any)
        func labels(_ prefix: String) -> [String] {
            any.matching(NSPredicate(format: "label BEGINSWITH %@", prefix)).allElementsBoundByIndex.prefix(10).map(\.label)
        }
        print("MARKDOWN-NOTE formula labels: \(labels("数式、"))")
        print("MARKDOWN-NOTE table labels: \(labels("表、"))")
        print("MARKDOWN-NOTE code labels: \(labels("コード、"))")
        XCTAssertTrue(any.matching(NSPredicate(format: "label == %@", "数式、0 から 1 までの積分 x の 2 乗 dx イコール 3 分の 1"))
            .firstMatch.exists, "A formula reads in words")
        XCTAssertTrue(any.matching(NSPredicate(format: "label == %@", "モデル、E2B")).firstMatch.exists,
                      "A cell reads with its column's header")

        // Between the header and the composer, where a touch reaches the reply.
        let top = app.buttons["chat-model-settings"].frame.maxY + 24
        let bottom = any["chat-composer"].frame.minY - 24
        func reach(_ query: XCUIElementQuery, _ name: String, room: CGFloat = 0) -> XCUIElement? {
            for pull in 0..<8 {
                if let element = query.allElementsBoundByIndex.last(where: { element in
                    element.frame.width > 0 && element.frame.midY > top && element.frame.midY + room < bottom
                }) {
                    print("MARKDOWN-NOTE \(name) reached after \(pull) pulls at \(element.frame)")
                    return element
                }
                reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.35))
                    .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.6)))
                Thread.sleep(forTimeInterval: 0.6)
            }
            return nil
        }
        func menu(_ item: String, also others: [String], shot: String) {
            XCTAssertTrue(app.buttons[item].waitForExistence(timeout: 4), "\(item) in the menu")
            for other in others { XCTAssertTrue(app.buttons[other].exists, "\(other) in the menu") }
            capture(shot, app: app)
            app.buttons[item].tap()
            XCTAssertTrue(app.buttons[item].waitForNonExistence(timeout: 3), "The menu closes")
            Thread.sleep(forTimeInterval: 0.4)
        }

        let formula = reach(any.matching(identifier: "math-block"), "formula")
        XCTAssertNotNil(formula, "A formula block on screen")
        formula?.press(forDuration: 1.2)
        menu("LaTeXをコピー", also: ["返信全体をコピー"], shot: "markdown-menu-math")

        let copy = reach(app.buttons.matching(identifier: "code-copy"), "code", room: 80)
        XCTAssertNotNil(copy, "The Swift block's copy button")
        copy?.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).withOffset(CGVector(dx: -120, dy: 50))
            .press(forDuration: 1.2)
        menu("返信全体をコピー", also: ["ファイルとして共有"], shot: "markdown-menu-code")

        let cell = reach(any.matching(NSPredicate(format: "label == %@", "モデル、E2B")), "table")
        XCTAssertNotNil(cell, "The table on screen")
        cell?.press(forDuration: 1.2)
        menu("表をコピー", also: ["タブ区切りでコピー", "返信全体をコピー"], shot: "markdown-menu-table")

        // Prose keeps the reply's own menu, which copies all of it.
        reading.swipeUp(); reading.swipeUp(); reading.swipeUp()
        Thread.sleep(forTimeInterval: 0.6)
        let prose = reach(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "連立方程式も描けます")), "prose")
        XCTAssertNotNil(prose, "A paragraph on screen")
        prose?.press(forDuration: 1.2)
        menu("コピー", also: [], shot: "markdown-menu-reply")
    }

    /// A table wider than the screen scrolls inside its own frame while the
    /// rest of the reply stays put, and a long press on it, on text or on
    /// the blank beside a short number, copies the table alone; the reply's
    /// own menu still copies all of it, wide code scrolls alone too, and a
    /// swipe on prose still shows the times.
    @MainActor func testWideTableScrollsAloneAndCopiesItself() {
        wideTable("markdown-wide-table", arguments: [], fixed: true, everything: true)
    }

    @MainActor func testWideTableInDarkMode() {
        wideTable("markdown-wide-table-dark", arguments: ["--dark"], fixed: true, everything: false)
    }

    /// The swipe and the table's menu as they were before 1.0.99, for
    /// comparison; it only notes what happens.
    @MainActor func testWideTableBeforeTheFixForComparison() {
        wideTable("markdown-wide-table-old", arguments: ["--probe-timestamp-anywhere", "--probe-table-menu-outside"],
                  fixed: false, everything: false)
    }

    @MainActor private func wideTable(_ name: String, arguments: [String], fixed: Bool, everything: Bool) {
        continueAfterFailure = false
        let app = PreviewApp()
        // The times stay out after a swipe, so a screenshot shows them.
        app.launchArguments = Self.keepOpen + ["--wide-table", "--show-pasteboard", "--probe-timestamp-hold"] + arguments
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        let any = app.descendants(matching: .any)
        let screen = app.frame
        func labelled(_ text: String) -> XCUIElement { any.matching(NSPredicate(format: "label == %@", text)).firstMatch }
        func check(_ ok: Bool, _ what: String) {
            print("MARKDOWN-NOTE \(name) \(ok ? "yes" : "NO"): \(what)")
            if fixed { XCTAssertTrue(ok, what) }
        }
        let before = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "表の前の文章")).firstMatch
        let after = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "表の後の文章")).firstMatch
        let table = any.matching(identifier: "markdown-table").firstMatch
        let total = labelled("合計")
        XCTAssertTrue(before.waitForExistence(timeout: 5) && total.exists, "The reply with the wide table on screen")

        // The reply keeps the screen's width; only the table runs past it.
        // Header cells are found twice (31 elements for these 17 labels in
        // the first run), so each label is looked up on its own.
        let headers = ["項目"] + (1...12).map { "\($0)月" } + ["合計", "合計、17,700", "合計、11,260", "合計、6,440"]
        XCTAssertEqual(headers.filter { !labelled($0).exists }, [], "Every column's header and the last column's cells")
        let tableFrame = table.frame, afterFrame = after.frame, firstTotal = total.frame.minX
        print("MARKDOWN-NOTE \(name) screen \(screen.size) table \(tableFrame) prose \(afterFrame) total \(firstTotal)")
        XCTAssertTrue(tableFrame.minX >= 0 && tableFrame.maxX <= screen.width + 0.5, "The table's frame keeps the screen's width")
        XCTAssertLessThanOrEqual(afterFrame.maxX, screen.width + 0.5, "Prose keeps the screen's width")
        XCTAssertGreaterThan(firstTotal, screen.width, "The last column starts past the screen's edge")
        capture("\(name)-start", app: app)

        // Where the first line of prose ends, in pixels: the rows move by
        // the times' swipe, which a frame may not show.
        let beforeFrame = before.frame
        let band = CGRect(x: 0, y: beforeFrame.minY + 2, width: screen.width - 80,
                          height: max(8, min(18, beforeFrame.height - 4)))
        var background = 255
        func proseEnd() -> CGFloat? {
            guard let image = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(image, band, screenWidth: screen.width) else { return nil }
            return area.inkBounds(in: band, background: background)?.maxX
        }
        if let image = XCUIScreen.main.screenshot().image.cgImage,
           let area = ScreenArea(image, band, screenWidth: screen.width) {
            background = area.meanLuma(in: CGRect(x: 2, y: band.minY, width: 6, height: band.height))
        }
        guard let start = proseEnd() else { return XCTFail("The first line of prose in pixels") }
        func swipeLeft(at y: CGFloat, from x: CGFloat) {
            let origin = app.coordinate(withNormalizedOffset: .zero)
            origin.withOffset(CGVector(dx: x, dy: y))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x - 220, dy: y)),
                       withVelocity: .fast, thenHoldForDuration: 0)
            Thread.sleep(forTimeInterval: 1.0)
        }

        // Sideways on the table: the table scrolls to its last column, the
        // prose does not move.
        var shifts: [CGFloat] = []
        var lastTotal = total.frame
        for _ in 0..<3 where lastTotal.maxX > screen.width - 4 {
            swipeLeft(at: tableFrame.midY, from: screen.width * 0.65)
            shifts.append(start - (proseEnd() ?? start))
            lastTotal = total.frame
        }
        print("MARKDOWN-NOTE \(name) table swipes: prose moved \(shifts) pt, last column \(firstTotal) -> \(lastTotal)")
        check(firstTotal - lastTotal.minX > 100, "The table scrolls sideways")
        check(shifts.allSatisfy { abs($0) <= 2 }, "The prose stays put while the table scrolls")
        check(lastTotal.minX >= 0 && lastTotal.maxX <= screen.width, "The last column comes fully on screen")
        capture("\(name)-scrolled", app: app)

        // A long press opens one menu; the pasteboard shows what an item
        // copied.
        let pasteboard = any.matching(identifier: "preview-pasteboard").firstMatch
        func copied(_ item: String) -> String {
            let previous = pasteboard.label
            app.buttons[item].firstMatch.tap()
            _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label != %@", previous),
                                                               object: pasteboard)], timeout: 3)
            return pasteboard.label
        }
        let markers = ["表をコピー", "タブ区切りでコピー", "返信全体をコピー", "コピー", "ファイルとして共有"]
        let menuItems = app.buttons.matching(NSPredicate(format: "label IN %@", markers))
        func menu(at point: CGPoint, _ what: String) -> [String] {
            app.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: point.x, dy: point.y)).press(forDuration: 1.2)
            _ = menuItems.firstMatch.waitForExistence(timeout: 3)
            let shown = menuItems.allElementsBoundByIndex.map(\.label)
            print("MARKDOWN-NOTE \(name) \(what) menu: \(shown)")
            return shown
        }
        func tableMenu(_ shown: [String], _ what: String) {
            check(shown.contains("表をコピー") && shown.contains("タブ区切りでコピー") && shown.contains("返信全体をコピー")
                  && !shown.contains("コピー"), "A long press on \(what) opens the table's menu")
        }
        func noteCopy(_ text: String, _ what: String) {
            print("MARKDOWN-NOTE \(name) \(what) copied \(text.count) characters: "
                  + text.replacingOccurrences(of: "\n", with: "⏎").replacingOccurrences(of: "\t", with: "⇥").prefix(160))
        }
        func outsideTable(_ text: String) -> Bool {
            !text.contains("表の前") && !text.contains("表の後") && !text.contains("引用") && !text.contains("let note")
        }

        // On a number in the last column, then on the blank beside a short
        // one, where the reply's menu used to answer.
        let number = labelled("合計、6,440").frame
        let shown = menu(at: CGPoint(x: number.midX, y: number.midY), "a number")
        tableMenu(shown, "a number")
        capture("\(name)-menu", app: app)
        if shown.contains("表をコピー") {
            let markdown = copied("表をコピー")
            noteCopy(markdown, "表をコピー")
            check(markdown.hasPrefix("| 項目 | 1月 | 2月") && markdown.contains("| 利益 | 380 | 480")
                  && markdown.contains("| 6,440 |") && outsideTable(markdown), "表をコピー copies the table alone, as Markdown")
        } else if shown.contains("コピー") {
            noteCopy(copied("コピー"), "コピー")
        }
        let short = labelled("12月、770").frame
        let blank = menu(at: CGPoint(x: short.minX + 4, y: short.midY), "the blank beside 770")
        tableMenu(blank, "the blank beside 770")
        if blank.contains("タブ区切りでコピー") {
            let separated = copied("タブ区切りでコピー")
            noteCopy(separated, "タブ区切りでコピー")
            check(separated.hasPrefix("項目\t1月\t2月") && separated.contains("利益\t380\t480") && !separated.contains("|")
                  && outsideTable(separated), "タブ区切りでコピー copies the table alone, tab separated")
        } else if blank.contains("返信全体をコピー") || blank.contains("コピー") {
            noteCopy(copied(blank.contains("コピー") ? "コピー" : "返信全体をコピー"), "the reply's copy")
        }
        guard everything else { return }

        // Wide code scrolls alone too. Its menu is left as it was; noted.
        let code = any.matching(identifier: "code-block").firstMatch.frame
        let codeLine = CGPoint(x: screen.width * 0.65, y: code.maxY - 16)
        if codeLine.y < any.matching(identifier: "chat-composer").firstMatch.frame.minY - 4 {
            let moved = start - (proseEnd() ?? start)
            swipeLeft(at: codeLine.y, from: codeLine.x)
            check(abs(start - (proseEnd() ?? start) - moved) <= 2, "The prose stays put while code scrolls")
            if !menu(at: CGPoint(x: screen.width / 2, y: codeLine.y), "wide code").isEmpty {
                app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.12)).tap()
                Thread.sleep(forTimeInterval: 0.8)
            }
        } else {
            print("MARKDOWN-NOTE \(name) code under the composer at \(code); skipped")
        }

        // Prose keeps the reply's own menu, which copies all of it.
        let reply = menu(at: CGPoint(x: afterFrame.minX + 40, y: afterFrame.minY + 8), "prose")
        check(reply.contains("コピー") && !reply.contains("表をコピー"), "A long press on prose opens the reply's menu")
        if reply.contains("コピー") {
            let whole = copied("コピー")
            noteCopy(whole, "コピー")
            check(whole.hasPrefix("表の前の文章です。") && whole.contains("| 項目 | 1月") && whole.contains("引用")
                  && whole.contains("let note"), "The reply's コピー copies all of it")
        }

        // A swipe on prose still slides the rows to show the times.
        swipeLeft(at: afterFrame.minY + 8, from: screen.width * 0.65)
        let moved = start - (proseEnd() ?? start)
        print("MARKDOWN-NOTE \(name) prose swipe: prose moved \(moved) pt")
        XCTAssertGreaterThan(moved, 30, "A swipe on prose shows the times")
        capture("\(name)-times", app: app)
    }

    /// A long reply with every heading level, nested and numbered lists, a
    /// quote, a table and code, flat on the conversation: its top, middle
    /// and end, light and dark, for the spacing and alignment review.
    @MainActor func testMarkdownLongArticleLayout() {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = PreviewApp()
            app.launchArguments = Self.keepOpen + ["--markdown-article"] + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            XCTAssertTrue(reading.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.6)
            let name = dark ? "markdown-article-dark" : "markdown-article"
            capture("\(name)-end", app: app)
            XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "#")).count, 0, "Raw heading markers")
            XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "**")).count, 0, "Raw bold markers")
            reading.swipeDown()
            Thread.sleep(forTimeInterval: 0.8)
            capture("\(name)-middle", app: app)
            // At the very top, where the reply must start below the header.
            // The history list holds the same title, so look in the chat only.
            let request = reading.staticTexts["長文のMarkdownを表示して"].firstMatch
            for _ in 0..<5 where !(request.exists && request.frame.minY > 100) {
                reading.swipeDown()
                Thread.sleep(forTimeInterval: 0.5)
            }
            XCTAssertTrue(reading.staticTexts["2035年のAIと暮らし"].firstMatch.exists, "The H1 heading")
            Thread.sleep(forTimeInterval: 0.6)
            capture("\(name)-top", app: app)
            app.terminate()
        }
    }

    /// While the reply streams, unfinished syntax never shows: no raw bold
    /// markers, code fences or half links, and the rows never jump down.
    @MainActor func testMarkdownStreamingNeverShowsRawSyntax() {
        markdownStreaming("markdown-stream", arguments: [], strict: true)
    }

    /// The same stream with the tables drawn as 219 drew them, on the same
    /// runner: how long the reply takes to finish, for comparison (notes
    /// only; 1.1.0 (220)).
    @MainActor func testMarkdownStreamingWith219TablesForComparison() {
        markdownStreaming("markdown-stream-219", arguments: ["--probe-table-old-fit"], strict: false)
    }

    /// The same stream with its table written in as 1.1.0 (244) wrote it
    /// (`--probe-table-pop`), on the same runner: how long the reply takes
    /// to finish beside 245's (notes only; 1.1.0 (245)).
    @MainActor func testMarkdownStreamingAs244ForComparison() {
        markdownStreaming("markdown-stream-244", arguments: ["--probe-table-pop"], strict: false)
    }

    @MainActor private func markdownStreaming(_ name: String, arguments: [String], strict: Bool) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--markdown-stream"] + arguments; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("表示テスト")
        app.buttons["送信する"].tap()
        let sent = Date()
        XCTAssertTrue(app.buttons["停止する"].waitForExistence(timeout: 10))
        // How long each accessibility snapshot takes while the reply streams
        // tells a slow runner from a busy main thread.
        print("MARKDOWN-NOTE \(name) stop button seen \(Date().timeIntervalSince(sent)) s after the send")
        var shots = 0
        var checks = 0
        let start = Date()
        while app.buttons["停止する"].exists && Date().timeIntervalSince(start) < 20 {
            checks += 1
            let raw = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@ OR label CONTAINS %@ OR label CONTAINS %@",
                                                           "**", "```", "](http"))
            XCTAssertEqual(raw.count, 0, "Raw Markdown while streaming: \(raw.allElementsBoundByIndex.map(\.label))")
            if Date().timeIntervalSince(start) > Double(shots) * 1.6 + 1, shots < 4 {
                capture("\(name)-\(shots)", app: app); shots += 1
            }
        }
        print("MARKDOWN-NOTE \(name) stream loop: \(checks) checks and \(shots) shots in \(Date().timeIntervalSince(start)) s")
        let finished = app.buttons["送信する"].waitForExistence(timeout: strict ? 10 : 40)
        print("MARKDOWN-NOTE \(name) reply finished: \(finished), \(Date().timeIntervalSince(sent)) s after the send")
        // When it came late, how late (notes only).
        if strict, !finished, app.buttons["送信する"].waitForExistence(timeout: 30) {
            print("MARKDOWN-NOTE \(name) reply finished late: \(Date().timeIntervalSince(sent)) s after the send")
        }
        if strict { XCTAssertTrue(finished, "The reply finishes within 30 s of the send") }
        guard finished else { return }
        Thread.sleep(forTimeInterval: 0.6)
        capture("\(name)-done", app: app)
        XCTAssertTrue(app.staticTexts["表示テスト"].exists || app.staticTexts["表示テスト"].waitForExistence(timeout: 2))
    }

    // MARK: Tables that fit (1.1.0 (220))

    /// Tables a little wider than the reply at their columns' own widths
    /// (a long Japanese column beside a short one, as E2B writes them, a
    /// check column, English in four columns) keep the reply's width: every
    /// cell inside its table, each table inside the reply, no text at a
    /// table's right edge, what follows a table below it, and a drag that
    /// starts on a table scrolls the chat. Up to 219 they scrolled sideways
    /// and hid their right edge (MARKDOWN-NOTE table-fit lines, SHOT
    /// markdown-table-fit-*).
    @MainActor func testLongTextTablesFitTheReply() {
        longTables("markdown-table-fit", arguments: [], narrow: false, fixed: true)
    }

    @MainActor func testLongTextTablesFitInDarkOnANarrowPhone() {
        longTables("markdown-table-fit-dark-narrow", arguments: ["--dark", "--narrow-phone"], narrow: true, fixed: true)
    }

    /// The same tables as 219 drew them, for comparison; it only notes
    /// what happens.
    @MainActor func testLongTextTablesBeforeTheFixForComparison() {
        longTables("markdown-table-fit-old", arguments: ["--probe-table-old-fit"], narrow: false, fixed: false)
    }

    /// The tables keep the reply's width while they stream in, row by row,
    /// and once the reply has ended.
    @MainActor func testLongTextTablesFitWhileStreaming() {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = ["--table-stream"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("資料を作って")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["停止する"].waitForExistence(timeout: 10))
        let reply = app.frame.insetBy(dx: Self.replyEdge, dy: 0)
        var checks = 0, shots = 0, seen = 0
        let start = Date()
        while app.buttons["停止する"].exists && Date().timeIntervalSince(start) < 40 {
            let fits = tableFits(app, "markdown-table-stream", "streaming \(checks)")
            checks += 1
            seen = max(seen, fits.count)
            for fit in fits {
                XCTAssertEqual(fit.outside, [], "Every cell inside its table while it streams")
                XCTAssertLessThanOrEqual(fit.frame.maxX, reply.maxX + 0.5, "The table keeps the reply's width while it streams")
                XCTAssertGreaterThanOrEqual(fit.frame.minX, reply.minX - 0.5, "The table starts at the reply's edge while it streams")
            }
            if Date().timeIntervalSince(start) > Double(shots) * 3 + 2, shots < 3 {
                capture("markdown-table-stream-\(shots)", app: app); shots += 1
            }
        }
        print("MARKDOWN-NOTE table-fit stream: \(checks) checks, \(seen) tables at most, \(Date().timeIntervalSince(start)) s")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 15), "The reply ends")
        Thread.sleep(forTimeInterval: 0.6)
        let done = tableFits(app, "markdown-table-stream", "done")
        XCTAssertEqual(done.count, 3, "The reply's three tables")
        for fit in done {
            XCTAssertEqual(fit.outside, [], "Every cell inside its table once the reply has ended")
            XCTAssertLessThanOrEqual(fit.frame.maxX, reply.maxX + 0.5)
            XCTAssertGreaterThanOrEqual(fit.frame.minX, reply.minX - 0.5)
        }
        let past = pastTheEdges(app, app.frame)
        print("MARKDOWN-NOTE markdown-table-stream past the screen's edges: \(past.count) \(past.prefix(4))")
        XCTAssertEqual(past, [], "Nothing runs past the screen's edges once the reply has ended")
        capture("markdown-table-stream-done", app: app)
    }

    /// A plan table written in as E4B wrote one on the phone (2026-10-29):
    /// while it is written the table only grows, a row once shown never
    /// going again, and once the reply has ended it keeps the reply's width
    /// and every row. TABLE-STREAM lines carry its growth; the session
    /// recording's frames come from the MENU-MARK table-stream-* lines
    /// (scope table-stream, SHOT composer-video-table-stream-*).
    @MainActor func testStreamingTableOnlyGrows() {
        let summary = planTableStream("table-stream", arguments: [], marks: [1.5, 5.5, 9.5, 13.5])
        let counts = Self.tableGrowth(summary)
        XCTAssertEqual(counts["shrank"], 0, "The table never shrinks while it is written: \(summary)")
        XCTAssertEqual(counts["rowsBack"], 0, "No row goes once shown: \(summary)")
        XCTAssertEqual(counts["rows"], 8, "Every row shows: \(summary)")
    }

    /// The same plan as 1.1.0 (244) streamed it (`--probe-table-pop`), for
    /// comparison on the same runner: it only notes what happens.
    @MainActor func testStreamingTableAs244ForComparison() {
        _ = planTableStream("table-stream-244", arguments: ["--probe-table-pop"], marks: [5.5, 9.5])
    }

    /// The same plan with its table written as lines of text
    /// (`--probe-table-as-text`): the screen's frames while text of the same
    /// length is written, beside the table's (notes only).
    @MainActor func testStreamingPlanAsTextForComparison() {
        _ = planTableStream("table-stream-text", arguments: ["--probe-table-as-text"], marks: [])
    }

    /// Sends a message, has the plan table written in, and returns the
    /// table's growth notes (TableGrowthLog) once the reply has ended; the
    /// TABLE-STREAM line also carries the screen's frames while it was
    /// written (FrameGapCounter). `marks` are seconds after the send for the
    /// recording's frames.
    @MainActor private func planTableStream(_ name: String, arguments: [String], marks: [TimeInterval]) -> String {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--table-plan-stream", "--table-trace", "--frame-trace"] + arguments
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("春の京都1泊2日の旅行プランを表にして")
        let sent = Date().timeIntervalSince1970
        app.buttons["送信する"].tap()
        for (index, mark) in marks.enumerated() {
            print(String(format: "MENU-MARK %@-%d %.3f", name, index, sent + mark))
        }
        XCTAssertTrue(app.buttons["停止する"].waitForExistence(timeout: 10))
        let start = Date()
        // Nothing asks the app anything while the reply is written (about
        // 16 s): each question holds its main thread, where the frames are
        // counted. The recording keeps what the screen showed.
        Thread.sleep(forTimeInterval: 24)
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 30), "The reply ends")
        Thread.sleep(forTimeInterval: 1.5)
        let trace = app.descendants(matching: .any).matching(identifier: "table-growth-trace").firstMatch
        let summary = trace.exists ? trace.label : "missing"
        let frames = app.descendants(matching: .any).matching(identifier: "stream-frame-trace").firstMatch
        print("TABLE-STREAM \(name): \(summary), \(String(format: "%.1f", Date().timeIntervalSince(start))) s; "
              + (frames.exists ? frames.label : "frames missing"))
        let reply = app.frame.insetBy(dx: Self.replyEdge, dy: 0)
        let fits = tableFits(app, "plan-\(name)", "done")
        for fit in fits {
            XCTAssertEqual(fit.outside, [], "Every cell inside its table once the reply has ended")
            XCTAssertLessThanOrEqual(fit.frame.maxX, reply.maxX + 0.5, "The table keeps the reply's width")
        }
        capture("plan-\(name)-done", app: app)
        return summary
    }

    /// TableGrowthLog's summary as numbers by name.
    static func tableGrowth(_ summary: String) -> [String: Int] {
        let words = summary.split(separator: " ").map(String.init)
        var counts: [String: Int] = [:]
        for index in words.indices.dropLast() {
            if let value = Int(words[index + 1]) { counts[words[index]] = value }
        }
        return counts
    }

    /// What lays the long tables' reply out on a 402pt phone: the same
    /// reply with one thing changed at a time, its tables' widths and
    /// where its texts end (TABLE-PROBE lines, SHOT markdown-table-probe-*;
    /// scope tables-probe). It only notes what it finds.
    @MainActor func testLongTablesLayoutVariants() {
        // In 219 the reply grew wider than a 402pt screen with the check
        // table (=1): each variant changes one thing, 219's drawing beside.
        let part = "--long-tables-part=1"
        let variants: [(String, [String])] = [
            ("all", []), ("all-219", ["--probe-table-old-fit"]),
            ("t0", ["--long-tables-part=0"]), ("t1", [part]), ("t1-219", ["--probe-table-old-fit", part]),
            ("t2", ["--long-tables-part=2"]), ("t1-nobox", ["--long-tables-variant=nobox", part]),
            ("t1-twocol", ["--long-tables-variant=twocol", part]), ("t1-short", ["--long-tables-variant=short", part]),
            ("narrow", ["--narrow-phone"])]
        for (name, arguments) in variants {
            let app = PreviewApp()
            app.launchArguments = Self.keepOpen + ["--long-tables"] + arguments
            app.launch()
            guard app.buttons["chat-add-menu"].waitForExistence(timeout: 10) else { XCTFail(name); continue }
            Thread.sleep(forTimeInterval: 1.0)
            let fits = tableFits(app, "table-probe-\(name)", "rest")
            let width = app.frame.width
            var past: [String] = []
            var cells: [String] = []
            if let root = try? app.snapshot() {
                func all(_ element: any XCUIElementSnapshot) -> [any XCUIElementSnapshot] {
                    [element] + element.children.flatMap { all($0) }
                }
                past = all(root).filter { !$0.label.isEmpty && $0.frame.maxX > width + 1 && $0.frame.height < 400 }
                    .map { "\(Int($0.frame.minX))-\(Int($0.frame.maxX)) \($0.label.prefix(10))" }
                if let table = all(root).first(where: { $0.identifier == "markdown-table" }) {
                    cells = all(table).dropFirst().prefix(8)
                        .map { "\($0.label.prefix(6)) \(Int($0.frame.minX))+\(Int($0.frame.width))x\(Int($0.frame.height))" }
                }
            }
            func frame(_ prefix: String) -> String {
                let element = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", prefix)).firstMatch
                guard element.exists else { return "none" }
                let frame = element.frame
                return "\(Int(frame.minX))+\(Int(frame.width))x\(Int(frame.height))@\(Int(frame.minY))"
            }
            print("TABLE-PROBE \(name) tables \(fits.map { "\(Int($0.frame.minX))+\(Int($0.frame.width))x\(Int($0.frame.height))" }) "
                  + "user \(frame("カフェの開業")) h3 \(frame("3. 物件")) para \(frame("開店の1か月前")) last \(frame("表の後の文章"))")
            print("TABLE-PROBE \(name) cells \(cells)")
            print("TABLE-PROBE \(name) past the screen: \(past.count) \(past.prefix(6))")
            capture("markdown-table-probe-\(name)", app: app)
            app.terminate()
        }
    }

    @MainActor private func longTables(_ name: String, arguments: [String], narrow: Bool, fixed: Bool) {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--long-tables"] + arguments
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        func check(_ ok: Bool, _ what: String) {
            print("MARKDOWN-NOTE \(name) \(ok ? "yes" : "NO"): \(what)")
            if fixed { XCTAssertTrue(ok, what) }
        }
        let screen = app.frame
        // --narrow-phone lays the app out 375pt wide in the screen's middle.
        let content = narrow ? CGRect(x: (screen.width - 375) / 2, y: 0, width: 375, height: screen.height) : screen
        let reply = content.insetBy(dx: Self.replyEdge, dy: 0)
        let tables = app.descendants(matching: .any).matching(identifier: "markdown-table")
        XCTAssertTrue(tables.firstMatch.waitForExistence(timeout: 5), "The reply's tables")
        let input = app.textViews["chat-input"]
        let bottom = min(input.frame.minY, app.buttons["chat-add-menu"].frame.minY) - 14
        let top: CGFloat = 150
        print("MARKDOWN-NOTE \(name) screen \(screen.size) reply \(reply) visible \(top)-\(bottom)")

        let first = tableFits(app, name, "start")
        XCTAssertEqual(first.count, 3, "The reply's three tables")
        check(first.allSatisfy { $0.outside.isEmpty }, "Every cell lies inside its table")
        check(first.allSatisfy { $0.frame.minX >= reply.minX - 0.5 && $0.frame.maxX <= reply.maxX + 0.5 },
              "Each table keeps the reply's width")
        check(first.allSatisfy { $0.right <= $0.frame.maxX + 0.5 }, "No cell reaches past its table's right edge")
        let past = pastTheEdges(app, content)
        print("MARKDOWN-NOTE \(name) past the screen's edges: \(past.count) \(past.prefix(4))")
        check(past.isEmpty, "Nothing runs past the screen's edges")
        // What follows each table starts below it.
        let next = ["4. 運営体制の構築", "表の後の文章です。表は画面の幅に収まり、この文章と重なりません。"]
        let sorted = first.sorted { $0.frame.minY < $1.frame.minY }
        guard sorted.count == 3 else { return }
        for (text, table) in zip(next, [sorted[0], sorted[2]]) {
            let element = app.staticTexts[text]
            if element.exists {
                print("MARKDOWN-NOTE \(name) after table \(table.frame.maxY): \(text.prefix(8)) at \(element.frame.minY)")
                XCTAssertGreaterThanOrEqual(element.frame.minY, table.frame.maxY - 0.5, "\(text.prefix(8)) below its table")
            }
        }

        // No text in a band just inside the right edge of the part of each
        // table on screen, where a table that fits has only its padding;
        // checked at the reply's end and twice further up, after a drag
        // that starts on a table.
        for step in 0..<3 {
            let fits = tableFits(app, name, "step \(step)")
            guard let shot = XCUIScreen.main.screenshot().image.cgImage else { return XCTFail("A screenshot") }
            for (index, fit) in fits.enumerated() {
                let low = max(fit.frame.minY + 3, top), high = min(fit.frame.maxY - 3, bottom)
                guard high - low >= 20 else { continue }
                let band = CGRect(x: fit.frame.maxX - 8, y: low, width: 5, height: high - low)
                let paper = CGRect(x: fit.frame.minX - 10, y: low, width: 4, height: high - low)
                guard let area = ScreenArea(shot, band.union(paper), screenWidth: screen.width) else { continue }
                let background = area.meanLuma(in: paper)
                let ink = area.ink(in: band, background: background).share
                print("MARKDOWN-NOTE \(name) step \(step) table \(index) right-edge ink \(String(format: "%.4f", ink)) over \(Int(high - low)) pt")
                check(ink < 0.01, "No text at table \(index)'s right edge (step \(step))")
            }
            capture("\(name)-\(step)", app: app)
            guard step < 2, let on = fits.min(by: { abs($0.frame.midY - 450) < abs($1.frame.midY - 450) }) else { continue }
            let x = max(on.frame.minX + 20, content.minX + 30), y = min(max(on.frame.midY, top + 40), bottom - 300)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            origin.withOffset(CGVector(dx: x, dy: y))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: y + 280)),
                       withVelocity: .slow, thenHoldForDuration: 0.3)
            Thread.sleep(forTimeInterval: 0.8)
            let moved = (tableFits(app, name, "after drag \(step)").first?.frame.minY ?? 0) - (fits.first?.frame.minY ?? 0)
            print("MARKDOWN-NOTE \(name) drag from a table at y \(Int(y)) moved the chat \(Int(moved)) pt")
            // The second drag may reach the top of the chat.
            if step == 0 { XCTAssertGreaterThan(moved, 100, "A drag that starts on a table scrolls the chat") }
        }
    }

    /// Labelled elements that reach past `content`'s sides: in 219 a check
    /// table widened the whole reply, its prose and the sent bubble running
    /// past the screen's edges.
    @MainActor private func pastTheEdges(_ app: XCUIApplication, _ content: CGRect) -> [String] {
        guard let root = try? app.snapshot() else { return ["no snapshot"] }
        func all(_ element: any XCUIElementSnapshot) -> [any XCUIElementSnapshot] {
            [element] + element.children.flatMap { all($0) }
        }
        return all(root).filter { !$0.label.isEmpty && $0.frame.height < 400 && $0.frame.width > 0
                && ($0.frame.maxX > content.maxX + 1 || $0.frame.minX < content.minX - 1) }
            .map { "\(Int($0.frame.minX))-\(Int($0.frame.maxX)) \($0.label.prefix(10))" }
    }

    /// Each table on screen, read from one snapshot: its frame, the cells
    /// that reach past it, and the right edge of its widest row.
    struct TableFit {
        let frame: CGRect
        let cells: Int
        let outside: [String]
        let right: CGFloat
    }

    @MainActor private func tableFits(_ app: XCUIApplication, _ name: String, _ moment: String) -> [TableFit] {
        guard let root = try? app.snapshot() else { XCTFail("A snapshot of the screen"); return [] }
        func all(_ element: any XCUIElementSnapshot) -> [any XCUIElementSnapshot] {
            [element] + element.children.flatMap { all($0) }
        }
        let tables = all(root).filter { $0.identifier == "markdown-table" }.sorted { $0.frame.minY < $1.frame.minY }
        return tables.enumerated().map { (index, table) -> TableFit in
            let frame = table.frame
            let cells = all(table).dropFirst().filter { !$0.label.isEmpty }
            let outside = cells.filter { $0.frame.maxX > frame.maxX + 0.5 || $0.frame.minX < frame.minX - 0.5 }.map { $0.label }
            let right = cells.map { $0.frame.maxX }.max() ?? frame.maxX
            print("MARKDOWN-NOTE \(name) \(moment) table \(index) frame \(frame) cells \(cells.count) right \(right) "
                  + "outside \(outside.count) \(outside.prefix(2).map { String($0.prefix(14)) })")
            return TableFit(frame: frame, cells: cells.count, outside: outside, right: right)
        }
    }

    // MARK: Charts (Phase 6-1)

    @MainActor func testChartsDrawInRepliesAndCopyTheirData() {
        charts("markdown-charts", arguments: [], everything: true)
    }

    @MainActor func testChartsInDarkMode() {
        charts("markdown-charts-dark", arguments: ["--dark"], everything: false)
    }

    /// At the largest accessibility text size the charts grow with the text
    /// and still keep the screen's width.
    @MainActor func testChartsAtTheLargestTextSize() {
        charts("markdown-charts-large", arguments: ["--large-type"], everything: false)
    }

    /// Charts between prose (`--chart-sample`): bars on their side with a
    /// long label, two series, data that cannot be drawn shown as its
    /// source, and further up upright bars, a line and a pie. Each keeps the
    /// screen's width and shows no raw data; a tap reads an item out; the
    /// copy button and the chart's menu copy its data alone.
    @MainActor private func charts(_ name: String, arguments: [String], everything: Bool) {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = Self.keepOpen + ["--chart-sample", "--show-pasteboard"] + arguments
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        let any = app.descendants(matching: .any)
        let screen = app.frame
        let top = app.buttons["chat-model-settings"].frame.maxY + 8
        // Above the composer and the jump button over it.
        let bottom = any["chat-composer"].frame.minY - 70
        let origin = app.coordinate(withNormalizedOffset: .zero)
        func chart(_ title: String) -> XCUIElement {
            any.matching(NSPredicate(format: "identifier == %@ AND label CONTAINS %@", "chart-block", title)).firstMatch
        }
        func readout(_ block: XCUIElement) -> XCUIElement { block.descendants(matching: .any)["chart-readout"].firstMatch }
        /// Waits for the readout to say `text`, and returns what it says.
        func reads(_ block: XCUIElement, _ text: String) -> String {
            let line = readout(block)
            _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", text),
                                                               object: line)], timeout: 2)
            return line.label
        }
        func drag(by dy: CGFloat) {
            let start = dy > 0 ? top + 30 : bottom - 30
            origin.withOffset(CGVector(dx: screen.width / 2, dy: start))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: screen.width / 2, dy: start + dy)),
                       withVelocity: .slow, thenHoldForDuration: 0.3)
            Thread.sleep(forTimeInterval: 0.5)
        }
        /// Scrolls until the element is between the header and `limit`, or
        /// its top is when it is taller than that. Up by no more than it
        /// takes, so a pull at the end does not open a new chat.
        func reveal(_ element: XCUIElement, above limit: CGFloat? = nil) -> Bool {
            let floor = limit ?? bottom
            let room = floor - top
            for _ in 0..<10 {
                let frame = element.frame
                let tall = frame.height > room
                if frame.minY >= top && (tall ? frame.minY <= top + 60 : frame.maxY <= floor) { return true }
                if frame.minY < top {
                    drag(by: min(room * 0.8, top - frame.minY + 24))
                } else {
                    drag(by: -min(room * 0.8, tall ? frame.minY - top - 24 : frame.maxY - floor + 24))
                }
            }
            return false
        }
        func fits(_ block: XCUIElement, _ what: String) {
            let frame = block.frame
            print("MARKDOWN-NOTE \(name) \(what) at \(frame), screen \(screen.size)")
            XCTAssertTrue(frame.width > 100 && frame.minX >= 0 && frame.maxX <= screen.width + 0.5, "\(what) keeps the screen's width")
        }

        // Nothing of the data shows as text (the pasteboard's own line,
        // which shows what was copied, aside); the broken data shows as its
        // source under the reason, and the prose after it follows.
        let raw = app.staticTexts.matching(NSPredicate(format: "(label CONTAINS %@ OR label CONTAINS %@) AND identifier != %@",
                                                       "\"unit\"", "```", "preview-pasteboard"))
        XCTAssertEqual(raw.count, 0, "Chart data as text")
        let fallback = any.matching(identifier: "chart-fallback").firstMatch
        XCTAssertTrue(fallback.exists, "The broken data's note")
        XCTAssertTrue(reveal(fallback, above: any["chat-composer"].frame.minY - 4), "The broken data's note on screen")
        print("MARKDOWN-NOTE \(name) fallback: \(fallback.label)")
        XCTAssertTrue(fallback.label.contains("「A」の値が数値ではありません"), "The note says why")
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "たくさん")).firstMatch.exists,
                      "The broken data shown as code")
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "表示できないデータの後")).firstMatch.exists,
                      "The prose after the broken data")
        capture("\(name)-fallback", app: app)

        // Two series: a legend, and a tap reads out both values.
        let quarters = chart("四半期の売上")
        XCTAssertTrue(quarters.exists && reveal(quarters), "The chart of two series on screen")
        fits(quarters, "two series")
        XCTAssertEqual(readout(quarters).label, "項目をタップすると数値を表示します")
        if everything {
            let frame = quarters.frame
            origin.withOffset(CGVector(dx: frame.maxX - 44, dy: frame.maxY - 150)).tap()
            XCTAssertEqual(reads(quarters, "Q4：2024年 15.4億円・2025年 17.2億円"), "Q4：2024年 15.4億円・2025年 17.2億円",
                           "A tap on Q4 reads out both series")
        }
        capture("\(name)-series", app: app)

        // Bars on their side: seven items and a long label.
        let stores = chart("地方別の店舗数")
        XCTAssertTrue(stores.exists && reveal(stores), "The chart of bars on their side on screen")
        fits(stores, "bars on their side")
        XCTAssertEqual(readout(stores).label, "最大：関東 128店", "With nothing picked, the largest bar")
        capture("\(name)-rows", app: app)
        if everything {
            // 近畿 is the fourth of seven rows: its mark if it is exposed,
            // else where its row is drawn.
            let frame = stores.frame
            let mark = stores.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "近畿")).firstMatch
            let markY = mark.exists && frame.contains(CGPoint(x: frame.midX, y: mark.frame.midY)) ? mark.frame.midY : nil
            print("MARKDOWN-NOTE \(name) 近畿 row \(markY.map { "from its mark at \($0)" } ?? "from the layout")")
            origin.withOffset(CGVector(dx: frame.midX, dy: markY ?? frame.maxY - 134)).tap()
            XCTAssertEqual(reads(stores, "近畿：85店"), "近畿：85店", "A tap on a row reads it out")
            capture("\(name)-rows-picked", app: app)

            // The copy button and the menu copy this chart's data alone.
            let markdown = "地方別の店舗数（サンプル）\n\n| 項目 | 値（店） |\n| --- | --: |\n| 北海道・東北 | 42 |\n| 関東 | 128 |\n"
                + "| 中部 | 67 |\n| 近畿 | 85 |\n| 中国・四国 | 31 |\n| 九州・沖縄 | 49 |\n| 海外（アジア太平洋地域） | 12 |"
            let separated = "項目\t値（店）\n北海道・東北\t42\n関東\t128\n中部\t67\n近畿\t85\n中国・四国\t31\n九州・沖縄\t49\n海外（アジア太平洋地域）\t12"
            let pasteboard = any.matching(identifier: "preview-pasteboard").firstMatch
            func waitForCopy(after previous: String) -> String {
                _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label != %@", previous),
                                                                   object: pasteboard)], timeout: 3)
                return pasteboard.label
            }
            func note(_ text: String, _ what: String) {
                print("MARKDOWN-NOTE \(name) \(what) copied \(text.count) characters: "
                      + text.replacingOccurrences(of: "\n", with: "⏎").replacingOccurrences(of: "\t", with: "⇥").prefix(200))
            }
            var previous = pasteboard.label
            stores.buttons["chart-copy"].firstMatch.tap()
            let button = waitForCopy(after: previous)
            note(button, "the copy button")
            XCTAssertEqual(button, markdown, "The copy button copies the chart's data as a Markdown table")

            let titleText = stores.staticTexts["地方別の店舗数（サンプル）"].firstMatch
            func fromMenu(_ item: String) -> String? {
                Thread.sleep(forTimeInterval: 0.8)
                let title = titleText.frame
                origin.withOffset(CGVector(dx: title.midX, dy: title.midY)).press(forDuration: 1.2)
                // The card's copy button has the same name as the menu's.
                let entry = app.buttons.matching(NSPredicate(format: "label == %@ AND identifier != %@", item, "chart-copy")).firstMatch
                guard entry.waitForExistence(timeout: 3) else {
                    print("MARKDOWN-NOTE \(name) menu without \(item): "
                          + app.buttons.allElementsBoundByIndex.map(\.label).filter { $0.contains("コピー") }.joined(separator: ", "))
                    return nil
                }
                previous = pasteboard.label
                entry.tap()
                return waitForCopy(after: previous)
            }
            let tabs = fromMenu("タブ区切りでコピー")
            capture("\(name)-copied", app: app)
            note(tabs ?? "", "タブ区切りでコピー")
            XCTAssertEqual(tabs, separated, "タブ区切りでコピー copies the data tab separated")
            let table = fromMenu("データをコピー")
            note(table ?? "", "データをコピー")
            XCTAssertEqual(table, markdown, "データをコピー copies the data as a Markdown table")
            let whole = fromMenu("返信全体をコピー") ?? ""
            note(whole, "返信全体をコピー")
            XCTAssertTrue(whole.hasPrefix("地方別の店舗数です。") && whole.contains("```chart")
                          && whole.hasSuffix("表示できないデータの後の文章です。"), "返信全体をコピー copies the whole reply as written")
        }

        // Further up, in the reply before: a pie with its legend, a line
        // and upright bars.
        let pie = chart("1日の時間の使い方")
        XCTAssertTrue(pie.exists && reveal(pie), "The pie chart on screen")
        fits(pie, "pie")
        XCTAssertEqual(readout(pie).label, "合計：24時間", "With nothing picked, the pie's total")
        let work = pie.buttons["仕事、8時間、33.3パーセント"].firstMatch
        XCTAssertTrue(work.exists && reveal(work), "The legend names each slice with its value and share")
        work.tap()
        XCTAssertEqual(reads(pie, "仕事：8時間（33.3%）"), "仕事：8時間（33.3%）", "A tap on the legend reads the slice out")
        capture("\(name)-pie", app: app)

        let line = chart("東京の月別平均気温")
        XCTAssertTrue(line.exists && reveal(line), "The line chart on screen")
        fits(line, "line")
        XCTAssertEqual(readout(line).label, "1月 5.4℃ → 12月 7.7℃", "With nothing picked, the first and last values")
        capture("\(name)-line", app: app)

        let cities = chart("主要都市の人口")
        XCTAssertTrue(cities.exists && reveal(cities), "The upright bars on screen")
        fits(cities, "upright bars")
        XCTAssertEqual(readout(cities).label, "最大：東京 1,400万人", "With nothing picked, the largest bar")
        if everything {
            // 大阪 is the middle one of five bars.
            let frame = cities.frame
            origin.withOffset(CGVector(dx: frame.midX + 15, dy: frame.maxY - 120)).tap()
            XCTAssertEqual(reads(cities, "大阪：275万人"), "大阪：275万人", "A tap on a bar reads it out")
        }
        capture("\(name)-columns", app: app)
        XCTAssertEqual(raw.count, 0, "Chart data as text")
    }

    /// A chart streamed a few characters at a time (`--chart-stream`): its
    /// data never shows as text or code while it arrives, the chart takes
    /// its placeholder's place once its block is complete, and the prose
    /// after it follows.
    @MainActor func testChartStreamsWithoutShowingItsData() {
        checkChartStream(["--chart-stream"], message: "果物の売上を見せて", name: "markdown-chart-stream")
    }

    /// The same reply as Gemma E2B wrote it on the phone (1.0.100), the chart
    /// block inside a ```markdown fence, answering a message that asks for
    /// a chart: the wrapper's fences never show, the chart is drawn, and the
    /// prose after it is prose, not code.
    @MainActor func testWrappedChartFromThePhoneIsDrawn() {
        checkChartStream(["--chart-stream", "--chart-wrapped"], message: "果物の売上をグラフにして", name: "markdown-chart-wrapped")
    }

    @MainActor private func checkChartStream(_ arguments: [String], message: String, name: String) {
        continueAfterFailure = false
        let app = PreviewApp(); app.launchArguments = arguments; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しいチャット"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText(message)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["停止する"].waitForExistence(timeout: 10))
        let any = app.descendants(matching: .any)
        let watched = any.matching(NSPredicate(format: "identifier IN %@", ["chart-pending", "chart-block", "chart-fallback", "code-block"]))
        let raw = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@ OR label CONTAINS %@ OR label CONTAINS %@",
                                                       "\"type\"", "\"label\"", "```"))
        var seen: [String] = []
        var checks = 0
        let start = Date()
        while app.buttons["停止する"].exists && Date().timeIntervalSince(start) < 30 {
            checks += 1
            XCTAssertEqual(raw.count, 0, "Chart data as text while streaming: \(raw.allElementsBoundByIndex.map(\.label))")
            let shown = watched.allElementsBoundByIndex.map(\.identifier)
            XCTAssertFalse(shown.contains("code-block") || shown.contains("chart-fallback"),
                           "A code block or the fallback while the chart streams: \(shown)")
            for identifier in shown where !seen.contains(identifier) {
                seen.append(identifier)
                capture("\(name)-\(identifier)", app: app)
            }
        }
        print("MARKDOWN-NOTE \(name): \(checks) checks in \(Date().timeIntervalSince(start)) s, seen \(seen)")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.6)
        let block = any.matching(identifier: "chart-block").firstMatch
        XCTAssertTrue(block.waitForExistence(timeout: 3), "The chart once its data is complete")
        XCTAssertFalse(any.matching(identifier: "chart-pending").firstMatch.exists, "No placeholder after the reply")
        XCTAssertFalse(any.matching(identifier: "chart-fallback").firstMatch.exists, "No fallback for complete data")
        XCTAssertEqual(block.descendants(matching: .any)["chart-readout"].firstMatch.label, "最大：りんご 120個")
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "グラフの後の説明です。")).firstMatch
                        .waitForExistence(timeout: 4), "The prose after the chart")
        XCTAssertEqual(raw.count, 0, "Chart data as text after the reply")
        XCTAssertFalse(any.matching(identifier: "code-block").firstMatch.exists, "No code block after the reply")
        capture("\(name)-done", app: app)
    }

    /// Magic Keyboard (fielua-reports #3, 1.1.0 (222)), on an iPad in
    /// landscape as on the keyboard's stand. The simulator's own keyboard
    /// stays on the screen and XCUITest's keys never reach the field (run
    /// 40702339896), so the checks give the app what the tester's iPad
    /// said instead: `--hardware-keyboard` counts the Mac's keyboard that
    /// Simulator joins to it (GameController), `--probe-hardware-notices`
    /// posts the keyboard notices of the tester's record as the field takes
    /// the keys. The model and 高速・深く buttons must open their menus and
    /// a choice must take; スタンダード's pills stand without the field too.
    /// `221` is the composer as it was (--keyboard-as-221): its pills going
    /// away under the notices is the tester's report, and only printed.
    /// Return is tried and printed (HWKB lines), never required.
    @MainActor func testHardwareKeyboardSmartComposer() {
        hardwareKeyboard("smart", ["--hardware-keyboard", "--probe-hardware-notices"], answers: true)
    }
    @MainActor func testHardwareKeyboardClassicComposer() {
        hardwareKeyboard("classic", ["--classic-composer", "--hardware-keyboard", "--probe-hardware-notices"], answers: true)
    }
    @MainActor func testHardwareKeyboardClassicComposerAs221() {
        hardwareKeyboard("classic-221", ["--classic-composer", "--keyboard-as-221", "--probe-hardware-notices"], answers: false)
    }
    /// Without GameController's keyboard (it may not tell): the notices
    /// alone no longer put the pills away.
    @MainActor func testHardwareKeyboardNoticesKeepClassicPills() {
        hardwareKeyboard("classic-notices", ["--classic-composer", "--probe-hardware-notices"], answers: true)
    }

    @MainActor private func hardwareKeyboard(_ variant: String, _ flags: [String], answers: Bool) {
        continueAfterFailure = true
        XCUIDevice.shared.orientation = .landscapeLeft
        addTeardownBlock { XCUIDevice.shared.orientation = .portrait }
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--keyboard-probe"] + flags
        app.launch()
        let input = app.textViews["chat-input"]
        let model = app.buttons["composer-model"], detail = app.buttons["composer-photo-detail"]
        let probe = app.descendants(matching: .any)["keyboard-probe"]
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.5)
        var missed: [String] = []
        func text() -> String { input.value as? String ?? "" }
        func log(_ step: String) {
            print("HWKB \(variant) \(step) soft-keyboards=\(app.keyboards.count) field=\(input.frame) "
                  + "text=\(text().debugDescription) probe=\(probe.exists ? probe.label : "none")")
        }
        func focus() {
            // A tap on a field that has the keys opens UIKit's edit menu
            // (選択・すべてを選択) over the pills (run 40709897986).
            if probe.exists && probe.label.hasPrefix("focused=true") { return }
            input.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            // Past the notices (0.5 and 0.8 s) and the pills' motion.
            Thread.sleep(forTimeInterval: 1.6)
        }
        let outside = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.25))
        // A menu opens from its button and stays open.
        func opens(_ name: String, _ button: XCUIElement, _ item: XCUIElement) -> Bool {
            let shown = button.exists && button.isHittable
            log("\(name)-before shown=\(shown) frame=\(button.exists ? "\(button.frame)" : "none")")
            var opened = false, stays = false
            if shown {
                button.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
                opened = item.waitForExistence(timeout: 3)
                Thread.sleep(forTimeInterval: 1.0)
                stays = item.exists
            }
            log("\(name)-after opened=\(opened) stays=\(stays)")
            capture("hwkb-\(variant)-\(name)", app: app)
            print("HWKB \(variant) \(name) \(opened && stays ? "answered" : "NO-ANSWER")")
            if !(opened && stays) { missed.append(name) }
            return opened && stays
        }
        let gemma = menuItem("model-menu-gemma", "Gemma", app)
        func closeMenu() { outside.tap(); _ = gone(gemma); Thread.sleep(forTimeInterval: 0.8) }

        // スタンダード with a hardware keyboard: the pills before the field
        // has the keys.
        if variant == "classic" {
            capture("hwkb-\(variant)-unfocused", app: app)
            if opens("model-unfocused", model, gemma) { closeMenu() }
        }

        focus()
        log("focused")
        capture("hwkb-\(variant)-focused", app: app)
        input.typeText("Magic Keyboard")
        Thread.sleep(forTimeInterval: 1.0)
        log("typed")

        // The model menu, then 高速・じっくり考える with じっくり考える chosen,
        // the field holding the keys each time.
        if opens("model", model, gemma) { closeMenu() }
        log("model-closed")
        focus()
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "じっくり考える")).firstMatch
        if opens("detail", detail, deep) {
            deep.tap()
            Thread.sleep(forTimeInterval: 1.0)
            let chosen = detail.value as? String ?? ""
            print("HWKB \(variant) detail-choice value=\(chosen)")
            if !chosen.contains("じっくり考える") { missed.append("detail-choice") }
        }
        log("detail-closed")

        // Return, as far as XCUITest's keys go: printed only.
        focus()
        input.typeKey("\r", modifierFlags: [])
        let returned = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Magic Keyboard")).firstMatch
            .waitForExistence(timeout: 3)
        log("return")
        print("HWKB \(variant) return \(returned ? "SENT" : "not sent (XCUITest's key did not reach the field)")")
        capture("hwkb-\(variant)-return", app: app)

        print("HWKB \(variant) missed=\(missed.isEmpty ? "none" : missed.joined(separator: ","))")
        if answers {
            XCTAssertEqual(missed, [], "With the hardware keyboard's notices every button answers")
        } else {
            print("HWKB \(variant) reproduced=\(missed.contains("model") || missed.contains("detail") ? "yes" : "no")")
        }
    }

    /// Below this share of non-background pixels the conversation is blank.
    /// Text and bubbles cover several percent of the reading area.
    /// These checks read the unfolded composer while they scroll through
    /// older messages (its jump control, the plus menu, the field). The
    /// composer's fold has checks of its own (testComposer...).
    static let keepOpen = ["--keep-composer-open"]
    /// A reply's text and its blocks start 16pt in from the app's edges
    /// (ChatMetrics: the 12pt gutter and the reply's 4pt inset).
    static let replyEdge: CGFloat = 16
    static let drawnInk = 0.005

    /// Share of pixels that differ from the background in the conversation,
    /// between the header and the jump control. Accessibility frames stay
    /// in place when rows are not drawn, so hit tests alone miss a blank
    /// screen (the eager block as one lazy item, 1.0.71).
    @MainActor private func readingInk(_ app: XCUIApplication) -> Double {
        let shot = XCUIScreen.main.screenshot().image
        guard let image = shot.cgImage, app.frame.width > 0 else { return -1 }
        let scale = CGFloat(image.width) / app.frame.width
        let top = app.buttons["chat-model-settings"].frame.maxY + 12
        let bottom = app.descendants(matching: .any)["chat-composer"].frame.minY - 90
        guard bottom > top + 40,
              let region = image.cropping(to: CGRect(x: 0, y: top * scale, width: CGFloat(image.width),
                                                     height: (bottom - top) * scale).integral) else { return -1 }
        let width = 300, height = max(1, width * region.height / max(1, region.width))
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(region, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return -1 }
        var luma: [Int] = []
        luma.reserveCapacity(width * height)
        for index in stride(from: 0, to: pixels.count, by: 4) {
            let red = 299 * Int(pixels[index])
            let green = 587 * Int(pixels[index + 1])
            let blue = 114 * Int(pixels[index + 2])
            luma.append((red + green + blue) / 1000)
        }
        let background: Int = luma.sorted()[luma.count / 2]
        let marked: Int = luma.filter { abs($0 - background) > 60 }.count
        return Double(marked) / Double(luma.count)
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// Aurora Bloom (1.1.0 (178)) from launch (with --bloom-delay, so it
    /// starts after the launch has settled): screenshots as quick as they
    /// come, read a point per pixel, and of each the light's coloured size
    /// above the wordmark and the wordmark's coloured letters, printed as
    /// WELCOME-BLOOM lines and put on one sheet. The light is born small,
    /// grows to its size without shrinking back, and the wordmark comes in
    /// as it opens.
    @MainActor private func captureBloom(_ name: String, app: XCUIApplication) {
        let screen = CGRect(origin: .zero, size: app.frame.size)
        var frames: [(time: Date, area: ScreenArea)] = []
        let begin = Date()
        while Date().timeIntervalSince(begin) < 13 {
            guard let shot = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(shot, screen, screenWidth: screen.width) else { break }
            frames.append((Date(), area))
        }
        let wordmark = app.staticTexts["Fielua"]
        XCTAssertTrue(wordmark.waitForExistence(timeout: 5))
        let word = wordmark.frame
        let canvas = CGRect(x: word.midX - 140, y: word.minY + 47.4 - 280, width: 280, height: 280)
        let above = CGRect(x: canvas.minX, y: canvas.minY, width: canvas.width, height: word.minY - canvas.minY)
        let readings = frames.map { frame in
            (time: frame.time, light: frame.area.colour(in: above), letters: frame.area.colour(in: word).count)
        }
        guard let born = readings.first(where: { $0.light.count > 0 }) else {
            return XCTFail("The welcome's light never drew")
        }
        XCTAssertTrue(readings.first?.light.count == 0,
                      "The screenshots began after the light: the launch took longer than --bloom-delay")
        for reading in readings {
            print(String(format: "WELCOME-BLOOM %@ t=%.2f light %d pt² %.0fx%.0f letters %d", name,
                         reading.time.timeIntervalSince(born.time), reading.light.count,
                         reading.light.bounds.isNull ? 0 : reading.light.bounds.width,
                         reading.light.bounds.isNull ? 0 : reading.light.bounds.height, reading.letters))
        }
        let lit = readings.filter { $0.time >= born.time }
        let widths = lit.map { (age: $0.time.timeIntervalSince(born.time), width: $0.light.bounds.width) }
        XCTAssertLessThanOrEqual(born.light.bounds.width, 60, "Born small")
        let grown = widths.last(where: { $0.age <= 2.6 })?.width ?? 0
        XCTAssertGreaterThan(grown, 110, "Grown to its size")
        // Until its glow spreads (its colour widens the bounds as it opens,
        // and narrows them as it settles); the flowing colours at its edge
        // move the bounds by a few points.
        for (earlier, later) in zip(widths, widths.dropFirst()) where later.age <= 1.6 {
            XCTAssertGreaterThanOrEqual(later.width, earlier.width - 4, "Grows without shrinking back at \(later.age) s")
        }
        if let letters = lit.first(where: { $0.letters > 30 }) {
            let after = letters.time.timeIntervalSince(born.time)
            print(String(format: "WELCOME-BLOOM %@ wordmark after %.2f s", name, after))
            XCTAssertTrue((0.9...2.6).contains(after), "The wordmark comes in as the light opens: \(after) s")
        } else {
            XCTFail("The wordmark's colours never showed")
        }
        // Twelve frames from just before the light to after it has opened.
        let region = CGRect(x: canvas.minX, y: canvas.minY, width: canvas.width, height: word.maxY + 34 - canvas.minY)
        let picks = frames.filter { $0.time >= born.time.addingTimeInterval(-0.3) }.prefix(12)
        let tile = region.size
        let sheet = UIGraphicsImageRenderer(size: CGSize(width: tile.width * 4, height: tile.height * 3)).image { context in
            UIColor.gray.setFill(); context.fill(CGRect(x: 0, y: 0, width: tile.width * 4, height: tile.height * 3))
            for (index, frame) in picks.enumerated() {
                let origin = CGPoint(x: CGFloat(index % 4) * tile.width, y: CGFloat(index / 4) * tile.height)
                if let image = frame.area.image(of: region) {
                    UIImage(cgImage: image).draw(in: CGRect(origin: origin, size: tile))
                }
                let label = String(format: "%.2f s", frame.time.timeIntervalSince(born.time))
                (label as NSString).draw(at: CGPoint(x: origin.x + 6, y: origin.y + 4),
                                         withAttributes: [.font: UIFont.systemFont(ofSize: 12), .foregroundColor: UIColor.gray])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// Waits, with screenshots only, for the welcome's light to show in the
    /// middle of the screen, before its wordmark.
    @MainActor private func waitForWelcomeLight(_ app: XCUIApplication) -> Bool {
        let band = CGRect(x: app.frame.midX - 140, y: app.frame.height * 0.12, width: 280, height: app.frame.height * 0.45)
        let start = Date()
        while Date().timeIntervalSince(start) < 15 {
            guard let shot = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(shot, band, screenWidth: app.frame.width) else { return false }
            if area.colour().count > 20 { return true }
        }
        return false
    }

    /// The welcome's haptics trace (preview builds with --haptics-trace),
    /// once it holds the text or the time is up.
    @MainActor private func trace(_ app: XCUIApplication, containing text: String, timeout: TimeInterval) -> String {
        let element = app.descendants(matching: .any).matching(identifier: "welcome-haptics-trace").firstMatch
        let end = Date().addingTimeInterval(timeout)
        var label = ""
        repeat {
            label = element.exists ? element.label : ""
            if !label.isEmpty && (text.isEmpty || label.contains(text)) { break }
            Thread.sleep(forTimeInterval: 0.1)
        } while Date() < end
        return label
    }

    /// The welcome's light at full resolution: its 280pt canvas, which
    /// reaches 47pt into the wordmark (OnboardingView's WelcomeOrb.margin),
    /// to review its outline and colours pixel by pixel. The light waits
    /// for its shader to compile, so this waits for its colours, and then
    /// for it to finish opening (1.1.0 (173) drew no light at all).
    @MainActor private func captureOrb(_ name: String, app: XCUIApplication) {
        let wordmark = app.staticTexts["Fielua"]
        XCTAssertTrue(wordmark.waitForExistence(timeout: 5))
        let canvas = CGRect(x: wordmark.frame.midX - 140, y: wordmark.frame.minY + 47.4 - 280, width: 280, height: 280)
        let start = Date()
        var lit: Double?
        while Date().timeIntervalSince(start) < 10 {
            guard let shot = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(shot, canvas, screenWidth: app.frame.width) else { break }
            if area.colour().count > 5000 { lit = Date().timeIntervalSince(start); break }
            Thread.sleep(forTimeInterval: 0.25)
        }
        XCTAssertNotNil(lit, "The welcome's light never drew")
        guard lit != nil else { return }
        Thread.sleep(forTimeInterval: 1.6)
        guard let image = XCUIScreen.main.screenshot().image.cgImage,
              let area = ScreenArea(image, canvas, screenWidth: app.frame.width) else { return }
        let colour = area.colour()
        print(String(format: "WELCOME-ORB %@ lit after %.2f s, colour %d pt², bounds %.0fx%.0f at (%.0f, %.0f)",
                     name, lit ?? -1, colour.count, colour.bounds.width, colour.bounds.height,
                     colour.bounds.minX, colour.bounds.minY))
        let scale = CGFloat(image.width) / app.frame.width
        let pixels = CGRect(x: canvas.minX * scale, y: canvas.minY * scale,
                            width: canvas.width * scale, height: canvas.height * scale).integral
        guard let crop = image.cropping(to: pixels) else { return }
        let attachment = XCTAttachment(image: UIImage(cgImage: crop))
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// Ten screenshots as quick as they come (about 0.2 s apart) of the
    /// first lines of a reply whose text is flowing in, cropped at full
    /// resolution and stacked on one sheet with their times, to review how
    /// the characters appear.
    @MainActor private func revealStrip(_ name: String, app: XCUIApplication, around frame: CGRect) {
        let screenWidth = app.frame.width
        guard screenWidth > 0, frame.width > 0 else { return }
        var frames: [(t: Double, image: UIImage)] = []
        let start = Date()
        for _ in 0..<10 {
            let t = Date().timeIntervalSince(start)
            let shot = XCUIScreen.main.screenshot().image
            guard let image = shot.cgImage else { continue }
            let scale = CGFloat(image.width) / screenWidth
            let rect = CGRect(x: max(0, frame.minX - 4) * scale, y: max(0, frame.minY - 6) * scale,
                              width: min(frame.width + 8, screenWidth) * scale, height: 60 * scale).integral
            guard let crop = image.cropping(to: rect) else { continue }
            frames.append((t, UIImage(cgImage: crop)))
        }
        guard let first = frames.first else { return }
        let label: CGFloat = 16
        let cell = first.image.size
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let sheetSize = CGSize(width: cell.width, height: (cell.height + label) * CGFloat(frames.count))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let top = CGFloat(index) * (cell.height + label)
                frame.image.draw(in: CGRect(x: 0, y: top + label, width: cell.width, height: cell.height))
                (String(format: "%ld  %.0f ms", index, frame.t * 1000) as NSString)
                    .draw(at: CGPoint(x: 4, y: top + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 12), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        print("MARKDOWN-NOTE reveal strip shots at " + frames.map { String(format: "%.2f", $0.t) }.joined(separator: " ") + " s")
    }
}

/// One screenshot in the Aurora Orb test: seconds after the send tap, the
/// orb's colour in points², the share of text right of it on its line, and
/// the top of the sent bubble.
private struct OrbReading {
    let t: Double
    let colour: Int
    let ink: Double
    let bubble: CGFloat?
}

/// An area of a screenshot read at one pixel per point, to measure what is
/// drawn there without querying the app.
/// A screenshot's rect in its own pixels, for comparing two screenshots
/// pixel by pixel (the slid conversation's corners, 1.1.0 (190)).
private struct RGBAPixels {
    private let bytes: [UInt8]
    private let width: Int
    private let scale: CGFloat

    init?(_ shot: CGImage, _ rect: CGRect, scale: CGFloat) {
        let pixels = CGRect(x: rect.minX * scale, y: rect.minY * scale,
                            width: rect.width * scale, height: rect.height * scale).integral
        guard let crop = shot.cropping(to: pixels) else { return nil }
        let width = crop.width, height = crop.height
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(crop, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return nil }
        self.bytes = bytes
        self.width = width
        self.scale = scale
    }

    /// The largest difference of any colour channel and where it is (in
    /// points from the rect's origin), the mean, and the share of pixels
    /// more than 8 levels apart.
    func difference(_ other: RGBAPixels) -> (max: Int, at: CGPoint, mean: Double, overShare: Double) {
        guard bytes.count == other.bytes.count, !bytes.isEmpty else { return (255, .zero, 255, 1) }
        var largest = 0, place = 0, sum = 0, over = 0
        for index in stride(from: 0, to: bytes.count, by: 4) {
            var pixel = 0
            for channel in 0..<3 {
                let change = abs(Int(bytes[index + channel]) - Int(other.bytes[index + channel]))
                pixel = max(pixel, change); sum += change
            }
            if pixel > largest { largest = pixel; place = index / 4 }
            if pixel > 8 { over += 1 }
        }
        let pixels = bytes.count / 4
        let at = CGPoint(x: CGFloat(place % width) / scale, y: CGFloat(place / width) / scale)
        return (largest, at, Double(sum) / Double(pixels * 3), Double(over) / Double(pixels))
    }

    private func luma(_ index: Int) -> Int {
        (Int(bytes[index]) * 299 + Int(bytes[index + 1]) * 587 + Int(bytes[index + 2]) * 114) / 1000
    }

    var darkest: Int {
        stride(from: 0, to: bytes.count, by: 4).map { luma($0) }.min() ?? 255
    }

    var meanLuma: Double {
        let values = stride(from: 0, to: bytes.count, by: 4).map { luma($0) }
        return Double(values.reduce(0, +)) / Double(max(1, values.count))
    }
}

private struct ScreenArea {
    let frame: CGRect
    private let width: Int
    private let height: Int
    private let bytes: [UInt8]

    init?(_ shot: CGImage, _ frame: CGRect, screenWidth: CGFloat) {
        guard screenWidth > 0, frame.width >= 1, frame.height >= 1 else { return nil }
        let scale = CGFloat(shot.width) / screenWidth
        let rect = CGRect(x: frame.minX * scale, y: frame.minY * scale,
                          width: frame.width * scale, height: frame.height * scale).integral
        guard let crop = shot.cropping(to: rect) else { return nil }
        let width = Int(frame.width), height = Int(frame.height)
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(crop, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return nil }
        self.frame = CGRect(origin: frame.origin, size: CGSize(width: width, height: height))
        self.width = width
        self.height = height
        self.bytes = bytes
    }

    /// The clearly coloured pixels, where text and the conversation are
    /// black, white or grey: how many, their middle and their bounds.
    func colour() -> (count: Int, centre: CGPoint, bounds: CGRect) {
        var count = 0, sumX = 0, sumY = 0
        var minX = Int.max, maxX = Int.min, minY = Int.max, maxY = Int.min
        for y in 0..<height {
            for x in 0..<width where Self.chroma(pixel(x, y)) > 50 {
                count += 1; sumX += x; sumY += y
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard count > 0 else { return (0, .zero, .null) }
        let centre = CGPoint(x: frame.minX + CGFloat(sumX) / CGFloat(count) + 0.5,
                             y: frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5)
        let bounds = CGRect(x: frame.minX + CGFloat(minX), y: frame.minY + CGFloat(minY),
                            width: CGFloat(maxX - minX + 1), height: CGFloat(maxY - minY + 1))
        return (count, centre, bounds)
    }

    /// Share of a band's pixels that are text, grey to black on a light
    /// background or light on a dark one, and the middle of that text.
    func ink(in rect: CGRect, background: Int) -> (share: Double, centreY: CGFloat) {
        let (columns, rows) = span(rect)
        var count = 0, sumY = 0
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) < 60, abs(Self.luma(value) - background) > 80 { count += 1; sumY += y }
            }
        }
        let share = Double(count) / Double(max(1, columns.count * rows.count))
        return (share, count == 0 ? .nan : frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5)
    }

    func meanLuma(in rect: CGRect) -> Int {
        let (columns, rows) = span(rect)
        var total = 0
        for y in rows {
            for x in columns { total += Self.luma(pixel(x, y)) }
        }
        return total / max(1, columns.count * rows.count)
    }

    /// The top of the sent bubble: the first row with some blue in it.
    func blueTop() -> CGFloat? {
        for y in 0..<height {
            var blue = 0
            for x in 0..<width {
                let value = pixel(x, y)
                if value.blue > 180, value.blue - value.red > 120 { blue += 1 }
            }
            if blue >= 3 { return frame.minY + CGFloat(y) }
        }
        return nil
    }

    /// The bounds, in screen points, of the grey to black pixels off the
    /// background inside a rectangle given in screen points.
    func inkBounds(in rect: CGRect, background: Int) -> CGRect? {
        let (columns, rows) = span(rect)
        var minX = Int.max, maxX = Int.min
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) < 60, abs(Self.luma(value) - background) > 80 { minX = min(minX, x); maxX = max(maxX, x) }
            }
        }
        guard minX <= maxX else { return nil }
        return CGRect(x: frame.minX + CGFloat(minX), y: rect.minY, width: CGFloat(maxX - minX + 1), height: rect.height)
    }

    /// Coloured pixels, and grey to black ones off the background, inside
    /// a rectangle given in screen points.
    func marks(in rect: CGRect, background: Int) -> (colour: Int, ink: Int) {
        let (columns, rows) = span(rect)
        var colour = 0, ink = 0
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) > 50 { colour += 1 } else if abs(Self.luma(value) - background) > 80 { ink += 1 }
            }
        }
        return (colour, ink)
    }

    /// Mean change of colour from an earlier reading of the same area, over
    /// the pixels coloured in either.
    func change(from earlier: ScreenArea, in rect: CGRect) -> Double {
        let (columns, rows) = span(rect)
        var total = 0, count = 0
        for y in rows {
            for x in columns {
                let now = pixel(x, y), then = earlier.pixel(x, y)
                guard Self.chroma(now) > 50 || Self.chroma(then) > 50 else { continue }
                total += abs(now.red - then.red) + abs(now.green - then.green) + abs(now.blue - then.blue)
                count += 3
            }
        }
        return count == 0 ? 0 : Double(total) / Double(count)
    }

    /// `colour()` and the colour's weight in one pass: every pixel's
    /// colourfulness above the paper's summed, and its middle. The weight
    /// changes smoothly as a coloured shape moves or grows by less than a
    /// point.
    func colourAndWeight() -> (count: Int, centre: CGPoint, bounds: CGRect, mass: Double, massCentre: CGPoint) {
        var count = 0, sumX = 0, sumY = 0
        var mass = 0, massX = 0, massY = 0
        var minX = Int.max, maxX = Int.min, minY = Int.max, maxY = Int.min
        for y in 0..<height {
            for x in 0..<width {
                let chroma = Self.chroma(pixel(x, y))
                guard chroma > 14 else { continue }
                let value = chroma - 14
                mass += value; massX += value * x; massY += value * y
                guard chroma > 50 else { continue }
                count += 1; sumX += x; sumY += y
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard count > 0, mass > 0 else { return (0, .zero, .null, 0, .zero) }
        return (count,
                CGPoint(x: frame.minX + CGFloat(sumX) / CGFloat(count) + 0.5, y: frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5),
                CGRect(x: frame.minX + CGFloat(minX), y: frame.minY + CGFloat(minY),
                       width: CGFloat(maxX - minX + 1), height: CGFloat(maxY - minY + 1)),
                Double(mass),
                CGPoint(x: frame.minX + CGFloat(massX) / CGFloat(mass) + 0.5, y: frame.minY + CGFloat(massY) / CGFloat(mass) + 0.5))
    }

    /// The mean colour inside a rectangle given in screen points.
    func meanColour(in rect: CGRect) -> (red: Double, green: Double, blue: Double) {
        let (columns, rows) = span(rect)
        var red = 0, green = 0, blue = 0
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                red += value.red; green += value.green; blue += value.blue
            }
        }
        let count = Double(max(1, columns.count * rows.count))
        return (Double(red) / count, Double(green) / count, Double(blue) / count)
    }

    /// The clearly coloured pixels inside a rectangle: how many and their
    /// bounds.
    func colour(in rect: CGRect) -> (count: Int, bounds: CGRect) {
        let (columns, rows) = span(rect)
        var count = 0
        var minX = Int.max, maxX = Int.min, minY = Int.max, maxY = Int.min
        for y in rows {
            for x in columns where Self.chroma(pixel(x, y)) > 50 {
                count += 1
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard count > 0 else { return (0, .null) }
        return (count, CGRect(x: frame.minX + CGFloat(minX), y: frame.minY + CGFloat(minY),
                              width: CGFloat(maxX - minX + 1), height: CGFloat(maxY - minY + 1)))
    }

    /// A rectangle of the reading as an image, a pixel per point.
    func image(of rect: CGRect) -> CGImage? {
        let (columns, rows) = span(rect)
        guard !columns.isEmpty, !rows.isEmpty else { return nil }
        var cut = [UInt8]()
        cut.reserveCapacity(columns.count * rows.count * 4)
        for y in rows {
            let start = (y * width + columns.lowerBound) * 4
            cut.append(contentsOf: bytes[start..<(start + columns.count * 4)])
        }
        guard let provider = CGDataProvider(data: Data(cut) as CFData) else { return nil }
        return CGImage(width: columns.count, height: rows.count, bitsPerComponent: 8, bitsPerPixel: 32,
                       bytesPerRow: columns.count * 4, space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
    }

    /// The pixels inside a rectangle given in screen points.
    private func span(_ rect: CGRect) -> (columns: Range<Int>, rows: Range<Int>) {
        guard !rect.isNull else { return (0..<0, 0..<0) }
        let x0 = min(width, max(0, Int((rect.minX - frame.minX).rounded(.down))))
        let x1 = min(width, max(x0, Int((rect.maxX - frame.minX).rounded(.up))))
        let y0 = min(height, max(0, Int((rect.minY - frame.minY).rounded(.down))))
        let y1 = min(height, max(y0, Int((rect.maxY - frame.minY).rounded(.up))))
        return (x0..<x1, y0..<y1)
    }

    private func pixel(_ x: Int, _ y: Int) -> (red: Int, green: Int, blue: Int) {
        let index = (y * width + x) * 4
        return (Int(bytes[index]), Int(bytes[index + 1]), Int(bytes[index + 2]))
    }

    private static func chroma(_ value: (red: Int, green: Int, blue: Int)) -> Int {
        max(value.red, value.green, value.blue) - min(value.red, value.green, value.blue)
    }

    private static func luma(_ value: (red: Int, green: Int, blue: Int)) -> Int {
        (299 * value.red + 587 * value.green + 114 * value.blue) / 1000
    }
}

/// The license files 設定's オープンソースライセンス lists, in its order
/// (OpenSourceLicense.all in the app).
private enum OpenSourceLicenseFiles {
    static let all = ["LiteRT-LM.txt", "SwiftMath.txt", "GUST-FONT-LICENSE.txt", "OFL.txt", "LICENSE", "ZIPFoundation.txt"]
}
