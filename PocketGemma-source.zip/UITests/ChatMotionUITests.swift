import XCTest

final class ChatMotionUITests: XCTestCase {
    /// Stability gate after rolling back end-visibility observation. The stricter
    /// jump-button test below stays unchanged and its known failure is retained.
    @MainActor func testManualScrollAndComposerRemainResponsiveAfterGrowingReply() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--growing-reply", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Stability check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        XCTAssertEqual(input.value as? String, "")
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        let reading = app.scrollViews["chat-conversation"]
        func swipe(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, app.textViews["chat-input"].frame.minY - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipe(up: false); swipe(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        swipe(up: true); swipe(up: true)
        capture("manual-scroll-stability", app: app)
        // An input/edit after both drag directions proves that the event loop
        // still services interaction instead of spinning in lazy placement.
        input.tap(); input.typeText("Still responsive")
        XCTAssertEqual(input.value as? String, "Still responsive")
        XCTAssertTrue(app.keyboards.firstMatch.exists)
        capture("composer-responsive-after-manual-scroll", app: app)
    }

    @MainActor func testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition() throws {
        try mixedAttachmentStream([])
    }
    /// Probe: the same with every message a lazy row, as before 1.0.70.
    @MainActor func testProbeMixedAttachmentAllLazy() throws { try mixedAttachmentStream(["--probe-all-lazy"]) }
    /// Probe: the latest messages as one item of the lazy stack, as in 1.0.71.
    @MainActor func testProbeMixedAttachmentEagerItem() throws { try mixedAttachmentStream(["--probe-eager-item"]) }

    @MainActor private func mixedAttachmentStream(_ flags: [String]) throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = Self.keepOpen + ["--e2b", "--long-chat", "--attachment-fixtures", "--layout-stress", "--layout-metrics"] + flags
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        importFixture("sample-image", extension: "png", app: app)
        let draft = app.descendants(matching: .any).matching(identifier: "draft-attachments").firstMatch
        XCTAssertTrue(draft.waitForExistence(timeout: 5))
        XCTAssertLessThanOrEqual(draft.frame.height, 84)
        let preview = app.buttons["添付ファイルを開く: sample-image.png"]
        XCTAssertTrue(preview.exists)
        XCTAssertLessThanOrEqual(preview.frame.height, 76)
        capture("compact-image-draft", app: app)
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("Layout stress")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["回答を停止する"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.keyboards.firstMatch.exists)
        let reading = app.scrollViews["chat-conversation"]
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        reading.swipeDown(); reading.swipeDown()
        let jumpShown = app.buttons["chat-jump-latest"].waitForExistence(timeout: 4)
        let suffix = flags.isEmpty ? "" : "-probe"
        let swipedInk = readingInk(app)
        print("MIXED after-swipes\(suffix) ink=\(swipedInk) jump=\(jumpShown) \(debug.label.prefix(200))")
        capture("mixed-after-swipes" + suffix, app: app)
        XCTAssertTrue(jumpShown)
        XCTAssertGreaterThan(swipedInk, Self.drawnInk, "Scrolled up during a reply, the conversation must stay drawn")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 15))
        let streamedInk = readingInk(app)
        print("MIXED after-stream\(suffix) ink=\(streamedInk) jump=\(app.buttons["chat-jump-latest"].exists) \(debug.label.prefix(200))")
        capture("mixed-after-stream" + suffix, app: app)
        XCTAssertTrue(app.buttons["chat-jump-latest"].exists, "Finishing a stream must not move an older-message reader")
        XCTAssertGreaterThan(streamedInk, Self.drawnInk, "The finished reply must leave the conversation drawn")
        app.buttons["chat-jump-latest"].tap()
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "レイアウト検証12：")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["layout-metrics-export"].tap()
        let json = try XCTUnwrap(app.buttons["layout-metrics-export"].value as? String)
        let data = try XCTUnwrap(json.data(using: .utf8))
        let metrics = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        // Keep the observations even when a layout assertion fails.
        let attachment = XCTAttachment(data: data, uniformTypeIdentifier: "public.json")
        attachment.name = "ui-layout-and-main-display-link-metrics"; attachment.lifetime = .keepAlways; add(attachment)
        XCTAssertGreaterThan((metrics["geometrySamples"] as? Int) ?? 0, 3)
        XCTAssertEqual((metrics["maximumLayoutOverlapPoints"] as? Double) ?? -1, 0, accuracy: 0.5)
        XCTAssertGreaterThan((metrics["displayLinkSamples"] as? Int) ?? 0, 0)
        capture("mixed-attachment-stream-layout", app: app)
    }

    @MainActor func testInlinePhotoDockAndRepeatedMenuOpenClose() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--e2b"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        // Let launch settle and each menu finish opening before the outside
        // tap, as the glass morph test does; a tap mid-morph can be dropped.
        Thread.sleep(forTimeInterval: 1.0)
        for _ in 0..<3 {
            app.buttons["chat-add-menu"].tap()
            XCTAssertTrue(menuItem("chat-attach-photos", "写真", app).waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            dismissMenu(menuItem("chat-attach-photos", "写真", app), app: app)
        }
        app.buttons["chat-add-menu"].tap(); menuItem("chat-attach-photos", "写真", app).tap()
        let dock = app.descendants(matching: .any).matching(identifier: "photo-dock").firstMatch
        XCTAssertTrue(dock.waitForExistence(timeout: 5))
        // Where the sheet and the composer sit as it opens and a moment
        // later (the two-row composer's checks found the dock 874pt tall).
        print("PHOTO-SHEET opened: dock=\(dock.frame) composer=\(app.descendants(matching: .any)["chat-composer"].frame)")
        capture("composer-photo-dock", app: app)
        // The system's "Private Access to Photos" note covers the grid once
        // it loads; while it shows, the dock read screen-sized (874pt) though
        // the card on screen was compact. Measure once it is dismissed.
        let privacyNote = app.buttons["OK"]
        let noted = privacyNote.waitForExistence(timeout: 12)
        print("PHOTO-SHEET privacy note: shown=\(noted) dock=\(dock.frame)")
        if noted { privacyNote.tap(); sleep(1) }
        print("PHOTO-SHEET later: dock=\(dock.frame) composer=\(app.descendants(matching: .any)["chat-composer"].frame)")
        capture("composer-photo-dock-later", app: app)
        XCTAssertLessThan(dock.frame.height, app.frame.height * 0.5)
        XCTAssertGreaterThan(dock.frame.minY, app.buttons["chat-model-settings"].frame.maxY)
        XCTAssertTrue(app.textViews["chat-input"].isHittable)
        // Messages leaves clear room between the field and the card.
        sleep(1)
        let field = app.descendants(matching: .any)["chat-composer"]
        let gap = dock.frame.minY - field.frame.maxY
        print("PHOTO-SHEET gap: field=\(field.frame.maxY) sheet=\(dock.frame.minY) gap=\(gap)")
        capture("inline-photo-grid", app: app)
        // iMessage-style: tapping a photo adds it to the draft immediately.
        // The privacy note was handled above; tap it if it shows again late.
        let privacyOK = app.buttons["OK"]
        if privacyOK.waitForExistence(timeout: 2) { privacyOK.tap() }
        // The grid is a remote system view; its cells are not hittable
        // elements, so tap the first cell's center by coordinate.
        // While the library loads, the only image is the spinner.
        let loading = dock.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "読み込み中")).firstMatch
        if loading.exists {
            _ = XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"),
                                                                 object: loading)], timeout: 15)
        }
        let photo = dock.images.firstMatch
        let picked = photo.waitForExistence(timeout: 10)
        if picked {
            // The first tap can land while the grid is still settling, so
            // allow one more.
            let draft = app.descendants(matching: .any)["draft-attachments"]
            photo.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            if !draft.waitForExistence(timeout: 6) {
                print("PHOTO-SHEET first tap missed: photo=\(photo.frame) sheet=\(dock.frame)")
                photo.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
            }
            XCTAssertTrue(draft.waitForExistence(timeout: 8),
                          "A tapped photo must appear in the draft without a confirm step")
            capture("inline-photo-picked", app: app)
        }
        // The card is a sheet, as in Messages: swiping up grows it to full
        // height and swiping down returns it to the compact card.
        let compactHeight = dock.frame.height
        let origin = app.coordinate(withNormalizedOffset: .zero)
        func drag(fromY y: CGFloat, by dy: CGFloat) {
            origin.withOffset(CGVector(dx: dock.frame.midX, dy: y))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: dock.frame.midX, dy: y + dy)),
                       withVelocity: .slow, thenHoldForDuration: 0.2)
        }
        // Does a swipe on the grid itself resize the sheet? The grid is a
        // remote view, so this is reported rather than required.
        drag(fromY: dock.frame.midY + 40, by: -200)
        sleep(1)
        let afterGridSwipe = dock.frame.height
        print("PHOTO-SHEET grid swipe up: compact=\(compactHeight) after=\(afterGridSwipe)")
        if afterGridSwipe < compactHeight + 80 {
            // The grabber at the top edge always resizes the sheet.
            drag(fromY: dock.frame.minY + 6, by: -300)
            sleep(1)
        }
        let expandedHeight = dock.frame.height
        print("PHOTO-SHEET expanded: height=\(expandedHeight) top=\(dock.frame.minY)")
        XCTAssertGreaterThan(expandedHeight, compactHeight + 80,
                             "The card grows to full height (compact \(compactHeight), now \(expandedHeight))")
        // With a photo picked, full height shows Messages' done check.
        let done = app.buttons["photo-done"]
        if picked {
            XCTAssertTrue(done.waitForExistence(timeout: 3), "The done check appears once a photo is picked")
            print("PHOTO-SHEET done: frame=\(done.frame) sheet=\(dock.frame)")
        }
        capture("expanded-inline-photo-grid", app: app)
        drag(fromY: dock.frame.minY + 6, by: expandedHeight - compactHeight)
        sleep(1)
        print("PHOTO-SHEET collapsed: exists=\(dock.exists) height=\(dock.frame.height)")
        XCTAssertTrue(dock.exists, "Swiping down from full height returns to the card")
        XCTAssertEqual(dock.frame.height, compactHeight, accuracy: 4)
        XCTAssertFalse(done.exists, "The compact card is the bare grid")
        capture("photo-sheet-collapsed", app: app)
        if picked {
            // Done closes the picker and keeps the photo in the draft.
            drag(fromY: dock.frame.minY + 6, by: -300)
            XCTAssertTrue(done.waitForExistence(timeout: 3))
            done.tap()
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: dock)
            waitForExpectations(timeout: 4)
            XCTAssertTrue(app.descendants(matching: .any)["draft-attachments"].exists)
            app.buttons["chat-add-menu"].tap(); menuItem("chat-attach-photos", "写真", app).tap()
            XCTAssertTrue(dock.waitForExistence(timeout: 5))
        }
        // Like the keyboard it replaces, the panel closes when the field is tapped.
        app.textViews["chat-input"].tap()
        expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: dock)
        waitForExpectations(timeout: 4)
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
        // Checked last so a miss still leaves every screenshot above.
        XCTAssertEqual(gap, 21, accuracy: 3, "The card keeps Messages' gap below the field")
    }

    @MainActor func testHistorySettingsAndDeveloperVisibilityPersist() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--reset-settings"]; app.launch()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["history-settings"].tap()
        let toggle = app.switches["developer-settings-toggle"]
        // Hidden until revealed (three-finger swipes at the bottom; the test
        // build reveals it with a launch argument).
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 4))
        XCTAssertFalse(toggle.exists)
        app.terminate(); app.launchArguments = ["--developer-unlocked"]; app.launch()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap(); app.buttons["history-settings"].tap()
        revealModelControl(toggle, app: app)
        XCTAssertEqual(toggle.value as? String, "0")
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists)
        XCTAssertFalse(app.staticTexts["推論の診断"].exists)
        // Memory release is a developer-only item.
        XCTAssertFalse(app.buttons["AIのメモリを解放する"].exists)
        XCTAssertFalse(app.staticTexts["Claudeについて"].exists)
        capture("daily-settings-developer-off", app: app)
        let switchTop = toggle.frame.minY
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        XCTAssertTrue(app.staticTexts["推論の診断"].waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR developer switch top before \(switchTop) after on \(toggle.frame.minY)")
        XCTAssertEqual(toggle.frame.minY, switchTop, accuracy: 1, "What the switch adds appears below it")
        capture("history-developer-on", app: app)
        XCTAssertFalse(app.descendants(matching: .any)["update-source-card"].exists, "The AltStore update card is gone")
        XCTAssertTrue(app.buttons["AIのメモリを解放する"].exists)
        XCTAssertTrue(app.buttons["model-use-qwen3-06b"].exists, "Developer settings make Qwen usable")
        capture("developer-settings-visible", app: app)
        app.buttons["完了"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 1, "Opening settings must not create a chat")
        app.terminate(); app.launchArguments = []; app.launch()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 10))
        app.buttons["会話一覧を開く"].tap(); app.buttons["history-settings"].tap()
        revealModelControl(toggle, app: app)
        XCTAssertEqual(toggle.value as? String, "1")
        let onTop = toggle.frame.minY
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "0")
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertFalse(app.staticTexts["推論の診断"].exists)
        print("HISTORY-SIDEBAR developer switch top before \(onTop) after off \(toggle.frame.minY)")
        XCTAssertTrue(toggle.isHittable)
        // Turned off, the list ends at its last line: no empty page below it
        // (1.0.53 kept the taller list's height).
        let list = app.scrollViews["model-list"], footer = app.descendants(matching: .any)["model-list-footer"]
        for _ in 0..<4 { list.swipeUp() }
        Thread.sleep(forTimeInterval: 1)
        print("HISTORY-SIDEBAR model list end: footer=\(footer.frame) list=\(list.frame)")
        capture("history-developer-off-end", app: app)
        XCTAssertTrue(footer.isHittable, "The list's last line is on screen at its end")
        XCTAssertLessThan(list.frame.maxY - footer.frame.maxY, 140, "No blank space below the last line")
        app.buttons["完了"].tap(); app.buttons["history-settings"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertFalse(app.segmentedControls["execution-backend"].exists)
        XCTAssertFalse(app.textFields["setting-TopK"].exists)
        XCTAssertEqual(app.textFields["setting-Max Tokens"].value as? String, "4096")
        capture("basic-generation-settings", app: app)
    }

    /// Settings lists the open-source licenses and shows each text. The math
    /// fonts' licenses come from SwiftMath's own bundle; the packages'
    /// LICENSE files are added by the device build only (build-ios.sh).
    @MainActor func testOpenSourceLicensesShowTheirTexts() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        let link = app.buttons["model-licenses"]
        revealModelControl(link, app: app)
        link.tap()
        XCTAssertTrue(app.navigationBars["オープンソースライセンス"].waitForExistence(timeout: 3))
        capture("markdown-licenses", app: app)
        app.buttons["license-GUST-FONT-LICENSE.txt"].tap()
        let text = app.descendants(matching: .any)["license-text"]
        expectation(for: NSPredicate(format: "label CONTAINS %@", "GUST Font License"), evaluatedWith: text)
        waitForExpectations(timeout: 3)
        capture("markdown-license-text", app: app)
    }

    @MainActor private func revealModelControl(_ control: XCUIElement, app: XCUIApplication) {
        for _ in 0..<15 { if control.exists && control.isHittable { break }; app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(control.isHittable)
    }

    @MainActor func testModelDeleteAsksFirstAndOffersDownloadAgain() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        let delete = app.buttons["model-delete-gemma-4-e2b"]
        revealModelControl(delete, app: app)
        capture("history-model-delete-button", app: app)
        delete.tap()
        let confirm = app.alerts.buttons["削除"]
        XCTAssertTrue(confirm.waitForExistence(timeout: 3))
        capture("history-model-delete-alert", app: app)
        confirm.tap()
        XCTAssertTrue(app.buttons["model-download-gemma-4-e2b"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["model-delete-gemma-4-e2b"].exists)
        XCTAssertTrue(app.buttons["model-delete-gemma-4-e4b"].exists, "Other models keep theirs")
        capture("history-model-deleted", app: app)
    }

    /// The download's Live Activity from the Home Screen: the app's icon
    /// on the left of the Dynamic Island, the percentage on the right.
    @MainActor func testDownloadLiveActivityInDynamicIsland() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--download-activity"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-compact", height: 140)
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = "history-download-home"; screen.lifetime = .keepAlways; add(screen)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-expanded", height: 260)
        app.activate()
    }

    /// A download the person starts also has iOS's continued-processing
    /// task, and iOS adds its own display for it: how the two share the
    /// island, in the app and from the Home Screen.
    @MainActor func testDownloadLiveActivityWithContinuedTask() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--download-activity", "--download-activity-continued"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        let continued = app.staticTexts.matching(identifier: "download-continued-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        Thread.sleep(forTimeInterval: 1.5)
        print("HISTORY-SIDEBAR \(status.label) \(continued.label)")
        XCTAssertEqual(status.label, "live-activity: started")
        captureScreenTop("history-island-both-app", height: 140)
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-both", height: 140)
        let screen = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screen.name = "history-island-both-home"; screen.lifetime = .keepAlways; add(screen)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-both-expanded", height: 260)
        app.activate()
        print("HISTORY-SIDEBAR after \(continued.label)")
    }

    /// Two models at once share one activity: one model on each side of the
    /// island, and a row for each when it is pressed.
    @MainActor func testTwoDownloadLiveActivitiesInDynamicIsland() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--download-activity", "--download-activity-two"]; app.launch()
        let status = app.staticTexts.matching(identifier: "download-activity-status").firstMatch
        XCTAssertTrue(status.waitForExistence(timeout: 10))
        let started = NSPredicate(format: "label != %@", "live-activity: starting")
        _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: started, object: status)], timeout: 5)
        print("HISTORY-SIDEBAR \(status.label)")
        XCTAssertEqual(status.label, "live-activity: started 2")
        XCUIDevice.shared.press(.home)
        Thread.sleep(forTimeInterval: 3)
        captureScreenTop("history-island-two", height: 140)
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        springboard.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.025)).press(forDuration: 1.2)
        Thread.sleep(forTimeInterval: 1)
        captureScreenTop("history-island-two-expanded", height: 260)
        app.activate()
    }

    /// Pulling past the end of a conversation, as in ChatGPT: a ring fills,
    /// turns into the new chat button, and letting go opens a new chat.
    @MainActor func testPullPastEndOpensNewChat() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--pull-snapshot"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let first = app.staticTexts["画面の動きを確認"]
        XCTAssertTrue(first.waitForExistence(timeout: 3))
        sleep(1)
        // A short pull springs back and keeps the conversation.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.6))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)),
                   withVelocity: .slow, thenHoldForDuration: 0.3)
        Thread.sleep(forTimeInterval: 1.2)
        XCTAssertTrue(first.exists, "A short pull keeps the conversation")
        XCTAssertFalse(app.staticTexts["メッセージを送って会話を始めましょう"].exists)
        // A long pull fills the ring; letting go there opens a new chat.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.72))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.22)),
                   withVelocity: .slow, thenHoldForDuration: 0.8)
        let snapshots = app.descendants(matching: .any)["pull-snapshots"]
        XCTAssertTrue(snapshots.waitForExistence(timeout: 3))
        print("HISTORY-SIDEBAR pull: \(snapshots.label)")
        capture("history-pull-snapshots", app: app)
        let snapshotCount = snapshots.label
        snapshots.tap()
        XCTAssertTrue(app.staticTexts["メッセージを送って会話を始めましょう"].waitForExistence(timeout: 3))
        XCTAssertFalse(first.exists, "The pull opened a new, empty chat")
        capture("history-pull-new-chat", app: app)
        XCTAssertEqual(snapshotCount, "pull snapshots 2", "The ring half full, then the button")
    }

    @MainActor private func captureScreenTop(_ name: String, height: CGFloat) {
        let image = XCUIScreen.main.screenshot().image
        guard let full = image.cgImage,
              let top = full.cropping(to: CGRect(x: 0, y: 0, width: CGFloat(full.width),
                                                 height: min(CGFloat(full.height), height * image.scale))) else { return }
        let attachment = XCTAttachment(image: UIImage(cgImage: top, scale: image.scale, orientation: .up))
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    /// E4B (the default model) takes photos at 70 image tokens: the photo
    /// item opens the inline picker as E2B's does, and the draft stays.
    @MainActor func testE4BPhotosOpenThePickerAndKeepTheDraft() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        input.tap(); input.typeText("Keep my draft")
        app.buttons["chat-add-menu"].tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 3))
        XCTAssertTrue(menuItem("chat-attach-files", "ファイル", app).exists)
        XCTAssertTrue(menuItem("chat-attach-camera", "カメラ", app).exists)
        capture("e4b-attachments-available", app: app)
        photos.tap()
        // Photos opens the inline picker, not the locked-item guidance.
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "photo-dock").firstMatch
            .waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["E2Bで新しい会話を開く"].exists)
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].exists, "Photos must not switch models")
        XCTAssertEqual(input.value as? String, "Keep my draft")
        capture("e4b-photo-dock", app: app)
    }

    @MainActor func testSwitchFromE2BWithDraftAttachmentCannotSendToE4B() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--e2b", "--attachment-fixtures"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-image", app: app)
        XCTAssertTrue(app.buttons["添付を外す: sample-image.png"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        let e4b = app.buttons["model-use-gemma-4-e4b"]
        XCTAssertTrue(e4b.waitForExistence(timeout: 4)); e4b.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.buttons["添付を外す: sample-image.png"].exists)
        XCTAssertFalse(app.buttons["送信する"].isEnabled)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Text still works")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Text still works"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 6))
        capture("e4b-text-after-attachment-switch", app: app)
    }

    @MainActor func testLargeTypeReducedMotionAttachmentMenuRemainsUsable() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--large-type", "--reduce-motion", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        let photos = menuItem("chat-attach-photos", "写真", app)
        XCTAssertTrue(photos.waitForExistence(timeout: 4)); XCTAssertTrue(photos.isHittable)
        // The system menu sets its rows' height: an unlocked one-line row was
        // 42pt in the simulator (run 39441056590); a locked row's 調整中
        // subtitle makes it taller. The row must lie whole on the screen.
        XCTAssertTrue(app.windows.firstMatch.frame.contains(photos.frame), "\(photos.frame)")
        capture("large-type-dark-attachment-menu", app: app)
        // The camera is still locked: tapping it explains what works.
        let camera = menuItem("chat-attach-camera", "カメラ", app)
        XCTAssertTrue(camera.isHittable); camera.tap()
        let guide = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "カメラ・動画は調整中")).firstMatch
        XCTAssertTrue(guide.waitForExistence(timeout: 4))
        capture("large-type-attachment-guide", app: app)
        // Confirmation dialogs can adapt to a popover. UIKit omits the
        // cancel button there and exposes a native dismiss region instead.
        if app.buttons["閉じる"].exists { app.buttons["閉じる"].tap() }
        else if app.buttons["Cancel"].exists { app.buttons["Cancel"].tap() }
        else {
            let dismiss = app.otherElements["PopoverDismissRegion"]
            XCTAssertTrue(dismiss.waitForExistence(timeout: 3)); dismiss.tap()
        }
        XCTAssertFalse(guide.exists)
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].exists, "Dismissing must not switch models")
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
    }

    /// E4B's 高速・深く replaces its image-token picker in the developer
    /// configuration, and a saved 深く survives a relaunch.
    @MainActor func testE4BPhotoDetailIsSavedWithTheModel() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--reset-settings", "--developer-unlocked"]; app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 4))
        let toggle = app.switches["developer-settings-toggle"]
        revealModelControl(toggle, app: app)
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        app.navigationBars["モデルと設定"].buttons["完了"].tap()
        openConfiguration(app)
        let detail = app.buttons["photo-detail"]
        func shown() -> String { "\(detail.label) \(detail.value as? String ?? "")" }
        revealConfigurationControl(detail, app: app)
        XCTAssertFalse(app.buttons["visual-token-budget"].exists, "The photo detail sets E4B's image tokens")
        XCTAssertTrue(shown().contains("高速"), shown())
        detail.tap()
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "深く")).firstMatch
        XCTAssertTrue(deep.waitForExistence(timeout: 3)); deep.tap()
        XCTAssertTrue(shown().contains("深く"), shown())
        capture("e4b-photo-detail-deep", app: app)
        app.buttons["configuration-save"].tap()
        app.terminate(); app.launchArguments = []; app.launch()
        openConfiguration(app)
        revealConfigurationControl(detail, app: app)
        XCTAssertTrue(shown().contains("深く"), "A saved 深く must survive a relaunch: \(shown())")
    }

    @MainActor func testFirstLaunchModelChoiceAndCompletionPersist() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--startup", "--reset-startup"]
        app.launch()
        XCTAssertTrue(app.buttons["startup-skip"].waitForExistence(timeout: 10))
        capture("first-launch-models", app: app)
        // Only Gemma is offered at first launch; Qwen is developer-only.
        XCTAssertFalse(app.buttons["startup-model-qwen3-06b"].exists)
        let choice = app.buttons["startup-model-gemma-4-e2b"]
        let list = app.scrollViews["startup-model-list"]
        for _ in 0..<5 {
            if choice.exists && choice.isHittable && choice.frame.minY >= list.frame.minY
                && choice.frame.maxY < app.buttons["startup-continue"].frame.minY { break }
            list.swipeUp()
        }
        XCTAssertTrue(choice.isHittable); choice.tap()
        capture("first-launch-qwen-gauges", app: app)
        XCTAssertTrue(app.buttons["startup-continue"].isEnabled)
        app.buttons["startup-continue"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 5))
        app.terminate(); app.launchArguments = ["--startup"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        XCTAssertFalse(app.buttons["startup-skip"].exists)
    }

    @MainActor func testShortConversationAndGrowingReplyStayStableWithKeyboard() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = Self.keepOpen + ["--growing-reply", "--dark"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        let firstY = modelName.frame.minY
        input.typeText("Short send")
        XCTAssertEqual(modelName.frame.minY, firstY, accuracy: 3, "Typing in a short chat must not reposition its content")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Short send"].waitForExistence(timeout: 4))
        XCTAssertEqual(input.value as? String, "")
        XCTAssertFalse(app.keyboards.firstMatch.exists, "Successful send must close the keyboard")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
        let reply = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "返信の確認12：")).firstMatch
        XCTAssertTrue(reply.exists)
        // E4B no longer shows an attachment note above the field.
        XCTAssertFalse(app.buttons["chat-switch-e2b"].exists)
        func readingBottom() -> CGFloat { input.frame.minY }
        XCTAssertLessThanOrEqual(reply.frame.maxY, readingBottom())
        capture("short-send-long-reply-keyboard", app: app)
        let reading = app.scrollViews["chat-conversation"]
        // The scroll view extends behind the bars and keyboard. Its default
        // swipe coordinates can hit those controls instead of the text area.
        func swipeReading(up: Bool) {
            let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
            let bottom = min(reading.frame.maxY, readingBottom() - 20)
            XCTAssertGreaterThan(bottom - top, 80)
            let origin = app.coordinate(withNormalizedOffset: .zero)
            let x = reading.frame.midX
            let start = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.8 : 0.2)))
            let end = origin.withOffset(CGVector(dx: x, dy: top + (bottom - top) * (up ? 0.2 : 0.8)))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        swipeReading(up: false); swipeReading(up: false)
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
        for _ in 0..<8 {
            if reply.exists && reply.frame.maxY <= readingBottom()
                && reply.frame.maxY > readingBottom() - 32 { break }
            swipeReading(up: true)
        }
        let observations: [String: Any] = ["replyBottom": reply.frame.maxY,
            "inputTop": input.frame.minY,
            "readingBottom": readingBottom(), "jumpVisible": app.buttons["chat-jump-latest"].exists]
        if let bytes = try? JSONSerialization.data(withJSONObject: observations, options: .sortedKeys) {
            let evidence = XCTAttachment(data: bytes, uniformTypeIdentifier: "public.json")
            evidence.name = "manual-bottom-and-composer-geometry"; evidence.lifetime = .keepAlways; add(evidence)
        }
        capture("manual-return-bottom-geometry", app: app)
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        print("SCROLL-DEBUG after manual return:", debug.label)
        XCTAssertLessThanOrEqual(reply.frame.maxY, readingBottom())
        XCTAssertGreaterThan(reply.frame.maxY, readingBottom() - 32, "Manual scrolling must reach the reply's end above the actual composer")
        let hidden = NSPredicate(format: "exists == false")
        let result = XCTWaiter().wait(for: [XCTNSPredicateExpectation(predicate: hidden, object: app.buttons["chat-jump-latest"])], timeout: 4)
        XCTAssertEqual(result, .completed, "Jump control stays after a manual return. \(debug.label) replyBottom=\(reply.frame.maxY) readingBottom=\(readingBottom())")
        capture("manual-return-no-jump", app: app)
    }

    @MainActor func testHistorySidebarSlide() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--history-fixture"]; app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        let sidebar = historySidebar(app)
        if sidebar.exists { print("HISTORY-SIDEBAR exposed while closed: \(sidebar.debugDescription.prefix(1500))") }
        XCTAssertFalse(sidebar.exists)
        let closed = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)
        // The sidebar's controls line up with the conversation's own.
        let headerMidY = open.frame.midY, plusMidY = app.buttons["chat-add-menu"].frame.midY

        // A swipe right on the conversation slides it aside, as ChatGPT does.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.45))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.46)))
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        print("HISTORY-SIDEBAR open: sidebar=\(sidebar.frame) app=\(app.frame)")
        print("HISTORY-SIDEBAR conversation exposed while open: header=\(open.exists) reading=\(app.scrollViews["chat-conversation"].exists) input=\(app.textViews["chat-input"].exists)")
        XCTAssertEqual(sidebar.frame.minX, 0, accuracy: 1)
        XCTAssertEqual(sidebar.frame.width, app.frame.width - 92, accuracy: 1, "92pt of the conversation stays in view")
        let compose = app.buttons["history-compose"], settings = app.buttons["history-settings"]
        print("HISTORY-SIDEBAR buttons: compose=\(compose.frame) settings=\(settings.frame) search=\(app.buttons["history-search"].frame)")
        XCTAssertTrue(compose.isHittable)
        XCTAssertEqual(compose.frame.height, 48, accuracy: 1)
        XCTAssertLessThan(compose.frame.minX, sidebar.frame.width * 0.2, "New chat sits at the bottom leading corner")
        XCTAssertGreaterThan(compose.frame.minY, app.frame.height * 0.85)
        XCTAssertGreaterThan(settings.frame.minX, compose.frame.maxX)
        XCTAssertLessThanOrEqual(settings.frame.maxX, sidebar.frame.maxX)
        let search = app.buttons["history-search"]
        XCTAssertEqual(compose.frame.minX - sidebar.frame.minX, 24, accuracy: 1)
        XCTAssertEqual(sidebar.frame.maxX - settings.frame.maxX, 24, accuracy: 1)
        XCTAssertEqual(search.frame.maxX, settings.frame.maxX, accuracy: 1)
        XCTAssertEqual(search.frame.midY, headerMidY, accuracy: 1, "Search sits level with the conversation's header button")
        print("HISTORY-SIDEBAR levels: header=\(headerMidY) search=\(search.frame.midY) plus=\(plusMidY) compose=\(compose.frame.midY)")
        // The simulator's plus frame can be 54pt tall (see the menu test),
        // so its center is only a rough reference here. The two-row panel
        // (Phase UI-1) puts the plus about 8pt above the new-chat button.
        XCTAssertEqual(compose.frame.midY, plusMidY, accuracy: 10, "New chat sits level with the conversation's plus button")
        XCTAssertEqual(settings.frame.midY, compose.frame.midY, accuracy: 1)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 7)
        capture("history-open", app: app)

        // A long press lifts just the row's rounded shape and offers delete.
        app.buttons["会話を開く: 夕飯のレシピ"].press(forDuration: 1.2)
        let deleteItem = app.buttons["削除"]
        XCTAssertTrue(deleteItem.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        print("HISTORY-SIDEBAR row menu: delete=\(deleteItem.frame)")
        capture("history-row-menu", app: app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.3, dy: 0.8)).tap()
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: deleteItem)], timeout: 3)
        XCTAssertTrue(sidebar.exists)

        // Tapping the strip of conversation slides it back. The strip is
        // the visible part of a screen-wide element, so tap by coordinate.
        XCTAssertTrue(app.descendants(matching: .any)["history-close"].exists)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        wait(for: [closed], timeout: 3)

        // The header button opens it too; frames taken during the slide.
        open.tap()
        for index in 0..<3 { capture("history-motion-\(index)", app: app) }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)

        // Search filters by title and message text.
        app.buttons["history-search"].tap()
        let field = app.textFields["history-search-field"]
        // Frames while the field grows out of the search circle.
        for index in 0..<3 { capture("history-search-motion-\(index)", app: app) }
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        sleep(1)
        let close = app.buttons["history-search-close"]
        print("HISTORY-SIDEBAR search: field=\(field.frame) close=\(close.frame)")
        XCTAssertEqual(close.frame.maxX, settings.frame.maxX, accuracy: 1, "The search circle stays put as the close button")
        XCTAssertEqual(field.frame.midY, close.frame.midY, accuracy: 1)
        field.tap(); field.typeText("カメムシ")
        XCTAssertTrue(app.buttons["会話を開く: カメムシ対策"].waitForExistence(timeout: 3))
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 1)
        capture("history-search", app: app)
        app.buttons["history-search-close"].tap()
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "会話を開く:")).count, 7)

        // A swipe left closes it.
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.7, dy: 0.5))
            .press(forDuration: 0.1, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.1, dy: 0.51)))
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: sidebar)], timeout: 3)

        // Opening an older conversation slides back to it.
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        app.buttons["会話を開く: 夕飯のレシピ"].tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["夕飯のレシピ"].waitForExistence(timeout: 3))

        // New chat: an empty conversation, and the sidebar closes.
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        compose.tap()
        XCTAssertTrue(open.waitForExistence(timeout: 3))
        XCTAssertFalse(app.staticTexts["夕飯のレシピ"].exists)

        app.terminate(); app.launchArguments = ["--history-fixture", "--dark"]; app.launch()
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        sleep(1)
        open.tap()
        XCTAssertTrue(sidebar.waitForExistence(timeout: 3))
        sleep(1)
        capture("history-dark", app: app)
    }

    @MainActor func testMenuSendAndInteractiveBack() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--gesture-diagnostics"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertEqual(menu.frame.height, 44, accuracy: 1)
        XCTAssertEqual(menu.frame.width, 44, accuracy: 1)
        let controlHeight = menu.frame.height
        menu.tap()
        capture("after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("expanded-menu", app: app)
        app.buttons["新しい会話"].tap()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 3))
        input.tap()
        input.typeText("Animation check")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Animation check"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 5))
        capture("sent-message-keyboard", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["会話を開く: Animation check"].tap()
        XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
        // A swipe right on the conversation slides the history out.
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.45))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.46))
        start.press(forDuration: 0.1, thenDragTo: end)
        capture("after-history-swipe", app: app)
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        capture("conversation-list", app: app)
        XCTAssertEqual(app.descendants(matching: .any).matching(identifier: "history-sidebar").count, 1)
        for _ in 0..<2 {
            app.buttons["会話を開く: Animation check"].tap()
            XCTAssertTrue(app.buttons["会話一覧を開く"].waitForExistence(timeout: 3))
            app.buttons["会話一覧を開く"].tap()
            XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
            XCTAssertEqual(app.descendants(matching: .any).matching(identifier: "history-sidebar").count, 1)
        }
        XCTAssertGreaterThanOrEqual(app.buttons["history-compose"].frame.height, controlHeight - 1)
    }

    @MainActor func testLongConversationJumpControlAndHeader() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = Self.keepOpen + ["--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        capture("long-chat-latest", app: app)
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        XCTAssertTrue(jump.waitForExistence(timeout: 3))
        XCTAssertEqual(jump.frame.height, 44, accuracy: 1)
        XCTAssertLessThan(jump.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
        XCTAssertEqual(jump.frame.midX, app.windows.firstMatch.frame.midX, accuracy: 1, "Jump control is centered")
        XCTAssertFalse(app.buttons["chat-switch-e2b"].exists, "No attachment note above the field")
        XCTAssertLessThan(jump.frame.maxY, app.textViews["chat-input"].frame.minY,
                          "Jump control sits just above the field")
        capture("jump-from-composer", app: app)
        jump.tap()
        let disappeared = NSPredicate(format: "exists == false")
        expectation(for: disappeared, evaluatedWith: jump)
        waitForExpectations(timeout: 4)
        capture("jump-returned-to-latest", app: app)
        // Selectable reply text is reading content, not a tappable control.
        // Check its actual viewport bounds rather than XCTest's hit point.
        let latest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(latest.exists)
        XCTAssertGreaterThan(latest.frame.width, 0)
        XCTAssertGreaterThan(latest.frame.height, 0)
        XCTAssertGreaterThanOrEqual(latest.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(latest.frame.maxY, app.buttons["chat-add-menu"].frame.minY)
    }

    @MainActor func testStreamingReplyRemainsReadableAndFinishes() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--slow-reply"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Text animation")
        app.buttons["送信する"].tap()
        let partial = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "新しい文字が")).firstMatch
        XCTAssertTrue(partial.waitForExistence(timeout: 5))
        // Quick shots of the reply's first lines while its characters flow
        // in, to review the fade, rise and stagger (markdown-reveal-strip).
        revealStrip("markdown-reveal-strip", app: app, around: partial.frame)
        capture("reply-revealing", app: app)
        let finished = app.staticTexts["新しい文字がぼやけた状態から少しずつくっきり表示されます。\nすでに読んだ文章は鮮明なままです。日本語と絵文字もそのまま表示します。😊"]
        XCTAssertTrue(finished.waitForExistence(timeout: 8))
        expectation(for: NSPredicate(format: "exists == false"),
                    evaluatedWith: app.buttons["回答を停止する"])
        waitForExpectations(timeout: 3)
        capture("reply-fully-clear", app: app)
        XCTAssertTrue(app.staticTexts["Text animation"].exists)
    }

    /// A paragraph's last characters, still in the rainbow when the next
    /// paragraph starts, keep fading to their own colour instead of turning
    /// clear at once: every chunk of a streamed reply keeps its reveal. The
    /// old behaviour (only the last chunk revealing) runs second, for
    /// comparison; only the first run is asserted.
    @MainActor func testParagraphBreakKeepsRainbowFlowing() {
        continueAfterFailure = false
        guard let kept = paragraphBreakReveal("markdown-reveal-paragraph", arguments: ["--paragraph-stream"]) else {
            return XCTFail("The paragraph break was not captured")
        }
        let old = paragraphBreakReveal("markdown-reveal-paragraph-old",
                                       arguments: ["--paragraph-stream", "--probe-last-chunk-live"])
        print(String(format: "MARKDOWN-NOTE paragraph break: rainbow in the first paragraph %ld -> %ld pt² (fixed), ",
                     kept.before, kept.at)
              + (old.map { String(format: "%ld -> %ld pt² (old)", $0.before, $0.at) } ?? "old run not captured"))
        if kept.gap <= 0.45 {
            XCTAssertGreaterThanOrEqual(kept.at, 30, "The first paragraph's rainbow vanished when the second began")
        }
    }

    /// Streams two paragraphs and screenshots them as quick as they come;
    /// returns the coloured area of the first paragraph in the shot before
    /// and in the first shot where the second paragraph shows its rainbow,
    /// and the time between those shots. (Grey below the reply is the
    /// preview's status line, so only colour marks the second paragraph.)
    @MainActor private func paragraphBreakReveal(_ name: String,
                                                 arguments: [String]) -> (before: Int, at: Int, gap: Double)? {
        let app = XCUIApplication()
        app.launchArguments = arguments
        app.launch()
        defer { app.terminate() }
        // A new chat, where the rows stay still while the reply streams.
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("Paragraphs")
        app.buttons["送信する"].tap()
        let first = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "最初の段落では")).firstMatch
        guard first.waitForExistence(timeout: 5) else { return nil }
        let screen = app.frame
        let left = first.frame.minX
        let firstTop = first.frame.minY
        let region = CGRect(x: max(0, left - 4), y: max(0, first.frame.minY - 6),
                            width: screen.width - 2 * max(0, left - 4), height: 160)
        var shots: [(t: Double, area: ScreenArea, crop: UIImage)] = []
        let start = Date()
        while Date().timeIntervalSince(start) < 4.5, shots.count < 40 {
            let t = Date().timeIntervalSince(start)
            guard let image = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(image, region, screenWidth: screen.width) else { continue }
            let scale = CGFloat(image.width) / screen.width
            let pixels = CGRect(x: region.minX * scale, y: region.minY * scale,
                                width: region.width * scale, height: region.height * scale).integral
            guard let cropped = image.cropping(to: pixels) else { continue }
            // A copy at two pixels a point, so the full screenshot is let go.
            let format = UIGraphicsImageRendererFormat()
            format.scale = 2
            let crop = UIGraphicsImageRenderer(size: region.size, format: format).image { _ in
                UIImage(cgImage: cropped).draw(in: CGRect(origin: .zero, size: region.size))
            }
            shots.append((t, area, crop))
        }
        let second = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "次の段落が")).firstMatch
        guard second.waitForExistence(timeout: 8) else { return nil }
        let top = second.frame.minY
        print(String(format: "MARKDOWN-NOTE %@ first paragraph top %.1f then %.1f, second at %.1f, region %.1f-%.1f",
                     name, firstTop, first.frame.minY, top, region.minY, region.maxY))
        guard top > region.minY + 12, top < region.maxY - 8 else { return nil }
        // From the paragraph's own top, clear of the sent bubble's blue above.
        let above = CGRect(x: region.minX, y: firstTop, width: region.width, height: top - 2 - firstTop)
        let below = CGRect(x: region.minX, y: top, width: region.width, height: region.maxY - top)
        let readings = shots.map { shot in
            (t: shot.t, above: shot.area.marks(in: above, background: 255).colour,
             below: shot.area.marks(in: below, background: 255))
        }
        print("MARKDOWN-NOTE \(name) " + readings.map {
            String(format: "%.2fs %ld|%ld+%ld", $0.t, $0.above, $0.below.colour, $0.below.ink)
        }.joined(separator: " "))
        guard let k = readings.firstIndex(where: { $0.below.colour >= 20 }), k > 0 else { return nil }
        // The shots around the break on one sheet.
        let picked = Array(shots[max(0, k - 4)..<min(shots.count, k + 6)])
        let label: CGFloat = 16
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        let sheetSize = CGSize(width: region.width, height: (region.height + label) * CGFloat(picked.count))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, shot) in picked.enumerated() {
                let y = CGFloat(index) * (region.height + label)
                shot.crop.draw(in: CGRect(x: 0, y: y + label, width: region.width, height: region.height))
                (String(format: "%.0f ms", shot.t * 1000) as NSString)
                    .draw(at: CGPoint(x: 4, y: y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 12), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        return (readings[k - 1].above, readings[k].above, readings[k].t - readings[k - 1].t)
    }

    @MainActor func testDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = Self.keepOpen + ["--dark", "--reduce-motion", "--long-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        capture("dark-after-plus-tap", app: app)
        XCTAssertTrue(app.buttons["モデルと設定"].waitForExistence(timeout: 3))
        capture("dark-reduced-motion-menu", app: app)
        dismissMenu(app.buttons["モデルと設定"], app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        reading.swipeDown()
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
        capture("dark-glass-scrolling", app: app)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap()
        input.typeText("Glass check")
        XCTAssertTrue(app.buttons["送信する"].isHittable)
        capture("dark-glass-keyboard", app: app)
    }

    @MainActor func testModelCatalogSwitchPreservesGemmaHistory() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 3))
        capture("model-catalog", app: app)
        XCTAssertFalse(app.buttons["model-use-qwen3-06b"].exists, "Qwen is hidden unless developer settings are on")
        let use = app.buttons["model-use-gemma-4-e2b"]
        for _ in 0..<8 {
            if use.isHittable { break }
            app.scrollViews["model-list"].swipeUp()
        }
        XCTAssertTrue(use.isHittable)
        capture("model-qwen-ready", app: app)
        use.tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4))
        XCTAssertFalse(app.staticTexts["画面の動きを確認"].exists)
        capture("qwen-new-chat", app: app)
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 3))
        app.buttons["会話を開く: 画面の動きを確認"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E4B"].waitForExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["画面の動きを確認"].exists)
        capture("gemma-history-preserved", app: app)
    }

    @MainActor func testTallReplyBubbleAndFeatheredChrome() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = Self.keepOpen + ["--tall-bubble"]
        app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["chat-model-settings"].isHittable)
        capture("tall-bubble-bottom", app: app)
        let reading = app.scrollViews["chat-conversation"]
        reading.swipeDown()
        capture("light-feathered-chrome", app: app)
        menu.tap()
        XCTAssertTrue(app.buttons["新しい会話"].waitForExistence(timeout: 3))
        capture("light-feathered-menu", app: app)
        dismissMenu(app.buttons["新しい会話"], app: app)
        let greeting = app.staticTexts["こんにちは"].firstMatch
        for _ in 0..<10 {
            if greeting.exists && greeting.frame.minY >= reading.frame.minY
                && greeting.frame.maxY < menu.frame.minY { break }
            reading.swipeDown()
        }
        XCTAssertTrue(greeting.exists)
        XCTAssertGreaterThan(greeting.frame.width, 0)
        XCTAssertLessThan(greeting.frame.width, reading.frame.width * 0.75)
        capture("short-bubble-shapes", app: app)
    }

    @MainActor func testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll() { sendFromOlderMessages([]) }

    /// Probe rounds 5-6 (df83ad6, 8175ec2): this test froze at the first
    /// swipe after the second send with and without the rows' transition,
    /// scroll spring and explicit ids, and with plain replies; an eager
    /// VStack passed. ChatView now lays out the latest messages eagerly.
    @MainActor func testProbeSendOlderBaseline() { sendFromOlderMessages([], probe: "baseline") }
    @MainActor func testProbeSendOlderPlainReplies() {
        sendFromOlderMessages(["--probe-plain-replies"], probe: "plain-replies")
    }

    /// 81 messages: the older 40 stay lazy rows above the eager block.
    @MainActor func testProbeLongerChatScrollsThroughLazyRows() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--long-chat", "--longer-chat"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Longer chat send")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["Longer chat send"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        let older = app.staticTexts["長い会話の確認 18"].firstMatch
        for _ in 0..<16 {
            if older.exists && older.isHittable { break }
            reading.swipeDown()
        }
        XCTAssertTrue(older.exists, "Scrolled into the lazy rows")
        XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 5))
        let ink = readingInk(app)
        print("PROBE longer-chat ink=\(ink)")
        XCTAssertGreaterThan(ink, Self.drawnInk, "The lazy rows must be drawn")
        capture("probe-longer-chat-older", app: app)
        app.buttons["chat-jump-latest"].tap()
        Thread.sleep(forTimeInterval: 1.5)
        XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
        XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
        capture("probe-longer-chat-latest", app: app)
        print("PROBE longer-chat passed")
    }

    @MainActor private func sendFromOlderMessages(_ flags: [String], probe: String? = nil) {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = XCUIApplication()
            app.launchArguments = Self.keepOpen + ["--long-chat"] + flags + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 3))
            XCTAssertGreaterThan(readingInk(app), Self.drawnInk, "Older messages must be drawn")
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap(); input.typeText("Send scroll regression\nSecond line\nThird line")
            let beforeHeight = input.frame.height
            app.buttons["送信する"].tap()
            let sent = app.staticTexts["Send scroll regression\nSecond line\nThird line"].firstMatch
            XCTAssertTrue(sent.waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["chat-jump-latest"].exists)
            XCTAssertLessThan(input.frame.height, beforeHeight)
            XCTAssertGreaterThanOrEqual(sent.frame.minY, reading.frame.minY)
            XCTAssertLessThanOrEqual(sent.frame.maxY, input.frame.minY)
            capture(dark ? "dark-send-scroll-settled" : "light-send-scroll-settled", app: app)
            input.tap(); input.typeText("Second send still works")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts["Second send still works"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            reading.swipeDown(); reading.swipeDown()
            XCTAssertTrue(app.buttons["chat-jump-latest"].waitForExistence(timeout: 4))
            XCTAssertTrue(app.buttons["chat-jump-latest"].isHittable)
            let ink = readingInk(app)
            print("PROBE send-older ink after second send dark=\(dark) ink=\(ink)")
            XCTAssertGreaterThan(ink, Self.drawnInk, "Older messages must be drawn after two sends")
            app.buttons["chat-jump-latest"].tap()
            capture(dark ? "dark-second-send-responsive" : "light-second-send-responsive", app: app)
            app.terminate()
        }
        if let probe { print("PROBE send-older \(probe) passed") }
    }

    @MainActor func testGenerationSettingsCancelSaveAndPromptPersist() {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--reset-settings"]
        app.launch()
        openConfiguration(app)
        let topK = app.textFields["setting-TopK"]
        revealConfigurationControl(topK, app: app)
        XCTAssertTrue(app.staticTexts["setting-help-TopK"].exists)
        XCTAssertEqual(topK.value as? String, "40")
        replace(topK, with: "12")
        app.buttons["キャンセル"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "40", "Cancel must discard draft settings")
        revealConfigurationControl(topK, app: app)
        replace(topK, with: "12")
        let cpu = app.segmentedControls["execution-backend"].buttons["CPU"]
        revealConfigurationControl(cpu, app: app)
        cpu.tap()
        XCTAssertTrue(cpu.isSelected, "CPU must be selected before saving")
        let visionCPU = app.segmentedControls["vision-execution-backend"].buttons["CPU"]
        let visionGPU = app.segmentedControls["vision-execution-backend"].buttons["GPU"]
        revealConfigurationControl(visionCPU, app: app)
        XCTAssertTrue(visionCPU.isSelected, "New vision settings default to CPU without changing the main backend")
        visionGPU.tap()
        XCTAssertTrue(visionGPU.isSelected)
        XCTAssertTrue(cpu.isSelected, "Vision GPU must not change the main CPU preference")
        let thinking = app.switches["enable-thinking"]
        let speculation = app.switches["enable-speculation"]
        revealConfigurationControl(thinking, app: app)
        XCTAssertTrue(thinking.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-thinking"].exists)
        // SwiftUI exposes the labeled row as the switch's accessibility frame.
        // Tap the visible switch at the trailing edge rather than its label.
        thinking.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertTrue(speculation.isEnabled)
        XCTAssertTrue(app.staticTexts["setting-help-enable-speculation"].exists)
        speculation.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(speculation.value as? String, "1")
        capture("model-configuration-controls", app: app)
        app.segmentedControls.buttons["システムプロンプト"].tap()
        let prompt = app.textViews["system-prompt-input"]
        XCTAssertTrue(prompt.waitForExistence(timeout: 3))
        replace(prompt, with: "Reply briefly in Japanese.")
        capture("custom-system-prompt", app: app)
        app.buttons["configuration-save"].tap()
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(topK.waitForExistence(timeout: 3))
        XCTAssertEqual(topK.value as? String, "12")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
        app.buttons["configuration-save"].tap()
        app.terminate()
        app.launchArguments = []
        app.launch()
        openConfiguration(app)
        XCTAssertEqual(topK.value as? String, "12", "Saved model configuration must survive relaunch")
        capture("saved-model-configuration", app: app)
        revealConfigurationControl(cpu, app: app)
        XCTAssertTrue(cpu.isSelected)
        revealConfigurationControl(visionGPU, app: app)
        XCTAssertTrue(visionGPU.isSelected, "The independently saved vision backend must survive relaunch")
        revealConfigurationControl(thinking, app: app)
        XCTAssertEqual(thinking.value as? String, "1")
        revealConfigurationControl(speculation, app: app)
        XCTAssertEqual(speculation.value as? String, "1")
        app.segmentedControls.buttons["システムプロンプト"].tap()
        XCTAssertEqual(prompt.value as? String, "Reply briefly in Japanese.")
    }

    /// E4B (the default model): documents are read into text on device and
    /// sent as text.
    @MainActor func testDocumentImportsPreviewAndArchiveRestore() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--attachment-fixtures"]
        app.launch()
        importFixture("sample-document", extension: "pdf", app: app)
        app.buttons["添付ファイルを開く: sample-document.pdf"].tap()
        XCTAssertTrue(app.navigationBars["sample-document.pdf"].waitForExistence(timeout: 4))
        capture("pdf-preview", app: app)
        app.buttons["完了"].tap()
        importFixture("sample-text", extension: "txt", app: app)
        importFixture("sample-data", extension: "json", app: app)
        capture("documents-ready", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: PDF fixture content・本文: 日本語の添付テスト😊・本文: {\"項目\": \"JSONの添付テスト\"}"].waitForExistence(timeout: 6))
        capture("documents-sent", app: app)
        app.terminate()
        app.launchArguments = ["--attachment-fixtures", "--restore-fixture-chat"]
        app.launch()
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-document.pdf"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["添付ファイルを開く: sample-data.json"].exists)
        capture("attachment-archive-restored", app: app)
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction("sample-unsupported", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 4))
        app.alerts.buttons["閉じる"].tap()
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        importFixture("sample-sjis", extension: "txt", app: app)
        importFixture("sample-utf16", extension: "txt", app: app)
        importFixture("sample-markdown", extension: "md", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: 日本語の添付確認・本文: 日本語UTF16😊・本文: Markdownの添付テスト"].waitForExistence(timeout: 6))
    }

    /// Qwen takes text only: the plus menu has no photo, camera, file or
    /// video item, only the conversation actions. A file that still reaches
    /// the chat (a test fixture) is refused with the guide, which offers E2B
    /// and keeps the draft when switching.
    @MainActor func testQwenOffersNoAttachments() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--qwen3", "--attachment-fixtures"]
        app.launch()
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        let newChat = menuItem("新しい会話", "新しい会話", app)
        XCTAssertTrue(newChat.waitForExistence(timeout: 3))
        XCTAssertTrue(menuItem("会話一覧", "会話一覧", app).exists)
        XCTAssertTrue(menuItem("モデルと設定", "モデルと設定", app).exists)
        for (id, title) in [("chat-attach-photos", "写真"), ("chat-attach-camera", "カメラ"),
                            ("chat-attach-files", "ファイル"), ("chat-attach-video", "動画")] {
            XCTAssertFalse(menuItem(id, title, app).exists, "\(title) must not be offered to Qwen")
        }
        capture("qwen-attachment-menu", app: app)
        chooseMenuAction("sample-text", app: app)
        XCTAssertTrue(app.buttons["E2Bで新しい会話を開く"].waitForExistence(timeout: 3))
        func guide(_ text: String) -> Bool {
            app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch.exists
        }
        XCTAssertTrue(guide("テキスト専用")); XCTAssertTrue(guide("写真やファイル"))
        capture("qwen-attachment-guidance", app: app)
        if app.buttons["閉じる"].exists { app.buttons["閉じる"].tap() }
        else if app.buttons["Cancel"].exists { app.buttons["Cancel"].tap() }
        else { app.otherElements["PopoverDismissRegion"].tap() }
        XCTAssertTrue(app.staticTexts["Qwen3 0.6B"].exists, "Dismissing must not switch models")
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        input.tap(); input.typeText("Text still works")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["Text still works"].waitForExistence(timeout: 4))
        capture("qwen-text-only-sent", app: app)
        // The menu's fixtures wait for the preview reply to finish.
        expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: app.buttons["回答を停止する"])
        waitForExpectations(timeout: 10)
        input.tap(); input.typeText("Keep my draft")
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-text", app: app)
        XCTAssertTrue(app.buttons["E2Bで新しい会話を開く"].waitForExistence(timeout: 3))
        app.buttons["E2Bで新しい会話を開く"].tap()
        XCTAssertTrue(app.staticTexts["Gemma 4 E2B"].waitForExistence(timeout: 4))
        XCTAssertEqual(input.value as? String, "Keep my draft")
        XCTAssertFalse(app.otherElements["draft-attachments"].exists)
    }

    @MainActor func testVideoImportSamplesThreeScenesAndDraftRemoval() throws {
        throw XCTSkip("Legacy unverified media formats are intentionally unavailable in1.0.19; covered by attachment policy and lock tests.")
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = ["--attachment-fixtures", "--dark"]
        app.launch()
        importFixture("sample-video", extension: "mp4", app: app)
        capture("video-draft", app: app)
        app.buttons["添付を外す: sample-video.mp4"].tap()
        XCTAssertFalse(app.buttons["添付ファイルを開く: sample-video.mp4"].exists)
        importFixture("sample-video", extension: "mp4", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 動画3場面"].waitForExistence(timeout: 6))
        XCTAssertTrue(app.staticTexts["動画は開始・中間・終了付近の3場面を読み込みます。音声は解析しません。"].exists)
        capture("video-three-scenes-sent", app: app)
    }

    @MainActor func testWordScannedPdfAndOversizeImports() throws {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--attachment-fixtures"]; app.launch()
        importFixture("sample-word", extension: "docx", app: app)
        importFixture("sample-scan", extension: "pdf", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["添付の読み込み確認: 本文: Word本文の確認😊・本文: SCAN PDF 123"].waitForExistence(timeout: 12))
        capture("word-and-scanned-pdf-read", app: app)
        app.buttons["chat-add-menu"].tap(); chooseMenuAction("sample-oversize", app: app)
        XCTAssertTrue(app.alerts["お知らせ"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["添付ファイルを開く: sample-oversize.docx"].exists)
    }

    @MainActor func testComposerClearsJapaneseEmojiAndDismissesKeyboardOnEverySend() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch(); XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        for text in ["日本語の送信😊", "次のメッセージ\n二行目"] {
            input.tap(); input.typeText(text)
            XCTAssertEqual(input.value as? String, text, "Typing must retain the committed Japanese text before send")
            app.buttons["送信する"].tap()
            XCTAssertTrue(app.staticTexts[text].waitForExistence(timeout: 4))
            expectation(for: NSPredicate(format: "exists == false"), evaluatedWith: app.keyboards.firstMatch)
            waitForExpectations(timeout: 4)
            XCTAssertEqual(input.value as? String, "")
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            XCTAssertFalse(app.buttons["送信する"].isEnabled)
        }
        capture("japanese-draft-cleared-keyboard-closed", app: app)
    }

    @MainActor func testAutomaticDeviceChoiceAndCloudBackupOptIn() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch(); XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap(); app.buttons["model-recommendations"].tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "model-auto-result").firstMatch.waitForExistence(timeout: 4))
        XCTAssertFalse(app.buttons["startup-continue"].exists, "Automatic choice must not open a manual picker")
        capture("automatic-device-model-selection", app: app)
        let toggle = app.switches["cloud-history-toggle"]
        let list = app.scrollViews["model-list"]
        for _ in 0..<14 { if toggle.isHittable { break }; list.swipeUp() }
        XCTAssertTrue(toggle.isHittable); XCTAssertEqual(toggle.value as? String, "0")
        toggle.tap()
        let cancel = app.buttons["Cancel"].firstMatch.exists ? app.buttons["Cancel"].firstMatch : app.buttons["キャンセル"].firstMatch
        XCTAssertTrue(cancel.waitForExistence(timeout: 5)); cancel.tap()
        XCTAssertEqual(toggle.value as? String, "0", "Canceling folder access must leave cloud storage off")
        capture("icloud-backup-optional", app: app)
    }

    @MainActor func testBackupWritesLatestSnapshotAndRestoresAttachments() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--cloud-fixture"]; app.launch()
        XCTAssertTrue(app.staticTexts["バックアップ検証成功: 自動保存・最新会話・添付の復元"].waitForExistence(timeout: 15))
        capture("backup-local-file-provider-roundtrip", app: app)
    }

    @MainActor func testNativeBubbleInertiaStillWorksAfterSendAndRespectsReduceMotion() throws {
        throw XCTSkip("The UIKit layer driver was retired in1.0.20. Pure SwiftUI row geometry and non-overlap are checked by the mixed attachment streaming test.")
        continueAfterFailure = false
        for reduced in [false, true] {
            let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--long-chat", "--elastic-diagnostics"] + (reduced ? ["--reduce-motion"] : []); app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let input = app.textViews["chat-input"]
            input.tap(); input.typeText("Bounce check"); app.buttons["送信する"].tap()
            XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 6))
            let reading = app.scrollViews["chat-conversation"]
            reading.swipeDown(); reading.swipeDown()
            let report = app.staticTexts["elastic-report"]
            if reduced { XCTAssertTrue(report.label.contains("バウンズ待機")) }
            else {
                XCTAssertTrue(report.label.contains("バウンズ動作を確認"), "Actual rendered row layers must have moved after a drag")
                expectation(for: NSPredicate(format: "label CONTAINS %@", "静止"), evaluatedWith: report)
                waitForExpectations(timeout: 4)
            }
            capture(reduced ? "bubble-inertia-disabled" : "bubble-inertia-after-send", app: app)
            app.terminate()
        }
    }

    @MainActor func testVisionProbeScreenSeparatesRealJPEGAndComponentTests() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        let button = app.buttons["open-vision-probe"]
        for _ in 0..<10 where !button.isHittable { app.scrollViews["model-list"].swipeUp() }
        XCTAssertTrue(button.isHittable); button.tap()
        XCTAssertTrue(app.buttons["run-vision-probe"].waitForExistence(timeout: 5))
        app.buttons["run-vision-probe"].tap()
        XCTAssertTrue(app.staticTexts["UI検証用アプリではネイティブ推論を実行しません。"].waitForExistence(timeout: 3))
        capture("vision-minimal-probe-controls", app: app)
    }

    /// The developer GPU start test opens from the diagnostics card with its
    /// model and precision choices; the preview runs no native inference.
    @MainActor func testGPUStartTestScreenOpensFromDeveloperDiagnostics() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--reset-settings", "--developer-unlocked"]; app.launch()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.navigationBars["モデルと設定"].waitForExistence(timeout: 4))
        let toggle = app.switches["developer-settings-toggle"]
        revealModelControl(toggle, app: app)
        toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
        XCTAssertEqual(toggle.value as? String, "1")
        let open = app.buttons["open-gpu-test"]
        revealModelControl(open, app: app)
        open.tap()
        XCTAssertTrue(app.navigationBars["GPU起動テスト"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "日本の首都はどこですか")).firstMatch.exists,
                      "The screen names its one fixed question")
        let run = app.buttons["run-gpu-test"]
        XCTAssertTrue(run.waitForExistence(timeout: 3))
        capture("gpu-start-test-controls", app: app)
        run.tap()
        XCTAssertTrue(app.staticTexts["UI検証用アプリではネイティブ推論を実行しません。"].waitForExistence(timeout: 3))
        capture("gpu-start-test-preview-run", app: app)
        app.navigationBars["GPU起動テスト"].buttons["完了"].tap()
        XCTAssertTrue(open.waitForExistence(timeout: 4))
        // Back to the daily settings for the tests that follow.
        app.terminate(); app.launchArguments = ["--reset-settings"]; app.launch()
    }

    @MainActor private func importFixture(_ name: String, extension suffix: String, app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap()
        chooseMenuAction(name, app: app)
        XCTAssertTrue(app.buttons["添付ファイルを開く: \(name).\(suffix)"].waitForExistence(timeout: 8))
    }

    /// Device-like token stream (a few characters at a time, Markdown list)
    /// in a new chat. The reply stays shorter than the screen for seconds, so
    /// the rows must never move down; on device they dropped to a bottom-
    /// aligned position mid-reply and crept back up.
    @MainActor func testTokenStreamFirstReplyNeverMovesDown() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--token-stream"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["テスト"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.5)
        var positions: [CGFloat] = []
        let start = Date()
        while Date().timeIntervalSince(start) < 9 {
            if sent.exists { positions.append(sent.frame.minY) }
        }
        let down = zip(positions, positions.dropFirst()).map { $1 - $0 }.max() ?? 0
        XCTAssertLessThanOrEqual(down, 3, "Rows moved down while the reply streamed: \(positions)")
    }

    /// New chat, first reply growing past one screen: following the reply may
    /// move the rows up, but they must never move back down. On device they
    /// alternated between a top- and a bottom-aligned position every chunk.
    @MainActor func testGrowingFirstReplyNeverMovesBackDown() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--growing-reply"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let sent = app.staticTexts["テスト"].firstMatch
        XCTAssertTrue(sent.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        var positions: [CGFloat] = []
        for _ in 0..<30 {
            if sent.exists { positions.append(sent.frame.minY) }
            Thread.sleep(forTimeInterval: 0.1)
        }
        let backDown = zip(positions, positions.dropFirst()).map { $1 - $0 }.max() ?? 0
        XCTAssertLessThanOrEqual(backDown, 3, "Rows moved back down while the reply grew: \(positions)")
    }

    /// New chat, first reply: while a short reply streams in, the rows must
    /// stay where they are. On device they jumped between a top- and a
    /// bottom-aligned position with every streamed chunk.
    @MainActor func testFirstReplyInNewChatDoesNotJump() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--slow-reply"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("テスト")
        app.buttons["送信する"].tap()
        let modelName = app.staticTexts["Gemma 4 E4B"].firstMatch
        XCTAssertTrue(modelName.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)   // keyboard closed, reply about to start
        var positions: [CGFloat] = []
        for _ in 0..<20 {
            positions.append(modelName.frame.minY)
            Thread.sleep(forTimeInterval: 0.15)
        }
        let spread = (positions.max() ?? 0) - (positions.min() ?? 0)
        XCTAssertLessThanOrEqual(spread, 3, "Rows moved while the first reply streamed: \(positions)")
    }

    /// The Aurora Orb holds the reply's place while the model works: it
    /// shows as soon as the message is sent, keeps its mist moving, stays
    /// while the reply holds only a line break, and gives way to the first
    /// text on its line without moving the rows.
    @MainActor func testAuroraOrbWaitsForFirstVisibleText() {
        auroraOrb("light", arguments: ["--orb-wait"])
    }

    @MainActor func testAuroraOrbInDarkMode() {
        auroraOrb("dark", arguments: ["--orb-wait", "--dark"])
    }

    /// With Reduce Motion the orb holds one still frame.
    @MainActor func testAuroraOrbHoldsStillWithReduceMotion() {
        auroraOrb("still", arguments: ["--orb-wait", "--reduce-motion"])
    }

    /// From send to first text (preview --orb-wait: a line break 9 s after
    /// the send, the text 0.3 s later), measured from screenshots. The orb
    /// breathes between 24pt and 12pt, shrinks away over 0.7 s from the
    /// line break, and the text waits until it has gone. Element queries
    /// wait for the app to settle and ran out the wait while the orb drew
    /// (1.0.82 CI), so only one is made while it shows.
    @MainActor private func auroraOrb(_ variant: String, arguments: [String]) {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = arguments; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("オーロラ")
        // Under the header and above the composer, the orb is the only
        // colour on the left and the sent bubble the only blue on the right.
        let screen = app.frame.size
        let top = max(app.buttons["会話一覧を開く"].frame.maxY, app.buttons["chat-model-settings"].frame.maxY) + 8
        let left = CGRect(x: 0, y: top, width: 200, height: screen.height - 130 - top)
        let right = CGRect(x: screen.width / 2, y: top, width: screen.width / 2, height: left.height)
        let orb = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "AIが回答を作成しています")).firstMatch
        let tapped = Date()
        app.buttons["送信する"].tap()
        let sent = Date().timeIntervalSince(tapped)

        var readings: [OrbReading] = []
        var foundLine: (centre: CGPoint, bounds: CGRect, background: Int)?   // the orb settled on its line
        var recent: [(t: Double, area: ScreenArea)] = []
        var changes: [Double] = []
        var strip: [(t: Double, image: UIImage)] = []
        var waitShot: UIImage?, textShot: UIImage?
        var labelled: Bool?, labelSeconds = 0.0
        var foundText: Double?, textY = CGFloat.nan
        while Date().timeIntervalSince(tapped) < 30 {
            let t = Date().timeIntervalSince(tapped)
            let shot = XCUIScreen.main.screenshot().image
            guard let image = shot.cgImage, let area = ScreenArea(image, left, screenWidth: screen.width),
                  let side = ScreenArea(image, right, screenWidth: screen.width) else {
                XCTFail("Could not read a screenshot"); return
            }
            let colour = area.colour()
            if foundLine == nil, t >= sent + 0.8, colour.count >= 250 {
                let blank = CGRect(x: colour.bounds.maxX + 8, y: colour.centre.y - 9,
                                   width: 192 - colour.bounds.maxX, height: 18)
                foundLine = (colour.centre, colour.bounds, area.meanLuma(in: blank))
            }
            var ink = 0.0
            if let line = foundLine {
                // Right of the orb on its line: blank until the text comes.
                let band = CGRect(x: line.bounds.maxX + 8, y: line.centre.y - 9,
                                  width: 192 - line.bounds.maxX, height: 18)
                ink = area.ink(in: band, background: line.background).share
                if foundText == nil, ink > 0.02 { foundText = t }
                if foundText == nil, colour.count >= 60 {
                    // How much the mist changed over about a second. Shots
                    // can come 1 s apart while the simulator is busy (the
                    // dark run of 1.0.86 made 13 in 13 s), so pairs may be
                    // up to 2.5 s apart.
                    if let earlier = recent.last(where: { t - $0.t >= 0.8 }), t - earlier.t <= 2.5 {
                        changes.append(area.change(from: earlier.area, in: line.bounds.insetBy(dx: -4, dy: -4)))
                    }
                    recent.append((t, area))
                    recent.removeAll { t - $0.t > 2.5 }
                    if strip.count < 8, t - (strip.last?.t ?? 0) >= 1,
                       let crop = orbCrop(shot, around: line.centre, side: 64, screenWidth: screen.width) {
                        strip.append((t, crop))
                    }
                    if waitShot == nil, t >= sent + 2 { waitShot = shot }
                }
            }
            readings.append(OrbReading(t: t, colour: colour.count, ink: ink, bubble: side.blueTop()))
            if labelled == nil, foundLine != nil, foundText == nil, t >= sent + 1.5 {
                let start = Date()
                labelled = orb.exists
                labelSeconds = Date().timeIntervalSince(start)
            }
            if let line = foundLine, let textAt = foundText, textShot == nil, t >= textAt + 1.2 {
                textShot = shot
                let row = CGRect(x: line.bounds.minX - 4, y: line.centre.y - 16, width: 200 - line.bounds.minX, height: 32)
                textY = area.ink(in: row, background: line.background).centreY
            }
            if let textAt = foundText, t >= textAt + 2 { break }
        }

        if !strip.isEmpty { attachOrbStrip("orb-strip-\(variant)", frames: strip) }
        for (name, image) in [("wait", waitShot), ("text", textShot)] {
            guard let image else { continue }
            let attachment = XCTAttachment(image: image)
            attachment.name = "orb-\(variant)-\(name)"
            attachment.lifetime = .keepAlways
            add(attachment)
        }
        let gaps = zip(readings.dropFirst(), readings).map { later, earlier in later.t - earlier.t }
        let every = gaps.isEmpty ? 0 : gaps.reduce(0, +) / Double(gaps.count)
        let label = labelled.map { $0 ? "yes" : "no" } ?? "-"
        print(String(format: "ORB %@ tap=%.2f text=%.2f shots=%ld every=%.2f label=%@ in %.2f",
                     variant, sent, foundText ?? -1, readings.count, every, label, labelSeconds))
        var timeline: [String] = []
        for reading in readings {
            let bubble = reading.bubble.map { String(format: "%.0f", Double($0)) } ?? "-"
            timeline.append(String(format: "%.1f:%ld/%.2f/", reading.t, reading.colour, reading.ink) + bubble)
        }
        print("ORB \(variant) timeline (s:colour/ink/bubble) " + timeline.joined(separator: " "))
        let sortedChanges = changes.sorted()
        let median = sortedChanges.isEmpty ? -1 : sortedChanges[sortedChanges.count / 2]
        print(String(format: "ORB %@ change min=%.2f median=%.2f max=%.2f orbY=%.1f textY=%.1f", variant,
                     sortedChanges.first ?? -1, median, sortedChanges.last ?? -1,
                     Double(foundLine?.centre.y ?? -1), Double(textY)))
        print("ORB \(variant) orb bounds \(String(describing: foundLine?.bounds))")

        // The sent bubble flies up from the composer, and the orb shows
        // with it as it lands.
        guard let landed = readings.last?.bubble,
              let arrival = readings.first(where: { $0.bubble.map { abs($0 - landed) <= 2 } ?? false }) else {
            XCTFail("The sent message never showed"); return
        }
        XCTAssertLessThanOrEqual(arrival.t - sent, 2, "The sent message must show at once")
        guard let line = foundLine, let textAt = foundText else { XCTFail("The reply's text never showed"); return }
        // The orb shows from then until the first token, down to a 12pt
        // light (about 110 points² of colour) at the bottom of its breath.
        // It then shrinks away over 0.7 s, the text is laid out at a pace
        // and each character clears in 0.22 s, so its ink reads 0.1-0.5 s
        // after the orb has gone, and shots come every 0.3-1 s (the light
        // run of 1.0.88 had a 0.9 s gap just there), so the last 1.6 s
        // before the text reads is left out.
        let waiting = readings.filter { $0.t >= arrival.t + 0.3 && $0.t < textAt - 1.6 }
        let missing = waiting.filter { $0.colour < 60 }.map(\.t)
        XCTAssertTrue(missing.isEmpty, "The orb must show from the send until the first token; it was missing at \(missing) s")
        // The text waits until the orb has gone, so no shot has both.
        let both = readings.filter { $0.ink > 0.02 && $0.colour >= 60 }.map(\.t)
        XCTAssertTrue(both.isEmpty, "The text must wait until the orb has gone; both showed at \(both) s")
        let after = readings.filter { $0.t >= textAt + 0.6 }
        XCTAssertFalse(after.isEmpty)
        XCTAssertLessThanOrEqual(after.map(\.colour).max() ?? 0, 10, "No colour of the orb may stay behind the text")
        XCTAssertGreaterThanOrEqual(changes.count, 3, "Too few shots of the orb to measure its motion")
        if variant == "still" {
            XCTAssertLessThan(sortedChanges.last ?? 0, 0.3, "With Reduce Motion the orb holds still")
        } else {
            XCTAssertGreaterThan(sortedChanges.first ?? 0, 1, "The orb's mist must keep moving")
        }
        XCTAssertLessThanOrEqual(abs(textY - line.centre.y), 4, "The text must take the orb's line")
        let tops = readings.filter { $0.t >= arrival.t }.compactMap(\.bubble)
        XCTAssertGreaterThan(tops.count, readings.count / 2, "The sent bubble must stay in view")
        XCTAssertLessThanOrEqual((tops.max() ?? 0) - (tops.min() ?? 0), 2, "Rows moved while the orb gave way")
        XCTAssertEqual(labelled, true, "VoiceOver must read the orb as the reply being written")
        XCTAssertFalse(orb.exists, "Nothing of the orb may stay for VoiceOver once the text shows")
        let reply = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "こんにちは")).firstMatch
        XCTAssertTrue(reply.waitForExistence(timeout: 3))
        app.terminate()
    }

    /// Recording-oriented: send with the keyboard open, twice, in a long
    /// chat. Pauses isolate each send in interaction.mp4 for frame review of
    /// the keyboard dismissal, the follow-to-bottom scroll and the new bubble.
    @MainActor func testSendWithKeyboardOpenMotion() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat"]; app.launch()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        for text in ["送信の動きを確認します", "もう一度送信します"] {
            input.tap(); input.typeText(text)
            Thread.sleep(forTimeInterval: 0.8)
            app.buttons["送信する"].tap()
            Thread.sleep(forTimeInterval: 2.5)
            capture("after-send", app: app)
            XCTAssertTrue(app.staticTexts[text].exists || app.otherElements[text].exists
                          || app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch.exists)
        }
        XCTAssertTrue(app.buttons["chat-add-menu"].isHittable)
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists, "Sending must leave the latest message in view")
    }

    /// Recording-oriented check of the plus menu (a native Menu, so iOS
    /// owns the morph). Pauses isolate each open and close in interaction.mp4.
    @MainActor func testPlusMenuGlassMorphOpenCloseAndInterruption() {
        continueAfterFailure = false
        for arguments in [["--e2b"], ["--e2b", "--dark"]] {
            let app = XCUIApplication(); app.launchArguments = arguments; app.launch()
            let plus = app.buttons["chat-add-menu"]
            XCTAssertTrue(plus.waitForExistence(timeout: 10))
            let restingFrame = plus.frame
            Thread.sleep(forTimeInterval: 1.0)
            for _ in 0..<2 {
                plus.tap()
                let photos = menuItem("chat-attach-photos", "写真", app)
                XCTAssertTrue(photos.waitForExistence(timeout: 3))
                Thread.sleep(forTimeInterval: 1.2)
                capture("plus-menu-open\(arguments.contains("--dark") ? "-dark" : "")", app: app)
                dismissMenu(photos, app: app)
                Thread.sleep(forTimeInterval: 1.2)
            }
            // Open and dismiss immediately: the system reverses mid-flight.
            plus.tap()
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
            Thread.sleep(forTimeInterval: 1.2)
            XCTAssertFalse(menuItem("chat-attach-photos", "写真", app).exists)
            XCTAssertEqual(plus.frame.minX, restingFrame.minX, accuracy: 1)
            XCTAssertEqual(plus.frame.minY, restingFrame.minY, accuracy: 1)
            XCTAssertTrue(plus.isHittable)
            XCTAssertTrue(app.textViews["chat-input"].isHittable)
        }
    }

    @MainActor private func chooseMenuAction(_ name: String, app: XCUIApplication) {
        let button = menuItem(name, name, app)
        XCTAssertTrue(button.waitForExistence(timeout: 3))
        for _ in 0..<6 {
            if button.isHittable { break }
            app.collectionViews.firstMatch.swipeUp()
        }
        XCTAssertTrue(button.isHittable); button.tap()
    }

    /// System menu rows may expose either the identifier or only the title
    /// (possibly followed by the "調整中" subtitle) to XCUITest.
    @MainActor private func menuItem(_ id: String, _ title: String, _ app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                         id, title, title + ",")).firstMatch
    }

    @MainActor private func isLocked(_ item: XCUIElement) -> Bool {
        (item.value as? String) == "現在調整中" || item.label.contains("調整中")
    }

    /// Tap outside the menu, on the conversation, and wait for it to close.
    @MainActor private func dismissMenu(_ item: XCUIElement, app: XCUIApplication) {
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        let gone = NSPredicate(format: "exists == false")
        let wait = XCTNSPredicateExpectation(predicate: gone, object: item)
        XCTAssertEqual(XCTWaiter().wait(for: [wait], timeout: 3), .completed, "menu should close")
        XCTAssertTrue(app.buttons["会話の操作を開く"].waitForExistence(timeout: 3))
    }

    @MainActor private func openConfiguration(_ app: XCUIApplication) {
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 10))
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.buttons["model-generation-settings"].waitForExistence(timeout: 3))
        app.buttons["model-generation-settings"].tap()
        XCTAssertTrue(app.textFields["setting-Max Tokens"].waitForExistence(timeout: 3))
    }

    @MainActor private func replace(_ field: XCUIElement, with text: String) {
        field.tap()
        // Place the caret after the last line, including a multi-line editor.
        field.coordinate(withNormalizedOffset: CGVector(dx: 0.95, dy: 0.9)).tap()
        let old = field.value as? String ?? ""
        field.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: old.count) + text)
    }

    @MainActor private func revealConfigurationControl(_ control: XCUIElement, app: XCUIApplication) {
        let form = app.collectionViews["generation-configuration"]
        XCTAssertTrue(form.waitForExistence(timeout: 3))
        for _ in 0..<12 {
            let bounds = form.frame
            let keyboard = app.keyboards.firstMatch
            let bottom = min(bounds.maxY, keyboard.exists ? keyboard.frame.minY : app.frame.maxY) - 16
            if control.exists && control.isHittable && control.frame.minY >= bounds.minY + 8 && control.frame.maxY <= bottom { return }
            // SwiftUI can report offscreen segmented buttons as hittable. Drag the
            // visible Form gutter above the keyboard instead of swiping the app.
            let height = max(1, bottom - bounds.minY)
            let start = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: height * 0.8))
            let end = form.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: 8, dy: height * 0.15))
            start.press(forDuration: 0.05, thenDragTo: end)
        }
        XCTFail("Configuration control must be fully visible before interaction: \(control.identifier)")
    }

    /// Frames of the jump control's motion, for review without a recording:
    /// rising after a scroll up, and fusing back after a tap. Both the
    /// E2B and E4B layouts are covered; both now sink into the field.
    @MainActor func testJumpControlMotionFrames() {
        continueAfterFailure = false
        for (variant, arguments) in [("e2b", ["--long-chat", "--e2b"]), ("e4b", ["--long-chat"])] {
            let app = XCUIApplication()
            app.launchArguments = Self.keepOpen + arguments
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            XCTAssertTrue(reading.waitForExistence(timeout: 3))
            reading.swipeDown()
            captureStrip("jump-strip-\(variant)-rise")
            let jump = app.buttons["chat-jump-latest"]
            XCTAssertTrue(jump.waitForExistence(timeout: 3))
            XCTAssertEqual(jump.frame.midX, app.windows.firstMatch.frame.midX, accuracy: 1)
            jump.tap()
            captureStrip("jump-strip-\(variant)-fuse")
            let hidden = NSPredicate(format: "exists == false")
            expectation(for: hidden, evaluatedWith: jump)
            waitForExpectations(timeout: 4)
            capture("jump-\(variant)-settled", app: app)
            app.terminate()
        }
    }

    // MARK: - Composer: two rows, folded into three buttons (Phase UI-1)

    /// The composer at rest: one glass panel with the text above and the
    /// plus and send below, and the same with the keyboard up. Long text
    /// grows the panel up to six lines, then scrolls inside it.
    @MainActor func testComposerTwoRowsWithAndWithoutKeyboard() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let panel = app.descendants(matching: .any)["chat-composer"]
        let input = app.textViews["chat-input"]
        let send = app.buttons["送信する"]
        func checkRows(_ state: String) {
            let window = app.windows.firstMatch.frame
            print("COMPOSER \(state) panel=\(panel.frame) input=\(input.frame) plus=\(menu.frame) send=\(send.frame)")
            XCTAssertEqual(panel.frame.width, window.width - 24, accuracy: 1, "\(state): the panel spans the screen")
            XCTAssertGreaterThanOrEqual(panel.frame.height, 115, "\(state): two rows tall, as in the reference image")
            XCTAssertLessThanOrEqual(input.frame.maxY, menu.frame.minY + 1, "\(state): the text sits above the buttons")
            XCTAssertEqual(menu.frame.midY, send.frame.midY, accuracy: 1, "\(state): plus and send share the lower row")
            XCTAssertLessThan(menu.frame.midX, panel.frame.midX, "\(state): plus on the left")
            XCTAssertGreaterThan(send.frame.midX, panel.frame.midX, "\(state): send on the right")
            XCTAssertGreaterThanOrEqual(menu.frame.minX, panel.frame.minX - 1)
            XCTAssertLessThanOrEqual(send.frame.maxX, panel.frame.maxX + 1)
            XCTAssertLessThanOrEqual(send.frame.maxY, panel.frame.maxY + 1)
        }
        checkRows("rest")
        XCTAssertEqual(menu.frame.width, 44, accuracy: 1); XCTAssertEqual(menu.frame.height, 44, accuracy: 1)
        capture("composer-rest", app: app)
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        checkRows("keyboard")
        XCTAssertLessThanOrEqual(panel.frame.maxY, app.keyboards.firstMatch.frame.minY, "The panel rides above the keyboard")
        capture("composer-keyboard", app: app)
        let oneLine = panel.frame.height
        input.typeText("1行目\n2行目\n3行目")
        // The panel holds two lines at rest; the third grows it.
        XCTAssertGreaterThan(panel.frame.height, oneLine + 15, "Lines grow the panel")
        checkRows("three-lines")
        input.typeText("\n4行目\n5行目\n6行目\n7行目\n8行目\n9行目")
        let capped = panel.frame.height
        input.typeText("\n10行目\n11行目")
        XCTAssertEqual(panel.frame.height, capped, accuracy: 1, "Past six lines the text scrolls inside the panel")
        XCTAssertLessThan(capped, app.frame.height * 0.4)
        checkRows("long-text")
        capture("composer-long-text", app: app)
    }

    /// Reading older messages folds the composer into the voice, chat and
    /// latest buttons. Scrolling back down, and reaching the end, keep it
    /// folded; only the chat button unfolds it, with the keyboard up and
    /// the draft ready to continue without another tap.
    @MainActor func testComposerFoldsIntoThreeButtonsAndOnlyChatUnfolds() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let input = app.textViews["chat-input"]
        input.tap(); input.typeText("下書きの続き")
        let voice = app.buttons["composer-voice"], chat = app.buttons["composer-expand"]
        let latest = app.buttons["composer-jump"]
        XCTAssertFalse(chat.exists, "The folded buttons are hidden while the panel shows")
        dragReading(app, towardOlder: true)
        XCTAssertTrue(chat.waitForExistence(timeout: 4), "Reading older messages folds the composer")
        Thread.sleep(forTimeInterval: 1.0)
        XCTAssertTrue(gone(menu), "The panel's controls leave with it")
        XCTAssertFalse(app.keyboards.firstMatch.exists, "Folding puts the keyboard away")
        XCTAssertFalse(app.buttons["chat-jump-latest"].exists, "No separate jump control while folded")
        let window = app.windows.firstMatch.frame
        print("COMPOSER folded voice=\(voice.frame) chat=\(chat.frame) latest=\(latest.frame)")
        for button in [voice, chat, latest] {
            XCTAssertTrue(button.isHittable)
            XCTAssertEqual(button.frame.width, 48, accuracy: 1)
            XCTAssertEqual(button.frame.height, 48, accuracy: 1)
            XCTAssertEqual(button.frame.midY, chat.frame.midY, accuracy: 1, "One row")
        }
        XCTAssertEqual(chat.frame.midX, window.midX, accuracy: 1, "The chat button is centered")
        XCTAssertEqual(chat.frame.midX - voice.frame.midX, 72, accuracy: 1, "Voice on the left")
        XCTAssertEqual(latest.frame.midX - chat.frame.midX, 72, accuracy: 1, "Latest on the right")
        XCTAssertEqual(voice.label, "音声入力")
        XCTAssertEqual(chat.label, "入力欄を開く")
        XCTAssertEqual(latest.label, "最新のメッセージへ移動")
        capture("composer-folded", app: app)
        // Back toward the end: still folded.
        dragReading(app, towardOlder: false)
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertTrue(chat.exists, "Scrolling down does not unfold")
        XCTAssertFalse(menu.exists)
        // The latest button goes to the end and leaves the composer folded.
        latest.tap()
        Thread.sleep(forTimeInterval: 1.5)
        let newest = app.staticTexts["最新の返信です。ここまで戻りました。"].firstMatch
        XCTAssertTrue(newest.exists)
        XCTAssertLessThanOrEqual(newest.frame.maxY, chat.frame.minY, "The latest reply rests above the buttons")
        XCTAssertTrue(chat.exists, "Reaching the end keeps the composer folded")
        XCTAssertFalse(menu.exists)
        capture("composer-folded-at-latest", app: app)
        // One tap: the panel returns with the keyboard and the draft.
        chat.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3), "The chat button brings the keyboard at once")
        XCTAssertTrue(menu.waitForExistence(timeout: 3))
        XCTAssertTrue(gone(chat), "The buttons leave once they have merged")
        XCTAssertEqual(input.value as? String, "下書きの続き", "The draft is kept")
        // No tap on the field first: it already has the keyboard.
        input.typeText("です")
        XCTAssertEqual(input.value as? String, "下書きの続きです")
        capture("composer-unfolded-keyboard", app: app)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["下書きの続きです"].waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
        XCTAssertTrue(menu.exists, "Sending keeps the panel")
        XCTAssertFalse(chat.exists)
    }

    /// Folding follows the reader's finger only: the keyboard, a send, the
    /// reply's own following and a small nudge never fold the composer.
    @MainActor func testComposerStaysOpenThroughKeyboardSendAndStreaming() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat", "--growing-reply"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let chat = app.buttons["composer-expand"]
        let input = app.textViews["chat-input"]
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertFalse(chat.exists, "The keyboard does not fold the composer")
        input.typeText("Keyboard and stream")
        app.buttons["送信する"].tap()
        for _ in 0..<6 {
            Thread.sleep(forTimeInterval: 0.5)
            XCTAssertFalse(chat.exists, "Following the reply does not fold the composer")
        }
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        XCTAssertFalse(chat.exists)
        XCTAssertTrue(menu.exists)
        // A slow nudge of a few points toward older messages is not reading them.
        let reading = app.scrollViews["chat-conversation"]
        let origin = app.coordinate(withNormalizedOffset: .zero)
        let y = reading.frame.minY + reading.frame.height * 0.4
        origin.withOffset(CGVector(dx: reading.frame.midX, dy: y))
            .press(forDuration: 0.2, thenDragTo: origin.withOffset(CGVector(dx: reading.frame.midX, dy: y + 30)),
                   withVelocity: 80, thenHoldForDuration: 0.3)
        Thread.sleep(forTimeInterval: 0.8)
        XCTAssertFalse(chat.exists, "A nudge does not fold the composer")
        XCTAssertTrue(menu.exists)
        capture("composer-after-stream", app: app)
    }

    /// The voice button says there is no voice input yet instead of
    /// pretending, and can open the field for the keyboard's dictation.
    @MainActor func testComposerVoiceButtonSaysThereIsNoVoiceInputYet() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        dragReading(app, towardOlder: true)
        let voice = app.buttons["composer-voice"]
        XCTAssertTrue(voice.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 1.0)
        voice.tap()
        let note = app.alerts["音声入力"]
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        XCTAssertTrue(note.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "まだ音声で話しかける機能がありません"))
                        .firstMatch.exists)
        capture("composer-voice-note", app: app)
        note.buttons["閉じる"].tap()
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertTrue(app.buttons["composer-expand"].exists, "Closing the note keeps the composer folded")
        voice.tap()
        XCTAssertTrue(note.waitForExistence(timeout: 3))
        note.buttons["入力欄を開く"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 4))
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 3))
        XCTAssertTrue(gone(app.buttons["composer-expand"]))
    }

    /// Dark mode with Reduce Motion: the panel and the buttons cross-fade in
    /// place, and both still work. Opening another chat brings the panel.
    @MainActor func testComposerFoldInDarkModeWithReducedMotion() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat", "--dark", "--reduce-motion"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        capture("composer-rest-dark-reduced", app: app)
        dragReading(app, towardOlder: true)
        let chat = app.buttons["composer-expand"]
        XCTAssertTrue(chat.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.6)
        XCTAssertTrue(gone(menu))
        XCTAssertTrue(app.buttons["composer-voice"].isHittable)
        XCTAssertTrue(app.buttons["composer-jump"].isHittable)
        capture("composer-folded-dark-reduced", app: app)
        chat.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        XCTAssertTrue(menu.waitForExistence(timeout: 3))
        capture("composer-unfolded-dark-reduced", app: app)
        // Fold again, then start a new chat from the history: it opens with
        // the panel, ready to type.
        dragReading(app, towardOlder: true)
        XCTAssertTrue(chat.waitForExistence(timeout: 4))
        app.buttons["会話一覧を開く"].tap()
        XCTAssertTrue(historySidebar(app).waitForExistence(timeout: 4))
        app.buttons["history-compose"].tap()
        XCTAssertTrue(menu.waitForExistence(timeout: 4), "A new chat opens with the panel")
        XCTAssertTrue(gone(chat))
    }

    /// E4B only: a 高速・深く pill beside the plus shows the saved choice and
    /// changes it from its menu; E2B and Qwen have none.
    @MainActor func testComposerPhotoDetailPillOnlyForE4B() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--reset-settings"]; app.launch()
        let menu = app.buttons["chat-add-menu"]
        XCTAssertTrue(menu.waitForExistence(timeout: 10))
        let pill = app.buttons["composer-photo-detail"]
        XCTAssertTrue(pill.waitForExistence(timeout: 3), "E4B offers the photo detail")
        print("COMPOSER photo-detail pill=\(pill.frame) plus=\(menu.frame) value=\(pill.value ?? "")")
        XCTAssertEqual(pill.value as? String, "高速")
        XCTAssertEqual(pill.frame.midY, menu.frame.midY, accuracy: 1, "On the plus's row")
        XCTAssertGreaterThanOrEqual(pill.frame.minX, menu.frame.maxX - 1, "Right of the plus")
        XCTAssertLessThan(pill.frame.maxX, app.buttons["送信する"].frame.minX)
        capture("composer-photo-detail", app: app)
        // Let launch settle before opening the menu, as the plus menu checks do.
        Thread.sleep(forTimeInterval: 1.0)
        pill.tap()
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "深く")).firstMatch
        XCTAssertTrue(deep.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-photo-detail-menu", app: app)
        deep.tap()
        XCTAssertTrue(gone(deep))
        XCTAssertEqual(pill.value as? String, "深く")
        app.terminate()
        for flags in [["--e2b"], ["--qwen3"]] {
            app.launchArguments = flags; app.launch()
            XCTAssertTrue(menu.waitForExistence(timeout: 10))
            XCTAssertFalse(pill.exists, "\(flags): only E4B offers it")
            app.terminate()
        }
    }

    /// Frames of the fold and the unfold, played five times slower
    /// (`--slow-composer`) so back-to-back screenshots sample the glass as
    /// it splits and merges.
    @MainActor func testComposerMorphFramesLight() { composerMorphFrames("light", []) }
    @MainActor func testComposerMorphFramesDark() { composerMorphFrames("dark", ["--dark"]) }

    @MainActor private func composerMorphFrames(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        // A drag would return only after the morph had finished, so a
        // preview-only target (`--fold-button`) starts the fold.
        let app = XCUIApplication(); app.launchArguments = ["--long-chat", "--slow-composer", "--fold-button"] + flags
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.0)
        app.buttons["probe-fold"].tap()
        captureStrip("composer-strip-\(variant)-fold", count: 24, top: 0.64, height: 0.36)
        let chat = app.buttons["composer-expand"]
        XCTAssertTrue(chat.waitForExistence(timeout: 6))
        Thread.sleep(forTimeInterval: 2.0)
        capture("composer-folded-\(variant)", app: app)
        chat.tap()
        captureStrip("composer-strip-\(variant)-unfold", count: 16, top: 0.36, height: 0.64)
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 6))
    }

    /// The plus and 高速 menus opened and closed again and again, by a tap
    /// outside and by a choice, with and without the keyboard: the screen
    /// behind them must come back as it was (device report on 1.0.111).
    @MainActor func testComposerMenusLeaveTheScreenAsItWasLight() { composerMenuCycles("light", [], rounds: 2) }
    @MainActor func testComposerMenusLeaveTheScreenAsItWasDark() { composerMenuCycles("dark", ["--dark"], rounds: 1) }

    /// Menu queries are slow (a case of eight cycles took 200 s), so the
    /// rounds are few: closed by a tap outside, then 深く picked, then with
    /// the keyboard up 高速 picked again.
    @MainActor private func composerMenuCycles(_ variant: String, _ flags: [String], rounds: Int) {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--long-chat", "--reset-settings"] + flags
        app.launch()
        let plus = app.buttons["chat-add-menu"], pill = app.buttons["composer-photo-detail"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        XCTAssertTrue(pill.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 1.5)
        let before = XCUIScreen.main.screenshot().image
        capture("composer-menus-\(variant)-before", app: app)
        let outside = app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35))
        let photos = menuItem("chat-attach-photos", "写真", app)
        let deep = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "深く")).firstMatch
        let fast = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "高速")).firstMatch
        func settled(_ label: String, against reference: UIImage) {
            Thread.sleep(forTimeInterval: 0.8)
            let after = XCUIScreen.main.screenshot().image
            print(String(format: "COMPOSER menus-%@ %@ header=%.1f reading=%.1f composer=%.1f", variant, label,
                         screenDifference(reference, after, from: 0, to: 0.16),
                         screenDifference(reference, after, from: 0.16, to: 0.76),
                         screenDifference(reference, after, from: 0.76, to: 1)))
            XCTAssertTrue(plus.isHittable, "\(label): the plus is back")
            XCTAssertTrue(app.textViews["chat-input"].isHittable, "\(label): the field is back")
        }
        for round in 1...rounds {
            plus.tap()
            XCTAssertTrue(photos.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            if round == 1 { capture("composer-menus-\(variant)-plus-open", app: app) }
            outside.tap()
            if round == 1 { captureStrip("composer-menus-\(variant)-plus-close-strip", count: 8, top: 0, height: 1) }
            XCTAssertTrue(gone(photos))
            settled("plus-\(round)", against: before)
            capture("composer-menus-\(variant)-after-plus-\(round)", app: app)
            pill.tap()
            XCTAssertTrue(deep.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.8)
            if round == 1 { capture("composer-menus-\(variant)-detail-open", app: app) }
            if round == 2 { deep.tap() } else { outside.tap() }
            if round == 1 { captureStrip("composer-menus-\(variant)-detail-close-strip", count: 8, top: 0, height: 1) }
            XCTAssertTrue(gone(deep))
            settled("detail-\(round)", against: before)
            capture("composer-menus-\(variant)-after-detail-\(round)", app: app)
        }
        XCTAssertEqual(pill.value as? String, rounds >= 2 ? "深く" : "高速")
        // The same with the keyboard up.
        let input = app.textViews["chat-input"]
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.0)
        let typing = XCUIScreen.main.screenshot().image
        capture("composer-menus-\(variant)-keyboard-before", app: app)
        plus.tap()
        XCTAssertTrue(photos.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-menus-\(variant)-keyboard-plus-open", app: app)
        outside.tap()
        XCTAssertTrue(gone(photos))
        settled("keyboard-plus", against: typing)
        capture("composer-menus-\(variant)-keyboard-after-plus", app: app)
        pill.tap()
        XCTAssertTrue(fast.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.8)
        capture("composer-menus-\(variant)-keyboard-detail-open", app: app)
        if rounds >= 2 { fast.tap() } else { outside.tap() }
        XCTAssertTrue(gone(fast))
        settled("keyboard-detail", against: typing)
        XCTAssertEqual(pill.value as? String, "高速")
        capture("composer-menus-\(variant)-keyboard-after-detail", app: app)
    }

    /// Mean difference (0-255 per channel) between two screenshots across
    /// a band of the screen, given as parts of its height.
    @MainActor private func screenDifference(_ first: UIImage, _ second: UIImage, from top: CGFloat, to bottom: CGFloat) -> Double {
        let width = 120, height = 260
        func sample(_ image: UIImage) -> [UInt8]? {
            guard let cgImage = image.cgImage else { return nil }
            var bytes = [UInt8](repeating: 0, count: width * height * 4)
            let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
                guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                              bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                              bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
                context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
                return true
            }
            return drawn ? bytes : nil
        }
        guard let a = sample(first), let b = sample(second) else { return -1 }
        // The buffer's first row is the top of the screen.
        let rows = Int(top * CGFloat(height))..<Int(bottom * CGFloat(height))
        var total = 0, count = 0
        for row in rows {
            for column in 0..<width {
                let index = (row * width + column) * 4
                for channel in 0..<3 { total += abs(Int(a[index + channel]) - Int(b[index + channel])) }
                count += 3
            }
        }
        return count == 0 ? 0 : Double(total) / Double(count)
    }

    /// Waits for an element to leave the screen and the accessibility tree.
    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval = 3) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed
    }

    /// A drag through the reading area only, clear of the header, the
    /// composer and the keyboard. Toward older messages moves the finger down.
    @MainActor private func dragReading(_ app: XCUIApplication, towardOlder: Bool) {
        let reading = app.scrollViews["chat-conversation"]
        let any = app.descendants(matching: .any)
        let edges = [any["chat-composer"], app.buttons["composer-expand"], app.keyboards.firstMatch]
            .filter { $0.exists }.map { $0.frame.minY }
        let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
        let bottom = min(reading.frame.maxY, edges.min() ?? reading.frame.maxY) - 20
        XCTAssertGreaterThan(bottom - top, 120)
        let origin = app.coordinate(withNormalizedOffset: .zero)
        let x = reading.frame.midX
        let upper = top + (bottom - top) * 0.15, lower = top + (bottom - top) * 0.9
        origin.withOffset(CGVector(dx: x, dy: towardOlder ? upper : lower))
            .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: towardOlder ? lower : upper)))
    }

    /// Screenshots taken back to back (they do not wait for the app to go
    /// idle), cropped to the composer area (`top` and `height` as parts of
    /// the screen) and laid out on one sheet.
    @MainActor private func captureStrip(_ name: String, count: Int = 12, top: CGFloat = 0.58, height: CGFloat = 0.36) {
        var frames: [UIImage] = []
        var times: [Double] = []
        let start = Date()
        for _ in 0..<count {
            frames.append(XCUIScreen.main.screenshot().image)
            times.append(Date().timeIntervalSince(start))
        }
        guard let first = frames.first else { return }
        let size = first.size
        let crop = CGRect(x: 0, y: size.height * top, width: size.width, height: size.height * height)
        let factor: CGFloat = 0.5
        let cell = CGSize(width: crop.width * factor, height: crop.height * factor)
        let label: CGFloat = 14, columns = 4
        let rows = (frames.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.black.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width,
                                     y: CGFloat(index / columns) * (cell.height + label))
                let target = CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height)
                context.cgContext.saveGState()
                context.cgContext.clip(to: target)
                frame.draw(in: CGRect(x: target.minX - crop.minX * factor, y: target.minY - crop.minY * factor,
                                      width: size.width * factor, height: size.height * factor))
                context.cgContext.restoreGState()
                (String(format: "%d  %.0f ms", index, times[index] * 1000) as NSString)
                    .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// A copy of a screenshot's square around a point, at full resolution.
    /// Drawn into its own image, so the whole screenshot is not kept.
    private func orbCrop(_ shot: UIImage, around centre: CGPoint, side: CGFloat, screenWidth: CGFloat) -> UIImage? {
        guard let image = shot.cgImage, screenWidth > 0 else { return nil }
        let scale = CGFloat(image.width) / screenWidth
        let rect = CGRect(x: (centre.x - side / 2) * scale, y: (centre.y - side / 2) * scale,
                          width: side * scale, height: side * scale).integral
        guard let crop = image.cropping(to: rect) else { return nil }
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: CGSize(width: crop.width, height: crop.height), format: format).image { _ in
            UIImage(cgImage: crop).draw(at: .zero)
        }
    }

    /// The orb's crops laid out on one sheet with their times after the
    /// send, to review its motion.
    @MainActor private func attachOrbStrip(_ name: String, frames: [(t: Double, image: UIImage)]) {
        let columns = 4
        let label: CGFloat = 14
        let cell = frames[0].image.size
        let rows = (frames.count + columns - 1) / columns
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let sheetSize = CGSize(width: cell.width * CGFloat(columns), height: (cell.height + label) * CGFloat(rows))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let origin = CGPoint(x: CGFloat(index % columns) * cell.width,
                                     y: CGFloat(index / columns) * (cell.height + label))
                frame.image.draw(in: CGRect(x: origin.x, y: origin.y + label, width: cell.width, height: cell.height))
                (String(format: "%ld  %.1f s", index, frame.t) as NSString)
                    .draw(at: CGPoint(x: origin.x + 4, y: origin.y + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 10), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor private func historySidebar(_ app: XCUIApplication) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
    }

    /// Opening chats from history, between a long Markdown chat and short
    /// ones, lands at each chat's end, never below its last message. On
    /// device (1.0.58) a chat sometimes opened past its end, and touching it
    /// then counted as the pull that opens a new chat.
    @MainActor func testOpeningChatsFromHistoryLandsAtTheEnd() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--markdown-sample", "--history-fixture"]; app.launch()
        let open = app.buttons["会話一覧を開く"]
        XCTAssertTrue(open.waitForExistence(timeout: 10))
        let debug = app.descendants(matching: .any).matching(identifier: "scroll-debug").firstMatch
        func value(_ key: String) -> Double? {
            let label = debug.label
            guard let range = label.range(of: key + "=") else { return nil }
            return Double(label[range.upperBound...].prefix { "-0123456789.".contains($0) })
        }
        func pastEnd() -> Double? {
            guard let content = value("content"), let offset = value("offset"), let container = value("container"),
                  let top = value("insetTop") else { return nil }
            return offset + top + container - max(content, container)
        }
        for (index, title) in ["夕飯のレシピ", "Markdownの表示を確認", "カメムシ対策", "Markdownの表示を確認"].enumerated() {
            open.tap()
            let row = app.buttons["会話を開く: \(title)"]
            XCTAssertTrue(row.waitForExistence(timeout: 3), title)
            row.tap()
            Thread.sleep(forTimeInterval: 1.2)
            let past = pastEnd()
            print("HISTORY-OPEN \(title) past=\(past.map { String(format: "%.1f", $0) } ?? "?") \(debug.label.prefix(160))")
            capture("markdown-history-open-\(index)", app: app)
            XCTAssertLessThanOrEqual(past ?? 0, 8, "\(title) opened below its last message")
            XCTAssertGreaterThanOrEqual(past ?? 0, -8, "\(title) opened above its latest message")
            let content = value("content")
            // A small touch on the conversation must never open a new chat.
            let reading = app.scrollViews["chat-conversation"]
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.45))
                .press(forDuration: 0.1, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.47)))
            Thread.sleep(forTimeInterval: 0.8)
            XCTAssertFalse(app.staticTexts["メッセージを送って会話を始めましょう"].exists, "A touch opened a new chat")
            // The conversation is still open (a new chat would be empty).
            XCTAssertGreaterThan(value("content") ?? 0, (content ?? 0) * 0.5, "\(title) is still open")
            XCTAssertLessThanOrEqual(pastEnd() ?? 0, 8, "\(title) stays at its end after a touch")
        }
    }

    /// Probe (1.0.59): scrolling up in the long chat froze the preview app
    /// at full CPU in the send-motion check. Each variant turns suspects off;
    /// a variant that prints its PROBE line did not freeze.
    // Round 1 (f73c481): all-off and plain-replies passed; no link dialog, no
    // reveal, a shared scroll view and no pull each still froze. So it is
    // the Markdown reply itself. Round 2 narrows that down.
    // Round 2 (346d01d): no text selection, flat blocks and plain-string
    // text all still froze. Round 3 samples the frozen app's main thread.
    @MainActor func testProbeLongChatScrollBaseline() { probeLongChatScroll("baseline", []) }
    @MainActor func testProbeLongChatScrollNoSelection() { probeLongChatScroll("no-selection", ["--probe-no-selection"]) }
    @MainActor func testProbeLongChatScrollFlat() { probeLongChatScroll("flat", ["--probe-flat"]) }
    @MainActor func testProbeLongChatScrollStringText() { probeLongChatScroll("string-text", ["--probe-string-text", "--probe-no-reveal"]) }

    // Round 4 (1.0.67): with full-width replies the plain scroll-up passes,
    // but scrolling up right after a send still froze (send test). The
    // keyboard is open then and the drag dismisses it interactively.
    @MainActor func testProbeKeyboardImmediately() {
        probeLongChatScroll("keyboard-immediately", ["--probe-dismiss-immediately"], keyboard: true)
    }
    @MainActor func testProbeKeyboardInteractive() { probeLongChatScroll("keyboard-interactive", [], keyboard: true) }
    @MainActor func testProbeKeyboardNever() {
        probeLongChatScroll("keyboard-never", ["--probe-keep-keyboard"], keyboard: true)
    }
    @MainActor func testProbeKeyboardSent() { probeLongChatScroll("keyboard-sent", [], keyboard: true, send: true) }

    @MainActor private func probeLongChatScroll(_ name: String, _ flags: [String], keyboard: Bool = false, send: Bool = false) {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--long-chat"] + flags; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        if keyboard {
            let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
            input.tap()
            XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
            if send {
                input.typeText("Probe send\nSecond line")
                app.buttons["送信する"].tap()
                XCTAssertTrue(app.staticTexts["Probe send\nSecond line"].firstMatch.waitForExistence(timeout: 4))
                XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 8))
            }
            print("PROBE \(name) keyboard-before-scroll=\(app.keyboards.firstMatch.exists)")
        }
        let start = Date()
        reading.swipeDown()
        reading.swipeDown()
        let jump = app.buttons["chat-jump-latest"]
        let shown = jump.waitForExistence(timeout: 5)
        print("PROBE \(name) seconds=\(String(format: "%.1f", Date().timeIntervalSince(start))) jump=\(shown)")
        capture("probe-\(name)", app: app)
        XCTAssertTrue(shown)
        app.terminate()
    }

    /// Markdown replies: headings, emphasis, quote, lists and checklist,
    /// table, highlighted code with a copy button, math, rule and a
    /// tap-to-load image, in light mode. A link asks before it opens.
    @MainActor func testMarkdownReplyRendersEveryBlock() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--markdown-sample"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-bottom", app: app)
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "サンプル画像")).firstMatch.exists,
                      "The image shows as a card to tap, not loaded by itself")
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "**")).count, 0, "Raw bold markers")
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "```")).count, 0, "Raw code fences")
        let copies = app.buttons.matching(identifier: "code-copy")
        print("MARKDOWN-NOTE copy buttons: \(copies.count)")
        var copy = copies.allElementsBoundByIndex.last { $0.isHittable }
        // The sample's math below the code block has grown past a screen
        // (1.0.77), so the block is pulled back into view first.
        var pulls = 0
        while copy == nil, pulls < 5 {
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
                .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.7)))
            Thread.sleep(forTimeInterval: 0.6)
            copy = copies.allElementsBoundByIndex.last { $0.isHittable }
            pulls += 1
        }
        print("MARKDOWN-NOTE pulls to reach the copy button: \(pulls)")
        XCTAssertNotNil(copy, "The Swift block's copy button")
        copy?.tap()
        Thread.sleep(forTimeInterval: 0.3)
        capture("markdown-copied", app: app)
        // The screenshot shows the change; XCTest's accessibility snapshot
        // of the label can lag behind it, so this is only noted.
        let copied = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "コピーしました")).firstMatch
        print("MARKDOWN-NOTE copied label seen: \(copied.waitForExistence(timeout: 2))")
        // A short pull, so the reply's first lines clear the header.
        reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
            .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.55)))
        Thread.sleep(forTimeInterval: 0.8)
        capture("markdown-top", app: app)
        let link = app.links["リンク"].firstMatch
        XCTAssertTrue(link.waitForExistence(timeout: 2), "Links are exposed as links")
        // The pull's momentum varies; a link left under the header and the
        // status bar takes no tap, so pull a little more until it clears.
        let header = app.buttons["chat-model-settings"].frame.maxY
        var nudges = 0
        while link.frame.minY < header + 8, nudges < 3 {
            reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3))
                .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.45)))
            Thread.sleep(forTimeInterval: 0.8)
            nudges += 1
        }
        print("MARKDOWN-NOTE link at \(link.frame.minY) below the header at \(header) after \(nudges) more pulls")
        if link.isHittable {
            link.tap()
            XCTAssertTrue(app.staticTexts["リンクを開きますか？"].waitForExistence(timeout: 3), "A link asks before leaving the app")
            capture("markdown-link-confirm", app: app)
            // iOS 26 shows it as a popover without a cancel button; a tap
            // outside dismisses it.
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.62)).tap()
            XCTAssertTrue(app.staticTexts["リンクを開きますか？"].waitForNonExistence(timeout: 3))
        } else {
            print("MARKDOWN-NOTE link not hittable: \(link.frame)")
        }
        reading.swipeDown(); reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-wide", app: app)
        XCTAssertTrue(app.buttons["残り30行を表示"].exists || app.staticTexts["残り30行を表示"].exists,
                      "Long code shows its first lines until expanded")
    }

    @MainActor func testMarkdownReplyInDarkMode() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--markdown-sample", "--dark"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-bottom", app: app)
        reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-middle", app: app)
        reading.swipeDown()
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-dark-top", app: app)
    }

    /// Phase 5: a formula, a table and a code block each offer their own
    /// copy menu on a long press, prose keeps the reply's menu, and
    /// VoiceOver reads formulas in words and cells with their column's header.
    @MainActor func testMarkdownCopyMenusAndVoiceOverLabels() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = Self.keepOpen + ["--markdown-sample"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        let reading = app.scrollViews["chat-conversation"]
        XCTAssertTrue(reading.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        let any = app.descendants(matching: .any)
        func labels(_ prefix: String) -> [String] {
            any.matching(NSPredicate(format: "label BEGINSWITH %@", prefix)).allElementsBoundByIndex.prefix(10).map(\.label)
        }
        print("MARKDOWN-NOTE formula labels: \(labels("数式、"))")
        print("MARKDOWN-NOTE table labels: \(labels("表、"))")
        print("MARKDOWN-NOTE code labels: \(labels("コード、"))")
        XCTAssertTrue(any.matching(NSPredicate(format: "label == %@", "数式、0 から 1 までの積分 x の 2 乗 dx イコール 3 分の 1"))
            .firstMatch.exists, "A formula reads in words")
        XCTAssertTrue(any.matching(NSPredicate(format: "label == %@", "モデル、E2B")).firstMatch.exists,
                      "A cell reads with its column's header")

        // Between the header and the composer, where a touch reaches the reply.
        let top = app.buttons["chat-model-settings"].frame.maxY + 24
        let bottom = any["chat-composer"].frame.minY - 24
        func reach(_ query: XCUIElementQuery, _ name: String, room: CGFloat = 0) -> XCUIElement? {
            for pull in 0..<8 {
                if let element = query.allElementsBoundByIndex.last(where: { element in
                    element.frame.width > 0 && element.frame.midY > top && element.frame.midY + room < bottom
                }) {
                    print("MARKDOWN-NOTE \(name) reached after \(pull) pulls at \(element.frame)")
                    return element
                }
                reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.35))
                    .press(forDuration: 0.05, thenDragTo: reading.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.6)))
                Thread.sleep(forTimeInterval: 0.6)
            }
            return nil
        }
        func menu(_ item: String, also others: [String], shot: String) {
            XCTAssertTrue(app.buttons[item].waitForExistence(timeout: 4), "\(item) in the menu")
            for other in others { XCTAssertTrue(app.buttons[other].exists, "\(other) in the menu") }
            capture(shot, app: app)
            app.buttons[item].tap()
            XCTAssertTrue(app.buttons[item].waitForNonExistence(timeout: 3), "The menu closes")
            Thread.sleep(forTimeInterval: 0.4)
        }

        let formula = reach(any.matching(identifier: "math-block"), "formula")
        XCTAssertNotNil(formula, "A formula block on screen")
        formula?.press(forDuration: 1.2)
        menu("LaTeXをコピー", also: ["返信全体をコピー"], shot: "markdown-menu-math")

        let copy = reach(app.buttons.matching(identifier: "code-copy"), "code", room: 80)
        XCTAssertNotNil(copy, "The Swift block's copy button")
        copy?.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).withOffset(CGVector(dx: -120, dy: 50))
            .press(forDuration: 1.2)
        menu("返信全体をコピー", also: ["ファイルとして共有"], shot: "markdown-menu-code")

        let cell = reach(any.matching(NSPredicate(format: "label == %@", "モデル、E2B")), "table")
        XCTAssertNotNil(cell, "The table on screen")
        cell?.press(forDuration: 1.2)
        menu("表をコピー", also: ["タブ区切りでコピー", "返信全体をコピー"], shot: "markdown-menu-table")

        // Prose keeps the reply's own menu, which copies all of it.
        reading.swipeUp(); reading.swipeUp(); reading.swipeUp()
        Thread.sleep(forTimeInterval: 0.6)
        let prose = reach(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "連立方程式も描けます")), "prose")
        XCTAssertNotNil(prose, "A paragraph on screen")
        prose?.press(forDuration: 1.2)
        menu("コピー", also: [], shot: "markdown-menu-reply")
    }

    /// A table wider than the screen scrolls inside its own frame while the
    /// rest of the reply stays put, and a long press on it, on text or on
    /// the blank beside a short number, copies the table alone; the reply's
    /// own menu still copies all of it, wide code scrolls alone too, and a
    /// swipe on prose still shows the times.
    @MainActor func testWideTableScrollsAloneAndCopiesItself() {
        wideTable("markdown-wide-table", arguments: [], fixed: true, everything: true)
    }

    @MainActor func testWideTableInDarkMode() {
        wideTable("markdown-wide-table-dark", arguments: ["--dark"], fixed: true, everything: false)
    }

    /// The swipe and the table's menu as they were before 1.0.99, for
    /// comparison; it only notes what happens.
    @MainActor func testWideTableBeforeTheFixForComparison() {
        wideTable("markdown-wide-table-old", arguments: ["--probe-timestamp-anywhere", "--probe-table-menu-outside"],
                  fixed: false, everything: false)
    }

    @MainActor private func wideTable(_ name: String, arguments: [String], fixed: Bool, everything: Bool) {
        continueAfterFailure = false
        let app = XCUIApplication()
        // The times stay out after a swipe, so a screenshot shows them.
        app.launchArguments = Self.keepOpen + ["--wide-table", "--show-pasteboard", "--probe-timestamp-hold"] + arguments
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        let any = app.descendants(matching: .any)
        let screen = app.frame
        func labelled(_ text: String) -> XCUIElement { any.matching(NSPredicate(format: "label == %@", text)).firstMatch }
        func check(_ ok: Bool, _ what: String) {
            print("MARKDOWN-NOTE \(name) \(ok ? "yes" : "NO"): \(what)")
            if fixed { XCTAssertTrue(ok, what) }
        }
        let before = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "表の前の文章")).firstMatch
        let after = app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "表の後の文章")).firstMatch
        let table = any.matching(identifier: "markdown-table").firstMatch
        let total = labelled("合計")
        XCTAssertTrue(before.waitForExistence(timeout: 5) && total.exists, "The reply with the wide table on screen")

        // The reply keeps the screen's width; only the table runs past it.
        // Header cells are found twice (31 elements for these 17 labels in
        // the first run), so each label is looked up on its own.
        let headers = ["項目"] + (1...12).map { "\($0)月" } + ["合計", "合計、17,700", "合計、11,260", "合計、6,440"]
        XCTAssertEqual(headers.filter { !labelled($0).exists }, [], "Every column's header and the last column's cells")
        let tableFrame = table.frame, afterFrame = after.frame, firstTotal = total.frame.minX
        print("MARKDOWN-NOTE \(name) screen \(screen.size) table \(tableFrame) prose \(afterFrame) total \(firstTotal)")
        XCTAssertTrue(tableFrame.minX >= 0 && tableFrame.maxX <= screen.width + 0.5, "The table's frame keeps the screen's width")
        XCTAssertLessThanOrEqual(afterFrame.maxX, screen.width + 0.5, "Prose keeps the screen's width")
        XCTAssertGreaterThan(firstTotal, screen.width, "The last column starts past the screen's edge")
        capture("\(name)-start", app: app)

        // Where the first line of prose ends, in pixels: the rows move by
        // the times' swipe, which a frame may not show.
        let beforeFrame = before.frame
        let band = CGRect(x: 0, y: beforeFrame.minY + 2, width: screen.width - 80,
                          height: max(8, min(18, beforeFrame.height - 4)))
        var background = 255
        func proseEnd() -> CGFloat? {
            guard let image = XCUIScreen.main.screenshot().image.cgImage,
                  let area = ScreenArea(image, band, screenWidth: screen.width) else { return nil }
            return area.inkBounds(in: band, background: background)?.maxX
        }
        if let image = XCUIScreen.main.screenshot().image.cgImage,
           let area = ScreenArea(image, band, screenWidth: screen.width) {
            background = area.meanLuma(in: CGRect(x: 2, y: band.minY, width: 6, height: band.height))
        }
        guard let start = proseEnd() else { return XCTFail("The first line of prose in pixels") }
        func swipeLeft(at y: CGFloat, from x: CGFloat) {
            let origin = app.coordinate(withNormalizedOffset: .zero)
            origin.withOffset(CGVector(dx: x, dy: y))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x - 220, dy: y)),
                       withVelocity: .fast, thenHoldForDuration: 0)
            Thread.sleep(forTimeInterval: 1.0)
        }

        // Sideways on the table: the table scrolls to its last column, the
        // prose does not move.
        var shifts: [CGFloat] = []
        var lastTotal = total.frame
        for _ in 0..<3 where lastTotal.maxX > screen.width - 4 {
            swipeLeft(at: tableFrame.midY, from: screen.width * 0.65)
            shifts.append(start - (proseEnd() ?? start))
            lastTotal = total.frame
        }
        print("MARKDOWN-NOTE \(name) table swipes: prose moved \(shifts) pt, last column \(firstTotal) -> \(lastTotal)")
        check(firstTotal - lastTotal.minX > 100, "The table scrolls sideways")
        check(shifts.allSatisfy { abs($0) <= 2 }, "The prose stays put while the table scrolls")
        check(lastTotal.minX >= 0 && lastTotal.maxX <= screen.width, "The last column comes fully on screen")
        capture("\(name)-scrolled", app: app)

        // A long press opens one menu; the pasteboard shows what an item
        // copied.
        let pasteboard = any.matching(identifier: "preview-pasteboard").firstMatch
        func copied(_ item: String) -> String {
            let previous = pasteboard.label
            app.buttons[item].firstMatch.tap()
            _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label != %@", previous),
                                                               object: pasteboard)], timeout: 3)
            return pasteboard.label
        }
        let markers = ["表をコピー", "タブ区切りでコピー", "返信全体をコピー", "コピー", "ファイルとして共有"]
        let menuItems = app.buttons.matching(NSPredicate(format: "label IN %@", markers))
        func menu(at point: CGPoint, _ what: String) -> [String] {
            app.coordinate(withNormalizedOffset: .zero).withOffset(CGVector(dx: point.x, dy: point.y)).press(forDuration: 1.2)
            _ = menuItems.firstMatch.waitForExistence(timeout: 3)
            let shown = menuItems.allElementsBoundByIndex.map(\.label)
            print("MARKDOWN-NOTE \(name) \(what) menu: \(shown)")
            return shown
        }
        func tableMenu(_ shown: [String], _ what: String) {
            check(shown.contains("表をコピー") && shown.contains("タブ区切りでコピー") && shown.contains("返信全体をコピー")
                  && !shown.contains("コピー"), "A long press on \(what) opens the table's menu")
        }
        func noteCopy(_ text: String, _ what: String) {
            print("MARKDOWN-NOTE \(name) \(what) copied \(text.count) characters: "
                  + text.replacingOccurrences(of: "\n", with: "⏎").replacingOccurrences(of: "\t", with: "⇥").prefix(160))
        }
        func outsideTable(_ text: String) -> Bool {
            !text.contains("表の前") && !text.contains("表の後") && !text.contains("引用") && !text.contains("let note")
        }

        // On a number in the last column, then on the blank beside a short
        // one, where the reply's menu used to answer.
        let number = labelled("合計、6,440").frame
        let shown = menu(at: CGPoint(x: number.midX, y: number.midY), "a number")
        tableMenu(shown, "a number")
        capture("\(name)-menu", app: app)
        if shown.contains("表をコピー") {
            let markdown = copied("表をコピー")
            noteCopy(markdown, "表をコピー")
            check(markdown.hasPrefix("| 項目 | 1月 | 2月") && markdown.contains("| 利益 | 380 | 480")
                  && markdown.contains("| 6,440 |") && outsideTable(markdown), "表をコピー copies the table alone, as Markdown")
        } else if shown.contains("コピー") {
            noteCopy(copied("コピー"), "コピー")
        }
        let short = labelled("12月、770").frame
        let blank = menu(at: CGPoint(x: short.minX + 4, y: short.midY), "the blank beside 770")
        tableMenu(blank, "the blank beside 770")
        if blank.contains("タブ区切りでコピー") {
            let separated = copied("タブ区切りでコピー")
            noteCopy(separated, "タブ区切りでコピー")
            check(separated.hasPrefix("項目\t1月\t2月") && separated.contains("利益\t380\t480") && !separated.contains("|")
                  && outsideTable(separated), "タブ区切りでコピー copies the table alone, tab separated")
        } else if blank.contains("返信全体をコピー") || blank.contains("コピー") {
            noteCopy(copied(blank.contains("コピー") ? "コピー" : "返信全体をコピー"), "the reply's copy")
        }
        guard everything else { return }

        // Wide code scrolls alone too. Its menu is left as it was; noted.
        let code = any.matching(identifier: "code-block").firstMatch.frame
        let codeLine = CGPoint(x: screen.width * 0.65, y: code.maxY - 16)
        if codeLine.y < any.matching(identifier: "chat-composer").firstMatch.frame.minY - 4 {
            let moved = start - (proseEnd() ?? start)
            swipeLeft(at: codeLine.y, from: codeLine.x)
            check(abs(start - (proseEnd() ?? start) - moved) <= 2, "The prose stays put while code scrolls")
            if !menu(at: CGPoint(x: screen.width / 2, y: codeLine.y), "wide code").isEmpty {
                app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.12)).tap()
                Thread.sleep(forTimeInterval: 0.8)
            }
        } else {
            print("MARKDOWN-NOTE \(name) code under the composer at \(code); skipped")
        }

        // Prose keeps the reply's own menu, which copies all of it.
        let reply = menu(at: CGPoint(x: afterFrame.minX + 40, y: afterFrame.minY + 8), "prose")
        check(reply.contains("コピー") && !reply.contains("表をコピー"), "A long press on prose opens the reply's menu")
        if reply.contains("コピー") {
            let whole = copied("コピー")
            noteCopy(whole, "コピー")
            check(whole.hasPrefix("表の前の文章です。") && whole.contains("| 項目 | 1月") && whole.contains("引用")
                  && whole.contains("let note"), "The reply's コピー copies all of it")
        }

        // A swipe on prose still slides the rows to show the times.
        swipeLeft(at: afterFrame.minY + 8, from: screen.width * 0.65)
        let moved = start - (proseEnd() ?? start)
        print("MARKDOWN-NOTE \(name) prose swipe: prose moved \(moved) pt")
        XCTAssertGreaterThan(moved, 30, "A swipe on prose shows the times")
        capture("\(name)-times", app: app)
    }

    /// A long reply with every heading level, nested and numbered lists, a
    /// quote, a table and code, flat on the conversation: its top, middle
    /// and end, light and dark, for the spacing and alignment review.
    @MainActor func testMarkdownLongArticleLayout() {
        continueAfterFailure = false
        for dark in [false, true] {
            let app = XCUIApplication()
            app.launchArguments = Self.keepOpen + ["--markdown-article"] + (dark ? ["--dark"] : [])
            app.launch()
            XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
            let reading = app.scrollViews["chat-conversation"]
            XCTAssertTrue(reading.waitForExistence(timeout: 3))
            Thread.sleep(forTimeInterval: 0.6)
            let name = dark ? "markdown-article-dark" : "markdown-article"
            capture("\(name)-end", app: app)
            XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "#")).count, 0, "Raw heading markers")
            XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "**")).count, 0, "Raw bold markers")
            reading.swipeDown()
            Thread.sleep(forTimeInterval: 0.8)
            capture("\(name)-middle", app: app)
            // At the very top, where the reply must start below the header.
            // The history list holds the same title, so look in the chat only.
            let request = reading.staticTexts["長文のMarkdownを表示して"].firstMatch
            for _ in 0..<5 where !(request.exists && request.frame.minY > 100) {
                reading.swipeDown()
                Thread.sleep(forTimeInterval: 0.5)
            }
            XCTAssertTrue(reading.staticTexts["2035年のAIと暮らし"].firstMatch.exists, "The H1 heading")
            Thread.sleep(forTimeInterval: 0.6)
            capture("\(name)-top", app: app)
            app.terminate()
        }
    }

    /// While the reply streams, unfinished syntax never shows: no raw bold
    /// markers, code fences or half links, and the rows never jump down.
    @MainActor func testMarkdownStreamingNeverShowsRawSyntax() {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = ["--markdown-stream"]; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText("表示テスト")
        app.buttons["送信する"].tap()
        let sent = Date()
        XCTAssertTrue(app.buttons["回答を停止する"].waitForExistence(timeout: 10))
        // How long each accessibility snapshot takes while the reply streams
        // tells a slow runner from a busy main thread.
        print("MARKDOWN-NOTE stop button seen \(Date().timeIntervalSince(sent)) s after the send")
        var shots = 0
        var checks = 0
        let start = Date()
        while app.buttons["回答を停止する"].exists && Date().timeIntervalSince(start) < 20 {
            checks += 1
            let raw = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@ OR label CONTAINS %@ OR label CONTAINS %@",
                                                           "**", "```", "](http"))
            XCTAssertEqual(raw.count, 0, "Raw Markdown while streaming: \(raw.allElementsBoundByIndex.map(\.label))")
            if Date().timeIntervalSince(start) > Double(shots) * 1.6 + 1, shots < 4 {
                capture("markdown-stream-\(shots)", app: app); shots += 1
            }
        }
        print("MARKDOWN-NOTE stream loop: \(checks) checks and \(shots) shots in \(Date().timeIntervalSince(start)) s")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        print("MARKDOWN-NOTE reply finished \(Date().timeIntervalSince(sent)) s after the send")
        Thread.sleep(forTimeInterval: 0.6)
        capture("markdown-stream-done", app: app)
        XCTAssertTrue(app.staticTexts["表示テスト"].exists || app.staticTexts["表示テスト"].waitForExistence(timeout: 2))
    }

    // MARK: Charts (Phase 6-1)

    @MainActor func testChartsDrawInRepliesAndCopyTheirData() {
        charts("markdown-charts", arguments: [], everything: true)
    }

    @MainActor func testChartsInDarkMode() {
        charts("markdown-charts-dark", arguments: ["--dark"], everything: false)
    }

    /// At the largest accessibility text size the charts grow with the text
    /// and still keep the screen's width.
    @MainActor func testChartsAtTheLargestTextSize() {
        charts("markdown-charts-large", arguments: ["--large-type"], everything: false)
    }

    /// Charts between prose (`--chart-sample`): bars on their side with a
    /// long label, two series, data that cannot be drawn shown as its
    /// source, and further up upright bars, a line and a pie. Each keeps the
    /// screen's width and shows no raw data; a tap reads an item out; the
    /// copy button and the chart's menu copy its data alone.
    @MainActor private func charts(_ name: String, arguments: [String], everything: Bool) {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchArguments = Self.keepOpen + ["--chart-sample", "--show-pasteboard"] + arguments
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        let any = app.descendants(matching: .any)
        let screen = app.frame
        let top = app.buttons["chat-model-settings"].frame.maxY + 8
        // Above the composer and the jump button over it.
        let bottom = any["chat-composer"].frame.minY - 70
        let origin = app.coordinate(withNormalizedOffset: .zero)
        func chart(_ title: String) -> XCUIElement {
            any.matching(NSPredicate(format: "identifier == %@ AND label CONTAINS %@", "chart-block", title)).firstMatch
        }
        func readout(_ block: XCUIElement) -> XCUIElement { block.descendants(matching: .any)["chart-readout"].firstMatch }
        /// Waits for the readout to say `text`, and returns what it says.
        func reads(_ block: XCUIElement, _ text: String) -> String {
            let line = readout(block)
            _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label == %@", text),
                                                               object: line)], timeout: 2)
            return line.label
        }
        func drag(by dy: CGFloat) {
            let start = dy > 0 ? top + 30 : bottom - 30
            origin.withOffset(CGVector(dx: screen.width / 2, dy: start))
                .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: screen.width / 2, dy: start + dy)),
                       withVelocity: .slow, thenHoldForDuration: 0.3)
            Thread.sleep(forTimeInterval: 0.5)
        }
        /// Scrolls until the element is between the header and `limit`, or
        /// its top is when it is taller than that. Up by no more than it
        /// takes, so a pull at the end does not open a new chat.
        func reveal(_ element: XCUIElement, above limit: CGFloat? = nil) -> Bool {
            let floor = limit ?? bottom
            let room = floor - top
            for _ in 0..<10 {
                let frame = element.frame
                let tall = frame.height > room
                if frame.minY >= top && (tall ? frame.minY <= top + 60 : frame.maxY <= floor) { return true }
                if frame.minY < top {
                    drag(by: min(room * 0.8, top - frame.minY + 24))
                } else {
                    drag(by: -min(room * 0.8, tall ? frame.minY - top - 24 : frame.maxY - floor + 24))
                }
            }
            return false
        }
        func fits(_ block: XCUIElement, _ what: String) {
            let frame = block.frame
            print("MARKDOWN-NOTE \(name) \(what) at \(frame), screen \(screen.size)")
            XCTAssertTrue(frame.width > 100 && frame.minX >= 0 && frame.maxX <= screen.width + 0.5, "\(what) keeps the screen's width")
        }

        // Nothing of the data shows as text (the pasteboard's own line,
        // which shows what was copied, aside); the broken data shows as its
        // source under the reason, and the prose after it follows.
        let raw = app.staticTexts.matching(NSPredicate(format: "(label CONTAINS %@ OR label CONTAINS %@) AND identifier != %@",
                                                       "\"unit\"", "```", "preview-pasteboard"))
        XCTAssertEqual(raw.count, 0, "Chart data as text")
        let fallback = any.matching(identifier: "chart-fallback").firstMatch
        XCTAssertTrue(fallback.exists, "The broken data's note")
        XCTAssertTrue(reveal(fallback, above: any["chat-composer"].frame.minY - 4), "The broken data's note on screen")
        print("MARKDOWN-NOTE \(name) fallback: \(fallback.label)")
        XCTAssertTrue(fallback.label.contains("「A」の値が数値ではありません"), "The note says why")
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "たくさん")).firstMatch.exists,
                      "The broken data shown as code")
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "表示できないデータの後")).firstMatch.exists,
                      "The prose after the broken data")
        capture("\(name)-fallback", app: app)

        // Two series: a legend, and a tap reads out both values.
        let quarters = chart("四半期の売上")
        XCTAssertTrue(quarters.exists && reveal(quarters), "The chart of two series on screen")
        fits(quarters, "two series")
        XCTAssertEqual(readout(quarters).label, "項目をタップすると数値を表示します")
        if everything {
            let frame = quarters.frame
            origin.withOffset(CGVector(dx: frame.maxX - 44, dy: frame.maxY - 150)).tap()
            XCTAssertEqual(reads(quarters, "Q4：2024年 15.4億円・2025年 17.2億円"), "Q4：2024年 15.4億円・2025年 17.2億円",
                           "A tap on Q4 reads out both series")
        }
        capture("\(name)-series", app: app)

        // Bars on their side: seven items and a long label.
        let stores = chart("地方別の店舗数")
        XCTAssertTrue(stores.exists && reveal(stores), "The chart of bars on their side on screen")
        fits(stores, "bars on their side")
        XCTAssertEqual(readout(stores).label, "最大：関東 128店", "With nothing picked, the largest bar")
        capture("\(name)-rows", app: app)
        if everything {
            // 近畿 is the fourth of seven rows: its mark if it is exposed,
            // else where its row is drawn.
            let frame = stores.frame
            let mark = stores.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "近畿")).firstMatch
            let markY = mark.exists && frame.contains(CGPoint(x: frame.midX, y: mark.frame.midY)) ? mark.frame.midY : nil
            print("MARKDOWN-NOTE \(name) 近畿 row \(markY.map { "from its mark at \($0)" } ?? "from the layout")")
            origin.withOffset(CGVector(dx: frame.midX, dy: markY ?? frame.maxY - 134)).tap()
            XCTAssertEqual(reads(stores, "近畿：85店"), "近畿：85店", "A tap on a row reads it out")
            capture("\(name)-rows-picked", app: app)

            // The copy button and the menu copy this chart's data alone.
            let markdown = "地方別の店舗数（サンプル）\n\n| 項目 | 値（店） |\n| --- | --: |\n| 北海道・東北 | 42 |\n| 関東 | 128 |\n"
                + "| 中部 | 67 |\n| 近畿 | 85 |\n| 中国・四国 | 31 |\n| 九州・沖縄 | 49 |\n| 海外（アジア太平洋地域） | 12 |"
            let separated = "項目\t値（店）\n北海道・東北\t42\n関東\t128\n中部\t67\n近畿\t85\n中国・四国\t31\n九州・沖縄\t49\n海外（アジア太平洋地域）\t12"
            let pasteboard = any.matching(identifier: "preview-pasteboard").firstMatch
            func waitForCopy(after previous: String) -> String {
                _ = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: NSPredicate(format: "label != %@", previous),
                                                                   object: pasteboard)], timeout: 3)
                return pasteboard.label
            }
            func note(_ text: String, _ what: String) {
                print("MARKDOWN-NOTE \(name) \(what) copied \(text.count) characters: "
                      + text.replacingOccurrences(of: "\n", with: "⏎").replacingOccurrences(of: "\t", with: "⇥").prefix(200))
            }
            var previous = pasteboard.label
            stores.buttons["chart-copy"].firstMatch.tap()
            let button = waitForCopy(after: previous)
            note(button, "the copy button")
            XCTAssertEqual(button, markdown, "The copy button copies the chart's data as a Markdown table")

            let titleText = stores.staticTexts["地方別の店舗数（サンプル）"].firstMatch
            func fromMenu(_ item: String) -> String? {
                Thread.sleep(forTimeInterval: 0.8)
                let title = titleText.frame
                origin.withOffset(CGVector(dx: title.midX, dy: title.midY)).press(forDuration: 1.2)
                // The card's copy button has the same name as the menu's.
                let entry = app.buttons.matching(NSPredicate(format: "label == %@ AND identifier != %@", item, "chart-copy")).firstMatch
                guard entry.waitForExistence(timeout: 3) else {
                    print("MARKDOWN-NOTE \(name) menu without \(item): "
                          + app.buttons.allElementsBoundByIndex.map(\.label).filter { $0.contains("コピー") }.joined(separator: ", "))
                    return nil
                }
                previous = pasteboard.label
                entry.tap()
                return waitForCopy(after: previous)
            }
            let tabs = fromMenu("タブ区切りでコピー")
            capture("\(name)-copied", app: app)
            note(tabs ?? "", "タブ区切りでコピー")
            XCTAssertEqual(tabs, separated, "タブ区切りでコピー copies the data tab separated")
            let table = fromMenu("データをコピー")
            note(table ?? "", "データをコピー")
            XCTAssertEqual(table, markdown, "データをコピー copies the data as a Markdown table")
            let whole = fromMenu("返信全体をコピー") ?? ""
            note(whole, "返信全体をコピー")
            XCTAssertTrue(whole.hasPrefix("地方別の店舗数です。") && whole.contains("```chart")
                          && whole.hasSuffix("表示できないデータの後の文章です。"), "返信全体をコピー copies the whole reply as written")
        }

        // Further up, in the reply before: a pie with its legend, a line
        // and upright bars.
        let pie = chart("1日の時間の使い方")
        XCTAssertTrue(pie.exists && reveal(pie), "The pie chart on screen")
        fits(pie, "pie")
        XCTAssertEqual(readout(pie).label, "合計：24時間", "With nothing picked, the pie's total")
        let work = pie.buttons["仕事、8時間、33.3パーセント"].firstMatch
        XCTAssertTrue(work.exists && reveal(work), "The legend names each slice with its value and share")
        work.tap()
        XCTAssertEqual(reads(pie, "仕事：8時間（33.3%）"), "仕事：8時間（33.3%）", "A tap on the legend reads the slice out")
        capture("\(name)-pie", app: app)

        let line = chart("東京の月別平均気温")
        XCTAssertTrue(line.exists && reveal(line), "The line chart on screen")
        fits(line, "line")
        XCTAssertEqual(readout(line).label, "1月 5.4℃ → 12月 7.7℃", "With nothing picked, the first and last values")
        capture("\(name)-line", app: app)

        let cities = chart("主要都市の人口")
        XCTAssertTrue(cities.exists && reveal(cities), "The upright bars on screen")
        fits(cities, "upright bars")
        XCTAssertEqual(readout(cities).label, "最大：東京 1,400万人", "With nothing picked, the largest bar")
        if everything {
            // 大阪 is the middle one of five bars.
            let frame = cities.frame
            origin.withOffset(CGVector(dx: frame.midX + 15, dy: frame.maxY - 120)).tap()
            XCTAssertEqual(reads(cities, "大阪：275万人"), "大阪：275万人", "A tap on a bar reads it out")
        }
        capture("\(name)-columns", app: app)
        XCTAssertEqual(raw.count, 0, "Chart data as text")
    }

    /// A chart streamed a few characters at a time (`--chart-stream`): its
    /// data never shows as text or code while it arrives, the chart takes
    /// its placeholder's place once its block is complete, and the prose
    /// after it follows.
    @MainActor func testChartStreamsWithoutShowingItsData() {
        checkChartStream(["--chart-stream"], message: "果物の売上を見せて", name: "markdown-chart-stream")
    }

    /// The same reply as Gemma E2B wrote it on the phone (1.0.100), the chart
    /// block inside a ```markdown fence, answering a message that asks for
    /// a chart: the wrapper's fences never show, the chart is drawn, and the
    /// prose after it is prose, not code.
    @MainActor func testWrappedChartFromThePhoneIsDrawn() {
        checkChartStream(["--chart-stream", "--chart-wrapped"], message: "果物の売上をグラフにして", name: "markdown-chart-wrapped")
    }

    @MainActor private func checkChartStream(_ arguments: [String], message: String, name: String) {
        continueAfterFailure = false
        let app = XCUIApplication(); app.launchArguments = arguments; app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        app.buttons["chat-add-menu"].tap(); app.buttons["新しい会話"].tap()
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        input.tap(); input.typeText(message)
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.buttons["回答を停止する"].waitForExistence(timeout: 10))
        let any = app.descendants(matching: .any)
        let watched = any.matching(NSPredicate(format: "identifier IN %@", ["chart-pending", "chart-block", "chart-fallback", "code-block"]))
        let raw = app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@ OR label CONTAINS %@ OR label CONTAINS %@",
                                                       "\"type\"", "\"label\"", "```"))
        var seen: [String] = []
        var checks = 0
        let start = Date()
        while app.buttons["回答を停止する"].exists && Date().timeIntervalSince(start) < 30 {
            checks += 1
            XCTAssertEqual(raw.count, 0, "Chart data as text while streaming: \(raw.allElementsBoundByIndex.map(\.label))")
            let shown = watched.allElementsBoundByIndex.map(\.identifier)
            XCTAssertFalse(shown.contains("code-block") || shown.contains("chart-fallback"),
                           "A code block or the fallback while the chart streams: \(shown)")
            for identifier in shown where !seen.contains(identifier) {
                seen.append(identifier)
                capture("\(name)-\(identifier)", app: app)
            }
        }
        print("MARKDOWN-NOTE \(name): \(checks) checks in \(Date().timeIntervalSince(start)) s, seen \(seen)")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.6)
        let block = any.matching(identifier: "chart-block").firstMatch
        XCTAssertTrue(block.waitForExistence(timeout: 3), "The chart once its data is complete")
        XCTAssertFalse(any.matching(identifier: "chart-pending").firstMatch.exists, "No placeholder after the reply")
        XCTAssertFalse(any.matching(identifier: "chart-fallback").firstMatch.exists, "No fallback for complete data")
        XCTAssertEqual(block.descendants(matching: .any)["chart-readout"].firstMatch.label, "最大：りんご 120個")
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label BEGINSWITH %@", "グラフの後の説明です。")).firstMatch
                        .waitForExistence(timeout: 4), "The prose after the chart")
        XCTAssertEqual(raw.count, 0, "Chart data as text after the reply")
        XCTAssertFalse(any.matching(identifier: "code-block").firstMatch.exists, "No code block after the reply")
        capture("\(name)-done", app: app)
    }

    /// Below this share of non-background pixels the conversation is blank.
    /// Text and bubbles cover several percent of the reading area.
    /// These checks read the unfolded composer while they scroll through
    /// older messages (its jump control, the plus menu, the field). The
    /// composer's fold has checks of its own (testComposer...).
    static let keepOpen = ["--keep-composer-open"]
    static let drawnInk = 0.005

    /// Share of pixels that differ from the background in the conversation,
    /// between the header and the jump control. Accessibility frames stay
    /// in place when rows are not drawn, so hit tests alone miss a blank
    /// screen (the eager block as one lazy item, 1.0.71).
    @MainActor private func readingInk(_ app: XCUIApplication) -> Double {
        let shot = XCUIScreen.main.screenshot().image
        guard let image = shot.cgImage, app.frame.width > 0 else { return -1 }
        let scale = CGFloat(image.width) / app.frame.width
        let top = app.buttons["chat-model-settings"].frame.maxY + 12
        let bottom = app.descendants(matching: .any)["chat-composer"].frame.minY - 90
        guard bottom > top + 40,
              let region = image.cropping(to: CGRect(x: 0, y: top * scale, width: CGFloat(image.width),
                                                     height: (bottom - top) * scale).integral) else { return -1 }
        let width = 300, height = max(1, width * region.height / max(1, region.width))
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = pixels.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(region, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return -1 }
        var luma: [Int] = []
        luma.reserveCapacity(width * height)
        for index in stride(from: 0, to: pixels.count, by: 4) {
            let red = 299 * Int(pixels[index])
            let green = 587 * Int(pixels[index + 1])
            let blue = 114 * Int(pixels[index + 2])
            luma.append((red + green + blue) / 1000)
        }
        let background: Int = luma.sorted()[luma.count / 2]
        let marked: Int = luma.filter { abs($0 - background) > 60 }.count
        return Double(marked) / Double(luma.count)
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    /// Ten screenshots as quick as they come (about 0.2 s apart) of the
    /// first lines of a reply whose text is flowing in, cropped at full
    /// resolution and stacked on one sheet with their times, to review how
    /// the characters appear.
    @MainActor private func revealStrip(_ name: String, app: XCUIApplication, around frame: CGRect) {
        let screenWidth = app.frame.width
        guard screenWidth > 0, frame.width > 0 else { return }
        var frames: [(t: Double, image: UIImage)] = []
        let start = Date()
        for _ in 0..<10 {
            let t = Date().timeIntervalSince(start)
            let shot = XCUIScreen.main.screenshot().image
            guard let image = shot.cgImage else { continue }
            let scale = CGFloat(image.width) / screenWidth
            let rect = CGRect(x: max(0, frame.minX - 4) * scale, y: max(0, frame.minY - 6) * scale,
                              width: min(frame.width + 8, screenWidth) * scale, height: 60 * scale).integral
            guard let crop = image.cropping(to: rect) else { continue }
            frames.append((t, UIImage(cgImage: crop)))
        }
        guard let first = frames.first else { return }
        let label: CGFloat = 16
        let cell = first.image.size
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let sheetSize = CGSize(width: cell.width, height: (cell.height + label) * CGFloat(frames.count))
        let sheet = UIGraphicsImageRenderer(size: sheetSize, format: format).image { context in
            UIColor.darkGray.setFill()
            context.fill(CGRect(origin: .zero, size: sheetSize))
            for (index, frame) in frames.enumerated() {
                let top = CGFloat(index) * (cell.height + label)
                frame.image.draw(in: CGRect(x: 0, y: top + label, width: cell.width, height: cell.height))
                (String(format: "%ld  %.0f ms", index, frame.t * 1000) as NSString)
                    .draw(at: CGPoint(x: 4, y: top + 1),
                          withAttributes: [.font: UIFont.systemFont(ofSize: 12), .foregroundColor: UIColor.white])
            }
        }
        let attachment = XCTAttachment(image: sheet)
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        print("MARKDOWN-NOTE reveal strip shots at " + frames.map { String(format: "%.2f", $0.t) }.joined(separator: " ") + " s")
    }
}

/// One screenshot in the Aurora Orb test: seconds after the send tap, the
/// orb's colour in points², the share of text right of it on its line, and
/// the top of the sent bubble.
private struct OrbReading {
    let t: Double
    let colour: Int
    let ink: Double
    let bubble: CGFloat?
}

/// An area of a screenshot read at one pixel per point, to measure what is
/// drawn there without querying the app.
private struct ScreenArea {
    let frame: CGRect
    private let width: Int
    private let height: Int
    private let bytes: [UInt8]

    init?(_ shot: CGImage, _ frame: CGRect, screenWidth: CGFloat) {
        guard screenWidth > 0, frame.width >= 1, frame.height >= 1 else { return nil }
        let scale = CGFloat(shot.width) / screenWidth
        let rect = CGRect(x: frame.minX * scale, y: frame.minY * scale,
                          width: frame.width * scale, height: frame.height * scale).integral
        guard let crop = shot.cropping(to: rect) else { return nil }
        let width = Int(frame.width), height = Int(frame.height)
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = bytes.withUnsafeMutableBytes { buffer -> Bool in
            guard let context = CGContext(data: buffer.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                          bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                          bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            context.draw(crop, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { return nil }
        self.frame = CGRect(origin: frame.origin, size: CGSize(width: width, height: height))
        self.width = width
        self.height = height
        self.bytes = bytes
    }

    /// The clearly coloured pixels, where text and the conversation are
    /// black, white or grey: how many, their middle and their bounds.
    func colour() -> (count: Int, centre: CGPoint, bounds: CGRect) {
        var count = 0, sumX = 0, sumY = 0
        var minX = Int.max, maxX = Int.min, minY = Int.max, maxY = Int.min
        for y in 0..<height {
            for x in 0..<width where Self.chroma(pixel(x, y)) > 50 {
                count += 1; sumX += x; sumY += y
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
            }
        }
        guard count > 0 else { return (0, .zero, .null) }
        let centre = CGPoint(x: frame.minX + CGFloat(sumX) / CGFloat(count) + 0.5,
                             y: frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5)
        let bounds = CGRect(x: frame.minX + CGFloat(minX), y: frame.minY + CGFloat(minY),
                            width: CGFloat(maxX - minX + 1), height: CGFloat(maxY - minY + 1))
        return (count, centre, bounds)
    }

    /// Share of a band's pixels that are text, grey to black on a light
    /// background or light on a dark one, and the middle of that text.
    func ink(in rect: CGRect, background: Int) -> (share: Double, centreY: CGFloat) {
        let (columns, rows) = span(rect)
        var count = 0, sumY = 0
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) < 60, abs(Self.luma(value) - background) > 80 { count += 1; sumY += y }
            }
        }
        let share = Double(count) / Double(max(1, columns.count * rows.count))
        return (share, count == 0 ? .nan : frame.minY + CGFloat(sumY) / CGFloat(count) + 0.5)
    }

    func meanLuma(in rect: CGRect) -> Int {
        let (columns, rows) = span(rect)
        var total = 0
        for y in rows {
            for x in columns { total += Self.luma(pixel(x, y)) }
        }
        return total / max(1, columns.count * rows.count)
    }

    /// The top of the sent bubble: the first row with some blue in it.
    func blueTop() -> CGFloat? {
        for y in 0..<height {
            var blue = 0
            for x in 0..<width {
                let value = pixel(x, y)
                if value.blue > 180, value.blue - value.red > 120 { blue += 1 }
            }
            if blue >= 3 { return frame.minY + CGFloat(y) }
        }
        return nil
    }

    /// The bounds, in screen points, of the grey to black pixels off the
    /// background inside a rectangle given in screen points.
    func inkBounds(in rect: CGRect, background: Int) -> CGRect? {
        let (columns, rows) = span(rect)
        var minX = Int.max, maxX = Int.min
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) < 60, abs(Self.luma(value) - background) > 80 { minX = min(minX, x); maxX = max(maxX, x) }
            }
        }
        guard minX <= maxX else { return nil }
        return CGRect(x: frame.minX + CGFloat(minX), y: rect.minY, width: CGFloat(maxX - minX + 1), height: rect.height)
    }

    /// Coloured pixels, and grey to black ones off the background, inside
    /// a rectangle given in screen points.
    func marks(in rect: CGRect, background: Int) -> (colour: Int, ink: Int) {
        let (columns, rows) = span(rect)
        var colour = 0, ink = 0
        for y in rows {
            for x in columns {
                let value = pixel(x, y)
                if Self.chroma(value) > 50 { colour += 1 } else if abs(Self.luma(value) - background) > 80 { ink += 1 }
            }
        }
        return (colour, ink)
    }

    /// Mean change of colour from an earlier reading of the same area, over
    /// the pixels coloured in either.
    func change(from earlier: ScreenArea, in rect: CGRect) -> Double {
        let (columns, rows) = span(rect)
        var total = 0, count = 0
        for y in rows {
            for x in columns {
                let now = pixel(x, y), then = earlier.pixel(x, y)
                guard Self.chroma(now) > 50 || Self.chroma(then) > 50 else { continue }
                total += abs(now.red - then.red) + abs(now.green - then.green) + abs(now.blue - then.blue)
                count += 3
            }
        }
        return count == 0 ? 0 : Double(total) / Double(count)
    }

    /// The pixels inside a rectangle given in screen points.
    private func span(_ rect: CGRect) -> (columns: Range<Int>, rows: Range<Int>) {
        guard !rect.isNull else { return (0..<0, 0..<0) }
        let x0 = min(width, max(0, Int((rect.minX - frame.minX).rounded(.down))))
        let x1 = min(width, max(x0, Int((rect.maxX - frame.minX).rounded(.up))))
        let y0 = min(height, max(0, Int((rect.minY - frame.minY).rounded(.down))))
        let y1 = min(height, max(y0, Int((rect.maxY - frame.minY).rounded(.up))))
        return (x0..<x1, y0..<y1)
    }

    private func pixel(_ x: Int, _ y: Int) -> (red: Int, green: Int, blue: Int) {
        let index = (y * width + x) * 4
        return (Int(bytes[index]), Int(bytes[index + 1]), Int(bytes[index + 2]))
    }

    private static func chroma(_ value: (red: Int, green: Int, blue: Int)) -> Int {
        max(value.red, value.green, value.blue) - min(value.red, value.green, value.blue)
    }

    private static func luma(_ value: (red: Int, green: Int, blue: Int)) -> Int {
        (299 * value.red + 587 * value.green + 114 * value.blue) / 1000
    }
}
