import XCTest

/// The draft's documents as small glass cards above the field (1.1.0 (271),
/// fielua-reports Issue #9), scope file-cards: a document coming in (its
/// place first shaped as the card), a second one and a photo beside it, the
/// cross taking out only its own item, the card opening Quick Look, the
/// keyboard coming up under them, the send, and the fold of スマート. The
/// row's motion runs eight times slower (`--slow-draft`) and the fold five
/// times (`--slow-composer`), so the session recording's frames
/// (MENU-MARK chip-*, scripts/menu-frames.swift) show them coming and going;
/// CHIP lines give the measured frames, SHOT chip-* the screens.
final class DraftFileCardUITests: XCTestCase {
    static let longName = "2026年11月の打ち合わせ資料_最終確認版_ver3.txt"
    /// The card's measures (DraftChip): 44pt tall; 7 + 30 + 8 before the
    /// name, 4 + 38 after it; the name at most 144pt on the phone, 168 on
    /// the iPad, whatever else is in the draft.
    static let cardHeight: CGFloat = 44
    static let cardChrome: CGFloat = 87

    @MainActor func testDraftFileCardsLightSmart() { fileCards("light-smart", []) }
    @MainActor func testDraftFileCardsDarkStandard() { fileCards("dark-standard", ["--dark", "--classic-composer"]) }

    @MainActor private func fileCards(_ variant: String, _ flags: [String]) {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--e2b", "--attachment-fixtures", "--slow-draft", "--keep-composer-open"] + flags
        app.launch()
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.2)
        let any = app.descendants(matching: .any)
        let strip = any.matching(identifier: "draft-attachments").firstMatch
        let composer = any["chat-composer"]
        capture("chip-\(variant)-empty", app: app)
        let restingComposer = composer.frame

        // One document: its card above the field, the cross inside it.
        add("sample-document", mark: "chip-\(variant)-in", app: app)
        let open = app.buttons["添付ファイルを開く: sample-document.pdf"]
        let cross = app.buttons["添付を外す: sample-document.pdf"]
        XCTAssertTrue(open.waitForExistence(timeout: 8))
        XCTAssertTrue(cross.exists)
        settle()
        print("CHIP \(variant) one strip=\(strip.frame) open=\(open.frame) cross=\(cross.frame) composer=\(composer.frame) resting=\(restingComposer)")
        capture("chip-\(variant)-one", app: app)
        zoom("chipzoom-\(variant)-one", strip.frame.union(composer.frame), app: app)
        // The row's own frame is not an element (the scroll view reports its
        // content's), so its height shows in where the card stands: a row
        // of a photo's 82pt would leave 13pt more below the card.
        XCTAssertEqual(open.frame.height, Self.cardHeight, accuracy: 1)
        XCTAssertEqual(cross.frame.height, Self.cardHeight, accuracy: 1, "The cross's target is the card's height")
        XCTAssertEqual(cross.frame.minX, open.frame.maxX, accuracy: 1, "The cross ends the card")
        // At the composer's leading edge: スタンダード's bar at rest stands
        // 38pt in since 1.1.0 (274), スマート's panel 12pt.
        XCTAssertEqual(open.frame.minX, restingComposer.minX, accuracy: 1, "In line with the composer's leading edge")
        let single = cross.frame.maxX - open.frame.minX
        XCTAssertGreaterThan(single, Self.cardChrome + 130, "「sample-document.pdf」 whole")
        XCTAssertLessThanOrEqual(single, Self.cardChrome + 144 + 1, "A card under two thirds of the field")
        let gap = composer.frame.minY - open.frame.maxY
        XCTAssertGreaterThan(gap, 14, "Above the field, not on it")
        XCTAssertLessThan(gap, 24, "Right above the field, the row a card's height and 6pt around it")
        XCTAssertTrue(open.isHittable); XCTAssertTrue(cross.isHittable)

        // A photo beside it keeps its 64pt card, on the same line below.
        add("sample-image", mark: "chip-\(variant)-photo", app: app)
        let photo = app.buttons["添付ファイルを開く: sample-image.png"]
        XCTAssertTrue(photo.waitForExistence(timeout: 8))
        settle()
        print("CHIP \(variant) mixed strip=\(strip.frame) open=\(open.frame) cross=\(cross.frame) photo=\(photo.frame) composer=\(composer.frame)")
        capture("chip-\(variant)-mixed", app: app)
        zoom("chipzoom-\(variant)-mixed", strip.frame.union(composer.frame), app: app)
        XCTAssertEqual(composer.frame.minY - photo.frame.maxY, gap, accuracy: 3, "With a photo the row is a photo's height, as before")
        XCTAssertEqual(photo.frame.height, 64, accuracy: 1, "The photo's card is unchanged")
        XCTAssertEqual(photo.frame.maxY, open.frame.maxY, accuracy: 1, "Both stand on one line")
        XCTAssertGreaterThan(photo.frame.minX, cross.frame.maxX)
        XCTAssertEqual(cross.frame.maxX - open.frame.minX, single, accuracy: 1, "The card keeps its width when a photo comes")
        let photoCross = app.buttons["添付を外す: sample-image.png"]
        XCTAssertTrue(photoCross.isHittable)
        menuMark("chip-\(variant)-photo-out"); photoCross.tap()
        XCTAssertTrue(gone(photo, timeout: 4), "The photo's cross takes the photo out")
        settle()
        XCTAssertTrue(open.exists, "and only the photo")
        XCTAssertEqual(composer.frame.minY - open.frame.maxY, gap, accuracy: 1, "The row a card's height again")

        // A second document with a long name: shortened on the card, whole
        // for VoiceOver, the two side by side.
        add("sample-long-name", mark: "chip-\(variant)-second", app: app)
        let longOpen = app.buttons["添付ファイルを開く: \(Self.longName)"]
        let longCross = app.buttons["添付を外す: \(Self.longName)"]
        XCTAssertTrue(longOpen.waitForExistence(timeout: 8))
        settle()
        print("CHIP \(variant) two open=\(open.frame) cross=\(cross.frame) longOpen=\(longOpen.frame) longCross=\(longCross.frame) strip=\(strip.frame) screen=\(app.frame)")
        capture("chip-\(variant)-two", app: app)
        zoom("chipzoom-\(variant)-two", strip.frame.union(composer.frame), app: app)
        XCTAssertGreaterThan(longOpen.frame.minX, cross.frame.maxX, "In the order they came")
        XCTAssertEqual(cross.frame.maxX - open.frame.minX, single, accuracy: 1, "The first card keeps its width")
        let long = longCross.frame.maxX - longOpen.frame.minX
        XCTAssertLessThanOrEqual(long, Self.cardChrome + 144 + 1, "The long name is shortened")
        XCTAssertGreaterThan(long, Self.cardChrome + 124, "to the card's full width")
        XCTAssertTrue(longOpen.isHittable, "The second card shows, the row going on past the screen's edge")

        // The first one's cross: that document alone leaves.
        menuMark("chip-\(variant)-out"); cross.tap()
        XCTAssertTrue(gone(open, timeout: 4))
        settle()
        XCTAssertTrue(longOpen.exists, "The other document stays")
        print("CHIP \(variant) after-out longOpen=\(longOpen.frame) longCross=\(longCross.frame) strip=\(strip.frame)")
        capture("chip-\(variant)-after-out", app: app)
        XCTAssertEqual(longOpen.frame.minX, restingComposer.minX, accuracy: 1, "It moves to the row's start")
        XCTAssertEqual(longCross.frame.maxX - longOpen.frame.minX, long, accuracy: 1, "as wide as it was: its name is not cut anew")
        XCTAssertTrue(longCross.isHittable)

        // The card itself opens the file.
        longOpen.tap()
        XCTAssertTrue(app.navigationBars[Self.longName].waitForExistence(timeout: 5), "The card opens Quick Look")
        app.buttons["閉じる"].tap()
        XCTAssertTrue(gone(app.navigationBars[Self.longName], timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)

        // The keyboard comes up: the card rides with the field.
        let input = app.textViews["chat-input"]
        menuMark("chip-\(variant)-keys-up"); input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.6)
        let keyboard = app.keyboards.firstMatch.frame
        print("CHIP \(variant) keyboard longOpen=\(longOpen.frame) composer=\(composer.frame) keyboard=\(keyboard)")
        capture("chip-\(variant)-keyboard", app: app)
        zoom("chipzoom-\(variant)-keyboard", strip.frame.union(composer.frame), app: app)
        XCTAssertLessThan(composer.frame.maxY, keyboard.minY + 1, "The field above the keyboard")
        XCTAssertEqual(composer.frame.minY - longOpen.frame.maxY, gap, accuracy: 2, "The card keeps its place above the field")
        XCTAssertTrue(longCross.isHittable)

        // Sent: the draft's row leaves, the message carries the file.
        input.typeText("資料です")
        menuMark("chip-\(variant)-send"); app.buttons["送信する"].tap()
        XCTAssertTrue(gone(strip, timeout: 6), "The row leaves with the send")
        XCTAssertTrue(app.staticTexts["資料です"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 2.0)
        XCTAssertFalse(longCross.exists, "No cross left behind")
        XCTAssertTrue(app.buttons["添付ファイルを開く: \(Self.longName)"].exists, "The sent message shows the file")
        print("CHIP \(variant) sent composer=\(composer.frame) keyboards=\(app.keyboards.count)")
        capture("chip-\(variant)-sent", app: app)
    }

    /// スマート folds with a document in the draft: its card fades with the
    /// panel (glass and all), and comes back with it.
    @MainActor func testDraftFileCardFoldsAwayWithTheComposer() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--e2b", "--long-chat", "--attachment-fixtures", "--slow-composer"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.2)
        let strip = app.descendants(matching: .any).matching(identifier: "draft-attachments").firstMatch
        let composer = app.descendants(matching: .any)["chat-composer"]
        add("sample-document", mark: "chip-fold-in", app: app)
        let open = app.buttons["添付ファイルを開く: sample-document.pdf"]
        XCTAssertTrue(open.waitForExistence(timeout: 8))
        Thread.sleep(forTimeInterval: 1.0)
        let gap = composer.frame.minY - open.frame.maxY
        capture("chip-fold-before", app: app)
        let card = open.frame.union(app.buttons["添付を外す: sample-document.pdf"].frame)
        let chat = app.buttons["composer-expand"]
        menuMark("chip-fold-out"); dragReading(app, towardOlder: true)
        XCTAssertTrue(chat.waitForExistence(timeout: 5), "Reading older messages folds the composer")
        Thread.sleep(forTimeInterval: 4.5)
        XCTAssertTrue(gone(strip, timeout: 5), "Folded, the row is gone")
        print("CHIP fold folded strip=\(strip.exists) open=\(open.exists) card=\(card)")
        capture("chip-fold-folded", app: app)
        XCTAssertFalse(open.exists)
        menuMark("chip-fold-back"); chat.tap()
        XCTAssertTrue(open.waitForExistence(timeout: 6), "Unfolded, the card is back")
        Thread.sleep(forTimeInterval: 3.5)
        print("CHIP fold back strip=\(strip.frame) open=\(open.frame) composer=\(composer.frame) gap-before=\(gap)")
        capture("chip-fold-back", app: app)
        XCTAssertEqual(composer.frame.minY - open.frame.maxY, gap, accuracy: 1, "Back where it stood above the field")
        XCTAssertTrue(open.isHittable)
    }

    /// The iPad with its hardware keyboard (scope file-cards-ipad, as
    /// hw-keyboard's, with its `--hardware-keyboard` and the tester's
    /// keyboard notices): the cards above スタンダード's bar, which stays open
    /// with the keys, each name whole beside the other (the wide field has
    /// the room), and the cross and the send.
    @MainActor func testDraftFileCardOnTheIPad() {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .landscapeLeft
        addTeardownBlock { XCUIDevice.shared.orientation = .portrait }
        let app = PreviewApp()
        app.launchArguments = ["--e2b", "--attachment-fixtures", "--classic-composer", "--keep-composer-open",
                                "--hardware-keyboard", "--probe-hardware-notices"]
        app.launch()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 1.2)
        let any = app.descendants(matching: .any)
        let strip = any.matching(identifier: "draft-attachments").firstMatch
        let composer = any["chat-composer"]
        add("sample-document", mark: "chip-ipad-in", app: app)
        add("sample-long-name", mark: "chip-ipad-second", app: app)
        let open = app.buttons["添付ファイルを開く: sample-document.pdf"]
        let longOpen = app.buttons["添付ファイルを開く: \(Self.longName)"]
        XCTAssertTrue(longOpen.waitForExistence(timeout: 8))
        Thread.sleep(forTimeInterval: 1.0)
        let input = app.textViews["chat-input"]
        input.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
        Thread.sleep(forTimeInterval: 1.4)
        print("CHIP ipad strip=\(strip.frame) open=\(open.frame) longOpen=\(longOpen.frame) composer=\(composer.frame) screen=\(app.frame) keyboards=\(app.keyboards.count)")
        capture("chip-ipad-two", app: app)
        XCTAssertGreaterThan(composer.frame.minY - open.frame.maxY, 14, "Above the bar")
        XCTAssertLessThan(composer.frame.minY - open.frame.maxY, 24, "Right above the bar")
        XCTAssertGreaterThan(open.frame.minX, 0)
        // 7 + 30 + 8 + name + 4: 「sample-document.pdf」 whole (about 138pt),
        // the long name at its full 168.
        XCTAssertGreaterThan(open.frame.width, 49 + 130, "With two on the iPad a short name is not cut")
        XCTAssertGreaterThan(longOpen.frame.width, 49 + 150, "and a long one has its full room")
        XCTAssertLessThanOrEqual(longOpen.frame.width, 49 + 168 + 1, "but no more")
        zoom("chipzoom-ipad-two", strip.frame.union(composer.frame), app: app)
        let cross = app.buttons["添付を外す: sample-document.pdf"]
        XCTAssertTrue(cross.isHittable)
        cross.tap()
        XCTAssertTrue(gone(open, timeout: 4))
        XCTAssertTrue(longOpen.exists)
        input.typeText("iPadの資料")
        app.buttons["送信する"].tap()
        XCTAssertTrue(gone(strip, timeout: 6))
        XCTAssertTrue(app.staticTexts["iPadの資料"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.2)
        capture("chip-ipad-sent", app: app)
    }

    // MARK: Helpers

    /// The row's motion (eight times slower here) and the import finished.
    private func settle() { Thread.sleep(forTimeInterval: 2.4) }

    /// A fixture from the plus menu (`--attachment-fixtures`); the mark
    /// times the tap that starts the import.
    @MainActor private func add(_ name: String, mark: String, app: XCUIApplication) {
        app.buttons["chat-add-menu"].tap()
        let row = app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                                   name, name, name + ",")).firstMatch
        // A long menu builds its lower rows only once scrolled to.
        if !row.waitForExistence(timeout: 3) {
            XCTAssertTrue(app.collectionViews.firstMatch.exists, "The menu is open")
        }
        for _ in 0..<6 {
            if row.exists && row.isHittable { break }
            app.collectionViews.firstMatch.swipeUp()
        }
        XCTAssertTrue(row.isHittable, "\(name) is in the menu")
        menuMark(mark); row.tap()
    }

    @MainActor private func dragReading(_ app: XCUIApplication, towardOlder: Bool) {
        let reading = app.scrollViews["chat-conversation"]
        let any = app.descendants(matching: .any)
        let edges = [any["draft-attachments"], any["chat-composer"], app.buttons["composer-expand"], app.keyboards.firstMatch]
            .filter { $0.exists }.map { $0.frame.minY }
        let top = max(reading.frame.minY, app.buttons["chat-model-settings"].frame.maxY + 16)
        let bottom = min(reading.frame.maxY, edges.min() ?? reading.frame.maxY) - 20
        XCTAssertGreaterThan(bottom - top, 120)
        let origin = app.coordinate(withNormalizedOffset: .zero)
        let x = reading.frame.midX
        let upper = top + (bottom - top) * 0.15, lower = top + (bottom - top) * 0.9
        origin.withOffset(CGVector(dx: x, dy: towardOlder ? upper : lower))
            .press(forDuration: 0.05, thenDragTo: origin.withOffset(CGVector(dx: x, dy: towardOlder ? lower : upper)))
    }

    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed || !element.exists
    }

    private func menuMark(_ name: String) {
        print(String(format: "MENU-MARK %@ %.3f", name, Date().timeIntervalSince1970))
    }

    /// The draft's row and the field at the screen's own pixels, so the
    /// glass, the mark and the name can be looked at closely.
    @MainActor private func zoom(_ name: String, _ rect: CGRect, app: XCUIApplication) {
        // The app's own picture, the right way up in landscape too.
        let image = app.screenshot().image
        let scale = image.scale
        let area = rect.insetBy(dx: -8, dy: -16).intersection(CGRect(origin: .zero, size: app.frame.size))
        guard let full = image.cgImage,
              let part = full.cropping(to: CGRect(x: area.minX * scale, y: area.minY * scale,
                                                  width: area.width * scale, height: area.height * scale)) else { return }
        let attachment = XCTAttachment(image: UIImage(cgImage: part, scale: scale, orientation: .up))
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
