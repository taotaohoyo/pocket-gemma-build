import XCTest

/// Claude (1.1.0 (257)) against the relay that scripts/check-ui.sh starts
/// for the claude scope: claude-relay itself in Cloudflare's runtime
/// (workerd, wrangler dev) on this Mac, with a stand-in for Anthropic
/// (claude-relay/test/ui-relay.mjs). This iPhone registered as the
/// developer with the admin key, the relay's state on the page, a friend's
/// invite, a chat answered by Claude with the earlier turns it was given,
/// a stop (the stand-in sees the connection close: FAKE-CLAUDE CLOSED-EARLY),
/// 超高 chosen in the chat's model settings (the stand-in sees effort
/// xhigh), the model menu's Claude models with Fable 5.2 first and a chat
/// with Haiku 5.5, back to the phone's model, the credit running out (the
/// relay stops itself) and 再開, and 登録を解除 with the chats kept.
/// Screenshots as SHOT claude-*, lines as CLAUDE.
final class ClaudeUITests: XCTestCase {
    /// As check-ui.sh starts the relay.
    private let server = "http://127.0.0.1:8787"
    private let adminKey = "ui-check-admin-key-0123456789abcdefghij"

    @MainActor func testClaudeRegisterChatStopPauseAndLeave() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--claude-reset"]
        app.launch()

        // 設定 › Claude, nothing registered: the invite entry and the
        // developer's registration.
        openClaude(app)
        XCTAssertTrue(app.buttons["claude-developer-toggle"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["claude-invite-field"].exists)
        capture("claude-empty", app: app)

        // A pasted link that is no invite is refused before anything is sent.
        let inviteField = app.textFields["claude-invite-field"]
        inviteField.tap(); inviteField.typeText("https://example.com/other")
        app.buttons["claude-invite-read"].tap()
        XCTAssertTrue(app.staticTexts["claude-invite-problem"].waitForExistence(timeout: 3))

        // The developer: the relay's address and the admin key.
        app.buttons["claude-developer-toggle"].tap()
        let serverField = app.textFields["claude-server-field"]
        XCTAssertTrue(serverField.waitForExistence(timeout: 3))
        XCTAssertTrue(app.buttons["claude-admin-new"].exists, "a new admin key can be made here")
        serverField.tap(); serverField.typeText(server)
        let keyField = app.secureTextFields["claude-admin-field"]
        keyField.tap(); keyField.typeText(adminKey)
        capture("claude-developer", app: app)
        app.buttons["claude-developer-register"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["claude-registered"].waitForExistence(timeout: 20), "registered as the developer")
        let status = app.descendants(matching: .any).matching(identifier: "claude-status").firstMatch
        XCTAssertTrue(waitForLabel(status, containing: "使えます", timeout: 15), "the relay says Claude answers")
        print("CLAUDE registered status='\(status.label)' model='\(app.staticTexts["claude-model"].label)'")

        // The relay's management: friends off until the terms are checked.
        let friends = app.switches["claude-friends"]
        XCTAssertTrue(friends.waitForExistence(timeout: 10), "the developer manages the relay")
        print("CLAUDE friends=\(String(describing: friends.value))")
        XCTAssertEqual(friends.value as? String, "0", "friends start off")
        let friendName = app.textFields["claude-friend-name"]
        enter("友人\n", into: friendName, app)
        let makeInvite = app.buttons["claude-friend-invite"]
        reveal(makeInvite, app)
        press(makeInvite, app)
        XCTAssertTrue(app.descendants(matching: .any)["claude-friend-link"].waitForExistence(timeout: 10), "a friend's invite link")
        capture("claude-admin", app: app)

        // Without the admin key (1.1.0 (262)): the key the developer's
        // invite tied to this iPhone opens the same management after Face
        // ID (on the simulator, a plain key that asks nothing). 再開 below
        // goes through it too.
        let forget = app.buttons["claude-admin-forget"]
        reveal(forget, app)
        press(forget, app)
        let unlock = app.buttons["claude-admin-unlock"]
        XCTAssertTrue(unlock.waitForExistence(timeout: 10), "Face ID opens the management")
        print("CLAUDE FACEID unlock='\(unlock.label)'")
        reveal(unlock, app)
        capture("claude-admin-faceid", app: app)
        press(unlock, app)
        XCTAssertTrue(app.switches["claude-friends"].waitForExistence(timeout: 15), "managed after Face ID")
        XCTAssertFalse(app.buttons["claude-admin-forget"].exists, "no admin key left to forget")
        let friendAgain = app.textFields["claude-friend-name"]
        enter("友人2\n", into: friendAgain, app)
        reveal(makeInvite, app)
        press(makeInvite, app)
        XCTAssertTrue(app.buttons["claude-invite-withdraw-友人2"].waitForExistence(timeout: 10), "an invite made after Face ID")
        print("CLAUDE FACEID managed friends=\(String(describing: app.switches["claude-friends"].value)) invite=made")
        capture("claude-admin-faceid-open", app: app)

        // A chat answered by Claude.
        let startChat = app.buttons["claude-start-chat"]
        reveal(startChat, app, upward: false)
        press(startChat, app)
        let veil = app.descendants(matching: .any)["history-close"]
        if veil.waitForExistence(timeout: 3) { veil.tap() }
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 8))
        Thread.sleep(forTimeInterval: 0.8)
        let line = app.staticTexts["chat-model-line"]
        print("CLAUDE chat line='\(line.exists ? line.label : "none")' header='\(String(describing: app.buttons["chat-model-settings"].value))'")
        XCTAssertTrue(line.label.contains("外部AI"), "the chat says it is an external AI")
        XCTAssertTrue(app.staticTexts["chat-claude-disclosure"].exists)
        capture("claude-chat-empty", app: app)
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は1件です。"].waitForExistence(timeout: 20),
                      "Claude's reply streamed in through the relay")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10) || app.buttons["chat-add-menu"].exists)
        capture("claude-chat-reply", app: app)

        // Stopped while Claude writes: what came stays, marked stopped.
        input.tap(); input.typeText("長く話して")
        app.buttons["送信する"].tap()
        let stop = app.buttons["停止する"]
        XCTAssertTrue(stop.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 3)
        stop.tap()
        XCTAssertTrue(app.staticTexts["停止しました"].waitForExistence(timeout: 10), "the reply stopped")
        capture("claude-chat-stopped", app: app)

        // The next question gets the first exchange and itself.
        Thread.sleep(forTimeInterval: 1)
        input.tap(); input.typeText("もう一度")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は3件です。"].waitForExistence(timeout: 20),
                      "the earlier complete exchange went with the question, the stopped one did not")
        capture("claude-chat-context", app: app)

        // The chat's model settings (its header): 超高 with Opus 5.5; the next
        // question goes with it (effort xhigh at the stand-in). No tag of
        // rank and no explanations under the levels (1.1.0 (258)).
        let header = app.buttons["chat-model-settings"]
        XCTAssertTrue(header.waitForExistence(timeout: 5))
        header.tap()
        let top = app.descendants(matching: .any).matching(NSPredicate(format: "identifier == %@ OR label BEGINSWITH %@",
                                                                         "claude-effort-xhigh", "超高")).firstMatch
        XCTAssertTrue(top.waitForExistence(timeout: 5), "the levels are in the chat's model settings")
        for level in ["低", "中", "高"] {
            XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label BEGINSWITH %@", level)).firstMatch.exists)
        }
        XCTAssertFalse(app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "max")).firstMatch.exists,
                       "max is never offered")
        print("CLAUDE settings top='\(top.label)'")
        XCTAssertFalse(app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "最上級")).firstMatch.exists,
                       "no Fielua rank on Claude's levels")
        capture("claude-effort-settings", app: app)
        top.tap()
        app.buttons["configuration-save"].tap()
        XCTAssertTrue(gone(app.buttons["configuration-save"], timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        print("CLAUDE header after 超高='\(String(describing: header.value))'")
        XCTAssertTrue((header.value as? String ?? "").contains("超高"), "the chat says its level")
        input.tap(); input.typeText("超高で")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は5件です。"].waitForExistence(timeout: 20),
                      "Opus 5.5 at 超高 answered")

        // The model menu has Claude's models in the relay's order, Fable 5.2
        // above Opus 5.5 (Hachimoto さん, 2026-11-11); Haiku 5.5
        // starts a chat answered by it.
        input.tap()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 5))
        print("CLAUDE pill='\(chip.label)' value='\(String(describing: chip.value))'")
        XCTAssertTrue((chip.value as? String ?? "").contains("Claude Opus 5.5"), "the pill says Claude's model")
        chip.tap()
        let claudeItem = menuItem("model-menu-claude", "Claude", app)
        XCTAssertTrue(claudeItem.waitForExistence(timeout: 4), "Claude is in the model menu")
        print("CLAUDE model menu item='\(claudeItem.label)'")
        claudeItem.tap()
        let models = [("claude-fable-5-2", "Claude Fable 5.2"), ("claude-opus-5-5", "Claude Opus 5.5"),
                      ("claude-sonnet-5-5", "Claude Sonnet 5.5"), ("claude-haiku-5-5", "Claude Haiku 5.5")]
        let opusItem = menuItem("model-menu-claude-opus-5-5", "Claude Opus 5.5", app)
        XCTAssertTrue(opusItem.waitForExistence(timeout: 4), "Claude's models are in its submenu")
        var above = -CGFloat.infinity
        for (id, name) in models {
            let item = menuItem("model-menu-\(id)", name, app)
            XCTAssertTrue(item.exists, "\(name) can be chosen")
            print("CLAUDE model item '\(item.label)' y=\(Int(item.frame.minY))")
            XCTAssertLessThan(above, item.frame.minY, "\(name) in its place: Fable 5.2, Opus 5.5, Sonnet 5.5, Haiku 5.5")
            above = item.frame.minY
        }
        // Claude Fable 5.1 is former (5.2 took its place): not offered for a new chat.
        XCTAssertFalse(app.descendants(matching: .any)["model-menu-claude-fable-5-1"].exists, "Fable 5.1 is no longer offered")
        // Each model's second line (its level) is the menu row's subtitle:
        // seen in the shot, as a phone model's status is; the row's label
        // holds the title alone.
        print("CLAUDE opus row label='\(opusItem.label)' value='\(opusItem.value as? String ?? "")'")
        capture("claude-model-menu", app: app)
        menuItem("model-menu-claude-haiku-5-5", "Claude Haiku 5.5", app).tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        let haikuLine = app.staticTexts["chat-model-line"]
        print("CLAUDE haiku line='\(haikuLine.exists ? haikuLine.label : "none")' pill='\(chip.label)'")
        XCTAssertTrue(haikuLine.label.contains("Claude Haiku 5.5") && haikuLine.label.contains("外部AI"))
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は1件です。"].waitForExistence(timeout: 20),
                      "Haiku 5.5 answered a new chat")

        // A phone model starts a chat on the phone.
        input.tap()
        chip.tap()
        let gemma = menuItem("model-menu-gemma", "Gemma 4", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        gemma.tap()
        let e4b = menuItem("model-menu-gemma-4-e4b", "Gemma 4 E4B", app)
        XCTAssertTrue(e4b.waitForExistence(timeout: 3))
        e4b.tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        let phoneLine = app.staticTexts["chat-model-line"]
        print("CLAUDE back on the phone line='\(phoneLine.exists ? phoneLine.label : "none")'")
        XCTAssertFalse(phoneLine.label.contains("外部AI"))
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 10),
                      "the phone's model answers")

        // Out of credit: the relay stops itself, and the chat says so.
        input.tap()
        chip.tap()
        let claudeAgain = menuItem("model-menu-claude", "Claude", app)
        XCTAssertTrue(claudeAgain.waitForExistence(timeout: 4))
        claudeAgain.tap()
        let opusAgain = menuItem("model-menu-claude-opus-5-5", "Claude Opus 5.5", app)
        XCTAssertTrue(opusAgain.waitForExistence(timeout: 4))
        opusAgain.tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        input.tap(); input.typeText("billing")
        app.buttons["送信する"].tap()
        let alert = app.alerts.firstMatch
        XCTAssertTrue(alert.waitForExistence(timeout: 15))
        let said = alert.staticTexts.allElementsBoundByIndex.map(\.label).joined(separator: " ")
        print("CLAUDE out of credit alert='\(said)'")
        XCTAssertTrue(said.contains("クレジット"), "the reason, in a few words")
        capture("claude-out-of-credit", app: app)
        alert.buttons["閉じる"].tap()
        let note = app.staticTexts["chat-claude-note"]
        _ = note.waitForExistence(timeout: 5)
        print("CLAUDE chat note='\(note.exists ? note.label : "none")'")

        // 再開 on the developer's page; Claude answers again.
        openClaude(app)
        let resume = app.buttons["claude-resume"]
        XCTAssertTrue(resume.waitForExistence(timeout: 10), "the page says the relay stopped itself")
        capture("claude-paused", app: app)
        resume.tap()
        XCTAssertTrue(gone(resume, timeout: 10))
        XCTAssertTrue(waitForLabel(status, containing: "使えます", timeout: 15))

        // 登録を解除: the relay forgets this iPhone, the chats stay.
        leave(app)
        capture("claude-left", app: app)
        app.buttons["settings-close"].tap()
        let sidebar = app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
        if !sidebar.waitForExistence(timeout: 2) { app.buttons["会話一覧を開く"].tap() }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        let named = sidebar.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "こんにちは")).count
        print("CLAUDE history after leaving rows naming こんにちは=\(named)")
        XCTAssertGreaterThan(named, 0, "the Claude chat stays in the history")
        capture("claude-history-kept", app: app)
    }

    /// The web's features in the app (1.1.0 (260)): the estimate of the
    /// credit (the developer enters the balance; the composer's ring), a
    /// reply whose connection drops and is read again from the relay whole,
    /// a photo and a PDF sent (the stand-in counts them), Claude's web
    /// search (its line and the page it cited) and a file made by code
    /// execution (its card, and 保存 fetching it for the share sheet).
    @MainActor func testClaudeAttachmentsSearchFilesCreditAndReconnect() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--claude-reset", "--attachment-fixtures", "--claude-drop-once"]
        app.launch()
        openClaude(app)
        XCTAssertTrue(app.buttons["claude-developer-toggle"].waitForExistence(timeout: 5))
        app.buttons["claude-developer-toggle"].tap()
        let serverField = app.textFields["claude-server-field"]
        XCTAssertTrue(serverField.waitForExistence(timeout: 3))
        serverField.tap(); serverField.typeText(server)
        let keyField = app.secureTextFields["claude-admin-field"]
        keyField.tap(); keyField.typeText(adminKey)
        app.buttons["claude-developer-register"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["claude-registered"].waitForExistence(timeout: 20))
        let status = app.descendants(matching: .any).matching(identifier: "claude-status").firstMatch
        XCTAssertTrue(waitForLabel(status, containing: "使えます", timeout: 15))

        // The balance from Anthropic's Console: the estimate starts at 100%.
        let creditRow = app.buttons["claude-credit-row"]
        reveal(creditRow, app)
        press(creditRow, app)
        let amount = app.textFields["claude-credit-amount"]
        XCTAssertTrue(amount.waitForExistence(timeout: 5), "the developer enters the balance")
        amount.tap(); amount.typeText("25")
        app.buttons["claude-credit-save"].tap()
        let left = app.staticTexts["claude-credit-left"]
        XCTAssertTrue(left.waitForExistence(timeout: 10))
        print("CLAUDE credit left='\(left.label)'")
        XCTAssertTrue(left.label.contains("$25.00"), "about $25.00 left")
        capture("claude-credit-sheet", app: app)
        app.buttons["claude-credit-close"].tap()
        XCTAssertTrue(gone(left, timeout: 5))

        let startChat = app.buttons["claude-start-chat"]
        reveal(startChat, app, upward: false)
        press(startChat, app)
        let veil = app.descendants(matching: .any)["history-close"]
        if veil.waitForExistence(timeout: 3) { veil.tap() }
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 8))
        input.tap()
        let ring = app.buttons["claude-credit"]
        XCTAssertTrue(ring.waitForExistence(timeout: 10), "the composer shows the estimate")
        print("CLAUDE credit ring='\(ring.label)'")

        // The first reply's connection drops after two pieces (as iOS's
        // would): read again from the relay, each sentence once.
        input.typeText("つなぎ直して")
        app.buttons["送信する"].tap()
        let whole = (1...12).map { "これは\($0)文目です。" }.joined()
        XCTAssertTrue(app.staticTexts[whole].waitForExistence(timeout: 40), "the reply read again whole, nothing twice")
        capture("claude-reconnected", app: app)

        // A photo and a PDF go with the question.
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10) || app.buttons["chat-add-menu"].exists)
        for (name, suffix) in [("sample-image", "png"), ("sample-document", "pdf")] {
            app.buttons["chat-add-menu"].tap()
            if name == "sample-image" {
                XCTAssertTrue(menuItem("chat-attach-photos", "写真", app).waitForExistence(timeout: 4), "photos for Claude")
                XCTAssertFalse(menuItem("chat-attach-video", "動画", app).exists, "no video for Claude")
                capture("claude-plus-menu", app: app)
            }
            let fixture = menuItem(name, name, app)
            for _ in 0..<6 where !(fixture.exists && fixture.isHittable) { app.collectionViews.firstMatch.swipeUp() }
            XCTAssertTrue(fixture.isHittable, "\(name) is in the menu")
            fixture.tap()
            XCTAssertTrue(app.buttons["添付ファイルを開く: \(name).\(suffix)"].waitForExistence(timeout: 10), "\(name) attached")
        }
        capture("claude-attached", app: app)
        input.tap(); input.typeText("これは何")
        app.buttons["送信する"].tap()
        let carried = "テスト用のClaudeが答えています。受け取った発言は3件です。画像1枚と文書1件を受け取りました。"
        XCTAssertTrue(app.staticTexts[carried].waitForExistence(timeout: 30), "Claude got the photo and the PDF")
        capture("claude-attachments-reply", app: app)

        // ウェブ検索 and ファイル作成 from the plus menu: their pills show.
        for (id, title) in [("chat-web-search", "ウェブ検索"), ("chat-make-files", "ファイル作成")] {
            app.buttons["chat-add-menu"].tap()
            let toggle = menuItem(id, title, app)
            XCTAssertTrue(toggle.waitForExistence(timeout: 4), "\(title) is in the plus menu")
            toggle.tap()
            Thread.sleep(forTimeInterval: 0.6)
        }
        XCTAssertTrue(app.buttons["composer-web-search"].waitForExistence(timeout: 4), "the search pill")
        XCTAssertTrue(app.buttons["composer-make-files"].exists, "the files pill")
        capture("claude-tools-on", app: app)
        input.tap(); input.typeText("検索して")
        app.buttons["送信する"].tap()
        let searched = app.descendants(matching: .any).matching(NSPredicate(format: "identifier == %@ AND label CONTAINS %@",
                                                                              "reply-web-search", "Fielua テスト")).firstMatch
        XCTAssertTrue(searched.waitForExistence(timeout: 30), "the reply says what it searched")
        XCTAssertTrue(app.staticTexts["調べます。\n\n検索した結果です。"].waitForExistence(timeout: 10)
                      || app.staticTexts["検索した結果です。"].exists, "the text after the search is a paragraph of its own")
        let cited = app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "Fieluaのテストページ B")).firstMatch
        XCTAssertTrue(cited.waitForExistence(timeout: 10), "the page it cited")
        XCTAssertFalse(app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "Fieluaのテストページ A")).firstMatch.exists,
                       "only the cited page")
        print("CLAUDE searched='\(searched.label)'")
        capture("claude-searched", app: app)

        input.tap(); input.typeText("ファイルを作って")
        app.buttons["送信する"].tap()
        let card = app.descendants(matching: .any).matching(NSPredicate(format: "identifier == %@", "claude-file")).firstMatch
        XCTAssertTrue(card.waitForExistence(timeout: 30), "the made file's card")
        let named = app.staticTexts["report.txt"]
        XCTAssertTrue(named.waitForExistence(timeout: 15), "its name, from the relay")
        capture("claude-file-card", app: app)
        let save = app.buttons["claude-file-save"]
        XCTAssertTrue(save.waitForExistence(timeout: 5))
        save.tap()
        let share = app.otherElements["ActivityListView"]
        let shown = share.waitForExistence(timeout: 15) || app.navigationBars["UIActivityContentView"].waitForExistence(timeout: 3)
        // That the file came is the stand-in's to say (FAKE-CLAUDE files content).
        print("CLAUDE share sheet shown=\(shown)")
        capture("claude-file-share", app: app)
        if shown {
            let close = app.buttons.matching(NSPredicate(format: "label IN %@", ["閉じる", "Close"])).firstMatch
            if close.exists && close.isHittable { close.tap() } else { app.swipeDown(velocity: .fast) }
            _ = gone(share, timeout: 5)
        }

        // The estimate stops; the ring goes.
        openClaude(app)
        let row = app.buttons["claude-credit-row"]
        reveal(row, app)
        press(row, app)
        let clear = app.buttons["claude-credit-clear"]
        XCTAssertTrue(clear.waitForExistence(timeout: 5))
        clear.tap()
        XCTAssertTrue(gone(clear, timeout: 10), "the estimate stopped")
        app.buttons["claude-credit-close"].tap()
    }

    // MARK: Helpers

    @MainActor private func openClaude(_ app: XCUIApplication) {
        let history = app.buttons["会話一覧を開く"]
        if history.waitForExistence(timeout: 10) { history.tap() }
        let gear = app.buttons["history-settings"]
        XCTAssertTrue(gear.waitForExistence(timeout: 4))
        gear.tap()
        let row = app.buttons["settings-row-claude"]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        print("CLAUDE row value=\(String(describing: row.value))")
        row.tap()
        XCTAssertTrue(app.navigationBars["Claude"].waitForExistence(timeout: 4))
    }

    /// 登録を解除 on the page, through its dialog.
    @MainActor private func leave(_ app: XCUIApplication) {
        let leave = app.buttons["claude-leave"]
        XCTAssertTrue(leave.waitForExistence(timeout: 5))
        leave.tap()
        let confirms = app.buttons.matching(identifier: "claude-leave-confirm")
        var confirm = confirms.firstMatch
        if confirm.waitForExistence(timeout: 4) {
            confirm = confirms.allElementsBoundByIndex.first { $0.isHittable } ?? confirm
        } else {
            let named = app.buttons.matching(NSPredicate(format: "label == %@", "登録を解除"))
            confirm = named.element(boundBy: max(named.count - 1, 0))
        }
        confirm.tap()
        XCTAssertTrue(app.buttons["claude-developer-toggle"].waitForExistence(timeout: 10), "nothing registered")
    }

    /// Scrolls the Claude page until the element can be tapped (the
    /// keyboard or the sheet's edge may cover it). What covers it is
    /// printed and photographed when it can't be tapped at once.
    @MainActor private func reveal(_ element: XCUIElement, _ app: XCUIApplication, upward: Bool = true) {
        XCTAssertTrue(element.waitForExistence(timeout: 5), "\(element.identifier) is on the page")
        dismissSystemPrompts(app)
        guard !element.isHittable else { return }
        let page = app.scrollViews["claude-settings"]
        let keyboard = app.keyboards.firstMatch
        print("CLAUDE cover \(element.identifier) frame=\(element.frame) page=\(page.exists ? page.frame : .zero)"
              + " keyboard=\(keyboard.exists ? keyboard.frame : .zero) alerts=\(app.alerts.count) sheets=\(app.sheets.count)"
              + " windows=\(app.windows.count) window=\(app.windows.firstMatch.frame)")
        capture("claude-cover-\(element.identifier)", app: app)
        // A drag inside the page, clear of the keyboard and the sheet's bar.
        for _ in 0..<4 where !element.isHittable {
            let top = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.32))
            let middle = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5))
            if upward { middle.press(forDuration: 0.05, thenDragTo: top) } else { top.press(forDuration: 0.05, thenDragTo: middle) }
            Thread.sleep(forTimeInterval: 0.5)
        }
        print("CLAUDE reveal \(element.identifier) hittable=\(element.isHittable) frame=\(element.frame) keyboard=\(app.keyboards.count)")
    }

    /// Taps the element, by its place when XCTest calls it covered.
    @MainActor private func press(_ element: XCUIElement, _ app: XCUIApplication) {
        if element.isHittable { element.tap(); return }
        print("CLAUDE pressing \(element.identifier) by its place")
        element.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.5)).tap()
    }

    /// Types into a field on the Claude page.
    @MainActor private func enter(_ text: String, into field: XCUIElement, _ app: XCUIApplication) {
        reveal(field, app)
        press(field, app)
        Thread.sleep(forTimeInterval: 0.4)
        let focused = (field.value(forKey: "hasKeyboardFocus") as? Bool) ?? false
        print("CLAUDE typing into \(field.identifier) focused=\(focused) keyboard=\(app.keyboards.count)")
        if focused { field.typeText(text) } else { app.typeText(text) }
    }

    /// The system's own prompts over the app (a password to save, and the
    /// like): put away, and said in the log.
    @MainActor private func dismissSystemPrompts(_ app: XCUIApplication) {
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        for owner in [app, springboard] {
            for label in ["今はしない", "Not Now", "保存しない", "パスワードを保存しない"] {
                let button = owner.buttons[label]
                if button.exists && button.isHittable {
                    let said = owner.staticTexts.allElementsBoundByIndex.prefix(6).map(\.label).joined(separator: " | ")
                    print("CLAUDE system prompt put away: \(label) in \(owner === app ? "the app" : "SpringBoard") said='\(said)'")
                    capture("claude-system-prompt", app: app)
                    button.tap()
                    Thread.sleep(forTimeInterval: 0.6)
                }
            }
        }
    }

    @MainActor private func waitForLabel(_ element: XCUIElement, containing text: String, timeout: TimeInterval) -> Bool {
        let has = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", text), object: element)
        return XCTWaiter().wait(for: [has], timeout: timeout) == .completed
    }

    @MainActor private func menuItem(_ id: String, _ title: String, _ app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                         id, title, title + ",")).firstMatch
    }

    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed || !element.exists
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
