import XCTest

/// Claude (1.1.0 (257)) against the relay that scripts/check-ui.sh starts
/// for the claude scope: claude-relay itself in Cloudflare's runtime
/// (workerd, wrangler dev) on this Mac, with a stand-in for Anthropic
/// (claude-relay/test/ui-relay.mjs). This iPhone registered as the
/// developer with the admin key, the relay's state on the page, a friend's
/// invite, a chat answered by Claude with the earlier turns it was given,
/// a stop (the stand-in sees the connection close: FAKE-CLAUDE CLOSED-EARLY),
/// 超高 chosen in the chat's model settings (the stand-in sees effort
/// xhigh), the model menu's Claude models with Opus 5.5 first and a chat
/// with Haiku 5.5, back to the phone's model, the credit running out (the
/// relay stops itself) and 再開, and 登録を解除 with the chats kept.
/// Screenshots as SHOT claude-*, lines as CLAUDE.
final class ClaudeUITests: XCTestCase {
    /// As check-ui.sh starts the relay.
    private let server = "http://127.0.0.1:8787"
    private let adminKey = "ui-check-admin-key-0123456789abcdefghij"

    @MainActor func testClaudeRegisterChatStopPauseAndLeave() {
        continueAfterFailure = false
        let app = PreviewApp()
        app.launchArguments = ["--reset-settings", "--claude-reset"]
        app.launch()

        // 設定 › Claude, nothing registered: the invite entry and the
        // developer's registration.
        openClaude(app)
        XCTAssertTrue(app.buttons["claude-developer-toggle"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.textFields["claude-invite-field"].exists)
        capture("claude-empty", app: app)

        // A pasted link that is no invite is refused before anything is sent.
        let inviteField = app.textFields["claude-invite-field"]
        inviteField.tap(); inviteField.typeText("https://example.com/other")
        app.buttons["claude-invite-read"].tap()
        XCTAssertTrue(app.staticTexts["claude-invite-problem"].waitForExistence(timeout: 3))

        // The developer: the relay's address and the admin key.
        app.buttons["claude-developer-toggle"].tap()
        let serverField = app.textFields["claude-server-field"]
        XCTAssertTrue(serverField.waitForExistence(timeout: 3))
        XCTAssertTrue(app.buttons["claude-admin-new"].exists, "a new admin key can be made here")
        serverField.tap(); serverField.typeText(server)
        let keyField = app.secureTextFields["claude-admin-field"]
        keyField.tap(); keyField.typeText(adminKey)
        capture("claude-developer", app: app)
        app.buttons["claude-developer-register"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["claude-registered"].waitForExistence(timeout: 20), "registered as the developer")
        let status = app.descendants(matching: .any).matching(identifier: "claude-status").firstMatch
        XCTAssertTrue(waitForLabel(status, containing: "使えます", timeout: 15), "the relay says Claude answers")
        print("CLAUDE registered status='\(status.label)' model='\(app.staticTexts["claude-model"].label)'")

        // The relay's management: friends off until the terms are checked.
        let friends = app.switches["claude-friends"]
        XCTAssertTrue(friends.waitForExistence(timeout: 10), "the developer manages the relay")
        print("CLAUDE friends=\(String(describing: friends.value))")
        XCTAssertEqual(friends.value as? String, "0", "friends start off")
        let friendName = app.textFields["claude-friend-name"]
        reveal(friendName, app)
        friendName.tap(); friendName.typeText("友人\n")
        let makeInvite = app.buttons["claude-friend-invite"]
        reveal(makeInvite, app)
        makeInvite.tap()
        XCTAssertTrue(app.descendants(matching: .any)["claude-friend-link"].waitForExistence(timeout: 10), "a friend's invite link")
        capture("claude-admin", app: app)

        // A chat answered by Claude.
        let startChat = app.buttons["claude-start-chat"]
        reveal(startChat, app, upward: false)
        startChat.tap()
        let veil = app.descendants(matching: .any)["history-close"]
        if veil.waitForExistence(timeout: 3) { veil.tap() }
        let input = app.textViews["chat-input"]
        XCTAssertTrue(input.waitForExistence(timeout: 8))
        Thread.sleep(forTimeInterval: 0.8)
        let line = app.staticTexts["chat-model-line"]
        print("CLAUDE chat line='\(line.exists ? line.label : "none")' header='\(String(describing: app.buttons["chat-model-settings"].value))'")
        XCTAssertTrue(line.label.contains("外部AI"), "the chat says it is an external AI")
        XCTAssertTrue(app.staticTexts["chat-claude-disclosure"].exists)
        capture("claude-chat-empty", app: app)
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は1件です。"].waitForExistence(timeout: 20),
                      "Claude's reply streamed in through the relay")
        XCTAssertTrue(app.buttons["送信する"].waitForExistence(timeout: 10) || app.buttons["chat-add-menu"].exists)
        capture("claude-chat-reply", app: app)

        // Stopped while Claude writes: what came stays, marked stopped.
        input.tap(); input.typeText("長く話して")
        app.buttons["送信する"].tap()
        let stop = app.buttons["停止する"]
        XCTAssertTrue(stop.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 3)
        stop.tap()
        XCTAssertTrue(app.staticTexts["停止しました"].waitForExistence(timeout: 10), "the reply stopped")
        capture("claude-chat-stopped", app: app)

        // The next question gets the first exchange and itself.
        Thread.sleep(forTimeInterval: 1)
        input.tap(); input.typeText("もう一度")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は3件です。"].waitForExistence(timeout: 20),
                      "the earlier complete exchange went with the question, the stopped one did not")
        capture("claude-chat-context", app: app)

        // The chat's model settings (its header): 超高, Fielua's top with
        // Opus 5.5; the next question goes with it (effort xhigh at the stand-in).
        let header = app.buttons["chat-model-settings"]
        XCTAssertTrue(header.waitForExistence(timeout: 5))
        header.tap()
        let top = app.descendants(matching: .any).matching(NSPredicate(format: "identifier == %@ OR label BEGINSWITH %@",
                                                                         "claude-effort-xhigh", "超高")).firstMatch
        XCTAssertTrue(top.waitForExistence(timeout: 5), "the levels are in the chat's model settings")
        for level in ["低", "中", "高"] {
            XCTAssertTrue(app.descendants(matching: .any).matching(NSPredicate(format: "label BEGINSWITH %@", level)).firstMatch.exists)
        }
        XCTAssertFalse(app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "max")).firstMatch.exists,
                       "max is never offered")
        print("CLAUDE settings top='\(top.label)'")
        capture("claude-effort-settings", app: app)
        top.tap()
        app.buttons["configuration-save"].tap()
        XCTAssertTrue(gone(app.buttons["configuration-save"], timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        print("CLAUDE header after 超高='\(String(describing: header.value))'")
        XCTAssertTrue((header.value as? String ?? "").contains("超高"), "the chat says its level")
        input.tap(); input.typeText("超高で")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は5件です。"].waitForExistence(timeout: 20),
                      "Opus 5.5 at 超高 answered")

        // The model menu has Claude's models, Opus 5.5 first (at 超高, Fielua's
        // top); Haiku 5.5 starts a chat answered by it.
        input.tap()
        let chip = app.buttons["composer-model"]
        XCTAssertTrue(chip.waitForExistence(timeout: 5))
        print("CLAUDE pill='\(chip.label)' value='\(String(describing: chip.value))'")
        XCTAssertTrue((chip.value as? String ?? "").contains("Claude Opus 5.5"), "the pill says Claude's model")
        chip.tap()
        let claudeItem = menuItem("model-menu-claude", "Claude", app)
        XCTAssertTrue(claudeItem.waitForExistence(timeout: 4), "Claude is in the model menu")
        print("CLAUDE model menu item='\(claudeItem.label)'")
        claudeItem.tap()
        let models = ["claude-opus-5-5": "Claude Opus 5.5", "claude-fable-5-1": "Claude Fable 5.1",
                      "claude-sonnet-5-5": "Claude Sonnet 5.5", "claude-haiku-5-5": "Claude Haiku 5.5"]
        let opusItem = menuItem("model-menu-claude-opus-5-5", "Claude Opus 5.5", app)
        XCTAssertTrue(opusItem.waitForExistence(timeout: 4), "Claude's models are in its submenu")
        for (id, name) in models {
            let item = menuItem("model-menu-\(id)", name, app)
            XCTAssertTrue(item.exists, "\(name) can be chosen")
            print("CLAUDE model item '\(item.label)' y=\(Int(item.frame.minY))")
            XCTAssertLessThanOrEqual(opusItem.frame.minY, item.frame.minY, "Opus 5.5 first")
        }
        let topShown = opusItem.label.contains("最上級")
            || app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "Fieluaの最上級")).firstMatch.exists
        XCTAssertTrue(topShown, "Opus 5.5 at 超高 is Fielua's top")
        capture("claude-model-menu", app: app)
        menuItem("model-menu-claude-haiku-5-5", "Claude Haiku 5.5", app).tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        let haikuLine = app.staticTexts["chat-model-line"]
        print("CLAUDE haiku line='\(haikuLine.exists ? haikuLine.label : "none")' pill='\(chip.label)'")
        XCTAssertTrue(haikuLine.label.contains("Claude Haiku 5.5") && haikuLine.label.contains("外部AI"))
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["テスト用のClaudeが答えています。受け取った発言は1件です。"].waitForExistence(timeout: 20),
                      "Haiku 5.5 answered a new chat")

        // A phone model starts a chat on the phone.
        input.tap()
        chip.tap()
        let gemma = menuItem("model-menu-gemma", "Gemma 4", app)
        XCTAssertTrue(gemma.waitForExistence(timeout: 3))
        gemma.tap()
        let e4b = menuItem("model-menu-gemma-4-e4b", "Gemma 4 E4B", app)
        XCTAssertTrue(e4b.waitForExistence(timeout: 3))
        e4b.tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        let phoneLine = app.staticTexts["chat-model-line"]
        print("CLAUDE back on the phone line='\(phoneLine.exists ? phoneLine.label : "none")'")
        XCTAssertFalse(phoneLine.label.contains("外部AI"))
        input.tap(); input.typeText("こんにちは")
        app.buttons["送信する"].tap()
        XCTAssertTrue(app.staticTexts["プレビュー用の返信です。入力欄・吹き出し・スクロールを確認できます。"].waitForExistence(timeout: 10),
                      "the phone's model answers")

        // Out of credit: the relay stops itself, and the chat says so.
        input.tap()
        chip.tap()
        let claudeAgain = menuItem("model-menu-claude", "Claude", app)
        XCTAssertTrue(claudeAgain.waitForExistence(timeout: 4))
        claudeAgain.tap()
        let opusAgain = menuItem("model-menu-claude-opus-5-5", "Claude Opus 5.5", app)
        XCTAssertTrue(opusAgain.waitForExistence(timeout: 4))
        opusAgain.tap()
        XCTAssertTrue(input.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        input.tap(); input.typeText("billing")
        app.buttons["送信する"].tap()
        let alert = app.alerts.firstMatch
        XCTAssertTrue(alert.waitForExistence(timeout: 15))
        let said = alert.staticTexts.allElementsBoundByIndex.map(\.label).joined(separator: " ")
        print("CLAUDE out of credit alert='\(said)'")
        XCTAssertTrue(said.contains("クレジット"), "the reason, in a few words")
        capture("claude-out-of-credit", app: app)
        alert.buttons["閉じる"].tap()
        let note = app.staticTexts["chat-claude-note"]
        _ = note.waitForExistence(timeout: 5)
        print("CLAUDE chat note='\(note.exists ? note.label : "none")'")

        // 再開 on the developer's page; Claude answers again.
        openClaude(app)
        let resume = app.buttons["claude-resume"]
        XCTAssertTrue(resume.waitForExistence(timeout: 10), "the page says the relay stopped itself")
        capture("claude-paused", app: app)
        resume.tap()
        XCTAssertTrue(gone(resume, timeout: 10))
        XCTAssertTrue(waitForLabel(status, containing: "使えます", timeout: 15))

        // 登録を解除: the relay forgets this iPhone, the chats stay.
        leave(app)
        capture("claude-left", app: app)
        app.buttons["settings-close"].tap()
        let sidebar = app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch
        if !sidebar.waitForExistence(timeout: 2) { app.buttons["会話一覧を開く"].tap() }
        XCTAssertTrue(sidebar.waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        let named = sidebar.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", "こんにちは")).count
        print("CLAUDE history after leaving rows naming こんにちは=\(named)")
        XCTAssertGreaterThan(named, 0, "the Claude chat stays in the history")
        capture("claude-history-kept", app: app)
    }

    // MARK: Helpers

    @MainActor private func openClaude(_ app: XCUIApplication) {
        let history = app.buttons["会話一覧を開く"]
        if history.waitForExistence(timeout: 10) { history.tap() }
        let gear = app.buttons["history-settings"]
        XCTAssertTrue(gear.waitForExistence(timeout: 4))
        gear.tap()
        let row = app.buttons["settings-row-claude"]
        XCTAssertTrue(row.waitForExistence(timeout: 5))
        print("CLAUDE row value=\(String(describing: row.value))")
        row.tap()
        XCTAssertTrue(app.navigationBars["Claude"].waitForExistence(timeout: 4))
    }

    /// 登録を解除 on the page, through its dialog.
    @MainActor private func leave(_ app: XCUIApplication) {
        let leave = app.buttons["claude-leave"]
        XCTAssertTrue(leave.waitForExistence(timeout: 5))
        leave.tap()
        let confirms = app.buttons.matching(identifier: "claude-leave-confirm")
        var confirm = confirms.firstMatch
        if confirm.waitForExistence(timeout: 4) {
            confirm = confirms.allElementsBoundByIndex.first { $0.isHittable } ?? confirm
        } else {
            let named = app.buttons.matching(NSPredicate(format: "label == %@", "登録を解除"))
            confirm = named.element(boundBy: max(named.count - 1, 0))
        }
        confirm.tap()
        XCTAssertTrue(app.buttons["claude-developer-toggle"].waitForExistence(timeout: 10), "nothing registered")
    }

    /// Scrolls the Claude page until the element can be tapped (the
    /// keyboard or the sheet's edge may cover it).
    @MainActor private func reveal(_ element: XCUIElement, _ app: XCUIApplication, upward: Bool = true) {
        let page = app.scrollViews["claude-settings"]
        for _ in 0..<4 where !element.isHittable && page.exists {
            if upward { page.swipeUp(velocity: .slow) } else { page.swipeDown(velocity: .slow) }
            Thread.sleep(forTimeInterval: 0.4)
        }
        print("CLAUDE reveal \(element.identifier) hittable=\(element.isHittable) keyboard=\(app.keyboards.count)")
    }

    @MainActor private func waitForLabel(_ element: XCUIElement, containing text: String, timeout: TimeInterval) -> Bool {
        let has = XCTNSPredicateExpectation(predicate: NSPredicate(format: "label CONTAINS %@", text), object: element)
        return XCTWaiter().wait(for: [has], timeout: timeout) == .completed
    }

    @MainActor private func menuItem(_ id: String, _ title: String, _ app: XCUIApplication) -> XCUIElement {
        app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                         id, title, title + ",")).firstMatch
    }

    @MainActor private func gone(_ element: XCUIElement, timeout: TimeInterval) -> Bool {
        let leaves = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [leaves], timeout: timeout) == .completed || !element.exists
    }

    @MainActor private func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
