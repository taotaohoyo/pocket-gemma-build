import XCTest

/// The preview app in Japanese, whatever the simulator's language: the
/// tests find Fielua's words in Japanese (1.1.0 (183)). A test that asks
/// for another language passes its own -AppleLanguages.
final class PreviewApp: XCUIApplication {
    override func launch() {
        if !launchArguments.contains("-AppleLanguages") { launchArguments += ["-AppleLanguages", "(ja)"] }
        super.launch()
    }
}

/// 多言語対応 (1.1.0 (183)): the first launch, 設定 with its pages, and the
/// chat with its menu, history and configuration in English, Chinese and
/// Korean, photographed for review (SHOT lang-*). Each screen's words are
/// read too: a LANG-JA line names any still written in Japanese script
/// (kana, and for English and Korean kanji; for Chinese, characters only
/// Japanese writes that way). A language Fielua doesn't have shows English.
final class LanguageUITests: XCTestCase {
    private struct Language {
        let code: String
        let settings: String
        let next: String
    }

    private static let english = Language(code: "en", settings: "Settings", next: "Continue")
    private static let chinese = Language(code: "zh-Hans", settings: "设置", next: "继续")
    private static let korean = Language(code: "ko", settings: "설정", next: "계속")

    @MainActor func testOnboardingInEnglish() { onboarding(Self.english) }
    @MainActor func testOnboardingInChinese() { onboarding(Self.chinese) }
    @MainActor func testOnboardingInKorean() { onboarding(Self.korean) }
    @MainActor func testSettingsInEnglish() { settings(Self.english) }
    @MainActor func testSettingsInChinese() { settings(Self.chinese) }
    @MainActor func testSettingsInKorean() { settings(Self.korean) }
    @MainActor func testChatInEnglish() { chat(Self.english) }
    @MainActor func testChatInChinese() { chat(Self.chinese) }
    @MainActor func testChatInKorean() { chat(Self.korean) }

    /// French isn't one of Fielua's languages: English, not Japanese.
    @MainActor func testOtherLanguagesFallBackToEnglish() {
        continueAfterFailure = false
        for (code, next) in [("fr", "Continue"), ("ja", "続ける")] {
            let app = XCUIApplication()
            app.launchArguments = ["-AppleLanguages", "(\(code))", "--startup", "--reset-startup", "--reset-settings"]
            app.launch()
            let welcome = app.buttons["onboarding-welcome-continue"]
            XCTAssertTrue(welcome.waitForExistence(timeout: 10))
            print("LANG fallback \(code) continue='\(welcome.label)'")
            XCTAssertEqual(welcome.label, next, "\(code) shows \(next)")
            if code == "ja" {
                // Japanese as it was: the model page, for comparison.
                welcome.tap()
                XCTAssertTrue(app.buttons["onboarding-model-continue"].waitForExistence(timeout: 5))
                Thread.sleep(forTimeInterval: 0.6)
                let attachment = XCTAttachment(screenshot: app.screenshot())
                attachment.name = "lang-ja-2-model"
                attachment.lifetime = .keepAlways
                add(attachment)
            }
            app.terminate()
        }
    }

    @MainActor private func onboarding(_ language: Language) {
        continueAfterFailure = false
        let app = launch(language, ["--startup", "--reset-startup", "--reset-settings", "--fresh-install", "--download-progress"])
        let welcome = app.buttons["onboarding-welcome-continue"]
        XCTAssertTrue(welcome.waitForExistence(timeout: 10))
        XCTAssertEqual(welcome.label, language.next)
        Thread.sleep(forTimeInterval: 1.2)
        look("1-welcome", language, app)
        welcome.tap()
        XCTAssertTrue(app.buttons["onboarding-model-continue"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.6)
        look("2-model", language, app)
        let list = app.descendants(matching: .any)["onboarding-model-list"].firstMatch
        if list.exists { drag(list); look("2-model-notes", language, app) }
        app.buttons["onboarding-model-continue"].tap()
        XCTAssertTrue(app.buttons["onboarding-keyboard-continue"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.4)
        look("3-keyboard", language, app)
        app.buttons["onboarding-keyboard-continue"].tap()
        XCTAssertTrue(app.buttons["onboarding-launch-continue"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 1.4)
        look("4-launch", language, app)
        app.buttons["onboarding-launch-continue"].tap()
        let start = app.buttons["onboarding-ready-start"]
        XCTAssertTrue(start.waitForExistence(timeout: 5))
        look("5-ready-downloading", language, app)
        expectation(for: NSPredicate(format: "isEnabled == true"), evaluatedWith: start)
        waitForExpectations(timeout: 12)
        Thread.sleep(forTimeInterval: 0.5)
        look("5-ready", language, app)
        start.tap()
        XCTAssertTrue(app.buttons["chat-add-menu"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        look("6-chat", language, app)
    }

    @MainActor private func settings(_ language: Language) {
        continueAfterFailure = false
        let app = launch(language, ["--reset-settings"])
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        plus.tap()
        let item = app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                                    "設定", language.settings, language.settings + ",")).firstMatch
        XCTAssertTrue(item.waitForExistence(timeout: 3), "\(language.settings) is in the menu")
        item.tap()
        XCTAssertTrue(app.buttons["settings-row-models"].waitForExistence(timeout: 5))
        Thread.sleep(forTimeInterval: 0.8)
        look("settings-home", language, app)
        let row = app.buttons["settings-row-language"]
        print("LANG \(language.code) language-row label='\(row.label)' value='\(row.value as? String ?? "")'")
        open("models", language, app)
        let list = app.scrollViews["model-list"]
        for page in 1...3 {
            drag(list)
            look("settings-models-\(page)", language, app)
        }
        app.buttons["settings-back"].tap()
        open("keyboard", language, app, wait: 1.4)
        drag(app)
        look("settings-keyboard-2", language, app)
        app.buttons["settings-back"].tap()
        open("notifications", language, app)
        app.buttons["settings-back"].tap()
        open("about", language, app)
    }

    @MainActor private func chat(_ language: Language) {
        continueAfterFailure = false
        let app = launch(language, ["--reset-settings"])
        let plus = app.buttons["chat-add-menu"]
        XCTAssertTrue(plus.waitForExistence(timeout: 10))
        Thread.sleep(forTimeInterval: 0.8)
        look("chat", language, app)
        plus.tap()
        let settings = app.buttons.matching(NSPredicate(format: "identifier == %@ OR label == %@ OR label BEGINSWITH %@",
                                                        "設定", language.settings, language.settings + ",")).firstMatch
        XCTAssertTrue(settings.waitForExistence(timeout: 3))
        Thread.sleep(forTimeInterval: 0.6)
        look("chat-menu", language, app)
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.35)).tap()
        XCTAssertTrue(gone(settings))
        let history = app.buttons["chat-history"]
        XCTAssertTrue(history.waitForExistence(timeout: 3))
        history.tap()
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "history-sidebar").firstMatch.waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.8)
        look("chat-history", language, app)
        app.descendants(matching: .any)["history-close"].firstMatch.tap()
        XCTAssertTrue(app.buttons["chat-model-settings"].waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.6)
        app.buttons["chat-model-settings"].tap()
        XCTAssertTrue(app.textFields["setting-Max Tokens"].waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: 0.8)
        look("chat-configuration", language, app)
        app.segmentedControls["configuration-tabs"].buttons.element(boundBy: 1).tap()
        Thread.sleep(forTimeInterval: 0.8)
        look("chat-configuration-prompt", language, app)
        app.buttons["configuration-cancel"].tap()
        XCTAssertTrue(plus.waitForExistence(timeout: 4))
    }

    @MainActor private func launch(_ language: Language, _ arguments: [String]) -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["-AppleLanguages", "(\(language.code))"] + arguments
        app.launch()
        return app
    }

    /// A 設定 row's page, photographed once it has slid in.
    @MainActor private func open(_ page: String, _ language: Language, _ app: XCUIApplication, wait: TimeInterval = 0.8) {
        let row = app.buttons["settings-row-\(page)"]
        XCTAssertTrue(row.waitForExistence(timeout: 5), "設定 is on its rows")
        row.tap()
        XCTAssertTrue(app.buttons["settings-back"].waitForExistence(timeout: 4))
        Thread.sleep(forTimeInterval: wait)
        look("settings-\(page)", language, app)
    }

    /// Up by most of a screen, held at its end so the list stops there.
    @MainActor private func drag(_ element: XCUIElement) {
        element.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.8))
            .press(forDuration: 0.05, thenDragTo: element.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.3)),
                   withVelocity: .slow, thenHoldForDuration: 0.4)
        Thread.sleep(forTimeInterval: 0.4)
    }

    @MainActor private func gone(_ element: XCUIElement) -> Bool {
        let wait = XCTNSPredicateExpectation(predicate: NSPredicate(format: "exists == false"), object: element)
        return XCTWaiter().wait(for: [wait], timeout: 3) == .completed
    }

    /// The screen as SHOT lang-<language>-<name>, and its words read: LANG
    /// with how many were read, LANG-JA for each in Japanese script.
    @MainActor private func look(_ name: String, _ language: Language, _ app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "lang-\(language.code)-\(name)"
        attachment.lifetime = .keepAlways
        add(attachment)
        guard let snapshot = try? app.snapshot() else { return print("LANG \(language.code) \(name) no snapshot") }
        var words: [(type: XCUIElement.ElementType, text: String)] = []
        func read(_ element: XCUIElementSnapshot) {
            for text in [element.label, element.value as? String ?? "", element.placeholderValue ?? "", element.title]
                where !text.isEmpty {
                words.append((element.elementType, text))
            }
            element.children.forEach(read)
        }
        read(snapshot)
        var seen = Set<String>()
        let japanese = words.filter { Self.isJapanese($0.text, chinese: language.code == "zh-Hans") && seen.insert($0.text).inserted }
        print("LANG \(language.code) \(name) words=\(words.count) japanese=\(japanese.count)")
        for word in japanese.prefix(40) {
            print("LANG-JA \(language.code) \(name) \(word.type.rawValue) '\(word.text.prefix(160).replacingOccurrences(of: "\n", with: "⏎"))'")
        }
    }

    /// Kana anywhere; kanji in English and Korean; in Chinese, the kanji
    /// Japanese writes its own way (続 for 续, 設 for 设, …).
    private static func isJapanese(_ text: String, chinese: Bool) -> Bool {
        let japaneseOnly = Set("続設読話覧択際開閉戻時間気済録証確認変換説書選語様機細詳歴応検覚記")
        return text.unicodeScalars.contains { scalar in
            switch scalar.value {
            case 0x3040...0x30FF, 0xFF66...0xFF9F: true
            case 0x4E00...0x9FFF: chinese ? japaneseOnly.contains(Character(scalar)) : true
            default: false
            }
        }
    }
}
