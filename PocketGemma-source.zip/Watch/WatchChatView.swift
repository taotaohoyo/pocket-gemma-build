import SwiftUI
import WatchKit
#if DEBUG
import os
#endif

/// The watch's conversation, laid out like Fielua on the iPhone: questions
/// in blue bubbles with a tail on the right, answers flat and full width,
/// the Aurora light while the iPhone gets ready, and the classic composer
/// (a glass capsule with the blue send circle, which turns into stop while
/// the answer is written) floating over the bottom. Scrolling the
/// conversation folds the composer into the chat button, as the iPhone's
/// 縮小型 composer does, and it unfolds at the conversation's end. The
/// iPhone's chats are a tap away at the top leading corner.
struct WatchChatView: View {
    @EnvironmentObject private var session: WatchSession
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.isLuminanceReduced) private var luminanceReduced
    @Environment(\.scenePhase) private var scenePhase
    @State private var showingChats = false
    /// The composer's fold: 0 the field, 1 the chat button (animated).
    @State private var morph: CGFloat = 0
    @State private var folded = false
    @State private var composerWidth: CGFloat = 0
    /// Scrolling the app does itself (to a new question) folds nothing.
    @State private var ownScrollUntil = Date.distantPast
    #if DEBUG
    /// The scroll geometry, shown in the CI's scroll and morph previews.
    @State private var probe = ""
    #endif

    var body: some View {
        NavigationStack {
            ZStack {
                if session.exchanges.isEmpty {
                    WatchWelcome(loading: session.loading)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    conversation
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                composer
                    .background(alignment: .bottom) {
                        // The scroll edge's soft fade, as under iOS's
                        // composer: the answer fades into black behind
                        // the field and doesn't show below it, in the
                        // watch's rounded bottom corners. Folded, the
                        // conversation shows beside the chat button.
                        LinearGradient(colors: [.black.opacity(0), .black],
                                       startPoint: .top, endPoint: UnitPoint(x: 0.5, y: 0.5))
                            .padding(.top, -WatchMetrics.fade)
                            .ignoresSafeArea(edges: .bottom)
                            .opacity(1 - min(1, max(0, morph)))
                            .allowsHitTesting(false)
                    }
            }
            .navigationTitle("Fielua")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showingChats = true } label: {
                        Image(systemName: "bubble.left.and.bubble.right")
                    }
                    .accessibilityLabel("会話一覧")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        withAnimation(reduceMotion ? nil : .smooth(duration: 0.3)) { session.startOver() }
                        setFolded(false)
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                    .disabled(session.isAnswering || session.exchanges.isEmpty)
                    .accessibilityLabel("新しい会話")
                }
            }
            .navigationDestination(isPresented: $showingChats) { WatchChatsView() }
        }
        .onAppear {
            session.refresh()
            #if DEBUG
            playPreview()
            #endif
        }
        // Back on the wrist: the iPhone's latest list, and chat if it changed.
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { session.refresh() }
        }
    }

    private var conversation: some View {
        ScrollViewReader { reader in
            ScrollView {
                VStack(alignment: .leading, spacing: WatchMetrics.exchangeGap) {
                    if let shown = session.shown, shown.earlier > 0 || !shown.watchModel {
                        WatchChatNote(chat: shown)
                    }
                    ForEach(session.exchanges) { exchange in
                        WatchExchangeView(exchange: exchange)
                            .id(exchange.id)
                    }
                }
                .padding(.horizontal, WatchMetrics.gutter)
                .padding(.bottom, WatchMetrics.gutter)
            }
            #if DEBUG
            .overlay(alignment: .topLeading) {
                if session.preview == "scroll" || session.preview == "morph" {
                    Text("\(folded ? "folded" : "open") \(probe)").font(.system(size: 9)).foregroundStyle(.green)
                        .allowsHitTesting(false)
                }
            }
            .onScrollGeometryChange(for: String.self) { geometry in
                String(format: "c%.0f k%.0f t%.0f b%.0f o%.0f", geometry.contentSize.height,
                       geometry.containerSize.height, geometry.contentInsets.top, geometry.contentInsets.bottom,
                       geometry.contentOffset.y)
            } action: { _, new in
                probe = new
            }
            #endif
            .onScrollGeometryChange(for: ScrollSpot.self) { geometry in
                // watchOS gives the container without the insets of the
                // bar and the composer (measured in CI: 106 pt between 62
                // and 80 on a 46 mm watch, the end at 1024 - 106 - 62).
                ScrollSpot(offset: geometry.contentOffset.y,
                           below: geometry.contentSize.height - geometry.containerSize.height
                               - geometry.contentInsets.top - geometry.contentOffset.y)
            } action: { old, new in
                scrolled(from: old, to: new)
            }
            // A new question goes to the top, so its answer is read from
            // the start as it is written (the Digital Crown scrolls on).
            .onChange(of: session.exchanges.last?.id) { _, id in
                guard let id else { return }
                ownScrollUntil = Date().addingTimeInterval(0.8)
                withAnimation(reduceMotion ? nil : .smooth(duration: 0.35)) {
                    reader.scrollTo(id, anchor: .top)
                }
            }
            .onChange(of: session.conversation) {
                ownScrollUntil = Date().addingTimeInterval(0.8)
                setFolded(false)
            }
            .onAppear {
                ownScrollUntil = Date().addingTimeInterval(0.8)
                if let id = session.exchanges.last?.id { reader.scrollTo(id, anchor: .top) }
                #if DEBUG
                playScrollPreview(reader)
                #endif
            }
        }
    }

    private var composer: some View {
        WatchComposerBar(progress: morph, width: composerWidth, folded: folded, answering: session.isAnswering,
                         reduceMotion: reduceMotion,
                         onAsk: { text in
                             session.ask(text)
                             setFolded(false)
                         },
                         onStop: { session.stop() })
            .frame(maxWidth: .infinity, alignment: .trailing)
            .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { composerWidth = $0 }
            .frame(height: WatchMetrics.field)
            .padding(.horizontal, WatchMetrics.gutter)
            .padding(.top, 4)
    }

    /// Folds once the person scrolls the conversation with more of it
    /// below; unfolds at its end. Growing text (an answer being written)
    /// moves nothing, so it folds nothing.
    private func scrolled(from old: ScrollSpot, to new: ScrollSpot) {
        #if DEBUG
        WatchTrace.log.notice("scrolled below \(Double(new.below), privacy: .public) offset \(Double(old.offset), privacy: .public) -> \(Double(new.offset), privacy: .public) folded \(folded, privacy: .public)")
        #endif
        if new.below <= WatchMetrics.unfoldNear {
            if folded { setFolded(false) }
            return
        }
        guard !folded, Date() > ownScrollUntil, abs(new.offset - old.offset) > 1,
              new.below > WatchMetrics.foldBeyond else { return }
        setFolded(true)
    }

    private func setFolded(_ fold: Bool) {
        #if DEBUG
        WatchTrace.log.notice("setFolded \(fold, privacy: .public) folded \(folded, privacy: .public) morph \(Double(morph), privacy: .public)")
        #endif
        guard fold != folded || morph != (fold ? 1 : 0) else { return }
        folded = fold
        // Scroll callbacks run in transactions without animation.
        Task { @MainActor in
            #if DEBUG
            WatchTrace.log.notice("fold task \(fold, privacy: .public) folded \(folded, privacy: .public) dim \(luminanceReduced, privacy: .public)")
            #endif
            guard folded == fold else { return }
            if luminanceReduced {
                morph = fold ? 1 : 0
            } else {
                withAnimation(reduceMotion ? WatchMotion.reduced : fold ? WatchMotion.fold : WatchMotion.unfold) {
                    morph = fold ? 1 : 0
                }
            }
        }
    }

    #if DEBUG
    /// CI screenshots and frame sheets (scripts/check-watch-ui.sh).
    private func playPreview() {
        WatchTrace.log.notice("preview \(session.preview ?? "-", privacy: .public)")
        switch session.preview {
        case "history":
            // As a tap would, once the screen is up.
            Task { @MainActor in
                try? await Task.sleep(for: .seconds(1.5))
                showingChats = true
            }
        case "folded", "folded-answering":
            folded = true
            morph = 1
        case "morph":
            WatchMotion.slowdown = 8
            Task { @MainActor in
                try? await Task.sleep(for: .seconds(3))
                WatchTrace.log.notice("morph fold")
                setFolded(true)
                try? await Task.sleep(for: .seconds(14))
                WatchTrace.log.notice("morph unfold")
                setFolded(false)
            }
        default: break
        }
    }

    /// Scrolls as a person would: into the middle, which folds the
    /// composer, then to the end, which unfolds it.
    private func playScrollPreview(_ reader: ScrollViewProxy) {
        guard session.preview == "scroll", session.exchanges.count > 2 else { return }
        let middle = session.exchanges[1].id, last = session.exchanges[session.exchanges.count - 1].id
        Task { @MainActor in
            reader.scrollTo(session.exchanges[0].id, anchor: .top)
            try? await Task.sleep(for: .seconds(5))
            withAnimation(.smooth(duration: 0.4)) { reader.scrollTo(middle, anchor: .top) }
            try? await Task.sleep(for: .seconds(10))
            withAnimation(.smooth(duration: 0.4)) { reader.scrollTo(last, anchor: .bottom) }
        }
    }
    #endif
}

#if DEBUG
/// The fold's steps, for the CI's log (scripts/check-watch-ui.sh).
enum WatchTrace {
    static let log = Logger(subsystem: "app.pocketgemma.watch.preview", category: "fold")
    @MainActor private static var lastBar = Date.distantPast

    /// The composer drawn at `progress`, four times a second at most.
    @MainActor static func bar(_ progress: CGFloat) {
        guard Date().timeIntervalSince(lastBar) > 0.25 else { return }
        lastBar = Date()
        log.notice("bar \(Double(progress), privacy: .public)")
    }
}
#endif

/// Where the conversation is scrolled: its offset, and how much of it is
/// below the screen.
private struct ScrollSpot: Equatable {
    var offset: CGFloat
    var below: CGFloat
}

/// iOS Fielua's classic field (ChatView.classicField), which folds into
/// the 縮小型 composer's chat button (ComposerPanelMorph): the glass draws
/// in toward the send circle at its trailing end, a little thinner while
/// it is pulled, and swells as it gathers into a drop that settles as the
/// button. The field keeps its layout inside and is clipped by the glass,
/// its prompt gone first; the send circle's blue melts into the glass and
/// the speech bubble arrives as the drop settles. While an answer is
/// written the circle stays, as stop. With Reduce Motion the two
/// cross-fade in place.
///
/// The prompt and the send circle open the watch's own input (dictation,
/// Scribble or the keyboard), and so does the chat button; the question is
/// sent when that is done: a watch has no field to type into in place.
private struct WatchComposerBar: View, Animatable {
    var progress: CGFloat
    let width: CGFloat
    let folded: Bool
    let answering: Bool
    let reduceMotion: Bool
    let onAsk: (String) -> Void
    let onStop: () -> Void

    var animatableData: CGFloat {
        get { progress }
        set { progress = newValue }
    }

    var body: some View {
        let side = WatchMetrics.field
        let q = min(1, max(0, progress)), over = max(0, progress - 1)
        // Before the bar is measured: the screen's width less the gutters.
        let full = max(width > 0 ? width : WKInterfaceDevice.current().screenBounds.width - 2 * WatchMetrics.gutter, side)
        let size = shapeSize(full: full, side: side, q: q, over: over)
        #if DEBUG
        let _ = WatchTrace.bar(progress)
        #endif
        let shape = RoundedRectangle(cornerRadius: min(size.width, size.height) / 2, style: .continuous)
        let prompt = reduceMotion ? 1 - q : 1 - WatchMotion.step(0, 0.22, q)
        let melt = answering ? 0 : reduceMotion ? q : WatchMotion.step(0.35, 0.75, q)
        let arrow = answering ? 1 : reduceMotion ? 1 - q : 1 - WatchMotion.step(0.15, 0.45, q)
        let bubble = answering ? 0 : reduceMotion ? q : WatchMotion.step(0.62, 0.9, q)
        ZStack(alignment: .trailing) {
            HStack(spacing: 0) {
                TextFieldLink(prompt: Text("質問してみよう")) {
                    Text("質問してみよう")
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .padding(.leading, WatchMetrics.fieldInset)
                        .frame(maxWidth: .infinity, minHeight: side, alignment: .leading)
                        .contentShape(.rect)
                } onSubmit: { onAsk($0) }
                .buttonStyle(.plain)
                .disabled(answering)
                .opacity(prompt)
                .accessibilityIdentifier("watch-composer")
                if answering {
                    Button(action: onStop) { sendCircle("stop.fill", fill: 1, glyph: 1) }
                        .buttonStyle(.plain)
                        .accessibilityLabel("回答を停止する")
                        .transition(.opacity)
                } else {
                    TextFieldLink(prompt: Text("質問してみよう")) {
                        sendCircle("arrow.up", fill: 1 - melt, glyph: arrow)
                    } onSubmit: { onAsk($0) }
                    .buttonStyle(.plain)
                    .accessibilityLabel("質問を書いて送る")
                    .transition(.opacity)
                }
            }
            .frame(width: full, height: side)
            .allowsHitTesting(!folded)
            .accessibilityHidden(folded)
            // The chat button's speech bubble, as on the iPhone.
            Image(systemName: "message")
                .font(.system(size: WatchMetrics.chatGlyph, weight: .medium))
                .foregroundStyle(.primary)
                .scaleEffect(reduceMotion ? 1 : 0.6 + 0.4 * bubble)
                .opacity(bubble)
                .frame(width: side, height: side)
                .allowsHitTesting(false)
                .accessibilityHidden(true)
            if folded { foldedButton }
        }
        .animation(reduceMotion ? nil : .smooth(duration: 0.2), value: answering)
        .frame(width: full, height: side, alignment: .trailing)
        .frame(width: size.width, height: size.height, alignment: .trailing)
        .clipShape(shape)
        .glassEffect(.regular, in: shape)
    }

    /// The glass along the fold: drawn in to the trailing circle (most of
    /// it by 0.7), a little thinner while it is pulled, swelling by a few
    /// points as it gathers and settling; past 1, the spring's overshoot
    /// squashes it a touch. With Reduce Motion it changes over at half way.
    private func shapeSize(full: CGFloat, side: CGFloat, q: CGFloat, over: CGFloat) -> CGSize {
        if reduceMotion { return CGSize(width: q < 0.5 ? full : side, height: side) }
        let narrow = WatchMotion.step(0, 0.7, q)
        let thin = WatchMotion.step(0, 0.25, q) * (1 - WatchMotion.step(0.25, 0.55, q))
        let swell = WatchMotion.step(0.45, 0.8, q) * (1 - WatchMotion.step(0.8, 1, q))
        return CGSize(width: full + (side - full) * narrow + 3 * swell - 4 * over,
                      height: side - 3 * thin + 4 * swell + 6 * over)
    }

    /// Folded, the whole button opens the input, or stops the answer.
    @ViewBuilder private var foldedButton: some View {
        let target = Color.clear
            .frame(width: WatchMetrics.field, height: WatchMetrics.field)
            .contentShape(.circle)
        if answering {
            Button(action: onStop) { target }
                .buttonStyle(.plain)
                .accessibilityLabel("回答を停止する")
        } else {
            TextFieldLink(prompt: Text("質問してみよう")) { target } onSubmit: { onAsk($0) }
                .buttonStyle(.plain)
                .accessibilityLabel("質問を入力する")
                .accessibilityIdentifier("watch-chat-button")
        }
    }

    /// The same circle as iOS Fielua's (ChatView.sendButton): a white
    /// glyph on blue in a full-height target.
    private func sendCircle(_ symbol: String, fill: CGFloat, glyph: CGFloat) -> some View {
        Image(systemName: symbol)
            .font(.system(size: symbol == "stop.fill" ? WatchMetrics.glyph - 5 : WatchMetrics.glyph, weight: .bold))
            .foregroundStyle(.white)
            .opacity(glyph)
            .frame(width: WatchMetrics.sendCircle, height: WatchMetrics.sendCircle)
            .background(WatchTheme.accent.opacity(fill), in: .circle)
            .frame(width: WatchMetrics.field, height: WatchMetrics.field)
            .contentShape(.circle)
            .accessibilityIdentifier("watch-send")
    }
}

/// The first screen: the light and the name.
private struct WatchWelcome: View {
    /// A chat from the iPhone is on its way: the light breathes.
    let loading: Bool

    var body: some View {
        VStack(spacing: 8) {
            WatchOrb(still: !loading)
            Text("Fielua")
                .font(.system(.title3, design: .serif))
                .opacity(loading ? 0 : 1)
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel(loading ? "iPhoneから読み込んでいます" : "Fielua")
    }
}

/// Above a chat from the iPhone: the older messages left there, and the
/// model that answers on the watch when the chat is another's.
private struct WatchChatNote: View {
    let chat: WatchShownChat

    var body: some View {
        VStack(spacing: 2) {
            if chat.earlier > 0 { Text("前の\(chat.earlier)件はiPhoneにあります") }
            if !chat.watchModel { Text("\(chat.model)の会話・WatchではE2Bが答えます") }
        }
        .font(.footnote)
        .foregroundStyle(.secondary)
        .multilineTextAlignment(.center)
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .combine)
    }
}

/// One question and its answer.
private struct WatchExchangeView: View {
    let exchange: WatchExchange
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if !exchange.question.isEmpty {
                Text(exchange.question)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .padding(.trailing, WatchBubble.tail)
                    .background(WatchTheme.accent, in: WatchBubble())
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(.leading, WatchMetrics.bubbleLead)
                    .accessibilityLabel("質問: \(exchange.question)")
            }
            if let count = exchange.attachments, count > 0 {
                Label("\(count)", systemImage: "paperclip")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .accessibilityLabel("写真やファイル\(count)件はiPhoneで見られます")
            }
            answer
        }
        // The light gives way to the first words.
        .animation(reduceMotion ? nil : .smooth(duration: 0.3), value: exchange.state)
    }

    @ViewBuilder private var answer: some View {
        let state = exchange.linkState
        if !exchange.answer.isEmpty {
            Text(WatchMarkdown.text(exchange.answer))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        if exchange.clipped == true {
            note("続きはiPhoneで読めます", symbol: "iphone")
        }
        switch state {
        case .waiting:
            HStack(spacing: 4) {
                WatchOrb()
                if let detail = exchange.detail {
                    Text(detail).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                }
            }
            .transition(.opacity)
        case .writing, .finished:
            EmptyView()
        case .paused:
            note(exchange.detail ?? "iPhoneでFieluaを開くと続きを書きます", symbol: "iphone")
        case .stopped:
            note(exchange.detail ?? "止めました", symbol: "stop.circle")
        case .failed, .refused:
            note(exchange.detail ?? "iPhoneで答えられませんでした", symbol: "exclamationmark.circle")
        }
    }

    private func note(_ text: String, symbol: String) -> some View {
        Label(text, systemImage: symbol)
            .font(.footnote)
            .foregroundStyle(.secondary)
    }
}
