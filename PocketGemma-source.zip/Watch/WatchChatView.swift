import SwiftUI

/// The watch's conversation, laid out like Fielua on the iPhone: questions
/// in blue bubbles with a tail on the right, answers flat and full width,
/// the Aurora light while the iPhone gets ready, and the classic composer
/// (a glass capsule with the blue send circle, which turns into stop while
/// the answer is written) floating over the bottom.
struct WatchChatView: View {
    @EnvironmentObject private var session: WatchSession
    @State private var draft = ""
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        NavigationStack {
            ScrollViewReader { reader in
                ScrollView {
                    VStack(alignment: .leading, spacing: WatchMetrics.exchangeGap) {
                        if session.exchanges.isEmpty {
                            WatchWelcome(reachable: session.reachable)
                        }
                        ForEach(session.exchanges) { exchange in
                            WatchExchangeView(exchange: exchange)
                                .id(exchange.id)
                        }
                    }
                    .padding(.horizontal, WatchMetrics.gutter)
                    .padding(.bottom, WatchMetrics.gutter)
                }
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    composer
                }
                // A new question goes to the top, so its answer is read from
                // the start as it is written (the Digital Crown scrolls on).
                .onChange(of: session.exchanges.last?.id) { _, id in
                    guard let id else { return }
                    withAnimation(reduceMotion ? nil : .smooth(duration: 0.35)) {
                        reader.scrollTo(id, anchor: .top)
                    }
                }
                .onAppear {
                    if let id = session.exchanges.last?.id { reader.scrollTo(id, anchor: .top) }
                }
            }
            .navigationTitle("Fielua")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        withAnimation(reduceMotion ? nil : .smooth(duration: 0.3)) { session.startOver() }
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                    .disabled(session.isAnswering || session.exchanges.isEmpty)
                    .accessibilityLabel("新しい会話")
                }
            }
        }
    }

    /// iOS Fielua's classic field (ChatView.classicField): the text in a
    /// glass capsule, the send circle at its trailing end. The field opens
    /// the watch's own input (dictation, Scribble or the keyboard), and the
    /// question is sent when that is done.
    private var composer: some View {
        HStack(spacing: 4) {
            TextField("質問してみよう", text: $draft)
                .textFieldStyle(.plain)
                .submitLabel(.send)
                .onSubmit(send)
                .lineLimit(1)
                .padding(.leading, WatchMetrics.fieldInset)
                .accessibilityIdentifier("watch-composer")
            sendButton
        }
        .frame(minHeight: WatchMetrics.field)
        .glassEffect(.regular, in: .capsule)
        .padding(.horizontal, WatchMetrics.gutter)
        .padding(.top, 4)
    }

    private var canSend: Bool {
        !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    /// The same circle as iOS Fielua's (ChatView.sendButton): a white arrow
    /// on blue, gray while there is nothing to send, stop while answering.
    private var sendButton: some View {
        Button {
            if session.isAnswering { session.stop() } else { send() }
        } label: {
            Image(systemName: session.isAnswering ? "stop.fill" : "arrow.up")
                .contentTransition(reduceMotion ? .identity : .symbolEffect(.replace))
                .font(.system(size: session.isAnswering ? WatchMetrics.glyph - 5 : WatchMetrics.glyph, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: WatchMetrics.sendCircle, height: WatchMetrics.sendCircle)
                .background(session.isAnswering || canSend ? WatchTheme.accent : WatchTheme.idleSend, in: .circle)
                .frame(width: WatchMetrics.field, height: WatchMetrics.field)
                .contentShape(.circle)
        }
        .buttonStyle(.plain)
        .disabled(!session.isAnswering && !canSend)
        .accessibilityLabel(session.isAnswering ? "回答を停止する" : "送信する")
        .accessibilityIdentifier("watch-send")
    }

    private func send() {
        guard canSend, !session.isAnswering else { return }
        session.ask(draft)
        draft = ""
    }
}

/// The first screen: the light and the name, and where the answers come
/// from.
private struct WatchWelcome: View {
    let reachable: Bool

    var body: some View {
        VStack(spacing: 6) {
            WatchOrb(still: true)
            Text("Fielua")
                .font(.system(.title3, design: .serif))
            Text(reachable ? "iPhoneのGemma 4 E2Bが答えます" : "iPhoneを近くに置いてください")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .accessibilityElement(children: .combine)
    }
}

/// One question and its answer.
private struct WatchExchangeView: View {
    let exchange: WatchExchange
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(exchange.question)
                .foregroundStyle(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .padding(.trailing, WatchBubble.tail)
                .background(WatchTheme.accent, in: WatchBubble())
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.leading, WatchMetrics.bubbleLead)
                .accessibilityLabel("質問: \(exchange.question)")
            answer
        }
        // The light gives way to the first words.
        .animation(reduceMotion ? nil : .smooth(duration: 0.3), value: exchange.state)
    }

    @ViewBuilder private var answer: some View {
        let state = exchange.linkState
        if !exchange.answer.isEmpty {
            Text(WatchMarkdown.text(exchange.answer))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        switch state {
        case .waiting:
            HStack(spacing: 4) {
                WatchOrb()
                if let detail = exchange.detail {
                    Text(detail).font(.footnote).foregroundStyle(.secondary).lineLimit(2)
                }
            }
            .transition(.opacity)
        case .writing, .finished:
            EmptyView()
        case .paused:
            note(exchange.detail ?? "iPhoneでFieluaを開くと続きを書きます", symbol: "iphone")
        case .stopped:
            note(exchange.detail ?? "止めました", symbol: "stop.circle")
        case .failed, .refused:
            note(exchange.detail ?? "iPhoneで答えられませんでした", symbol: "exclamationmark.circle")
        }
    }

    private func note(_ text: String, symbol: String) -> some View {
        Label(text, systemImage: symbol)
            .font(.footnote)
            .foregroundStyle(.secondary)
    }
}
