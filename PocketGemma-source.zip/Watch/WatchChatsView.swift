import SwiftUI

/// The iPhone's chats, the latest first, as its 会話一覧 lists them: any
/// model's, each with its first question, when it was last used and its
/// model. A tap shows the chat on the watch, where it goes on; Gemma 4 E2B
/// answers there whatever the chat's model.
struct WatchChatsView: View {
    @EnvironmentObject private var session: WatchSession
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        List {
            if session.chats.isEmpty {
                Text(session.reachable ? "会話はまだありません" : "iPhoneにつながっていません")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .listRowBackground(Color.clear)
            }
            ForEach(session.chats) { chat in
                Button {
                    session.open(chat.id)
                    dismiss()
                } label: {
                    row(chat)
                }
                .disabled(session.isAnswering && chat.id != session.conversation)
            }
        }
        .navigationTitle("会話一覧")
        .onAppear { session.refresh() }
    }

    private func row(_ chat: WatchHistory.Summary) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(chat.title)
                .lineLimit(2)
                .foregroundStyle(chat.id == session.conversation ? WatchTheme.accent : .primary)
            HStack(spacing: 4) {
                Text(chat.updated, format: .relative(presentation: .named))
                Text("・\(chat.model)")
            }
            .font(.footnote)
            .foregroundStyle(.secondary)
            .lineLimit(1)
        }
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(chat.id == session.conversation ? .isSelected : [])
    }
}
