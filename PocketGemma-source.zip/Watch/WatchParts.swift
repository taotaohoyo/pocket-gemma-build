import SwiftUI

/// Fielua's colours on the watch, as on the iPhone (Theme): the system blue
/// for questions and send, the icon's five colours for the light.
enum WatchTheme {
    static let accent = Color.blue
    /// The app icon's rainbow, red to blue (AuroraOrbShader.metal).
    static let rainbow: [Color] = [
        Color(red: 0.85, green: 0.30, blue: 0.26),
        Color(red: 0.90, green: 0.56, blue: 0.10),
        Color(red: 0.86, green: 0.66, blue: 0.04),
        Color(red: 0.10, green: 0.60, blue: 0.33),
        Color(red: 0.10, green: 0.45, blue: 0.90),
    ]
}

enum WatchMetrics {
    static let gutter: CGFloat = 4
    /// The composer capsule's height, and the send button's target.
    static let field: CGFloat = 40
    static let sendCircle: CGFloat = 28
    static let glyph: CGFloat = 15
    static let fieldInset: CGFloat = 12
    static let exchangeGap: CGFloat = 12
    /// Room a question's bubble leaves on its left.
    static let bubbleLead: CGFloat = 20
    /// How far above the composer the conversation starts to fade.
    static let fade: CGFloat = 14
    /// The chat button's speech bubble.
    static let chatGlyph: CGFloat = 17
    /// The composer folds into the chat button once the conversation is
    /// scrolled with this much of it still below, and unfolds within this
    /// of its end.
    static let foldBeyond: CGFloat = 40
    static let unfoldNear: CGFloat = 16
}

/// The composer's fold and unfold, timed as on the iPhone
/// (ChatMotion.composerFold, composerUnfold, reducedComposer).
@MainActor
enum WatchMotion {
    #if DEBUG
    /// The CI's frame sheets play the fold slower (WatchPreview `morph`).
    static var slowdown = 1.0
    #else
    static let slowdown = 1.0
    #endif
    static var fold: Animation { .spring(duration: 0.75 * slowdown, bounce: 0.12) }
    static var unfold: Animation { .timingCurve(0.45, 0, 0.25, 1, duration: 0.56 * slowdown) }
    static var reduced: Animation { .easeInOut(duration: 0.2 * slowdown) }

    /// Smoothstep from `from` to `to` (ChatMotion.step).
    nonisolated static func step(_ from: CGFloat, _ to: CGFloat, _ x: CGFloat) -> CGFloat {
        let t = min(1, max(0, (x - from) / (to - from)))
        return t * t * (3 - 2 * t)
    }
}

/// The Aurora light, small, for the watch: the icon's colours turning
/// inside a soft circle that breathes between half and full size once
/// every 3.6 seconds, as AuroraOrbView does on the iPhone (drawn without its
/// Metal shader). Held still with Reduce Motion and on the dimmed
/// always-on screen.
struct WatchOrb: View {
    let still: Bool
    static let canvas: CGFloat = 30
    static let light: CGFloat = 20
    static let smallest = 0.5
    static let breathPeriod: TimeInterval = 3.6

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.isLuminanceReduced) private var luminanceReduced
    @Environment(\.scenePhase) private var scenePhase
    @State private var started = Date()

    init(still: Bool = false) {
        self.still = still
    }

    var body: some View {
        Group {
            if still || reduceMotion || luminanceReduced {
                light(at: 0)
            } else {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: scenePhase != .active)) { context in
                    light(at: context.date.timeIntervalSince(started))
                }
            }
        }
        .frame(width: Self.canvas, height: Self.canvas)
        .allowsHitTesting(false)
        .accessibilityElement()
        .accessibilityLabel("返信を書いています")
        .accessibilityHidden(still)
    }

    private func light(at time: TimeInterval) -> some View {
        let turn = 2 * Double.pi / Self.breathPeriod
        let size = Self.smallest + 0.5 * (1 - Self.smallest) * (1 + cos(turn * time))
        return ZStack {
            Circle()
                .fill(AngularGradient(colors: WatchTheme.rainbow + [WatchTheme.rainbow[0]], center: .center,
                                      angle: .degrees(time * 40)))
                .blur(radius: 2.5)
            Circle()
                .fill(RadialGradient(colors: [.white.opacity(0.7), .white.opacity(0)], center: .center,
                                     startRadius: 0, endRadius: Self.light * 0.4))
        }
        .frame(width: Self.light, height: Self.light)
        .shadow(color: WatchTheme.rainbow[4].opacity(0.45), radius: 4)
        .scaleEffect(size)
    }
}

/// A question's bubble: iOS Fielua's outline (MessageBubble, outgoing),
/// corners of 18 with the short curved tail at the bottom right.
struct WatchBubble: Shape {
    /// The width the tail takes on the right.
    static let tail: CGFloat = 6

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let left = rect.minX, top = rect.minY, bottom = rect.maxY
        let right = rect.maxX - Self.tail
        let radius = max(0, min(18, min((rect.width - Self.tail) / 2, rect.height / 2)))
        let curve = radius * 0.5522847498
        path.move(to: CGPoint(x: left + radius, y: top))
        path.addLine(to: CGPoint(x: right - radius, y: top))
        path.addCurve(to: CGPoint(x: right, y: top + radius),
                      control1: CGPoint(x: right - radius + curve, y: top),
                      control2: CGPoint(x: right, y: top + radius - curve))
        path.addLine(to: CGPoint(x: right, y: bottom - radius))
        path.addCurve(to: CGPoint(x: rect.maxX, y: bottom),
                      control1: CGPoint(x: right, y: bottom - 7),
                      control2: CGPoint(x: right + 1, y: bottom - 3))
        path.addCurve(to: CGPoint(x: right - 8, y: bottom - 4),
                      control1: CGPoint(x: right + 1, y: bottom),
                      control2: CGPoint(x: right - 4, y: bottom - 1))
        path.addCurve(to: CGPoint(x: right - radius, y: bottom),
                      control1: CGPoint(x: right - 11, y: bottom - 1),
                      control2: CGPoint(x: right - 14, y: bottom))
        path.addLine(to: CGPoint(x: left + radius, y: bottom))
        path.addCurve(to: CGPoint(x: left, y: bottom - radius),
                      control1: CGPoint(x: left + radius - curve, y: bottom),
                      control2: CGPoint(x: left, y: bottom - radius + curve))
        path.addLine(to: CGPoint(x: left, y: top + radius))
        path.addCurve(to: CGPoint(x: left + radius, y: top),
                      control1: CGPoint(x: left, y: top + radius - curve),
                      control2: CGPoint(x: left + radius - curve, y: top))
        path.closeSubpath()
        return path
    }
}

/// An answer's Markdown, as far as a watch shows it: bold, italics, inline
/// code and links as styled text; headings bold, list items with a bullet,
/// code blocks as their lines and table rows as their cells. The iPhone's
/// chat has the whole of it.
enum WatchMarkdown {
    static func text(_ source: String) -> AttributedString {
        var lines: [String] = []
        var inCode = false
        for line in source.components(separatedBy: "\n") {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix("```") || trimmed.hasPrefix("~~~") {
                inCode.toggle()
                continue
            }
            if inCode {
                lines.append(line)
            } else if trimmed.hasPrefix("#") {
                let title = trimmed.drop { $0 == "#" }.trimmingCharacters(in: .whitespaces)
                lines.append(title.isEmpty ? "" : "**\(title)**")
            } else if let item = listItem(trimmed) {
                let depth = line.prefix { $0 == " " }.count / 2
                lines.append(String(repeating: "  ", count: depth) + "• " + item)
            } else if trimmed.hasPrefix("|") {
                let cells = trimmed.split(separator: "|").map { $0.trimmingCharacters(in: .whitespaces) }
                // The row under a table's header (|---|:---:|).
                guard !cells.allSatisfy({ $0.allSatisfy { "-:".contains($0) } }) else { continue }
                lines.append(cells.joined(separator: " ・ "))
            } else if trimmed.allSatisfy({ "-*_".contains($0) }) && trimmed.count >= 3 {
                // A thematic break.
                continue
            } else {
                lines.append(line)
            }
        }
        let text = lines.joined(separator: "\n")
        let options = AttributedString.MarkdownParsingOptions(interpretedSyntax: .inlineOnlyPreservingWhitespace,
                                                              failurePolicy: .returnPartiallyParsedIfPossible)
        return (try? AttributedString(markdown: text, options: options)) ?? AttributedString(text)
    }

    private static func listItem(_ line: String) -> String? {
        for marker in ["- ", "* ", "+ "] where line.hasPrefix(marker) {
            return String(line.dropFirst(marker.count))
        }
        return nil
    }
}
