import SwiftUI

/// Fielua on the Apple Watch (2026-10-23): a question asked here is answered
/// on the iPhone by Gemma 4 E2B and read here as it is written.
@main
struct FieluaWatchApp: App {
    @StateObject private var session = WatchSession()

    var body: some Scene {
        WindowGroup {
            WatchChatView()
                .environmentObject(session)
        }
    }
}
