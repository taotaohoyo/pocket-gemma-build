import Foundation
import WatchConnectivity
import WatchKit

/// One question and its answer on the watch.
struct WatchExchange: Codable, Identifiable, Equatable {
    var id: String
    var question: String
    var answer = ""
    var state: String = WatchLink.State.waiting.rawValue
    /// What the iPhone is doing, or why it couldn't answer.
    var detail: String? = "iPhoneに送っています"

    var linkState: WatchLink.State { WatchLink.State(rawValue: state) ?? .waiting }
}

/// The watch's side of Fielua (WatchLink): sends the question to the iPhone,
/// where Gemma 4 E2B answers it, and takes the answer as it is written. The
/// conversation is kept on the watch (the latest exchanges) and on the
/// iPhone as a chat in its history.
@MainActor
final class WatchSession: NSObject, ObservableObject {
    @Published private(set) var exchanges: [WatchExchange] = []
    @Published private(set) var reachable = false
    private var conversation = UUID().uuidString
    private static let storeKey = "exchanges"
    private static let conversationKey = "conversation"
    /// The watch keeps only the latest; the whole chat is on the iPhone.
    private static let kept = 20

    override init() {
        super.init()
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: Self.storeKey),
           let saved = try? JSONDecoder().decode([WatchExchange].self, from: data) {
            exchanges = saved
        }
        if let saved = defaults.string(forKey: Self.conversationKey) { conversation = saved }
        #if DEBUG
        // CI screenshots (scripts/check-watch-ui.sh), with no iPhone.
        if let preview = defaults.string(forKey: "WatchPreview") {
            exchanges = Self.preview(preview)
            return
        }
        #endif
        guard WCSession.isSupported() else { return }
        WCSession.default.delegate = self
        WCSession.default.activate()
    }

    var isAnswering: Bool {
        guard let last = exchanges.last else { return false }
        return !last.linkState.isFinal && last.linkState != .paused
    }

    func ask(_ raw: String) {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isAnswering else { return }
        let ask = WatchLink.Ask(id: UUID().uuidString, conversation: conversation, text: text)
        exchanges.append(WatchExchange(id: ask.id, question: text))
        if exchanges.count > Self.kept { exchanges.removeFirst(exchanges.count - Self.kept) }
        save()
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isReachable else {
            update(WatchLink.Reply(question: ask.id, text: "", state: .refused,
                                   detail: "iPhoneにつながっていません。iPhoneを近くに置いて、もう一度送ってください"))
            return
        }
        session.sendMessage(ask.message, replyHandler: { reply in
            Task { @MainActor in
                if let reply = WatchLink.Reply(reply) { self.update(reply) }
            }
        }, errorHandler: { error in
            Task { @MainActor in
                self.update(WatchLink.Reply(question: ask.id, text: "", state: .refused,
                                            detail: "iPhoneに届きませんでした（\(error.localizedDescription)）"))
            }
        })
    }

    func stop() {
        guard isAnswering, let last = exchanges.last, WCSession.default.isReachable else { return }
        WCSession.default.sendMessage(WatchLink.stop(question: last.id), replyHandler: nil, errorHandler: nil)
    }

    /// A new conversation: a new chat on the iPhone from the next question.
    func startOver() {
        guard !isAnswering else { return }
        conversation = UUID().uuidString
        exchanges = []
        UserDefaults.standard.set(conversation, forKey: Self.conversationKey)
        save()
    }

    fileprivate func update(_ reply: WatchLink.Reply) {
        guard let index = exchanges.firstIndex(where: { $0.id == reply.question }) else { return }
        var exchange = exchanges[index]
        let wasFinal = exchange.linkState.isFinal
        // A late message never takes back a newer one's text.
        guard !(wasFinal && !reply.state.isFinal), reply.text.count >= exchange.answer.count || reply.state.isFinal else { return }
        exchange.answer = reply.text
        exchange.state = reply.state.rawValue
        exchange.detail = reply.detail
        guard exchange != exchanges[index] else { return }
        exchanges[index] = exchange
        // The iPhone took a new question, so an earlier answer that waited
        // for Fielua to open there won't go on (ChatStore.askFromWatch).
        if reply.state != .refused {
            for earlier in exchanges.indices where earlier < index && exchanges[earlier].linkState == .paused {
                exchanges[earlier].state = WatchLink.State.stopped.rawValue
                exchanges[earlier].detail = "ここで止まりました"
            }
        }
        if reply.state.isFinal || reply.state == .paused { save() }
        if reply.state == .finished && !wasFinal { WKInterfaceDevice.current().play(.success) }
    }

    private func save() {
        UserDefaults.standard.set(conversation, forKey: Self.conversationKey)
        if let data = try? JSONEncoder().encode(exchanges) { UserDefaults.standard.set(data, forKey: Self.storeKey) }
    }

    #if DEBUG
    private static func preview(_ name: String) -> [WatchExchange] {
        let question = "週末に行ける温泉を3つ教えて"
        let answer = """
        ## 週末の温泉
        東京から**2時間ほど**で行ける温泉です。
        - 箱根湯本：駅から近く、日帰りもできます
        - 草津：湯畑の景色が有名です
        - 鬼怒川：川沿いの宿が多いです
        """
        switch name {
        case "answer":
            return [WatchExchange(id: "a", question: question, answer: answer, state: "finished", detail: nil)]
        case "waiting":
            return [WatchExchange(id: "w", question: question, detail: "モデルを読み込んでいます")]
        case "writing":
            return [WatchExchange(id: "r", question: question, answer: String(answer.prefix(40)), state: "writing",
                                  detail: nil)]
        case "paused":
            return [WatchExchange(id: "p", question: question, answer: String(answer.prefix(60)), state: "paused",
                                  detail: "iPhoneでFieluaを開くと続きを書きます")]
        default:
            return []
        }
    }
    #endif

    fileprivate func refreshReachability() {
        reachable = WCSession.default.isReachable
    }
}

extension WatchSession: WCSessionDelegate {
    nonisolated func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState,
                             error: Error?) {
        let context = session.receivedApplicationContext
        Task { @MainActor in
            self.refreshReachability()
            if let reply = WatchLink.Reply(context) { self.update(reply) }
        }
    }

    nonisolated func sessionReachabilityDidChange(_ session: WCSession) {
        Task { @MainActor in self.refreshReachability() }
    }

    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Task { @MainActor in
            if let reply = WatchLink.Reply(message) { self.update(reply) }
        }
    }

    nonisolated func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        Task { @MainActor in
            if let reply = WatchLink.Reply(applicationContext) { self.update(reply) }
        }
    }
}
