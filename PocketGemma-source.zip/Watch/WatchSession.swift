import Foundation
import WatchConnectivity
import WatchKit

/// One question and its answer on the watch. Its id is the question's
/// message id on the iPhone.
struct WatchExchange: Codable, Identifiable, Equatable {
    var id: String
    var question: String
    var answer = ""
    var state: String = WatchLink.State.waiting.rawValue
    /// What the iPhone is doing, or why it couldn't answer.
    var detail: String? = "iPhoneに送っています"
    /// Only the answer's start is here; the whole is on the iPhone.
    var clipped: Bool?
    /// Photos and files sent with the question, shown on the iPhone.
    var attachments: Int?
    /// Asked on this watch. An answer the iPhone is writing to its own
    /// question shows here as it stands, but only the watch's own is
    /// followed and can be stopped from here.
    var mine: Bool?

    var linkState: WatchLink.State { WatchLink.State(rawValue: state) ?? .waiting }
}

/// The chat the watch shows, as the iPhone has it: its model, and the
/// older messages left there.
struct WatchShownChat: Equatable {
    var model: String
    var watchModel: Bool
    var earlier: Int
}

/// The watch's side of Fielua (WatchLink): sends the question to the iPhone,
/// where Gemma 4 E2B answers it, and takes the answer as it is written.
///
/// The chats are the iPhone's (WatchHistory): the watch shows one of them,
/// a new one or any from the iPhone's list, by its id there, and keeps a
/// copy of the list and of the chats it opened lately. A newer list or
/// chat from the iPhone replaces the copy; nothing here deletes or changes
/// a chat on the iPhone.
@MainActor
final class WatchSession: NSObject, ObservableObject {
    @Published private(set) var exchanges: [WatchExchange] = []
    @Published private(set) var reachable = false
    /// The iPhone's chats, the latest first.
    @Published private(set) var chats: [WatchHistory.Summary] = []
    /// The chat shown: its id on the iPhone (or the id it will have there).
    @Published private(set) var conversation = UUID().uuidString
    @Published private(set) var shown: WatchShownChat?
    /// A chat opened from the list is on its way from the iPhone.
    @Published private(set) var loading = false
    private var cache = WatchHistory.Cache()
    private static let storeKey = "exchanges"
    private static let conversationKey = "conversation"
    private static let helloKey = "helloSent"
    /// The most of a chat the watch shows; the rest is on the iPhone.
    private static let kept = 30
    private static let cacheURL = URL.cachesDirectory.appending(path: "WatchHistory.json")
    #if DEBUG
    /// CI screenshots (scripts/check-watch-ui.sh): a sample, no iPhone.
    private(set) var preview: String?
    #endif

    override init() {
        super.init()
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: Self.storeKey),
           let saved = try? JSONDecoder().decode([WatchExchange].self, from: data) {
            exchanges = saved
        }
        if let saved = defaults.string(forKey: Self.conversationKey) { conversation = saved }
        #if DEBUG
        if let preview = defaults.string(forKey: "WatchPreview") {
            self.preview = preview
            Self.loadPreview(preview, into: self)
            return
        }
        #endif
        if let saved = WatchHistory.decode(WatchHistory.Cache.self, from: try? Data(contentsOf: Self.cacheURL)) {
            cache = saved
            chats = saved.list?.chats ?? []
            showPage(of: conversation)
        }
        guard WCSession.isSupported() else { return }
        WCSession.default.delegate = self
        WCSession.default.activate()
    }

    var isAnswering: Bool {
        guard let last = exchanges.last, last.mine == true else { return false }
        return !last.linkState.isFinal && last.linkState != .paused
    }

    func ask(_ raw: String) {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isAnswering else { return }
        let ask = WatchLink.Ask(id: UUID().uuidString, conversation: conversation, text: text)
        exchanges.append(WatchExchange(id: ask.id, question: text, mine: true))
        trim()
        save()
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isReachable else {
            update(WatchLink.Reply(question: ask.id, text: "", state: .refused,
                                   detail: "iPhoneにつながっていません。iPhoneを近くに置いて、もう一度送ってください"))
            return
        }
        session.sendMessage(ask.message, replyHandler: { reply in
            Task { @MainActor in
                if let reply = WatchLink.Reply(reply) { self.update(reply) }
            }
        }, errorHandler: { error in
            Task { @MainActor in
                self.update(WatchLink.Reply(question: ask.id, text: "", state: .refused,
                                            detail: "iPhoneに届きませんでした（\(error.localizedDescription)）"))
            }
        })
    }

    func stop() {
        guard isAnswering, let last = exchanges.last, WCSession.default.isReachable else { return }
        WCSession.default.sendMessage(WatchLink.stop(question: last.id), replyHandler: nil, errorHandler: nil)
    }

    /// A new conversation: a new chat on the iPhone from the next question.
    func startOver() {
        guard !isAnswering else { return }
        conversation = UUID().uuidString
        exchanges = []
        shown = nil
        loading = false
        save()
    }

    /// Shows one of the iPhone's chats: the copy at once if there is one,
    /// then the iPhone's latest.
    func open(_ chat: String) {
        guard !isAnswering else { return }
        if chat != conversation {
            conversation = chat
            exchanges = []
            shown = nil
            showPage(of: chat)
            save()
        }
        loading = exchanges.isEmpty
        requestPage(chat)
    }

    /// Asks the iPhone for the list, and so for the shown chat if it changed.
    func refresh() {
        #if DEBUG
        if preview != nil { return }
        #endif
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isReachable else {
            loading = false
            return
        }
        session.sendMessage(WatchLink.listRequest, replyHandler: { reply in
            let data = WatchLink.listData(in: reply)
            Task { @MainActor in if let data { self.takeList(data) } }
        }, errorHandler: nil)
    }

    private func requestPage(_ chat: String) {
        let session = WCSession.default
        guard WCSession.isSupported(), session.activationState == .activated, session.isReachable else {
            loading = false
            return
        }
        session.sendMessage(WatchLink.pageRequest(chat: chat), replyHandler: { reply in
            let data = WatchLink.pageData(in: reply), missing = WatchLink.missingPage(in: reply)
            Task { @MainActor in
                if let page = WatchHistory.decode(WatchHistory.Page.self, from: data) {
                    self.takePage(page)
                } else if let missing {
                    self.chatIsGone(missing)
                } else if chat == self.conversation {
                    self.loading = false
                }
            }
        }, errorHandler: { _ in
            Task { @MainActor in if chat == self.conversation { self.loading = false } }
        })
    }

    fileprivate func takeList(_ data: Data) {
        guard let list = WatchHistory.decode(WatchHistory.List.self, from: data) else { return }
        // The conversation of 1.1.0 (152) takes its chat's id.
        if let former = list.formerConversation, former == conversation, let chat = list.formerChat {
            conversation = chat
            save()
        }
        let gone = cache.apply(list)
        chats = list.chats
        saveCache()
        if gone.contains(conversation) {
            chatIsGone(conversation)
        } else if !isAnswering, list.summary(conversation) != nil, cache.needsPage(conversation) {
            requestPage(conversation)
        }
    }

    private func takePage(_ page: WatchHistory.Page) {
        cache.store(page)
        saveCache()
        guard page.chat == conversation else { return }
        // The answer being written is newer here, and the chat is read
        // again once it is done (the list says it changed); unless the
        // chat says it ended, when its last word was lost on the way.
        if isAnswering, let last = exchanges.last {
            guard let turn = WatchHistory.turns(page.messages).last(where: { $0.id == last.id }),
                  let state = WatchLink.State(rawValue: turn.state), state.isFinal || state == .paused else { return }
        }
        showPage(of: page.chat)
        loading = false
        save()
    }

    /// The chat was deleted on the iPhone: the watch starts a new one.
    private func chatIsGone(_ chat: String) {
        guard chat == conversation else { return }
        loading = false
        if !isAnswering { startOver() }
    }

    /// The copy of `chat`, as the watch lays it out.
    private func showPage(of chat: String) {
        guard let page = cache.page(chat) else { return }
        let turns = WatchHistory.turns(page.messages).map { turn in
            WatchExchange(id: turn.id, question: turn.question, answer: turn.answer, state: turn.state,
                          detail: turn.state == WatchLink.State.paused.rawValue ? "iPhoneでFieluaを開くと続きを書きます" : nil,
                          clipped: turn.clipped ? true : nil, attachments: turn.attachments > 0 ? turn.attachments : nil)
        }
        let dropped = max(0, turns.count - Self.kept)
        exchanges = Array(turns.suffix(Self.kept))
        shown = WatchShownChat(model: page.model, watchModel: page.watchModel, earlier: page.earlier + dropped)
    }

    fileprivate func update(_ reply: WatchLink.Reply) {
        guard let index = exchanges.firstIndex(where: { $0.id == reply.question }) else { return }
        var exchange = exchanges[index]
        let wasFinal = exchange.linkState.isFinal
        // A late message never takes back a newer one's text.
        guard !(wasFinal && !reply.state.isFinal), reply.text.count >= exchange.answer.count || reply.state.isFinal else { return }
        exchange.answer = reply.text
        exchange.state = reply.state.rawValue
        exchange.detail = reply.detail
        // The iPhone wrote it in this chat: a new one, or the chat of 152.
        if let chat = reply.conversation, chat != conversation, index == exchanges.count - 1 {
            conversation = chat
        }
        guard exchange != exchanges[index] else { return }
        exchanges[index] = exchange
        // The iPhone took a new question, so an earlier answer that waited
        // for Fielua to open there won't go on (ChatStore.askFromWatch).
        if reply.state != .refused {
            for earlier in exchanges.indices where earlier < index && exchanges[earlier].linkState == .paused {
                exchanges[earlier].state = WatchLink.State.stopped.rawValue
                exchanges[earlier].detail = "ここで止まりました"
            }
        }
        if reply.state.isFinal || reply.state == .paused { save() }
        if reply.state == .finished && !wasFinal { WKInterfaceDevice.current().play(.success) }
    }

    private func trim() {
        guard exchanges.count > Self.kept else { return }
        let dropped = exchanges.count - Self.kept
        exchanges.removeFirst(dropped)
        if var info = shown {
            info.earlier += 2 * dropped
            shown = info
        }
    }

    private func save() {
        UserDefaults.standard.set(conversation, forKey: Self.conversationKey)
        if let data = try? JSONEncoder().encode(exchanges) { UserDefaults.standard.set(data, forKey: Self.storeKey) }
    }

    private func saveCache() {
        guard let data = WatchHistory.encode(cache) else { return }
        try? data.write(to: Self.cacheURL, options: .atomic)
    }

    fileprivate func refreshReachability() {
        let now = WCSession.default.isReachable
        let came = now && !reachable
        reachable = now
        if came { refresh() }
    }

    /// The watch app's first opening reaches the iPhone, even later.
    fileprivate func sayHello() {
        let defaults = UserDefaults.standard
        guard !defaults.bool(forKey: Self.helloKey) else { return }
        WCSession.default.transferUserInfo(WatchLink.hello)
        defaults.set(true, forKey: Self.helloKey)
    }

    /// `launch`: the context the watch held when the app opened, which may
    /// be older than the copy: then the iPhone's list comes on its own.
    /// The iPhone's 開発者設定 「初回起動扱いにする」 (WatchLink.reset): as on
    /// the watch app's first launch, the welcome screen, no copy of the
    /// iPhone's chats, and `hello` sent again at the next opening. Nothing
    /// on the iPhone changes; its list comes again with the next refresh.
    fileprivate func forgetAsOnFirstLaunch() {
        exchanges = []
        conversation = UUID().uuidString
        shown = nil
        loading = false
        cache = WatchHistory.Cache()
        chats = []
        try? FileManager.default.removeItem(at: Self.cacheURL)
        let defaults = UserDefaults.standard
        for key in [Self.storeKey, Self.conversationKey, Self.helloKey] { defaults.removeObject(forKey: key) }
    }

    fileprivate func takeContext(_ context: [String: Any], launch: Bool = false) {
        if let list = WatchLink.contextList(in: context), !launch || cache.list == nil { takeList(list) }
        if let reply = WatchLink.contextReply(in: context) { update(reply) }
    }

    #if DEBUG
    private static func loadPreview(_ name: String, into session: WatchSession) {
        let question = "週末に行ける温泉を3つ教えて"
        let answer = """
        ## 週末の温泉
        東京から**2時間ほど**で行ける温泉です。
        - 箱根湯本：駅から近く、日帰りもできます
        - 草津：湯畑の景色が有名です
        - 鬼怒川：川沿いの宿が多いです
        """
        let long = answer + """

        どこも週末は混みやすいので、早めの予約がおすすめです。箱根は電車でも行きやすく、草津はバスで湯畑の近くまで行けます。鬼怒川は特急で乗り換えなしです。
        - 日帰りなら箱根湯本
        - 雪見の湯なら草津
        - 川沿いの宿なら鬼怒川
        """
        let now = Date()
        session.chats = [
            .init(id: "c1", title: question, updated: now.addingTimeInterval(-300), model: "E2B", watchModel: true, count: 2),
            .init(id: "c2", title: "この写真の花の名前は？", updated: now.addingTimeInterval(-7_200), model: "E4B", watchModel: false, count: 4),
            .init(id: "c3", title: "明日の会議の要点をまとめて", updated: now.addingTimeInterval(-86_400), model: "E4B", watchModel: false, count: 6),
            .init(id: "c4", title: "英語で自己紹介を書いて", updated: now.addingTimeInterval(-172_800), model: "Qwen3 0.6B", watchModel: false, count: 2),
        ]
        session.reachable = true
        switch name {
        case "answer":
            session.exchanges = [WatchExchange(id: "a", question: question, answer: answer, state: "finished", detail: nil)]
        case "waiting":
            session.exchanges = [WatchExchange(id: "w", question: question, detail: "モデルを読み込んでいます", mine: true)]
        case "writing":
            session.exchanges = [WatchExchange(id: "r", question: question, answer: String(answer.prefix(40)),
                                               state: "writing", detail: nil, mine: true)]
        case "paused":
            session.exchanges = [WatchExchange(id: "p", question: question, answer: String(answer.prefix(60)),
                                               state: "paused", detail: "iPhoneでFieluaを開くと続きを書きます", mine: true)]
        case "folded", "morph":
            session.exchanges = [WatchExchange(id: "f", question: question, answer: long, state: "finished", detail: nil)]
        case "folded-answering":
            session.exchanges = [WatchExchange(id: "s", question: question, answer: long, state: "writing", detail: nil, mine: true)]
        case "scroll":
            session.exchanges = [
                WatchExchange(id: "s1", question: "温泉のおすすめは？", answer: long, state: "finished", detail: nil),
                WatchExchange(id: "s2", question: "日帰りならどこ？", answer: long, state: "finished", detail: nil),
                WatchExchange(id: "s3", question: "電車で行ける？", answer: answer, state: "finished", detail: nil),
            ]
        case "other":
            session.conversation = "c2"
            session.exchanges = [
                WatchExchange(id: "o1", question: "この写真の花の名前は？", answer: "アジサイです。梅雨の時期に咲きます。",
                              state: "finished", detail: nil, attachments: 1),
                WatchExchange(id: "o2", question: "育て方を短く教えて", answer: "半日陰で、土が乾いたらたっぷり水をあげます。",
                              state: "finished", detail: nil),
            ]
            session.shown = WatchShownChat(model: "E4B", watchModel: false, earlier: 12)
        default:
            break
        }
    }
    #endif
}

extension WatchSession: WCSessionDelegate {
    nonisolated func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState,
                             error: Error?) {
        let context = session.receivedApplicationContext
        Task { @MainActor in
            self.takeContext(context, launch: true)
            self.refreshReachability()
            if activationState == .activated { self.sayHello() }
        }
    }

    nonisolated func sessionReachabilityDidChange(_ session: WCSession) {
        Task { @MainActor in self.refreshReachability() }
    }

    nonisolated func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Task { @MainActor in
            if let reply = WatchLink.Reply(message) { self.update(reply) }
        }
    }

    nonisolated func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        Task { @MainActor in self.takeContext(applicationContext) }
    }

    nonisolated func session(_ session: WCSession, didReceiveUserInfo userInfo: [String: Any] = [:]) {
        guard WatchLink.isReset(userInfo) else { return }
        Task { @MainActor in self.forgetAsOnFirstLaunch() }
    }
}
