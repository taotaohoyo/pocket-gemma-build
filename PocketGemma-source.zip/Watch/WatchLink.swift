import Foundation

/// What Fielua on the iPhone and its Apple Watch app say to each other over
/// WatchConnectivity (2026-10-23): the watch asks, the iPhone answers with
/// Gemma 4 E2B and sends the answer back as it is written. The watch also
/// reads the iPhone's chats (2026-10-24): the list, and a chat's latest
/// messages (WatchHistory, sent as JSON data). Shared by both apps, as
/// property lists (WatchConnectivity's message format).
enum WatchLink {
    /// The watch's question. `id` becomes the question's message id on the
    /// iPhone. `conversation` is the chat's id on the iPhone; one the iPhone
    /// doesn't have starts a new chat with that id.
    struct Ask: Equatable {
        var id: String
        var conversation: String
        var text: String

        var message: [String: Any] { ["kind": "ask", "id": id, "conversation": conversation, "text": text] }

        init(id: String, conversation: String, text: String) {
            self.id = id
            self.conversation = conversation
            self.text = text
        }

        init?(_ message: [String: Any]) {
            guard message["kind"] as? String == "ask", let id = message["id"] as? String,
                  let conversation = message["conversation"] as? String, let text = message["text"] as? String else { return nil }
            self.init(id: id, conversation: conversation, text: text)
        }
    }

    /// The watch asks the iPhone to stop writing the answer to `question`.
    static func stop(question: String) -> [String: Any] { ["kind": "stop", "id": question] }
    static func stopQuestion(in message: [String: Any]) -> String? {
        message["kind"] as? String == "stop" ? message["id"] as? String : nil
    }

    /// The watch asks the iPhone to go on with its answer to `question`,
    /// paused when the background time ran out (2026-10-24, WatchCarryOn):
    /// iOS wakes Fielua for the message with another stretch of time. The
    /// iPhone answers with the reply as it stands.
    static func carryOn(question: String) -> [String: Any] { ["kind": "carryOn", "id": question] }
    static func carryOnQuestion(in message: [String: Any]) -> String? {
        message["kind"] as? String == "carryOn" ? message["id"] as? String : nil
    }

    enum State: String {
        /// The iPhone took the question and is getting the model ready.
        case waiting
        case writing
        case finished
        /// Out of background time: the watch app asks for the rest
        /// (`carryOn`), and it also goes on when Fielua is opened on the
        /// iPhone.
        case paused
        /// Stopped on the iPhone or from the watch.
        case stopped
        case failed
        /// Not asked: the iPhone is busy, or has no E2B. `detail` says why.
        case refused

        /// Nothing more comes for the question.
        var isFinal: Bool { self == .finished || self == .stopped || self == .failed || self == .refused }
    }

    /// The answer to `question` so far (the whole text each time, so a lost
    /// message costs nothing), with what the iPhone is doing. `conversation`
    /// is the chat the iPhone wrote it in.
    struct Reply: Equatable {
        var question: String
        var text: String
        var state: State
        var detail: String?
        var conversation: String?

        var message: [String: Any] {
            var message: [String: Any] = ["kind": "reply", "question": question, "text": text, "state": state.rawValue]
            if let detail { message["detail"] = detail }
            if let conversation { message["conversation"] = conversation }
            return message
        }

        init(question: String, text: String, state: State, detail: String? = nil, conversation: String? = nil) {
            self.question = question
            self.text = text
            self.state = state
            self.detail = detail
            self.conversation = conversation
        }

        init?(_ message: [String: Any]) {
            guard message["kind"] as? String == "reply", let question = message["question"] as? String,
                  let text = message["text"] as? String,
                  let state = (message["state"] as? String).flatMap(State.init(rawValue:)) else { return nil }
            self.init(question: question, text: text, state: state, detail: message["detail"] as? String,
                      conversation: message["conversation"] as? String)
        }
    }

    // MARK: The iPhone's chats (WatchHistory)

    /// The watch asks for the list of chats; the answer is `list(_:)`.
    static let listRequest: [String: Any] = ["kind": "list"]
    static func isListRequest(_ message: [String: Any]) -> Bool { message["kind"] as? String == "list" }
    static func list(_ data: Data) -> [String: Any] { ["kind": "list", "data": data] }
    static func listData(in message: [String: Any]) -> Data? {
        message["kind"] as? String == "list" ? message["data"] as? Data : nil
    }

    /// The watch asks for a chat's latest messages; the answer is `page(_:)`.
    static func pageRequest(chat: String) -> [String: Any] { ["kind": "pageRequest", "chat": chat] }
    static func requestedPage(in message: [String: Any]) -> String? {
        message["kind"] as? String == "pageRequest" ? message["chat"] as? String : nil
    }
    static func page(_ data: Data) -> [String: Any] { ["kind": "page", "data": data] }
    static func pageData(in message: [String: Any]) -> Data? {
        message["kind"] as? String == "page" ? message["data"] as? Data : nil
    }
    /// The iPhone has no such chat (deleted there).
    static func missingPage(chat: String) -> [String: Any] { ["kind": "page", "missing": chat] }
    static func missingPage(in message: [String: Any]) -> String? {
        message["kind"] as? String == "page" ? message["missing"] as? String : nil
    }

    /// What the watch reads when it opens (the application context, which
    /// holds one dictionary): the latest list, and the last word on the
    /// last answer.
    static func context(list: Data?, reply: Reply?) -> [String: Any] {
        var context: [String: Any] = ["kind": "context"]
        if let list { context["list"] = list }
        if let reply { context["reply"] = reply.message }
        return context
    }
    static func contextList(in context: [String: Any]) -> Data? {
        context["kind"] as? String == "context" ? context["list"] as? Data : nil
    }
    static func contextReply(in context: [String: Any]) -> Reply? {
        guard context["kind"] as? String == "context", let reply = context["reply"] as? [String: Any] else { return nil }
        return Reply(reply)
    }

    /// Sent once when the watch app first opens, queued until the iPhone
    /// can take it: the iPhone then knows the watch app is used
    /// (WatchIntro).
    static let hello: [String: Any] = ["kind": "hello"]

    /// The iPhone's 開発者設定 「初回起動扱いにする」: the watch app forgets
    /// what it showed and that it was opened. Queued like `hello`.
    static let reset: [String: Any] = ["kind": "reset"]
    static func isReset(_ info: [String: Any]) -> Bool { info["kind"] as? String == "reset" }
}
