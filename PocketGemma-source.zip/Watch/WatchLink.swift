import Foundation

/// What Fielua on the iPhone and its Apple Watch app say to each other over
/// WatchConnectivity (2026-10-23): the watch asks, the iPhone answers with
/// Gemma 4 E2B and sends the answer back as it is written. Shared by both
/// apps, as property lists (WatchConnectivity's message format).
enum WatchLink {
    /// The watch's question. `conversation` is the watch's conversation: a
    /// new one starts a new chat on the iPhone.
    struct Ask: Equatable {
        var id: String
        var conversation: String
        var text: String

        var message: [String: Any] { ["kind": "ask", "id": id, "conversation": conversation, "text": text] }

        init(id: String, conversation: String, text: String) {
            self.id = id
            self.conversation = conversation
            self.text = text
        }

        init?(_ message: [String: Any]) {
            guard message["kind"] as? String == "ask", let id = message["id"] as? String,
                  let conversation = message["conversation"] as? String, let text = message["text"] as? String else { return nil }
            self.init(id: id, conversation: conversation, text: text)
        }
    }

    /// The watch asks the iPhone to stop writing the answer to `question`.
    static func stop(question: String) -> [String: Any] { ["kind": "stop", "id": question] }
    static func stopQuestion(in message: [String: Any]) -> String? {
        message["kind"] as? String == "stop" ? message["id"] as? String : nil
    }

    enum State: String {
        /// The iPhone took the question and is getting the model ready.
        case waiting
        case writing
        case finished
        /// Out of background time: it goes on when Fielua is opened on the
        /// iPhone.
        case paused
        /// Stopped on the iPhone or from the watch.
        case stopped
        case failed
        /// Not asked: the iPhone is busy, or has no E2B. `detail` says why.
        case refused

        /// Nothing more comes for the question.
        var isFinal: Bool { self == .finished || self == .stopped || self == .failed || self == .refused }
    }

    /// The answer to `question` so far (the whole text each time, so a lost
    /// message costs nothing), with what the iPhone is doing.
    struct Reply: Equatable {
        var question: String
        var text: String
        var state: State
        var detail: String?

        var message: [String: Any] {
            var message: [String: Any] = ["kind": "reply", "question": question, "text": text, "state": state.rawValue]
            if let detail { message["detail"] = detail }
            return message
        }

        init(question: String, text: String, state: State, detail: String? = nil) {
            self.question = question
            self.text = text
            self.state = state
            self.detail = detail
        }

        init?(_ message: [String: Any]) {
            guard message["kind"] as? String == "reply", let question = message["question"] as? String,
                  let text = message["text"] as? String,
                  let state = (message["state"] as? String).flatMap(State.init(rawValue:)) else { return nil }
            self.init(question: question, text: text, state: state, detail: message["detail"] as? String)
        }
    }
}
