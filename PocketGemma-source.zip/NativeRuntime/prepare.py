"""Apply the reviewed LM-layer patch to exactly the pinned upstream source.

The LiteRT C runtime stays the official 0.18.0 binary. A separately rebuilt
LM framework calls its public C ABI; this is not a rebuild of XNNPACK/Metal.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('source', type=Path)
args = p.parse_args()
here = Path(__file__).resolve().parent
lock = json.loads((here / 'upstream-lock.json').read_text())
source = args.source.resolve()
revision = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
assert revision == lock['upstreamRevision'], 'Wrong native source revision'
patch = here / 'vision-runtime.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest() == lock['patchSHA256']
for item in lock['patches']:
    assert hashlib.sha256((source / item['path']).read_bytes()).hexdigest() == item['beforeSHA256'], item['path']
subprocess.run(['git', '-C', str(source), 'apply', '--check', str(patch)], check=True)
subprocess.run(['git', '-C', str(source), 'apply', str(patch)], check=True)
for item in lock['patches']:
    assert hashlib.sha256((source / item['path']).read_bytes()).hexdigest() == item['afterSHA256'], item['path']
exports = (here / 'lm-exports.txt').read_bytes()
assert hashlib.sha256(exports).hexdigest() == lock['lmExportsSHA256']
(source / 'c/pocket_gemma.exports').write_bytes(exports)
# miniaudio embeds an Objective-C class in its implementation header. Keep
# the two copies' runtime class names distinct; visibility alone cannot do it.
miniaudio = source / 'third_party/miniaudio/miniaudio.BUILD'
assert hashlib.sha256(miniaudio.read_bytes()).hexdigest() == lock['miniaudioBuildSHA256']
definition = miniaudio.read_text()
anchor = '    name = "miniaudio_objc",\n'
assert definition.count(anchor) == 1
definition = definition.replace(anchor, anchor + '    copts = ["-Dma_ios_notification_handler=' + lock['miniaudioClassName'] + '"],\n')
miniaudio.write_text(definition)
build = source / 'c/BUILD'
build.write_text(build.read_text() + '''
# Pocket Gemma LM-layer rebuild. LiteRT's public C ABI is supplied by the
# checksum-verified official framework, through PGOriginalRuntime.
cc_binary(
    name = "libPocketGemmaLM.dylib",
    linkshared = True,
    linkstatic = True,
    additional_linker_inputs = ["pocket_gemma.exports"],
    deps = [":engine"],
)
''')
print(json.dumps({'upstream': revision, 'patchSHA256': lock['patchSHA256']}))
