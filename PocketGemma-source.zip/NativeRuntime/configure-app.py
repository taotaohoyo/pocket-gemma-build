"""Install a verified LM-layer build as an explicit local Swift package.

Never overwrite SwiftPM's checksum-verified cache. The rebuilt layer and its
official runtime provider are separate binary targets and both are recorded.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import urllib.request
import zipfile

p=argparse.ArgumentParser()
p.add_argument('artifact',type=Path)
args=p.parse_args()
root=Path('Packages/PocketLiteRTLM')
assert not root.exists(), 'Use a clean checkout for native package preparation'
root.mkdir(parents=True)
lock=json.loads(Path('NativeRuntime/upstream-lock.json').read_text())
with zipfile.ZipFile(args.artifact) as archive:
    for n in archive.namelist():
        assert not Path(n).is_absolute() and '..' not in Path(n).parts
    archive.extractall(root/'Artifacts')
receipt=json.loads((root/'Artifacts/native-runtime-build.json').read_text())
assert receipt['sourceRevision']==lock['upstreamRevision']
assert receipt['patchSHA256']==lock['patchSHA256']
assert receipt['buildID']=='0.18.0-pg1'
for item in receipt['binaries']:
    name=item['name']; platform='ios-arm64-simulator' if item['slice']=='ios_sim_arm64' else 'ios-arm64'
    # Discover slice IDs from each generated XCFramework rather than assuming.
    import plistlib
    container=root/'Artifacts'/f'{name}.xcframework'
    info=plistlib.loads((container/'Info.plist').read_bytes())
    choices=[e for e in info['AvailableLibraries'] if (e.get('SupportedPlatformVariant')=='simulator')==(item['slice']=='ios_sim_arm64')]
    assert len(choices)==1
    entry=choices[0]; data=(container/entry['LibraryIdentifier']/entry['LibraryPath']/name).read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']

# install_name_tool changes the provider's load command. Seal the staged
# frameworks with ad-hoc build signatures before simulator execution. AltStore
# still supplies the user's provisioning/signature at installation time.
import subprocess
receipt['artifactBinariesBeforeAdHocSigning'] = [dict(e) for e in receipt['binaries']]
for name in ['CLiteRTLM','PGOriginalRuntime']:
    container=root/'Artifacts'/f'{name}.xcframework'
    info=plistlib.loads((container/'Info.plist').read_bytes())
    for entry in info['AvailableLibraries']:
        framework=container/entry['LibraryIdentifier']/entry['LibraryPath']
        subprocess.run(['codesign','--force','--sign','-','--timestamp=none',str(framework)],check=True)
        arch='ios_sim_arm64' if entry.get('SupportedPlatformVariant')=='simulator' else 'ios_arm64'
        for item in receipt['binaries']:
            if item['slice']==arch and item['name']==name:
                data=(framework/name).read_bytes()
                item.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

url=f"https://codeload.github.com/google-ai-edge/LiteRT-LM/tar.gz/{lock['upstreamRevision']}"
with urllib.request.urlopen(url,timeout=90) as response: upstream=response.read()
sources=root/'Sources/LiteRTLM'; sources.mkdir(parents=True)
source_hashes={}
with tarfile.open(fileobj=io.BytesIO(upstream),mode='r:gz') as archive:
    for member in archive.getmembers():
        relative=Path(*Path(member.name).parts[1:])
        if member.isfile() and relative.parent==Path('swift') and relative.suffix=='.swift' and not relative.name.endswith('Tests.swift'):
            data=archive.extractfile(member).read()
            source_hashes[relative.as_posix()]=hashlib.sha256(data).hexdigest()
            (sources/relative.name).write_bytes(data)
        if member.isfile() and relative.as_posix()=='LICENSE':
            (root/'LICENSE').write_bytes(archive.extractfile(member).read())
assert (sources/'Engine.swift').is_file() and (sources/'Config.swift').is_file()
config=sources/'Config.swift'; text=config.read_text()
text=text.replace('import Foundation','''import Foundation

/// Pocket Gemma extension; applies only to CPU vision, before engine creation.
public enum VisionCPUKernelMode: Int32, Sendable {
  case xnnpack = 0
  case builtin = 2
}
''',1)
text=text.replace('  public let visionBackend: Backend?', '  public let visionBackend: Backend?\n  public let visionCpuKernelMode: VisionCPUKernelMode',1)
text=text.replace('    activationDataType: ActivationDataType? = nil\n', '    activationDataType: ActivationDataType? = nil,\n    visionCpuKernelMode: VisionCPUKernelMode = .xnnpack\n',1)
text=text.replace('    self.visionBackend = visionBackend', '    self.visionBackend = visionBackend\n    self.visionCpuKernelMode = visionCpuKernelMode',1)
config.write_text(text)
engine=sources/'Engine.swift'; text=engine.read_text()
anchor='    defer { litert_lm_engine_settings_delete(settings) }'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'''

    if visionBackendStr?.lowercased() == "cpu" {
      guard pocket_gemma_engine_settings_set_vision_cpu_kernel_mode(
          settings, engineConfig.visionCpuKernelMode.rawValue) == 0 else {
        throw LiteRTLMError.engine(.failedToCreateSettings(LiteRTLMError.consumeLastError() ?? "Invalid vision kernel mode"))
      }
    }
''')
engine.write_text(text)
(root/'Package.swift').write_text('''// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "LiteRTLM", platforms: [.iOS(.v15)],
    products: [.library(name: "LiteRTLM", targets: ["LiteRTLM"])],
    targets: [
        .binaryTarget(name: "CLiteRTLM", path: "Artifacts/CLiteRTLM.xcframework"),
        .binaryTarget(name: "PGOriginalRuntime", path: "Artifacts/PGOriginalRuntime.xcframework"),
        .target(name: "LiteRTLM", dependencies: ["CLiteRTLM", "PGOriginalRuntime"])
    ])
''')
receipt['swiftOriginalSourceSHA256']=source_hashes
receipt['swiftPatchedSourceSHA256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources.glob('*.swift')}
(root/'runtime-lock.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ['project.yml','native-test-project.yml']:
    path=Path(name)
    if path.exists():
        text=path.read_text()
        old='    url: https://github.com/google-ai-edge/LiteRT-LM.git\n    exactVersion: 0.18.0'
        assert old in text, f'Unexpected upstream package declaration: {name}'
        path.write_text(text.replace(old,'    path: Packages/PocketLiteRTLM'))
print(json.dumps({'package':str(root),'buildID':receipt['buildID'],'patchSHA256':receipt['patchSHA256']}))
