"""Keep the official runtime provider and rebuilt LM layer distinguishable."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import shutil
import subprocess
import sys

root=Path('build/NativeRuntime').resolve()
lock=json.loads(Path('NativeRuntime/upstream-lock.json').read_text())
official=root/'Official/CLiteRTLM.xcframework'
info=plistlib.loads((official/'Info.plist').read_bytes())
parts={('ios_sim_arm64' if e.get('SupportedPlatformVariant')=='simulator' else 'ios_arm64'):e
       for e in info['AvailableLibraries'] if e['SupportedPlatform']=='ios' and e['SupportedArchitectures']==['arm64']}
assert set(parts)=={'ios_arm64','ios_sim_arm64'}
if sys.argv[1]=='prepare':
    for arch,entry in parts.items():
        original=official/entry['LibraryIdentifier']/entry['LibraryPath']
        provider=root/'Providers'/arch/'PGOriginalRuntime.framework'
        shutil.copytree(original,provider)
        (provider/'CLiteRTLM').rename(provider/'PGOriginalRuntime')
        subprocess.run(['install_name_tool','-id','@rpath/PGOriginalRuntime.framework/PGOriginalRuntime',str(provider/'PGOriginalRuntime')],check=True)
        # No C/Swift source imports the provider's original LM module.
        shutil.rmtree(provider/'Modules',ignore_errors=True)
        shutil.rmtree(provider/'Headers',ignore_errors=True)
        (provider/'Headers').mkdir(); (provider/'Headers/PGOriginalRuntime.h').write_text('// Dependency-only module. Public LiteRT ABI is re-exported by CLiteRTLM.\n')
        (provider/'Modules').mkdir(); (provider/'Modules/module.modulemap').write_text('framework module PGOriginalRuntime { umbrella header "PGOriginalRuntime.h" export * }\n')
        details=plistlib.loads((provider/'Info.plist').read_bytes())
        details.update(CFBundleExecutable='PGOriginalRuntime',CFBundleName='PGOriginalRuntime',CFBundleIdentifier='app.pocketgemma.runtime.provider')
        (provider/'Info.plist').write_bytes(plistlib.dumps(details))
    sys.exit(0)

artifacts=root/'Artifacts'; artifacts.mkdir()
rebuilt=[]; providers=[]; binaries=[]
for arch,entry in parts.items():
    original=official/entry['LibraryIdentifier']/entry['LibraryPath']
    custom=root/'Rebuilt'/arch/'CLiteRTLM.framework'
    shutil.copytree(original,custom)
    shutil.copy2(root/f'{arch}.dylib',custom/'CLiteRTLM')
    signature=custom/'_CodeSignature'
    if signature.exists(): shutil.rmtree(signature)
    for header in (root/'upstream/c').glob('*.h'):
        # Keep upstream framework module layout; replace headers by basename.
        matches=list((custom/'Headers').rglob(header.name))
        if matches:
            assert len(matches)==1
            shutil.copy2(header,matches[0])
    exported=subprocess.check_output(['nm','-gU',str(custom/'CLiteRTLM')],text=True)
    assert '_pocket_gemma_engine_settings_set_vision_cpu_kernel_mode' in exported
    assert '_litert_lm_engine_create' in exported
    deps=subprocess.check_output(['otool','-L',str(custom/'CLiteRTLM')],text=True)
    assert '@rpath/PGOriginalRuntime.framework/PGOriginalRuntime' in deps
    rebuilt += ['-framework',str(custom)]
    provider=root/'Providers'/arch/'PGOriginalRuntime.framework'
    providers += ['-framework',str(provider)]
    for name,path in [('CLiteRTLM',custom/'CLiteRTLM'),('PGOriginalRuntime',provider/'PGOriginalRuntime')]:
        data=path.read_bytes()
        binaries.append({'slice':arch,'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
subprocess.run(['xcodebuild','-create-xcframework',*rebuilt,'-output',str(artifacts/'CLiteRTLM.xcframework')],check=True)
subprocess.run(['xcodebuild','-create-xcframework',*providers,'-output',str(artifacts/'PGOriginalRuntime.xcframework')],check=True)
receipt={'baseRuntime':'0.18.0','buildID':'0.18.0-pg1','sourceRevision':lock['upstreamRevision'],
         'liteRTSourceRef':lock['liteRTRef'],'patchSHA256':lock['patchSHA256'],
         'originalArtifactSHA256':'d765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347',
         'scope':'Rebuilt LM layer; unchanged official LiteRT C runtime code, provider install ID renamed.',
         'binaries':binaries}
(artifacts/'native-runtime-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.make_archive(str(root/'PocketGemma-NativeRuntime'),'zip',artifacts)
print(json.dumps(receipt,indent=2))
