#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
task_root="$PWD"
native_root="$task_root/build/NativeRuntime"
source_root="$native_root/upstream"
mkdir -p "$native_root"
GIT_LFS_SKIP_SMUDGE=1 git clone --depth 1 --branch v0.18.0 https://github.com/google-ai-edge/LiteRT-LM.git "$source_root"
git -C "$source_root" lfs install --local
git -C "$source_root" lfs pull --include='prebuilt/ios_arm64/libGemmaModelConstraintProvider.dylib,prebuilt/ios_sim_arm64/libGemmaModelConstraintProvider.dylib' --exclude='' origin
python3 NativeRuntime/native_artifact.py lfs "$source_root"
python3 NativeRuntime/prepare.py "$source_root"

python3 - <<'PY'
import hashlib, pathlib, urllib.request, zipfile
root=pathlib.Path('build/NativeRuntime')
url='https://github.com/google-ai-edge/LiteRT-LM/releases/download/v0.18.0/CLiteRTLM.xcframework.zip'
archive=root/'official.xcframework.zip'
urllib.request.urlretrieve(url,archive)
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='d765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347'
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():
        assert not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts
    z.extractall(root/'Official')
PY

# The original framework is a provider of the public LiteRT C API, including
# the existing Metal implementation. Rename its install ID so two independent
# LM entry points are never confused by the dynamic loader.
python3 NativeRuntime/package.py prepare

for arch in ios_sim_arm64 ios_arm64; do
  framework_path="$native_root/Providers/$arch"
  (
    cd "$source_root"
    bazelisk build --config="$arch" --noenable_platform_specific_config -c opt --jobs=3 \
      --local_ram_resources=4096 \
      --disk_cache="$HOME/Library/Caches/pg-gemma-bazel" \
      --repository_cache="$HOME/Library/Caches/pg-gemma-bazel-repos" \
      --define=litert_runtime_link_mode=none \
      --ios_minimum_os=15.0 \
      --linkopt="-F$framework_path" \
      --linkopt=-Wl,-framework,PGOriginalRuntime \
      --linkopt="-Wl,-exported_symbols_list,$source_root/c/pocket_gemma.exports" \
      --linkopt="-Wl,-map,$native_root/$arch-link-map.txt" \
      --linkopt=-Wl,-undefined,error \
      --linkopt=-Wl,-install_name,@rpath/CLiteRTLM.framework/CLiteRTLM \
      //c:libPocketGemmaLM.dylib
    cp -L bazel-bin/c/libPocketGemmaLM.dylib "$native_root/$arch.dylib"
  )
done
python3 NativeRuntime/package.py finish
python3 NativeRuntime/native_artifact.py zip "$native_root/PocketGemma-NativeRuntime.zip"
shasum -a 256 "$native_root/PocketGemma-NativeRuntime.zip" > "$native_root/PocketGemma-NativeRuntime.zip.sha256"
