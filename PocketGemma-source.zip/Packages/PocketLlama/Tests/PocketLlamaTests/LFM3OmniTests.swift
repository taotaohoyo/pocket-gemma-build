import XCTest
import AVFoundation
import Darwin
import PocketCore
@testable import PocketLlama

/// LFM3-Omni 2B as the app runs it (1.1.0 (236)), on the Mac: its model and
/// projector through LFM3Chat and LlamaVision with its starting settings
/// and the app's sampling (min-p none), a spoken question as the app sends
/// one: a WAV written with the composer recorder's settings (VoiceRecorder)
/// and VoiceNote.ask as the turn's text when nothing is typed. The files
/// are CI's (LFM3_OMNI_GGUF, LFM3_OMNI_MMPROJ; LFM3_OMNI_CAPITAL and
/// LFM3_OMNI_COLOUR, spoken by macOS's voice, whose words are
/// LFM3_OMNI_CAPITAL_SAID and LFM3_OMNI_COLOUR_SAID; LFM3_OMNI_PICTURE, the
/// vision probe's red square). Without them these tests are skipped.
/// LLAMA_GPU=1 runs them on Metal.
final class LFM3OmniTests: XCTestCase {
    private static var shared: (chat: LFM3Chat, stop: LlamaStop)?
    private static var recordings: [String: Data] = [:]

    private func value(_ name: String) throws -> String {
        guard let value = ProcessInfo.processInfo.environment[name], !value.isEmpty else { throw XCTSkip("\(name) is not set") }
        return value
    }
    private func path(_ name: String) throws -> String {
        let path = try value(name)
        guard FileManager.default.fileExists(atPath: path) else { throw XCTSkip("\(name) is missing") }
        return path
    }
    private var gpu: Bool { ProcessInfo.processInfo.environment["LLAMA_GPU"] == "1" }
    private var label: String { gpu ? "GPU" : "CPU" }
    private let settings = GenerationSettings(for: .lfm3Omni).normalized(for: .lfm3Omni)

    private func loaded() throws -> (chat: LFM3Chat, stop: LlamaStop) {
        if let shared = Self.shared { return shared }
        let model = try path("LFM3_OMNI_GGUF"), projector = try path("LFM3_OMNI_MMPROJ")
        let stop = LlamaStop()
        let before = Self.footprint()
        let began = Date()
        let options = LlamaEngine.Options(contextTokens: settings.maxTokens, gpu: gpu,
                                          threads: ProcessInfo.processInfo.activeProcessorCount)
        let engine = try LlamaEngine(path: model, options: options, stop: stop)
        let loadedModel = Date()
        let vision = try LlamaVision(engine: engine, projector: projector)
        print(String(format: "LFM3OMNI-TEST %@ load model %.2f s + projector %.2f s, footprint %.2f GB -> %.2f GB, weights %.2f GB, context %d, threads %d, reads pictures %@, reads audio %@",
                     label, loadedModel.timeIntervalSince(began), Date().timeIntervalSince(loadedModel), Self.gigabytes(before),
                     Self.gigabytes(Self.footprint()), Double(engine.modelBytes) / 1e9, settings.maxTokens, options.threads,
                     vision.readsPictures ? "yes" : "no", vision.readsAudio ? "yes" : "no"))
        XCTAssertTrue(vision.readsAudio); XCTAssertTrue(vision.readsPictures)
        Self.shared = (LFM3Chat(engine: engine, vision: vision), stop)
        return Self.shared!
    }

    /// The spoken question as the app's recorder writes it: Core Audio's
    /// WAV writer with VoiceRecorder's settings (16 kHz mono 16-bit).
    private func recording(_ name: String) throws -> Data {
        if let data = Self.recordings[name] { return data }
        let source = try AVAudioFile(forReading: URL(fileURLWithPath: try path(name)))
        let buffer = AVAudioPCMBuffer(pcmFormat: source.processingFormat, frameCapacity: AVAudioFrameCount(source.length))!
        try source.read(into: buffer)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(VoiceNote.storedName(UUID()))
        // The file is complete once it is released, at the end of `write`.
        func write() throws {
            let file = try AVAudioFile(forWriting: url, settings: [
                AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: VoiceNote.sampleRate, AVNumberOfChannelsKey: 1,
                AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false,
            ], commonFormat: source.processingFormat.commonFormat, interleaved: source.processingFormat.isInterleaved)
            try file.write(from: buffer)
        }
        try write()
        let data = try Data(contentsOf: url)
        let written = try AVAudioFile(forReading: url)
        let seconds = Double(written.length) / written.fileFormat.sampleRate
        print(String(format: "LFM3OMNI-TEST %@ recording %@: %.2f s, %d bytes, %.0f Hz %d channel, chunks %@", label, name, seconds,
                     data.count, written.fileFormat.sampleRate, Int(written.fileFormat.channelCount), Self.chunks(data)))
        XCTAssertEqual(written.fileFormat.sampleRate, VoiceNote.sampleRate)
        XCTAssertTrue(VoiceNote.isRecording(VoiceNote.attachment(seconds: seconds, byteCount: Int64(data.count))))
        Self.recordings[name] = data
        return data
    }

    private func picture() throws -> Data { try Data(contentsOf: URL(fileURLWithPath: try path("LFM3_OMNI_PICTURE"))) }

    @discardableResult
    private func ask(_ question: String, media: [Data] = [], turns: [LFM3Prompt.Turn] = [], turnMedia: [Data] = [],
                     name: String) throws -> LFM3Chat.Outcome {
        let (chat, stop) = try loaded()
        stop.reset()
        var first: Date?
        let began = Date()
        let request = LFM3Chat.Request(system: settings.systemMessage(for: .lfm3Omni), turns: turns, question: question,
                                       questionPictures: media, turnPictures: turnMedia,
                                       thinkingBudget: settings.thinkingTokenBudget(on: .lfm3Omni),
                                       inputTokenLimit: settings.inputTokenLimit,
                                       sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature,
                                                       minP: 0, seed: 7))
        let outcome = try chat.reply(request) { event in
            if case .answer = event, first == nil { first = Date() }
        }
        let stats = outcome.stats
        print(String(format: "LFM3OMNI-TEST %@ %@: %d media = %d tokens in %.2f s; prompt %d places in %.2f s; wrote %d tokens in %.2f s = %.1f tok/s; first answer after %.2f s; thought %d; ending %@; footprint %.2f GB",
                     label, name, outcome.pictures.count, outcome.pictures.tokens, outcome.pictures.seconds, stats.promptTokens,
                     stats.prefillSeconds, stats.generatedTokens, stats.decodeSeconds,
                     Double(stats.generatedTokens) / max(0.001, stats.decodeSeconds), (first ?? Date()).timeIntervalSince(began),
                     outcome.thoughtTokens, stats.ending.rawValue, Self.gigabytes(Self.footprint())))
        print("LFM3OMNI-TEST \(label) \(name) answer: \(outcome.answer.debugDescription)")
        return outcome
    }

    /// Spoken alone: the turn's text is VoiceNote.ask, and the reply
    /// answers what was said.
    func testItAnswersASpokenQuestion() throws {
        let said = try value("LFM3_OMNI_CAPITAL_SAID")
        let (chat, _) = try loaded()
        let capital = try recording("LFM3_OMNI_CAPITAL")
        for line in try chat.vision!.describe(capital) { print("LFM3OMNI-TEST \(label) chunk \(line)") }
        print("LFM3OMNI-TEST \(label) said: \(said.debugDescription), places \(try chat.vision!.places(capital)), app's estimate \(VoiceNote.places(seconds: Double(capital.count - 44) / 32_000))")
        let outcome = try ask(VoiceNote.ask, media: [capital], name: "spoken")
        XCTAssertEqual(outcome.pictures.count, 1)
        XCTAssertEqual(outcome.thoughtTokens, 0, "no thinking")
        XCTAssertFalse(outcome.answer.contains("<think>") || outcome.answer.contains("</think>"), outcome.answer)
        XCTAssertTrue(["東京", "Tokyo"].contains { outcome.answer.contains($0) }, outcome.answer)
    }

    /// Recorded first, then a photo attached: the spoken question is about
    /// the photo.
    func testItAnswersASpokenQuestionAboutAPhoto() throws {
        print("LFM3OMNI-TEST \(label) said: \(try value("LFM3_OMNI_COLOUR_SAID").debugDescription)")
        let outcome = try ask(VoiceNote.ask, media: [try recording("LFM3_OMNI_COLOUR"), try picture()], name: "spoken-photo")
        XCTAssertEqual(outcome.pictures.count, 2)
        XCTAssertTrue(outcome.answer.contains("赤"), outcome.answer)
    }

    /// A typed follow-up hears the earlier turn's recording again, as the
    /// chat's history sends it.
    func testAFollowUpKeepsTheRecording() throws {
        let capital = try recording("LFM3_OMNI_CAPITAL")
        let answer = try ask(VoiceNote.ask, media: [capital], name: "follow-up-1").answer
        let next = try ask("さっき音声で何と質問しましたか？質問の文をそのまま書いてください。",
                           turns: [.init(.user, VoiceNote.ask, pictures: 1), .init(.assistant, answer)],
                           turnMedia: [capital], name: "follow-up-2")
        XCTAssertEqual(next.pictures.count, 1)
        XCTAssertTrue(["首都", "capital"].contains { next.answer.contains($0) }, next.answer)
    }

    /// The words written down, with a Japanese request (for the report).
    func testItWritesDownTheRecording() throws {
        let outcome = try ask("この音声を文字に起こしてください。", media: [try recording("LFM3_OMNI_CAPITAL")], name: "transcribe")
        print("LFM3OMNI-TEST \(label) said: \(try value("LFM3_OMNI_CAPITAL_SAID").debugDescription)")
        XCTAssertFalse(outcome.answer.isEmpty)
    }

    /// Text alone, as typed into an Omni chat.
    func testATypedQuestion() throws {
        let outcome = try ask("日本の首都はどこですか？", name: "typed")
        XCTAssertEqual(outcome.pictures.count, 0)
        XCTAssertTrue(outcome.answer.contains("東京"), outcome.answer)
    }

    /// Stop ends a reply to a recording, and the next question is answered.
    func testStopAfterARecording() throws {
        let (chat, stop) = try loaded()
        let capital = try recording("LFM3_OMNI_CAPITAL")
        stop.reset()
        var words = 0
        var stoppedAt: Date?
        let request = LFM3Chat.Request(system: settings.systemMessage(for: .lfm3Omni), turns: [],
                                       question: "音声の質問に答えたあと、その都市の歴史を300字で詳しく説明してください。",
                                       questionPictures: [capital], thinkingBudget: 0, inputTokenLimit: settings.inputTokenLimit,
                                       sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature, minP: 0, seed: 7))
        let outcome = try chat.reply(request) { event in
            guard case .answer = event else { return }
            words += 1
            if words == 10 {
                stoppedAt = Date()
                DispatchQueue.global().async { stop.stop() }
            }
        }
        let after = Date().timeIntervalSince(stoppedAt ?? Date())
        print(String(format: "LFM3OMNI-TEST %@ stop: ended %.3f s after stop, ending %@", label, after, outcome.stats.ending.rawValue))
        XCTAssertEqual(outcome.stats.ending, .cancelled)
        XCTAssertLessThan(after, 2)
        let again = try ask(VoiceNote.ask, media: [capital], name: "after-stop")
        XCTAssertTrue(["東京", "Tokyo"].contains { again.answer.contains($0) }, again.answer)
    }

    /// The RIFF chunks of a WAV, for the log.
    private static func chunks(_ data: Data) -> String {
        var names: [String] = []
        var offset = 12
        let bytes = [UInt8](data)
        while offset + 8 <= bytes.count {
            let name = String(decoding: bytes[offset..<offset + 4], as: UTF8.self)
            let size = Int(bytes[offset + 4]) | Int(bytes[offset + 5]) << 8 | Int(bytes[offset + 6]) << 16 | Int(bytes[offset + 7]) << 24
            names.append("\(name) \(size)")
            offset += 8 + size + (size & 1)
        }
        return names.joined(separator: ", ")
    }

    private static func footprint() -> UInt64 {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return result == KERN_SUCCESS ? info.phys_footprint : 0
    }
    private static func gigabytes(_ bytes: UInt64) -> Double { Double(bytes) / 1e9 }
}
