import XCTest
import Darwin
import PocketCore
@testable import PocketLlama

/// LFM3-Audio 2B and LFM3-Omni 2B on the Mac, to judge them (1.1.0 (234)):
/// their model and projector through LFM3Chat and LlamaVision, a spoken
/// question as a WAV file in the person's turn, as a photo goes. The files
/// are CI's (LFM3_AUDIO_GGUF, LFM3_AUDIO_MMPROJ, LFM3_AUDIO_WAV, whose words
/// are LFM3_AUDIO_SAID); LFM3_AUDIO_PICTURE adds Omni's photo. Without them
/// these tests are skipped. LLAMA_GPU=1 runs them on Metal. Text replies
/// only: speech out is not part of this check.
final class LFM3AudioTests: XCTestCase {
    private static var shared: (chat: LFM3Chat, stop: LlamaStop)?

    private func value(_ name: String) throws -> String {
        guard let value = ProcessInfo.processInfo.environment[name], !value.isEmpty else { throw XCTSkip("\(name) is not set") }
        return value
    }
    private func path(_ name: String) throws -> String {
        let path = try value(name)
        guard FileManager.default.fileExists(atPath: path) else { throw XCTSkip("\(name) is missing") }
        return path
    }
    private var gpu: Bool { ProcessInfo.processInfo.environment["LLAMA_GPU"] == "1" }
    private var label: String { (ProcessInfo.processInfo.environment["LFM3_AUDIO_LABEL"] ?? "Audio") + (gpu ? " GPU" : " CPU") }
    private let settings = GenerationSettings(for: .lfm3VL).normalized(for: .lfm3VL)

    private func loaded() throws -> (chat: LFM3Chat, stop: LlamaStop) {
        if let shared = Self.shared { return shared }
        let model = try path("LFM3_AUDIO_GGUF"), projector = try path("LFM3_AUDIO_MMPROJ")
        let stop = LlamaStop()
        let before = Self.footprint()
        let began = Date()
        let options = LlamaEngine.Options(contextTokens: settings.maxTokens, gpu: gpu,
                                          threads: ProcessInfo.processInfo.activeProcessorCount)
        let engine = try LlamaEngine(path: model, options: options, stop: stop)
        let loadedModel = Date()
        let vision = try LlamaVision(engine: engine, projector: projector)
        print(String(format: "LFM3AUDIO-TEST %@ load model %.2f s + projector %.2f s, footprint %.2f GB -> %.2f GB, weights %.2f GB, reads pictures %@, reads audio %@",
                     label, loadedModel.timeIntervalSince(began), Date().timeIntervalSince(loadedModel), Self.gigabytes(before),
                     Self.gigabytes(Self.footprint()), Double(engine.modelBytes) / 1e9,
                     vision.readsPictures ? "yes" : "no", vision.readsAudio ? "yes" : "no"))
        XCTAssertTrue(vision.readsAudio)
        Self.shared = (LFM3Chat(engine: engine, vision: vision), stop)
        return Self.shared!
    }

    @discardableResult
    private func ask(_ question: String, media: [Data], system: String? = nil, name: String) throws -> LFM3Chat.Outcome {
        let (chat, stop) = try loaded()
        stop.reset()
        let began = Date()
        let request = LFM3Chat.Request(system: system ?? settings.systemMessage(for: .lfm3VL), turns: [], question: question,
                                       questionPictures: media, thinkingBudget: 0, inputTokenLimit: settings.inputTokenLimit,
                                       sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature,
                                                       minP: 0, seed: 7))
        let outcome = try chat.reply(request) { _ in }
        let stats = outcome.stats
        print(String(format: "LFM3AUDIO-TEST %@ %@: %d media = %d tokens in %.2f s; prompt %d places in %.2f s; wrote %d tokens in %.2f s = %.1f tok/s; total %.2f s; ending %@; footprint %.2f GB",
                     label, name, outcome.pictures.count, outcome.pictures.tokens, outcome.pictures.seconds, stats.promptTokens,
                     stats.prefillSeconds, stats.generatedTokens, stats.decodeSeconds,
                     Double(stats.generatedTokens) / max(0.001, stats.decodeSeconds), Date().timeIntervalSince(began),
                     stats.ending.rawValue, Self.gigabytes(Self.footprint())))
        print("LFM3AUDIO-TEST \(label) \(name) answer: \(outcome.answer.debugDescription)")
        return outcome
    }

    private func sound() throws -> Data { try Data(contentsOf: URL(fileURLWithPath: try path("LFM3_AUDIO_WAV"))) }

    /// The words of the recording, written down.
    func testItWritesDownTheRecording() throws {
        let said = try value("LFM3_AUDIO_SAID")
        let (chat, _) = try loaded()
        for line in try chat.vision!.describe(try sound()) { print("LFM3AUDIO-TEST \(label) chunk \(line)") }
        let written = try ask("この音声を文字に起こしてください。", media: [try sound()], name: "transcribe")
        print("LFM3AUDIO-TEST \(label) said: \(said.debugDescription)")
        XCTAssertEqual(written.pictures.count, 1)
        XCTAssertFalse(written.answer.isEmpty)
        let asr = try ask("", media: [try sound()], system: "Perform ASR.", name: "transcribe-asr-prompt")
        XCTAssertFalse(asr.answer.isEmpty)
    }

    /// The spoken question answered in text.
    func testItAnswersTheSpokenQuestion() throws {
        let answer = try ask("音声で聞かれた質問に、日本語で短く答えてください。", media: [try sound()], name: "answer").answer
        XCTAssertTrue(["東京", "Tokyo"].contains { answer.contains($0) }, answer)
    }

    /// Omni: a photo and a recording in one turn.
    func testOmniSeesAndHears() throws {
        let picture = try Data(contentsOf: URL(fileURLWithPath: try path("LFM3_AUDIO_PICTURE")))
        let (chat, _) = try loaded()
        guard chat.vision?.readsPictures == true else { throw XCTSkip("this projector reads no pictures") }
        let both = try ask("画像の図形は何色ですか？それから、音声の質問にも短く答えてください。", media: [picture, try sound()], name: "omni")
        XCTAssertEqual(both.pictures.count, 2)
        XCTAssertTrue(both.answer.contains("赤"), both.answer)
    }

    private static func footprint() -> UInt64 {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return result == KERN_SUCCESS ? info.phys_footprint : 0
    }
    private static func gigabytes(_ bytes: UInt64) -> Double { Double(bytes) / 1e9 }
}
