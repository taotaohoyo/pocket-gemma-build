import XCTest
import AVFoundation
import Darwin
import PocketCore
@testable import PocketLlama

/// 先行読み込み for the LFM3 series (1.1.0 (289)), on the Mac with the real
/// files: the load the app's GemmaService starts ahead of the question
/// (LlamaReply.load: the model, then its projector for LFM3-VL 2B and
/// LFM3-Omni 2B, on the GPU or the CPU), measured before it is let on the
/// phone. For each model: the load's time, its memory (phys_footprint) and
/// the address space it maps, during and after; that a release gives both
/// back and that loads and releases over and over leave nothing behind; a
/// load stopped part-way; the first answer's time from the send when the
/// send loads the model (as before 289), when it was loaded ahead, when the
/// send came while it loaded (joined), and on the same engine for another
/// chat, whose turns never reach it; the photo (VL) and the spoken question
/// (Omni) on an engine loaded ahead; one model after another, never two.
/// The files are CI's (LFM3_GGUF; LFM3_VL_GGUF, LFM3_VL_MMPROJ,
/// LFM3_VL_PICTURE; LFM3_OMNI_GGUF, LFM3_OMNI_MMPROJ, LFM3_OMNI_CAPITAL);
/// without them a model's test is skipped. LLAMA_GPU=1 runs on Metal.
/// LFM3PREWARM lines carry the figures. The CI Mac is a 3-core VM with a
/// paravirtual GPU: its times are not the phone's, only their comparison is.
final class LFM3PrewarmTests: XCTestCase {
    private var gpu: Bool { ProcessInfo.processInfo.environment["LLAMA_GPU"] == "1" }
    private var label: String { gpu ? "GPU" : "CPU" }

    private struct Files {
        let spec: ModelSpec
        let model: String
        let projector: String?
        var tag: String { spec.id }
    }

    private func env(_ name: String) -> String? {
        guard let value = ProcessInfo.processInfo.environment[name], !value.isEmpty,
              FileManager.default.fileExists(atPath: value) else { return nil }
        return value
    }

    private func files(_ spec: ModelSpec) throws -> Files {
        switch spec.id {
        case ModelSpec.lfm3.id:
            guard let model = env("LFM3_GGUF") else { throw XCTSkip("LFM3_GGUF is not set") }
            return Files(spec: spec, model: model, projector: nil)
        case ModelSpec.lfm3VL.id:
            guard let model = env("LFM3_VL_GGUF"), let projector = env("LFM3_VL_MMPROJ") else { throw XCTSkip("LFM3-VL is not set") }
            return Files(spec: spec, model: model, projector: projector)
        default:
            guard let model = env("LFM3_OMNI_GGUF"), let projector = env("LFM3_OMNI_MMPROJ") else { throw XCTSkip("LFM3-Omni is not set") }
            return Files(spec: spec, model: model, projector: projector)
        }
    }

    // MARK: Memory and address space

    private struct Room {
        let footprint: UInt64
        /// Unmapped address space in all; its fall is what a load mapped.
        let free: UInt64
        let regions: Int
        static func now() -> Room {
            let space = AddressSpace.current()
            return Room(footprint: LFM3PrewarmTests.footprint(), free: space?.free ?? 0, regions: space?.regions ?? 0)
        }
        func mapped(since start: Room) -> Int64 { Int64(start.free) - Int64(free) }
        func grew(since start: Room) -> Int64 { Int64(footprint) - Int64(start.footprint) }
    }

    /// Samples the footprint and the address space every 20 ms while a load
    /// or a reply runs: the most of each.
    private final class Sampler: @unchecked Sendable {
        private let lock = NSLock()
        private var running = true
        private var peakFootprint: UInt64 = 0
        private var leastFree: UInt64 = .max
        private let done = DispatchSemaphore(value: 0)
        init() {
            let thread = Thread { [self] in
                while true {
                    let room = Room.now()
                    lock.lock()
                    peakFootprint = max(peakFootprint, room.footprint)
                    if room.free > 0 { leastFree = min(leastFree, room.free) }
                    let go = running
                    lock.unlock()
                    if !go { break }
                    Thread.sleep(forTimeInterval: 0.02)
                }
                done.signal()
            }
            thread.start()
        }
        func finish() -> (peakFootprint: UInt64, leastFree: UInt64) {
            lock.lock(); running = false; lock.unlock()
            done.wait()
            return (peakFootprint, leastFree)
        }
    }

    private static func footprint() -> UInt64 {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return result == KERN_SUCCESS ? info.phys_footprint : 0
    }

    private static func gb(_ bytes: UInt64) -> String { String(format: "%.3f", Double(bytes) / 1e9) }
    private static func gb(_ bytes: Int64) -> String { String(format: "%+.3f", Double(bytes) / 1e9) }

    // MARK: Loading, as LlamaReply.load

    private final class Loaded: @unchecked Sendable {
        let engine: LlamaEngine
        let vision: LlamaVision?
        let stop: LlamaStop
        init(engine: LlamaEngine, vision: LlamaVision?, stop: LlamaStop) { self.engine = engine; self.vision = vision; self.stop = stop }
        var chat: LFM3Chat { LFM3Chat(engine: engine, vision: vision) }
    }

    /// The result of a load on a thread of its own.
    private final class LoadResult: @unchecked Sendable {
        var result: Result<Loaded, Error>?
        let done = DispatchSemaphore(value: 0)
    }

    /// The app's load (LlamaReply.load): the model, then the projector
    /// unless stopped, with the app's context. The CI Mac has three cores;
    /// as the other Mac checks, all of them (the phone's count is
    /// LlamaEngine.defaultThreads; memory and mapping don't depend on it).
    private static func load(_ files: Files, gpu: Bool, stop: LlamaStop) throws -> Loaded {
        let settings = GenerationSettings(for: files.spec).normalized(for: files.spec)
        let options = LlamaEngine.Options(contextTokens: settings.maxTokens, gpu: gpu,
                                          threads: ProcessInfo.processInfo.activeProcessorCount)
        let engine = try LlamaEngine(path: files.model, options: options, stop: stop)
        guard let projector = files.projector, !stop.isStopped else {
            if stop.isStopped { throw CancellationError() }
            return Loaded(engine: engine, vision: nil, stop: stop)
        }
        let vision = try LlamaVision(engine: engine, projector: projector)
        if stop.isStopped { throw CancellationError() }
        return Loaded(engine: engine, vision: vision, stop: stop)
    }

    private struct Load {
        let loaded: Loaded
        let seconds: Double
        let peakFootprint: UInt64
        let leastFree: UInt64
    }

    private func timedLoad(_ files: Files, name: String, from start: Room) throws -> Load {
        let sampler = Sampler()
        let began = Date()
        let loaded = try Self.load(files, gpu: gpu, stop: LlamaStop())
        let seconds = Date().timeIntervalSince(began)
        let peaks = sampler.finish()
        let after = Room.now()
        print("LFM3PREWARM \(label) \(files.tag) \(name) load " + String(format: "%.2f s", seconds)
              + " footprint +\(Self.gb(after.grew(since: start))) GB (peak +\(Self.gb(Int64(peaks.peakFootprint) - Int64(start.footprint))))"
              + " mapped \(Self.gb(after.mapped(since: start))) GB (peak \(Self.gb(Int64(start.free) - Int64(peaks.leastFree))))"
              + " regions \(after.regions - start.regions) weights \(Self.gb(loaded.engine.modelBytes)) GB threads \(loaded.engine.options.threads)")
        return Load(loaded: loaded, seconds: seconds, peakFootprint: peaks.peakFootprint, leastFree: peaks.leastFree)
    }

    /// Lets the engine go as GemmaService's release does (`llama = nil`).
    private func release(_ loaded: inout Loaded?, _ files: Files, name: String, start: Room) -> Room {
        loaded = nil
        let after = Room.now()
        print("LFM3PREWARM \(label) \(files.tag) \(name) released: footprint \(Self.gb(after.grew(since: start))) GB"
              + " mapped \(Self.gb(after.mapped(since: start))) GB vs the start")
        return after
    }

    // MARK: Asking

    private struct Answer {
        let text: String
        /// From the send to the first written token.
        let firstToken: Double
        let promptTokens: Int
        let prefillSeconds: Double
        let pictures: Int
    }

    /// One question, as LlamaReply asks it, stopped after `tokens` answer
    /// pieces (the first answer's start is what is compared).
    private func ask(_ loaded: Loaded, _ files: Files, _ question: String, media: [Data] = [],
                     turns: [LFM3Prompt.Turn] = [], tokens: Int = 14, sentAt: Date = Date()) throws -> Answer {
        let settings = GenerationSettings(for: files.spec).normalized(for: files.spec)
        loaded.stop.reset()
        var first: Date?, pieces = 0
        let request = LFM3Chat.Request(system: settings.systemMessage(for: files.spec), turns: turns, question: question,
                                       questionPictures: media, thinkingBudget: 0, inputTokenLimit: settings.inputTokenLimit,
                                       sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature,
                                                       minP: files.spec.id == ModelSpec.lfm3.id ? 0.05 : 0, seed: 7))
        let outcome = try loaded.chat.reply(request) { event in
            switch event {
            case .prefilled: break
            case .thought, .answer:
                if first == nil { first = Date() }
                if case .answer = event {
                    pieces += 1
                    if pieces >= tokens { loaded.stop.stop() }
                }
            }
        }
        loaded.stop.reset()
        return Answer(text: outcome.answer, firstToken: (first ?? Date()).timeIntervalSince(sentAt),
                      promptTokens: outcome.stats.promptTokens, prefillSeconds: outcome.stats.prefillSeconds,
                      pictures: outcome.pictures.count)
    }

    private func report(_ files: Files, _ name: String, _ answer: Answer, load: Double? = nil, waited: Double? = nil) {
        var line = "LFM3PREWARM \(label) \(files.tag) \(name) first-token " + String(format: "%.2f s", answer.firstToken)
        if let load { line += String(format: " (load %.2f s inside)", load) }
        if let waited { line += String(format: " (waited %.2f s for the load)", waited) }
        line += String(format: " prompt %d tokens %.2f s, media %d, footprint %@ GB", answer.promptTokens, answer.prefillSeconds,
                       answer.pictures, Self.gb(Self.footprint()))
        print(line)
        print("LFM3PREWARM \(label) \(files.tag) \(name) answer: \(answer.text.debugDescription)")
    }

    private static let capitalQuestion = "日本の首都はどこですか？一言で答えてください。"
    private func saysTokyo(_ text: String) -> Bool { ["東京", "Tokyo", "とうきょう"].contains { text.contains($0) } }

    // MARK: The measurement, one model

    private func exercise(_ spec: ModelSpec) throws {
        let files = try files(spec)
        let start = Room.now()
        print("LFM3PREWARM \(label) \(files.tag) start footprint \(Self.gb(start.footprint)) GB free \(Self.gb(start.free)) GB regions \(start.regions)"
              + " file \(Self.gb(UInt64(spec.downloadByteCount))) GB")
        // The files' first read from disk (and Metal's first library), apart
        // from the comparison.
        var loaded: Loaded? = try timedLoad(files, name: "cold", from: start).loaded
        var after = release(&loaded, files, name: "cold", start: start)

        // 1. The send loads the model (before 289).
        var sent = Date()
        let sendLoad = try timedLoad(files, name: "send-loads", from: start)
        loaded = sendLoad.loaded
        let bySend = try ask(loaded!, files, Self.capitalQuestion, sentAt: sent)
        report(files, "send-loads", bySend, load: sendLoad.seconds)
        XCTAssertTrue(saysTokyo(bySend.text), bySend.text)
        let loadedRoom = Room.now()
        after = release(&loaded, files, name: "send-loads", start: start)
        XCTAssertLessThan(after.mapped(since: start), 96_000_000, "the release gives the address space back")
        XCTAssertLessThan(after.grew(since: start), 160_000_000, "the release gives the memory back")

        // 2. Loaded ahead, the question a moment later.
        let ahead = try timedLoad(files, name: "ahead", from: start)
        loaded = ahead.loaded
        Thread.sleep(forTimeInterval: 0.5)
        let byAhead = try ask(loaded!, files, Self.capitalQuestion)
        report(files, "ahead", byAhead)
        XCTAssertTrue(saysTokyo(byAhead.text), byAhead.text)

        // 3. The same engine for another chat: its own turns only.
        let secret = "私の合言葉は「すずらん七号」です。覚えておいてください。"
        let a = try ask(loaded!, files, "私の合言葉は何ですか？", turns: [.init(.user, secret), .init(.assistant, "わかりました。覚えました。")],
                        tokens: 20)
        report(files, "reused-chat-a", a)
        XCTAssertTrue(a.text.contains("すずらん"), a.text)
        let b = try ask(loaded!, files, "私の合言葉は何ですか？", tokens: 20)
        report(files, "reused-chat-b", b)
        XCTAssertFalse(b.text.contains("すずらん"), "another chat's turns never reach this one: \(b.text)")

        // 4. Its photo (VL) or spoken question (Omni) on the engine loaded ahead.
        if spec.id == ModelSpec.lfm3VL.id, let path = env("LFM3_VL_PICTURE") {
            let photo = try ask(loaded!, files, "この画像の図形は何色ですか？一言で答えてください。",
                                media: [try Data(contentsOf: URL(fileURLWithPath: path))])
            report(files, "ahead-photo", photo)
            XCTAssertTrue(photo.text.contains("赤"), photo.text)
            XCTAssertEqual(photo.pictures, 1)
        }
        if spec.id == ModelSpec.lfm3Omni.id, let path = env("LFM3_OMNI_CAPITAL") {
            let spoken = try ask(loaded!, files, VoiceNote.ask, media: [try recording(path)])
            report(files, "ahead-voice", spoken)
            XCTAssertTrue(saysTokyo(spoken.text), spoken.text)
            XCTAssertEqual(spoken.pictures, 1)
        }
        after = release(&loaded, files, name: "ahead", start: start)
        XCTAssertLessThan(after.mapped(since: start), 96_000_000)

        // 5. Sent while it loads: the send waits for that load (joined).
        let began = Date()
        let joinedLoad = LoadResult()
        let gpu = gpu
        Thread {
            joinedLoad.result = Result { try Self.load(files, gpu: gpu, stop: LlamaStop()) }
            joinedLoad.done.signal()
        }.start()
        Thread.sleep(forTimeInterval: 0.2)
        sent = Date()
        joinedLoad.done.wait()
        let loadSeconds = Date().timeIntervalSince(began), waited = Date().timeIntervalSince(sent)
        loaded = try joinedLoad.result!.get()
        joinedLoad.result = nil
        let byJoin = try ask(loaded!, files, Self.capitalQuestion, sentAt: sent)
        report(files, "joined", byJoin, load: loadSeconds, waited: waited)
        XCTAssertTrue(saysTokyo(byJoin.text), byJoin.text)
        after = release(&loaded, files, name: "joined", start: start)

        // 6. A load stopped part-way (a release, another model, the app
        // leaving): nothing stays, and the next load answers.
        let stop = LlamaStop()
        let stopped = LoadResult()
        let stopBegan = Date()
        Thread {
            stopped.result = Result { try Self.load(files, gpu: gpu, stop: stop) }
            stopped.done.signal()
        }.start()
        Thread.sleep(forTimeInterval: 0.05)
        let stopAt = Date()
        stop.stop()
        stopped.done.wait()
        let stopOutcome: String
        switch stopped.result! {
        case .success: stopOutcome = "finished before the stop"
        case .failure(let error): stopOutcome = "ended: \(error is CancellationError ? "cancelled" : error.localizedDescription)"
        }
        stopped.result = nil
        let afterStop = Room.now()
        print("LFM3PREWARM \(label) \(files.tag) stop-mid-load " + String(format: "%.3f s after the stop (load ran %.2f s): ", Date().timeIntervalSince(stopAt), Date().timeIntervalSince(stopBegan))
              + stopOutcome + " footprint \(Self.gb(afterStop.grew(since: start))) GB mapped \(Self.gb(afterStop.mapped(since: start))) GB vs the start")
        XCTAssertLessThan(afterStop.mapped(since: start), 96_000_000, "a stopped load maps nothing afterwards")
        loaded = try timedLoad(files, name: "after-stop", from: start).loaded
        let again = try ask(loaded!, files, Self.capitalQuestion)
        report(files, "after-stop", again)
        XCTAssertTrue(saysTokyo(again.text), again.text)
        after = release(&loaded, files, name: "after-stop", start: start)

        // 7. Loads and releases over and over (quick switching).
        var cycles: [String] = []
        for round in 1...4 {
            var cycle: Loaded? = try Self.load(files, gpu: gpu, stop: LlamaStop())
            _ = cycle
            cycle = nil
            let room = Room.now()
            cycles.append("\(round): mapped \(Self.gb(room.mapped(since: start))) footprint \(Self.gb(room.grew(since: start)))")
            after = room
        }
        print("LFM3PREWARM \(label) \(files.tag) cycles " + cycles.joined(separator: " · "))
        XCTAssertLessThan(after.mapped(since: start), 96_000_000, "four loads and releases leave nothing mapped")
        XCTAssertLessThan(after.grew(since: start), 200_000_000, "four loads and releases leave no memory")

        print("LFM3PREWARM \(label) \(files.tag) summary file \(Self.gb(UInt64(spec.downloadByteCount))) GB"
              + " loaded: footprint +\(Self.gb(loadedRoom.grew(since: start))) GB mapped \(Self.gb(loadedRoom.mapped(since: start))) GB"
              + " · load peak: footprint +\(Self.gb(Int64(sendLoad.peakFootprint) - Int64(start.footprint))) GB mapped \(Self.gb(Int64(start.free) - Int64(sendLoad.leastFree))) GB"
              + String(format: " · first token: send-loads %.2f s, ahead %.2f s, joined %.2f s (after %.2f s of its load), reused %.2f s",
                       bySend.firstToken, byAhead.firstToken, byJoin.firstToken, loadSeconds - waited, b.firstToken))
    }

    /// The spoken question as the app's recorder writes it (VoiceRecorder:
    /// 16 kHz mono 16-bit), as LFM3OmniTests does.
    private func recording(_ path: String) throws -> Data {
        let source = try AVAudioFile(forReading: URL(fileURLWithPath: path))
        let buffer = AVAudioPCMBuffer(pcmFormat: source.processingFormat, frameCapacity: AVAudioFrameCount(source.length))!
        try source.read(into: buffer)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(VoiceNote.storedName(UUID()))
        func write() throws {
            let file = try AVAudioFile(forWriting: url, settings: [
                AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: VoiceNote.sampleRate, AVNumberOfChannelsKey: 1,
                AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false,
            ], commonFormat: source.processingFormat.commonFormat, interleaved: source.processingFormat.isInterleaved)
            try file.write(from: buffer)
        }
        try write()
        return try Data(contentsOf: url)
    }

    func test1LFM3() throws { try exercise(.lfm3) }
    func test2LFM3VL() throws { try exercise(.lfm3VL) }
    func test3LFM3Omni() throws { try exercise(.lfm3Omni) }

    /// One model after another, as quick switching between LFM3 chats asks
    /// (GemmaService releases before it loads): the most memory at once
    /// stays under the biggest model's with room to spare, never two.
    func test4OneModelAfterAnother() throws {
        let all = [ModelSpec.lfm3, .lfm3VL, .lfm3Omni].compactMap { try? files($0) }
        guard all.count >= 2 else { throw XCTSkip("fewer than two LFM3 models") }
        let start = Room.now()
        var singles: [String: UInt64] = [:]
        for files in all {
            var loaded: Loaded? = try Self.load(files, gpu: gpu, stop: LlamaStop())
            singles[files.tag] = UInt64(max(0, Room.now().grew(since: start)))
            _ = loaded
            loaded = nil
        }
        let sampler = Sampler()
        for _ in 1...2 {
            for files in all {
                var loaded: Loaded? = try Self.load(files, gpu: gpu, stop: LlamaStop())
                _ = loaded
                loaded = nil
            }
        }
        let peaks = sampler.finish()
        let after = Room.now()
        let biggest = singles.values.max() ?? 0
        let peak = UInt64(max(0, Int64(peaks.peakFootprint) - Int64(start.footprint)))
        let mappedPeak = Int64(start.free) - Int64(peaks.leastFree)
        print("LFM3PREWARM \(label) switching \(all.map(\.tag).joined(separator: " -> ")) x2: peak footprint +\(Self.gb(peak)) GB"
              + " (biggest one alone +\(Self.gb(biggest)) GB, all \(singles.map { "\($0.key) +\(Self.gb($0.value))" }.sorted().joined(separator: ", ")))"
              + " peak mapped \(Self.gb(mappedPeak)) GB; after: mapped \(Self.gb(after.mapped(since: start))) footprint \(Self.gb(after.grew(since: start)))")
        XCTAssertLessThan(peak, biggest + 400_000_000, "never two models at once")
        XCTAssertLessThan(after.mapped(since: start), 96_000_000)
    }
}
