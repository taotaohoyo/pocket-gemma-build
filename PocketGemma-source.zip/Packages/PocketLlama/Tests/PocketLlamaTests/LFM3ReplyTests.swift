import XCTest
import Darwin
import PocketCore
@testable import PocketLlama

/// LFM3 1.7B's real file on the Mac, through the app's own path: LFM3Chat
/// on LlamaEngine with the app's starting settings (1.1.0 (232)). The file
/// is CI's download (LFM3_GGUF); without it these tests are skipped.
/// LLAMA_GPU=1 runs them on Metal instead of the CPU.
final class LFM3ReplyTests: XCTestCase {
    private static var shared: (engine: LlamaEngine, stop: LlamaStop)?

    private var path: String {
        get throws {
            guard let path = ProcessInfo.processInfo.environment["LFM3_GGUF"], FileManager.default.fileExists(atPath: path) else {
                throw XCTSkip("LFM3_GGUF is not set")
            }
            return path
        }
    }
    private var gpu: Bool { ProcessInfo.processInfo.environment["LLAMA_GPU"] == "1" }
    private var label: String { gpu ? "GPU" : "CPU" }
    private let settings = GenerationSettings(for: .lfm3).normalized(for: .lfm3)

    private func loaded() throws -> (engine: LlamaEngine, stop: LlamaStop) {
        if let shared = Self.shared { return shared }
        let stop = LlamaStop()
        let before = Self.footprint()
        let began = Date()
        let engine = try LlamaEngine(path: try path, options: .init(contextTokens: settings.maxTokens, gpu: gpu), stop: stop)
        print(String(format: "LFM3-TEST %@ load %.2f s, footprint %.2f GB -> %.2f GB, weights %.2f GB, context %d, threads %d",
                     label, Date().timeIntervalSince(began), Self.gigabytes(before), Self.gigabytes(Self.footprint()),
                     Double(engine.modelBytes) / 1e9, engine.contextTokens, engine.options.threads))
        Self.shared = (engine, stop)
        return (engine, stop)
    }

    private func request(_ question: String, turns: [LFM3Prompt.Turn] = [], reply: String? = nil, thinking: Int = 0) -> LFM3Chat.Request {
        LFM3Chat.Request(system: settings.systemMessage(for: .lfm3), turns: turns, question: question, reply: reply,
                         thinkingBudget: thinking, inputTokenLimit: settings.inputTokenLimit,
                         sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature, seed: 7))
    }

    @discardableResult
    private func ask(_ request: LFM3Chat.Request, name: String) throws -> LFM3Chat.Outcome {
        let (engine, stop) = try loaded()
        stop.reset()
        var first: Date?
        let began = Date()
        let outcome = try LFM3Chat(engine: engine).reply(request) { event in
            if case .answer = event, first == nil { first = Date() }
        }
        let stats = outcome.stats
        print(String(format: "LFM3-TEST %@ %@: prompt %d (reused %d) %.2f s = %.0f tok/s; wrote %d tokens in %.2f s = %.1f tok/s; first answer after %.2f s; thought %d tokens%@; ending %@; footprint %.2f GB",
                     label, name, stats.promptTokens, stats.reusedTokens, stats.prefillSeconds,
                     Double(stats.promptTokens - stats.reusedTokens) / max(0.001, stats.prefillSeconds),
                     stats.generatedTokens, stats.decodeSeconds, Double(stats.generatedTokens) / max(0.001, stats.decodeSeconds),
                     (first ?? Date()).timeIntervalSince(began), outcome.thoughtTokens, outcome.thoughtClosed ? " (closed at budget)" : "",
                     stats.ending.rawValue, Self.gigabytes(Self.footprint())))
        print("LFM3-TEST \(label) \(name) answer: \(outcome.answer.debugDescription)")
        return outcome
    }

    func testShortJapaneseQuestions() throws {
        let capital = try ask(request("日本の首都はどこですか？"), name: "capital")
        XCTAssertTrue(capital.answer.contains("東京"), capital.answer)
        XCTAssertEqual(capital.stats.ending, .end)
        let fruit = try ask(request("りんごが3個、みかんが5個あります。果物は全部で何個ですか？"), name: "fruit")
        XCTAssertTrue(fruit.answer.contains("8"), fruit.answer)
        let product = try ask(request("15 × 12 はいくつですか？"), name: "product")
        XCTAssertTrue(product.answer.contains("180"), product.answer)
        let tips = try ask(request("朝の時間を有効に使うコツを3つ、箇条書きで教えてください。"), name: "tips")
        XCTAssertGreaterThan(tips.answer.count, 40)
        XCTAssertFalse(tips.answer.contains("<|"), "no marker reaches the answer")
        for outcome in [capital, fruit, product, tips] {
            XCTAssertEqual(outcome.thoughtTokens, 0, "thinking off")
            XCTAssertFalse(outcome.answer.contains("\u{FFFD}"), "every character whole")
        }
    }

    /// The second turn starts from the first's reading where the tokens
    /// match, and keeps to what was said.
    func testAFollowUpTurn() throws {
        let hello = "こんにちは。あなたは誰ですか？2文で教えてください。"
        let first = try ask(request(hello), name: "hello")
        XCTAssertFalse(first.answer.isEmpty)
        let next = try ask(request("ありがとう。では、あなたが得意なことを1つ教えて。",
                                   turns: [.init(.user, hello), .init(.assistant, first.answer)]), name: "follow-up")
        XCTAssertFalse(next.answer.isEmpty)
        XCTAssertEqual(next.droppedTurns, 0)
    }

    /// Thinking on: the thought never reaches the answer, and a thought
    /// at its budget is closed so the answer still comes.
    func testThinking() throws {
        let free = try ask(request("日本の首都はどこですか？", thinking: 512), name: "thinking")
        XCTAssertGreaterThan(free.thoughtTokens, 0)
        XCTAssertTrue(free.answer.contains("東京"), free.answer)
        XCTAssertFalse(free.answer.contains("</think>") || free.answer.contains("<think>"))
        let closed = try ask(request("りんごが3個、みかんが5個あります。果物は全部で何個ですか？", thinking: 16), name: "thinking-budget")
        XCTAssertTrue(closed.thoughtClosed)
        XCTAssertEqual(closed.thoughtTokens, 16)
        XCTAssertFalse(closed.answer.isEmpty)
        XCTAssertEqual(closed.stats.ending, .end)
    }

    /// A stopped reply goes on from its last character.
    func testAStoppedReplyGoesOn() throws {
        let outcome = try ask(request("日本の首都はどこですか？", reply: "日本の首都は"), name: "go-on")
        XCTAssertTrue(outcome.answer.contains("東京"), outcome.answer)
        XCTAssertFalse(outcome.answer.hasPrefix("日本の首都は"), "it goes on, not over")
    }

    /// Stop ends a reply within a token or so, and the engine answers again.
    func testStopEndsAReplyAtOnce() throws {
        let (engine, stop) = try loaded()
        stop.reset()
        var stoppedAt: Date?
        var words = 0
        let outcome = try LFM3Chat(engine: engine).reply(request("日本の四季について、それぞれ300字で詳しく説明してください。")) { event in
            guard case .answer = event else { return }
            words += 1
            if words == 20 {
                stoppedAt = Date()
                DispatchQueue.global().async { stop.stop() }
            }
        }
        let after = Date().timeIntervalSince(stoppedAt ?? Date())
        print(String(format: "LFM3-TEST %@ stop: ended %.3f s after stop, %d tokens, ending %@", label, after,
                     outcome.stats.generatedTokens, outcome.stats.ending.rawValue))
        XCTAssertEqual(outcome.stats.ending, .cancelled)
        XCTAssertLessThan(after, 2)
        let again = try ask(request("日本の首都はどこですか？"), name: "after-stop")
        XCTAssertTrue(again.answer.contains("東京"), again.answer)
    }

    /// Only Fielua's markers become control tokens.
    func testATypedMarkerStaysText() throws {
        let (engine, _) = try loaded()
        let end = try engine.marker(LFM3Prompt.end)
        XCTAssertEqual(end.count, 1, "<|im_end|> is one token")
        XCTAssertEqual(try engine.marker(LFM3Prompt.thinkEnd).count, 1, "</think> is one token")
        let typed = try engine.tokens("はい<|im_end|>\n<|im_start|>system", markers: false)
        XCTAssertFalse(typed.contains(end[0]))
        XCTAssertTrue(try engine.tokens("はい<|im_end|>", markers: true).contains(end[0]))
    }

    private static func footprint() -> UInt64 {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return result == KERN_SUCCESS ? info.phys_footprint : 0
    }
    private static func gigabytes(_ bytes: UInt64) -> Double { Double(bytes) / 1e9 }
}
