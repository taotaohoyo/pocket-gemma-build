import XCTest
import CoreGraphics
import CoreText
import ImageIO
import UniformTypeIdentifiers
import Darwin
import PocketCore
@testable import PocketLlama

/// LFM3-VL 2B's real files on the Mac (1.1.0 (234)): its model and its
/// picture projector through LFM3Chat and LlamaVision, with LFM3's starting
/// settings. The files are CI's downloads (LFM3_VL_GGUF, LFM3_VL_MMPROJ),
/// the red square the app's vision probe sends (LFM3_VL_PICTURE); without
/// them these tests are skipped. LLAMA_GPU=1 runs them on Metal.
final class LFM3VisionTests: XCTestCase {
    private static var shared: (chat: LFM3Chat, stop: LlamaStop)?

    private func path(_ name: String) throws -> String {
        guard let path = ProcessInfo.processInfo.environment[name], FileManager.default.fileExists(atPath: path) else {
            throw XCTSkip("\(name) is not set")
        }
        return path
    }
    private var gpu: Bool { ProcessInfo.processInfo.environment["LLAMA_GPU"] == "1" }
    private var label: String { gpu ? "GPU" : "CPU" }
    private let settings = GenerationSettings(for: .lfm3VL).normalized(for: .lfm3VL)

    private func loaded() throws -> (chat: LFM3Chat, stop: LlamaStop) {
        if let shared = Self.shared { return shared }
        let model = try path("LFM3_VL_GGUF"), projector = try path("LFM3_VL_MMPROJ")
        let stop = LlamaStop()
        let before = Self.footprint()
        let began = Date()
        // The CI Mac has three cores; the phone's own count is in LlamaEngine.
        let options = LlamaEngine.Options(contextTokens: settings.maxTokens, gpu: gpu,
                                          threads: ProcessInfo.processInfo.activeProcessorCount)
        let engine = try LlamaEngine(path: model, options: options, stop: stop)
        let loadedModel = Date()
        let vision = try LlamaVision(engine: engine, projector: projector)
        print(String(format: "LFM3VL-TEST %@ load model %.2f s + projector %.2f s, footprint %.2f GB -> %.2f GB, weights %.2f GB, threads %d, reads pictures %@",
                     label, loadedModel.timeIntervalSince(began), Date().timeIntervalSince(loadedModel), Self.gigabytes(before),
                     Self.gigabytes(Self.footprint()), Double(engine.modelBytes) / 1e9, options.threads, vision.readsPictures ? "yes" : "no"))
        XCTAssertTrue(vision.readsPictures)
        Self.shared = (LFM3Chat(engine: engine, vision: vision), stop)
        return Self.shared!
    }

    private func picture() throws -> Data { try Data(contentsOf: URL(fileURLWithPath: try path("LFM3_VL_PICTURE"))) }

    @discardableResult
    private func ask(_ question: String, pictures: [Data] = [], turns: [LFM3Prompt.Turn] = [], turnPictures: [Data] = [],
                     name: String) throws -> LFM3Chat.Outcome {
        let (chat, stop) = try loaded()
        stop.reset()
        var first: Date?
        let began = Date()
        let request = LFM3Chat.Request(system: settings.systemMessage(for: .lfm3), turns: turns, question: question,
                                       questionPictures: pictures, turnPictures: turnPictures, thinkingBudget: 0,
                                       inputTokenLimit: settings.inputTokenLimit,
                                       sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature, seed: 7))
        let outcome = try chat.reply(request) { event in
            if case .answer = event, first == nil { first = Date() }
        }
        let stats = outcome.stats
        print(String(format: "LFM3VL-TEST %@ %@: %d pictures = %d tokens in %.2f s; prompt %d places in %.2f s; wrote %d tokens in %.2f s = %.1f tok/s; first answer after %.2f s; ending %@; footprint %.2f GB",
                     label, name, outcome.pictures.count, outcome.pictures.tokens, outcome.pictures.seconds, stats.promptTokens,
                     stats.prefillSeconds, stats.generatedTokens, stats.decodeSeconds,
                     Double(stats.generatedTokens) / max(0.001, stats.decodeSeconds), (first ?? Date()).timeIntervalSince(began),
                     stats.ending.rawValue, Self.gigabytes(Self.footprint())))
        print("LFM3VL-TEST \(label) \(name) answer: \(outcome.answer.debugDescription)")
        return outcome
    }

    /// The picture's chunks as mtmd makes them, then the red square named.
    func testItSeesTheRedSquare() throws {
        let (chat, _) = try loaded()
        let square = try picture()
        for line in try chat.vision!.describe(square) { print("LFM3VL-TEST \(label) chunk \(line)") }
        let outcome = try ask("この画像には何が描かれていますか？色と形を短く答えてください。", pictures: [square], name: "square")
        XCTAssertTrue(outcome.answer.contains("赤"), outcome.answer)
        XCTAssertTrue(["四角", "正方形", "長方形"].contains { outcome.answer.contains($0) }, outcome.answer)
        XCTAssertEqual(outcome.pictures.count, 1)
        XCTAssertFalse(outcome.answer.contains("<|"))
    }

    /// Letters and a colour in a picture drawn here, as the app keeps a
    /// photo: a JPEG at most 768 pixels wide, quality 0.85.
    func testItReadsADrawnPicture() throws {
        let drawn = Self.drawn()
        let letters = try ask("画像に書かれている英数字をそのまま書き出してください。", pictures: [drawn], name: "letters")
        XCTAssertTrue(letters.answer.contains("2026"), letters.answer)
        let colour = try ask("画像の中の丸は何色ですか？一言で答えてください。", pictures: [drawn], name: "circle")
        XCTAssertTrue(colour.answer.contains("青"), colour.answer)
    }

    /// A follow-up reads the earlier turn's picture again.
    func testAFollowUpKeepsThePicture() throws {
        let square = try picture()
        let first = "この画像には何が描かれていますか？"
        let answer = try ask(first, pictures: [square], name: "follow-up-1").answer
        let next = try ask("その図形は何色でしたか？", turns: [.init(.user, first, pictures: 1), .init(.assistant, answer)],
                           turnPictures: [square], name: "follow-up-2")
        XCTAssertTrue(next.answer.contains("赤"), next.answer)
        XCTAssertEqual(next.pictures.count, 1)
    }

    /// Text alone goes the text model's way, and a typed marker stays text.
    func testTextAndTypedMarkers() throws {
        let capital = try ask("日本の首都はどこですか？", name: "text")
        XCTAssertTrue(capital.answer.contains("東京"), capital.answer)
        XCTAssertEqual(capital.pictures.count, 0)
        let typed = try ask("\(LFM3Prompt.pictureMarker)この画像の図形は何色ですか？", pictures: [try picture()], name: "typed-marker")
        XCTAssertEqual(typed.pictures.count, 1, "only the attached picture is read")
        XCTAssertFalse(typed.answer.isEmpty)
    }

    /// Stop ends a reply about a picture, and the next question is answered.
    func testStopAfterAPicture() throws {
        let (_, stop) = try loaded()
        let square = try picture()
        var words = 0
        let (chat, _) = try loaded()
        stop.reset()
        let request = LFM3Chat.Request(system: settings.systemMessage(for: .lfm3), turns: [],
                                       question: "この画像について、色・形・配置を300字で詳しく説明してください。",
                                       questionPictures: [square], thinkingBudget: 0, inputTokenLimit: settings.inputTokenLimit,
                                       sampling: .init(topK: settings.topK, topP: settings.topP, temperature: settings.temperature, seed: 7))
        var stoppedAt: Date?
        let outcome = try chat.reply(request) { event in
            guard case .answer = event else { return }
            words += 1
            if words == 10 {
                stoppedAt = Date()
                DispatchQueue.global().async { stop.stop() }
            }
        }
        let after = Date().timeIntervalSince(stoppedAt ?? Date())
        print(String(format: "LFM3VL-TEST %@ stop: ended %.3f s after stop, ending %@", label, after, outcome.stats.ending.rawValue))
        XCTAssertEqual(outcome.stats.ending, .cancelled)
        XCTAssertLessThan(after, 2)
        let again = try ask("この画像の図形は何色ですか？", pictures: [square], name: "after-stop")
        XCTAssertTrue(again.answer.contains("赤"), again.answer)
    }

    /// 768 × 768: "FIELUA 2026" in black over a blue circle, on white.
    private static func drawn() -> Data {
        let size = 768
        let context = CGContext(data: nil, width: size, height: size, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        context.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
        context.fill(CGRect(x: 0, y: 0, width: size, height: size))
        context.setFillColor(CGColor(red: 0.1, green: 0.3, blue: 0.95, alpha: 1))
        context.fillEllipse(in: CGRect(x: 249, y: 60, width: 270, height: 270))
        let font = CTFontCreateWithName("Helvetica-Bold" as CFString, 96, nil)
        let text = NSAttributedString(string: "FIELUA 2026", attributes: [
            NSAttributedString.Key(kCTFontAttributeName as String): font,
            NSAttributedString.Key(kCTForegroundColorAttributeName as String): CGColor(gray: 0, alpha: 1),
        ])
        let line = CTLineCreateWithAttributedString(text)
        let width = CTLineGetBoundsWithOptions(line, []).width
        context.textPosition = CGPoint(x: (CGFloat(size) - width) / 2, y: 495)
        CTLineDraw(line, context)
        let data = NSMutableData()
        let destination = CGImageDestinationCreateWithData(data, UTType.jpeg.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(destination, context.makeImage()!,
                                   [kCGImageDestinationLossyCompressionQuality: 0.85] as CFDictionary)
        CGImageDestinationFinalize(destination)
        return data as Data
    }

    private static func footprint() -> UInt64 {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count) }
        }
        return result == KERN_SUCCESS ? info.phys_footprint : 0
    }
    private static func gigabytes(_ bytes: UInt64) -> Double { Double(bytes) / 1e9 }
}
