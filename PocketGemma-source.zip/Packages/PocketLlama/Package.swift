// swift-tools-version: 5.9
import PackageDescription

// llama.cpp for the models LiteRT-LM can't run (LFM3, 1.1.0 (232)): the
// project's own Apple build of release b11960 (= v0.8.0, the first with
// LFM3), Metal included. It has iPhone and Mac slices but none for the
// simulator, so only the device app links it (project.yml) and the app's
// code asks `canImport(PocketLlama)`; the Mac runs the tests.
let package = Package(
    name: "PocketLlama",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [.library(name: "PocketLlama", targets: ["PocketLlama"])],
    dependencies: [.package(path: "../PocketCore")],
    targets: [
        .binaryTarget(
            name: "llama",
            url: "https://github.com/ggml-org/llama.cpp/releases/download/b11960/llama-b11960-xcframework.zip",
            checksum: "feba05e0b7cb5e682ae3354abb455bf9723ae2cc95c69e24d073264e6a34d759"),
        .target(name: "PocketLlama", dependencies: ["llama", "PocketCore"]),
        .testTarget(name: "PocketLlamaTests", dependencies: ["PocketLlama", "PocketCore"]),
    ]
)
