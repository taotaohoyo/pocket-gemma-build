import Foundation
import llama

/// A vision model's pictures on llama.cpp's mtmd (LFM3-VL 2B): its
/// projector file (mmproj) beside the model's engine. A prompt with
/// pictures is read whole from an empty context, Fielua's own tokens as
/// they are and each picture where it stands, so a marker typed in a
/// message stays text here too.
public final class LlamaVision: @unchecked Sendable {
    public enum Failure: LocalizedError, Equatable {
        case projector
        case picture
        case tokenize(Int32)
        case encode(Int32)
        public var errorDescription: String? {
            switch self {
            case .projector: "llama.cpp could not load the picture projector"
            case .picture: "llama.cpp could not read the picture"
            case .tokenize(let code): "llama.cpp could not prepare the picture (\(code))"
            case .encode(let code): "llama.cpp could not read the picture into the model (\(code))"
            }
        }
    }

    /// A prompt's pieces in order: tokens Fielua made, or a picture's file
    /// (JPEG or PNG bytes).
    public enum Piece: Sendable {
        case tokens([Int32])
        case picture(Data)
    }

    /// What reading the pictures took, for the diagnostics.
    public struct Pictures: Sendable {
        public var count = 0
        public var tokens = 0
        public var seconds = 0.0
    }

    public let engine: LlamaEngine
    private let context: OpaquePointer
    public private(set) var lastPictures = Pictures()

    /// Loads the projector for `engine`'s model, on its GPU or CPU.
    public init(engine: LlamaEngine, projector path: String) throws {
        var params = mtmd_context_params_default()
        params.use_gpu = engine.options.gpu
        params.print_timings = false
        params.n_threads = Int32(engine.options.threads)
        guard let context = mtmd_init_from_file(path, engine.model, params) else { throw Failure.projector }
        self.engine = engine
        self.context = context
    }

    deinit { mtmd_free(context) }

    public var readsPictures: Bool { mtmd_support_vision(context) }
    /// Whether the projector hears sound (LFM3-Audio, LFM3-Omni): a WAV,
    /// MP3 or FLAC file goes in as a picture's piece does.
    public var readsAudio: Bool { mtmd_support_audio(context) }

    /// Reads `pieces` from an empty context, then writes as
    /// `LlamaEngine.generate` does.
    public func generate(_ pieces: [Piece], maximum: Int, sampling: LlamaEngine.Sampling,
                         prefilled: (LlamaEngine.Stats) -> Void = { _ in },
                         next: (Int32, [UInt8]) -> LlamaEngine.Next) throws -> LlamaEngine.Stats {
        var stats = LlamaEngine.Stats()
        var pictures = Pictures()
        lastPictures = pictures
        let window = engine.contextTokens
        engine.clearForPicture()
        let began = Date()
        var position = 0
        var recent: [Int32] = []
        for (index, piece) in pieces.enumerated() {
            if engine.isStopped { stats.ending = .cancelled; return stats }
            switch piece {
            case .tokens(let tokens):
                guard position + tokens.count < window else {
                    throw LlamaEngine.Failure.tooLong(tokens: position + tokens.count, context: window)
                }
                guard try engine.read(tokens) else { stats.ending = .cancelled; return stats }
                position += tokens.count
                recent += tokens
            case .picture(let data):
                let reading = Date()
                let after = try read(data, at: position, window: window, last: index == pieces.count - 1)
                guard let after else { stats.ending = .cancelled; return stats }
                pictures.count += 1
                pictures.tokens += after - position
                pictures.seconds += Date().timeIntervalSince(reading)
                position = after
                recent = []
            }
        }
        lastPictures = pictures
        stats.promptTokens = position
        stats.prefillSeconds = Date().timeIntervalSince(began)
        prefilled(stats)
        return try engine.write(stats, position: position, reading: nil, recent: recent, maximum: maximum,
                                sampling: sampling, next: next)
    }

    /// The places a picture takes in the context, its markers included.
    public func places(_ data: Data) throws -> Int {
        try withChunks(of: data) { Int(mtmd_helper_get_n_pos($0)) }
    }

    /// What mtmd makes of a picture, for the tests: each chunk's kind and
    /// tokens, a text chunk's as text.
    public func describe(_ data: Data) throws -> [String] {
        try withChunks(of: data) { chunks in
            (0..<mtmd_input_chunks_size(chunks)).map { index in
                let chunk = mtmd_input_chunks_get(chunks, index)
                let tokens = Int(mtmd_input_chunk_get_n_tokens(chunk))
                if mtmd_input_chunk_get_type(chunk) == MTMD_INPUT_CHUNK_TYPE_TEXT {
                    var count = 0
                    let pointer = mtmd_input_chunk_get_tokens_text(chunk, &count)
                    let text = (0..<count).map { String(decoding: engine.bytes(of: pointer![$0]), as: UTF8.self) }.joined()
                    return "text \(tokens): \(text.debugDescription)"
                }
                return "media \(tokens) tokens, \(mtmd_input_chunk_get_n_pos(chunk)) places"
            }
        }
    }

    /// The picture's bitmap tokenized at mtmd's marker, for `body`.
    private func withChunks<T>(of data: Data, _ body: (OpaquePointer) throws -> T) throws -> T {
        let wrapper = data.withUnsafeBytes { bytes in
            mtmd_helper_bitmap_init_from_buf(context, bytes.bindMemory(to: UInt8.self).baseAddress, bytes.count,
                                             false, mtmd_helper_init_opt_default())
        }
        guard let bitmap = wrapper.bitmap else { throw Failure.picture }
        defer {
            mtmd_bitmap_free(bitmap)
            if let video = wrapper.video_ctx { mtmd_helper_video_free(video) }
        }
        guard let chunks = mtmd_input_chunks_init() else { throw Failure.picture }
        defer { mtmd_input_chunks_free(chunks) }
        var bitmaps: [OpaquePointer?] = [bitmap]
        let marker = mtmd_get_marker(context)!
        var text = mtmd_input_text(text: marker, text_len: strlen(marker), add_special: false, parse_special: true)
        let result = mtmd_tokenize(context, chunks, &text, &bitmaps, 1)
        guard result == 0 else { throw Failure.tokenize(result) }
        return try body(chunks)
    }

    /// Reads one picture after `position` places; the places after it, or
    /// nil when stopped.
    private func read(_ data: Data, at position: Int, window: Int, last: Bool) throws -> Int? {
        try withChunks(of: data) { chunks in try read(chunks, at: position, window: window, last: last) }
    }

    private func read(_ chunks: OpaquePointer, at position: Int, window: Int, last: Bool) throws -> Int? {
        let places = Int(mtmd_helper_get_n_pos(chunks))
        guard position + places < window else {
            throw LlamaEngine.Failure.tooLong(tokens: position + places, context: window)
        }
        if engine.isStopped { return nil }
        var after: llama_pos = 0
        let code = mtmd_helper_eval_chunks(context, engine.context, chunks, llama_pos(position), 0,
                                           Int32(engine.options.batchTokens), last, &after)
        if engine.isStopped { return nil }
        guard code == 0 else { throw Failure.encode(code) }
        return Int(after)
    }
}
