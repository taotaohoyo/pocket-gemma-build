import Foundation
import llama

/// Stops a model's load or reply from another thread: the load at its next
/// progress report, a reply at its next token, and a CPU decode inside its
/// graph (llama.cpp's abort callback). The GPU finishes the batch it has.
public final class LlamaStop: @unchecked Sendable {
    private let lock = NSLock()
    private var stopped = false
    public init() {}
    public var isStopped: Bool { lock.lock(); defer { lock.unlock() }; return stopped }
    public func stop() { lock.lock(); stopped = true; lock.unlock() }
    public func reset() { lock.lock(); stopped = false; lock.unlock() }

    fileprivate var pointer: UnsafeMutableRawPointer { Unmanaged.passUnretained(self).toOpaque() }
    fileprivate static func of(_ pointer: UnsafeMutableRawPointer?) -> LlamaStop? {
        pointer.map { Unmanaged<LlamaStop>.fromOpaque($0).takeUnretainedValue() }
    }
}

/// One GGUF model and its context on llama.cpp (release b11960). One
/// caller at a time, off the main thread; only `LlamaStop` crosses threads.
/// The context keeps what it last read: a prompt that starts with all of it
/// is read from there on, any other from the start, since LFM3's
/// convolution state can't be cut back to an earlier token.
public final class LlamaEngine: @unchecked Sendable {
    public struct Options: Equatable, Sendable {
        public var contextTokens: Int
        public var gpu: Bool
        public var threads: Int
        public var batchTokens: Int
        public init(contextTokens: Int, gpu: Bool, threads: Int = LlamaEngine.defaultThreads, batchTokens: Int = 512) {
            self.contextTokens = contextTokens; self.gpu = gpu; self.threads = threads; self.batchTokens = batchTokens
        }
    }

    /// The sampler chain llama-server ran the Arm CPU check with:
    /// penalties over the last 64 tokens, then TopK, TopP, MinP 0.05 and
    /// the temperature.
    public struct Sampling: Equatable, Sendable {
        public var topK: Int
        public var topP: Double
        public var temperature: Double
        public var minP: Double
        public var repeatPenalty: Double
        public var repeatLastN: Int
        public var seed: UInt32
        public init(topK: Int, topP: Double, temperature: Double, minP: Double = 0.05, repeatPenalty: Double = 1.1,
                    repeatLastN: Int = 64, seed: UInt32 = .random(in: 1 ... .max)) {
            self.topK = topK; self.topP = topP; self.temperature = temperature; self.minP = minP
            self.repeatPenalty = repeatPenalty; self.repeatLastN = repeatLastN; self.seed = seed
        }
    }

    /// What the caller wants after each token: go on, stop before it is
    /// read, or read more tokens after it (a thought closed at its budget).
    public enum Next: Sendable { case go, stop, inject([Int32]) }

    public enum Ending: String, Sendable {
        /// The model ended its turn.
        case end
        /// The caller stopped it (`Next.stop`).
        case stopped
        /// `LlamaStop`.
        case cancelled
        /// The context window is full.
        case context
        /// `maximum` tokens.
        case limit
    }

    public struct Stats: Sendable {
        public var promptTokens = 0
        /// Prompt tokens the context already held.
        public var reusedTokens = 0
        public var generatedTokens = 0
        public var prefillSeconds = 0.0
        public var decodeSeconds = 0.0
        public var ending: Ending = .end
    }

    public enum Failure: LocalizedError, Equatable {
        case load, context, tokenize
        case decode(Int32)
        case tooLong(tokens: Int, context: Int)
        public var errorDescription: String? {
            switch self {
            case .load: "llama.cpp could not load the model file"
            case .context: "llama.cpp could not create the context"
            case .tokenize: "llama.cpp could not tokenize the prompt"
            case .decode(let code): "llama.cpp decode failed (\(code))"
            case .tooLong(let tokens, let context): "prompt of \(tokens) tokens exceeds the context of \(context)"
            }
        }
    }

    public static let release = "b11960"
    /// Two cores fewer than the device has, at most four: the phone's
    /// performance cores and some of its efficiency cores.
    public static var defaultThreads: Int { max(1, min(4, ProcessInfo.processInfo.activeProcessorCount - 2)) }

    public let options: Options
    let model: OpaquePointer
    let context: OpaquePointer
    private let vocab: OpaquePointer
    private let stopSignal: LlamaStop
    /// The tokens the context holds; nil when a stopped read left it unknown.
    private var held: [Int32]? = []
    private var markers: [String: [Int32]] = [:]

    private static let backend: Void = {
        llama_backend_init()
        // Warnings and errors only, to stderr, where the app's native log
        // capture reads them; loading alone writes a hundred lines of info.
        llama_log_set({ level, text, _ in
            guard level == GGML_LOG_LEVEL_WARN || level == GGML_LOG_LEVEL_ERROR, let text else { return }
            fputs(text, stderr)
        }, nil)
    }()

    /// Loads the model and makes its context; blocks while it reads the
    /// file. On the CPU no GPU device is offered at all, so a reply in the
    /// background never reaches Metal, which iOS refuses there.
    public init(path: String, options: Options, stop: LlamaStop) throws {
        _ = Self.backend
        self.options = options
        stopSignal = stop
        var modelParams = llama_model_default_params()
        modelParams.n_gpu_layers = options.gpu ? 999 : 0
        modelParams.load_mode = LLAMA_LOAD_MODE_MMAP
        modelParams.progress_callback = { _, data in !(LlamaStop.of(data)?.isStopped ?? false) }
        modelParams.progress_callback_user_data = stop.pointer
        let noDevices = UnsafeMutablePointer<ggml_backend_dev_t?>.allocate(capacity: 1)
        noDevices.initialize(to: nil)
        defer { noDevices.deallocate() }
        if !options.gpu { modelParams.devices = noDevices }
        guard let model = llama_model_load_from_file(path, modelParams) else { throw Failure.load }
        var contextParams = llama_context_default_params()
        contextParams.n_ctx = UInt32(options.contextTokens)
        contextParams.n_batch = UInt32(options.batchTokens)
        contextParams.n_ubatch = UInt32(options.batchTokens)
        contextParams.n_seq_max = 1
        contextParams.n_threads = Int32(options.threads)
        contextParams.n_threads_batch = Int32(options.threads)
        contextParams.no_perf = true
        if !options.gpu {
            contextParams.offload_kqv = false
            contextParams.op_offload = false
        }
        contextParams.abort_callback = { data in LlamaStop.of(data)?.isStopped ?? false }
        contextParams.abort_callback_data = stop.pointer
        guard let context = llama_init_from_model(model, contextParams) else {
            llama_model_free(model)
            throw Failure.context
        }
        self.model = model
        self.context = context
        vocab = llama_model_get_vocab(model)
    }

    deinit {
        llama_free(context)
        llama_model_free(model)
    }

    public var contextTokens: Int { Int(llama_n_ctx(context)) }
    /// The weights' size in memory.
    public var modelBytes: UInt64 { llama_model_size(model) }

    /// `text`'s tokens; `markers` reads control tokens such as <|im_end|>
    /// in it, which only Fielua's own markers may become.
    public func tokens(_ text: String, markers: Bool) throws -> [Int32] {
        let bytes = Array(text.utf8)
        guard !bytes.isEmpty else { return [] }
        var capacity = bytes.count + 8
        for _ in 0..<2 {
            var tokens = [llama_token](repeating: 0, count: capacity)
            let count = bytes.withUnsafeBufferPointer { buffer in
                buffer.withMemoryRebound(to: CChar.self) { text in
                    llama_tokenize(vocab, text.baseAddress, Int32(text.count), &tokens, Int32(capacity), false, markers)
                }
            }
            if count >= 0 { return Array(tokens.prefix(Int(count))) }
            guard count != Int32.min else { break }
            capacity = Int(-count)
        }
        throw Failure.tokenize
    }

    /// A marker's tokens (one, for the markers in the model's vocabulary).
    public func marker(_ text: String) throws -> [Int32] {
        if let known = markers[text] { return known }
        let tokens = try tokens(text, markers: true)
        markers[text] = tokens
        return tokens
    }

    /// A token's bytes as the model wrote them, markers included; a
    /// character may continue in the next token's bytes.
    public func bytes(of token: Int32) -> [UInt8] {
        var capacity: Int32 = 64
        for _ in 0..<2 {
            var buffer = [CChar](repeating: 0, count: Int(capacity))
            let count = llama_token_to_piece(vocab, token, &buffer, capacity, 0, true)
            if count >= 0 { return buffer.prefix(Int(count)).map { UInt8(bitPattern: $0) } }
            capacity = -count
        }
        return []
    }

    /// Forgets what the context read, so the next prompt is read whole.
    public func forget() {
        llama_memory_clear(llama_get_memory(context), true)
        held = []
    }

    /// Reads `prompt`, then writes token by token until the model ends its
    /// turn, `maximum` tokens, a full context, `next` says stop, or the
    /// stop signal. `next` gets each token with its bytes before the token
    /// is read; the end-of-turn token never reaches it. `prefilled` gets
    /// the reading's figures once the prompt is read.
    public func generate(prompt: [Int32], maximum: Int, sampling: Sampling,
                         prefilled: (Stats) -> Void = { _ in }, next: (Int32, [UInt8]) -> Next) throws -> Stats {
        var stats = Stats()
        stats.promptTokens = prompt.count
        let window = contextTokens
        guard !prompt.isEmpty, prompt.count < window else { throw Failure.tooLong(tokens: prompt.count, context: window) }
        var start = 0
        if let held, held.count < prompt.count, Array(prompt.prefix(held.count)) == held {
            start = held.count
        } else {
            llama_memory_clear(llama_get_memory(context), true)
        }
        stats.reusedTokens = start
        held = nil
        let began = Date()
        guard try read(prompt, from: start) else { stats.ending = .cancelled; return stats }
        held = prompt
        stats.prefillSeconds = Date().timeIntervalSince(began)
        prefilled(stats)
        return try write(stats, position: prompt.count, reading: prompt, recent: prompt, maximum: maximum, sampling: sampling, next: next)
    }

    /// Reads `tokens` from `index` on, a batch at a time, after what the
    /// context holds; false when stopped on the way.
    func read(_ tokens: [Int32], from index: Int = 0) throws -> Bool {
        var input = tokens, index = index
        while index < input.count {
            if stopSignal.isStopped { return false }
            let count = min(options.batchTokens, input.count - index)
            let result = input.withUnsafeMutableBufferPointer { buffer in
                llama_decode(context, llama_batch_get_one(buffer.baseAddress! + index, Int32(count)))
            }
            if result != 0 {
                if stopSignal.isStopped { return false }
                throw Failure.decode(result)
            }
            index += count
        }
        return true
    }

    /// Empties the context for a prompt with a picture, whose tokens the
    /// next prompt can't be matched against.
    func clearForPicture() {
        llama_memory_clear(llama_get_memory(context), true)
        held = nil
    }

    var isStopped: Bool { stopSignal.isStopped }

    /// Writes after a prompt that is read: `position` places the context
    /// holds, `reading` its tokens when they are all known (none with a
    /// picture), `recent` the prompt's last tokens, for the penalties.
    func write(_ stats: Stats, position: Int, reading: [Int32]?, recent: [Int32], maximum: Int, sampling: Sampling,
               next: (Int32, [UInt8]) -> Next) throws -> Stats {
        var stats = stats, position = position, reading = reading
        let window = contextTokens
        let chain = llama_sampler_chain_init(llama_sampler_chain_default_params())
        defer { llama_sampler_free(chain) }
        if sampling.repeatPenalty != 1 {
            llama_sampler_chain_add(chain, llama_sampler_init_penalties(llama_vocab_n_tokens(vocab), Int32(sampling.repeatLastN),
                                                                        Float(sampling.repeatPenalty), 0, 0))
        }
        llama_sampler_chain_add(chain, llama_sampler_init_top_k(Int32(sampling.topK)))
        llama_sampler_chain_add(chain, llama_sampler_init_top_p(Float(sampling.topP), 1))
        llama_sampler_chain_add(chain, llama_sampler_init_min_p(Float(sampling.minP), 1))
        llama_sampler_chain_add(chain, llama_sampler_init_temp(Float(sampling.temperature)))
        llama_sampler_chain_add(chain, llama_sampler_init_dist(sampling.seed))
        // The prompt's last tokens count for the penalties, as in llama-server.
        for token in recent.suffix(max(0, sampling.repeatLastN)) { llama_sampler_accept(chain, token) }

        let writing = Date()
        while true {
            if stopSignal.isStopped { stats.ending = .cancelled; break }
            if stats.generatedTokens >= maximum { stats.ending = .limit; break }
            if position >= window - 1 { stats.ending = .context; break }
            let token = llama_sampler_sample(chain, context, -1)
            if llama_vocab_is_eog(vocab, token) { stats.ending = .end; break }
            stats.generatedTokens += 1
            var feed = [token]
            switch next(token, bytes(of: token)) {
            case .go: break
            case .stop: stats.ending = .stopped
            case .inject(let extra):
                feed += extra
                for token in extra { llama_sampler_accept(chain, token) }
            }
            if stats.ending == .stopped { break }
            if position + feed.count >= window { stats.ending = .context; break }
            let result = feed.withUnsafeMutableBufferPointer { buffer in
                llama_decode(context, llama_batch_get_one(buffer.baseAddress!, Int32(buffer.count)))
            }
            if result != 0 {
                held = nil
                if stopSignal.isStopped { stats.ending = .cancelled; break }
                throw Failure.decode(result)
            }
            position += feed.count
            reading? += feed
            held = reading
        }
        stats.decodeSeconds = Date().timeIntervalSince(writing)
        return stats
    }
}
