import Foundation
import PocketCore

/// LFM3's replies on llama.cpp (1.1.0 (232)): Fielua's chat in LFM3's
/// format (LFM3Prompt), with as many of the latest turns as fit; the
/// thought split from the answer, never shown, and closed at its budget;
/// the answer's characters put together from its tokens' bytes; a loop
/// stopped once it shows (ReplyContinuation.isLooping). Blocks while it
/// writes; one reply at a time.
public final class LFM3Chat: @unchecked Sendable {
    public enum Event: Sendable {
        /// The prompt is read and the model begins to write.
        case prefilled(LlamaEngine.Stats)
        /// A token of the thought.
        case thought
        /// Text of the answer, in order.
        case answer(String)
    }

    public struct Request: Sendable {
        public var system: String
        /// The chat before the question, oldest first.
        public var turns: [LFM3Prompt.Turn]
        public var question: String
        /// A stopped reply's text to go on from; it never thinks again.
        public var reply: String?
        /// Most tokens of thought before the answer; 0 doesn't think.
        public var thinkingBudget: Int
        /// The prompt's room: earlier turns go, oldest first, until it fits.
        public var inputTokenLimit: Int
        public var sampling: LlamaEngine.Sampling
        public init(system: String, turns: [LFM3Prompt.Turn], question: String, reply: String? = nil, thinkingBudget: Int,
                    inputTokenLimit: Int, sampling: LlamaEngine.Sampling) {
            self.system = system; self.turns = turns; self.question = question; self.reply = reply
            self.thinkingBudget = thinkingBudget; self.inputTokenLimit = inputTokenLimit; self.sampling = sampling
        }
    }

    public struct Outcome: Sendable {
        public var answer = ""
        public var thoughtTokens = 0
        /// The thought reached its budget and was closed for the model.
        public var thoughtClosed = false
        /// Earlier turns left out to fit.
        public var droppedTurns = 0
        public var looped = false
        public var stats = LlamaEngine.Stats()
    }

    public let engine: LlamaEngine
    public init(engine: LlamaEngine) { self.engine = engine }

    /// The prompt's tokens: Fielua's markers as control tokens, every text
    /// (the system prompt, the messages, a file's text) as plain text.
    public func tokens(_ parts: [LFM3Prompt.Part]) throws -> [Int32] {
        try parts.flatMap { part -> [Int32] in
            switch part {
            case .marker(let marker): try engine.marker(marker)
            case .text(let text): try engine.tokens(text, markers: false)
            }
        }
    }

    public func reply(_ request: Request, onEvent: (Event) -> Void) throws -> Outcome {
        let thinking = request.reply == nil && request.thinkingBudget > 0
        var outcome = Outcome()
        var turns = request.turns
        var prompt: [Int32] = []
        while true {
            let parts = LFM3Prompt.parts(system: request.system, turns: turns + [.init(.user, request.question)],
                                         thinking: thinking, reply: request.reply)
            prompt = try tokens(parts)
            if prompt.count <= request.inputTokenLimit || turns.isEmpty { break }
            // An exchange at a time, the oldest first.
            let count = turns.count >= 2 && turns[0].role == .user && turns[1].role == .assistant ? 2 : 1
            turns.removeFirst(count)
            outcome.droppedTurns += count
        }
        let window = engine.contextTokens
        // The question alone may be over the room it was given, but the
        // reply needs some of the window.
        guard prompt.count + 64 < window else { throw LlamaEngine.Failure.tooLong(tokens: prompt.count, context: window) }
        let close = thinking ? try engine.marker(LFM3Prompt.thinkEnd) : []
        var splitter = ThoughtSplitter(thinking: thinking)
        var assembler = UTF8Assembler()
        var unchecked = 0
        let stats = try engine.generate(prompt: prompt, maximum: window, sampling: request.sampling,
                                        prefilled: { onEvent(.prefilled($0)) }) { _, bytes in
            let wasThinking = splitter.thinking
            let part = splitter.feed(assembler.feed(bytes))
            if wasThinking {
                outcome.thoughtTokens += 1
                onEvent(.thought)
            }
            if !part.answer.isEmpty {
                outcome.answer += part.answer
                onEvent(.answer(part.answer))
                unchecked += part.answer.count
            }
            if splitter.ended { return .stop }
            if unchecked >= 32 {
                unchecked = 0
                if ReplyContinuation.isLooping(outcome.answer) {
                    outcome.looped = true
                    return .stop
                }
            }
            if splitter.thinking, outcome.thoughtTokens >= request.thinkingBudget {
                outcome.thoughtClosed = true
                splitter.endThought()
                _ = assembler.flush()
                return .inject(close)
            }
            return .go
        }
        outcome.stats = stats
        if !splitter.ended, !outcome.looped, outcome.stats.ending != .cancelled {
            let last = splitter.feed(assembler.flush()).answer + splitter.flush().answer
            if !last.isEmpty {
                outcome.answer += last
                onEvent(.answer(last))
            }
        }
        return outcome
    }
}
