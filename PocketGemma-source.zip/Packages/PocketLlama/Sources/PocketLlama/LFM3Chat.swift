import Foundation
import PocketCore

/// LFM3's replies on llama.cpp (1.1.0 (232)): Fielua's chat in LFM3's
/// format (LFM3Prompt), with as many of the latest turns as fit; the
/// thought split from the answer, never shown, and closed at its budget;
/// the answer's characters put together from its tokens' bytes; a loop
/// stopped once it shows (ReplyContinuation.isLooping). Blocks while it
/// writes; one reply at a time. With LFM3-VL 2B's projector (`vision`,
/// 1.1.0 (234)) the person's turns carry their pictures, which go with
/// their turn when it is left out to fit.
public final class LFM3Chat: @unchecked Sendable {
    public enum Failure: LocalizedError, Equatable {
        /// Pictures, but no projector to read them.
        case noVision
        public var errorDescription: String? { "this model reads no pictures" }
    }

    public enum Event: Sendable {
        /// The prompt is read and the model begins to write.
        case prefilled(LlamaEngine.Stats)
        /// A token of the thought.
        case thought
        /// Text of the answer, in order.
        case answer(String)
    }

    public struct Request: Sendable {
        public var system: String
        /// The chat before the question, oldest first.
        public var turns: [LFM3Prompt.Turn]
        public var question: String
        /// The question's pictures (JPEG or PNG), read before its text.
        public var questionPictures: [Data]
        /// The earlier turns' pictures, oldest first, as many as their
        /// `pictures` say.
        public var turnPictures: [Data]
        /// A stopped reply's text to go on from; it never thinks again.
        public var reply: String?
        /// Most tokens of thought before the answer; 0 doesn't think.
        public var thinkingBudget: Int
        /// The prompt's room: earlier turns go, oldest first, until it fits.
        public var inputTokenLimit: Int
        public var sampling: LlamaEngine.Sampling
        public init(system: String, turns: [LFM3Prompt.Turn], question: String, questionPictures: [Data] = [],
                    turnPictures: [Data] = [], reply: String? = nil, thinkingBudget: Int,
                    inputTokenLimit: Int, sampling: LlamaEngine.Sampling) {
            self.system = system; self.turns = turns; self.question = question
            self.questionPictures = questionPictures; self.turnPictures = turnPictures; self.reply = reply
            self.thinkingBudget = thinkingBudget; self.inputTokenLimit = inputTokenLimit; self.sampling = sampling
        }
    }

    public struct Outcome: Sendable {
        public var answer = ""
        public var thoughtTokens = 0
        /// The thought reached its budget and was closed for the model.
        public var thoughtClosed = false
        /// Earlier turns left out to fit.
        public var droppedTurns = 0
        public var looped = false
        public var stats = LlamaEngine.Stats()
        /// The pictures read, their tokens and seconds.
        public var pictures = LlamaVision.Pictures()
    }

    public let engine: LlamaEngine
    public let vision: LlamaVision?
    public init(engine: LlamaEngine, vision: LlamaVision? = nil) { self.engine = engine; self.vision = vision }

    /// The prompt's tokens: Fielua's markers as control tokens, every text
    /// (the system prompt, the messages, a file's text) as plain text.
    public func tokens(_ parts: [LFM3Prompt.Part]) throws -> [Int32] {
        try parts.flatMap { part -> [Int32] in
            switch part {
            case .marker(let marker): try engine.marker(marker)
            case .text(let text): try engine.tokens(text, markers: false)
            case .picture: throw Failure.noVision
            }
        }
    }

    /// The prompt in pieces for the projector: runs of tokens, and the
    /// pictures in order where the parts place them; and its places.
    func pieces(_ parts: [LFM3Prompt.Part], pictures: [(data: Data, places: Int)]) throws -> (pieces: [LlamaVision.Piece], places: Int) {
        var pieces: [LlamaVision.Piece] = [], run: [Int32] = [], places = 0, next = 0
        for part in parts {
            switch part {
            case .picture:
                if !run.isEmpty { pieces.append(.tokens(run)); places += run.count; run = [] }
                guard next < pictures.count else { throw Failure.noVision }
                pieces.append(.picture(pictures[next].data))
                places += pictures[next].places
                next += 1
            default:
                run += try tokens([part])
            }
        }
        if !run.isEmpty { pieces.append(.tokens(run)); places += run.count }
        return (pieces, places)
    }

    public func reply(_ request: Request, onEvent: (Event) -> Void) throws -> Outcome {
        let thinking = request.reply == nil && request.thinkingBudget > 0
        var outcome = Outcome()
        var turns = request.turns
        // Each picture's places, found once.
        func sized(_ pictures: [Data]) throws -> [(data: Data, places: Int)] {
            guard !pictures.isEmpty else { return [] }
            guard let vision else { throw Failure.noVision }
            return try pictures.map { ($0, try vision.places($0)) }
        }
        var turnPictures = try sized(request.turnPictures)
        let questionPictures = try sized(request.questionPictures)
        var prompt: [Int32] = []
        var pieces: [LlamaVision.Piece] = []
        var places = 0
        let question = LFM3Prompt.Turn(.user, request.question, pictures: request.questionPictures.count)
        while true {
            let parts = LFM3Prompt.parts(system: request.system, turns: turns + [question],
                                         thinking: thinking, reply: request.reply)
            if parts.contains(.picture) {
                (pieces, places) = try self.pieces(parts, pictures: turnPictures + questionPictures)
            } else {
                prompt = try tokens(parts)
                pieces = []
                places = prompt.count
            }
            if places <= request.inputTokenLimit || turns.isEmpty { break }
            // An exchange at a time, the oldest first, with its pictures.
            let count = turns.count >= 2 && turns[0].role == .user && turns[1].role == .assistant ? 2 : 1
            turnPictures.removeFirst(min(turnPictures.count, turns.prefix(count).reduce(0) { $0 + $1.pictures }))
            turns.removeFirst(count)
            outcome.droppedTurns += count
        }
        let window = engine.contextTokens
        // The question alone may be over the room it was given, but the
        // reply needs some of the window.
        guard places + 64 < window else { throw LlamaEngine.Failure.tooLong(tokens: places, context: window) }
        let close = thinking ? try engine.marker(LFM3Prompt.thinkEnd) : []
        var splitter = ThoughtSplitter(thinking: thinking)
        var assembler = UTF8Assembler()
        var unchecked = 0
        func write(_ token: Int32, _ bytes: [UInt8]) -> LlamaEngine.Next {
            let wasThinking = splitter.thinking
            let part = splitter.feed(assembler.feed(bytes))
            if wasThinking {
                outcome.thoughtTokens += 1
                onEvent(.thought)
            }
            if !part.answer.isEmpty {
                outcome.answer += part.answer
                onEvent(.answer(part.answer))
                unchecked += part.answer.count
            }
            if splitter.ended { return .stop }
            if unchecked >= 32 {
                unchecked = 0
                if ReplyContinuation.isLooping(outcome.answer) {
                    outcome.looped = true
                    return .stop
                }
            }
            if splitter.thinking, outcome.thoughtTokens >= request.thinkingBudget {
                outcome.thoughtClosed = true
                splitter.endThought()
                _ = assembler.flush()
                return .inject(close)
            }
            return .go
        }
        let stats: LlamaEngine.Stats
        if let vision, !pieces.isEmpty {
            stats = try vision.generate(pieces, maximum: window, sampling: request.sampling,
                                        prefilled: { onEvent(.prefilled($0)) }, next: write)
            outcome.pictures = vision.lastPictures
        } else {
            stats = try engine.generate(prompt: prompt, maximum: window, sampling: request.sampling,
                                        prefilled: { onEvent(.prefilled($0)) }, next: write)
        }
        outcome.stats = stats
        if !splitter.ended, !outcome.looped, outcome.stats.ending != .cancelled {
            let last = splitter.feed(assembler.flush()).answer + splitter.flush().answer
            if !last.isEmpty {
                outcome.answer += last
                onEvent(.answer(last))
            }
        }
        return outcome
    }
}
