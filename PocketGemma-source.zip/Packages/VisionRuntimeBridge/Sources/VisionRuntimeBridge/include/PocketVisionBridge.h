#ifndef POCKET_VISION_BRIDGE_H
#define POCKET_VISION_BRIDGE_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int32_t status;
    int32_t stage;
    int32_t kernel_mode;
    int32_t input_count;
    int32_t output_count;
    uint64_t output_elements;
    uint64_t nonfinite_elements;
    char tensors[2048];
    char error[6000];
} PGVisionProbeResult;

// Diagnostic component invocation only. The file is an unmodified section
// from the verified model. No process-wide flags or memory limits change.
// kernel_mode: 0 = delegate, 2 = optimized built-in CPU (no XNNPACK).
void PGRunVisionComponent(const char *model_path, const char *signature,
                         int32_t kernel_mode, PGVisionProbeResult *result);
const char *PGVisionProbeStage(int32_t stage);
const char *PGVisionProbeError(const PGVisionProbeResult *result);
const char *PGVisionProbeTensors(const PGVisionProbeResult *result);
uint64_t PGProcessMemoryFootprint(void);
uint64_t PGProcessVirtualSize(void);
uint64_t PGProcessRegionCount(void);
#ifdef __cplusplus
}
#endif
#endif
