import XCTest
@testable import PocketCore

/// スタンダード's pills and the keyboard (fielua-reports #3): a hardware
/// keyboard's notices never put them away, an on-screen keyboard going
/// down still does, and with a hardware keyboard they always stand.
final class ComposerKeyboardTests: XCTestCase {
    /// The tester's iPad (send record, 2026-10-28): a 1389×970 window, the
    /// keyboard's frames (0,970 1389×470) and (0,970 0×0) over and over.
    func testAHardwareKeyboardsNoticesAreNoLeave() {
        XCTAssertFalse(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 970, beginHeight: 470, endTop: 970))
        XCTAssertFalse(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 970, beginHeight: 0, endTop: 970))
        XCTAssertFalse(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 970, beginHeight: 470, endTop: 970.5))
    }

    func testTheShortcutsBarIsNoKeyboard() {
        XCTAssertFalse(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 915, beginHeight: 55, endTop: 970))
    }

    /// The iPad simulator's keyboard (run 40702339896) and an iPhone's.
    func testAnOnScreenKeyboardGoingDownLeaves() {
        XCTAssertTrue(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 572, beginHeight: 460, endTop: 1032))
        XCTAssertTrue(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 534, beginHeight: 498, endTop: 1032))
        XCTAssertTrue(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 538, beginHeight: 336, endTop: 874))
        // Let go halfway through an interactive dismissal.
        XCTAssertTrue(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 800, beginHeight: 336, endTop: 874))
    }

    func testWithoutFramesItLeavesAsBefore() {
        XCTAssertTrue(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: nil, beginHeight: nil, endTop: 874))
        XCTAssertTrue(ComposerKeyboard.onScreenKeyboardLeaves(beginTop: 538, beginHeight: 336, endTop: nil))
    }

    func testWithoutAHardwareKeyboardThePillsFollowTheField() {
        XCTAssertTrue(ComposerKeyboard.classicPillsShown(focused: true, keyboardLeaving: false, actionsOpen: false, hardwareKeyboard: false))
        XCTAssertFalse(ComposerKeyboard.classicPillsShown(focused: false, keyboardLeaving: false, actionsOpen: false, hardwareKeyboard: false))
        XCTAssertFalse(ComposerKeyboard.classicPillsShown(focused: true, keyboardLeaving: true, actionsOpen: false, hardwareKeyboard: false))
        XCTAssertFalse(ComposerKeyboard.classicPillsShown(focused: true, keyboardLeaving: false, actionsOpen: true, hardwareKeyboard: false))
    }

    /// A menu that takes the keys from the field, or a notice that says the
    /// keyboard hides, leaves them where they are.
    func testWithAHardwareKeyboardThePillsStay() {
        XCTAssertTrue(ComposerKeyboard.classicPillsShown(focused: false, keyboardLeaving: false, actionsOpen: false, hardwareKeyboard: true))
        XCTAssertTrue(ComposerKeyboard.classicPillsShown(focused: true, keyboardLeaving: true, actionsOpen: false, hardwareKeyboard: true))
        XCTAssertFalse(ComposerKeyboard.classicPillsShown(focused: true, keyboardLeaving: false, actionsOpen: true, hardwareKeyboard: true),
                       "The plus panel still covers them")
    }
}
