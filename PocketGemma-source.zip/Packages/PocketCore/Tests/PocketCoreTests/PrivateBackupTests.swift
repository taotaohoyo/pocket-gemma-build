import XCTest
@testable import PocketCore

/// Fielua's own iCloud backup (1.1.0 (252)), on a plain folder standing in
/// for the iCloud container.
final class PrivateBackupTests: XCTestCase {
    private var work: URL!
    private var local: URL!
    private var backup: PrivateBackup!
    private let phone = UUID().uuidString
    private let pad = UUID().uuidString

    override func setUpWithError() throws {
        work = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        local = work.appendingPathComponent("Attachments", isDirectory: true)
        try FileManager.default.createDirectory(at: local, withIntermediateDirectories: true)
        backup = PrivateBackup(container: work.appendingPathComponent("Container", isDirectory: true))
    }

    override func tearDownWithError() throws {
        try? FileManager.default.removeItem(at: work)
    }

    private func photo(_ name: String, _ text: String = "jpeg") throws -> ChatAttachment {
        try Data(text.utf8).write(to: local.appendingPathComponent(name))
        return ChatAttachment(kind: .image, name: "photo.jpg", storedName: name)
    }

    private func chat(_ text: String, _ attachments: [ChatAttachment] = []) -> ChatThread {
        var thread = ChatThread(modelID: ModelSpec.e2b.id)
        thread.messages = [ChatMessage(role: .user, text: text, attachments: attachments),
                           ChatMessage(role: .assistant, text: "答え: " + text)]
        return thread
    }

    private func source(_ name: String) -> URL? { local.appendingPathComponent(name) }

    private func media(_ device: String) throws -> [String] {
        try FileManager.default.contentsOfDirectory(atPath: backup.deviceFolder(device)
            .appendingPathComponent(PrivateBackup.attachmentsName).path).sorted()
    }

    func testTheBackupIsOutsideTheContainersDocumentsFolder() {
        // The Files app and iCloud Drive list only <container>/Documents.
        XCTAssertEqual(backup.root.lastPathComponent, "Backup")
        XCTAssertFalse(backup.root.pathComponents.contains("Documents"))
    }

    func testSaveWritesTheConversationsAndTheAttachmentsTheyUse() throws {
        let threads = [chat("旅行の持ち物", [try photo("a.jpg")]), chat("天気")]
        let saved = try backup.save(threads, deviceID: phone, source: source)
        XCTAssertEqual(saved, PrivateBackup.Saved(copied: 1, removed: 0))
        XCTAssertEqual(try media(phone), ["a.jpg"])
        let archive = try backup.deviceFolder(phone).appendingPathComponent(PrivateBackup.archiveName)
        XCTAssertEqual(try ChatArchive(fileURL: archive).load().map(\.id), threads.map(\.id))
        XCTAssertEqual(try ChatArchive(fileURL: archive).load().flatMap(\.messages).map(\.text), threads.flatMap(\.messages).map(\.text))
        // Saving again copies nothing new.
        XCTAssertEqual(try backup.save(threads, deviceID: phone, source: source), PrivateBackup.Saved(copied: 0, removed: 0))
    }

    func testADeletedChatsAttachmentsLeaveTheBackupWithIt() throws {
        let kept = chat("残す", [try photo("keep.jpg")])
        let gone = chat("消す", [try photo("gone.jpg"), try photo("gone2.jpg")])
        try backup.save([kept, gone], deviceID: phone, source: source)
        XCTAssertEqual(try media(phone), ["gone.jpg", "gone2.jpg", "keep.jpg"])
        let saved = try backup.save([kept], deviceID: phone, source: source)
        XCTAssertEqual(saved.removed, 2)
        XCTAssertEqual(try media(phone), ["keep.jpg"])
        let archive = try backup.deviceFolder(phone).appendingPathComponent(PrivateBackup.archiveName)
        XCTAssertEqual(try ChatArchive(fileURL: archive).load().map(\.id), [kept.id])
    }

    func testOneDeviceNeverRemovesAnotherDevicesFiles() throws {
        try backup.save([chat("iPad の会話", [try photo("pad.jpg")])], deviceID: pad, source: source)
        try backup.save([], deviceID: phone, source: source)
        XCTAssertEqual(try media(pad), ["pad.jpg"])
        XCTAssertTrue(FileManager.default.fileExists(atPath: try backup.deviceFolder(pad)
            .appendingPathComponent(PrivateBackup.archiveName).path))
    }

    func testAnArchiveIsNotWrittenWhileAnAttachmentItNamesIsMissing() throws {
        let missing = ChatAttachment(kind: .image, name: "photo.jpg", storedName: "nowhere.jpg")
        XCTAssertThrowsError(try backup.save([chat("写真", [missing])], deviceID: phone, source: source))
        XCTAssertFalse(FileManager.default.fileExists(atPath: try backup.deviceFolder(phone)
            .appendingPathComponent(PrivateBackup.archiveName).path))
    }

    func testADeviceIDIsNeverAPath() {
        for id in ["../escape", "", "Backup", "a/b"] {
            XCTAssertThrowsError(try backup.save([], deviceID: id, source: source), id)
        }
    }

    func testRestoreMergesEveryDeviceAndBringsBackTheirAttachments() throws {
        let phoneChat = chat("iPhone の会話", [try photo("p.jpg", "phone")])
        let padChat = chat("iPad の会話", [try photo("q.jpg", "pad")])
        try backup.save([phoneChat], deviceID: phone, source: source)
        try backup.save([padChat], deviceID: pad, source: source)
        let restoredMedia = work.appendingPathComponent("Restored", isDirectory: true)
        var prepared: [String] = []
        let restored = try backup.restore(prepare: { prepared.append($0.lastPathComponent) },
                                          destination: { restoredMedia.appendingPathComponent($0) })
        XCTAssertEqual(Set(restored.map(\.id)), [phoneChat.id, padChat.id])
        XCTAssertEqual(try String(contentsOf: restoredMedia.appendingPathComponent("p.jpg"), encoding: .utf8), "phone")
        XCTAssertEqual(try String(contentsOf: restoredMedia.appendingPathComponent("q.jpg"), encoding: .utf8), "pad")
        // Every file is made ready (downloaded from iCloud) before it is read.
        XCTAssertEqual(prepared.filter { $0 == PrivateBackup.archiveName }.count, 2)
        XCTAssertEqual(Set(prepared.filter { $0.hasSuffix(".jpg") }), ["p.jpg", "q.jpg"])
        // An attachment already on the phone is left as it is.
        prepared = []
        _ = try backup.restore(prepare: { prepared.append($0.lastPathComponent) },
                               destination: { restoredMedia.appendingPathComponent($0) })
        XCTAssertFalse(prepared.contains("p.jpg"))
    }

    func testRestoreFailsWhenAnAttachmentHasNotArrivedRatherThanLosingIt() throws {
        try backup.save([chat("写真", [try photo("late.jpg")])], deviceID: phone, source: source)
        try FileManager.default.removeItem(at: backup.deviceFolder(phone)
            .appendingPathComponent(PrivateBackup.attachmentsName).appendingPathComponent("late.jpg"))
        let restoredMedia = work.appendingPathComponent("Restored", isDirectory: true)
        XCTAssertThrowsError(try backup.restore(prepare: { _ in }, destination: { restoredMedia.appendingPathComponent($0) }))
    }

    func testRestoreWithNoBackupThrows() throws {
        XCTAssertThrowsError(try backup.restore(prepare: { _ in }, destination: { _ in nil }))
        try backup.save([], deviceID: phone, source: source)
        XCTAssertThrowsError(try backup.restore(prepare: { _ in }, destination: { _ in nil }))
    }

    func testRestoreSkipsALinkedDeviceFolderAndOddNames() throws {
        let real = chat("本物")
        try backup.save([real], deviceID: phone, source: source)
        let elsewhere = work.appendingPathComponent("Elsewhere", isDirectory: true)
        let other = PrivateBackup(container: elsewhere)
        try other.save([chat("外")], deviceID: pad, source: source)
        try FileManager.default.createSymbolicLink(at: backup.root.appendingPathComponent(pad),
                                                   withDestinationURL: try other.deviceFolder(pad))
        try FileManager.default.createDirectory(at: backup.root.appendingPathComponent("not-a-device"), withIntermediateDirectories: true)
        let restored = try backup.restore(prepare: { _ in }, destination: { _ in nil })
        XCTAssertEqual(restored.map(\.id), [real.id])
    }

    func testAStandInForAFileStillInICloudCountsAsThatFile() throws {
        XCTAssertEqual(PrivateBackup.itemName(".photo.jpg.icloud"), "photo.jpg")
        XCTAssertEqual(PrivateBackup.itemName("photo.jpg"), "photo.jpg")
        XCTAssertNil(PrivateBackup.itemName(".DS_Store"))
        XCTAssertNil(PrivateBackup.itemName(".icloud"))
        // A stand-in already in the backup is not copied over again.
        let attachment = try photo("cloud.jpg")
        let folder = try backup.deviceFolder(phone).appendingPathComponent(PrivateBackup.attachmentsName, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try Data().write(to: folder.appendingPathComponent(".cloud.jpg.icloud"))
        XCTAssertEqual(try backup.save([chat("写真", [attachment])], deviceID: phone, source: source).copied, 0)
        // And it is removed when no conversation uses it.
        XCTAssertEqual(try backup.save([], deviceID: phone, source: source).removed, 1)
        XCTAssertEqual(try media(phone), [])
    }
}
