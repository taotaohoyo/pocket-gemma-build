import XCTest
@testable import PocketCore

/// LFM3-Omni 2B on llama.cpp (1.1.0 (236)): its two pinned files, and a
/// question spoken into the app (VoiceNote), which only it takes.
final class LFM3OmniTests: XCTestCase {
    func testItsTwoFilesArePinned() {
        let omni = ModelSpec.lfm3Omni, projector = ModelSpec.lfm3OmniProjector
        XCTAssertEqual(omni.runtime, .llamaCpp); XCTAssertEqual(projector.runtime, .llamaCpp)
        XCTAssertEqual(omni.byteCount, 1_049_617_920)
        XCTAssertEqual(omni.sha256, "6d2273a383b92dd7c5db0eb4c8dfeae13e805b485a6621c4b391ae179c2b5f28")
        XCTAssertEqual(projector.byteCount, 540_892_768)
        XCTAssertEqual(projector.sha256, "720ff4fc09df0e026c4ec641d0c698bf27b5bcd50561944c88eda5e3dffe1839")
        for spec in [omni, projector] {
            XCTAssertTrue(spec.downloadURL.absoluteString.hasPrefix(
                "https://huggingface.co/LiquidAI/LFM3-Omni-2B-GGUF/resolve/2918dd47cfceb4f260cd1734cd1aac1b22bbe4b6/\(spec.fileName)"), spec.id)
        }
        XCTAssertEqual(omni.family, "LFM")
        XCTAssertTrue(omni.isTestVersion)
        XCTAssertFalse(omni.isDeveloperOnly); XCTAssertFalse(omni.isStarter); XCTAssertFalse(omni.isLocked)
        XCTAssertEqual(ModelSpec.catalog.last?.id, omni.id, "last in the list, after LFM3-VL 2B")
    }

    func testTheProjectorBelongsToTheModel() {
        let omni = ModelSpec.lfm3Omni, projector = ModelSpec.lfm3OmniProjector
        XCTAssertEqual(omni.parts.map(\.id), [projector.id])
        XCTAssertEqual(omni.files.map(\.id), [omni.id, projector.id])
        XCTAssertEqual(projector.owner.id, omni.id)
        XCTAssertNil(ModelSpec.find(projector.id), "it can't be chosen")
        XCTAssertEqual(ModelSpec.findFile(projector.id)?.id, projector.id)
        XCTAssertEqual(omni.downloadByteCount, 1_049_617_920 + 540_892_768)
        XCTAssertNotEqual(projector.fileName, ModelSpec.lfm3VLProjector.fileName, "each model keeps its own projector")
    }

    /// A spoken question, photos and text; no videos, files, thinking or
    /// web search. Only Omni hears a voice.
    func testWhatItTakesIn() {
        let omni = ModelSpec.lfm3Omni, capabilities = omni.capabilities
        XCTAssertTrue(omni.supportsVoice); XCTAssertTrue(omni.supportsVision)
        XCTAssertFalse(capabilities.videos); XCTAssertFalse(capabilities.documents); XCTAssertFalse(omni.supportsThinking)
        XCTAssertFalse(omni.supportsWebSearch); XCTAssertFalse(omni.supportsSpeculation)
        XCTAssertEqual(omni.maximumContextTokens, 8192)
        XCTAssertEqual(ModelSpec.catalog.filter(\.supportsVoice).map(\.id), [omni.id])
        let policy = ModelAttachmentPolicy(model: omni)
        XCTAssertTrue(policy.allowsVoice); XCTAssertTrue(policy.allowsPhotos); XCTAssertFalse(policy.allowsVideo)
        XCTAssertFalse(policy.allowsDocuments); XCTAssertTrue(policy.allowsAnyAttachment)
        XCTAssertEqual(policy.summary, "テキスト・写真・音声")
        XCTAssertEqual(policy.guidance, "写真と、話しかけた音声を利用できます。動画やファイルを使うにはGemma 4 E2Bへ切り替えてください。")
        // Everything else reads as before.
        XCTAssertEqual(ModelAttachmentPolicy(model: .lfm3VL).summary, "テキスト・写真")
        XCTAssertEqual(ModelAttachmentPolicy(model: .lfm3).summary, "テキスト")
        XCTAssertFalse(ModelAttachmentPolicy.voiceGuidance.isEmpty)
        let settings = GenerationSettings(for: omni).normalized(for: omni)
        XCTAssertEqual(settings.temperature, 0.1); XCTAssertEqual(settings.topK, 50)
        XCTAssertEqual(settings.thinkingTokenBudget(on: omni), 0)
    }

    /// A recording goes only to Omni, and only as the app makes it.
    func testARecordingGoesOnlyToOmni() {
        let id = UUID()
        let recording = VoiceNote.attachment(id: id, seconds: 4.2, byteCount: 134_444)
        XCTAssertEqual(recording.kind, .audio)
        XCTAssertEqual(recording.storedName, id.uuidString + "-voice.wav")
        XCTAssertEqual(recording.name, "音声 0:04")
        XCTAssertEqual(recording.duration, 4.2)
        XCTAssertTrue(VoiceNote.isRecording(recording))
        XCTAssertTrue(ModelAttachmentPolicy(model: .lfm3Omni).allows(recording))
        for spec in ModelSpec.catalog where spec.id != ModelSpec.lfm3Omni.id {
            XCTAssertFalse(ModelAttachmentPolicy(model: spec).allows(recording), spec.id)
            XCTAssertThrowsError(try ModelAttachmentPolicy(model: spec).validateNewAttachments([recording]), spec.id)
        }
        // Not the app's own recording: too short, too long, renamed, or
        // carrying anything else.
        let omni = ModelAttachmentPolicy(model: .lfm3Omni)
        XCTAssertFalse(omni.allows(VoiceNote.attachment(seconds: 0.3, byteCount: 9_600)))
        XCTAssertFalse(omni.allows(VoiceNote.attachment(seconds: 75, byteCount: 2_400_000)))
        XCTAssertFalse(omni.allows(ChatAttachment(id: id, kind: .audio, name: "音声 0:04", storedName: "talk.mp3",
                                                  byteCount: 1, duration: 4)))
        XCTAssertFalse(omni.allows(ChatAttachment(id: id, kind: .audio, name: "音声", storedName: VoiceNote.storedName(id),
                                                  byteCount: 1)), "a recording knows its length")
        XCTAssertFalse(omni.allows(ChatAttachment(id: id, kind: .audio, name: "音声 0:04", storedName: VoiceNote.storedName(id),
                                                  imageNames: ["a.jpg"], byteCount: 1, duration: 4)))
        // Omni hears the recording in an earlier turn too; another model
        // gets the turn without it, and a note that says so.
        let earlier = [ChatMessage(role: .user, text: VoiceNote.ask, attachments: [recording]),
                       ChatMessage(role: .assistant, text: "東京です。")]
        XCTAssertEqual(omni.inferenceHistory(earlier)[0].media, [recording])
        let other = ModelAttachmentPolicy(model: .lfm3).inferenceHistory(earlier)
        XCTAssertTrue(other[0].media.isEmpty)
        XCTAssertTrue(other[0].text.hasSuffix(ModelAttachmentPolicy.earlierAttachmentsNote))
    }

    /// A recording's room in the context follows its length, and a chat
    /// opened by voice alone is named 音声.
    func testItsRoomAndItsChatsName() {
        let short = VoiceNote.attachment(seconds: 2, byteCount: 64_044)
        let long = VoiceNote.attachment(seconds: 60, byteCount: 1_920_044)
        XCTAssertEqual(VoiceNote.places(seconds: 1.85), 26, "23 places for 1.85 s (run 40796978426), and its markers")
        XCTAssertGreaterThan(long.contextByteCost, short.contextByteCost)
        XCTAssertEqual(long.contextByteCost, long.name.utf8.count + VoiceNote.places(seconds: 60) * 2)
        let settings = GenerationSettings(for: .lfm3Omni).normalized(for: .lfm3Omni)
        XCTAssertLessThan(long.contextByteCost, settings.inputByteBudget, "a minute's question fits a turn")
        XCTAssertEqual(short.modelImageNames(settings), [], "a recording is no picture")
        var asked = ChatMessage(role: .user, text: VoiceNote.ask, attachments: [short])
        asked.hidesText = true
        var thread = ChatThread(modelID: ModelSpec.lfm3Omni.id)
        thread.messages = [asked]
        XCTAssertEqual(thread.title, "音声")
        XCTAssertEqual(VoiceNote.clock(0), "0:00"); XCTAssertEqual(VoiceNote.clock(59.6), "1:00"); XCTAssertEqual(VoiceNote.clock(75), "1:15")
    }
}
