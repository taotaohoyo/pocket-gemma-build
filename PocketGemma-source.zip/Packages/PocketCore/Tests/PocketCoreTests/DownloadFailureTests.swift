import XCTest
@testable import PocketCore

/// 1.1.0 (240): why a download stopped, in words that tell a network error,
/// the Hub's answer, a file that failed its check and a full phone apart;
/// how long a download has gone without a byte; and the pins every
/// download starts from.
final class DownloadFailureTests: XCTestCase {
    private func urlError(_ code: Int) -> NSError { NSError(domain: NSURLErrorDomain, code: code) }

    func testURLErrorsAreSortedByWhatToDo() {
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorNotConnectedToInternet)), .offline)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorDataNotAllowed)), .offline)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorNetworkConnectionLost)), .connectionLost)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorTimedOut)), .connectionLost)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorCannotFindHost)), .serverUnreachable)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorCannotConnectToHost)), .serverUnreachable)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorSecureConnectionFailed)), .secureConnection)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorAppTransportSecurityRequiresSecureConnection)), .secureConnection)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorCannotWriteToFile)), .noSpace)
        XCTAssertEqual(DownloadFailure.from(NSError(domain: NSCocoaErrorDomain, code: NSFileWriteOutOfSpaceError)), .noSpace)
        XCTAssertEqual(DownloadFailure.from(NSError(domain: NSPOSIXErrorDomain, code: Int(ENOSPC))), .noSpace)
        XCTAssertEqual(DownloadFailure.from(NSError(domain: NSCocoaErrorDomain, code: 4, userInfo: [
            NSUnderlyingErrorKey: NSError(domain: NSPOSIXErrorDomain, code: Int(ENOSPC))])), .noSpace)
        XCTAssertEqual(DownloadFailure.from(urlError(NSURLErrorBadServerResponse)), .other(NSURLErrorDomain, NSURLErrorBadServerResponse))
    }

    func testTheFileCheckIsNeverANetworkError() {
        XCTAssertEqual(DownloadFailure.from(ModelValidationError.wrongChecksum), .wrongChecksum)
        XCTAssertEqual(DownloadFailure.from(ModelValidationError.wrongSize(5, 9)), .wrongSize(5, 9))
        XCTAssertEqual(DownloadFailure.wrongChecksum.kind, .file)
        XCTAssertEqual(DownloadFailure.wrongSize(5, 9).kind, .file)
        XCTAssertEqual(DownloadFailure.connectionLost.kind, .network)
        XCTAssertEqual(DownloadFailure.http(403).kind, .server)
        XCTAssertEqual(DownloadFailure.noSpace.kind, .storage)
        XCTAssertTrue(DownloadFailure.wrongChecksum.message().hasPrefix("ファイル確認エラー："))
        XCTAssertTrue(DownloadFailure.wrongChecksum.message().contains("SHA-256"))
        XCTAssertTrue(DownloadFailure.wrongSize(5, 9).message().contains("5 / 9"))
        XCTAssertTrue(DownloadFailure.connectionLost.message().hasPrefix("通信エラー："))
        XCTAssertTrue(DownloadFailure.http(404).message().hasPrefix("配布元のエラー："))
        XCTAssertTrue(DownloadFailure.noSpace.message().hasPrefix("空き容量不足："))
    }

    func testTheHubsAnswers() {
        XCTAssertNil(DownloadFailure.from(status: 200))
        XCTAssertNil(DownloadFailure.from(status: 206))
        XCTAssertEqual(DownloadFailure.from(status: 403), .http(403))
        XCTAssertEqual(DownloadFailure.from(status: 0), .http(0), "no answer at all is not a file either")
        XCTAssertTrue(DownloadFailure.http(404).message().contains("HTTP 404"))
        XCTAssertTrue(DownloadFailure.http(429).message().contains("混み合っています"))
        XCTAssertTrue(DownloadFailure.http(503).message().contains("HTTP 503"))
        XCTAssertTrue(DownloadFailure.http(403).message().contains("HTTP 403"))
        XCTAssertTrue(DownloadFailure.http(418).message().contains("HTTP 418"))
    }

    /// Starting again at once helps a link that ran out (the Hub's CDN link
    /// lasts an hour), a broken connection or a stall; not a missing file,
    /// a full phone or no network.
    func testOnlyWhatCanHelpStartsAgainAtOnce() {
        for failure: DownloadFailure in [.connectionLost, .stalled, .http(403), .http(410), .http(416), .http(500), .http(503)] {
            XCTAssertTrue(failure.retriesAtOnce, "\(failure)")
        }
        for failure: DownloadFailure in [.offline, .noSpace, .http(404), .http(429), .wrongChecksum, .wrongSize(1, 2),
                                         .serverUnreachable, .secureConnection, .other("x", 1)] {
            XCTAssertFalse(failure.retriesAtOnce, "\(failure)")
        }
    }

    func testKeptBytesAreSaid() {
        XCTAssertFalse(DownloadFailure.stalled.message().contains("続きから"))
        XCTAssertTrue(DownloadFailure.stalled.message(keepsReceived: true).hasSuffix("次は続きから受け取ります。"))
    }

    func testStallCountsFromTheLastNewByte() {
        let start = Date(timeIntervalSince1970: 1_000)
        var stall = DownloadStall(bytes: 0, now: start)
        XCTAssertEqual(stall.idle(received: 0, now: start.addingTimeInterval(10)), 10)
        XCTAssertEqual(stall.idle(received: 0, now: start.addingTimeInterval(DownloadStall.restartAfter)), DownloadStall.restartAfter)
        XCTAssertEqual(stall.idle(received: 4096, now: start.addingTimeInterval(50)), 0, "a new byte starts the count again")
        XCTAssertEqual(stall.idle(received: 4096, now: start.addingTimeInterval(70)), 20)
        XCTAssertLessThan(DownloadStall.noticeAfter, DownloadStall.restartAfter)
        XCTAssertGreaterThanOrEqual(DownloadStall.restarts, 1)
    }

    /// What a stopped download received is kept per file, next to the
    /// receipts, never in the Files app's model folder.
    func testResumeDataHasAPlaceForEachFile() {
        let library = ModelLibrary(directory: URL(fileURLWithPath: "/m"), stateDirectory: URL(fileURLWithPath: "/s"))
        let places = ModelSpec.allFiles.map { library.resumeURL($0).path }
        XCTAssertEqual(Set(places).count, ModelSpec.allFiles.count)
        XCTAssertTrue(places.allSatisfy { $0.hasPrefix("/s/") && $0.hasSuffix(".resume") })
        XCTAssertEqual(library.resumeURL(.lfm3VLProjector).lastPathComponent, "lfm3-vl-2b-mmproj.resume")
        for file in ModelSpec.allFiles {
            XCTAssertNotEqual(library.resumeURL(file), library.pendingURL(file))
            XCTAssertNotEqual(library.resumeURL(file), library.receiptURL(file))
        }
    }

    /// Every file the app downloads is pinned: a Hub resolve link at a
    /// full revision, the file's own name, a SHA-256. run 40825923927 took
    /// every one of them whole and matched size and SHA-256.
    func testEveryDownloadIsPinned() throws {
        XCTAssertEqual(ModelSpec.allFiles.count, 12)
        XCTAssertEqual(Set(ModelSpec.allFiles.map(\.id)).count, 12)
        for file in ModelSpec.allFiles {
            let url = file.downloadURL
            XCTAssertEqual(url.scheme, "https")
            XCTAssertEqual(url.host, "huggingface.co")
            let path = url.pathComponents
            let resolve = try XCTUnwrap(path.firstIndex(of: "resolve"), file.id)
            let revision = path[resolve + 1]
            XCTAssertEqual(revision.count, 40, file.id)
            XCTAssertTrue(revision.allSatisfy(\.isHexDigit), file.id)
            XCTAssertEqual(url.lastPathComponent, file.fileName, file.id)
            XCTAssertEqual(file.sha256.count, 64, file.id)
            XCTAssertTrue(file.sha256.allSatisfy { $0.isHexDigit && !$0.isUppercase }, file.id)
            XCTAssertGreaterThan(file.byteCount, 100_000_000, file.id)
        }
    }
}
