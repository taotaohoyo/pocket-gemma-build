import XCTest
@testable import PocketCore

/// A video reaches Gemma as three of its scenes, each after its time.
final class VideoScenesTests: XCTestCase {
    func testScenesSitNearTheStartMiddleAndEndInOrder() {
        XCTAssertEqual(VideoScenes.times(duration: 12), [0.5, 6, 11.5])
        // A short clip keeps its scenes inside it, in order.
        let short = VideoScenes.times(duration: 2)
        XCTAssertEqual(short.count, VideoScenes.count)
        XCTAssertEqual(short[0], 0.2, accuracy: 0.0001); XCTAssertEqual(short[1], 1); XCTAssertEqual(short[2], 1.8, accuracy: 0.0001)
        for duration in [0.04, 0.5, 1, 3.3, 59.9, 3600] {
            let times = VideoScenes.times(duration: duration)
            XCTAssertEqual(times.count, VideoScenes.count, "\(duration)")
            XCTAssertEqual(times, times.sorted(), "\(duration)")
            XCTAssertTrue(times.allSatisfy { $0 >= 0 && $0 < duration }, "\(duration): \(times)")
        }
        XCTAssertEqual(VideoScenes.times(duration: 0), [])
        XCTAssertEqual(VideoScenes.times(duration: .nan), [])
        XCTAssertEqual(VideoScenes.times(duration: .infinity), [])
    }
    func testLabelsReadAsClockTimes() {
        XCTAssertEqual(VideoScenes.label(0), "0:00")
        XCTAssertEqual(VideoScenes.label(7.9), "0:07")
        XCTAssertEqual(VideoScenes.label(750), "12:30")
        XCTAssertEqual(VideoScenes.label(3725), "1:02:05")
        XCTAssertEqual(VideoScenes.label(-3), "0:00")
        XCTAssertEqual(VideoScenes.label(.nan), "0:00")
    }
    func testTheModelIsToldTheLengthAndEachScenesTime() {
        let opening = VideoScenes.opening(name: "clip.mov", duration: 12)
        XCTAssertTrue(opening.contains("clip.mov") && opening.contains("0:12") && opening.contains("音声は含みません"), opening)
        XCTAssertFalse(VideoScenes.opening(name: "clip.mov", duration: nil).contains("長さ"))
        XCTAssertEqual(VideoScenes.sceneLabels(duration: 12, scenes: 3), ["\n[0:00]", "\n[0:06]", "\n[0:11]"])
        // Scenes not taken at these times get no times.
        XCTAssertNil(VideoScenes.sceneLabels(duration: nil, scenes: 3))
        XCTAssertNil(VideoScenes.sceneLabels(duration: 12, scenes: 1))
        XCTAssertNil(VideoScenes.sceneLabels(duration: 12, scenes: 0))
    }
    /// Three scenes of 280 image tokens fit E2B's input with a question, and
    /// a video counts as three of a send's four images.
    func testAVideosScenesFitATurn() {
        let settings = GenerationSettings().normalized(for: .e2b)
        let video = ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov",
                                   imageNames: (0..<VideoScenes.count).map { "scene-\($0).jpg" }, duration: 12)
        XCTAssertLessThan(video.contextByteCost(visualTokenBudget: settings.visualTokenBudget) + 300, settings.inputByteBudget)
        XCTAssertLessThanOrEqual(video.imageNames.count + 1, 4, "a video and a photo fit one send")
    }
}
