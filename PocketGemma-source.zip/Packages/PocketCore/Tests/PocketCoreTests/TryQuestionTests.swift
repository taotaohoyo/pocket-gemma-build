import XCTest
@testable import PocketCore

/// 体験型おすすめ質問 (1.1.0 (219)): three chips, each sending a question of
/// its own through the chat's send; the questions never search the web,
/// need no chart and fit one message.
final class TryQuestionTests: XCTestCase {
    func testThreeChipsEachWithItsOwnQuestion() {
        XCTAssertEqual(TryQuestion.allCases.map(\.label), ["数学を解く", "文章を要約", "資料を作る"])
        for question in TryQuestion.allCases {
            XCTAssertNotEqual(question.prompt, question.label, "the chip sends a question, not its word")
            XCTAssertGreaterThan(question.prompt.count, question.label.count * 3)
            // ChatStore.send takes about 1,500 characters a message.
            XCTAssertLessThanOrEqual(question.prompt.utf8.count, 4500)
            XCTAssertFalse(RichFormatGuide.asksForChart(question.prompt), "\(question): a table, not a chart")
        }
        XCTAssertTrue(TryQuestion.document.prompt.contains("Markdown"))
        XCTAssertTrue(TryQuestion.math.prompt.contains("48") && TryQuestion.math.prompt.contains("6人"))
    }

    func testTryQuestionsNeverSearchAndLeaveOtherMessagesAlone() {
        let plain = [ChatMessage(role: .user, text: "こんにちは"), ChatMessage(role: .assistant, text: "どうぞ")]
        for question in TryQuestion.allCases {
            XCTAssertTrue(TryQuestion.isSample(question.prompt))
            XCTAssertTrue(TryQuestion.isSample(" \(question.prompt)\n"))
            XCTAssertFalse(WebSearchPolicy.searches(enabled: true, keyed: true, model: .e2b, messages: [],
                                                    attachments: [], asked: question.prompt), "\(question)")
            XCTAssertFalse(TryQuestion.isSample(question.label))
        }
        XCTAssertFalse(TryQuestion.isSample(""))
        XCTAssertFalse(TryQuestion.isSample("48個のお菓子を6人で分けると？"))
        XCTAssertTrue(WebSearchPolicy.searches(enabled: true, keyed: true, model: .e2b, messages: plain,
                                               attachments: [], asked: "今日の東京の天気は？"))
    }
}
