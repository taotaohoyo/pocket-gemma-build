import XCTest
import CryptoKit
@testable import PocketCore

/// What a stopped model download keeps and what comes after its task ends
/// (1.1.0 (293), Hachimoto さん's directive of 2026-11-17).
final class DownloadKeepTests: XCTestCase {
    private func cancelled(reason: Int? = nil, resumeData: Bool = false) -> NSError {
        var info: [String: Any] = [:]
        if let reason { info[NSURLErrorBackgroundTaskCancelledReasonKey] = reason }
        if resumeData { info[NSURLSessionDownloadTaskResumeData] = Data([1, 2, 3]) }
        return NSError(domain: NSURLErrorDomain, code: NSURLErrorCancelled, userInfo: info)
    }

    /// iOS's cancel (the app closed from the app switcher, background
    /// updates off, the system's resources) is told apart from the app's.
    func testSystemStopsAreNotThePersonsStop() {
        XCTAssertEqual(DownloadEnding(cancelled()), .cancelledByApp)
        XCTAssertEqual(DownloadEnding(cancelled(reason: NSURLErrorCancelledReasonUserForceQuitApplication)),
                       .stoppedBySystem(reason: NSURLErrorCancelledReasonUserForceQuitApplication))
        XCTAssertEqual(DownloadEnding(cancelled(reason: NSURLErrorCancelledReasonBackgroundUpdatesDisabled)),
                       .stoppedBySystem(reason: 1))
        XCTAssertEqual(DownloadEnding(cancelled(reason: NSURLErrorCancelledReasonInsufficientSystemResources, resumeData: true)),
                       .stoppedBySystem(reason: 2))
        XCTAssertEqual(DownloadEnding(NSError(domain: NSURLErrorDomain, code: NSURLErrorNetworkConnectionLost)), .failed)
        XCTAssertEqual(DownloadEnding(NSError(domain: NSCocoaErrorDomain, code: NSURLErrorCancelled)), .failed)
        XCTAssertEqual(DownloadEnding.reasonText(0), "アプリが閉じられた")
    }

    private func retry(_ failure: DownloadFailure, resumed: Bool = false, new: Bool = false, kept: Bool = false,
                       keptFailed: Bool = false, tries: Int = 0) -> DownloadRetry {
        DownloadRetry.after(failure, resumed: resumed, hasNewData: new, hasKeptData: kept,
                            keptDataFailed: keptFailed, tries: tries, maxTries: 2)
    }

    /// A connection lost right after a resumed task started (292 began
    /// from nothing then): the data kept before it is tried again.
    func testALostConnectionGoesOnFromWhatCame() {
        XCTAssertEqual(retry(.connectionLost, resumed: true, new: true), .fromNewData)
        XCTAssertEqual(retry(.connectionLost, resumed: true, kept: true), .fromKeptData)
        XCTAssertEqual(retry(.connectionLost, resumed: true, kept: true, keptFailed: true), .fromStart,
                       "a second end on the same data: it is not tried a third time")
        XCTAssertEqual(retry(.connectionLost), .fromStart, "nothing kept, nothing lost")
        XCTAssertEqual(retry(.stalled, new: true), .fromNewData)
    }

    /// The Hub's CDN link in resume data lasts about an hour: a refused or
    /// run-out link, or a file that changed, starts over from the Hub.
    func testARunOutLinkStartsOver() {
        for status in [401, 403, 410, 412, 416] {
            XCTAssertEqual(retry(.http(status), resumed: true, kept: true), .fromStart, "HTTP \(status)")
        }
        XCTAssertEqual(retry(.http(404), resumed: true, kept: true), .stop, "a file gone: the app's update")
        XCTAssertEqual(retry(.http(503), resumed: true, kept: true), .fromKeptData, "the Hub's trouble keeps what came")
        XCTAssertEqual(retry(.http(503), new: true), .fromNewData)
        XCTAssertEqual(retry(.http(429), kept: true), .fromKeptData)
    }

    /// An end without words: resume data is tried; kept data that a resumed
    /// task failed on twice is taken as unusable.
    func testAnUnknownEndOnKeptDataTriesItOnce() {
        XCTAssertEqual(retry(.other("NSURLErrorDomain", -3001), new: true), .fromNewData)
        XCTAssertEqual(retry(.other("NSURLErrorDomain", -3001), resumed: true, kept: true), .fromKeptData)
        XCTAssertEqual(retry(.other("NSURLErrorDomain", -3001), resumed: true, kept: true, keptFailed: true), .fromStart)
        XCTAssertEqual(retry(.other("NSURLErrorDomain", -1)), .stop)
    }

    /// A full phone, no network or too many tries: the download stops and
    /// keeps what came (the caller writes it as paused).
    func testStopsKeepWhatCame() {
        XCTAssertEqual(retry(.noSpace, resumed: true, new: true), .stop)
        XCTAssertEqual(retry(.offline, kept: true), .stop)
        XCTAssertEqual(retry(.secureConnection), .stop)
        XCTAssertEqual(retry(.connectionLost, new: true, tries: 2), .stop)
        XCTAssertEqual(retry(.http(403), tries: 2), .stop)
    }

    func testTheRecordReadsBackAndNeverGoesNegative() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let url = folder.appendingPathComponent("x.download")
        let keep = DownloadKeep(state: .paused, receivedBytes: 1_294_073_856, expectedBytes: 2_588_147_712, cellular: true,
                                updated: Date(timeIntervalSince1970: 1_800_000_000))
        try keep.write(to: url)
        XCTAssertEqual(DownloadKeep.read(from: url), keep)
        XCTAssertEqual(try XCTUnwrap(keep.fraction), 0.5, accuracy: 1e-9)
        XCTAssertNil(DownloadKeep(state: .running, receivedBytes: -5, expectedBytes: 10, cellular: false).fraction)
        XCTAssertNil(DownloadKeep.read(from: folder.appendingPathComponent("none")))
        try Data("not json".utf8).write(to: url)
        XCTAssertNil(DownloadKeep.read(from: url), "a broken record reads as none")
    }

    /// A download going on from what it kept asks for the rest's room only.
    func testRoomIsForWhatIsStillToCome() {
        let gb: Int64 = 1_000_000_000
        XCTAssertEqual(ModelDownload.roomNeeded(remaining: [(byteCount: 3 * gb, received: 0)], others: 0), 4 * gb)
        XCTAssertEqual(ModelDownload.roomNeeded(remaining: [(byteCount: 3 * gb, received: 2 * gb)], others: 0), 2 * gb)
        XCTAssertEqual(ModelDownload.roomNeeded(remaining: [(byteCount: 3 * gb, received: 5 * gb)], others: gb), 2 * gb,
                       "a figure past the file counts as the whole file")
        XCTAssertEqual(ModelDownload.roomNeeded(remaining: [(byteCount: gb, received: -1), (byteCount: gb, received: gb / 2)],
                                                others: -3), gb + gb / 2 + gb)
    }

    /// The record sits beside the resume data, one per file, and goes with
    /// a retired model's things.
    func testEachFileHasARecordBesideItsResumeData() {
        let library = ModelLibrary(directory: URL(fileURLWithPath: "/m"), stateDirectory: URL(fileURLWithPath: "/s"))
        let places = ModelSpec.allFiles.map { library.keepURL($0).path }
        XCTAssertEqual(Set(places).count, ModelSpec.allFiles.count)
        XCTAssertTrue(places.allSatisfy { $0.hasPrefix("/s/") && $0.hasSuffix(".download") })
        for file in ModelSpec.allFiles {
            XCTAssertNotEqual(library.keepURL(file), library.resumeURL(file))
            XCTAssertNotEqual(library.keepURL(file), library.pendingURL(file))
            XCTAssertNotEqual(library.keepURL(file), library.receiptURL(file))
        }
        let paths = ModelRetirement.paths(of: .phi4MiniReasoning, in: library, caches: URL(fileURLWithPath: "/none"))
        XCTAssertTrue(paths.contains(library.keepURL(.phi4MiniReasoning)))
    }

    /// The SHA-256 check tells how far it got (the continued task moves
    /// with it) and checks as before.
    func testTheCheckTellsHowFarItGot() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let url = folder.appendingPathComponent("model.bin")
        let size = 130 * 1_048_576
        let bytes = Data(repeating: 7, count: size)
        try bytes.write(to: url)
        let sha = SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
        let spec = ModelSpec(fileName: "model.bin", byteCount: Int64(size), sha256: sha,
                             downloadURL: URL(string: "https://example.com/model.bin")!)
        var heard: [Int64] = []
        try ModelValidator.validate(url, spec: spec) { heard.append($0) }
        XCTAssertEqual(heard, [64 * 1_048_576, 128 * 1_048_576])
        let wrong = ModelSpec(fileName: "model.bin", byteCount: Int64(size), sha256: String(repeating: "0", count: 64),
                              downloadURL: URL(string: "https://example.com/model.bin")!)
        XCTAssertThrowsError(try ModelValidator.validate(url, spec: wrong)) { error in
            guard case .wrongChecksum? = error as? ModelValidationError else { return XCTFail("\(error)") }
        }
    }
}
