import XCTest
@testable import PocketCore

/// Phase 5: how long the reply's Markdown work takes, printed as MD-PERF
/// lines in the CI log. The bounds are loose so a slow runner passes; the
/// printed numbers are what the report compares.
final class MarkdownPerformanceTests: XCTestCase {
    private static var reply: String {
        let code = (1...60).map { "    let value\($0) = compute(\"text\", \($0)) // \($0)番目" }.joined(separator: "\n")
        let section = { (index: Int) in
            """
            ## 第\(index)章 数式と表

            本文の段落です。**太字**、*斜体*、`code`、[リンク](https://www.apple.com/jp/) が入ります。二次方程式の解は $x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$ です。

            1. 準備する
            2. 実行する
               - 入れ子の項目

            | 項目 | 値 | 式 |
            |:--|--:|:-:|
            | 売上 | 120 | $a^2$ |
            | 費用 | 80 | $b_1$ |

            $$
            \\int_0^1 x^2\\,dx = \\frac{1}{3}
            $$

            \\begin{cases} x+y=5 \\\\ x-y=1 \\end{cases}

            ```swift
            func run() -> Int {
            \(code)
                return 0
            }
            ```

            """
        }
        return (1...4).map(section).joined(separator: "\n")
    }

    private func milliseconds(_ start: DispatchTime) -> Double {
        Double(DispatchTime.now().uptimeNanoseconds - start.uptimeNanoseconds) / 1_000_000
    }

    /// What the reply view does for each piece of a streaming reply: split
    /// it into chunks, parse the last one as streaming and the others once.
    func testStreamingALongReplyStaysCheapPerToken() {
        let reply = Self.reply
        let characters = Array(reply)
        var finished: [String: MarkdownDocument] = [:]
        var prefix = ""
        var total = 0.0
        var worst = 0.0
        var steps = 0
        var offset = 0
        while offset < characters.count {
            let end = min(offset + 6, characters.count)
            prefix += String(characters[offset..<end])
            offset = end
            let start = DispatchTime.now()
            let chunks = MarkdownSource.chunks(prefix)
            for index in chunks.indices {
                if index == chunks.count - 1 {
                    _ = MarkdownDocument(chunks[index], streaming: true)
                } else if finished[chunks[index]] == nil {
                    finished[chunks[index]] = MarkdownDocument(chunks[index])
                }
            }
            let elapsed = milliseconds(start)
            total += elapsed
            worst = max(worst, elapsed)
            steps += 1
        }
        print(String(format: "MD-PERF stream chars=%d steps=%d total=%.0fms mean=%.2fms worst=%.1fms",
                     characters.count, steps, total, total / Double(steps), worst))
        XCTAssertLessThan(worst, 500, "One step of a streaming reply")
    }

    func testFinishedReplyAndCodeTimings() {
        let reply = Self.reply
        var start = DispatchTime.now()
        let chunks = MarkdownSource.chunks(reply)
        let documents = chunks.map { MarkdownDocument($0) }
        let parse = milliseconds(start)
        XCTAssertFalse(documents.flatMap(\.blocks).isEmpty)

        let line = "let value = compute(\"text\", 42) // comment\n"
        start = DispatchTime.now()
        _ = SyntaxHighlighter.tokens(String(repeating: line, count: 60), language: "swift")
        let code60 = milliseconds(start)
        start = DispatchTime.now()
        _ = SyntaxHighlighter.tokens(String(repeating: line, count: 600), language: "swift")
        let code600 = milliseconds(start)
        start = DispatchTime.now()
        _ = SyntaxHighlighter.detectedLanguage(String(repeating: line, count: 600))
        let detect = milliseconds(start)

        let formulas = ["\\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}", "\\int_0^1 x^2\\,dx = \\frac{1}{3}",
                        "\\begin{cases} x+y=5 \\\\ x-y=1 \\end{cases}", "\\sum_{i=1}^{n} \\frac{(x_i - \\bar{x})^2}{n - 1}"]
        start = DispatchTime.now()
        for _ in 0..<25 { for formula in formulas { _ = MathSpeech.spoken(formula); _ = MathSyntax.normalized(formula) } }
        let math = milliseconds(start) / 100
        print(String(format: "MD-PERF finished chars=%d chunks=%d parse=%.1fms code60=%.1fms code600=%.1fms detect600=%.2fms formula=%.3fms",
                     reply.count, chunks.count, parse, code60, code600, detect, math))
        XCTAssertLessThan(parse, 2_000)
        XCTAssertLessThan(code600, 2_000)
    }
}
