import XCTest
@testable import PocketCore

/// Smart Mode (1.1.0 (249), the user's directive of 2026-10-31): how a
/// question is read, which saved model it goes to, and the settings that
/// turn runs with, which must really differ, not only the words on screen.
final class SmartModeTests: XCTestCase {
    private let both: Set<String> = [ModelSpec.e4b.id, ModelSpec.e2b.id]
    private let wide = AddressSpace(range: 545_000_000_000, free: 68_720_000_000, largestFree: 68_720_000_000, regions: 1)

    override func tearDown() {
        PhotoDetail.offer(atLaunch: nil)
        super.tearDown()
    }

    private func task(_ prompt: String, _ kinds: [ChatAttachment.Kind] = [], genre: SmartGenre = .auto) -> SmartTask {
        SmartClassifier.task(genre: genre, prompt: prompt, attachments: kinds)
    }

    private func plan(_ prompt: String, genre: SmartGenre = .auto, attachments: [ChatAttachment.Kind] = [],
                      earlier: Set<ChatAttachment.Kind> = [], earlierDetail: PhotoDetail? = nil,
                      _ context: SmartPlanner.Context) -> Result<SmartPlanner.Plan, SmartPlanner.Unavailable> {
        SmartPlanner.plan(.init(genre: genre, prompt: prompt, attachments: attachments, earlier: earlier,
                                earlierDetail: earlierDetail), in: context)
    }

    private func context(_ current: ModelSpec = .e4b, installed: Set<String>? = nil, deeperFits: Bool = false,
                         prefersSmall: Bool = false, avoided: Set<String> = [], searchReady: Bool = false,
                         searchBlocked: Bool = false, developer: Bool = false, twelveBFits: Bool = false,
                         e4bHearsVideo: Bool = false) -> SmartPlanner.Context {
        SmartPlanner.Context(current: current, installed: installed ?? both, developer: developer, deeperFits: deeperFits,
                             twelveBFits: twelveBFits, prefersSmall: prefersSmall, avoided: avoided,
                             searchReady: searchReady, searchBlocked: searchBlocked, e4bHearsVideo: e4bHearsVideo)
    }

    // MARK: Reading the question

    func testAutoReadsTheQuestionInTheAppsLanguages() {
        let cases: [(String, [ChatAttachment.Kind], SmartTask)] = [
            ("こんにちは", [], .conversation),
            ("なぜ空は青いの？", [], .conversation),
            ("Why is the sky blue?", [], .conversation),
            ("10/31の予定を整理したい", [], .conversation),
            ("次の方程式を解いて: 2x + 3 = 11", [], .math),
            ("What is 12 * 7?", [], .math),
            ("확률 문제를 풀어줘", [], .math),
            ("このSwiftUIのコードのバグを直して", [], .programming),
            ("Write a Python function that reverses a list", [], .programming),
            ("帮我写一个Python函数", [], .programming),
            ("이 코드를 디버그해 줘", [], .programming),
            ("次の文章を3行で要約して。今日は雨でした。", [], .textSummary),
            ("Summarize this article for me", [], .textSummary),
            ("请总结这段文字", [], .textSummary),
            ("AとBを比較して、どちらがいいか教えて", [], .reasoning),
            ("Compare these two plans and tell me which is better", [], .reasoning),
            ("取引先へのお詫びのメールを書いて", [], .writing),
            ("これは何？", [.image], .photo),
            ("このレシートの文字を読んで", [.image], .photoText),
            ("この数式を解いて", [.image], .math),
            ("どう思う？", [.file], .fileSummary),
            ("何が起きている？", [.video], .video),
            ("この問題を解いて", [.audio], .voice),
        ]
        for (prompt, kinds, expected) in cases {
            XCTAssertEqual(task(prompt, kinds), expected, prompt)
        }
    }

    func testEverydayWordsAreNotCodeOrMath() {
        for prompt in ["Let me know the weather tomorrow", "Class trip ideas for spring", "The bug in my garden is eating leaves",
                       "How many people live in Tokyo?", "電話番号は03-1234-5678です", "ポイントを貯めるコツは？"] {
            XCTAssertEqual(task(prompt), .conversation, prompt)
        }
    }

    /// A genre the person named wins over the words; a recording always
    /// goes to the model that hears one.
    func testANamedGenreWinsOverTheWords() {
        XCTAssertEqual(task("こんにちは", genre: .math), .math)
        XCTAssertEqual(task("こんにちは", genre: .programming), .programming)
        XCTAssertEqual(task("2 + 2 = ?", genre: .textSummary), .textSummary)
        XCTAssertEqual(task("今日のニュース", genre: .webSearch), .webSearch)
        XCTAssertEqual(task("要約して", [.audio], genre: .textSummary), .voice)
    }

    func testTheTryQuestionsReadAsTheirChips() {
        XCTAssertEqual(task(TryQuestion.math.prompt), .math)
        XCTAssertEqual(task(TryQuestion.summary.prompt), .textSummary)
        XCTAssertEqual(task(TryQuestion.document.prompt), .writing)
    }

    // MARK: Choosing the model

    func testAnEverydayQuestionStaysOnTheChatsModelAndRepliesFast() throws {
        let onE4B = try plan("こんにちは", context(.e4b)).get()
        XCTAssertEqual(onE4B.model, .e4b)
        XCTAssertEqual(onE4B.tuning.pace, .quick)
        XCTAssertFalse(onE4B.tuning.thinks)
        XCTAssertEqual(onE4B.tuning.photoDetail, .fast)
        XCTAssertTrue(onE4B.notices.isEmpty)
        let onE2B = try plan("こんにちは", context(.e2b)).get()
        XCTAssertEqual(onE2B.model, .e2b, "No reload for a model that suits the question")
        XCTAssertNil(onE2B.tuning.photoDetail)
    }

    func testReasoningMathAndCodeGoToE4BAndThink() throws {
        for (prompt, expected) in [("2x + 3 = 11 を解いて", SmartTask.math), ("このコードを直して", .programming),
                                   ("AとBを比較して", .reasoning)] {
            let chosen = try plan(prompt, context(.e2b)).get()
            XCTAssertEqual(chosen.model, .e4b, prompt)
            XCTAssertEqual(chosen.tuning.task, expected, prompt)
            XCTAssertEqual(chosen.tuning.pace, .careful, prompt)
            XCTAssertTrue(chosen.tuning.thinks, "Text alone thinks without the address space: \(prompt)")
            XCTAssertTrue(chosen.notices.isEmpty, prompt)
        }
        // A phone whose memory is tight for E4B keeps E2B, which thinks too.
        let small = try plan("2x + 3 = 11 を解いて", context(.e2b, prefersSmall: true)).get()
        XCTAssertEqual(small.model, .e2b)
        XCTAssertTrue(small.tuning.thinks)
    }

    func testPhotosThinkOnlyWithTheRoomForIt() throws {
        let narrow = try plan("この数式を解いて", attachments: [.image], context(.e4b)).get()
        XCTAssertEqual(narrow.model, .e4b)
        XCTAssertFalse(narrow.tuning.thinks)
        XCTAssertEqual(narrow.notices, [.noThinkingWithPhotos])
        XCTAssertEqual(narrow.tuning.photoDetail, .deep, "280 runs as 140 on the CPU without the room")
        // Earlier photos count too.
        let later = try plan("では答えは？ 2x + 3 = 11", earlier: [.image], context(.e4b)).get()
        XCTAssertFalse(later.tuning.thinks)
        XCTAssertEqual(later.notices, [.noThinkingWithPhotos])
        PhotoDetail.offer(atLaunch: wide)
        let roomy = try plan("この数式を解いて", attachments: [.image], context(.e4b, deeperFits: true)).get()
        XCTAssertTrue(roomy.tuning.thinks)
        XCTAssertEqual(roomy.tuning.photoDetail, .deeper)
        XCTAssertTrue(roomy.notices.isEmpty)
    }

    func testFinePrintAndVideosGoWhereTheyAreReadBest() throws {
        XCTAssertEqual(try plan("このレシートの文字を読んで", attachments: [.image], context(.e4b)).get().model, .e2b)
        XCTAssertEqual(try plan("このレシートの文字を読んで", attachments: [.image], context(.e4b, deeperFits: true)).get().model, .e4b)
        XCTAssertEqual(try plan("何が起きている？", attachments: [.video], context(.e4b)).get().model, .e2b)
        XCTAssertEqual(try plan("何が起きている？", attachments: [.video], context(.e4b, e4bHearsVideo: true)).get().model, .e4b)
        // An everyday photo stays on the chat's model, briefly at 70.
        let photo = try plan("これは何？", attachments: [.image], context(.e4b)).get()
        XCTAssertEqual(photo.model, .e4b)
        XCTAssertEqual(photo.tuning.photoDetail, .fast)
    }

    /// A question about the same photos keeps their detail, so the engine
    /// loaded for them is used again.
    func testTheSamePhotosKeepTheirDetail() throws {
        PhotoDetail.offer(atLaunch: wide)
        let kept = try plan("AとBを比較して", earlier: [.image], earlierDetail: .fast, context(.e4b, deeperFits: true)).get()
        XCTAssertEqual(kept.tuning.photoDetail, .fast)
        XCTAssertTrue(kept.tuning.thinks)
        let new = try plan("AとBを比較して", attachments: [.image], earlier: [.image], earlierDetail: .fast,
                           context(.e4b, deeperFits: true)).get()
        XCTAssertEqual(new.tuning.photoDetail, .deeper, "New photos take the detail of the question")
    }

    func testASpokenQuestionGoesToTheModelThatHearsIt() throws {
        let installed = both.union([ModelSpec.lfm3Omni.id])
        let spoken = try plan(VoiceNote.ask, attachments: [.audio], context(.e4b, installed: installed)).get()
        XCTAssertEqual(spoken.model, .lfm3Omni)
        XCTAssertFalse(spoken.tuning.thinks)
        XCTAssertTrue(spoken.notices.isEmpty)
        XCTAssertEqual(try plan("この写真は？", attachments: [.audio, .image], context(.e4b, installed: installed)).get().model, .lfm3Omni)
        // Its chat goes on with it, as no other model reads the recording.
        XCTAssertEqual(try plan("ありがとう", earlier: [.audio], context(.lfm3Omni, installed: installed)).get().model, .lfm3Omni)
        guard case .failure(let missing) = plan(VoiceNote.ask, attachments: [.audio], context(.e4b)) else { return XCTFail() }
        XCTAssertTrue(missing.message.contains("LFM3-Omni 2B"))
        guard case .failure(let mixed) = plan(VoiceNote.ask, attachments: [.audio, .file], context(.e4b, installed: installed)) else {
            return XCTFail()
        }
        XCTAssertTrue(mixed.message.contains("分けて"))
    }

    /// Never a model that isn't saved, unlocked or able to start here, and
    /// never a download: the question says what to download instead.
    func testOnlySavedUsableModelsAreChosen() throws {
        guard case .failure(let none) = plan("こんにちは", context(.e4b, installed: [])) else { return XCTFail() }
        XCTAssertTrue(none.message.contains("E2B"))
        let qwen = try plan("こんにちは", context(.e4b, installed: [ModelSpec.qwen25.id])).get()
        XCTAssertEqual(qwen.model, .qwen25)
        XCTAssertEqual(qwen.notices, [.outsideStarters])
        let lfm = try plan("2x + 3 = 11 を解いて", context(.e4b, installed: [ModelSpec.lfm3.id])).get()
        XCTAssertEqual(lfm.model, .lfm3)
        XCTAssertFalse(lfm.tuning.thinks, "Smart Mode's thinking is Gemma's, confirmed on the phone")
        XCTAssertEqual(lfm.notices, [.outsideStarters, .modelDoesNotThink])
        // 12B only where it can start; Qwen3 only with developer settings.
        XCTAssertEqual(try plan("こんにちは", context(.e4b, installed: [ModelSpec.gemma12B.id], twelveBFits: true)).get().model, .gemma12B)
        if case .success = plan("こんにちは", context(.e4b, installed: [ModelSpec.gemma12B.id])) { XCTFail("12B without the room") }
        if case .success = plan("こんにちは", context(.e4b, installed: [ModelSpec.qwen3.id])) { XCTFail("Qwen3 without developer settings") }
        XCTAssertEqual(try plan("こんにちは", context(.e4b, installed: [ModelSpec.qwen3.id], developer: true)).get().model, .qwen3)
        // Photos and files only to a model that reads them.
        guard case .failure(let photos) = plan("これは何？", attachments: [.image], context(.e4b, installed: [ModelSpec.qwen25.id])) else {
            return XCTFail()
        }
        XCTAssertTrue(photos.message.contains("写真"))
        XCTAssertEqual(try plan("要約して", attachments: [.file], context(.e2b, installed: [ModelSpec.e2b.id])).get().model, .e2b)
    }

    func testAModelThatFailedIsTriedLast() throws {
        XCTAssertEqual(try plan("2x + 3 = 11 を解いて", context(.e4b, avoided: [ModelSpec.e4b.id])).get().model, .e2b)
        XCTAssertEqual(try plan("こんにちは", context(.e4b, avoided: [ModelSpec.e4b.id])).get().model, .e2b)
        // The only one saved is still tried.
        XCTAssertEqual(try plan("こんにちは", context(.e4b, installed: [ModelSpec.e4b.id], avoided: [ModelSpec.e4b.id])).get().model, .e4b)
    }

    /// Only the genre ウェブ検索 searches, with the person's connection and
    /// no file; 自動 never sends a question out for what its words seem to
    /// ask, and a try question never searches.
    func testOnlyTheWebSearchGenreSearches() throws {
        XCTAssertFalse(try plan("今日の東京の天気は？ 最新のニュースも", context(.e4b, searchReady: true)).get().searches)
        let search = try plan("今日の東京の天気は？", genre: .webSearch, context(.e2b, searchReady: true)).get()
        XCTAssertTrue(search.searches)
        XCTAssertTrue(search.model.supportsWebSearch)
        XCTAssertEqual(search.tuning.task, .webSearch)
        let offline = try plan("今日の東京の天気は？", genre: .webSearch, context(.e4b)).get()
        XCTAssertFalse(offline.searches)
        XCTAssertEqual(offline.notices, [.searchNeedsConnection])
        let blocked = try plan("今日の東京の天気は？", genre: .webSearch, context(.e4b, searchReady: true, searchBlocked: true)).get()
        XCTAssertFalse(blocked.searches)
        XCTAssertEqual(blocked.notices, [.searchBlockedByFiles])
        XCTAssertFalse(try plan(TryQuestion.math.prompt, genre: .webSearch, context(.e4b, searchReady: true)).get().searches)
        // A model that searches, with search on.
        let other = try plan("今日の東京の天気は？", genre: .webSearch, context(.qwen25, installed: both.union([ModelSpec.qwen25.id]),
                                                                       searchReady: true)).get()
        XCTAssertTrue(other.model.supportsWebSearch)
    }

    func testAChatRestsOnASavedModel() {
        XCTAssertEqual(SmartPlanner.restingModel(preferred: .e4b, context: context(.e4b)), .e4b)
        XCTAssertEqual(SmartPlanner.restingModel(preferred: .e4b, context: context(.e4b, installed: [ModelSpec.e2b.id])), .e2b)
        XCTAssertEqual(SmartPlanner.restingModel(preferred: .qwen25, context: context(.e4b, installed: both.union([ModelSpec.qwen25.id]))),
                       .qwen25, "The person's model, when saved")
        XCTAssertNil(SmartPlanner.restingModel(preferred: .e4b, context: context(.e4b, installed: [])))
        // The composer offers photos and files for the model they go to.
        XCTAssertEqual(SmartPlanner.attachmentModel(context: context(.lfm3Omni, installed: both.union([ModelSpec.lfm3Omni.id]))), .e4b)
        XCTAssertEqual(SmartPlanner.attachmentModel(context: context(.e2b)), .e2b)
    }

    // MARK: The settings a turn runs with

    func testTheTuningChangesWhatTheModelRunsWith() throws {
        var saved = GenerationSettings(for: .e4b)
        saved.enableThinking = true
        saved.photoDetail = .deeper
        saved.temperature = 0.3
        let quick = saved.tuned(SmartTuning(task: .conversation, thinks: false, photoDetail: .fast), for: .e4b)
        XCTAssertFalse(quick.thinks(on: .e4b), "A saved thinking switch doesn't make a quick turn think")
        XCTAssertEqual(quick.thinkingTokenBudget(on: .e4b), 0)
        XCTAssertTrue(quick.systemMessage(for: .e4b).contains(GenerationSettings.briefReplyNote))
        XCTAssertEqual(quick.visualTokenBudget, 70)
        XCTAssertEqual(quick.temperature, 0.3, "The person's other settings stay")
        XCTAssertFalse(quick.isFast(on: .e4b))
        XCTAssertFalse(quick.deeperFallsBack(on: .e4b))

        let careful = saved.tuned(SmartTuning(task: .math, thinks: true, photoDetail: PhotoDetail.deeper.running), for: .e4b)
        XCTAssertTrue(careful.thinks(on: .e4b))
        XCTAssertEqual(careful.thinkingTokenBudget(on: .e4b), careful.maxTokens / 4)
        XCTAssertEqual(careful.inputTokenLimit, quick.inputTokenLimit - careful.maxTokens / 4, "Thinking has room of its own")
        let system = careful.systemMessage(for: .e4b)
        XCTAssertTrue(system.contains(GenerationSettings.carefulReplyNote))
        XCTAssertTrue(system.contains(try XCTUnwrap(SmartTask.math.note)))
        XCTAssertFalse(careful.deeperFallsBack(on: .e4b), "Smart Mode says what it can't give with the reply instead")
        XCTAssertEqual(careful.photoDetail, .deep)
        XCTAssertEqual(careful.languageBackend(needsVision: true), .cpu)
        XCTAssertEqual(careful.languageBackend(needsVision: false), saved.backend)

        let standard = saved.tuned(SmartTuning(task: .textSummary, thinks: false, photoDetail: .deeper), for: .e4b)
        XCTAssertFalse(standard.systemMessage(for: .e4b).contains(GenerationSettings.briefReplyNote))
        XCTAssertFalse(standard.systemMessage(for: .e4b).contains(GenerationSettings.carefulReplyNote))
        XCTAssertTrue(standard.systemMessage(for: .e4b).contains(try XCTUnwrap(SmartTask.textSummary.note)))

        // Each tuning is a conversation of its own, and none is saved.
        XCTAssertNotEqual(quick, careful)
        XCTAssertNotEqual(quick, saved.normalized(for: .e4b))
        let encoded = String(decoding: try JSONEncoder().encode(careful), as: UTF8.self)
        XCTAssertFalse(encoded.contains("smart"))
        XCTAssertNil(try JSONDecoder().decode(GenerationSettings.self, from: Data(encoded.utf8)).smart)
    }

    /// A quick turn and a careful one share the engine: the drafter stays
    /// as saved, so the plan (and the loaded model) is the same.
    func testQuickAndCarefulTurnsShareTheEngine() {
        let saved = GenerationSettings(for: .e4b)
        let quick = saved.tuned(SmartTuning(task: .conversation, thinks: false, photoDetail: .fast), for: .e4b)
        let careful = saved.tuned(SmartTuning(task: .reasoning, thinks: true, photoDetail: PhotoDetail.deeper.running), for: .e4b)
        XCTAssertEqual(InferenceEnginePlan(model: .e4b, settings: quick, needsVision: false),
                       InferenceEnginePlan(model: .e4b, settings: careful, needsVision: false))
        XCTAssertFalse(quick.speculativeDecoding(for: .e4b, needsVision: false))
    }

    func testStandInsReadThePromptAsBefore() {
        let qwen = GenerationSettings(for: .qwen25).tuned(SmartTuning(task: .math, thinks: false), for: .qwen25)
        XCTAssertEqual(qwen.systemMessage(for: .qwen25), qwen.modelPrompt)
        XCTAssertFalse(qwen.thinks(on: .qwen25))
        let phi = GenerationSettings(for: .phi4MiniReasoning).tuned(SmartTuning(task: .math, thinks: false), for: .phi4MiniReasoning)
        XCTAssertTrue(phi.systemMessage(for: .phi4MiniReasoning).contains(GenerationSettings.answerLanguageNote))
        XCTAssertTrue(phi.thinks(on: .phi4MiniReasoning), "A reasoning model thinks as it always does")
    }

    // MARK: Kept with the chat

    func testTheGenreIsKeptWithTheChatAndOlderChatsAreAuto() throws {
        let older = try JSONDecoder().decode(ChatThread.self, from: Data(#"{"id":"00000000-0000-0000-0000-000000000001","messages":[],"updatedAt":0}"#.utf8))
        XCTAssertEqual(older.genre, .auto)
        XCTAssertNil(older.modelPinned)
        let later = try JSONDecoder().decode(ChatThread.self, from: Data(#"{"id":"00000000-0000-0000-0000-000000000001","messages":[],"updatedAt":0,"genreID":"poetry"}"#.utf8))
        XCTAssertEqual(later.genre, .auto, "A genre a later version adds reads as 自動")
        var thread = ChatThread()
        thread.webSearch = true
        XCTAssertEqual(thread.genre, .webSearch, "The chat's search switch is the genre ウェブ検索")
        thread.genre = .math
        XCTAssertEqual(thread.genre, .math)
        XCTAssertNil(thread.webSearch)
        thread.genre = .webSearch
        XCTAssertEqual(thread.webSearch, true)
        let reopened = try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(thread))
        XCTAssertEqual(reopened.genre, .webSearch)
        thread.genre = .auto
        XCTAssertNil(thread.webSearch); XCTAssertNil(thread.genreID)
    }

    func testTheChoiceIsKeptWithTheReply() throws {
        var reply = ChatMessage(role: .assistant, text: "42")
        reply.smart = SmartReply(genre: .auto, modelID: ModelSpec.e4b.id,
                                 tuning: SmartTuning(task: .math, thinks: true, photoDetail: .deeper), searched: false,
                                 notices: [.noThinkingWithPhotos])
        let reopened = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(reply))
        XCTAssertEqual(reopened.smart, reply.smart)
        XCTAssertEqual(reopened.smart?.genreLine, "自動 · 数学")
        XCTAssertEqual(reopened.smart?.summary, "Gemma 4 E4B · 考えてから返信")
        // Values a later version writes never keep the archive from opening.
        let future = #"{"genre":"poetry","modelID":"e9","tuning":{"task":"dance","pace":"slow","thinks":true},"searched":true,"notices":["later","modelDoesNotThink"]}"#
        let read = try JSONDecoder().decode(SmartReply.self, from: Data(future.utf8))
        XCTAssertEqual(read.genre, .auto)
        XCTAssertEqual(read.tuning.task, .conversation)
        XCTAssertEqual(read.tuning.pace, .quick)
        XCTAssertEqual(read.notices, [.modelDoesNotThink])
        let plain = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(ChatMessage(role: .assistant, text: "hi")))
        XCTAssertNil(plain.smart)
    }
}
