import XCTest
@testable import PocketCore

/// Phi-4-mini-reasoning is no longer offered (fielua-reports Issue #17, the
/// user's decision of 2026-11-15, 1.1.0 (279)): nothing lists, chooses,
/// downloads or runs it; a phone that had chosen it goes on with a saved
/// model and downloads nothing by itself; its chats stay and go on with the
/// phone's choice; its files stay until the person deletes them, and only
/// its own files go then.
final class ModelRetirementTests: XCTestCase {
    private let phi = ModelSpec.phi4MiniReasoning

    func testPhiIsNoLongerOfferedAnywhere() {
        XCTAssertEqual(ModelSpec.retiredCatalog.map(\.id), [phi.id])
        XCTAssertTrue(phi.isRetired); XCTAssertFalse(ModelSpec.e4b.isRetired)
        for developer in [false, true] {
            XCTAssertFalse(ModelSpec.visibleCatalog(developer: developer).contains { $0.id == phi.id })
            XCTAssertFalse(ModelSpec.pickerCatalog(developer: developer).contains { $0.id == phi.id })
        }
        XCTAssertFalse(ModelSpec.catalog.contains { $0.id == phi.id })
        XCTAssertFalse(ModelSpec.catalog.contains(where: \.isRetired))
        XCTAssertFalse(ModelSpec.allFiles.contains { $0.id == phi.id || $0.fileName == phi.fileName })
        XCTAssertFalse(ModelSpec.starterCatalog.contains { $0.id == phi.id })
        XCTAssertNil(ModelSpec.find(phi.id), "nothing chooses or runs it")
        XCTAssertNil(ModelSpec.findFile(phi.id), "no download follows it")
        XCTAssertEqual(ModelSpec.retired(phi.id)?.id, phi.id)
        XCTAssertNil(ModelSpec.retired(ModelSpec.e4b.id))
        XCTAssertEqual(ModelSpec.named(phi.id)?.name, "Phi-4-mini-reasoning", "its chats keep its name")
        XCTAssertEqual(ModelSpec.named(ModelSpec.e2b.id)?.id, ModelSpec.e2b.id)
        XCTAssertFalse(SmartPlanner.standIns.contains(phi.id), "Smart Mode never picks it")
        XCTAssertFalse(SmartPlanner.starters.contains(phi.id))
        let roomy = DeviceCapacity(memoryBytes: 64_000_000_000, freeDiskBytes: 500_000_000_000, processorCount: 12, isPad: true)
        let small = DeviceCapacity(memoryBytes: 4_000_000_000, freeDiskBytes: 20_000_000_000, processorCount: 6, isPad: false)
        for device in [roomy, small] {
            for developer in [false, true] {
                XCTAssertNotEqual(ModelRecommendation.recommended(for: device, includeDeveloperModels: developer)?.id, phi.id)
            }
        }
    }

    /// The phone's choice at launch. Phi gives way to a saved model, E4B
    /// first, then E2B, then the other models everyone has, the test
    /// versions after them and 12B last; none saved, E2B, to download by
    /// the person. Every other choice is as before.
    func testAPhoneThatHadChosenPhiGoesOnWithASavedModel() {
        func choice(_ saved: String?, _ installed: [ModelSpec]) -> ModelRetirement.Selection {
            ModelRetirement.selection(savedID: saved, installed: Set(installed.flatMap(\.files).map(\.id)))
        }
        XCTAssertEqual(choice(phi.id, [.e4b, .e2b, .qwen35]), .init(model: .e4b, replaced: phi))
        XCTAssertEqual(choice(phi.id, [.e2b, .qwen35]).model.id, ModelSpec.e2b.id)
        XCTAssertEqual(choice(phi.id, [.qwen25, .lfm3]).model.id, ModelSpec.qwen25.id, "no test version first")
        XCTAssertEqual(choice(phi.id, [.gemma12B, .lfm3]).model.id, ModelSpec.lfm3.id, "12B last")
        XCTAssertEqual(choice(phi.id, [.gemma12B]).model.id, ModelSpec.gemma12B.id)
        // Nothing saved, or only a developer's model, or a model short of
        // a file: E2B, not on the phone, and nothing downloads it.
        let none = choice(phi.id, [])
        XCTAssertEqual(none.model.id, ModelSpec.e2b.id); XCTAssertEqual(none.replaced?.id, phi.id)
        XCTAssertEqual(choice(phi.id, [.qwen3]).model.id, ModelSpec.e2b.id)
        let projectorMissing = ModelRetirement.selection(savedID: phi.id, installed: [ModelSpec.lfm3VL.id])
        XCTAssertEqual(projectorMissing.model.id, ModelSpec.e2b.id)
        // Phi's own file saved counts for nothing: it can't run.
        XCTAssertEqual(ModelRetirement.selection(savedID: phi.id, installed: [phi.id]).model.id, ModelSpec.e2b.id)
        // Every other choice, as before 279.
        XCTAssertEqual(choice(ModelSpec.qwen25.id, []), .init(model: .qwen25, replaced: nil))
        XCTAssertEqual(choice(ModelSpec.e2b.id, [.e4b]), .init(model: .e2b, replaced: nil))
        XCTAssertEqual(choice(nil, [.e2b]), .init(model: .e4b, replaced: nil), "a model saved from before the choice was kept")
        XCTAssertEqual(choice(nil, []), .init(model: .e2b, replaced: nil), "a new phone")
        XCTAssertEqual(choice("unknown-model", []).model.id, ModelSpec.e2b.id)
        XCTAssertNil(choice("unknown-model", [.e4b]).replaced)
    }

    /// A chat of Phi goes on with the phone's choice, which its model
    /// button names and which answers; its records keep Phi's name.
    func testAPhiChatGoesOnWithThePhonesChoiceAndKeepsItsName() {
        XCTAssertEqual(ModelSpec.chatModel(phi.id, standIn: .e2b).id, ModelSpec.e2b.id)
        XCTAssertEqual(ModelSpec.chatModel(phi.id, standIn: .qwen25).id, ModelSpec.qwen25.id)
        XCTAssertEqual(ModelSpec.chatModel(ModelSpec.lfm3.id, standIn: .e2b).id, ModelSpec.lfm3.id)
        XCTAssertEqual(ModelSpec.chatModel(nil, standIn: .e2b).id, ModelSpec.e4b.id, "a chat from before models could be chosen")
        XCTAssertEqual(ModelSpec.chatModel("unknown-model", standIn: .e2b).id, ModelSpec.e4b.id)
        XCTAssertEqual(WatchHistory.modelName(phi.id), "Phi-4-mini-reasoning")
        XCTAssertEqual(WatchHistory.modelName(ModelSpec.e2b.id), "E2B")
        let reply = SmartReply(genre: .auto, modelID: phi.id, tuning: SmartTuning(task: .math, thinks: true), searched: false, notices: [])
        XCTAssertTrue(reply.summary.hasPrefix("Phi-4-mini-reasoning · "), reply.summary)
    }

    // MARK: - Files

    private struct Phone {
        let root: URL, models: URL, state: URL, documents: URL, caches: URL
        var library: ModelLibrary { ModelLibrary(directory: models, stateDirectory: state, fallbackDirectories: [documents]) }
        init() throws {
            root = FileManager.default.temporaryDirectory.appendingPathComponent("retired-\(UUID().uuidString)", isDirectory: true)
            models = root.appendingPathComponent("ModelFiles", isDirectory: true)
            state = root.appendingPathComponent("ModelState", isDirectory: true)
            documents = root.appendingPathComponent("Documents/Models", isDirectory: true)
            caches = root.appendingPathComponent("InferenceCache", isDirectory: true)
            for folder in [models, state, documents, caches] {
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            }
        }
        /// A file of `size` bytes that takes no room (sparse): Phi's is 2.78 GB.
        func file(_ url: URL, size: Int64) throws {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            XCTAssertTrue(FileManager.default.createFile(atPath: url.path, contents: nil))
            let handle = try FileHandle(forWritingTo: url)
            try handle.truncate(atOffset: UInt64(size))
            try handle.close()
        }
        func exists(_ url: URL) -> Bool { FileManager.default.fileExists(atPath: url.path) }
    }

    /// Phi's file, receipt and engine caches are found and counted, and go
    /// only when asked; another model's files, and a file of another size
    /// under Phi's common name "model.litertlm", are never counted or touched.
    func testPhisFilesAreListedUntilTheyAreDeletedAndOnlyThey() throws {
        let phone = try Phone()
        defer { try? FileManager.default.removeItem(at: phone.root) }
        let library = phone.library
        XCTAssertEqual(ModelRetirement.leftovers(in: library, caches: phone.caches), [], "a phone that never had Phi")

        // Phi as 278 left it: the file, its receipt, a cache built from it.
        try phone.file(library.modelURL(phi), size: phi.byteCount)
        try phi.sha256.write(to: library.receiptURL(phi), atomically: true, encoding: .utf8)
        let phiCache = phone.caches.appendingPathComponent("cpu/\(phi.sha256)/model.xnnpack_cache")
        try phone.file(phiCache, size: 3_000_000)
        // E4B, saved, with a cache; and somebody's own "model.litertlm".
        try phone.file(library.modelURL(.e4b), size: ModelSpec.e4b.byteCount)
        try ModelSpec.e4b.sha256.write(to: library.receiptURL(.e4b), atomically: true, encoding: .utf8)
        let e4bCache = phone.caches.appendingPathComponent("gpu/\(ModelSpec.e4b.sha256)/weights.bin")
        try phone.file(e4bCache, size: 5_000_000)
        let foreign = phone.documents.appendingPathComponent("model.litertlm")
        try phone.file(foreign, size: 1_234)

        XCTAssertTrue(library.hasFile(phi), "the receipt and the file match")
        let left = ModelRetirement.leftovers(in: library, caches: phone.caches)
        XCTAssertEqual(left.map(\.id), [phi.id])
        XCTAssertEqual(left.first?.bytes, phi.byteCount + Int64(phi.sha256.utf8.count) + 3_000_000,
                       "the file, the receipt and the cache; not the other file named model.litertlm")
        XCTAssertEqual(left.first?.hasModelFile, true)
        XCTAssertFalse(left.first?.sizeLabel.isEmpty ?? true)
        // Listing it changed nothing.
        XCTAssertTrue(phone.exists(library.modelURL(phi))); XCTAssertTrue(phone.exists(phiCache))

        try ModelRetirement.remove(phi, in: library, caches: phone.caches)
        XCTAssertFalse(phone.exists(phone.models.appendingPathComponent(phi.fileName)))
        XCTAssertFalse(phone.exists(library.receiptURL(phi)))
        XCTAssertFalse(phone.exists(phone.caches.appendingPathComponent("cpu/\(phi.sha256)")))
        XCTAssertFalse(library.hasFile(phi))
        XCTAssertEqual(ModelRetirement.leftovers(in: library, caches: phone.caches), [])
        // Only Phi's: E4B, its receipt and cache, and the other file stay.
        XCTAssertTrue(library.hasFile(.e4b))
        XCTAssertTrue(phone.exists(e4bCache))
        XCTAssertTrue(phone.exists(foreign))
        XCTAssertTrue(phone.exists(phone.caches.appendingPathComponent("cpu")), "the runtime's folder stays")
    }

    /// Whatever Phi left is listed so it can be deleted: a file an earlier
    /// version kept in Documents, a download finished but not checked, or
    /// only its caches; a receipt or a stopped download's note alone is no
    /// space to give back and makes no row.
    func testEveryKindOfLeftoverIsListed() throws {
        let phone = try Phone()
        defer { try? FileManager.default.removeItem(at: phone.root) }
        let library = phone.library

        try "x".write(to: library.receiptURL(phi), atomically: true, encoding: .utf8)
        try phone.file(library.resumeURL(phi), size: 2_000)
        XCTAssertEqual(ModelRetirement.leftovers(in: library, caches: phone.caches), [], "bytes only")

        let cache = phone.caches.appendingPathComponent("gpu/\(phi.sha256)/a.bin")
        try phone.file(cache, size: 4_000_000)
        var left = ModelRetirement.leftovers(in: library, caches: phone.caches)
        XCTAssertEqual(left.map(\.id), [phi.id]); XCTAssertEqual(left.first?.hasModelFile, false)

        try phone.file(library.pendingURL(phi), size: 10_000_000)
        try phone.file(phone.documents.appendingPathComponent(phi.fileName), size: phi.byteCount)
        left = ModelRetirement.leftovers(in: library, caches: phone.caches)
        XCTAssertEqual(left.first?.hasModelFile, true, "the copy in Documents")
        XCTAssertEqual(left.first?.bytes, phi.byteCount + 10_000_000 + 4_000_000 + 2_000 + 1)

        try ModelRetirement.remove(phi, in: library, caches: phone.caches)
        XCTAssertEqual(ModelRetirement.leftovers(in: library, caches: phone.caches), [])
        for url in ModelRetirement.paths(of: phi, in: library, caches: phone.caches) {
            XCTAssertFalse(phone.exists(url), url.path)
        }
    }

    /// Told once: the model the person had chosen, else one with files on
    /// the phone; never again once seen, and never on a phone that had none.
    func testThePersonIsToldOnce() {
        let files = [RetiredModelFiles(spec: phi, bytes: 4_954_187_376, hasModelFile: true)]
        let chosen = ModelRetirement.notice(replaced: phi, leftovers: files, told: [])
        XCTAssertEqual(chosen, RetirementNotice(retired: phi, chosen: true, bytes: 4_954_187_376))
        XCTAssertEqual(ModelRetirement.notice(replaced: phi, leftovers: [], told: [])?.bytes, 0)
        XCTAssertEqual(ModelRetirement.notice(replaced: nil, leftovers: files, told: [])?.chosen, false)
        XCTAssertNil(ModelRetirement.notice(replaced: phi, leftovers: files, told: [phi.id]))
        XCTAssertNil(ModelRetirement.notice(replaced: nil, leftovers: files, told: [phi.id]))
        XCTAssertNil(ModelRetirement.notice(replaced: nil, leftovers: [], told: []))

        XCTAssertEqual(chosen?.title, "Phi-4-mini-reasoningの提供を終了しました")
        let ready = chosen?.message(current: .e4b, currentReady: true) ?? ""
        XCTAssertTrue(ready.contains("これからの会話はGemma 4 E4Bで行います。"), ready)
        XCTAssertTrue(ready.contains("これまでの会話はそのまま残ります。"), ready)
        XCTAssertTrue(ready.contains("モデル管理」から削除できます"), ready)
        let toDownload = chosen?.message(current: .e2b, currentReady: false) ?? ""
        XCTAssertTrue(toDownload.contains("ダウンロードしてください"), toDownload)
        XCTAssertFalse(toDownload.contains("Gemma 4 E2Bで行います"), toDownload)
        let nothingLeft = RetirementNotice(retired: phi, chosen: true, bytes: 0).message(current: .e4b, currentReady: true)
        XCTAssertFalse(nothingLeft.contains("削除"), nothingLeft)
        let savedOnly = RetirementNotice(retired: phi, chosen: false, bytes: 1).message(current: .e4b, currentReady: true)
        XCTAssertFalse(savedOnly.contains("これからの会話"), "the choice did not change")
    }
}
