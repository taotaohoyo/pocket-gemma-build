import XCTest
@testable import PocketCore

final class ReplyContinuationTests: XCTestCase {
    func testOnlyAFullContextWindowCountsAsCutOff() {
        XCTAssertTrue(ReplyContinuation.filledContext(tokenCount: 4096, maxTokens: 4096))
        XCTAssertTrue(ReplyContinuation.filledContext(tokenCount: 4095, maxTokens: 4096))
        XCTAssertFalse(ReplyContinuation.filledContext(tokenCount: 3000, maxTokens: 4096))
    }

    func testOnlyARepeatingTailCountsAsALoop() {
        XCTAssertTrue(ReplyContinuation.isLooping("はい、" + String(repeating: "え", count: 300)))
        XCTAssertTrue(ReplyContinuation.isLooping("日本の四季\n" + String(repeating: "春は桜が咲き、夏は海で泳ぎます。\n", count: 20)))
        XCTAssertFalse(ReplyContinuation.isLooping(String(repeating: "え", count: 299)), "Too short to tell")
        let list = (1...60).map { "\($0). 項目です\n" }.joined()
        XCTAssertFalse(ReplyContinuation.isLooping(list), "Numbers change from item to item")
        let rows = (1...40).map { "| \($0)月 | \($0 * 10) |\n" }.joined()
        XCTAssertFalse(ReplyContinuation.isLooping("| 月 | 売上 |\n| --- | --- |\n" + rows))
        let prose = String(repeating: "今日は晴れています。", count: 2) + (1...30).map { "第\($0)段落の文章です。" }.joined()
        XCTAssertFalse(ReplyContinuation.isLooping(prose))
        XCTAssertFalse(ReplyContinuation.isLooping(String(repeating: "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをんアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンがぎぐげござじずぜぞだぢづでどばびぶべぼぱぴぷぺぽ0123456789", count: 3)),
                       "A stretch over 100 characters is not taken as a loop")
    }

    func testShortReplyIsSentWhole() {
        let request = ReplyContinuation.request(prompt: "質問", reply: "短い回答の途中", settings: GenerationSettings())
        XCTAssertEqual(request, .init(question: "質問", outline: "", tail: "短い回答の途中"))
        XCTAssertEqual(request.instruction, ReplyContinuation.ask)
    }

    func testLongReplyKeepsItsEndWithinTheInputBudget() throws {
        let settings = GenerationSettings()
        let lines = (1...400).map { "\($0). 日本語の説明がここに続きます。" }
        let reply = lines.joined(separator: "\n") + "\n401. 途中で"
        let request = ReplyContinuation.request(prompt: String(repeating: "長い質問", count: 500), reply: reply, settings: settings)
        XCTAssertTrue(request.tail.hasSuffix("401. 途中で"))
        XCTAssertLessThanOrEqual(request.tail.utf8.count, settings.maxTokens / 2)
        XCTAssertLessThanOrEqual(request.question.utf8.count, settings.maxTokens / 4)
        XCTAssertLessThanOrEqual(request.question.utf8.count + request.tail.utf8.count + request.instruction.utf8.count,
                                 settings.inputByteBudget)
        // Starts on a whole line rather than in the middle of one.
        let first = try XCTUnwrap(lines.firstIndex { request.tail.hasPrefix($0 + "\n") }, String(request.tail.prefix(40)))
        // The outline names the items written before the tail, up to the one
        // just before it, and the instruction carries it.
        XCTAssertLessThanOrEqual(request.outline.utf8.count, settings.maxTokens / 4)
        XCTAssertTrue(request.outline.split(separator: "\n").last?.hasPrefix("\(first). ") == true, request.outline)
        XCTAssertTrue(request.instruction.contains(request.outline))
        XCTAssertTrue(request.instruction.contains("漏れなく"))
        // It names the item the reply is on and the number after it.
        XCTAssertEqual(request.next, "番号付きの項目は「401. 途中で」まで書きました。項目が残っていれば、次の番号は402です。\n")
        XCTAssertTrue(request.instruction.contains(request.next))
    }

    func testNextNumberOnlyWhileTheListGoesOn() {
        let bold = "### 四国地方\n\n**30. 香川県**\n* **県庁所在地:** 高松市\n* **"
        XCTAssertEqual(ReplyContinuation.next(after: bold), "番号付きの項目は「30. 香川県」まで書きました。項目が残っていれば、次の番号は31です。\n")
        XCTAssertEqual(ReplyContinuation.next(after: "1. 材料を切る\n   1. 玉ねぎ\n   2. にんじ"),
                       "番号付きの項目は「1. 材料を切る」まで書きました。項目が残っていれば、次の番号は2です。\n")
        XCTAssertEqual(ReplyContinuation.next(after: "1. 材料を切る\n2. 炒める\n\nこれで完成です。"), "")
        XCTAssertEqual(ReplyContinuation.next(after: "1. 材料を切る\n2. 炒める\n## 盛り付け\n"), "")
        XCTAssertEqual(ReplyContinuation.next(after: "```\n1. 例\n"), "")
        XCTAssertEqual(ReplyContinuation.next(after: "短い回答"), "")
    }

    func testNumberedItemsInsideEmphasisAndHeadings() {
        XCTAssertEqual(ReplyContinuation.item(of: "**29. 徳島県**"), ReplyContinuation.Item(number: 29, name: "徳島県", nested: false))
        XCTAssertEqual(ReplyContinuation.item(of: "1. **北海道**：札幌市"), ReplyContinuation.Item(number: 1, name: "北海道", nested: false))
        XCTAssertEqual(ReplyContinuation.item(of: "### 12. 東京都（東京）"), ReplyContinuation.Item(number: 12, name: "東京都", nested: false))
        XCTAssertEqual(ReplyContinuation.item(of: "   3) 小項目"), ReplyContinuation.Item(number: 3, name: "小項目", nested: true))
        XCTAssertNil(ReplyContinuation.item(of: "2024年の話"))
        XCTAssertNil(ReplyContinuation.item(of: "**北海道**"))
    }

    func testOutlineListsEarlierHeadingsAndItemsWithoutMarkup() {
        let reply = """
        ## 都道府県

        1. **北海道**：札幌市
        2. **青森県**：青森市
        ```swift
        let x = 1
        ```
        | 県 | 市 |
        |---|---|
        | `岩手` | 盛岡 |
        ---
        * __宮城県__：仙台市、牛タンと松島の美しい景色が有名です
        """
        XCTAssertEqual(ReplyContinuation.outline(of: Substring(reply), byteLimit: 1000), """
        ## 都道府県
        1. 北海道：札幌市
        2. 青森県：青森市
        | 県 | 市 |
        | 岩手 | 盛岡 |
        * 宮城県：仙台市、牛タンと松島の美しい景色が有
        """)
        XCTAssertEqual(ReplyContinuation.outline(of: Substring(reply), byteLimit: 0), "")
    }

    func testOutlineKeepsLatestItemsWhenTheyDoNotAllFit() {
        let reply = (1...100).map { "\($0). 項目\($0)の説明がここに入ります" }.joined(separator: "\n")
        let outline = ReplyContinuation.outline(of: Substring(reply), byteLimit: 300)
        XCTAssertLessThanOrEqual(outline.utf8.count, 300)
        XCTAssertTrue(outline.hasSuffix("\n100. 項目100"), outline)
        XCTAssertFalse(outline.contains("\n1. "))
    }

    func testCutInsideCodeBlockReopensItsFence() {
        let code = (1...300).map { "    let value\($0) = compute(\($0))" }.joined(separator: "\n")
        let reply = "説明です。\n\n```swift\nfunc run() {\n" + code
        let tail = ReplyContinuation.tail(of: reply, byteLimit: 600)
        XCTAssertTrue(tail.hasPrefix("```swift\n"), String(tail.prefix(30)))
        XCTAssertTrue(tail.hasSuffix("compute(300)"))
        let closed = reply + "\n}\n```\n\n" + String(repeating: "あとがき。", count: 200)
        XCTAssertFalse(ReplyContinuation.tail(of: closed, byteLimit: 600).hasPrefix("```"))
    }

    func testContinuationDropsRewrittenUnfinishedLine() {
        let reply = "1. りんご\n2. みかん\n3. ぶど"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "3. ぶどう\n4. もも", after: reply), "う\n4. もも")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "う\n4. もも", after: reply), "う\n4. もも")
    }

    func testContinuationDropsAnnouncementAndRepeatedLines() {
        let reply = "## 手順\n- 材料を用意する\n- 鍋に水を入れる\n"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "続きです。\n\n- 鍋に水を入れる\n- 火にかける", after: reply), "- 火にかける")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "Continuing:\n- 火にかける", after: reply), "- 火にかける")
        let sentence = "東京は日本の首都で、人口が最も多い都市です。大阪は"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "人口が最も多い都市です。大阪は西日本の中心です。", after: sentence),
                       "西日本の中心です。")
    }

    func testContinuationDropsAcknowledgementAndStartsANewItemOnItsOwnLine() {
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "はい、続けます。\n\n36. 徳島県", after: "35. 山口県：山口市\n"), "36. 徳島県")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "承知しました。\n36. 徳島県", after: "35. 山口県：山口市"), "\n36. 徳島県")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "## 四国", after: "35. 山口県：山口市"), "\n## 四国")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "市です。", after: "35. 山口県：山口"), "市です。")
    }

    func testRejectsApologyAndARestartedList() {
        let reply = "1. 北海道：札幌市\n2. 青森県：青森市\n3. 岩手県：盛岡市\n"
        XCTAssertTrue(ReplyContinuation.rejects("合計47都道府県しかありませんでした。本当に大変申し訳ありません。", after: reply))
        XCTAssertTrue(ReplyContinuation.rejects("Sorry, I can't continue the list.", after: reply))
        XCTAssertTrue(ReplyContinuation.rejects("1. **北海道**：札幌市\n2. 青森県", after: reply))
        XCTAssertFalse(ReplyContinuation.rejects("4. 宮城県：仙台市", after: reply))
        XCTAssertFalse(ReplyContinuation.rejects("う\n4. もも", after: "1. りんご\n2. みかん\n3. ぶど"))
        // A second list numbered from 1 is new content, not a restart.
        XCTAssertFalse(ReplyContinuation.rejects("1. 皿を用意する", after: "## 作り方\n1. 材料を切る\n2. 炒める\n## 盛り付け\n"))
        // Apology words the reply is itself about are content.
        XCTAssertFalse(ReplyContinuation.rejects("「すみません」は呼びかけにも使います。", after: "1. 「すみません」は軽い謝罪です。\n"))
    }

    func testRejectsAListGoingBackAtTheSeam() {
        let reply = "**1. 北海道**\n* 札幌市\n\n### 四国地方\n\n**29. 徳島県**\n* 徳島市\n\n**30. 香川県**\n* **"
        // Seen in the simulator: the bold items were not read as numbers.
        let back = ReplyContinuation.trimmedStart(of: "\n26. 三重県\n* 県庁所在地: 津市", after: reply)
        XCTAssertTrue(ReplyContinuation.rejects(back, after: reply), back)
        XCTAssertFalse(ReplyContinuation.rejects("県庁所在地:** 高松市\n\n**31. 愛媛県**", after: reply))
        // Starting over after a short acknowledgement and a bold title.
        let over = ReplyContinuation.trimmedStart(of: "承知しました。\n\n**北海道**\n\n1. **北海道**\n* 札幌市", after: reply + "名物\n")
        XCTAssertTrue(ReplyContinuation.rejects(over, after: reply + "名物\n"), over)
        // A long acknowledgement restates the task before starting over.
        XCTAssertTrue(ReplyContinuation.rejects("承知いたしました。北海道から沖縄県まで、47都道府県すべてについて、番号、都道府県名、県庁所在地、名物を書きます。\n\n---", after: reply))
        XCTAssertTrue(ReplyContinuation.rejects("**【訂正と再構成】**\n北海道から", after: reply))
    }

    func testAcceptsNewListsThatStartFromOne() {
        let steps = "1. 材料を切る\n2. 炒める\n"
        XCTAssertFalse(ReplyContinuation.rejects("   1. 玉ねぎを薄切りにする", after: steps))
        XCTAssertFalse(ReplyContinuation.rejects("これで下ごしらえは完了です。\n1. 皿に盛る", after: steps))
        XCTAssertFalse(ReplyContinuation.rejects("## 盛り付け\n1. 皿に盛る", after: steps))
        XCTAssertFalse(ReplyContinuation.rejects("3. 煮込む", after: steps))
        XCTAssertTrue(ReplyContinuation.rejects("1. 皿に盛る", after: steps))
        XCTAssertTrue(ReplyContinuation.rejects("2. 炒める", after: steps))
    }

    func testHoldsTheOpeningPastAnAnnouncement() {
        let reply = "35. 山口県：山口市\n"
        XCTAssertFalse(ReplyContinuation.canCheck("承知しました。\n" + String(repeating: "あ", count: 79), after: reply))
        XCTAssertTrue(ReplyContinuation.canCheck("承知しました。\n" + String(repeating: "あ", count: 80), after: reply))
        XCTAssertTrue(ReplyContinuation.canCheck(String(repeating: "あ", count: 80), after: reply))
        XCTAssertFalse(ReplyContinuation.canCheck(String(repeating: "あ", count: 80), after: "35. 山口"))
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "**36. 徳島県**", after: "35. 山口県：山口市"), "\n**36. 徳島県**")
    }

    func testContinuationKeepsGenuineText() {
        let reply = "結論として、"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "この方法が最も簡単です。", after: reply), "この方法が最も簡単です。")
        // A long line that merely mentions 続き is content, not an announcement.
        let mention = "この物語の続きは、主人公が旅に出て新しい仲間と出会い、さまざまな試練を乗り越える場面から始まります。\n次へ"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: mention, after: reply), mention)
    }
}
