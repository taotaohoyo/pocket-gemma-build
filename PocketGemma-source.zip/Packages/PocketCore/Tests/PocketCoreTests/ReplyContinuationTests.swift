import XCTest
@testable import PocketCore

final class ReplyContinuationTests: XCTestCase {
    func testOnlyAFullContextWindowCountsAsCutOff() {
        XCTAssertTrue(ReplyContinuation.filledContext(tokenCount: 4096, maxTokens: 4096))
        XCTAssertTrue(ReplyContinuation.filledContext(tokenCount: 4095, maxTokens: 4096))
        XCTAssertFalse(ReplyContinuation.filledContext(tokenCount: 3000, maxTokens: 4096))
    }

    func testShortReplyIsSentWhole() {
        let request = ReplyContinuation.request(prompt: "質問", reply: "短い回答の途中", settings: GenerationSettings())
        XCTAssertEqual(request, .init(question: "質問", tail: "短い回答の途中"))
    }

    func testLongReplyKeepsItsEndWithinTheInputBudget() {
        let settings = GenerationSettings()
        let lines = (1...400).map { "\($0). 日本語の説明がここに続きます。" }
        let reply = lines.joined(separator: "\n") + "\n401. 途中で"
        let request = ReplyContinuation.request(prompt: String(repeating: "長い質問", count: 500), reply: reply, settings: settings)
        XCTAssertTrue(request.tail.hasSuffix("401. 途中で"))
        XCTAssertLessThanOrEqual(request.tail.utf8.count, settings.maxTokens / 2)
        XCTAssertLessThanOrEqual(request.question.utf8.count, settings.maxTokens / 4)
        XCTAssertLessThanOrEqual(request.question.utf8.count + request.tail.utf8.count + ReplyContinuation.instruction.utf8.count,
                                 settings.inputByteBudget)
        // Starts on a whole line rather than in the middle of one.
        XCTAssertTrue(lines.contains { request.tail.hasPrefix($0 + "\n") }, String(request.tail.prefix(40)))
    }

    func testCutInsideCodeBlockReopensItsFence() {
        let code = (1...300).map { "    let value\($0) = compute(\($0))" }.joined(separator: "\n")
        let reply = "説明です。\n\n```swift\nfunc run() {\n" + code
        let tail = ReplyContinuation.tail(of: reply, byteLimit: 600)
        XCTAssertTrue(tail.hasPrefix("```swift\n"), String(tail.prefix(30)))
        XCTAssertTrue(tail.hasSuffix("compute(300)"))
        let closed = reply + "\n}\n```\n\n" + String(repeating: "あとがき。", count: 200)
        XCTAssertFalse(ReplyContinuation.tail(of: closed, byteLimit: 600).hasPrefix("```"))
    }

    func testContinuationDropsRewrittenUnfinishedLine() {
        let reply = "1. りんご\n2. みかん\n3. ぶど"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "3. ぶどう\n4. もも", after: reply), "う\n4. もも")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "う\n4. もも", after: reply), "う\n4. もも")
    }

    func testContinuationDropsAnnouncementAndRepeatedLines() {
        let reply = "## 手順\n- 材料を用意する\n- 鍋に水を入れる\n"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "続きです。\n\n- 鍋に水を入れる\n- 火にかける", after: reply), "- 火にかける")
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "Continuing:\n- 火にかける", after: reply), "- 火にかける")
        let sentence = "東京は日本の首都で、人口が最も多い都市です。大阪は"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "人口が最も多い都市です。大阪は西日本の中心です。", after: sentence),
                       "西日本の中心です。")
    }

    func testContinuationKeepsGenuineText() {
        let reply = "結論として、"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: "この方法が最も簡単です。", after: reply), "この方法が最も簡単です。")
        // A long line that merely mentions 続き is content, not an announcement.
        let mention = "この物語の続きは、主人公が旅に出て新しい仲間と出会い、さまざまな試練を乗り越える場面から始まります。\n次へ"
        XCTAssertEqual(ReplyContinuation.trimmedStart(of: mention, after: reply), mention)
    }
}
