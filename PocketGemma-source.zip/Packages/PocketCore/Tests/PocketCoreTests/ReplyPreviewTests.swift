import XCTest
@testable import PocketCore

/// 生成中の一節 (ReplyPreview, 1.1.0 (301)): which of a reply's words show
/// beside the Aurora Orb while it is written, how a phrase grows and when
/// it gives way. A model is played in at a given speed, its text arriving
/// in 45 ms batches as the store delivers it, and the preview is read as
/// the row reads it, at most every `ReplyPreview.interval`. The phrase is
/// laid out by a stand-in for the font (13pt kanji and kana, 7pt Latin, in
/// 300pt lines of 18pt). PREVIEW-NOTE lines in the log carry the numbers.
final class ReplyPreviewTests: XCTestCase {
    private typealias Arrival = (at: TimeInterval, text: String)

    private static let long = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。\n\nただし、まだ誤りが多く、実用化には時間がかかると考えられています。量子ビットは、0と1を同時に重ね合わせた状態を持てます。この性質を使うと、ある種の問題では、いまのコンピュータよりずっと少ない手順で答えに近づけます。"

    private static let width = 300.0
    private static let lineHeight = 15.5

    /// The stand-in font: a text's height in 300pt lines.
    private static func measure(_ text: String) -> Double {
        var used = 0.0
        var lines = 1
        for character in text {
            let advance: Double = character == " " ? 4 : character.isASCII ? 7 : 13
            if used + advance > width {
                lines += 1
                used = 0
            }
            used += advance
        }
        return text.isEmpty ? 0 : Double(lines) * 18
    }

    private static func lines(_ text: String) -> Int {
        max(1, Int(measure(text) / lineHeight + 0.2))
    }

    /// `text` written at `rate` characters a second from `start`.
    private func steady(_ text: String, rate: Double, from start: TimeInterval = 0) -> [Arrival] {
        var arrivals: [Arrival] = []
        var at = start
        var owed = 0.0
        var rest = Substring(text)
        while !rest.isEmpty {
            owed += rate * 0.045
            let count = min(Int(owed), rest.count)
            owed -= Double(count)
            if count > 0 {
                arrivals.append((at, String(rest.prefix(count))))
                rest = rest.dropFirst(count)
            }
            at += 0.045
        }
        return arrivals
    }

    private struct Seen {
        var phrase: ReplyPreview.Phrase
        var at: TimeInterval
        var words: String
    }

    /// Plays `arrivals` in, reading as the row reads, and keeps each phrase
    /// as it showed after each read.
    private func play(_ arrivals: [Arrival], until end: TimeInterval) -> [Seen] {
        let preview = ReplyPreview()
        preview.width = Self.width
        var seen: [Seen] = []
        var text = ""
        var next = 0
        var lastRead = -1.0
        var now = 0.0
        while now <= end {
            while next < arrivals.count, arrivals[next].at <= now {
                text += arrivals[next].text
                next += 1
            }
            if now - lastRead >= ReplyPreview.interval {
                lastRead = now
                preview.update(source: text, ended: next >= arrivals.count, now: now,
                               lineHeight: Self.lineHeight, measure: Self.measure)
                if let phrase = preview.current {
                    seen.append(Seen(phrase: phrase, at: now, words: ReplyPreviewReaderTests.words(text)))
                }
            }
            now += 0.015
        }
        return seen
    }

    func testThePhraseIsOnlyWordsAlreadyWrittenAndFitsTwoLines() {
        let seen = play(steady(Self.long, rate: 55), until: 6)
        XCTAssertFalse(seen.isEmpty)
        for item in seen {
            XCTAssertTrue(item.words.contains(item.phrase.text), "\(item.phrase.text) is not among the words so far")
            XCTAssertLessThanOrEqual(Self.lines(item.phrase.text), ReplyPreview.lines, item.phrase.text)
        }
    }

    func testTheFirstPhraseStartsWithTheFirstWords() {
        let seen = play(steady(Self.long, rate: 55), until: 6)
        let first = seen.first
        XCTAssertEqual(first?.phrase.number, 1)
        XCTAssertEqual(first.map { $0.at < 0.2 }, true, "shows with the first batch")
        XCTAssertEqual(first.map { Self.long.hasPrefix($0.phrase.text) }, true)
    }

    func testAFastModelsPhraseChangesNoOftenerThanHalfABreath() {
        let arrivals = steady(Self.long, rate: 55)
        let end = arrivals.last?.at ?? 0
        let seen = play(arrivals, until: 8)
        var shown: [Int: TimeInterval] = [:]
        for item in seen where shown[item.phrase.number] == nil { shown[item.phrase.number] = item.phrase.shownAt }
        let times = shown.keys.sorted().compactMap { shown[$0] }
        XCTAssertGreaterThan(times.count, 2, "the phrase moves on with the reply")
        for (earlier, later) in zip(times, times.dropFirst()) {
            // Once the reply has ended its last words may come sooner.
            let least = later > end ? ReplyPreview.shortestLifeAtEnd : ReplyPreview.shortestLife
            XCTAssertGreaterThanOrEqual(later - earlier, least - 0.001)
        }
        print("PREVIEW-NOTE fast phrases=\(times.count) end=\(String(format: "%.2f", end)) times=\(times.map { String(format: "%.2f", $0) }) last=\(seen.last?.phrase.text ?? "")")
    }

    func testANewPhraseStartsWithinOneLineMostlyAtAClause() {
        let seen = play(steady(Self.long, rate: 55), until: 8)
        let starts = Dictionary(seen.map { ($0.phrase.number, $0) }, uniquingKeysWith: { first, _ in first })
        var atClause = 0
        var later = 0
        for number in starts.keys.sorted() where number > 1 {
            guard let item = starts[number] else { continue }
            later += 1
            XCTAssertEqual(Self.lines(item.phrase.text), 1, "starts within one line: \(item.phrase.text)")
            guard let range = item.words.range(of: item.phrase.text, options: .backwards) else {
                XCTFail("not among the words: \(item.phrase.text)"); continue
            }
            let before = item.words[..<range.lowerBound].last { $0 != " " }
            if before.map({ "。、！？,.".contains($0) }) ?? true { atClause += 1 }
            print("PREVIEW-NOTE start \(number) …\(before.map(String.init) ?? "")|\(item.phrase.text)")
        }
        XCTAssertGreaterThan(later, 0)
        XCTAssertGreaterThanOrEqual(atClause * 2, later, "most phrases begin at a clause")
    }

    func testASlowModelsPhraseGrowsAsItWrites() {
        let seen = play(steady(Self.long, rate: 8), until: 4)
        XCTAssertEqual(Set(seen.map(\.phrase.number)), [1], "one phrase while it fills")
        let lengths = seen.map(\.phrase.text.count)
        XCTAssertEqual(lengths, lengths.sorted(), "it only grows")
        XCTAssertGreaterThan(lengths.last ?? 0, 20)
        // A piece for each read that brought characters, each kept with its time.
        let pieces = seen.last?.phrase.pieces ?? []
        XCTAssertGreaterThan(pieces.count, 3)
        XCTAssertEqual(pieces.last?.count, seen.last?.phrase.text.count)
    }

    /// A phrase's characters wait for the stage's words (the first phrase)
    /// or the phrase giving way (the next ones) to go, and never come out
    /// of order.
    func testANewPhrasesWordsWaitTheirTurn() {
        let seen = play(steady(Self.long, rate: 60), until: 6)
        var checked = Set<Int>()
        for item in seen where !checked.contains(item.phrase.number) {
            checked.insert(item.phrase.number)
            let delay = item.phrase.number == 1 ? ReplyPreview.firstDelay : ReplyPreview.swapDelay
            XCTAssertEqual(item.phrase.pieces.first?.at ?? 0, item.phrase.shownAt + delay, accuracy: 0.001)
        }
        for item in seen {
            let times = item.phrase.pieces.map(\.at).filter { $0 > 0 }
            XCTAssertEqual(times, times.sorted(), "characters come in order")
        }
        XCTAssertGreaterThan(checked.count, 1)
    }

    func testNothingShowsBeforeThereAreWords() {
        let preview = ReplyPreview()
        preview.width = Self.width
        for text in ["", "\n", "```", "$$\n\\frac{a}{b}", "---"] {
            preview.update(source: text, ended: false, now: 1, lineHeight: Self.lineHeight, measure: Self.measure)
            XCTAssertNil(preview.current, "\(text.debugDescription) shows nothing")
        }
    }

    func testNoWidthNoPhrase() {
        let preview = ReplyPreview()
        preview.update(source: Self.long, ended: false, now: 1, lineHeight: Self.lineHeight, measure: Self.measure)
        XCTAssertNil(preview.current)
    }

    func testTheGivenWayPhraseIsForgottenAfterItsFade() {
        let preview = ReplyPreview()
        preview.width = Self.width
        var text = ""
        var now = 0.0
        var sawLeaving = false
        for arrival in steady(Self.long, rate: 55) {
            text += arrival.text
            now = arrival.at
            preview.update(source: text, ended: false, now: now, lineHeight: Self.lineHeight, measure: Self.measure)
            if let leaving = preview.previous {
                sawLeaving = true
                XCTAssertLessThanOrEqual(now - leaving.at, ReplyPreview.swapDuration + 0.05)
                XCTAssertNotEqual(leaving.phrase.number, preview.current?.number)
            }
        }
        XCTAssertTrue(sawLeaving)
    }

    func testItsHeightEasesToTheSecondLine() {
        let seen = play(steady(Self.long, rate: 20), until: 3)
        guard let grown = seen.first(where: { Self.lines($0.phrase.text) == 2 })?.phrase else {
            return XCTFail("the first phrase reaches its second line")
        }
        XCTAssertEqual(grown.heightFrom, 18, accuracy: 0.5)
        XCTAssertEqual(grown.height, 36, accuracy: 0.5)
        XCTAssertEqual(ReplyPreview.height(of: grown, at: grown.heightAt), 18, accuracy: 0.5)
        XCTAssertEqual(ReplyPreview.height(of: grown, at: grown.heightAt + ReplyPreview.heightEase), 36, accuracy: 0.5)
    }

    func testAReplacedReplyStartsOver() {
        let preview = ReplyPreview()
        preview.width = Self.width
        preview.update(source: "最初の返信です。", ended: false, now: 1, lineHeight: Self.lineHeight, measure: Self.measure)
        preview.update(source: "別の返信です。", ended: false, now: 2, lineHeight: Self.lineHeight, measure: Self.measure)
        XCTAssertEqual(preview.current?.text, "別の返信です。")
    }
}

/// What the preview reads of a reply (ReplyPreviewReader).
final class ReplyPreviewReaderTests: XCTestCase {
    /// The words of `text`, read in one go.
    static func words(_ text: String) -> String {
        var reader = ReplyPreviewReader()
        reader.read(ReplyPreviewText.withoutThoughts(text))
        return reader.text(from: reader.base, to: reader.total)
    }

    /// The same words however the text arrives.
    private func wordsInPieces(_ text: String, size: Int) -> String {
        var reader = ReplyPreviewReader()
        var sofar = ""
        var rest = Substring(text)
        while !rest.isEmpty {
            sofar += rest.prefix(size)
            rest = rest.dropFirst(size)
            reader.read(sofar)
        }
        return reader.text(from: reader.base, to: reader.total)
    }

    func testMarkdownReadsAsItsWords() {
        let text = "## 量子コンピュータ\n\n**量子ビット**を使います。[詳しく](https://example.com)は`qubit`で。\n\n- 重ね合わせ\n1. もつれ\n> 引用です\n---\n"
        XCTAssertEqual(Self.words(text), "量子コンピュータ 量子ビットを使います。詳しくはqubitで。 重ね合わせ もつれ 引用です")
    }

    func testCodeShowsAsItsLinesButNotAChartsData() {
        let text = "コードです。\n```swift\nlet qubit = Qubit()\n```\n図です。\n```chart\n{\"type\": \"bar\"}\n```\n以上です。"
        XCTAssertEqual(Self.words(text), "コードです。 let qubit = Qubit() 図です。 以上です。")
    }

    func testFormulasAndRulesAreLeftOutAndTablesReadAsCells() {
        let text = "式は$x^2$です。\n$$\n\\frac{a}{b}\n$$\n| 名前 | 値 |\n|---|---|\n| 速さ | 速い |\n"
        XCTAssertEqual(Self.words(text), "式はです。 名前  値 速さ  速い")
    }

    func testThoughtsNeverShow() {
        XCTAssertEqual(Self.words("<think>内部の考え</think>答えです。"), "答えです。")
        XCTAssertEqual(Self.words("答えの前に<think>考え中"), "答えの前に")
    }

    func testPiecesReadAsTheWhole() {
        let text = "## 見出し\n\n本文の**太字**と`コード`。\n```\nprint(1)\n```\n終わり。"
        XCTAssertEqual(wordsInPieces(text, size: 3), Self.words(text))
        XCTAssertEqual(wordsInPieces(text, size: 1), Self.words(text))
    }

    func testClauseAndWordStarts() {
        var reader = ReplyPreviewReader()
        reader.read("量子は、仕組みを使います。Then it ends.")
        let words = Array(reader.text(from: 0, to: reader.total))
        let clauses = reader.clauseStarts(from: 1, to: reader.total).map { String(words[$0]) }
        XCTAssertEqual(clauses, ["仕", "T"])
        let starts = reader.wordStarts(from: 1, to: reader.total).map { String(words[$0]) }
        XCTAssertTrue(starts.contains("使"), "\(starts)")
        XCTAssertTrue(starts.contains("i"), "\(starts)")
    }

    func testOnlyTheNewestWordsAreKept() {
        let line = String(repeating: "あ", count: 99) + "。\n"
        var reader = ReplyPreviewReader()
        reader.read(String(repeating: line, count: 40))
        XCTAssertGreaterThan(reader.base, 0)
        XCTAssertLessThanOrEqual(reader.words.count, ReplyPreviewReader.keep + 200 + 1)
        XCTAssertEqual(reader.total, 40 * 100 + 39)
    }
}
