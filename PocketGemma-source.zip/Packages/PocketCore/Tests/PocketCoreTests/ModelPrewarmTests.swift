import XCTest
@testable import PocketCore

/// 先行読み込み (1.1.0 (284), Issue #21): which chats load their model ahead
/// of the question, and how much room a load ahead leaves.
final class ModelPrewarmTests: XCTestCase {
    private func conditions(_ model: ModelSpec = .e2b, onScreen: Bool = true, generating: Bool = false,
                            remote: Bool = false, smart: Bool = false, installed: Bool = true,
                            lowPower: Bool = false, thermal: Int = 0) -> ModelPrewarm.Conditions {
        ModelPrewarm.Conditions(model: model, onScreen: onScreen, generating: generating, remote: remote, smart: smart,
                                installed: installed, lowPower: lowPower, thermal: thermal)
    }

    func testASavedGemmaOnScreenLoadsAhead() {
        XCTAssertNil(ModelPrewarm.skip(conditions(.e2b)))
        XCTAssertNil(ModelPrewarm.skip(conditions(.e4b)))
        // Qwen runs on LiteRT-LM too (developer settings).
        XCTAssertNil(ModelPrewarm.skip(conditions(.qwen3)))
        // Warm is not hot: .fair (1) still loads.
        XCTAssertNil(ModelPrewarm.skip(conditions(thermal: 1)))
    }

    func testEachReasonLeavesTheLoadToTheSend() {
        XCTAssertEqual(ModelPrewarm.skip(conditions(onScreen: false)), .offScreen)
        XCTAssertEqual(ModelPrewarm.skip(conditions(generating: true)), .generating)
        // Claude and the PC: nothing loads on the phone.
        XCTAssertEqual(ModelPrewarm.skip(conditions(remote: true)), .remote)
        XCTAssertEqual(ModelPrewarm.skip(conditions(smart: true)), .smart)
        // Nothing downloads for it.
        XCTAssertEqual(ModelPrewarm.skip(conditions(installed: false)), .notInstalled)
        XCTAssertEqual(ModelPrewarm.skip(conditions(lowPower: true)), .lowPower)
        XCTAssertEqual(ModelPrewarm.skip(conditions(thermal: 2)), .heat)
        XCTAssertEqual(ModelPrewarm.skip(conditions(thermal: 3)), .heat)
        XCTAssertEqual(ModelPrewarm.skip(conditions(.gemma12B)), .large)
        // Off screen comes first: iOS gives no GPU there.
        XCTAssertEqual(ModelPrewarm.skip(conditions(onScreen: false, lowPower: true)), .offScreen)
    }

    func testRoomForTheStartAndForTheSendAfterAFailedOne() {
        let e2b = ModelSpec.e2b, e4b = ModelSpec.e4b
        // Twice the file for a start (E4B's GPU start mapped ~7.0 GB for 3.66 GB).
        XCTAssertEqual(ModelPrewarm.startAddressSpace(e4b), UInt64(e4b.downloadByteCount) * 2)
        XCTAssertGreaterThan(ModelPrewarm.startAddressSpace(e4b), 7_000_000_000)
        XCTAssertEqual(ModelPrewarm.minimumLargestFree(e2b), ModelPrewarm.startAddressSpace(e2b) * 2 + 1_000_000_000)
        // TestFlight's signature (Extended Virtual Addressing, 68.72 GB free
        // at launch on the phone) has room for both models.
        XCTAssertNil(ModelPrewarm.roomSkip(e4b, availableMemory: 6_440_000_000, largestFree: 68_720_000_000))
        XCTAssertNil(ModelPrewarm.roomSkip(e2b, availableMemory: 6_440_000_000, largestFree: 68_720_000_000))
        // The sideload's (about 6.44 GB in one block) leaves them to the send.
        XCTAssertEqual(ModelPrewarm.roomSkip(e2b, availableMemory: 3_470_000_000, largestFree: 6_440_000_000), .addressSpace)
        XCTAssertEqual(ModelPrewarm.roomSkip(e4b, availableMemory: 3_470_000_000, largestFree: 6_440_000_000), .addressSpace)
        // Little memory left: the send loads, as before.
        XCTAssertEqual(ModelPrewarm.roomSkip(e2b, availableMemory: 1_200_000_000, largestFree: 68_720_000_000), .memory)
        XCTAssertEqual(ModelPrewarm.roomSkip(e4b, availableMemory: ModelPrewarm.minimumAvailableMemory(e4b) - 1, largestFree: nil), .memory)
        XCTAssertNil(ModelPrewarm.roomSkip(e4b, availableMemory: ModelPrewarm.minimumAvailableMemory(e4b), largestFree: nil))
        // Not measured (the simulator's memory is the Mac's): not checked.
        XCTAssertNil(ModelPrewarm.roomSkip(e2b, availableMemory: nil, largestFree: nil))
        // The bigger file asks for more of both.
        XCTAssertGreaterThan(ModelPrewarm.minimumAvailableMemory(e4b), ModelPrewarm.minimumAvailableMemory(e2b))
        XCTAssertGreaterThan(ModelPrewarm.minimumLargestFree(e4b), ModelPrewarm.minimumLargestFree(e2b))
    }

    func testTheDiagnosticsNotes() {
        XCTAssertEqual(ModelPrewarm.Use.ready(loadSeconds: 3.24, readyBefore: 5.0).note,
                       "先行読み込み済み（読み込み 3.2秒・送信の 5.0秒前に完了）")
        XCTAssertEqual(ModelPrewarm.Use.joined(loadSeconds: 3.2, waited: 1.26).note,
                       "読み込み中に送信して合流（読み込み 3.2秒・送信後の待ち 1.3秒）")
        XCTAssertEqual(ModelPrewarm.Use.skipped(.lowPower).note, "先行読み込みは見送り: 低電力モード")
        for skip in ModelPrewarm.Skip.allCases { XCTAssertFalse(skip.note.isEmpty, "\(skip)") }
        // Short enough to wait out a menu and the keyboard, not the typing.
        XCTAssertLessThanOrEqual(ModelPrewarm.delay, .seconds(1))
        XCTAssertGreaterThanOrEqual(ModelPrewarm.delay, .milliseconds(300))
    }

    // MARK: 1.1.0 (288), Issue #25

    func testTheSideloadKeepsItsModelForALoadAheadThatCouldNeverFit() {
        // The sideload's launch (about 6.44 GB in one block): no room ever,
        // so nothing is let go for it.
        XCTAssertFalse(ModelPrewarm.launchHasRoom(.e2b, launchLargestFree: 6_440_000_000))
        XCTAssertFalse(ModelPrewarm.launchHasRoom(.e4b, launchLargestFree: 6_440_000_000))
        // TestFlight's (Extended Virtual Addressing, 68.72 GB).
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e2b, launchLargestFree: 68_720_000_000))
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e4b, launchLargestFree: 68_720_000_000))
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.qwen35, launchLargestFree: 68_720_000_000))
        // Not measured: the room is read again after the release.
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e4b, launchLargestFree: nil))
    }

    func testHeatLetsAnIdleModelGoFromSerious() {
        XCTAssertFalse(ModelPrewarm.releasesIdleModel(thermal: 0))
        XCTAssertFalse(ModelPrewarm.releasesIdleModel(thermal: 1))
        XCTAssertTrue(ModelPrewarm.releasesIdleModel(thermal: 2))
        XCTAssertTrue(ModelPrewarm.releasesIdleModel(thermal: 3))
    }

    func testTheModelsLoadedAheadAndThoseLeftToTheSend() {
        // LiteRT-LM's phone models: Gemma 4 E2B and E4B, and Qwen.
        for model in [ModelSpec.e2b, .e4b, .qwen3, .qwen25, .qwen35] {
            XCTAssertNil(ModelPrewarm.skip(conditions(model)), model.id)
        }
        // LFM3 on llama.cpp too since 1.1.0 (289), each reason as Gemma's.
        for model in [ModelSpec.lfm3, .lfm3VL, .lfm3Omni] {
            XCTAssertNil(ModelPrewarm.skip(conditions(model)), model.id)
            XCTAssertEqual(ModelPrewarm.skip(conditions(model, onScreen: false)), .offScreen, model.id)
            XCTAssertEqual(ModelPrewarm.skip(conditions(model, generating: true)), .generating, model.id)
            XCTAssertEqual(ModelPrewarm.skip(conditions(model, installed: false)), .notInstalled, model.id)
            XCTAssertEqual(ModelPrewarm.skip(conditions(model, lowPower: true)), .lowPower, model.id)
            XCTAssertEqual(ModelPrewarm.skip(conditions(model, thermal: 2)), .heat, model.id)
        }
        // Only 12B is left to the send.
        XCTAssertEqual(ModelPrewarm.skip(conditions(.gemma12B)), .large)
    }

    func testTheLineWaitsAndStays() {
        XCTAssertEqual(ModelPrewarm.indicatorDelay, .milliseconds(300))
        XCTAssertGreaterThanOrEqual(ModelPrewarm.indicatorMinimum, .milliseconds(500))
        XCTAssertEqual(ModelPrewarm.Use.reused.note, "起動済みのモデルを再利用（読み込みなし）")
        XCTAssertEqual(ModelPrewarm.Trigger.opened.rawValue, "opened")
    }

    // MARK: 1.1.0 (289), the LFM3 series on llama.cpp

    func testAnLFM3EngineServesItsTurnsWithPhotosOrNone() {
        for model in [ModelSpec.lfm3, .lfm3VL, .lfm3Omni] {
            let settings = GenerationSettings().normalized(for: model)
            let text = InferenceEnginePlan(model: model, settings: settings, needsVision: false)
            let photo = InferenceEnginePlan(model: model, settings: settings, needsVision: true)
            let heard = InferenceEnginePlan(model: model, settings: settings, needsVision: true, hearing: true)
            // The projector loads with the model: a load ahead without
            // photos serves a turn with them, and the other way round.
            XCTAssertTrue(ModelPrewarm.serves(text, photo), model.id)
            XCTAssertTrue(ModelPrewarm.serves(photo, text), model.id)
            XCTAssertTrue(ModelPrewarm.serves(text, heard), model.id)
            // The background's CPU, or another context: loaded again.
            var cpu = settings; cpu.backend = .cpu
            XCTAssertFalse(ModelPrewarm.serves(text, InferenceEnginePlan(model: model, settings: cpu, needsVision: false)), model.id)
            var shorter = settings; shorter.maxTokens = 2048
            XCTAssertFalse(ModelPrewarm.serves(text, InferenceEnginePlan(model: model, settings: shorter, needsVision: false)), model.id)
        }
        func plan(_ model: ModelSpec, photos: Bool = false) -> InferenceEnginePlan {
            InferenceEnginePlan(model: model, settings: GenerationSettings().normalized(for: model), needsVision: photos)
        }
        // Another model is never served, either way.
        XCTAssertFalse(ModelPrewarm.serves(plan(.lfm3), plan(.lfm3VL)))
        XCTAssertFalse(ModelPrewarm.serves(plan(.lfm3VL), plan(.lfm3Omni)))
        XCTAssertFalse(ModelPrewarm.serves(plan(.lfm3), plan(.e2b)))
        XCTAssertFalse(ModelPrewarm.serves(plan(.e2b), plan(.lfm3)))
        // LiteRT-LM's as in 288: the same plan only; photos need the vision part.
        XCTAssertTrue(ModelPrewarm.serves(plan(.e2b), plan(.e2b)))
        XCTAssertFalse(ModelPrewarm.serves(plan(.e2b), plan(.e2b, photos: true)))
        XCTAssertFalse(ModelPrewarm.serves(plan(.e4b, photos: true), plan(.e4b)))
    }

    func testLFM3LoadsAheadOnlyWithTheWideAddressSpace() {
        for model in [ModelSpec.lfm3, .lfm3VL, .lfm3Omni] {
            // The sideload's launch (6.44 GB in one block): never, though
            // the formula alone would let the smaller two in.
            XCTAssertFalse(ModelPrewarm.launchHasRoom(model, launchLargestFree: 6_440_000_000), model.id)
            XCTAssertFalse(ModelPrewarm.launchHasRoom(model, launchLargestFree: ModelPrewarm.llamaLaunchLargestFree - 1), model.id)
            // TestFlight's (Extended Virtual Addressing, 68.72 GB).
            XCTAssertTrue(ModelPrewarm.launchHasRoom(model, launchLargestFree: 68_720_000_000), model.id)
            XCTAssertNil(ModelPrewarm.roomSkip(model, availableMemory: 6_440_000_000, largestFree: 68_720_000_000), model.id)
            // The memory for the load (a quarter more than the files, which
            // llama.cpp keeps as the app's own) and 1.5 GB; too little: the send loads.
            XCTAssertEqual(ModelPrewarm.minimumAvailableMemory(model), ModelPrewarm.llamaFootprintBytes(model) + 1_500_000_000, model.id)
            XCTAssertEqual(ModelPrewarm.llamaFootprintBytes(model), UInt64(model.downloadByteCount) * 5 / 4, model.id)
            XCTAssertEqual(ModelPrewarm.roomSkip(model, availableMemory: ModelPrewarm.minimumAvailableMemory(model) - 1,
                                                 largestFree: nil), .memory, model.id)
            XCTAssertEqual(ModelPrewarm.roomSkip(model, availableMemory: 1_000_000_000, largestFree: nil), .memory, model.id)
            // Room for the load and for the send's after a failed one, as Gemma's.
            XCTAssertEqual(ModelPrewarm.startAddressSpace(model), ModelPrewarm.llamaMappedBytes(model), model.id)
            XCTAssertEqual(ModelPrewarm.minimumLargestFree(model), ModelPrewarm.llamaMappedBytes(model) * 2 + 1_000_000_000, model.id)
            XCTAssertEqual(ModelPrewarm.roomSkip(model, availableMemory: nil, largestFree: 4_000_000_000), .addressSpace, model.id)
        }
        // What the Mac measured fits, with room (run 43852786698): the
        // mapping on Metal, the memory on either.
        XCTAssertGreaterThan(ModelPrewarm.startAddressSpace(.lfm3), 2_597_000_000)
        XCTAssertGreaterThan(ModelPrewarm.startAddressSpace(.lfm3VL), 7_952_000_000)
        XCTAssertGreaterThan(ModelPrewarm.startAddressSpace(.lfm3Omni), 8_520_000_000)
        XCTAssertGreaterThan(ModelPrewarm.llamaFootprintBytes(.lfm3), 1_238_000_000)
        XCTAssertGreaterThan(ModelPrewarm.llamaFootprintBytes(.lfm3VL), 1_409_000_000)
        XCTAssertGreaterThan(ModelPrewarm.llamaFootprintBytes(.lfm3Omni), 1_769_000_000)
        // TestFlight's launch has the room for each even after a failed load.
        XCTAssertLessThan(ModelPrewarm.minimumLargestFree(.lfm3Omni), 68_720_000_000 / 2)
        // The line is the wide address space's, as じっくり考える's.
        XCTAssertEqual(ModelPrewarm.llamaLaunchLargestFree, PhotoDetail.deeperAddressSpace)
        // LiteRT-LM's gates are 288's.
        XCTAssertEqual(ModelPrewarm.minimumAvailableMemory(.e2b), UInt64(ModelSpec.e2b.downloadByteCount) / 4 + 1_500_000_000)
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e2b, launchLargestFree: 16_000_000_000 - 1))
    }

    func testAConversationBelongsToItsOwnChat() {
        let a = UUID(), b = UUID()
        var context = ConversationContext()
        XCTAssertFalse(context.belongs(to: a))
        context.completeTurn(threadID: a, history: [], prompt: "こんにちは", reply: "こんにちは。")
        XCTAssertTrue(context.belongs(to: a))
        XCTAssertFalse(context.belongs(to: b))
        context.invalidate()
        XCTAssertFalse(context.belongs(to: a))
    }
}

