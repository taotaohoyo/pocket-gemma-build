import XCTest
@testable import PocketCore

/// 先行読み込み (1.1.0 (284), Issue #21): which chats load their model ahead
/// of the question, and how much room a load ahead leaves.
final class ModelPrewarmTests: XCTestCase {
    private func conditions(_ model: ModelSpec = .e2b, onScreen: Bool = true, generating: Bool = false,
                            remote: Bool = false, smart: Bool = false, installed: Bool = true,
                            lowPower: Bool = false, thermal: Int = 0) -> ModelPrewarm.Conditions {
        ModelPrewarm.Conditions(model: model, onScreen: onScreen, generating: generating, remote: remote, smart: smart,
                                installed: installed, lowPower: lowPower, thermal: thermal)
    }

    func testASavedGemmaOnScreenLoadsAhead() {
        XCTAssertNil(ModelPrewarm.skip(conditions(.e2b)))
        XCTAssertNil(ModelPrewarm.skip(conditions(.e4b)))
        // Qwen runs on LiteRT-LM too (developer settings).
        XCTAssertNil(ModelPrewarm.skip(conditions(.qwen3)))
        // Warm is not hot: .fair (1) still loads.
        XCTAssertNil(ModelPrewarm.skip(conditions(thermal: 1)))
    }

    func testEachReasonLeavesTheLoadToTheSend() {
        XCTAssertEqual(ModelPrewarm.skip(conditions(onScreen: false)), .offScreen)
        XCTAssertEqual(ModelPrewarm.skip(conditions(generating: true)), .generating)
        // Claude and the PC: nothing loads on the phone.
        XCTAssertEqual(ModelPrewarm.skip(conditions(remote: true)), .remote)
        XCTAssertEqual(ModelPrewarm.skip(conditions(smart: true)), .smart)
        // Nothing downloads for it.
        XCTAssertEqual(ModelPrewarm.skip(conditions(installed: false)), .notInstalled)
        XCTAssertEqual(ModelPrewarm.skip(conditions(lowPower: true)), .lowPower)
        XCTAssertEqual(ModelPrewarm.skip(conditions(thermal: 2)), .heat)
        XCTAssertEqual(ModelPrewarm.skip(conditions(thermal: 3)), .heat)
        XCTAssertEqual(ModelPrewarm.skip(conditions(.gemma12B)), .large)
        XCTAssertEqual(ModelPrewarm.skip(conditions(.lfm3)), .otherRuntime)
        // Off screen comes first: iOS gives no GPU there.
        XCTAssertEqual(ModelPrewarm.skip(conditions(onScreen: false, lowPower: true)), .offScreen)
    }

    func testRoomForTheStartAndForTheSendAfterAFailedOne() {
        let e2b = ModelSpec.e2b, e4b = ModelSpec.e4b
        // Twice the file for a start (E4B's GPU start mapped ~7.0 GB for 3.66 GB).
        XCTAssertEqual(ModelPrewarm.startAddressSpace(e4b), UInt64(e4b.downloadByteCount) * 2)
        XCTAssertGreaterThan(ModelPrewarm.startAddressSpace(e4b), 7_000_000_000)
        XCTAssertEqual(ModelPrewarm.minimumLargestFree(e2b), ModelPrewarm.startAddressSpace(e2b) * 2 + 1_000_000_000)
        // TestFlight's signature (Extended Virtual Addressing, 68.72 GB free
        // at launch on the phone) has room for both models.
        XCTAssertNil(ModelPrewarm.roomSkip(e4b, availableMemory: 6_440_000_000, largestFree: 68_720_000_000))
        XCTAssertNil(ModelPrewarm.roomSkip(e2b, availableMemory: 6_440_000_000, largestFree: 68_720_000_000))
        // The sideload's (about 6.44 GB in one block) leaves them to the send.
        XCTAssertEqual(ModelPrewarm.roomSkip(e2b, availableMemory: 3_470_000_000, largestFree: 6_440_000_000), .addressSpace)
        XCTAssertEqual(ModelPrewarm.roomSkip(e4b, availableMemory: 3_470_000_000, largestFree: 6_440_000_000), .addressSpace)
        // Little memory left: the send loads, as before.
        XCTAssertEqual(ModelPrewarm.roomSkip(e2b, availableMemory: 1_200_000_000, largestFree: 68_720_000_000), .memory)
        XCTAssertEqual(ModelPrewarm.roomSkip(e4b, availableMemory: ModelPrewarm.minimumAvailableMemory(e4b) - 1, largestFree: nil), .memory)
        XCTAssertNil(ModelPrewarm.roomSkip(e4b, availableMemory: ModelPrewarm.minimumAvailableMemory(e4b), largestFree: nil))
        // Not measured (the simulator's memory is the Mac's): not checked.
        XCTAssertNil(ModelPrewarm.roomSkip(e2b, availableMemory: nil, largestFree: nil))
        // The bigger file asks for more of both.
        XCTAssertGreaterThan(ModelPrewarm.minimumAvailableMemory(e4b), ModelPrewarm.minimumAvailableMemory(e2b))
        XCTAssertGreaterThan(ModelPrewarm.minimumLargestFree(e4b), ModelPrewarm.minimumLargestFree(e2b))
    }

    func testTheDiagnosticsNotes() {
        XCTAssertEqual(ModelPrewarm.Use.ready(loadSeconds: 3.24, readyBefore: 5.0).note,
                       "先行読み込み済み（読み込み 3.2秒・送信の 5.0秒前に完了）")
        XCTAssertEqual(ModelPrewarm.Use.joined(loadSeconds: 3.2, waited: 1.26).note,
                       "読み込み中に送信して合流（読み込み 3.2秒・送信後の待ち 1.3秒）")
        XCTAssertEqual(ModelPrewarm.Use.skipped(.lowPower).note, "先行読み込みは見送り: 低電力モード")
        for skip in ModelPrewarm.Skip.allCases { XCTAssertFalse(skip.note.isEmpty, "\(skip)") }
        // Short enough to wait out a menu and the keyboard, not the typing.
        XCTAssertLessThanOrEqual(ModelPrewarm.delay, .seconds(1))
        XCTAssertGreaterThanOrEqual(ModelPrewarm.delay, .milliseconds(300))
    }

    // MARK: 1.1.0 (288), Issue #25

    func testTheSideloadKeepsItsModelForALoadAheadThatCouldNeverFit() {
        // The sideload's launch (about 6.44 GB in one block): no room ever,
        // so nothing is let go for it.
        XCTAssertFalse(ModelPrewarm.launchHasRoom(.e2b, launchLargestFree: 6_440_000_000))
        XCTAssertFalse(ModelPrewarm.launchHasRoom(.e4b, launchLargestFree: 6_440_000_000))
        // TestFlight's (Extended Virtual Addressing, 68.72 GB).
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e2b, launchLargestFree: 68_720_000_000))
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e4b, launchLargestFree: 68_720_000_000))
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.qwen35, launchLargestFree: 68_720_000_000))
        // Not measured: the room is read again after the release.
        XCTAssertTrue(ModelPrewarm.launchHasRoom(.e4b, launchLargestFree: nil))
    }

    func testHeatLetsAnIdleModelGoFromSerious() {
        XCTAssertFalse(ModelPrewarm.releasesIdleModel(thermal: 0))
        XCTAssertFalse(ModelPrewarm.releasesIdleModel(thermal: 1))
        XCTAssertTrue(ModelPrewarm.releasesIdleModel(thermal: 2))
        XCTAssertTrue(ModelPrewarm.releasesIdleModel(thermal: 3))
    }

    func testTheModelsLoadedAheadAndThoseLeftToTheSend() {
        // LiteRT-LM's phone models: Gemma 4 E2B and E4B, and Qwen.
        for model in [ModelSpec.e2b, .e4b, .qwen3, .qwen25, .qwen35] {
            XCTAssertNil(ModelPrewarm.skip(conditions(model)), model.id)
        }
        // LFM on llama.cpp, and 12B.
        for model in [ModelSpec.lfm3, .lfm3VL, .lfm3Omni] {
            XCTAssertEqual(ModelPrewarm.skip(conditions(model)), .otherRuntime, model.id)
        }
        XCTAssertEqual(ModelPrewarm.skip(conditions(.gemma12B)), .large)
    }

    func testTheLineWaitsAndStays() {
        XCTAssertEqual(ModelPrewarm.indicatorDelay, .milliseconds(300))
        XCTAssertGreaterThanOrEqual(ModelPrewarm.indicatorMinimum, .milliseconds(500))
        XCTAssertEqual(ModelPrewarm.Use.reused.note, "起動済みのモデルを再利用（読み込みなし）")
        XCTAssertEqual(ModelPrewarm.Trigger.opened.rawValue, "opened")
    }

    func testAConversationBelongsToItsOwnChat() {
        let a = UUID(), b = UUID()
        var context = ConversationContext()
        XCTAssertFalse(context.belongs(to: a))
        context.completeTurn(threadID: a, history: [], prompt: "こんにちは", reply: "こんにちは。")
        XCTAssertTrue(context.belongs(to: a))
        XCTAssertFalse(context.belongs(to: b))
        context.invalidate()
        XCTAssertFalse(context.belongs(to: a))
    }
}

