import XCTest
@testable import PocketCore

/// The model pickers by series (fielua-reports Issue #7, 1.1.0 (269)): the
/// first level lists Gemma, Qwen and LFM (and Phi until 279), each opening
/// to its models, grouped from the models' own `family`. モデル管理 lists
/// the same series from 1.1.0 (279) (Issue #17).
final class ModelFamilyTests: XCTestCase {
    func testThePickersListTheSeriesTheUserNamedInTheirOrder() {
        let groups = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: false))
        XCTAssertEqual(groups.map(\.family), ["Gemma", "Qwen", "LFM"])
        XCTAssertEqual(groups.map(\.key), ["gemma", "qwen", "lfm"])
        XCTAssertEqual(groups.map(\.title), groups.map(\.family))
        // E2B first, as the first launch and the chat's menu listed it.
        XCTAssertEqual(groups[0].models.map(\.id), [ModelSpec.e2b.id, ModelSpec.e4b.id, ModelSpec.gemma12B.id])
        XCTAssertEqual(groups[1].models.map(\.id), [ModelSpec.qwen35.id, ModelSpec.qwen25.id])
        XCTAssertEqual(groups[2].models.map(\.id), [ModelSpec.lfm3.id, ModelSpec.lfm3VL.id, ModelSpec.lfm3Omni.id])
        // No Phi series, with developer settings either (1.1.0 (279)).
        for developer in [false, true] {
            XCTAssertFalse(ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: developer)).contains { $0.family == "Phi" })
        }
    }

    /// Nothing is lost or doubled: every model the pickers offered before
    /// is in exactly one series, its own; Qwen3 0.6B only with developer
    /// settings, in Qwen; no part of a model (a projector) is offered.
    func testEveryModelIsInItsOwnSeriesOnce() {
        for developer in [false, true] {
            let offered = ModelSpec.pickerCatalog(developer: developer)
            XCTAssertEqual(offered.first?.id, ModelSpec.e2b.id)
            XCTAssertEqual(Set(offered.map(\.id)), Set(ModelSpec.visibleCatalog(developer: developer).map(\.id)))
            let groups = ModelFamilyGroup.groups(offered)
            let grouped = groups.flatMap(\.models)
            XCTAssertEqual(grouped.count, offered.count)
            XCTAssertEqual(Set(grouped.map(\.id)), Set(offered.map(\.id)))
            for group in groups {
                XCTAssertFalse(group.models.isEmpty)
                XCTAssertTrue(group.models.allSatisfy { $0.family == group.family }, group.family)
            }
            XCTAssertEqual(groups.first { $0.contains(ModelSpec.qwen3.id) }?.family, developer ? "Qwen" : nil)
            XCTAssertFalse(grouped.contains { $0.id == ModelSpec.lfm3VLProjector.id || $0.id == ModelSpec.lfm3OmniProjector.id })
        }
        let qwen = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: true)).first { $0.family == "Qwen" }
        XCTAssertEqual(qwen?.models.map(\.id), [ModelSpec.qwen35.id, ModelSpec.qwen3.id, ModelSpec.qwen25.id])
    }

    /// From the models, not a fixed list: a model given twice is listed
    /// once, and a series the picker has never seen gets a row of its own
    /// after the named ones, in the order its first model came.
    func testSeriesComeFromTheModelsThemselves() {
        let other = ModelSpec(fileName: "other.litertlm", byteCount: 1, sha256: String(repeating: "0", count: 64),
                              downloadURL: URL(string: "https://example.invalid/other.litertlm")!,
                              id: "other-1b", name: "Other 1B", family: "Other")
        let groups = ModelFamilyGroup.groups([other, .phi4MiniReasoning, .qwen25, .e4b, .qwen25, .e2b])
        // A series not named (Phi since 279, Other) after the named ones,
        // in the order its first model came.
        XCTAssertEqual(groups.map(\.family), ["Gemma", "Qwen", "Other", "Phi"])
        XCTAssertEqual(groups[0].models.map(\.id), [ModelSpec.e4b.id, ModelSpec.e2b.id], "The order given")
        XCTAssertEqual(groups[1].models.map(\.id), [ModelSpec.qwen25.id], "Once")
        XCTAssertTrue(groups[2].contains("other-1b")); XCTAssertFalse(groups[2].contains(nil))
        XCTAssertTrue(ModelFamilyGroup.groups([]).isEmpty)
    }

    /// The series' line: how many models and how many are on the phone;
    /// LFM, test versions all, says so before it is opened.
    func testTheSeriesLineAndItsTestVersions() {
        let groups = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: false))
        let gemma = groups[0], lfm = groups[2]
        XCTAssertEqual(gemma.summary { _ in false }, "3モデル")
        XCTAssertEqual(gemma.summary { $0.id == ModelSpec.e2b.id || $0.id == ModelSpec.e4b.id }, "3モデル · ダウンロード済み 2")
        XCTAssertEqual(lfm.summary { _ in true }, "3モデル · ダウンロード済み 3")
        XCTAssertFalse(gemma.isAllTestVersions, "E2B and E4B are not test versions")
        XCTAssertFalse(groups[1].isAllTestVersions)
        XCTAssertTrue(lfm.isAllTestVersions)
    }

    /// モデル管理's series rows say what the chat's menu says (1.1.0 (279)):
    /// the model in use, else one downloading, else the count; E2B and E4B
    /// by their short names within Gemma.
    func testTheLineSharedByTheMenuAndModelManagement() {
        let groups = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: false))
        let gemma = groups[0], qwen = groups[1]
        XCTAssertEqual(ModelSpec.e4b.shortName, "E4B"); XCTAssertEqual(ModelSpec.gemma12B.shortName, "12B")
        XCTAssertEqual(ModelSpec.qwen35.shortName, "Qwen3.5 4B")
        XCTAssertEqual(gemma.line(currentID: ModelSpec.e4b.id, downloading: .e2b, percent: 40, installed: { _ in false }), "E4Bを使用中")
        XCTAssertEqual(gemma.line(currentID: ModelSpec.qwen25.id, downloading: .e2b, percent: 40, installed: { _ in false }),
                       "E2B · ダウンロード中 40%")
        XCTAssertEqual(qwen.line(currentID: ModelSpec.e4b.id, downloading: .e2b, percent: 40, installed: { $0.id == ModelSpec.qwen25.id }),
                       "2モデル · ダウンロード済み 1", "Another series' download is not this one's")
        XCTAssertEqual(qwen.line(currentID: nil, downloading: nil, percent: 0, installed: { _ in false }), "2モデル")
    }
}
