import XCTest
@testable import PocketCore

/// The model pickers by series (fielua-reports Issue #7, 1.1.0 (269)): the
/// first level lists Gemma, Qwen, LFM and Phi, each opening to its models,
/// grouped from the models' own `family`.
final class ModelFamilyTests: XCTestCase {
    func testThePickersListTheSeriesTheUserNamedInTheirOrder() {
        let groups = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: false))
        XCTAssertEqual(groups.map(\.family), ["Gemma", "Qwen", "LFM", "Phi"])
        XCTAssertEqual(groups.map(\.key), ["gemma", "qwen", "lfm", "phi"])
        XCTAssertEqual(groups.map(\.title), groups.map(\.family))
        // E2B first, as the first launch and the chat's menu listed it.
        XCTAssertEqual(groups[0].models.map(\.id), [ModelSpec.e2b.id, ModelSpec.e4b.id, ModelSpec.gemma12B.id])
        XCTAssertEqual(groups[1].models.map(\.id), [ModelSpec.qwen35.id, ModelSpec.qwen25.id])
        XCTAssertEqual(groups[2].models.map(\.id), [ModelSpec.lfm3.id, ModelSpec.lfm3VL.id, ModelSpec.lfm3Omni.id])
        XCTAssertEqual(groups[3].models.map(\.id), [ModelSpec.phi4MiniReasoning.id])
    }

    /// Nothing is lost or doubled: every model the pickers offered before
    /// is in exactly one series, its own; Qwen3 0.6B only with developer
    /// settings, in Qwen; no part of a model (a projector) is offered.
    func testEveryModelIsInItsOwnSeriesOnce() {
        for developer in [false, true] {
            let offered = ModelSpec.pickerCatalog(developer: developer)
            XCTAssertEqual(offered.first?.id, ModelSpec.e2b.id)
            XCTAssertEqual(Set(offered.map(\.id)), Set(ModelSpec.visibleCatalog(developer: developer).map(\.id)))
            let groups = ModelFamilyGroup.groups(offered)
            let grouped = groups.flatMap(\.models)
            XCTAssertEqual(grouped.count, offered.count)
            XCTAssertEqual(Set(grouped.map(\.id)), Set(offered.map(\.id)))
            for group in groups {
                XCTAssertFalse(group.models.isEmpty)
                XCTAssertTrue(group.models.allSatisfy { $0.family == group.family }, group.family)
            }
            XCTAssertEqual(groups.first { $0.contains(ModelSpec.qwen3.id) }?.family, developer ? "Qwen" : nil)
            XCTAssertFalse(grouped.contains { $0.id == ModelSpec.lfm3VLProjector.id || $0.id == ModelSpec.lfm3OmniProjector.id })
        }
        let qwen = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: true)).first { $0.family == "Qwen" }
        XCTAssertEqual(qwen?.models.map(\.id), [ModelSpec.qwen35.id, ModelSpec.qwen3.id, ModelSpec.qwen25.id])
    }

    /// From the models, not a fixed list: a model given twice is listed
    /// once, and a series the picker has never seen gets a row of its own
    /// after the named ones, in the order its first model came.
    func testSeriesComeFromTheModelsThemselves() {
        let other = ModelSpec(fileName: "other.litertlm", byteCount: 1, sha256: String(repeating: "0", count: 64),
                              downloadURL: URL(string: "https://example.invalid/other.litertlm")!,
                              id: "other-1b", name: "Other 1B", family: "Other")
        let groups = ModelFamilyGroup.groups([other, .phi4MiniReasoning, .qwen25, .e4b, .qwen25, .e2b])
        XCTAssertEqual(groups.map(\.family), ["Gemma", "Qwen", "Phi", "Other"])
        XCTAssertEqual(groups[0].models.map(\.id), [ModelSpec.e4b.id, ModelSpec.e2b.id], "The order given")
        XCTAssertEqual(groups[1].models.map(\.id), [ModelSpec.qwen25.id], "Once")
        XCTAssertTrue(groups[3].contains("other-1b")); XCTAssertFalse(groups[3].contains(nil))
        XCTAssertTrue(ModelFamilyGroup.groups([]).isEmpty)
    }

    /// The series' line: how many models and how many are on the phone;
    /// LFM and Phi, test versions all, say so before they are opened.
    func testTheSeriesLineAndItsTestVersions() {
        let groups = ModelFamilyGroup.groups(ModelSpec.pickerCatalog(developer: false))
        let gemma = groups[0], lfm = groups[2], phi = groups[3]
        XCTAssertEqual(gemma.summary { _ in false }, "3モデル")
        XCTAssertEqual(gemma.summary { $0.id == ModelSpec.e2b.id || $0.id == ModelSpec.e4b.id }, "3モデル · ダウンロード済み 2")
        XCTAssertEqual(phi.summary { _ in true }, "1モデル · ダウンロード済み 1")
        XCTAssertFalse(gemma.isAllTestVersions, "E2B and E4B are not test versions")
        XCTAssertFalse(groups[1].isAllTestVersions)
        XCTAssertTrue(lfm.isAllTestVersions); XCTAssertTrue(phi.isAllTestVersions)
    }
}
