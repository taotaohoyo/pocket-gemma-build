import XCTest
@testable import PocketCore

/// PCと接続 (1.1.0 (253)): what the iPhone computes and reads exactly as
/// Fielua for Windows does (src-tauri/src/link/proto.rs has the same
/// vectors), and which turns a PC reply is given; and (1.1.0 (254)) the
/// networks and what the iPhone says when the PC doesn't answer.
final class PCLinkTests: XCTestCase {
    private func bytes(_ value: UInt8) -> Data { Data(repeating: value, count: 32) }

    func testNumbersMatchFieluaForWindows() {
        XCTAssertEqual(PCLink.commitment(serverNonce: bytes(0x33)), "jECjYSmMoCwY-ZaOXoNEcoJZc90BQT5g9lBnya8E2zA")
        XCTAssertEqual(PCLink.confirmationNumber(fingerprint: bytes(0x11), clientNonce: bytes(0x22), serverNonce: bytes(0x33)),
                       "613 534")
        XCTAssertEqual(PCLink.tokenHash("abc"), "ef14115dfc719ba573ae44169f8c69a7dccecac7e3f9dcc1c011371ecd660da6")
    }

    func testBase64URLRoundTripsAndRefusesOtherText() {
        let data = Data((0..<64).map { UInt8($0 * 4) })
        let text = PCLink.base64URL(data)
        XCTAssertFalse(text.contains("+") || text.contains("/") || text.contains("="))
        XCTAssertEqual(PCLink.data(base64URL: text), data)
        XCTAssertNil(PCLink.data(base64URL: ""))
        XCTAssertNil(PCLink.data(base64URL: "abc$"))
        XCTAssertNil(PCLink.data(base64URL: "あいう"))
    }

    func testNoncesAreRandom32Bytes() {
        let a = PCLink.randomNonce(), b = PCLink.randomNonce()
        XCTAssertEqual(a.count, 32)
        XCTAssertNotEqual(a, b)
    }

    func testCodeAndAddressAsTyped() {
        XCTAssertEqual(PCLink.normalizedCode(" 1234-5678 "), "12345678")
        XCTAssertEqual(PCLink.normalizedCode("１２３"), "", "full-width digits are not the code's")
        XCTAssertEqual(PCLink.address("192.168.1.10")?.host, "192.168.1.10")
        XCTAssertEqual(PCLink.address("192.168.1.10")?.port, PCLink.defaultPort)
        XCTAssertEqual(PCLink.address(" DESKTOP.local:47861 ")?.port, 47861)
        XCTAssertNil(PCLink.address(""))
        XCTAssertNil(PCLink.address("192.168.1.10:0"))
        XCTAssertNil(PCLink.address("192.168.1.10:99999"))
        XCTAssertNil(PCLink.address("http://192.168.1.10"))
        XCTAssertNil(PCLink.address("a:b:c"))
    }

    private var inviteText: String {
        let fp = PCLink.base64URL(bytes(0xAB)), secret = PCLink.base64URL(bytes(0xCD))
        return "fielua://pair?v=1&id=abc123&n=DESKTOP%201&h=192.168.1.10,10.0.0.5&p=47860&fp=\(fp)&s=\(secret)"
    }

    func testQRInvitationIsRead() throws {
        let invite = try XCTUnwrap(PCPairingInvite(inviteText))
        XCTAssertEqual(invite.pcID, "abc123")
        XCTAssertEqual(invite.pcName, "DESKTOP 1")
        XCTAssertEqual(invite.hosts, ["192.168.1.10", "10.0.0.5"])
        XCTAssertEqual(invite.port, 47860)
        XCTAssertEqual(invite.fingerprint, bytes(0xAB))
        XCTAssertEqual(PCLink.data(base64URL: invite.secret), bytes(0xCD))
    }

    func testOtherQRCodesAreRefused() {
        XCTAssertNil(PCPairingInvite("https://example.com"))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "v=1", with: "v=2")))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "fielua://pair", with: "fielua://other")))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "p=47860", with: "p=0")))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "id=abc123", with: "id=../x")))
        let shortFingerprint = PCLink.base64URL(Data(repeating: 1, count: 16))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: PCLink.base64URL(bytes(0xAB)), with: shortFingerprint)))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "&s=", with: "&x=")))
    }

    func testInvitationWithoutANameOrAddresses() throws {
        let text = inviteText.replacingOccurrences(of: "n=DESKTOP%201&h=192.168.1.10,10.0.0.5&", with: "")
        let invite = try XCTUnwrap(PCPairingInvite(text))
        XCTAssertEqual(invite.pcName, "Windows PC")
        XCTAssertEqual(invite.hosts, [])
    }

    func testPairedPCTriesTheLastAddressFirstThenItsName() {
        var pc = PCPairedPC(pcID: "abc123", pcName: "PC", fingerprint: "x", hosts: ["192.168.1.10", "10.0.0.5"],
                            port: 47860, deviceID: "d", token: "t")
        XCTAssertEqual(pc.candidateHosts, ["192.168.1.10", "10.0.0.5", "fielua-abc123.local"])
        pc.answered(at: "10.0.0.5")
        XCTAssertEqual(pc.hosts, ["10.0.0.5", "192.168.1.10"])
        for index in 0..<10 { pc.answered(at: "192.168.2.\(index)") }
        XCTAssertEqual(pc.hosts.count, 6)
        XCTAssertEqual(pc.hosts.first, "192.168.2.9")
    }

    func testPairedPCLearnsItsAddressesAndPort() {
        var pc = PCPairedPC(pcID: "abc123", pcName: "PC", fingerprint: "x", hosts: ["fielua-abc123.local"],
                            port: 47860, deviceID: "d", token: "t")
        // Registered by choosing it in the list: its name, then the addresses it gives.
        pc.answered(at: "fielua-abc123.local", addresses: ["192.168.1.10", "192.168.137.1", "DESKTOP.local", "1.2.3"])
        XCTAssertEqual(pc.hosts, ["fielua-abc123.local", "192.168.1.10", "192.168.137.1"], "addresses only, no names")
        XCTAssertEqual(pc.port, 47860)
        pc.answered(at: "192.168.137.1", port: 47861, addresses: ["192.168.137.1", "192.168.1.11"])
        XCTAssertEqual(pc.hosts, ["192.168.137.1", "192.168.1.11", "fielua-abc123.local", "192.168.1.10"])
        XCTAssertEqual(pc.port, 47861, "the port Bonjour found it on")
        pc.answered(at: "192.168.1.11", port: 0)
        XCTAssertEqual(pc.port, 47861, "no port is no change")
        XCTAssertEqual(pc.candidateHosts.last, "192.168.1.10")
    }

    func testHostsAreTriedLikeliestFirst() {
        let home = PCLinkNetwork("192.168.1.0/24")
        let saved = ["10.0.0.5", "fielua-abc.local", "192.168.1.10", "192.168.1.11"]
        XCTAssertEqual(PCLink.orderedHosts(saved, network: home),
                       ["192.168.1.10", "192.168.1.11", "fielua-abc.local", "10.0.0.5"])
        XCTAssertEqual(PCLink.orderedHosts(saved, first: "192.168.1.11", announced: "fielua-abc.local", network: home),
                       ["192.168.1.11", "fielua-abc.local", "192.168.1.10", "10.0.0.5"])
        // Unknown network: as saved, the last that answered first.
        XCTAssertEqual(PCLink.orderedHosts(saved, first: "192.168.1.10"),
                       ["192.168.1.10", "10.0.0.5", "fielua-abc.local", "192.168.1.11"])
        XCTAssertEqual(PCLink.orderedHosts(["A.local", "a.local", "192.168.1.10"], network: home), ["192.168.1.10", "A.local"])
    }

    func testPairedPCRoundTripsThroughJSON() throws {
        let pc = PCPairedPC(pcID: "abc123", pcName: "PC", fingerprint: "fp", hosts: ["192.168.1.10"], port: 47861,
                            deviceID: "d", token: "t", pairedAt: Date(timeIntervalSince1970: 1_800_000_000))
        XCTAssertEqual(try JSONDecoder().decode(PCPairedPC.self, from: JSONEncoder().encode(pc)), pc)
    }

    func testNetworksFromAddressesAndMasks() throws {
        let home = try XCTUnwrap(PCLinkNetwork(address: "192.168.1.23", netmask: "255.255.255.0"))
        XCTAssertEqual(home.description, "192.168.1.0/24")
        XCTAssertEqual(PCLinkNetwork("192.168.1.0/24"), home)
        XCTAssertTrue(home.contains("192.168.1.10"))
        XCTAssertFalse(home.contains("192.168.2.10"))
        XCTAssertFalse(home.contains("fielua-abc.local"), "a name is no address")
        XCTAssertFalse(home.isWindowsHotspot)
        // Apartment and office networks in other ranges are networks too.
        let wide = try XCTUnwrap(PCLinkNetwork(address: "10.20.30.40", netmask: "255.255.0.0"))
        XCTAssertEqual(wide.description, "10.20.0.0/16")
        XCTAssertTrue(wide.contains("10.20.99.1"))
        XCTAssertEqual(PCLinkNetwork(address: "100.64.3.9", prefix: 10)?.description, "100.64.0.0/10")
        XCTAssertEqual(PCLinkNetwork(address: "192.168.1.5", prefix: 32)?.description, "192.168.1.5/32")
        // Windows's mobile hotspot.
        let hotspot = try XCTUnwrap(PCLinkNetwork(address: "192.168.137.57", netmask: "255.255.255.0"))
        XCTAssertTrue(hotspot.isWindowsHotspot)
        XCTAssertTrue(hotspot.contains(PCLink.hotspotAddress))
        XCTAssertFalse(PCLinkNetwork(address: "192.168.136.5", prefix: 23)!.isWindowsHotspot, "a wider network is not the hotspot")
        // Not addresses or masks.
        XCTAssertNil(PCLinkNetwork(address: "192.168.1", netmask: "255.255.255.0"))
        XCTAssertNil(PCLinkNetwork(address: "192.168.1.256", netmask: "255.255.255.0"))
        XCTAssertNil(PCLinkNetwork(address: "192.168.1.1", netmask: "255.0.255.0"), "a mask with holes")
        XCTAssertNil(PCLinkNetwork(address: "192.168.1.1", netmask: "0.0.0.0"))
        XCTAssertNil(PCLinkNetwork(address: "192.168.1.1", prefix: 0))
        XCTAssertNil(PCLinkNetwork("192.168.1.0"))
        XCTAssertNil(PCLinkNetwork.value("１.２.３.４"))
        XCTAssertNil(PCLinkNetwork.value("1.2.3.4.5"))
        XCTAssertNil(PCLinkNetwork.value("01234.1.1.1"))
    }

    func testProblemsSayOnlyWhatTheFactsShow() {
        let home = PCLinkNetwork("192.168.1.0/24"), office = PCLinkNetwork("10.0.0.0/16")
        let hotspot = PCLinkNetwork("192.168.137.0/24")
        typealias Facts = PCLinkProblem.Facts
        // iOS's permission first: without it nothing else can be seen.
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(localNetworkDenied: true, onLocalNetwork: true, pcAnnounced: true)),
                       .localNetworkOff)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: false, lastNetwork: home)), .noNetwork)
        // Announced here but silent: the PC is on this network.
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: office, lastNetwork: home,
                                                    pcAnnounced: true)), .pcSilent)
        // Through the hotspot last time, elsewhere now.
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: home, lastNetwork: hotspot)),
                       .hotspotElsewhere)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: office, lastNetwork: home)),
                       .otherNetwork)
        // The same network, or nothing known: what to check, no verdict.
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: home, lastNetwork: home)), .notFound)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: hotspot, lastNetwork: hotspot)),
                       .notFound)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts()), .notFound)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: home)), .notFound)
        // Registering from a QR code: the PC is running and gave its addresses.
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: home,
                                                    pcAddresses: ["10.0.0.9", "192.168.1.10"])), .pcSilent)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, phoneNetwork: home,
                                                    pcAddresses: ["10.0.0.9", "192.168.137.1"])), .otherNetwork)
        XCTAssertEqual(PCLinkProblem.diagnose(Facts(onLocalNetwork: true, pcAddresses: ["192.168.1.10"])), .notFound,
                       "without the iPhone's own network, no verdict")
    }

    func testModelNamesWithoutLatest() {
        XCTAssertEqual(PCModel(name: "gemma3:latest").shortName, "gemma3")
        XCTAssertEqual(PCModel(name: "gemma3:4b").shortName, "gemma3:4b")
        XCTAssertEqual(PCChatTarget(pcID: "a", pcName: "PC", model: "qwen3:latest").shortModel, "qwen3")
    }

    func testReplyLinesAreRead() {
        XCTAssertEqual(PCChatEvent(line: #"{"type":"started","model":"gemma3:4b"}"#), .started(model: "gemma3:4b"))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"delta","content":"こん","thinking":""}"#), .delta(content: "こん", thinking: ""))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"waiting","stage":"starting"}"#), .waiting(stage: "starting"))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"waiting"}"#), .waiting(stage: nil))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"done","stats":{"outputTokens":12,"evalMs":340}}"#),
                       .done(outputTokens: 12, evalMilliseconds: 340))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"failed","error":{"kind":"outOfMemory","detail":"x"}}"#),
                       .failed(kind: "outOfMemory", detail: "x"))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"stopped"}"#), .stopped)
        XCTAssertNil(PCChatEvent(line: ""))
        XCTAssertNil(PCChatEvent(line: "not json"))
        XCTAssertNil(PCChatEvent(line: #"{"type":"other"}"#))
    }

    private func exchange(_ question: String, _ answer: String, state: ReplyState = .complete,
                          attachments: [ChatAttachment] = []) -> [ChatMessage] {
        [ChatMessage(role: .user, text: question, attachments: attachments),
         ChatMessage(role: .assistant, text: answer, state: state)]
    }

    func testContextSendsCompleteTextExchangesAndTheQuestion() {
        let photo = ChatAttachment(kind: .image, name: "写真.jpg", storedName: "p.jpg")
        let history = exchange("一", "いち") + exchange("写真", "見えます", attachments: [photo])
            + exchange("二", "に", state: .failed) + exchange("三", "", state: .stopped) + exchange("四", "よん")
        let turns = PCContext.turns(history: history, question: "五")
        XCTAssertEqual(turns.map(\.role), ["user", "assistant", "user", "assistant", "user"])
        XCTAssertEqual(turns.map(\.content), ["一", "いち", "四", "よん", "五"])
    }

    func testContextKeepsTheNewestWithinItsBudget() {
        let long = String(repeating: "あ", count: 2_000)  // 6,000 bytes
        let history = (1...10).flatMap { exchange("問\($0)" + long, "答\($0)") }
        let turns = PCContext.turns(history: history, question: "最後", byteBudget: 20_000)
        XCTAssertEqual(turns.last?.content, "最後")
        XCTAssertEqual(turns.count, 7, "three exchanges fit 20,000 bytes")
        XCTAssertTrue(turns[0].content.hasPrefix("問8"))
        XCTAssertTrue(turns[4].content.hasPrefix("問10"))
        let few = PCContext.turns(history: history.map { var m = $0; m.text = String(m.text.prefix(3)); return m },
                                  question: "最後", maxMessages: 5)
        XCTAssertEqual(few.count, 5)
        XCTAssertTrue(few.first?.content.hasPrefix("問9") == true)
    }

    func testChatThreadKeepsItsPCAndOlderArchivesHaveNone() throws {
        var thread = ChatThread(modelID: "gemma-4-e4b")
        thread.pc = PCChatTarget(pcID: "abc123", pcName: "PC", model: "gemma3:4b")
        let decoded = try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(thread))
        XCTAssertEqual(decoded.pc, thread.pc)
        var older = try JSONSerialization.jsonObject(with: JSONEncoder().encode(ChatThread(modelID: "gemma-4-e4b"))) as! [String: Any]
        older.removeValue(forKey: "pc")
        XCTAssertNil(try JSONDecoder().decode(ChatThread.self, from: JSONSerialization.data(withJSONObject: older)).pc)
    }
}
