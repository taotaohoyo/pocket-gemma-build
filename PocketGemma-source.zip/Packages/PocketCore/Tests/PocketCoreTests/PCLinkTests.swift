import XCTest
@testable import PocketCore

/// PCと接続 (1.1.0 (253)): what the iPhone computes and reads exactly as
/// Fielua for Windows does (src-tauri/src/link/proto.rs has the same
/// vectors), and which turns a PC reply is given.
final class PCLinkTests: XCTestCase {
    private func bytes(_ value: UInt8) -> Data { Data(repeating: value, count: 32) }

    func testNumbersMatchFieluaForWindows() {
        XCTAssertEqual(PCLink.commitment(serverNonce: bytes(0x33)), "jECjYSmMoCwY-ZaOXoNEcoJZc90BQT5g9lBnya8E2zA")
        XCTAssertEqual(PCLink.confirmationNumber(fingerprint: bytes(0x11), clientNonce: bytes(0x22), serverNonce: bytes(0x33)),
                       "613 534")
        XCTAssertEqual(PCLink.tokenHash("abc"), "ef14115dfc719ba573ae44169f8c69a7dccecac7e3f9dcc1c011371ecd660da6")
    }

    func testBase64URLRoundTripsAndRefusesOtherText() {
        let data = Data((0..<64).map { UInt8($0 * 4) })
        let text = PCLink.base64URL(data)
        XCTAssertFalse(text.contains("+") || text.contains("/") || text.contains("="))
        XCTAssertEqual(PCLink.data(base64URL: text), data)
        XCTAssertNil(PCLink.data(base64URL: ""))
        XCTAssertNil(PCLink.data(base64URL: "abc$"))
        XCTAssertNil(PCLink.data(base64URL: "あいう"))
    }

    func testNoncesAreRandom32Bytes() {
        let a = PCLink.randomNonce(), b = PCLink.randomNonce()
        XCTAssertEqual(a.count, 32)
        XCTAssertNotEqual(a, b)
    }

    func testCodeAndAddressAsTyped() {
        XCTAssertEqual(PCLink.normalizedCode(" 1234-5678 "), "12345678")
        XCTAssertEqual(PCLink.normalizedCode("１２３"), "", "full-width digits are not the code's")
        XCTAssertEqual(PCLink.address("192.168.1.10")?.host, "192.168.1.10")
        XCTAssertEqual(PCLink.address("192.168.1.10")?.port, PCLink.defaultPort)
        XCTAssertEqual(PCLink.address(" DESKTOP.local:47861 ")?.port, 47861)
        XCTAssertNil(PCLink.address(""))
        XCTAssertNil(PCLink.address("192.168.1.10:0"))
        XCTAssertNil(PCLink.address("192.168.1.10:99999"))
        XCTAssertNil(PCLink.address("http://192.168.1.10"))
        XCTAssertNil(PCLink.address("a:b:c"))
    }

    private var inviteText: String {
        let fp = PCLink.base64URL(bytes(0xAB)), secret = PCLink.base64URL(bytes(0xCD))
        return "fielua://pair?v=1&id=abc123&n=DESKTOP%201&h=192.168.1.10,10.0.0.5&p=47860&fp=\(fp)&s=\(secret)"
    }

    func testQRInvitationIsRead() throws {
        let invite = try XCTUnwrap(PCPairingInvite(inviteText))
        XCTAssertEqual(invite.pcID, "abc123")
        XCTAssertEqual(invite.pcName, "DESKTOP 1")
        XCTAssertEqual(invite.hosts, ["192.168.1.10", "10.0.0.5"])
        XCTAssertEqual(invite.port, 47860)
        XCTAssertEqual(invite.fingerprint, bytes(0xAB))
        XCTAssertEqual(PCLink.data(base64URL: invite.secret), bytes(0xCD))
    }

    func testOtherQRCodesAreRefused() {
        XCTAssertNil(PCPairingInvite("https://example.com"))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "v=1", with: "v=2")))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "fielua://pair", with: "fielua://other")))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "p=47860", with: "p=0")))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "id=abc123", with: "id=../x")))
        let shortFingerprint = PCLink.base64URL(Data(repeating: 1, count: 16))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: PCLink.base64URL(bytes(0xAB)), with: shortFingerprint)))
        XCTAssertNil(PCPairingInvite(inviteText.replacingOccurrences(of: "&s=", with: "&x=")))
    }

    func testInvitationWithoutANameOrAddresses() throws {
        let text = inviteText.replacingOccurrences(of: "n=DESKTOP%201&h=192.168.1.10,10.0.0.5&", with: "")
        let invite = try XCTUnwrap(PCPairingInvite(text))
        XCTAssertEqual(invite.pcName, "Windows PC")
        XCTAssertEqual(invite.hosts, [])
    }

    func testPairedPCTriesTheLastAddressFirstThenItsName() {
        var pc = PCPairedPC(pcID: "abc123", pcName: "PC", fingerprint: "x", hosts: ["192.168.1.10", "10.0.0.5"],
                            port: 47860, deviceID: "d", token: "t")
        XCTAssertEqual(pc.candidateHosts, ["192.168.1.10", "10.0.0.5", "fielua-abc123.local"])
        pc.answered(at: "10.0.0.5")
        XCTAssertEqual(pc.hosts, ["10.0.0.5", "192.168.1.10"])
        for index in 0..<10 { pc.answered(at: "192.168.2.\(index)") }
        XCTAssertEqual(pc.hosts.count, 6)
        XCTAssertEqual(pc.hosts.first, "192.168.2.9")
    }

    func testPairedPCRoundTripsThroughJSON() throws {
        let pc = PCPairedPC(pcID: "abc123", pcName: "PC", fingerprint: "fp", hosts: ["192.168.1.10"], port: 47861,
                            deviceID: "d", token: "t", pairedAt: Date(timeIntervalSince1970: 1_800_000_000))
        XCTAssertEqual(try JSONDecoder().decode(PCPairedPC.self, from: JSONEncoder().encode(pc)), pc)
    }

    func testModelNamesWithoutLatest() {
        XCTAssertEqual(PCModel(name: "gemma3:latest").shortName, "gemma3")
        XCTAssertEqual(PCModel(name: "gemma3:4b").shortName, "gemma3:4b")
        XCTAssertEqual(PCChatTarget(pcID: "a", pcName: "PC", model: "qwen3:latest").shortModel, "qwen3")
    }

    func testReplyLinesAreRead() {
        XCTAssertEqual(PCChatEvent(line: #"{"type":"started","model":"gemma3:4b"}"#), .started(model: "gemma3:4b"))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"delta","content":"こん","thinking":""}"#), .delta(content: "こん", thinking: ""))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"waiting","stage":"starting"}"#), .waiting(stage: "starting"))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"waiting"}"#), .waiting(stage: nil))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"done","stats":{"outputTokens":12,"evalMs":340}}"#),
                       .done(outputTokens: 12, evalMilliseconds: 340))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"failed","error":{"kind":"outOfMemory","detail":"x"}}"#),
                       .failed(kind: "outOfMemory", detail: "x"))
        XCTAssertEqual(PCChatEvent(line: #"{"type":"stopped"}"#), .stopped)
        XCTAssertNil(PCChatEvent(line: ""))
        XCTAssertNil(PCChatEvent(line: "not json"))
        XCTAssertNil(PCChatEvent(line: #"{"type":"other"}"#))
    }

    private func exchange(_ question: String, _ answer: String, state: ReplyState = .complete,
                          attachments: [ChatAttachment] = []) -> [ChatMessage] {
        [ChatMessage(role: .user, text: question, attachments: attachments),
         ChatMessage(role: .assistant, text: answer, state: state)]
    }

    func testContextSendsCompleteTextExchangesAndTheQuestion() {
        let photo = ChatAttachment(kind: .image, name: "写真.jpg", storedName: "p.jpg")
        let history = exchange("一", "いち") + exchange("写真", "見えます", attachments: [photo])
            + exchange("二", "に", state: .failed) + exchange("三", "", state: .stopped) + exchange("四", "よん")
        let turns = PCContext.turns(history: history, question: "五")
        XCTAssertEqual(turns.map(\.role), ["user", "assistant", "user", "assistant", "user"])
        XCTAssertEqual(turns.map(\.content), ["一", "いち", "四", "よん", "五"])
    }

    func testContextKeepsTheNewestWithinItsBudget() {
        let long = String(repeating: "あ", count: 2_000)  // 6,000 bytes
        let history = (1...10).flatMap { exchange("問\($0)" + long, "答\($0)") }
        let turns = PCContext.turns(history: history, question: "最後", byteBudget: 20_000)
        XCTAssertEqual(turns.last?.content, "最後")
        XCTAssertEqual(turns.count, 7, "three exchanges fit 20,000 bytes")
        XCTAssertTrue(turns[0].content.hasPrefix("問8"))
        XCTAssertTrue(turns[4].content.hasPrefix("問10"))
        let few = PCContext.turns(history: history.map { var m = $0; m.text = String(m.text.prefix(3)); return m },
                                  question: "最後", maxMessages: 5)
        XCTAssertEqual(few.count, 5)
        XCTAssertTrue(few.first?.content.hasPrefix("問9") == true)
    }

    func testChatThreadKeepsItsPCAndOlderArchivesHaveNone() throws {
        var thread = ChatThread(modelID: "gemma-4-e4b")
        thread.pc = PCChatTarget(pcID: "abc123", pcName: "PC", model: "gemma3:4b")
        let decoded = try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(thread))
        XCTAssertEqual(decoded.pc, thread.pc)
        var older = try JSONSerialization.jsonObject(with: JSONEncoder().encode(ChatThread(modelID: "gemma-4-e4b"))) as! [String: Any]
        older.removeValue(forKey: "pc")
        XCTAssertNil(try JSONDecoder().decode(ChatThread.self, from: JSONSerialization.data(withJSONObject: older)).pc)
    }
}
