import XCTest
@testable import PocketCore

/// Context management, phase 1 (1.1.0 (256), the user's directive of
/// 2026-11-06): Gemma's input measured closer to its tokens, the newest
/// exchange kept word for word when too long to give whole, the person's
/// earlier words kept in view, and the live conversation still reused.
final class ContextBudgetTests: XCTestCase {
    private func pair(_ question: String, _ reply: String) -> [ChatMessage] {
        [ChatMessage(role: .user, text: question), ChatMessage(role: .assistant, text: reply)]
    }

    // MARK: GemmaTokens

    /// Texts with their real count from Gemma's SentencePiece vocabulary
    /// (262,144 pieces, counted without BOS), and the estimate the local
    /// calibration's reference gives them.
    private static let counted: [(name: String, text: String, real: Int, estimate: Int)] = [
        ("ja-prose", "## 旅行の計画\n\n京都には3日間滞在します。1日目は清水寺と祇園を歩き、2日目は嵐山で竹林と渡月橋を見ます。**予算は5万円**で、移動はできるだけ電車にします。", 55, 70),
        ("ja-list", "- 着替え\n- 充電器\n- 常備薬\n- パスポート\n- 折りたたみ傘", 22, 30),
        ("numbers", "| 月 | 売上 | 前年比 |\n|---|---|---|\n| 1月 | 1,234,567 | 103.5% |\n| 2月 | 2,345,678 | 98.2% |\n| 3月 | 3,456,789 | 110.0% |", 89, 113),
        ("phone-dates", "母の電話番号は090-1234-5678、締め切りは2026年11月20日 17:30です。", 41, 44),
        ("english", "The Eiffel Tower was completed in 1889 for the World's Fair and is 330 metres tall.", 26, 35),
        ("swift", "func reversed(_ items: [Int]) -> [Int] {\n    var result: [Int] = []\n    for item in items.reversed() { result.append(item) }\n    return result\n}", 46, 72),
        ("emoji", "今日は最高でした🎉✨ ありがとう😊", 7, 17),
        ("korean", "내 고양이 이름은 나비야. 나비는 세 살이에요.", 16, 23),
        ("chinese", "我的生日是五月二十日，请记住。", 11, 15),
        ("fullwidth", "ＰｙｔｈｏｎでＡＰＩを呼ぶ（バージョン３．１２）", 20, 24),
        ("spaces", "a    b      c\t\td", 7, 10),
        ("half-width", "ｶﾞｰﾃﾞﾝﾊﾟｰﾃｨｰのﾁｹｯﾄは3,000円です。ﾃﾞｰﾀﾍﾞｰｽのｲﾝﾃﾞｯｸｽ", 42, 46),
        ("letter-run", "hahahahahahahahahahahahahahahahahahahahahahahahahahaha qwertyuiopasdfghjklzxcvbnm", 28, 36),
    ]

    func testGemmaEstimateIsNeverBelowTheRealCount() {
        for item in Self.counted {
            let estimate = GemmaTokens.estimate(item.text)
            XCTAssertEqual(estimate, item.estimate, item.name)
            XCTAssertGreaterThanOrEqual(estimate, item.real, "\(item.name): never fewer than Gemma's tokens")
        }
        XCTAssertEqual(GemmaTokens.estimate(""), 0)
    }

    func testDigitsAreCountedAsTokensUnlikeTheByteRule() {
        // Gemma splits numbers into digits: two bytes a token counted this
        // table at 0.77 of its tokens, which overfilled number-heavy chats.
        let table = Self.counted.first { $0.name == "numbers" }!
        XCTAssertLessThan(table.text.utf8.count / 2, table.real)
        XCTAssertGreaterThanOrEqual(ContextMeasure.gemma.tokens(table.text), table.real)
        // Japanese prose: the byte rule asked for far more room than it takes.
        let prose = Self.counted.first { $0.name == "ja-prose" }!
        XCTAssertGreaterThan(prose.text.utf8.count / 2, ContextMeasure.gemma.tokens(prose.text))
    }

    func testMeasureFollowsTheModel() {
        XCTAssertEqual(ContextMeasure.of(.e2b), .gemma)
        XCTAssertEqual(ContextMeasure.of(.e4b), .gemma)
        for model in ModelSpec.catalog where model.family != "Gemma" {
            XCTAssertEqual(ContextMeasure.of(model), .utf8, model.id)
        }
        let message = ChatMessage(role: .user, text: "こんにちは")
        XCTAssertEqual(ContextMeasure.utf8.cost(message, visualTokenBudget: 280, inputByteBudget: 6000), "こんにちは".utf8.count)
        XCTAssertEqual(ContextMeasure.gemma.cost(message, visualTokenBudget: 280, inputByteBudget: 6000),
                       2 * (GemmaTokens.estimate("こんにちは") + GemmaTokens.perTurn))
    }

    // MARK: ContextPlanner

    func testWholePairsAsBeforeWhenTheyFit() {
        let messages = pair("一つ目", "答え1") + pair("二つ目", "答え2") + pair("三つ目", "答え3")
        for budget in [0, 10, 25, 40, 60, 1000] {
            let plan = ContextPlanner.plan(messages, budget: budget, measure: .utf8, question: "質問")
            let before = HistoryBuilder.recentPairs(messages, byteBudget: budget)
            if !plan.excerpted { XCTAssertEqual(plan.turns.map(\.id), before.map(\.id), "budget \(budget)") }
            XCTAssertLessThanOrEqual(plan.cost, budget)
            XCTAssertEqual(plan.totalPairs, 3)
        }
    }

    func testInterruptedAndFailedRepliesAreLeftOutAsBefore() {
        var stopped = ChatMessage(role: .assistant, text: "途中まで")
        stopped.state = .stopped
        let messages = pair("一つ目", "答え1") + [ChatMessage(role: .user, text: "止めた質問"), stopped]
        let plan = ContextPlanner.plan(messages, budget: 10_000, measure: .gemma, question: "次")
        XCTAssertEqual(plan.turns.map(\.text), ["一つ目", "答え1"])
    }

    /// A long list as the newest reply: before, the history was empty and
    /// 「3番目をもっと詳しく」 had nothing to go on.
    private func longList() -> String {
        (1...60).map { "\($0). 観光地\($0)：京都の名所で、見どころは庭園と建築です。所要時間はおよそ\($0 % 3 + 1)時間。" }
            .joined(separator: "\n")
    }

    func testTheNewestLongReplyIsKeptAsAnExcerpt() {
        let list = longList()
        let messages = pair("前の話", "前の答え") + pair("京都の観光地を60個挙げて", list)
        let question = "観光地42の所要時間は？"
        let budget = 1_200
        XCTAssertTrue(HistoryBuilder.recentPairs(messages, byteBudget: budget).isEmpty, "before: nothing")
        let plan = ContextPlanner.plan(messages, budget: budget, measure: .gemma, question: question)
        XCTAssertTrue(plan.excerpted)
        XCTAssertEqual(plan.turns.count, 2)
        XCTAssertEqual(plan.turns[0].id, messages[2].id, "the excerpt keeps the messages' ids")
        XCTAssertEqual(plan.turns[1].id, messages[3].id)
        XCTAssertEqual(plan.turns[0].text, "京都の観光地を60個挙げて")
        let excerpt = plan.turns[1].text
        XCTAssertLessThanOrEqual(plan.cost, budget)
        XCTAssertTrue(excerpt.hasPrefix("1. 観光地1："), "its opening")
        XCTAssertTrue(excerpt.contains("60. 観光地60："), "its end")
        XCTAssertTrue(excerpt.contains("42. 観光地42："), "the line the question names")
        XCTAssertTrue(excerpt.contains("\n…\n"), "a gap is marked")
        XCTAssertTrue(HistoryExcerpt.isExcerpt(excerpt, of: list))
        // Only lines of the reply, whole.
        let lines = Set(list.components(separatedBy: "\n"))
        for line in excerpt.components(separatedBy: "\n") where line != HistoryExcerpt.gap {
            XCTAssertTrue(lines.contains(line), line)
        }
        XCTAssertEqual(plan.earlier.map(\.text), ["前の話"])
    }

    func testAnExcerptNeverCutsANumber() {
        let line = "合計金額は 1234567890123456789012345678901234567890 円で、内訳は別紙のとおりです"
        let text = HistoryExcerpt.shortened(line, question: "合計", budget: 40, measure: .utf8)
        XCTAssertTrue(text.hasSuffix(" …"), text)
        let head = String(text.dropLast(2))
        XCTAssertTrue(line.hasPrefix(head))
        XCTAssertFalse(head.last?.isNumber ?? false, "cut before the number, not inside it: \(head)")
        XCTAssertTrue(HistoryExcerpt.isExcerpt(text, of: line))
    }

    func testNoExcerptWhenTooLittleRoom() {
        let messages = pair("京都の観光地を60個挙げて", longList())
        let plan = ContextPlanner.plan(messages, budget: ContextPlanner.minimumExcerpt / 2, measure: .gemma, question: "次")
        XCTAssertTrue(plan.turns.isEmpty)
        XCTAssertFalse(plan.excerpted)
        XCTAssertEqual(plan.earlier.count, 1)
    }

    func testOlderPairsLeftOutAreListedAsEarlier() {
        let messages = pair("予算は5万円で京都に行きたい", String(repeating: "京都の案です。", count: 40))
            + pair("2泊3日にしたい", String(repeating: "日程の案です。", count: 40))
            + pair("ホテルは駅の近く", "わかりました。")
        let plan = ContextPlanner.plan(messages, budget: 80, measure: .gemma, question: "まとめて")
        XCTAssertEqual(plan.turns.map(\.text), ["ホテルは駅の近く", "わかりました。"])
        XCTAssertEqual(plan.earlier.map(\.text), ["予算は5万円で京都に行きたい", "2泊3日にしたい"])
    }

    func testTrimmedDropsTheOldestAndKeepsTheNewest() {
        let turns = pair("一", String(repeating: "あ", count: 100)) + pair("二", String(repeating: "い", count: 100))
            + pair("三", String(repeating: "う", count: 100))
        let (kept, earlier) = ContextPlanner.trimmed(turns, earlier: [ChatMessage(role: .user, text: "零")], toBudget: 150,
                                                     measure: .gemma)
        XCTAssertEqual(kept.map(\.text).first, "三")
        XCTAssertEqual(kept.count, 2, "the newest stays whatever its size")
        XCTAssertEqual(earlier.map(\.text), ["零", "一", "二"])
        let (all, none) = ContextPlanner.trimmed(turns, earlier: [], toBudget: 100_000, measure: .gemma)
        XCTAssertEqual(all.map(\.id), turns.map(\.id))
        XCTAssertTrue(none.isEmpty)
    }

    // MARK: ConversationContext

    func testTheLiveConversationGoesOnWithAnExcerptOfWhatItHolds() {
        let thread = UUID()
        let list = longList()
        var context = ConversationContext()
        context.completeTurn(threadID: thread, history: [], prompt: "京都の観光地を60個挙げて", reply: list, tokens: 1_500)
        let saved = pair("京都の観光地を60個挙げて", list)
        let plan = ContextPlanner.plan(saved, budget: 1_200, measure: .gemma, question: "観光地42の所要時間は？")
        XCTAssertTrue(plan.excerpted)
        XCTAssertTrue(context.canReuse(threadID: thread, history: plan.turns), "the conversation holds the whole reply")
        var altered = plan.turns
        altered[1].text = "1. 観光地1：違う内容\n…"
        XCTAssertFalse(context.canReuse(threadID: thread, history: altered))
        XCTAssertFalse(context.canReuse(threadID: UUID(), history: plan.turns))
        // Released with the model, it comes back whole.
        let held = context.heldHistory(threadID: thread, history: Array(plan.turns.suffix(0)), tokenLimit: 3_000)
        XCTAssertEqual(held?.map(\.text), ["京都の観光地を60個挙げて", list])
        let heldAgain = context.heldHistory(threadID: thread, history: [], tokenLimit: 1_000)
        XCTAssertNil(heldAgain, "more tokens than the room")
    }

    func testAConversationSetUpWithAnExcerptIsNotTakenForTheWholeReply() {
        let thread = UUID()
        let list = longList()
        let plan = ContextPlanner.plan(pair("京都の観光地を60個挙げて", list), budget: 1_200, measure: .gemma, question: "観光地42")
        var context = ConversationContext()
        context.completeTurn(threadID: thread, history: plan.turns, prompt: "観光地42", reply: "2時間です。", tokens: 900)
        let whole = pair("京都の観光地を60個挙げて", list) + pair("観光地42", "2時間です。")
        XCTAssertFalse(context.canReuse(threadID: thread, history: whole), "it holds only the excerpt")
        XCTAssertTrue(context.canReuse(threadID: thread, history: Array(whole.suffix(2))))
    }

    // MARK: EarlierNote

    func testEarlierNoteQuotesThePersonsWordsAndSkipsThanks() {
        let earlier = [ChatMessage(role: .user, text: "予算は5万円で、2026年3月14日から京都へ2泊したい"),
                       ChatMessage(role: .user, text: "ありがとう"),
                       ChatMessage(role: .user, text: "続けて"),
                       ChatMessage(role: .user, text: "同行者は母で、足が悪いので階段の少ない所がいい")]
        let note = EarlierNote.build(earlier, question: "おすすめのホテルは？", budget: 900, measure: .gemma, tag: "ab12cd34")
        XCTAssertNotNil(note)
        guard let note else { return }
        XCTAssertEqual(note.count, 2)
        XCTAssertTrue(note.text.contains("- 予算は5万円で、2026年3月14日から京都へ2泊したい\n"))
        XCTAssertTrue(note.text.contains("- 同行者は母で、足が悪いので階段の少ない所がいい\n"))
        XCTAssertFalse(note.text.contains("ありがとう"))
        XCTAssertFalse(note.text.contains("続けて"))
        XCTAssertTrue(note.text.contains("[Earlierab12cd34 begins]"))
        XCTAssertTrue(note.text.contains("[Earlierab12cd34 ends]"))
        XCTAssertLessThan(note.text.range(of: "予算")!.lowerBound, note.text.range(of: "同行者")!.lowerBound, "oldest first")
        XCTAssertLessThanOrEqual(ContextMeasure.gemma.cost(note.text), 900)
    }

    func testEarlierNoteKeepsTheFirstAndTheLatestWhenTight() {
        let earlier = (1...12).map { ChatMessage(role: .user, text: "条件\($0)：会場は第\($0)会議室、参加者は\($0 * 10)人です") }
        let note = EarlierNote.build(earlier, question: "会場はどこ？", budget: 420, measure: .gemma, tag: "t")
        XCTAssertNotNil(note)
        guard let note else { return }
        XCTAssertLessThan(note.count, 12)
        XCTAssertTrue(note.text.contains("条件1："), "the chat's first message")
        XCTAssertTrue(note.text.contains("条件12："), "its latest")
        XCTAssertLessThanOrEqual(ContextMeasure.gemma.cost(note.text), 420)
    }

    func testEarlierNoteCutsALongMessageOutsideNumbersAndLeavesOutNotes() {
        let long = "請求番号は 98765432109876543210 です。" + String(repeating: "詳しい事情を説明します。", count: 30)
        let note = EarlierNote.build([ChatMessage(role: .user, text: long + ModelAttachmentPolicy.earlierAttachmentsNote)],
                                     question: "請求番号は？", budget: 900, measure: .gemma, tag: "x")
        XCTAssertNotNil(note)
        XCTAssertTrue(note?.text.contains("98765432109876543210") ?? false, "the number whole")
        XCTAssertFalse(note?.text.contains("Earlier attachments") ?? true)
        XCTAssertTrue(note?.text.contains(" …\n") ?? false)
        XCTAssertNil(EarlierNote.build([ChatMessage(role: .user, text: "ありがとう")], question: "次", budget: 900, measure: .gemma))
        XCTAssertNil(EarlierNote.build([ChatMessage(role: .user, text: long)], question: "次", budget: 60, measure: .gemma))
    }

    func testEarlierNoteShareStaysSmall() {
        XCTAssertEqual(EarlierNote.share(inputByteBudget: 6_044), 755)
        XCTAssertEqual(EarlierNote.share(inputByteBudget: 16_000), 900)
        XCTAssertEqual(EarlierNote.share(inputByteBudget: 0), 0)
    }

    // MARK: Cuts, overflow, diagnostics

    func testCutAtBoundaryNeverEndsInsideANumberOrAWord() {
        XCTAssertEqual(SmartMemoryNote.cutAtBoundary("価格は 123456 円です", byteLimit: 14), "価格は")
        XCTAssertEqual(SmartMemoryNote.cutAtBoundary("call items.reverse() now", byteLimit: 12), "call")
        XCTAssertEqual(SmartMemoryNote.cutAtBoundary("短い", byteLimit: 100), "短い")
        XCTAssertEqual(SmartMemoryNote.cutAtBoundary("あいうえお", byteLimit: 7), "あい")
    }

    func testContextOverflowMatchesTheRuntimesRefusal() {
        struct Refusal: Error, CustomStringConvertible {
            let description: String
        }
        XCTAssertTrue(ContextOverflow.matches(Refusal(description:
            "invalidResponse(\"INVALID_ARGUMENT: Input token ids are too long. Exceeding the maximum number of tokens allowed: 4120 >= 4096\")")))
        XCTAssertFalse(ContextOverflow.matches(Refusal(description: "failedToCreateConversation(\"model missing\")")))
        XCTAssertFalse(ContextOverflow.matches(CancellationError()))
    }

    func testContextFillSaysCountsOnly() {
        var fill = ContextFill(turns: 3, pairs: 8, estimate: 2_410, earlier: 2, filled: true, held: false)
        fill.tokens = 2_801
        fill.overflowRetries = 1
        XCTAssertEqual(fill.summary,
                       "会話を作り直した（満杯のため） · 履歴 3組/8組 · 入力の見積り 2410トークン · 実測 2801トークン（返事込み） · 以前の発言 2件 · 入りきらず減らした 1回")
    }

    // MARK: Smart Memory's room in Gemma's measure

    func testSmartMemoryNoteFitsTheRoomInGemmasMeasure() {
        var thread = ChatThread(modelID: ModelSpec.e2b.id)
        let digits = (0..<40).map { _ in String(Int.random(in: 1_000_000...9_999_999)) }.joined(separator: ", ")
        thread.messages = pair("口座番号の一覧を覚えておいて", digits)
        var index = SmartMemoryIndex()
        index.sync([thread])
        let hits = index.search("口座番号の一覧をもう一度")
        XCTAssertFalse(hits.isEmpty)
        let room = 800
        let note = SmartMemoryFit.fitting(hits, threads: [thread], question: "口座番号の一覧をもう一度", room: room, measure: .gemma)
        if let note { XCTAssertLessThanOrEqual(ContextMeasure.gemma.cost(note.text), room) }
        // In bytes, as before.
        let bytes = SmartMemoryFit.fitting(hits, threads: [thread], question: "口座番号の一覧をもう一度", room: room, measure: .utf8)
        XCTAssertNotNil(bytes)
        XCTAssertLessThanOrEqual(bytes?.text.utf8.count ?? .max, room)
    }

    func testSmartMemoryPlanInGemmasMeasureKeepsMoreTurns() {
        let history = (1...6).flatMap { pair("質問\($0)：京都の旅行の計画について", String(repeating: "京都の旅行の計画を説明します。", count: 12)) }
        let bytes = SmartMemoryFit.plan(history: history, cost: 200, inputByteBudget: 6_044)
        let gemma = SmartMemoryFit.plan(history: history, cost: 200, inputByteBudget: 6_044, measure: .gemma)
        XCTAssertGreaterThanOrEqual(gemma.history.count, bytes.history.count)
        XCTAssertGreaterThanOrEqual(gemma.memoryBytes, SmartMemory.minimumBytes)
    }
}
