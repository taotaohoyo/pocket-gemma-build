import XCTest
@testable import PocketCore

final class PocketCoreTests: XCTestCase {
    func testExplicitVisionBudgetChangeRebuildsEncoderAndUsesSeparateCache() {
        for spec in [ModelSpec.e2b, .e4b] {
            var settings = GenerationSettings()
            let initial = InferenceEnginePlan(model: spec, settings: settings, needsVision: true)
            settings.visualTokenBudget = 70
            let retry = InferenceEnginePlan(model: spec, settings: settings, needsVision: true)
            XCTAssertNotEqual(initial, retry)
            XCTAssertNotEqual(initial.cacheComponent, retry.cacheComponent)
            XCTAssertEqual(retry.visualTokenBudget, 70)
            XCTAssertEqual(retry.visionBackend, .cpu)
        }
    }
    func testEngineIdentityIncludesBackendWeightsContextAndSpeculation() {
        let settings = GenerationSettings()
        let base = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true)
        var context = settings; context.maxTokens = 2048
        var speculative = settings; speculative.enableSpeculativeDecoding = true
        let alternatives = [
            InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true),
            InferenceEnginePlan(model: .e2b, settings: context, needsVision: true),
            InferenceEnginePlan(model: .e2b, settings: speculative, needsVision: true),
            InferenceEnginePlan(model: .e2b, settings: settings, needsVision: false),
            InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true, visionBackend: .gpu)
        ]
        for plan in alternatives {
            XCTAssertNotEqual(base, plan); XCTAssertNotEqual(base.cacheComponent, plan.cacheComponent)
        }
        var sampling = settings; sampling.topK = 20; sampling.temperature = 0.2
        XCTAssertEqual(base, InferenceEnginePlan(model: .e2b, settings: sampling, needsVision: true))
    }
    func testTextEngineDoesNotInheritPriorVisionLimit() {
        var settings = GenerationSettings(); settings.backend = .cpu
        settings.visualTokenBudget = 70
        let plan = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: false)
        XCTAssertNil(plan.visualTokenBudget); XCTAssertNil(plan.visionBackend)
        XCTAssertEqual(plan.backend, .cpu)
    }
    func testImagesRespectCPUChoiceAndPermitIndependentEncoder() {
        var settings = GenerationSettings(); settings.backend = .cpu
        let allCPU = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true)
        XCTAssertEqual(allCPU.backend, .cpu); XCTAssertEqual(allCPU.visionBackend, .cpu)
        let mixed = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true, visionBackend: .gpu)
        XCTAssertEqual(mixed.backend, .cpu); XCTAssertEqual(mixed.visionBackend, .gpu)
        XCTAssertNotEqual(allCPU.cacheComponent, mixed.cacheComponent)
    }
    func testPinnedGemmaVisionLimitsRejectAbsentSignatures() {
        for model in [ModelSpec.e2b, .e4b] {
            var settings = GenerationSettings(); settings.visualTokenBudget = 1120
            XCTAssertEqual(settings.normalized(for: model).visualTokenBudget, 280)
            settings.visualTokenBudget = 140
            XCTAssertEqual(settings.normalized(for: model).visualTokenBudget, 140)
        }
    }
    func testNativeErrorCategoriesDoNotTreatAllFailuresAsMemoryPressure() {
        XCTAssertEqual(NativeFailureKind(description: "Failed to modify graph with delegate"), .delegateSetup)
        XCTAssertEqual(NativeFailureKind(description: "Failed to allocate tensors"), .tensorAllocation)
        XCTAssertEqual(NativeFailureKind(description: "Failed to decode image"), .imageDecode)
        XCTAssertEqual(NativeFailureKind(description: "INTERNAL unknown failure"), .other)
    }
    func testBottomGeometryAndIdleReturnClearStaleJumpButton() {
        XCTAssertEqual(ChatScrollGeometry.distanceFromBottom(contentHeight: 1800, visibleBottom: 1800), 0)
        XCTAssertEqual(ChatScrollGeometry.distanceFromBottom(contentHeight: 300, visibleBottom: 800), 0)
        XCTAssertEqual(ChatScrollGeometry.distanceFromBottom(contentHeight: 1800, visibleBottom: 1200), 600)
        // Regression: end at 830pt is hidden behind an input bar at 497pt,
        // even though the full-screen scroll rectangle reaches 874pt.
        let obscured = ChatScrollGeometry.distanceFromBottom(contentHeight: 830, visibleBottom: 497)
        XCTAssertEqual(obscured, 333)
        var scroll = ChatScrollPolicy()
        scroll.setUserScrolling(true); scroll.observe(distanceFromBottom: obscured); scroll.setUserScrolling(false)
        XCTAssertTrue(scroll.showsJumpButton)
        scroll.observe(distanceFromBottom: 0) // keyboard closes; no drag callback
        XCTAssertFalse(scroll.showsJumpButton)
        XCTAssertTrue(scroll.shouldFollowStream)
    }

    func testRecommendationsScaleToPhoneAndPadWithoutHidingAlternatives() {
        let gb: UInt64 = 1_000_000_000
        let small = DeviceCapacity(memoryBytes: 4 * gb, freeDiskBytes: 20_000_000_000, processorCount: 6, isPad: false)
        let medium = DeviceCapacity(memoryBytes: 8 * gb, freeDiskBytes: 20_000_000_000, processorCount: 6, isPad: false)
        let large = DeviceCapacity(memoryBytes: 16 * gb, freeDiskBytes: 20_000_000_000, processorCount: 8, isPad: true)
        XCTAssertEqual(ModelRecommendation.recommended(for: small)?.id, ModelSpec.qwen3.id)
        XCTAssertEqual(ModelRecommendation.recommended(for: medium)?.id, ModelSpec.e2b.id)
        XCTAssertEqual(ModelRecommendation.recommended(for: large)?.id, ModelSpec.e4b.id)
        XCTAssertTrue(ModelRecommendation.fit(.e4b, device: small).memoryIsTight)
        XCTAssertLessThan(ModelRecommendation.fit(.qwen3, device: medium).load, ModelRecommendation.fit(.e4b, device: medium).load)
        XCTAssertGreaterThan(ModelRecommendation.fit(.qwen3, device: medium).responsiveness, ModelRecommendation.fit(.e4b, device: medium).responsiveness)
        XCTAssertEqual(ModelSpec.catalog.count, 4)
    }

    func testAutomaticRecommendationUsesAppMemoryLimitAndInstalledDownloads() {
        let device = DeviceCapacity(memoryBytes: 12_000_000_000, freeDiskBytes: 900_000_000,
                                    processorCount: 6, isPad: false, availableMemoryBytes: 2_000_000_000)
        XCTAssertNil(ModelRecommendation.recommended(for: device))
        XCTAssertEqual(ModelRecommendation.recommended(for: device, installedIDs: [ModelSpec.qwen3.id])?.id, ModelSpec.qwen3.id)
        XCTAssertTrue(ModelRecommendation.fit(.e4b, device: device, isInstalled: true).memoryIsTight)
        let roomy = DeviceCapacity(memoryBytes: 32_000_000_000, freeDiskBytes: 30_000_000_000, processorCount: 8, isPad: true)
        XCTAssertEqual(ModelRecommendation.recommended(for: roomy)?.id, ModelSpec.e4b.id)
        XCTAssertNil(ModelSpec.find("gemma-4-12b"), "12B was removed; old threads fall back to E4B")
    }

    func testBackupMergeIsAdditiveIdempotentAndRecoversInterruptedReply() {
        var local = ChatThread(modelID: ModelSpec.e4b.id)
        local.messages = [ChatMessage(role: .user, text: "local"), ChatMessage(role: .assistant, text: "a longer complete reply")]
        var older = local
        older.messages[1].text = "a"; older.updatedAt = local.updatedAt.addingTimeInterval(-10)
        var remoteOnly = ChatThread(modelID: ModelSpec.e2b.id)
        remoteOnly.messages = [ChatMessage(role: .assistant, text: "partial", state: .generating)]
        let merged = HistoryMerge.merge(local: [local], incoming: [older, remoteOnly])
        XCTAssertEqual(merged.count, 2)
        XCTAssertEqual(merged.first { $0.id == local.id }?.messages.last?.text, "a longer complete reply")
        XCTAssertEqual(merged.first { $0.id == remoteOnly.id }?.messages.last?.state, .stopped)
        XCTAssertEqual(HistoryMerge.merge(local: merged, incoming: [older, remoteOnly]), merged)
    }

    func testNewerBackupAddsTurnsWithoutReplacingLongerLocalReply() {
        var local = ChatThread()
        local.messages = [ChatMessage(role: .user, text: "first"), ChatMessage(role: .assistant, text: "full reply")]
        var remote = local
        remote.messages[1].text = "cut"; remote.updatedAt = local.updatedAt.addingTimeInterval(20)
        remote.messages.append(ChatMessage(role: .user, text: "second"))
        XCTAssertEqual(HistoryMerge.merge(local: [local], incoming: [remote])[0].messages.map(\.text), ["first", "full reply", "second"])
    }

    func testBackupRejectsAttachmentTraversalBeforeCopyingFiles() {
        var thread = ChatThread()
        thread.messages = [ChatMessage(role: .user, text: "file", attachments: [ChatAttachment(kind: .file, name: "ok.txt", storedName: "../private.txt")])]
        XCTAssertThrowsError(try HistoryMerge.attachmentNames(in: [thread]))
        thread.messages[0].attachments = [ChatAttachment(kind: .image, name: "image", storedName: "original.png", thumbnailName: "small.jpg", imageNames: ["small.jpg"])]
        XCTAssertEqual(try HistoryMerge.attachmentNames(in: [thread]), ["original.png", "small.jpg"])
    }

    func testInsufficientDiskAndUnknownCapacityDoNotRecommendLargeDownload() {
        let noSpace = DeviceCapacity(memoryBytes: 16_000_000_000, freeDiskBytes: 500_000_000, processorCount: 8, isPad: true)
        XCTAssertNil(ModelRecommendation.recommended(for: noSpace))
        XCTAssertFalse(ModelRecommendation.fit(.qwen3, device: noSpace).hasDiskSpace)
        let unknown = DeviceCapacity(memoryBytes: 0, freeDiskBytes: 20_000_000_000, processorCount: 0, isPad: false)
        for spec in ModelSpec.catalog {
            let fit = ModelRecommendation.fit(spec, device: unknown)
            XCTAssertTrue(fit.load.isFinite); XCTAssertTrue(fit.responsiveness.isFinite)
            XCTAssertTrue((0...1).contains(fit.load)); XCTAssertTrue((0...1).contains(fit.responsiveness))
        }
        XCTAssertEqual(ModelRecommendation.recommended(for: unknown)?.id, ModelSpec.qwen3.id)
    }
    func testSmallContextRemainsUsableAndVisualQualityReservesInputSpace() {
        var small = GenerationSettings(); small.maxTokens = 1024
        small = small.normalized(for: .e4b)
        XCTAssertGreaterThan(small.inputByteBudget, 0)
        let video = ChatAttachment(kind: .video, name: "v.mp4", storedName: "v.mp4", imageNames: ["a.jpg", "b.jpg", "c.jpg"])
        let settings = GenerationSettings()
        XCTAssertLessThan(video.contextByteCost(visualTokenBudget: 280), settings.inputByteBudget)
        XCTAssertGreaterThan(video.contextByteCost(visualTokenBudget: 1120), settings.inputByteBudget)
        let history = [ChatMessage(role: .user, text: "u", attachments: [video]), ChatMessage(role: .assistant, text: "a")]
        XCTAssertEqual(HistoryBuilder.recentPairs(history, byteBudget: settings.inputByteBudget).count, 2)
        XCTAssertTrue(HistoryBuilder.recentPairs(history, byteBudget: settings.inputByteBudget, visualTokenBudget: 1120).isEmpty)
    }
    func testLegacyMessageWithoutAttachmentsStillDecodes() throws {
        let old = ChatMessage(role: .user, text: "保存済み")
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(old)) as? [String: Any])
        object.removeValue(forKey: "attachments")
        let decoded = try JSONDecoder().decode(ChatMessage.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(decoded.text, old.text)
        XCTAssertEqual(decoded.id, old.id)
        XCTAssertTrue(decoded.media.isEmpty)
    }

    func testMediaArchiveKeepsFilesFramesAndExtractedText() throws {
        let image = ChatAttachment(kind: .image, name: "写真.png", storedName: "original.png", thumbnailName: "small.jpg", imageNames: ["small.jpg"])
        let video = ChatAttachment(kind: .video, name: "movie.mp4", storedName: "original.mp4", imageNames: ["first.jpg", "middle.jpg", "last.jpg"], byteCount: 4000, duration: 2.5)
        let file = ChatAttachment(kind: .file, name: "本文.pdf", storedName: "original.pdf", extractedText: "本文と絵文字😊")
        let message = ChatMessage(role: .user, text: "添付内容", attachments: [image, video, file])
        let decoded = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(message))
        XCTAssertEqual(decoded.media, [image, video, file])
        XCTAssertEqual(decoded, message)
    }

    func testAttachmentFileNamesCannotEscapeStorageDirectory() {
        for name in ["", ".", "..", "../secret", "folder/file", "folder\\file", "C:secret", "bad\0name"] {
            XCTAssertFalse(ChatAttachment.isSafeFileName(name), name)
        }
        XCTAssertTrue(ChatAttachment.isSafeFileName("ABC-frame-0.jpg"))
        XCTAssertTrue(ChatAttachment.isSafeFileName("日本語.pdf"))
    }

    func testMediaIsCountedInHistoryBudgetWithoutSplittingPairs() {
        let file = ChatAttachment(kind: .file, name: "x.txt", storedName: "x.txt", extractedText: "日本語")
        let messages = [ChatMessage(role: .user, text: "u", attachments: [file]), ChatMessage(role: .assistant, text: "a")]
        let cost = file.contextByteCost + 2
        XCTAssertTrue(HistoryBuilder.recentPairs(messages, byteBudget: cost - 1).isEmpty)
        XCTAssertEqual(HistoryBuilder.recentPairs(messages, byteBudget: cost), messages)
    }

    func testChangedMediaInvalidatesNativeConversationReuse() {
        let id = UUID()
        let file = ChatAttachment(kind: .file, name: "x.txt", storedName: "x.txt", extractedText: "first")
        var context = ConversationContext()
        context.completeTurn(threadID: id, history: [], prompt: "u", reply: "a", attachments: [file])
        var history = [ChatMessage(role: .user, text: "u", attachments: [file]), ChatMessage(role: .assistant, text: "a")]
        XCTAssertTrue(context.canReuse(threadID: id, history: history))
        history[0].attachments?[0].extractedText = "changed"
        XCTAssertFalse(context.canReuse(threadID: id, history: history))
    }

    func testSettingsClampMemoryLimitsAndUnsupportedOptions() {
        var settings = GenerationSettings()
        settings.maxTokens = Int.max; settings.maxOutputTokens = Int.max
        settings.topK = -1; settings.topP = .nan; settings.temperature = .infinity
        settings.visualTokenBudget = 999; settings.enableSpeculativeDecoding = true
        let qwen = settings.normalized(for: .qwen3)
        XCTAssertEqual(qwen.maxTokens, 4096); XCTAssertEqual(qwen.maxOutputTokens, 2048)
        XCTAssertEqual(qwen.topK, 1); XCTAssertEqual(qwen.topP, 0.95); XCTAssertEqual(qwen.temperature, 0.7)
        XCTAssertEqual(qwen.visualTokenBudget, 280); XCTAssertFalse(qwen.enableSpeculativeDecoding)
        settings.maxTokens = -100; settings.maxOutputTokens = -1
        let gemma = settings.normalized(for: .e4b)
        XCTAssertEqual(gemma.maxTokens, 1024); XCTAssertEqual(gemma.maxOutputTokens, 128)
        XCTAssertTrue(gemma.enableSpeculativeDecoding)
        settings.maxTokens = 8192; settings.enableThinking = true
        XCTAssertEqual(settings.normalized(for: .qwen25).maxTokens, 4096)
        XCTAssertFalse(settings.normalized(for: .qwen25).enableThinking)
    }

    func testSystemPromptLimitsKeepUnicodeGraphemesIntactAndSettingsRoundTrip() throws {
        let emoji = "👨‍👩‍👧‍👦"
        XCTAssertEqual(GenerationSettings.prefix("あ" + emoji + "z", byteLimit: 3 + emoji.utf8.count), "あ" + emoji)
        XCTAssertEqual(GenerationSettings.prefix(emoji, byteLimit: emoji.utf8.count - 1), "")
        var settings = GenerationSettings()
        settings.backend = .cpu; settings.enableThinking = true; settings.temperature = 1.2
        settings.systemPrompt = String(repeating: "日本語😊", count: 1000)
        let normalized = settings.normalized(for: .e4b)
        XCTAssertLessThanOrEqual(normalized.systemPrompt.utf8.count, 4000)
        XCTAssertEqual(try JSONDecoder().decode(GenerationSettings.self, from: JSONEncoder().encode(normalized)), normalized)
    }

    func testOldArchiveWithoutModelIDKeepsMessagesAndDefaultsToGemma() throws {
        var original = ChatThread()
        original.messages = [ChatMessage(role: .user, text: "保存済みの会話")]
        var json = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(original)) as? [String: Any])
        json.removeValue(forKey: "modelID")
        let restored = try JSONDecoder().decode(ChatThread.self, from: JSONSerialization.data(withJSONObject: json))
        XCTAssertNil(restored.modelID)
        XCTAssertEqual(restored.messages, original.messages)
        XCTAssertEqual(restored.id, original.id)
        let qwen = ChatThread(modelID: ModelSpec.qwen3.id)
        XCTAssertEqual(try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(qwen)).modelID, qwen.modelID)
    }

    func testInstallingSecondModelKeepsLegacyFileAndReceipt() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let library = ModelLibrary(directory: directory)
        let hash = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        let old = ModelSpec(fileName: ModelSpec.e4b.fileName, byteCount: 3, sha256: hash,
            downloadURL: ModelSpec.e4b.downloadURL, id: ModelSpec.e4b.id)
        let new = ModelSpec(fileName: ModelSpec.qwen3.fileName, byteCount: 3, sha256: hash,
            downloadURL: ModelSpec.qwen3.downloadURL, id: ModelSpec.qwen3.id)
        try Data("abc".utf8).write(to: library.modelURL(old))
        try hash.write(to: directory.appendingPathComponent("verified.txt"), atomically: true, encoding: .utf8)
        XCTAssertTrue(library.isInstalled(old))
        XCTAssertEqual(library.pendingURL(old).lastPathComponent, "download.pending")
        try Data("abc".utf8).write(to: library.pendingURL(new))
        try ModelValidator.validate(library.pendingURL(new), spec: new)
        try library.installValidated(new)
        XCTAssertTrue(library.isInstalled(new))
        XCTAssertTrue(library.isInstalled(old))
        XCTAssertEqual(try Data(contentsOf: library.modelURL(old)), Data("abc".utf8))
        try Data("a".utf8).write(to: library.modelURL(new))
        XCTAssertFalse(library.isInstalled(new))
        XCTAssertTrue(library.isInstalled(old))
    }

    func testCatalogModelsHaveIsolatedFilesReceiptsAndPendingDownloads() {
        let library = ModelLibrary(directory: URL(fileURLWithPath: "/models"))
        XCTAssertEqual(Set(ModelSpec.catalog.map(\.id)).count, ModelSpec.catalog.count)
        let paths = ModelSpec.catalog.flatMap { [library.modelURL($0), library.pendingURL($0), library.receiptURL($0)] }
        XCTAssertEqual(Set(paths).count, paths.count)
        XCTAssertNil(ModelSpec.find("claude"))
    }

    func testReplyChunksKeepIndependentClocksAndReadablePrefix() {
        var reveal = ReplyRevealBuffer(text: "こんにちは。")
        reveal.update("こんにちは。新しい", at: 1)
        reveal.update("こんにちは。新しい返信", at: 1.1)
        // A piece starts no earlier than it came, the first half a step on.
        XCTAssertEqual(reveal.segments[0].startsAt, 1 + ReplyRevealBuffer.freshLead * ReplyRevealBuffer.defaultStep,
                       accuracy: 0.0001)
        XCTAssertGreaterThanOrEqual(reveal.segments[1].startsAt, 1.1)
        // Each piece settles when its last character has appeared.
        let firstSettles = reveal.segments[0].settlesAt
        XCTAssertLessThan(firstSettles, reveal.segments[1].settlesAt)
        reveal.settle(at: firstSettles)
        XCTAssertEqual(reveal.settledText, "こんにちは。新しい")
        XCTAssertEqual(reveal.segments.map(\.text), ["返信"])
        reveal.settle(at: 2)
        XCTAssertEqual(reveal.settledText, "こんにちは。新しい返信")
        XCTAssertNil(reveal.animationDeadline)
    }

    func testReplyRevealPreservesJapaneseEmojiAndCopyText() {
        var reveal = ReplyRevealBuffer()
        let parts = ["日本語", "の返信です。", "👨‍👩‍👧‍👦", "👍🏽", "\n次の行"]
        var complete = ""
        for (index, part) in parts.enumerated() {
            complete += part
            reveal.update(complete, at: Double(index) * 0.03)
            XCTAssertEqual(reveal.text, complete)
        }
        reveal.settle(at: 2)
        XCTAssertEqual(reveal.settledText, complete)
    }

    func testJoinedUnicodeGraphemeAndCorrectionsStayIntact() {
        var reveal = ReplyRevealBuffer(text: "か")
        reveal.update("か\u{3099}", at: 1)
        XCTAssertEqual(reveal.text, "か\u{3099}")
        reveal.update("👨", at: 1.1)
        reveal.update("👨‍👩‍👧‍👦", at: 1.2)
        XCTAssertEqual(reveal.text, "👨‍👩‍👧‍👦")
        XCTAssertTrue(reveal.segments.isEmpty)
        reveal.update("修正した返信", at: 2)
        XCTAssertEqual(reveal.settledText, "修正した返信")
    }

    func testFastReplyKeepsAnimationBookkeepingBounded() {
        var reveal = ReplyRevealBuffer()
        var complete = ""
        for index in 0..<100 {
            complete += "あ"
            reveal.update(complete, at: Double(index) * 0.001)
            XCTAssertLessThanOrEqual(reveal.segments.count, ReplyRevealBuffer.maximumAnimatedSegments)
            XCTAssertEqual(reveal.text, complete)
        }
        // The last piece came at 0.099 s and starts within furthestLead of
        // that; inFlight later every character has settled.
        reveal.settle(at: 0.1 + ReplyRevealBuffer.furthestLead + ReplyRevealBuffer.inFlight + 0.01)
        XCTAssertEqual(reveal.settledText, complete)
        XCTAssertTrue(reveal.segments.isEmpty)
    }

    func testRestoredReplyDoesNotReplayItsAnimation() {
        let reveal = ReplyRevealBuffer(text: "保存済みの返信です。")
        XCTAssertTrue(reveal.segments.isEmpty)
        XCTAssertEqual(reveal.settledText, "保存済みの返信です。")
    }

    func testStreamingContentDoesNotPullReaderAwayFromOldMessages() {
        var scrolling = ChatScrollPolicy()
        scrolling.observe(distanceFromBottom: 300)
        XCTAssertTrue(scrolling.shouldFollowStream, "Content growth must not disable automatic following")
        scrolling.setUserScrolling(true)
        scrolling.observe(distanceFromBottom: 500)
        scrolling.setUserScrolling(false)
        XCTAssertFalse(scrolling.shouldFollowStream)
        scrolling.observe(distanceFromBottom: 600)
        XCTAssertFalse(scrolling.shouldFollowStream)
        scrolling.requestLatest()
        XCTAssertTrue(scrolling.shouldFollowStream)
    }

    func testFollowingResumesWhenReaderScrollsBackToTheLatestReply() {
        var scrolling = ChatScrollPolicy()
        scrolling.setUserScrolling(true)
        scrolling.observe(distanceFromBottom: 400)
        scrolling.observe(distanceFromBottom: 20)
        XCTAssertFalse(scrolling.shouldFollowStream, "Do not fight an active finger gesture")
        scrolling.setUserScrolling(false)
        XCTAssertTrue(scrolling.shouldFollowStream)
    }

    func testAnimationMessageIdentitySurvivesArchiveRoundTrip() throws {
        let id = UUID()
        let message = ChatMessage(id: id, role: .user, text: "sent")
        let restored = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(message))
        XCTAssertEqual(restored.id, id)
    }

    func testSecondTurnReusesTheCompletedNativeConversation() {
        let thread = UUID()
        let firstTurn = [ChatMessage(role: .user, text: "こんにちは"),
                         ChatMessage(role: .assistant, text: "こんにちは！")]
        var context = ConversationContext()
        XCTAssertFalse(context.canReuse(threadID: thread, history: []))
        context.completeTurn(threadID: thread, history: [], prompt: "こんにちは", reply: "こんにちは！")
        XCTAssertTrue(context.canReuse(threadID: thread, history: firstTurn))
        XCTAssertFalse(context.canReuse(threadID: UUID(), history: firstTurn))
        // Context trimming must create a fresh native conversation.
        XCTAssertFalse(context.canReuse(threadID: thread, history: []))
        context.invalidate()
        XCTAssertFalse(context.canReuse(threadID: thread, history: firstTurn))
    }

    func testExpiredReplyCannotAppendOrFinishANewerRequest() {
        var ticket = ReplyTicket()
        let old = ticket.begin()
        XCTAssertTrue(ticket.finish(old))
        let new = ticket.begin()
        XCTAssertFalse(ticket.accepts(old))
        XCTAssertFalse(ticket.finish(old))
        XCTAssertTrue(ticket.accepts(new))
        XCTAssertTrue(ticket.finish(new))
        XCTAssertFalse(ticket.finish(new))
    }

    func testFailedAndStoppedRepliesAreExcludedFromContext() {
        let messages = [
            ChatMessage(role: .user, text: "first"),
            ChatMessage(role: .assistant, text: "answer"),
            ChatMessage(role: .user, text: "second"),
            ChatMessage(role: .assistant, text: "partial", state: .stopped),
            ChatMessage(role: .user, text: "third"),
            ChatMessage(role: .assistant, text: "error", state: .failed)
        ]
        XCTAssertEqual(HistoryBuilder.recentPairs(messages).map(\.text), ["first", "answer"])
    }

    func testHistoryKeepsNewestCompletePairsWithoutSplitting() {
        let messages = [
            ChatMessage(role: .user, text: "older"), ChatMessage(role: .assistant, text: "answer"),
            ChatMessage(role: .user, text: "new"), ChatMessage(role: .assistant, text: "yes")
        ]
        XCTAssertEqual(HistoryBuilder.recentPairs(messages, byteBudget: 6).map(\.text), ["new", "yes"])
        XCTAssertTrue(HistoryBuilder.recentPairs(messages, byteBudget: 5).isEmpty)
    }

    func testUTF8BudgetCountsJapaneseBytes() {
        let messages = [ChatMessage(role: .user, text: "あ"), ChatMessage(role: .assistant, text: "い")]
        XCTAssertTrue(HistoryBuilder.recentPairs(messages, byteBudget: 5).isEmpty)
        XCTAssertEqual(HistoryBuilder.recentPairs(messages, byteBudget: 6).count, 2)
    }

    func testArchiveRoundTripRecoversInterruptedReply() throws {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: dir) }
        let archive = ChatArchive(fileURL: dir.appendingPathComponent("chats.json"))
        var thread = ChatThread()
        thread.messages = [ChatMessage(role: .user, text: "hello"), ChatMessage(role: .assistant, text: "part", state: .generating)]
        try archive.save([thread])
        let restored = try archive.load()
        XCTAssertEqual(restored.first?.id, thread.id)
        XCTAssertEqual(restored.first?.messages.last?.state, .stopped)
        XCTAssertEqual(restored.first?.messages.last?.text, "part")
    }

    func testCorruptedArchiveThrowsRatherThanSilentlyDiscardingHistory() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: url) }
        try Data("invalid".utf8).write(to: url)
        XCTAssertThrowsError(try ChatArchive(fileURL: url).load())
    }

    func testChecksumRejectsSameSizeCorruptionAndTruncatedDownloads() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: url) }
        let spec = ModelSpec(fileName: "sample", byteCount: 3,
            sha256: "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            downloadURL: URL(string: "https://example.com/sample")!)
        try Data("abc".utf8).write(to: url)
        XCTAssertNoThrow(try ModelValidator.validate(url, spec: spec))
        try Data("abd".utf8).write(to: url)
        XCTAssertThrowsError(try ModelValidator.validate(url, spec: spec))
        try Data("ab".utf8).write(to: url)
        XCTAssertThrowsError(try ModelValidator.validate(url, spec: spec))
    }
}
