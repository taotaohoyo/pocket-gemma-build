import XCTest
@testable import PocketCore

/// Searches for the latest (1.1.0 (211)). On 210 E4B was asked
/// 「今のchatGPTの最新モデルはなにー？」 and then 「検索してくれる？」: it
/// searched 「ChatGPT 最新モデル」 and 「GPT-5.5 Instant」 and answered GPT-5.5
/// Instant, in English, when GPT-6 had come to ChatGPT on October 7. The
/// pages here are real pages of 2026-10-27, cut short, as a general search
/// and the past month's search found them (titles, addresses and dates as
/// published; texts from their first lines).
final class WebSearchLatestTests: XCTestCase {
    private let today = ISO8601DateFormatter().date(from: "2026-10-27T03:00:00Z")!
    private let earlier = "今のchatGPTの最新モデルはなにー？"
    private var zone: TimeZone?

    override func setUp() {
        zone = NSTimeZone.default
        NSTimeZone.default = TimeZone(identifier: "Asia/Tokyo")!
    }
    override func tearDown() {
        if let zone { NSTimeZone.default = zone }
    }

    private func day(_ text: String) -> Date { ISO8601DateFormatter().date(from: text + "T12:00:00Z")! }

    /// 「ChatGPT 最新モデル」 as a general search found it: pages that call
    /// older models the latest.
    private var general: [WebSearchHit] {
        [WebSearchHit(title: "ChatGPTのモデルとは？OpenAIの最新モデル一覧と特徴を解説【2026年最新版】",
                      url: "https://www.ai-souken.com/article/openai-model-list-chatgpt", site: "ai-souken.com",
                      text: "2026年2月にOpenAIがChatGPTのモデル構成を刷新し、GPT-5.2シリーズを標準にしました。最新フラグシップはGPT-5.4 Thinkingです。",
                      published: day("2026-03-01")),
         WebSearchHit(title: "ChatGPTのバージョン一覧【2026年最新】：GPT-5.4から歴代モデルまで完全比較",
                      url: "https://dot-ai.myuuu.co.jp/times/articles/484", site: "dot-ai.myuuu.co.jp",
                      text: "今回はChatGPTのバージョン比較をしましょう。最新はGPT-5.4（2026年3月）です。", published: day("2026-04-19")),
         WebSearchHit(title: "ChatGPT switches to GPT-5.5 Instant as the default model",
                      url: "https://itdaily.com/news/cloud/chatgpt-switches-to-gpt-5-5-instant-as-default-model/", site: "itdaily.com",
                      text: "OpenAI is replacing GPT-5.3 Instant with GPT-5.5 Instant as the default model for all ChatGPT users.",
                      published: day("2026-05-06")),
         WebSearchHit(title: "GPT‑5.5 Instant: より賢く、より明快に、よりパーソナルに | OpenAI",
                      url: "https://openai.com/ja-JP/index/gpt-5-5-instant/", site: "openai.com",
                      text: "誰でも利用できる ChatGPT のデフォルト モデルを更新し、より賢く、より正確に、そして より明確で簡潔な回答で、あなたにより合った体験を提供します。",
                      published: day("2026-05-05"))]
    }

    /// The same search within the past month.
    private var month: [WebSearchHit] {
        [WebSearchHit(title: "GPT-6 and the Intelligent UI for everyone | OpenAI", url: "https://openai.com/index/gpt-6-for-everyone/",
                      site: "openai.com",
                      text: "Last month we released the first GPT-6 models to paying customers. Today GPT-6 comes to everyone: GPT-6 Sol powers ChatGPT for Plus, Pro, Business and Enterprise, and GPT-6 Luna for Free and Go.",
                      published: day("2026-10-07")),
         WebSearchHit(title: "OpenAI Is Finally Bringing GPT-6 to ChatGPT for Everyone",
                      url: "https://www.androidheadlines.com/2026/10/openai-bringing-gpt-6-ai-models-chatgpt-everyone.html", site: "androidheadlines.com",
                      text: "OpenAI started rolling out GPT-6 models to ChatGPT worldwide, bringing GPT-6 Sol to paid plans; Free and Go users get GPT-6 Luna starting October 8.",
                      published: day("2026-10-07")),
         WebSearchHit(title: "OpenAI、「GPT-6 Sol」「Luna」公開　Astra並の性能でコストはGPT-5.6の半額",
                      url: "https://www.watch.impress.co.jp/docs/news/2142636.html", site: "watch.impress.co.jp",
                      text: "OpenAIは22日(米国時間)、最上位モデル「GPT‑6 Astra」と同じGPT-6シリーズで、新モデル「GPT‑6 Sol」、「GPT‑6 Luna」を提供開始した。",
                      published: day("2026-09-23"))]
    }

    private func interleaved() -> [WebSearchHit] {
        (0..<max(general.count, month.count)).flatMap { index in
            [general.indices.contains(index) ? general[index] : nil, month.indices.contains(index) ? month[index] : nil].compactMap { $0 }
        }
    }

    func testABareFollowUpSearchesWhatTheMessageBeforeAsked() {
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        XCTAssertTrue(follow.followsUp)
        XCTAssertTrue(follow.wantsLatest, "the message before asked for the latest")
        XCTAssertEqual(follow.names, ["chatgpt"])
        XCTAssertEqual(follow.language, "Japanese")
        XCTAssertTrue(follow.isOfficial("https://openai.com/index/gpt-6-for-everyone/"), "ChatGPT's maker")
        XCTAssertFalse(follow.isOfficial("https://www.ai-souken.com/article/openai-model-list-chatgpt"))
        // 210 read only the follow-up: nothing asked for the latest.
        XCTAssertFalse(SearchTarget(question: "検索してくれる？", today: today).wantsLatest)
        // The query alone says so too, and names the maker.
        let plain = SearchTarget(question: "調べて", today: today)
        XCTAssertTrue(plain.latest(for: "ChatGPT 最新モデル"))
        XCTAssertTrue(plain.isOfficial("https://help.openai.com/en/articles/9624314", query: "ChatGPT 最新モデル"))
        XCTAssertTrue(plain.isOfficial("https://openai.com/index/gpt-5-5-instant/", query: "GPT-5.5 Instant"))
        // Other follow-ups, and questions of their own.
        for question in ["調べて", "ググって", "ネットで調べてくれる？", "それって何が新しくなるの？", "search it", "Can you look it up?",
                         "please search", "검색해줘", "搜索一下"] {
            XCTAssertTrue(SearchTarget(question: question, earlier: [earlier], today: today).followsUp, question)
        }
        for question in ["東京スカイツリーの高さを検索して", "Search the height of Tokyo Tower", "갤럭시 최신 모델은 뭐야? 검색해줘",
                         "iOS 27.2の新機能を調べて"] {
            XCTAssertFalse(SearchTarget(question: question, earlier: [earlier], today: today).followsUp, question)
        }
        XCTAssertFalse(SearchTarget(question: "検索してくれる？", today: today).followsUp, "nothing before it")
    }

    func testTheLatestReadsThePastMonthsPagesFirst() throws {
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        let query = "ChatGPT 最新モデル"
        let recent = try XCTUnwrap(follow.recent(for: query))
        XCTAssertEqual(recent.query, query)
        XCTAssertEqual(recent.timeRange, "month")
        XCTAssertEqual(recent.mcpArguments["time_range"] as? String, "month", "signed in too")
        XCTAssertEqual(recent.restBody()["time_range"] as? String, "month")
        XCTAssertNil(SearchTarget(question: "iOS27.2っていつ更新されるのー？", today: today).recent(for: "iOS 27.2 更新"),
                     "a version's pages: 208's search")
        XCTAssertNil(SearchTarget(question: "東京スカイツリーの高さを調べて", today: today).recent(for: "東京スカイツリー 高さ"))
        XCTAssertEqual(follow.searchWords(in: query), ["ChatGPT"], "「最新」 in an old title says nothing of its date")

        let findings = follow.select(interleaved(), query: query)
        XCTAssertTrue(findings.latest)
        XCTAssertEqual(findings.hits.map(\.site), ["openai.com", "androidheadlines.com", "watch.impress.co.jp"])
        XCTAssertEqual(findings.hits.first?.url, "https://openai.com/index/gpt-6-for-everyone/")
        XCTAssertFalse(findings.hits.contains { $0.site == "ai-souken.com" || $0.site == "dot-ai.myuuu.co.jp" })
        XCTAssertFalse(findings.hits.contains { $0.url.contains("gpt-5-5-instant") }, "May's page beside October's says nothing current")
        // 210: the follow-up alone, the general search alone.
        let before = SearchTarget(question: "検索してくれる？", today: today).select(general)
        XCTAssertFalse(before.latest)
        XCTAssertEqual(before.hits.map(\.site), ["ai-souken.com", "dot-ai.myuuu.co.jp", "itdaily.com"])

        let response = WebSearch.toolResponse(query: query, findings: findings, target: follow, search: 1)
        let results = try XCTUnwrap(response["results"] as? [[String: Any]])
        XCTAssertEqual(results.compactMap { $0["date"] as? String }, ["2026-10-07", "2026-10-07", "2026-09-23"])
        let note = try XCTUnwrap(response["note"] as? String)
        XCTAssertTrue(note.contains("Today is 2026-10-27; newer pages say what is current"), note)
        XCTAssertTrue(note.hasSuffix("1 is from the maker's own site."), note)
        XCTAssertTrue((response["then"] as? String)?.contains("Answer in Japanese, whatever language the results are in.") == true)
        XCTAssertLessThanOrEqual(WebSearch.estimatedTokens(response), WebSearch.responseTokenBudget)
    }

    /// Pages older than 120 days go once two from the past 45 days say what
    /// is current, only for the latest of something no version names.
    func testOldPagesGoOnceNewerOnesSayWhatIsCurrent() {
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        let query = "ChatGPT 最新モデル"
        let one = follow.select([general[2], month[1], general[0]], query: query)
        XCTAssertEqual(one.hits.map(\.site), ["androidheadlines.com", "itdaily.com", "ai-souken.com"], "one new page: the older stay, behind it")
        let two = follow.select([general[2], month[0], general[0], month[1]], query: query)
        XCTAssertEqual(two.hits.map(\.site), ["openai.com", "androidheadlines.com"])
        let plain = SearchTarget(question: "ChatGPTの歴代モデルを調べて", today: today)
        XCTAssertEqual(plain.select(interleaved(), query: "ChatGPT 歴代モデル").hits.count, WebSearch.resultLimit, "not asked for the latest")
    }

    /// What the maker's newest page names is current: a page naming only
    /// older versions of it goes, whatever its date.
    func testAPageNamingOnlyOlderVersionsThanTheMakersGoes() {
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        let query = "ChatGPT 最新モデル"
        let magazine = WebSearchHit(title: "【2026年最新】ChatGPTのモデル比較一覧", url: "https://shift-ai.co.jp/blog/31295", site: "shift-ai.co.jp",
                                    text: "GPT‑5.5 Instantは、ChatGPTの全ユーザーが使える高速のデフォルトモデルです。", published: day("2026-09-23"))
        let both = WebSearchHit(title: "ChatGPTのバージョン一覧", url: "https://aipicks.jp/chatgpt", site: "aipicks.jp",
                                text: "最新はGPT-6 Astra、通常のチャットはGPT-5.5 Instantから移りました。", published: day("2026-09-30"))
        XCTAssertEqual(follow.select([magazine, month[0], both], query: query).hits.map(\.site), ["openai.com", "aipicks.jp"])
        XCTAssertEqual(follow.select([magazine, both], query: query).hits.count, 2, "no maker's page: nothing says which is current")
        XCTAssertEqual(SearchTarget(question: "iOS 27.2の新機能は？", today: today).select([magazine, month[0], both]).hits.count, 3,
                       "not asked for the latest")
        XCTAssertEqual(SearchTarget.namedVersions(in: "GPT‑5.5 Instant と GPT-6.1 Sol、Python 3.15.2、top 10、2026年").map { "\($0.name) \($0.version)" },
                       ["gpt [5, 5]", "gpt [6, 1]", "python [3, 15, 2]"])
        XCTAssertTrue(SearchTarget.isOlder([5, 5], than: [6]))
        XCTAssertTrue(SearchTarget.isOlder([6], than: [6, 1]))
        XCTAssertFalse(SearchTarget.isOlder([6, 1], than: [6]))
        XCTAssertFalse(SearchTarget.isOlder([6], than: [6]))
    }

    /// Neither search found a page of the maker's: the same search goes
    /// once more on its sites, and only then (E2B on Tavily's real results,
    /// run 40509213631).
    func testNoPageOfTheMakersSearchesItsSites() throws {
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        let query = "ChatGPT 最新モデル"
        let magazine = WebSearchHit(title: "【2026年最新】ChatGPTのモデル比較一覧", url: "https://shift-ai.co.jp/blog/31295", site: "shift-ai.co.jp",
                                    text: "GPT‑5.5 Instantは、ChatGPTの全ユーザーが使える高速のデフォルトモデルです。", published: day("2026-09-23"))
        let official = try XCTUnwrap(follow.official(for: query, after: [magazine, month[1]]))
        XCTAssertEqual(official.query, query)
        XCTAssertEqual(official.includeDomains, ["openai.com"])
        XCTAssertNil(official.timeRange)
        XCTAssertEqual(official.restBody()["include_domains"] as? [String], ["openai.com"])
        XCTAssertEqual(official.restBody(minimal: true)["include_domains"] as? [String], ["openai.com"], "stays on the maker's sites")
        XCTAssertEqual(official.mcpArguments["include_domains"] as? [String], ["openai.com"])
        XCTAssertNil(TavilyQuery(query).restBody()["include_domains"])
        XCTAssertNil(TavilyQuery(query).mcpArguments["include_domains"])
        XCTAssertNil(follow.official(for: query, after: [magazine, general[3]]), "a page of OpenAI's came, if old")
        XCTAssertNil(SearchTarget(question: "iOS27.2っていつ更新されるのー？", today: today).official(for: "iOS 27.2 更新", after: [magazine]),
                     "a version says which")
        XCTAssertNil(SearchTarget(question: "最新のニュースを調べて", today: today).official(for: "最新 ニュース", after: [magazine]),
                     "no maker named")
    }

    /// Two searches' pages in turns rank by their place in their own
    /// search; the same words aren't searched twice in a reply.
    func testPagesRankWithinTheirOwnSearchAndRepeatsAreAnsweredFromBefore() {
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        let pages = (0..<6).map { WebSearchHit(title: "ChatGPT update \($0)", url: "https://news\($0).example.com/a",
                                               site: "news\($0).example.com", text: "GPT-6 news", published: day("2026-10-20")) }
        XCTAssertEqual(follow.select(pages, query: "ChatGPT 最新モデル").hits.first?.site, "news0.example.com")
        let ranks = Dictionary(uniqueKeysWithValues: pages.enumerated().map { ($0.element.url, 5 - $0.offset) })
        XCTAssertEqual(follow.select(pages, query: "ChatGPT 最新モデル", ranks: ranks).hits.map(\.site),
                       ["news5.example.com", "news4.example.com", "news3.example.com"])
        let again = WebSearch.repeatResponse(query: "ChatGPT 最新モデル", language: "Japanese")
        XCTAssertEqual((again["results"] as? [Any])?.count, 0)
        XCTAssertTrue((again["note"] as? String)?.contains("already searched") == true)
        XCTAssertEqual(again["then"] as? String, "Answer in Japanese.")
        XCTAssertTrue(JSONSerialization.isValidJSONObject(again))
    }

    /// With no page found the language comes last too, and a reply written
    /// again says the search couldn't confirm it.
    func testNoPageFoundStillNamesTheLanguageLast() {
        let target = SearchTarget(question: "iOS 27.9はいつ出るの？ウェブで調べて", today: today)
        let none = WebSearch.toolResponse(query: "iOS 27.9 release date", findings: target.select([]), target: target, search: 1)
        XCTAssertEqual(none["then"] as? String, "Answer in Japanese.")
        XCTAssertEqual(Array((none as [String: Any]).keys).sorted().last, "then", "read last")
        XCTAssertEqual(WebSearch.toolResponse(query: "q", hits: [], search: 1)["then"] as? String,
                       "Answer in the language of the user's question.")
        XCTAssertTrue(WebSearch.noResultsMaterial(language: "Japanese").hasSuffix("\nAnswer in Japanese."))
        XCTAssertTrue(WebSearch.noResultsMaterial().contains("couldn't confirm it, and don't guess"))
        XCTAssertNil(WebSearch.answerMaterial([none]), "no pages to quote")
    }

    /// Pages without Tavily's date, as its MCP server gives them: the day
    /// in the address, else the newest day the text names.
    func testPagesWithoutADateGoByTheirAddressOrText() throws {
        XCTAssertEqual(SearchTarget.addressDate("https://www.androidheadlines.com/2026/10/openai-gpt-6.html").map(WebSearch.dateText), "2026-10-01")
        XCTAssertEqual(SearchTarget.addressDate("https://gigazine.net/gsc_news/en/20260507-openai-gpt-5-5-instant").map(WebSearch.dateText), "2026-05-07")
        XCTAssertEqual(SearchTarget.addressDate("https://www.iphoneincanada.ca/2026/09/21/ios-27-2-beta-2/").map(WebSearch.dateText), "2026-09-21")
        XCTAssertNil(SearchTarget.addressDate("https://www.watch.impress.co.jp/docs/news/2142636.html"))
        XCTAssertNil(SearchTarget.addressDate("https://e.com/2099/01/01/future", notAfter: today))
        XCTAssertEqual(SearchTarget.newestDate(in: "2026年3月に公開、2026年10月7日に更新", notAfter: today).map(WebSearch.dateText), "2026-10-07")
        XCTAssertEqual(SearchTarget.newestDate(in: "Released on October 7, 2026 and updated 9 Oct 2026", notAfter: today).map(WebSearch.dateText), "2026-10-09")
        XCTAssertEqual(SearchTarget.newestDate(in: "2026년 10월 7일 출시", notAfter: today).map(WebSearch.dateText), "2026-10-07")
        XCTAssertNil(SearchTarget.newestDate(in: "Market 2026 outlook, junior 2026", notAfter: today), "not month names")
        XCTAssertNil(SearchTarget.newestDate(in: "2027年3月に発売予定", notAfter: today), "not after today")
        let json: [String: Any] = ["results": [
            ["title": "a", "url": "https://www.androidheadlines.com/2026/10/openai-gpt-6.html", "content": "x"],
            ["title": "b", "url": "https://e.com/b", "content": "y", "published_date": "2026-10-19T00:00:00Z"]]]
        XCTAssertEqual(try TavilySearch.parse(json: json).map { $0.published.map(WebSearch.dateText) }, ["2026-10-01", "2026-10-19"])
        // Ranked by the text's date when there is no other.
        let follow = SearchTarget(question: "検索してくれる？", earlier: [earlier], today: today)
        let undated = [WebSearchHit(title: "ChatGPTの最新モデル", url: "https://old.example.jp/a", site: "old.example.jp", text: "2025年8月、GPT-5が登場。"),
                       WebSearchHit(title: "ChatGPT news", url: "https://new.example.com/b", site: "new.example.com", text: "On October 7, 2026, GPT-6 came to ChatGPT.")]
        XCTAssertEqual(follow.select(undated, query: "ChatGPT 最新モデル").hits.first?.site, "new.example.com")
    }

    func testTheReplysLanguageIsToldFromItsStart() {
        XCTAssertEqual(WebSearch.replyIsIn("**GPT-6 Sol**です", language: "Japanese"), true)
        XCTAssertEqual(WebSearch.replyIsIn("The latest ChatGPT model is GPT-6", language: "Japanese"), false)
        XCTAssertNil(WebSearch.replyIsIn("**GPT-6 Sol** (Plus", language: "Japanese"), "names alone don't tell")
        XCTAssertEqual(WebSearch.replyIsIn("최신 모델은 GPT-6입니다", language: "Japanese"), false)
        XCTAssertEqual(WebSearch.replyIsIn("최신 모델은 GPT-6입니다", language: "Korean"), true)
        XCTAssertEqual(WebSearch.replyIsIn("The newest model is on the list", language: "Korean"), false)
        XCTAssertEqual(WebSearch.replyIsIn("目前最新的模型是GPT-6", language: "Simplified Chinese"), true)
        XCTAssertEqual(WebSearch.replyIsIn("最新モデルはGPT-6です", language: "Simplified Chinese"), false)
        XCTAssertEqual(WebSearch.replyIsIn("The latest is GPT-6", language: "English"), true)
        XCTAssertEqual(WebSearch.replyIsIn("最新のモデルはGPT-6です", language: "English"), false)
        XCTAssertEqual(WebSearch.replyIsIn("Le dernier modèle est GPT-6", language: "French"), true, "not told by its letters")
        // A language the question asks for in so many words.
        XCTAssertEqual(SearchTarget(question: "ChatGPTの最新モデルを英語で教えて").language, "English")
        XCTAssertEqual(SearchTarget(question: "Tell me about iOS 27.2 in Japanese").language, "Japanese")
        XCTAssertEqual(SearchTarget(question: "최신 아이폰을 영어로 알려줘").language, "English")
        XCTAssertEqual(SearchTarget(question: "用繁體中文回答最新的iPhone").language, "Traditional Chinese")
        XCTAssertEqual(SearchTarget(question: "今のChatGPTの最新モデルは？").language, "Japanese")
        // A question for the current state searches first.
        XCTAssertTrue(SearchTarget(question: earlier).asksForCurrent)
        XCTAssertTrue(SearchTarget(question: "What is the latest ChatGPT model?").asksForCurrent)
        XCTAssertFalse(SearchTarget(question: "東京スカイツリーの高さは？").asksForCurrent)
        XCTAssertFalse(SearchTarget(question: "iOS27.2っていつ更新されるのー？").asksForCurrent, "the model already searches these")
    }
}
