import XCTest
@testable import PocketCore

final class ChatEndVisibilityTests: XCTestCase {
    func testVisibleEndOverridesStaleLazyHeightWhileManualScrollingFinishes() {
        var policy = ChatScrollPolicy()
        policy.setUserScrolling(true)
        policy.observe(distanceFromBottom: 400)
        XCTAssertTrue(policy.showsJumpButton)
        policy.observeEndVisibility(true)
        policy.observe(distanceFromBottom: 90) // cached estimate still says away
        XCTAssertFalse(policy.showsJumpButton)
        XCTAssertFalse(policy.shouldFollowStream) // never fight the finger
        policy.setUserScrolling(false)
        XCTAssertTrue(policy.shouldFollowStream)
        XCTAssertFalse(policy.showsJumpButton)
        policy.setUserScrolling(true)
        policy.observeEndVisibility(false)
        policy.observe(distanceFromBottom: 400)
        policy.setUserScrolling(false)
        XCTAssertTrue(policy.showsJumpButton)
        XCTAssertFalse(policy.shouldFollowStream)
    }

    func testGrowingContentLosingEndVisibilityDoesNotAbandonFollowing() {
        var policy = ChatScrollPolicy()
        policy.observeEndVisibility(true)
        policy.observeEndVisibility(false)
        policy.observe(distanceFromBottom: 200)
        XCTAssertTrue(policy.shouldFollowStream)
        XCTAssertFalse(policy.showsJumpButton)
        policy.setUserScrolling(true)
        policy.observe(distanceFromBottom: 300)
        policy.setUserScrolling(false)
        XCTAssertFalse(policy.shouldFollowStream)
        policy.observeEndVisibility(false)
        policy.observe(distanceFromBottom: 500)
        XCTAssertFalse(policy.shouldFollowStream)
    }
}
