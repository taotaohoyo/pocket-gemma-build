import XCTest
@testable import PocketCore

/// How a reply's text is laid out behind the model (ReplyPacer). A model is
/// played in at a given speed, its text arriving in 45 ms batches as the
/// store delivers it; the pacer is stepped at the row's interval; and the
/// steps are checked for their lag behind the model, their size and pace,
/// and how soon they finish. PACE-NOTE lines in the log carry the numbers.
final class ReplyPacerTests: XCTestCase {
    private struct Step {
        let at: TimeInterval
        let count: Int
        let pace: Double
    }

    private struct Playback {
        let pacer: ReplyPacer
        var steps: [Step] = []
        /// When each character was shown, and when it arrived.
        var shownAt: [TimeInterval] = []
        var arrivedAt: [TimeInterval] = []
        /// Times the display ran out of text while the model still wrote.
        var dryStops = 0

        var lags: [TimeInterval] { zip(shownAt, arrivedAt).map { $0.0 - $0.1 } }
        var largestStep: Int { steps.map(\.count).max() ?? 0 }
        /// The largest rise of the pace from one step to the next.
        var steepestRise: Double {
            zip(steps.dropFirst(), steps).map { $0.0.pace - $0.1.pace }.max() ?? 0
        }
        func lags(arrivedAfter start: TimeInterval) -> [TimeInterval] {
            zip(shownAt, arrivedAt).filter { $0.1 >= start }.map { $0.0 - $0.1 }
        }
    }

    private typealias Arrival = (at: TimeInterval, text: String)

    /// Plays `arrivals` into a pacer held until `release`, with the model
    /// writing until `end`, stepping the pacer until `until`.
    private func play(_ arrivals: [Arrival], release: TimeInterval, end: TimeInterval, until: TimeInterval) -> Playback {
        let pacer = ReplyPacer(text: "", generating: true, held: true, shown: 0)
        var playback = Playback(pacer: pacer)
        var pending = arrivals.sorted { $0.at < $1.at }
        var now: TimeInterval = 0
        var moving = false
        while now < until {
            while let next = pending.first, next.at <= now {
                pacer.text += next.text
                playback.arrivedAt += Array(repeating: next.at, count: next.text.count)
                pending.removeFirst()
            }
            if now >= release { pacer.held = false }
            if now >= end { pacer.generating = false }
            let before = pacer.shown
            if let count = pacer.advance(at: now), count > before {
                playback.steps.append(Step(at: now, count: count - before, pace: pacer.pace))
                playback.shownAt += Array(repeating: now, count: count - before)
                moving = true
            } else if moving, pacer.generating, pacer.caughtUp, !pacer.text.isEmpty {
                playback.dryStops += 1
                moving = false
            }
            now += ReplyPacer.interval(forLength: pacer.shown)
        }
        return playback
    }

    /// A model writing `rate` characters a second from `start` for
    /// `seconds`, delivered in 45 ms batches.
    private func steady(_ rate: Double, for seconds: TimeInterval, from start: TimeInterval = 0) -> [Arrival] {
        var arrivals: [Arrival] = []
        var at = start
        var owed = 0.0
        while at < start + seconds {
            owed += rate * 0.045
            let count = Int(owed)
            owed -= Double(count)
            if count > 0 { arrivals.append((at: at, text: String(repeating: "あ", count: count))) }
            at += 0.045
        }
        return arrivals
    }

    private func note(_ name: String, _ playback: Playback, end: TimeInterval) {
        let lags = playback.lags
        let mean = lags.isEmpty ? 0 : lags.reduce(0, +) / Double(lags.count)
        let finish = (playback.steps.last?.at ?? end) - end
        print(String(format: "PACE-NOTE %@: %d chars, lag mean %.2f s max %.2f s, finished %.2f s after the end, largest step %d, steepest rise %.1f chars/s, dry stops %d",
                     name, playback.pacer.text.count, mean, lags.max() ?? 0, finish, playback.largestStep,
                     playback.steepestRise, playback.dryStops))
    }

    func testHoldsThePlaceUntilReleasedThenStartsClosely() {
        let pacer = ReplyPacer(text: "こんにちは。", generating: true, held: true, shown: 0)
        XCTAssertNil(pacer.advance(at: 0))
        XCTAssertNil(pacer.advance(at: 0.5))
        XCTAssertEqual(pacer.shown, 0)
        pacer.held = false
        var now = 0.5
        while pacer.shown < 1, now < 2 {
            now += 0.042
            _ = pacer.advance(at: now)
        }
        XCTAssertLessThan(now - 0.5, 0.1, "The first character follows the release at once")
    }

    func testFollowsAModelAQuarterSlowerAboutTwoSecondsBehind() {
        for rate in [15.0, 25.0, 40.0, 80.0] {
            let playback = play(steady(rate, for: 6), release: 0.7, end: 6, until: 12)
            note("steady \(Int(rate)) chars/s", playback, end: 6)
            XCTAssertEqual(playback.pacer.shown, playback.pacer.text.count, "\(rate): everything is shown in the end")
            // Once under way, the display runs at about three quarters of
            // the model's speed (never under the least pace), so it trails
            // the model by up to about two seconds, and never runs dry.
            let paces = playback.steps.filter { $0.at > 2 && $0.at < 4.5 }.map(\.pace).sorted()
            let middle = paces[paces.count / 2]
            let wanted = max(ReplyPacer.relaxation * rate, ReplyPacer.slowestWhileWriting)
            XCTAssertEqual(middle, wanted, accuracy: wanted * 0.1, "\(rate): a quarter slower than the model")
            let settled = playback.lags(arrivedAfter: 1.5).filter { $0 < 10 }
            let mean = settled.reduce(0, +) / Double(settled.count)
            XCTAssertGreaterThan(mean, 1.0, "\(rate): the text in hand covers the model's pauses")
            XCTAssertLessThan(mean, 2.2, "\(rate): the display does not fall far behind")
            XCTAssertLessThanOrEqual(settled.max() ?? 0, ReplyPacer.drainLag + 0.3, "\(rate)")
            XCTAssertEqual(playback.dryStops, 0, "\(rate)")
            // Steps stay small: no piece appears as a block.
            XCTAssertLessThanOrEqual(playback.largestStep, max(4, Int(rate / 10)), "\(rate)")
            // What remains at the end runs on at the pace the text had:
            // neither a burst nor a wait.
            let finish = (playback.steps.last?.at ?? 0) - 6
            XCTAssertLessThanOrEqual(finish, ReplyPacer.drainLag + 0.4, "\(rate)")
            XCTAssertGreaterThan(finish, 0.8, "\(rate): the end is not a burst")
            let before = playback.steps.filter { $0.at > 5.6 && $0.at < 6 }.map(\.pace)
            let after = playback.steps.filter { $0.at >= 6 }.map(\.pace)
            let beforeMean = before.reduce(0, +) / Double(max(before.count, 1))
            XCTAssertLessThanOrEqual(after.max() ?? 0, beforeMean * 1.25 + 1, "\(rate): the end does not speed up")
        }
    }

    func testALongReplyEndsUpAtTheModelsSpeedAboutTwoSecondsBehind() {
        let playback = play(steady(30, for: 15), release: 0.7, end: 15, until: 22)
        note("steady 30 chars/s for 15 s", playback, end: 15)
        XCTAssertEqual(playback.pacer.shown, playback.pacer.text.count)
        let early = playback.steps.filter { $0.at > 2 && $0.at < 4 }.map(\.pace)
        let late = playback.steps.filter { $0.at > 10 && $0.at < 14.5 }.map(\.pace)
        let earlyMean = early.reduce(0, +) / Double(max(early.count, 1))
        let lateMean = late.reduce(0, +) / Double(max(late.count, 1))
        XCTAssertEqual(earlyMean, 22.5, accuracy: 2.5, "At first a quarter slower than the model")
        XCTAssertEqual(lateMean, 30, accuracy: 2, "Then at the model's speed, the delay bounded")
        XCTAssertLessThanOrEqual(playback.lags.max() ?? 0, ReplyPacer.drainLag + 0.3, "Never further behind than the drain lag")
        XCTAssertLessThan(playback.steepestRise, 3, "The pace moves gradually")
        XCTAssertLessThanOrEqual((playback.steps.last?.at ?? 0) - 15, ReplyPacer.drainLag + 0.4)
    }

    func testAHiccupNeitherStopsNorRushesTheText() {
        // Forty characters a second, 1.2 s of nothing, then forty a second
        // again: the text in hand runs on through the gap, easing a little,
        // and picks up gently.
        let playback = play(steady(40, for: 3) + steady(40, for: 3, from: 4.2), release: 0.7, end: 7.2, until: 11)
        note("40 chars/s, 1.2 s hiccup", playback, end: 7.2)
        XCTAssertEqual(playback.pacer.shown, playback.pacer.text.count)
        XCTAssertEqual(playback.dryStops, 0, "The text in hand covers the gap")
        XCTAssertLessThan(playback.steepestRise, 5)
        XCTAssertLessThanOrEqual(playback.lags.max() ?? 0, 2.6)
        let through = playback.steps.filter { $0.at > 3 && $0.at < 4.2 }.map(\.pace)
        XCTAssertGreaterThan(through.min() ?? 0, 15, "No crawl through the gap")
    }

    func testASlowModelIsShownAsItWrites() {
        // Six characters a second: slower than the least pace, so each piece
        // shows within a step of arriving instead of waiting for a backlog.
        let playback = play(steady(6, for: 8), release: 0.7, end: 8, until: 10)
        note("slow 6 chars/s", playback, end: 8)
        XCTAssertEqual(playback.pacer.shown, playback.pacer.text.count)
        XCTAssertLessThanOrEqual(playback.lags(arrivedAfter: 2).max() ?? 0, 0.3, "Each piece shows within a step or two of arriving")
        XCTAssertLessThanOrEqual(playback.largestStep, 2)
    }

    func testAStallSlowsTheTextGentlyAndABatchAfterItDoesNotBurst() {
        // Forty characters a second, two seconds of nothing, then eighty
        // characters at once (the model's tokens batched while the display
        // ran out) and forty a second again.
        let arrivals = steady(40, for: 2) + [(at: 4.0, text: String(repeating: "い", count: 80))] + steady(40, for: 2, from: 4.0)
        let playback = play(arrivals, release: 0.7, end: 6, until: 9)
        note("40 chars/s, 2 s stall, 80-char batch", playback, end: 6)
        XCTAssertEqual(playback.pacer.shown, playback.pacer.text.count)
        XCTAssertLessThanOrEqual(playback.largestStep, 5, "The batch is laid out at a pace, not as a block")
        // Two ticks can pass between the first steps of the recovery, so a
        // step's rise can be about twice a tick's.
        XCTAssertLessThan(playback.steepestRise, 20, "The pace rises gently")
        // Within two seconds of the model resuming, the display trails it by
        // no more than its usual two seconds again.
        let resumed = playback.lags(arrivedAfter: 5.5)
        XCTAssertLessThanOrEqual(resumed.max() ?? 0, ReplyPacer.drainLag + 0.5)
        // The display eased off while the model was silent, stopping at
        // most once, rather than running on at full pace into a dry stop.
        XCTAssertLessThanOrEqual(playback.dryStops, 1)
        let paces = playback.steps.filter { $0.at > 2 && $0.at < 4 }.map(\.pace)
        XCTAssertLessThan(paces.last ?? 0, paces.first ?? 0, "The pace eased off through the stall")
    }

    func testAShortReplyThatEndedDuringTheHoldShowsOnRelease() {
        let arrivals: [Arrival] = [(at: 0.1, text: "はい、"), (at: 0.25, text: "できます。"), (at: 0.4, text: "どうぞ。")]
        let playback = play(arrivals, release: 0.7, end: 0.4, until: 3)
        note("short reply ended in the hold", playback, end: 0.7)
        XCTAssertEqual(playback.pacer.shown, playback.pacer.text.count)
        let first = playback.steps.first?.at ?? 10
        XCTAssertLessThan(first - 0.7, 0.3, "The text starts as soon as the place is free")
        XCTAssertLessThanOrEqual((playback.steps.last?.at ?? 10) - 0.7, 1.0, "A short reply is not drawn out")
        XCTAssertGreaterThanOrEqual(playback.steps.count, 3, "Nor does it appear all at once")
    }

    func testAStoppedReplyLaysOutWhatItHasAndThenStaysQuiet() {
        let pacer = ReplyPacer(text: String(repeating: "う", count: 40), generating: true, held: false, shown: 0)
        var now = 0.0
        for _ in 0..<10 { now += 0.042; _ = pacer.advance(at: now) }
        pacer.generating = false
        let stopped = now
        while !pacer.caughtUp, now < stopped + 3 { now += 0.042; _ = pacer.advance(at: now) }
        XCTAssertLessThanOrEqual(now - stopped, 2.0, "What remains follows the stop within two seconds, at the pace it had")
        // Caught up: no more updates until new text comes.
        for _ in 0..<20 { now += 0.042; XCTAssertNil(pacer.advance(at: now)) }
        pacer.text += "え"
        now += 0.042
        var shown: Int?
        for _ in 0..<10 where shown == nil { now += 0.042; shown = pacer.advance(at: now) }
        XCTAssertEqual(shown, 41, "New text shows within a few steps")
    }

    func testNothingIsReportedWhileCaughtUp() {
        let pacer = ReplyPacer(text: "完了", generating: true, held: false, shown: 2)
        var now = 0.0
        for _ in 0..<30 { now += 0.042; XCTAssertNil(pacer.advance(at: now)) }
    }

    func testALongPauseDoesNotComeBackAsABurst() {
        let pacer = ReplyPacer(text: String(repeating: "お", count: 400), generating: true, held: false, shown: 0)
        _ = pacer.advance(at: 0)
        for tick in 1...10 { _ = pacer.advance(at: Double(tick) * 0.042) }
        let before = pacer.shown
        // Three seconds without a step, as when the app was suspended.
        _ = pacer.advance(at: 3.5)
        XCTAssertLessThanOrEqual(pacer.shown - before, Int(ReplyPacer.longestStep * 400) + 2)
    }

    func testCharactersAreNeverSplit() {
        // Pieces of one character arrive one scalar at a time, as tokens
        // can: an emoji sequence, a flag, a combining mark, "\r\n".
        let pieces = ["家族", "👨", "\u{200D}", "👩", "\u{200D}", "👧", "の旅", "🇯", "🇵", "cafe", "\u{301}", "\r", "\n", "か", "\u{3099}", "完"]
        let pacer = ReplyPacer(text: "", generating: true, held: false, shown: 0)
        var now = 0.0
        var widest = 0
        for piece in pieces {
            pacer.text += piece
            // Enough time that the pace lets everything through.
            for _ in 0..<40 {
                now += 0.1
                _ = pacer.advance(at: now)
                let displayed = String(pacer.text.prefix(pacer.shown))
                XCTAssertTrue(pacer.text.hasPrefix(displayed), "\(Array(displayed.unicodeScalars))")
                XCTAssertLessThanOrEqual(pacer.shown, pacer.text.count)
                widest = max(widest, displayed.unicodeScalars.count)
            }
        }
        XCTAssertEqual(pacer.shown, pacer.text.count)
        XCTAssertEqual(String(pacer.text.prefix(pacer.shown)), pieces.joined())
        // The joined family and flag are shown whole, as one character each.
        XCTAssertEqual(pieces.joined().count, 13)
        XCTAssertEqual(widest, pieces.joined().unicodeScalars.count)
    }

    func testAJoiningScalarGrowsTheShownCharacterWithoutASplit() {
        let pacer = ReplyPacer(text: "a👨", generating: true, held: false, shown: 2)
        pacer.text += "\u{200D}👩"
        XCTAssertEqual(pacer.text.count, 2, "The sequence joined into the shown character")
        XCTAssertNil(pacer.advance(at: 1), "Nothing new to count")
        XCTAssertEqual(String(pacer.text.prefix(pacer.shown)), "a👨\u{200D}👩", "The whole sequence shows")
    }

    func testStepsKeepSyntaxWhole() {
        XCTAssertEqual(ReplyPacer.wholeSyntax("**太字**の説明", from: 0, step: 1), 2, "Both asterisks together")
        XCTAssertEqual(ReplyPacer.wholeSyntax("**太字**の説明", from: 2, step: 1), 1)
        XCTAssertEqual(ReplyPacer.wholeSyntax("**太字**の説明", from: 2, step: 3), 4, "...and the closing pair")
        XCTAssertEqual(ReplyPacer.wholeSyntax("\\frac{1}{2}", from: 0, step: 1), 6, "The command's name and the brace")
        XCTAssertEqual(ReplyPacer.wholeSyntax("\\frac{1}{2}", from: 6, step: 1), 3, "1 then }{")
        XCTAssertEqual(ReplyPacer.wholeSyntax("[リンク](https://a.example)", from: 4, step: 1), 2, "](")
        XCTAssertEqual(ReplyPacer.wholeSyntax("```swift\ncode", from: 0, step: 1), 3)
        XCTAssertEqual(ReplyPacer.wholeSyntax("ただの文章です", from: 2, step: 2), 2)
        XCTAssertEqual(ReplyPacer.wholeSyntax("x$", from: 0, step: 2), 2, "A step reaching the end stays there")
    }

    /// A table's header and delimiter row are laid out whole once a step
    /// reaches them, or all that has come of them (1.1.0 (245)); the rows
    /// under them, prose and code are paced as before.
    func testATableHeadIsLaidOutWhole() {
        let text = "表です。\n\n| 日程 | 時間帯 |\n| :--- | :--- |\n| 1日目 | 午前 |\n"
        let head = "表です。\n\n".count
        let header = "表です。\n\n| 日程 | 時間帯 |\n".count
        let delimiter = "表です。\n\n| 日程 | 時間帯 |\n| :--- | :--- |\n".count
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: head, end: head + 3, generating: true), delimiter)
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: header, end: header + 2, generating: true), delimiter)
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: 0, end: head, generating: true), head, "A step before it is left alone")
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: delimiter, end: delimiter + 3, generating: true), delimiter + 3,
                       "The rows are paced")
        // Still being written: all that has come of it.
        for partial in ["表です。\n\n| 日程 | 時", "表です。\n\n| 日程 | 時間帯 |\n", "表です。\n\n| 日程 | 時間帯 |\n| :--"] {
            XCTAssertEqual(MarkdownSource.pacedEnd(partial, shown: head, end: head + 2, generating: true), partial.count, partial)
        }
        // Not a table: a line under it that is no delimiter row, or code.
        let prose = "| 注 | です\n本文です。"
        XCTAssertEqual(MarkdownSource.pacedEnd(prose, shown: 0, end: 3, generating: true), 3)
        let code = "前文\n```\n| a | b |\n|---|---|\n```\n"
        let inCode = "前文\n```\n".count
        XCTAssertEqual(MarkdownSource.pacedEnd(code, shown: inCode, end: inCode + 3, generating: true), inCode + 3)
        XCTAssertEqual(MarkdownSource.pacedEnd("文章だけ | です", shown: 0, end: 2, generating: true), 2)
    }

    /// A table reply from a model writing 30 characters a second, laid out
    /// at the pace: what the table shows only grows, and it keeps growing,
    /// a cell's text a character at a time, with no long stop while the
    /// text moves through the table. As 244 laid it out, rows went again
    /// and the table stood still for a row's length at a time. TABLE-NOTE
    /// lines carry the numbers.
    func testATableGrowsAtThePaceAndNeverShrinks() {
        let fixed = tableGrowth()
        MarkdownSource.holdsTableRowsWhole = true
        defer { MarkdownSource.holdsTableRowsWhole = false }
        let before = tableGrowth()
        print(String(format: "TABLE-NOTE pacer 245: %d steps in the table, longest still %.2f s, shrinks %d, first shown %.2f s; 244: %d steps, longest still %.2f s, shrinks %d, first shown %.2f s",
                     fixed.steps, fixed.longestStill, fixed.shrinks, fixed.firstShown,
                     before.steps, before.longestStill, before.shrinks, before.firstShown))
        XCTAssertEqual(fixed.shrinks, 0, "The table never shrinks")
        XCTAssertLessThan(fixed.longestStill, 0.6, "The table keeps growing as the text moves through it")
        XCTAssertLessThanOrEqual(fixed.firstShown, before.firstShown, "The header shows no later")
        XCTAssertGreaterThan(before.shrinks, 0, "As 244 laid it out, rows went again")
    }

    /// Plays the plan reply in at 30 characters a second: the steps that
    /// changed the table, the longest time the table's text stood still
    /// between its first and last change, how often it shrank, and when it
    /// first showed.
    private func tableGrowth() -> (steps: Int, longestStill: TimeInterval, shrinks: Int, firstShown: TimeInterval) {
        let reply = MarkdownTests.planReply
        var arrivals: [Arrival] = []
        var at = 0.0, cursor = reply.startIndex
        while cursor < reply.endIndex {
            let next = reply.index(cursor, offsetBy: 2, limitedBy: reply.endIndex) ?? reply.endIndex
            arrivals.append((at: at, text: String(reply[cursor..<next])))
            cursor = next
            at += 2.0 / 30
        }
        let playback = play(arrivals, release: 0, end: at, until: at + 4)
        var shown = 0, steps = 0, shrinks = 0
        var visible = 0
        var lastChange: TimeInterval?, firstShown: TimeInterval = .infinity
        var longestStill = 0.0
        for step in playback.steps {
            shown += step.count
            let prefix = String(reply.prefix(shown))
            let count = MarkdownTests.table(in: prefix, streaming: shown < reply.count)
                .map { table in (table.header + table.rows.flatMap { $0 }).reduce(0) { total, cell in total + cell.characters.count } } ?? 0
            guard count != visible else { continue }
            if count < visible { shrinks += 1 }
            if visible == 0 { firstShown = step.at }
            if let lastChange { longestStill = max(longestStill, step.at - lastChange) }
            lastChange = step.at
            visible = count
            steps += 1
        }
        return (steps, longestStill, shrinks, firstShown)
    }

    func testTheIntervalGrowsWithTheReply() {
        XCTAssertEqual(ReplyPacer.interval(forLength: 0), 1.0 / 24, accuracy: 0.0001)
        XCTAssertEqual(ReplyPacer.interval(forLength: 16_000), 0.1, accuracy: 0.0001)
        XCTAssertEqual(ReplyPacer.interval(forLength: 40_000), 0.1, accuracy: 0.0001)
        XCTAssertEqual(ReplyPacer.interval(forLength: 12_000), 0.085, accuracy: 0.001)
        var previous = 0.0
        for length in stride(from: 0, through: 20_000, by: 500) {
            let interval = ReplyPacer.interval(forLength: length)
            XCTAssertGreaterThanOrEqual(interval, previous)
            XCTAssertLessThanOrEqual(interval, ReplyPacer.longestStep)
            previous = interval
        }
    }

    func testALongReplyCostsLittlePerStep() {
        let paragraph = "長い回答の段落です。**太字**や`code`、数式 $x^2$ も混ざります。日本語の文章が続き、絵文字😊も入ります。\n\n"
        let text = String(repeating: paragraph, count: 12_000 / paragraph.count + 1)
        let pacer = ReplyPacer(text: text, generating: true, held: false, shown: text.count - 2_000)
        let start = DispatchTime.now()
        var now = 0.0
        var steps = 0
        while !pacer.caughtUp, steps < 2_000 {
            now += 0.042
            if pacer.advance(at: now) != nil { steps += 1 }
        }
        let milliseconds = Double(DispatchTime.now().uptimeNanoseconds - start.uptimeNanoseconds) / 1_000_000
        print(String(format: "PACE-PERF %d chars: %d steps in %.1f ms, %.3f ms per step", text.count, steps, milliseconds,
                     milliseconds / Double(max(steps, 1))))
        XCTAssertGreaterThan(steps, 0)
        XCTAssertLessThan(milliseconds / Double(max(steps, 1)), 5, "A step over a long reply stays cheap")
    }
}
