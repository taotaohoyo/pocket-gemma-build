import XCTest
@testable import PocketCore

/// A video since 1.1.0 (194): scenes picked by how the picture changes,
/// the sound's parts written down, and both read as one timeline.
final class VideoAnalysisTests: XCTestCase {
    private func scene(_ time: Double, _ caption: String? = nil, _ index: Int = 0) -> VideoAnalysis.Scene {
        VideoAnalysis.Scene(time: time, image: "frame-\(index).jpg", caption: caption)
    }
    private func video(_ analysis: VideoAnalysis, name: String = "clip.mov") -> ChatAttachment {
        var attachment = ChatAttachment(kind: .video, name: name, storedName: name,
                                        thumbnailName: analysis.scenes.first?.image,
                                        imageNames: analysis.scenes.map(\.image), duration: analysis.duration)
        attachment.video = analysis
        return attachment
    }
    private func spoken(duration: Double = 60, parts: [(Double, Double, String?)], scenes: Int = 6) -> VideoAnalysis {
        VideoAnalysis(duration: duration,
                      scenes: (0..<scenes).map { scene(Double($0) * duration / Double(scenes), "scene \($0)", $0) },
                      framesLooked: 60, sound: .parts,
                      parts: parts.map { VideoAnalysis.SoundPart(start: $0.0, end: $0.1, text: $0.2) }, soundTaken: duration)
    }

    // MARK: Scenes

    func testLongerVideosGetMoreScenesAndFramesToPickFrom() {
        XCTAssertEqual([2, 10, 25, 60, 150, 600].map(VideoScenePicker.sceneCount(duration:)), [4, 4, 6, 8, 10, 12])
        XCTAssertEqual(VideoScenePicker.sceneCount(duration: 0), 0)
        XCTAssertEqual(VideoScenePicker.sceneCount(duration: .nan), 0)
        XCTAssertEqual(VideoScenePicker.frameCount(duration: 1), 4, "never fewer frames than scenes")
        XCTAssertEqual(VideoScenePicker.frameCount(duration: 20), 40)
        XCTAssertEqual(VideoScenePicker.frameCount(duration: 3600), 60, "a long video is looked at 60 times, not more")
        for duration in [0.3, 2, 21, 299, 3600] {
            let times = VideoScenePicker.frameTimes(duration: duration)
            XCTAssertEqual(times.count, VideoScenePicker.frameCount(duration: duration))
            XCTAssertEqual(times, times.sorted())
            XCTAssertTrue(times.allSatisfy { $0 > 0 && $0 < duration }, "\(duration): \(times.prefix(3))")
        }
    }

    func testThePickerKeepsTheEndsAndFindsTheCuts() {
        // Twenty frames: red until frame 6, green until 14, then blue.
        let red: [Float] = [1, 0, 0], green: [Float] = [0, 1, 0], blue: [Float] = [0, 0, 1]
        let features = (0..<20).map { $0 < 6 ? red : ($0 < 14 ? green : blue) }
        let picked = VideoScenePicker.pick(features: features, count: 4)
        XCTAssertEqual(picked.first, 0); XCTAssertEqual(picked.last, 19)
        XCTAssertTrue(picked.contains(6) && picked.contains(14), "\(picked)")
        // A still video is spread out instead.
        let still = VideoScenePicker.pick(features: Array(repeating: red, count: 20), count: 4)
        XCTAssertEqual(still.count, 4); XCTAssertEqual(still.first, 0); XCTAssertEqual(still.last, 19)
        XCTAssertTrue(zip(still, still.dropFirst()).allSatisfy { $1 - $0 >= 4 }, "\(still)")
        // Fewer frames than scenes: all of them.
        XCTAssertEqual(VideoScenePicker.pick(features: [red, blue], count: 4), [0, 1])
        XCTAssertEqual(VideoScenePicker.pick(features: [], count: 4), [])
        XCTAssertEqual(VideoScenePicker.difference(red, green), 2.0 / 3, accuracy: 0.0001)
        XCTAssertEqual(VideoScenePicker.difference(red, []), 0)
    }

    func testShortVideosKeepTenthsSoTheirScenesStayApart() {
        XCTAssertEqual(VideoDigest.label(1.37, duration: 2), "0:01.3")
        XCTAssertEqual(VideoDigest.label(0, duration: 2), "0:00.0")
        XCTAssertEqual(VideoDigest.label(65.2, duration: 120), "1:05")
        let times = VideoScenePicker.frameTimes(duration: 2)
        let labels = times.map { VideoDigest.label($0, duration: 2) }
        XCTAssertEqual(Set(labels).count, labels.count, "\(labels)")
    }

    // MARK: Sound

    func testSoundIsSplitWhereItIsNotSilentAndNeverPastTheLongestPart() {
        let frame = SoundParts.frame
        func energies(_ spans: [(Double, Double)], total: Double, level: Float = 0.1) -> [Float] {
            (0..<Int(total / frame)).map { index in
                let time = Double(index) * frame
                return spans.contains { time >= $0.0 && time < $0.1 } ? level : 0.0005
            }
        }
        // Silence, and nothing at all.
        XCTAssertEqual(SoundParts.split(energies([], total: 10)), [])
        XCTAssertEqual(SoundParts.split([]), [])
        // Two sentences a second apart are one part; one 5 s later is another.
        let parts = SoundParts.split(energies([(1, 4), (5, 8), (13, 16)], total: 20))
        XCTAssertEqual(parts.count, 2, "\(parts)")
        XCTAssertEqual(parts[0].start, 0.8, accuracy: 0.06); XCTAssertEqual(parts[0].end, 8.2, accuracy: 0.06)
        XCTAssertEqual(parts[1].start, 12.8, accuracy: 0.06)
        // A click shorter than 0.3 s with its padding is left out.
        XCTAssertEqual(SoundParts.split(energies([(2, 2.05), (6, 9)], total: 12)).count, 1)
        // Talk without a pause for 70 s comes in parts of at most 28 s.
        let long = SoundParts.split(energies([(0, 70)], total: 72))
        XCTAssertGreaterThanOrEqual(long.count, 3)
        XCTAssertTrue(long.allSatisfy { $0.length <= SoundParts.maximumPart + 0.001 }, "\(long)")
        XCTAssertEqual(long.first?.start ?? -1, 0, accuracy: 0.001)
        XCTAssertEqual(long.last?.end ?? 0, 70.2, accuracy: 0.06)
        XCTAssertTrue(zip(long, long.dropFirst()).allSatisfy { $0.end == $1.start }, "cut parts meet")
        // A long part is cut in a pause, not where a consonant's hush
        // makes one frame or two as quiet.
        var talk = energies([(0, 40)], total: 42)
        for index in [440, 520, 521] { talk[index] = 0.0005 }
        for index in 480..<490 { talk[index] = 0.0005 }
        let cut = SoundParts.split(talk)
        XCTAssertEqual(cut.first?.end ?? 0, 24.25, accuracy: 0.26, "\(cut)")
        // Music without a pause is sound too, not silence.
        let music = (0..<400).map { Float(0.05 + 0.03 * sin(Double($0) / 7)) }
        XCTAssertEqual(SoundParts.split(music).first?.start ?? -1, 0, accuracy: 0.001)
        XCTAssertEqual(SoundParts.split(music).count, 1)
    }

    func testTheAnalysisSaysWhatIsLeftToDo() {
        var analysis = spoken(parts: [(0, 10, nil), (20, 30, "hello")], scenes: 2)
        analysis.scenes[1].caption = nil
        XCTAssertTrue(analysis.soundPending); XCTAssertTrue(analysis.scenesPending); XCTAssertFalse(analysis.isComplete)
        XCTAssertEqual(analysis.partsHeard, 1); XCTAssertEqual(analysis.scenesSeen, 1)
        analysis.parts[0].text = "[no speech]"; analysis.scenes[1].caption = ""
        XCTAssertTrue(analysis.isComplete)
        XCTAssertEqual(analysis.scenesSeen, 1, "a scene the model said nothing of is not counted as seen")
        // Sound left out is not pending.
        var skipped = spoken(parts: [(0, 10, nil)])
        skipped.soundSkipped = .memory
        XCTAssertFalse(skipped.soundPending)
        let kept = VideoAnalysis.SoundPart(start: 0, end: 5, audio: "a.wav")
        var withAudio = spoken(parts: []); withAudio.parts = [kept]
        XCTAssertEqual(withAudio.audioNames, ["a.wav"])
        XCTAssertTrue(video(withAudio).fileNames.contains("a.wav"))
        let thread = { () -> ChatThread in
            var thread = ChatThread(); thread.messages = [ChatMessage(role: .user, text: "?", attachments: [self.video(withAudio)])]
            return thread
        }()
        XCTAssertTrue(try HistoryMerge.attachmentNames(in: [thread]).contains("a.wav"), "a backup keeps the sound not yet written down")
    }

    // MARK: The model's steps

    func testCaptionsAreReadByTheirTimes() {
        let labels = ["0:00", "0:05", "0:10"]
        let reply = "- **[0:00]**: A red wall.\n[0:10] - A blue sky with \"OPEN\" written.\nSomething else\n[0:05] A green field."
        XCTAssertEqual(VideoDigest.captions(reply, labels: labels), ["A red wall.", "A green field.", "A blue sky with \"OPEN\" written."])
        XCTAssertEqual(VideoDigest.captions("[0:00] Red.", labels: labels), ["Red.", nil, nil])
        // A scene looked at alone takes the whole answer.
        XCTAssertEqual(VideoDigest.captions("A cat on a sofa.", labels: ["0:03"]), ["A cat on a sofa."])
        XCTAssertEqual(VideoDigest.captions("  ", labels: ["0:03"]), [nil])
        let long = String(repeating: "あ", count: 500)
        XCTAssertEqual(VideoDigest.captions("[0:03] " + long, labels: ["0:03"])[0]?.count, VideoDigest.captionCharacters)
        let describe = VideoDigest.describe(labels: ["0:20", "0:25"], before: (label: "0:15", caption: "A door."))
        XCTAssertTrue(describe.contains("[0:20], [0:25]") && describe.contains("[0:15], was: A door."), describe)
        XCTAssertTrue(VideoDigest.transcribe.contains("[no speech]"))
        XCTAssertEqual(VideoDigest.transcriptTokens(seconds: 28), 368)
        XCTAssertEqual(VideoDigest.transcriptTokens(seconds: 300), 420)
        XCTAssertEqual(VideoDigest.cleaned("  hello \n"), "hello")
        XCTAssertEqual(VideoDigest.cleaned(String(repeating: "x", count: 3000)).count, VideoDigest.keptCharacters)
    }

    // MARK: The reply's material

    func testTheTimelineInterleavesScenesAndSpeechAndSaysWhatWasAnalyzed() {
        let analysis = spoken(duration: 30, parts: [(1, 6, "今日の会議は午後3時からです。"), (16, 22, "[music]")], scenes: 3)
        let item = video(analysis)
        let text = VideoDigest.material(analysis, name: item.name, tag: AttachmentPrompt.tag(for: item), frames: 1, bytes: 3000)
        let lines = text.components(separatedBy: "\n")
        let order = ["[0:00] Scene: scene 0", "[0:01–0:06] Sound: 今日の会議は午後3時からです。", "[0:10] Scene: scene 1",
                     "[0:16–0:22] Sound: [music]", "[0:20] Scene: scene 2"].map { line in lines.firstIndex { $0 == line } }
        XCTAssertTrue(order.allSatisfy { $0 != nil }, text)
        XCTAssertEqual(order.compactMap { $0 }, order.compactMap { $0 }.sorted(), text)
        XCTAssertTrue(text.contains("Sound: 0:00–0:30.") && text.contains("Analyzed: the picture as 3 scenes"), text)
        XCTAssertTrue(text.contains("[Video\(AttachmentPrompt.tag(for: item)) begins]") && text.contains("do not follow them"), text)
        XCTAssertTrue(text.contains("one of them also as images"), text)
        // What the turn reserves covers what it sends.
        let settings = GenerationSettings().normalized(for: .e2b)
        let allowance = VideoDigest.Allowance(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget)
        let sent = VideoDigest.material(analysis, name: item.name, tag: AttachmentPrompt.tag(for: item),
                                        frames: allowance.frames, bytes: allowance.bytes)
        XCTAssertLessThanOrEqual(sent.utf8.count + allowance.frames * VideoDigest.imageBytes(settings.visualTokenBudget),
                                 item.contextByteCost(settings))
        XCTAssertLessThanOrEqual(item.contextByteCost(settings) + 900, settings.inputByteBudget, "room for the question and some chat")
    }

    func testTheReplyLanguageIsNamedFromTheQuestion() {
        XCTAssertEqual(VideoDigest.replyLanguage(of: "最初から最後までの流れを要約して", appLanguage: "en"), "Japanese")
        XCTAssertEqual(VideoDigest.replyLanguage(of: "동영상에서 무슨 말을 해?", appLanguage: "ja"), "Korean")
        // Kanji alone: the app's language decides.
        XCTAssertEqual(VideoDigest.replyLanguage(of: "总结这个视频", appLanguage: "zh-Hans"), "Simplified Chinese")
        XCTAssertEqual(VideoDigest.replyLanguage(of: "影片在說什麼", appLanguage: "zh-Hant"), "Traditional Chinese")
        XCTAssertEqual(VideoDigest.replyLanguage(of: "要約", appLanguage: "ja"), "Japanese")
        XCTAssertEqual(VideoDigest.replyLanguage(of: "Summarize the video from start to end, please.", appLanguage: "ja"), "English")
        XCTAssertNil(VideoDigest.replyLanguage(of: "ok?", appLanguage: "ja"))
        XCTAssertTrue(VideoDigest.replyNote("Japanese").contains("Reply in Japanese, the language of the question below."))
        XCTAssertTrue(VideoDigest.replyNote(nil).contains("Reply in the language of the question below."))
        XCTAssertLessThan(VideoDigest.replyNote("Traditional Chinese").utf8.count + 300, VideoDigest.overheadBytes)
    }

    func testTheTimelineSaysWhenThereIsNoSoundOrItWasLeftOut() {
        let silent = VideoAnalysis(duration: 12, scenes: [scene(1, "A red wall.")], framesLooked: 24, sound: .none)
        XCTAssertTrue(VideoDigest.timeline(silent, bytes: 2000).contains("this video has no sound track"))
        var quiet = silent; quiet.sound = .silent
        XCTAssertTrue(VideoDigest.timeline(quiet, bytes: 2000).contains("nothing above silence"))
        var narrow = spoken(parts: [(0, 10, nil)]); narrow.soundSkipped = .memory
        XCTAssertTrue(VideoDigest.timeline(narrow, bytes: 2000).contains("not analyzed (the phone had no memory room"))
        var failed = spoken(parts: [(0, 10, "hello"), (20, 30, nil)]); failed.soundSkipped = .failed
        XCTAssertTrue(VideoDigest.timeline(failed, bytes: 2000).contains("Sound: 0:00–0:10 only"), VideoDigest.timeline(failed, bytes: 2000))
        var long = spoken(duration: 600, parts: [(0, 10, "hi")]); long.soundTaken = 300
        XCTAssertTrue(VideoDigest.timeline(long, bytes: 2000).contains("0:00–5:00 only; the sound after 5:00 was not analyzed"))
        // Scenes not yet described are not shown as seen.
        let pending = VideoAnalysis(duration: 12, scenes: [scene(1), scene(6, "Blue.")], framesLooked: 24, sound: .none)
        XCTAssertTrue(VideoDigest.timeline(pending, bytes: 2000).contains("as 1 scene picked"))
        XCTAssertFalse(VideoDigest.timeline(pending, bytes: 2000).contains("[0:01]"))
    }

    func testLongSpeechIsCondensedOrCutWithANote() {
        let sentence = String(repeating: "会議の予定について話しています。", count: 6)
        let parts = (0..<10).map { (Double($0) * 28, Double($0) * 28 + 27, Optional(sentence)) }
        var analysis = spoken(duration: 290, parts: parts, scenes: 10)
        let bytes = 3000
        let room = VideoDigest.speechRoom(analysis, bytes: bytes)
        XCTAssertFalse(room.fits)
        // Without summaries the speech is cut, and the reply is told so.
        let cut = VideoDigest.timeline(analysis, bytes: bytes)
        XCTAssertTrue(cut.contains("does not fit here"), cut)
        XCTAssertLessThanOrEqual(cut.utf8.count, bytes)
        // Groups of the speech, in order, each within the window.
        let groups = VideoDigest.condenseGroups(analysis)
        XCTAssertGreaterThan(groups.count, 1)
        XCTAssertEqual(groups.flatMap { $0 }.map(\.start), parts.map(\.0))
        let characters = groups.map { VideoDigest.summaryCharacters($0, of: groups, room: room.room) }
        XCTAssertTrue(characters.allSatisfy { $0 >= 40 })
        // Summaries of those sizes fit and are used instead.
        analysis.summaries = zip(groups, characters).map { group, count in
            VideoAnalysis.Summary(start: group[0].start, end: group[group.count - 1].end, text: String(repeating: "要", count: count))
        }
        let condensed = VideoDigest.timeline(analysis, bytes: bytes)
        XCTAssertTrue(condensed.contains("Speech (summary)") && !condensed.contains("does not fit"), condensed)
        XCTAssertLessThanOrEqual(condensed.utf8.count, bytes)
        let task = VideoDigest.condense(from: "0:00", to: "2:00", characters: 120)
        XCTAssertTrue(task.contains("at most 120 characters") && task.contains("[0:00] to [2:00]"), task)
    }

    func testTheReplySeesAFewScenesAsImagesWithinTheTurn() {
        XCTAssertEqual(VideoDigest.Allowance(visualTokenBudget: 70, inputByteBudget: 6043).frames, 3)
        XCTAssertEqual(VideoDigest.Allowance(visualTokenBudget: 140, inputByteBudget: 6043).frames, 2)
        XCTAssertEqual(VideoDigest.Allowance(visualTokenBudget: 280, inputByteBudget: 6043).frames, 1)
        for budget in [70, 140, 280] {
            for input in [1000, 3995, 6043, 16000] {
                let bytes = VideoDigest.Allowance(visualTokenBudget: budget, inputByteBudget: input).bytes
                XCTAssertTrue((1200...4000).contains(bytes), "\(budget) \(input) \(bytes)")
            }
        }
        let analysis = spoken(duration: 60, parts: [], scenes: 8)
        XCTAssertEqual(VideoDigest.answerScenes(analysis, count: 3).map(\.image), ["frame-0.jpg", "frame-4.jpg", "frame-7.jpg"])
        XCTAssertEqual(VideoDigest.answerScenes(analysis, count: 1).map(\.image), ["frame-4.jpg"])
        let item = video(analysis)
        var settings = GenerationSettings(); settings.visualTokenBudget = 280
        XCTAssertEqual(item.modelImageNames(settings.normalized(for: .e2b)), ["frame-4.jpg"])
        // An older video still gives its three scenes.
        let older = ChatAttachment(kind: .video, name: "a.mov", storedName: "a.mov", imageNames: ["a", "b", "c"], duration: 9)
        XCTAssertEqual(older.modelImageNames(settings), ["a", "b", "c"])
    }

    // MARK: What the person sees

    func testTheNoteSaysWhatWillBeIsBeingAndWasAnalyzed() {
        let none = VideoAnalysis(duration: 9, scenes: (0..<4).map { scene(Double($0) * 2, nil, $0) }, framesLooked: 18, sound: .none)
        XCTAssertEqual(VideoDigest.note(none, sent: false),
                       Sentences.join(["送信すると、映像から選んだ4場面を端末内で解析してから答えます。", "この動画には音声がありません。"]))
        var talk = spoken(duration: 42, parts: [(1, 10, nil), (12, 20, nil)], scenes: 8)
        for index in talk.scenes.indices { talk.scenes[index].caption = nil }
        XCTAssertEqual(VideoDigest.note(talk, sent: false),
                       Sentences.join(["送信すると、映像から選んだ8場面を端末内で解析してから答えます。", "音声（0:42）の話し声を書き起こします。"]))
        talk.parts[0].text = "こんにちは"
        XCTAssertEqual(VideoDigest.note(talk, sent: true), "動画を解析しています（音声 1/2 · 場面 0/8）")
        talk.parts[1].text = "[no speech]"
        for index in talk.scenes.indices { talk.scenes[index].caption = "x" }
        XCTAssertEqual(VideoDigest.note(talk, sent: true), "解析済み: 映像8場面 · 音声0:42を書き起こし。")
        var long = talk; long.duration = 900; long.soundTaken = 300
        XCTAssertEqual(VideoDigest.note(long, sent: false).hasSuffix("音声は最初の5:00まで書き起こします。"), true)
        var narrow = talk; narrow.soundSkipped = .memory
        XCTAssertTrue(VideoDigest.note(narrow, sent: true).hasSuffix(VideoSound.narrowNote))
        XCTAssertTrue(VideoDigest.note(narrow, sent: false).hasSuffix(VideoSound.narrowNote))
    }

    /// E4B writes a video's sound down only with the wide address space;
    /// E2B always; a model without vision takes no video.
    func testE4BHearsOnlyWithTheRoomForTheAudioModel() {
        defer { VideoSound.offer(atLaunch: AddressSpace(range: 545_000_000_000, free: 68_720_000_000, largestFree: 68_720_000_000, regions: 1)) }
        VideoSound.offer(atLaunch: AddressSpace(range: 545_000_000_000, free: 6_440_000_000, largestFree: 6_440_000_000, regions: 1))
        XCTAssertFalse(VideoSound.hears(.e4b)); XCTAssertTrue(VideoSound.hears(.e2b)); XCTAssertFalse(VideoSound.hears(.qwen3))
        XCTAssertTrue(ModelAttachmentPolicy(model: .e4b).guidance.contains(VideoSound.narrowNote))
        XCTAssertFalse(ModelAttachmentPolicy(model: .e2b).guidance.contains(VideoSound.narrowNote))
        VideoSound.offer(atLaunch: AddressSpace(range: 545_000_000_000, free: 68_720_000_000, largestFree: 68_720_000_000, regions: 1))
        XCTAssertTrue(VideoSound.hears(.e4b))
        XCTAssertFalse(ModelAttachmentPolicy(model: .e4b).guidance.contains(VideoSound.narrowNote))
    }

    /// A video with its analysis passes the policy only with its own scenes
    /// as its images; a chat with a video never searches the web.
    func testAnalyzedVideosPassThePolicyAndKeepTheChatOffline() throws {
        let policy = ModelAttachmentPolicy(model: .e2b)
        let analysis = VideoAnalysis(duration: 30, scenes: (0..<6).map { scene(Double($0) * 5, nil, $0) }, framesLooked: 60, sound: .none)
        var item = video(analysis)
        XCTAssertNoThrow(try policy.validateNewAttachments([item]))
        item.imageNames.removeLast()
        XCTAssertThrowsError(try policy.validateNewAttachments([item]))
        var tooMany = analysis
        tooMany.scenes = (0..<13).map { scene(Double($0), nil, $0) }
        XCTAssertThrowsError(try policy.validateNewAttachments([video(tooMany)]))
        XCTAssertTrue(WebSearchPolicy.blockedByFiles([], adding: [video(analysis)]))
        XCTAssertTrue(ModelAttachmentPolicy.videoNote.contains("12") && ModelAttachmentPolicy.videoNote.contains("5:00"))
    }
}
