import XCTest
@testable import PocketCore

final class ReplyResumeTests: XCTestCase {
    func testShortReplyIsGivenBackWholeAfterTheRenderedQuestion() {
        let parts = OpenTurn.parts(prompt: "質問", reply: "もし、あなたが**実際にそのような", settings: GenerationSettings())
        XCTAssertEqual(parts.question, "質問")
        XCTAssertEqual(parts.tail, "もし、あなたが**実際にそのような")
        let prompt = OpenTurn.prompt(renderedQuestion: "<turn>user\n質問<end>\n<turn>model\n", tail: parts.tail)
        XCTAssertEqual(prompt, "<turn>user\n質問<end>\n<turn>model\nもし、あなたが**実際にそのような",
                       "Nothing follows the reply's last character")
    }

    func testLongReplyGivesBackItsEndWithinTheInputBudget() {
        let settings = GenerationSettings()
        let reply = (1...400).map { "\($0). 日本語の説明がここに続きます。" }.joined(separator: "\n") + "\n401. 途中で"
        let parts = OpenTurn.parts(prompt: String(repeating: "長い質問", count: 500), reply: reply, settings: settings)
        XCTAssertTrue(parts.tail.hasSuffix("401. 途中で"))
        XCTAssertTrue(parts.tail.first.map { $0.isNumber } ?? false, "The tail starts on a whole line: \(parts.tail.prefix(20))")
        XCTAssertLessThanOrEqual(parts.tail.utf8.count, OpenTurn.tailBytes)
        XCTAssertLessThanOrEqual(parts.question.utf8.count, settings.maxTokens / 4)
        XCTAssertLessThanOrEqual(parts.question.utf8.count + parts.tail.utf8.count, settings.inputByteBudget)
    }

    func testInTheBackgroundTheReplyIsReadBackShorter() {
        let settings = GenerationSettings()
        let reply = (1...400).map { "\($0). 日本語の説明がここに続きます。" }.joined(separator: "\n") + "\n401. 途中で"
        let full = OpenTurn.parts(prompt: "質問", reply: reply, settings: settings)
        let short = OpenTurn.parts(prompt: "質問", reply: reply, settings: settings, tailLimit: BackgroundRead.tailBytes)
        XCTAssertLessThanOrEqual(short.tail.utf8.count, BackgroundRead.tailBytes)
        XCTAssertLessThan(short.tail.utf8.count, full.tail.utf8.count)
        XCTAssertTrue(short.tail.hasSuffix("401. 途中で"), "It still goes on from the last character")
        XCTAssertTrue(short.tail.first.map { $0.isNumber } ?? false, "From the start of a line: \(short.tail.prefix(20))")
        XCTAssertEqual(short.question, full.question)
        XCTAssertEqual(BackgroundRead.historyBudget(settings), settings.inputByteBudget / 4)
        XCTAssertGreaterThan(BackgroundRead.historyBudget(settings), 0)
    }

    func testAReplyStoppedInsideACodeBlockKeepsItsFence() {
        let code = (1...300).map { "    print(\"line \($0)\")" }.joined(separator: "\n")
        let reply = "説明です。\n```python\n" + code
        let parts = OpenTurn.parts(prompt: "コードを書いて", reply: reply, settings: GenerationSettings())
        XCTAssertTrue(parts.tail.hasPrefix("```python\n"), String(parts.tail.prefix(30)))
        XCTAssertTrue(parts.tail.hasSuffix("print(\"line 300\")"))
    }

    func testTheRawTemplateOnlyWritesMessageText() {
        let template = OpenTurn.rawTemplate
        XCTAssertFalse(template.contains("add_generation_prompt"), "The model's own turn is already open")
        XCTAssertFalse(template.contains("\n{{"), "No line break of its own reaches the prompt")
        XCTAssertTrue(template.contains("extra_context.message"))
        XCTAssertTrue(template.contains("for message in messages"))
    }

    func testNoticePreviewIsPlainText() {
        let reply = """
        ## 通学中の注意

        **まず**、あなたの`安全`が一番大切です。
        - 学校の先生に相談する
        | 窓口 | 電話 |
        | --- | --- |
        | 相談ダイヤル | 0120 |
        ```swift
        let secret = 1
        ```
        $$
        x^2
        $$
        """
        let preview = ReplyNotice.preview(of: reply, limit: 200)
        XCTAssertEqual(preview, "通学中の注意 まず、あなたの安全が一番大切です。 学校の先生に相談する 窓口 電話 相談ダイヤル 0120")
        XCTAssertFalse(preview.contains("secret"))
        XCTAssertFalse(preview.contains("x^2"))
    }

    func testNoticePreviewIsCutShort() {
        let preview = ReplyNotice.preview(of: String(repeating: "あ", count: 300), limit: 90)
        XCTAssertEqual(preview.count, 91)
        XCTAssertTrue(preview.hasSuffix("…"))
        XCTAssertEqual(ReplyNotice.preview(of: ""), "")
    }

    func testProgressRisesWithEveryCharacterAndLeavesTheEndForTheFinish() {
        XCTAssertEqual(ReplyNotice.progressUnits(characters: 0), 0)
        var last: Int64 = 0
        for characters in [1, 10, 100, 500, 1000, 3000, 10000, 100_000] {
            let units = ReplyNotice.progressUnits(characters: characters)
            XCTAssertGreaterThan(units, last, "\(characters)")
            XCTAssertLessThan(units, 1000)
            last = units
        }
        XCTAssertLessThanOrEqual(ReplyNotice.progressUnits(characters: .max / 2), 950)
    }
}
