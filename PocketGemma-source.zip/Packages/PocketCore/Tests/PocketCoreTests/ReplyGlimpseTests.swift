import XCTest
@testable import PocketCore

/// The Aurora Orb's glimpse of the reply (ReplyGlimpse, 1.1.0 (297)): which
/// words it may show, when it shows them, and when the orb leaves. A model is
/// played in at a given speed, its text arriving in 45 ms batches as the
/// store delivers it, and the glimpse is stepped as the row steps it: on each
/// change and at the moment it asked to be woken. GLIMPSE-NOTE lines in the
/// log carry the numbers.
final class ReplyGlimpseTests: XCTestCase {
    private typealias Arrival = (at: TimeInterval, text: String)

    private struct Playback {
        var phrase: String?
        var shownAt: TimeInterval?
        var leftAt: TimeInterval?
        var firstAt: TimeInterval?
        var phrases: Set<String> = []
    }

    private static let long = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。ただし、まだ誤りが多く、実用化には時間がかかると考えられています。"

    /// `text` written at `rate` characters a second from `start`.
    private func steady(_ text: String, rate: Double, from start: TimeInterval = 0) -> [Arrival] {
        var arrivals: [Arrival] = []
        var at = start
        var owed = 0.0
        var rest = Substring(text)
        while !rest.isEmpty {
            owed += rate * 0.045
            let count = min(Int(owed), rest.count)
            owed -= Double(count)
            if count > 0 {
                arrivals.append((at, String(rest.prefix(count))))
                rest = rest.dropFirst(count)
            }
            at += 0.045
        }
        return arrivals
    }

    /// Steps a glimpse as the row does, with the model writing until `end`
    /// (the last arrival when nil).
    private func play(_ arrivals: [Arrival], end: TimeInterval? = nil, until: TimeInterval = 6) -> Playback {
        let glimpse = ReplyGlimpse()
        let end = end ?? (arrivals.last?.at ?? 0)
        var playback = Playback()
        var pending = arrivals
        var text = ""
        var wake: TimeInterval?
        var wasGenerating = true
        var now = 0.0
        while now < until, playback.leftAt == nil {
            var changed = false
            while let next = pending.first, next.at <= now + 1e-9 {
                text += next.text
                pending.removeFirst()
                changed = true
            }
            let generating = now < end - 1e-9
            if !text.isEmpty, playback.firstAt == nil { playback.firstAt = now }
            if changed || generating != wasGenerating || (wake.map { now >= $0 } ?? false) {
                switch glimpse.step(text: text, generating: generating, now: now) {
                case .leave: playback.leftAt = now
                case .wait(let until): wake = until
                }
                if let phrase = glimpse.phrase {
                    if playback.shownAt == nil { playback.shownAt = glimpse.shownAt }
                    playback.phrase = phrase
                    playback.phrases.insert(phrase)
                }
            }
            wasGenerating = generating
            now += 1.0 / 60
        }
        return playback
    }

    private func note(_ name: String, _ playback: Playback) {
        let first = playback.firstAt ?? 0
        print(String(format: "GLIMPSE-NOTE %@: phrase at %.2f s, orb leaves at %.2f s after the first text, phrase %@",
                     name, (playback.shownAt ?? first - 1) - first, (playback.leftAt ?? first - 1) - first,
                     playback.phrase ?? "-"))
    }

    // MARK: Words

    func testProseLeavesOutMarksCodeFormulasTablesAndAddresses() {
        let text = """
        ## 量子コンピュータとは
        **量子ビット**を使う、*新しい*計算機です。詳しくは[解説](https://example.com/q)を見てください。
        - `qubit` は 0 と 1 を同時に持てます。
        > 引用の文です。
        ```swift
        let secret = "コードの中"
        ```
        | 項目 | 内容 |
        |---|---|
        $$
        E = mc^2
        $$
        式 $x^2 + y^2 = r^2$ は円です。![図](https://example.com/a.png)注[^1]<br>https://example.com/page を参照。
        """
        let lines = ReplyGlimpseText.prose(text).split(separator: "\n", omittingEmptySubsequences: false).map(String.init)
        XCTAssertEqual(lines[0], "量子コンピュータとは")
        XCTAssertEqual(lines[1], "量子ビットを使う、新しい計算機です。詳しくは解説を見てください。")
        XCTAssertEqual(lines[2], "qubit は 0 と 1 を同時に持てます。")
        XCTAssertEqual(lines[3], "引用の文です。")
        let prose = lines.joined(separator: "\n")
        for hidden in ["コードの中", "secret", "項目", "mc^2", "x^2", "example.com", "図", "[^1]", "<br>", "**", "`", "##"] {
            XCTAssertFalse(prose.contains(hidden), "\(hidden) must not show: \(prose)")
        }
        XCTAssertTrue(prose.contains("式 は円です。"), prose)
        XCTAssertTrue(prose.contains("注 を参照。") || prose.contains("注を参照。"), prose)
    }

    func testAThoughtNeverShows() {
        XCTAssertEqual(ReplyGlimpseText.prose("<think>ユーザーは秘密を聞いている</think>答えは42です。"), "答えは42です。")
        XCTAssertEqual(ReplyGlimpseText.prose("<think>まだ考えている途中"), "")
        XCTAssertEqual(ReplyGlimpseText.prose("考えの続き</think>答えです。"), "答えです。")
        XCTAssertEqual(ReplyGlimpseText.prose("<THINKING>x</THINKING>はい。"), "はい。")
        // Streamed a few characters at a time, a tag reads as markup at its
        // first character and the orb leaves as it did; in one piece, the
        // thought is passed over and the answer after it shows.
        let streamed = steady("<think>ユーザーは秘密を聞いている。どう答えるか考える。</think>答えは四十二です。理由を説明します。", rate: 40)
        let inOne: [Arrival] = [(0, "<think>ユーザーは秘密を聞いている。どう答えるか考える。"), (0.3, "</think>答えは四十二です。"), (0.6, "理由を説明します。")]
        for arrivals in [streamed, inOne] {
            let playback = play(arrivals, end: 3)
            for phrase in playback.phrases {
                XCTAssertFalse(phrase.contains("秘密") || phrase.contains("考える") || phrase.contains("think"), phrase)
            }
        }
        XCTAssertEqual(play(inOne, end: 3).phrase, "答えは四十二です。")
        XCTAssertEqual(ReplyGlimpseText.opening("<think>考え中"), .undecided)
    }

    func testClausesJoinShortOnesAndPhrasesCutAtWords() {
        let clauses = ReplyGlimpseText.clauses("量子コンピュータは、量子ビットを")
        XCTAssertEqual(clauses, [.init(text: "量子コンピュータは、", complete: true), .init(text: "量子ビットを", complete: false)])
        XCTAssertEqual(ReplyGlimpseText.phrase(clauses, partial: false), "量子コンピュータは、")
        // はい、 is too short alone: it joins what follows.
        XCTAssertEqual(ReplyGlimpseText.clauses("はい、できます。どうぞ"),
                       [.init(text: "はい、できます。", complete: true), .init(text: "どうぞ", complete: false)])
        // A closing bracket stays with its sentence.
        XCTAssertEqual(ReplyGlimpseText.clauses("「こんにちは、世界。」と書きます")[0].text, "「こんにちは、世界。」")
        // Words still being written: up to a particle in Japanese, a space elsewhere.
        XCTAssertNil(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("量子コンピュ"), partial: true))
        XCTAssertEqual(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("量子コンピュータは"), partial: true), "量子コンピュータは…")
        XCTAssertEqual(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("量子ビットという仕組みを使っ"), partial: true), "量子ビットという仕組みを…")
        XCTAssertNil(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("ゆっく"), partial: true), "Inside a word of kana")
        XCTAssertEqual(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("たくさんの計算を同時に進め"), partial: true), "たくさんの計算を同時に…")
        XCTAssertEqual(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("Quantum computers use qub"), partial: true), "Quantum computers use…")
        XCTAssertNil(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses("量子コンピュータは"), partial: false))
        // A heading's line has ended: it is a whole clause.
        XCTAssertEqual(ReplyGlimpseText.phrase(ReplyGlimpseText.clauses(ReplyGlimpseText.prose("## 量子コンピュータとは\n\n**量子")), partial: false),
                       "量子コンピュータとは")
        // One line of the glimpse at most.
        let long = ReplyGlimpseText.phrase([.init(text: String(repeating: "あ", count: 60) + "。", complete: true)], partial: false)
        XCTAssertEqual(long?.count, ReplyGlimpseText.longestPhrase + 1)
        XCTAssertEqual(long?.last, "…")
    }

    func testCodeTablesFormulasAndPicturesAreLeftToTheReply() {
        for start in ["```swift\nlet x = 1", "~~~\ncode", "| 項目 | 内容 |", "$$\nE = mc^2", "\\[ x \\]", "![図](a.png)", "<div>"] {
            XCTAssertEqual(ReplyGlimpseText.opening(start), .other, start)
        }
        for start in ["", "\n", "  ", "##", "**", "- ", "`"] {
            XCTAssertEqual(ReplyGlimpseText.opening(start), .undecided, start)
        }
        for start in ["## 見出し", "**太字**", "- 項目です", "こんにちは", "1. 最初に"] {
            XCTAssertEqual(ReplyGlimpseText.opening(start), .prose, start)
        }
        // The orb leaves at the first text, as it did.
        // The orb leaves as soon as the fence is whole ("`" alone could
        // still be inline code), a few hundredths of a second after it did.
        let code = play(steady("```swift\nlet x = 1\n```\nこれはコードです。", rate: 28))
        XCTAssertNil(code.phrase)
        XCTAssertLessThanOrEqual((code.leftAt ?? 10) - (code.firstAt ?? 0), 0.15)
    }

    func testThePhraseIsAlwaysTheRepliesOwnWords() {
        let replies = [Self.long, "## 量子コンピュータとは\n\n**量子ビット**を使って計算する新しいコンピュータです。",
                       "Quantum computers use qubits, which can hold many states at once.",
                       "1. **準備**：材料をそろえます。\n2. 次に、[手順](https://example.com)を確認します。",
                       "はい、できます。", "式 $a+b=c$ を使うと、答えが出ます。"]
        for reply in replies {
            for rate in [14.0, 28.0, 55.0, 90.0] {
                let playback = play(steady(reply, rate: rate))
                let prose = ReplyGlimpseText.prose(reply).replacingOccurrences(of: "\n", with: " ")
                for phrase in playback.phrases {
                    let words = phrase.hasSuffix("…") ? String(phrase.dropLast()) : phrase
                    XCTAssertTrue(prose.contains(words), "\(phrase) is not in \(prose)")
                }
            }
        }
    }

    // MARK: Timing

    func testAPhraseShowsSoonAndTheOrbLeavesBeforeTwoSeconds() {
        for rate in [14.0, 28.0, 55.0, 90.0] {
            // The model writes on past the glimpse (a long reply).
            let playback = play(steady(Self.long, rate: rate, from: 1), end: 10)
            note("long reply \(Int(rate)) chars/s", playback)
            guard let first = playback.firstAt, let shown = playback.shownAt, let left = playback.leftAt else {
                XCTFail("\(rate): a phrase must show and the orb must leave"); continue
            }
            XCTAssertLessThan(shown - first, ReplyGlimpse.patience, "\(rate): the phrase shows soon after the first words")
            // Its hold, cut short by the latest the orb may stay, never below its shortest.
            let read = min(ReplyGlimpse.hold, max(ReplyGlimpse.latest - (shown - first), ReplyGlimpse.shortest))
            XCTAssertGreaterThanOrEqual(left - shown, read - 0.02, "\(rate): the phrase has time to be read")
            XCTAssertLessThanOrEqual(left - first, ReplyGlimpse.latest + 0.05, "\(rate): the orb leaves in time for the text to begin about two seconds behind")
            XCTAssertNotNil(playback.phrase?.first { $0.isLetter }, "\(rate)")
        }
    }

    func testAReplyThatEndsIsNotKeptBack() {
        // Over before a phrase could show (はい、 is too short to show alone):
        // the orb leaves when it ends.
        let short = play(steady("はい、", rate: 28, from: 1), end: 1.2)
        note("short reply", short)
        XCTAssertNil(short.phrase)
        XCTAssertEqual(short.leftAt ?? 0, 1.2, accuracy: 0.02)
        // Ended while its phrase shows: the phrase stays its shortest, and
        // no longer than that or the reply's end.
        let line = steady("こんにちは！今日はどんなお手伝いをしましょうか？", rate: 28, from: 1)
        let mid = play(line)
        note("one-line reply", mid)
        guard let shown = mid.shownAt, let left = mid.leftAt, let end = line.last?.at else { XCTFail("A phrase must show"); return }
        XCTAssertGreaterThanOrEqual(left - shown, ReplyGlimpse.shortest - 0.02)
        XCTAssertLessThanOrEqual(left, max(shown + ReplyGlimpse.shortest, end) + 0.03)
    }

    func testNothingToReadLetsTheOrbGo() {
        let marks = play([(1, "##")], end: 5)
        XCTAssertNil(marks.phrase)
        XCTAssertEqual((marks.leftAt ?? 0) - 1, ReplyGlimpse.patience, accuracy: 0.03)
        let glimpse = ReplyGlimpse()
        XCTAssertEqual(glimpse.step(text: "", generating: true, now: 0), .wait(until: nil))
        _ = glimpse.step(text: "```", generating: true, now: 1)
        XCTAssertEqual(glimpse.step(text: "```\nこんにちは。とても長い文章です。", generating: true, now: 1.1), .leave,
                       "Once let go, the orb is not called back")
    }

    func testSlowMotionStretchesEveryTime() {
        let glimpse = ReplyGlimpse(timeScale: 4)
        XCTAssertEqual(glimpse.step(text: "量子コンピュータは、", generating: true, now: 0), .wait(until: ReplyGlimpse.hold * 4))
        XCTAssertEqual(glimpse.phrase, "量子コンピュータは、")
    }

    // MARK: Motion

    func testTheLookComesAndGoesSmoothly() {
        let start = ReplyGlimpseMotion.look(sinceShown: 0, sinceLeaving: nil, reduced: false)
        XCTAssertEqual(start.opacity, 0)
        XCTAssertEqual(start.offset, ReplyGlimpseMotion.rise)
        XCTAssertEqual(start.blur, ReplyGlimpseMotion.softBlur)
        let rest = ReplyGlimpseMotion.look(sinceShown: ReplyGlimpseMotion.appear, sinceLeaving: nil, reduced: false)
        XCTAssertEqual(rest, .init(opacity: 1, blur: ReplyGlimpseMotion.restingBlur, offset: 0))
        let gone = ReplyGlimpseMotion.look(sinceShown: 2, sinceLeaving: ReplyGlimpseMotion.disappear, reduced: false)
        XCTAssertEqual(gone.opacity, 0, accuracy: 1e-9)
        XCTAssertEqual(gone.offset, -ReplyGlimpseMotion.drift, accuracy: 1e-9)
        // Steadily: no frame brighter than the next while it comes, none
        // brighter than the one before while it goes.
        var previous = -1.0
        for frame in 0...36 {
            let look = ReplyGlimpseMotion.look(sinceShown: Double(frame) / 60, sinceLeaving: nil, reduced: false)
            XCTAssertGreaterThanOrEqual(look.opacity, previous)
            previous = look.opacity
        }
        for frame in 0...27 {
            let look = ReplyGlimpseMotion.look(sinceShown: 2, sinceLeaving: Double(frame) / 60, reduced: false)
            XCTAssertLessThanOrEqual(look.opacity, previous + 1e-9)
            previous = look.opacity
        }
        // Leaving before it has fully come: it fades from where it is.
        let early = ReplyGlimpseMotion.look(sinceShown: 0.2, sinceLeaving: 0, reduced: false)
        XCTAssertEqual(early.opacity, ReplyGlimpseMotion.look(sinceShown: 0.2, sinceLeaving: nil, reduced: false).opacity, accuracy: 1e-9)
        // Reduce Motion: it only fades, quickly.
        for time in stride(from: 0.0, through: 1.0, by: 0.05) {
            let look = ReplyGlimpseMotion.look(sinceShown: time, sinceLeaving: time > 0.5 ? time - 0.5 : nil, reduced: true)
            XCTAssertEqual(look.offset, 0)
            XCTAssertEqual(look.blur, ReplyGlimpseMotion.restingBlur)
        }
        XCTAssertEqual(ReplyGlimpseMotion.look(sinceShown: ReplyGlimpseMotion.appearReduced, sinceLeaving: nil, reduced: true).opacity, 1)
        XCTAssertTrue(ReplyGlimpseMotion.moving(sinceShown: 0.3, sinceLeaving: nil, reduced: false))
        XCTAssertFalse(ReplyGlimpseMotion.moving(sinceShown: 0.7, sinceLeaving: nil, reduced: false))
        XCTAssertTrue(ReplyGlimpseMotion.moving(sinceShown: 2, sinceLeaving: 0.1, reduced: false))
        XCTAssertFalse(ReplyGlimpseMotion.moving(sinceShown: 2, sinceLeaving: 0.5, reduced: false))
    }

    func testReadingTheReplyStaysCheap() {
        // The most a row reads: its reply's beginning, at each change until a
        // phrase shows (a handful of times; 120 here, up to the read limit).
        let text = String(repeating: Self.long + "\n\n**太字**と[リンク](https://example.com)と`コード`。\n", count: 40)
        let prefixes = (0..<120).map { String(text.prefix($0 * 8 + 8)) }
        let start = Date()
        for prefix in prefixes {
            _ = ReplyGlimpseText.opening(prefix)
            _ = ReplyGlimpseText.phrase(ReplyGlimpseText.clauses(ReplyGlimpseText.prose(prefix)), partial: true)
        }
        _ = ReplyGlimpse().step(text: text, generating: true, now: 0)
        let elapsed = Date().timeIntervalSince(start)
        print(String(format: "GLIMPSE-PERF 120 readings %.1f ms (%.3f ms each)", elapsed * 1000, elapsed * 1000 / 120))
        XCTAssertLessThan(elapsed, 0.5, "Reading the beginning of a reply must take next to no time")
    }
}
