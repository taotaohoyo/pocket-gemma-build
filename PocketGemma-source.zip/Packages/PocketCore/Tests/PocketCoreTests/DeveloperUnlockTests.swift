import XCTest
@testable import PocketCore

/// Gemma 4 12B for developers (1.1.0 (200)): usable only with 開発者設定 on
/// and its password entered, on the GPU only. The public tests never hold
/// the password: they check the derivation against the standard vectors,
/// that other passwords fail, and what the unlock changes.
final class DeveloperUnlockTests: XCTestCase {
    private var saved: [String: Any?] = [:]

    override func setUp() {
        super.setUp()
        for key in [DeveloperUnlock.developerSettingsKey, DeveloperUnlock.storageKey] {
            saved[key] = UserDefaults.standard.object(forKey: key)
        }
        UserDefaults.standard.set(false, forKey: DeveloperUnlock.developerSettingsKey)
        DeveloperUnlock.lock()
    }

    override func tearDown() {
        for (key, value) in saved {
            if let value { UserDefaults.standard.set(value, forKey: key) } else { UserDefaults.standard.removeObject(forKey: key) }
        }
        super.tearDown()
    }

    func testTheSourceHoldsOnlyASaltedKey() {
        // PBKDF2-HMAC-SHA256's published vectors (RFC 7914 section 11's
        // construction, as other implementations list them).
        XCTAssertEqual(DeveloperUnlock.derive("password", salt: Data("salt".utf8), iterations: 1, length: 32)?.hex,
                       "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b")
        XCTAssertEqual(DeveloperUnlock.derive("password", salt: Data("salt".utf8), iterations: 4096, length: 32)?.hex,
                       "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a")
        XCTAssertEqual(DeveloperUnlock.salt.count, 16)
        XCTAssertEqual(DeveloperUnlock.key.count, 32)
        XCTAssertGreaterThanOrEqual(DeveloperUnlock.iterations, 1_000_000)
        XCTAssertNotEqual(DeveloperUnlock.mark, DeveloperUnlock.key.hex, "the saved mark is not the key")
        for wrong in ["", " ", "password", "fielua", "Fielua2026", "12345678", "gemma12b"] {
            XCTAssertFalse(DeveloperUnlock.matches(wrong), wrong)
        }
        // A Japanese keyboard's full-width letters and digits, and spaces
        // around it, read as the plain password; case still counts.
        XCTAssertEqual(DeveloperUnlock.normalized("　ａｂｃ１２３ \n"), "abc123")
        XCTAssertEqual(DeveloperUnlock.normalized("Abc"), "Abc")
    }

    func testTwelveBNeedsDeveloperSettingsAndThePassword() {
        let twelve = ModelSpec.gemma12B
        XCTAssertFalse(DeveloperUnlock.isActive)
        XCTAssertTrue(twelve.isLocked)
        XCTAssertNil(ModelSpec.find(twelve.id))
        // The password alone, with 開発者設定 off, unlocks nothing.
        DeveloperUnlock.rememberUnlock()
        XCTAssertFalse(DeveloperUnlock.isActive)
        XCTAssertTrue(twelve.isLocked)
        // 開発者設定 alone neither.
        DeveloperUnlock.lock()
        UserDefaults.standard.set(true, forKey: DeveloperUnlock.developerSettingsKey)
        XCTAssertFalse(DeveloperUnlock.isActive)
        XCTAssertEqual(ModelSpec.lockedCatalog.map(\.id), [twelve.id])
        // Both: 12B is a developer model like Qwen, after E2B and E4B.
        DeveloperUnlock.rememberUnlock()
        XCTAssertTrue(DeveloperUnlock.isActive)
        XCTAssertFalse(twelve.isLocked)
        XCTAssertEqual(ModelSpec.lockedCatalog, [])
        XCTAssertEqual(ModelSpec.catalog.map(\.id), [ModelSpec.e4b.id, ModelSpec.e2b.id, twelve.id, ModelSpec.qwen3.id, ModelSpec.qwen25.id])
        XCTAssertEqual(ModelSpec.find(twelve.id)?.id, twelve.id, "its chats open with it again")
        XCTAssertTrue(ModelSpec.visibleCatalog(developer: true).contains { $0.id == twelve.id })
        XCTAssertFalse(ModelSpec.visibleCatalog(developer: false).contains { $0.id == twelve.id })
        // Never chosen for anyone, even unlocked on a roomy device.
        let roomy = DeviceCapacity(memoryBytes: 64_000_000_000, freeDiskBytes: 500_000_000_000, processorCount: 12, isPad: true)
        XCTAssertNotEqual(ModelRecommendation.recommended(for: roomy)?.id, twelve.id)
        // 開発者設定 off locks it at once; lock() forgets the password.
        UserDefaults.standard.set(false, forKey: DeveloperUnlock.developerSettingsKey)
        XCTAssertTrue(twelve.isLocked)
        UserDefaults.standard.set(true, forKey: DeveloperUnlock.developerSettingsKey)
        DeveloperUnlock.lock()
        XCTAssertTrue(twelve.isLocked)
        XCTAssertEqual(ModelSpec.catalog.count, 4)
    }

    func testTwelveBRunsOnTheGPUWithTextAndFiles() {
        let twelve = ModelSpec.gemma12B
        XCTAssertTrue(twelve.supportsGPU)
        XCTAssertFalse(twelve.supportsCPU, "0.2 tokens a second on the phone's CPU")
        XCTAssertFalse(twelve.supportsVision)
        XCTAssertFalse(twelve.supportsSpeculation)
        XCTAssertFalse(twelve.supportsThinking)
        XCTAssertFalse(twelve.supportsWebSearch)
        XCTAssertTrue(twelve.capabilities.documents)
        // 4,096 tokens with benchmark mode answered on the phone's GPU
        // (201's comparison, engine C).
        XCTAssertEqual(twelve.maximumContextTokens, 4096)
        XCTAssertTrue(twelve.capabilities.gpuBenchmarkMode)
        XCTAssertFalse([ModelSpec.e4b, .e2b, .qwen3, .qwen25].contains { $0.capabilities.gpuBenchmarkMode })
        XCTAssertEqual(ModelAttachmentPolicy(model: twelve).allowsImages, false)
        // A saved CPU, or the background's, becomes the GPU.
        var settings = GenerationSettings(for: twelve)
        settings.backend = .cpu
        settings.maxTokens = 8192
        let normalized = settings.normalized(for: twelve)
        XCTAssertEqual(normalized.backend, .gpu)
        XCTAssertEqual(normalized.maxTokens, 4096)
        // Room for a file's text again: 201's 1,024 tokens read only its start.
        XCTAssertEqual(normalized.inputTokenLimit, 3072)
        XCTAssertEqual(InferenceEnginePlan(model: twelve, settings: normalized, needsVision: false).backend, .gpu)
        // Every other model keeps the CPU.
        XCTAssertTrue([ModelSpec.e4b, .e2b, .qwen3, .qwen25].allSatisfy(\.supportsCPU))
        XCTAssertEqual(settings.normalized(for: .e4b).backend, .cpu)
    }

    func testTwelveBStartsInAChatOnlyWithRoom() {
        // TestFlight 1.1.0 (199) on the phone, with EVA and IML.
        XCTAssertEqual(LargeModelProbe.chatBlockers(largestFreeAddress: 68_720_000_000, availableMemory: 6_380_000_000), [])
        // The sideload's signature: 6.44 GB of contiguous space.
        let sideload = LargeModelProbe.chatBlockers(largestFreeAddress: 6_440_000_000, availableMemory: 6_380_000_000)
        XCTAssertEqual(sideload.count, 1)
        guard case .addressSpace = sideload.first else { return XCTFail("\(sideload)") }
        XCTAssertEqual(LargeModelProbe.chatBlockers(largestFreeAddress: 68_720_000_000, availableMemory: 2_000_000_000).count, 1)
        XCTAssertEqual(LargeModelProbe.chatBlockers(largestFreeAddress: nil, availableMemory: nil).count, 1,
                       "an unreadable address space is no evidence of room")
        XCTAssertEqual(LargeModelProbe.chatBlockers(largestFreeAddress: 68_720_000_000, availableMemory: nil), [],
                       "the simulator has no memory limit to keep")
    }
}

private extension Data {
    var hex: String { map { String(format: "%02x", $0) }.joined() }
}
