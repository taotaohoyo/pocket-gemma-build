import XCTest
@testable import PocketCore

final class LargeModelChatCompareTests: XCTestCase {
    func testTwelveBChatStartsAsTheCheckDid() {
        let twelve = ModelSpec.gemma12B
        let plan = InferenceEnginePlan(model: twelve, settings: GenerationSettings(for: twelve), needsVision: false)
        XCTAssertEqual(plan.backend, .gpu)
        XCTAssertEqual(plan.maxTokens, LargeModelProbe.contextTokens)
        XCTAssertTrue(plan.gpuBenchmarkMode)
        // Never the cache 200 wrote without benchmark mode.
        XCTAssertTrue(plan.cacheComponent.hasSuffix("/GPU-vision-none-kernel-none-v0-ctx1024-mtp0-bench"), plan.cacheComponent)
        // E2B, E4B and Qwen start and cache as before, on either backend.
        for model in [ModelSpec.e4b, .e2b, .qwen3, .qwen25] {
            for backend in [ExecutionBackend.gpu, .cpu] {
                var settings = GenerationSettings(for: model)
                settings.backend = backend
                let other = InferenceEnginePlan(model: model, settings: settings, needsVision: false)
                XCTAssertFalse(other.gpuBenchmarkMode, model.id)
                XCTAssertFalse(other.cacheComponent.contains("-bench"), other.cacheComponent)
            }
        }
    }

    func testEnginesChangeOneSettingAtATime() {
        let engines = LargeModelChatCompare.engines
        XCTAssertEqual(engines.map(\.id), ["A", "B", "C", "D", "E", "F"])
        // A is 201's chat; D and E are 200's.
        let a = engines[0], d = engines[3], e = engines[4]
        XCTAssertEqual(a.context, ModelSpec.gemma12B.maximumContextTokens)
        XCTAssertEqual(a.benchmark, ModelSpec.gemma12B.capabilities.gpuBenchmarkMode)
        XCTAssertEqual(d.context, 4096); XCTAssertFalse(d.benchmark)
        XCTAssertTrue(e.reusesCache); XCTAssertEqual(e.context, d.context); XCTAssertEqual(e.benchmark, d.benchmark)
        XCTAssertFalse(engines[0].reusesCache)
        XCTAssertTrue(engines.allSatisfy { $0.prompts.contains(.chat) })
        XCTAssertEqual(LargeModelChatCompare.Prompt.check.text, LargeModelProbe.question)
    }

    func testReplyReadsAsJapaneseOrNot() {
        XCTAssertTrue(LargeModelChatCompare.readsAsJapanese("日本の首都は東京です。"))
        XCTAssertTrue(LargeModelChatCompare.readsAsJapanese("こんにちは！何かお手伝いできることはありますか？"))
        // 1.1.0 (200)'s replies on the phone.
        XCTAssertFalse(LargeModelChatCompare.readsAsJapanese("HDROffsets PAFStruct Component HDROffsets"))
        XCTAssertFalse(LargeModelChatCompare.readsAsJapanese("অআইঈউ PAFStruct অআইঈউ"))
        XCTAssertFalse(LargeModelChatCompare.readsAsJapanese(""))
    }

    func testConclusionNamesTheSettingTheGPUNeeds() {
        func record(_ chats: [String: Bool]) -> LargeModelChatCompare.Record {
            var record = LargeModelChatCompare.Record()
            for (engine, ok) in chats.sorted(by: { $0.key < $1.key }) {
                record.results.append(.init(engine: engine, prompt: .chat, reply: ok ? "こんにちは！元気です。" : "PAFStruct অআই",
                                            loadSeconds: 17, replySeconds: 3, pieces: 12))
            }
            return record
        }
        XCTAssertTrue(record(["A": true, "B": false, "C": true, "D": false]).conclusion.contains { $0.hasPrefix("待つ設定") })
        XCTAssertTrue(record(["A": true, "B": true, "C": false, "D": false]).conclusion.contains { $0.hasPrefix("Context 4096 が原因") })
        XCTAssertTrue(record(["D": true, "E": false]).conclusion.contains { $0.contains("2回目以降") })
        XCTAssertTrue(record(["C": false, "F": true]).conclusion.contains { $0.contains("32ビット") })
        XCTAssertEqual(record(["A": true]).conclusion.count, 1)
        // The record keeps no prompt beyond the fixed ones, and the reply's start only.
        let long = LargeModelChatCompare.Result(engine: "A", prompt: .chat, reply: String(repeating: "あ", count: 200),
                                                loadSeconds: 1, replySeconds: 1, pieces: 1)
        XCTAssertEqual(long.reply.count, 80)
    }

    func testLogKeepsTheRunReplacedInPlace() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("compare.json")
        defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
        let log = LargeModelChatCompare.Log(url: url)
        var record = LargeModelChatCompare.Record()
        record.running = "A"
        log.save(record)
        record.running = ""
        record.finished = true
        log.save(record)
        let loaded = log.load()
        XCTAssertEqual(loaded.count, 1)
        XCTAssertEqual(loaded.first?.finished, true)
    }
}
