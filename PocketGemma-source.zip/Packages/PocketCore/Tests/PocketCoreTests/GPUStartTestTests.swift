import XCTest
@testable import PocketCore

/// The developer GPU start test's settings and native log (GPUStartTest).
final class GPUStartTestTests: XCTestCase {
    /// Only the GPU start test, whose one input is a fixed question, keeps
    /// the GPU's own messages; chats keep the narrow allowlist. Conversation
    /// payloads are dropped either way.
    func testGPUMessagesAreKeptOnlyForTheGPUStartTest() {
        let output = """
        I0000 00:00:1 123 delegate_metal.mm:347] Metal argument buffers are not supported on this device
        W0000 00:00:1 123 gpu_backend.cc:88] Unsupported data type for op FULLY_CONNECTED in fp16
        E0000 00:00:1 123 ml_drift_delegate.cc:412] Failed to build program: kernel compile error
        I0000 00:00:1 123 tokenizer.cc:10] Loaded tokenizer with 151643 tokens
        {"role":"user","content":"GPU error private"}
        prompt: metal private prompt

        """
        var chat = NativeLogBuffer()
        chat.append(Data(output.utf8)); chat.finish()
        XCTAssertEqual(chat.lines.count, 1)
        XCTAssertTrue(chat.lines[0].contains("delegate_metal.mm:347"))
        var test = NativeLogBuffer(keepsGPUMessages: true)
        test.append(Data(output.utf8)); test.finish()
        XCTAssertEqual(test.lines.count, 3)
        XCTAssertTrue(test.lines[1].contains("Unsupported data type"))
        XCTAssertTrue(test.lines[2].contains("Failed to build program"))
        XCTAssertFalse(test.lines.joined().contains("tokenizer"))
        XCTAssertFalse(test.lines.joined().contains("private"))
        XCTAssertEqual(test.discardedLines, 3)
    }

    /// A GPU build prints more than a chat's 64 lines. The test keeps its
    /// last 96, where the failure is, within 12 KB.
    func testGPUStartTestKeepsTheLastLinesWithinItsCap() {
        var test = NativeLogBuffer(keepsGPUMessages: true)
        for index in 0..<150 { test.append(Data("I0000 gpu_kernel.cc:1] compiled shader \(index)\n".utf8)) }
        test.append(Data("E0000 litert_compiled_model.h:1961] Failed to create the compiled model\n".utf8))
        test.finish()
        XCTAssertEqual(test.lines.count, 96)
        XCTAssertTrue(test.truncated)
        XCTAssertTrue(test.lines.last?.contains("litert_compiled_model.h:1961") == true)
        XCTAssertLessThanOrEqual(test.lines.reduce(0) { $0 + $1.utf8.count }, 12_288)
        var chat = NativeLogBuffer()
        for index in 0..<150 { chat.append(Data("E0000 litert_compiled_model.h:1961] Failed \(index)\n".utf8)) }
        chat.finish()
        XCTAssertEqual(chat.lines.count, 64)
    }

    /// No override first, as 1.0.104 started Qwen3; each precision records
    /// its own label, and the test offers only the two Qwen models.
    func testPrecisionsAndModels() {
        XCTAssertEqual(GPUPrecision.allCases, [.modelDefault, .float16, .float32])
        XCTAssertEqual(GPUPrecision.modelDefault.diagnosticLabel, "model/runtime default (no override)")
        XCTAssertEqual(Set(GPUPrecision.allCases.map(\.diagnosticLabel)).count, 3)
        XCTAssertEqual(GPUPrecision.float32.title, "32ビット")
        XCTAssertEqual(GPUStartTest.modelIDs, [ModelSpec.qwen3.id, ModelSpec.qwen25.id])
        // The test leaves chats as they are: Qwen3 still runs on the CPU.
        var settings = GenerationSettings(); settings.backend = .gpu
        XCTAssertEqual(InferenceEnginePlan(model: .qwen3, settings: settings, needsVision: false).backend, .cpu)
    }
}
