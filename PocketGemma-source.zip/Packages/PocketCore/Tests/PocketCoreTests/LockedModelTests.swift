import XCTest
@testable import PocketCore

/// Gemma 4 12B is listed as locked (2026-10-26): never found, chosen,
/// recommended or offered, and the developer 12B check refuses to start
/// without the room it needs instead of going around a limit.
final class LockedModelTests: XCTestCase {
    func testTwelveBIsListedButNeverUsable() {
        let locked = ModelSpec.gemma12B
        XCTAssertTrue(locked.isLocked)
        XCTAssertEqual(ModelSpec.lockedCatalog.map(\.id), ["gemma-4-12b"])
        XCTAssertFalse(ModelSpec.catalog.contains { $0.id == locked.id })
        XCTAssertNil(ModelSpec.find(locked.id), "an old 12B chat still falls back to E4B")
        XCTAssertFalse(ModelSpec.visibleCatalog(developer: true).contains { $0.id == locked.id })
        XCTAssertFalse(ModelSpec.visibleCatalog(developer: false).contains { $0.id == locked.id })
        XCTAssertTrue(ModelSpec.catalog.allSatisfy { !$0.isLocked })
        // The automatic choice only looks at the catalog, even on a roomy device.
        let roomy = DeviceCapacity(memoryBytes: 64_000_000_000, freeDiskBytes: 500_000_000_000, processorCount: 12, isPad: true)
        XCTAssertNotEqual(ModelRecommendation.recommended(for: roomy)?.id, locked.id)
        // The pinned export: a fixed revision, size and digest.
        XCTAssertEqual(locked.byteCount, 6_883_278_368)
        XCTAssertTrue(locked.downloadURL.absoluteString.contains("/resolve/161028364f396379d490ed64ff07c6ef0fcd02d9/"))
        XCTAssertEqual(locked.sha256.count, 64)
    }

    func testTheCheckStartsOnlyWithRoom() {
        let ready = LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: 68_000_000_000,
                                             availableMemory: 6_400_000_000, freeDisk: 40_000_000_000, cacheBytes: 0)
        XCTAssertEqual(ready, [])
        // The phone's free Apple ID launch (1.0.112): 6.44 GB of contiguous
        // space and 3.47 GB of memory, as when 12B failed with ENOMEM.
        let narrow = LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: 6_440_000_000,
                                              availableMemory: 3_470_000_000, freeDisk: 40_000_000_000, cacheBytes: 0)
        XCTAssertEqual(narrow.count, 2)
        guard case .addressSpace(let needed, _) = narrow.first else { return XCTFail("\(narrow)") }
        XCTAssertGreaterThan(needed, UInt64(ModelSpec.gemma12B.byteCount))
        guard case .memory = narrow.last else { return XCTFail("\(narrow)") }
        XCTAssertEqual(LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: nil,
                                                availableMemory: 6_400_000_000, freeDisk: 40_000_000_000, cacheBytes: 0).count, 1,
                       "an unreadable address space is no evidence of room")
        let missing = LargeModelProbe.blockers(fileReady: false, ranThisLaunch: true, largestFreeAddress: 68_000_000_000,
                                               availableMemory: 6_400_000_000, freeDisk: 1_000_000_000, cacheBytes: 0)
        XCTAssertEqual(missing.first, .fileMissing)
        XCTAssertTrue(missing.contains(.alreadyRanThisLaunch))
        XCTAssertTrue(missing.contains { if case .disk = $0 { return true } else { return false } })
        // An earlier start's cache is reused, so no new room is needed for it.
        XCTAssertEqual(LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: 68_000_000_000,
                                                availableMemory: 6_400_000_000, freeDisk: 1_000_000_000,
                                                cacheBytes: 6_000_000_000), [])
        XCTAssertTrue(missing.allSatisfy { !$0.message.isEmpty })
    }

    func testRecordsSurviveAnEndedCheckAndMeasureSpeed() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("records.json")
        let log = LargeModelProbe.Log(url: url)
        defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
        var record = LargeModelProbe.Record(backend: .cpu)
        record.stage = "engine_initialization"
        log.save(record)
        // iOS ended the app here: the relaunch finds it still running.
        XCTAssertEqual(log.load().first?.result, "running")
        XCTAssertTrue(try XCTUnwrap(log.load().first).summary.contains("途中で終了"))
        record.stage = "complete"; record.result = "success"
        record.firstTextSeconds = 4; record.replySeconds = 14; record.replyPieces = 21
        log.save(record)
        XCTAssertEqual(log.load().count, 1)
        XCTAssertEqual(try XCTUnwrap(log.load().first?.decodeTokensPerSecond), 2, accuracy: 0.001)
        record.conversationTokens = 61; record.promptTokens = 30
        XCTAssertEqual(try XCTUnwrap(record.decodeTokensPerSecond), 3, accuracy: 0.001, "the SDK's counts win")
        for _ in 0..<20 { log.save(LargeModelProbe.Record(backend: .gpu)) }
        XCTAssertEqual(log.load().count, LargeModelProbe.Log.limit)
    }
}
