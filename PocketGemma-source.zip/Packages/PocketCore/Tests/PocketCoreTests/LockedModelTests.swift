import XCTest
@testable import PocketCore

/// Gemma 4 12B, listed as locked in 1.1.0 (196) and for developers with a
/// password from 200, is open to everyone from 204 as a test version, with
/// Qwen2.5 1.5B (the user, 22:01 UTC 2026-10-26); the automatic choice still
/// never picks it, and the developer 12B check refuses to start without the
/// room it needs instead of going around a limit.
final class LockedModelTests: XCTestCase {
    func testTwelveBAndQwen25AreOpenToEveryone() {
        let twelve = ModelSpec.gemma12B
        XCTAssertFalse(twelve.isLocked)
        XCTAssertEqual(ModelSpec.lockedCatalog, [], "no model is locked now")
        XCTAssertEqual(ModelSpec.catalog.map(\.id), [ModelSpec.e4b.id, ModelSpec.e2b.id, twelve.id, ModelSpec.phi4MiniReasoning.id,
                                                      ModelSpec.qwen35.id, ModelSpec.qwen3.id, ModelSpec.qwen25.id, ModelSpec.lfm3.id])
        XCTAssertEqual(ModelSpec.find(twelve.id)?.id, twelve.id, "its chats open with it")
        XCTAssertEqual(ModelSpec.visibleCatalog(developer: false).map(\.id),
                       [ModelSpec.e4b.id, ModelSpec.e2b.id, twelve.id, ModelSpec.phi4MiniReasoning.id, ModelSpec.qwen35.id, ModelSpec.qwen25.id,
                        ModelSpec.lfm3.id])
        XCTAssertEqual(ModelSpec.visibleCatalog(developer: true).map(\.id), ModelSpec.catalog.map(\.id))
        XCTAssertEqual(ModelSpec.catalog.filter(\.isDeveloperOnly).map(\.id), [ModelSpec.qwen3.id], "only Qwen3 stays a developer's")
        XCTAssertEqual(ModelSpec.catalog.filter(\.isTestVersion).map(\.id), [twelve.id, ModelSpec.phi4MiniReasoning.id, ModelSpec.lfm3.id],
                       "12B, Phi-4-mini-reasoning (205) and LFM3 1.7B (232) are test versions")
        XCTAssertEqual(ModelSpec.starterCatalog.map(\.id), [ModelSpec.e4b.id, ModelSpec.e2b.id], "the automatic choice keeps to Gemma E4B and E2B")
        XCTAssertFalse(ModelSpec.testVersionNote.isEmpty)
        // The automatic choice keeps to E4B and E2B for everyone, and never
        // picks the test version, even on a roomy device.
        let roomy = DeviceCapacity(memoryBytes: 64_000_000_000, freeDiskBytes: 500_000_000_000, processorCount: 12, isPad: true)
        XCTAssertNotEqual(ModelRecommendation.recommended(for: roomy)?.id, twelve.id)
        let small = DeviceCapacity(memoryBytes: 4_000_000_000, freeDiskBytes: 20_000_000_000, processorCount: 6, isPad: false)
        XCTAssertTrue(ModelRecommendation.recommended(for: small, includeDeveloperModels: false)?.isStarter == true)
        // The pinned export: a fixed revision, size and digest.
        XCTAssertEqual(twelve.byteCount, 6_883_278_368)
        XCTAssertTrue(twelve.downloadURL.absoluteString.contains("/resolve/161028364f396379d490ed64ff07c6ef0fcd02d9/"))
        XCTAssertEqual(twelve.sha256.count, 64)
    }

    /// A chat that can't start 12B says why in the app's language: the
    /// sideload's signature, or too little memory.
    func testTwelveBChatsSayWhyItCannotStart() {
        let sideload = LargeModelProbe.chatBlockers(largestFreeAddress: 6_440_000_000, availableMemory: 6_380_000_000)
        XCTAssertEqual(sideload.first?.chatMessage, "この署名ではアドレス空間が足りないため、読み込めません。TestFlight版で使ってください。")
        let tight = LargeModelProbe.chatBlockers(largestFreeAddress: 68_720_000_000, availableMemory: 2_000_000_000)
        XCTAssertEqual(tight.count, 1)
        XCTAssertTrue(tight.first?.chatMessage.contains("2.00 GB") == true, tight.first?.chatMessage ?? "")
        XCTAssertNotEqual(tight.first?.chatMessage, tight.first?.message, "the developer check keeps its own words")
    }

    /// 12B's card says the sideload can't map it, from the launch's room.
    func testTheLaunchSaysWhetherTwelveBFits() {
        defer { LargeModelProbe.offer(atLaunch: AddressSpace(range: 545_000_000_000, free: 68_720_000_000, largestFree: 68_720_000_000, regions: 1)) }
        LargeModelProbe.offer(atLaunch: AddressSpace(range: 545_000_000_000, free: 6_440_000_000, largestFree: 6_440_000_000, regions: 1))
        XCTAssertFalse(LargeModelProbe.twelveBFitsAtLaunch, "the sideload's 6.44 GB")
        LargeModelProbe.offer(atLaunch: nil)
        XCTAssertFalse(LargeModelProbe.twelveBFitsAtLaunch)
        LargeModelProbe.offer(atLaunch: AddressSpace(range: 545_000_000_000, free: 68_720_000_000, largestFree: 68_720_000_000, regions: 1))
        XCTAssertTrue(LargeModelProbe.twelveBFitsAtLaunch, "TestFlight's 68.7 GB")
    }

    func testTheCheckStartsOnlyWithRoom() {
        let ready = LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: 68_000_000_000,
                                             availableMemory: 6_400_000_000, freeDisk: 40_000_000_000, cacheBytes: 0)
        XCTAssertEqual(ready, [])
        // The phone's free Apple ID launch (1.0.112): 6.44 GB of contiguous
        // space and 3.47 GB of memory, as when 12B failed with ENOMEM.
        let narrow = LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: 6_440_000_000,
                                              availableMemory: 3_470_000_000, freeDisk: 40_000_000_000, cacheBytes: 0)
        XCTAssertEqual(narrow.count, 2)
        guard case .addressSpace(let needed, _) = narrow.first else { return XCTFail("\(narrow)") }
        XCTAssertGreaterThan(needed, UInt64(ModelSpec.gemma12B.byteCount))
        guard case .memory = narrow.last else { return XCTFail("\(narrow)") }
        XCTAssertEqual(LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: nil,
                                                availableMemory: 6_400_000_000, freeDisk: 40_000_000_000, cacheBytes: 0).count, 1,
                       "an unreadable address space is no evidence of room")
        let missing = LargeModelProbe.blockers(fileReady: false, ranThisLaunch: true, largestFreeAddress: 68_000_000_000,
                                               availableMemory: 6_400_000_000, freeDisk: 1_000_000_000, cacheBytes: 0)
        XCTAssertEqual(missing.first, .fileMissing)
        XCTAssertTrue(missing.contains(.alreadyRanThisLaunch))
        XCTAssertTrue(missing.contains { if case .disk = $0 { return true } else { return false } })
        // An earlier start's cache is reused, so no new room is needed for it.
        XCTAssertEqual(LargeModelProbe.blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: 68_000_000_000,
                                                availableMemory: 6_400_000_000, freeDisk: 1_000_000_000,
                                                cacheBytes: 6_000_000_000), [])
        XCTAssertTrue(missing.allSatisfy { !$0.message.isEmpty })
    }

    func testRecordsSurviveAnEndedCheckAndMeasureSpeed() throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathComponent("records.json")
        let log = LargeModelProbe.Log(url: url)
        defer { try? FileManager.default.removeItem(at: url.deletingLastPathComponent()) }
        var record = LargeModelProbe.Record(backend: .cpu)
        record.stage = "engine_initialization"
        log.save(record)
        // iOS ended the app here: the relaunch finds it still running.
        XCTAssertEqual(log.load().first?.result, "running")
        XCTAssertTrue(try XCTUnwrap(log.load().first).summary.contains("途中で終了"))
        record.stage = "complete"; record.result = "success"
        record.firstTextSeconds = 4; record.replySeconds = 14; record.replyPieces = 21
        log.save(record)
        XCTAssertEqual(log.load().count, 1)
        XCTAssertEqual(try XCTUnwrap(log.load().first?.decodeTokensPerSecond), 2, accuracy: 0.001)
        record.conversationTokens = 61; record.promptTokens = 30
        XCTAssertEqual(try XCTUnwrap(record.decodeTokensPerSecond), 3, accuracy: 0.001, "the SDK's counts win")
        for _ in 0..<20 { log.save(LargeModelProbe.Record(backend: .gpu)) }
        XCTAssertEqual(log.load().count, LargeModelProbe.Log.limit)
    }
}
