import XCTest
@testable import PocketCore

/// Phase 5: what the copy menus put on the pasteboard and what VoiceOver
/// says for formulas and tables.
final class MarkdownCopyTests: XCTestCase {
    private func table(_ source: String, file: StaticString = #filePath, line: UInt = #line) -> MarkdownTable? {
        guard case .table(let table)? = MarkdownDocument(source).blocks.first else {
            XCTFail("No table in \(MarkdownDocument(source).blocks)", file: file, line: line)
            return nil
        }
        return table
    }

    private static let sample = """
    | 名前 | 値 | 式 |
    |:--|:-:|--:|
    | **太字** と *斜体* | `code` | $x^2$ |
    | [リンク](https://example.com) | 1\\|2 | ~~旧~~ |
    """

    func testTableCopiesAsTabSeparatedCells() throws {
        let table = try XCTUnwrap(table(Self.sample))
        XCTAssertEqual(table.tabSeparated.components(separatedBy: "\n"), [
            "名前\t値\t式",
            "太字 と 斜体\tcode\t$x^2$",
            "リンク\t1|2\t旧",
        ])
    }

    func testTableCopiesBackAsMarkdown() throws {
        let table = try XCTUnwrap(table(Self.sample))
        XCTAssertEqual(table.markdown.components(separatedBy: "\n"), [
            "| 名前 | 値 | 式 |",
            "| --- | :-: | --: |",
            "| **太字** と *斜体* | `code` | $x^2$ |",
            "| [リンク](https://example.com) | 1\\|2 | ~~旧~~ |",
        ])
        // What was copied reads back as the same table.
        XCTAssertEqual(self.table(table.markdown)?.markdown, table.markdown)
    }

    func testCopiedCellsKeepFormulasOnceAndFlattenLines() throws {
        let table = try XCTUnwrap(table("| a | b |\n|---|---|\n| 前 \\(y_1\\) 後 | 2 |"))
        XCTAssertEqual(table.tabSeparated.components(separatedBy: "\n").last, "前 \\(y_1\\) 後\t2")
        // A tab inside a cell would start a new column in a spreadsheet.
        var tabbed = table
        tabbed.rows[0][1] = AttributedString("x\ty")
        XCTAssertEqual(tabbed.tabSeparated.components(separatedBy: "\n").last, "前 \\(y_1\\) 後\tx y")
        tabbed.rows[0][1] = AttributedString("一行目\n二行目")
        XCTAssertEqual(tabbed.tabSeparated.components(separatedBy: "\n").last, "前 \\(y_1\\) 後\t一行目 二行目")
    }

    func testTableReadsOutHeadersWithCells() throws {
        let table = try XCTUnwrap(table(Self.sample))
        XCTAssertEqual(table.spokenSummary, "表、2行、3列")
        XCTAssertEqual(table.spokenCell(row: 0, column: 0), "名前、太字 と 斜体")
        XCTAssertEqual(table.spokenCell(row: 0, column: 2), "式、x の 2 乗")
        XCTAssertEqual(table.spokenCell(row: 1, column: 1), "値、1|2")
        XCTAssertEqual(table.spokenCell(row: 5, column: 0), "")
        let blank = try XCTUnwrap(self.table("| 項目 | メモ |\n|---|---|\n| a |  |"))
        XCTAssertEqual(blank.spokenCell(row: 0, column: 1), "メモ、空欄")
    }

    // MARK: Formulas read aloud

    func testFormulasReadAloudInJapanese() {
        let cases: [(String, String)] = [
            ("\\frac{a}{b}", "b 分の a"),
            ("x^2 + 1", "x の 2 乗 プラス 1"),
            ("\\text{利益率} = \\frac{\\text{利益}}{\\text{売上高}} \\times 100\\%", "利益率 イコール 売上高 分の 利益 かける 100 パーセント"),
            ("利益率 = \\frac{利益}{売上} × 100", "利益率 イコール 売上 分の 利益 かける 100"),
            ("f'(x)=2x", "f プライム (x) イコール 2x"),
            ("f^{\\prime\\prime}", "f プライム プライム"),
            ("\\sqrt{2}", "ルート 2"),
            ("\\sqrt[3]{8}", "3 乗根 8"),
            ("\\sum_{i=1}^{n} i", "i イコール 1 から n までの和 i"),
            ("\\lim_{x \\to 0} \\frac{\\sin x}{x}", "x が 0 に近づくときの極限 x 分の サイン x"),
            ("\\int_0^1 x^2\\,dx", "0 から 1 までの積分 x の 2 乗 dx"),
            ("\\alpha + \\beta", "アルファ プラス ベータ"),
            ("x_1", "x 下付き 1"),
            ("90^\\circ", "90 度"),
            ("\\vec{v}", "ベクトル v"),
            ("\\bar{x}", "x バー"),
            ("\\left( \\frac{1}{2} \\right)", "(2 分の 1)"),
            ("n!", "n の階乗"),
            ("a \\ne b", "a ノットイコール b"),
            ("\\color{red}{x}", "x"),
            ("\\mathbb{R}", "R"),
            ("", ""),
        ]
        for (latex, spoken) in cases {
            XCTAssertEqual(MathSpeech.spoken(latex), spoken, latex)
        }
    }

    func testEnvironmentsReadRowByRow() {
        XCTAssertEqual(MathSpeech.spoken("\\begin{cases} x+y=5 \\\\ x-y=1 \\end{cases}"),
                       "場合分け x プラス y イコール 5、x マイナス y イコール 1")
        XCTAssertEqual(MathSpeech.spoken("\\begin{aligned}\na &= b+c \\\\\nx &= y+z\n\\end{aligned}"),
                       "a イコール b プラス c、x イコール y プラス z")
        XCTAssertEqual(MathSpeech.spoken("\\begin{pmatrix} 1 & 2 \\\\ 3 & 4 \\end{pmatrix}"), "行列 1 2、3 4")
        XCTAssertEqual(MathSpeech.spoken("\\begin{array}{cc} a & b \\end{array}"), "a b")
    }

    func testUnknownCommandsAreReadByNameAndNothingBreaks() {
        XCTAssertEqual(MathSpeech.spoken("\\xrightarrow{x} y"), "xrightarrow x y")
        // Unbalanced or cut-off input still gives words, never a crash.
        for latex in ["\\frac{a", "x^", "\\sqrt[", "\\begin{cases} x", "}}}", "\\", "{\\text{", "_^_^", "\\left."] {
            _ = MathSpeech.spoken(latex)
        }
        // Nested thousands deep, it still returns.
        XCTAssertFalse(MathSpeech.spoken(String(repeating: "x^{", count: 3_000)).isEmpty)
        XCTAssertFalse(MathSpeech.spoken(String(repeating: "\\frac", count: 1_000) + "ab").isEmpty)
        XCTAssertFalse(MathSpeech.spoken(String(repeating: "\\sqrt{", count: 1_000)).isEmpty)
    }
}
