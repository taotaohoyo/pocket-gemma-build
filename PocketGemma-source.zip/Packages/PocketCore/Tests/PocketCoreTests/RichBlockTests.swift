import XCTest
@testable import PocketCore

/// Rich blocks in replies (Phase 6-1): ```chart blocks read, checked and
/// copied without changing a value, the fallback for data that does not
/// hold up, streaming that never shows a chart's data, the pacer laying a
/// chart out whole, and the note that asks the model for one.
final class RichBlockTests: XCTestCase {
    private func chart(_ source: String, file: StaticString = #filePath, line: UInt = #line) -> ChartSpec? {
        switch ChartSpec.parse(source) {
        case .success(let chart): return chart
        case .failure(let error):
            XCTFail("Expected a chart, got \(error) (\(error.message))", file: file, line: line)
            return nil
        }
    }

    private func failure(_ source: String) -> RichBlockError? {
        if case .failure(let error) = ChartSpec.parse(source) { return error }
        return nil
    }

    static let population = #"{"type":"bar","title":"都市の人口","unit":"万人","data":[{"label":"東京","value":1400},{"label":"大阪","value":880},{"label":"名古屋","value":230.5}]}"#

    // MARK: Reading

    func testBarChartKeepsEveryLabelValueAndUnitAsWritten() {
        guard let spec = chart(Self.population) else { return }
        XCTAssertEqual(spec.kind, .bar)
        XCTAssertEqual(spec.title, "都市の人口")
        XCTAssertEqual(spec.unit, "万人")
        XCTAssertEqual(spec.series, [""])
        XCTAssertEqual(spec.items.map(\.label), ["東京", "大阪", "名古屋"])
        XCTAssertEqual(spec.items.map(\.values), [[1400], [880], [230.5]])
        XCTAssertEqual(spec.display(1400), "1,400万人")
        XCTAssertEqual(spec.display(230.5), "230.5万人")
        XCTAssertEqual(spec.overview, "最大：東京 1,400万人")
        XCTAssertEqual(spec.readout(at: 2), "名古屋：230.5万人")
        XCTAssertEqual(spec.spokenSummary, "棒グラフ、都市の人口、3項目、単位 万人")
        XCTAssertEqual(spec.spokenItem(1), "大阪、880万人")
    }

    func testSeveralSeriesAsItemsWithNames() {
        let source = #"{"type":"line","title":"売上","unit":"万円","series":["2023年","2024年"],"data":[{"label":"1月","values":[10,11]},{"label":"2月","values":[12,15]},{"label":"3月","values":[14,null]}]}"#
        guard let spec = chart(source) else { return }
        XCTAssertEqual(spec.kind, .line)
        XCTAssertEqual(spec.series, ["2023年", "2024年"])
        XCTAssertEqual(spec.items[2].values, [14, nil])
        XCTAssertEqual(spec.readout(at: 1), "2月：2023年 12万円・2024年 15万円")
        XCTAssertEqual(spec.readout(at: 2), "3月：2023年 14万円・2024年 —")
        XCTAssertEqual(spec.spokenItem(0), "1月、2023年 10万円、2024年 11万円")
        XCTAssertEqual(spec.markdown, """
        売上

        | 項目 | 2023年（万円） | 2024年（万円） |
        | --- | --: | --: |
        | 1月 | 10 | 11 |
        | 2月 | 12 | 15 |
        | 3月 | 14 |  |
        """)
    }

    func testParallelArraysAndChartJSShapes() {
        guard let parallel = chart(#"{"type":"pie","labels":["A","B"],"values":[3,1]}"#),
              let chartJS = chart(#"{"type":"bar","data":{"labels":[2022,2023],"datasets":[{"label":"国内","data":[5,6]},{"label":"海外","data":[2,3]}]}}"#)
        else { return }
        XCTAssertEqual(parallel.items.map(\.label), ["A", "B"])
        XCTAssertEqual(parallel.items.map(\.values), [[3], [1]])
        XCTAssertEqual(parallel.percentage(0), "75.0%")
        XCTAssertEqual(parallel.overview, "合計：4")
        XCTAssertEqual(chartJS.items.map(\.label), ["2022", "2023"])
        XCTAssertEqual(chartJS.series, ["国内", "海外"])
        XCTAssertEqual(chartJS.items.map(\.values), [[5, 2], [6, 3]])
    }

    /// What small models slip into: trailing commas, a word before the
    /// object, numbers written as text, "doughnut" for a pie.
    func testTolerantOfJSON5AndNumbersWrittenAsText() {
        guard let spec = chart(#"json {type: "doughnut", data: [{label: "A", value: "1,400"}, {label: "B", value: "１２.５"}, {label: "C", value: -0},],}"#)
        else { return }
        XCTAssertEqual(spec.kind, .pie)
        XCTAssertEqual(spec.items.map(\.values), [[1400], [12.5], [0]])
        XCTAssertEqual(ChartSpec.number(fromText: "1,400"), 1400)
        XCTAssertEqual(ChartSpec.number(fromText: "−3.5"), -3.5)
        XCTAssertNil(ChartSpec.number(fromText: "12%"))
        XCTAssertNil(ChartSpec.number(fromText: "1,40"))
        XCTAssertNil(ChartSpec.number(fromText: "約100"))
    }

    func testDataThatDoesNotHoldUpIsNotDrawn() {
        XCTAssertEqual(failure("ここはグラフではありません"), .unreadable)
        XCTAssertEqual(failure(#"{"title":"x","data":[{"label":"A","value":1}]}"#), .missingType)
        XCTAssertEqual(failure(#"{"type":"scatter","data":[{"label":"A","value":1}]}"#), .unknownType("scatter"))
        XCTAssertEqual(failure(#"{"type":"bar","data":[]}"#), .noData)
        XCTAssertEqual(failure(#"{"type":"bar","data":[{"label":"A","value":"12%"}]}"#), .notANumber(label: "A"))
        XCTAssertEqual(failure(#"{"type":"bar","data":[{"label":"A","value":true}]}"#), .notANumber(label: "A"))
        // JSON5 may read Infinity as a number or not at all; either way it is not drawn.
        let infinity = failure(#"{"type":"bar","data":[{"label":"A","value":Infinity}]}"#)
        XCTAssertTrue(infinity == .notANumber(label: "A") || infinity == .unreadable, "\(String(describing: infinity))")
        XCTAssertEqual(failure(#"{"type":"bar","data":[{"label":"A","value":1e300}]}"#), .notANumber(label: "A"))
        XCTAssertEqual(failure(#"{"type":"bar","data":[{"value":1}]}"#), .missingLabel(1))
        XCTAssertEqual(failure(#"{"type":"bar","data":[{"label":"A","value":null}]}"#), .noData)
        XCTAssertEqual(failure(#"{"type":"pie","data":[{"label":"A","value":-1},{"label":"B","value":2}]}"#), .negativeInPie(label: "A"))
        XCTAssertEqual(failure(#"{"type":"pie","data":[{"label":"A","value":0}]}"#), .emptyPie)
        XCTAssertEqual(failure(#"{"type":"pie","data":[{"label":"A","value":null}]}"#), .notANumber(label: "A"))
        XCTAssertEqual(failure(#"{"type":"pie","series":["x","y"],"data":[{"label":"A","values":[1,2]}]}"#), .tooManySeries(limit: 1))
        XCTAssertEqual(failure(#"{"type":"bar","data":[{"label":"A","values":[1,2]},{"label":"B","values":[1]}]}"#), .seriesMismatch(label: "B"))
        XCTAssertEqual(failure(#"{"type":"bar","labels":["A","B"],"values":[1]}"#), .countMismatch)
        let many = (1...31).map { #"{"label":"項目\#($0)","value":\#($0)}"# }.joined(separator: ",")
        XCTAssertEqual(failure(#"{"type":"bar","data":[\#(many)]}"#), .tooManyItems(limit: 30))
        XCTAssertEqual(failure(String(repeating: " ", count: RichBlocks.sourceLimit + 1)), .tooLarge)
        // Every reason reads as a sentence for the fallback's line.
        XCTAssertEqual(RichBlockError.notANumber(label: "A").message, "「A」の値が数値ではありません")
    }

    /// Values are written back exactly as the data gave them.
    func testValuesAreNeverRoundedOrFilledIn() {
        XCTAssertEqual(ChartSpec.plain(1400), "1400")
        XCTAssertEqual(ChartSpec.plain(1400, grouped: true), "1,400")
        XCTAssertEqual(ChartSpec.plain(1234567.891, grouped: true), "1,234,567.891")
        XCTAssertEqual(ChartSpec.plain(-1234.5, grouped: true), "-1,234.5")
        XCTAssertEqual(ChartSpec.plain(0.1), "0.1")
        XCTAssertEqual(ChartSpec.plain(12.345), "12.345")
        XCTAssertEqual(ChartSpec.plain(0.0000001), "0.0000001")
        XCTAssertEqual(ChartSpec.plain(-0.0), "0")
        guard let spec = chart(#"{"type":"bar","data":[{"label":"x|y","value":0.1},{"label":"z","value":null}]}"#) else { return }
        XCTAssertEqual(spec.markdown, "| 項目 | 値 |\n| --- | --: |\n| x\\|y | 0.1 |\n| z |  |")
        XCTAssertEqual(spec.tabSeparated, "項目\t値\nx|y\t0.1\nz\t")
    }

    func testCopiedDataIsTheChartsAlone() {
        guard let spec = chart(Self.population) else { return }
        XCTAssertEqual(spec.markdown, """
        都市の人口

        | 項目 | 値（万人） |
        | --- | --: |
        | 東京 | 1400 |
        | 大阪 | 880 |
        | 名古屋 | 230.5 |
        """)
        XCTAssertEqual(spec.tabSeparated, "項目\t値（万人）\n東京\t1400\n大阪\t880\n名古屋\t230.5")
    }

    func testLayoutHelpers() {
        guard let spec = chart(Self.population) else { return }
        XCTAssertTrue(spec.prefersColumns)
        XCTAssertEqual(spec.valueRange(headroom: 0.1), 0...2000)
        XCTAssertEqual(ChartSpec.roundStep(385), 500)
        XCTAssertEqual(ChartSpec.roundStep(1.12), 2)
        XCTAssertEqual(ChartSpec.roundStep(0.24), 0.25)
        let line = ChartSpec(kind: .line, items: [10.0, 12, 14].enumerated().map { .init(label: "\($0.offset)", values: [$0.element]) })
        XCTAssertEqual(line.valueRange(headroom: 0.06), 8...16)
        let months = ChartSpec(kind: .line, items: (1...12).map { .init(label: "\($0)月", values: [Double($0)]) })
        XCTAssertEqual(months.tickIndices(maximum: 5), [0, 3, 6, 9, 11])
        let long = ChartSpec(kind: .bar, items: [.init(label: "北海道・東北地方の合計", values: [1])])
        XCTAssertFalse(long.prefersColumns)
        XCTAssertEqual(ChartSpec.shortened("北海道・東北地方の合計", width: 12), "北海道・東…")
        XCTAssertEqual(ChartSpec.shortened("東京", width: 12), "東京")
        XCTAssertEqual(ChartSpec.axisLabel(2500), "2,500")
        XCTAssertEqual(ChartSpec.axisLabel(0.30000000000000004), "0.3")
    }

    func testPlaceholderPeeksAtKindAndTitle() {
        let partial = #"{"type":"line","title":"気温の推移","unit":"#
        XCTAssertEqual(ChartSpec.peek(partial).kind, .line)
        XCTAssertEqual(ChartSpec.peek(partial).title, "気温の推移")
        XCTAssertNil(ChartSpec.peek(#"{"type":"line","title":"気温の"#).title)
        XCTAssertNil(ChartSpec.peek("{").kind)
    }

    // MARK: In replies

    static let reply = """
    人口を比べます。

    ```chart
    \(population)
    ```

    東京が最も多いです。
    """

    func testChartBlockSitsBetweenProse() {
        let blocks = MarkdownDocument(Self.reply).blocks
        XCTAssertEqual(blocks.count, 3)
        guard case .paragraph? = blocks.first, case .rich(let rich)? = blocks.dropFirst().first, case .paragraph? = blocks.last else {
            return XCTFail("\(blocks)")
        }
        XCTAssertEqual(rich.tag, "chart")
        guard case .ready(.chart(let spec)) = rich.state else { return XCTFail("\(rich.state)") }
        XCTAssertEqual(spec.items.count, 3)
        XCTAssertEqual(MarkdownSource.chunks(Self.reply).count, 3)
    }

    /// Only the reserved tag makes a chart: the same JSON as ```json is code,
    /// and prose that talks about charts is prose.
    func testOnlyTheChartTagIsDrawnAsAChart() {
        let json = "```json\n\(Self.population)\n```"
        guard case .code(let language, _)? = MarkdownDocument(json).blocks.first else { return XCTFail() }
        XCTAssertEqual(language, "json")
        guard case .paragraph? = MarkdownDocument("chart: {\"type\":\"bar\"} はグラフの書き方です。").blocks.first else { return XCTFail() }
        guard case .rich(let titled)? = MarkdownDocument("```Chart title=人口\n\(Self.population)\n```").blocks.first,
              case .ready = titled.state else { return XCTFail("A tag with attributes and capitals is still a chart") }
    }

    func testBrokenChartFallsBackToItsSource() {
        let source = #"{"type":"bar","data":[{"label":"A","value":"たくさん"}]}"#
        guard case .rich(let rich)? = MarkdownDocument("```chart\n\(source)\n```").blocks.first else { return XCTFail() }
        XCTAssertEqual(rich.source, source)
        XCTAssertEqual(rich.state, .failed(.notANumber(label: "A")))
    }

    /// While the block streams in, its place shows a placeholder: never its
    /// data as text, never a code block, never half a chart.
    func testStreamingChartNeverShowsItsData() {
        var prefix = ""
        var sawPending = false
        for character in Self.reply {
            prefix.append(character)
            let blocks = MarkdownSource.chunks(prefix).suffix(1).flatMap { MarkdownDocument($0, streaming: true).blocks }
            for block in blocks {
                switch block {
                case .code: XCTFail("A code block while the chart streams: \(prefix.debugDescription)")
                case .paragraph(let text):
                    let plain = String(text.characters)
                    XCTAssertFalse(plain.contains("\"type\"") || plain.contains("```"), "Raw data in \(prefix.debugDescription)")
                case .rich(let rich):
                    if case .pending = rich.state { sawPending = true }
                    if case .failed(let error) = rich.state { XCTFail("Failed while streaming: \(error) in \(prefix.debugDescription)") }
                default: break
                }
            }
        }
        XCTAssertTrue(sawPending)
    }

    func testStoppedReplyShowsItsUnfinishedChartAsSource() {
        let stopped = "人口です。\n\n```chart\n{\"type\":\"bar\",\"data\":[{\"label\":\"東京\",\"val"
        let blocks = MarkdownDocument(stopped).blocks
        guard case .rich(let rich)? = blocks.last else { return XCTFail("\(blocks)") }
        XCTAssertEqual(rich.state, .failed(.unfinished))
        XCTAssertTrue(rich.source.hasPrefix("{\"type\":\"bar\""))
        XCTAssertEqual(MarkdownSource.markingUnfinishedRich("```swift\nlet a = 1"), "```swift\nlet a = 1")
    }

    // MARK: Pacing

    func testPacedStepTakesTheWholeChart() {
        let text = "前文\n```chart\n{\"type\":\"bar\"}\n```\n後の文"
        let opening = "前文\n".count
        let after = "前文\n```chart\n{\"type\":\"bar\"}\n```\n".count
        // A step that reaches into the opening line takes the whole block.
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: 2, end: opening + 3, generating: true), after)
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: 2, end: opening + 12, generating: false), after)
        // Steps before or after it are left alone.
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: 0, end: opening, generating: true), opening)
        XCTAssertEqual(MarkdownSource.pacedEnd(text, shown: after, end: after + 2, generating: true), after + 2)
        // Still being written: all that has come of it.
        let open = "前文\n```chart\n{\"type\":\"b"
        XCTAssertEqual(MarkdownSource.pacedEnd(open, shown: 2, end: opening + 4, generating: true), open.count)
        // A tag still arriving waits for its line to end while the model writes.
        let tag = "前文\n```cha"
        XCTAssertEqual(MarkdownSource.pacedEnd(tag, shown: 2, end: tag.count, generating: true), opening)
        XCTAssertEqual(MarkdownSource.pacedEnd(tag, shown: 2, end: tag.count, generating: false), tag.count)
        // Code is paced as before.
        let code = "前文\n```swift\nlet a = 1\n```\n"
        XCTAssertEqual(MarkdownSource.pacedEnd(code, shown: 2, end: opening + 5, generating: true), opening + 5)
        XCTAssertEqual(MarkdownSource.pacedEnd("文章だけ", shown: 0, end: 2, generating: true), 2)
    }

    /// A model writing a reply with a chart in it at 40 characters a second:
    /// the display never stops inside the chart's data, shows the chart as
    /// soon as it is complete, and finishes the reply.
    func testPacerNeverLaysOutAChartsData() {
        let reply = Self.reply
        let pacer = ReplyPacer(text: "", generating: true, held: false, shown: 0)
        let characters = Array(reply)
        let fenceStart = reply.distance(from: reply.startIndex, to: reply.range(of: "```chart")!.lowerBound)
        let fenceEnd = reply.distance(from: reply.startIndex, to: reply.range(of: "```\n\n東京")!.lowerBound) + 4
        var now = 0.0
        var arrived = 0
        var stops: [Int] = []
        while now < 30, !(pacer.caughtUp && !pacer.generating) {
            let due = min(characters.count, Int(now * 40))
            if due > arrived {
                pacer.text += String(characters[arrived..<due])
                arrived = due
            }
            pacer.generating = arrived < characters.count
            if let shown = pacer.advance(at: now) { stops.append(shown) }
            now += ReplyPacer.interval(forLength: pacer.shown)
        }
        XCTAssertTrue(pacer.caughtUp, "The reply finishes")
        let inside = stops.filter { $0 > fenceStart && $0 < fenceEnd }
        print("RICH-NOTE pacer stops inside the chart block: \(inside) (block \(fenceStart)..<\(fenceEnd), \(stops.count) steps)")
        // Inside the block the display only ever stands at the end of what
        // had arrived, which shows the placeholder (or the chart, once its
        // closing fence has come): never its data, as code or as text.
        for stop in inside {
            let shown = String(characters[0..<stop])
            for block in MarkdownSource.chunks(shown).suffix(1).flatMap({ MarkdownDocument($0, streaming: true).blocks }) {
                switch block {
                case .code: XCTFail("Code at \(stop)")
                case .rich(let rich): if case .failed = rich.state { XCTFail("A failed chart at \(stop)") }
                case .paragraph(let text): XCTAssertFalse(String(text.characters).contains("\"type\""), "Data at \(stop)")
                default: break
                }
            }
        }
    }

    // MARK: The model's note

    func testFormatNoteOnlyForChartRequests() {
        for asking in ["東京と大阪の人口をグラフにして", "売上の推移を見せて", "円グラフで表して", "Make a bar chart of this",
                       "plot the temperatures", "これを可視化して", "グラフにはPocketAIのネイティブグラフ表示機能を使用してください。"] {
            XCTAssertNotNil(RichFormatGuide.guide(for: asking), asking)
        }
        for plain in ["こんにちは", "この段落を要約して", "Summarize this paragraph", "photograph tips", "Swiftのコードを書いて"] {
            XCTAssertNil(RichFormatGuide.guide(for: plain), plain)
        }
        // In the message's language.
        XCTAssertEqual(RichFormatGuide.guide(for: "東京と大阪の人口をグラフにして"), RichFormatGuide.chart)
        XCTAssertEqual(RichFormatGuide.guide(for: "Make a bar chart of this"), RichFormatGuide.chartInEnglish)
        XCTAssertEqual(RichFormatGuide.guide(for: "この数字で chart を作って"), RichFormatGuide.chart)
        for note in [RichFormatGuide.chart, RichFormatGuide.chartInEnglish] {
            print("RICH-NOTE format note: \(note.count) characters, \(note.utf8.count) bytes")
            XCTAssertLessThan(note.utf8.count, 1200, "The note stays short")
            // The note's own example is a chart the app draws.
            guard let start = note.range(of: "```chart\n"), let end = note.range(of: "\n```", range: start.upperBound..<note.endIndex) else {
                return XCTFail("The note shows a chart block")
            }
            XCTAssertNotNil(chart(String(note[start.upperBound..<end.lowerBound])))
        }
    }
}
