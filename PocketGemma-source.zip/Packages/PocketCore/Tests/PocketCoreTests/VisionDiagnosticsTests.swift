import XCTest
@testable import PocketCore

final class VisionDiagnosticsTests: XCTestCase {
    func testLanguageEmbeddingErrorTakesPrecedenceOverNormalVisionLogs() {
        let evidence = NativeLogEvidence(error: "ERROR: llm_litert_compiled_model_executor.cc:675 No per-layer embeddings found in inputs.",
            logLines: ["I0000 vision_litert_compiled_model_executor.cc:107 PG_COMPONENT vision_cpu_kernel=delegate_xnnpack threads=4"])
        XCTAssertEqual(evidence.failingComponent, "language_executor")
        XCTAssertNil(evidence.failedDelegate)
    }

    func testNormalExecutorMarkersDoNotIdentifyAGenericFailureComponent() {
        let evidence = NativeLogEvidence(error: "Unknown native failure",
            logLines: ["I0000 vision_litert_compiled_model_executor.cc:107 PG_COMPONENT vision_cpu_kernel=delegate_xnnpack threads=4",
                       "I0000 llm_litert_compiled_model_executor.cc:1943 PG_COMPONENT embeddings_ready_before_llm_compile"])
        XCTAssertNil(evidence.failingComponent)
        let mapping = NativeLogEvidence(error: "Failed to map section: model=tf_lite_per_layer_embedder: Cannot allocate memory", logLines: [])
        XCTAssertEqual(mapping.failingComponent, "model_loader")
        XCTAssertNil(mapping.failedDelegate)
    }

    func testPrefixedEmbeddingReadinessMarkersAreRetained() {
        var log = NativeLogBuffer()
        log.append(Data("I0000 00:00:1 123 executor_utils.cc:1227] PG_COMPONENT embeddings_initialized text_lookup=1 ple_lookup=1\nI0000 00:00:1 123 llm_litert_compiled_model_executor.cc:1943] PG_COMPONENT embeddings_ready_before_llm_compile\nI0000 00:00:1 123 llm_litert_compiled_model_executor.cc:530] PG_COMPONENT llm_vision_prefill text_lookup=1 ple_lookup=1 requires_ple=1 vision_ple=0\n".utf8))
        log.finish()
        XCTAssertEqual(log.lines.count, 3)
        XCTAssertEqual(log.discardedLines, 0)
    }

    func testEmbeddingMarkerCannotAdmitPrivateConversationOrUnrelatedSDKOutput() {
        var log = NativeLogBuffer()
        log.append(Data("{\"role\":\"user\",\"content\":\"PG_COMPONENT embeddings_initialized private\"}\nprompt: PG_COMPONENT llm_vision_prefill private\nI0000 sdk.cc:1] PG_COMPONENT unrelated_private_payload\n".utf8))
        log.finish()
        XCTAssertTrue(log.lines.isEmpty)
        XCTAssertEqual(log.discardedLines, 3)
    }

    func testVisionCPUImplementationMigratesAndRoundTripsWithoutChangingOtherPreferences() throws {
        let legacy = try JSONDecoder().decode(GenerationSettings.self, from: Data(#"{"backend":"GPU","visionBackend":"CPU","visualTokenBudget":280,"temperature":0.3}"#.utf8))
        XCTAssertEqual(legacy.visionCPUImplementation, .xnnpack)
        var changed = legacy; changed.visionCPUImplementation = .builtin
        let restored = try JSONDecoder().decode(GenerationSettings.self, from: JSONEncoder().encode(changed))
        XCTAssertEqual(restored, changed)
        XCTAssertEqual(restored.backend, .gpu); XCTAssertEqual(restored.visionBackend, .cpu)
        XCTAssertEqual(restored.temperature, 0.3); XCTAssertEqual(restored.visualTokenBudget, 280)
    }

    func testVisionCPUKernelsDoNotShareAnEngineOrWeightCache() {
        var settings = GenerationSettings()
        let standard = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true)
        settings.visionCPUImplementation = .builtin
        let builtin = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true)
        XCTAssertNotEqual(standard, builtin); XCTAssertNotEqual(standard.cacheComponent, builtin.cacheComponent)
        XCTAssertEqual(standard.modelSHA256, builtin.modelSHA256)
        XCTAssertEqual(standard.backend, .gpu); XCTAssertEqual(builtin.backend, .gpu)
        XCTAssertEqual(builtin.visionCPUImplementation, .builtin)
    }

    func testVisionKernelSelectionDoesNotRebuildTextOrGPUVisionEngine() {
        var settings = GenerationSettings(); settings.visionBackend = .gpu
        let text = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: false)
        let gpuVision = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true)
        settings.visionCPUImplementation = .builtin
        XCTAssertEqual(text, InferenceEnginePlan(model: .e2b, settings: settings, needsVision: false))
        XCTAssertEqual(gpuVision, InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true))
        XCTAssertNil(gpuVision.visionCPUImplementation)
    }

    func testSectionWarningsPreserveLoaderCauseAndRedactPrivatePaths() {
        var log = NativeLogBuffer()
        // Match official 0.18 loader messages. A chunk boundary and a final
        // unterminated warning exercise the actual stderr-buffering path.
        log.append(Data("W litert_lm_loader.cc:373] Failed to map sec".utf8))
        log.append(Data("tion: INTERNAL: Failed to map /var/mobile/Containers/private-model.litertlm: Cannot allocate memory\nW litert_lm_loader.cc:364] Section not found: TFLiteModel\nW litert_lm_loader.cc:443] TFLite model for type: tf_lite_vision_encoder not found. Skipping.".utf8))
        log.finish()
        XCTAssertEqual(log.lines.count, 3)
        XCTAssertEqual(log.discardedLines, 0)
        XCTAssertTrue(log.lines[0].contains("Failed to map section:"))
        XCTAssertTrue(log.lines[0].contains("Cannot allocate memory"))
        XCTAssertFalse(log.lines.joined().contains("private-model"))
        XCTAssertFalse(log.lines.joined().contains("/var/mobile/"))
        XCTAssertTrue(log.lines[1].contains("Section not found: TFLiteModel"))
        XCTAssertTrue(log.lines[2].contains("tf_lite_vision_encoder not found. Skipping."))
        let evidence = NativeLogEvidence(error: "tf_lite_vision_encoder not found in the model.", logLines: log.lines)
        XCTAssertNil(evidence.failedDelegate)
        XCTAssertNil(evidence.xnnpackPhase)
        XCTAssertTrue(evidence.operatorNames.isEmpty)
        XCTAssertTrue(evidence.delegateNodes.isEmpty)
    }

    func testSectionWarningWordsCannotAdmitConversationPayloads() {
        var log = NativeLogBuffer()
        log.append(Data("{\"role\":\"user\",\"content\":\"Failed to map section: private conversation\"}\nprompt: Section not found: private prompt\nresponse: not found. Skipping private response\n".utf8))
        log.finish()
        XCTAssertTrue(log.lines.isEmpty)
        XCTAssertEqual(log.discardedLines, 3)
    }

    func testPhysical2374ReshapeIdentifiesPhaseWithoutInventingOperatorOrOOM() {
        let evidence = NativeLogEvidence(error: "ERROR: [litert_compiled_model.cc:164] Failed to allocate tensors",
            logLines: ["ERROR: XNNPack delegate failed to reshape runtime", "ERROR: Node number 2374 (TfLiteXNNPackDelegate) failed to prepare."])
        XCTAssertEqual(evidence.failedDelegate, "XNNPACK")
        XCTAssertEqual(evidence.xnnpackPhase, "reshape_runtime")
        XCTAssertEqual(evidence.delegateNodes, [2374])
        XCTAssertTrue(evidence.operatorNames.isEmpty)
    }
    func testExternalValueReshapeIsDistinguishedFromInternalRuntimeReshape() {
        let evidence = NativeLogEvidence(error: "XNNPack delegate failed to reshape external value", logLines: [])
        XCTAssertEqual(evidence.xnnpackPhase, "reshape_external_value")
    }
    func testUnderlyingXNNPACKOperatorMessageSurvivesFilterWithoutConversation() {
        var buffer = NativeLogBuffer()
        buffer.append(Data("Error in XNNPACK: failed to reshape batch matrix multiply operator: incompatible dimensions 12 and 40\n{\"role\":\"user\",\"content\":\"Error in XNNPACK: private conversation\"}\n".utf8))
        buffer.finish()
        XCTAssertEqual(buffer.lines.count, 1)
        XCTAssertTrue(buffer.lines[0].contains("incompatible dimensions"))
        XCTAssertFalse(buffer.lines.joined().contains("private conversation"))
    }
    func testOldNativeEvidenceStillDecodesWithoutNewPhaseField() throws {
        let json = #"{"observedDelegates":["XNNPACK"],"failedDelegate":"XNNPACK","operatorNames":[],"delegateNodes":[1480],"sourceLocations":[]}"#
        let record = try JSONDecoder().decode(NativeLogEvidence.self, from: Data(json.utf8))
        XCTAssertEqual(record.delegateNodes, [1480]); XCTAssertNil(record.xnnpackPhase)
    }
    func testNativePatchCountIsOnlyFromObservedPreprocessingMessage() {
        let line = "Resize image from 1200x1600 to 672x912 which will result in 2394 patches to fit the max_num_patches: 2520 limit."
        var buffer = NativeLogBuffer(); buffer.append(Data((line+"\n").utf8)); buffer.finish()
        let record = NativeLogEvidence(error: "", logLines: buffer.lines)
        XCTAssertEqual(record.preparedImagePatches, [2394])
        XCTAssertNil(NativeLogEvidence(error: "Failed to allocate tensors", logLines: []).preparedImagePatches)
    }
    func testLegacySettingsMigrateOnlyVisionBackendAndPreservePreferences() throws {
        let json = #"{"maxTokens":4096,"maxOutputTokens":640,"topK":12,"topP":0.88,"temperature":0.25,"visualTokenBudget":70,"backend":"GPU","enableThinking":true,"enableSpeculativeDecoding":false,"systemPrompt":"My saved prompt"}"#
        let settings = try JSONDecoder().decode(GenerationSettings.self, from: Data(json.utf8))
        XCTAssertEqual(settings.backend, .gpu); XCTAssertEqual(settings.visionBackend, .cpu)
        XCTAssertEqual(settings.maxTokens, 4096); XCTAssertEqual(settings.maxOutputTokens, 640)
        XCTAssertEqual(settings.visualTokenBudget, 70); XCTAssertEqual(settings.topK, 12)
        XCTAssertEqual(settings.topP, 0.88); XCTAssertEqual(settings.temperature, 0.25)
        XCTAssertTrue(settings.enableThinking); XCTAssertFalse(settings.enableSpeculativeDecoding)
        XCTAssertEqual(settings.systemPrompt, "My saved prompt")
        XCTAssertFalse(settings.usesDefaultSystemPrompt)
        XCTAssertEqual(settings.systemMessage(for: .e2b), "My saved prompt")
    }
    /// The default prompt 183 and earlier saved, in Japanese, is still the
    /// default: the model reads the instruction about the reply's language
    /// instead, in every app language. A prompt the person wrote, in any
    /// language, goes to the model as written and stays as saved.
    func testDefaultPromptReadsAsTheLanguageInstructionAndOwnPromptsStay() throws {
        let saved = #"{"systemPrompt":"あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"}"#
        let old = try JSONDecoder().decode(GenerationSettings.self, from: Data(saved.utf8))
        XCTAssertTrue(old.usesDefaultSystemPrompt)
        XCTAssertEqual(old.systemMessage(for: .e2b), GenerationSettings.defaultInstruction)
        XCTAssertEqual(old.normalized(for: .e2b).systemMessage(for: .e2b), GenerationSettings.defaultInstruction)
        XCTAssertEqual(try JSONDecoder().decode(GenerationSettings.self, from: JSONEncoder().encode(old)).systemPrompt,
                       GenerationSettings.defaultSystemPrompt)
        XCTAssertTrue(GenerationSettings().usesDefaultSystemPrompt)
        XCTAssertTrue(GenerationSettings.defaultInstruction.contains("latest message"))
        for own in ["あなたは親切で率直なアシスタントです。", "Reply briefly in Japanese.", "請用繁體中文回答。"] {
            var settings = GenerationSettings(); settings.systemPrompt = own
            XCTAssertFalse(settings.usesDefaultSystemPrompt, own)
            XCTAssertEqual(settings.systemMessage(for: .e2b), own)
            XCTAssertEqual(settings.normalized(for: .e2b).systemPrompt, own)
        }
    }
    func testIndependentBackendSelectionsSurvivePerModelRoundTrip() throws {
        var e2b = GenerationSettings(); e2b.backend = .gpu; e2b.visionBackend = .gpu
        var e4b = GenerationSettings(); e4b.backend = .gpu; e4b.visionBackend = .cpu
        let saved = [ModelSpec.e2b.id: e2b, ModelSpec.e4b.id: e4b]
        let decoded = try JSONDecoder().decode([String: GenerationSettings].self, from: JSONEncoder().encode(saved))
        XCTAssertEqual(decoded, saved)
    }
    func testThreeBackendPlansPreserveModelAndTokensButNeverShareCaches() {
        for model in [ModelSpec.e2b, .e4b] {
            var settings = GenerationSettings(); settings.visualTokenBudget = 280
            let configurations: [(ExecutionBackend, ExecutionBackend)] = [(.gpu, .gpu), (.gpu, .cpu), (.cpu, .cpu)]
            let plans = configurations.map { main, vision -> InferenceEnginePlan in
                settings.backend = main; settings.visionBackend = vision
                return InferenceEnginePlan(model: model, settings: settings, needsVision: true)
            }
            XCTAssertEqual(Set(plans.map(\.cacheComponent)).count, 3)
            for plan in plans {
                XCTAssertEqual(plan.modelSHA256, model.sha256)
                XCTAssertEqual(plan.maxTokens, 4096)
                XCTAssertEqual(plan.visualTokenBudget, model.id == ModelSpec.e4b.id ? 70 : 280)
            }
            XCTAssertEqual(plans[1].backend, .gpu); XCTAssertEqual(plans[1].visionBackend, .cpu)
        }
    }
    func testVisionChoiceDoesNotChangeTextEngineOrTextCache() {
        var settings = GenerationSettings()
        let before = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false)
        settings.visionBackend = .gpu
        let after = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false)
        XCTAssertEqual(before, after); XCTAssertEqual(before.cacheComponent, after.cacheComponent)
        XCTAssertEqual(after.backend, .gpu); XCTAssertNil(after.visionBackend)
    }
    func testGenericVisionDelegateErrorDoesNotInventMetalXNNPACKOrOperator() {
        let evidence = NativeLogEvidence(error: "vision_litert_compiled_model_executor.cc:313\nlitert_compiled_model.h:1961 Failed to modify graph with delegate", logLines: [])
        XCTAssertNil(evidence.failedDelegate); XCTAssertTrue(evidence.operatorNames.isEmpty)
        XCTAssertTrue(evidence.observedDelegates.isEmpty); XCTAssertTrue(evidence.delegateNodes.isEmpty)
        XCTAssertEqual(evidence.failingComponent, "vision_executor")
        XCTAssertEqual(evidence.sourceLocations, ["vision_litert_compiled_model_executor.cc:313", "litert_compiled_model.h:1961"])
    }
    func testXNNPACKDelegateNodeIsNotReportedAsUnderlyingOperator() {
        let evidence = NativeLogEvidence(error: "Failed to allocate tensors", logLines: ["ERROR: XNNPack delegate failed to reshape runtime", "Node number 1480 (TfLiteXNNPackDelegate) failed to prepare."])
        XCTAssertEqual(evidence.failedDelegate, "XNNPACK")
        XCTAssertEqual(evidence.delegateNodes, [1480]); XCTAssertTrue(evidence.operatorNames.isEmpty)
    }
    func testUnsupportedOperatorIsRecordedOnlyWhenNamedInNativeError() {
        let evidence = NativeLogEvidence(error: "Didn't find op for builtin opcode 'STABLEHLO_COMPOSITE' version '1'.", logLines: ["Created a Metal device."])
        XCTAssertEqual(evidence.operatorNames, ["STABLEHLO_COMPOSITE"])
        XCTAssertEqual(evidence.observedDelegates, ["Metal"]); XCTAssertNil(evidence.failedDelegate)
    }
    func testRegisteredDelegateAndGenericFailureDoNotIdentifyTheFailedDelegate() {
        let evidence = NativeLogEvidence(error: "Created TensorFlow Lite XNNPACK delegate for CPU.\nCreated a Metal device.\nFailed to modify graph with delegate", logLines: [])
        XCTAssertEqual(evidence.observedDelegates, ["XNNPACK", "Metal"])
        XCTAssertNil(evidence.failedDelegate)
    }
    func testUnnamedUnsupportedOperatorDoesNotBecomeAnEnglishWord() {
        let evidence = NativeLogEvidence(error: "Unsupported operator encountered while preparing model", logLines: [])
        XCTAssertTrue(evidence.operatorNames.isEmpty)
    }
    func testNativeBufferHandlesChunkBoundariesFiltersConversationAndRedactsPaths() {
        var log = NativeLogBuffer()
        log.append(Data("Private unrelated text\n{\"role\":\"user\",\"content\":\"XNNPACK delegate prompt\"}\nNode num".utf8))
        log.append(Data("ber 1480 (TfLiteXNNPackDelegate) failed to prepare.\nFailed to decode image /var/mobile/Containers/private-image.jpg\n".utf8))
        log.finish()
        XCTAssertEqual(log.lines.count, 2); XCTAssertEqual(log.discardedLines, 2)
        XCTAssertTrue(log.lines[0].contains("1480"))
        XCTAssertFalse(log.lines.joined().contains("private-image"))
        XCTAssertFalse(log.lines.joined().contains("Private unrelated"))
    }
    func testVisionRunFailureDistinguishesEncoderFromAdapterWithoutGuessingDelegate() {
        for part in ["vision_encoder", "vision_adapter"] {
            let text = "PG_VISION_FAILURE component=\(part) signature=1 litert_status=2: Failed to invoke the compiled model"
            let evidence = NativeLogEvidence(error: text, logLines: [
                "I0000 PG_VISION_OK component=vision_encoder signature=1"
            ])
            XCTAssertEqual(evidence.failingComponent, part)
            XCTAssertNil(evidence.failedDelegate)
        }
        XCTAssertNil(NativeLogEvidence(error: "unrelated failure", logLines: [
            "I0000 PG_VISION_OK component=vision_encoder signature=1"
        ]).failingComponent)
    }
    func testVisionBufferLayoutIsRetainedWithoutAcceptingConversationData() {
        var log = NativeLogBuffer()
        log.append(Data(("I0000 PG_VISION_RUN component=vision_encoder signature=1 inputs=0:type=2 dims=1,2520,2, bytes=20160\n" +
            "E0000 PG_VISION_FAILURE component=vision_encoder signature=1 litert_status=2\n" +
            "TFLite reporter: Node number 2374 (TfLiteXNNPackDelegate) failed to prepare.\n" +
            "TFLite reporter: Failed to read /var/mobile/Containers/private.jpg\n" +
            "PG_VISION_RUN component=vision_encoder prompt: do not retain\n").utf8))
        log.finish()
        XCTAssertEqual(log.lines.count, 4)
        XCTAssertTrue(log.lines[0].contains("2520"))
        XCTAssertFalse(log.lines.joined().contains("private.jpg"))
        XCTAssertFalse(log.lines.joined().contains("do not retain"))
        XCTAssertEqual(NativeLogEvidence(error: "", logLines: log.lines).failedDelegate, "XNNPACK")
    }
    func testNativeBufferStaysBoundedAndSignalsDroppedEvidence() {
        var log = NativeLogBuffer()
        for _ in 0..<1000 { log.append(Data("ERROR: XNNPack delegate failed to reshape runtime\n".utf8)) }
        log.finish()
        XCTAssertLessThanOrEqual(log.lines.count, 64)
        XCTAssertLessThanOrEqual(log.lines.joined().utf8.count, 8192)
        XCTAssertTrue(log.truncated)
    }
}
