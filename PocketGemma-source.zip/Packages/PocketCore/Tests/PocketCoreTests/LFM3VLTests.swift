import XCTest
@testable import PocketCore

/// LFM3-VL 2B on llama.cpp (1.1.0 (234)): its two pinned files, which
/// download, check and delete as one model, and what it may take in.
final class LFM3VLTests: XCTestCase {
    func testItsTwoFilesArePinned() {
        let vl = ModelSpec.lfm3VL, projector = ModelSpec.lfm3VLProjector
        XCTAssertEqual(vl.runtime, .llamaCpp); XCTAssertEqual(projector.runtime, .llamaCpp)
        XCTAssertEqual(vl.byteCount, 1_049_615_648)
        XCTAssertEqual(vl.sha256, "621c455376cb96a20891697deb9975c6fb47dd5ea98ed3ad1f3b7e8f24f0b1e6")
        XCTAssertEqual(projector.byteCount, 203_031_872)
        XCTAssertEqual(projector.sha256, "c5c5b58d544a18da919172d2d0368090ea1a4a351b6feb7f8a326a264a5918ab")
        for spec in [vl, projector] {
            XCTAssertTrue(spec.downloadURL.absoluteString.hasPrefix(
                "https://huggingface.co/LiquidAI/LFM3-VL-2B-GGUF/resolve/b36554cfd35854b06429900131730cd80f092cdb/\(spec.fileName)"), spec.id)
        }
        XCTAssertEqual(vl.family, "LFM")
        XCTAssertTrue(vl.isTestVersion)
        XCTAssertFalse(vl.isDeveloperOnly); XCTAssertFalse(vl.isStarter); XCTAssertFalse(vl.isLocked)
    }

    /// The projector is a file of the model, never a model of its own.
    func testTheProjectorBelongsToTheModel() {
        let vl = ModelSpec.lfm3VL, projector = ModelSpec.lfm3VLProjector
        XCTAssertEqual(vl.parts.map(\.id), [projector.id])
        XCTAssertEqual(vl.files.map(\.id), [vl.id, projector.id])
        XCTAssertEqual(projector.owner.id, vl.id)
        XCTAssertEqual(vl.owner.id, vl.id)
        XCTAssertNil(ModelSpec.find(projector.id), "it can't be chosen")
        XCTAssertEqual(ModelSpec.findFile(projector.id)?.id, projector.id)
        XCTAssertEqual(ModelSpec.findFile(vl.id)?.id, vl.id)
        XCTAssertFalse(ModelSpec.catalog.contains { $0.id == projector.id })
        XCTAssertEqual(ModelSpec.allFiles.count, ModelSpec.catalog.count + 1)
        XCTAssertEqual(vl.downloadByteCount, 1_049_615_648 + 203_031_872)
        XCTAssertEqual(vl.sizeLabel, ByteCountFormatter.string(fromByteCount: 1_252_647_520, countStyle: .decimal))
        // Every other model is one file, as before.
        for spec in ModelSpec.catalog where spec.id != vl.id {
            XCTAssertEqual(spec.files.map(\.id), [spec.id], spec.id)
            XCTAssertEqual(spec.downloadByteCount, spec.byteCount, spec.id)
            XCTAssertEqual(spec.owner.id, spec.id, spec.id)
        }
    }

    /// Installed only with both files checked and saved.
    func testItIsInstalledOnlyWithBothFiles() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let library = ModelLibrary(directory: folder)
        let vl = ModelSpec.lfm3VL, projector = ModelSpec.lfm3VLProjector
        func save(_ spec: ModelSpec) throws {
            FileManager.default.createFile(atPath: library.modelURL(spec).path, contents: nil)
            let handle = try FileHandle(forWritingTo: library.modelURL(spec))
            try handle.truncate(atOffset: UInt64(spec.byteCount))
            try handle.close()
            try spec.sha256.write(to: library.receiptURL(spec), atomically: true, encoding: .utf8)
        }
        XCTAssertFalse(library.isInstalled(vl))
        try save(vl)
        XCTAssertTrue(library.hasFile(vl))
        XCTAssertFalse(library.isInstalled(vl), "the projector is still missing")
        try save(projector)
        XCTAssertTrue(library.hasFile(projector))
        XCTAssertTrue(library.isInstalled(vl))
        try FileManager.default.removeItem(at: library.receiptURL(projector))
        XCTAssertFalse(library.isInstalled(vl))
        XCTAssertTrue(library.hasFile(vl))
    }

    /// Photos and text: no videos, files or web search; the LiteRT-LM
    /// drafter never.
    func testItTakesPhotosOnly() {
        let vl = ModelSpec.lfm3VL, capabilities = vl.capabilities
        XCTAssertEqual(capabilities.photos, .native)
        XCTAssertFalse(capabilities.videos)
        XCTAssertFalse(capabilities.documents)
        XCTAssertTrue(vl.supportsVision); XCTAssertFalse(vl.supportsWebSearch); XCTAssertFalse(vl.supportsSpeculation)
        XCTAssertTrue(vl.supportsThinking); XCTAssertFalse(capabilities.reasons)
        XCTAssertTrue(vl.supportsGPU); XCTAssertTrue(vl.supportsCPU); XCTAssertTrue(capabilities.startsOnGPU)
        XCTAssertTrue(capabilities.guardsReplies)
        XCTAssertEqual(vl.maximumContextTokens, 8192)
        let policy = ModelAttachmentPolicy(model: vl)
        XCTAssertTrue(policy.allowsImages); XCTAssertTrue(policy.allowsPhotos)
        XCTAssertFalse(policy.allowsVideo); XCTAssertFalse(policy.hearsVideo); XCTAssertFalse(policy.allowsDocuments)
        XCTAssertFalse(policy.coarsePhotos)
        XCTAssertEqual(policy.summary, "テキスト・写真")
        XCTAssertEqual(policy.guidance, "写真を利用できます。動画やファイルを使うにはGemma 4 E2Bへ切り替えてください。")
        let photo = ChatAttachment(kind: .image, name: "a.jpg", storedName: "a.jpg", imageNames: ["a-image.jpg"])
        let video = ChatAttachment(kind: .video, name: "v.mp4", storedName: "v.mp4", imageNames: ["a.jpg", "b.jpg", "c.jpg"])
        XCTAssertTrue(policy.allows(photo))
        XCTAssertFalse(policy.allows(video))
        XCTAssertNoThrow(try policy.validateNewAttachments([photo]))
        XCTAssertThrowsError(try policy.validateNewAttachments([video]))
    }

    /// Gemma's photos and videos stay as they were.
    func testGemmaKeepsItsVideos() {
        for spec in [ModelSpec.e2b, .e4b] {
            XCTAssertTrue(spec.capabilities.videos, spec.id)
            XCTAssertTrue(ModelAttachmentPolicy(model: spec).allowsVideo, spec.id)
            XCTAssertTrue(spec.supportsSpeculation, spec.id)
        }
        XCTAssertEqual(ModelAttachmentPolicy(model: .e2b).summary, "テキスト・写真・動画・ファイル")
        for spec in ModelSpec.catalog where spec.capabilities.photos != .native {
            XCTAssertFalse(spec.capabilities.videos, spec.id)
        }
    }

    /// It starts with LFM3's sampling.
    func testItStartsWithLFM3sSampling() {
        let settings = GenerationSettings(for: .lfm3VL).normalized(for: .lfm3VL)
        XCTAssertEqual(settings.temperature, 0.1); XCTAssertEqual(settings.topK, 50); XCTAssertEqual(settings.topP, 1)
        XCTAssertEqual(settings.backend, .gpu)
        XCTAssertFalse(settings.enableThinking)
        XCTAssertEqual(settings.thinkingTokenBudget(on: .lfm3VL), 0)
    }
}
