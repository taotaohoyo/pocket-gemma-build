import XCTest
@testable import PocketCore

final class AttachmentPolicyTests: XCTestCase {
    private var image: ChatAttachment {
        ChatAttachment(kind: .image, name: "photo.jpg", storedName: "original.jpg", imageNames: ["normalized.jpg"])
    }
    func testE4BBlocksAllNewMediaAndRemainsTextOnly() {
        let policy = ModelAttachmentPolicy(model: .e4b)
        let text = ChatAttachment(kind: .file, name: "note.txt", storedName: "note.txt", extractedText: "hello")
        XCTAssertFalse(policy.allowsImages); XCTAssertFalse(policy.allowsTextFiles)
        XCTAssertThrowsError(try policy.validateNewAttachments([image]))
        XCTAssertThrowsError(try policy.validateNewAttachments([text]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov")]))
        XCTAssertNoThrow(try policy.validateNewAttachments([]))
        XCTAssertTrue(policy.guidance.contains("E2B"))
    }
    func testE2BPreservesNormalizedImagesAndVerifiedTextOnly() {
        let policy = ModelAttachmentPolicy(model: .e2b)
        XCTAssertNoThrow(try policy.validateNewAttachments([image]))
        let text = ChatAttachment(kind: .file, name: "note.TXT", storedName: "text.txt", extractedText: "日本語😊")
        XCTAssertNoThrow(try policy.validateNewAttachments([text]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .file, name: "file.pdf", storedName: "file.pdf", extractedText: "text")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .file, name: "note.txt", storedName: "note.txt")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov", imageNames: ["frame.jpg"])]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .image, name: "photo", storedName: "photo")]))
    }
    func testOldE4BImagesCannotReactivateVisionOrModifyArchive() {
        let image = self.image
        let messages = [ChatMessage(role: .user, text: "この写真", attachments: [image]),
                        ChatMessage(role: .assistant, text: "以前の回答")]
        let result = ModelAttachmentPolicy(model: .e4b).inferenceHistory(messages)
        XCTAssertEqual(messages[0].media, [image])
        XCTAssertTrue(result.flatMap(\.media).isEmpty)
        XCTAssertEqual(result.map(\.id), messages.map(\.id))
        XCTAssertTrue(result[0].text.contains("読み込んでいません"))
        XCTAssertEqual(result[1], messages[1])
        XCTAssertEqual(ModelAttachmentPolicy(model: .e2b).inferenceHistory(messages), messages)
        XCTAssertEqual(ModelAttachmentPolicy(model: .e4b).inferenceHistory(result), result)
    }
    func testPickerResultBelongsToItsOriginalConversationAndModel() {
        let thread = UUID()
        let context = AttachmentImportContext(threadID: thread, modelID: ModelSpec.e2b.id)
        XCTAssertTrue(context.matches(threadID: thread, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: UUID(), modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: thread, modelID: ModelSpec.e4b.id))
        XCTAssertFalse(context.matches(threadID: nil, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(AttachmentImportContext(threadID: nil, modelID: ModelSpec.e2b.id).matches(threadID: nil, modelID: ModelSpec.e2b.id))
    }
    func test12BAcceptsImagesAndConvertedDocuments() {
        let policy = ModelAttachmentPolicy(model: .gemma12b)
        XCTAssertFalse(policy.isTemporarilyLocked)
        XCTAssertTrue(policy.allowsImages); XCTAssertTrue(policy.allowsDocuments)
        XCTAssertNoThrow(try policy.validateNewAttachments([image]))
        for name in ["report.pdf", "memo.docx", "data.csv", "note.txt"] {
            XCTAssertNoThrow(try policy.validateNewAttachments([ChatAttachment(kind: .file, name: name, storedName: name, extractedText: "本文")]), name)
        }
        // Still text extracted on device: an empty document or a video is refused.
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .file, name: "empty.pdf", storedName: "empty.pdf")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov", imageNames: ["frame.jpg"])]))
        XCTAssertEqual(policy.summary, "テキスト・写真・ファイル")
        // The smaller models keep their scopes.
        XCTAssertFalse(ModelAttachmentPolicy(model: .e2b).allowsDocuments)
        XCTAssertFalse(ModelAttachmentPolicy(model: .e4b).allowsImages)
    }
    func testTextModelRejectsImageWithDisguisedFileKind() {
        let disguised = ChatAttachment(kind: .file, name: "note.txt", storedName: "file.txt", imageNames: ["hidden.jpg"], extractedText: "x")
        for model in [ModelSpec.e2b, .e4b, .gemma12b, .qwen3, .qwen25] {
            XCTAssertThrowsError(try ModelAttachmentPolicy(model: model).validateNewAttachments([disguised]))
        }
    }
}
