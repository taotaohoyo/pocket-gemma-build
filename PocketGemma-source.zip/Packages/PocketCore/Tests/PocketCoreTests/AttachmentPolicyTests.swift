import XCTest
@testable import PocketCore

final class AttachmentPolicyTests: XCTestCase {
    private var image: ChatAttachment {
        ChatAttachment(kind: .image, name: "photo.jpg", storedName: "original.jpg", imageNames: ["normalized.jpg"])
    }
    /// A video as the importer keeps it: its scenes as images, no text.
    private func video(scenes: Int = 3) -> ChatAttachment {
        ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov", thumbnailName: scenes > 0 ? "scene-0.jpg" : nil,
                       imageNames: (0..<scenes).map { "scene-\($0).jpg" }, duration: 9)
    }
    private func file(_ name: String, _ text: String? = "日本語😊") -> ChatAttachment {
        ChatAttachment(kind: .file, name: name, storedName: name, extractedText: text)
    }
    /// A photo read by OCR for a text-only model: a thumbnail to show, its
    /// text for the model, and no image for the model to see.
    private var photoText: ChatAttachment {
        ChatAttachment(kind: .image, name: "receipt.jpg", storedName: "receipt.jpg", thumbnailName: "thumb.jpg",
                       extractedText: "合計 1,280円")
    }
    /// E4B takes photos at 70 or 140 image tokens, the settings that fit the
    /// phone's address space (2026-10-20), and says fine print reads better
    /// on E2B.
    func testE4BTakesPhotosAt70Or140ImageTokensAndFiles() {
        let policy = ModelAttachmentPolicy(model: .e4b)
        XCTAssertTrue(policy.allowsImages); XCTAssertTrue(policy.coarsePhotos); XCTAssertTrue(policy.allowsDocuments)
        XCTAssertFalse(policy.readsPhotoText); XCTAssertTrue(policy.allowsPhotos)
        XCTAssertEqual(policy.photoTokens, 140)
        XCTAssertNoThrow(try policy.validateNewAttachments([image]))
        XCTAssertThrowsError(try policy.validateNewAttachments([photoText]), "E4B reads the photo itself")
        XCTAssertNoThrow(try policy.validateNewAttachments([file("note.txt"), file("資料.pdf")]))
        // A video's scenes reach E4B as its photos do.
        XCTAssertTrue(policy.allowsVideo)
        XCTAssertNoThrow(try policy.validateNewAttachments([video()]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov")]))
        XCTAssertNoThrow(try policy.validateNewAttachments([]))
        XCTAssertTrue(policy.guidance.contains(ModelAttachmentPolicy.coarsePhotoNote))
        XCTAssertTrue(policy.guidance.contains(ModelAttachmentPolicy.videoNote))
        XCTAssertEqual(policy.summary, "テキスト・写真・動画・ファイル · 写真は粗め")
        // A budget saved earlier (280, the default) runs at the photo
        // detail's tokens in E4B's chats, 70 for 高速; the developer probe
        // still runs the budget it names.
        var settings = GenerationSettings(); settings.visualTokenBudget = 280
        XCTAssertEqual(settings.normalized(for: .e4b).visualTokenBudget, 70)
        XCTAssertEqual(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true).visualTokenBudget, 70)
        let probe = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true, visualTokenBudget: 280)
        XCTAssertEqual(probe.visualTokenBudget, 280); XCTAssertTrue(probe.cacheComponent.contains("-v280-"))
        XCTAssertEqual(ModelSpec.e4b.visualTokenBudgets, [70, 140, 280])
    }
    /// E4B reads photos at the detail chosen in the composer: 高速 at 70
    /// image tokens on the saved backend, 深く at 140 with the language model
    /// on the CPU while the chat has photos (140 on the GPU failed on the
    /// phone, on the CPU it fit). Text-only chats keep the saved backend, and
    /// the choice is saved with E4B's settings.
    func testE4BPhotoDetailSetsTheTokensAndBackendOfPhotoChats() throws {
        XCTAssertEqual(ModelSpec.e4b.photoDetails, [.fast, .deep])
        XCTAssertEqual(ModelSpec.e4b.chatVisualTokenBudgets, [70, 140])
        XCTAssertEqual(PhotoDetail.fast.title, "高速"); XCTAssertEqual(PhotoDetail.deep.title, "深く")
        var settings = GenerationSettings()
        XCTAssertEqual(settings.photoDetail, .fast)
        let fast = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true)
        XCTAssertEqual(fast.backend, .gpu); XCTAssertEqual(fast.visualTokenBudget, 70)
        settings.photoDetail = .deep
        XCTAssertEqual(settings.normalized(for: .e4b).visualTokenBudget, 140)
        let deep = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true)
        XCTAssertEqual(deep.backend, .cpu); XCTAssertEqual(deep.visionBackend, .cpu)
        XCTAssertEqual(deep.visualTokenBudget, 140)
        XCTAssertTrue(deep.cacheComponent.hasSuffix("/CPU-vision-CPU-kernel-xnnpack-v140-ctx4096-mtp0"), deep.cacheComponent)
        XCTAssertNotEqual(fast, deep); XCTAssertNotEqual(fast.cacheComponent, deep.cacheComponent)
        // Without photos both keep the saved GPU; only 高速 adds the drafter.
        let text = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false)
        let fastText = InferenceEnginePlan(model: .e4b, settings: GenerationSettings(), needsVision: false)
        XCTAssertEqual(text.backend, .gpu); XCTAssertNil(text.visualTokenBudget)
        XCTAssertEqual(fastText.backend, .gpu); XCTAssertNil(fastText.visualTokenBudget)
        XCTAssertFalse(text.speculativeDecoding); XCTAssertTrue(fastText.speculativeDecoding)
        // A CPU chosen for the language model stays in 高速 too.
        settings.backend = .cpu; settings.photoDetail = .fast
        XCTAssertEqual(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true).backend, .cpu)
        // Saved with the settings; settings saved before the choice, or with
        // a value this version doesn't know, read as 高速.
        var saved = GenerationSettings(); saved.photoDetail = .deep
        XCTAssertEqual(try JSONDecoder().decode(GenerationSettings.self, from: JSONEncoder().encode(saved)).photoDetail, .deep)
        let older = try JSONDecoder().decode(GenerationSettings.self, from: Data(#"{"backend":"GPU","visualTokenBudget":280}"#.utf8))
        XCTAssertEqual(older.photoDetail, .fast)
        let unknown = try JSONDecoder().decode(GenerationSettings.self, from: Data(#"{"photoDetail":"finest","temperature":0.3}"#.utf8))
        XCTAssertEqual(unknown.photoDetail, .fast); XCTAssertEqual(unknown.temperature, 0.3)
    }
    /// 高速 also writes faster: brief replies for every turn, no thinking,
    /// and the MTP drafter for turns without photos (E4B's photos leave too
    /// little address space on the phone to add it there). 深く keeps what
    /// was saved, and other models are unchanged whatever their settings say.
    func testE4BFastRepliesAreBriefNeverThinkAndDraftWithoutPhotos() {
        var settings = GenerationSettings(); settings.enableThinking = true
        let prompt = GenerationSettings.defaultSystemPrompt
        XCTAssertTrue(settings.isFast(on: .e4b))
        XCTAssertEqual(settings.systemMessage(for: .e4b), prompt + "\n" + GenerationSettings.briefReplyNote)
        XCTAssertFalse(settings.normalized(for: .e4b).enableThinking)
        let text = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false)
        let photo = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true)
        XCTAssertTrue(text.speculativeDecoding); XCTAssertFalse(photo.speculativeDecoding)
        XCTAssertTrue(text.cacheComponent.hasSuffix("/GPU-vision-none-kernel-none-v0-ctx4096-mtp1"), text.cacheComponent)
        XCTAssertTrue(photo.cacheComponent.hasSuffix("-v70-ctx4096-mtp0"), photo.cacheComponent)
        // A custom prompt keeps its words; the note follows it.
        settings.systemPrompt = "Answer as a pirate."
        XCTAssertEqual(settings.normalized(for: .e4b).systemMessage(for: .e4b), "Answer as a pirate.\n" + GenerationSettings.briefReplyNote)
        // 深く: the prompt as written, thinking and the drafter as saved.
        settings.photoDetail = .deep
        XCTAssertFalse(settings.isFast(on: .e4b))
        XCTAssertEqual(settings.systemMessage(for: .e4b), "Answer as a pirate.")
        XCTAssertTrue(settings.normalized(for: .e4b).enableThinking)
        XCTAssertFalse(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false).speculativeDecoding)
        settings.enableSpeculativeDecoding = true
        XCTAssertTrue(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false).speculativeDecoding)
        XCTAssertTrue(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true).speculativeDecoding)
        // Saved on, the drafter also runs 高速's photo turns.
        settings.photoDetail = .fast
        XCTAssertTrue(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true).speculativeDecoding)
        // E2B and Qwen read as 高速 but have no choice: nothing changes.
        var other = GenerationSettings(); other.enableThinking = true
        for model in [ModelSpec.e2b, .qwen3, .qwen25] {
            XCTAssertFalse(other.isFast(on: model), model.name)
            XCTAssertEqual(other.normalized(for: model).systemMessage(for: model), prompt, model.name)
            XCTAssertEqual(other.normalized(for: model).enableThinking, model.supportsThinking, model.name)
            XCTAssertFalse(InferenceEnginePlan(model: model, settings: other, needsVision: false).speculativeDecoding, model.name)
        }
    }
    /// Only E4B offers the choice: E2B keeps 280 on its saved backend, and a
    /// 深く that reached another model's settings reads as 高速.
    func testOnlyE4BOffersPhotoDetail() {
        var settings = GenerationSettings(); settings.photoDetail = .deep
        for model in [ModelSpec.e2b, .qwen3, .qwen25] {
            XCTAssertTrue(model.photoDetails.isEmpty, model.name)
            let normalized = settings.normalized(for: model)
            XCTAssertEqual(normalized.photoDetail, .fast, model.name)
            XCTAssertEqual(normalized.languageBackend(needsVision: true), .gpu, model.name)
        }
        let e2b = InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true)
        XCTAssertEqual(e2b.backend, .gpu); XCTAssertEqual(e2b.visualTokenBudget, 280)
        XCTAssertEqual(ModelSpec.e2b.chatVisualTokenBudgets, [70, 140, 280])
    }
    /// さらに深く is offered only where the launch's address space has room
    /// for it: TestFlight's 68.7 GB largest free block on the phone, not the
    /// free Apple ID's 6.44 GB. Its photos take 280 image tokens with the
    /// language model on its saved backend; its replies always think, in room
    /// of their own, and are asked for care. Without the room a saved
    /// さらに深く reads as 深く, and the choice saved for 深く's thinking stays.
    func testE4BDeeperNeedsTheRoomAndThinksInRoomOfItsOwn() throws {
        defer { PhotoDetail.offer(atLaunch: nil) }
        func launch(largestFree: UInt64) -> AddressSpace {
            AddressSpace(range: 545_000_000_000, free: largestFree, largestFree: largestFree, regions: 1)
        }
        var settings = GenerationSettings(); settings.photoDetail = .deeper
        for space in [nil, launch(largestFree: 6_440_000_000), launch(largestFree: PhotoDetail.deeperAddressSpace - 1)] {
            PhotoDetail.offer(atLaunch: space)
            XCTAssertEqual(ModelSpec.e4b.photoDetails, [.fast, .deep])
            XCTAssertEqual(settings.normalized(for: .e4b).photoDetail, .deep)
            XCTAssertEqual(settings.normalized(for: .e4b).visualTokenBudget, 140)
            XCTAssertFalse(settings.isDeeper(on: .e4b)); XCTAssertFalse(settings.thinks(on: .e4b))
            XCTAssertTrue(ModelAttachmentPolicy(model: .e4b).coarsePhotos)
        }
        PhotoDetail.offer(atLaunch: launch(largestFree: 68_720_000_000))
        XCTAssertEqual(ModelSpec.e4b.photoDetails, [.fast, .deep, .deeper])
        XCTAssertEqual(ModelSpec.e4b.chatVisualTokenBudgets, [70, 140, 280])
        XCTAssertEqual(PhotoDetail.deeper.title, "さらに深く")
        let policy = ModelAttachmentPolicy(model: .e4b)
        XCTAssertFalse(policy.coarsePhotos); XCTAssertEqual(policy.photoTokens, 280)
        for model in [ModelSpec.e2b, .qwen3, .qwen25] {
            XCTAssertTrue(model.photoDetails.isEmpty, model.name)
            let other = settings.normalized(for: model)
            XCTAssertEqual(other.photoDetail, .fast, model.name); XCTAssertFalse(other.isDeeper(on: model), model.name)
            XCTAssertEqual(other.deeperThinkingTokens, 0, model.name)
        }
        let deeper = settings.normalized(for: .e4b)
        XCTAssertEqual(deeper.photoDetail, .deeper); XCTAssertEqual(deeper.visualTokenBudget, 280)
        let photo = InferenceEnginePlan(model: .e4b, settings: settings, needsVision: true)
        XCTAssertEqual(photo.backend, .gpu); XCTAssertEqual(photo.visionBackend, .cpu)
        XCTAssertEqual(photo.visualTokenBudget, 280); XCTAssertFalse(photo.speculativeDecoding)
        XCTAssertTrue(photo.cacheComponent.hasSuffix("/GPU-vision-CPU-kernel-xnnpack-v280-ctx4096-mtp0"), photo.cacheComponent)
        // Without photos it runs 深く's engine; only the conversation differs.
        var deep = settings; deep.photoDetail = .deep
        XCTAssertEqual(InferenceEnginePlan(model: .e4b, settings: settings, needsVision: false),
                       InferenceEnginePlan(model: .e4b, settings: deep, needsVision: false))
        // It thinks whatever was saved, and leaves the saved choice for 深く.
        XCTAssertFalse(deeper.enableThinking)
        XCTAssertTrue(deeper.isDeeper(on: .e4b)); XCTAssertTrue(deeper.thinks(on: .e4b))
        XCTAssertFalse(deep.normalized(for: .e4b).thinks(on: .e4b))
        // A quarter of the context to think in, kept free of the input.
        XCTAssertEqual(deeper.deeperThinkingTokens, 1024)
        XCTAssertEqual(deeper.thinkingTokenBudget(on: .e4b), 1024)
        XCTAssertEqual(deeper.inputTokenLimit, 4096 - 512 - 512 - 1024)
        XCTAssertEqual(deep.normalized(for: .e4b).inputTokenLimit, 4096 - 512 - 512)
        XCTAssertEqual(deeper.inputByteBudget, 2048 * 2 - GenerationSettings.defaultSystemPrompt.utf8.count)
        var longer = settings; longer.maxTokens = 8192
        XCTAssertEqual(longer.normalized(for: .e4b).thinkingTokenBudget(on: .e4b), 2048)
        // 深く's saved thinking keeps half the reply's room, as before; 高速 none.
        deep.enableThinking = true
        XCTAssertEqual(deep.normalized(for: .e4b).thinkingTokenBudget(on: .e4b), 256)
        XCTAssertEqual(GenerationSettings().normalized(for: .e4b).thinkingTokenBudget(on: .e4b), 0)
        // The note asking for care follows the person's prompt.
        XCTAssertEqual(deeper.systemMessage(for: .e4b),
                       GenerationSettings.defaultSystemPrompt + "\n" + GenerationSettings.carefulReplyNote)
        XCTAssertEqual(deep.systemMessage(for: .e4b), GenerationSettings.defaultSystemPrompt)
        XCTAssertEqual(try JSONDecoder().decode(GenerationSettings.self, from: JSONEncoder().encode(settings)).photoDetail, .deeper)
    }
    func testE2BTakesPhotosAndEveryDocumentFormatAsText() {
        let policy = ModelAttachmentPolicy(model: .e2b)
        XCTAssertNoThrow(try policy.validateNewAttachments([image]))
        for name in ["note.TXT", "memo.md", "資料.pdf", "data.csv", "data.json", "report.docx"] {
            XCTAssertNoThrow(try policy.validateNewAttachments([file(name)]), name)
        }
        // Only extracted text is sent: a file with none is refused.
        XCTAssertThrowsError(try policy.validateNewAttachments([file("note.txt", nil)]))
        XCTAssertThrowsError(try policy.validateNewAttachments([file("blank.txt", " \n")]))
        // A video goes as its scenes, never more than were taken, never as text.
        XCTAssertTrue(policy.allowsVideo)
        XCTAssertNoThrow(try policy.validateNewAttachments([video()]))
        XCTAssertNoThrow(try policy.validateNewAttachments([video(scenes: 1)]))
        XCTAssertThrowsError(try policy.validateNewAttachments([video(scenes: 0)]))
        XCTAssertThrowsError(try policy.validateNewAttachments([video(scenes: 4)]))
        var captioned = video(); captioned.extractedText = "字幕"
        XCTAssertThrowsError(try policy.validateNewAttachments([captioned]))
        XCTAssertFalse(policy.guidance.contains("動画は調整中"))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .image, name: "photo", storedName: "photo")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([photoText]), "E2B reads the photo itself")
        XCTAssertEqual(policy.summary, "テキスト・写真・動画・ファイル")
        XCTAssertFalse(policy.coarsePhotos); XCTAssertEqual(policy.photoTokens, 280)
        XCTAssertFalse(policy.guidance.contains(ModelAttachmentPolicy.coarsePhotoNote))
        var settings = GenerationSettings(); settings.visualTokenBudget = 280
        XCTAssertEqual(InferenceEnginePlan(model: .e2b, settings: settings, needsVision: true).visualTokenBudget, 280)
    }
    /// Qwen takes text only: no photo, not even its recognized text, and no
    /// file. An older Qwen chat keeps its attachments in the archive, but
    /// they no longer reach the model.
    func testQwenTakesTextOnly() {
        for model in [ModelSpec.qwen3, .qwen25] {
            let policy = ModelAttachmentPolicy(model: model)
            XCTAssertFalse(policy.allowsImages); XCTAssertFalse(policy.coarsePhotos); XCTAssertFalse(policy.allowsDocuments)
            XCTAssertFalse(policy.readsPhotoText); XCTAssertFalse(policy.allowsPhotos); XCTAssertFalse(policy.allowsAnyAttachment)
            XCTAssertThrowsError(try policy.validateNewAttachments([image]), model.name)
            XCTAssertThrowsError(try policy.validateNewAttachments([file("memo.md")]), model.name)
            XCTAssertThrowsError(try policy.validateNewAttachments([photoText]), model.name)
            XCTAssertFalse(policy.allowsVideo); XCTAssertThrowsError(try policy.validateNewAttachments([video()]), model.name)
            XCTAssertNoThrow(try policy.validateNewAttachments([]), model.name)
            XCTAssertTrue(policy.guidance.contains("テキスト専用")); XCTAssertTrue(policy.guidance.contains("E2B"))
            XCTAssertTrue(policy.guidance.contains("写真やファイル"))
            XCTAssertEqual(policy.summary, "テキスト")
            let older = [ChatMessage(role: .user, text: "この資料", attachments: [file("資料.pdf"), photoText]),
                         ChatMessage(role: .assistant, text: "以前の回答")]
            let history = policy.inferenceHistory(older)
            XCTAssertTrue(history.flatMap(\.media).isEmpty, model.name)
            XCTAssertTrue(history[0].text.contains("読み込んでいません"))
            XCTAssertEqual(history[1], older[1])
            XCTAssertEqual(older[0].media.count, 2, "Archive content must remain intact")
        }
    }
    func testCapabilitiesMatchThePinnedFiles() {
        XCTAssertEqual(ModelSpec.e2b.capabilities.photos, .native)
        XCTAssertEqual(ModelSpec.e4b.capabilities.photos, .native)
        XCTAssertEqual(ModelSpec.qwen3.capabilities.photos, .unsupported)
        XCTAssertEqual(ModelSpec.qwen25.capabilities.photos, .unsupported)
        XCTAssertEqual(ModelSpec.e4b.maximumContextTokens, 8192)
        XCTAssertEqual(ModelSpec.qwen3.maximumContextTokens, 4096)
        XCTAssertEqual(ModelSpec.qwen25.maximumContextTokens, 4096)
        XCTAssertTrue(ModelSpec.qwen3.supportsThinking); XCTAssertFalse(ModelSpec.qwen25.supportsThinking)
        XCTAssertFalse(ModelSpec.qwen3.supportsVision)
        XCTAssertTrue(ModelSpec.catalog.allSatisfy(\.capabilities.charts))
        XCTAssertEqual(ModelSpec.catalog.filter(\.capabilities.documents).map(\.id), [ModelSpec.e4b.id, ModelSpec.e2b.id])
    }
    func testQwenKeepsTheSamplingItsFileChecksPassedWith() {
        for spec in [ModelSpec.qwen3, .qwen25] {
            let settings = GenerationSettings(for: spec)
            XCTAssertEqual(settings.topK, 40); XCTAssertEqual(settings.topP, 0.95)
            // Qwen starts from the app's defaults, the GPU included.
            XCTAssertEqual(settings.normalized(for: spec), GenerationSettings().normalized(for: spec))
        }
        // Gemma keeps the values approved on the phone.
        XCTAssertEqual(GenerationSettings(for: .e2b), GenerationSettings())
        XCTAssertEqual(GenerationSettings(for: .e4b), GenerationSettings())
    }
    /// On the phone, Qwen3's GPU build failed at 16-bit and started at 32-bit
    /// (1.0.106's GPU start test), so it runs on the GPU at 32-bit, in its
    /// own cache; a CPU choice stays as before.
    func testQwen3RunsOnTheGPUAt32Bit() {
        XCTAssertTrue(ModelSpec.qwen3.supportsGPU)
        XCTAssertEqual(ModelSpec.qwen3.capabilities.gpuPrecision, .float32)
        XCTAssertEqual(GenerationSettings(for: .qwen3).backend, .gpu)
        let gpuPlan = InferenceEnginePlan(model: .qwen3, settings: GenerationSettings(for: .qwen3).normalized(for: .qwen3),
                                          needsVision: false)
        XCTAssertEqual(gpuPlan.backend, .gpu); XCTAssertEqual(gpuPlan.gpuPrecision, .float32)
        XCTAssertTrue(gpuPlan.cacheComponent.hasSuffix("/GPU-vision-none-kernel-none-v0-ctx4096-mtp0-act-float32"))
        var cpu = GenerationSettings(); cpu.backend = .cpu
        let cpuPlan = InferenceEnginePlan(model: .qwen3, settings: cpu.normalized(for: .qwen3), needsVision: false)
        XCTAssertEqual(cpuPlan.backend, .cpu); XCTAssertEqual(cpuPlan.gpuPrecision, .modelDefault)
        // The cache 1.0.105's Qwen3 chats used on the phone.
        XCTAssertEqual(cpuPlan.cacheComponent,
                       "litert-0.18.0-pg3/\(ModelSpec.qwen3.sha256)/CPU-vision-none-kernel-none-v0-ctx4096-mtp0")
        // Gemma and Qwen2.5 ran on the phone's GPU at the default precision:
        // the same default, choices and caches as before.
        var gpu = GenerationSettings(); gpu.backend = .gpu
        for spec in [ModelSpec.e2b, .e4b, .qwen25] {
            XCTAssertTrue(spec.supportsGPU)
            XCTAssertEqual(spec.capabilities.gpuPrecision, .modelDefault)
            XCTAssertEqual(GenerationSettings(for: spec).normalized(for: spec).backend, .gpu)
            XCTAssertEqual(gpu.normalized(for: spec).backend, .gpu)
            XCTAssertEqual(cpu.normalized(for: spec).backend, .cpu)
            let plan = InferenceEnginePlan(model: spec, settings: gpu.normalized(for: spec), needsVision: false)
            XCTAssertEqual(plan.gpuPrecision, .modelDefault)
            XCTAssertFalse(plan.cacheComponent.contains("-act-"), plan.cacheComponent)
        }
    }
    /// 1.0.105 and 1.0.106 saved CPU for Qwen3 whatever was chosen; only
    /// that CPU moves to the GPU, with the rest of its settings kept.
    func testSavedQwen3CPUMovesToTheGPU() {
        var cpu = GenerationSettings(); cpu.backend = .cpu; cpu.temperature = 0.3
        let saved = [ModelSpec.qwen3.id: cpu, ModelSpec.qwen25.id: cpu, ModelSpec.e2b.id: cpu]
        let moved = GenerationSettings.movingQwen3ToTheGPU(saved)
        XCTAssertEqual(moved[ModelSpec.qwen3.id]?.backend, .gpu)
        XCTAssertEqual(moved[ModelSpec.qwen3.id]?.temperature, 0.3)
        XCTAssertEqual(moved[ModelSpec.qwen25.id], cpu); XCTAssertEqual(moved[ModelSpec.e2b.id], cpu)
        XCTAssertEqual(GenerationSettings.movingQwen3ToTheGPU([:]), [:])
    }
    /// E4B takes photos again, so an older E4B chat's photo goes back to the
    /// model with its history, as E2B's does; the archive is untouched.
    func testOlderE4BPhotosGoBackWithTheirChat() {
        let image = self.image
        let messages = [ChatMessage(role: .user, text: "この写真", attachments: [image]),
                        ChatMessage(role: .assistant, text: "以前の回答")]
        XCTAssertEqual(ModelAttachmentPolicy(model: .e4b).inferenceHistory(messages), messages)
        XCTAssertEqual(ModelAttachmentPolicy(model: .e2b).inferenceHistory(messages), messages)
        XCTAssertEqual(messages[0].media, [image])
    }
    func testPhotosNeverCrossBetweenVisionAndTextModels() {
        // One of each (the helpers make a new id on every use).
        let image = self.image, photoText = self.photoText
        let messages = [ChatMessage(role: .user, text: "写真", attachments: [image]),
                        ChatMessage(role: .assistant, text: "回答"),
                        ChatMessage(role: .user, text: "文字", attachments: [photoText]),
                        ChatMessage(role: .assistant, text: "回答")]
        // Qwen takes text only: neither E2B's image nor older recognized text.
        let qwen = ModelAttachmentPolicy(model: .qwen25).inferenceHistory(messages)
        XCTAssertTrue(qwen.flatMap(\.media).isEmpty)
        // E2B keeps its own image and does not take OCR text as a photo.
        let e2b = ModelAttachmentPolicy(model: .e2b).inferenceHistory(messages)
        XCTAssertEqual(e2b.flatMap(\.media), [image])
    }
    func testPickerResultBelongsToItsOriginalConversationAndModel() {
        let thread = UUID()
        let context = AttachmentImportContext(threadID: thread, modelID: ModelSpec.e2b.id)
        XCTAssertTrue(context.matches(threadID: thread, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: UUID(), modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: thread, modelID: ModelSpec.e4b.id))
        XCTAssertFalse(context.matches(threadID: nil, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(AttachmentImportContext(threadID: nil, modelID: ModelSpec.e2b.id).matches(threadID: nil, modelID: ModelSpec.e2b.id))
    }
    func testTextModelRejectsImageWithDisguisedFileKind() {
        let disguised = ChatAttachment(kind: .file, name: "note.txt", storedName: "file.txt", imageNames: ["hidden.jpg"], extractedText: "x")
        for model in [ModelSpec.e2b, .e4b, .qwen3, .qwen25] {
            XCTAssertThrowsError(try ModelAttachmentPolicy(model: model).validateNewAttachments([disguised]))
        }
    }
}
