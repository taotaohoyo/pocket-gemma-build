import XCTest
@testable import PocketCore

final class AttachmentPolicyTests: XCTestCase {
    private var image: ChatAttachment {
        ChatAttachment(kind: .image, name: "photo.jpg", storedName: "original.jpg", imageNames: ["normalized.jpg"])
    }
    private func file(_ name: String, _ text: String? = "日本語😊") -> ChatAttachment {
        ChatAttachment(kind: .file, name: name, storedName: name, extractedText: text)
    }
    /// A photo read by OCR for a text-only model: a thumbnail to show, its
    /// text for the model, and no image for the model to see.
    private var photoText: ChatAttachment {
        ChatAttachment(kind: .image, name: "receipt.jpg", storedName: "receipt.jpg", thumbnailName: "thumb.jpg",
                       extractedText: "合計 1,280円")
    }
    func testE4BReadsFilesButKeepsPhotosSuspended() {
        let policy = ModelAttachmentPolicy(model: .e4b)
        XCTAssertFalse(policy.allowsImages); XCTAssertTrue(policy.photosSuspended); XCTAssertTrue(policy.allowsDocuments)
        XCTAssertFalse(policy.readsPhotoText); XCTAssertFalse(policy.allowsPhotos)
        XCTAssertThrowsError(try policy.validateNewAttachments([image]))
        XCTAssertThrowsError(try policy.validateNewAttachments([photoText]), "No OCR stand-in while E4B photos are checked")
        XCTAssertNoThrow(try policy.validateNewAttachments([file("note.txt"), file("資料.pdf")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov")]))
        XCTAssertNoThrow(try policy.validateNewAttachments([]))
        XCTAssertTrue(policy.guidance.contains("E2B"))
        XCTAssertEqual(policy.summary, "テキスト・ファイル · 写真は調整中")
    }
    func testE2BTakesPhotosAndEveryDocumentFormatAsText() {
        let policy = ModelAttachmentPolicy(model: .e2b)
        XCTAssertNoThrow(try policy.validateNewAttachments([image]))
        for name in ["note.TXT", "memo.md", "資料.pdf", "data.csv", "data.json", "report.docx"] {
            XCTAssertNoThrow(try policy.validateNewAttachments([file(name)]), name)
        }
        // Only extracted text is sent: a file with none is refused.
        XCTAssertThrowsError(try policy.validateNewAttachments([file("note.txt", nil)]))
        XCTAssertThrowsError(try policy.validateNewAttachments([file("blank.txt", " \n")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov", imageNames: ["frame.jpg"])]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .image, name: "photo", storedName: "photo")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([photoText]), "E2B reads the photo itself")
        XCTAssertEqual(policy.summary, "テキスト・写真・ファイル")
    }
    func testQwenIsTextOnlyAndPointsPhotosToE2B() {
        for model in [ModelSpec.qwen3, .qwen25] {
            let policy = ModelAttachmentPolicy(model: model)
            XCTAssertFalse(policy.allowsImages); XCTAssertFalse(policy.photosSuspended); XCTAssertTrue(policy.allowsDocuments)
            XCTAssertTrue(policy.readsPhotoText); XCTAssertTrue(policy.allowsPhotos)
            XCTAssertThrowsError(try policy.validateNewAttachments([image]), model.name)
            XCTAssertNoThrow(try policy.validateNewAttachments([file("memo.md"), file("表.csv")]), model.name)
            // A photo goes in only as its recognized text.
            XCTAssertNoThrow(try policy.validateNewAttachments([photoText]), model.name)
            var both = photoText; both.imageNames = ["normalized.jpg"]
            XCTAssertThrowsError(try policy.validateNewAttachments([both]), model.name)
            var blank = photoText; blank.extractedText = " "
            XCTAssertThrowsError(try policy.validateNewAttachments([blank]), model.name)
            XCTAssertTrue(policy.guidance.contains("テキスト専用")); XCTAssertTrue(policy.guidance.contains("E2B"))
            XCTAssertTrue(policy.guidance.contains("文字認識"))
            XCTAssertEqual(policy.summary, "テキスト・ファイル・写真の文字")
        }
    }
    func testCapabilitiesMatchThePinnedFiles() {
        XCTAssertEqual(ModelSpec.e2b.capabilities.photos, .native)
        XCTAssertEqual(ModelSpec.e4b.capabilities.photos, .native)
        XCTAssertEqual(ModelSpec.qwen3.capabilities.photos, .textRecognition)
        XCTAssertEqual(ModelSpec.qwen25.capabilities.photos, .textRecognition)
        XCTAssertEqual(ModelSpec.e4b.maximumContextTokens, 8192)
        XCTAssertEqual(ModelSpec.qwen3.maximumContextTokens, 4096)
        XCTAssertEqual(ModelSpec.qwen25.maximumContextTokens, 4096)
        XCTAssertTrue(ModelSpec.qwen3.supportsThinking); XCTAssertFalse(ModelSpec.qwen25.supportsThinking)
        XCTAssertFalse(ModelSpec.qwen3.supportsVision)
        XCTAssertTrue(ModelSpec.catalog.allSatisfy { $0.capabilities.documents && $0.capabilities.charts })
    }
    func testQwenKeepsTheSamplingItsFileChecksPassedWith() {
        for spec in [ModelSpec.qwen3, .qwen25] {
            let settings = GenerationSettings(for: spec)
            XCTAssertEqual(settings.topK, 40); XCTAssertEqual(settings.topP, 0.95)
            // Only the accelerator differs from the app's defaults, and
            // normalizing those for Qwen moves them to the CPU too.
            XCTAssertEqual(settings.normalized(for: spec), GenerationSettings().normalized(for: spec))
        }
        // Gemma keeps the values approved on the phone.
        XCTAssertEqual(GenerationSettings(for: .e2b), GenerationSettings())
        XCTAssertEqual(GenerationSettings(for: .e4b), GenerationSettings())
    }
    func testQwenRunsOnTheCPUEvenWithASavedGPUChoice() {
        var gpu = GenerationSettings(); gpu.backend = .gpu
        for spec in [ModelSpec.qwen3, .qwen25] {
            XCTAssertFalse(spec.supportsGPU)
            XCTAssertEqual(GenerationSettings(for: spec).backend, .cpu)
            // 1.0.104 saved GPU for Qwen; the engine plan uses the CPU.
            let settings = gpu.normalized(for: spec)
            XCTAssertEqual(settings.backend, .cpu)
            XCTAssertEqual(InferenceEnginePlan(model: spec, settings: settings, needsVision: false).backend, .cpu)
        }
        // Gemma keeps the GPU default and either saved choice.
        var cpu = GenerationSettings(); cpu.backend = .cpu
        for spec in [ModelSpec.e2b, .e4b] {
            XCTAssertTrue(spec.supportsGPU)
            XCTAssertEqual(GenerationSettings(for: spec).normalized(for: spec).backend, .gpu)
            XCTAssertEqual(gpu.normalized(for: spec).backend, .gpu)
            XCTAssertEqual(cpu.normalized(for: spec).backend, .cpu)
        }
    }
    func testOldE4BImagesCannotReactivateVisionOrModifyArchive() {
        let image = self.image
        let messages = [ChatMessage(role: .user, text: "この写真", attachments: [image]),
                        ChatMessage(role: .assistant, text: "以前の回答")]
        let result = ModelAttachmentPolicy(model: .e4b).inferenceHistory(messages)
        XCTAssertEqual(messages[0].media, [image])
        XCTAssertTrue(result.flatMap(\.media).isEmpty)
        XCTAssertEqual(result.map(\.id), messages.map(\.id))
        XCTAssertTrue(result[0].text.contains("読み込んでいません"))
        XCTAssertEqual(result[1], messages[1])
        XCTAssertEqual(ModelAttachmentPolicy(model: .e2b).inferenceHistory(messages), messages)
        XCTAssertEqual(ModelAttachmentPolicy(model: .e4b).inferenceHistory(result), result)
    }
    func testPhotosNeverCrossBetweenVisionAndTextModels() {
        // One of each (the helpers make a new id on every use).
        let image = self.image, photoText = self.photoText
        let messages = [ChatMessage(role: .user, text: "写真", attachments: [image]),
                        ChatMessage(role: .assistant, text: "回答"),
                        ChatMessage(role: .user, text: "文字", attachments: [photoText]),
                        ChatMessage(role: .assistant, text: "回答")]
        // Qwen keeps the recognized text and never gets E2B's image.
        let qwen = ModelAttachmentPolicy(model: .qwen25).inferenceHistory(messages)
        XCTAssertEqual(qwen.flatMap(\.media), [photoText])
        // E2B keeps its own image and does not take OCR text as a photo.
        let e2b = ModelAttachmentPolicy(model: .e2b).inferenceHistory(messages)
        XCTAssertEqual(e2b.flatMap(\.media), [image])
    }
    func testPickerResultBelongsToItsOriginalConversationAndModel() {
        let thread = UUID()
        let context = AttachmentImportContext(threadID: thread, modelID: ModelSpec.e2b.id)
        XCTAssertTrue(context.matches(threadID: thread, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: UUID(), modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: thread, modelID: ModelSpec.e4b.id))
        XCTAssertFalse(context.matches(threadID: nil, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(AttachmentImportContext(threadID: nil, modelID: ModelSpec.e2b.id).matches(threadID: nil, modelID: ModelSpec.e2b.id))
    }
    func testTextModelRejectsImageWithDisguisedFileKind() {
        let disguised = ChatAttachment(kind: .file, name: "note.txt", storedName: "file.txt", imageNames: ["hidden.jpg"], extractedText: "x")
        for model in [ModelSpec.e2b, .e4b, .qwen3, .qwen25] {
            XCTAssertThrowsError(try ModelAttachmentPolicy(model: model).validateNewAttachments([disguised]))
        }
    }
}
