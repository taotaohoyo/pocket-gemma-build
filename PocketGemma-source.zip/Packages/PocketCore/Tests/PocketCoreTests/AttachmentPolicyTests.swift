import XCTest
@testable import PocketCore

final class AttachmentPolicyTests: XCTestCase {
    private var image: ChatAttachment {
        ChatAttachment(kind: .image, name: "photo.jpg", storedName: "original.jpg", imageNames: ["normalized.jpg"])
    }
    private func file(_ name: String, _ text: String? = "日本語😊") -> ChatAttachment {
        ChatAttachment(kind: .file, name: name, storedName: name, extractedText: text)
    }
    func testE4BReadsFilesButKeepsPhotosSuspended() {
        let policy = ModelAttachmentPolicy(model: .e4b)
        XCTAssertFalse(policy.allowsImages); XCTAssertTrue(policy.photosSuspended); XCTAssertTrue(policy.allowsDocuments)
        XCTAssertThrowsError(try policy.validateNewAttachments([image]))
        XCTAssertNoThrow(try policy.validateNewAttachments([file("note.txt"), file("資料.pdf")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov")]))
        XCTAssertNoThrow(try policy.validateNewAttachments([]))
        XCTAssertTrue(policy.guidance.contains("E2B"))
        XCTAssertEqual(policy.summary, "テキスト・ファイル · 写真は調整中")
    }
    func testE2BTakesPhotosAndEveryDocumentFormatAsText() {
        let policy = ModelAttachmentPolicy(model: .e2b)
        XCTAssertNoThrow(try policy.validateNewAttachments([image]))
        for name in ["note.TXT", "memo.md", "資料.pdf", "data.csv", "data.json", "report.docx"] {
            XCTAssertNoThrow(try policy.validateNewAttachments([file(name)]), name)
        }
        // Only extracted text is sent: a file with none is refused.
        XCTAssertThrowsError(try policy.validateNewAttachments([file("note.txt", nil)]))
        XCTAssertThrowsError(try policy.validateNewAttachments([file("blank.txt", " \n")]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .video, name: "clip.mov", storedName: "clip.mov", imageNames: ["frame.jpg"])]))
        XCTAssertThrowsError(try policy.validateNewAttachments([ChatAttachment(kind: .image, name: "photo", storedName: "photo")]))
        XCTAssertEqual(policy.summary, "テキスト・写真・ファイル")
    }
    func testQwenIsTextOnlyAndPointsPhotosToE2B() {
        for model in [ModelSpec.qwen3, .qwen25] {
            let policy = ModelAttachmentPolicy(model: model)
            XCTAssertFalse(policy.allowsImages); XCTAssertFalse(policy.photosSuspended); XCTAssertTrue(policy.allowsDocuments)
            XCTAssertThrowsError(try policy.validateNewAttachments([image]), model.name)
            XCTAssertNoThrow(try policy.validateNewAttachments([file("memo.md"), file("表.csv")]), model.name)
            XCTAssertTrue(policy.guidance.contains("テキスト専用")); XCTAssertTrue(policy.guidance.contains("E2B"))
            XCTAssertEqual(policy.summary, "テキスト・ファイル")
        }
    }
    func testCapabilitiesMatchThePinnedFiles() {
        XCTAssertEqual(ModelSpec.e2b.capabilities.photos, .native)
        XCTAssertEqual(ModelSpec.e4b.capabilities.photos, .native)
        XCTAssertEqual(ModelSpec.qwen3.capabilities.photos, .unsupported)
        XCTAssertEqual(ModelSpec.qwen25.capabilities.photos, .unsupported)
        XCTAssertEqual(ModelSpec.e4b.maximumContextTokens, 8192)
        XCTAssertEqual(ModelSpec.qwen3.maximumContextTokens, 4096)
        XCTAssertEqual(ModelSpec.qwen25.maximumContextTokens, 4096)
        XCTAssertTrue(ModelSpec.qwen3.supportsThinking); XCTAssertFalse(ModelSpec.qwen25.supportsThinking)
        XCTAssertFalse(ModelSpec.qwen3.supportsVision)
        XCTAssertTrue(ModelSpec.catalog.allSatisfy { $0.capabilities.documents && $0.capabilities.charts })
    }
    func testOldE4BImagesCannotReactivateVisionOrModifyArchive() {
        let image = self.image
        let messages = [ChatMessage(role: .user, text: "この写真", attachments: [image]),
                        ChatMessage(role: .assistant, text: "以前の回答")]
        let result = ModelAttachmentPolicy(model: .e4b).inferenceHistory(messages)
        XCTAssertEqual(messages[0].media, [image])
        XCTAssertTrue(result.flatMap(\.media).isEmpty)
        XCTAssertEqual(result.map(\.id), messages.map(\.id))
        XCTAssertTrue(result[0].text.contains("読み込んでいません"))
        XCTAssertEqual(result[1], messages[1])
        XCTAssertEqual(ModelAttachmentPolicy(model: .e2b).inferenceHistory(messages), messages)
        XCTAssertEqual(ModelAttachmentPolicy(model: .e4b).inferenceHistory(result), result)
    }
    func testPickerResultBelongsToItsOriginalConversationAndModel() {
        let thread = UUID()
        let context = AttachmentImportContext(threadID: thread, modelID: ModelSpec.e2b.id)
        XCTAssertTrue(context.matches(threadID: thread, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: UUID(), modelID: ModelSpec.e2b.id))
        XCTAssertFalse(context.matches(threadID: thread, modelID: ModelSpec.e4b.id))
        XCTAssertFalse(context.matches(threadID: nil, modelID: ModelSpec.e2b.id))
        XCTAssertFalse(AttachmentImportContext(threadID: nil, modelID: ModelSpec.e2b.id).matches(threadID: nil, modelID: ModelSpec.e2b.id))
    }
    func testTextModelRejectsImageWithDisguisedFileKind() {
        let disguised = ChatAttachment(kind: .file, name: "note.txt", storedName: "file.txt", imageNames: ["hidden.jpg"], extractedText: "x")
        for model in [ModelSpec.e2b, .e4b, .qwen3, .qwen25] {
            XCTAssertThrowsError(try ModelAttachmentPolicy(model: model).validateNewAttachments([disguised]))
        }
    }
}
