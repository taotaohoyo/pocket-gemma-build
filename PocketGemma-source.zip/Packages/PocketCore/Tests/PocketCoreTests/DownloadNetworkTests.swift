import XCTest
@testable import PocketCore

final class DownloadNetworkTests: XCTestCase {
    /// The request alone decides cellular: no means never, whatever the
    /// background session allows.
    func testRequestCarriesTheCellularChoice() {
        for spec in ModelSpec.catalog {
            let wifiOnly = ModelDownload.request(for: spec, cellular: false)
            XCTAssertEqual(wifiOnly.url, spec.downloadURL)
            XCTAssertFalse(wifiOnly.allowsCellularAccess)
            XCTAssertTrue(ModelDownload.request(for: spec, cellular: true).allowsCellularAccess)
        }
    }

    /// Only a download still at 0% on the card starts over with the
    /// switch's new choice.
    func testOnlyADownloadUnderOnePercentStartsOver() {
        let size = ModelSpec.e4b.byteCount
        XCTAssertTrue(ModelDownload.startsOver(receivedBytes: 0, expectedBytes: size))
        XCTAssertTrue(ModelDownload.startsOver(receivedBytes: size / 100 - 1, expectedBytes: size))
        XCTAssertFalse(ModelDownload.startsOver(receivedBytes: size / 100 + 1, expectedBytes: size))
        XCTAssertFalse(ModelDownload.startsOver(receivedBytes: size, expectedBytes: size))
        XCTAssertTrue(ModelDownload.startsOver(receivedBytes: 0, expectedBytes: 0), "an unknown size has received nothing")
    }

    func testWhatADownloadWaitsFor() {
        let wifi = DownloadNetwork(hasWiFi: true, isOnline: true, cellularDenied: false)
        let cellular = DownloadNetwork(hasWiFi: false, isOnline: true, cellularDenied: false)
        let offline = DownloadNetwork(hasWiFi: false, isOnline: false, cellularDenied: false)
        let denied = DownloadNetwork(hasWiFi: false, isOnline: false, cellularDenied: true)
        for usesCellular in [false, true] {
            XCTAssertNil(wifi.wait(usesCellular: usesCellular))
            XCTAssertNil(DownloadNetwork.unknown.wait(usesCellular: usesCellular))
            XCTAssertEqual(denied.wait(usesCellular: usesCellular), .cellularDenied)
        }
        XCTAssertEqual(cellular.wait(usesCellular: false), .wifi)
        XCTAssertNil(cellular.wait(usesCellular: true))
        XCTAssertEqual(offline.wait(usesCellular: false), .wifi)
        XCTAssertEqual(offline.wait(usesCellular: true), .network)

        XCTAssertTrue(cellular.waitsForWiFi(allowsCellular: false))
        XCTAssertFalse(cellular.waitsForWiFi(allowsCellular: true))
        XCTAssertFalse(wifi.waitsForWiFi(allowsCellular: false))
        XCTAssertFalse(offline.waitsForWiFi(allowsCellular: false), "offline is not a cellular-only phone")
    }

    /// The card names the way out: the switch while nothing has arrived,
    /// starting over once something has, iOS's 設定 when it denies cellular.
    func testWaitingWordsPointToTheWayOut() throws {
        XCTAssertEqual(DownloadWait.wifi.status(name: "Gemma 4 E2B", percent: 0), "Gemma 4 E2BはWi-Fiを待っています · 0%")
        XCTAssertEqual(DownloadWait.network.status(name: "Gemma 4 E2B", percent: 12), "Gemma 4 E2Bはインターネット接続を待っています · 12%")
        let turnOn = try XCTUnwrap(DownloadWait.wifi.hint(received: false, switchOn: false))
        XCTAssertTrue(turnOn.contains("「モバイル通信でもダウンロード」をオン"))
        XCTAssertNil(DownloadWait.wifi.hint(received: false, switchOn: true), "it is already starting again")
        let kept = try XCTUnwrap(DownloadWait.wifi.hint(received: true, switchOn: true))
        XCTAssertTrue(kept.contains("続きから") && kept.contains("中止してから"))
        XCTAssertFalse(kept.contains("オンにして"))
        XCTAssertTrue(try XCTUnwrap(DownloadWait.wifi.hint(received: true, switchOn: false)).contains("オンにして"))
        XCTAssertTrue(try XCTUnwrap(DownloadWait.cellularDenied.hint(received: false, switchOn: true)).contains("「設定」"))
        XCTAssertNil(DownloadWait.network.hint(received: true, switchOn: true))
    }
}
