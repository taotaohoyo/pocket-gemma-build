import XCTest
@testable import PocketCore

final class DownloadPaceTests: XCTestCase {
    /// The 293 record of 2026-11-17 19:48–19:50: about 1 MB/s at first,
    /// then 0.1–0.2 MB/s in the last half minute before iOS ended the task.
    func testTheLastHalfMinuteAgainstTheBest() {
        var pace = DownloadPace()
        var bytes: Int64 = 693_000_000
        for second in 0...60 {
            pace.note(bytes: bytes, at: TimeInterval(second))
            bytes += 1_000_000
        }
        for second in 61...107 {
            pace.note(bytes: bytes, at: TimeInterval(second))
            bytes += 120_000
        }
        XCTAssertEqual(pace.best, 1_000_000, accuracy: 1)
        let last = try! XCTUnwrap(pace.rate(now: 107))
        XCTAssertEqual(last, 120_000, accuracy: 1)
        XCTAssertEqual(DownloadPace.text(last), "0.1 MB/秒")
        XCTAssertEqual(DownloadPace.text(pace.best), "1.0 MB/秒")
        XCTAssertEqual(DownloadPace.text(nil), "不明")
    }

    /// No bytes since the last sample: the rate falls with the time that
    /// passed, as the transfer did, to nothing once a whole half minute
    /// brought nothing.
    func testNothingCameSinceTheLastSample() {
        var pace = DownloadPace()
        pace.note(bytes: 0, at: 0)
        pace.note(bytes: 30_000_000, at: 30)
        XCTAssertEqual(try XCTUnwrap(pace.rate(now: 30)), 1_000_000, accuracy: 1)
        XCTAssertEqual(try XCTUnwrap(pace.rate(now: 45)), 30_000_000 / 45, accuracy: 1)
        XCTAssertEqual(try XCTUnwrap(pace.rate(now: 60)), 0, accuracy: 1)
    }

    /// Less than a whole window: a rate, but no best yet.
    func testAShortStartHasNoBest() {
        var pace = DownloadPace()
        XCTAssertNil(pace.rate(now: 0))
        pace.note(bytes: 0, at: 0)
        XCTAssertNil(pace.rate(now: 0.5))
        pace.note(bytes: 10_000_000, at: 10)
        XCTAssertEqual(try XCTUnwrap(pace.rate(now: 10)), 1_000_000, accuracy: 1)
        XCTAssertEqual(pace.best, 0)
    }

    /// Bytes that go back start the samples over; the best stays; old
    /// samples go.
    func testBytesThatGoBackStartOver() {
        var pace = DownloadPace()
        for second in 0...40 { pace.note(bytes: Int64(second) * 2_000_000, at: TimeInterval(second)) }
        XCTAssertEqual(pace.best, 2_000_000, accuracy: 1)
        pace.note(bytes: 1_000, at: 41)
        XCTAssertEqual(pace.samples.count, 1)
        XCTAssertEqual(pace.best, 2_000_000, accuracy: 1)
        for second in 42...300 { pace.note(bytes: 1_000 + Int64(second), at: TimeInterval(second)) }
        XCTAssertLessThanOrEqual(pace.samples.count, 121)
    }
}
