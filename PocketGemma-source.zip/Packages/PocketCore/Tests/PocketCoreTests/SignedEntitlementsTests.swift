import XCTest
@testable import PocketCore

final class SignedEntitlementsTests: XCTestCase {
    /// A minimal arm64 Mach-O: the header, one LC_CODE_SIGNATURE, and a
    /// signature super blob holding the XML entitlements slot only.
    private func machO(entitlements: [String: Any]?, signed: Bool = true) throws -> Data {
        var signature = Data()
        if signed {
            var blob = Data()
            if let entitlements {
                let plist = try PropertyListSerialization.data(fromPropertyList: entitlements, format: .xml, options: 0)
                blob.append(bigEndian: 0xFADE_7171); blob.append(bigEndian: UInt32(8 + plist.count)); blob.append(plist)
            }
            let slots: UInt32 = entitlements == nil ? 0 : 1
            signature.append(bigEndian: 0xFADE_0CC0); signature.append(bigEndian: UInt32(12 + 8 * Int(slots) + blob.count))
            signature.append(bigEndian: slots)
            if slots == 1 { signature.append(bigEndian: 5); signature.append(bigEndian: 20) }
            signature.append(blob)
        }
        var data = Data()
        let commands: UInt32 = signed ? 1 : 0
        for value: UInt32 in [0xFEED_FACF, 0x0100_000C, 0, 2, commands, commands * 16, 0, 0] { data.append(littleEndian: value) }
        if signed { for value: UInt32 in [0x1D, 16, 48, UInt32(signature.count)] { data.append(littleEndian: value) } }
        data.append(signature)
        return data
    }

    private func read(_ data: Data) -> [String: Any]? {
        SignedEntitlements.read { offset, count in
            guard offset <= UInt64(data.count) else { return nil }
            let start = Int(offset)
            return data.subdata(in: start..<min(data.count, start + count))
        }
    }

    func testFindsTheMemoryEntitlementsInTheSignature() throws {
        let entitlements: [String: Any] = [SignedEntitlements.extendedVirtualAddressing: true,
                                           SignedEntitlements.increasedMemoryLimit: true,
                                           "application-identifier": "TEAM.app.pocketgemma.personal"]
        let found = try XCTUnwrap(read(try machO(entitlements: entitlements)))
        XCTAssertEqual(SignedEntitlements.memoryEntitlements(in: found), SignedEntitlements.memoryKeys)
    }

    func testOnlyTrueValuesCount() throws {
        let found = try XCTUnwrap(read(try machO(entitlements: [SignedEntitlements.extendedVirtualAddressing: false,
                                                                SignedEntitlements.increasedMemoryLimit: true])))
        XCTAssertEqual(SignedEntitlements.memoryEntitlements(in: found), [SignedEntitlements.increasedMemoryLimit])
    }

    func testNoEntitlementsIsEmptyAndNoSignatureIsNil() throws {
        XCTAssertEqual(read(try machO(entitlements: nil))?.count, 0, "Signed, but no entitlements slot")
        XCTAssertNil(read(try machO(entitlements: nil, signed: false)), "No LC_CODE_SIGNATURE")
        let truncated = try machO(entitlements: [SignedEntitlements.increasedMemoryLimit: true]).dropLast(10)
        XCTAssertNil(read(Data(truncated)))
        XCTAssertNil(read(Data("not a Mach-O file".utf8)))
    }

    func testUniversalBinaryUsesTheARM64Slice() throws {
        let thin = try machO(entitlements: [SignedEntitlements.extendedVirtualAddressing: true])
        var fat = Data()
        // x86_64 first, at 1024; arm64 second, at 4096.
        for value: UInt32 in [0xCAFE_BABE, 2, 0x0100_0007, 3, 1024, 16, 10, 0x0100_000C, 0, 4096, UInt32(thin.count), 12] {
            fat.append(bigEndian: value)
        }
        fat.append(Data(count: 1024 - fat.count)); fat.append(Data(repeating: 0xAB, count: 16))
        fat.append(Data(count: 4096 - fat.count)); fat.append(thin)
        let found = try XCTUnwrap(read(fat))
        XCTAssertEqual(SignedEntitlements.memoryEntitlements(in: found), [SignedEntitlements.extendedVirtualAddressing])
    }

    func testReadsAFileAndARealSignedBinary() throws {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent("signed-\(UUID().uuidString)")
        try machO(entitlements: [SignedEntitlements.increasedMemoryLimit: true]).write(to: file)
        defer { try? FileManager.default.removeItem(at: file) }
        XCTAssertEqual(SignedEntitlements.memoryEntitlements(ofExecutableAt: file), [SignedEntitlements.increasedMemoryLimit])
        XCTAssertNil(SignedEntitlements.memoryEntitlements(ofExecutableAt: file.appendingPathExtension("missing")))
        // An app Apple signed, on the Mac that runs the tests.
        let calculator = URL(fileURLWithPath: "/System/Applications/Calculator.app/Contents/MacOS/Calculator")
        guard FileManager.default.fileExists(atPath: calculator.path) else { throw XCTSkip("No Calculator on this Mac") }
        XCTAssertEqual(SignedEntitlements.memoryEntitlements(ofExecutableAt: calculator), [],
                       "Its signature reads, and it has no memory entitlements")
    }
}

private extension Data {
    mutating func append(bigEndian value: UInt32) { Swift.withUnsafeBytes(of: value.bigEndian) { append(contentsOf: $0) } }
    mutating func append(littleEndian value: UInt32) { Swift.withUnsafeBytes(of: value.littleEndian) { append(contentsOf: $0) } }
}
