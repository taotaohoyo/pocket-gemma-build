import XCTest
@testable import PocketCore

/// Signing in to Tavily and searching with the account (1.1.0 (207)),
/// against a stand-in for mcp.tavily.com that answers as the real server
/// did in run 40444619260 (status codes, event-stream answers, the session
/// header, the limit payload). Mocks only: the real sign-in needs a person.
final class TavilyAccountTests: XCTestCase {
    /// The registration asks for a public native client with the app's own
    /// redirect, and Tavily's page opens with PKCE (S256), our state and the
    /// MCP server as the token's resource.
    func testRegistrationAndTheSignInPage() throws {
        let request = TavilyAccount.registrationRequest()
        XCTAssertEqual(request.url, TavilyAccount.registrationEndpoint)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: try XCTUnwrap(request.httpBody)) as? [String: Any])
        XCTAssertEqual(body["redirect_uris"] as? [String], ["fielua://oauth/tavily"])
        XCTAssertEqual(body["token_endpoint_auth_method"] as? String, "none", "a public client: no secret in the app")
        XCTAssertEqual(body["application_type"] as? String, "native")
        XCTAssertEqual(body["grant_types"] as? [String], ["authorization_code", "refresh_token"])
        XCTAssertEqual(try TavilyAccount.clientID(fromRegistration: Data(#"{"client_id":"abc","token_endpoint_auth_method":"none"}"#.utf8)), "abc")
        XCTAssertThrowsError(try TavilyAccount.clientID(fromRegistration: Data(#"{"client_id":"abc","token_endpoint_auth_method":"client_secret_basic"}"#.utf8)))

        let signIn = TavilyAccount.signIn(clientID: "abc")
        let items = Dictionary(uniqueKeysWithValues: try XCTUnwrap(URLComponents(url: signIn.url, resolvingAgainstBaseURL: false)?.queryItems)
            .map { ($0.name, $0.value ?? "") })
        XCTAssertEqual(signIn.url.host, "mcp.tavily.com")
        XCTAssertEqual(items["client_id"], "abc")
        XCTAssertEqual(items["redirect_uri"], "fielua://oauth/tavily")
        XCTAssertEqual(items["response_type"], "code")
        XCTAssertEqual(items["code_challenge_method"], "S256")
        XCTAssertEqual(items["code_challenge"], TavilyAccount.challenge(for: signIn.verifier))
        XCTAssertEqual(items["state"], signIn.state)
        XCTAssertEqual(items["resource"], "https://mcp.tavily.com/mcp")
        XCTAssertEqual(items["scope"], "openid offline_access")
        XCTAssertGreaterThanOrEqual(signIn.verifier.count, 43, "RFC 7636: 43 to 128 characters")
        XCTAssertLessThanOrEqual(signIn.verifier.count, 128)
        XCTAssertNotEqual(TavilyAccount.signIn(clientID: "abc").state, signIn.state, "a new state each time")
        // RFC 7636 appendix B.
        XCTAssertEqual(TavilyAccount.challenge(for: "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"),
                       "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM")
    }

    /// 新規登録's page: Tavily's sign-in page that mcp.tavily.com sent the
    /// browser to, its parameters exactly as sent, asked to open at sign-up
    /// (1.1.0 (223)). Any other answer gives none, and the sign-in page opens.
    func testTheSignUpPageIsTavilysSignInPageAtSignUp() throws {
        let page = try XCTUnwrap(TavilyAccount.signUpPage(redirect: redirect(302, FakeTavily.signInPage)))
        XCTAssertEqual(page.absoluteString, FakeTavily.signInPage + "&screen_hint=signup")
        XCTAssertEqual(page.host, "auth.tavily.com")
        XCTAssertNotNil(TavilyAccount.signUpPage(redirect: redirect(303, FakeTavily.signInPage)))
        let others = [
            (200, FakeTavily.signInPage),
            (302, "https://evil.example/authorize?state=s"),
            (302, "https://auth.tavily.com.evil.example/authorize?state=s"),
            (302, "https://auth.tavily.com@evil.example/authorize?state=s"),
            (302, "https://user@auth.tavily.com/authorize?state=s"),
            (302, "https://auth.tavily.com:8443/authorize?state=s"),
            (302, "http://auth.tavily.com/authorize?state=s"),
            (302, "https://auth.tavily.com/u/login?state=s"),
            (302, "https://auth.tavily.com/authorize?client_id=c"),
            (302, "https://auth.tavily.com/authorize?state="),
            (302, "https://auth.tavily.com/authorize?state=s&screen_hint=login"),
            (302, "/authorize?state=s"),
            (302, "fielua://oauth/tavily?error=server_error&state=s")
        ]
        for (status, location) in others {
            XCTAssertNil(TavilyAccount.signUpPage(redirect: redirect(status, location)), "\(status) \(location)")
        }
        XCTAssertNil(TavilyAccount.signUpPage(redirect: HTTPURLResponse(url: TavilyAccount.authorizationEndpoint, statusCode: 302,
                                                                         httpVersion: nil, headerFields: [:])!))
    }

    /// 新規登録 asks mcp.tavily.com where its sign-in goes and opens that page
    /// at sign-up, with the app's own state and PKCE, so the answer comes back
    /// as from ログイン. ログイン doesn't ask. Offline says so; any other
    /// answer opens the sign-in page.
    func testSignUpOpensTheSameSignInAtSignUp() async throws {
        let server = FakeTavily()
        let store = MemoryStore()
        let session = TavilyAccountSession(store: store, transport: server.transport, withoutRedirects: server.transport,
                                           now: { server.now })
        let signIn = try await session.beginSignIn()
        XCTAssertEqual(signIn.url.host, "mcp.tavily.com")
        XCTAssertEqual(server.paths, ["/register"], "ログイン opens mcp.tavily.com's page as before")

        let signUp = try await session.beginSignIn(signUp: true)
        XCTAssertEqual(signUp.url.absoluteString, FakeTavily.signInPage + "&screen_hint=signup")
        XCTAssertEqual(server.paths, ["/register", "/authorize"])
        let asked = try XCTUnwrap(server.lastAuthorize)
        let items = Dictionary(uniqueKeysWithValues: (URLComponents(url: asked, resolvingAgainstBaseURL: false)?.queryItems ?? [])
            .map { ($0.name, $0.value ?? "") })
        XCTAssertEqual(items["state"], signUp.state, "mcp.tavily.com was asked with this sign-in's state")
        XCTAssertEqual(items["code_challenge"], TavilyAccount.challenge(for: signUp.verifier))
        XCTAssertEqual(items["redirect_uri"], "fielua://oauth/tavily")
        let result = try await session.finishSignIn(callback: server.callback(for: signUp), signIn: signUp)
        XCTAssertEqual(result, .ready)
        XCTAssertEqual(store.load()?.status, .connected)

        server.authorizeAnswer = (200, nil)
        let page = try await session.beginSignIn(signUp: true)
        XCTAssertEqual(page.url.host, "mcp.tavily.com", "an unexpected answer opens the sign-in page")
        server.authorizeAnswer = (302, "https://evil.example/authorize?state=s")
        let elsewhere = try await session.beginSignIn(signUp: true)
        XCTAssertEqual(elsewhere.url.host, "mcp.tavily.com")
        server.offline = true
        do { _ = try await session.beginSignIn(signUp: true); XCTFail("offline opened a page") } catch {
            XCTAssertEqual(error as? TavilySignInError, .offline)
        }
        server.offline = false

        let plain = TavilyAccountSession(store: store, transport: server.transport, now: { server.now })
        server.paths = []
        let fallback = try await plain.beginSignIn(signUp: true)
        XCTAssertEqual(fallback.url.host, "mcp.tavily.com", "no way to stop at the redirect: the sign-in page")
        XCTAssertEqual(server.paths, [])
    }

    /// Only Tavily's answer to this sign-in gives a code: the right redirect,
    /// the right state, Tavily as issuer when named; a refusal says so.
    func testTheAnswerMustMatchTheSignIn() throws {
        let signIn = TavilyAccount.signIn(clientID: "abc")
        let state = signIn.state.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let good = URL(string: "fielua://oauth/tavily?code=C1&state=\(state)&iss=https%3A%2F%2Fmcp.tavily.com%2F")!
        XCTAssertEqual(try TavilyAccount.code(from: good, for: signIn), "C1")
        XCTAssertEqual(try TavilyAccount.code(from: URL(string: "fielua://oauth/tavily?code=C2&state=\(state)")!, for: signIn), "C2")
        let wrong: [(String, TavilySignInError)] = [
            ("fielua://oauth/tavily?code=C1&state=other", .failed),
            ("fielua://oauth/tavily?code=C1&state=\(state)&iss=https%3A%2F%2Fevil.example%2F", .failed),
            ("fielua://elsewhere?code=C1&state=\(state)", .failed),
            ("other://oauth/tavily?code=C1&state=\(state)", .failed),
            ("fielua://oauth/tavily?state=\(state)", .failed),
            ("fielua://oauth/tavily?error=access_denied&state=\(state)", .denied),
            ("fielua://oauth/tavily?error=server_error&state=\(state)", .failed)
        ]
        for (url, expected) in wrong {
            XCTAssertThrowsError(try TavilyAccount.code(from: URL(string: url)!, for: signIn), url) {
                XCTAssertEqual($0 as? TavilySignInError, expected, url)
            }
        }
    }

    /// The token request carries the verifier and the resource; the revoke
    /// carries an empty client_secret, which Tavily's server asks for.
    func testTokenAndRevokeRequests() throws {
        let signIn = TavilyAccount.signIn(clientID: "abc")
        let fields = form(TavilyAccount.tokenRequest(code: "C1", for: signIn))
        XCTAssertEqual(fields["grant_type"], "authorization_code")
        XCTAssertEqual(fields["code_verifier"], signIn.verifier)
        XCTAssertEqual(fields["redirect_uri"], "fielua://oauth/tavily")
        XCTAssertEqual(fields["resource"], "https://mcp.tavily.com/mcp")
        XCTAssertNil(fields["client_secret"])
        let revoke = form(TavilyAccount.revokeRequest(token: "R+1/=", hint: "refresh_token", clientID: "abc"))
        XCTAssertEqual(revoke["token"], "R+1/=", "form values are percent-encoded")
        XCTAssertEqual(revoke["client_secret"], "")
        let now = Date(timeIntervalSince1970: 1_000)
        let tokens = try TavilyAccount.tokens(from: Data(#"{"access_token":"A","expires_in":3600,"token_type":"Bearer"}"#.utf8),
                                              now: now, keeping: "R")
        XCTAssertEqual(tokens, TavilyAccount.Tokens(access: "A", refresh: "R", expiresAt: now.addingTimeInterval(3540)))
    }

    /// Answers as the server sends them: an event stream with the search
    /// API's answer as structuredContent, the same JSON as text, the
    /// keyless limit's payload, a JSON-RPC error.
    func testReadingTheSearchToolsAnswer() throws {
        let stream = Data("event: message\r\ndata: {\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"content\":[{\"type\":\"text\",\"text\":\"{}\"}],\"structuredContent\":{\"query\":\"q\",\"results\":[{\"url\":\"https://example.com/a\",\"title\":\"A\",\"content\":\"Body\"}]},\"isError\":false}}\r\n\r\n".utf8)
        let message = try XCTUnwrap(TavilyAccount.message(from: stream, contentType: "text/event-stream"))
        let answer = try TavilyAccount.searchAnswer(fromCall: message)
        let hits = try TavilySearch.parse(JSONSerialization.data(withJSONObject: answer))
        XCTAssertEqual(hits.map(\.url), ["https://example.com/a"], "the same reading as a search with a key")

        let text = ["result": ["content": [["type": "text", "text": #"{"query":"q","results":[]}"#]]]] as [String: Any]
        XCTAssertEqual((try TavilyAccount.searchAnswer(fromCall: text)["results"] as? [Any])?.count, 0)

        let cap: [String: Any] = ["result": ["isError": false, "structuredContent": [
            "code": "monthly_cap_reached_bonus_eligible", "message": "You reached the monthly keyless Tavily limit."]]]
        XCTAssertThrowsError(try TavilyAccount.searchAnswer(fromCall: cap)) { XCTAssertEqual($0 as? WebSearchFailure, .quota) }
        let rate: [String: Any] = ["result": ["isError": true, "content": [["type": "text", "text": "Rate limit exceeded, slow down"]]]]
        XCTAssertThrowsError(try TavilyAccount.searchAnswer(fromCall: rate)) { XCTAssertEqual($0 as? WebSearchFailure, .rateLimited) }
        let status: [String: Any] = ["result": ["structuredContent": ["error": "Unauthorized", "status": 432]]]
        XCTAssertThrowsError(try TavilyAccount.searchAnswer(fromCall: status)) { XCTAssertEqual($0 as? WebSearchFailure, .quota) }
        let broken: [String: Any] = ["result": ["isError": true, "content": [["type": "text", "text": "Something went wrong"]]]]
        XCTAssertThrowsError(try TavilyAccount.searchAnswer(fromCall: broken)) { XCTAssertEqual($0 as? WebSearchFailure, .unavailable) }
        let rpc: [String: Any] = ["error": ["code": -32600, "message": "Bad request"]]
        XCTAssertThrowsError(try TavilyAccount.searchAnswer(fromCall: rpc)) { XCTAssertEqual($0 as? WebSearchFailure, .unavailable) }
        XCTAssertNil(TavilyAccount.message(from: Data("event: ping\n\n".utf8), contentType: "text/event-stream"))
    }

    /// Signing in end to end: registration once, code to tokens, one check
    /// search through a fresh MCP session, then the sign-in is kept.
    func testSignInRegistersOnceChecksASearchAndKeepsTheTokens() async throws {
        let server = FakeTavily()
        let store = MemoryStore()
        let session = TavilyAccountSession(store: store, transport: server.transport, now: { server.now })
        let signIn = try await session.beginSignIn()
        XCTAssertEqual(store.load()?.clientID, "client-1")
        XCTAssertEqual(store.load()?.status, .signedOut, "registered, not yet connected")
        let result = try await session.finishSignIn(callback: server.callback(for: signIn), signIn: signIn)
        XCTAssertEqual(result, .ready)
        XCTAssertEqual(store.load()?.status, .connected)
        XCTAssertEqual(store.load()?.accessToken, "access-1")
        XCTAssertEqual(server.paths, ["/register", "/token", "/mcp initialize", "/mcp notifications/initialized", "/mcp tools/call"])
        XCTAssertEqual(server.lastArguments?["query"] as? String, "Tavily", "the check searches a fixed word, nothing of the person's")
        XCTAssertEqual(server.lastArguments?["max_results"] as? Int, 1)
        _ = try await session.beginSignIn()
        XCTAssertEqual(server.paths.filter { $0 == "/register" }.count, 1, "the registration is kept")
    }

    /// An account that can't search yet isn't called connected, and its
    /// tokens are revoked; a used-up month still connects, with the reason.
    func testASignInThatCannotSearchIsNotConnected() async throws {
        let server = FakeTavily()
        server.searchAnswer = ["error": "Account has no API key"]
        let store = MemoryStore()
        let session = TavilyAccountSession(store: store, transport: server.transport, now: { server.now })
        let signIn = try await session.beginSignIn()
        do {
            _ = try await session.finishSignIn(callback: server.callback(for: signIn), signIn: signIn)
            XCTFail("connected without a search")
        } catch { XCTAssertEqual(error as? TavilySignInError, .cannotSearch) }
        XCTAssertEqual(store.load()?.status, .signedOut)
        XCTAssertNil(store.load()?.accessToken)
        XCTAssertTrue(server.paths.contains("/revoke"))

        server.searchAnswer = ["code": "usage_limit_exceeded", "message": "Plan usage limit exceeded"]
        let again = try await session.beginSignIn()
        let result = try await session.finishSignIn(callback: server.callback(for: again), signIn: again)
        XCTAssertEqual(result, .limited(.quota))
        XCTAssertEqual(store.load()?.status, .connected)
    }

    /// A search with the account: the MCP session is reused; an expired
    /// token is renewed first; a token Tavily turns down is renewed once
    /// and the search tried again; a forgotten MCP session is reopened.
    func testSearchRenewsTheSignInAndReopensTheSession() async throws {
        let server = FakeTavily()
        server.tokenNumber = 1
        let store = MemoryStore()
        store.save(TavilyAccountRecord(clientID: "client-1", accessToken: "access-1", refreshToken: "refresh-1",
                                       expiresAt: server.now.addingTimeInterval(600)))
        let session = TavilyAccountSession(store: store, transport: server.transport, now: { server.now })
        let arguments = try JSONSerialization.data(withJSONObject: ["query": "東京 天気", "max_results": 3])
        _ = try await session.search(arguments: arguments)
        _ = try await session.search(arguments: arguments)
        XCTAssertEqual(server.paths.filter { $0 == "/mcp initialize" }.count, 1, "one MCP session for both")
        XCTAssertEqual(server.lastArguments?["query"] as? String, "東京 天気")
        XCTAssertEqual(server.lastAuthorization, "Bearer access-1")

        server.now = server.now.addingTimeInterval(3600)
        server.paths = []
        _ = try await session.search(arguments: arguments)
        XCTAssertEqual(server.paths.first, "/token", "an expired token is renewed before searching")
        XCTAssertEqual(store.load()?.accessToken, "access-2")
        XCTAssertEqual(server.lastAuthorization, "Bearer access-2")

        server.rejectToken = "access-2"
        server.paths = []
        _ = try await session.search(arguments: arguments)
        XCTAssertEqual(server.paths, ["/mcp tools/call", "/token", "/mcp initialize", "/mcp notifications/initialized", "/mcp tools/call"])
        XCTAssertEqual(store.load()?.accessToken, "access-3")

        server.forgetSessions()
        server.paths = []
        _ = try await session.search(arguments: arguments)
        XCTAssertEqual(server.paths, ["/mcp tools/call", "/mcp initialize", "/mcp notifications/initialized", "/mcp tools/call"])
    }

    /// Tavily refusing the renewal means signing in again, kept so the
    /// settings say so; no connection is just offline and keeps the sign-in.
    func testARefusedRenewalAsksToSignInAgain() async throws {
        let server = FakeTavily()
        let store = MemoryStore()
        store.save(TavilyAccountRecord(clientID: "client-1", accessToken: "access-1", refreshToken: "refresh-1",
                                       expiresAt: server.now.addingTimeInterval(-1)))
        let session = TavilyAccountSession(store: store, transport: server.transport, now: { server.now })
        let arguments = try JSONSerialization.data(withJSONObject: ["query": "q"])
        server.offline = true
        do { _ = try await session.search(arguments: arguments); XCTFail() } catch {
            XCTAssertEqual(error as? WebSearchFailure, .offline)
        }
        XCTAssertEqual(store.load()?.status, .connected, "offline keeps the sign-in")
        server.offline = false
        server.refuseRefresh = true
        do { _ = try await session.search(arguments: arguments); XCTFail() } catch {
            XCTAssertEqual(error as? WebSearchFailure, .signInNeeded)
        }
        XCTAssertEqual(store.load()?.status, .needsSignIn)
        XCTAssertNil(store.load()?.refreshToken, "the refused tokens are dropped")
        server.paths = []
        do { _ = try await session.search(arguments: arguments); XCTFail() } catch {
            XCTAssertEqual(error as? WebSearchFailure, .signInNeeded)
        }
        XCTAssertEqual(server.paths, [], "no request until the person signs in again")
        // Signing in again keeps the registration.
        server.refuseRefresh = false
        let signIn = try await session.beginSignIn()
        XCTAssertEqual(signIn.clientID, "client-1")
        _ = try await session.finishSignIn(callback: server.callback(for: signIn), signIn: signIn)
        XCTAssertEqual(store.load()?.status, .connected)
    }

    /// Disconnecting forgets the sign-in on the device first, then asks
    /// Tavily to revoke both tokens; offline it is still forgotten here.
    func testDisconnectForgetsAndRevokes() async throws {
        let server = FakeTavily()
        let store = MemoryStore()
        let record = TavilyAccountRecord(clientID: "client-1", accessToken: "access-1", refreshToken: "refresh-1",
                                         expiresAt: server.now.addingTimeInterval(600))
        store.save(record)
        let session = TavilyAccountSession(store: store, transport: server.transport, now: { server.now })
        let confirmed = await session.disconnect()
        XCTAssertTrue(confirmed)
        XCTAssertNil(store.load())
        XCTAssertEqual(server.revoked, ["refresh-1", "access-1"])
        store.save(record)
        server.offline = true
        let offline = await session.disconnect()
        XCTAssertFalse(offline)
        XCTAssertNil(store.load(), "forgotten on the device even when Tavily can't be told")
        do { _ = try await session.search(arguments: Data("{}".utf8)); XCTFail() } catch {
            XCTAssertEqual(error as? WebSearchFailure, .keyMissing)
        }
    }

    /// Sign-in failures each have their words; closing the page has none.
    func testSignInErrors() {
        XCTAssertEqual(TavilySignInError(URLError(.notConnectedToInternet)), .offline)
        XCTAssertEqual(TavilySignInError(URLError(.cancelled)), .cancelled)
        XCTAssertEqual(TavilySignInError(URLError(.timedOut)), .failed)
        XCTAssertEqual(TavilySignInError(CancellationError()), .cancelled)
        XCTAssertNil(TavilySignInError.cancelled.message)
        XCTAssertTrue(TavilySignInError.offline.message?.contains("インターネット") == true)
        XCTAssertTrue(WebSearchFailure.signInNeeded.message.contains("ログイン"))
        XCTAssertEqual(WebSearchFailure(WebSearchFailure.signInNeeded), .signInNeeded)
    }

    private func redirect(_ status: Int, _ location: String) -> HTTPURLResponse {
        HTTPURLResponse(url: TavilyAccount.authorizationEndpoint, statusCode: status, httpVersion: nil,
                        headerFields: ["Location": location])!
    }

    private func form(_ request: URLRequest) -> [String: String] {
        let body = String(decoding: request.httpBody ?? Data(), as: UTF8.self)
        var fields: [String: String] = [:]
        for pair in body.split(separator: "&") {
            let parts = pair.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            fields[String(parts[0])] = String(parts.count > 1 ? parts[1] : "").removingPercentEncoding
        }
        return fields
    }
}

private final class MemoryStore: TavilyAccountStore, @unchecked Sendable {
    private let lock = NSLock()
    private var record: TavilyAccountRecord?
    func load() -> TavilyAccountRecord? { lock.locked { record } }
    @discardableResult func save(_ record: TavilyAccountRecord) -> Bool { lock.locked { self.record = record }; return true }
    func delete() { lock.locked { record = nil } }
}

/// mcp.tavily.com as the probe saw it, in memory.
private final class FakeTavily: @unchecked Sendable {
    /// Where /authorize sent the browser in run 40705304587, with its
    /// own client, state and challenge made up.
    static let signInPage = "https://auth.tavily.com/authorize?response_type=code&client_id=upstream-client"
        + "&redirect_uri=https%3A%2F%2Fmcp.tavily.com%2Fauth%2Fcallback&state=upstream-state&scope=openid+offline_access"
        + "&code_challenge=upstream-challenge&code_challenge_method=S256&audience=tavily-remote-mcp-auth-api"
    private let lock = NSLock()
    var authorizeAnswer: (status: Int, location: String?) = (302, FakeTavily.signInPage)
    var lastAuthorize: URL?
    var now = Date(timeIntervalSince1970: 1_800_000_000)
    var paths: [String] = []
    var revoked: [String] = []
    var lastArguments: [String: Any]?
    var lastAuthorization: String?
    var searchAnswer: [String: Any] = ["query": "q", "results": [["url": "https://example.com", "title": "Example", "content": "Text"]]]
    var offline = false
    var refuseRefresh = false
    var rejectToken: String?
    var tokenNumber = 0
    private var sessions: Set<String> = []
    private var code = ""
    private var verifier = ""

    func forgetSessions() { lock.locked { sessions = [] } }

    func callback(for signIn: TavilyAccount.SignIn) -> URL {
        lock.locked { code = "code-\(signIn.state.prefix(6))"; verifier = signIn.verifier }
        var components = URLComponents(string: TavilyAccount.redirectURI)!
        components.queryItems = [URLQueryItem(name: "code", value: code), URLQueryItem(name: "state", value: signIn.state),
                                 URLQueryItem(name: "iss", value: TavilyAccount.issuer)]
        return components.url!
    }

    var transport: TavilyAccountSession.Transport {
        { [self] request in try lock.locked { try answer(request) } }
    }

    private func answer(_ request: URLRequest) throws -> (Data, HTTPURLResponse) {
        if offline { throw URLError(.notConnectedToInternet) }
        let path = request.url?.path ?? ""
        let body = request.httpBody ?? Data()
        switch path {
        case "/authorize":
            paths.append(path)
            lastAuthorize = request.url
            let headers = authorizeAnswer.location.map { ["Location": $0] } ?? ["Content-Type": "text/html"]
            return (Data(), HTTPURLResponse(url: request.url!, statusCode: authorizeAnswer.status, httpVersion: nil, headerFields: headers)!)
        case "/register":
            paths.append(path)
            return reply(201, ["client_id": "client-1", "token_endpoint_auth_method": "none"])
        case "/token":
            paths.append(path)
            let fields = form(body)
            if fields["grant_type"] == "authorization_code" {
                guard fields["code"] == code, TavilyAccount.challenge(for: fields["code_verifier"] ?? "") == TavilyAccount.challenge(for: verifier)
                else { return reply(401, ["error": "invalid_grant"]) }
            } else if refuseRefresh {
                return reply(401, ["error": "invalid_grant", "error_description": "refresh token does not exist"])
            }
            tokenNumber += 1
            return reply(200, ["access_token": "access-\(tokenNumber)", "refresh_token": "refresh-\(tokenNumber)",
                               "expires_in": 3600, "token_type": "Bearer"])
        case "/revoke":
            paths.append(path)
            let fields = form(body)
            guard fields["client_secret"] == "" else { return reply(400, ["error": "invalid_request"]) }
            revoked.append(fields["token"] ?? "")
            return reply(200, [:])
        case "/mcp":
            let message = (try? JSONSerialization.jsonObject(with: body) as? [String: Any]) ?? [:]
            let method = message["method"] as? String ?? ""
            paths.append("/mcp \(method)")
            let authorization = request.value(forHTTPHeaderField: "Authorization") ?? ""
            lastAuthorization = authorization
            guard authorization.hasPrefix("Bearer access-"), authorization != "Bearer \(rejectToken ?? "-")" else {
                return reply(401, ["error": "invalid_token"])
            }
            if method == "initialize" {
                let id = UUID().uuidString
                sessions.insert(id)
                return stream(["jsonrpc": "2.0", "id": 1, "result": ["protocolVersion": "2025-06-18"]], session: id)
            }
            guard let session = request.value(forHTTPHeaderField: "Mcp-Session-Id"), sessions.contains(session) else {
                return reply(400, ["jsonrpc": "2.0", "id": "server-error",
                                   "error": ["code": -32600, "message": "Missing mcp-session-id header. Please reconnect to start a new session."]])
            }
            if method == "notifications/initialized" { return reply(202, [:]) }
            lastArguments = (message["params"] as? [String: Any])?["arguments"] as? [String: Any]
            return stream(["jsonrpc": "2.0", "id": 2, "result": ["content": [["type": "text", "text": "…"]],
                                                                  "structuredContent": searchAnswer, "isError": false]], session: nil)
        default:
            return reply(404, [:])
        }
    }

    private func reply(_ status: Int, _ json: [String: Any]) -> (Data, HTTPURLResponse) {
        (try! JSONSerialization.data(withJSONObject: json),
         HTTPURLResponse(url: TavilyAccount.endpoint, statusCode: status, httpVersion: nil, headerFields: ["Content-Type": "application/json"])!)
    }

    private func stream(_ json: [String: Any], session: String?) -> (Data, HTTPURLResponse) {
        let data = try! JSONSerialization.data(withJSONObject: json)
        var headers = ["Content-Type": "text/event-stream"]
        if let session { headers["mcp-session-id"] = session }
        return (Data("event: message\r\ndata: ".utf8) + data + Data("\r\n\r\n".utf8),
                HTTPURLResponse(url: TavilyAccount.endpoint, statusCode: 200, httpVersion: nil, headerFields: headers)!)
    }

    private func form(_ body: Data) -> [String: String] {
        var fields: [String: String] = [:]
        for pair in String(decoding: body, as: UTF8.self).split(separator: "&") {
            let parts = pair.split(separator: "=", maxSplits: 1, omittingEmptySubsequences: false)
            fields[String(parts[0])] = String(parts.count > 1 ? parts[1] : "").removingPercentEncoding
        }
        return fields
    }
}

private extension NSLock {
    func locked<T>(_ body: () throws -> T) rethrows -> T {
        lock()
        defer { unlock() }
        return try body()
    }
}
