import XCTest
@testable import PocketCore

/// 要点 (1.1.0 (302)): what the point beside the Aurora Orb says and when.
/// The reply is read as it is laid out (a prefix of its text at a time);
/// points come only from what has been read, never as the reply's own
/// words cut out, and stay at least ReplyPoints.quiet. POINTS-NOTE lines
/// in the log carry the points each stream gave.
final class ReplyPointsTests: XCTestCase {
    static let sample = "量子コンピュータは、量子ビットという仕組みを使って、たくさんの計算を同時に進めます。身近な例では、薬の候補を探したり、物流の道順を最適化したりする研究が進んでいます。\n\nただし、まだ誤りが多く、実用化には時間がかかると考えられています。"
    static let more = "量子ビットは、0と1を同時に重ね合わせた状態を持てます。この性質を使うと、ある種の問題では、いまのコンピュータよりずっと少ない手順で答えに近づけます。ただ、量子の状態はとても壊れやすく、周りの熱や振動でもすぐに乱れてしまいます。そのため、装置を極低温に冷やしたり、誤りを見つけて直す仕組みを重ねたりする研究が続いています。"
    static let photosynthesis = "光合成とは、植物が光のエネルギーを使って、水と二酸化炭素から糖をつくるはたらきです。葉緑体という小さな器官で行われます。"
    static let battery = "画面の明るさを下げると、電池が長持ちします。位置情報も使うときだけにすると、さらに減りを抑えられます。"
    static let markdown = "## 量子コンピュータのしくみ\n\n量子コンピュータは、**量子ビット**を使って計算します。\n\n"
        + "- 重ね合わせ：0と1を同時に持てます\n- もつれ：離れた量子ビットが結びつきます\n\n"
        + "```swift\nlet qubit = Qubit()\nqubit.apply(.hadamard)\n```\n\n"
        + "ふつうのコンピュータとは、`ビット`の扱い方が違います。\n\n"
        + "| 方式 | 速さ | 誤り |\n|---|---|---|\n| 超伝導 | 速い | 多い |\n\n$$\nE = mc^2\n$$\n\n"
        + "## 実用化への課題\n\nまだ誤りが多いのが課題です。\n"

    // MARK: The outline

    func testTheOutlineHasSectionsItemsTablesAndBlocks() {
        var outline = ReplyOutline()
        outline.read(Self.markdown)
        XCTAssertEqual(outline.sections.count, 2)
        let first = outline.sections[0]
        XCTAssertEqual(first.heading, "量子コンピュータのしくみ")
        XCTAssertEqual(first.leads, ["重ね合わせ", "もつれ"])
        XCTAssertEqual(first.bold, ["量子ビット"])
        XCTAssertEqual(first.code, ["swift"])
        XCTAssertEqual(first.table, ["方式", "速さ", "誤り"])
        XCTAssertEqual(first.formulas, 1)
        let words = String(first.prose)
        XCTAssertTrue(words.contains("量子コンピュータは、量子ビットを使って計算します。"), words)
        XCTAssertTrue(words.contains("ふつうのコンピュータとは、ビットの扱い方が違います。"), words)
        for hidden in ["qubit", "Qubit", "mc^2", "超伝導", "**", "#"] {
            XCTAssertFalse(words.contains(hidden), "\(hidden) is no sentence of the reply: \(words)")
        }
        XCTAssertEqual(outline.sections[1].heading, "実用化への課題")
        XCTAssertEqual(outline.sections[1].last, .prose)
        XCTAssertEqual(outline.passage(from: 0), "まだ誤りが多いのが課題です。")
    }

    func testOnlyEndedSentencesOfTheLineBeingWrittenCount() {
        var outline = ReplyOutline()
        outline.read("量子ビットは、0と1を同時に持てます。この性質を")
        XCTAssertEqual(outline.passage(from: 0), "量子ビットは、0と1を同時に持てます。")
        XCTAssertEqual(outline.newestWritten, 19)
        outline.read("量子ビットは、0と1を同時に持てます。この性質を使います")
        XCTAssertEqual(outline.passage(from: 0), "量子ビットは、0と1を同時に持てます。")
        outline.read("量子ビットは、0と1を同時に持てます。この性質を使います\n\n## 次")
        XCTAssertEqual(outline.passage(from: 0), "量子ビットは、0と1を同時に持てます。この性質を使います")
        XCTAssertEqual(outline.sections.count, 1, "A heading still being written is not one yet")
    }

    func testAReplacedTextIsReadAfresh() {
        var outline = ReplyOutline()
        outline.read("一つめの返信です。\n")
        outline.read("別の返信です。\n")
        XCTAssertEqual(outline.starts, 1)
        XCTAssertEqual(outline.passage(from: 0), "別の返信です。")
    }

    // MARK: Topics

    func testTopicsAreWhatThePassageSaysItIsAbout() {
        XCTAssertEqual(ReplyTopics.point(String(Self.sample.prefix(42)), japanese: true), "量子コンピュータ・量子ビット")
        XCTAssertEqual(ReplyTopics.point(Self.more, japanese: true), "量子ビット・量子の状態")
        XCTAssertEqual(ReplyTopics.point(Self.photosynthesis, japanese: true), "光合成・葉緑体")
        XCTAssertEqual(ReplyTopics.point("この設定では省電力と明るさを変えます。", bold: ["省電力", "明るさ"], japanese: true),
                       "省電力・明るさ")
    }

    func testNoTopicsFromSentencesThatNameNone() {
        XCTAssertNil(ReplyTopics.point("ただし、まだ誤りが多く、実用化には時間がかかると考えられています。", japanese: true))
        XCTAssertNil(ReplyTopics.point("はい、できます。", japanese: true))
        XCTAssertNil(ReplyTopics.point(Self.battery, japanese: true))
        // One topic alone would read as the reply's first words.
        XCTAssertNil(ReplyTopics.point("量子ビットは、0と1を同時に持てます。", japanese: true))
    }

    // MARK: A model's point, checked

    func testAShortRestatementIsAccepted() {
        XCTAssertEqual(ReplyPointCheck.accept("「画面と位置情報の節電」。", source: Self.battery), "画面と位置情報の節電")
        XCTAssertEqual(ReplyPointCheck.accept("要点：・量子ビットで同時に計算。", source: Self.sample), "量子ビットで同時に計算")
        XCTAssertEqual(ReplyPointCheck.accept("**実用化**までの課題です", source: Self.sample), "実用化までの課題")
        XCTAssertEqual(ReplyPointCheck.accept("壊れやすい量子状態への対策\n（説明）", source: Self.more), "壊れやすい量子状態への対策")
        XCTAssertEqual(ReplyPointCheck.accept("Saving battery life",
                                              source: "Lower the screen brightness to save battery life."),
                       "Saving battery life")
    }

    func testTheReplysOwnWordsCutOutAreRefused() {
        XCTAssertNil(ReplyPointCheck.accept("0と1を同時に重ね合わせた状態", source: Self.more))
        XCTAssertTrue(ReplyPointCheck.isCopy("たくさんの計算を同時に進めます", of: Self.sample))
        // Its first words.
        XCTAssertTrue(ReplyPointCheck.isCopy("量子ビット", of: Self.more))
        XCTAssertNil(ReplyPointCheck.accept("量子ビット", source: Self.more))
        XCTAssertFalse(ReplyPointCheck.isCopy("量子ビットで同時に計算", of: Self.sample))
        XCTAssertFalse(ReplyPointCheck.isCopy("量子の状態", of: Self.more))
    }

    func testWhatThePassageDoesNotSayIsRefused() {
        // A number it never gave.
        XCTAssertNil(ReplyPointCheck.accept("電池を3割長持ちさせる方法", source: Self.battery))
        // Something it never spoke of.
        XCTAssertNil(ReplyPointCheck.accept("電池の交換時期", source: Self.battery))
        XCTAssertNil(ReplyPointCheck.accept("量子暗号の安全性", source: Self.sample))
        XCTAssertFalse(ReplyPointCheck.grounded("ひらがなだけ", in: Self.sample))
    }

    func testRefusalsTalkAboutTheTextAndLongAnswersAreRefused() {
        XCTAssertNil(ReplyPointCheck.accept("申し訳ありませんが、お答えできません", source: Self.battery))
        XCTAssertNil(ReplyPointCheck.accept("この文章の要点", source: Self.battery))
        XCTAssertNil(ReplyPointCheck.accept("Sorry, I can't help with that", source: "Lower the screen brightness."))
        XCTAssertNil(ReplyPointCheck.accept(String(repeating: "量子", count: 13), source: Self.sample))
        XCTAssertNil(ReplyPointCheck.accept("  \n", source: Self.sample))
    }

    // MARK: When

    /// `text` laid out at `rate` characters a second, read every
    /// ReplyPoints.interval as the row reads it, each request settled at
    /// once with `summary`'s answer for its passage (nil: no model).
    private func stream(_ text: String, rate: Double, until end: TimeInterval,
                        summary: (ReplyPoints.Request) -> String? = { _ in nil })
        -> (points: [(at: TimeInterval, point: ReplyPoints.Point)], requests: [ReplyPoints.Request]) {
        let planner = ReplyPoints()
        let characters = Array(text)
        var points: [(at: TimeInterval, point: ReplyPoints.Point)] = []
        var requests: [ReplyPoints.Request] = []
        var now: TimeInterval = 0
        while now <= end {
            let laid = String(characters.prefix(Int(rate * now)))
            planner.read(laid)
            if let request = planner.next(now: now, ended: false) {
                requests.append(request)
                // Only what is laid out: the passage is in it.
                XCTAssertTrue(ReplyPreviewText.plain(laid).replacingOccurrences(of: " ", with: "")
                    .contains(request.passage.replacingOccurrences(of: " ", with: "")),
                              "\(request.passage) is not in what was laid out")
                if let point = planner.settle(request, summary: summary(request), now: now) { points.append((now, point)) }
            }
            now += ReplyPoints.interval
        }
        print("POINTS-NOTE " + points.map { String(format: "%.2f[%@]「%@」", $0.at, $0.point.kind.rawValue, $0.point.text) }
            .joined(separator: " "))
        return (points, requests)
    }

    func testPointsFollowTheReplyAndStayAtLeastQuiet() {
        let text = Self.sample + "\n\n" + Self.more + "\n\n" + Self.photosynthesis
        let (points, requests) = stream(text, rate: 30, until: 20)
        XCTAssertEqual(points.first?.point.text, "量子コンピュータ・量子ビット")
        XCTAssertEqual(points.last?.point.text, "光合成・葉緑体")
        XCTAssertTrue(points.contains { $0.point.text == "量子ビット・量子の状態" })
        XCTAssertTrue(points.allSatisfy { $0.point.kind == .topics })
        // The first only once its first sentence was there (42 characters).
        XCTAssertGreaterThanOrEqual(points.first?.at ?? 0, 42.0 / 30.0 - 0.01)
        for (later, earlier) in zip(points.dropFirst(), points) {
            XCTAssertGreaterThanOrEqual(later.at - earlier.at, ReplyPoints.quiet - 0.001)
        }
        XCTAssertLessThan(requests.count, 12, "A point is asked for only as the reply moves on")
    }

    func testNothingBeforeEnoughIsWrittenNorAfterTheEnd() {
        let quick = ReplyPoints()
        quick.read("はい、できます。")
        XCTAssertNil(quick.next(now: 10, ended: false))
        let ended = ReplyPoints()
        ended.read(Self.sample)
        XCTAssertNil(ended.next(now: 10, ended: true))
        let thinking = ReplyPoints()
        thinking.read("")
        XCTAssertNil(thinking.next(now: 10, ended: false))
    }

    func testAModelsPointIsShownOnlyIfItPasses() {
        let good = ReplyPoints()
        good.read(Self.sample)
        let first = try! XCTUnwrap(good.next(now: 0, ended: false))
        XCTAssertTrue(first.summarises)
        XCTAssertEqual(first.fallback?.text, "量子コンピュータ・量子ビット")
        XCTAssertEqual(good.settle(first, summary: "量子ビットで同時に計算", now: 0),
                       ReplyPoints.Point(text: "量子ビットで同時に計算", kind: .summary))
        XCTAssertNil(good.next(now: 1, ended: false), "Nothing new while one is out or the last is new")

        let copied = ReplyPoints()
        copied.read(Self.sample)
        let request = try! XCTUnwrap(copied.next(now: 0, ended: false))
        XCTAssertTrue(copied.waiting)
        XCTAssertEqual(copied.settle(request, summary: "たくさんの計算を同時に進めます", now: 0)?.kind, .topics,
                       "The reply's words cut out are not shown: its structure's point is")
        XCTAssertFalse(copied.waiting)
    }

    func testANewSectionAsksAgainAndBlocksSayWhatTheyAre() {
        let planner = ReplyPoints()
        planner.read("## 準備\n\n画面の明るさを下げると、電池が長持ちします。位置情報も使うときだけにします。\n")
        let first = try! XCTUnwrap(planner.next(now: 0, ended: false))
        XCTAssertEqual(first.heading, "準備")
        XCTAssertEqual(planner.settle(first, summary: "画面と位置情報の節電", now: 0)?.text, "画面と位置情報の節電")
        planner.read("## 準備\n\n画面の明るさを下げると、電池が長持ちします。位置情報も使うときだけにします。\n\n"
                     + "次の表にまとめます。\n\n| 機種 | 価格 | 重さ |\n|---|---|---|\n| A | 1万円 | 100g |\n")
        XCTAssertNil(planner.next(now: 2, ended: false), "Not before the last has stood its time")
        let table = try! XCTUnwrap(planner.next(now: 5, ended: false))
        XCTAssertFalse(table.summarises)
        XCTAssertEqual(planner.settle(table, summary: "何か", now: 5)?.text, "表：機種・価格・重さ")
        planner.read("## 準備\n\n画面の明るさを下げると、電池が長持ちします。位置情報も使うときだけにします。\n\n"
                     + "次の表にまとめます。\n\n| 機種 | 価格 | 重さ |\n|---|---|---|\n| A | 1万円 | 100g |\n\n"
                     + "```python\nprint(1)\n```\n")
        let code = try! XCTUnwrap(planner.next(now: 10, ended: false))
        XCTAssertEqual(planner.settle(code, summary: nil, now: 10)?.text, "Python のコード")
        planner.read("## 準備\n\n画面の明るさを下げると、電池が長持ちします。位置情報も使うときだけにします。\n\n"
                     + "次の表にまとめます。\n\n| 機種 | 価格 | 重さ |\n|---|---|---|\n| A | 1万円 | 100g |\n\n"
                     + "```python\nprint(1)\n```\n\n## 確認\n\n設定のあとは、電池の減り方を一日見て、変わったかを確かめます。\n")
        let section = try! XCTUnwrap(planner.next(now: 15, ended: false))
        XCTAssertEqual(section.heading, "確認")
        XCTAssertEqual(section.passage, "設定のあとは、電池の減り方を一日見て、変わったかを確かめます。")
    }

    func testAListsTermsAreItsPoint() {
        let planner = ReplyPoints()
        planner.read("## 量子の性質\n\n- **重ね合わせ**：0と1を同時に持てます\n- **もつれ**：離れた量子ビットが結びつきます\n")
        let request = try! XCTUnwrap(planner.next(now: 0, ended: false))
        XCTAssertEqual(request.fallback, ReplyPoints.Point(text: "量子の性質：重ね合わせ・もつれ", kind: .structure))
    }

    func testThoughtsAreNeverRead() {
        let planner = ReplyPoints()
        planner.read("<think>秘密の考えです。秘密の考えです。秘密の考えです。秘密の考えです。</think>" + Self.sample)
        let request = try! XCTUnwrap(planner.next(now: 0, ended: false))
        XCTAssertFalse(request.passage.contains("秘密"))
    }

    // MARK: How they come and go

    func testAPointTakesThePlaceOfTheOneBefore() {
        let preview = ReplyPreview()
        let measure: (String) -> Double = { _ in 18 }
        XCTAssertTrue(preview.show("量子コンピュータ・量子ビット", now: 10, measure: measure))
        XCTAssertEqual(preview.current?.number, 1)
        XCTAssertNil(preview.previous)
        XCTAssertEqual(preview.firstShownAt, 10)
        XCTAssertEqual(preview.current?.pieces.first?.at ?? 0, 10 + ReplyPreview.firstDelay, accuracy: 0.0001)
        XCTAssertFalse(preview.show("量子コンピュータ・量子ビット", now: 11, measure: measure), "The same point does not come again")
        XCTAssertTrue(preview.show("量子ビット・量子の状態", now: 15, measure: measure))
        XCTAssertEqual(preview.previous?.phrase.text, "量子コンピュータ・量子ビット")
        XCTAssertEqual(preview.current?.pieces.first?.at ?? 0, 15 + ReplyPreview.swapDelay, accuracy: 0.0001)
        XCTAssertEqual(preview.firstShownAt, 10)
        XCTAssertFalse(preview.tidy(now: 15.3))
        XCTAssertTrue(preview.tidy(now: 15.6))
        XCTAssertNil(preview.previous)
    }
}
