import XCTest
@testable import PocketCore

/// モデル管理's 回答の速さ and 端末への負担 (1.1.0 (225), fielua-reports
/// Issue #4), in place of the two gauges.
final class ModelGaugeTests: XCTestCase {
    private let phone12 = DeviceCapacity(memoryBytes: 12_000_000_000, freeDiskBytes: 30_000_000_000,
                                         processorCount: 6, isPad: false, availableMemoryBytes: 6_000_000_000)

    func testTheFiveSpeedWordsGoFromSlowToFast() {
        XCTAssertEqual(ReplySpeed.allCases.map(\.label), ["かなりゆっくり", "ゆっくり", "速い", "とても速い", "高速"])
        XCTAssertEqual(ReplySpeed(tokensPerSecond: 4.9), .verySlow)
        XCTAssertEqual(ReplySpeed(tokensPerSecond: 5), .slow)
        XCTAssertEqual(ReplySpeed(tokensPerSecond: 12), .fast)
        XCTAssertEqual(ReplySpeed(tokensPerSecond: 20), .veryFast)
        XCTAssertEqual(ReplySpeed(tokensPerSecond: 40), .fastest)
        XCTAssertEqual(ReplySpeed.unratedLabel, "未評価")
    }

    /// Each word comes from an iPhone figure; models nobody timed on an
    /// iPhone say 未評価 instead of a guess.
    func testSpeedsComeOnlyFromMeasuredIPhoneFigures() {
        let words = Dictionary(uniqueKeysWithValues: ModelSpec.catalog.map { ($0.id, ModelRecommendation.fit($0, device: phone12).speedLabel) })
        XCTAssertEqual(words[ModelSpec.e2b.id], "高速")
        XCTAssertEqual(words[ModelSpec.e4b.id], "とても速い")
        XCTAssertEqual(words[ModelSpec.gemma12B.id], "速い")
        XCTAssertEqual(words[ModelSpec.qwen35.id], "ゆっくり")
        XCTAssertEqual(words[ModelSpec.phi4MiniReasoning.id], "かなりゆっくり")
        XCTAssertEqual(words[ModelSpec.qwen3.id], "未評価")
        XCTAssertEqual(words[ModelSpec.qwen25.id], "未評価")
        XCTAssertEqual(words[ModelSpec.lfm3.id], "未評価", "LFM3 hasn't been timed on an iPhone yet (232)")
        for spec in ModelSpec.catalog {
            guard let evidence = SpeedEvidence.of(spec) else { continue }
            if evidence.source == .reasoning {
                XCTAssertTrue(spec.capabilities.reasons, "only a model that thinks first is rated without a figure")
            } else {
                XCTAssertNotNil(evidence.tokensPerSecond)
                XCTAssertTrue(evidence.device.hasPrefix("iPhone"), "\(spec.name) is rated from an iPhone")
                XCTAssertEqual(evidence.speed, ReplySpeed(tokensPerSecond: evidence.tokensPerSecond!))
            }
        }
        XCTAssertEqual(SpeedEvidence.of(.e2b)?.basis, "iPhone 17 ProのGPUで毎秒約57トークン（配布元の公開値）")
        XCTAssertEqual(SpeedEvidence.of(.gemma12B)?.basis, "iPhone 18 ProのGPUで毎秒約16トークン（Fieluaの実測）")
        XCTAssertEqual(SpeedEvidence.of(.qwen35)?.processor, "CPU", "Qwen3.5 runs on the CPU")
    }

    /// The burden follows the device's memory, not what is free the moment
    /// the page opens: a model the app already holds changes nothing.
    func testBurdenDependsOnTheDeviceNotOnWhatIsFreeNow() {
        let loaded = DeviceCapacity(memoryBytes: phone12.memoryBytes, freeDiskBytes: phone12.freeDiskBytes,
                                    processorCount: 6, isPad: false, availableMemoryBytes: 1_000_000_000)
        for spec in ModelSpec.catalog {
            XCTAssertEqual(ModelRecommendation.fit(spec, device: loaded).burden,
                           ModelRecommendation.fit(spec, device: phone12).burden, spec.name)
        }
        let burden = { (spec: ModelSpec, device: DeviceCapacity) in ModelRecommendation.fit(spec, device: device).burden }
        XCTAssertEqual(burden(.e2b, phone12), .low)
        XCTAssertEqual(burden(.e4b, phone12), .moderate)
        XCTAssertEqual(burden(.gemma12B, phone12), .high)
        XCTAssertEqual(burden(.qwen25, phone12), .low)
        XCTAssertEqual(burden(.lfm3, phone12), .low)
        // Phi and Qwen3.5 hold their weights in memory and work on the CPU.
        XCTAssertEqual(burden(.qwen35, phone12), .moderate)
        XCTAssertEqual(burden(.phi4MiniReasoning, phone12), .moderate)
        let phone8 = DeviceCapacity(memoryBytes: 8_000_000_000, freeDiskBytes: 30_000_000_000, processorCount: 6, isPad: false)
        XCTAssertEqual(burden(.e2b, phone8), .moderate)
        XCTAssertEqual(burden(.e4b, phone8), .high)
        XCTAssertEqual(burden(.qwen35, phone8), .high)
        let pad16 = DeviceCapacity(memoryBytes: 16_000_000_000, freeDiskBytes: 30_000_000_000, processorCount: 10, isPad: true)
        XCTAssertEqual(burden(.e4b, pad16), .low)
        XCTAssertEqual(burden(.gemma12B, pad16), .moderate)
        // Suitability still accounts for the actual available-memory limit.
        let e2 = ModelRecommendation.fit(.e2b, device: loaded)
        XCTAssertTrue(e2.memoryIsTight)
        XCTAssertGreaterThan(e2.estimatedMemoryBytes, e2.deviceMemoryBudgetBytes)
        XCTAssertEqual(DeviceBurden.allCases.map(\.label), ["小さい", "普通", "大きい"])
        XCTAssertEqual(DeviceBurden.title(isPad: false), "iPhoneへの負担")
        XCTAssertEqual(DeviceBurden.title(isPad: true), "iPadへの負担")
    }
}

final class DeveloperModelTests: XCTestCase {
    /// From 1.1.0 (204) Qwen2.5 and the test version 12B are listed for
    /// everyone; Qwen3 only with developer settings, and the automatic
    /// choice picks Gemma E4B or E2B without them.
    func testQwen3NeedsDeveloperSettingsAndTheChoiceWithoutThemIsGemma() {
        XCTAssertEqual(ModelSpec.visibleCatalog(developer: false).map(\.id),
                       [ModelSpec.e4b.id, ModelSpec.e2b.id, ModelSpec.gemma12B.id, ModelSpec.phi4MiniReasoning.id,
                        ModelSpec.qwen35.id, ModelSpec.qwen25.id, ModelSpec.lfm3.id])
        XCTAssertEqual(ModelSpec.visibleCatalog(developer: true).count, ModelSpec.catalog.count)
        let small = DeviceCapacity(memoryBytes: 4_000_000_000, freeDiskBytes: 20_000_000_000, processorCount: 6, isPad: false)
        XCTAssertEqual(ModelRecommendation.recommended(for: small)?.id, ModelSpec.qwen3.id)
        let gemmaOnly = ModelRecommendation.recommended(for: small, includeDeveloperModels: false)
        XCTAssertNotNil(gemmaOnly)
        XCTAssertFalse(gemmaOnly!.isDeveloperOnly)
        XCTAssertTrue(gemmaOnly!.isStarter)
    }
}
