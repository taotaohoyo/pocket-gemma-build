import XCTest
@testable import PocketCore

final class ModelGaugeTests: XCTestCase {
    func testRelativeGaugesDoNotSaturateWhenAppAlreadyHoldsAModel() {
        let empty = DeviceCapacity(memoryBytes: 12_000_000_000, freeDiskBytes: 30_000_000_000,
            processorCount: 6, isPad: false, availableMemoryBytes: 6_000_000_000)
        let loaded = DeviceCapacity(memoryBytes: empty.memoryBytes, freeDiskBytes: empty.freeDiskBytes,
            processorCount: 6, isPad: false, availableMemoryBytes: 1_000_000_000)
        let e2 = ModelRecommendation.fit(.e2b, device: loaded)
        let e4 = ModelRecommendation.fit(.e4b, device: loaded)
        // E4B is the largest catalog model and the 100% reference.
        XCTAssertLessThan(e2.load, e4.load)
        XCTAssertEqual(e4.load, 1)
        XCTAssertLessThan(e2.load, 0.8)
        XCTAssertEqual(e2.load, ModelRecommendation.fit(.e2b, device: empty).load)
        XCTAssertEqual(e2.responsiveness, ModelRecommendation.fit(.e2b, device: empty).responsiveness)
        // Suitability still accounts for the actual available-memory limit.
        XCTAssertTrue(e2.memoryIsTight)
        XCTAssertGreaterThan(e2.estimatedMemoryBytes, e2.deviceMemoryBudgetBytes)
        XCTAssertEqual(ModelRecommendation.fit(.qwen3, device: empty).responsiveness, 1)
    }
}
