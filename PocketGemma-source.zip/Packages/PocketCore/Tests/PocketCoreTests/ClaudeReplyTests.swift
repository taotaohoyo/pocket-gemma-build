import XCTest
@testable import PocketCore

/// Claude in the app as in Fielua for the web (1.1.0 (260)): the reply's
/// searches, citations, files and container as the relay passes them on,
/// what one request carries of photos and files, and the credit's estimate.
final class ClaudeReplyTests: XCTestCase {
    private func event(_ json: String) -> ClaudeStreamEvent? { ClaudeStreamEvent(line: "data: " + json) }

    func testStreamReadsSearchesCitationsFilesAndTheContainer() {
        XCTAssertEqual(event(#"{"type":"message_start","message":{"model":"claude-opus-5-5","container":{"id":"container_011abc","expires_at":"2026-12-01T00:00:00Z"}}}"#),
                       .started(model: "claude-opus-5-5", container: "container_011abc"))
        XCTAssertEqual(event(#"{"type":"content_block_start","index":2,"content_block":{"type":"server_tool_use","id":"srvtoolu_1","name":"web_search","input":{}}}"#),
                       .toolStart(index: 2, name: "web_search"))
        XCTAssertEqual(event(#"{"type":"content_block_delta","index":2,"delta":{"type":"input_json_delta","partial_json":"{\"query\":\"東京\"}"}}"#),
                       .toolInput(index: 2, json: #"{"query":"東京"}"#))
        XCTAssertEqual(event(#"{"type":"content_block_stop","index":2}"#), .blockStop(index: 2))
        // Only http(s) pages, their titles trimmed and "www." left off the site.
        XCTAssertEqual(event(#"{"type":"content_block_start","index":3,"content_block":{"type":"web_search_tool_result","tool_use_id":"srvtoolu_1","content":[{"type":"web_search_result","url":"https://www.example.com/a","title":" 例 ","encrypted_content":"x"},{"type":"web_search_result","url":"javascript:alert(1)","title":"bad"}]}}"#),
                       .searchResults([WebSearchSource(title: "例", url: "https://www.example.com/a", site: "example.com")]))
        XCTAssertEqual(event(#"{"type":"content_block_start","index":3,"content_block":{"type":"web_search_tool_result","tool_use_id":"x","content":{"type":"web_search_tool_result_error","error_code":"too_many_requests"}}}"#),
                       .searchFailed("too_many_requests"))
        XCTAssertEqual(event(#"{"type":"content_block_delta","index":4,"delta":{"type":"citations_delta","citation":{"type":"web_search_result_location","url":"https://example.com/b","title":"B","cited_text":"…"}}}"#),
                       .cited(WebSearchSource(title: "B", url: "https://example.com/b", site: "example.com")))
        // The file ids however deep, and none that isn't an id.
        XCTAssertEqual(event(#"{"type":"content_block_start","index":5,"content_block":{"type":"bash_code_execution_tool_result","tool_use_id":"x","content":{"type":"bash_code_execution_result","stdout":"","content":[{"type":"bash_code_execution_output","file_id":"file_011abc"},{"file_id":"../etc"}]}}}"#),
                       .files(["file_011abc"]))
        XCTAssertEqual(event(#"{"type":"message_delta","delta":{"stop_reason":"pause_turn","container":{"id":"container_011abc"}}}"#),
                       .paused(container: "container_011abc"))
        XCTAssertEqual(event(#"{"type":"message_delta","delta":{"stop_reason":"end_turn","container":{"id":"container_011abc"}}}"#),
                       .container("container_011abc"))
        XCTAssertEqual(event(#"{"type":"content_block_start","index":1,"content_block":{"type":"text","text":"始め"}}"#), .textStart("始め"))
    }

    func testReaderPutsTheTextAfterASearchInAParagraphOfItsOwn() {
        let a = WebSearchSource(title: "A", url: "https://a.example/1", site: "a.example")
        let b = WebSearchSource(title: "B", url: "https://b.example/2", site: "b.example")
        var reader = ClaudeReplyReader()
        var text = ""
        let events: [ClaudeStreamEvent] = [
            .started(model: "claude-opus-5-5"), .textStart(""), .text("調べます。"),
            .toolStart(index: 1, name: "web_search"), .toolInput(index: 1, json: #"{"query":"#),
            .toolInput(index: 1, json: #""東京 天気"}"#), .blockStop(index: 1), .searchResults([a, b]),
            .textStart(""), .text("晴れです。"), .cited(b), .textStart(""), .text("以上。"),
            .files(["file_0123456789"]), .paused(container: "container_abc123"),
        ]
        for event in events {
            if case .blockStop = event { XCTAssertEqual(reader.activity, .searching("")) }
            if let added = reader.read(event) { text += added }
        }
        XCTAssertEqual(text, "調べます。\n\n晴れです。以上。")
        XCTAssertNil(reader.activity)
        XCTAssertEqual(reader.queries, ["東京 天気"])
        XCTAssertEqual(reader.files, ["file_0123456789"])
        XCTAssertEqual(reader.container, "container_abc123")
        XCTAssertEqual(reader.end, .paused)
        XCTAssertEqual(reader.servedModel, "claude-opus-5-5")
        let record = reader.search(generating: false)
        XCTAssertEqual(record?.queries, ["東京 天気"])
        XCTAssertEqual(record?.sources, [b], "the pages it cited come first, alone")
        XCTAssertNil(record?.failedQueries)
    }

    func testReaderSaysWhatItSearchesAndWhenTheSearchFailed() {
        var reader = ClaudeReplyReader()
        _ = reader.read(.toolStart(index: 0, name: "web_search"))
        _ = reader.read(.toolInput(index: 0, json: #"{"query":"ニュース"}"#))
        _ = reader.read(.blockStop(index: 0))
        XCTAssertEqual(reader.activity, .searching("ニュース"))
        XCTAssertEqual(reader.search(generating: true)?.inProgress, "ニュース")
        _ = reader.read(.searchFailed("too_many_requests"))
        let record = reader.search(generating: false)
        XCTAssertNil(record?.inProgress)
        XCTAssertEqual(record?.failedQueries, ["ニュース"])
        XCTAssertEqual(record?.failure, .unavailable, "never in Tavily's words")
        XCTAssertNil(ClaudeReplyReader().search(generating: false), "no search, no record")
        var coding = ClaudeReplyReader()
        _ = coding.read(.toolStart(index: 3, name: "bash_code_execution"))
        XCTAssertEqual(coding.activity, .runningCode)
        _ = coding.read(.toolStart(index: 4, name: "text_editor_code_execution"))
        XCTAssertEqual(coding.activity, .writingFile)
        XCTAssertEqual(coding.read(.textStart("")), nil, "no text yet: nothing to set apart")
        XCTAssertEqual(coding.read(.cutOff), nil)
        XCTAssertEqual(coding.end, .cutOff)
    }

    func testOneRequestCarriesWhatTheRelayTakes() {
        var budget = ClaudeAttachmentBudget(bytes: 3_000)
        XCTAssertEqual(budget.chars, 4_000)
        let photo = ClaudeAttachmentPart(image: String(repeating: "A", count: 3_000), mediaType: "image/jpeg", name: "a.jpg")
        XCTAssertTrue(budget.take([photo], alreadyInTurn: 0))
        XCTAssertEqual(budget.remainingChars, 1_000)
        let pdf = ClaudeAttachmentPart(pdf: String(repeating: "B", count: 2_000), name: "b.pdf")
        XCTAssertFalse(budget.take([pdf], alreadyInTurn: 1))
        XCTAssertEqual(budget.remainingChars, 1_000, "nothing taken when it doesn't fit")
        let note = ClaudeAttachmentPart(text: "メモ", name: "c.txt")
        XCTAssertTrue(budget.take([note], alreadyInTurn: 1), "text counts apart from the base64")
        XCTAssertFalse(budget.take([note], alreadyInTurn: ClaudeAttachmentBudget.maxPartsPerTurn))
        let long = ClaudeAttachmentPart(text: String(repeating: "x", count: ClaudeAttachmentBudget.maxTextFileBytes + 1), name: "d.txt")
        XCTAssertFalse(budget.take([long], alreadyInTurn: 0))
        XCTAssertEqual(photo.json["type"] as? String, "image")
        XCTAssertEqual(photo.json["mediaType"] as? String, "image/jpeg")
        XCTAssertNil(photo.json["text"])
        XCTAssertEqual(note.json["text"] as? String, "メモ")
        XCTAssertNil(note.json["data"])
    }

    func testTurnsCarryTheirPhotosAndFiles() {
        func exchange(_ question: String, _ answer: String, state: ReplyState = .complete,
                      attachments: [ChatAttachment] = []) -> [ChatMessage] {
            [ChatMessage(role: .user, text: question, attachments: attachments),
             ChatMessage(role: .assistant, text: answer, state: state)]
        }
        let photo = ChatAttachment(kind: .image, name: "写真.jpg", storedName: "p.jpg")
        let pdf = ChatAttachment(kind: .file, name: "a.pdf", storedName: "a.pdf")
        let history = exchange("一", "いち") + exchange("この写真", "見えます", attachments: [photo])
            + exchange("二", "失敗", state: .failed, attachments: [pdf]) + exchange(" ", "空")
        let turns = ClaudeContext.turns(history: history, question: "三", attachments: [pdf])
        XCTAssertEqual(turns.map(\.role), ["user", "assistant", "user", "assistant", "user"])
        XCTAssertEqual(turns.map(\.content), ["一", "いち", "この写真", "見えます", "三"])
        XCTAssertEqual(turns[2].attachments, [photo])
        XCTAssertEqual(turns.last?.attachments, [pdf])
        XCTAssertTrue(ClaudeContext.sends(photo))
        XCTAssertTrue(ClaudeContext.sends(pdf))
        XCTAssertFalse(ClaudeContext.sends(ChatAttachment(kind: .video, name: "v.mov", storedName: "v.mov")))
        XCTAssertFalse(ClaudeContext.sends(ChatAttachment(kind: .audio, name: "声.m4a", storedName: "s.m4a")))
        XCTAssertTrue(ClaudeContext.notSentNote(["a.pdf", "b.png"]).contains("「a.pdf」「b.png」"))
    }

    func testCreditFromTheRelaysStatus() throws {
        let status: [String: Any] = ["percent": 12.5, "remainingUSD": 3.1, "budgetUSD": 25, "spentUSD": 21.9,
                                     "setAt": 1_762_000_000_000.0, "friends": true]
        let credit = try XCTUnwrap(ClaudeCredit(status))
        XCTAssertTrue(credit.isLow)
        XCTAssertTrue(credit.friends)
        XCTAssertEqual(credit.setAt.timeIntervalSince1970, 1_762_000_000, accuracy: 0.001)
        XCTAssertNil(ClaudeCredit(nil))
        XCTAssertNil(ClaudeCredit(NSNull()))
        XCTAssertNil(ClaudeCredit(["percent": 50] as [String: Any]))
        var over = status
        over["percent"] = 140
        XCTAssertEqual(ClaudeCredit(over)?.percent, 100)
        XCTAssertFalse(ClaudeCredit(over)?.isLow ?? true)
        XCTAssertEqual(ClaudeCredit.dollars(12.3), "$12.30")
        XCTAssertEqual(ClaudeCredit.dollars(0.049), "$0.05")
        XCTAssertEqual(ClaudeCredit.dollars(150.4), "$150")
    }

    func testFilesAndContainersAsTheAppKeepsThem() throws {
        let now = Date()
        let sheet = ClaudeMadeFile(id: "file_0123456789", name: "表.xlsx", madeAt: now)
        XCTAssertEqual(sheet.kind, "Excel")
        XCTAssertFalse(sheet.expired(now: now.addingTimeInterval(28 * 86_400)))
        XCTAssertTrue(sheet.expired(now: now.addingTimeInterval(30 * 86_400)))
        XCTAssertTrue(ClaudeMadeFile(id: "file_1234567", name: "a.png", mimeType: "image/png", size: 1_000).isPicture)
        XCTAssertFalse(ClaudeMadeFile(id: "file_1234567", name: "a.png", mimeType: "image/png", size: 9_000_000).isPicture)
        XCTAssertTrue(ClaudeContainer(id: "container_abc123", madeAt: now).live(now: now.addingTimeInterval(28 * 86_400)))
        XCTAssertFalse(ClaudeContainer(id: "container_abc123", madeAt: now).live(now: now.addingTimeInterval(29 * 86_400 + 1)))
        // Kept with the reply and the chat; older archives have neither.
        var message = ChatMessage(role: .assistant, text: "作りました")
        message.claudeFiles = [ClaudeMadeFile(id: "file_0123456789", name: "a.pdf", mimeType: "application/pdf", size: 10)]
        message.claudeEnd = .paused
        let back = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(message))
        XCTAssertEqual(back.claudeFiles?.first?.name, "a.pdf")
        XCTAssertEqual(back.claudeEnd, .paused)
        var thread = ChatThread(modelID: "gemma-4-e4b")
        thread.makesFiles = true
        thread.claudeContainer = ClaudeContainer(id: "container_abc123")
        let again = try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(thread))
        XCTAssertEqual(again.makesFiles, true)
        XCTAssertEqual(again.claudeContainer?.id, "container_abc123")
        let older = try JSONDecoder().decode(ChatMessage.self, from: JSONEncoder().encode(ChatMessage(role: .assistant, text: "前")))
        XCTAssertNil(older.claudeFiles)
        XCTAssertNil(older.claudeEnd)
    }

    func testReplyKeysAreWhatTheRelayTakes() {
        let key = ClaudeReplyKey.make()
        XCTAssertTrue(ClaudeReplyKey.isValid(key))
        XCTAssertNotEqual(key, ClaudeReplyKey.make())
        XCTAssertFalse(ClaudeReplyKey.isValid("abc"))
        XCTAssertFalse(ClaudeReplyKey.isValid(String(repeating: "A", count: 32)))
        XCTAssertFalse(ClaudeReplyKey.isValid(String(repeating: "g", count: 32)))
        XCTAssertTrue(ClaudeStreamEvent.isOutputID("file_011abc"))
        XCTAssertFalse(ClaudeStreamEvent.isOutputID("../etc/passwd"))
        XCTAssertFalse(ClaudeStreamEvent.isOutputID("abc"))
    }
}
