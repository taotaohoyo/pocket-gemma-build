import XCTest
@testable import PocketCore

final class WatchHistoryTests: XCTestCase {
    private func chat(_ model: ModelSpec, turns: Int, updated: Date = Date(), answer: String = "答えです。") -> ChatThread {
        var thread = ChatThread(modelID: model.id)
        for index in 0..<turns {
            thread.messages.append(ChatMessage(role: .user, text: "質問\(index)"))
            thread.messages.append(ChatMessage(role: .assistant, text: "\(answer)\(index)"))
        }
        thread.updatedAt = updated
        return thread
    }

    func testANewChatCanTakeTheIdTheWatchGaveIt() {
        let id = UUID()
        XCTAssertEqual(ChatThread(id: id, modelID: ModelSpec.e2b.id).id, id)
        XCTAssertNotEqual(ChatThread().id, ChatThread().id)
    }

    func testListHasEveryModelsChatsLatestFirstAndLeavesEmptyOnesOut() {
        let now = Date()
        let e4b = chat(.e4b, turns: 2, updated: now.addingTimeInterval(-60))
        let e2b = chat(.e2b, turns: 1, updated: now)
        let qwen = chat(.qwen3, turns: 1, updated: now.addingTimeInterval(-120))
        var old = chat(.e4b, turns: 1, updated: now.addingTimeInterval(-180))
        old.modelID = nil
        let empty = ChatThread(modelID: ModelSpec.e2b.id)
        let list = WatchHistory.list([qwen, empty, e4b, old, e2b])
        XCTAssertEqual(list.chats.map(\.id), [e2b, e4b, qwen, old].map(\.id.uuidString))
        XCTAssertEqual(list.chats.map(\.model), ["E2B", "E4B", "Qwen3 0.6B", "E4B"])
        XCTAssertEqual(list.chats.map(\.watchModel), [true, false, false, false])
        XCTAssertEqual(list.chats[1].count, 4)
        XCTAssertEqual(list.chats[1].title, "質問0")
    }

    func testListKeepsTheLatestFortyAndFitsAContext() {
        let now = Date()
        let threads = (0..<120).map { chat(.e4b, turns: 1, updated: now.addingTimeInterval(TimeInterval(-$0)),
                                          answer: String(repeating: "長", count: 40)) }
        let list = WatchHistory.list(threads)
        XCTAssertEqual(list.chats.count, WatchHistory.listLimit)
        XCTAssertEqual(list.chats.first?.id, threads[0].id.uuidString)
        XCTAssertEqual(list.chats.last?.id, threads[WatchHistory.listLimit - 1].id.uuidString)
        // Titles are a chat's first question, up to 28 characters.
        var long = chat(.e2b, turns: 1, updated: now.addingTimeInterval(10))
        long.messages[0].text = String(repeating: "あ", count: 200)
        let size = WatchHistory.encode(WatchHistory.list([long] + threads))?.count ?? .max
        XCTAssertLessThan(size, 20_000, "The list rides in the application context beside a reply")
    }

    func testFormerConversationGoesWithTheList() {
        let thread = chat(.e2b, turns: 1)
        let list = WatchHistory.list([thread], former: ("watch-conversation", thread.id))
        XCTAssertEqual(list.formerConversation, "watch-conversation")
        XCTAssertEqual(list.formerChat, thread.id.uuidString)
        XCTAssertEqual(WatchHistory.decode(WatchHistory.List.self, from: WatchHistory.encode(list)), list)
    }

    func testPageCarriesTheLatestMessagesStartingOnAQuestion() {
        let thread = chat(.e4b, turns: 100, answer: String(repeating: "説明", count: 400))
        let page = WatchHistory.page(thread)
        XCTAssertFalse(page.messages.isEmpty)
        XCTAssertTrue(page.messages.first?.fromUser == true)
        XCTAssertEqual(page.messages.last?.id, thread.messages.last?.id.uuidString)
        XCTAssertEqual(page.earlier + page.messages.count, thread.messages.count)
        XCTAssertGreaterThan(page.earlier, 0)
        XCTAssertLessThanOrEqual(page.messages.count, WatchHistory.pageMessages)
        XCTAssertEqual(page.model, "E4B")
        XCTAssertFalse(page.watchModel)
        let size = WatchHistory.encode(page)?.count ?? .max
        XCTAssertLessThan(size, 60_000, "A page goes in one WatchConnectivity message")
    }

    func testPageNeverChangesTheChat() {
        var thread = chat(.qwen3, turns: 3)
        thread.messages[1].state = .stopped
        let before = thread
        _ = WatchHistory.page(thread, paused: [thread.messages[1].id])
        _ = WatchHistory.list([thread])
        XCTAssertEqual(thread, before)
        XCTAssertEqual(thread.modelID, ModelSpec.qwen3.id)
    }

    func testLongMessageIsClippedOnACharacterAndSaysSo() {
        var thread = chat(.e2b, turns: 1)
        thread.messages[1].text = String(repeating: "日本語🙂", count: 3_000)
        let page = WatchHistory.page(thread)
        let answer = page.messages[1]
        XCTAssertTrue(answer.clipped)
        XCTAssertLessThanOrEqual(answer.text.utf8.count, WatchHistory.messageLimit)
        XCTAssertTrue(thread.messages[1].text.hasPrefix(answer.text))
        XCTAssertFalse(page.messages[0].clipped)
        let short = WatchHistory.clip("あいう", bytes: 7)
        XCTAssertEqual(short.text, "あい")
        XCTAssertTrue(short.clipped)
        XCTAssertEqual(WatchHistory.clip("あいう", bytes: 9).text, "あいう")
        XCTAssertFalse(WatchHistory.clip("あいう", bytes: 9).clipped)
    }

    func testStatesAndAttachmentsAsTheWatchShowsThem() {
        var thread = ChatThread(modelID: ModelSpec.e4b.id)
        let photo = ChatAttachment(kind: .image, name: "p.jpg", storedName: "p.jpg", imageNames: ["n.jpg"])
        thread.messages = [
            ChatMessage(role: .user, text: "これは何？", attachments: [photo]),
            ChatMessage(role: .assistant, text: "花です"),
            ChatMessage(role: .user, text: "続けて"),
            ChatMessage(role: .assistant, text: "途中", state: .stopped),
            ChatMessage(role: .user, text: "もう一つ"),
            ChatMessage(role: .assistant, text: "途中まで", state: .stopped),
            ChatMessage(role: .user, text: "失敗"),
            ChatMessage(role: .assistant, text: "", state: .failed),
            ChatMessage(role: .user, text: "今"),
            ChatMessage(role: .assistant, text: "", state: .generating),
        ]
        let page = WatchHistory.page(thread, paused: [thread.messages[5].id])
        XCTAssertEqual(page.messages.map(\.state),
                       ["finished", "finished", "finished", "stopped", "finished", "paused", "finished", "failed",
                        "finished", "waiting"])
        XCTAssertEqual(page.messages[0].attachments, 1)
        let turns = WatchHistory.turns(page.messages)
        XCTAssertEqual(turns.map(\.id), [0, 2, 4, 6, 8].map { thread.messages[$0].id.uuidString })
        XCTAssertEqual(turns.map(\.state), ["finished", "stopped", "paused", "failed", "waiting"])
        XCTAssertEqual(turns[0].attachments, 1)
        XCTAssertEqual(turns[0].answer, "花です")
    }

    func testTurnsKeepAQuestionWithoutAnswerAndAnAnswerAlone() {
        let messages = [
            WatchHistory.Message(id: "a", fromUser: false, text: "前の答え", state: "finished"),
            WatchHistory.Message(id: "q1", fromUser: true, text: "質問1", state: "finished"),
            WatchHistory.Message(id: "q2", fromUser: true, text: "質問2", state: "finished"),
            WatchHistory.Message(id: "r2", fromUser: false, text: "答え2", state: "finished"),
        ]
        let turns = WatchHistory.turns(messages)
        XCTAssertEqual(turns.map(\.id), ["a", "q1", "q2"])
        XCTAssertEqual(turns.map(\.question), ["", "質問1", "質問2"])
        XCTAssertEqual(turns.map(\.answer), ["前の答え", "", "答え2"])
        XCTAssertEqual(turns[1].state, "stopped")
    }

    func testCacheKeepsTheLatestPagesAndDropsDeletedChats() {
        let now = Date()
        let threads = (0..<10).map { chat(.e2b, turns: 1, updated: now.addingTimeInterval(TimeInterval(-$0))) }
        var cache = WatchHistory.Cache()
        cache.apply(WatchHistory.list(threads))
        for thread in threads.reversed() { cache.store(WatchHistory.page(thread)) }
        XCTAssertEqual(cache.pages.count, WatchHistory.Cache.pagesKept)
        XCTAssertEqual(cache.pages.first?.chat, threads[0].id.uuidString, "The latest stored comes first")
        XCTAssertNil(cache.page(threads[9].id.uuidString))
        // Deleted on the iPhone: gone from the list, and its page goes.
        let gone = cache.apply(WatchHistory.list(Array(threads.dropFirst())))
        XCTAssertEqual(gone, [threads[0].id.uuidString])
        XCTAssertNil(cache.page(threads[0].id.uuidString))
        XCTAssertNotNil(cache.page(threads[1].id.uuidString))
        XCTAssertEqual(WatchHistory.decode(WatchHistory.Cache.self, from: WatchHistory.encode(cache)), cache)
    }

    func testAChatPushedOffAFullListIsNotTakenForDeleted() {
        let now = Date()
        let threads = (0..<WatchHistory.listLimit).map { chat(.e4b, turns: 1, updated: now.addingTimeInterval(TimeInterval(-$0 - 10))) }
        var cache = WatchHistory.Cache()
        cache.apply(WatchHistory.list(threads))
        let oldest = threads.last!
        cache.store(WatchHistory.page(oldest))
        let newer = chat(.e2b, turns: 1, updated: now)
        let gone = cache.apply(WatchHistory.list(threads + [newer]))
        XCTAssertTrue(gone.isEmpty)
        XCTAssertNotNil(cache.page(oldest.id.uuidString))
    }

    func testCacheAsksAgainWhenTheListSaysTheChatChanged() {
        var thread = chat(.e4b, turns: 1, updated: Date(timeIntervalSince1970: 1_000))
        var cache = WatchHistory.Cache()
        XCTAssertTrue(cache.needsPage(thread.id.uuidString))
        cache.apply(WatchHistory.list([thread]))
        cache.store(WatchHistory.page(thread))
        XCTAssertFalse(cache.needsPage(thread.id.uuidString))
        thread.messages.append(ChatMessage(role: .user, text: "続き"))
        thread.messages.append(ChatMessage(role: .assistant, text: "はい"))
        thread.updatedAt = Date(timeIntervalSince1970: 2_000)
        cache.apply(WatchHistory.list([thread]))
        XCTAssertTrue(cache.needsPage(thread.id.uuidString))
        cache.store(WatchHistory.page(thread))
        XCTAssertFalse(cache.needsPage(thread.id.uuidString))
        XCTAssertEqual(cache.page(thread.id.uuidString)?.messages.count, 4)
    }
}
