import XCTest
@testable import PocketCore

final class SyntaxHighlighterTests: XCTestCase {
    private func has(_ tokens: [CodeToken], _ kind: CodeTokenKind, _ text: String,
                     file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertTrue(tokens.contains(CodeToken(kind: kind, text: text)),
                      "\(kind) \(text.debugDescription) missing in \(tokens)", file: file, line: line)
    }

    static let samples: [(String, String)] = [
        ("swift", "import SwiftUI\n@MainActor struct A: View {\n  let name = \"Pocket \\(1)\" // 名前\n  func run() async throws -> Int { #if DEBUG\n return 0x1F + 2.5e-3 }\n}\n\"\"\"\nmulti\n\"\"\""),
        ("python", "@dataclass\ndef f(x: int) -> str:\n    \"\"\"doc\n    more\"\"\"\n    return f'{x}'  # done"),
        ("js", "const a = `t ${b}`; // c\nfunction g($el) { return /x/.test(a) }"),
        ("ts", "interface P { name: string }\nexport type Q = P | null"),
        ("json", "{\"name\": \"a\", \"n\": -1.5, \"ok\": true, \"list\": [null]}"),
        ("yaml", "name: pocket\nitems:\n  - 1\n  - \"two\" # c"),
        ("bash", "#!/bin/bash\necho \"$HOME\" ${USER} | grep -v x # c"),
        ("sql", "SELECT id, name FROM users WHERE age > 20 -- adults\n/* block */"),
        ("html", "<!doctype html>\n<a href=\"x\" data-id='1'>t &amp; u</a><!-- c --><br/>"),
        ("css", "@media (max-width: 600px) { .a { color: #fff; margin: 0 4px } }"),
        ("rust", "fn main() { let s: &str = \"x\"; println!(\"{}\", s); }"),
        ("go", "package main\nfunc main() { s := `raw\nline`; fmt.Println(s) }"),
        ("c", "#include <stdio.h>\nint main(void) { printf(\"%d\\n\", 1); /* c */ }"),
        ("diff", "--- a\n+++ b\n@@ -1 +1 @@\n-old\n+new\n same"),
        ("markdown", "# 見出し\n> 引用\n本文"),
        ("lua", "--[[ block ]] local x = 1 -- c"),
        ("unknown", "a + b"),
        ("swift", "\"unterminated\n😊 é 日本語"),
    ]

    func testTokensJoinBackIntoTheCodeExactly() {
        for (language, code) in Self.samples {
            let tokens = SyntaxHighlighter.tokens(code, language: language)
            XCTAssertEqual(tokens.map(\.text).joined(), code, language)
            XCTAssertFalse(tokens.contains { $0.text.isEmpty }, language)
        }
    }

    func testSwift() {
        let tokens = SyntaxHighlighter.tokens("let name = \"Pocket\" // greeting\nfunc run() -> Int { return 42 }\n@MainActor", language: "swift")
        has(tokens, .keyword, "let")
        has(tokens, .string, "\"Pocket\"")
        has(tokens, .comment, "// greeting")
        has(tokens, .keyword, "func")
        has(tokens, .function, "run")
        has(tokens, .type, "Int")
        has(tokens, .number, "42")
        has(tokens, .attribute, "@MainActor")
    }

    func testPythonMultilineStringsAndComments() {
        let tokens = SyntaxHighlighter.tokens("def f(x):\n    \"\"\"doc\n    more\"\"\"\n    return x  # done", language: "py")
        has(tokens, .keyword, "def")
        has(tokens, .function, "f")
        has(tokens, .string, "\"\"\"doc\n    more\"\"\"")
        has(tokens, .comment, "# done")
    }

    func testJSONKeysAndValues() {
        let tokens = SyntaxHighlighter.tokens("{\"name\": \"a\", \"n\": 1, \"ok\": true}", language: "json")
        has(tokens, .property, "\"name\"")
        has(tokens, .string, "\"a\"")
        has(tokens, .number, "1")
        has(tokens, .keyword, "true")
    }

    func testShellVariablesAndComments() {
        let tokens = SyntaxHighlighter.tokens("echo $HOME ${USER} # c", language: "sh")
        has(tokens, .keyword, "echo")
        has(tokens, .property, "$HOME")
        has(tokens, .property, "${USER}")
        has(tokens, .comment, "# c")
    }

    func testSQLKeywordsIgnoreCase() {
        let tokens = SyntaxHighlighter.tokens("SELECT name from t -- c", language: "sql")
        has(tokens, .keyword, "SELECT")
        has(tokens, .keyword, "from")
        has(tokens, .comment, "-- c")
    }

    func testMarkupTagsAttributesAndComments() {
        let tokens = SyntaxHighlighter.tokens("<a href=\"x\">t</a><!-- c -->", language: "html")
        has(tokens, .tag, "<a")
        has(tokens, .attribute, "href")
        has(tokens, .string, "\"x\"")
        has(tokens, .comment, "<!-- c -->")
    }

    func testDiffLines() {
        let tokens = SyntaxHighlighter.tokens("+added\n-removed\n context", language: "diff")
        XCTAssertEqual(tokens, [CodeToken(kind: .inserted, text: "+added\n"), CodeToken(kind: .deleted, text: "-removed\n"),
                                CodeToken(kind: .plain, text: " context")])
    }

    func testUnknownOrMissingLanguageStaysPlain() {
        XCTAssertEqual(SyntaxHighlighter.tokens("a + b", language: "brainfuck"), [CodeToken(kind: .plain, text: "a + b")])
        XCTAssertEqual(SyntaxHighlighter.tokens("a + b", language: nil), [CodeToken(kind: .plain, text: "a + b")])
        XCTAssertEqual(SyntaxHighlighter.tokens("", language: "swift"), [])
    }

    func testDisplayNames() {
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "py"), "Python")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "JS"), "JavaScript")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "c++"), "C++")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "zsh"), "Shell")
        XCTAssertNil(SyntaxHighlighter.displayName(for: nil))
        XCTAssertNil(SyntaxHighlighter.displayName(for: "nonsense"))
    }

    func testLargeCodeStaysQuickAndHugeCodeStaysPlain() {
        let line = "let value = compute(\"text\", 42) // comment\n"
        let code = String(repeating: line, count: 3_000)
        let start = Date()
        let tokens = SyntaxHighlighter.tokens(code, language: "swift")
        XCTAssertLessThan(Date().timeIntervalSince(start), 2)
        XCTAssertEqual(tokens.map(\.text).joined(), code)
        let huge = String(repeating: line, count: 6_000)
        XCTAssertEqual(SyntaxHighlighter.tokens(huge, language: "swift").count, 1)
    }
}
