import XCTest
@testable import PocketCore

final class SyntaxHighlighterTests: XCTestCase {
    private func has(_ tokens: [CodeToken], _ kind: CodeTokenKind, _ text: String,
                     file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertTrue(tokens.contains(CodeToken(kind: kind, text: text)),
                      "\(kind) \(text.debugDescription) missing in \(tokens)", file: file, line: line)
    }

    static let samples: [(String, String)] = [
        ("swift", "import SwiftUI\n@MainActor struct A: View {\n  let name = \"Pocket \\(1)\" // 名前\n  func run() async throws -> Int { #if DEBUG\n return 0x1F + 2.5e-3 }\n}\n\"\"\"\nmulti\n\"\"\""),
        ("python", "@dataclass\ndef f(x: int) -> str:\n    \"\"\"doc\n    more\"\"\"\n    return f'{x}'  # done"),
        ("js", "const a = `t ${b}`; // c\nfunction g($el) { return /x/.test(a) }"),
        ("ts", "interface P { name: string }\nexport type Q = P | null"),
        ("json", "{\"name\": \"a\", \"n\": -1.5, \"ok\": true, \"list\": [null]}"),
        ("yaml", "name: pocket\nitems:\n  - 1\n  - \"two\" # c"),
        ("bash", "#!/bin/bash\necho \"$HOME\" ${USER} | grep -v x # c"),
        ("sql", "SELECT id, name FROM users WHERE age > 20 -- adults\n/* block */"),
        ("html", "<!doctype html>\n<a href=\"x\" data-id='1'>t &amp; u</a><!-- c --><br/>"),
        ("css", "@media (max-width: 600px) { .a { color: #fff; margin: 0 4px } }"),
        ("rust", "fn main() { let s: &str = \"x\"; println!(\"{}\", s); }"),
        ("go", "package main\nfunc main() { s := `raw\nline`; fmt.Println(s) }"),
        ("c", "#include <stdio.h>\nint main(void) { printf(\"%d\\n\", 1); /* c */ }"),
        ("diff", "--- a\n+++ b\n@@ -1 +1 @@\n-old\n+new\n same"),
        ("markdown", "# 見出し\n> 引用\n本文"),
        ("lua", "--[[ block ]] local x = 1 -- c"),
        ("unknown", "a + b"),
        ("swift", "\"unterminated\n😊 é 日本語"),
    ]

    func testTokensJoinBackIntoTheCodeExactly() {
        for (language, code) in Self.samples {
            let tokens = SyntaxHighlighter.tokens(code, language: language)
            XCTAssertEqual(tokens.map(\.text).joined(), code, language)
            XCTAssertFalse(tokens.contains { $0.text.isEmpty }, language)
        }
    }

    func testSwift() {
        let tokens = SyntaxHighlighter.tokens("let name = \"Pocket\" // greeting\nfunc run() -> Int { return 42 }\n@MainActor", language: "swift")
        has(tokens, .keyword, "let")
        has(tokens, .string, "\"Pocket\"")
        has(tokens, .comment, "// greeting")
        has(tokens, .keyword, "func")
        has(tokens, .function, "run")
        has(tokens, .type, "Int")
        has(tokens, .number, "42")
        has(tokens, .attribute, "@MainActor")
    }

    func testPythonMultilineStringsAndComments() {
        let tokens = SyntaxHighlighter.tokens("def f(x):\n    \"\"\"doc\n    more\"\"\"\n    return x  # done", language: "py")
        has(tokens, .keyword, "def")
        has(tokens, .function, "f")
        has(tokens, .string, "\"\"\"doc\n    more\"\"\"")
        has(tokens, .comment, "# done")
    }

    func testJSONKeysAndValues() {
        let tokens = SyntaxHighlighter.tokens("{\"name\": \"a\", \"n\": 1, \"ok\": true}", language: "json")
        has(tokens, .property, "\"name\"")
        has(tokens, .string, "\"a\"")
        has(tokens, .number, "1")
        has(tokens, .keyword, "true")
    }

    func testShellVariablesAndComments() {
        let tokens = SyntaxHighlighter.tokens("echo $HOME ${USER} # c", language: "sh")
        has(tokens, .keyword, "echo")
        has(tokens, .property, "$HOME")
        has(tokens, .property, "${USER}")
        has(tokens, .comment, "# c")
    }

    func testSQLKeywordsIgnoreCase() {
        let tokens = SyntaxHighlighter.tokens("SELECT name from t -- c", language: "sql")
        has(tokens, .keyword, "SELECT")
        has(tokens, .keyword, "from")
        has(tokens, .comment, "-- c")
    }

    func testMarkupTagsAttributesAndComments() {
        let tokens = SyntaxHighlighter.tokens("<a href=\"x\">t</a><!-- c -->", language: "html")
        has(tokens, .tag, "<a")
        has(tokens, .attribute, "href")
        has(tokens, .string, "\"x\"")
        has(tokens, .comment, "<!-- c -->")
    }

    func testDiffLines() {
        let tokens = SyntaxHighlighter.tokens("+added\n-removed\n context", language: "diff")
        XCTAssertEqual(tokens, [CodeToken(kind: .inserted, text: "+added\n"), CodeToken(kind: .deleted, text: "-removed\n"),
                                CodeToken(kind: .plain, text: " context")])
    }

    func testUnknownOrMissingLanguageStaysPlain() {
        XCTAssertEqual(SyntaxHighlighter.tokens("a + b", language: "brainfuck"), [CodeToken(kind: .plain, text: "a + b")])
        XCTAssertEqual(SyntaxHighlighter.tokens("a + b", language: nil), [CodeToken(kind: .plain, text: "a + b")])
        XCTAssertEqual(SyntaxHighlighter.tokens("", language: "swift"), [])
    }

    func testDisplayNames() {
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "py"), "Python")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "JS"), "JavaScript")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "c++"), "C++")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "zsh"), "Shell")
        XCTAssertNil(SyntaxHighlighter.displayName(for: nil))
        XCTAssertNil(SyntaxHighlighter.displayName(for: "nonsense"))
    }

    func testHintsNameALanguageByTheirFirstWord() {
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "language-python"), "Python")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "{.python}"), "Python")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "python:main.py"), "Python")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "py title=x"), "Python")
        XCTAssertEqual(SyntaxHighlighter.tokens("def f():", language: "language-python").first, CodeToken(kind: .keyword, text: "def"))
        XCTAssertNil(SyntaxHighlighter.displayName(for: ""))
        XCTAssertNil(SyntaxHighlighter.displayName(for: "  "))
    }

    func testLanguagesWithoutColorsStillHaveNames() {
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "toml"), "TOML")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "Dockerfile"), "Dockerfile")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "makefile"), "Makefile")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "ps1"), "PowerShell")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "latex"), "LaTeX")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "text"), "テキスト")
        XCTAssertEqual(SyntaxHighlighter.displayName(for: "plaintext"), "テキスト")
        // Named, but drawn in one color.
        XCTAssertEqual(SyntaxHighlighter.tokens("a = 1", language: "toml"), [CodeToken(kind: .plain, text: "a = 1")])
    }

    func testFileExtensions() {
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "python"), "py")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "swift"), "swift")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "c++"), "cpp")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "zsh"), "sh")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "yaml"), "yml")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "toml"), "toml")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "dockerfile"), "Dockerfile")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: nil), "txt")
        XCTAssertEqual(SyntaxHighlighter.fileExtension(for: "nonsense"), "txt")
    }

    func testDetectsLanguagesFromUnmistakableSigns() {
        let cases: [(String, String)] = [
            ("#!/usr/bin/env python3\nprint('hi')", "python"),
            ("#!/bin/bash\necho hi", "bash"),
            ("{\"name\": \"a\", \"n\": 1}", "json"),
            ("[1, 2, 3]", "json"),
            ("<?xml version=\"1.0\"?>\n<a/>", "xml"),
            ("<!DOCTYPE html>\n<html></html>", "html"),
            ("diff --git a/x b/x\n--- a/x\n+++ b/x\n@@ -1 +1 @@\n-a\n+b", "diff"),
            ("SELECT name FROM users WHERE id = 1;", "sql"),
            ("import SwiftUI\n\nstruct A: View {}", "swift"),
            ("func add(a: Int, b: Int) -> Int {\n    a + b\n}", "swift"),
            ("package main\n\n// a -> b\nfunc main() {\n}", "go"),
            ("fn main() {\n    println!(\"hi\");\n}", "rust"),
            ("public class Main {\n  public static void main(String[] args) {}\n}", "java"),
            ("#include <stdio.h>\nint main() { return 0; }", "c"),
            ("#include <iostream>\nint main() { std::cout << 1; }", "cpp"),
            ("def greet(name):\n    return name", "python"),
            ("from math import pi\nprint(pi)", "python"),
            ("const add = (a, b) => a + b;", "javascript"),
            ("console.log(1)", "javascript"),
            ("npm install\nnpm run build", "bash"),
            ("$ git status", "bash"),
        ]
        for (code, language) in cases {
            XCTAssertEqual(SyntaxHighlighter.detectedLanguage(code), language, code)
            XCTAssertNotNil(SyntaxHighlighter.displayName(for: language), language)
        }
    }

    func testDetectionLeavesUncertainTextAlone() {
        for text in ["こんにちは。今日はいい天気です。", "a + b", "hello world", "Total: 100", "x = 1\ny = 2",
                     "[1] 参考文献", "{ 名前 }", "export default App;", "# 見出し\n# もう一つ", "", " ", "1"] {
            XCTAssertNil(SyntaxHighlighter.detectedLanguage(text), text)
        }
    }

    func testLargeCodeStaysQuickAndHugeCodeStaysPlain() {
        let line = "let value = compute(\"text\", 42) // comment\n"
        let code = String(repeating: line, count: 3_000)
        let start = Date()
        let tokens = SyntaxHighlighter.tokens(code, language: "swift")
        XCTAssertLessThan(Date().timeIntervalSince(start), 2)
        XCTAssertEqual(tokens.map(\.text).joined(), code)
        let huge = String(repeating: line, count: 6_000)
        XCTAssertEqual(SyntaxHighlighter.tokens(huge, language: "swift").count, 1)
    }
}
