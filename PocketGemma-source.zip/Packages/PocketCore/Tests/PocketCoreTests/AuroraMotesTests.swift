import XCTest
@testable import PocketCore

/// The light around the Aurora Orb while a reply is prepared (AuroraMotes,
/// 1.1.0 (298)): calm, inside its field, never popping, the same however
/// long the model thinks, and gone with the orb. Frames are taken at 30 a
/// second, as the orb draws. MOTES-NOTE lines in the log carry the numbers.
final class AuroraMotesTests: XCTestCase {
    private static let frame = 1.0 / 30.0
    private static let exit = 0.7

    /// The orb's breath (AuroraOrbView.breath): full at 0, half at 1.8 s.
    private static func breath(_ time: TimeInterval) -> Double {
        0.5 + 0.25 * (1 + cos(2 * Double.pi * time / 3.6))
    }

    private func motes(_ time: TimeInterval, leaving: TimeInterval? = nil) -> [AuroraMotes.Mote] {
        AuroraMotes.motes(at: time, leavingAt: leaving, exitDuration: Self.exit, breath: Self.breath)
    }

    private func light(_ motes: [AuroraMotes.Mote]) -> Double { motes.reduce(0) { $0 + $1.alpha } }

    private func frames(from: TimeInterval, to: TimeInterval) -> [TimeInterval] {
        stride(from: from, through: to, by: Self.frame).map { $0 }
    }

    func testNothingAtFirstAndLittleBeforeAQuickReply() {
        XCTAssertTrue(motes(0).isEmpty)
        XCTAssertTrue(motes(AuroraMotes.start - 0.01).isEmpty)
        XCTAssertEqual(AuroraMotes.veil(at: 0, leavingAt: nil, exitDuration: Self.exit, breath: Self.breath), 0)
        let steady = frames(from: 5, to: 60).map { light(motes($0)) }
        let mean = steady.reduce(0, +) / Double(steady.count)
        // A reply whose first text comes 0.6 s after the send: the orb
        // leaves with hardly a mote, so nothing flashes.
        let early = frames(from: 0, to: 0.6).map { light(motes($0)) }.max() ?? 0
        print(String(format: "MOTES-NOTE light by 0.6 s %.3f, steady mean %.3f", early, mean))
        XCTAssertLessThan(early, 0.08 * mean)
        // A quick reply that leaves at 0.6 s: what had begun fades with the
        // orb, never more than a glint.
        let quick = frames(from: 0.6, to: 1.4).map { light(motes($0, leaving: 0.6)) }
        XCTAssertLessThan(quick.max() ?? 0, 0.08 * mean)
    }

    func testAFewAtATimeHoweverLongTheModelThinks() {
        var counts: [Int] = []
        for time in stride(from: 3.0, through: 900, by: 0.37) {
            counts.append(motes(time).filter { $0.alpha > 0.03 }.count)
        }
        let mean = Double(counts.reduce(0, +)) / Double(counts.count)
        print(String(format: "MOTES-NOTE visible motes 3-900 s: %ld to %ld, mean %.1f",
                     counts.min() ?? 0, counts.max() ?? 0, mean))
        XCTAssertGreaterThanOrEqual(counts.min() ?? 0, 2, "Never a bare orb while it thinks")
        XCTAssertLessThanOrEqual(counts.max() ?? 99, AuroraMotes.slots, "Never busy")
        XCTAssertEqual(mean, 7.5, accuracy: 1.5)
        // Each as faint as the design says.
        let strongest = stride(from: 3.0, through: 300, by: 0.37).flatMap { motes($0) }.map(\.alpha).max() ?? 1
        XCTAssertLessThanOrEqual(strongest, AuroraMotes.alpha + AuroraMotes.alphaSpread + 0.001)
    }

    func testTheyStayInsideTheirField() {
        let field = AuroraMotes.field
        for leaving in [nil, 0.6, 7.3, 61.0] as [TimeInterval?] {
            for time in frames(from: 0, to: (leaving ?? 70) + 1) {
                for mote in motes(time, leaving: leaving) {
                    // Its soft edge (three radii out) too.
                    let edge = 3 * mote.radius
                    XCTAssertGreaterThanOrEqual(mote.x - edge, -field.left, "Left at \(time)")
                    XCTAssertLessThanOrEqual(mote.x + edge, field.right, "Right at \(time)")
                    XCTAssertGreaterThanOrEqual(mote.y - edge, -field.up, "Up at \(time)")
                    XCTAssertLessThanOrEqual(mote.y + edge, field.down, "Down at \(time)")
                }
            }
        }
    }

    func testNoMotePopsOrJumps() {
        let leaving = 9.0
        var previous: [String: AuroraMotes.Mote] = [:]
        var largestFade = 0.0, largestStep = 0.0, largestStepLeaving = 0.0
        for time in frames(from: 0, to: leaving + 1) {
            var now: [String: AuroraMotes.Mote] = [:]
            for mote in motes(time, leaving: leaving) { now["\(mote.slot)-\(mote.cycle)"] = mote }
            for (key, mote) in now {
                guard let before = previous[key] else {
                    XCTAssertLessThan(mote.alpha, 0.03, "A mote came in at once at \(time)")
                    continue
                }
                largestFade = max(largestFade, abs(mote.alpha - before.alpha))
                let step = hypot(mote.x - before.x, mote.y - before.y)
                if time > leaving { largestStepLeaving = max(largestStepLeaving, step) } else { largestStep = max(largestStep, step) }
            }
            for (key, mote) in previous where now[key] == nil {
                XCTAssertLessThan(mote.alpha, 0.03, "A mote went at once at \(time)")
            }
            previous = now
        }
        print(String(format: "MOTES-NOTE per frame: alpha %.3f, step %.2f pt, %.2f pt while the orb leaves",
                     largestFade, largestStep, largestStepLeaving))
        XCTAssertLessThan(largestFade, 0.08)
        XCTAssertLessThan(largestStep, 0.6, "Slow: under 18 points a second")
        XCTAssertLessThan(largestStepLeaving, 1.8)
    }

    func testTheyGoTowardTheLineAndAreGoneWithTheOrb() {
        let leaving = 7.3
        let atStart = motes(leaving)
        XCTAssertFalse(atStart.isEmpty)
        let known = Set(atStart.map { "\($0.slot)-\($0.cycle)" })
        var depths: [Double] = []
        for time in frames(from: leaving, to: leaving + Self.exit + 0.5) {
            let now = motes(time, leaving: leaving)
            // No mote is born once the reply's text has come.
            XCTAssertTrue(now.allSatisfy { known.contains("\($0.slot)-\($0.cycle)") }, "A mote was born at \(time)")
            if time >= leaving + Self.exit { XCTAssertTrue(now.isEmpty, "Motes left at \(time)") }
            let weight = light(now)
            if weight > 0 { depths.append(now.reduce(0) { $0 + abs($1.y) * $1.alpha } / weight) }
        }
        // Toward the reply's first line (y = 0) as they fade.
        XCTAssertLessThan(depths.last ?? 0, (depths.first ?? 0) * 0.8)
        XCTAssertEqual(AuroraMotes.veil(at: leaving + Self.exit, leavingAt: leaving, exitDuration: Self.exit, breath: Self.breath), 0)
    }

    func testTheGlowBreathesWithTheOrb() {
        let full = AuroraMotes.veil(at: 3.6 * 3, leavingAt: nil, exitDuration: Self.exit, breath: Self.breath)
        let half = AuroraMotes.veil(at: 3.6 * 3 + 1.8, leavingAt: nil, exitDuration: Self.exit, breath: Self.breath)
        XCTAssertEqual(full, AuroraMotes.veilStrength, accuracy: 0.0001)
        XCTAssertEqual(half, AuroraMotes.veilStrength * 0.85, accuracy: 0.0001)
    }

    func testPackedForTheShader() {
        let some = motes(12)
        let values = AuroraMotes.packed(some, origin: (x: 24, y: 12))
        XCTAssertEqual(values.count, some.count * 5)
        if let first = some.first {
            XCTAssertEqual(Double(values[0]), 24 + first.x, accuracy: 0.001)
            XCTAssertEqual(Double(values[1]), 12 + first.y, accuracy: 0.001)
            XCTAssertEqual(Double(values[3]), first.alpha, accuracy: 0.001)
        }
    }
}
