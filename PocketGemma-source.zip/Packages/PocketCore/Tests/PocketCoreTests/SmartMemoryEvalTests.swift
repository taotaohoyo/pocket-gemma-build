import XCTest
@testable import PocketCore

/// Smart Memory's search on a labeled set (1.1.0 (256)): 43 chats, 29
/// questions that one saved exchange answers, 14 that none does
/// (SmartMemoryEvalSet). Before 256 the search found 24 of the 29 and
/// recalled something for 2 of the 14; the floor here keeps what 256 gained.
final class SmartMemoryEvalTests: XCTestCase {
    struct Result {
        var found = 0, answerable = 0, hits = 0, rightHits = 0, unrelatedWithHits = 0, unrelated = 0
        var misses: [String] = [], strays: [String] = []
    }

    static func evaluate() -> Result {
        var threads: [ChatThread] = [], ids: [String: [UUID]] = [:]
        for chat in SmartMemoryEvalSet.chats {
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            for (question, answer) in chat.pairs {
                let asked = ChatMessage(role: .user, text: question)
                thread.messages += [asked, ChatMessage(role: .assistant, text: answer)]
                ids[chat.name, default: []].append(asked.id)
            }
            threads.append(thread)
        }
        var index = SmartMemoryIndex()
        index.sync(threads)
        var result = Result()
        for query in SmartMemoryEvalSet.queries {
            let hits = index.search(query.question)
            let expected = Set(query.expected.map { ids[$0.0]![$0.1] })
            result.hits += hits.count
            result.rightHits += hits.filter { expected.contains($0.question) }.count
            if expected.isEmpty {
                result.unrelated += 1
                if !hits.isEmpty { result.unrelatedWithHits += 1; result.strays.append(query.question) }
            } else {
                result.answerable += 1
                if hits.contains(where: { expected.contains($0.question) }) { result.found += 1 } else { result.misses.append(query.question) }
            }
        }
        return result
    }

    func testLabeledSet() {
        let result = Self.evaluate()
        print("SMART_MEMORY_EVAL found=\(result.found)/\(result.answerable) rightHits=\(result.rightHits)/\(result.hits) "
              + "unrelatedWithHits=\(result.unrelatedWithHits)/\(result.unrelated) misses=\(result.misses) strays=\(result.strays)")
        XCTAssertEqual(result.answerable, 29)
        XCTAssertEqual(result.unrelated, 14)
        XCTAssertGreaterThanOrEqual(result.found, 26, "misses: \(result.misses)")
        XCTAssertEqual(result.unrelatedWithHits, 0, "strays: \(result.strays)")
        XCTAssertGreaterThanOrEqual(Double(result.rightHits) / Double(max(1, result.hits)), 0.9)
    }

    /// The search's time with many saved chats: 400 chats of 5 exchanges,
    /// indexed once, then a question; within Smart Memory's 400 ms.
    func testSearchTimeWithManyChats() {
        let topics = SmartMemoryEvalSet.chats.flatMap(\.pairs)
        let threads: [ChatThread] = (0..<400).map { chat in
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            thread.messages = (0..<5).flatMap { turn -> [ChatMessage] in
                let (question, answer) = topics[(chat * 5 + turn) % topics.count]
                return [ChatMessage(role: .user, text: question + "（\(chat)-\(turn)）"),
                        ChatMessage(role: .assistant, text: String(repeating: answer, count: 6))]
            }
            return thread
        }
        var index = SmartMemoryIndex()
        let built = Date()
        index.sync(threads)
        let indexing = Date().timeIntervalSince(built) * 1000
        let asked = Date()
        index.sync(threads)
        let hits = index.search("沖縄のホテルどこだっけ")
        let searching = Date().timeIntervalSince(asked) * 1000
        print("SMART_MEMORY_TIME exchanges=\(index.documentCount) indexMs=\(Int(indexing)) syncAndSearchMs=\(Int(searching)) hits=\(hits.count)")
        XCTAssertEqual(index.documentCount, 2_000)
        XCTAssertFalse(hits.isEmpty)
        XCTAssertLessThan(searching, 400, "a search with the index built stays within Smart Memory's time")
    }

    /// Among a few saved chats, a question of two parts finds each part's
    /// exchange. The E2B probe context-e2b (2026-11-06) found neither: the
    /// question's words no exchange had outweighed those they shared.
    func testAFewChatsAndAQuestionOfTwoParts() {
        func pair(_ question: String, _ reply: String) -> [ChatMessage] {
            [ChatMessage(role: .user, text: question), ChatMessage(role: .assistant, text: reply)]
        }
        var trip = ChatThread(modelID: ModelSpec.e2b.id)
        trip.messages = pair("家族旅行の条件を先に伝えます。予算は1人4万5千円まで、出発は12月6日、同行者は母で階段が苦手です。",
                             "承知しました。1人4万5千円まで、12月6日出発ですね。")
            + pair("京都の紅葉について詳しく教えて", "京都の紅葉は11月下旬が見ごろです。")
        var inn = ChatThread(modelID: ModelSpec.e2b.id)
        inn.messages = pair("旅行の宿は「湯の花荘」に決めました。エレベーターがあるそうです。", "湯の花荘ですね。エレベーターがあるなら安心です。")
        var index = SmartMemoryIndex()
        index.sync([trip, inn])
        let question = "最初に伝えた旅行の条件と、決めた宿の名前を教えて"
        XCTAssertEqual(Set(index.search(question).map(\.question)), [trip.messages[0].id, inn.messages[0].id])
        XCTAssertEqual(index.search(question, excluding: Set(trip.messages.map(\.id))).map(\.thread), [inn.id],
                       "the conditions already in the turns given")
        XCTAssertEqual(index.search("東京でおすすめのラーメン屋は？"), [])
        XCTAssertEqual(index.search("宿題が終わらない"), [], "宿題 is not 宿")
    }

    func testFullWidthAndVariantWordsFindTheExchange() {
        var thread = ChatThread(modelID: ModelSpec.e2b.id)
        thread.messages = [ChatMessage(role: .user, text: "Pythonでリストを逆順にするには？"),
                           ChatMessage(role: .assistant, text: "`items.reverse()` か `items[::-1]` です。"),
                           ChatMessage(role: .user, text: "コンピューターの電源が入らない"),
                           ChatMessage(role: .assistant, text: "電源ボタンを15秒長押ししてみてください。")]
        var index = SmartMemoryIndex()
        index.sync([thread])
        XCTAssertFalse(index.search("ＰＹＴＨＯＮでリストを逆にする").isEmpty, "full width letters")
        XCTAssertEqual(index.search("python item reverse").count, 1, "items, the plural, is item")
        XCTAssertFalse(index.search("コンピュータの電源").isEmpty, "without the long vowel mark")
        // A stop word stays one with the plural rule: "this" is not "thi".
        XCTAssertFalse(SmartMemoryTerms.query("this").contains(SmartMemoryTerms.hash("thi")))
        XCTAssertTrue(SmartMemoryTerms.query("this").isEmpty)
    }
}
