import XCTest
@testable import PocketCore

/// Smart Memory's search on a labeled set (1.1.0 (256)): 43 chats, 29
/// questions that one saved exchange answers, 14 that none does
/// (SmartMemoryEvalSet). Before 256 the search found 24 of the 29 and
/// recalled something for 2 of the 14; the floor here keeps what 256 gained.
final class SmartMemoryEvalTests: XCTestCase {
    struct Result {
        var found = 0, answerable = 0, hits = 0, rightHits = 0, unrelatedWithHits = 0, unrelated = 0
        var misses: [String] = [], strays: [String] = []
    }

    static func evaluate() -> Result {
        var threads: [ChatThread] = [], ids: [String: [UUID]] = [:]
        for chat in SmartMemoryEvalSet.chats {
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            for (question, answer) in chat.pairs {
                let asked = ChatMessage(role: .user, text: question)
                thread.messages += [asked, ChatMessage(role: .assistant, text: answer)]
                ids[chat.name, default: []].append(asked.id)
            }
            threads.append(thread)
        }
        var index = SmartMemoryIndex()
        index.sync(threads)
        var result = Result()
        for query in SmartMemoryEvalSet.queries {
            let hits = index.search(query.question)
            let expected = Set(query.expected.map { ids[$0.0]![$0.1] })
            result.hits += hits.count
            result.rightHits += hits.filter { expected.contains($0.question) }.count
            if expected.isEmpty {
                result.unrelated += 1
                if !hits.isEmpty { result.unrelatedWithHits += 1; result.strays.append(query.question) }
            } else {
                result.answerable += 1
                if hits.contains(where: { expected.contains($0.question) }) { result.found += 1 } else { result.misses.append(query.question) }
            }
        }
        return result
    }

    func testLabeledSet() {
        let result = Self.evaluate()
        print("SMART_MEMORY_EVAL found=\(result.found)/\(result.answerable) rightHits=\(result.rightHits)/\(result.hits) "
              + "unrelatedWithHits=\(result.unrelatedWithHits)/\(result.unrelated) misses=\(result.misses) strays=\(result.strays)")
        XCTAssertEqual(result.answerable, 29)
        XCTAssertEqual(result.unrelated, 14)
        XCTAssertGreaterThanOrEqual(result.found, 26, "misses: \(result.misses)")
        XCTAssertEqual(result.unrelatedWithHits, 0, "strays: \(result.strays)")
        XCTAssertGreaterThanOrEqual(Double(result.rightHits) / Double(max(1, result.hits)), 0.9)
    }

    /// The search's time with many saved chats: 400 chats of 5 exchanges,
    /// indexed once, then a question; within Smart Memory's 400 ms.
    func testSearchTimeWithManyChats() {
        let topics = SmartMemoryEvalSet.chats.flatMap(\.pairs)
        let threads: [ChatThread] = (0..<400).map { chat in
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            thread.messages = (0..<5).flatMap { turn -> [ChatMessage] in
                let (question, answer) = topics[(chat * 5 + turn) % topics.count]
                return [ChatMessage(role: .user, text: question + "（\(chat)-\(turn)）"),
                        ChatMessage(role: .assistant, text: String(repeating: answer, count: 6))]
            }
            return thread
        }
        var index = SmartMemoryIndex()
        let built = Date()
        index.sync(threads)
        let indexing = Date().timeIntervalSince(built) * 1000
        let asked = Date()
        index.sync(threads)
        let hits = index.search("沖縄のホテルどこだっけ")
        let searching = Date().timeIntervalSince(asked) * 1000
        print("SMART_MEMORY_TIME exchanges=\(index.documentCount) indexMs=\(Int(indexing)) syncAndSearchMs=\(Int(searching)) hits=\(hits.count)")
        XCTAssertEqual(index.documentCount, 2_000)
        XCTAssertFalse(hits.isEmpty)
        XCTAssertLessThan(searching, 400, "a search with the index built stays within Smart Memory's time")
    }

    func testFullWidthAndVariantWordsFindTheExchange() {
        var thread = ChatThread(modelID: ModelSpec.e2b.id)
        thread.messages = [ChatMessage(role: .user, text: "Pythonでリストを逆順にするには？"),
                           ChatMessage(role: .assistant, text: "`items.reverse()` か `items[::-1]` です。"),
                           ChatMessage(role: .user, text: "コンピューターの電源が入らない"),
                           ChatMessage(role: .assistant, text: "電源ボタンを15秒長押ししてみてください。")]
        var index = SmartMemoryIndex()
        index.sync([thread])
        XCTAssertFalse(index.search("ＰＹＴＨＯＮでリストを逆にする").isEmpty, "full width letters")
        XCTAssertEqual(index.search("python item reverse").count, 1, "items, the plural, is item")
        XCTAssertFalse(index.search("コンピュータの電源").isEmpty, "without the long vowel mark")
    }
}
