import XCTest
@testable import PocketCore

/// Smart Memory's search on a labeled set (1.1.0 (256)): 43 chats, 29
/// questions that one saved exchange answers, 14 that none does
/// (SmartMemoryEvalSet). Before 256 the search found 24 of the 29, 24 of
/// its 30 hits right, and recalled something for 2 of the 14; 256 finds 26,
/// 26 of 27 right, and nothing for the 14. The floor here keeps that.
final class SmartMemoryEvalTests: XCTestCase {
    struct Result {
        var found = 0, answerable = 0, hits = 0, rightHits = 0, unrelatedWithHits = 0, unrelated = 0
        var misses: [String] = [], strays: [String] = []
    }

    static func evaluate() -> Result {
        var threads: [ChatThread] = [], ids: [String: [UUID]] = [:]
        for chat in SmartMemoryEvalSet.chats {
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            for (question, answer) in chat.pairs {
                let asked = ChatMessage(role: .user, text: question)
                thread.messages += [asked, ChatMessage(role: .assistant, text: answer)]
                ids[chat.name, default: []].append(asked.id)
            }
            threads.append(thread)
        }
        var index = SmartMemoryIndex()
        index.sync(threads)
        var result = Result()
        for query in SmartMemoryEvalSet.queries {
            let hits = index.search(query.question)
            let expected = Set(query.expected.map { ids[$0.0]![$0.1] })
            result.hits += hits.count
            result.rightHits += hits.filter { expected.contains($0.question) }.count
            if expected.isEmpty {
                result.unrelated += 1
                if !hits.isEmpty { result.unrelatedWithHits += 1; result.strays.append(query.question) }
            } else {
                result.answerable += 1
                if hits.contains(where: { expected.contains($0.question) }) { result.found += 1 } else { result.misses.append(query.question) }
            }
        }
        return result
    }

    func testLabeledSet() {
        let result = Self.evaluate()
        print("SMART_MEMORY_EVAL found=\(result.found)/\(result.answerable) rightHits=\(result.rightHits)/\(result.hits) "
              + "unrelatedWithHits=\(result.unrelatedWithHits)/\(result.unrelated) misses=\(result.misses) strays=\(result.strays)")
        XCTAssertEqual(result.answerable, 29)
        XCTAssertEqual(result.unrelated, 14)
        XCTAssertGreaterThanOrEqual(result.found, 26, "misses: \(result.misses)")
        XCTAssertEqual(result.unrelatedWithHits, 0, "strays: \(result.strays)")
        XCTAssertGreaterThanOrEqual(Double(result.rightHits) / Double(max(1, result.hits)), 0.9)
    }

    /// The search's time with many saved chats: 400 chats of 5 exchanges,
    /// indexed once, then a question; within Smart Memory's 400 ms.
    func testSearchTimeWithManyChats() {
        let topics = SmartMemoryEvalSet.chats.flatMap(\.pairs)
        let threads: [ChatThread] = (0..<400).map { chat in
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            thread.messages = (0..<5).flatMap { turn -> [ChatMessage] in
                let (question, answer) = topics[(chat * 5 + turn) % topics.count]
                return [ChatMessage(role: .user, text: question + "（\(chat)-\(turn)）"),
                        ChatMessage(role: .assistant, text: String(repeating: answer, count: 6))]
            }
            return thread
        }
        var index = SmartMemoryIndex()
        let built = Date()
        index.sync(threads)
        let indexing = Date().timeIntervalSince(built) * 1000
        let asked = Date()
        index.sync(threads)
        let hits = index.search("沖縄のホテルどこだっけ")
        let searching = Date().timeIntervalSince(asked) * 1000
        print("SMART_MEMORY_TIME exchanges=\(index.documentCount) indexMs=\(Int(indexing)) syncAndSearchMs=\(Int(searching)) hits=\(hits.count)")
        XCTAssertEqual(index.documentCount, 2_000)
        XCTAssertFalse(hits.isEmpty)
        XCTAssertLessThan(searching, 400, "a search with the index built stays within Smart Memory's time")
    }

    /// Among a few saved chats, a question of two parts finds each part's
    /// exchange. The E2B probe context-e2b (2026-11-06) found neither: the
    /// question's words no exchange had outweighed those they shared.
    func testAFewChatsAndAQuestionOfTwoParts() {
        func pair(_ question: String, _ reply: String) -> [ChatMessage] {
            [ChatMessage(role: .user, text: question), ChatMessage(role: .assistant, text: reply)]
        }
        var trip = ChatThread(modelID: ModelSpec.e2b.id)
        trip.messages = pair("家族旅行の条件を先に伝えます。予算は1人4万5千円まで、出発は12月6日、同行者は母で階段が苦手です。",
                             "承知しました。1人4万5千円まで、12月6日出発ですね。")
            + pair("京都の紅葉について詳しく教えて", "京都の紅葉は11月下旬が見ごろです。")
        var inn = ChatThread(modelID: ModelSpec.e2b.id)
        inn.messages = pair("旅行の宿は「湯の花荘」に決めました。エレベーターがあるそうです。", "湯の花荘ですね。エレベーターがあるなら安心です。")
        var index = SmartMemoryIndex()
        index.sync([trip, inn])
        let question = "最初に伝えた旅行の条件と、決めた宿の名前を教えて"
        XCTAssertEqual(Set(index.search(question).map(\.question)), [trip.messages[0].id, inn.messages[0].id])
        XCTAssertEqual(index.search(question, excluding: Set(trip.messages.map(\.id))).map(\.thread), [inn.id],
                       "the conditions already in the turns given")
        XCTAssertEqual(index.search("東京でおすすめのラーメン屋は？"), [])
        XCTAssertEqual(index.search("宿題が終わらない"), [], "宿題 is not 宿")
    }

    /// Replies as Gemma writes them, for the review's cases (2026-11-06).
    private static let replies: [(String, String)] = [
        ("うちの猫の名前はミケで、誕生日は3月14日です", "ミケちゃん、3月14日生まれなんですね。覚えておきます。"),
        ("沖縄旅行のホテルはハレクラニ沖縄です", "ハレクラニ沖縄ですね。素敵な旅行になりますように。"),
        ("Excelで重複を消すには？", "データタブの「重複の削除」を使います。分からないところがあれば、お気軽にどうぞ。"),
        ("肩こりがひどい", "つらいですね。もう少し詳しく症状を教えていただければ、対策をご提案できます。"),
        ("この文を英語にして：よろしくお願いします", "\"Thank you in advance\" や \"I look forward to working with you\" です。"),
        ("緑茶の良い淹れ方", "70度くらいのお湯で1分ほど待つのが良い方法です。"),
        ("車の運転で気をつけること", "車間距離を十分にとり、スピードに気をつけましょう。"),
        ("自動車保険は東京海上にした。更新は毎年4月", "東京海上、毎年4月更新ですね。"),
        ("実家の住所は札幌市中央区北1条西2丁目です", "札幌市中央区北1条西2丁目ですね。"),
        ("子猫を飼い始めました。名前はモモです。", "モモちゃん、かわいいですね。"),
        ("車検は来年の3月だった気がする", "来年3月の車検ですね。"),
        ("ポチのかかりつけの動物病院は駅前のさくら動物病院", "さくら動物病院ですね。"),
        ("Here is my resume, can you review it?", "Thanks for sharing it, and I'm happy to help! Your resume is clear."),
    ]

    private func indexed(_ count: Int) -> (SmartMemoryIndex, [String: UUID]) {
        var threads: [ChatThread] = [], ids: [String: UUID] = [:]
        for (question, reply) in Self.replies.prefix(count) {
            var thread = ChatThread(modelID: ModelSpec.e2b.id)
            thread.messages = [ChatMessage(role: .user, text: question), ChatMessage(role: .assistant, text: reply)]
            ids[question] = thread.messages[0].id
            threads.append(thread)
        }
        var index = SmartMemoryIndex()
        index.sync(threads)
        return (index, ids)
    }

    /// The review (SM-1, SM-3, SM-6): a reply's words of course (分かりました,
    /// もう少し詳しく, Thanks) and new questions sharing a word or two with
    /// one of a few saved chats recalled it.
    func testFollowUpsAndNewQuestionsRecallNothing() {
        let questions = ["分かりました", "分かりやすく説明して", "もう少し詳しく", "お願いします", "良い方法はある？", "気をつけることは？",
                         "友達の誕生日に名前入りのケーキを頼みたい。お店の選び方は？", "子供の名前の候補をいくつか考えて。誕生日は春の予定",
                         "京都の紅葉を見に行く旅行で、和風旅館とホテルの違いは？", "父の誕生日プレゼントに名前を彫った万年筆はどう？",
                         "新しい名前を考えて", "Thanks, that helps!", "This helps, thanks", "Thanks!", "thank you"]
        for count in [1, 2, 4, Self.replies.count] {
            let (index, _) = indexed(count)
            for question in questions { XCTAssertEqual(index.search(question), [], "\(count) chats: \(question)") }
        }
    }

    /// The review (SM-4): a kanji alone in the question (車, 家, 猫, 犬)
    /// raised the words a hit needs, though the saved exchange had it
    /// inside a word (自動車, 実家, 子猫) or not at all; 255 found these.
    func testAKanjiAloneFindsTheWordItIsIn() {
        let (index, ids) = indexed(Self.replies.count)
        let expected: [(String, [String])] = [
            ("車の保険どこだっけ", ["自動車保険は東京海上にした。更新は毎年4月"]),
            ("家の住所どこだっけ", ["実家の住所は札幌市中央区北1条西2丁目です"]),
            ("猫の名前は？", ["子猫を飼い始めました。名前はモモです。", "うちの猫の名前はミケで、誕生日は3月14日です"]),
            ("車の車検はいつ？", ["車検は来年の3月だった気がする"]),
            ("犬の病院はどこ？", ["ポチのかかりつけの動物病院は駅前のさくら動物病院"]),
        ]
        for (question, answers) in expected {
            XCTAssertEqual(Set(index.search(question).map(\.question)), Set(answers.compactMap { ids[$0] }), question)
        }
    }

    func testFullWidthAndVariantWordsFindTheExchange() {
        var thread = ChatThread(modelID: ModelSpec.e2b.id)
        thread.messages = [ChatMessage(role: .user, text: "Pythonでリストを逆順にするには？"),
                           ChatMessage(role: .assistant, text: "`items.reverse()` か `items[::-1]` です。"),
                           ChatMessage(role: .user, text: "コンピューターの電源が入らない"),
                           ChatMessage(role: .assistant, text: "電源ボタンを15秒長押ししてみてください。")]
        var index = SmartMemoryIndex()
        index.sync([thread])
        XCTAssertFalse(index.search("ＰＹＴＨＯＮでリストを逆にする").isEmpty, "full width letters")
        XCTAssertEqual(index.search("python item reverse").count, 1, "items, the plural, is item")
        XCTAssertFalse(index.search("コンピュータの電源").isEmpty, "without the long vowel mark")
        // A stop word stays one with the plural rule: "this" is not "thi".
        XCTAssertFalse(SmartMemoryTerms.query("this").contains(SmartMemoryTerms.hash("thi")))
        XCTAssertTrue(SmartMemoryTerms.query("this").isEmpty)
    }
}
