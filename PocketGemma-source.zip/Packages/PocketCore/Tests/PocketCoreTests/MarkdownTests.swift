import XCTest
@testable import PocketCore

final class MarkdownTests: XCTestCase {
    private func plain(_ text: AttributedString) -> String { String(text.characters) }

    private func paragraph(_ block: MarkdownBlock?, file: StaticString = #filePath, line: UInt = #line) -> AttributedString {
        guard case .paragraph(let text)? = block else {
            XCTFail("Expected a paragraph, got \(String(describing: block))", file: file, line: line)
            return AttributedString()
        }
        return text
    }

    private func intent(of word: String, in text: AttributedString) -> InlinePresentationIntent? {
        guard let range = text.range(of: word) else { return nil }
        return text[range].runs.first?.inlinePresentationIntent
    }

    func testPlainReplyStaysOneParagraphWithTheSameText() {
        let reply = "これはUI検証用のサンプル会話です。実際のAI推論は実行していません。"
        let blocks = MarkdownDocument(reply).blocks
        XCTAssertEqual(blocks.count, 1)
        XCTAssertEqual(plain(paragraph(blocks.first)), reply)
    }

    func testHeadingsEmphasisStrikethroughAndInlineCode() {
        let blocks = MarkdownDocument("# 見出し\n\n**太字** と *斜体* と ~~取り消し~~ と `code`").blocks
        guard case .heading(let level, let title)? = blocks.first else { return XCTFail("\(blocks)") }
        XCTAssertEqual(level, 1)
        XCTAssertEqual(plain(title), "見出し")
        let text = paragraph(blocks.dropFirst().first)
        XCTAssertEqual(plain(text), "太字 と 斜体 と 取り消し と code")
        XCTAssertTrue(intent(of: "太字", in: text)?.contains(.stronglyEmphasized) == true)
        XCTAssertTrue(intent(of: "斜体", in: text)?.contains(.emphasized) == true)
        XCTAssertTrue(intent(of: "取り消し", in: text)?.contains(.strikethrough) == true)
        XCTAssertTrue(intent(of: "code", in: text)?.contains(.code) == true)
    }

    /// Gemma writes `**「…」**とか`; CommonMark alone leaves the asterisks.
    func testEmphasisNextToJapanesePunctuation() {
        let text = paragraph(MarkdownDocument("もしよろしければ、**「〇〇についてのクイズを出して」**とか、これは**「重要」**です。").blocks.first)
        XCTAssertEqual(plain(text), "もしよろしければ、「〇〇についてのクイズを出して」とか、これは「重要」です。")
        XCTAssertTrue(intent(of: "「〇〇についてのクイズを出して」", in: text)?.contains(.stronglyEmphasized) == true)
        XCTAssertTrue(intent(of: "「重要」", in: text)?.contains(.stronglyEmphasized) == true)
        XCTAssertFalse(plain(text).contains("\u{200A}"))
    }

    func testSingleLineBreaksAreKept() {
        XCTAssertEqual(plain(paragraph(MarkdownDocument("一行目\n二行目").blocks.first)), "一行目\n二行目")
    }

    func testNestedOrderedListsAndChecklists() {
        let source = "1. 準備\n2. 実行\n   - 確認\n   - [x] 完了\n   - [ ] 未完了"
        guard case .list(let ordered, let items)? = MarkdownDocument(source).blocks.first else {
            return XCTFail("\(MarkdownDocument(source).blocks)")
        }
        XCTAssertTrue(ordered)
        XCTAssertEqual(items.map(\.ordinal), [1, 2])
        XCTAssertEqual(plain(paragraph(items[0].blocks.first)), "準備")
        guard case .list(let nestedOrdered, let nested)? = items[1].blocks.last else { return XCTFail("\(items[1].blocks)") }
        XCTAssertFalse(nestedOrdered)
        XCTAssertEqual(nested.map(\.checked), [nil, true, false])
        XCTAssertEqual(nested.map { plain(paragraph($0.blocks.first)) }, ["確認", "完了", "未完了"])
    }

    func testOrderedListKeepsItsStartNumber() {
        guard case .list(_, let items)? = MarkdownDocument("3. 三\n4. 四").blocks.first else { return XCTFail() }
        XCTAssertEqual(items.map(\.ordinal), [3, 4])
    }

    func testQuoteRuleAndFollowingParagraph() {
        let blocks = MarkdownDocument("> 引用\n> 続き\n\n---\n\n後").blocks
        XCTAssertEqual(blocks.count, 3, "\(blocks)")
        guard case .quote(let inner)? = blocks.first else { return XCTFail("\(blocks)") }
        XCTAssertEqual(plain(paragraph(inner.first)), "引用\n続き")
        XCTAssertEqual(blocks.dropFirst().first, .rule)
        XCTAssertEqual(plain(paragraph(blocks.last)), "後")
    }

    func testTableCellsAndAlignment() {
        let source = "| 名前 | 値 |\n|:--|--:|\n| a | **1** |\n| b | 2 |"
        guard case .table(let table)? = MarkdownDocument(source).blocks.first else {
            return XCTFail("\(MarkdownDocument(source).blocks)")
        }
        XCTAssertEqual(table.alignments, [.leading, .trailing])
        XCTAssertEqual(table.header.map(plain), ["名前", "値"])
        XCTAssertEqual(table.rows.map { $0.map(plain) }, [["a", "1"], ["b", "2"]])
        XCTAssertTrue(intent(of: "1", in: table.rows[0][1])?.contains(.stronglyEmphasized) == true)
    }

    func testCodeBlockKeepsItsTextExactly() {
        let code = "let x = \"**not bold**\" // $x$\n\n  indented"
        XCTAssertEqual(MarkdownDocument("```Swift\n\(code)\n```").blocks, [.code(language: "swift", code: code)])
        XCTAssertEqual(MarkdownDocument("```\nplain\n```").blocks, [.code(language: nil, code: "plain")])
    }

    func testInlineAndBlockMath() {
        let blocks = MarkdownDocument("式は $E=mc^2$ と $a_1 * b_2$ です。\n\n$$\n\\frac{a}{b}\n$$\n\n\\[ x^2 \\]\n\n$$ y_1 $$").blocks
        let text = paragraph(blocks.first)
        XCTAssertEqual(plain(text), "式は E=mc^2 と a_1 * b_2 です。")
        let math = text.runs.compactMap { $0[MarkdownMathAttribute.self] }
        XCTAssertEqual(math, [MarkdownMath(latex: "E=mc^2", display: false, raw: "$E=mc^2$"),
                              MarkdownMath(latex: "a_1 * b_2", display: false, raw: "$a_1 * b_2$")])
        XCTAssertEqual(Array(blocks.dropFirst()), [.math("\\frac{a}{b}"), .math("x^2"), .math("y_1")])
        let parenthesized = paragraph(MarkdownDocument("式 \\( x \\) と $$ y $$ です").blocks.first)
        XCTAssertEqual(parenthesized.runs.compactMap { $0[MarkdownMathAttribute.self]?.raw }, ["\\( x \\)", "$$ y $$"])
    }

    func testMathSyntaxEscapesCharactersSwiftMathWouldDrop() {
        XCTAssertEqual(MathSyntax.prepared("50% \\% #1 \\# $ \\$ a~b \\\\"), "50\\% \\% \\#1 \\# \\$ \\$ a\\ b \\\\")
        XCTAssertEqual(MathSyntax.prepared("\\frac{a}{b}"), "\\frac{a}{b}")
    }

    func testMathNormalizationRewritesWhatSwiftMathLacks() {
        XCTAssertEqual(MathSyntax.normalized("\\begin{align*} a &= b \\\\[4pt] c &= d \\end{align*}"),
                       "\\begin{aligned} a &\\;= b \\\\ c &\\;= d \\end{aligned}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{alignat}{2} a &= b \\end{alignat}"), "\\begin{aligned} a &\\;= b \\end{aligned}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{aligned} x &\\le y \\\\ &+ z \\end{aligned}"),
                       "\\begin{aligned} x &\\;\\le y \\\\ &+ z \\end{aligned}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{array}{|c|c|} \\hline a & b \\\\ \\hline \\end{array}"),
                       "\\begin{matrix}  a & b \\\\  \\end{matrix}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{equation} x \\end{equation}"), " x ")
        XCTAssertEqual(MathSyntax.normalized("\\dfrac{a}{b} \\tfrac12 \\operatorname{argmax}_x \\operatorname*{E}"),
                       "\\frac{a}{b} \\frac12 \\mathrm{argmax}_x \\mathrm{E}")
        XCTAssertEqual(MathSyntax.normalized("f'(x) + g''(x) \\text{it's}"), "f^{\\prime}(x) + g^{\\prime\\prime}(x) \\text{it's}")
        XCTAssertEqual(MathSyntax.normalized("ｘ＝１０−２ − ３"), "x=10-2 - 3")
        XCTAssertEqual(MathSyntax.normalized("１～１０"), "1～10")
        XCTAssertEqual(MathSyntax.normalized("a \\medspace b"), "a \\> b")
        XCTAssertEqual(MathSyntax.normalized("\\color{red}{x} \\textcolor{blue}{y} \\tag{1} \\label{eq} z"), "{x} {y} \\qquad (1)  z")
        XCTAssertEqual(MathSyntax.normalized("\\begin{align} a = b \\\\ c = d \\end{align}"), "\\begin{gather} a = b \\\\ c = d \\end{gather}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{array}{cc|c} 1 & 0 \\end{array}"), "\\begin{array}{cc|c} 1 & 0 \\end{array}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{cases} x + y = 1 \\\\ x - y = 0 \\end{cases}"),
                       "\\begin{cases} x + y = 1 \\\\ x - y = 0 &\\end{cases}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{cases} 1 & x > 0 \\\\ 0 & x \\le 0 \\end{cases}"),
                       "\\begin{cases} 1 & x > 0 \\\\ 0 & x \\le 0 \\end{cases}")
        XCTAssertEqual(MathSyntax.normalized("\\begin{equation} \\begin{align} a &= b \\end{align} \\end{equation}"),
                       " \\begin{aligned} a &\\;= b \\end{aligned} ")
        XCTAssertEqual(MathSyntax.normalized("a \\: b ＆ c"), "a \\> b ＆ c")
        XCTAssertEqual(MathSyntax.normalized("\\left( \\frac{a}{b} \\middle| c \\right) \\bigl( d \\bigr)"),
                       "\\left( \\frac{a}{b} | c \\right) ( d )")
        XCTAssertEqual(MathSyntax.normalized("\\boldsymbol{v} \\dots \\implies \\lVert x \\rVert \\therefore"),
                       "\\bm{v} \\ldots \\Rightarrow \\Vert x \\Vert ∴")
        XCTAssertEqual(MathSyntax.normalized("a \\pmod{n} \\sum_{\\substack{i<j}}"),
                       "a \\ (\\mathrm{mod}\\ n) \\sum_{\\begin{matrix}i<j\\end{matrix}}")
        XCTAssertEqual(MathSyntax.normalized("\\not\\in \\not= 50%"), "\\notin \\neq 50\\%")
        XCTAssertEqual(MathSyntax.normalized("\\frac{a}{b}"), "\\frac{a}{b}")
    }

    func testMathPlaceholdersStandForTextRuns() {
        let (source, texts) = MathSyntax.placeholders("\\text{自己分析} × 企業研究 = 内定",
                                                      isKnown: { $0 == "×" }, symbolName: { $0 == "×" ? "times" : nil })
        // A space is ASCII, so it ends a run and is never part of the text.
        XCTAssertEqual(source, "\\text{{\\PocketTextA}} × {\\PocketTextB} = {\\PocketTextC}")
        XCTAssertEqual(texts, ["自己分析", "企業研究", "内定"])
        XCTAssertEqual(MathSyntax.placeholderName(0), "PocketTextA")
        XCTAssertEqual(MathSyntax.placeholderName(26), "PocketTextBA")
        let (symbol, none) = MathSyntax.placeholders("a ≤ b", isKnown: { _ in false }, symbolName: { $0 == "≤" ? "le" : nil })
        XCTAssertEqual(symbol, "a {\\le} b")
        XCTAssertTrue(none.isEmpty)
    }

    func testDisplayMathInsideALine() {
        let text = paragraph(MarkdownDocument("式 \\[ x^2 \\] と $$ y $$ です").blocks.first)
        XCTAssertEqual(text.runs.compactMap { $0[MarkdownMathAttribute.self] },
                       [MarkdownMath(latex: "x^2", display: true, raw: "\\[ x^2 \\]"), MarkdownMath(latex: "y", display: true, raw: "$$ y $$")])
        let note = paragraph(MarkdownDocument("\\[注意\\] は数式ではない").blocks.first)
        XCTAssertTrue(note.runs.allSatisfy { $0[MarkdownMathAttribute.self] == nil })
        XCTAssertEqual(plain(note), "[注意] は数式ではない")
        // Escaped brackets around a citation number stay brackets.
        let citation = paragraph(MarkdownDocument("参考文献 \\[1\\] と \\[12\\] を参照").blocks.first)
        XCTAssertTrue(citation.runs.allSatisfy { $0[MarkdownMathAttribute.self] == nil })
        XCTAssertEqual(plain(citation), "参考文献 [1] と [12] を参照")
    }

    func testStreamingHoldsBackInlineMathStillArriving() {
        XCTAssertEqual(MarkdownSource.repairStreaming("式は $\\frac{a}{"), "式は")
        XCTAssertEqual(MarkdownSource.repairStreaming("式は \\(x^"), "式は")
        XCTAssertEqual(MarkdownSource.repairStreaming("式は $$x^2"), "式は")
        XCTAssertEqual(MarkdownSource.repairStreaming("$a_1$ と $b_"), "$a_1$ と")
        XCTAssertEqual(MarkdownSource.repairStreaming("`$x$` と $y_"), "`$x$` と")
        XCTAssertEqual(MarkdownSource.repairStreaming("- $x^"), "")
        XCTAssertEqual(MarkdownSource.repairStreaming("式は $"), "式は")
        // Prose with a dollar in it shows: no LaTeX in it, or too long to hide.
        XCTAssertEqual(MarkdownSource.repairStreaming("価格は $5 と $10"), "価格は $5 と $10")
        XCTAssertEqual(MarkdownSource.repairStreaming("価格は$5と$10です"), "価格は$5と$10です")
        let long = "式は $" + String(repeating: "x^2 + ", count: 12)
        XCTAssertEqual(MarkdownSource.repairStreaming(long), long)
    }

    func testJapaneseInlineMathWithAnOperatorIsMath() {
        let text = paragraph(MarkdownDocument("$利益率 = 5$ と $利益率$ と $5と$10").blocks.first)
        XCTAssertEqual(text.runs.compactMap { $0[MarkdownMathAttribute.self]?.latex }, ["利益率 = 5"])
        XCTAssertTrue(plain(text).hasSuffix("$利益率$ と $5と$10"), plain(text))
        // A unit or a particle after a number or a word keeps prices and
        // variables as prose, operator or not.
        for prose in ["価格は$5=750円です。(1$=150円)", "環境変数$HOME_DIRと$PATHを設定します", "1$=150円なら、10$=1500円です"] {
            let paragraphText = paragraph(MarkdownDocument(prose).blocks.first)
            XCTAssertTrue(paragraphText.runs.allSatisfy { $0[MarkdownMathAttribute.self] == nil }, prose)
            XCTAssertEqual(plain(paragraphText), prose)
        }
    }

    func testNoteLineKeepsItsEscapedBrackets() {
        let note = paragraph(MarkdownDocument("[注]: 式は \\[x\\] です").blocks.first)
        XCTAssertTrue(note.runs.allSatisfy { $0[MarkdownMathAttribute.self] == nil })
        XCTAssertEqual(plain(note), "[注]: 式は [x] です")
    }

    func testAFormulaClosedOnItsOwnLineIsNotAnOpenBlockWhileStreaming() {
        let chunk = "\\[ x^2 \\] と書けます\n次の行"
        XCTAssertEqual(MarkdownSource.repairStreaming(chunk), chunk)
        XCTAssertFalse(MarkdownSource.repairStreamingDetailed(chunk).closedMath)
        XCTAssertEqual(MarkdownSource.repairStreamingDetailed("\\[\nx^2").text, "\\[\nx^2\n\\]")
    }

    func testIndentedCodeKeepsItsText() {
        let blocks = MarkdownDocument("例:\n\n    echo $HOME/$USER\n    [^1]: **x**\n    [注]: 日本語").blocks
        XCTAssertEqual(blocks.last, .code(language: nil, code: "echo $HOME/$USER\n[^1]: **x**\n[注]: 日本語"), "\(blocks)")
        XCTAssertEqual(MarkdownDocument("```math title=x\na\n```").blocks, [.math("a")])
        XCTAssertEqual(MarkdownDocument("```Swift extra\nlet a = 1\n```").blocks, [.code(language: "swift", code: "let a = 1")])
    }

    func testNoteLinesStayVisibleWhileLinkDefinitionsHide() {
        let source = "[注]: 上記は概算です。\n\n[1]: https://example.com"
        XCTAssertEqual(MarkdownSource.referenceDefinitions(source), "[1]: https://example.com")
        let blocks = MarkdownDocument(source).blocks
        XCTAssertEqual(blocks.count, 1, "\(blocks)")
        XCTAssertEqual(plain(paragraph(blocks.first)), "[注]: 上記は概算です。")
    }

    func testHTMLBlockStaysVisible() {
        let blocks = MarkdownDocument("<div>\nこんにちは\n</div>\n\n後").blocks
        let text = blocks.map(Self.visibleText).joined()
        XCTAssertTrue(text.contains("こんにちは"), "\(blocks)")
        XCTAssertTrue(text.contains("後"), "\(blocks)")
    }

    func testPricesAndCodeAreNotMath() {
        let text = paragraph(MarkdownDocument("価格は$5と$10です。`$x$` はコード。").blocks.first)
        XCTAssertEqual(plain(text), "価格は$5と$10です。$x$ はコード。")
        XCTAssertTrue(text.runs.allSatisfy { $0[MarkdownMathAttribute.self] == nil })
        let japanese = paragraph(MarkdownDocument("$5と$10です。速さは $v = \\frac{d}{t}$、単位は $\\text{秒}$ です。").blocks.first)
        XCTAssertEqual(japanese.runs.compactMap { $0[MarkdownMathAttribute.self]?.latex }, ["v = \\frac{d}{t}", "\\text{秒}"])
        XCTAssertTrue(plain(japanese).hasPrefix("$5と$10です。"))
    }

    func testLinksAreLimitedToWebAndMail() {
        let text = paragraph(MarkdownDocument("[公式](https://example.com) [危険](javascript:alert(1)) [ファイル](file:///etc/passwd) [メール](mailto:a@example.com) https://www.apple.com を見て").blocks.first)
        func link(_ word: String) -> URL? { text.range(of: word).flatMap { text[$0].runs.first?.link } }
        XCTAssertEqual(link("公式")?.absoluteString, "https://example.com")
        XCTAssertNil(link("危険"))
        XCTAssertNil(link("ファイル"))
        XCTAssertEqual(link("メール")?.scheme, "mailto")
        XCTAssertEqual(link("https://www.apple.com")?.host, "www.apple.com")
    }

    func testImagesBecomeBlocksOfTheirOwn() {
        let blocks = MarkdownDocument("説明\n\n![猫の写真](https://example.com/cat.png)").blocks
        XCTAssertEqual(plain(paragraph(blocks.first)), "説明")
        XCTAssertEqual(blocks.last, .image(url: URL(string: "https://example.com/cat.png"), alt: "猫の写真"))
        XCTAssertTrue(MarkdownLinkPolicy.isLoadableImage(URL(string: "https://example.com/cat.png")!))
        XCTAssertFalse(MarkdownLinkPolicy.isLoadableImage(URL(string: "http://example.com/cat.png")!))
        XCTAssertFalse(MarkdownLinkPolicy.isLoadableImage(URL(string: "file:///tmp/cat.png")!))
    }

    func testRawHTMLIsShownAsText() {
        let blocks = MarkdownDocument("<b>太字</b> と <script>alert(1)</script>").blocks
        let text = blocks.map { block -> String in
            if case .paragraph(let text) = block { return plain(text) }
            return ""
        }.joined()
        XCTAssertTrue(text.contains("太字"), text)
        XCTAssertTrue(text.contains("alert(1)"), text)
    }

    // MARK: Streaming

    func testStreamingClosesOrHoldsBackUnfinishedSyntax() {
        XCTAssertEqual(MarkdownSource.repairStreaming("```python\nprint(1)"), "```python\nprint(1)\n```")
        XCTAssertEqual(MarkdownSource.repairStreaming("テキスト **"), "テキスト")
        XCTAssertEqual(MarkdownSource.repairStreaming("これは**重要"), "これは**重要**")
        XCTAssertEqual(MarkdownSource.repairStreaming("`let x"), "`let x`")
        XCTAssertEqual(MarkdownSource.repairStreaming("詳しくは[公式サイト](https://exa"), "詳しくは公式サイト")
        XCTAssertEqual(MarkdownSource.repairStreaming("写真\n![猫](https://ex"), "写真\n")
        XCTAssertEqual(MarkdownSource.repairStreaming("| a | b |\n|---|---|\n| 1 | 2 |\n| 3"), "| a | b |\n|---|---|\n| 1 | 2 |")
        XCTAssertEqual(MarkdownSource.repairStreaming("説明\n| a | b |\n| --"), "説明")
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n-"), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n2"), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("$$\n\\frac{1}{2}"), "$$\n\\frac{1}{2}\n$$")
        XCTAssertEqual(MarkdownSource.repairStreaming("> ```\n> code"), "> ```\n> code\n> ```")
    }

    /// Markers still arriving wait, so a paragraph never turns into a
    /// heading or grows an empty item for a moment.
    func testStreamingHoldsBackMarkersThatWouldFlipTheLayout() {
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n- **"), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n1. **"), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("引用\n> -"), "引用")
        XCTAssertEqual(MarkdownSource.repairStreaming("> #"), "")
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n100."), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("2024"), "2024")
        XCTAssertEqual(MarkdownSource.repairStreaming("***重要"), "***重要***")
        XCTAssertEqual(MarkdownSource.repairStreaming("__重要"), "__重要__")
        XCTAssertEqual(MarkdownSource.repairStreaming("詳しくは[公式サ"), "詳しくは公式サ")
        XCTAssertEqual(MarkdownSource.repairStreaming("写真\n![猫の"), "写真\n")
        let streamed = MarkdownDocument("段落\n- **", streaming: true).blocks
        XCTAssertEqual(streamed.count, 1, "\(streamed)")
        XCTAssertEqual(plain(paragraph(streamed.first)), "段落")
    }

    func testStreamingMarksAnUnfinishedMathBlock() {
        XCTAssertTrue(MarkdownDocument("$$\n\\frac{1}{2}", streaming: true).openMathAtEnd)
        XCTAssertFalse(MarkdownDocument("$$\n\\frac{1}{2}\n$$", streaming: true).openMathAtEnd)
        XCTAssertFalse(MarkdownDocument("$$\n\\frac{1}{2}").openMathAtEnd)
        XCTAssertEqual(MarkdownDocument("$$\n\\frac{1}{2}", streaming: true).blocks, [.math("\\frac{1}{2}")])
    }

    func testStreamingDocumentsNeverShowRawMarkers() {
        XCTAssertEqual(MarkdownDocument("```python\nprint(1)", streaming: true).blocks, [.code(language: "python", code: "print(1)")])
        let bold = paragraph(MarkdownDocument("これは**重要", streaming: true).blocks.first)
        XCTAssertEqual(plain(bold), "これは重要")
        XCTAssertTrue(intent(of: "重要", in: bold)?.contains(.stronglyEmphasized) == true)
        // Every prefix of a rich reply parses into blocks without raw syntax.
        let reply = Self.richReply
        var prefix = ""
        for character in reply {
            prefix.append(character)
            for chunk in MarkdownSource.chunks(prefix).suffix(1) {
                let blocks = MarkdownDocument(chunk, streaming: true).blocks
                let text = blocks.map(Self.visibleText).joined()
                XCTAssertFalse(text.contains("**"), "Raw bold in \(prefix.debugDescription)")
                XCTAssertFalse(text.contains("```"), "Raw fence in \(prefix.debugDescription)")
                XCTAssertFalse(text.contains("](http"), "Raw link in \(prefix.debugDescription)")
            }
        }
    }

    static func visibleText(_ block: MarkdownBlock) -> String {
        switch block {
        case .paragraph(let text), .heading(_, let text): return String(text.characters)
        case .quote(let blocks): return blocks.map(visibleText).joined()
        case .list(_, let items): return items.flatMap(\.blocks).map(visibleText).joined()
        case .table(let table): return (table.header + table.rows.flatMap { $0 }).map { String($0.characters) }.joined()
        default: return ""
        }
    }

    static let richReply = """
    ## まとめ

    **「おすすめ」**は次のとおりです。詳しくは[公式サイト](https://example.com)へ。

    1. **準備**：`brew install` を実行
    2. 確認
       - [x] 完了
       - [ ] 未完了

    | 項目 | 値 |
    |:--|--:|
    | 速度 | **速い** |

    ```swift
    let total = items.reduce(0, +) // 合計
    ```

    > 引用の中の *強調*

    式 $E=mc^2$ と

    $$
    \\int_0^1 x\\,dx
    $$
    """

    // MARK: Chunks

    func testChunksSplitAtTopLevelBlocksOnly() {
        XCTAssertEqual(MarkdownSource.chunks("段落1\n\n段落2"), ["段落1", "段落2"])
        XCTAssertEqual(MarkdownSource.chunks("```\na\n\nb\n```\n\n後"), ["```\na\n\nb\n```", "後"])
        XCTAssertEqual(MarkdownSource.chunks("- a\n\n- b\n\n次"), ["- a\n\n- b", "次"])
        XCTAssertEqual(MarkdownSource.chunks("1. a\n\n    続き\n\n次"), ["1. a\n\n    続き", "次"])
        XCTAssertEqual(MarkdownSource.chunks("$$\nx\n\ny\n$$\n\n後"), ["$$\nx\n\ny\n$$", "後"])
        XCTAssertEqual(MarkdownSource.chunks("a\r\n\r\nb\n\n\n"), ["a", "b"])
    }

    func testChunkedRichReplyMatchesTheWholeReply() {
        let whole = MarkdownDocument(Self.richReply).blocks
        let chunked = MarkdownSource.chunks(Self.richReply).flatMap { MarkdownDocument($0).blocks }
        XCTAssertEqual(chunked.count, whole.count)
        XCTAssertEqual(chunked.map(Self.visibleText), whole.map(Self.visibleText))
    }

    func testReferenceLinksResolveAcrossChunks() {
        let source = "[公式][1]を見て\n\n段落\n\n[1]: https://example.com"
        let references = MarkdownSource.referenceDefinitions(source)
        XCTAssertEqual(references, "[1]: https://example.com")
        let first = paragraph(MarkdownDocument(MarkdownSource.chunks(source)[0], references: references).blocks.first)
        XCTAssertEqual(first.range(of: "公式").flatMap { first[$0].runs.first?.link }?.host, "example.com")
    }

    func testFootnoteDefinitionStaysVisible() {
        XCTAssertEqual(plain(paragraph(MarkdownDocument("[^1]: 注釈").blocks.first)), "[^1]: 注釈")
    }

    func testLongReplyParsesQuickly() {
        let reply = String(repeating: Self.richReply + "\n\n", count: 40)
        let start = Date()
        let blocks = MarkdownSource.chunks(reply).flatMap { MarkdownDocument($0).blocks }
        XCTAssertGreaterThan(blocks.count, 300)
        XCTAssertLessThan(Date().timeIntervalSince(start), 3)
    }

    /// Prints how Foundation splits a few inputs into runs, for reading CI logs.
    func testDumpFoundationRuns() throws {
        let options = AttributedString.MarkdownParsingOptions(
            allowsExtendedAttributes: false, interpretedSyntax: .full,
            failurePolicy: .returnPartiallyParsedIfPossible, languageCode: nil)
        for source in ["a\nb", "a  \nb", "x\n\n---\n\ny", "3. c\n4. d", "- [x] a\n  - b", "| a | b |\n|:-:|--:|\n| 1 | 2 |", "~~s~~ ~t~", "> q\n>\n> r",
                       "<div>\nこんにちは\n</div>\n\n後", "p\n\n    code\n    more", "\\[注]: 日本語", "```math title=x\na\n```"] {
            let parsed = try AttributedString(markdown: source, options: options)
            var lines = ["MD-DUMP \(source.debugDescription)"]
            for run in parsed.runs {
                let intents = run.presentationIntent?.components.map { "\($0.kind)#\($0.identity)" } ?? []
                lines.append("  \(String(parsed[run.range].characters).debugDescription) inline=\(run.inlinePresentationIntent.map { String($0.rawValue) } ?? "-") blocks=\(intents)")
            }
            print(lines.joined(separator: "\n"))
        }
    }
}
