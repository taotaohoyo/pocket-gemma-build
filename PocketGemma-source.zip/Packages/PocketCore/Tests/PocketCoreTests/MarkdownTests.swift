import XCTest
@testable import PocketCore

final class MarkdownTests: XCTestCase {
    private func plain(_ text: AttributedString) -> String { String(text.characters) }

    private func paragraph(_ block: MarkdownBlock?, file: StaticString = #filePath, line: UInt = #line) -> AttributedString {
        guard case .paragraph(let text)? = block else {
            XCTFail("Expected a paragraph, got \(String(describing: block))", file: file, line: line)
            return AttributedString()
        }
        return text
    }

    private func intent(of word: String, in text: AttributedString) -> InlinePresentationIntent? {
        guard let range = text.range(of: word) else { return nil }
        return text[range].runs.first?.inlinePresentationIntent
    }

    func testPlainReplyStaysOneParagraphWithTheSameText() {
        let reply = "これはUI検証用のサンプル会話です。実際のAI推論は実行していません。"
        let blocks = MarkdownDocument(reply).blocks
        XCTAssertEqual(blocks.count, 1)
        XCTAssertEqual(plain(paragraph(blocks.first)), reply)
    }

    func testHeadingsEmphasisStrikethroughAndInlineCode() {
        let blocks = MarkdownDocument("# 見出し\n\n**太字** と *斜体* と ~~取り消し~~ と `code`").blocks
        guard case .heading(let level, let title)? = blocks.first else { return XCTFail("\(blocks)") }
        XCTAssertEqual(level, 1)
        XCTAssertEqual(plain(title), "見出し")
        let text = paragraph(blocks.dropFirst().first)
        XCTAssertEqual(plain(text), "太字 と 斜体 と 取り消し と code")
        XCTAssertTrue(intent(of: "太字", in: text)?.contains(.stronglyEmphasized) == true)
        XCTAssertTrue(intent(of: "斜体", in: text)?.contains(.emphasized) == true)
        XCTAssertTrue(intent(of: "取り消し", in: text)?.contains(.strikethrough) == true)
        XCTAssertTrue(intent(of: "code", in: text)?.contains(.code) == true)
    }

    /// Gemma writes `**「…」**とか`; CommonMark alone leaves the asterisks.
    func testEmphasisNextToJapanesePunctuation() {
        let text = paragraph(MarkdownDocument("もしよろしければ、**「〇〇についてのクイズを出して」**とか、これは**「重要」**です。").blocks.first)
        XCTAssertEqual(plain(text), "もしよろしければ、「〇〇についてのクイズを出して」とか、これは「重要」です。")
        XCTAssertTrue(intent(of: "「〇〇についてのクイズを出して」", in: text)?.contains(.stronglyEmphasized) == true)
        XCTAssertTrue(intent(of: "「重要」", in: text)?.contains(.stronglyEmphasized) == true)
        XCTAssertFalse(plain(text).contains("\u{200A}"))
    }

    func testSingleLineBreaksAreKept() {
        XCTAssertEqual(plain(paragraph(MarkdownDocument("一行目\n二行目").blocks.first)), "一行目\n二行目")
    }

    func testNestedOrderedListsAndChecklists() {
        let source = "1. 準備\n2. 実行\n   - 確認\n   - [x] 完了\n   - [ ] 未完了"
        guard case .list(let ordered, let items)? = MarkdownDocument(source).blocks.first else {
            return XCTFail("\(MarkdownDocument(source).blocks)")
        }
        XCTAssertTrue(ordered)
        XCTAssertEqual(items.map(\.ordinal), [1, 2])
        XCTAssertEqual(plain(paragraph(items[0].blocks.first)), "準備")
        guard case .list(let nestedOrdered, let nested)? = items[1].blocks.last else { return XCTFail("\(items[1].blocks)") }
        XCTAssertFalse(nestedOrdered)
        XCTAssertEqual(nested.map(\.checked), [nil, true, false])
        XCTAssertEqual(nested.map { plain(paragraph($0.blocks.first)) }, ["確認", "完了", "未完了"])
    }

    func testOrderedListKeepsItsStartNumber() {
        guard case .list(_, let items)? = MarkdownDocument("3. 三\n4. 四").blocks.first else { return XCTFail() }
        XCTAssertEqual(items.map(\.ordinal), [3, 4])
    }

    func testQuoteRuleAndFollowingParagraph() {
        let blocks = MarkdownDocument("> 引用\n> 続き\n\n---\n\n後").blocks
        XCTAssertEqual(blocks.count, 3, "\(blocks)")
        guard case .quote(let inner)? = blocks.first else { return XCTFail("\(blocks)") }
        XCTAssertEqual(plain(paragraph(inner.first)), "引用\n続き")
        XCTAssertEqual(blocks.dropFirst().first, .rule)
        XCTAssertEqual(plain(paragraph(blocks.last)), "後")
    }

    func testTableCellsAndAlignment() {
        let source = "| 名前 | 値 |\n|:--|--:|\n| a | **1** |\n| b | 2 |"
        guard case .table(let table)? = MarkdownDocument(source).blocks.first else {
            return XCTFail("\(MarkdownDocument(source).blocks)")
        }
        XCTAssertEqual(table.alignments, [.leading, .trailing])
        XCTAssertEqual(table.header.map(plain), ["名前", "値"])
        XCTAssertEqual(table.rows.map { $0.map(plain) }, [["a", "1"], ["b", "2"]])
        XCTAssertTrue(intent(of: "1", in: table.rows[0][1])?.contains(.stronglyEmphasized) == true)
    }

    func testCodeBlockKeepsItsTextExactly() {
        let code = "let x = \"**not bold**\" // $x$\n\n  indented"
        XCTAssertEqual(MarkdownDocument("```Swift\n\(code)\n```").blocks, [.code(language: "swift", code: code)])
        XCTAssertEqual(MarkdownDocument("```\nplain\n```").blocks, [.code(language: nil, code: "plain")])
    }

    func testInlineAndBlockMath() {
        let blocks = MarkdownDocument("式は $E=mc^2$ と $a_1 * b_2$ です。\n\n$$\n\\frac{a}{b}\n$$\n\n\\[ x^2 \\]\n\n$$ y_1 $$").blocks
        let text = paragraph(blocks.first)
        XCTAssertEqual(plain(text), "式は E=mc^2 と a_1 * b_2 です。")
        let math = text.runs.compactMap { $0[MarkdownMathAttribute.self] }
        XCTAssertEqual(math, [MarkdownMath(latex: "E=mc^2", display: false), MarkdownMath(latex: "a_1 * b_2", display: false)])
        XCTAssertEqual(Array(blocks.dropFirst()), [.math("\\frac{a}{b}"), .math("x^2"), .math("y_1")])
    }

    func testPricesAndCodeAreNotMath() {
        let text = paragraph(MarkdownDocument("価格は$5と$10です。`$x$` はコード。").blocks.first)
        XCTAssertEqual(plain(text), "価格は$5と$10です。$x$ はコード。")
        XCTAssertTrue(text.runs.allSatisfy { $0[MarkdownMathAttribute.self] == nil })
    }

    func testLinksAreLimitedToWebAndMail() {
        let text = paragraph(MarkdownDocument("[公式](https://example.com) [危険](javascript:alert(1)) [ファイル](file:///etc/passwd) [メール](mailto:a@example.com) https://www.apple.com を見て").blocks.first)
        func link(_ word: String) -> URL? { text.range(of: word).flatMap { text[$0].runs.first?.link } }
        XCTAssertEqual(link("公式")?.absoluteString, "https://example.com")
        XCTAssertNil(link("危険"))
        XCTAssertNil(link("ファイル"))
        XCTAssertEqual(link("メール")?.scheme, "mailto")
        XCTAssertEqual(link("https://www.apple.com")?.host, "www.apple.com")
    }

    func testImagesBecomeBlocksOfTheirOwn() {
        let blocks = MarkdownDocument("説明\n\n![猫の写真](https://example.com/cat.png)").blocks
        XCTAssertEqual(plain(paragraph(blocks.first)), "説明")
        XCTAssertEqual(blocks.last, .image(url: URL(string: "https://example.com/cat.png"), alt: "猫の写真"))
        XCTAssertTrue(MarkdownLinkPolicy.isLoadableImage(URL(string: "https://example.com/cat.png")!))
        XCTAssertFalse(MarkdownLinkPolicy.isLoadableImage(URL(string: "http://example.com/cat.png")!))
        XCTAssertFalse(MarkdownLinkPolicy.isLoadableImage(URL(string: "file:///tmp/cat.png")!))
    }

    func testRawHTMLIsShownAsText() {
        let blocks = MarkdownDocument("<b>太字</b> と <script>alert(1)</script>").blocks
        let text = blocks.map { block -> String in
            if case .paragraph(let text) = block { return plain(text) }
            return ""
        }.joined()
        XCTAssertTrue(text.contains("太字"), text)
        XCTAssertTrue(text.contains("alert(1)"), text)
    }

    // MARK: Streaming

    func testStreamingClosesOrHoldsBackUnfinishedSyntax() {
        XCTAssertEqual(MarkdownSource.repairStreaming("```python\nprint(1)"), "```python\nprint(1)\n```")
        XCTAssertEqual(MarkdownSource.repairStreaming("テキスト **"), "テキスト")
        XCTAssertEqual(MarkdownSource.repairStreaming("これは**重要"), "これは**重要**")
        XCTAssertEqual(MarkdownSource.repairStreaming("`let x"), "`let x`")
        XCTAssertEqual(MarkdownSource.repairStreaming("詳しくは[公式サイト](https://exa"), "詳しくは公式サイト")
        XCTAssertEqual(MarkdownSource.repairStreaming("写真\n![猫](https://ex"), "写真\n")
        XCTAssertEqual(MarkdownSource.repairStreaming("| a | b |\n|---|---|\n| 1 | 2 |\n| 3"), "| a | b |\n|---|---|\n| 1 | 2 |")
        XCTAssertEqual(MarkdownSource.repairStreaming("説明\n| a | b |\n| --"), "説明")
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n-"), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("段落\n2"), "段落")
        XCTAssertEqual(MarkdownSource.repairStreaming("$$\n\\frac{1}{2}"), "$$\n\\frac{1}{2}\n$$")
        XCTAssertEqual(MarkdownSource.repairStreaming("> ```\n> code"), "> ```\n> code\n> ```")
    }

    func testStreamingDocumentsNeverShowRawMarkers() {
        XCTAssertEqual(MarkdownDocument("```python\nprint(1)", streaming: true).blocks, [.code(language: "python", code: "print(1)")])
        let bold = paragraph(MarkdownDocument("これは**重要", streaming: true).blocks.first)
        XCTAssertEqual(plain(bold), "これは重要")
        XCTAssertTrue(intent(of: "重要", in: bold)?.contains(.stronglyEmphasized) == true)
        // Every prefix of a rich reply parses into blocks without raw syntax.
        let reply = Self.richReply
        var prefix = ""
        for character in reply {
            prefix.append(character)
            for chunk in MarkdownSource.chunks(prefix).suffix(1) {
                let blocks = MarkdownDocument(chunk, streaming: true).blocks
                let text = blocks.map(Self.visibleText).joined()
                XCTAssertFalse(text.contains("**"), "Raw bold in \(prefix.debugDescription)")
                XCTAssertFalse(text.contains("```"), "Raw fence in \(prefix.debugDescription)")
                XCTAssertFalse(text.contains("](http"), "Raw link in \(prefix.debugDescription)")
            }
        }
    }

    static func visibleText(_ block: MarkdownBlock) -> String {
        switch block {
        case .paragraph(let text), .heading(_, let text): return String(text.characters)
        case .quote(let blocks): return blocks.map(visibleText).joined()
        case .list(_, let items): return items.flatMap(\.blocks).map(visibleText).joined()
        case .table(let table): return (table.header + table.rows.flatMap { $0 }).map { String($0.characters) }.joined()
        default: return ""
        }
    }

    static let richReply = """
    ## まとめ

    **「おすすめ」**は次のとおりです。詳しくは[公式サイト](https://example.com)へ。

    1. **準備**：`brew install` を実行
    2. 確認
       - [x] 完了
       - [ ] 未完了

    | 項目 | 値 |
    |:--|--:|
    | 速度 | **速い** |

    ```swift
    let total = items.reduce(0, +) // 合計
    ```

    > 引用の中の *強調*

    式 $E=mc^2$ と

    $$
    \\int_0^1 x\\,dx
    $$
    """

    // MARK: Chunks

    func testChunksSplitAtTopLevelBlocksOnly() {
        XCTAssertEqual(MarkdownSource.chunks("段落1\n\n段落2"), ["段落1", "段落2"])
        XCTAssertEqual(MarkdownSource.chunks("```\na\n\nb\n```\n\n後"), ["```\na\n\nb\n```", "後"])
        XCTAssertEqual(MarkdownSource.chunks("- a\n\n- b\n\n次"), ["- a\n\n- b", "次"])
        XCTAssertEqual(MarkdownSource.chunks("1. a\n\n    続き\n\n次"), ["1. a\n\n    続き", "次"])
        XCTAssertEqual(MarkdownSource.chunks("$$\nx\n\ny\n$$\n\n後"), ["$$\nx\n\ny\n$$", "後"])
        XCTAssertEqual(MarkdownSource.chunks("a\r\n\r\nb\n\n\n"), ["a", "b"])
    }

    func testChunkedRichReplyMatchesTheWholeReply() {
        let whole = MarkdownDocument(Self.richReply).blocks
        let chunked = MarkdownSource.chunks(Self.richReply).flatMap { MarkdownDocument($0).blocks }
        XCTAssertEqual(chunked.count, whole.count)
        XCTAssertEqual(chunked.map(Self.visibleText), whole.map(Self.visibleText))
    }

    func testReferenceLinksResolveAcrossChunks() {
        let source = "[公式][1]を見て\n\n段落\n\n[1]: https://example.com"
        let references = MarkdownSource.referenceDefinitions(source)
        XCTAssertEqual(references, "[1]: https://example.com")
        let first = paragraph(MarkdownDocument(MarkdownSource.chunks(source)[0], references: references).blocks.first)
        XCTAssertEqual(first.range(of: "公式").flatMap { first[$0].runs.first?.link }?.host, "example.com")
    }

    func testFootnoteDefinitionStaysVisible() {
        XCTAssertEqual(plain(paragraph(MarkdownDocument("[^1]: 注釈").blocks.first)), "[^1]: 注釈")
    }

    func testLongReplyParsesQuickly() {
        let reply = String(repeating: Self.richReply + "\n\n", count: 40)
        let start = Date()
        let blocks = MarkdownSource.chunks(reply).flatMap { MarkdownDocument($0).blocks }
        XCTAssertGreaterThan(blocks.count, 300)
        XCTAssertLessThan(Date().timeIntervalSince(start), 3)
    }

    /// Prints how Foundation splits a few inputs into runs, for reading CI logs.
    func testDumpFoundationRuns() throws {
        let options = AttributedString.MarkdownParsingOptions(
            allowsExtendedAttributes: false, interpretedSyntax: .full,
            failurePolicy: .returnPartiallyParsedIfPossible, languageCode: nil)
        for source in ["a\nb", "a  \nb", "x\n\n---\n\ny", "3. c\n4. d", "- [x] a\n  - b", "| a | b |\n|:-:|--:|\n| 1 | 2 |", "~~s~~ ~t~", "> q\n>\n> r"] {
            let parsed = try AttributedString(markdown: source, options: options)
            var lines = ["MD-DUMP \(source.debugDescription)"]
            for run in parsed.runs {
                let intents = run.presentationIntent?.components.map { "\($0.kind)#\($0.identity)" } ?? []
                lines.append("  \(String(parsed[run.range].characters).debugDescription) inline=\(run.inlinePresentationIntent.map { String($0.rawValue) } ?? "-") blocks=\(intents)")
            }
            print(lines.joined(separator: "\n"))
        }
    }
}
