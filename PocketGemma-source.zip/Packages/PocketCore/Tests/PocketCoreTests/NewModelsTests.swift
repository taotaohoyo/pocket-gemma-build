import XCTest
@testable import PocketCore

/// Phi-4-mini-reasoning and Qwen3.5 4B (1.1.0 (205), the user's directive
/// of 22:19 UTC 2026-10-26): open to everyone beside the others, text only,
/// downloaded on demand from pinned files.
final class NewModelsTests: XCTestCase {
    func testBothArePinnedAndOpenToEveryone() {
        for spec in [ModelSpec.phi4MiniReasoning, .qwen35] {
            XCTAssertEqual(ModelSpec.find(spec.id)?.id, spec.id)
            XCTAssertTrue(ModelSpec.visibleCatalog(developer: false).contains { $0.id == spec.id })
            XCTAssertFalse(spec.isLocked); XCTAssertFalse(spec.isDeveloperOnly)
            // Never the first launch's setup or the automatic choice.
            XCTAssertFalse(spec.isStarter)
            XCTAssertEqual(spec.sha256.count, 64)
            XCTAssertTrue(spec.downloadURL.absoluteString.hasPrefix("https://huggingface.co/litert-community/"))
            XCTAssertTrue(spec.downloadURL.absoluteString.contains("/resolve/"))
            XCTAssertFalse(spec.downloadURL.absoluteString.contains("/resolve/main/"), "a fixed revision")
            XCTAssertGreaterThan(spec.byteCount, 2_000_000_000)
            // Text only: no photos, videos or files are offered.
            let policy = ModelAttachmentPolicy(model: spec)
            XCTAssertFalse(policy.allowsAnyAttachment); XCTAssertFalse(policy.allowsVideo); XCTAssertFalse(spec.supportsVision)
            XCTAssertEqual(policy.summary, "テキスト")
            XCTAssertFalse(spec.supportsWebSearch); XCTAssertFalse(spec.supportsSpeculation)
            XCTAssertEqual(spec.maximumContextTokens, 4096)
        }
        // Phi's later turns were unsteady on the CPU, so it says it is a test version.
        XCTAssertTrue(ModelSpec.phi4MiniReasoning.isTestVersion); XCTAssertFalse(ModelSpec.qwen35.isTestVersion)
        XCTAssertEqual(ModelSpec.phi4MiniReasoning.family, "Phi")
        XCTAssertEqual(ModelSpec.qwen35.family, "Qwen")
        let roomy = DeviceCapacity(memoryBytes: 64_000_000_000, freeDiskBytes: 500_000_000_000, processorCount: 12, isPad: true)
        XCTAssertEqual(ModelRecommendation.recommended(for: roomy, includeDeveloperModels: false)?.id, ModelSpec.e4b.id)
    }

    /// Phi thinks before every answer, whatever the switch says, with room
    /// of its own: 1,536 of its 4,096 tokens, so the thinking and the answer
    /// have the 2,048 its card asks for, and a turn's input 1,536.
    func testPhiAlwaysThinksWithRoomOfItsOwn() {
        let phi = ModelSpec.phi4MiniReasoning
        XCTAssertTrue(phi.capabilities.reasons)
        var settings = GenerationSettings(for: phi)
        XCTAssertEqual(settings.backend, .cpu, "starts on the CPU")
        XCTAssertTrue(phi.supportsGPU && phi.supportsCPU, "both can be chosen")
        settings.enableThinking = false
        let normalized = settings.normalized(for: phi)
        XCTAssertTrue(normalized.thinks(on: phi))
        XCTAssertEqual(normalized.thinkingTokenBudget(on: phi), 1536)
        XCTAssertEqual(settings.thinkingTokenBudget(on: phi), 1536, "the same before normalizing")
        XCTAssertEqual(normalized.reasoningTokens, 1536)
        XCTAssertEqual(normalized.inputTokenLimit, 4096 - 512 - 512 - 1536)
        XCTAssertGreaterThanOrEqual(normalized.thinkingTokenBudget(on: phi) + normalized.maxOutputTokens, 2048)
        // A GPU chosen by hand stays.
        settings.backend = .gpu
        XCTAssertEqual(settings.normalized(for: phi).backend, .gpu)
        // A smaller context keeps the same share.
        var small = settings; small.maxTokens = 2048
        XCTAssertEqual(small.normalized(for: phi).reasoningTokens, 768)
    }

    /// Qwen3.5 4B: CPU only (its card measured 5.74 GB on an iPhone's GPU),
    /// thinking only when switched on.
    func testQwen35RunsOnTheCPU() {
        let qwen = ModelSpec.qwen35
        XCTAssertFalse(qwen.supportsGPU); XCTAssertTrue(qwen.supportsCPU)
        XCTAssertFalse(qwen.capabilities.reasons)
        var settings = GenerationSettings(for: qwen)
        XCTAssertEqual(settings.backend, .cpu)
        settings.backend = .gpu
        XCTAssertEqual(settings.normalized(for: qwen).backend, .cpu, "a saved GPU never reaches it")
        XCTAssertFalse(settings.normalized(for: qwen).thinks(on: qwen), "thinking off unless switched on")
        settings.enableThinking = true
        XCTAssertTrue(settings.normalized(for: qwen).thinks(on: qwen))
        XCTAssertEqual(settings.normalized(for: qwen).reasoningTokens, 0)
        XCTAssertEqual(settings.normalized(for: qwen).inputTokenLimit, 4096 - 512 - 512)
    }

    /// The models before 205 keep their settings and engines.
    func testEarlierModelsAreUnchanged() {
        for spec in [ModelSpec.e4b, .e2b, .gemma12B, .qwen3, .qwen25] {
            XCTAssertFalse(spec.capabilities.reasons, spec.id)
            XCTAssertTrue(spec.capabilities.startsOnGPU, spec.id)
            let settings = GenerationSettings(for: spec).normalized(for: spec)
            XCTAssertEqual(settings.backend, .gpu, spec.id)
            XCTAssertEqual(settings.reasoningTokens, 0, spec.id)
            XCTAssertEqual(settings.thinkingTokenBudget(on: spec), 0, spec.id)
        }
        XCTAssertEqual(GenerationSettings(for: .e2b).normalized(for: .e2b).inputTokenLimit, 4096 - 512 - 512)
        XCTAssertEqual(ModelSpec.gemma12B.capabilities.gpuBenchmarkMode, true)
    }
}
