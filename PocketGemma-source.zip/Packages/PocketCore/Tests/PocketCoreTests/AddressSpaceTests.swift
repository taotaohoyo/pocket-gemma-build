import XCTest
@testable import PocketCore

final class AddressSpaceTests: XCTestCase {
    func testGapsBetweenRegionsInAddressOrder() {
        var counter = AddressSpace.GapCounter(low: 100, high: 1000)
        XCTAssertTrue(counter.add(start: 100, end: 200))
        XCTAssertTrue(counter.add(start: 250, end: 300))
        XCTAssertTrue(counter.add(start: 280, end: 320), "An overlapping entry leaves no gap")
        XCTAssertTrue(counter.add(start: 600, end: 700))
        XCTAssertFalse(counter.add(start: 1000, end: 1100), "Past the end of the range")
        let result = counter.finish()
        XCTAssertEqual(result.free, 50 + 280 + 300)
        XCTAssertEqual(result.largest, 300)
        XCTAssertEqual(counter.regions, 4)
    }

    func testThisProcessHasARangeAndFreeSpace() throws {
        let space = try XCTUnwrap(AddressSpace.current())
        XCTAssertGreaterThan(space.range, 0)
        XCTAssertGreaterThan(space.regions, 0)
        XCTAssertGreaterThan(space.largestFree, 0)
        XCTAssertLessThanOrEqual(space.largestFree, space.free)
        XCTAssertLessThan(space.free, space.range)
    }
}
