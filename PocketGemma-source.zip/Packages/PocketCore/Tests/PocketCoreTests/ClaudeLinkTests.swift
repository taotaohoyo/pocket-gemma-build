import XCTest
@testable import PocketCore

/// Claude (1.1.0 (257)): the relay's address and invites as the relay
/// makes them (claude-relay/src/security.ts and join.ts), which turns a
/// reply is given, and Anthropic's stream as the relay passes it on.
final class ClaudeLinkTests: XCTestCase {
    func testServerIsHTTPSAndAHostAlone() {
        XCTAssertEqual(ClaudeLink.server("https://fielua-claude.example.workers.dev")?.absoluteString,
                       "https://fielua-claude.example.workers.dev")
        XCTAssertEqual(ClaudeLink.server("  fielua-claude.example.workers.dev/ ")?.absoluteString,
                       "https://fielua-claude.example.workers.dev")
        XCTAssertEqual(ClaudeLink.server("HTTPS://Relay.Example.com:8443")?.absoluteString, "https://relay.example.com:8443")
        XCTAssertNil(ClaudeLink.server("http://relay.example.com"), "never plain http to the internet")
        XCTAssertNil(ClaudeLink.server("https://user:pass@relay.example.com"))
        XCTAssertNil(ClaudeLink.server("https://relay.example.com/v1"))
        XCTAssertNil(ClaudeLink.server("https://relay.example.com?x=1"))
        XCTAssertNil(ClaudeLink.server("https://relay.example.com#x"))
        XCTAssertNil(ClaudeLink.server("https://relay"))
        XCTAssertNil(ClaudeLink.server("ftp://relay.example.com"))
        XCTAssertNil(ClaudeLink.server(""))
        XCTAssertNil(ClaudeLink.server("http://127.0.0.1:8787"), "local only for the preview's checks")
        XCTAssertEqual(ClaudeLink.server("http://127.0.0.1:8787", allowsLocal: true)?.absoluteString, "http://127.0.0.1:8787")
        XCTAssertNil(ClaudeLink.server("http://192.168.1.10:8787", allowsLocal: true))
    }

    func testInviteCodesAreReadAsTheRelayReadsThem() {
        XCTAssertEqual(ClaudeLink.code("ABCD-EFGH-JKMN-PQRS"), "ABCDEFGHJKMNPQRS")
        XCTAssertEqual(ClaudeLink.code("abcd efgh jkmn pqrs"), "ABCDEFGHJKMNPQRS")
        XCTAssertEqual(ClaudeLink.code("0OIL-1111-2222-3333"), "0011111122223333")
        XCTAssertNil(ClaudeLink.code("ABCD-EFGH-JKMN-PQR"), "15 characters")
        XCTAssertNil(ClaudeLink.code("ABCD-EFGH-JKMN-PQRU"), "U is not in the alphabet")
        XCTAssertNil(ClaudeLink.code("ABCD-EFGH-JKMN-PQR!"))
        XCTAssertEqual(ClaudeLink.grouped("ABCDEFGHJKMNPQRS"), "ABCD-EFGH-JKMN-PQRS")
    }

    func testInvitesFromFieluaForTheWebAndTheCodeAlone() {
        let web = ClaudeInvite("https://suelira.com/chat/#invite=ABCD-EFGH-JKMN-PQRS")
        XCTAssertEqual(web?.server, ClaudeLink.webRelay)
        XCTAssertEqual(web?.code, "ABCDEFGHJKMNPQRS")
        XCTAssertEqual(ClaudeInvite("https://www.suelira.com/chat/index.html#invite=ABCDEFGHJKMNPQRS"), web)
        XCTAssertEqual(ClaudeInvite("  abcd-efgh-jkmn-pqrs\n"), web, "the code alone")
        XCTAssertEqual(ClaudeInvite("https://fielua-claude.suelira.workers.dev/join#ABCD-EFGH-JKMN-PQRS"), web)
        XCTAssertNil(ClaudeInvite("http://suelira.com/chat/#invite=ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("https://suelira.com/other/#invite=ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("https://suelira.com/chat/#ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("https://evil.example.com/chat/#invite=ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("ABCD-EFGH"), "too short")
    }

    func testInvitesFromTheAppLinkAndThePageLink() {
        let app = ClaudeInvite("fielua://claude?server=https%3A%2F%2Ffielua-claude.example.workers.dev&code=ABCD-EFGH-JKMN-PQRS")
        XCTAssertEqual(app?.server.absoluteString, "https://fielua-claude.example.workers.dev")
        XCTAssertEqual(app?.code, "ABCDEFGHJKMNPQRS")
        XCTAssertEqual(app?.host, "fielua-claude.example.workers.dev")
        let page = ClaudeInvite("https://fielua-claude.example.workers.dev/join#ABCD-EFGH-JKMN-PQRS")
        XCTAssertEqual(page, app)
        XCTAssertNil(ClaudeInvite("fielua://claude?server=http%3A%2F%2Fevil.example.com&code=ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("fielua://claude?server=https%3A%2F%2Fa.example.com%2Fpath&code=ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("fielua://claude?server=https%3A%2F%2Fa.example.com&code=SHORT"))
        XCTAssertNil(ClaudeInvite("fielua://pair?server=https%3A%2F%2Fa.example.com&code=ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("https://a.example.com/join"), "no code")
        XCTAssertNil(ClaudeInvite("https://a.example.com/other#ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("https://a.example.com/join?x=1#ABCD-EFGH-JKMN-PQRS"))
        XCTAssertNil(ClaudeInvite("http://a.example.com/join#ABCD-EFGH-JKMN-PQRS"))
        XCTAssertEqual(ClaudeInvite("http://127.0.0.1:8787/join#ABCD-EFGH-JKMN-PQRS", allowsLocal: true)?.server.absoluteString,
                       "http://127.0.0.1:8787")
    }

    private func exchange(_ question: String, _ answer: String, state: ReplyState = .complete,
                          attachments: [ChatAttachment] = []) -> [ChatMessage] {
        [ChatMessage(role: .user, text: question, attachments: attachments),
         ChatMessage(role: .assistant, text: answer, state: state)]
    }

    func testContextSendsCompleteTextExchangesAndTheQuestion() {
        let photo = ChatAttachment(kind: .image, name: "写真.jpg", storedName: "p.jpg")
        let history = exchange("一", "いち") + exchange("写真", "見えます", attachments: [photo])
            + exchange("二", "に", state: .failed) + exchange("三", "途中", state: .stopped)
            + exchange("  ", "空白") + exchange("四", "よん")
        let turns = ClaudeContext.turns(history: history, question: "五")
        XCTAssertEqual(turns.map(\.role), ["user", "assistant", "user", "assistant", "user"])
        XCTAssertEqual(turns.map(\.content), ["一", "いち", "四", "よん", "五"])
    }

    func testContextStaysWithinTheRelaysLimits() {
        let long = String(repeating: "あ", count: 10_000)  // 30,000 bytes
        let history = (1...10).flatMap { exchange("問\($0)", long) }
        let turns = ClaudeContext.turns(history: history, question: "最後")
        XCTAssertEqual(turns.count, 7, "three exchanges fit 96 KB")
        XCTAssertEqual(turns.first?.content, "問8")
        XCTAssertLessThanOrEqual(turns.reduce(0) { $0 + $1.content.utf8.count }, ClaudeContext.byteBudget)
        // A reply larger than a turn may be ends the context there.
        let huge = String(repeating: "い", count: 21_000)  // 63,000 bytes
        let cut = ClaudeContext.turns(history: exchange("古い", "古い答え") + exchange("大きい", huge) + exchange("新しい", "新しい答え"),
                                      question: "最後")
        XCTAssertEqual(cut.map(\.content), ["新しい", "新しい答え", "最後"])
        let many = (1...40).flatMap { exchange("問\($0)", "答\($0)") }
        let few = ClaudeContext.turns(history: many, question: "最後")
        XCTAssertLessThanOrEqual(few.count, ClaudeContext.maxMessages)
        XCTAssertEqual(few.count % 2, 1)
        XCTAssertEqual(few.last?.content, "最後")
    }

    func testChatThreadKeepsItsClaudeAndOlderArchivesHaveNone() throws {
        var thread = ChatThread(modelID: "gemma-4-e4b")
        XCTAssertFalse(thread.isRemote)
        thread.claude = .fallback
        XCTAssertTrue(thread.isRemote)
        let decoded = try JSONDecoder().decode(ChatThread.self, from: JSONEncoder().encode(thread))
        XCTAssertEqual(decoded.claude, ClaudeChatTarget(model: "claude-opus-5-5", modelName: "Claude Opus 5.5", effort: .medium))
        var old = try JSONSerialization.jsonObject(with: JSONEncoder().encode(thread)) as! [String: Any]
        old.removeValue(forKey: "claude")
        let older = try JSONDecoder().decode(ChatThread.self, from: JSONSerialization.data(withJSONObject: old))
        XCTAssertNil(older.claude)
        XCTAssertFalse(older.isRemote)
        // A Claude chat from before levels: the model's default. A level
        // this version doesn't know (max) leaves it there too.
        for effort in [nil, "max", 3] as [Any?] {
            var target: [String: Any] = ["model": "claude-sonnet-5-5", "modelName": "Claude Sonnet 5.5"]
            if let effort { target["effort"] = effort }
            var json = try JSONSerialization.jsonObject(with: JSONEncoder().encode(thread)) as! [String: Any]
            json["claude"] = target
            let chat = try JSONDecoder().decode(ChatThread.self, from: JSONSerialization.data(withJSONObject: json))
            XCTAssertEqual(chat.claude?.model, "claude-sonnet-5-5")
            XCTAssertNil(chat.claude?.effort)
        }
    }

    func testFormerClaudeModelGoesOnInItsChat() {
        // Claude Fable 5.2 took Fable 5.1's place (2026-11-10): the relay no
        // longer offers 5.1 but still takes it.
        let offered = ClaudeModel.builtIn
        XCTAssertEqual(ClaudeModel.former.map(\.model.id), ["claude-fable-5-1"])
        XCTAssertFalse(offered.contains { $0.id == "claude-fable-5-1" }, "5.1 is not offered")
        // A chat begun with 5.1 keeps it, at every level Fielua offers.
        let old = ClaudeModel.forChat("claude-fable-5-1", offered: offered)
        XCTAssertEqual(old?.name, "Claude Fable 5.1")
        XCTAssertEqual(old?.efforts, [.low, .medium, .high, .xhigh])
        XCTAssertEqual(ClaudeModel.forChat("claude-sonnet-5-5", offered: offered)?.id, "claude-sonnet-5-5")
        XCTAssertNil(ClaudeModel.forChat("claude-unknown", offered: offered))
        // A new chat never starts with it: 5.1 chosen last means 5.2.
        XCTAssertEqual(ClaudeModel.forNewChat("claude-fable-5-1", offered: offered)?.id, "claude-fable-5-2")
        XCTAssertEqual(ClaudeModel.forNewChat("claude-haiku-5-5", offered: offered)?.id, "claude-haiku-5-5")
        XCTAssertNil(ClaudeModel.forNewChat("claude-unknown", offered: offered))
        // A relay that offers neither: nothing for a new chat.
        XCTAssertNil(ClaudeModel.forNewChat("claude-fable-5-1", offered: [.opus]))
    }

    func testClaudeModelsAndLevels() {
        XCTAssertEqual(ClaudeEffort.allCases.map(\.rawValue), ["low", "medium", "high", "xhigh"])
        XCTAssertEqual(ClaudeModel.builtIn.map(\.id), ["claude-fable-5-2", "claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"])
        XCTAssertEqual(ClaudeModel.builtIn.map(\.shortName), ["Fable 5.2", "Opus 5.5", "Sonnet 5.5", "Haiku 5.5"])
        XCTAssertEqual(ClaudeModel.builtIn.map(\.defaultEffort), [.high, .medium, .high, .medium])
        // A level the model doesn't take falls back to its default.
        let lowOnly = ClaudeModel(id: "x", name: "Claude X", efforts: [.low], defaultEffort: .low)
        XCTAssertEqual(ClaudeChatTarget(lowOnly, effort: .xhigh).effort, .low)
        XCTAssertEqual(ClaudeChatTarget(.opus).effort, .medium)

        // The relay's list: its order, max and unknown levels left out, a model without levels dropped.
        let relay: [[String: Any]] = [
            ["id": "claude-opus-5-5", "name": "Claude Opus 5.5", "efforts": ["low", "medium", "high", "xhigh", "max"], "defaultEffort": "medium"],
            ["id": "claude-haiku-5-5", "name": "Claude Haiku 5.5", "efforts": ["low", "turbo"], "defaultEffort": "medium"],
            ["id": "claude-next", "name": "Claude Next", "efforts": ["max"], "defaultEffort": "max"],
            ["name": "no id", "efforts": ["low"]],
        ]
        let catalog = ClaudeModel.catalog(relay)
        XCTAssertEqual(catalog?.map(\.id), ["claude-opus-5-5", "claude-haiku-5-5"])
        XCTAssertEqual(catalog?.first?.efforts, [.low, .medium, .high, .xhigh])
        XCTAssertEqual(catalog?.last?.efforts, [.low])
        XCTAssertEqual(catalog?.last?.defaultEffort, .low)
        XCTAssertNil(ClaudeModel.catalog(nil))
        XCTAssertNil(ClaudeModel.catalog("x"))
    }

    func testAnthropicsStreamAsTheRelayPassesItOn() {
        func event(_ json: String) -> ClaudeStreamEvent? { ClaudeStreamEvent(line: "data: " + json) }
        XCTAssertNil(ClaudeStreamEvent(line: "event: message_start"))
        XCTAssertNil(ClaudeStreamEvent(line: ""))
        XCTAssertNil(ClaudeStreamEvent(line: "data: not json"))
        XCTAssertEqual(ClaudeStreamEvent(line: ": keepalive"), .alive)
        XCTAssertEqual(event(#"{"type":"content_block_delta","index":0,"delta":{"type":"thinking_delta","thinking":"要約"}}"#), .thinking)
        XCTAssertEqual(event(#"{"type":"message_start","message":{"id":"msg_1","model":"claude-opus-5-5","content":[]}}"#),
                       .started(model: "claude-opus-5-5"))
        XCTAssertEqual(event(#"{"type":"content_block_start","index":0,"content_block":{"type":"thinking","thinking":""}}"#), .thinking)
        XCTAssertEqual(event(#"{"type":"content_block_delta","index":0,"delta":{"type":"signature_delta","signature":"x"}}"#), .thinking)
        XCTAssertEqual(event(#"{"type":"content_block_start","index":1,"content_block":{"type":"text","text":""}}"#), .textStart(""))
        XCTAssertEqual(event(#"{"type":"content_block_delta","index":1,"delta":{"type":"text_delta","text":"こんにちは"}}"#),
                       .text("こんにちは"))
        XCTAssertEqual(ClaudeStreamEvent(line: #"data:{"type":"content_block_delta","index":1,"delta":{"type":"text_delta","text":"a"}}"#),
                       .text("a"))
        XCTAssertEqual(event(#"{"type":"content_block_start","index":0,"content_block":{"type":"fallback","from":{"model":"a"},"to":{"model":"b"}}}"#),
                       .alive)
        XCTAssertEqual(event(#"{"type":"content_block_stop","index":1}"#), .blockStop(index: 1))
        XCTAssertEqual(event(#"{"type":"ping"}"#), .alive)
        XCTAssertEqual(event(#"{"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":5}}"#), .alive)
        XCTAssertEqual(event(#"{"type":"message_delta","delta":{"stop_reason":"refusal"}}"#), .refused)
        XCTAssertEqual(event(#"{"type":"message_delta","delta":{"stop_reason":"max_tokens"}}"#), .cutOff)
        XCTAssertEqual(event(#"{"type":"message_stop"}"#), .done)
        XCTAssertEqual(event(#"{"type":"error","error":{"type":"overloaded_error","message":"Overloaded"}}"#),
                       .failed(type: "overloaded_error"))
    }
}
