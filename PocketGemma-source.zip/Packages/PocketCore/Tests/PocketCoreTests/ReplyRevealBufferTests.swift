import XCTest
@testable import PocketCore

/// How the characters of a reply's arriving pieces are timed to appear
/// (ReplyRevealBuffer): one after another within a piece, flowing into the
/// next piece, and settled once the last has appeared.
final class ReplyRevealBufferTests: XCTestCase {
    func testCharactersOfAPieceStartOneAfterAnotherAtThePaceOfThePieces() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あい", at: 1.0)
        // Nothing came before the first piece, so it uses the default.
        XCTAssertEqual(reveal.segments[0].stagger, ReplyRevealBuffer.defaultStagger)
        // Four characters 0.04 s after the piece before: they start 0.01 s
        // apart, so the last starts about when the next piece is due.
        reveal.update("あいうえおか", at: 1.04)
        XCTAssertEqual(reveal.segments[1].stagger, 0.01, accuracy: 0.0001)
        XCTAssertEqual(reveal.segments[1].settlesAt, 1.04 + 0.03 + ReplyRevealBuffer.duration, accuracy: 0.0001)
        // One character 0.08 s later: a single character has no stagger to
        // share, and the bound keeps a lone piece from being drawn out.
        reveal.update("あいうえおかき", at: 1.12)
        XCTAssertEqual(reveal.segments[2].stagger, ReplyRevealBuffer.staggerRange.upperBound)
        XCTAssertEqual(reveal.segments[2].settlesAt, 1.12 + ReplyRevealBuffer.duration, accuracy: 0.0001)
    }

    func testABurstAfterAPauseStartsFreshAndNeverTrailsFar() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あ", at: 1)
        // After a long pause the piece is a fresh start at the default pace.
        reveal.update("あ" + String(repeating: "い", count: 3), at: 2)
        XCTAssertEqual(reveal.segments.last?.stagger, ReplyRevealBuffer.defaultStagger)
        // Sixty characters 0.15 s after the piece before would be 2.5 ms
        // apart; the bound keeps 5 ms between characters, so the burst has
        // started within 0.3 s of arriving.
        reveal.update(reveal.text + String(repeating: "う", count: 60), at: 2.15)
        let burst = reveal.segments.last!
        XCTAssertEqual(burst.stagger, ReplyRevealBuffer.staggerRange.lowerBound)
        XCTAssertEqual(burst.settlesAt - burst.arrivedAt, 59 * 0.005 + ReplyRevealBuffer.duration, accuracy: 0.0001)
        // Pieces every millisecond keep at least a small gap between characters.
        reveal.update(reveal.text + "えお", at: 2.151)
        XCTAssertEqual(reveal.segments.last?.stagger, ReplyRevealBuffer.staggerRange.lowerBound)
    }

    func testPiecesSettleInOrderWhenTheirLastCharacterHasAppeared() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あいう", at: 1.0)          // settles at 1 + 0.06 + duration
        reveal.update("あいうえ", at: 1.04)       // settles at 1.04 + duration, earlier than the piece before
        let first = reveal.segments[0], second = reveal.segments[1]
        XCTAssertGreaterThan(first.settlesAt, second.settlesAt)
        // The deadline waits for the last to finish, whichever piece that is.
        XCTAssertEqual(reveal.animationDeadline, first.settlesAt)
        // The earlier piece keeps the later one in the animated text until
        // it has finished, so the settled text stays a prefix.
        reveal.settle(at: second.settlesAt)
        XCTAssertEqual(reveal.segments.count, 2)
        reveal.settle(at: first.settlesAt)
        XCTAssertTrue(reveal.segments.isEmpty)
        XCTAssertEqual(reveal.settledText, "あいうえ")
        XCTAssertNil(reveal.animationDeadline)
    }

    func testAReplacedTextStartsItsClockAgain() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あい", at: 1)
        reveal.update("う", at: 1.02)
        XCTAssertEqual(reveal.settledText, "う")
        XCTAssertTrue(reveal.segments.isEmpty)
        reveal.update("うえ", at: 1.04)
        XCTAssertEqual(reveal.segments.last?.stagger, ReplyRevealBuffer.defaultStagger, "No earlier piece to pace by")
    }
}
