import XCTest
@testable import PocketCore

/// How the characters of a reply's arriving pieces are timed to appear
/// (ReplyRevealBuffer): on one schedule at the pace the text is laid out,
/// across the pieces' boundaries, and settled once the last has appeared.
final class ReplyRevealBufferTests: XCTestCase {
    private let step = 1.0 / 24

    func testCharactersStartEvenlyAcrossPieces() {
        var reveal = ReplyRevealBuffer()
        let pace = 60.0
        var text = ""
        var now = 1.0
        var arrivals: [TimeInterval] = []
        // Steps of two or three characters: 2.5 a step, the pace.
        for count in [2, 3, 2, 3, 2, 3, 3, 2] {
            text += String(repeating: "あ", count: count)
            reveal.update(text, at: now, pace: pace, step: step)
            arrivals.append(now)
            now += step
        }
        let starts = reveal.segments.flatMap { segment in
            (0..<segment.text.count).map { segment.startsAt + Double($0) * segment.spacing }
        }
        XCTAssertEqual(starts.count, 20)
        for (earlier, later) in zip(starts, starts.dropFirst()) {
            XCTAssertEqual(later - earlier, 1 / pace, accuracy: 0.2 / pace, "A piece's boundary is no change of rhythm")
        }
        // No character starts before its piece came, nor far after.
        for (segment, arrival) in zip(reveal.segments, arrivals) {
            XCTAssertGreaterThanOrEqual(segment.startsAt, arrival)
            XCTAssertLessThanOrEqual(segment.lastStartsAt, arrival + ReplyRevealBuffer.furthestLead)
        }
    }

    func testAFreshStartLeadsByHalfAStepAndAPauseStartsAfresh() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あい", at: 1, pace: 60, step: step)
        XCTAssertEqual(reveal.segments[0].startsAt, 1 + ReplyRevealBuffer.freshLead * step, accuracy: 0.0001)
        // The schedule stands two characters on, before 1.1: a piece that
        // comes later than the schedule starts at once.
        reveal.update("あいう", at: 1.1, pace: 60, step: step)
        XCTAssertEqual(reveal.segments.last?.startsAt ?? 0, 1.1, accuracy: 0.0001)
        // After a pause longer than half a second a piece starts afresh
        // (the pieces before have settled by then).
        reveal.update("あいうえお", at: 1.8, pace: 60, step: step)
        XCTAssertEqual(reveal.segments.last?.startsAt ?? 0, 1.8 + ReplyRevealBuffer.freshLead * step, accuracy: 0.0001)
        XCTAssertEqual(reveal.segments.count, 1)
    }

    func testABurstIsSqueezedToStartWithinAQuarterSecond() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あ", at: 1, pace: 12, step: step)
        // Eighty characters at twenty a second would take four seconds to
        // start; they are squeezed to have all started within a quarter.
        reveal.update("あ" + String(repeating: "い", count: 80), at: 1.05, pace: 20, step: step)
        let burst = reveal.segments[1]
        XCTAssertLessThanOrEqual(burst.lastStartsAt, 1.05 + ReplyRevealBuffer.furthestLead + 0.0001)
        XCTAssertGreaterThan(burst.spacing, 0, "Still one after another")
        XCTAssertGreaterThanOrEqual(burst.startsAt, 1.05)
    }

    func testTheSpacingFollowsThePaceWithoutAJump() {
        var reveal = ReplyRevealBuffer()
        var text = ""
        var now = 1.0
        var pace = 40.0
        var carry = 0.0
        var spacings: [TimeInterval] = []
        for _ in 0..<30 {
            carry += pace * step
            let count = Int(carry)
            carry -= Double(count)
            if count > 0 {
                text += String(repeating: "う", count: count)
                reveal.update(text, at: now, pace: pace, step: step)
                spacings.append(reveal.segments.last!.spacing)
            }
            pace = min(pace + 6, 100)
            now += step
        }
        for (earlier, later) in zip(spacings, spacings.dropFirst()) {
            XCTAssertLessThanOrEqual(earlier / later, 1.25, "The spacing shortens gently as the pace rises")
            XCTAssertGreaterThanOrEqual(earlier / later, 0.9)
        }
        XCTAssertLessThan(spacings.last!, spacings.first! / 2)
    }

    func testPiecesSettleInOrderWhenTheirLastCharacterHasAppeared() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あい", at: 1.0, pace: 60, step: step)
        reveal.update("あいうえ", at: 1.0 + step, pace: 60, step: step)
        let first = reveal.segments[0], second = reveal.segments[1]
        XCTAssertEqual(first.settlesAt, first.lastStartsAt + ReplyRevealBuffer.inFlight, accuracy: 0.0001)
        XCTAssertLessThan(first.settlesAt, second.settlesAt)
        // The deadline waits for the last to finish.
        XCTAssertEqual(reveal.animationDeadline, second.settlesAt)
        reveal.settle(at: first.settlesAt)
        XCTAssertEqual(reveal.settledText, "あい")
        XCTAssertEqual(reveal.segments.map(\.text), ["うえ"])
        reveal.settle(at: second.settlesAt)
        XCTAssertTrue(reveal.segments.isEmpty)
        XCTAssertEqual(reveal.settledText, "あいうえ")
        XCTAssertNil(reveal.animationDeadline)
    }

    func testPiecesFasterThanThePaceNeverQueueUp() {
        var reveal = ReplyRevealBuffer()
        var text = ""
        for index in 0..<100 {
            text += "あ"
            reveal.update(text, at: Double(index) * 0.001)
            XCTAssertLessThanOrEqual(reveal.segments.last!.startsAt, Double(index) * 0.001 + ReplyRevealBuffer.furthestLead + 0.0001)
        }
        reveal.settle(at: 0.1 + ReplyRevealBuffer.furthestLead + ReplyRevealBuffer.inFlight)
        XCTAssertTrue(reveal.segments.isEmpty)
    }

    func testAReplacedTextStartsItsClockAgain() {
        var reveal = ReplyRevealBuffer()
        reveal.update("あい", at: 1)
        reveal.update("う", at: 1.02)
        XCTAssertEqual(reveal.settledText, "う")
        XCTAssertTrue(reveal.segments.isEmpty)
        reveal.update("うえ", at: 1.04)
        XCTAssertEqual(reveal.segments.last?.startsAt ?? 0, 1.04 + ReplyRevealBuffer.freshLead * ReplyRevealBuffer.defaultStep,
                       accuracy: 0.0001, "No earlier piece to carry on from")
    }
}
