import XCTest
@testable import PocketCore

/// The orb's row following the reply's text down (1.1.0 (303)).
final class ReplyGlideTests: XCTestCase {
    /// 302's spring (`.smooth(duration: 0.24)`, critically damped): the
    /// share of the way gone `t` seconds after it began.
    private func spring302(_ t: Double) -> Double {
        let w = 2 * Double.pi / 0.24
        return 1 - (1 + w * t) * exp(-w * t)
    }

    func testCurveStartsGentlyAndLandsWithoutOvershoot() {
        XCTAssertEqual(ReplyGlide.share(at: 0), 0)
        XCTAssertEqual(ReplyGlide.share(at: 1), 1)
        var last = 0.0
        for step in 1...200 {
            let share = ReplyGlide.share(at: Double(step) / 200)
            XCTAssertGreaterThanOrEqual(share, last - 1e-9, "The row only ever goes one way")
            XCTAssertLessThanOrEqual(share, 1 + 1e-9, "The row never goes past its place")
            last = share
        }
        // The first line's 34pt (0.38 s): 302's spring went 18% in the
        // first 33 ms and 52% in 67 ms (two frames of the user's
        // recording); this goes a fraction of that.
        let first = ReplyGlide.duration(distance: 34, since: nil)
        let early = ReplyGlide.share(at: 0.033 / first), twoFrames = ReplyGlide.share(at: 0.067 / first)
        print(String(format: "GLIDE first line 34pt over %.2f s: %.0f%% at 33 ms, %.0f%% at 67 ms (302: %.0f%%, %.0f%%)",
                     first, early * 100, twoFrames * 100, spring302(0.033) * 100, spring302(0.067) * 100))
        XCTAssertLessThan(early, spring302(0.033) / 4)
        XCTAssertLessThan(twoFrames, spring302(0.067) / 2.5)
        XCTAssertGreaterThan(ReplyGlide.share(at: 0.5), 0.6, "Most of the way by half its time: it does not lag")
    }

    func testPushAtTheStartIsAFractionOf302() {
        // Speed and push (second difference) over the first 8 ms, for the
        // first line's 34pt.
        let duration = ReplyGlide.duration(distance: 34, since: nil)
        let dt = 1.0 / 240
        func at(_ t: Double) -> Double { 34 * ReplyGlide.share(at: t / duration) }
        let push = (at(2 * dt) - 2 * at(dt) + at(0)) / (dt * dt)
        let push302 = 34 * (spring302(2 * dt) - 2 * spring302(dt)) / (dt * dt)
        var fastest = 0.0, fastest302 = 0.0
        var t = 0.0
        while t < 0.6 {
            fastest = max(fastest, (at(t + dt) - at(t)) / dt)
            fastest302 = max(fastest302, 34 * (spring302(t + dt) - spring302(t)) / dt)
            t += dt
        }
        print(String(format: "GLIDE first line: push %.0f pt/s² (302 %.0f), fastest %.0f pt/s (302 %.0f)",
                     push, push302, fastest, fastest302))
        XCTAssertLessThan(push, push302 / 5)
        XCTAssertLessThan(fastest, fastest302 * 0.75)
    }

    func testTimeGrowsWithTheWayButLessThanInProportion() {
        let line = ReplyGlide.duration(distance: 23, since: nil)
        let paragraph = ReplyGlide.duration(distance: 40, since: nil)
        let heading = ReplyGlide.duration(distance: 55, since: nil)
        let table = ReplyGlide.duration(distance: 300, since: nil)
        print(String(format: "GLIDE times: line %.2f, first line %.2f, paragraph %.2f, heading %.2f, table %.2f s",
                     line, ReplyGlide.duration(distance: 34, since: nil), paragraph, heading, table))
        XCTAssertLessThan(line, paragraph)
        XCTAssertLessThan(paragraph, heading)
        XCTAssertLessThanOrEqual(table, ReplyGlide.longest)
        XCTAssertGreaterThanOrEqual(ReplyGlide.duration(distance: 1, since: nil), ReplyGlide.shortestByDistance)
        // Twice the way is less than twice as fast.
        XCTAssertGreaterThan(heading / line, 1.1)
        XCTAssertLessThan((55 / heading) / (23 / line), 55.0 / 23.0)
    }

    func testTimeKeepsUpWithAFastModel() {
        let calm = ReplyGlide.duration(distance: 23, since: 0.8)
        let quick = ReplyGlide.duration(distance: 23, since: 0.22)
        let burst = ReplyGlide.duration(distance: 23, since: 0.05)
        XCTAssertEqual(calm, ReplyGlide.duration(distance: 23, since: nil))
        XCTAssertLessThan(quick, calm)
        XCTAssertEqual(burst, ReplyGlide.shortest, accuracy: 1e-9)
        XCTAssertGreaterThanOrEqual(quick, ReplyGlide.shortest)
    }

    func testPositionFollowsTheCurve() {
        XCTAssertEqual(ReplyGlide.position(from: 100, to: 134, start: 10, duration: 0.4, at: 9.9), 100)
        XCTAssertEqual(ReplyGlide.position(from: 100, to: 134, start: 10, duration: 0.4, at: 10.5), 134)
        let middle = ReplyGlide.position(from: 100, to: 134, start: 10, duration: 0.4, at: 10.2)
        XCTAssertEqual(middle, 100 + 34 * ReplyGlide.share(at: 0.5), accuracy: 1e-9)
    }

    func testRoomFollowsGrowthAtOnce() {
        var room = ReplyRoom()
        XCTAssertEqual(room.text(height: 0, at: 0), .settle(0))
        XCTAssertEqual(room.text(height: 34, at: 1), .move(from: 0, to: 34))
        XCTAssertEqual(room.text(height: 34.2, at: 1.1), ReplyRoom.Step.none)
        XCTAssertEqual(room.text(height: 57, at: 1.5), .move(from: 34, to: 57))
        XCTAssertEqual(room.height, 57)
    }

    func testRoomWaitsBeforeGoingBackUp() {
        var room = ReplyRoom(height: 57)
        // A line's last word pulled back up: shorter for a moment, then
        // longer again. The row stays where it is throughout.
        XCTAssertEqual(room.text(height: 34, at: 2), .wait(until: 2 + ReplyRoom.shrinkHold))
        XCTAssertEqual(room.text(height: 34, at: 2.2), .wait(until: 2 + ReplyRoom.shrinkHold))
        XCTAssertEqual(room.text(height: 57, at: 2.3), ReplyRoom.Step.none)
        XCTAssertEqual(room.height, 57)
        // Shorter for good (a code block folded): followed after the hold.
        XCTAssertEqual(room.text(height: 40, at: 3), .wait(until: 3 + ReplyRoom.shrinkHold))
        XCTAssertEqual(room.look(at: 3 + ReplyRoom.shrinkHold), .move(from: 57, to: 40))
        XCTAssertEqual(room.height, 40)
        // Growth during a hold is followed at once, and ends the hold.
        XCTAssertEqual(room.text(height: 30, at: 4), .wait(until: 4 + ReplyRoom.shrinkHold))
        XCTAssertEqual(room.text(height: 63, at: 4.1), .move(from: 40, to: 63))
        XCTAssertEqual(room.look(at: 5), ReplyRoom.Step.none)
    }
}
