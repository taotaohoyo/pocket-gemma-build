import XCTest
@testable import PocketCore

/// A hardware keyboard's Return (fielua-reports #3): it sends, except while
/// the IME holds a word and with Shift or Option, which keep their line.
final class ComposerReturnKeyTests: XCTestCase {
    func testReturnAloneSends() {
        XCTAssertEqual(ComposerReturnKey.action(composing: false, shift: false, option: false, control: false), .send)
    }

    func testAWordBeingConvertedIsConfirmedNotSent() {
        XCTAssertEqual(ComposerReturnKey.action(composing: true, shift: false, option: false, control: false), .text,
                       "Return confirms 変換 and sends nothing")
        XCTAssertEqual(ComposerReturnKey.action(composing: true, shift: true, option: false, control: false), .text)
    }

    func testShiftAndOptionBeginANewLine() {
        XCTAssertEqual(ComposerReturnKey.action(composing: false, shift: true, option: false, control: false), .text)
        XCTAssertEqual(ComposerReturnKey.action(composing: false, shift: false, option: true, control: false), .text)
    }

    func testControlIsLeftToTheSystem() {
        XCTAssertEqual(ComposerReturnKey.action(composing: false, shift: false, option: false, control: true), .text)
    }
}
