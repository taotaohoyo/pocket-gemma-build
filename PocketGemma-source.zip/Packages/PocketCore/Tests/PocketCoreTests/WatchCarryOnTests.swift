import XCTest
@testable import PocketCore

final class WatchCarryOnTests: XCTestCase {
    func testAsksAgainAfterEveryRoundThatWroteMore() {
        var carryOn = WatchCarryOn()
        XCTAssertTrue(carryOn.ask(at: 120), "the first pause")
        XCTAssertTrue(carryOn.ask(at: 260))
        XCTAssertTrue(carryOn.ask(at: 410))
        XCTAssertEqual(carryOn.rounds, 3)
        XCTAssertEqual(carryOn.length, 410)
        XCTAssertEqual(carryOn.idle, 0)
    }

    func testARoundThatWroteNothingIsTriedOnceMore() {
        var carryOn = WatchCarryOn()
        XCTAssertTrue(carryOn.ask(at: 120))
        XCTAssertTrue(carryOn.ask(at: 120), "the iPhone may still have been stopping")
        XCTAssertFalse(carryOn.ask(at: 120), "then it waits for Fielua on the iPhone")
        XCTAssertFalse(carryOn.ask(at: 120))
        XCTAssertEqual(carryOn.rounds, 2)
        XCTAssertTrue(carryOn.ask(at: 180), "opened on the iPhone, it wrote more and paused again")
    }

    func testTheWatchAppBackOnScreenIsANewChance() {
        var carryOn = WatchCarryOn()
        XCTAssertTrue(carryOn.ask(at: 0), "a pause before the first word")
        XCTAssertTrue(carryOn.ask(at: 0))
        XCTAssertFalse(carryOn.ask(at: 0))
        XCTAssertTrue(carryOn.ask(at: 0, again: true))
        XCTAssertEqual(carryOn.idle, 0)
    }

    func testStopsAfterTheMostRounds() {
        var carryOn = WatchCarryOn()
        for round in 0..<WatchCarryOn.maximumRounds {
            XCTAssertTrue(carryOn.ask(at: 100 * (round + 1)))
        }
        XCTAssertFalse(carryOn.ask(at: 100_000))
        XCTAssertFalse(carryOn.ask(at: 100_001, again: true))
        XCTAssertEqual(carryOn.rounds, WatchCarryOn.maximumRounds)
    }
}
