import XCTest
@testable import PocketCore

/// Replies to chart requests as Gemma writes them on the phone (1.0.100
/// device test): the chart's data under ```json or a bare fence, or a chart
/// block wrapped in a ```markdown fence, whose closing fence then swallowed
/// the text after it. `MarkdownSource.readingCharts` reads them as charts;
/// everything else stays as written.
final class ChartReadingTests: XCTestCase {
    /// The data the user copied from the phone, as Gemma E2B wrote it.
    static let sales = """
    {
    "type":"bar",
    "title":"月別売上高",
    "unit":"万円",
    "data": [
    {"label":"1月","value":120},
    {"label":"2月","value":180},
    {"label":"3月","value":150},
    {"label":"4月","value":230}
    ]
    }
    """

    /// The device's shape: the chart block inside a ```markdown fence.
    static let wrapped = "1月から4月の売上高をグラフにしました。\n\n```markdown\n```chart\n\(sales)\n```\n```\n\n4月の売上が最も高くなっています。"

    /// Blocks as the reply view lays them out: chunk by chunk, the last
    /// one streaming while the model writes.
    private func blocks(_ text: String, streaming: Bool = false) -> [MarkdownBlock] {
        let chunks = MarkdownSource.chunks(text)
        return chunks.indices.flatMap { MarkdownDocument(chunks[$0], streaming: streaming && $0 == chunks.count - 1).blocks }
    }

    private func read(_ text: String, generating: Bool = false) -> [MarkdownBlock] {
        let read = MarkdownSource.readingCharts(text, generating: generating)
        return blocks(read, streaming: generating)
    }

    private func summary(_ blocks: [MarkdownBlock]) -> [String] {
        blocks.map { block in
            switch block {
            case .paragraph(let text): return "p:" + String(text.characters)
            case .code(let language, let code): return "code(\(language ?? "-")):" + code
            case .rich(let rich):
                switch rich.state {
                case .ready(.chart(let chart)): return "chart:\(chart.kind):\(chart.items.map(\.label).joined(separator: ","))"
                case .pending: return "pending"
                case .failed(let error): return "failed:\(error.message)"
                }
            case .heading(_, let text): return "h:" + String(text.characters)
            case .list: return "list"
            case .table: return "table"
            case .math: return "math"
            case .quote: return "quote"
            case .rule: return "rule"
            case .image: return "image"
            }
        }
    }

    // MARK: What the phone showed, and what it shows now

    func testMarkdownWrapperAroundChartNoLongerSwallowsTheText() {
        // As CommonMark reads it (1.0.100): the chart's closing fence ends
        // the wrapper, and the wrapper's own closing fence opens a code
        // block that takes the sentence after it.
        let before = summary(blocks(Self.wrapped))
        print("CHART-READ 1.0.100 read the wrapped chart as \(before)")
        XCTAssertEqual(before.first, "p:1月から4月の売上高をグラフにしました。")
        XCTAssertTrue(before.contains { $0.hasPrefix("code(markdown):```chart") })
        XCTAssertTrue(before.contains { $0.hasPrefix("code(-):") && $0.contains("4月の売上が最も高く") })
        XCTAssertFalse(before.contains { $0.hasPrefix("chart:") })
        // Read as a chart request's reply: prose, the chart, prose.
        XCTAssertEqual(summary(read(Self.wrapped)), [
            "p:1月から4月の売上高をグラフにしました。", "chart:bar:1月,2月,3月,4月", "p:4月の売上が最も高くなっています。",
        ])
    }

    func testChartUnderJSONOrBareFenceIsDrawn() {
        for tag in ["json", "JSON", "", "json5"] {
            let reply = "グラフです。\n\n```\(tag)\n\(Self.sales)\n```\n\n以上です。"
            XCTAssertEqual(summary(read(reply)), ["p:グラフです。", "chart:bar:1月,2月,3月,4月", "p:以上です。"], tag)
            // Not a chart request: code, as before.
            XCTAssertTrue(summary(blocks(reply))[1].hasPrefix("code("), tag)
        }
    }

    func testOtherWrappersAroundAChart() {
        let chart = "```chart\n\(Self.sales)\n```"
        let json = "```json\n\(Self.sales)\n```"
        let expected = ["p:前置き", "chart:bar:1月,2月,3月,4月", "p:あと"]
        for (name, reply) in [
            ("bare wrapper", "前置き\n\n```\n\(chart)\n```\n\nあと"),
            ("md wrapper", "前置き\n\n```md\n\(chart)\n```\n\nあと"),
            ("json inside markdown", "前置き\n\n```markdown\n\(json)\n```\n\nあと"),
            ("longer wrapper fence", "前置き\n\n````markdown\n\(chart)\n````\n\nあと"),
            ("tilde wrapper", "前置き\n\n~~~markdown\n\(chart)\n~~~\n\nあと"),
            ("text inside the wrapper", "```markdown\n前置き\n\n\(chart)\n\nあと\n```"),
        ] {
            XCTAssertEqual(summary(read(reply)), expected, name)
        }
    }

    func testAChartBlockAsAskedForStaysAsItIs() {
        let reply = "グラフです。\n\n```chart\n\(Self.sales)\n```\n\n以上です。"
        XCTAssertEqual(MarkdownSource.readingCharts(reply, generating: false), reply)
        XCTAssertEqual(MarkdownSource.readingCharts(reply, generating: true), reply)
        XCTAssertEqual(summary(read(reply)), ["p:グラフです。", "chart:bar:1月,2月,3月,4月", "p:以上です。"])
    }

    // MARK: What is never a chart

    func testCodeAndOtherJSONStayCode() {
        let replies = [
            // JSON that is not a chart's data.
            "```json\n{\"name\":\"Pocket AI\",\"version\":1}\n```",
            // A chart's shape whose values are not numbers: code, not a guess.
            "```json\n{\"type\":\"bar\",\"data\":[{\"label\":\"A\",\"value\":\"12%\"}]}\n```",
            // An array, and JSON with text around it.
            "```json\n[1, 2, 3]\n```",
            "```\nconst config = {\"type\":\"bar\",\"data\":[{\"label\":\"A\",\"value\":1}]}\n```",
            // Code that draws a chart is the code.
            "```javascript\nnew Chart(ctx, {type: 'bar', data: {labels: ['A'], datasets: [{data: [1]}]}})\n```",
            "```python\nimport matplotlib.pyplot as plt\nplt.bar(['A'], [1])\n```",
            // Markdown shown as written, with no chart in it.
            "```markdown\n| 月 | 売上 |\n| --- | --- |\n| 1月 | 120 |\n```",
            "```\nplain text\n```",
        ]
        for reply in replies {
            let text = "前置き\n\n" + reply + "\n\nあと"
            XCTAssertEqual(MarkdownSource.readingCharts(text, generating: false), text, reply)
            XCTAssertEqual(summary(read(text)), summary(blocks(text)), reply)
            XCTAssertFalse(summary(read(text)).contains { $0.hasPrefix("chart:") || $0.hasPrefix("failed:") }, reply)
        }
    }

    // MARK: Streaming

    /// Every prefix of `reply` as it streams: no fence, no chart data, no
    /// code block at any moment, and the chart at the end.
    private func assertStreamsCleanly(_ reply: String, _ name: String, chart expected: String = "chart:bar:1月,2月,3月,4月",
                                      file: StaticString = #filePath, line: UInt = #line) {
        let characters = Array(reply)
        var seen: Set<String> = []
        for count in 1...characters.count {
            let shown = summary(read(String(characters[0..<count]), generating: true))
            for block in shown {
                let kind = block.hasPrefix("code(") ? "code" : block.hasPrefix("failed:") ? "failed" : String(block.prefix(2))
                seen.insert(kind)
                XCTAssertFalse(block.hasPrefix("code("), "\(name): code at \(count): \(block)", file: file, line: line)
                XCTAssertFalse(block.hasPrefix("failed:"), "\(name): failed chart at \(count)", file: file, line: line)
                XCTAssertFalse(block.contains("```") || block.contains("~~~") || block.contains("\"type\"") || block.contains("{"),
                               "\(name): raw syntax at \(count): \(block)", file: file, line: line)
            }
        }
        print("CHART-READ \(name) streamed through \(seen.sorted())")
        XCTAssertTrue(summary(read(reply)).contains(expected), name, file: file, line: line)
    }

    func testStreamingNeverShowsWrapperFencesOrData() {
        assertStreamsCleanly(Self.wrapped, "markdown wrapper")
        assertStreamsCleanly("グラフです。\n\n```json\n\(Self.sales)\n```\n\n以上です。", "json fence")
        assertStreamsCleanly("グラフです。\n\n```\n\(Self.sales)\n```\n\n以上です。", "bare fence")
        assertStreamsCleanly("```markdown\n```chart\n\(Self.sales)\n```\n```", "wrapper alone")
        assertStreamsCleanly(RealReplies.natural, "E2B reply", chart: "chart:line:1月,2月,3月,4月")
    }

    func testStoppedWhileTheDataArrived() {
        // Its data names a chart type: the chart is shown as unfinished.
        let stopped = "グラフです。\n\n```json\n{\"type\":\"bar\",\"data\":[{\"label\":\"1月\",\"value\":120},"
        XCTAssertEqual(summary(read(stopped)), ["p:グラフです。", "failed:データが途中で終わっています"])
        XCTAssertEqual(summary(read("```markdown\n" + stopped.dropFirst(8))), ["failed:データが途中で終わっています"])
        // Otherwise it is the code it was.
        let code = "グラフです。\n\n```json\n{\"name\":\"Pocket"
        XCTAssertEqual(summary(read(code)), summary(blocks(code)))
    }

    func testPacerLaysOutTheWrappedChartWhole() {
        // The model's text arrives at 40 characters a second; the row reads
        // it for charts at each step, as the app does.
        let reply = Self.wrapped
        let characters = Array(reply)
        let pacer = ReplyPacer(text: "", generating: true, held: false, shown: 0)
        var now = 0.0, arrived = 0
        var stops: [String] = []
        while now < 30, !(pacer.caughtUp && !pacer.generating) {
            let due = min(characters.count, Int(now * 40))
            if due > arrived { arrived = due }
            pacer.generating = arrived < characters.count
            pacer.text = MarkdownSource.readingCharts(String(characters[0..<arrived]), generating: pacer.generating)
            if let shown = pacer.advance(at: now) { stops.append(String(pacer.text.prefix(shown))) }
            now += ReplyPacer.interval(forLength: pacer.shown)
        }
        XCTAssertTrue(pacer.caughtUp, "The reply finishes")
        for shown in stops {
            for block in summary(blocks(shown, streaming: true)) {
                XCTAssertFalse(block.hasPrefix("code(") || block.contains("```") || block.contains("\"type\""), "\(block) in \(shown)")
            }
        }
        XCTAssertEqual(summary(blocks(pacer.text)), [
            "p:1月から4月の売上高をグラフにしました。", "chart:bar:1月,2月,3月,4月", "p:4月の売上が最も高くなっています。",
        ])
    }

    // MARK: Gemma E2B's own replies

    func testRealRepliesFromGemmaE2B() {
        // Chart blocks as asked for: unchanged, drawn, the text around them kept.
        for (reply, kind) in [(RealReplies.natural, "line"), (RealReplies.pie, "pie")] {
            XCTAssertEqual(MarkdownSource.readingCharts(reply, generating: false), reply)
            let shown = summary(read(reply))
            print("CHART-READ E2B \(kind) reply: \(shown.map { String($0.prefix(30)) })")
            XCTAssertEqual(shown.filter { $0.hasPrefix("chart:") }.count, 1, kind)
            XCTAssertTrue(shown.contains { $0.hasPrefix("chart:\(kind):") }, kind)
            XCTAssertFalse(shown.contains { $0.hasPrefix("code(") || $0.hasPrefix("failed:") }, kind)
            XCTAssertTrue(shown.last?.hasPrefix("p:") == true, "The text after the chart is text")
        }
        // Without the note it wrote a table, which stays a table; the
        // message now asks for a chart and gets the note.
        XCTAssertEqual(MarkdownSource.readingCharts(RealReplies.explicit, generating: false), RealReplies.explicit)
        XCTAssertTrue(summary(read(RealReplies.explicit)).contains("table"))
        XCTAssertNotNil(RichFormatGuide.guide(for: "次のデータをchart形式で表示してください。1月120、2月180、3月150、4月230（単位は万円）"))
    }

    // MARK: Which messages ask for a chart

    func testChartRequestsAndCodeRequests() {
        for asking in ["1月から4月の売上をグラフにして", "次のデータをchart形式で表示してください", "chartで見せて",
                       "バーコードの読み取り件数の推移をグラフに", "Plot this", "Show it as a CHART please"] {
            XCTAssertTrue(RichFormatGuide.asksForChart(asking), asking)
        }
        for other in ["Pythonでグラフを描くコードを書いて", "matplotlibで棒グラフ", "Chart.jsでグラフを作るには",
                      "フローチャートを書いて", "flowchart for login", "GraphQL の説明", "photograph tips", "こんにちは"] {
            XCTAssertFalse(RichFormatGuide.asksForChart(other), other)
            XCTAssertNil(RichFormatGuide.guide(for: other), other)
        }
    }
}

/// Replies Gemma E2B wrote in CI with the app's settings and its note
/// (native probe chart-reply, CPU, 1.0.100), kept as written.
enum RealReplies {
    /// "1月から4月の月別売上高（…）をグラフにしてください。"
    static let natural = #"""
        こんにちは！喜んで売上高のグラフを作成しますね。

        いただいたデータは以下の通りです。

        *   1月：120万円
        *   2月：180万円
        *   3月：150万円
        *   4月：230万円

        売上高の**推移**を分かりやすく示すために、**折れ線グラフ (line)** で作成するのが最適だと思います。

        ```chart
        {"type":"line","title":"1月から4月の月別売上高の推移","unit":"万円","data":[{"label":"1月","value":120},{"label":"2月","value":180},{"label":"3月","value":150},{"label":"4月","value":230}]}
        ```

        このグラフは、1月から4月にかけての売上がどのように変動したか（増加したか、減少したかなど）を時系列で見ていくのに役立ちます。

        もし、特定の月の**割合**や、特定の期間の**比較**など、別の視点でのグラフが必要でしたら、遠慮なくお申し付けください！ 😊
        """#

    /// "次のデータをchart形式で表示してください。…" (1.0.100 sent no note for it)
    static let explicit = #"""
        はい、承知いたしました。いただいたデータを、わかりやすいチャート形式で表示しますね。

        どのようなチャート形式がご希望でしょうか？いくつか一般的な例をご提案しますので、どれが一番イメージに近いか教えてください。

        1. **棒グラフ (Bar Chart)**：各月の値を縦の棒で比較しやすく、最も一般的で分かりやすい形式です。
        2. **折れ線グラフ (Line Chart)**：時間経過（月）に伴う変化を滑らかに示したい場合に適しています。
        3. **円グラフ (Pie Chart)**：全体の構成比（合計に対する各月の割合）を見せたい場合に適していますが、このデータ（時系列データ）には少し向きません。

        **今回は、時系列の変化を見るのに適した「棒グラフ」で作成してみますね。**

        ---

        ### 📊 データの棒グラフ

        | 月 | 金額 (万円) |
        | :--- | :--- |
        | 1月 | 120 |
        | 2月 | 180 |
        | 3月 | 150 |
        | 4月 | 230 |

        **【グラフのイメージ説明】**

        このデータは、1月から4月にかけての金額の変化を示しています。

        * **1月** は 120万円です。
        * **2月** には 180万円と上昇します。
        * **3月** は 150万円と一度下落します。
        * **4月** には 230万円と、最も高い水準に達しています。

        ---

        **もし、この表示方法でよろしければ、このまま情報としてお使いいただけます。**

        もし、**「折れ線グラフにしたい」「別の形式でお願いしたい」** など、ご希望があれば遠慮なくお申し付けください。喜んで調整いたします！ 😊
        """#

    /// "一日の時間の使い方を円グラフにして。…"
    static let pie = #"""
        こんにちは！一日の時間の使い方を円グラフにして、わかりやすく整理しましょう。

        ご提示いただいた時間配分は以下の通りですね。

        *   **睡眠:** 8時間
        *   **仕事:** 8時間
        *   **家事:** 2時間
        *   **自由時間:** 6時間

        まず、合計時間を計算します。
        $8 (\text{睡眠}) + 8 (\text{仕事}) + 2 (\text{家事}) + 6 (\text{自由時間}) = 24$ 時間

        合計24時間の中で、各活動が占める割合を計算します。

        *   睡眠の割合: $(8 / 24) \times 100 = 33.33\%$
        *   仕事の割合: $(8 / 24) \times 100 = 33.33\%$
        *   家事の割合: $(2 / 24) \times 100 \approx 8.33\%$
        *   自由時間の割合: $(6 / 24) \times 100 = 25\%$

        これらの割合を円グラフ（pie）で表示するのが最も分かりやすいでしょう。

        以下に、ご要望の形式でグラフを作成します。

        ```chart
        {"type":"pie","title":"一日の時間の使い方","unit":"時間","data":[{"label":"睡眠","value":8},{"label":"仕事","value":8},{"label":"家事","value":2},{"label":"自由時間","value":6}]}
        ```

        このグラフは、一日のうちのどの時間が、睡眠、仕事、家事、自由時間に費やされているかの割合を示しています。睡眠と仕事がほぼ同じ時間（33.3%ずつ）を占めており、自由時間もかなりの割合（25%）を確保できていることがわかります。
        """#
}
