import XCTest
@testable import PocketCore

/// 起動時のチャット (2026-10-25): the choice carried over from 起動時にキーボード
/// を開いておく, the chats a launch opens and offers, and the drafts kept
/// through a launch.
final class LaunchChatTests: XCTestCase {
    private var defaults: UserDefaults!
    private let suite = "LaunchChatTests"

    override func setUp() {
        super.setUp()
        UserDefaults().removePersistentDomain(forName: suite)
        defaults = UserDefaults(suiteName: suite)
    }
    override func tearDown() {
        UserDefaults().removePersistentDomain(forName: suite)
        super.tearDown()
    }

    private func chat(_ messages: Int, minutesAgo: Double) -> ChatThread {
        var thread = ChatThread()
        thread.messages = (0..<messages).map { ChatMessage(role: $0 % 2 == 0 ? .user : .assistant, text: "メッセージ\($0)") }
        thread.updatedAt = Date().addingTimeInterval(-minutesAgo * 60)
        return thread
    }

    func testTheKeyboardSwitchCarriesOverOnceAndGoes() {
        XCTAssertEqual(LaunchChatMode.current(defaults), .resume, "前回の会話 until another is chosen")
        LaunchChatMode.migrate(defaults)
        XCTAssertNil(defaults.string(forKey: LaunchChatMode.storageKey), "Nothing to carry over on a new phone")

        defaults.set(true, forKey: LaunchChatMode.legacyKeyboardKey)
        LaunchChatMode.migrate(defaults)
        XCTAssertEqual(LaunchChatMode.current(defaults), .newChat, "On: launches opened a new chat")
        XCTAssertNil(defaults.object(forKey: LaunchChatMode.legacyKeyboardKey), "The switch's key goes")

        defaults.removeObject(forKey: LaunchChatMode.storageKey)
        defaults.set(false, forKey: LaunchChatMode.legacyKeyboardKey)
        LaunchChatMode.migrate(defaults)
        XCTAssertEqual(defaults.string(forKey: LaunchChatMode.storageKey), LaunchChatMode.resume.rawValue)

        // A choice made already stands; a stray switch key never changes it.
        defaults.set(LaunchChatMode.resume.rawValue, forKey: LaunchChatMode.storageKey)
        defaults.set(true, forKey: LaunchChatMode.legacyKeyboardKey)
        LaunchChatMode.migrate(defaults)
        XCTAssertEqual(LaunchChatMode.current(defaults), .resume)
        XCTAssertNil(defaults.object(forKey: LaunchChatMode.legacyKeyboardKey))
    }

    func testALaunchOpensTheChatLastOpen() {
        let latest = chat(2, minutesAgo: 1), older = chat(4, minutesAgo: 90)
        XCTAssertEqual(LaunchChatPlan.opening([latest, older], lastOpen: older.id), older.id, "The one being read")
        XCTAssertEqual(LaunchChatPlan.opening([latest, older], lastOpen: UUID()), latest.id, "Gone: the latest")
        XCTAssertEqual(LaunchChatPlan.opening([latest, older], lastOpen: nil), latest.id)
        XCTAssertNil(LaunchChatPlan.opening([], lastOpen: nil))
        LaunchChatPlan.remember(older.id, defaults)
        XCTAssertEqual(LaunchChatPlan.lastOpen(defaults), older.id)
        LaunchChatPlan.remember(nil, defaults)
        XCTAssertNil(LaunchChatPlan.lastOpen(defaults))
    }

    func testTheReturnGoesToTheChatOfBeforeAndNeverToAnEmptyOne() {
        let fresh = chat(0, minutesAgo: 0), latest = chat(2, minutesAgo: 5), older = chat(6, minutesAgo: 60)
        let threads = [fresh, latest, older]
        XCTAssertEqual(LaunchChatPlan.returnTarget(threads, before: older.id, newChat: fresh.id), older.id, "The chat open before")
        XCTAssertEqual(LaunchChatPlan.returnTarget(threads, before: fresh.id, newChat: fresh.id), latest.id,
                       "The new chat was open before (reused): the chat last written in")
        let blank = chat(0, minutesAgo: 30)
        XCTAssertEqual(LaunchChatPlan.returnTarget(threads + [blank], before: blank.id, newChat: fresh.id), latest.id,
                       "An empty chat is nothing to go back to")
        XCTAssertNil(LaunchChatPlan.returnTarget([fresh], before: nil, newChat: fresh.id), "No chat yet: no capsule")
        XCTAssertNil(LaunchChatPlan.returnTarget([fresh, blank], before: blank.id, newChat: fresh.id))
    }

    func testDraftsAreKeptPerChatUntilCleared() {
        let first = UUID(), second = UUID()
        XCTAssertTrue(LaunchDrafts.load(defaults).isEmpty)
        LaunchDrafts.set("書きかけの文章", for: first, defaults)
        LaunchDrafts.set("別の下書き", for: second, defaults)
        XCTAssertEqual(LaunchDrafts.load(defaults), [first: "書きかけの文章", second: "別の下書き"])
        LaunchDrafts.set("", for: first, defaults)
        XCTAssertEqual(LaunchDrafts.load(defaults), [second: "別の下書き"], "An empty field forgets its draft only")
        LaunchDrafts.prune(keeping: [first], defaults)
        XCTAssertTrue(LaunchDrafts.load(defaults).isEmpty, "A deleted chat's draft goes")
        XCTAssertNil(defaults.object(forKey: LaunchDrafts.storageKey))
        let many = (0..<(LaunchDrafts.limit + 3)).map { _ in UUID() }
        for (index, id) in many.enumerated() { LaunchDrafts.set("下書き\(index)", for: id, defaults) }
        let kept = LaunchDrafts.load(defaults)
        XCTAssertEqual(kept.count, LaunchDrafts.limit)
        XCTAssertNil(kept[many[0]], "The oldest goes first")
        XCTAssertEqual(kept[many.last!], "下書き\(LaunchDrafts.limit + 2)")
        LaunchDrafts.set("もう一度", for: many[3], defaults)
        LaunchDrafts.set("新しい", for: UUID(), defaults)
        XCTAssertEqual(LaunchDrafts.load(defaults)[many[3]], "もう一度", "Written again, it is the newest")
    }
}
