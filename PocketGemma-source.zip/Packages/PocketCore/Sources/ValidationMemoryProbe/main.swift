import Foundation
import CryptoKit
import Darwin
import PocketCore

// Run separately from XCTest so its peak RSS belongs to this check alone.
// A sparse 512 MiB fixture exercises hundreds of FileHandle reads without
// downloading the model or allocating the entire fixture in memory.
func peakResidentBytes() -> Int64 {
    var usage = rusage()
    precondition(getrusage(RUSAGE_SELF, &usage) == 0)
    return Int64(usage.ru_maxrss) // Darwin reports bytes, not Linux's KiB.
}

let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
defer { try? FileManager.default.removeItem(at: url) }
let byteCount: Int64 = 512 * 1_048_576
FileManager.default.createFile(atPath: url.path, contents: nil)
let writer = try FileHandle(forWritingTo: url)
try writer.truncate(atOffset: UInt64(byteCount))
try writer.close()
let zeros = Data(repeating: 0, count: 1_048_576)
var reference = SHA256()
for _ in 0..<512 { reference.update(data: zeros) }
let spec = ModelSpec(fileName: "fixture", byteCount: byteCount,
    sha256: reference.finalize().map { String(format: "%02x", $0) }.joined(),
    downloadURL: URL(string: "https://example.com/fixture")!)
let before = peakResidentBytes()
// Keep an outer pool alive as it can be on a long-running worker thread.
// The real validator must release each buffer inside that outer pool.
try autoreleasepool { try ModelValidator.validate(url, spec: spec) }
let growth = max(0, peakResidentBytes() - before)
print("Verified 512 MiB; peak RSS growth: \(growth) bytes")
guard growth < 64 * 1_048_576 else {
    fatalError("Validation retains file buffers: RSS grew by \(growth) bytes")
}
