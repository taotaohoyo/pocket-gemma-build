import Foundation

/// The light around the Aurora Orb while a reply is prepared (生成演出,
/// 1.1.0 (298)): small soft motes of the orb's golds that leave its rim,
/// drift out and gently down, sway a little and fade, a few at a time, over
/// a faint glow under the orb that breathes with it. When the reply's first
/// text comes and the orb shrinks away, no more are born, and those still
/// there drift toward the reply's first line and fade with the orb, so the
/// eye goes where the text begins.
///
/// It is light only: nothing here is words, and nothing is read from the
/// reply or asked of a model. It needs no text to stand on its own, so it
/// is the same however long the model thinks, and the reply's text begins
/// when it did in 1.1.0 (296): once the orb has gone.
///
/// Calm on purpose: seven or eight motes at a time (two to ten), slower than the orb's
/// breath, none at all for the first 0.3 s and fewer before 1.5 s (a quick
/// reply shows almost none, so nothing flashes), and all of them inside a
/// small field around the orb (`field`). Everything is a function of the
/// time since the orb appeared, so a frame drawn at any moment is the same
/// whatever came before, and nothing is kept between frames.
public enum AuroraMotes {
    /// One mote: where it is, in points from the orb's centre (y runs
    /// down); its soft core's radius (a Gaussian's sigma, in points); how
    /// strongly it shows (0...1); and its colour between the orb's deep
    /// amber (0) and its light gold (1). `slot` and `cycle` say which mote
    /// it is, for the checks.
    public struct Mote: Equatable, Sendable {
        public let x: Double
        public let y: Double
        public let radius: Double
        public let alpha: Double
        public let tone: Double
        public let slot: Int
        public let cycle: Int
    }

    /// The field the motes stay inside, in points from the orb's centre:
    /// 22 to the left (the reply's text starts 16pt from the screen's edge,
    /// the orb's centre 12pt further in), 44 to the right along the line, 10
    /// up (the sent message ends above that) and 40 down, into the room
    /// under the reply. The glow and the motes' soft edges fit inside it.
    public static let field = (left: 22.0, right: 44.0, up: 10.0, down: 40.0)

    /// How many motes there are at most, one after another in each place.
    public static let slots = 10
    /// No mote is born before this, so the orb comes in on its own...
    public static let start: TimeInterval = 0.3
    /// ...and the field grows to its full light by this long after the orb
    /// appeared.
    public static let fullAt: TimeInterval = 1.5
    /// Seconds between one mote's birth and the next in the same place
    /// (plus up to `periodSpread`), and the share of that it lives.
    static let period: TimeInterval = 4.4
    static let periodSpread: TimeInterval = 0.6
    static let life = 0.85
    /// Where on the rim a mote is born, in radians from the right, y down:
    /// a little above the right, round the bottom, to the lower left.
    static let angles = (from: -0.1, to: 2.5)
    /// How far it drifts out over its life (points a second, plus up to
    /// `speedSpread`, times `reach`); toward the left only `leftReach` of
    /// that, as there is little room; and how fast it sinks.
    static let speed = 4.5
    static let speedSpread = 2.5
    static let reach = 0.65
    static let leftReach = 0.6
    static let sink = 2.0
    /// Below this depth a mote fades out, whatever its age.
    static let floorDepth = (from: 26.0, to: 36.0)
    /// Its core's radius (plus up to `radiusSpread`), shrinking by
    /// `shrink` over its life.
    static let radius = 0.9
    static let radiusSpread = 0.7
    static let shrink = 0.3
    /// How strongly it shows at most (plus up to `alphaSpread`).
    static let alpha = 0.36
    static let alphaSpread = 0.22
    /// The glow under the orb at most.
    public static let veilStrength = 0.08
    /// When the reply's text comes: the share of the way each mote drifts
    /// toward the line, and the share of the orb's exit it takes to fade.
    static let pull = 0.45
    static let fadeShare = 0.85

    /// The motes `time` seconds after the orb appeared. `leavingAt`: when
    /// it began to leave (the reply's first text), if it has;
    /// `exitDuration`: how long it takes to; `breath`: the orb's size
    /// (1 = full) at a time, which the motes are born at the rim of and
    /// glow a little more with.
    public static func motes(at time: TimeInterval, leavingAt: TimeInterval?, exitDuration: TimeInterval,
                             breath: (TimeInterval) -> Double) -> [Mote] {
        guard time >= start else { return [] }
        let field = fieldLight(at: time, leavingAt: leavingAt, exitDuration: exitDuration, breath: breath)
        guard field > 0 else { return [] }
        let leaving = leavingAt.map { min(max((time - $0) / max(exitDuration, 0.001), 0), 1) } ?? 0
        let average = period + 0.5 * periodSpread
        var result: [Mote] = []
        result.reserveCapacity(slots)
        for slot in 0..<slots {
            let each = period + periodSpread * unit(slot, 0, 9)
            let first = start + Double(slot) * average / Double(slots)
            guard time >= first else { continue }
            let cycle = Int(((time - first) / each).rounded(.down))
            let born = first + Double(cycle) * each
            let lifetime = life * each
            let age = time - born
            // Born before the orb began to leave, still alive.
            guard age >= 0, age < lifetime else { continue }
            if let leavingAt, born >= leavingAt { continue }
            let made = mote(slot: slot, cycle: cycle, born: born, age: age, lifetime: lifetime,
                            field: field, leaving: leaving, breath: breath)
            if made.alpha > 0.002 { result.append(made) }
        }
        return result
    }

    /// The glow under the orb at `time`, 0...`veilStrength`.
    public static func veil(at time: TimeInterval, leavingAt: TimeInterval?, exitDuration: TimeInterval,
                            breath: (TimeInterval) -> Double) -> Double {
        veilStrength * fieldLight(at: time, leavingAt: leavingAt, exitDuration: exitDuration, breath: breath)
    }

    /// The motes as the shader takes them: five numbers each (x and y in
    /// points from `origin`, radius, alpha, tone).
    public static func packed(_ motes: [Mote], origin: (x: Double, y: Double)) -> [Float] {
        var values: [Float] = []
        values.reserveCapacity(motes.count * 5)
        for mote in motes {
            values += [Float(origin.x + mote.x), Float(origin.y + mote.y), Float(mote.radius), Float(mote.alpha), Float(mote.tone)]
        }
        return values
    }

    /// How much of the field's light shows: growing in after the orb
    /// appears, a little more as the orb breathes in, and fading as the
    /// orb leaves.
    static func fieldLight(at time: TimeInterval, leavingAt: TimeInterval?, exitDuration: TimeInterval,
                           breath: (TimeInterval) -> Double) -> Double {
        var light = smoothstep(start, fullAt, time)
        // The orb breathes between half and its full size.
        light *= 0.85 + 0.15 * min(max((breath(time) - 0.5) / 0.5, 0), 1)
        if let leavingAt, time > leavingAt {
            let share = min((time - leavingAt) / max(exitDuration, 0.001), 1)
            light *= 1 - smoothstep(0, fadeShare, share)
        }
        return light
    }

    private static func mote(slot: Int, cycle: Int, born: TimeInterval, age: TimeInterval, lifetime: TimeInterval,
                             field: Double, leaving: Double, breath: (TimeInterval) -> Double) -> Mote {
        let angle = angles.from + (angles.to - angles.from) * unit(slot, cycle, 1)
        let out = (x: cos(angle), y: sin(angle))
        let share = age / lifetime
        // Out from the rim, slowing as it goes, and sinking all the while.
        let distance = (speed + speedSpread * unit(slot, cycle, 2)) * lifetime * reach * (out.x < 0 ? leftReach : 1)
        let travelled = distance * (1 - (1 - share) * (1 - share))
        let rim = 12 * breath(born) * 0.85
        let swayPeriod = 2.4 + 0.8 * unit(slot, cycle, 4)
        let sway = (1.2 + 1.2 * unit(slot, cycle, 3))
            * sin(2 * Double.pi * (age / swayPeriod + unit(slot, cycle, 5))) * share
        var x = out.x * (rim + travelled) - out.y * sway
        var y = out.y * (rim + travelled) + out.x * sway + sink * age
        var alpha = (Self.alpha + alphaSpread * unit(slot, cycle, 7))
            * smoothstep(0, 0.45, age) * (1 - smoothstep(0.5 * lifetime, lifetime, age))
        alpha *= field * (1 - smoothstep(floorDepth.from, floorDepth.to, y))
        if leaving > 0 {
            // Toward the reply's first line, right of where it is.
            let toward = smoothstep(0, 1, leaving) * pull
            x += (max(x, 0) + 16 - x) * toward
            y += (0 - y) * toward
        }
        let radius = (Self.radius + radiusSpread * unit(slot, cycle, 6)) * (1 - shrink * share)
        return Mote(x: x, y: y, radius: radius, alpha: alpha, tone: unit(slot, cycle, 8), slot: slot, cycle: cycle)
    }

    /// A number in 0..<1 that is the same for the same mote and question,
    /// and unrelated between them.
    static func unit(_ slot: Int, _ cycle: Int, _ question: Int) -> Double {
        var x = UInt32(truncatingIfNeeded: slot &* 73_856_093) ^ UInt32(truncatingIfNeeded: cycle &* 19_349_663)
            ^ UInt32(truncatingIfNeeded: question &* 83_492_791)
        x = (x ^ (x >> 13)) &* 1_274_126_177
        x ^= x >> 16
        return Double(x) / 4_294_967_296
    }

    static func smoothstep(_ from: Double, _ to: Double, _ value: Double) -> Double {
        let share = min(max((value - from) / (to - from), 0), 1)
        return share * share * (3 - 2 * share)
    }
}
