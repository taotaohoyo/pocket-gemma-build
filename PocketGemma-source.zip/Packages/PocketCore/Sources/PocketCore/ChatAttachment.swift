import Foundation

public struct ChatAttachment: Codable, Identifiable, Equatable, Sendable {
    public enum Kind: String, Codable, Sendable { case image, video, file }
    public let id: UUID
    public let kind: Kind
    public let name: String
    public let storedName: String
    public var thumbnailName: String?
    public var imageNames: [String]
    public var extractedText: String?
    public var note: String?
    public var byteCount: Int64
    public var duration: Double?

    public init(id: UUID = UUID(), kind: Kind, name: String, storedName: String,
                thumbnailName: String? = nil, imageNames: [String] = [],
                extractedText: String? = nil, note: String? = nil,
                byteCount: Int64 = 0, duration: Double? = nil) {
        self.id = id; self.kind = kind; self.name = name; self.storedName = storedName
        self.thumbnailName = thumbnailName; self.imageNames = imageNames
        self.extractedText = extractedText; self.note = note
        self.byteCount = byteCount; self.duration = duration
    }
    public static func isSafeFileName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/")
            && !name.contains("\\") && !name.contains(":") && !name.contains("\0")
    }
    /// A file's whole extracted text, next to it in the attachment folder;
    /// extractedText holds what the model gets (DocumentExcerpt).
    public var textSidecarName: String { id.uuidString + "-text.txt" }
    public var contextByteCost: Int {
        contextByteCost(visualTokenBudget: 280)
    }
    public func contextByteCost(visualTokenBudget: Int) -> Int {
        // Match the same two-byte-per-token estimate used by the input budget,
        // including frame markers. Raising visual quality must reserve space.
        name.utf8.count + (extractedText.map { $0.utf8.count + AttachmentPrompt.overhead(for: kind) } ?? 0)
            + imageNames.count * (min(1120, max(70, visualTokenBudget)) * 2 + 128)
    }
}
