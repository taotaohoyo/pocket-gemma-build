import Foundation

public struct ChatAttachment: Codable, Identifiable, Equatable, Sendable {
    public enum Kind: String, Codable, Sendable { case image, video, file }
    public let id: UUID
    public let kind: Kind
    public let name: String
    public let storedName: String
    public var thumbnailName: String?
    public var imageNames: [String]
    public var extractedText: String?
    public var note: String?
    public var byteCount: Int64
    public var duration: Double?
    /// A video's scenes and sound and what the model made of them, since
    /// 1.1.0 (194); nil for photos, files and older videos, whose three
    /// scenes are `imageNames` (VideoScenes).
    public var video: VideoAnalysis?

    public init(id: UUID = UUID(), kind: Kind, name: String, storedName: String,
                thumbnailName: String? = nil, imageNames: [String] = [],
                extractedText: String? = nil, note: String? = nil,
                byteCount: Int64 = 0, duration: Double? = nil) {
        self.id = id; self.kind = kind; self.name = name; self.storedName = storedName
        self.thumbnailName = thumbnailName; self.imageNames = imageNames
        self.extractedText = extractedText; self.note = note
        self.byteCount = byteCount; self.duration = duration
    }
    public static func isSafeFileName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && !name.contains("/")
            && !name.contains("\\") && !name.contains(":") && !name.contains("\0")
    }
    /// A file's whole extracted text, next to it in the attachment folder;
    /// extractedText holds what the model gets (DocumentExcerpt).
    public var textSidecarName: String { id.uuidString + "-text.txt" }
    public var contextByteCost: Int {
        contextByteCost(visualTokenBudget: 280)
    }
    /// `inputByteBudget` sets a video's share (VideoDigest.Allowance); by
    /// default the default settings'.
    public func contextByteCost(visualTokenBudget: Int, inputByteBudget: Int = GenerationSettings().inputByteBudget) -> Int {
        // Match the same two-byte-per-token estimate used by the input budget,
        // including frame markers. Raising visual quality must reserve space.
        if video != nil {
            // Reserved before the analysis exists, so the chat's turns
            // chosen at send still fit once it does.
            let allowance = VideoDigest.Allowance(visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget)
            return name.utf8.count + VideoDigest.overheadBytes + allowance.bytes
                + modelImageNames(visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget).count * VideoDigest.imageBytes(visualTokenBudget)
        }
        return name.utf8.count + (extractedText.map { $0.utf8.count + AttachmentPrompt.overhead(for: kind) } ?? 0)
            + imageNames.count * VideoDigest.imageBytes(visualTokenBudget)
    }
    public func contextByteCost(_ settings: GenerationSettings) -> Int {
        contextByteCost(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget)
    }
    /// The images the model gets in a reply: a photo's, an older video's
    /// three scenes, or some of a video's scenes (its analysis describes
    /// them all).
    public func modelImageNames(visualTokenBudget: Int, inputByteBudget: Int = GenerationSettings().inputByteBudget) -> [String] {
        guard let video else { return imageNames }
        let allowance = VideoDigest.Allowance(visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget)
        return VideoDigest.answerScenes(video, count: allowance.frames).map(\.image)
    }
    public func modelImageNames(_ settings: GenerationSettings) -> [String] {
        modelImageNames(visualTokenBudget: settings.visualTokenBudget, inputByteBudget: settings.inputByteBudget)
    }
    /// Every file the attachment keeps in the attachment folder.
    public var fileNames: [String] {
        [storedName, textSidecarName] + imageNames + [thumbnailName].compactMap { $0 } + (video?.audioNames ?? [])
    }
}
