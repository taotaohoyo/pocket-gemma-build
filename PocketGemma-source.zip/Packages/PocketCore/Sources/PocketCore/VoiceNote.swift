import Foundation

/// A question spoken into the app (1.1.0 (236)), for a model that hears
/// one (`ModelSpec.supportsVoice`: LFM3-Omni 2B). It is recorded on the
/// phone as 16 kHz mono 16-bit WAV, the sound llama.cpp's mtmd reads, kept
/// with the chat as an attachment (`ChatAttachment.Kind.audio`) and never
/// sent off the phone.
public enum VoiceNote {
    /// The longest recording: a question, not a talk. About 750 places in
    /// LFM3-Omni 2B's context (`places(seconds:)`).
    public static let limit: Double = 60
    /// A shorter recording holds no question: it is dropped, not sent.
    public static let shortest: Double = 0.5
    public static let sampleRate: Double = 16_000

    /// What the model is asked when the person only speaks: the spoken
    /// question is the message. Shown nowhere (`ChatMessage.hidesText`).
    public static var ask: String { String(localized: "音声で話した内容に答えてください。") }

    /// The recording's file in the attachment folder.
    public static func storedName(_ id: UUID) -> String { id.uuidString + "-voice.wav" }

    /// "0:04": minutes and seconds, as a voice message shows its length.
    public static func clock(_ seconds: Double) -> String {
        let whole = max(0, Int(seconds.rounded()))
        return String(format: "%d:%02d", whole / 60, whole % 60)
    }

    /// The attachment's name: 音声 and its length.
    public static func name(_ seconds: Double) -> String { String(localized: "音声 \(clock(seconds))") }

    /// About how many places a recording takes in LFM3-Omni 2B's context:
    /// 1.85 seconds took 23 and its two markers (run 40796978426), about
    /// 12.4 a second. The reply counts the real places (LFM3Chat).
    public static func places(seconds: Double) -> Int { Int((seconds * 12.5).rounded(.up)) + 2 }

    /// The recording made into an attachment.
    public static func attachment(id: UUID = UUID(), seconds: Double, byteCount: Int64) -> ChatAttachment {
        ChatAttachment(id: id, kind: .audio, name: name(seconds), storedName: storedName(id),
                       byteCount: byteCount, duration: seconds)
    }

    /// Whether `attachment` is a recording as the app makes them: a WAV of
    /// its own name, at most `limit` long, with nothing else in it.
    public static func isRecording(_ attachment: ChatAttachment) -> Bool {
        guard attachment.kind == .audio, let seconds = attachment.duration else { return false }
        return attachment.storedName == storedName(attachment.id) && attachment.imageNames.isEmpty
            && attachment.extractedText == nil && attachment.video == nil
            && seconds >= shortest && seconds <= limit + 1
    }
}
