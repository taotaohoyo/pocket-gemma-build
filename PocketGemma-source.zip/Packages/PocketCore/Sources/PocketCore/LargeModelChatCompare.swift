import Foundation

/// 開発者設定's 12B comparison (1.1.0 (201)). On the phone's GPU the
/// developer 12B check of 1.1.0 (199) answered: Context 1,024, the runtime's
/// benchmark mode, no system message, greedy decoding. 1.1.0 (200)'s chat
/// wrote unrelated words and Bengali letters there: Context 4,096, no
/// benchmark mode, the chat's system message and sampler. On the CPU the
/// same file answered correctly with all of those (CI, 2026-10-26), so the
/// model, its tokenizer and its chat template are not the cause. Each
/// engine here starts the 12B file on the GPU and changes one of the GPU's
/// settings at a time, so one run on the phone shows which one the GPU
/// needs. It never touches the chat's engine, settings or history.
public enum LargeModelChatCompare {
    /// What an engine is asked: the 12B check's question with its greedy
    /// decoding and no system message, or "こんにちはー！" as the chat sends
    /// it (the 12B's system message and sampler).
    public enum Prompt: String, Codable, Sendable {
        case check, chat
        public var text: String { self == .check ? LargeModelProbe.question : LargeModelChatCompare.hello }
        public var title: String { self == .check ? "確認の質問" : "「\(LargeModelChatCompare.hello)」" }
    }

    public struct Engine: Sendable, Identifiable, Equatable {
        public let id: String
        public let context: Int
        /// ExperimentalFlags.enableBenchmark while the engine initializes.
        public let benchmark: Bool
        public let float32: Bool
        /// Starts again from the previous engine's cache, as a chat's later
        /// starts do, instead of writing a cache of its own.
        public let reusesCache: Bool
        public let prompts: [Prompt]

        public var title: String {
            "\(id) Context \(context)・待つ設定\(benchmark ? "あり" : "なし")\(float32 ? "・32ビット" : "")\(reusesCache ? "・前のキャッシュで再起動" : "")"
        }
    }

    public static let hello = "こんにちはー！"
    /// A: 1.1.0 (201)'s chat. D: 200's chat on its first start; E: on a
    /// later start, from D's cache.
    public static let engines: [Engine] = [
        Engine(id: "A", context: 1024, benchmark: true, float32: false, reusesCache: false, prompts: [.check, .chat]),
        Engine(id: "B", context: 1024, benchmark: false, float32: false, reusesCache: false, prompts: [.check, .chat]),
        Engine(id: "C", context: 4096, benchmark: true, float32: false, reusesCache: false, prompts: [.check, .chat]),
        Engine(id: "D", context: 4096, benchmark: false, float32: false, reusesCache: false, prompts: [.check, .chat]),
        Engine(id: "E", context: 4096, benchmark: false, float32: false, reusesCache: true, prompts: [.chat]),
        Engine(id: "F", context: 4096, benchmark: true, float32: true, reusesCache: false, prompts: [.chat]),
    ]
    public static let maxOutputTokens = LargeModelProbe.maxOutputTokens
    /// A reply this slow is stopped; the next engine still runs.
    public static let replySeconds: Double = 120

    /// Whether a reply reads as Japanese: mostly kana and kanji, and little
    /// of the Latin and Bengali letters 200's garbled replies were made of.
    public static func readsAsJapanese(_ reply: String) -> Bool {
        var japanese = 0, other = 0
        for scalar in reply.unicodeScalars {
            switch scalar.value {
            case 0x3040...0x30FF, 0x4E00...0x9FFF: japanese += 1
            case 0x0980...0x09FF: other += 10
            case 0x41...0x5A, 0x61...0x7A: other += 1
            default: break
            }
        }
        return japanese >= 3 && japanese > other * 2
    }

    public struct Result: Codable, Sendable, Equatable {
        public var engine: String
        public var prompt: Prompt
        public var japanese: Bool
        public var loadSeconds: Double
        public var replySeconds: Double
        public var pieces: Int
        /// The reply's start; the prompts are fixed, so it holds none of
        /// the person's words.
        public var reply: String

        public init(engine: String, prompt: Prompt, reply: String, loadSeconds: Double, replySeconds: Double, pieces: Int) {
            self.engine = engine
            self.prompt = prompt
            self.japanese = LargeModelChatCompare.readsAsJapanese(reply)
            self.loadSeconds = loadSeconds
            self.replySeconds = replySeconds
            self.pieces = pieces
            self.reply = String(reply.prefix(80)).replacingOccurrences(of: "\n", with: " ")
        }

        public var line: String {
            let title = LargeModelChatCompare.engines.first { $0.id == engine }?.title ?? engine
            return "\(title) / \(prompt.title): \(japanese ? "○ 日本語" : "× 日本語ではない") · 読み込み \(String(format: "%.1f", loadSeconds))秒 · 回答 \(String(format: "%.1f", replySeconds))秒（\(pieces)回）「\(reply)」"
        }
    }

    /// One run, saved after every reply, so a run that iOS ended keeps what
    /// it reached, with the engine it was on.
    public struct Record: Codable, Sendable, Equatable, Identifiable {
        public var id = UUID()
        public var date = Date()
        public var appVersion = ""
        public var device = ""
        /// The 12B's chat settings the chat prompts used.
        public var chatSettings = ""
        /// The engine running, or "" once the run ended.
        public var running = ""
        public var results: [Result] = []
        public var failures: [String] = []
        public var finished = false

        public init() {}

        func chat(_ engine: String) -> Bool? {
            results.first { $0.engine == engine && $0.prompt == .chat }?.japanese
        }

        /// What the results say about the GPU's settings; empty until the
        /// engines it compares have answered.
        public var conclusion: [String] {
            var lines: [String] = []
            if let a = chat("A") { lines.append(a ? "201のチャットの設定（A）は日本語で答えました。" : "201のチャットの設定（A）でも崩れました。") }
            if let a = chat("A"), let b = chat("B"), let c = chat("C"), let d = chat("D") {
                if a && c && !b && !d { lines.append("待つ設定（ベンチマークモード）がGPUに必要です。Contextは原因ではありません。") }
                else if a && b && !c && !d { lines.append("Context 4096 が原因です。待つ設定は関係ありません。") }
                else if a && b && c && !d { lines.append("Context 4096 と待つ設定なしが重なったときだけ崩れます。") }
                else if a && b && c && d { lines.append("この起動ではどの組み合わせも日本語で答えました。") }
            }
            if let d = chat("D"), let e = chat("E"), d, !e { lines.append("200のチャットは2回目以降の起動（キャッシュを読む起動）で崩れます。") }
            if let c = chat("C"), let f = chat("F"), !c, f { lines.append("Context 4096 は32ビットなら答えます。") }
            return lines
        }

        public var summary: String {
            var lines = ["\(appVersion) · \(device)", "チャットの条件: \(chatSettings)"]
            lines += results.map(\.line)
            lines += failures
            if !running.isEmpty { lines.append("\(running) の途中で終了しました。iOSがアプリを終了した可能性があります。") }
            lines += conclusion
            return lines.joined(separator: "\n")
        }
    }

    /// The runs kept on the phone, newest first, at most `limit`.
    public struct Log: Sendable {
        public let url: URL
        public static let limit = 10
        public init(url: URL) { self.url = url }
        public func load() -> [Record] {
            guard let data = try? Data(contentsOf: url) else { return [] }
            let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
            return (try? decoder.decode([Record].self, from: data)) ?? []
        }
        /// Replaces the record with the same id, or puts it first.
        public func save(_ record: Record) {
            var records = load()
            if let index = records.firstIndex(where: { $0.id == record.id }) { records[index] = record }
            else { records.insert(record, at: 0) }
            let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            guard let data = try? encoder.encode(Array(records.prefix(Self.limit))) else { return }
            try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? data.write(to: url, options: .atomic)
        }
    }
}
