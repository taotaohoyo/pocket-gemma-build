import Foundation
import CryptoKit
#if canImport(CommonCrypto)
import CommonCrypto
#endif

/// Gemma 4 12B for developers (1.1.0 (200), 2026-10-26): usable only while
/// 開発者設定 is on and its password has been entered. The repository is
/// public, so the source holds a salted PBKDF2-SHA256 key of the password,
/// never the password; checking one takes a million rounds on purpose.
/// What is saved is a mark of the key, so a build with another password
/// asks again. Turning 開発者設定 off forgets the password (`lock`).
public enum DeveloperUnlock {
    /// 開発者設定's switch, as the views' @AppStorage keeps it.
    public static let developerSettingsKey = "show-developer-settings-v1"
    /// Holds `mark` once the password has been entered.
    public static let storageKey = "developer-unlock-v1"
    static let salt = Data(hex: "0be1ed8e9f1c9655c1adf979d7ffebf3")
    static let iterations = 1_000_000
    static let key = Data(hex: "75bd3bd2fff3191ad400feb4e37e841f60abb75c8c8e7a2a4d220749e2d56a81")
    /// A digest of the key: what the saved state says, not the key itself.
    static let mark = SHA256.hash(data: key).prefix(8).map { String(format: "%02x", $0) }.joined()

    /// Whether 12B can be used now: 開発者設定 on and the password entered.
    public static var isActive: Bool {
        let defaults = UserDefaults.standard
        return defaults.bool(forKey: developerSettingsKey) && defaults.string(forKey: storageKey) == mark
    }

    /// Saves the unlock: on the main thread, so the views' @AppStorage
    /// sees it, once `matches` said yes; and in the UI check app (Preview),
    /// whose tests can't hold the password.
    public static func rememberUnlock() { UserDefaults.standard.set(mark, forKey: storageKey) }

    public static func lock() { UserDefaults.standard.removeObject(forKey: storageKey) }

    /// Whether this is the password. Call it off the main thread: the check
    /// takes a moment on purpose.
    public static func matches(_ password: String) -> Bool {
        let typed = normalized(password)
        guard !typed.isEmpty, let derived = derive(typed, salt: salt, iterations: iterations, length: key.count),
              derived.count == key.count else { return false }
        // Every byte is compared, whatever the first difference.
        return zip(derived, key).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
    }

    /// Full-width letters and digits (a Japanese keyboard) read as their
    /// ASCII forms, and spaces around the password don't count; case does.
    static func normalized(_ password: String) -> String {
        password.precomposedStringWithCompatibilityMapping.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func derive(_ password: String, salt: Data, iterations: Int, length: Int) -> Data? {
        #if canImport(CommonCrypto)
        let saltBytes = [UInt8](salt)
        var derived = [UInt8](repeating: 0, count: length)
        let status: Int32 = CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), password, password.utf8.count,
                                                 saltBytes, saltBytes.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256),
                                                 UInt32(iterations), &derived, derived.count)
        return status == Int32(kCCSuccess) ? Data(derived) : nil
        #else
        return nil
        #endif
    }
}

private extension Data {
    init(hex: String) {
        var bytes: [UInt8] = []
        var index = hex.startIndex
        while index < hex.endIndex, let end = hex.index(index, offsetBy: 2, limitedBy: hex.endIndex),
              let byte = UInt8(hex[index..<end], radix: 16) {
            bytes.append(byte)
            index = end
        }
        self.init(bytes)
    }
}
