import Foundation

/// The developer 12B check (2026-10-26): Gemma 4 12B started once, from a
/// folder of its own, answering one fixed question, to learn whether it runs
/// on this phone, with how much memory and how fast, and why not when it
/// doesn't. It never touches the chat's engine, saved settings or history,
/// and it unlocks nothing (12B is open to everyone since 1.1.0 (204)).
/// Once the chat has a verified copy of the file, the check reads that one.
///
/// In Oct 2026 the 12B was withdrawn because mapping its file failed with
/// ENOMEM: the app had no room in its address space. TestFlight builds have
/// Extended Virtual Addressing and Increased Memory Limit since 1.0.120.
public enum LargeModelProbe {
    public static let model = ModelSpec.gemma12B
    /// The only input, so the native messages never hold the user's text.
    public static let question = "日本の首都はどこですか？一文で答えてください。"
    public static let maxOutputTokens = 48
    /// A small context keeps the KV cache small: the check is about starting
    /// and writing, not long chats.
    public static let contextTokens = 1024
    /// A reply this slow is a result too: it is stopped rather than holding
    /// the check open.
    public static let replySeconds: Double = 600

    public enum Backend: String, Codable, CaseIterable, Identifiable, Sendable {
        case cpu, gpu
        public var id: String { rawValue }
        public var title: String { self == .cpu ? "CPU" : "GPU" }
    }

    /// What must be free before the check starts. These are the check's own
    /// margins, never a way around iOS's limits: when one is short the check
    /// doesn't start, and nothing raises or skips a limit.
    public enum Requirement {
        /// The file is mapped as one block, with the CPU's packed weights
        /// beside it: E4B's start took about 1.8 times its file in address
        /// space on the phone (2026-10-21).
        public static func addressSpace(fileBytes: Int64) -> UInt64 { UInt64(max(0, fileBytes)) * 2 + 1_000_000_000 }
        /// Memory iOS still lets the app use, once the chat's model is
        /// released. E4B's highest measured use was 1.93 GB for a 3.66 GB
        /// file; the 12B file is 1.9 times larger.
        public static let availableMemory: UInt64 = 4_500_000_000
        /// Room for the packed weights a first start writes to its cache.
        public static func disk(fileBytes: Int64) -> Int64 { fileBytes + 1_000_000_000 }
    }

    public enum Blocker: Equatable, Sendable {
        case fileMissing
        case alreadyRanThisLaunch
        case addressSpace(needed: UInt64, largestFree: UInt64)
        case memory(needed: UInt64, available: UInt64)
        case disk(needed: Int64, free: Int64)

        public var message: String {
            func gb<T: BinaryInteger>(_ bytes: T) -> String { String(format: "%.2f GB", Double(bytes) / 1_000_000_000) }
            switch self {
            case .fileMissing:
                return "12Bのファイルがありません。先にダウンロードしてください。"
            case .alreadyRanThisLaunch:
                return "この起動では確認済みです。正しく測るため、アプリを完全に終了して開き直してから実行してください。"
            case .addressSpace(let needed, let largestFree):
                return "アドレス空間の連続した空きが足りません（必要 \(gb(needed)) / 空き \(gb(largestFree))）。Extended Virtual Addressing のない署名では12Bを読み込めません。TestFlight版で確認してください。"
            case .memory(let needed, let available):
                return "使えるメモリが足りません（必要 \(gb(needed)) / 現在 \(gb(available))）。他のアプリを閉じ、アプリを開き直してから実行してください。"
            case .disk(let needed, let free):
                return "空き容量が足りません（必要 \(gb(needed)) / 空き \(gb(free))）。"
            }
        }

        /// What a chat says when 12B can't start (`chatBlockers`): open to
        /// everyone since 1.1.0 (204), so in the app's languages; `message`
        /// stays the developer check's, in Japanese.
        public var chatMessage: String {
            func gb<T: BinaryInteger>(_ bytes: T) -> String { String(format: "%.2f GB", Double(bytes) / 1_000_000_000) }
            switch self {
            case .addressSpace:
                return String(localized: "この署名ではアドレス空間が足りないため、読み込めません。TestFlight版で使ってください。")
            case .memory(let needed, let available):
                return String(localized: "使えるメモリが足りません（必要 \(gb(needed)) / 現在 \(gb(available))）。ほかのアプリを閉じ、Fieluaを開き直してから送ってください。")
            default:
                return message
            }
        }
    }

    /// Why the check can't start now; empty when it can. `availableMemory`
    /// is read after the chat's model was released; nil only where an app
    /// has no iOS memory limit at all (the simulator, LargeModelProbeRunner).
    public static func blockers(fileReady: Bool, ranThisLaunch: Bool, largestFreeAddress: UInt64?,
                                availableMemory: UInt64?, freeDisk: Int64, cacheBytes: Int64,
                                fileBytes: Int64 = model.byteCount) -> [Blocker] {
        var found: [Blocker] = []
        if !fileReady { found.append(.fileMissing) }
        if ranThisLaunch { found.append(.alreadyRanThisLaunch) }
        let space = Requirement.addressSpace(fileBytes: fileBytes)
        // An unreadable address space is no evidence of room.
        if (largestFreeAddress ?? 0) < space { found.append(.addressSpace(needed: space, largestFree: largestFreeAddress ?? 0)) }
        if let availableMemory, availableMemory < Requirement.availableMemory {
            found.append(.memory(needed: Requirement.availableMemory, available: availableMemory))
        }
        // A cache from an earlier start is reused; only a first start writes one.
        let disk = cacheBytes > fileBytes / 2 ? 0 : Requirement.disk(fileBytes: fileBytes)
        if freeDisk < disk { found.append(.disk(needed: disk, free: freeDisk)) }
        return found
    }

    /// Whether this launch's address space has room to map 12B: the
    /// sideload's signature (no Extended Virtual Addressing) has none, and
    /// 12B's card says so. Set once at launch, as PhotoDetail's.
    public private(set) static var twelveBFitsAtLaunch = true
    public static func offer(atLaunch space: AddressSpace?) {
        twelveBFitsAtLaunch = (space?.largestFree ?? 0) >= Requirement.addressSpace(fileBytes: model.byteCount)
    }

    /// Why 12B can't start in a chat now (1.1.0 (200)); empty when it can.
    /// The check's own room for its start, read after the chat's previous
    /// model was released: without Extended Virtual Addressing (the
    /// sideload's signature) the file has no block to map into, and a
    /// failed mapping keeps address space until the app restarts. The file
    /// and the disk are ModelStore's.
    public static func chatBlockers(largestFreeAddress: UInt64?, availableMemory: UInt64?) -> [Blocker] {
        blockers(fileReady: true, ranThisLaunch: false, largestFreeAddress: largestFreeAddress,
                 availableMemory: availableMemory, freeDisk: .max, cacheBytes: 0)
    }

    /// One check, saved before each stage so a check that iOS ended (out of
    /// memory) is still there after the relaunch, as "running" at its stage.
    public struct Record: Codable, Sendable, Equatable, Identifiable {
        public var id = UUID()
        public var date = Date()
        public var appVersion = ""
        public var device = ""
        public var backend: Backend
        public var contextTokens = LargeModelProbe.contextTokens
        /// checks, engine_initialization, conversation_creation,
        /// text_generation, release, complete.
        public var stage = "checks"
        /// running, success, failed, timeout, blocked.
        public var result = "running"
        public var failure: String?
        public var failureKind: String?
        public var nativeLines: [String] = []
        /// The memory entitlements the app's signature carries.
        public var entitlements: [String]?
        public var availableMemoryAtStart: UInt64?
        public var largestFreeAddressAtStart: UInt64?
        public var freeDiskAtStart: Int64?
        public var initializationSeconds: Double?
        /// From sending the question to its first text: mostly the prefill.
        public var firstTextSeconds: Double?
        public var replySeconds: Double?
        /// Streamed pieces; LiteRT-LM sends about one token per piece.
        public var replyPieces: Int?
        /// Tokens the conversation holds after the reply, and the prompt's
        /// share of them (the SDK's benchmark), when the SDK reports them.
        public var conversationTokens: Int?
        public var promptTokens: Int?
        public var reply: String?
        public var answeredTokyo: Bool?
        public var peakFootprint: UInt64?
        public var lowestAvailableMemory: UInt64?
        public var lowestLargestFreeAddress: UInt64?
        /// Address space still mapped after the engine was released, beyond
        /// what was mapped before the check.
        public var mappedAfterRelease: Int64?
        public var cacheBytes: Int64?

        public init(backend: Backend) { self.backend = backend }

        /// Reply tokens per second after the first text: the SDK's counts
        /// when it has them, otherwise the streamed pieces.
        public var decodeTokensPerSecond: Double? {
            guard let first = firstTextSeconds, let total = replySeconds, total > first + 0.05 else { return nil }
            let tokens: Int?
            if let all = conversationTokens, let prompt = promptTokens, all > prompt { tokens = all - prompt }
            else { tokens = replyPieces }
            guard let tokens, tokens > 1 else { return nil }
            return Double(tokens - 1) / (total - first)
        }

        public var summary: String {
            func gb<T: BinaryInteger>(_ bytes: T?) -> String {
                bytes.map { String(format: "%.2f GB", Double($0) / 1_000_000_000) } ?? "不明"
            }
            func seconds(_ value: Double?) -> String { value.map { String(format: "%.1f秒", $0) } ?? "不明" }
            let outcome: String
            switch result {
            case "success": outcome = "成功"
            case "blocked": outcome = "開始前に中止"
            case "timeout": outcome = "時間切れ"
            case "running": outcome = "途中で終了（\(stage)）。iOSがメモリ不足でアプリを終了した可能性があります"
            default: outcome = "失敗（\(stage)）"
            }
            var lines = ["\(LargeModelProbe.model.name) · \(backend.title) · Context \(contextTokens) · \(outcome)"]
            if let entitlements {
                lines.append("署名: EVA \(entitlements.contains(SignedEntitlements.extendedVirtualAddressing) ? "あり" : "なし") · IML \(entitlements.contains(SignedEntitlements.increasedMemoryLimit) ? "あり" : "なし")")
            }
            lines.append("開始時: 使えるメモリ \(gb(availableMemoryAtStart)) · 最大の連続した空き \(gb(largestFreeAddressAtStart))")
            if result != "blocked" {
                lines.append("読み込み \(seconds(initializationSeconds)) · 最初の文字まで \(seconds(firstTextSeconds)) · 回答全体 \(seconds(replySeconds))")
                if let speed = decodeTokensPerSecond { lines.append(String(format: "生成速度: 約%.1fトークン/秒", speed)) }
                lines.append("使用メモリの観測ピーク \(gb(peakFootprint)) · 使えるメモリの最小 \(gb(lowestAvailableMemory)) · 連続した空きの最小 \(gb(lowestLargestFreeAddress))")
                if let mapped = mappedAfterRelease { lines.append("解放後に残ったアドレス空間: \(gb(max(0, mapped)))") }
                if let cacheBytes { lines.append("キャッシュ: \(gb(cacheBytes))") }
            }
            if let reply { lines.append("回答: \(reply)") }
            if let failure { lines.append("理由: \(failure)") }
            return lines.joined(separator: "\n")
        }
    }

    /// The checks kept on the phone, newest first, at most `limit`.
    public struct Log {
        public let url: URL
        public static let limit = 12
        public init(url: URL) { self.url = url }
        public func load() -> [Record] {
            guard let data = try? Data(contentsOf: url) else { return [] }
            let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
            return (try? decoder.decode([Record].self, from: data)) ?? []
        }
        /// Replaces the record with the same id, or puts it first.
        public func save(_ record: Record) {
            var records = load()
            if let index = records.firstIndex(where: { $0.id == record.id }) { records[index] = record }
            else { records.insert(record, at: 0) }
            let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            guard let data = try? encoder.encode(Array(records.prefix(Self.limit))) else { return }
            try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? data.write(to: url, options: .atomic)
        }
        public func clear() { try? FileManager.default.removeItem(at: url) }
    }
}
