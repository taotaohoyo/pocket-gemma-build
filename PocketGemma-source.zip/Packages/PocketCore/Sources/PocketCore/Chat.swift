import Foundation

public enum ChatRole: String, Codable, Sendable {
    case user, assistant
}

public enum ReplyState: String, Codable, Sendable {
    case complete, generating, stopped, failed
}

public struct ChatMessage: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public let role: ChatRole
    public var text: String
    public var state: ReplyState
    public let createdAt: Date
    // Optional so pre-attachment archives remain readable without migration.
    public var attachments: [ChatAttachment]?
    public var media: [ChatAttachment] { attachments ?? [] }
    /// A reply's web searches: what it sent and the pages it read. nil for
    /// replies that didn't search, and in older archives.
    public var webSearch: WebSearchRecord?
    /// true for a photo or video sent with nothing typed (1.1.0 (198)): the
    /// conversation shows the media alone, and `text`, the ask written for
    /// it, goes only to the model. nil otherwise and in older archives.
    public var hidesText: Bool?
    /// What the person sees of the message's text.
    public var shownText: String { hidesText == true ? "" : text }

    public init(id: UUID = UUID(), role: ChatRole, text: String, state: ReplyState = .complete,
                attachments: [ChatAttachment] = []) {
        self.id = id
        self.role = role
        self.text = text
        self.state = state
        self.createdAt = Date()
        self.attachments = attachments.isEmpty ? nil : attachments
    }
}

public struct ChatThread: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public var messages: [ChatMessage]
    public var updatedAt: Date
    // Missing in old archives: those conversations used Gemma E4B.
    public var modelID: String?
    /// The chat's web search switch; off (nil) unless the person turns it on.
    public var webSearch: Bool?

    /// `id`: a new chat's own, unless the Apple Watch named it (WatchHistory).
    public init(id: UUID = UUID(), modelID: String? = nil) {
        self.id = id
        messages = []
        updatedAt = Date()
        self.modelID = modelID
    }

    public var title: String {
        guard let first = messages.first(where: { $0.role == .user }) else { return String(localized: "新しいチャット") }
        // A chat opened with a photo, video or spoken question alone is
        // named by it.
        if first.hidesText == true {
            if first.media.contains(where: { $0.kind == .audio }) { return String(localized: "音声") }
            return first.media.contains { $0.kind == .video } ? String(localized: "動画") : String(localized: "写真")
        }
        return String(first.text.replacingOccurrences(of: "\n", with: " ").prefix(28))
    }

    public mutating func recoverInterruptedReplies() {
        for index in messages.indices where messages[index].state == .generating {
            messages[index].state = .stopped
        }
    }
}

public enum HistoryBuilder {
    /// Preserve complete user/assistant pairs, newest first, within a conservative
    /// UTF-8 budget. Never feed an interrupted or failed reply back to the model.
    /// This is a size heuristic, not an exact tokenizer. The runtime enforces the
    /// final context limit and the UI surfaces its errors.
    /// `inputByteBudget` sets a video's share of a turn (VideoDigest.Allowance).
    public static func recentPairs(_ messages: [ChatMessage], byteBudget: Int = 5000, visualTokenBudget: Int = 280,
                                   inputByteBudget: Int = GenerationSettings().inputByteBudget) -> [ChatMessage] {
        var pairs: [[ChatMessage]] = []
        var pending: ChatMessage?
        for message in messages {
            if message.role == .user {
                pending = message
            } else {
                if let user = pending, message.state == .complete, !message.text.isEmpty {
                    pairs.append([user, message])
                }
                pending = nil
            }
        }
        var result: [ChatMessage] = []
        var used = 0
        for pair in pairs.reversed() {
            let count = pair.reduce(0) { $0 + $1.text.utf8.count + $1.media.reduce(0) { $0 + $1.contextByteCost(visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget) } }
            guard used + count <= byteBudget else { break }
            result.insert(contentsOf: pair, at: 0)
            used += count
        }
        return result
    }
}

