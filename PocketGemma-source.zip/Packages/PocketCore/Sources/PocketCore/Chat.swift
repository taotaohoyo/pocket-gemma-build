import Foundation

public enum ChatRole: String, Codable, Sendable {
    case user, assistant
}

public enum ReplyState: String, Codable, Sendable {
    case complete, generating, stopped, failed
}

public struct ChatMessage: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public let role: ChatRole
    public var text: String
    public var state: ReplyState
    public let createdAt: Date
    // Optional so pre-attachment archives remain readable without migration.
    public var attachments: [ChatAttachment]?
    public var media: [ChatAttachment] { attachments ?? [] }
    /// A reply's web searches: what it sent and the pages it read. nil for
    /// replies that didn't search, and in older archives.
    public var webSearch: WebSearchRecord?
    /// true for a photo or video sent with nothing typed (1.1.0 (198)): the
    /// conversation shows the media alone, and `text`, the ask written for
    /// it, goes only to the model. nil otherwise and in older archives.
    public var hidesText: Bool?
    /// What the person sees of the message's text.
    public var shownText: String { hidesText == true ? "" : text }
    /// What Smart Mode chose for a reply (1.1.0 (249)): the model, how it
    /// replied and what it could not give. nil for a reply without Smart
    /// Mode, and in older archives.
    public var smart: SmartReply?
    /// The earlier exchanges Smart Memory gave the reply (1.1.0 (251)), by
    /// id. nil without Smart Memory, and in older archives.
    public var memory: MemoryRecall?
    /// The on-device model that wrote a reply, by id (1.1.0 (296)), so
    /// Smart Memory can say whose words it quotes (ReplyAuthor). nil for
    /// the person's messages, for a reply from Claude or the PC (its chat
    /// names the model), and in older archives.
    public var modelID: String?
    /// The files a Claude reply made with code execution (1.1.0 (260)).
    /// nil for any other reply, and in older archives.
    public var claudeFiles: [ClaudeMadeFile]?
    /// How a Claude reply ended when it paused or reached its length limit
    /// (1.1.0 (260)). nil otherwise, and in older archives.
    public var claudeEnd: ClaudeReplyEnd?

    public init(id: UUID = UUID(), role: ChatRole, text: String, state: ReplyState = .complete,
                attachments: [ChatAttachment] = []) {
        self.id = id
        self.role = role
        self.text = text
        self.state = state
        self.createdAt = Date()
        self.attachments = attachments.isEmpty ? nil : attachments
    }
}

public struct ChatThread: Codable, Identifiable, Equatable, Sendable {
    public let id: UUID
    public var messages: [ChatMessage]
    public var updatedAt: Date
    // Missing in old archives: those conversations used Gemma E4B.
    public var modelID: String?
    /// The chat's web search switch; off (nil) unless the person turns it on.
    /// In Smart Mode it is the genre ウェブ検索 (`genre`).
    public var webSearch: Bool?
    /// The chat's 質問のジャンル in Smart Mode (1.1.0 (249)), by its raw
    /// value, so a genre a later version adds reads as 自動 here. nil for
    /// 自動, for ウェブ検索 (`webSearch`) and in older archives, whose chats
    /// are on 自動.
    public var genreID: String?
    /// true when the person chose the chat's model (the model menu, or モデル
    /// 管理's 「このモデルで会話を始める」): Smart Mode leaves the chat's model
    /// and its reply mode as chosen. nil otherwise and in older archives.
    public var modelPinned: Bool?
    /// PCと接続 (1.1.0 (253)): the chat's replies come from this model on
    /// the person's PC (PCLink). Its `modelID` stays the iPhone's model the
    /// chat was opened beside. nil for a chat on the iPhone, and in older
    /// archives.
    public var pc: PCChatTarget?
    /// Claude (1.1.0 (257)): the chat's replies come from Claude through
    /// the developer's relay (ClaudeLink). Its `modelID` stays the
    /// iPhone's model the chat was opened beside. nil for a chat on the
    /// iPhone, and in older archives.
    public var claude: ClaudeChatTarget?
    /// A Claude chat's ファイル作成 switch (1.1.0 (260)): its replies may
    /// make files with code execution. Its ウェブ検索 is `webSearch`, which
    /// Claude does itself. nil (off) otherwise, and in older archives.
    public var makesFiles: Bool?
    /// The code container a Claude chat's replies make files in, while
    /// Anthropic keeps it (1.1.0 (260)).
    public var claudeContainer: ClaudeContainer?

    /// Answered off the iPhone: on the PC or by Claude. A PC chat takes
    /// text alone; a Claude chat photos and files too, and Claude's own
    /// web search (1.1.0 (260)). Neither has Smart Mode or Smart Memory.
    public var isRemote: Bool { pc != nil || claude != nil }

    /// `id`: a new chat's own, unless the Apple Watch named it (WatchHistory).
    public init(id: UUID = UUID(), modelID: String? = nil) {
        self.id = id
        messages = []
        updatedAt = Date()
        self.modelID = modelID
    }

    /// The chat's genre: ウェブ検索 while its search switch is on, else the
    /// genre saved, else 自動. Setting one sets the search switch with it.
    public var genre: SmartGenre {
        get {
            if webSearch == true { return .webSearch }
            return genreID.flatMap(SmartGenre.init(rawValue:)) ?? .auto
        }
        set {
            webSearch = newValue == .webSearch ? true : nil
            genreID = newValue == .auto || newValue == .webSearch ? nil : newValue.rawValue
        }
    }

    /// The kinds of attachment the chat's messages carry.
    public var attachmentKinds: Set<ChatAttachment.Kind> {
        Set(messages.flatMap { $0.media.map(\.kind) })
    }

    public var title: String {
        guard let first = messages.first(where: { $0.role == .user }) else { return String(localized: "新しいチャット") }
        // A chat opened with a photo, video or spoken question alone is
        // named by it.
        if first.hidesText == true {
            if first.media.contains(where: { $0.kind == .audio }) { return String(localized: "音声") }
            return first.media.contains { $0.kind == .video } ? String(localized: "動画") : String(localized: "写真")
        }
        return String(first.text.replacingOccurrences(of: "\n", with: " ").prefix(28))
    }

    public mutating func recoverInterruptedReplies() {
        for index in messages.indices where messages[index].state == .generating {
            messages[index].state = .stopped
        }
    }
}

public enum HistoryBuilder {
    /// Preserve complete user/assistant pairs, newest first, within a conservative
    /// UTF-8 budget. Never feed an interrupted or failed reply back to the model.
    /// This is a size heuristic, not an exact tokenizer. The runtime enforces the
    /// final context limit and the UI surfaces its errors.
    /// `inputByteBudget` sets a video's share of a turn (VideoDigest.Allowance).
    public static func recentPairs(_ messages: [ChatMessage], byteBudget: Int = 5000, visualTokenBudget: Int = 280,
                                   inputByteBudget: Int = GenerationSettings().inputByteBudget) -> [ChatMessage] {
        var pairs: [[ChatMessage]] = []
        var pending: ChatMessage?
        for message in messages {
            if message.role == .user {
                pending = message
            } else {
                if let user = pending, message.state == .complete, !message.text.isEmpty {
                    pairs.append([user, message])
                }
                pending = nil
            }
        }
        var result: [ChatMessage] = []
        var used = 0
        for pair in pairs.reversed() {
            let count = pair.reduce(0) { $0 + $1.text.utf8.count + $1.media.reduce(0) { $0 + $1.contextByteCost(visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget) } }
            guard used + count <= byteBudget else { break }
            result.insert(contentsOf: pair, at: 0)
            used += count
        }
        return result
    }
}

