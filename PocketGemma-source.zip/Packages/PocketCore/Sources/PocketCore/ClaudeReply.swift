import Foundation

// Claude in the app as in Fielua for the web (1.1.0 (260), the user's
// 2026-11-11 「web版で作成した機能などをすべてFielua ipaに移す」): photos,
// PDFs and files sent with a question, web search and file creation, a
// reply read again after its connection dropped, and the estimate of the
// credit left. The relay (claude-relay) does the work; here is what the
// app keeps and how it reads a reply, without UIKit or the network.

/// A file one of Claude's replies made with code execution: the relay ties
/// it to this person for 30 days and gives it to them alone.
public struct ClaudeMadeFile: Codable, Equatable, Hashable, Sendable, Identifiable {
    /// Anthropic's Files API id ("file_011…").
    public let id: String
    /// Its name, kind and size, once the relay told them (a moment after the reply).
    public var name: String?
    public var mimeType: String?
    public var size: Int?
    public var madeAt: Date

    public init(id: String, name: String? = nil, mimeType: String? = nil, size: Int? = nil, madeAt: Date = Date()) {
        self.id = id; self.name = name; self.mimeType = mimeType; self.size = size; self.madeAt = madeAt
    }

    /// Anthropic keeps what code execution made for 30 days; the app lets
    /// a file go a day early, as the web does.
    public static let keptDays = 29
    public func expired(now: Date = Date()) -> Bool { now.timeIntervalSince(madeAt) > Double(Self.keptDays) * 86_400 }

    /// "PDF", "Word"…: what kind of file it is, from its name.
    public var kind: String {
        let ext = (name.map { ($0 as NSString).pathExtension.lowercased() }) ?? ""
        switch ext {
        case "pdf": return "PDF"
        case "docx": return "Word"
        case "xlsx": return "Excel"
        case "pptx": return "PowerPoint"
        case "csv": return "CSV"
        case "txt", "md": return String(localized: "テキスト")
        case "png", "jpg", "jpeg", "gif", "webp": return String(localized: "画像")
        case "json": return "JSON"
        case "zip": return "ZIP"
        default: return String(localized: "ファイル")
        }
    }

    /// A picture the reply's card shows as well.
    public var isPicture: Bool {
        ["image/png", "image/jpeg", "image/gif", "image/webp"].contains(mimeType ?? "") && (size ?? 0) < 8 * 1024 * 1024
    }
}

/// The code container a chat's replies make files in: kept for the next
/// question, so a file made before can be changed, while Anthropic keeps it.
public struct ClaudeContainer: Codable, Equatable, Hashable, Sendable {
    public var id: String
    public var madeAt: Date
    public init(id: String, madeAt: Date = Date()) { self.id = id; self.madeAt = madeAt }
    /// Anthropic keeps a container 30 days from when it was made; the app lets it go a day early.
    public func live(now: Date = Date()) -> Bool { now.timeIntervalSince(madeAt) < 29 * 86_400 }
}

/// How a Claude reply ended, besides done, stopped or failed.
public enum ClaudeReplyEnd: String, Codable, Equatable, Sendable {
    /// Anthropic paused a long turn (pause_turn): 「続けて」 goes on.
    case paused
    /// It reached its length limit (max_tokens).
    case cutOff

    public var notice: String {
        switch self {
        case .paused: return String(localized: "ここで一度止まりました。「続けて」と送ると続きを書きます。")
        case .cutOff: return String(localized: "返信が長さの上限に達したため、ここで終わっています。")
        }
    }
}

/// What a Claude reply is doing now, for the line under the orb.
public enum ClaudeActivity: Equatable, Sendable {
    case searching(String)
    case reading
    case writingFile
    case runningCode
    case reconnecting

    public var line: String {
        switch self {
        case .searching(let query): return query.isEmpty ? String(localized: "ウェブで検索しています…") : String(localized: "「\(query)」をウェブで検索しています…")
        case .reading: return String(localized: "ページを読んでいます…")
        case .writingFile: return String(localized: "ファイルを書いています…")
        case .runningCode: return String(localized: "コードを実行しています…")
        case .reconnecting: return String(localized: "つなぎ直しています…")
        }
    }

    /// A few words for iOS's display of a reply in the background.
    public var short: String {
        switch self {
        case .searching: return String(localized: "ウェブを検索しています")
        case .reading: return String(localized: "ページを読んでいます")
        case .writingFile: return String(localized: "ファイルを書いています")
        case .runningCode: return String(localized: "コードを実行しています")
        case .reconnecting: return String(localized: "つなぎ直しています")
        }
    }
}

/// A reply's events as the chat shows them: the text (a paragraph of its
/// own after a search or code), what it searched and read, the pages it
/// cited first, the files it made, its container and how it ended.
public struct ClaudeReplyReader: Sendable {
    /// What the reply is doing now (a search, code), nil while it writes.
    public private(set) var activity: ClaudeActivity?
    public private(set) var queries: [String] = []
    public private(set) var pages: [WebSearchSource] = []
    public private(set) var citedURLs: [String] = []
    public private(set) var searchFailure: String?
    public private(set) var files: [String] = []
    public private(set) var container: String?
    public private(set) var end: ClaudeReplyEnd?
    public private(set) var servedModel: String?
    private var tools: [Int: (name: String, json: String)] = [:]
    private var afterTool = false
    private var wroteText = false
    private var endsWithNewline = false

    public init() {}

    /// Reads one event; returns the text it adds to the reply, if any.
    public mutating func read(_ event: ClaudeStreamEvent) -> String? {
        switch event {
        case .started(let model, let container):
            servedModel = model.isEmpty ? nil : model
            if let container { self.container = container }
        case .textStart(let text):
            // Text after a search or code starts a paragraph of its own;
            // text between citations runs on.
            var added = ""
            if afterTool && wroteText && !endsWithNewline { added = "\n\n" }
            afterTool = false
            activity = nil
            added += text
            return note(added)
        case .text(let text):
            return note(text)
        case .toolStart(let index, let name):
            tools[index] = (name, "")
            afterTool = true
            switch name {
            case "web_search": activity = .searching("")
            case "web_fetch": activity = .reading
            case "text_editor_code_execution": activity = .writingFile
            default: activity = .runningCode
            }
        case .toolInput(let index, let json):
            if var tool = tools[index] {
                tool.json += json
                tools[index] = tool
            }
        case .blockStop(let index):
            guard let tool = tools.removeValue(forKey: index), tool.name == "web_search" else { break }
            let object = (try? JSONSerialization.jsonObject(with: Data((tool.json.isEmpty ? "{}" : tool.json).utf8))) as? [String: Any]
            let query = (object?["query"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !query.isEmpty else { break }
            if !queries.contains(query), queries.count < 10 { queries.append(query) }
            activity = .searching(query)
        case .searchResults(let found):
            for page in found where !pages.contains(where: { $0.url == page.url }) && pages.count < 40 { pages.append(page) }
        case .searchFailed(let code):
            searchFailure = code
        case .cited(let page):
            if !pages.contains(where: { $0.url == page.url }), pages.count < 40 { pages.append(page) }
            if !citedURLs.contains(page.url) { citedURLs.append(page.url) }
        case .files(let ids):
            for id in ids where !files.contains(id) && files.count < 20 { files.append(id) }
        case .container(let id):
            container = id
        case .paused(let id):
            if let id { container = id }
            end = .paused
        case .cutOff:
            end = .cutOff
        case .thinking, .refused, .done, .failed, .alive:
            break
        }
        return nil
    }

    private mutating func note(_ text: String) -> String? {
        guard !text.isEmpty else { return nil }
        wroteText = true
        endsWithNewline = text.hasSuffix("\n")
        return text
    }

    /// What the reply searched, as the chat keeps it (WebSearchRecord): the
    /// pages it cited, or citing none the ones it read; nil without a search.
    public func search(generating: Bool) -> WebSearchRecord? {
        guard !queries.isEmpty || !pages.isEmpty || searchFailure != nil else { return nil }
        var record = WebSearchRecord()
        record.queries = queries
        let cited = citedURLs.compactMap { url in pages.first { $0.url == url } }
        // As the web: the pages it cited, at most eight.
        record.sources = Array((cited.isEmpty ? pages : cited).prefix(8))
        if let searchFailure, pages.isEmpty {
            record.failedQueries = queries
            // In Claude's words, never Tavily's: its search didn't answer.
            record.failure = .unavailable
        }
        if generating, case .searching(let query) = activity, !query.isEmpty { record.inProgress = query }
        return record
    }
}

/// The estimate of the credit left (GET /v1/status `credit`): the balance
/// the developer entered from Anthropic's Console, less what the replies
/// since then cost at list prices. Anthropic has no API for the balance.
public struct ClaudeCredit: Equatable, Sendable {
    public var percent: Double
    public var remainingUSD: Double
    public var budgetUSD: Double
    public var spentUSD: Double
    public var setAt: Date
    /// Whether friends see it too (the developer's switch).
    public var friends: Bool

    public init?(_ value: Any?) {
        guard let object = value as? [String: Any],
              let percent = (object["percent"] as? NSNumber)?.doubleValue,
              let remaining = (object["remainingUSD"] as? NSNumber)?.doubleValue,
              let budget = (object["budgetUSD"] as? NSNumber)?.doubleValue,
              let spent = (object["spentUSD"] as? NSNumber)?.doubleValue,
              let setAt = (object["setAt"] as? NSNumber)?.doubleValue else { return nil }
        self.percent = min(100, max(0, percent))
        remainingUSD = remaining; budgetUSD = budget; spentUSD = spent
        self.setAt = Date(timeIntervalSince1970: setAt / 1000)
        friends = object["friends"] as? Bool ?? false
    }

    public init(percent: Double, remainingUSD: Double, budgetUSD: Double, spentUSD: Double, setAt: Date, friends: Bool) {
        self.percent = percent; self.remainingUSD = remainingUSD; self.budgetUSD = budgetUSD
        self.spentUSD = spentUSD; self.setAt = setAt; self.friends = friends
    }

    /// Under 15%: the ring says so in the caution color.
    public var isLow: Bool { percent < 15 }

    /// "$12.34", "約 $0.05"…
    public static func dollars(_ value: Double) -> String {
        let rounded = (value * 100).rounded() / 100
        return "$" + String(format: rounded >= 100 ? "%.0f" : "%.2f", rounded)
    }
}

/// One attachment as the relay takes it (claude-relay src/turns.ts): an
/// image, a PDF or a text file, its bytes base64 and checked there by
/// their first bytes. `chars`: its share of the request's attachments.
public struct ClaudeAttachmentPart: Equatable, Sendable {
    public enum Kind: String, Sendable { case image, pdf, text }
    public var kind: Kind
    public var mediaType: String?
    public var data: String?
    public var text: String?
    public var name: String
    public var caption: String?

    public init(image base64: String, mediaType: String, name: String, caption: String? = nil) {
        kind = .image; self.mediaType = mediaType; data = base64; self.name = name; self.caption = caption
    }
    public init(pdf base64: String, name: String) { kind = .pdf; data = base64; self.name = name }
    public init(text: String, name: String) { kind = .text; self.text = text; self.name = name }

    public var json: [String: Any] {
        var object: [String: Any] = ["type": kind.rawValue, "name": name]
        if let mediaType { object["mediaType"] = mediaType }
        if let data { object["data"] = data }
        if let text { object["text"] = text }
        if let caption, !caption.isEmpty { object["caption"] = caption }
        return object
    }

    /// Base64 characters counted against the relay's ATTACHMENT_MB.
    public var chars: Int { data?.count ?? 0 }
    public var textBytes: Int { text?.utf8.count ?? 0 }
}

/// What one request may carry, as the relay checks it: newest first, the
/// rest named in the question's text instead.
public struct ClaudeAttachmentBudget: Sendable {
    /// All images and PDFs as base64 (GET /v1/status `attachments.bytes` × 4/3).
    public var chars: Int
    public static let maxImages = 100
    public static let maxDocuments = 20
    public static let maxTextFileBytes = 250 * 1024
    public static let maxTextFilesBytes = 500 * 1024
    public static let maxPartsPerTurn = 40
    private(set) var usedChars = 0
    private(set) var images = 0
    private(set) var documents = 0
    private(set) var textBytes = 0

    /// `bytes`: the relay's limit on the files themselves (3 MB of base64 ≈ 2.25 MB).
    public init(bytes: Int) { chars = max(0, bytes) * 4 / 3 }

    /// The base64 characters still free for images and PDFs.
    public var remainingChars: Int { chars - usedChars }

    /// Takes the parts of one attachment if they all fit; false (nothing taken) if not.
    public mutating func take(_ parts: [ClaudeAttachmentPart], alreadyInTurn: Int) -> Bool {
        let newChars = parts.reduce(0) { $0 + $1.chars }
        let newImages = parts.filter { $0.kind == .image }.count
        let newDocuments = parts.filter { $0.kind != .image }.count
        let newText = parts.reduce(0) { $0 + $1.textBytes }
        guard !parts.isEmpty, usedChars + newChars <= chars, images + newImages <= Self.maxImages,
              documents + newDocuments <= Self.maxDocuments, textBytes + newText <= Self.maxTextFilesBytes,
              parts.allSatisfy({ $0.textBytes <= Self.maxTextFileBytes }),
              alreadyInTurn + parts.count <= Self.maxPartsPerTurn else { return false }
        usedChars += newChars; images += newImages; documents += newDocuments; textBytes += newText
        return true
    }
}

/// A turn of a Claude request: its text, and the attachments of a user
/// turn, before they are read and sized (the app does that).
public struct ClaudeTurn: Equatable, Sendable {
    public var role: String
    public var content: String
    public var attachments: [ChatAttachment]
    public init(role: String, content: String, attachments: [ChatAttachment] = []) {
        self.role = role; self.content = content; self.attachments = attachments
    }
}

extension ClaudeContext {
    /// The kinds Claude reads: photos, PDFs and text files. A recording or
    /// a video is named in the text, never sent.
    public static func sends(_ attachment: ChatAttachment) -> Bool {
        attachment.kind == .image || attachment.kind == .file
    }

    /// The turns a reply needs, with attachments (1.1.0 (260)): the latest
    /// complete exchanges, newest kept first, within the relay's limits,
    /// then the question with its own. Failed or stopped replies are never
    /// sent back. Which attachments fit the request is the app's to decide
    /// (it reads and sizes them), newest first.
    public static func turns(history: [ChatMessage], question: String, attachments: [ChatAttachment]) -> [ClaudeTurn] {
        var pairs: [(ChatMessage, String)] = []
        var pending: ChatMessage?
        for message in history {
            if message.role == .user {
                pending = message
            } else {
                if let asked = pending, message.state == .complete,
                   !asked.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !asked.media.isEmpty,
                   !message.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    pairs.append((asked, message.text))
                }
                pending = nil
            }
        }
        var kept: [ClaudeTurn] = []
        var used = question.utf8.count
        for (asked, answer) in pairs.reversed() {
            let text = asked.text
            let cost = text.utf8.count + answer.utf8.count
            guard text.utf8.count <= maxTurnBytes, answer.utf8.count <= maxTurnBytes,
                  used + cost <= byteBudget, kept.count + 3 <= maxMessages else { break }
            kept.insert(contentsOf: [ClaudeTurn(role: "user", content: text, attachments: asked.media),
                                     ClaudeTurn(role: "assistant", content: answer)], at: 0)
            used += cost
        }
        return kept + [ClaudeTurn(role: "user", content: question, attachments: attachments)]
    }

    /// The note in a turn's text for what it carried and wasn't sent this
    /// time: 「（前に添付した「a.pdf」は、今回は送っていません）」.
    public static func notSentNote(_ names: [String]) -> String {
        String(localized: "（前に添付した\(names.map { "「\($0)」" }.joined())は、今回は送っていません）")
    }
}

/// A key the relay keeps a reply under (/v1/replies/:key): 32 hex
/// characters, chosen before asking.
public enum ClaudeReplyKey {
    public static func make() -> String {
        var generator = SystemRandomNumberGenerator()
        return (0..<16).map { _ in String(format: "%02x", UInt8.random(in: .min ... .max, using: &generator)) }.joined()
    }
    public static func isValid(_ key: String) -> Bool {
        key.count == 32 && key.allSatisfy { $0.isHexDigit && ($0.isNumber || $0.isLowercase) }
    }
}
