import Foundation

/// Model downloads over cellular data (モデルと設定's モバイル通信でもダウンロード,
/// 0.0.1 (132)). The background session lets every download use cellular,
/// and each download's request decides: a request that says no never uses
/// it (Apple: URLRequest.allowsCellularAccess), whatever the session allows.
public enum ModelDownload {
    /// Where the choice is kept; off until the person turns it on, as a
    /// model is several gigabytes.
    public static let cellularKey = "model-download-cellular-v1"

    public static func request(for spec: ModelSpec, cellular: Bool) -> URLRequest {
        var request = URLRequest(url: spec.downloadURL)
        request.allowsCellularAccess = cellular
        return request
    }

    /// Whether a running download starts over when the switch changes. A
    /// download's choice is fixed when it starts; one that has received
    /// less than 1% (the card still reads 0%) loses next to nothing by
    /// starting again, while starting over a larger part would throw it away.
    public static func startsOver(receivedBytes: Int64, expectedBytes: Int64) -> Bool {
        receivedBytes * 100 < max(expectedBytes, 1)
    }
}

/// The networks the phone has now, as a model download sees them.
public struct DownloadNetwork: Equatable, Sendable {
    /// Wi-Fi, or another network that is not cellular, is up.
    public var hasWiFi: Bool
    /// Some network is up; without Wi-Fi, that is cellular.
    public var isOnline: Bool
    /// iOS's 設定 turned cellular data off for this app.
    public var cellularDenied: Bool

    public init(hasWiFi: Bool, isOnline: Bool, cellularDenied: Bool) {
        self.hasWiFi = hasWiFi; self.isOnline = isOnline; self.cellularDenied = cellularDenied
    }

    /// Before iOS first reports: nothing to wait for.
    public static let unknown = Self(hasWiFi: true, isOnline: true, cellularDenied: false)

    /// What a download waits for, or nil when it can receive now. A
    /// background download waits without a word, so the card says why.
    public func wait(usesCellular: Bool) -> DownloadWait? {
        if hasWiFi || (usesCellular && isOnline) { return nil }
        if cellularDenied { return .cellularDenied }
        return usesCellular ? .network : .wifi
    }

    /// On cellular only, with the switch off: a new download would wait.
    public func waitsForWiFi(allowsCellular: Bool) -> Bool {
        !hasWiFi && isOnline && !allowsCellular
    }
}

public enum DownloadWait: Equatable, Sendable {
    /// Cellular only (or nothing), and this download may not use cellular.
    case wifi
    /// No Wi-Fi, and iOS's 設定 turned cellular data off for this app.
    case cellularDenied
    /// This download may use cellular, but there is no network at all.
    case network

    /// The line above the progress bar.
    public func status(name: String, percent: Int) -> String {
        switch self {
        case .wifi, .cellularDenied: return String(localized: "\(name)はWi-Fiを待っています · \(percent)%")
        case .network: return String(localized: "\(name)はインターネット接続を待っています · \(percent)%")
        }
    }

    /// Where the card's words send the person for モバイル通信でもダウンロード.
    public enum SwitchPlace: Sendable {
        /// Below the card, as on the setup's page.
        case below
        /// On モデル管理, a page up: a series' page has no switch of its own
        /// since 1.1.0 (293) (Hachimoto さん's directive of 2026-11-17).
        case modelManagement
    }

    /// The way out, under the progress bar.
    /// - Parameters:
    ///   - received: the download has 1% or more, so it keeps its own choice.
    ///   - switchOn: モバイル通信でもダウンロード is on.
    ///   - place: where that switch is from the card.
    public func hint(received: Bool, switchOn: Bool, place: SwitchPlace = .below) -> String? {
        switch self {
        case .wifi:
            // What came keeps the Wi-Fi-only choice it started with, and the
            // 中止 asks since 1.1.0 (293) whether to keep it: to receive over
            // cellular, the words name the choice that deletes it.
            if received {
                if switchOn {
                    return String(localized: "Wi-Fiにつながると続きから受け取ります。モバイル通信で受け取るには、「ダウンロードを中止」で「削除して中止」を選んでから、もう一度ダウンロードしてください。")
                }
                return place == .below
                    ? String(localized: "Wi-Fiにつながると続きから受け取ります。モバイル通信で受け取るには、「ダウンロードを中止」で「削除して中止」を選び、下の「モバイル通信でもダウンロード」をオンにして、もう一度ダウンロードしてください。")
                    : String(localized: "Wi-Fiにつながると続きから受け取ります。モバイル通信で受け取るには、「ダウンロードを中止」で「削除して中止」を選び、モデル管理の「モバイル通信でもダウンロード」をオンにして、もう一度ダウンロードしてください。")
            }
            // With the switch on, this download is already starting again.
            if switchOn { return nil }
            return place == .below
                ? String(localized: "モバイル通信でも受け取るには、下の「モバイル通信でもダウンロード」をオンにしてください。")
                : String(localized: "モバイル通信でも受け取るには、モデル管理の「モバイル通信でもダウンロード」をオンにしてください。")
        case .cellularDenied:
            return String(localized: "iOSの「設定」で、このアプリのモバイルデータ通信がオフになっています。")
        case .network:
            return nil
        }
    }
}
