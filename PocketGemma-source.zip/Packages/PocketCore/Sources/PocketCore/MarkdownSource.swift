import Foundation

/// Text-level steps around Foundation's Markdown parser: splitting a reply
/// into blocks that can be parsed and drawn on their own, closing syntax a
/// streaming reply has not finished yet, taking LaTeX out of the text so
/// Markdown never touches it, and letting emphasis work next to Japanese
/// punctuation.
public enum MarkdownSource {
    /// Inserted where CommonMark would not see emphasis next to Japanese
    /// punctuation (`**「強調」**です`); removed again after parsing.
    static let flankingSpace: Character = "\u{200A}"
    static let mathOpen: Character = "\u{E000}"
    static let mathClose: Character = "\u{E001}"

    // MARK: Chunks

    /// The reply split at blank lines that start a new top-level block, so
    /// a growing reply only parses its last chunk again. Fenced code, math
    /// blocks, indented continuations and lists stay in one chunk.
    public static func chunks(_ source: String) -> [String] {
        let lines = self.lines(source)
        let fenced = fencedLines(lines)
        let math = mathBlockLines(lines, fenced: fenced)
        var chunks: [String] = []
        var current: [Substring] = []
        var index = 0
        while index < lines.count {
            let line = lines[index]
            guard isBlank(line), !fenced[index], !math[index] else {
                current.append(line)
                index += 1
                continue
            }
            var next = index + 1
            while next < lines.count, isBlank(lines[next]) { next += 1 }
            if next == lines.count { break }
            let following = lines[next]
            let startsBlock = !(following.first == " " || following.first == "\t")
            let continuesList = isListMarker(following) && current.contains(where: isListMarker)
            if startsBlock, !continuesList, !current.isEmpty {
                chunks.append(current.joined(separator: "\n"))
                current = []
                index = next
            } else {
                current.append(contentsOf: lines[index..<next])
                index = next
            }
        }
        if !current.isEmpty { chunks.append(current.joined(separator: "\n")) }
        return chunks
    }

    /// Link reference definitions (`[id]: https://…`) from the whole reply,
    /// added to every chunk so a reference resolves wherever it is used.
    public static func referenceDefinitions(_ source: String) -> String {
        let lines = self.lines(source)
        let fenced = fencedLines(lines)
        return lines.indices.filter { index in
            guard !fenced[index] else { return false }
            let line = lines[index].drop(while: { $0 == " " })
            guard line.first == "[", !line.hasPrefix("[^"), let close = line.firstIndex(of: "]") else { return false }
            let rest = line[line.index(after: close)...]
            return rest.first == ":" && rest.dropFirst().contains(where: { !$0.isWhitespace })
        }.map { String(lines[$0]) }.joined(separator: "\n")
    }

    // MARK: Streaming

    /// Closes what a streaming reply has opened but not finished, so the
    /// text never shows raw syntax or flips between layouts: an open code
    /// fence or math block is closed, half a table row and a lone `-` (which
    /// would turn the line above into a heading) wait, and emphasis, code
    /// spans and links on the last line are closed or held back.
    public static func repairStreaming(_ chunk: String) -> String {
        var lines = self.lines(chunk).map(String.init)
        while let last = lines.last, isBlank(Substring(last)) { lines.removeLast() }
        guard !lines.isEmpty else { return "" }
        if let fence = openFence(lines.map { Substring($0) }) {
            lines.append(fence)
            return lines.joined(separator: "\n")
        }
        let substrings = lines.map { Substring($0) }
        if let closing = openMathBlock(substrings, fenced: fencedLines(substrings)) {
            lines.append(closing)
            return lines.joined(separator: "\n")
        }
        holdBackTableRows(&lines)
        guard var last = lines.popLast() else { return "" }
        let content = last.trimmingCharacters(in: .whitespaces)
        // `-` or `=` under a line would make that line a heading for a
        // moment; a list marker, quote or heading marker still arriving
        // would show as an empty item.
        let dangling = (content.count < 3 && content.allSatisfy { $0 == "-" || $0 == "=" })
            || content.allSatisfy { $0 == "`" || $0 == "~" }
            || ["*", "+", ">"].contains(content) || (!content.isEmpty && content.allSatisfy { $0 == "#" })
            || (!content.isEmpty && content.count < 4 && content.allSatisfy { $0.isNumber || $0 == "." || $0 == ")" } && !lines.isEmpty)
        if !content.isEmpty, dangling {
            return lines.joined(separator: "\n")
        }
        last = repairInline(last)
        lines.append(last)
        return lines.joined(separator: "\n")
    }

    static func repairInline(_ line: String) -> String {
        var text = line
        if text.hasSuffix("\\") { text.removeLast() }
        // A link or image whose address is still arriving shows its label.
        if let open = text.range(of: "](", options: .backwards),
           !text[open.upperBound...].contains(")"),
           let label = text[..<open.lowerBound].lastIndex(of: "[") {
            let isImage = label > text.startIndex && text[text.index(before: label)] == "!"
            let labelText = String(text[text.index(after: label)..<open.lowerBound])
            text = String(text[..<(isImage ? text.index(before: label) : label)]) + (isImage ? "" : labelText)
        }
        // An unfinished code span is closed, so its text shows as code.
        let ticks = codeSpanTicks(text)
        if ticks.open { text += String(repeating: "`", count: ticks.length) }
        guard !ticks.open else { return text }
        // Emphasis: markers still arriving at the end wait; an open marker
        // gets its closing one, or waits when nothing follows it yet.
        if let last = text.last, last == "*" || last == "~" {
            while let last = text.last, last == "*" || last == "~" { text.removeLast() }
            while text.last == " " { text.removeLast() }
        }
        for marker in ["**", "~~", "*"] {
            let candidates = delimiterRuns(in: text, marker: marker)
            guard candidates.count % 2 == 1, let last = candidates.last else { continue }
            if last.upperBound == text.endIndex || text[last.upperBound...].allSatisfy(\.isWhitespace) {
                text.removeSubrange(last)
                text = String(text.reversed().drop(while: { $0 == " " }).reversed())
            } else {
                text += marker
            }
        }
        return text
    }

    // MARK: Before parsing

    /// The chunk with LaTeX taken out (block math becomes a ```math fence,
    /// inline math a placeholder numbered into `math`) and hair spaces where
    /// emphasis meets Japanese punctuation.
    static func prepare(_ source: String) -> (text: String, math: [MarkdownMath]) {
        let lines = self.lines(source)
        let fenced = fencedLines(lines)
        var output: [String] = []
        var math: [MarkdownMath] = []
        var index = 0
        while index < lines.count {
            let line = lines[index]
            guard !fenced[index] else { output.append(String(line)); index += 1; continue }
            let (prefix, content) = splitPrefix(line)
            let trimmed = content.trimmingCharacters(in: .whitespaces)
            if let delimiters = blockMathDelimiters(trimmed) {
                let (open, close) = delimiters
                let body = trimmed.dropFirst(open.count)
                let inner = body.hasSuffix(close) ? body.dropLast(close.count) : body
                if body.count > close.count, body.hasSuffix(close), !inner.contains(open) {
                    // `$$ x $$` on a line of its own.
                    let latex = inner.trimmingCharacters(in: .whitespaces)
                    output.append(contentsOf: [prefix + "```math", prefix + latex, prefix + "```"])
                    index += 1
                    continue
                }
                // A block over several lines; without its closing line it stays text.
                if !body.contains(close), let end = lines.indices.dropFirst(index + 1).first(where: {
                    !fenced[$0] && splitPrefix(lines[$0]).content.trimmingCharacters(in: .whitespaces).hasSuffix(close)
                }) {
                    output.append(prefix + "```math")
                    let first = body.trimmingCharacters(in: .whitespaces)
                    if !first.isEmpty { output.append(prefix + first) }
                    for middle in (index + 1)..<end { output.append(String(lines[middle])) }
                    let (endPrefix, endContent) = splitPrefix(lines[end])
                    let last = endContent.trimmingCharacters(in: .whitespaces).dropLast(close.count)
                        .trimmingCharacters(in: .whitespaces)
                    if !last.isEmpty { output.append(endPrefix + last) }
                    output.append(endPrefix + "```")
                    index = end + 1
                    continue
                }
            }
            // Foundation reads a footnote (`[^1]: …`) as an invisible link
            // definition; it is shown as written instead.
            if content.hasPrefix("[^"), content.contains("]:") {
                output.append(prefix + "\\" + content)
                index += 1
                continue
            }
            let withMath = extractInlineMath(String(line), into: &math)
            output.append(fixFlanking(withMath))
            index += 1
        }
        return (output.joined(separator: "\n"), math)
    }

    private static func blockMathDelimiters(_ trimmed: String) -> (String, String)? {
        if trimmed.hasPrefix("$$") { return ("$$", "$$") }
        if trimmed.hasPrefix("\\[") { return ("\\[", "\\]") }
        return nil
    }

    /// `$…$`, `\(…\)` and `$$…$$` inside a line, outside code spans. A
    /// dollar opens only before a non-space and closes only after one and
    /// not before a digit, so prices such as "$5 and $10" stay text.
    static func extractInlineMath(_ line: String, into math: inout [MarkdownMath]) -> String {
        guard line.contains("$") || line.contains("\\(") else { return line }
        let characters = Array(line)
        var output = ""
        var index = 0
        func placeholder(_ latex: String, display: Bool) -> String {
            math.append(MarkdownMath(latex: latex.trimmingCharacters(in: .whitespaces), display: display))
            return "\(mathOpen)\(math.count - 1)\(mathClose)"
        }
        while index < characters.count {
            let character = characters[index]
            if character == "`" {
                // Copy a code span as it is.
                var run = 0
                while index + run < characters.count, characters[index + run] == "`" { run += 1 }
                if let end = closingTicks(characters, from: index + run, length: run) {
                    output += String(characters[index..<(end + run)])
                    index = end + run
                } else {
                    output += String(characters[index..<(index + run)])
                    index += run
                }
                continue
            }
            if character == "\\", index + 1 < characters.count {
                let next = characters[index + 1]
                if next == "(", let end = find(["\\", ")"], in: characters, from: index + 2) {
                    output += placeholder(String(characters[(index + 2)..<end]), display: false)
                    index = end + 2
                    continue
                }
                output += String([character, next])
                index += 2
                continue
            }
            if character == "$" {
                if index + 1 < characters.count, characters[index + 1] == "$",
                   let end = find(["$", "$"], in: characters, from: index + 2), end > index + 2 {
                    output += placeholder(String(characters[(index + 2)..<end]), display: true)
                    index = end + 2
                    continue
                }
                if index + 1 < characters.count, !characters[index + 1].isWhitespace, characters[index + 1] != "$" {
                    var end = index + 1
                    var found: Int?
                    while end < characters.count {
                        if characters[end] == "\\" { end += 2; continue }
                        if characters[end] == "$" {
                            let before = characters[end - 1]
                            let after: Character? = end + 1 < characters.count ? characters[end + 1] : nil
                            if !before.isWhitespace, !(after?.isNumber ?? false) { found = end }
                            break
                        }
                        end += 1
                    }
                    if let found {
                        output += placeholder(String(characters[(index + 1)..<found]), display: false)
                        index = found + 1
                        continue
                    }
                }
            }
            output.append(character)
            index += 1
        }
        return output
    }

    private static func find(_ pattern: [Character], in characters: [Character], from start: Int) -> Int? {
        guard start < characters.count else { return nil }
        var index = start
        while index + pattern.count <= characters.count {
            if Array(characters[index..<(index + pattern.count)]) == pattern { return index }
            index += 1
        }
        return nil
    }

    private static func closingTicks(_ characters: [Character], from start: Int, length: Int) -> Int? {
        var index = start
        while index < characters.count {
            guard characters[index] == "`" else { index += 1; continue }
            var run = 0
            while index + run < characters.count, characters[index + run] == "`" { run += 1 }
            if run == length { return index }
            index += run
        }
        return nil
    }

    /// CommonMark emphasis does not open before punctuation unless a space
    /// or punctuation comes first, and does not close after punctuation
    /// unless a space or punctuation follows. Japanese has no spaces, so
    /// `これは**「重要」**です` stays literal. A hair space (removed again after
    /// parsing) is put where that rule fails.
    static func fixFlanking(_ line: String) -> String {
        guard line.contains("*") || line.contains("~") else { return line }
        var text = line
        for marker in ["***", "**", "*", "~~"] {
            let runs = delimiterRuns(in: text, marker: marker)
            var inserts: [String.Index] = []
            for (number, run) in runs.enumerated() {
                let before: Character? = run.lowerBound > text.startIndex ? text[text.index(before: run.lowerBound)] : nil
                let after: Character? = run.upperBound < text.endIndex ? text[run.upperBound] : nil
                if number % 2 == 0 {
                    // Opening: fails before punctuation after a letter.
                    if let after, isPunctuation(after), let before, !before.isWhitespace, !isPunctuation(before) {
                        inserts.append(run.lowerBound)
                    }
                } else if let before, isPunctuation(before), let after, !after.isWhitespace, !isPunctuation(after) {
                    // Closing: fails after punctuation before a letter.
                    inserts.append(run.upperBound)
                }
            }
            for index in inserts.reversed() { text.insert(flankingSpace, at: index) }
        }
        return text
    }

    /// Runs of exactly `marker` outside code spans that could open or close
    /// emphasis (not with spaces on both sides, as in `5 * 3`).
    static func delimiterRuns(in text: String, marker: String) -> [Range<String.Index>] {
        let symbol = marker.first!
        var runs: [Range<String.Index>] = []
        var index = text.startIndex
        var inCode = false
        while index < text.endIndex {
            let character = text[index]
            if character == "`" { inCode.toggle(); index = text.index(after: index); continue }
            guard !inCode, character == symbol else { index = text.index(after: index); continue }
            var end = index
            while end < text.endIndex, text[end] == symbol { end = text.index(after: end) }
            let length = text.distance(from: index, to: end)
            let before: Character? = index > text.startIndex ? text[text.index(before: index)] : nil
            let after: Character? = end < text.endIndex ? text[end] : nil
            let spacedBefore = before?.isWhitespace ?? true, spacedAfter = after?.isWhitespace ?? true
            if length == marker.count, !(spacedBefore && spacedAfter) {
                // `*` at the start of a line followed by a space is a list marker.
                runs.append(index..<end)
            }
            index = end
        }
        return runs
    }

    static func isPunctuation(_ character: Character) -> Bool {
        character.isPunctuation || character.isSymbol
    }

    // MARK: Lines

    static func lines(_ source: String) -> [Substring] {
        let normalized = source.contains("\r") ? source.replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n") : source
        return normalized.split(separator: "\n", omittingEmptySubsequences: false)
    }

    static func isBlank(_ line: Substring) -> Bool { line.allSatisfy { $0 == " " || $0 == "\t" } }

    static func isListMarker(_ line: Substring) -> Bool {
        let content = line.drop(while: { $0 == " " })
        guard let first = content.first else { return false }
        if "-*+".contains(first) { return content.dropFirst().first == " " }
        let digits = content.prefix(while: \.isNumber)
        guard !digits.isEmpty, digits.count < 10 else { return false }
        let rest = content.dropFirst(digits.count)
        return (rest.first == "." || rest.first == ")") && rest.dropFirst().first == " "
    }

    /// Leading spaces and quote markers, which a fence or math block keeps.
    static func splitPrefix(_ line: Substring) -> (prefix: String, content: Substring) {
        let content = line.drop(while: { $0 == " " || $0 == "\t" || $0 == ">" })
        return (String(line[..<content.startIndex]), content)
    }

    private struct Fence { let marker: Character; let length: Int; let prefix: String }

    private static func fenceOpening(_ line: Substring) -> Fence? {
        let (prefix, content) = splitPrefix(line)
        guard let marker = content.first, marker == "`" || marker == "~" else { return nil }
        let run = content.prefix(while: { $0 == marker })
        guard run.count >= 3 else { return nil }
        if marker == "`", content.dropFirst(run.count).contains("`") { return nil }
        return Fence(marker: marker, length: run.count, prefix: prefix)
    }

    private static func closes(_ fence: Fence, _ line: Substring) -> Bool {
        let content = splitPrefix(line).content
        let run = content.prefix(while: { $0 == fence.marker })
        return run.count >= fence.length && content.dropFirst(run.count).allSatisfy { $0 == " " || $0 == "\t" }
    }

    /// Whether each line belongs to a fenced code block, fences included.
    static func fencedLines(_ lines: [Substring]) -> [Bool] {
        var result = Array(repeating: false, count: lines.count)
        var open: Fence?
        for (index, line) in lines.enumerated() {
            if let fence = open {
                result[index] = true
                if closes(fence, line) { open = nil }
            } else if let fence = fenceOpening(line) {
                result[index] = true
                open = fence
            }
        }
        return result
    }

    private static func openFence(_ lines: [Substring]) -> String? {
        var open: Fence?
        for line in lines {
            if let fence = open { if closes(fence, line) { open = nil } }
            else { open = fenceOpening(line) }
        }
        return open.map { $0.prefix + String(repeating: $0.marker, count: $0.length) }
    }

    /// Whether each line is inside a `$$` or `\[` block that has its
    /// closing line, delimiters included.
    static func mathBlockLines(_ lines: [Substring], fenced: [Bool]) -> [Bool] {
        var result = Array(repeating: false, count: lines.count)
        var index = 0
        while index < lines.count {
            defer { index += 1 }
            guard !fenced[index] else { continue }
            let trimmed = splitPrefix(lines[index]).content.trimmingCharacters(in: .whitespaces)
            guard let delimiters = blockMathDelimiters(trimmed),
                  !(trimmed.count > delimiters.0.count && trimmed.dropFirst(delimiters.0.count).hasSuffix(delimiters.1)) else { continue }
            let close = delimiters.1
            guard let end = ((index + 1)..<max(index + 1, lines.count)).first(where: {
                !fenced[$0] && splitPrefix(lines[$0]).content.trimmingCharacters(in: .whitespaces).hasSuffix(close)
            }) else { continue }
            for line in index...end { result[line] = true }
            index = end
        }
        return result
    }

    private static func openMathBlock(_ lines: [Substring], fenced: [Bool]) -> String? {
        let closed = mathBlockLines(lines, fenced: fenced)
        for index in lines.indices.reversed() where !fenced[index] && !closed[index] {
            let (prefix, content) = splitPrefix(lines[index])
            let trimmed = content.trimmingCharacters(in: .whitespaces)
            guard let delimiters = blockMathDelimiters(trimmed) else { continue }
            let (open, close) = delimiters
            if trimmed.count > open.count, trimmed.dropFirst(open.count).hasSuffix(close) { return nil }
            return prefix + close
        }
        return nil
    }

    /// Trailing table lines wait until the table has its delimiter row,
    /// and a row still arriving waits until it ends.
    private static func holdBackTableRows(_ lines: inout [String]) {
        var start = lines.count
        while start > 0, lines[start - 1].trimmingCharacters(in: .whitespaces).hasPrefix("|") { start -= 1 }
        guard start < lines.count else { return }
        let rows = lines[start...].map { $0.trimmingCharacters(in: .whitespaces) }
        let hasDelimiter = rows.dropFirst().contains { row in
            row.contains("-") && row.hasSuffix("|") && row.filter({ $0 == "|" }).count >= 2
                && row.allSatisfy { "|-: ".contains($0) }
        }
        if !hasDelimiter {
            lines.removeSubrange(start...)
        } else if let last = rows.last, !last.hasSuffix("|") || last.count < 2 {
            lines.removeLast()
        }
    }

    private static func codeSpanTicks(_ text: String) -> (open: Bool, length: Int) {
        let characters = Array(text)
        var index = 0
        while index < characters.count {
            guard characters[index] == "`" else { index += 1; continue }
            var run = 0
            while index + run < characters.count, characters[index + run] == "`" { run += 1 }
            guard let end = closingTicks(characters, from: index + run, length: run) else { return (true, run) }
            index = end + run
        }
        return (false, 0)
    }
}
