import Foundation

/// Text-level steps around Foundation's Markdown parser: splitting a reply
/// into blocks that can be parsed and drawn on their own, closing syntax a
/// streaming reply has not finished yet, taking LaTeX out of the text so
/// Markdown never touches it, and letting emphasis work next to Japanese
/// punctuation.
public enum MarkdownSource {
    /// Inserted where CommonMark would not see emphasis next to Japanese
    /// punctuation (`**「強調」**です`); removed again after parsing.
    static let flankingSpace: Character = "\u{200A}"
    static let mathOpen: Character = "\u{E000}"
    static let mathClose: Character = "\u{E001}"

    // MARK: Chunks

    /// The reply split at blank lines that start a new top-level block, so
    /// a growing reply only parses its last chunk again. Fenced code, math
    /// blocks, indented continuations and lists stay in one chunk.
    public static func chunks(_ source: String) -> [String] {
        let lines = self.lines(source)
        let fenced = fencedLines(lines)
        let math = mathBlockLines(lines, fenced: fenced)
        var chunks: [String] = []
        var current: [Substring] = []
        // Whether the chunk so far holds a list item, kept as lines are
        // added rather than searched at every blank line of a loose list.
        var currentHasList = false
        var index = 0
        while index < lines.count {
            let line = lines[index]
            guard isBlank(line), !fenced[index], !math[index] else {
                current.append(line)
                if !fenced[index], !math[index], isListMarker(line) { currentHasList = true }
                index += 1
                continue
            }
            var next = index + 1
            while next < lines.count, isBlank(lines[next]) { next += 1 }
            if next == lines.count { break }
            let following = lines[next]
            let startsBlock = !(following.first == " " || following.first == "\t")
            let continuesList = isListMarker(following) && currentHasList
            if startsBlock, !continuesList, !current.isEmpty {
                chunks.append(current.joined(separator: "\n"))
                current = []
                currentHasList = false
                index = next
            } else {
                current.append(contentsOf: lines[index..<next])
                index = next
            }
        }
        if !current.isEmpty { chunks.append(current.joined(separator: "\n")) }
        return chunks
    }

    /// Link reference definitions (`[id]: https://…`) from the whole reply,
    /// added to every chunk so a reference resolves wherever it is used.
    public static func referenceDefinitions(_ source: String) -> String {
        let lines = self.lines(source)
        let fenced = fencedLines(lines)
        return lines.indices.filter { index in
            guard !fenced[index] else { return false }
            let line = lines[index].drop(while: { $0 == " " })
            guard line.first == "[", !line.hasPrefix("[^"), !isProseReference(line),
                  let close = line.firstIndex(of: "]") else { return false }
            let rest = line[line.index(after: close)...]
            return rest.first == ":" && rest.dropFirst().contains(where: { !$0.isWhitespace })
        }.map { String(lines[$0]) }.joined(separator: "\n")
    }

    /// `[注]: 上記は概算です。` is a note, not a link definition: Japanese has
    /// no spaces, so CommonMark would read the sentence as a link address
    /// and hide the whole line. Such a line is shown as written.
    static func isProseReference(_ content: Substring) -> Bool {
        guard content.first == "[", let close = content.firstIndex(of: "]") else { return false }
        let rest = content[content.index(after: close)...]
        guard rest.first == ":" else { return false }
        let destination = rest.dropFirst().drop(while: { $0 == " " || $0 == "\t" }).prefix(while: { !$0.isWhitespace })
        return destination.contains(where: isJapanese)
    }

    // MARK: Streaming

    /// Closes what a streaming reply has opened but not finished, so the
    /// text never shows raw syntax or flips between layouts: an open code
    /// fence or math block is closed, half a table row and a lone `-` (which
    /// would turn the line above into a heading) wait, and emphasis, code
    /// spans and links on the last line are closed or held back.
    public static func repairStreaming(_ chunk: String) -> String {
        repairStreamingDetailed(chunk).text
    }

    /// `closedMath` says the text ends in a `$$` or `\[` block that was
    /// given its closing line here, or in an environment written without
    /// them that was put in a `$$` block, so the formula is still being
    /// written.
    static func repairStreamingDetailed(_ chunk: String) -> (text: String, closedMath: Bool) {
        var lines = self.lines(chunk).map(String.init)
        while let last = lines.last, isBlank(Substring(last)) { lines.removeLast() }
        guard !lines.isEmpty else { return ("", false) }
        if let open = openFenceStart(lines.map { Substring($0) }) {
            // A fence's opening line alone whose tag may still become a rich
            // block's (```cha) waits, so it never shows as code for a moment.
            if open.index == lines.count - 1, let word = infoWord(lines[open.index]), RichBlocks.mayName(word) {
                lines.removeLast()
                return (lines.joined(separator: "\n"), false)
            }
            // A rich block still arriving shows its placeholder, not its data.
            if let marked = markingRich(lines[open.index], with: RichBlocks.pendingMarker) { lines[open.index] = marked }
            lines.append(open.closing)
            return (lines.joined(separator: "\n"), false)
        }
        let substrings = lines.map { Substring($0) }
        let fenced = fencedLines(substrings)
        if let closing = openMathBlock(substrings, fenced: fenced) {
            lines.append(closing)
            return (lines.joined(separator: "\n"), true)
        }
        // `\begin{cases}` on a line of its own without `$$`, still arriving:
        // shown as a formula still being written, as an open `$$` block is.
        if let start = openBareEnvironment(substrings, fenced: fenced) {
            let prefix = splitPrefix(substrings[start]).prefix
            lines.insert(prefix + "$$", at: start)
            lines.append(prefix + "$$")
            return (lines.joined(separator: "\n"), true)
        }
        holdBackTableRows(&lines)
        guard var last = lines.popLast() else { return ("", false) }
        if isDangling(last, first: lines.isEmpty) {
            return (lines.joined(separator: "\n"), false)
        }
        last = repairInline(last)
        // `- **` loses its markers above and would leave `-` under the
        // paragraph, a heading underline for a moment, so the line is
        // judged again as it will be parsed. A table row whose cells lost
        // all they had (`| **`) waits as one with nothing in them does.
        if isDangling(last, first: lines.isEmpty)
            || (!lines.isEmpty && last.trimmingCharacters(in: .whitespaces).hasPrefix("|")
                && !last.contains(where: { $0 != "|" && !$0.isWhitespace })) {
            return (lines.joined(separator: "\n"), false)
        }
        lines.append(last)
        return (lines.joined(separator: "\n"), false)
    }

    /// A last line that would change the layout for a moment: `-` or `=`
    /// under a line would make that line a heading; a list marker, quote
    /// or heading marker still arriving would show as an empty item. Quote
    /// markers are looked through, so `> -` waits as `-` does.
    static func isDangling(_ line: String, first: Bool) -> Bool {
        let content = splitPrefix(Substring(line)).content.trimmingCharacters(in: .whitespaces)
        guard !content.isEmpty else { return false }
        let quoted = line.contains(">")
        return (content.count < 3 && content.allSatisfy { $0 == "-" || $0 == "=" })
            || content.allSatisfy { $0 == "`" || $0 == "~" }
            || ["*", "+", "-"].contains(content) || content.allSatisfy { $0 == "#" }
            || (content.count < 11 && content.allSatisfy { $0.isNumber || $0 == "." || $0 == ")" } && !(first && !quoted))
    }

    /// Inline math still arriving (`式は $\frac{a}{`, `\begin{cases} x`)
    /// would show as raw LaTeX, so a short run that looks like LaTeX waits
    /// for its closing delimiter. A bare `$5` or a long run shows, so prose
    /// with a dollar in it is never hidden for long.
    static func holdBackOpenMath(_ text: String) -> String {
        guard text.contains("$") || text.contains("\\") else { return text }
        let characters = Array(text)
        var index = 0
        var opener: (start: Int, length: Int, sure: Bool)?
        while index < characters.count {
            let character = characters[index]
            if character == "`" {
                var run = 0
                while index + run < characters.count, characters[index + run] == "`" { run += 1 }
                if let end = closingTicks(characters, from: index + run, length: run) {
                    index = end + run
                } else {
                    index += run
                }
                continue
            }
            if character == "\\", index + 1 < characters.count {
                let next = characters[index + 1]
                if next == "(" || next == "[" {
                    let close: [Character] = next == "(" ? ["\\", ")"] : ["\\", "]"]
                    guard let end = find(close, in: characters, from: index + 2) else {
                        opener = (index, 2, true)
                        break
                    }
                    index = end + 2
                    continue
                }
                if let begin = mathEnvironmentBegin(characters, at: index) {
                    if let end = environmentEnd(characters, name: begin.name, from: begin.end) {
                        index = end.end
                        continue
                    }
                    // One that runs into a code span is LaTeX named in a sentence.
                    if !characters[begin.end...].contains("`") {
                        opener = (index, begin.end - index, true)
                        break
                    }
                }
                index += 2
                continue
            }
            if character == "$" {
                // A dollar sign that just arrived waits one token to show
                // whether it opens a formula.
                guard index + 1 < characters.count else {
                    opener = (index, 1, true)
                    break
                }
                if characters[index + 1] == "$" {
                    guard let end = find(["$", "$"], in: characters, from: index + 2) else {
                        opener = (index, 2, true)
                        break
                    }
                    index = end + 2
                    continue
                }
                if !characters[index + 1].isWhitespace {
                    var end = index + 1
                    var found: Int?
                    while end < characters.count {
                        if characters[end] == "\\" { end += 2; continue }
                        if characters[end] == "`" { break }
                        if characters[end] == "$" {
                            let before = characters[end - 1]
                            let after: Character? = end + 1 < characters.count ? characters[end + 1] : nil
                            if !before.isWhitespace, !(after?.isNumber ?? false) { found = end }
                            break
                        }
                        end += 1
                    }
                    if let found {
                        index = found + 1
                        continue
                    }
                    opener = (index, 1, false)
                    break
                }
            }
            index += 1
        }
        guard let opener else { return holdBackPartialBegin(text) }
        let content = characters[(opener.start + opener.length)...]
        let limit = opener.sure ? 80 : 60
        guard content.count <= limit, opener.sure || looksLikeLaTeX(content) else { return text }
        var kept = String(characters[..<opener.start])
        while kept.last == " " { kept.removeLast() }
        return kept
    }

    /// `\begin{ca` at the end of the text, a formula's first command still
    /// arriving, waits until its name is complete.
    static func holdBackPartialBegin(_ text: String) -> String {
        guard let slash = text.lastIndex(of: "\\") else { return text }
        let tail = text[slash...], begin = "\\begin{"
        let partial = tail.count < begin.count
            ? tail.count > 1 && begin.hasPrefix(tail)
            : tail.hasPrefix(begin) && tail.count <= begin.count + 12
                && tail.dropFirst(begin.count).allSatisfy { $0.isASCII && ($0.isLetter || $0 == "*") }
        guard partial else { return text }
        var kept = String(text[..<slash])
        while kept.last == " " { kept.removeLast() }
        return kept
    }

    static func repairInline(_ line: String) -> String {
        var text = line
        if text.hasSuffix("\\") { text.removeLast() }
        // A link or image whose address is still arriving shows its label.
        if let open = text.range(of: "](", options: .backwards),
           !text[open.upperBound...].contains(")"),
           let label = text[..<open.lowerBound].lastIndex(of: "[") {
            let isImage = label > text.startIndex && text[text.index(before: label)] == "!"
            let labelText = String(text[text.index(after: label)..<open.lowerBound])
            text = String(text[..<(isImage ? text.index(before: label) : label)]) + (isImage ? "" : labelText)
        } else if let label = text.lastIndex(of: "["), !text[label...].contains("]"),
                  !text[..<label].contains("`") || !codeSpanTicks(String(text[..<label])).open {
            // A label still arriving shows without its bracket; an image's
            // label waits for the image.
            let isImage = label > text.startIndex && text[text.index(before: label)] == "!"
            text = isImage ? String(text[..<text.index(before: label)]) : String(text[..<label]) + text[text.index(after: label)...]
        }
        // An unfinished code span is closed, so its text shows as code.
        let ticks = codeSpanTicks(text)
        if ticks.open { text += String(repeating: "`", count: ticks.length) }
        guard !ticks.open else { return text }
        text = holdBackOpenMath(text)
        // Emphasis: markers still arriving at the end wait; an open marker
        // gets its closing one, or waits when nothing follows it yet.
        if let last = text.last, last == "*" || last == "~" {
            while let last = text.last, last == "*" || last == "~" { text.removeLast() }
            while text.last == " " { text.removeLast() }
        }
        for marker in ["***", "**", "__", "~~", "*"] {
            let candidates = delimiterRuns(in: text, marker: marker)
            guard candidates.count % 2 == 1, let last = candidates.last else { continue }
            if last.upperBound == text.endIndex || text[last.upperBound...].allSatisfy(\.isWhitespace) {
                text.removeSubrange(last)
                text = String(text.reversed().drop(while: { $0 == " " }).reversed())
            } else {
                text += marker
            }
        }
        return text
    }

    // MARK: Before parsing

    /// The chunk with LaTeX taken out (block math becomes a ```math fence,
    /// inline math a placeholder numbered into `math`) and hair spaces where
    /// emphasis meets Japanese punctuation.
    static func prepare(_ source: String) -> (text: String, math: [MarkdownMath]) {
        let lines = self.lines(source)
        let fenced = fencedLines(lines)
        var output: [String] = []
        var math: [MarkdownMath] = []
        var index = 0
        while index < lines.count {
            let line = lines[index]
            guard !fenced[index] else { output.append(String(line)); index += 1; continue }
            let (prefix, content) = splitPrefix(line)
            let trimmed = content.trimmingCharacters(in: .whitespaces)
            if let delimiters = blockMathDelimiters(trimmed) {
                let (open, close) = delimiters
                let body = trimmed.dropFirst(open.count)
                let inner = body.hasSuffix(close) ? body.dropLast(close.count) : body
                if body.count > close.count, body.hasSuffix(close), !inner.contains(open) {
                    // `$$ x $$` on a line of its own.
                    let latex = inner.trimmingCharacters(in: .whitespaces)
                    output.append(contentsOf: [prefix + "```math", prefix + latex, prefix + "```"])
                    index += 1
                    continue
                }
                // A block over several lines; without its closing line it stays text.
                if !body.contains(close), let end = lines.indices.dropFirst(index + 1).first(where: {
                    !fenced[$0] && splitPrefix(lines[$0]).content.trimmingCharacters(in: .whitespaces).hasSuffix(close)
                }) {
                    output.append(prefix + "```math")
                    let first = body.trimmingCharacters(in: .whitespaces)
                    if !first.isEmpty { output.append(prefix + first) }
                    for middle in (index + 1)..<end { output.append(String(lines[middle])) }
                    let (endPrefix, endContent) = splitPrefix(lines[end])
                    let last = endContent.trimmingCharacters(in: .whitespaces).dropLast(close.count)
                        .trimmingCharacters(in: .whitespaces)
                    if !last.isEmpty { output.append(endPrefix + last) }
                    output.append(endPrefix + "```")
                    index = end + 1
                    continue
                }
            }
            // `\begin{cases} … \end{cases}` written without `$$` on lines of
            // its own (as Gemma does) is a formula all the same; LaTeX named in
            // a sentence, or without its `\end`, stays text.
            if trimmed.hasPrefix("\\begin{"), let environment = bareEnvironment(lines, fenced: fenced, at: index),
               let end = environment.end, environment.endsLine, isMathBody(environment.body[...], ownLines: true) {
                output.append(prefix + "```math")
                output.append(prefix + trimmed)
                if end > index {
                    for middle in (index + 1)..<end { output.append(String(lines[middle])) }
                    let (endPrefix, endContent) = splitPrefix(lines[end])
                    output.append(endPrefix + endContent.trimmingCharacters(in: .whitespaces))
                    output.append(endPrefix + "```")
                } else {
                    output.append(prefix + "```")
                }
                index = end + 1
                continue
            }
            // Foundation reads a footnote (`[^1]: …`) and a note such as
            // `[注]: 概算です` as invisible link definitions; both are shown
            // as written instead.
            // Math first, so the backslash added to a note cannot open `\[`.
            var withMath = extractInlineMath(String(line), into: &math)
            if isNoteLine(content) {
                withMath.insert("\\", at: withMath.index(withMath.startIndex, offsetBy: prefix.count))
            }
            output.append(fixFlanking(withMath))
            index += 1
        }
        return (output.joined(separator: "\n"), math)
    }

    static func isNoteLine(_ content: Substring) -> Bool {
        (content.hasPrefix("[^") && content.contains("]:")) || isProseReference(content)
    }

    /// Undoes `prepare` in text Foundation made a code block of: indented
    /// code has no fence to recognize it by, so its `$HOME/$USER` became a
    /// math placeholder and its `[^1]:` line an escaped one. Placeholders
    /// become the math as written, hair spaces go, and a note line loses
    /// its backslash. (A fenced block whose own line reads `\[^1]: …`
    /// loses that backslash too; nothing else in fenced code changes.)
    static func restoreCode(_ code: String, math: [MarkdownMath]) -> String {
        guard code.contains(where: { $0 == mathOpen || $0 == flankingSpace || $0 == "\\" }) else { return code }
        return lines(code).map { line -> String in
            var text = String(line)
            if text.hasPrefix("\\["), isNoteLine(Substring(text.dropFirst())) { text.removeFirst() }
            text.removeAll { $0 == flankingSpace }
            guard text.contains(mathOpen) else { return text }
            var restored = ""
            var rest = Substring(text)
            while let open = rest.firstIndex(of: mathOpen) {
                restored += rest[..<open]
                guard let close = rest[open...].firstIndex(of: mathClose),
                      let index = Int(rest[rest.index(after: open)..<close]), math.indices.contains(index) else {
                    restored.append(rest[open])
                    rest = rest[rest.index(after: open)...]
                    continue
                }
                restored += math[index].raw
                rest = rest[rest.index(after: close)...]
            }
            return restored + rest
        }.joined(separator: "\n")
    }

    private static func blockMathDelimiters(_ trimmed: String) -> (String, String)? {
        if trimmed.hasPrefix("$$") { return ("$$", "$$") }
        if trimmed.hasPrefix("\\[") { return ("\\[", "\\]") }
        return nil
    }

    /// `$…$`, `\(…\)`, `$$…$$`, `\[…\]` and a math environment written
    /// without them inside a line, outside code spans. A dollar opens only
    /// before a non-space and closes only after one and not before a digit,
    /// so prices such as "$5 and $10" stay text.
    static func extractInlineMath(_ line: String, into math: inout [MarkdownMath]) -> String {
        guard line.contains("$") || line.contains("\\(") || line.contains("\\[") || line.contains("\\begin{") else { return line }
        let characters = Array(line)
        var output = ""
        var index = 0
        func placeholder(_ latex: String, display: Bool, raw: ArraySlice<Character>) -> String {
            math.append(MarkdownMath(latex: latex.trimmingCharacters(in: .whitespaces), display: display, raw: String(raw)))
            return "\(mathOpen)\(math.count - 1)\(mathClose)"
        }
        while index < characters.count {
            let character = characters[index]
            if character == "`" {
                // Copy a code span as it is.
                var run = 0
                while index + run < characters.count, characters[index + run] == "`" { run += 1 }
                if let end = closingTicks(characters, from: index + run, length: run) {
                    output += String(characters[index..<(end + run)])
                    index = end + run
                } else {
                    output += String(characters[index..<(index + run)])
                    index += run
                }
                continue
            }
            if character == "\\", index + 1 < characters.count {
                let next = characters[index + 1]
                if next == "(", let end = find(["\\", ")"], in: characters, from: index + 2) {
                    output += placeholder(String(characters[(index + 2)..<end]), display: false, raw: characters[index..<(end + 2)])
                    index = end + 2
                    continue
                }
                // `\[ x^2 \]` in the middle of a line. An escaped bracket
                // (`\[1\]`, a citation) has no command or operator in it and
                // stays text; a note (`\[注]: …`) has no `\]`.
                if next == "[", let end = find(["\\", "]"], in: characters, from: index + 2),
                   end > index + 2, looksLikeLaTeX(characters[(index + 2)..<end]),
                   isLikelyMath(characters[(index + 2)..<end]) {
                    output += placeholder(String(characters[(index + 2)..<end]), display: true, raw: characters[index..<(end + 2)])
                    index = end + 2
                    continue
                }
                // `\begin{cases} … \end{cases}` without `$$`, shown as display
                // math; LaTeX named in a sentence has no formula inside.
                if next == "b", let begin = mathEnvironmentBegin(characters, at: index),
                   let end = environmentEnd(characters, name: begin.name, from: begin.end),
                   isMathBody(characters[begin.end..<end.start], ownLines: false) {
                    output += placeholder(String(characters[index..<end.end]), display: true, raw: characters[index..<end.end])
                    index = end.end
                    continue
                }
                output += String([character, next])
                index += 2
                continue
            }
            if character == "$" {
                if index + 1 < characters.count, characters[index + 1] == "$",
                   let end = find(["$", "$"], in: characters, from: index + 2), end > index + 2 {
                    output += placeholder(String(characters[(index + 2)..<end]), display: true, raw: characters[index..<(end + 2)])
                    index = end + 2
                    continue
                }
                if index + 1 < characters.count, !characters[index + 1].isWhitespace, characters[index + 1] != "$" {
                    var end = index + 1
                    var found: Int?
                    while end < characters.count {
                        if characters[end] == "\\" { end += 2; continue }
                        // Math never runs into a code span.
                        if characters[end] == "`" { break }
                        if characters[end] == "$" {
                            let before = characters[end - 1]
                            let after: Character? = end + 1 < characters.count ? characters[end + 1] : nil
                            if !before.isWhitespace, !(after?.isNumber ?? false) { found = end }
                            break
                        }
                        end += 1
                    }
                    if let found, isLikelyMath(characters[(index + 1)..<found]) {
                        output += placeholder(String(characters[(index + 1)..<found]), display: false, raw: characters[index...found])
                        index = found + 1
                        continue
                    }
                }
            }
            output.append(character)
            index += 1
        }
        return output
    }

    /// A command, a script, braces or an equals sign: what a formula has and
    /// a bracketed number, a word or a price has not.
    static func looksLikeLaTeX(_ content: ArraySlice<Character>) -> Bool {
        content.contains(where: { "\\^_{}=".contains($0) })
    }

    /// Japanese outside `\text{}` makes `$5と$10` a price, not math, unless
    /// the content has an operator, a command or a script (`$利益率 = 5$`).
    static func isLikelyMath(_ content: ArraySlice<Character>) -> Bool {
        var depth = 0
        var textDepth: Int?
        var command = ""
        var japaneseOutsideText = false
        var previous: Character?
        for character in content {
            defer { previous = character }
            if character == "\\" { command = "\\"; continue }
            if !command.isEmpty {
                if character.isLetter && character.isASCII { command.append(character); continue }
                if character == "{", ["\\text", "\\mathrm", "\\textrm", "\\mbox", "\\textbf", "\\operatorname"].contains(command) {
                    depth += 1
                    if textDepth == nil { textDepth = depth }
                    command = ""
                    continue
                }
                command = ""
            }
            if character == "{" { depth += 1; continue }
            if character == "}" {
                if textDepth == depth { textDepth = nil }
                depth = max(0, depth - 1)
                continue
            }
            if textDepth == nil, isJapanese(character) {
                // A unit or a particle right after a number or a word
                // (`150円`, `HOMEと`) is prose, whatever follows.
                if let previous, previous.isNumber || (previous.isLetter && previous.isASCII) { return false }
                japaneseOutsideText = true
            }
        }
        return !japaneseOutsideText || content.contains(where: { "=\\^_".contains($0) })
    }

    // MARK: Environments without delimiters

    /// Environments that only ever hold math, so `\begin{cases}` marks a
    /// formula even where a model left out `$$`: SwiftMath's own and those
    /// `MathSyntax` rewrites, without `tabular` (text) and `math` (inline).
    static let mathEnvironments: Set<String> = Set(MathSyntax.environments.keys).subtracting(["tabular", "math"])
        .union(["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "cases", "aligned", "split", "gather", "eqnarray"])

    /// `\begin{name}` at `start` for one of `mathEnvironments`: the name and
    /// where the command ends.
    static func mathEnvironmentBegin(_ characters: [Character], at start: Int) -> (name: String, end: Int)? {
        let begin: [Character] = Array("\\begin{")
        guard starts(begin, in: characters, at: start),
              let close = characters[(start + begin.count)...].prefix(14).firstIndex(of: "}") else { return nil }
        let name = String(characters[(start + begin.count)..<close])
        return mathEnvironments.contains(name) ? (name, close + 1) : nil
    }

    /// The `\end{name}` closing an environment whose `\begin` ends before
    /// `start`, past nested ones of the same name; nil when the text or a
    /// code span comes first.
    static func environmentEnd(_ characters: [Character], name: String, from start: Int) -> (start: Int, end: Int)? {
        let open: [Character] = Array("\\begin{\(name)}"), close: [Character] = Array("\\end{\(name)}")
        var depth = 1
        var index = start
        while index < characters.count {
            let character = characters[index]
            if character == "`" { return nil }
            guard character == "\\" else { index += 1; continue }
            if starts(close, in: characters, at: index) {
                depth -= 1
                if depth == 0 { return (index, index + close.count) }
                index += close.count
            } else if starts(open, in: characters, at: index) {
                depth += 1
                index += open.count
            } else {
                // `\\` and other escapes.
                index += 2
            }
        }
        return nil
    }

    struct BareEnvironment {
        /// The line holding the `\end`, or nil while it has not arrived.
        let end: Int?
        /// Whether only `.` or `,` follows the `\end` on its line.
        let endsLine: Bool
        let body: [Character]
    }

    /// A math environment opening the line at `index` without `$$`, followed
    /// to its `\end` over at most 40 lines with no blank line, fence or code
    /// span in between (otherwise nil, as it is no formula).
    static func bareEnvironment(_ lines: [Substring], fenced: [Bool], at index: Int) -> BareEnvironment? {
        guard !fenced[index] else { return nil }
        let first = splitPrefix(lines[index]).content.trimmingCharacters(in: .whitespaces)
        guard first.hasPrefix("\\begin{") else { return nil }
        var characters = Array(first)
        guard let begin = mathEnvironmentBegin(characters, at: 0) else { return nil }
        var lineEnds = [characters.count]
        var line = index
        while true {
            if characters.contains("`") { return nil }
            if let close = environmentEnd(characters, name: begin.name, from: begin.end) {
                let closing = lineEnds.firstIndex(where: { close.end <= $0 }) ?? lineEnds.count - 1
                let tail = String(characters[close.end..<lineEnds[closing]]).trimmingCharacters(in: .whitespaces)
                return BareEnvironment(end: index + closing, endsLine: tail.isEmpty || tail == "." || tail == ",",
                                       body: Array(characters[begin.end..<close.start]))
            }
            line += 1
            guard line < lines.count else {
                return BareEnvironment(end: nil, endsLine: false, body: Array(characters[begin.end...]))
            }
            guard line - index < 40, !fenced[line], !isBlank(lines[line]) else { return nil }
            characters.append("\n")
            characters += Array(splitPrefix(lines[line]).content.trimmingCharacters(in: .whitespaces))
            lineEnds.append(characters.count)
        }
    }

    /// The line where an environment written without `$$` opens and is
    /// still arriving at the end of a streaming chunk.
    static func openBareEnvironment(_ lines: [Substring], fenced: [Bool]) -> Int? {
        let closedMath = mathBlockLines(lines, fenced: fenced)
        var index = lines.count
        // An environment holds no blank line, so the search starts after the last one.
        while index > 0, !isBlank(lines[index - 1]), !fenced[index - 1], !closedMath[index - 1] { index -= 1 }
        while index < lines.count {
            guard let environment = bareEnvironment(lines, fenced: fenced, at: index) else { index += 1; continue }
            guard let end = environment.end else { return index }
            index = end + 1
        }
        return nil
    }

    /// An environment's content when it is a formula and not LaTeX named in
    /// a sentence: rows or columns (`\\`, `&`), or what `isLikelyMath` takes
    /// for math. Within a line, rows must read as math too.
    static func isMathBody(_ body: ArraySlice<Character>, ownLines: Bool) -> Bool {
        guard body.contains(where: { !$0.isWhitespace }) else { return false }
        let rows = body.contains("&") || find(["\\", "\\"], in: Array(body), from: 0) != nil
        if ownLines, rows { return true }
        return (rows || looksLikeLaTeX(body)) && isLikelyMath(body)
    }

    static func isJapanese(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        switch scalar.value {
        case 0x3000...0x30FF, 0x3400...0x4DBF, 0x4E00...0x9FFF, 0xF900...0xFAFF, 0xFF01...0xFF60, 0xFF61...0xFF9F: return true
        default: return false
        }
    }

    private static func find(_ pattern: [Character], in characters: [Character], from start: Int) -> Int? {
        guard start < characters.count else { return nil }
        var index = start
        while index + pattern.count <= characters.count {
            if Array(characters[index..<(index + pattern.count)]) == pattern { return index }
            index += 1
        }
        return nil
    }

    private static func starts(_ pattern: [Character], in characters: [Character], at start: Int) -> Bool {
        start + pattern.count <= characters.count && characters[start..<(start + pattern.count)].elementsEqual(pattern)
    }

    private static func closingTicks(_ characters: [Character], from start: Int, length: Int) -> Int? {
        var index = start
        while index < characters.count {
            guard characters[index] == "`" else { index += 1; continue }
            var run = 0
            while index + run < characters.count, characters[index + run] == "`" { run += 1 }
            if run == length { return index }
            index += run
        }
        return nil
    }

    /// CommonMark emphasis does not open before punctuation unless a space
    /// or punctuation comes first, and does not close after punctuation
    /// unless a space or punctuation follows. Japanese has no spaces, so
    /// `これは**「重要」**です` stays literal. A hair space (removed again after
    /// parsing) is put where that rule fails.
    static func fixFlanking(_ line: String) -> String {
        guard line.contains("*") || line.contains("~") else { return line }
        var text = line
        for marker in ["***", "**", "*", "~~"] {
            let runs = delimiterRuns(in: text, marker: marker)
            var inserts: [String.Index] = []
            for (number, run) in runs.enumerated() {
                let before: Character? = run.lowerBound > text.startIndex ? text[text.index(before: run.lowerBound)] : nil
                let after: Character? = run.upperBound < text.endIndex ? text[run.upperBound] : nil
                if number % 2 == 0 {
                    // Opening: fails before punctuation after a letter.
                    if let after, isPunctuation(after), let before, !before.isWhitespace, !isPunctuation(before) {
                        inserts.append(run.lowerBound)
                    }
                } else if let before, isPunctuation(before), let after, !after.isWhitespace, !isPunctuation(after) {
                    // Closing: fails after punctuation before a letter.
                    inserts.append(run.upperBound)
                }
            }
            for index in inserts.reversed() { text.insert(flankingSpace, at: index) }
        }
        return text
    }

    /// Runs of exactly `marker` outside code spans that could open or close
    /// emphasis (not with spaces on both sides, as in `5 * 3`).
    static func delimiterRuns(in text: String, marker: String) -> [Range<String.Index>] {
        let symbol = marker.first!
        var runs: [Range<String.Index>] = []
        var index = text.startIndex
        var inCode = false
        while index < text.endIndex {
            let character = text[index]
            if character == "`" { inCode.toggle(); index = text.index(after: index); continue }
            guard !inCode, character == symbol else { index = text.index(after: index); continue }
            var end = index
            while end < text.endIndex, text[end] == symbol { end = text.index(after: end) }
            let length = text.distance(from: index, to: end)
            let before: Character? = index > text.startIndex ? text[text.index(before: index)] : nil
            let after: Character? = end < text.endIndex ? text[end] : nil
            let spacedBefore = before?.isWhitespace ?? true, spacedAfter = after?.isWhitespace ?? true
            if length == marker.count, !(spacedBefore && spacedAfter) {
                // `*` at the start of a line followed by a space is a list marker.
                runs.append(index..<end)
            }
            index = end
        }
        return runs
    }

    static func isPunctuation(_ character: Character) -> Bool {
        character.isPunctuation || character.isSymbol
    }

    // MARK: Lines

    static func lines(_ source: String) -> [Substring] {
        let normalized = source.unicodeScalars.contains("\r") ? source.replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n") : source
        return normalized.split(separator: "\n", omittingEmptySubsequences: false)
    }

    static func isBlank(_ line: Substring) -> Bool { line.allSatisfy { $0 == " " || $0 == "\t" } }

    static func isListMarker(_ line: Substring) -> Bool {
        let content = line.drop(while: { $0 == " " })
        guard let first = content.first else { return false }
        if "-*+".contains(first) { return content.dropFirst().first == " " }
        let digits = content.prefix(while: \.isNumber)
        guard !digits.isEmpty, digits.count < 10 else { return false }
        let rest = content.dropFirst(digits.count)
        return (rest.first == "." || rest.first == ")") && rest.dropFirst().first == " "
    }

    /// Leading spaces and quote markers, which a fence or math block keeps.
    static func splitPrefix(_ line: Substring) -> (prefix: String, content: Substring) {
        let content = line.drop(while: { $0 == " " || $0 == "\t" || $0 == ">" })
        return (String(line[..<content.startIndex]), content)
    }

    private struct Fence { let marker: Character; let length: Int; let prefix: String }

    private static func fenceOpening(_ line: Substring) -> Fence? {
        let (prefix, content) = splitPrefix(line)
        guard let marker = content.first, marker == "`" || marker == "~" else { return nil }
        let run = content.prefix(while: { $0 == marker })
        guard run.count >= 3 else { return nil }
        if marker == "`", content.dropFirst(run.count).contains("`") { return nil }
        return Fence(marker: marker, length: run.count, prefix: prefix)
    }

    private static func closes(_ fence: Fence, _ line: Substring) -> Bool {
        let content = splitPrefix(line).content
        let run = content.prefix(while: { $0 == fence.marker })
        return run.count >= fence.length && content.dropFirst(run.count).allSatisfy { $0 == " " || $0 == "\t" }
    }

    /// Whether each line belongs to a fenced code block, fences included.
    static func fencedLines(_ lines: [Substring]) -> [Bool] {
        var result = Array(repeating: false, count: lines.count)
        var open: Fence?
        for (index, line) in lines.enumerated() {
            if let fence = open {
                result[index] = true
                if closes(fence, line) { open = nil }
            } else if let fence = fenceOpening(line) {
                result[index] = true
                open = fence
            }
        }
        return result
    }

    /// The fence the text leaves open: its opening line, and the line that
    /// would close it.
    private static func openFenceStart(_ lines: [Substring]) -> (index: Int, closing: String)? {
        var open: (index: Int, fence: Fence)?
        for (index, line) in lines.enumerated() {
            if let current = open {
                if closes(current.fence, line) { open = nil }
            } else if let fence = fenceOpening(line) {
                open = (index, fence)
            }
        }
        return open.map { ($0.index, $0.fence.prefix + String(repeating: $0.fence.marker, count: $0.fence.length)) }
    }

    /// The first word of a fence's info string (```chart title → `chart`).
    private static func infoWord(_ line: Substring, _ fence: Fence) -> Substring {
        splitPrefix(line).content.dropFirst(fence.length)
            .drop(while: { $0 == " " || $0 == "\t" }).prefix(while: { !$0.isWhitespace })
    }

    /// The first word of the info string of the fence a line opens.
    private static func infoWord(_ line: String) -> Substring? {
        let substring = Substring(line)
        return fenceOpening(substring).map { infoWord(substring, $0) }
    }

    // MARK: Rich blocks

    /// A fence's opening line with `marker` after its tag, when the fence
    /// opens a rich block (```chart); nil for any other line.
    static func markingRich(_ line: String, with marker: Character) -> String? {
        let substring = Substring(line)
        guard let fence = fenceOpening(substring) else { return nil }
        let word = infoWord(substring, fence)
        guard !word.isEmpty, RichBlocks.tags.contains(word.lowercased()) else { return nil }
        return String(line[..<word.endIndex]) + String(marker) + String(line[word.endIndex...])
    }

    /// A finished reply whose rich block never closed (it was stopped while
    /// the block was written) shows that block as unfinished, rather than
    /// drawing what had come of it.
    static func markingUnfinishedRich(_ source: String) -> String {
        guard RichBlocks.tags.contains(where: { source.range(of: $0, options: .caseInsensitive) != nil }) else { return source }
        var lines = self.lines(source).map(String.init)
        guard let open = openFenceStart(lines.map { Substring($0) }),
              let marked = markingRich(lines[open.index], with: RichBlocks.unfinishedMarker) else { return source }
        lines[open.index] = marked
        return lines.joined(separator: "\n")
    }

    // MARK: Charts in a reply to a chart request

    /// Fence tags whose block may hold a chart's data in a reply to a chart
    /// request: the model writes it under ```json or a bare fence as well
    /// as under ```chart.
    static let chartDataTags: Set<String> = ["", "json", "json5", "jsonc"]
    /// Fence tags of a block the model may wrap a chart block in to show it
    /// (```markdown, and on the phone also a bare fence).
    static let wrapperTags: Set<String> = ["", "markdown", "md", "json", "json5", "jsonc", "text", "plaintext", "txt"]

    private enum Reading: Equatable { case chart, undecided, other }

    /// A reply read the way the model meant its charts. A chart block inside
    /// a ```markdown, ```json, ```text or bare fence loses that wrapper and
    /// its closing fence: read as CommonMark, the chart's closing fence
    /// closed the wrapper, and the wrapper's own closing fence opened a code
    /// block that swallowed the text after it. In a reply to a message that
    /// asked for a chart (`requested`, `RichFormatGuide`), a ```json or bare
    /// fence whose data the chart checks accept (`ChartSpec.parse`) also
    /// becomes a ```chart block. Other code and JSON stay as written. While
    /// the model writes (`generating`), a fence that may still turn out to be
    /// one of these waits, and data arriving under a ```json or bare fence
    /// in such a reply shows the chart's placeholder; whatever does not pass
    /// the checks once its fence closes is code again.
    public static func readingCharts(_ text: String, generating: Bool, requested: Bool = true) -> String {
        guard text.contains("```") || text.contains("~~~") else { return text }
        let rows = lines(text)
        var dropped: Set<Int> = [], renamed: Set<Int> = [], held: Int?
        var index = 0
        scan: while index < rows.count {
            guard !dropped.contains(index), let fence = fenceOpening(rows[index]) else {
                index += 1
                continue
            }
            let tag = infoWord(rows[index], fence).lowercased()
            // An opening line still arriving (```mar) waits until its tag is known.
            if generating, index == rows.count - 1,
               wrapperTags.union(RichBlocks.tags).union(requested ? chartDataTags : []).contains(where: { $0.hasPrefix(tag) }) {
                held = index
                break
            }
            if wrapperTags.contains(tag) {
                switch wrapper(rows, at: index, fence, generating: generating, requested: requested) {
                case .wrapper(let end):
                    dropped.insert(index)
                    if let end { dropped.insert(end) }
                    index += 1
                    continue scan
                case .undecided:
                    held = index
                    break scan
                case .other:
                    break
                }
            }
            let close = ((index + 1)..<rows.count).first { closes(fence, rows[$0]) }
            if requested, chartDataTags.contains(tag) {
                switch chartData(rows, from: index, to: close, generating: generating) {
                case .chart: renamed.insert(index)
                case .undecided:
                    held = index
                    break scan
                case .other: break
                }
            }
            guard let close else { break }
            index = close + 1
        }
        guard !dropped.isEmpty || !renamed.isEmpty || held != nil else { return text }
        var result: [String] = []
        for (index, row) in rows.enumerated() {
            if let held, index >= held { break }
            guard !dropped.contains(index) else { continue }
            if renamed.contains(index), let fence = fenceOpening(row) {
                let tag = infoWord(row, fence)
                result.append(String(row[..<tag.startIndex]) + "chart" + String(row[tag.endIndex...]))
            } else {
                result.append(String(row))
            }
        }
        return result.joined(separator: "\n")
    }

    private enum Wrapper: Equatable { case wrapper(end: Int?), undecided, other }

    /// Whether the fence opened at `start` wraps a chart block. Inside it a
    /// fence with a tag opens a block of its own, so its bare closing fence
    /// does not end the wrapper; a bare fence while none is open does.
    private static func wrapper(_ rows: [Substring], at start: Int, _ fence: Fence, generating: Bool, requested: Bool) -> Wrapper {
        var inner: (fence: Fence, start: Int, tag: String)?
        var holdsChart = false
        var firstContent: Int?
        for index in (start + 1)..<rows.count {
            let row = rows[index]
            if let open = inner {
                guard closes(open.fence, row) else { continue }
                if open.tag == "chart" || (requested && chartDataTags.contains(open.tag)
                    && chartData(rows, from: open.start, to: index, generating: generating) == .chart) {
                    holdsChart = true
                }
                inner = nil
            } else if let opening = fenceOpening(row) {
                let tag = infoWord(row, opening).lowercased()
                if tag.isEmpty, opening.marker == fence.marker, opening.length >= fence.length {
                    // Right after the opening line, a bare fence still
                    // arriving may yet be ```chart.
                    if generating, firstContent == nil, index == rows.count - 1 { return .undecided }
                    return holdsChart ? .wrapper(end: index) : .other
                }
                inner = (opening, index, tag)
                firstContent = firstContent ?? index
            } else if !isBlank(row) {
                firstContent = firstContent ?? index
            }
        }
        if let open = inner, !holdsChart {
            if open.tag == "chart" { return .wrapper(end: nil) }
            if requested, chartDataTags.contains(open.tag) {
                switch chartData(rows, from: open.start, to: nil, generating: generating) {
                case .chart: return .wrapper(end: nil)
                case .undecided: return .undecided
                case .other: break
                }
            }
        }
        if holdsChart { return .wrapper(end: nil) }
        guard generating else { return .other }
        // While it arrives, a wrapper waits until its first line shows
        // whether a chart block opens in it.
        guard let first = firstContent else { return .undecided }
        return first == rows.count - 1 && mayOpenChart(rows[first], requested: requested) ? .undecided : .other
    }

    /// A last line still arriving that may become the opening fence of a
    /// chart block or of its data (`` ` ``, ```cha, ```js).
    private static func mayOpenChart(_ row: Substring, requested: Bool) -> Bool {
        let content = splitPrefix(row).content
        if let first = content.first, first == "`" || first == "~", content.count < 3,
           content.allSatisfy({ $0 == first }) {
            return true
        }
        guard let opening = fenceOpening(row) else { return false }
        let tag = infoWord(row, opening).lowercased()
        return RichBlocks.tags.union(requested ? chartDataTags : []).contains { $0.hasPrefix(tag) }
    }

    /// Whether the fenced block opened at `start` (closed at `end`, or still
    /// open) holds a chart's data. Closed, its body must be one JSON object
    /// the chart checks accept. Open while the model writes, a body starting
    /// an object is taken for chart data still arriving, and an empty one
    /// waits. Open in a finished reply, it is a chart that never closed only
    /// when its data names a chart type.
    private static func chartData(_ rows: [Substring], from start: Int, to end: Int?, generating: Bool) -> Reading {
        let body = rows[(start + 1)..<(end ?? rows.count)].joined(separator: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if end != nil {
            guard body.hasPrefix("{"), body.hasSuffix("}"), case .success = ChartSpec.parse(body) else { return .other }
            return .chart
        }
        guard body.hasPrefix("{") else { return generating && body.isEmpty ? .undecided : .other }
        if generating { return .chart }
        return ChartSpec.peek(body).kind != nil ? .chart : .other
    }

    /// Where a paced step (ReplyPacer) that would end `end` characters into
    /// `text` ends instead around a rich block, whose data is never laid out
    /// a character at a time: once a step reaches into the block's opening
    /// line it takes the whole block, through the line break after its
    /// closing fence, or all that has come of it while the model is still
    /// writing it, so the block's place shows its placeholder until the data
    /// is complete and then the block. While the model writes, a step that
    /// would end in a fence's opening line that has not ended yet, and whose
    /// tag may still become a rich block's (```cha), stops before that line.
    /// A table's head is taken whole in the same way (`tableHeadEnd`).
    public static func pacedEnd(_ text: String, shown: Int, end: Int, generating: Bool) -> Int {
        let end = tableHeadEnd(text, end: end)
        guard text.contains("```") || text.contains("~~~") else { return end }
        let lines = text.split(separator: "\n", omittingEmptySubsequences: false)
        var offset = 0
        var open: (fence: Fence, start: Int, rich: Bool)?
        for (index, line) in lines.enumerated() {
            let last = index == lines.count - 1
            // Where the line ends, past its line break when one has come.
            let after = offset + line.count + (last ? 0 : 1)
            if let current = open {
                if closes(current.fence, line) {
                    open = nil
                    if current.rich, end > current.start, end < after { return after }
                }
            } else if let fence = fenceOpening(line) {
                let word = infoWord(line, fence)
                if last, generating, end > offset, RichBlocks.mayName(word) { return max(shown, offset) }
                open = (fence, offset, RichBlocks.tags.contains(word.lowercased()))
            }
            if after >= end, open?.rich != true { break }
            offset = after
        }
        if let current = open, current.rich, end > current.start { return max(end, text.count) }
        return end
    }

    /// Whether each line is inside a `$$` or `\[` block that has its
    /// closing line, delimiters included.
    static func mathBlockLines(_ lines: [Substring], fenced: [Bool]) -> [Bool] {
        var result = Array(repeating: false, count: lines.count)
        var index = 0
        while index < lines.count {
            defer { index += 1 }
            guard !fenced[index] else { continue }
            let trimmed = splitPrefix(lines[index]).content.trimmingCharacters(in: .whitespaces)
            guard let delimiters = blockMathDelimiters(trimmed),
                  !(trimmed.count > delimiters.0.count && trimmed.dropFirst(delimiters.0.count).contains(delimiters.1)) else { continue }
            let close = delimiters.1
            guard let end = ((index + 1)..<max(index + 1, lines.count)).first(where: {
                !fenced[$0] && splitPrefix(lines[$0]).content.trimmingCharacters(in: .whitespaces).hasSuffix(close)
            }) else { continue }
            for line in index...end { result[line] = true }
            index = end
        }
        return result
    }

    private static func openMathBlock(_ lines: [Substring], fenced: [Bool]) -> String? {
        let closed = mathBlockLines(lines, fenced: fenced)
        for index in lines.indices.reversed() where !fenced[index] && !closed[index] {
            let (prefix, content) = splitPrefix(lines[index])
            let trimmed = content.trimmingCharacters(in: .whitespaces)
            guard let delimiters = blockMathDelimiters(trimmed) else { continue }
            let (open, close) = delimiters
            if trimmed.count > open.count, trimmed.dropFirst(open.count).contains(close) { return nil }
            return prefix + close
        }
        return nil
    }

    /// As 1.1.0 (244) streamed a table, for comparison in UI checks: a row
    /// still arriving waited until its line ended with a pipe, and the
    /// table's head was laid out a character at a time.
    public static var holdsTableRowsWhole = false

    /// Trailing table lines wait until the table has its delimiter row, all
    /// of it: a line has come after it, or it has its closing pipe and as
    /// many cells as the header. A row still arriving shows as far as it has
    /// come, once a cell has something in it, so its cells fill in as a
    /// paragraph's text does and a row once shown never goes again. Until
    /// 1.1.0 (244) the row waited until its line ended with a pipe, which
    /// it also did for a moment whenever a step ended just after a cell:
    /// the row showed a cell or two, went, and came back whole, every row.
    private static func holdBackTableRows(_ lines: inout [String]) {
        var start = lines.count
        while start > 0, lines[start - 1].trimmingCharacters(in: .whitespaces).hasPrefix("|") { start -= 1 }
        guard start < lines.count else { return }
        let rows = lines[start...].map { $0.trimmingCharacters(in: .whitespaces) }
        if holdsTableRowsWhole {
            let hasDelimiter = rows.dropFirst().contains { row in
                isTableDelimiter(row) && row.hasSuffix("|")
            }
            if !hasDelimiter {
                lines.removeSubrange(start...)
            } else if let last = rows.last, !last.hasSuffix("|") || last.count < 2 {
                lines.removeLast()
            }
            return
        }
        let headed = rows.count > 2
            || (rows.count == 2 && rows[1].hasSuffix("|") && tableCells(rows[1]) == tableCells(rows[0]))
        guard headed, isTableDelimiter(rows[1]) else {
            lines.removeSubrange(start...)
            return
        }
        if rows.count > 2, let last = rows.last, !last.contains(where: { $0 != "|" && !$0.isWhitespace }) {
            lines.removeLast()
        }
    }

    /// A table's delimiter row (`|:--|--:|`), whole or still arriving.
    static func isTableDelimiter(_ row: String) -> Bool {
        row.contains("-") && row.filter({ $0 == "|" }).count >= 2 && row.allSatisfy { "|-: ".contains($0) }
    }

    /// How many cells a table row has: its pipes not escaped, less the
    /// ones at its ends.
    static func tableCells(_ row: String) -> Int {
        var pipes: [String.Index] = []
        var escaped = false
        for index in row.indices {
            let character = row[index]
            if character == "|", !escaped { pipes.append(index) }
            escaped = character == "\\" && !escaped
        }
        var count = pipes.count + 1
        if pipes.first == row.startIndex { count -= 1 }
        if let last = pipes.last, row.index(after: last) == row.endIndex, row.count > 1 { count -= 1 }
        return count
    }

    /// Where a paced step (ReplyPacer) that would end `end` characters into
    /// `text` ends instead around a table's head: once a step reaches into a
    /// table's header line, it takes the header and its delimiter row whole,
    /// through the line break after the delimiter row, or all that has come
    /// of them while the model is still writing them. Neither shows before
    /// the delimiter row is complete (`holdBackTableRows`), so laid out a
    /// character at a time they showed nothing for a second or two and then
    /// the header all at once (until 1.1.0 (244)); taken whole, the header
    /// fades in as soon as it has come and the rows follow at the pace.
    static func tableHeadEnd(_ text: String, end: Int) -> Int {
        guard !holdsTableRowsWhole, text.contains("|") else { return end }
        let lines = text.split(separator: "\n", omittingEmptySubsequences: false)
        let fenced = text.contains("```") || text.contains("~~~") ? fencedLines(lines) : nil
        func isRow(_ index: Int) -> Bool {
            index >= 0 && index < lines.count && fenced?[index] != true
                && lines[index].drop(while: { $0 == " " || $0 == "\t" }).first == "|"
        }
        var offset = 0
        for index in lines.indices {
            let last = index == lines.count - 1
            let after = offset + lines[index].count + (last ? 0 : 1)
            guard after < end else {
                // The line the step ends in: a table's header line, or the
                // delimiter row under it.
                let header = isRow(index) && !isRow(index - 1)
                let delimiter = isRow(index) && isRow(index - 1) && !isRow(index - 2)
                guard header || delimiter else { return end }
                let row = header ? index + 1 : index
                // The header still arriving, or its delimiter row not begun.
                guard row < lines.count, !(row == lines.count - 1 && lines[row].isEmpty) else { return max(end, text.count) }
                let delimiterRow = lines[row].trimmingCharacters(in: .whitespaces)
                if row == lines.count - 1 {
                    // The delimiter row still arriving.
                    guard isRow(row), delimiterRow.allSatisfy({ "|-: ".contains($0) }) else { return end }
                    return max(end, text.count)
                }
                // A line under the header that is not a delimiter row: no table.
                guard isRow(row), isTableDelimiter(delimiterRow) else { return end }
                let rowStart = header ? after : offset
                return max(end, rowStart + lines[row].count + 1)
            }
            offset = after
        }
        return end
    }

    private static func codeSpanTicks(_ text: String) -> (open: Bool, length: Int) {
        let characters = Array(text)
        var index = 0
        while index < characters.count {
            guard characters[index] == "`" else { index += 1; continue }
            var run = 0
            while index + run < characters.count, characters[index + run] == "`" { run += 1 }
            guard let end = closingTicks(characters, from: index + run, length: run) else { return (true, run) }
            index = end + run
        }
        return (false, 0)
    }
}
