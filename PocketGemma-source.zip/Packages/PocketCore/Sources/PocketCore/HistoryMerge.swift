import Foundation

public enum HistoryMerge {
    /// Keep local-only conversations and messages. A cloud snapshot must never
    /// erase a newer local conversation or replay an interrupted generation.
    public static func merge(local: [ChatThread], incoming: [ChatThread]) -> [ChatThread] {
        var byID = Dictionary(local.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        for remote in incoming {
            guard var existing = byID[remote.id] else {
                var recovered = remote; recovered.recoverInterruptedReplies()
                byID[remote.id] = recovered; continue
            }
            var messages = Dictionary(existing.messages.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            var order = existing.messages.map(\.id)
            for message in remote.messages {
                if let localMessage = messages[message.id] {
                    if remote.updatedAt > existing.updatedAt && message.text.count >= localMessage.text.count {
                        messages[message.id] = message
                    }
                } else { messages[message.id] = message; order.append(message.id) }
            }
            let position = Dictionary(order.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
            existing.messages = messages.values.sorted {
                $0.createdAt == $1.createdAt ? (position[$0.id] ?? 0) < (position[$1.id] ?? 0) : $0.createdAt < $1.createdAt
            }
            existing.updatedAt = max(existing.updatedAt, remote.updatedAt)
            existing.recoverInterruptedReplies()
            byID[remote.id] = existing
        }
        return byID.values.sorted { $0.updatedAt == $1.updatedAt ? $0.id.uuidString < $1.id.uuidString : $0.updatedAt > $1.updatedAt }
    }
    public static func attachmentNames(in threads: [ChatThread]) throws -> Set<String> {
        let names = Set(threads.flatMap(\.messages).flatMap(\.media).flatMap {
            [$0.storedName] + $0.imageNames + [$0.thumbnailName].compactMap { $0 }
        })
        guard names.allSatisfy(ChatAttachment.isSafeFileName) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        return names
    }
}
