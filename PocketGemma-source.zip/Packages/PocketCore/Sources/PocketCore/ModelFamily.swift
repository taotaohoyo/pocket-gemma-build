import Foundation

/// A series of models: the first level of the model pickers (fielua-reports
/// Issue #7, the user's request of 2026-11-12, 1.1.0 (269)). The first
/// launch's モデルを選ぶ and the chat's model menu list Gemma, Qwen, LFM
/// and Phi, and a series opens to its own models; choosing the series
/// chooses nothing. Grouped from each model's `family`, so a model added
/// later joins its series and a new series gets a row of its own.
public struct ModelFamilyGroup: Identifiable, Equatable, Sendable {
    /// The series as each model names it: "Gemma", "Qwen", "LFM", "Phi".
    public let family: String
    /// The series's models, in the order they were given.
    public let models: [ModelSpec]

    public var id: String { family }
    /// What the picker calls the series: its name, as the models give it.
    public var title: String { family }
    /// "gemma": the part of the accessibility identifiers that names the
    /// series (model-menu-gemma, as Gemma 4's submenu was before 269).
    public var key: String { family.lowercased() }

    public func contains(_ id: String?) -> Bool { models.contains { $0.id == id } }
    /// Every model of the series is a test version (LFM and Phi in 269), so
    /// the series says so before it is opened.
    public var isAllTestVersions: Bool { !models.isEmpty && models.allSatisfy(\.isTestVersion) }

    /// How many models the series has and how many are on the phone:
    /// 「3モデル · ダウンロード済み 2」, the count alone while none is.
    public func summary(installed: (ModelSpec) -> Bool) -> String {
        let count = String(localized: "\(models.count)モデル")
        let saved = models.filter(installed).count
        return saved == 0 ? count : count + " · " + String(localized: "ダウンロード済み \(saved)")
    }

    /// The series in the order the user named them (2026-11-12: 「Gemma・
    /// Qwen・LFM・Phi」); a series not named here comes after them, in the
    /// order its first model comes in the list.
    static let preferredOrder = ["Gemma", "Qwen", "LFM", "Phi"]

    /// `models` by series. Within a series the models keep the order given
    /// (each once); the series follow `preferredOrder`.
    public static func groups(_ models: [ModelSpec]) -> [ModelFamilyGroup] {
        var order: [String] = []
        var members: [String: [ModelSpec]] = [:]
        for spec in models {
            if members[spec.family] == nil { order.append(spec.family) }
            if members[spec.family]?.contains(where: { $0.id == spec.id }) == true { continue }
            members[spec.family, default: []].append(spec)
        }
        func rank(_ family: String) -> Int { preferredOrder.firstIndex(of: family) ?? preferredOrder.count }
        return order.enumerated()
            .sorted { (rank($0.element), $0.offset) < (rank($1.element), $1.offset) }
            .map { ModelFamilyGroup(family: $0.element, models: members[$0.element] ?? []) }
    }
}

extension ModelSpec {
    /// The models the pickers offer, in their order: Gemma 4 E2B first,
    /// the first model of every new phone (fielua-reports Issue #1), then
    /// the catalog as listed; Qwen3 0.6B only with developer settings.
    /// The first launch listed its models so since 1.1.0 (219), and the
    /// chat's menu put E2B before E4B.
    public static func pickerCatalog(developer: Bool) -> [ModelSpec] {
        let visible = visibleCatalog(developer: developer)
        return visible.filter { $0.id == e2b.id } + visible.filter { $0.id != e2b.id }
    }
}
