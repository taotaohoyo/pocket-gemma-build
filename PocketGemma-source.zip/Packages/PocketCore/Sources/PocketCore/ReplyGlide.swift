import Foundation

/// How the Aurora Orb's row follows a reply's text down while it is written
/// (1.1.0 (303), the user's directive of 2026-11-20: the orb moves down
/// smoothly with the reply, with no jolt at its first character, smooth at
/// new lines, paragraphs, headings and lists, never ahead and back, never
/// over the text, and in a long chat in step with the scrolling).
///
/// The row (the orb, its field and the point beside it, one piece) sits
/// under the reply's text. Each time the text grows, the room the row
/// keeps for it (ReplyRoom) grows to the text's new height along one curve
/// that starts gently and lands softly (`share`), over a time that grows
/// with the distance and shortens when the text grows again sooner than
/// that (`duration`); the conversation, where it follows the reply, scrolls
/// in the same moment along the same curve. 302 left the row under the
/// text's own height, eased by a 0.24 s spring whose start is its fastest
/// part: on the phone two thirds of the first line's 34pt went in two
/// frames (67 ms), the jolt the user saw, and in a long chat the scroll
/// came a frame after the growth, so the orb sank and came back.
public enum ReplyGlide {
    /// The curve: a cubic Bézier through (0, 0), (x1, y1), (x2, y2), (1, 1).
    /// It leaves its place with no speed and little push (a sixth of 302's
    /// spring at the first frame), is fastest about a quarter of the way
    /// through its time and lands with no overshoot.
    public static let curve = (x1: 0.3, y1: 0.0, x2: 0.2, y2: 1.0)
    /// Seconds for a step of no distance, and per point of distance, within
    /// `shortestByDistance...longest`: a line (about 23pt) 0.34 s, the
    /// first line with its margins (34pt) 0.38 s, a paragraph (about 40pt)
    /// 0.40 s, a heading (about 55pt) 0.45 s, a table or a code block
    /// 0.48 s. A longer way goes faster, but not in proportion.
    public static let base: TimeInterval = 0.26
    public static let perPoint: TimeInterval = 0.0035
    public static let shortestByDistance: TimeInterval = 0.3
    public static let longest: TimeInterval = 0.48
    /// When the text grows again sooner than a step's time, the next step
    /// takes about as long as the text took (`since` times this), never
    /// less than `shortest`: the row keeps up with a fast model without
    /// stopping between lines.
    public static let pace = 1.2
    public static let shortest: TimeInterval = 0.24

    /// The time for a step of `distance` points, `since` seconds after the
    /// step before began (nil for the first).
    public static func duration(distance: Double, since: TimeInterval?) -> TimeInterval {
        let byDistance = min(max(base + perPoint * abs(distance), shortestByDistance), longest)
        guard let since, since >= 0 else { return byDistance }
        return min(byDistance, max(shortest, since * pace))
    }

    /// The share of the way gone at `progress` (0...1) of a step's time.
    public static func share(at progress: Double) -> Double {
        let x = min(max(progress, 0), 1)
        guard x > 0, x < 1 else { return x }
        // The Bézier's parameter for x, by bisection (x(t) only rises).
        var low = 0.0, high = 1.0
        for _ in 0..<40 {
            let middle = (low + high) / 2
            if bezier(middle, curve.x1, curve.x2) < x { low = middle } else { high = middle }
        }
        return bezier((low + high) / 2, curve.y1, curve.y2)
    }

    private static func bezier(_ t: Double, _ p1: Double, _ p2: Double) -> Double {
        let u = 1 - t
        return 3 * p1 * t * u * u + 3 * p2 * t * t * u + t * t * t
    }

    /// Where a step from `from` to `to` that began at `start` and lasts
    /// `duration` is at `time`, for a check to compare the screen with.
    public static func position(from: Double, to: Double, start: TimeInterval, duration: TimeInterval,
                                at time: TimeInterval) -> Double {
        guard duration > 0 else { return to }
        return from + (to - from) * share(at: (time - start) / duration)
    }
}

/// The room the orb's row keeps for a reply's text while it is written
/// (1.1.0 (303)): the text's height as laid out, followed as it grows. It
/// never goes back up the moment the text is laid out shorter (a character
/// that ends a line can pull the line before's last word back up, and a
/// long code block folds), only once the text has stayed shorter for
/// `shrinkHold`, so the orb does not go down, up and down again.
public struct ReplyRoom: Equatable, Sendable {
    public enum Step: Equatable, Sendable {
        /// Nothing to do.
        case none
        /// Take the text's height as it is, with no motion (the first
        /// height known).
        case settle(Double)
        /// Move the row from the room it keeps to this height.
        case move(from: Double, to: Double)
        /// The text is shorter: look again at this time.
        case wait(until: TimeInterval)
    }

    /// Shorter text is followed up only after this long.
    public static let shrinkHold: TimeInterval = 0.6
    /// Changes smaller than this (points) are not followed.
    public static let tolerance = 0.5

    /// The room kept, nil until the text's height is first known.
    public private(set) var height: Double?
    private var shorterSince: TimeInterval?
    private var latest: Double?

    public init(height: Double? = nil) { self.height = height }

    /// The text is laid out `natural` points tall at `now`.
    public mutating func text(height natural: Double, at now: TimeInterval) -> Step {
        latest = natural
        guard let kept = height else {
            height = natural
            return .settle(natural)
        }
        if natural > kept + Self.tolerance {
            shorterSince = nil
            height = natural
            return .move(from: kept, to: natural)
        }
        if natural < kept - Self.tolerance {
            guard let since = shorterSince else {
                shorterSince = now
                return .wait(until: now + Self.shrinkHold)
            }
            guard now - since >= Self.shrinkHold else { return .wait(until: since + Self.shrinkHold) }
            shorterSince = nil
            height = natural
            return .move(from: kept, to: natural)
        }
        shorterSince = nil
        return .none
    }

    /// The hold's time has come: the text's latest height, followed if it
    /// is still shorter.
    public mutating func look(at now: TimeInterval) -> Step {
        guard let latest else { return .none }
        return text(height: latest, at: now)
    }
}
