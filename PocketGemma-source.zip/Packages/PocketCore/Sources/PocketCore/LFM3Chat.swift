import Foundation

/// LFM3's chat format, as its GGUF's template writes it (llama.cpp b11960,
/// 1.1.0 (232)): ChatML turns after <|startoftext|>, and an assistant turn
/// that opens with <think>, closed at once when the reply doesn't think.
/// Earlier replies carry an empty thought, as the template writes them
/// (their thoughts are never kept). Fielua renders it itself, in parts, so
/// that only its own markers become control tokens: a message or a file
/// that types <|im_end|> stays text (LlamaChat tokenizes `.text` without
/// control tokens). LFM3-VL 2B (1.1.0 (234)) reads the same format with
/// its pictures at the start of the person's turn, where llama.cpp's mtmd
/// puts each picture's tokens between its own markers.
public enum LFM3Prompt {
    public enum Part: Equatable, Sendable {
        case marker(String)
        case text(String)
        /// The turn's next picture.
        case picture
    }

    public struct Turn: Equatable, Sendable {
        public enum Role: String, Sendable { case user, assistant }
        public let role: Role
        public let text: String
        /// Pictures sent with the person's turn, before its text.
        public let pictures: Int
        public init(_ role: Role, _ text: String, pictures: Int = 0) {
            self.role = role; self.text = text; self.pictures = role == .user ? pictures : 0
        }
    }

    /// Where llama.cpp's mtmd reads a picture (`mtmd_default_marker()`),
    /// as llama-server renders an image in the template.
    public static let pictureMarker = "<__media__>"

    public static let begin = "<|startoftext|>"
    public static let start = "<|im_start|>"
    public static let end = "<|im_end|>"
    public static let thinkStart = "<think>"
    public static let thinkEnd = "</think>"

    /// The prompt up to where the model writes: its turn open, with <think>
    /// left open when it thinks. `reply` is a stopped reply's text, which
    /// the model goes on from, after an empty thought.
    public static func parts(system: String, turns: [Turn], thinking: Bool, reply: String? = nil) -> [Part] {
        var parts: [Part] = [.marker(begin)]
        if !system.isEmpty { parts += [.marker(start), .text("system\n" + system), .marker(end), .text("\n")] }
        for turn in turns {
            switch turn.role {
            case .user:
                parts += [.marker(start), .text("user\n")] + Array(repeating: .picture, count: turn.pictures)
                    + [.text(turn.text), .marker(end), .text("\n")]
            case .assistant:
                parts += [.marker(start), .text("assistant\n"), .marker(thinkStart), .marker(thinkEnd),
                          .text(turn.text), .marker(end), .text("\n")]
            }
        }
        parts += [.marker(start), .text("assistant\n"), .marker(thinkStart)]
        if !thinking || reply != nil { parts.append(.marker(thinkEnd)) }
        if let reply { parts.append(.text(reply)) }
        return merged(parts)
    }

    /// The parts as one string, as the template renders the same chat.
    public static func rendered(_ parts: [Part]) -> String {
        parts.map { part in
            switch part {
            case .marker(let marker): marker
            case .text(let text): text
            case .picture: pictureMarker
            }
        }.joined()
    }

    /// Adjacent text joined and empty text dropped, so each text is read as
    /// the template's string would be.
    static func merged(_ parts: [Part]) -> [Part] {
        var result: [Part] = []
        for part in parts {
            guard case .text(let text) = part else { result.append(part); continue }
            if text.isEmpty { continue }
            if case .text(let last)? = result.last { result[result.count - 1] = .text(last + text) } else { result.append(part) }
        }
        return result
    }
}

/// Splits what LFM3 writes into its thought and its answer as it streams.
/// llama.cpp hands over the model's own text, markers and all: a thought
/// ends at </think>, and the answer at a turn marker the model should never
/// write (<|im_end|> ends its turn as a token before it shows). A marker
/// split across pieces is held back until it can be told apart from text.
/// The thought is never shown; the answer starts at its first character
/// that isn't a space or a line break.
public struct ThoughtSplitter: Sendable {
    public private(set) var thinking: Bool
    /// The model wrote a turn marker: whatever follows isn't the answer.
    public private(set) var ended = false
    private var held = ""
    private var answerStarted = false

    static let answerEnds = [LFM3Prompt.end, LFM3Prompt.start, LFM3Prompt.begin]

    public init(thinking: Bool) { self.thinking = thinking }

    public mutating func feed(_ text: String) -> (thought: String, answer: String) {
        guard !ended else { return ("", "") }
        var buffer = held + text
        held = ""
        var thought = "", answer = ""
        if thinking {
            if let range = buffer.range(of: LFM3Prompt.thinkEnd) {
                thought = String(buffer[..<range.lowerBound])
                buffer = String(buffer[range.upperBound...])
                thinking = false
            } else {
                let keep = Self.heldLength(buffer, markers: [LFM3Prompt.thinkEnd])
                held = String(buffer.suffix(keep))
                return (String(buffer.dropLast(keep)), "")
            }
        }
        if let range = Self.answerEnds.compactMap({ buffer.range(of: $0) }).min(by: { $0.lowerBound < $1.lowerBound }) {
            ended = true
            answer = String(buffer[..<range.lowerBound])
        } else {
            let keep = Self.heldLength(buffer, markers: Self.answerEnds)
            held = String(buffer.suffix(keep))
            answer = String(buffer.dropLast(keep))
        }
        return (thought, trimmedStart(answer))
    }

    /// The end of the stream: what was held back is text after all.
    public mutating func flush() -> (thought: String, answer: String) {
        defer { held = "" }
        guard !ended else { return ("", "") }
        return thinking ? (held, "") : ("", trimmedStart(held))
    }

    /// The thought ends here, as when the runtime closes it at its budget;
    /// what was held back of it is dropped.
    public mutating func endThought() {
        thinking = false
        held = ""
    }

    private mutating func trimmedStart(_ answer: String) -> String {
        guard !answerStarted else { return answer }
        let trimmed = String(answer.drop { $0.isWhitespace || $0.isNewline })
        if !trimmed.isEmpty { answerStarted = true }
        return trimmed
    }

    /// How much of the end of `text` may be the start of a marker.
    static func heldLength(_ text: String, markers: [String]) -> Int {
        let longest = markers.map(\.count).max() ?? 0
        for length in stride(from: min(text.count, longest - 1), to: 0, by: -1) {
            let tail = String(text.suffix(length))
            if markers.contains(where: { $0.hasPrefix(tail) }) { return length }
        }
        return 0
    }
}

/// Turns the bytes of a model's tokens into text: a token may end inside a
/// character (Japanese takes three bytes, an emoji four), which waits for
/// the next token's bytes. Bytes that never form a character read as U+FFFD.
public struct UTF8Assembler: Sendable {
    private var pending: [UInt8] = []
    public init() {}

    public mutating func feed(_ bytes: [UInt8]) -> String {
        pending += bytes
        let complete = Self.completeLength(pending)
        let text = String(decoding: pending[..<complete], as: UTF8.self)
        pending.removeFirst(complete)
        return text
    }

    public mutating func flush() -> String {
        defer { pending = [] }
        return String(decoding: pending, as: UTF8.self)
    }

    /// The length of `bytes` without a character still missing its last bytes.
    static func completeLength(_ bytes: [UInt8]) -> Int {
        var index = bytes.count - 1
        while index >= 0, bytes.count - index <= 4 {
            let byte = bytes[index]
            if byte & 0xC0 != 0x80 {
                let length = byte < 0x80 ? 1 : byte >= 0xF0 ? 4 : byte >= 0xE0 ? 3 : byte >= 0xC0 ? 2 : 1
                return bytes.count - index >= length ? bytes.count : index
            }
            index -= 1
        }
        return bytes.count
    }
}
