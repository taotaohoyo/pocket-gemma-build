import Foundation

/// The keyboard as スタンダード's pills (高速・深く and the model, over the
/// field) see it (fielua-reports #3, 1.1.0 (222)). With a Magic Keyboard on
/// the iPad they took no taps. They stood only while the field held the
/// keys and no keyboard notice said it was going down, and with a hardware
/// keyboard iPadOS's notices carry frames off the screen (the tester's
/// record) while the field keeps the keys; a menu taking the keys from the
/// field would have put them away under it too.
public enum ComposerKeyboard {
    /// Below this height a keyboard frame is a bar (iPadOS's shortcuts
    /// bar with a hardware keyboard, about 55pt), not a keyboard: the
    /// smallest on-screen one, the iPhone's in landscape, is about 200pt.
    public static let minimumKeyboardHeight = 100.0

    /// Whether a keyboard-will-hide notice is an on-screen keyboard on its
    /// way down, which the pills go into the field with. Frames in points,
    /// as the notice gives them: where the keyboard starts (its top and
    /// height) and the top it goes to. A hardware keyboard's notices start
    /// off the screen or with no height and go nowhere; they are no leave.
    /// Without frames, a leave, as before 1.1.0 (222).
    public static func onScreenKeyboardLeaves(beginTop: Double?, beginHeight: Double?, endTop: Double?) -> Bool {
        guard let beginTop, let beginHeight, let endTop else { return true }
        return beginHeight >= minimumKeyboardHeight && endTop > beginTop + 1
    }

    /// Whether the pills stand over the field. While the plus panel is
    /// open, never. With a hardware keyboard always: no on-screen keyboard
    /// comes or goes for them to rise and sink with, and their menus keep
    /// their place whoever holds the keys. Otherwise while the field holds
    /// the keys and the keyboard is not on its way down.
    public static func classicPillsShown(focused: Bool, keyboardLeaving: Bool, actionsOpen: Bool,
                                         hardwareKeyboard: Bool) -> Bool {
        if actionsOpen { return false }
        return hardwareKeyboard || (focused && !keyboardLeaving)
    }
}
