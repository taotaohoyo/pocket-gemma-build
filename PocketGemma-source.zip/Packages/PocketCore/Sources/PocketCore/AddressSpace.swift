import Foundation
#if canImport(Darwin)
import Darwin
#endif

/// The process's own address space: the range the system gives the app and
/// the unmapped space inside it. iOS limits this range separately from
/// memory. A model file is mapped as one block, so the largest free block
/// decides whether the next large mapping can succeed. Reading it walks the
/// region boundaries only (public Mach calls); it maps and changes nothing.
public struct AddressSpace: Codable, Sendable, Equatable {
    /// The task's map range, max_address − min_address.
    public let range: UInt64
    public let free: UInt64
    public let largestFree: UInt64
    public let regions: Int

    public init(range: UInt64, free: UInt64, largestFree: UInt64, regions: Int) {
        self.range = range; self.free = free; self.largestFree = largestFree; self.regions = regions
    }

    /// Adds up the gaps between regions given in address order.
    public struct GapCounter {
        private var next: UInt64
        private let high: UInt64
        public private(set) var free: UInt64 = 0
        public private(set) var largest: UInt64 = 0
        public private(set) var regions = 0
        public init(low: UInt64, high: UInt64) { next = low; self.high = high }
        /// False once a region starts at or past the end of the range.
        public mutating func add(start: UInt64, end: UInt64) -> Bool {
            guard start < high else { return false }
            if start > next { record(start - next) }
            next = max(next, end)
            regions += 1
            return true
        }
        public mutating func finish() -> (free: UInt64, largest: UInt64) {
            if high > next { record(high - next); next = high }
            return (free, largest)
        }
        private mutating func record(_ gap: UInt64) { free += gap; largest = max(largest, gap) }
    }

    public static func current() -> AddressSpace? {
        #if canImport(Darwin)
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<natural_t>.size)
        let status = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count)
            }
        }
        guard status == KERN_SUCCESS, info.max_address > info.min_address else { return nil }
        var counter = GapCounter(low: info.min_address, high: info.max_address)
        var address = vm_address_t(info.min_address)
        while counter.regions < 1_000_000 {
            var size: vm_size_t = 0, depth: natural_t = 0
            var region = vm_region_submap_info_data_64_t()
            var regionCount = mach_msg_type_number_t(
                MemoryLayout<vm_region_submap_info_data_64_t>.size / MemoryLayout<natural_t>.size)
            // Depth 0: top-level entries; the shared library region is one.
            let result = withUnsafeMutablePointer(to: &region) { pointer in
                pointer.withMemoryRebound(to: integer_t.self, capacity: Int(regionCount)) {
                    vm_region_recurse_64(mach_task_self_, &address, &size, &depth, $0, &regionCount)
                }
            }
            guard result == KERN_SUCCESS, size > 0 else { break }
            let start = UInt64(address)
            guard counter.add(start: start, end: start + UInt64(size)) else { break }
            address = vm_address_t(start + UInt64(size))
        }
        let regions = counter.regions
        let (free, largest) = counter.finish()
        return AddressSpace(range: info.max_address - info.min_address, free: free, largestFree: largest, regions: regions)
        #else
        return nil
        #endif
    }
}
