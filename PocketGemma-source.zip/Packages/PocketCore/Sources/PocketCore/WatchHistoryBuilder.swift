import Foundation

/// The iPhone's side of WatchHistory: the list and pages it sends the
/// Apple Watch, built from its chats as they are (nothing is changed).
extension WatchHistory {
    /// A model's name as short as the watch shows it. Chats from before
    /// models could be chosen were Gemma 4 E4B's (ChatThread.modelID).
    public static func modelName(_ id: String?) -> String {
        (ModelSpec.find(id) ?? .e4b).name.replacingOccurrences(of: "Gemma 4 ", with: "")
    }

    public static func summary(_ thread: ChatThread) -> Summary {
        Summary(id: thread.id.uuidString, title: thread.title, updated: thread.updatedAt,
                model: modelName(thread.modelID), watchModel: thread.modelID == ModelSpec.e2b.id,
                count: thread.messages.count)
    }

    /// The latest chats with something in them, the latest first.
    /// `former`: the watch's conversation of 1.1.0 (152) and its chat.
    public static func list(_ threads: [ChatThread], former: (conversation: String, chat: UUID)? = nil) -> List {
        let chats = threads.filter { !$0.messages.isEmpty }
            .sorted { $0.updatedAt > $1.updatedAt }
            .prefix(listLimit)
            .map(summary)
        return List(chats: Array(chats), formerConversation: former?.conversation, formerChat: former?.chat.uuidString)
    }

    /// The chat's latest messages within `budget`, each from its start up
    /// to `messageLimit`, starting on a question. `paused`: replies waiting
    /// for Fielua to open on the iPhone (ChatStore.replyIsPaused).
    public static func page(_ thread: ChatThread, paused: Set<UUID> = [], budget: Int = pageBudget) -> Page {
        var picked: [Message] = []
        var used = 0
        for message in thread.messages.reversed() {
            guard picked.count < pageMessages else { break }
            let (text, clipped) = clip(message.text, bytes: messageLimit)
            let cost = text.utf8.count + messageOverhead
            guard picked.isEmpty || used + cost <= budget else { break }
            picked.insert(Message(id: message.id.uuidString, fromUser: message.role == .user, text: text,
                                  state: state(message, paused: paused.contains(message.id)), clipped: clipped,
                                  attachments: message.media.count), at: 0)
            used += cost
        }
        // An answer whose question did not fit stays on the iPhone too.
        while picked.count > 1, picked.first?.fromUser == false { picked.removeFirst() }
        return Page(chat: thread.id.uuidString, updated: thread.updatedAt, model: modelName(thread.modelID),
                    watchModel: thread.modelID == ModelSpec.e2b.id, count: thread.messages.count,
                    messages: picked, earlier: thread.messages.count - picked.count)
    }

    /// A message's state as WatchLink.State names it.
    static func state(_ message: ChatMessage, paused: Bool) -> String {
        guard message.role == .assistant else { return "finished" }
        switch message.state {
        case .complete: return "finished"
        case .generating: return message.text.isEmpty ? "waiting" : "writing"
        case .stopped: return paused ? "paused" : "stopped"
        case .failed: return "failed"
        }
    }
}
