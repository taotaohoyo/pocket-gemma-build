import Foundation

/// What Fielua takes from a video and what the model made of it (1.1.0
/// (194)). LiteRT-LM 0.18 takes text, images and sound, not video, so a
/// video reaches Gemma 4 as scenes picked by how the picture changes
/// (VideoScenePicker) and as the parts of its sound that are not silent
/// (SoundParts), each with its time. When the message is sent, the model
/// describes the scenes and writes down the speech, one part at a time
/// (GemmaService); the reply then reads it all as one timeline
/// (VideoDigest). What is done is kept here, so a reply stopped part-way
/// goes on from there.
public struct VideoAnalysis: Codable, Equatable, Sendable {
    public struct Scene: Codable, Equatable, Sendable {
        /// Where in the video, in seconds.
        public var time: Double
        /// The scene's image in the attachment folder (also in imageNames).
        public var image: String
        /// How much the picture changed since the scene looked at before
        /// it (0 to 1): a cut or a big movement scores high.
        public var change: Double
        /// The model's words on the scene; nil until it has looked.
        public var caption: String?
        public init(time: Double, image: String, change: Double = 0, caption: String? = nil) {
            self.time = time; self.image = image; self.change = change; self.caption = caption
        }
    }
    /// A part of the sound that is not silent.
    public struct SoundPart: Codable, Equatable, Sendable {
        public var start: Double
        public var end: Double
        /// The part as 16 kHz mono WAV in the attachment folder, until it
        /// is written down (it is then removed).
        public var audio: String?
        /// The model's transcript; nil until written down.
        public var text: String?
        /// The system's sound classifier on the part (speech, music, …),
        /// likeliest first; nil where it could not run.
        public var sounds: [String]?
        public init(start: Double, end: Double, audio: String? = nil, text: String? = nil, sounds: [String]? = nil) {
            self.start = start; self.end = end; self.audio = audio; self.text = text; self.sounds = sounds
        }
    }
    /// The speech of several parts in fewer words, for a reply that has no
    /// room for all of it (VideoDigest.condensing).
    public struct Summary: Codable, Equatable, Sendable {
        public var start: Double
        public var end: Double
        public var text: String
        public init(start: Double, end: Double, text: String) { self.start = start; self.end = end; self.text = text }
    }
    public enum SoundSkip: String, Codable, Sendable {
        /// E4B on a launch without the wide address space (VideoSound).
        case memory
        /// The audio model could not start or read it.
        case failed
    }
    public enum Sound: String, Codable, Sendable {
        /// The video has no sound track.
        case none
        /// It has one, but nothing above silence.
        case silent
        /// Its parts are in `parts`.
        case parts
    }

    public var duration: Double
    public var scenes: [Scene]
    /// How many frames were looked at to pick the scenes.
    public var framesLooked: Int
    public var sound: Sound
    public var parts: [SoundPart]
    /// The end of the sound taken, in seconds: the whole video, or the
    /// first `SoundParts.limit` seconds of a longer one.
    public var soundTaken: Double
    /// Why the sound was not written down, when it was not; the reply and
    /// the attachment's note say so. Not a reason to fail the reply.
    public var soundSkipped: SoundSkip?
    public var summaries: [Summary]?

    public init(duration: Double, scenes: [Scene], framesLooked: Int, sound: Sound, parts: [SoundPart] = [],
                soundTaken: Double = 0, soundSkipped: SoundSkip? = nil, summaries: [Summary]? = nil) {
        self.duration = duration; self.scenes = scenes; self.framesLooked = framesLooked; self.sound = sound
        self.parts = parts; self.soundTaken = soundTaken; self.soundSkipped = soundSkipped; self.summaries = summaries
    }

    /// The scenes the model described; one it looked at and wrote nothing
    /// for has an empty caption.
    public var scenesSeen: Int { scenes.filter { !($0.caption ?? "").isEmpty }.count }
    public var partsHeard: Int { parts.filter { $0.text != nil }.count }
    /// Whether the sound still waits to be written down.
    public var soundPending: Bool { soundSkipped == nil && parts.contains { $0.text == nil } }
    public var scenesPending: Bool { scenes.contains { $0.caption == nil } }
    public var isComplete: Bool { !soundPending && !scenesPending }
    /// The audio files still kept.
    public var audioNames: [String] { parts.compactMap(\.audio) }
}

/// Picks a video's scenes from frames looked at evenly across it: the
/// first and the last, then the frames where the picture changes most (a
/// cut, a turn of the camera, something moving in), then the middle of the
/// longest stretch not yet covered, so a still video is still spread out.
public enum VideoScenePicker {
    /// How many scenes the model looks at: more for a longer video, never
    /// so many that describing them takes long on the phone.
    public static func sceneCount(duration: Double) -> Int {
        guard duration.isFinite, duration > 0 else { return 0 }
        switch duration {
        case ..<10.5: return 4
        case ..<30.5: return 6
        case ..<90.5: return 8
        case ..<180.5: return 10
        default: return maximumScenes
        }
    }
    public static let maximumScenes = 12
    /// How many frames are looked at to pick from: two a second, at most
    /// 60 (one every five seconds of a five-minute video).
    public static func frameCount(duration: Double) -> Int {
        guard duration.isFinite, duration > 0 else { return 0 }
        return min(60, max(sceneCount(duration: duration), Int((duration * 2).rounded(.up))))
    }
    /// Where the frames are looked at: a little in from each end, so a fade
    /// is not what the model sees, and evenly between.
    public static func frameTimes(duration: Double) -> [Double] {
        let count = frameCount(duration: duration)
        guard count > 0 else { return [] }
        let inset = min(0.5, duration * 0.05)
        guard count > 1 else { return [duration / 2] }
        let step = (duration - 2 * inset) / Double(count - 1)
        return (0..<count).map { inset + Double($0) * step }
    }
    /// How different two frames' small pictures are, 0 to 1.
    public static func difference(_ a: [Float], _ b: [Float]) -> Double {
        guard !a.isEmpty, a.count == b.count else { return 0 }
        var total: Float = 0
        for index in a.indices { total += abs(a[index] - b[index]) }
        return Double(total / Float(a.count))
    }
    /// The picked frames' indices, in time order. `features` are the
    /// frames' small pictures (values 0 to 1), one per frame time.
    public static func pick(features: [[Float]], count: Int) -> [Int] {
        let total = features.count
        guard count > 0, total > 0 else { return [] }
        guard total > count else { return Array(0..<total) }
        let changes = changes(features)
        var picked: Set<Int> = [0, total - 1]
        // Cuts: frames that change much more than the video usually does.
        let ordered = changes.indices.dropFirst().sorted { changes[$0] > changes[$1] }
        let usual = changes.dropFirst().sorted()[(total - 1) / 2]
        let apart = max(1, total / (count * 2))
        for index in ordered where picked.count < count {
            guard changes[index] >= max(0.08, usual * 2) else { break }
            if picked.allSatisfy({ abs($0 - index) >= apart }) { picked.insert(index) }
        }
        // Then the middle of the longest stretch between picked frames.
        while picked.count < count {
            let sorted = picked.sorted()
            var best = (gap: 0, at: -1)
            for (left, right) in zip(sorted, sorted.dropFirst()) where right - left > best.gap {
                best = (right - left, (left + right) / 2)
            }
            guard best.gap > 1, !picked.contains(best.at) else { break }
            picked.insert(best.at)
        }
        return picked.sorted()
    }
    /// Each frame's change from the one before (the first's is 0).
    public static func changes(_ features: [[Float]]) -> [Double] {
        features.indices.map { $0 == 0 ? 0 : difference(features[$0 - 1], features[$0]) }
    }
}

/// Splits a video's sound into the parts the model writes down: where it
/// is not silent, joined while short pauses separate them, and cut at the
/// quietest moment before `maximumPart` seconds (Gemma 4's audio is meant
/// for clips of up to about 30 seconds). Energies are the sound's RMS
/// level (0 to 1) every `frame` seconds.
public enum SoundParts {
    public static let frame = 0.05
    public static let maximumPart = 28.0
    /// The sound taken from a video: its first five minutes. Writing it
    /// down takes the phone about a tenth to a third of its length, and a
    /// reply has room for only so much of it (VideoDigest).
    public static let limit = 300.0
    /// Quieter than this throughout is silence (about -46 dBFS).
    public static let silence: Float = 0.005

    public struct Span: Equatable, Sendable {
        public var start: Double
        public var end: Double
        public init(start: Double, end: Double) { self.start = start; self.end = end }
        public var length: Double { end - start }
    }

    public static func split(_ energies: [Float]) -> [Span] {
        guard !energies.isEmpty else { return [] }
        let sorted = energies.sorted()
        let floor = sorted[sorted.count / 5], peak = sorted[min(sorted.count - 1, sorted.count * 95 / 100)]
        guard peak >= silence else { return [] }
        // Well above the quiet between words (a room's hum, a street), but
        // never so high that sound with no pauses, such as music, is lost.
        let threshold = max(silence, min(floor * 3, peak * 0.3))
        // Sounding stretches, as frame ranges.
        var stretches: [(Int, Int)] = []
        var begin: Int?
        for (index, energy) in energies.enumerated() {
            if energy >= threshold { if begin == nil { begin = index } }
            else if let start = begin { stretches.append((start, index)); begin = nil }
        }
        if let start = begin { stretches.append((start, energies.count)) }
        // A click is left out; each stretch is padded a little, so a word's
        // soft start and end stay in.
        let pad = Int(0.2 / frame)
        let padded = stretches.filter { Double($0.1 - $0.0) * frame >= 0.15 }
            .map { (max(0, $0.0 - pad), min(energies.count, $0.1 + pad)) }
        // Join while the pause is short and the part stays within the limit.
        let joinGap = Int(2.0 / frame), longest = Int(maximumPart / frame)
        var parts: [(Int, Int)] = []
        for stretch in padded {
            if let last = parts.last, stretch.0 - last.1 <= joinGap, stretch.1 - last.0 <= longest {
                parts[parts.count - 1].1 = stretch.1
            } else {
                parts.append(stretch)
            }
        }
        // Cut what is still too long at its quietest frame after 20 s, the
        // latest of equally quiet ones, so the parts stay few.
        var result: [Span] = []
        for part in parts {
            var start = part.0
            while part.1 - start > longest {
                let from = start + Int(20.0 / frame), to = start + longest
                let cut = (from..<to).reversed().min { energies[$0] < energies[$1] } ?? to
                result.append(Span(start: Double(start) * frame, end: Double(cut) * frame))
                start = cut
            }
            result.append(Span(start: Double(start) * frame, end: Double(part.1) * frame))
        }
        return result
    }
}
