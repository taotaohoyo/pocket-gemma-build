import Foundation

// Context management, phase 1 (the user's directive of 2026-11-06,
// 「コンテキスト管理・会話理解性能の強化」): what of a chat a question's input
// takes, measured closer to the tokens the model reads, keeping the newest
// exchange and the person's earlier words when older turns no longer fit.
// No model runs for it and nothing is stored: everything here is worked out
// again from the saved chat for each question. See plans/context-management.md.

/// An upper estimate of the tokens Gemma's tokenizer makes of a text: Gemma 4
/// E2B, E4B and 12B. Per character, by kind: a digit is a token of its own
/// (Gemma splits numbers into digits), a Latin word about one, a space that
/// is not before a Latin word one ("▁" alone), and Japanese, Chinese and
/// Korean less than one a character.
///
/// Calibrated against Gemma's SentencePiece vocabulary (262,144 pieces) on
/// 5,098 pieces of text of 100 to 2,000 characters (the Fielua reports, the
/// app's strings in its five languages, Swift and Python code, English
/// prose, numbers, Markdown tables, emoji, math): never below the real count
/// (lowest ratio 1.03, numbers), Japanese prose with Markdown 1.33 times the
/// real count, against 1.85 for the two-bytes-a-token rule it replaces for
/// Gemma, which counted digits at half their tokens (0.50). Checked against
/// the phone's E2B itself by the native probe context-e2b.
public enum GemmaTokens {
    /// The chat template's own tokens around a turn
    /// (`<start_of_turn>user\n` … `<end_of_turn>\n`).
    public static let perTurn = 6

    private enum Kind { case none, space, lower, upper, other }

    public static func estimate(_ text: String) -> Int {
        var total = 0.0, previous = Kind.none, spaces = 0
        for scalar in text.unicodeScalars {
            let value = scalar.value
            if value == 0x20 || value == 0x09 { spaces += 1; continue }
            let letter = (0x41...0x5A).contains(value) || (0x61...0x7A).contains(value)
            if spaces > 0 {
                // A space joins the Latin word after it ("▁word"); before a
                // digit, a kana or a mark it is a token alone.
                total += Double(spaces - 1) * 0.5 + (letter ? 0 : 1)
                spaces = 0
                previous = .space
            }
            if letter {
                let upper = value <= 0x5A
                if previous != .lower && previous != .upper { total += 1 }
                else if upper && previous == .lower { total += 0.8 }
                total += 0.12
                previous = upper ? .upper : .lower
                continue
            }
            previous = .other
            switch value {
            case 0x30...0x39: total += 1
            case 0x0A, 0x0D: total += 1
            case 0x00...0x7F: total += 0.9
            case 0x3040...0x309F: total += 0.6
            case 0x30A0...0x30FF, 0xFF66...0xFF9F: total += 0.6
            case 0x3400...0x9FFF, 0xF900...0xFAFF, 0x20000...0x2FFFF: total += 0.9
            case 0xAC00...0xD7AF, 0x1100...0x11FF, 0x3130...0x318F: total += 0.75
            case 0x3000...0x303F, 0xFF00...0xFF65: total += 1.1
            default: total += scalar.properties.isAlphabetic ? 0.6 : 2
            }
        }
        if spaces > 0 { total += Double(spaces - 1) * 0.5 + 1 }
        return Int((total * 1.04).rounded(.up))
    }
}

/// How a model's input is measured, in the input budget's units
/// (GenerationSettings.inputByteBudget: two for each token).
public enum ContextMeasure: Sendable, Equatable {
    /// A text's UTF-8 bytes, as before 1.1.0 (256): the models with
    /// tokenizers of their own (Qwen, Phi, LFM), and the short reads of a
    /// reply written on the CPU in the background or for the Apple Watch,
    /// which keep their earlier size.
    case utf8
    /// Gemma's tokens (GemmaTokens), two units each, and the turn's own.
    case gemma

    public static func of(_ model: ModelSpec) -> ContextMeasure { model.family == "Gemma" ? .gemma : .utf8 }

    /// A text's units, without the turn around it.
    public func cost(_ text: String) -> Int {
        switch self {
        case .utf8: return text.utf8.count
        case .gemma: return 2 * GemmaTokens.estimate(text)
        }
    }

    /// The tokens a text takes, for comparing with a conversation's real count.
    public func tokens(_ text: String) -> Int {
        switch self {
        case .utf8: return text.utf8.count / 2
        case .gemma: return GemmaTokens.estimate(text)
        }
    }

    /// A message's units: its text, its turn, and its attachments, whose
    /// cost is already in these units (ChatAttachment.contextByteCost).
    public func cost(_ message: ChatMessage, visualTokenBudget: Int, inputByteBudget: Int) -> Int {
        let media = message.media.reduce(0) {
            $0 + $1.contextByteCost(visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget)
        }
        switch self {
        case .utf8: return message.text.utf8.count + media
        case .gemma: return 2 * (GemmaTokens.estimate(message.text) + GemmaTokens.perTurn) + media
        }
    }
}

/// The earlier turns a question's input takes (1.1.0 (256)). As
/// HistoryBuilder.recentPairs: the newest complete exchanges, whole, while
/// they fit, never an interrupted or failed reply. Besides:
/// - measured as the model reads them (ContextMeasure), so a Japanese chat
///   keeps more of itself and a chat of numbers no longer overfills;
/// - the newest exchange always stays: one too long to fit whole (a long
///   list, a reply continued past the context) is kept as its question and
///   the reply's lines that bear on the new question, its opening and its
///   end, word for word, "…" marking what is left out (HistoryExcerpt);
/// - the person's own messages of the exchanges left out are listed
///   (`earlier`), for the note that keeps their words (EarlierNote).
public struct ContextPlan: Equatable, Sendable {
    /// The turns to give, oldest first.
    public var turns: [ChatMessage]
    /// Whether the newest exchange is an excerpt.
    public var excerpted: Bool
    /// The person's messages whose exchanges were left out, oldest first.
    public var earlier: [ChatMessage]
    /// The chat's complete exchanges, and the units the turns take.
    public var totalPairs: Int
    public var cost: Int

    public var keptPairs: Int { turns.count / 2 }
}

public enum ContextPlanner {
    /// An exchange whose excerpt would have less room than this is left out
    /// as before.
    public static let minimumExcerpt = 240

    /// The complete exchanges of `messages`, oldest first, as
    /// HistoryBuilder reads them.
    static func pairs(_ messages: [ChatMessage]) -> [[ChatMessage]] {
        var pairs: [[ChatMessage]] = [], pending: ChatMessage?
        for message in messages {
            if message.role == .user {
                pending = message
            } else {
                if let user = pending, message.state == .complete, !message.text.isEmpty { pairs.append([user, message]) }
                pending = nil
            }
        }
        return pairs
    }

    /// `budget`: the room for the turns, in the measure's units; `question`
    /// picks the lines an excerpt keeps.
    public static func plan(_ messages: [ChatMessage], budget: Int, measure: ContextMeasure, question: String,
                            visualTokenBudget: Int = 280,
                            inputByteBudget: Int = GenerationSettings().inputByteBudget) -> ContextPlan {
        let pairs = pairs(messages)
        func cost(_ message: ChatMessage) -> Int {
            measure.cost(message, visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget)
        }
        var turns: [ChatMessage] = [], used = 0, excerpted = false, first = pairs.count
        for (index, pair) in pairs.enumerated().reversed() {
            let count = cost(pair[0]) + cost(pair[1])
            if used + count <= budget {
                turns.insert(contentsOf: pair, at: 0)
                used += count
                first = index
                continue
            }
            // The newest exchange, too long to give whole.
            if turns.isEmpty, let excerpt = HistoryExcerpt.pair(pair, question: question, budget: budget, measure: measure,
                                                               visualTokenBudget: visualTokenBudget,
                                                               inputByteBudget: inputByteBudget) {
                turns = excerpt
                used = cost(excerpt[0]) + cost(excerpt[1])
                excerpted = true
                first = index
            }
            break
        }
        let earlier = pairs.prefix(first).map { $0[0] }
        return ContextPlan(turns: turns, excerpted: excerpted, earlier: earlier, totalPairs: pairs.count, cost: used)
    }

    /// `turns` within `budget`, the oldest exchanges left out first; the
    /// newest stays whatever its size. What it leaves out joins `earlier`.
    public static func trimmed(_ turns: [ChatMessage], earlier: [ChatMessage], toBudget budget: Int, measure: ContextMeasure,
                               visualTokenBudget: Int = 280,
                               inputByteBudget: Int = GenerationSettings().inputByteBudget) -> (turns: [ChatMessage], earlier: [ChatMessage]) {
        var kept = turns, dropped = earlier
        func cost(_ list: [ChatMessage]) -> Int {
            list.reduce(0) { $0 + measure.cost($1, visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget) }
        }
        while kept.count > 2, cost(kept) > budget {
            if kept[0].role == .user { dropped.append(kept[0]) }
            kept.removeFirst(2)
        }
        return (kept, dropped)
    }
}

/// The newest exchange shortened to fit, word for word: its question (cut
/// at a sentence only when very long), and its reply's opening, its end and
/// the lines between that share the new question's words, in order, "…"
/// marking each gap. Never a summary, and never a cut inside a number or a
/// word. The excerpt keeps the messages' ids, so the reply's own record
/// (its sources, its state) stays its own.
public enum HistoryExcerpt {
    public static let gap = "…"

    static func pair(_ pair: [ChatMessage], question: String, budget: Int, measure: ContextMeasure,
                     visualTokenBudget: Int, inputByteBudget: Int) -> [ChatMessage]? {
        guard pair.count == 2 else { return nil }
        var asked = pair[0], reply = pair[1]
        func cost(_ message: ChatMessage) -> Int {
            measure.cost(message, visualTokenBudget: visualTokenBudget, inputByteBudget: inputByteBudget)
        }
        // A long question keeps its first quarter of the room.
        if cost(asked) > budget / 4 {
            let text = shortened(asked.text, question: question, budget: budget / 4 - (cost(asked) - measure.cost(asked.text)),
                                 measure: measure)
            guard !text.isEmpty else { return nil }
            asked.text = text
        }
        let room = budget - cost(asked) - (cost(reply) - measure.cost(reply.text))
        guard room >= ContextPlanner.minimumExcerpt else { return nil }
        let text = shortened(reply.text, question: question, budget: room, measure: measure)
        guard !text.isEmpty else { return nil }
        reply.text = text
        return [asked, reply]
    }

    /// `text` within `budget` units: whole when it fits; otherwise its
    /// opening, its end and the lines that share the question's words.
    public static func shortened(_ text: String, question: String, budget: Int, measure: ContextMeasure) -> String {
        guard budget > 0 else { return "" }
        if measure.cost(text) <= budget { return text }
        let pieces = SmartMemoryNote.pieces(text)
        guard !pieces.isEmpty else { return "" }
        let costs = pieces.map(measure.cost)
        let gapCost = measure.cost("\n" + gap + "\n")
        var chosen = Set<Int>(), used = 0
        func take(_ index: Int) -> Bool {
            guard pieces.indices.contains(index), !chosen.contains(index) else { return false }
            let cost = costs[index] + gapCost
            guard used + cost <= budget else { return false }
            chosen.insert(index)
            used += cost
            return true
        }
        // The opening says what the reply is about; the end is where it
        // stopped, which a 「続きは？」 needs. A third of the room each at most.
        var head = 0
        while head < pieces.count, used + costs[head] + gapCost <= budget / 3 { _ = take(head); head += 1 }
        var tail = pieces.count - 1, tailUsed = 0
        while tail > head, tailUsed + costs[tail] + gapCost <= budget / 3 {
            if take(tail) { tailUsed += costs[tail] + gapCost }
            tail -= 1
        }
        // Then the lines with the most of the question's words, and the line
        // after each (the code under the line that names it).
        let query = SmartMemoryTerms.query(question)
        if !query.isEmpty {
            let scores = pieces.map { piece -> Int in
                var shared = Set<UInt64>()
                SmartMemoryTerms.forEachTerm(piece, limit: 4_000) { if query.contains($0) { shared.insert($0) } }
                return shared.count
            }
            let ranked = scores.indices.filter { scores[$0] > 0 && !chosen.contains($0) }
                .sorted { scores[$0] != scores[$1] ? scores[$0] > scores[$1] : $0 < $1 }
            for index in ranked where take(index) { _ = take(index + 1) }
        }
        // What room is left goes to the lines after the opening, in order.
        var next = head
        while next < pieces.count, used < budget {
            if !chosen.contains(next), !take(next) { break }
            next += 1
        }
        guard !chosen.isEmpty else {
            // Not even the first line fits: its words up to the room, cut
            // between words.
            return SmartMemoryNote.cutAtBoundary(pieces[0], byteLimit: max(0, budget / 2)) + " " + gap
        }
        var result = "", previous: Int?
        for index in chosen.sorted() {
            if let previous { result += index == previous + 1 ? "\n" : "\n" + gap + "\n" } else if index > 0 { result += gap + "\n" }
            result += pieces[index]
            previous = index
        }
        if let previous, previous < pieces.count - 1 { result += "\n" + gap }
        return result
    }

    /// Whether `excerpt` is `full` shortened as above: each of its lines,
    /// "…" aside, found in `full` in order. A live conversation that holds
    /// the whole reply goes on with it (ConversationContext.canReuse).
    public static func isExcerpt(_ excerpt: String, of full: String) -> Bool {
        guard excerpt != full else { return true }
        guard excerpt.contains(gap) else { return false }
        var position = full.startIndex
        for line in excerpt.components(separatedBy: "\n") {
            var piece = line.trimmingCharacters(in: .whitespaces)
            if piece.hasSuffix(" " + gap) { piece = String(piece.dropLast(gap.count + 1)) }
            guard !piece.isEmpty, piece != gap else { continue }
            guard let found = full.range(of: piece, range: position..<full.endIndex) else { return false }
            position = found.upperBound
        }
        return true
    }
}

/// The person's own earlier messages in this chat whose exchanges no longer
/// fit (ContextPlan.earlier), quoted before the question when the
/// conversation is set up again: the conditions and facts a long chat
/// started with (a budget, a date, a name) stay in view. Their words as
/// written, a line each (a long one cut at a sentence or between words,
/// never inside a number), the chat's first message and its latest ones
/// first when not all fit, then shown oldest first. Never the replies,
/// never a summary. Between lines tagged with a random code, as Smart
/// Memory's record is, and in English, naming the language to reply in.
public struct EarlierNote: Equatable, Sendable {
    public let text: String
    public let tag: String
    public let count: Int

    /// At most this much of a question's input (in its units), and this much
    /// of one message (UTF-8 bytes of its words).
    public static func share(inputByteBudget: Int) -> Int { min(900, max(0, inputByteBudget / 8)) }
    public static let messageBytes = 200
    /// Less room than this and the note is left out.
    public static let minimumCost = 160

    public static func opening(tag: String) -> String {
        "\nEarlier messages from the person in this conversation, oldest first; the replies to them no longer fit here. "
            + "Use them only where they bear on the question.\n[Earlier\(tag) begins]\n"
    }
    public static func closing(tag: String, language: String?) -> String {
        "[Earlier\(tag) ends]\n(Reply in \(language.map { "\($0), the language of the question below" } ?? "the language of the question below").)\n"
    }

    /// The note for `earlier` within `budget` units; nil when none is worth
    /// quoting or nothing fits.
    public static func build(_ earlier: [ChatMessage], question: String, budget: Int, measure: ContextMeasure,
                             tag: String = SmartMemoryNote.randomTag()) -> EarlierNote? {
        let language = VideoDigest.replyLanguage(of: question)
        let frame = measure.cost(opening(tag: tag) + closing(tag: tag, language: language))
        guard budget - frame >= minimumCost / 2 else { return nil }
        // A message with words worth keeping: not a thanks or a 「続けて」.
        let lines: [(index: Int, line: String)] = earlier.enumerated().compactMap { index, message in
            let words = message.shownText.replacingOccurrences(of: ModelAttachmentPolicy.earlierAttachmentsNote, with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard words.count >= 6, SmartMemoryTerms.query(words).count >= 2 else { return nil }
            let line = SmartMemoryNote.oneLine(cut(words, bytes: messageBytes))
            return (index, "- " + line + "\n")
        }
        guard !lines.isEmpty else { return nil }
        // The first message, then the latest, while they fit.
        var order = [lines[0]] + Array(lines.dropFirst().reversed())
        var chosen: [(index: Int, line: String)] = [], used = frame
        for item in order {
            let cost = measure.cost(item.line)
            guard used + cost <= budget else { continue }
            chosen.append(item)
            used += cost
        }
        order = chosen.sorted { $0.index < $1.index }
        guard !order.isEmpty else { return nil }
        let text = opening(tag: tag) + order.map(\.line).joined() + closing(tag: tag, language: language)
        return EarlierNote(text: text, tag: tag, count: order.count)
    }

    /// `text` within `bytes`, cut after a sentence when one ends in the last
    /// half, else between words, with "…".
    static func cut(_ text: String, bytes: Int) -> String {
        guard text.utf8.count > bytes else { return text }
        let head = SmartMemoryNote.cutAtBoundary(text, byteLimit: bytes - 4)
        if let end = head.lastIndex(where: { "。！？!?".contains($0) }), head[..<end].utf8.count >= bytes / 2 {
            return String(head[...end]) + " …"
        }
        return head + " …"
    }
}

/// How a conversation was set up again for a question (1.1.0 (256)), for
/// the developer diagnostics only: counts, never words.
public struct ContextFill: Equatable, Sendable {
    /// Exchanges given, and the chat's exchanges the history held.
    public var turns: Int
    public var pairs: Int
    /// The estimated tokens of the input (turns and the turn), and the real
    /// count of the conversation once the reply is written.
    public var estimate: Int
    public var tokens: Int?
    /// The person's earlier messages quoted (EarlierNote).
    public var earlier: Int
    /// Set up again because the live one had no room left, or from the
    /// turns a released conversation held.
    public var filled: Bool
    public var held: Bool
    /// Times the runtime found the input too long and it was set up again
    /// with fewer turns (ContextOverflow).
    public var overflowRetries = 0

    public init(turns: Int, pairs: Int, estimate: Int, earlier: Int, filled: Bool, held: Bool) {
        self.turns = turns
        self.pairs = pairs
        self.estimate = estimate
        self.earlier = earlier
        self.filled = filled
        self.held = held
    }

    public var summary: String {
        var parts = ["会話を作り直した" + (filled ? "（満杯のため）" : held ? "（保持していた会話）" : ""),
                     "履歴 \(turns)組/\(pairs)組", "入力の見積り \(estimate)トークン"]
        if let tokens { parts.append("実測 \(tokens)トークン（返事込み）") }
        if earlier > 0 { parts.append("以前の発言 \(earlier)件") }
        if overflowRetries > 0 { parts.append("入りきらず減らした \(overflowRetries)回") }
        return parts.joined(separator: " · ")
    }
}

/// The runtime's refusal of an input longer than its context
/// (LiteRT-LM: "Input token ids are too long. Exceeding the maximum number
/// of tokens allowed: N >= M").
public enum ContextOverflow {
    public static func matches(_ error: Error) -> Bool {
        let text = (String(describing: error) + " " + error.localizedDescription).lowercased()
        return text.contains("maximum number of tokens") || (text.contains("too long") && text.contains("token"))
    }
}
