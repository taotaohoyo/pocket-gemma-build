import Foundation
import CryptoKit

/// Signing in to Tavily from Fielua (1.1.0 (207), 2026-10-27): the person
/// signs up or signs in on Tavily's own page, shown in iOS's web sign-in
/// sheet, comes back to the app on their own, and searches with no key to
/// copy. Fielua never sees the password.
///
/// It is the sign-in of Tavily's remote MCP server (mcp.tavily.com), the one
/// Tavily's own command-line tool uses (tavily-cli, oauth.py): OAuth 2.1, the
/// app registering itself as a public client (RFC 7591, so there is no
/// secret to hide in this public repository), PKCE (S256) and refresh
/// tokens. Tavily's sign-in page is Auth0 at auth.tavily.com, with email,
/// Google, GitHub, LinkedIn and Microsoft, and its own 「Sign up」.
/// mcp.tavily.com passes no hint of the app's on to it (prompt=create and
/// screen_hint=signup, run 40444619260), so 新規登録 opens that page itself
/// at its sign-up (`signUpPage(redirect:)`, 1.1.0 (223)).
///
/// The access token it gives is not a Tavily API key: api.tavily.com refuses
/// it (tavily-cli, mcp_client.py), so these searches go through the MCP
/// server's tavily_search tool, which answers with the search API's own
/// results. Tavily picks which of the account's keys pays: one named
/// mcp_auth_default, else the account's default key.
public enum TavilyAccount {
    public static let issuer = "https://mcp.tavily.com/"
    /// The MCP endpoint: what the tokens are for (RFC 8707 `resource`), and
    /// where searches go.
    public static let resource = "https://mcp.tavily.com/mcp"
    public static let endpoint = URL(string: resource)!
    /// As the server's metadata (/.well-known/oauth-authorization-server)
    /// lists them.
    public static let registrationEndpoint = URL(string: "https://mcp.tavily.com/register")!
    public static let authorizationEndpoint = URL(string: "https://mcp.tavily.com/authorize")!
    public static let tokenEndpoint = URL(string: "https://mcp.tavily.com/token")!
    public static let revocationEndpoint = URL(string: "https://mcp.tavily.com/revoke")!
    /// Where mcp.tavily.com/authorize sends the browser: Tavily's sign-in
    /// page (Auth0).
    public static let signInPage = URL(string: "https://auth.tavily.com/authorize")!
    public static let scope = "openid offline_access"
    /// Where Tavily sends the person back. The sign-in sheet catches the
    /// scheme itself (ASWebAuthenticationSession), so the app registers no
    /// URL scheme with iOS; PKCE keeps the code useless to anyone else.
    public static let callbackScheme = "fielua"
    public static let redirectURI = "fielua://oauth/tavily"
    /// Tavily's dashboard, for an account that can't search yet.
    public static let dashboard = URL(string: "https://app.tavily.com/")!
    /// The words of the one search made when signing in, to see that the
    /// account can search before saying it's connected. Nothing from the
    /// person's chats.
    public static let checkQuery = "Tavily"

    /// The app's registration: a public client (no secret), for the
    /// authorization code with PKCE and refresh tokens.
    public static func registrationRequest() -> URLRequest {
        var request = URLRequest(url: registrationEndpoint, timeoutInterval: WebSearch.timeout)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = ["client_name": "Fielua", "redirect_uris": [redirectURI],
                                   "grant_types": ["authorization_code", "refresh_token"], "response_types": ["code"],
                                   "token_endpoint_auth_method": "none", "scope": scope, "application_type": "native"]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [.sortedKeys])
        return request
    }

    /// The client id Tavily gave this install. A registration that wants a
    /// secret is refused: the app has nowhere to keep one.
    public static func clientID(fromRegistration data: Data) throws -> String {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let id = root["client_id"] as? String, !id.isEmpty,
              (root["token_endpoint_auth_method"] as? String ?? "none") == "none" else { throw TavilySignInError.failed }
        return id
    }

    /// One sign-in: the page to open, and what its answer must match.
    public struct SignIn: Sendable, Equatable {
        public var url: URL
        public var state: String
        public var verifier: String
        public var clientID: String
    }

    public static func signIn(clientID: String) -> SignIn {
        let state = randomToken(bytes: 32)
        let verifier = randomToken(bytes: 64)
        var components = URLComponents(url: authorizationEndpoint, resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "redirect_uri", value: redirectURI),
            URLQueryItem(name: "scope", value: scope),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "code_challenge", value: challenge(for: verifier)),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "resource", value: resource)
        ]
        return SignIn(url: components.url!, state: state, verifier: verifier, clientID: clientID)
    }

    /// Tavily's sign-up page for a sign-in: the address mcp.tavily.com
    /// answered /authorize with (a redirect, not followed), when it is
    /// Tavily's sign-in page with mcp.tavily.com's own state, asked to open
    /// at its sign-up with Auth0's `screen_hint=signup`. The probe saw
    /// 「Create Your Account」 there, with 「Log in」 for an existing
    /// account, and the sign-in still found on the way back without any
    /// cookie (run 40705304587). Nil for any other answer.
    public static func signUpPage(redirect response: HTTPURLResponse) -> URL? {
        guard (300..<400).contains(response.statusCode),
              let location = response.value(forHTTPHeaderField: "Location"),
              let url = URL(string: location),
              var components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              components.scheme == "https", components.host == signInPage.host, components.port == nil,
              components.user == nil, components.password == nil, components.path == signInPage.path,
              let items = components.queryItems, items.contains(where: { $0.name == "state" && $0.value?.isEmpty == false }),
              !items.contains(where: { $0.name == "screen_hint" }),
              let query = components.percentEncodedQuery
        else { return nil }
        // Added as text, so mcp.tavily.com's own parameters stay exactly as sent.
        components.percentEncodedQuery = query + "&screen_hint=signup"
        return components.url
    }

    /// The code in Tavily's answer, once the answer is the one this sign-in
    /// asked for: our redirect, our state, and Tavily as its issuer when it
    /// names one (RFC 9207; the server says it does).
    public static func code(from callback: URL, for signIn: SignIn) throws -> String {
        guard callback.scheme == callbackScheme,
              let components = URLComponents(url: callback, resolvingAgainstBaseURL: false),
              "\(callback.scheme ?? ""):\(components.percentEncodedHost.map { "//" + $0 } ?? "")\(components.path)" == redirectURI
        else { throw TavilySignInError.failed }
        let items = Dictionary((components.queryItems ?? []).map { ($0.name, $0.value ?? "") }, uniquingKeysWith: { first, _ in first })
        guard items["state"] == signIn.state else { throw TavilySignInError.failed }
        if let iss = items["iss"], iss != issuer { throw TavilySignInError.failed }
        if let error = items["error"] {
            throw error == "access_denied" ? TavilySignInError.denied : TavilySignInError.failed
        }
        guard let code = items["code"], !code.isEmpty else { throw TavilySignInError.failed }
        return code
    }

    public static func tokenRequest(code: String, for signIn: SignIn) -> URLRequest {
        form(tokenEndpoint, ["grant_type": "authorization_code", "code": code, "redirect_uri": redirectURI,
                             "code_verifier": signIn.verifier, "client_id": signIn.clientID, "resource": resource])
    }

    public static func refreshRequest(refreshToken: String, clientID: String) -> URLRequest {
        form(tokenEndpoint, ["grant_type": "refresh_token", "refresh_token": refreshToken, "client_id": clientID,
                             "resource": resource])
    }

    /// Tokens from the token endpoint. A refresh that brings no new refresh
    /// token keeps the old one. The access token counts as expired a minute
    /// early, so a search doesn't start with one about to lapse.
    public static func tokens(from data: Data, now: Date, keeping refreshToken: String? = nil) throws -> Tokens {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let access = root["access_token"] as? String, !access.isEmpty else { throw TavilySignInError.failed }
        let lifetime = (root["expires_in"] as? NSNumber)?.doubleValue ?? 3600
        return Tokens(access: access, refresh: (root["refresh_token"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? refreshToken,
                      expiresAt: now.addingTimeInterval(max(60, lifetime) - 60))
    }

    public struct Tokens: Equatable, Sendable {
        public var access: String
        public var refresh: String?
        public var expiresAt: Date
    }

    /// Revocation of a token at Tavily when the person disconnects. Tavily's
    /// server asks even a public client for a client_secret field, so it
    /// goes empty, as Tavily's CLI sends it.
    public static func revokeRequest(token: String, hint: String, clientID: String) -> URLRequest {
        form(revocationEndpoint, ["token": token, "token_type_hint": hint, "client_id": clientID, "client_secret": ""])
    }

    // MARK: The MCP endpoint

    /// A JSON-RPC message to the MCP endpoint, with the access token and,
    /// after `initialize`, the session the server gave.
    public static func mcpRequest(_ body: [String: Any], token: String, session: String?) -> URLRequest {
        var request = URLRequest(url: endpoint, timeoutInterval: WebSearch.timeout)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json, text/event-stream", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        if let session { request.setValue(session, forHTTPHeaderField: "Mcp-Session-Id") }
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [.sortedKeys])
        return request
    }

    public static let protocolVersion = "2025-06-18"
    public static var initializeMessage: [String: Any] {
        ["jsonrpc": "2.0", "id": 1, "method": "initialize",
         "params": ["protocolVersion": protocolVersion, "capabilities": [String: Any](),
                    "clientInfo": ["name": "Fielua", "version": "1.1.0"]]]
    }
    public static var initializedMessage: [String: Any] { ["jsonrpc": "2.0", "method": "notifications/initialized"] }
    /// A tavily_search call. Its arguments are the search's own (the
    /// search API's names; the tool takes query, max_results,
    /// search_depth, topic, time_range, start_date, end_date, exact_match,
    /// include_raw_content, include_images, country, include_domains and
    /// exclude_domains, but not include_answer), so a search asks for the
    /// same thing signed in or with a key.
    public static func searchMessage(arguments: [String: Any]) -> [String: Any] {
        ["jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": ["name": "tavily_search", "arguments": arguments]]
    }

    /// The sign-in's check: one basic search (one credit) for one page.
    public static var checkArguments: [String: Any] {
        ["query": checkQuery, "max_results": 1, "search_depth": "basic", "include_raw_content": false, "include_images": false]
    }

    /// The JSON-RPC answer in an MCP response: a plain JSON body, or the
    /// first message of an event stream (`data:` lines).
    public static func message(from data: Data, contentType: String?) -> [String: Any]? {
        if contentType?.lowercased().contains("text/event-stream") == true {
            let text = String(decoding: data, as: UTF8.self).replacingOccurrences(of: "\r\n", with: "\n")
            for event in text.components(separatedBy: "\n\n") {
                let lines = event.split(separator: "\n", omittingEmptySubsequences: false)
                    .filter { $0.hasPrefix("data:") }
                    .map { $0.dropFirst(5).drop(while: { $0 == " " }) }
                guard !lines.isEmpty else { continue }
                let payload = lines.joined(separator: "\n")
                if let message = try? JSONSerialization.jsonObject(with: Data(payload.utf8)) as? [String: Any],
                   message["result"] != nil || message["error"] != nil { return message }
            }
            return nil
        }
        return try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    }

    /// What tavily_search answered: the search API's own answer
    /// (structuredContent, or the same JSON as text), for TavilySearch to
    /// read like any search's; or why there is none. Tavily's limits come
    /// back as a payload with a code instead of results, without isError
    /// (run 40444619260).
    public static func searchAnswer(fromCall message: [String: Any]) throws -> [String: Any] {
        if message["error"] != nil { throw WebSearchFailure.unavailable }
        guard let result = message["result"] as? [String: Any] else { throw WebSearchFailure.unavailable }
        var payload = result["structuredContent"] as? [String: Any]
        var text = ""
        if payload == nil, let content = result["content"] as? [[String: Any]] {
            text = content.compactMap { $0["text"] as? String }.joined(separator: "\n")
            payload = try? JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any]
        }
        if let payload {
            if payload["results"] is [Any] { return payload }
            throw failure(fromPayload: payload)
        }
        throw failure(fromText: text)
    }

    static func failure(fromPayload payload: [String: Any]) -> WebSearchFailure {
        if let status = (payload["status"] as? NSNumber)?.intValue ?? (payload["status_code"] as? NSNumber)?.intValue {
            return WebSearchFailure(status: status)
        }
        var words = [payload["code"], payload["error"], payload["message"]].compactMap { $0 as? String }
        if let detail = payload["detail"] as? [String: Any] { words += [detail["error"]].compactMap { $0 as? String } }
        if let detail = payload["detail"] as? String { words.append(detail) }
        return failure(fromText: words.joined(separator: " "))
    }

    static func failure(fromText text: String) -> WebSearchFailure {
        let words = text.lowercased()
        if words.contains("rate limit") || words.contains("rate_limit") || words.contains("too many") { return .rateLimited }
        if ["usage limit", "_cap", "cap_", "monthly", "quota", "credit", "plan limit", "exceed"].contains(where: words.contains) {
            return .quota
        }
        return .unavailable
    }

    // MARK: Helpers

    static func form(_ url: URL, _ fields: [String: String]) -> URLRequest {
        var request = URLRequest(url: url, timeoutInterval: WebSearch.timeout)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        request.httpBody = Data(fields.sorted { $0.key < $1.key }
            .map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: allowed) ?? "")" }
            .joined(separator: "&").utf8)
        return request
    }

    /// The PKCE challenge: base64url SHA-256 of the verifier, no padding.
    public static func challenge(for verifier: String) -> String {
        base64URL(Data(SHA256.hash(data: Data(verifier.utf8))))
    }

    static func randomToken(bytes count: Int) -> String {
        var generator = SystemRandomNumberGenerator()
        return base64URL(Data((0..<count).map { _ in UInt8.random(in: 0...255, using: &generator) }))
    }

    static func base64URL(_ data: Data) -> String {
        data.base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}

/// What the keychain keeps for the person's Tavily sign-in: this install's
/// registration and its tokens. Never the password, which only Tavily's page
/// sees.
public struct TavilyAccountRecord: Codable, Equatable, Sendable {
    public var clientID: String
    public var accessToken: String?
    public var refreshToken: String?
    public var expiresAt: Date?
    /// Tavily refused to renew the sign-in: the person signs in again.
    public var needsSignIn: Bool

    public init(clientID: String, accessToken: String? = nil, refreshToken: String? = nil, expiresAt: Date? = nil,
                needsSignIn: Bool = false) {
        self.clientID = clientID; self.accessToken = accessToken; self.refreshToken = refreshToken
        self.expiresAt = expiresAt; self.needsSignIn = needsSignIn
    }

    public enum Status: Equatable, Sendable { case signedOut, connected, needsSignIn }

    public var status: Status {
        if needsSignIn { return .needsSignIn }
        return accessToken == nil ? .signedOut : .connected
    }
}

/// Where the record lives (the keychain in the app, memory in tests).
public protocol TavilyAccountStore: Sendable {
    func load() -> TavilyAccountRecord?
    @discardableResult func save(_ record: TavilyAccountRecord) -> Bool
    func delete()
}

/// Why signing in didn't connect.
public enum TavilySignInError: Error, Equatable, Sendable {
    /// The person closed Tavily's page: back to where they were, no message.
    case cancelled
    case offline
    /// The person declined on Tavily's page.
    case denied
    /// Signed in, but a search with the account didn't work, so the app
    /// doesn't call it connected.
    case cannotSearch
    case failed
    /// The keychain wouldn't keep the sign-in.
    case notSaved

    public init(_ error: Error) {
        if let error = error as? TavilySignInError { self = error; return }
        if error is CancellationError { self = .cancelled; return }
        switch WebSearchFailure(error) {
        case nil: self = .cancelled
        case .offline?: self = .offline
        default: self = .failed
        }
    }

    public var message: String? {
        switch self {
        case .cancelled: return nil
        case .offline: return String(localized: "インターネットに接続できません。接続を確かめて、もう一度お試しください。")
        case .denied: return String(localized: "Tavilyの画面で接続が許可されませんでした。")
        case .cannotSearch: return String(localized: "ログインはできましたが、このアカウントではまだ検索できません。Tavilyのサイトでアカウントを確かめてから、もう一度ログインしてください。")
        case .failed: return String(localized: "Tavilyに接続できませんでした。少し待ってから、もう一度お試しください。")
        case .notSaved: return String(localized: "ログイン情報を保存できませんでした。もう一度お試しください。")
        }
    }
}

/// The signed-in searches and the sign-in itself, one at a time, so two
/// searches never renew the sign-in at once.
public actor TavilyAccountSession {
    public typealias Transport = @Sendable (URLRequest) async throws -> (Data, HTTPURLResponse)

    private let store: TavilyAccountStore
    private let transport: Transport
    /// The same requests, with a redirect as the answer instead of followed:
    /// for where 新規登録 opens. Without it, it opens the sign-in page.
    private let withoutRedirects: Transport?
    private let now: @Sendable () -> Date
    /// The MCP session the server opened for the current access token.
    private var mcpSession: (token: String, id: String)?

    public init(store: TavilyAccountStore, transport: @escaping Transport, withoutRedirects: Transport? = nil,
                now: @escaping @Sendable () -> Date = Date.init) {
        self.store = store
        self.transport = transport
        self.withoutRedirects = withoutRedirects
        self.now = now
    }

    /// Before Tavily's page opens: the app's registration (once per
    /// install, kept while signed out) and this sign-in's state and PKCE.
    /// 新規登録 opens the same sign-in at Tavily's sign-up page.
    public func beginSignIn(signUp: Bool = false) async throws -> TavilyAccount.SignIn {
        var signIn = try await registeredSignIn()
        if signUp { signIn.url = try await signUpPage(for: signIn.url) }
        return signIn
    }

    private func registeredSignIn() async throws -> TavilyAccount.SignIn {
        if let record = store.load() { return TavilyAccount.signIn(clientID: record.clientID) }
        let (data, response) = try await send(TavilyAccount.registrationRequest(), failure: signInFailure)
        guard (200..<300).contains(response.statusCode) else { throw TavilySignInError.failed }
        let clientID = try TavilyAccount.clientID(fromRegistration: data)
        guard store.save(TavilyAccountRecord(clientID: clientID)) else { throw TavilySignInError.notSaved }
        return TavilyAccount.signIn(clientID: clientID)
    }

    /// The sign-in's page asked to open at sign-up: mcp.tavily.com is asked
    /// where the sign-in goes, as the sheet would be sent. It keeps the
    /// sign-in on its side, so the sheet opening that page instead comes
    /// back as from ログイン. Offline says so; any other surprise opens the
    /// sign-in page as before, whose 「Sign up」 still leads there.
    private func signUpPage(for authorize: URL) async throws -> URL {
        guard let withoutRedirects else { return authorize }
        do {
            let (_, response) = try await withoutRedirects(URLRequest(url: authorize, timeoutInterval: WebSearch.timeout))
            return TavilyAccount.signUpPage(redirect: response) ?? authorize
        } catch {
            let failure = TavilySignInError(error)
            if failure == .offline || failure == .cancelled { throw failure }
            return authorize
        }
    }

    public enum Connected: Equatable, Sendable {
        case ready
        /// Connected, but the account's searches are used up or paused for now.
        case limited(WebSearchFailure)
    }

    /// After Tavily's page sends the person back: the code becomes tokens,
    /// and one search shows the account can search before the app keeps
    /// it as connected. A sign-in that can't search is revoked and dropped.
    public func finishSignIn(callback: URL, signIn: TavilyAccount.SignIn) async throws -> Connected {
        let code = try TavilyAccount.code(from: callback, for: signIn)
        let (data, response) = try await send(TavilyAccount.tokenRequest(code: code, for: signIn), failure: signInFailure)
        guard response.statusCode == 200 else { throw TavilySignInError.failed }
        let tokens = try TavilyAccount.tokens(from: data, now: now())
        var record = TavilyAccountRecord(clientID: signIn.clientID, accessToken: tokens.access, refreshToken: tokens.refresh,
                                         expiresAt: tokens.expiresAt)
        mcpSession = nil
        var outcome = Connected.ready
        do {
            _ = try await call(TavilyAccount.searchMessage(arguments: TavilyAccount.checkArguments), record: &record)
        } catch let failure as WebSearchFailure {
            switch failure {
            case .quota, .rateLimited: outcome = .limited(failure)
            case .offline: throw TavilySignInError.offline
            default:
                await revoke(record)
                store.save(TavilyAccountRecord(clientID: signIn.clientID))
                throw TavilySignInError.cannotSearch
            }
        }
        guard store.save(record) else { await revoke(record); throw TavilySignInError.notSaved }
        return outcome
    }

    /// A search with the person's account: tavily_search's arguments in,
    /// the search API's answer out (both JSON objects), for TavilySearch to
    /// read. Throws a `WebSearchFailure` (`.signInNeeded` once Tavily won't
    /// renew the sign-in), or `CancellationError` when the reply is stopped.
    public func search(arguments: Data) async throws -> Data {
        guard var record = store.load(), record.status != .signedOut else { throw WebSearchFailure.keyMissing }
        guard !record.needsSignIn else { throw WebSearchFailure.signInNeeded }
        guard let arguments = try? JSONSerialization.jsonObject(with: arguments) as? [String: Any] else {
            throw WebSearchFailure.unavailable
        }
        let answer = try await call(TavilyAccount.searchMessage(arguments: arguments), record: &record)
        return (try? JSONSerialization.data(withJSONObject: answer)) ?? Data()
    }

    /// Disconnects: the sign-in leaves this device at once, then Tavily is
    /// asked to revoke it. True when Tavily confirmed; false when it
    /// couldn't be reached (the device has forgotten it either way).
    public func disconnect() async -> Bool {
        mcpSession = nil
        guard let record = store.load() else { return true }
        store.delete()
        return await revoke(record)
    }

    @discardableResult
    private func revoke(_ record: TavilyAccountRecord) async -> Bool {
        var confirmed = true
        for (token, hint) in [(record.refreshToken, "refresh_token"), (record.accessToken, "access_token")] {
            guard let token else { continue }
            let request = TavilyAccount.revokeRequest(token: token, hint: hint, clientID: record.clientID)
            let status = try? await transport(request).1.statusCode
            if status != 200 { confirmed = false }
        }
        return confirmed
    }

    // MARK: Calls

    private enum Rejected: Error { case token, session }

    /// One tools/call, renewing the sign-in when it has run out or Tavily
    /// turns the token down (once), and opening a new MCP session when the
    /// server has forgotten its own (once).
    private func call(_ message: [String: Any], record: inout TavilyAccountRecord) async throws -> [String: Any] {
        var renewed = false
        var reopened = false
        if let expiresAt = record.expiresAt, expiresAt <= now() {
            try await renew(&record)
            renewed = true
        }
        while true {
            do {
                return try await callOnce(message, token: record.accessToken ?? "")
            } catch Rejected.token where !renewed {
                renewed = true
                try await renew(&record)
            } catch Rejected.session where !reopened {
                reopened = true
                mcpSession = nil
            } catch Rejected.token {
                markNeedsSignIn(record)
                throw WebSearchFailure.signInNeeded
            } catch Rejected.session {
                throw WebSearchFailure.unavailable
            }
        }
    }

    private func callOnce(_ message: [String: Any], token: String) async throws -> [String: Any] {
        let session = try await openSession(token: token)
        let (data, response) = try await send(TavilyAccount.mcpRequest(message, token: token, session: session), failure: searchFailure)
        let reply = TavilyAccount.message(from: data, contentType: response.value(forHTTPHeaderField: "Content-Type"))
        switch response.statusCode {
        case 200: break
        case 401: throw Rejected.token
        case 400, 404: throw Self.lostSession(reply) ? Rejected.session : WebSearchFailure.unavailable
        default: throw WebSearchFailure(status: response.statusCode)
        }
        guard let reply else { throw WebSearchFailure.unavailable }
        if Self.lostSession(reply) { throw Rejected.session }
        return try TavilyAccount.searchAnswer(fromCall: reply)
    }

    private static func lostSession(_ reply: [String: Any]?) -> Bool {
        guard let error = reply?["error"] as? [String: Any], let text = error["message"] as? String else { return false }
        return text.lowercased().contains("session")
    }

    /// The server's session for this token: `initialize`, then the
    /// `notifications/initialized` the protocol asks for.
    private func openSession(token: String) async throws -> String {
        if let mcpSession, mcpSession.token == token { return mcpSession.id }
        let (_, response) = try await send(TavilyAccount.mcpRequest(TavilyAccount.initializeMessage, token: token, session: nil),
                                           failure: searchFailure)
        switch response.statusCode {
        case 200: break
        case 401: throw Rejected.token
        default: throw WebSearchFailure(status: response.statusCode)
        }
        guard let id = response.value(forHTTPHeaderField: "Mcp-Session-Id"), !id.isEmpty else { throw WebSearchFailure.unavailable }
        _ = try await send(TavilyAccount.mcpRequest(TavilyAccount.initializedMessage, token: token, session: id), failure: searchFailure)
        mcpSession = (token, id)
        return id
    }

    /// Renews the access token. Tavily turning the refresh down (a 4xx)
    /// means the person signs in again; no connection is just offline.
    private func renew(_ record: inout TavilyAccountRecord) async throws {
        guard let refresh = record.refreshToken else {
            markNeedsSignIn(record)
            throw WebSearchFailure.signInNeeded
        }
        let (data, response) = try await send(TavilyAccount.refreshRequest(refreshToken: refresh, clientID: record.clientID),
                                              failure: searchFailure)
        if (400..<500).contains(response.statusCode) {
            markNeedsSignIn(record)
            throw WebSearchFailure.signInNeeded
        }
        guard response.statusCode == 200, let tokens = try? TavilyAccount.tokens(from: data, now: now(), keeping: refresh)
        else { throw WebSearchFailure.unavailable }
        record.accessToken = tokens.access
        record.refreshToken = tokens.refresh
        record.expiresAt = tokens.expiresAt
        mcpSession = nil
        store.save(record)
    }

    private func markNeedsSignIn(_ record: TavilyAccountRecord) {
        mcpSession = nil
        store.save(TavilyAccountRecord(clientID: record.clientID, needsSignIn: true))
    }

    private func signInFailure(_ error: Error) -> Error { TavilySignInError(error) }
    private func searchFailure(_ error: Error) -> Error {
        WebSearchFailure(error).map { $0 as Error } ?? CancellationError()
    }

    private func send(_ request: URLRequest, failure: (Error) -> Error) async throws -> (Data, HTTPURLResponse) {
        do { return try await transport(request) } catch { throw failure(error) }
    }
}
