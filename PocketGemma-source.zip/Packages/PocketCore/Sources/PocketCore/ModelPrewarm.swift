import Foundation

/// 先行読み込み (1.1.0 (284), fielua-reports Issue #21, the user's directive
/// of 2026-11-15): on the phone E2B's first reply after a model was chosen
/// waited long, and the next one in the same chat started at once, because
/// the engine a reply loads stays for the next (GemmaService). So the model
/// the person chose, or the one of the chat they start typing in, begins
/// loading before the question is sent: the same load a reply makes, with
/// nothing given to the model, no conversation set up, nothing generated.
/// A question sent while it loads waits for that load instead of starting
/// another; one model loads at a time and only the newest choice is kept.
/// Where loading ahead could hurt (memory, address space, heat, Low Power
/// Mode, the app off screen), it is left for the send, as before 284.
///
/// 1.1.0 (288) (Issue #25, the user's directive of 2026-11-16) on 287: a
/// chat opened from the history (or a notification, 「前回の会話に戻る」)
/// loads its model ahead too; the same model's engine serves the next chat
/// without a second start, each chat's conversation still set up from its
/// own turns at its send; 「モデルを起動中です…」 shows under the chat's
/// model while a start ahead actually runs; heat lets an idle model go.
///
/// 1.1.0 (289) (the user's directive of 2026-11-16) on 288: LFM3 1.7B,
/// LFM3-VL 2B and LFM3-Omni 2B on llama.cpp load ahead the same way, the
/// projector with the model, nothing read before the send; only where the
/// launch had the wide address space (TestFlight), with the room measured
/// on llama.cpp (`llamaMappedBytes`, `llamaFootprintBytes`).
public enum ModelPrewarm {
    /// What asked for it.
    public enum Trigger: String, Sendable {
        /// The model menu or モデル管理's 「このモデルで会話を始める」.
        case chosen
        /// The composer took the keyboard: a question is being typed.
        case typing
        /// A chat was opened: from the history, a tapped notification,
        /// 「前回の会話に戻る」 (1.1.0 (288)). Not the list's scrolling.
        case opened
    }

    /// Why a model is not loaded ahead; the send loads it as before.
    public enum Skip: String, Sendable, Equatable, CaseIterable {
        /// iOS lets no app use the GPU off screen, and the time there is short.
        case offScreen
        /// A reply is being written: it loads what it needs itself.
        case generating
        /// A chat answered on the PC or by Claude loads nothing here.
        case remote
        /// Smart Mode chooses the model with the question.
        case smart
        case notInstalled
        /// 12B, and a model locked: only the person's own send starts them.
        case large
        case lowPower
        case heat
        case memory
        case addressSpace
        /// This launch's earlier load ahead of it failed.
        case failedBefore
        /// After a reply stopped or failed, its native objects are let go
        /// by the next reply, which starts the engine again (as before).
        case rebuildPending

        /// For 推論の診断 (developer settings), in its Japanese.
        public var note: String {
            switch self {
            case .offScreen: "アプリが前面にない"
            case .generating: "返信中"
            case .remote: "PC・Claudeのチャット"
            case .smart: "おまかせモードのチャット"
            case .notInstalled: "モデルが未保存"
            case .large: "大きいモデル（対象外）"
            case .lowPower: "低電力モード"
            case .heat: "端末が熱い"
            case .memory: "使えるメモリが少ない"
            case .addressSpace: "アドレス空間の空きが少ない"
            case .failedBefore: "この起動で先行読み込みに失敗済み"
            case .rebuildPending: "前の返信を止めた・失敗した後"
            }
        }
    }

    /// After the choice, the keyboard or the chat opening: the menu, the
    /// new chat, the history's slide and the keyboard finish moving first,
    /// and a second ask within it replaces the first, so quick switching
    /// loads only the last chat's model.
    public static let delay: Duration = .milliseconds(600)

    /// 「モデルを起動中です…」 (1.1.0 (288)) shows once a start ahead has run
    /// this long, so a start that is over at once (the runtime's cache warm
    /// on a small model) shows nothing.
    public static let indicatorDelay: Duration = .milliseconds(300)
    /// Once shown, it stays at least this long, so it never only blinks.
    public static let indicatorMinimum: Duration = .milliseconds(600)

    /// The chat and the phone as ChatStore sees them, before anything loads.
    public struct Conditions: Sendable {
        public var model: ModelSpec
        public var onScreen: Bool
        public var generating: Bool
        public var remote: Bool
        public var smart: Bool
        public var installed: Bool
        public var lowPower: Bool
        /// ProcessInfo.ThermalState's raw value: 0 nominal to 3 critical.
        public var thermal: Int
        public init(model: ModelSpec, onScreen: Bool, generating: Bool, remote: Bool, smart: Bool, installed: Bool,
                    lowPower: Bool, thermal: Int) {
            self.model = model; self.onScreen = onScreen; self.generating = generating; self.remote = remote
            self.smart = smart; self.installed = installed; self.lowPower = lowPower; self.thermal = thermal
        }
    }

    /// Nil when the model may load ahead.
    public static func skip(_ conditions: Conditions) -> Skip? {
        let model = conditions.model
        if !conditions.onScreen { return .offScreen }
        if conditions.generating { return .generating }
        if conditions.remote { return .remote }
        if conditions.smart { return .smart }
        if model.isLocked || model.id == ModelSpec.gemma12B.id || model.capabilities.gpuBenchmarkMode { return .large }
        if !conditions.installed { return .notInstalled }
        if conditions.lowPower { return .lowPower }
        // .serious and .critical: iOS is already slowing the phone down.
        if conditions.thermal >= 2 { return .heat }
        return nil
    }

    /// Whether the phone's heat lets a loaded model go while no reply runs
    /// (1.1.0 (288)): from .serious, as iOS slows the phone down. The next
    /// send loads it as before. A reply's own limits (ReplyGuard) are apart.
    public static func releasesIdleModel(thermal: Int) -> Bool { thermal >= 2 }

    /// Address space a start of `model` maps: the file and the runtime's
    /// own. On the phone E4B's GPU start took about 7.0 GB for its 3.66 GB
    /// file and the CPU's 6.4 GB (1.0.120's probes, 2026-10-21), so twice
    /// the file. LFM3 on llama.cpp: `llamaMappedBytes` (1.1.0 (289)).
    public static func startAddressSpace(_ model: ModelSpec) -> UInt64 {
        if model.runtime == .llamaCpp { return llamaMappedBytes(model) }
        return UInt64(max(0, model.downloadByteCount)) * 2
    }

    /// Address space an LFM3 load maps (1.1.0 (289)), a quarter more than
    /// the Mac's check measured with the pinned files (check-lfm3-prewarm.yml,
    /// runs 43852786698 and 43856677986, an M1, the most of Metal and the
    /// CPU): LFM3 1.7B 2.61 GB for its 1.05 GB file; LFM3-VL 2B 7.96 GB and
    /// LFM3-Omni 2B 8.89 GB on Metal for 1.25 and 1.59 GB with the
    /// projector (3.28 and 3.97 GB on the CPU), most of it mapped and never
    /// touched: their memory grew 1.47 and 1.77 GB. Far more than twice the
    /// files, which LiteRT-LM's rule would have given.
    public static func llamaMappedBytes(_ model: ModelSpec) -> UInt64 {
        let measured: UInt64 = switch model.id {
        case ModelSpec.lfm3.id: 2_607_000_000
        case ModelSpec.lfm3VL.id: 7_959_000_000
        case ModelSpec.lfm3Omni.id: 8_893_000_000
        // A file not measured: per byte as the most measured (VL's 6.4).
        default: UInt64(max(0, model.downloadByteCount)) * 7
        }
        return measured + measured / 4
    }

    /// The largest unmapped block loading ahead needs: room for its start,
    /// and for the send's own start after it should it fail, since a failed
    /// start keeps its address space until the app quits; plus 1 GB. The
    /// sideload's signature (no Extended Virtual Addressing, about 6.4 GB
    /// at launch) leaves every model to the send, as before; TestFlight's
    /// (about 68 GB) has room.
    public static func minimumLargestFree(_ model: ModelSpec) -> UInt64 {
        startAddressSpace(model) * 2 + 1_000_000_000
    }

    /// Whether the launch's own largest free block (before any model was
    /// loaded) could ever give `model` the room above (1.1.0 (288)): when it
    /// could not (the sideload's signature), nothing is let go for a load
    /// ahead that would only be left to the send. Nil: not measured.
    public static func launchHasRoom(_ model: ModelSpec, launchLargestFree: UInt64?) -> Bool {
        guard let launchLargestFree else { return true }
        if model.runtime == .llamaCpp, launchLargestFree < llamaLaunchLargestFree { return false }
        return launchLargestFree >= minimumLargestFree(model)
    }

    /// The largest free block at launch an LFM3 load ahead needs (1.1.0
    /// (289)): the wide address space (Extended Virtual Addressing, about
    /// 68.7 GB on the phone, TestFlight), the line じっくり考える draws
    /// (PhotoDetail.deeperAddressSpace). llama.cpp's load was never measured
    /// on the phone in the sideload's 6.44 GB block, where LiteRT-LM's
    /// failed starts kept their address space, so there LFM3 loads at the
    /// send, as before 289.
    public static let llamaLaunchLargestFree: UInt64 = PhotoDetail.deeperAddressSpace

    /// Whether an engine loaded for `loaded` serves a turn planned as
    /// `wanted`. LiteRT-LM's: the same plan. LFM3's on llama.cpp (1.1.0
    /// (289)): the same file on the same processor with the same context,
    /// with the turn's photos or recording or none, since LFM3-VL 2B's and
    /// LFM3-Omni 2B's projector loads with the model either way (234, 236).
    public static func serves(_ loaded: InferenceEnginePlan, _ wanted: InferenceEnginePlan) -> Bool {
        guard ModelSpec.find(loaded.modelID)?.runtime == .llamaCpp else { return loaded == wanted }
        return loaded.modelID == wanted.modelID && loaded.modelSHA256 == wanted.modelSHA256
            && loaded.backend == wanted.backend && loaded.maxTokens == wanted.maxTokens
    }

    /// The memory iOS still lets the app take (os_proc_available_memory)
    /// that loading ahead leaves: a quarter of the file, which the start
    /// takes in pages it touches (E4B's whole photo reply peaked under
    /// 2 GB on the phone), and 1.5 GB for the app and the reply. LFM3 on
    /// llama.cpp (1.1.0 (289)): `llamaFootprintBytes`, and the same 1.5 GB.
    public static func minimumAvailableMemory(_ model: ModelSpec) -> UInt64 {
        if model.runtime == .llamaCpp { return llamaFootprintBytes(model) + 1_500_000_000 }
        return UInt64(max(0, model.downloadByteCount)) / 4 + 1_500_000_000
    }

    /// The memory an LFM3 load takes (1.1.0 (289)): a quarter more than its
    /// files. llama.cpp keeps the weights as the app's own memory, not the
    /// file's pages, so its footprint grew 1.18 times the files at most on
    /// the Mac (runs 43852786698, 43856677986: LFM3 1.7B 1.24 GB for
    /// 1.05 GB, LFM3-VL 2B 1.47 GB for 1.25 GB, LFM3-Omni 2B 1.77 GB for
    /// 1.59 GB, Metal and the CPU alike), where LiteRT-LM's start takes a
    /// quarter of its file.
    public static func llamaFootprintBytes(_ model: ModelSpec) -> UInt64 {
        let files = UInt64(max(0, model.downloadByteCount))
        return files + files / 4
    }

    /// Read in GemmaService just before loading, once the previous model is
    /// released. Nil values were not measured (the simulator's memory is
    /// the Mac's) and are not checked.
    public static func roomSkip(_ model: ModelSpec, availableMemory: UInt64?, largestFree: UInt64?) -> Skip? {
        if let availableMemory, availableMemory < minimumAvailableMemory(model) { return .memory }
        if let largestFree, largestFree < minimumLargestFree(model) { return .addressSpace }
        return nil
    }

    /// How the reply found its engine, for 推論の診断.
    public enum Use: Sendable, Equatable {
        /// Loaded ahead and ready when the question came.
        case ready(loadSeconds: Double, readyBefore: Double)
        /// Still loading when the question came: the reply waited for it.
        case joined(loadSeconds: Double, waited: Double)
        /// Loading ahead was left for this reason; the reply loaded the model.
        case skipped(Skip)
        /// It failed; the reply loaded the model as before.
        case failed
        /// It loaded another model or plan, which the reply let go.
        case other
        /// The chat opened on the engine already loaded for its model (the
        /// one before it, or this chat's earlier reply): nothing loaded
        /// again (1.1.0 (288)).
        case reused

        public var note: String {
            switch self {
            case .ready(let load, let before):
                String(format: "先行読み込み済み（読み込み %.1f秒・送信の %.1f秒前に完了）", load, before)
            case .joined(let load, let waited):
                String(format: "読み込み中に送信して合流（読み込み %.1f秒・送信後の待ち %.1f秒）", load, waited)
            case .skipped(let skip): "先行読み込みは見送り: " + skip.note
            case .failed: "先行読み込みは失敗、送信時に通常どおり読み込み"
            case .other: "先行読み込みは別の構成、送信時に読み込み直し"
            case .reused: "起動済みのモデルを再利用（読み込みなし）"
            }
        }
    }
}
