import Foundation

/// Smart Mode (Fielua スマート化計画, 1.1.0 (249), the user's directive of
/// 2026-10-31): the person only asks, and Fielua chooses the model and how
/// it replies for each question, from what the question says, what comes
/// with it, the phone, and the models saved on it. The person may name a
/// genre for the chat (SmartGenre); it is a policy for the reply and a
/// preference for the model, never a fixed model. The choice is made on the
/// phone from the words alone (SmartClassifier): no model runs to choose,
/// nothing is downloaded, and nothing leaves the phone for it.
///
/// It is on unless turned off in モデル管理. A chat whose model the person
/// chose (ChatThread.modelPinned), and every chat while it is off, keeps
/// the model, the reply mode and the settings as chosen, as before 249.
public enum SmartMode {
    /// モデル管理's switch, 「質問に合わせて自動で選ぶ」.
    public static let storageKey = "smart-mode-v1"
    public static var isOn: Bool {
        UserDefaults.standard.object(forKey: storageKey) as? Bool ?? true
    }
}

/// 質問のジャンル: what the person may say the chat's questions are about.
/// A new chat starts on 自動, and so does every chat saved without one.
/// ウェブ検索 is the chat's web search switch (ChatThread.webSearch), so the
/// plus menu's switch and the genre are one setting.
public enum SmartGenre: String, CaseIterable, Identifiable, Codable, Sendable {
    case auto, reasoning, math, textSummary, fileSummary, programming, webSearch
    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .auto: String(localized: "自動")
        case .reasoning: String(localized: "推論")
        case .math: String(localized: "数学")
        case .textSummary: String(localized: "文章要約")
        case .fileSummary: String(localized: "ファイル要約")
        case .programming: String(localized: "プログラミング")
        case .webSearch: String(localized: "ウェブ検索")
        }
    }
    public var symbol: String {
        switch self {
        case .auto: "sparkles"
        case .reasoning: "lightbulb"
        case .math: "function"
        case .textSummary: "text.alignleft"
        case .fileSummary: "doc.text"
        case .programming: "chevron.left.forwardslash.chevron.right"
        case .webSearch: "globe"
        }
    }
}

/// What a question is, as Smart Mode reads it: a genre the person named, or
/// what 自動 found in the words and what came with them.
public enum SmartTask: String, CaseIterable, Codable, Sendable {
    case conversation, writing, photo, photoText, video, voice
    case reasoning, math, textSummary, fileSummary, programming, webSearch

    public var title: String {
        switch self {
        case .conversation: String(localized: "会話")
        case .writing: String(localized: "文章作成")
        case .photo: String(localized: "写真")
        case .photoText: String(localized: "写真の文字")
        case .video: String(localized: "動画")
        case .voice: String(localized: "音声")
        case .reasoning: String(localized: "推論")
        case .math: String(localized: "数学")
        case .textSummary: String(localized: "文章要約")
        case .fileSummary: String(localized: "ファイル要約")
        case .programming: String(localized: "プログラミング")
        case .webSearch: String(localized: "ウェブ検索")
        }
    }

    /// How the reply goes about it: an everyday question, a photo or a
    /// spoken one briefly and fast; writing, summaries, fine print and a
    /// search's answer without a request for brevity; reasoning, math and
    /// code thinking first.
    public var pace: SmartPace {
        switch self {
        case .conversation, .photo, .video, .voice: .quick
        case .writing, .photoText, .textSummary, .fileSummary, .webSearch: .standard
        case .reasoning, .math, .programming: .careful
        }
    }

    /// What the task asks of the model after the system prompt, in English
    /// as the app's other words to the model are (GenerationSettings): the
    /// Japanese prompt pulled replies to Japanese (1.1.0 (187)). Each lets a
    /// length or format the person asks for win. About 30 to 45 tokens,
    /// out of the reply's reserve as 高速's and じっくり考える's notes.
    public var note: String? {
        switch self {
        case .conversation, .writing, .photo, .video, .voice, .webSearch: nil
        case .photoText:
            "Read the text in the image carefully and quote it exactly before you explain it. A length or format the user asks for wins."
        case .reasoning:
            "Lay out the reasoning in clear steps, say which assumptions it rests on, and end with the conclusion. A length or format the user asks for wins."
        case .math:
            "For a math problem, write the formula and each step of the working, check the result once more, and end with the answer on its own line. A length or format the user asks for wins."
        case .textSummary:
            "When asked to summarize, keep only the main points, in the user's language, and add nothing that is not in the text. A length or format the user asks for wins."
        case .fileSummary:
            "Answer from the attached material: summarize its main points, or answer the question about it, and add nothing that is not in it. A length or format the user asks for wins."
        case .programming:
            "For code, give complete code in fenced code blocks with the language name, then explain briefly how it works or what changed. A length or format the user asks for wins."
        }
    }
}

public enum SmartPace: String, Codable, Sendable {
    /// 高速's request for brief replies (GenerationSettings.briefReplyNote), no thinking.
    case quick
    /// No request for brevity, no thinking.
    case standard
    /// じっくり考える's request for care (carefulReplyNote), thinking first
    /// where it can.
    case careful
}

/// The generation settings Smart Mode gives one turn, on top of the model's
/// saved settings (GenerationSettings.smart): never saved with them, and
/// kept with the reply (SmartReply) so a reply that goes on after the app
/// left the screen goes on as it began.
public struct SmartTuning: Codable, Equatable, Sendable {
    public var task: SmartTask
    public var pace: SmartPace
    /// Whether the reply thinks first, with room of its own for it: a
    /// quarter of the context, 1,024 tokens at 4,096, as じっくり考える.
    public var thinks: Bool
    /// E4B's photo detail for the turn (70 for a brief reply, 280 for the
    /// rest, 140 with the language model on the CPU where the launch lacks
    /// the room for 280: PhotoDetail.running); nil for other models.
    public var photoDetail: PhotoDetail?

    public init(task: SmartTask, pace: SmartPace? = nil, thinks: Bool, photoDetail: PhotoDetail? = nil) {
        self.task = task; self.pace = pace ?? task.pace; self.thinks = thinks; self.photoDetail = photoDetail
    }

    public var note: String? { task.note }

    private enum CodingKeys: String, CodingKey { case task, pace, thinks, photoDetail }
    /// Never fails on a value a later version writes: the chat archive must
    /// always open.
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        task = (try? values.decodeIfPresent(SmartTask.self, forKey: .task)) ?? .conversation
        pace = (try? values.decodeIfPresent(SmartPace.self, forKey: .pace)) ?? task.pace
        thinks = (try? values.decodeIfPresent(Bool.self, forKey: .thinks)) ?? false
        photoDetail = (try? values.decodeIfPresent(PhotoDetail.self, forKey: .photoDetail)) ?? nil
    }
}

/// What a reply's choice could not give, said with it rather than answered
/// as something else unannounced.
public enum SmartNotice: String, Codable, Sendable {
    /// Thinking with photos needs the address space じっくり考える needs.
    case noThinkingWithPhotos
    /// The model chosen has no thinking (12B, LFM3-Omni 2B and others).
    case modelDoesNotThink
    /// Neither Gemma 4 E4B nor E2B can take the question here.
    case outsideStarters
    case searchNeedsConnection
    case searchBlockedByFiles

    public var text: String {
        switch self {
        case .noThinkingWithPhotos: String(localized: "アドレス空間が足りないため、写真のある質問は考えずに答えます。")
        case .modelDoesNotThink: String(localized: "このモデルは考える処理を使わずに答えます。")
        case .outsideStarters: String(localized: "Gemma 4 E4B・E2Bを使えないため、ほかのモデルで答えます。")
        case .searchNeedsConnection: String(localized: "Tavilyに接続していないため、検索せずに端末の中だけで答えます。")
        case .searchBlockedByFiles: String(localized: "ファイルや動画のある会話では検索せず、端末の中だけで答えます。")
        }
    }
}

/// What Smart Mode chose for a reply, kept with it (ChatMessage.smart): the
/// genre the chat had, the model, the settings and what the choice could not
/// give. The reply's menu shows it, the diagnostics record it, and a reply
/// that goes on later goes on with it.
public struct SmartReply: Codable, Equatable, Sendable {
    public var genre: SmartGenre
    public var modelID: String
    public var tuning: SmartTuning
    public var searched: Bool
    public var notices: [SmartNotice]

    public init(genre: SmartGenre, modelID: String, tuning: SmartTuning, searched: Bool, notices: [SmartNotice]) {
        self.genre = genre; self.modelID = modelID; self.tuning = tuning; self.searched = searched; self.notices = notices
    }

    /// The model and how it replied: 「Gemma 4 E4B · 考えてから返信」.
    public var summary: String {
        let model = ModelSpec.find(modelID)
        return (model?.name ?? modelID) + " · " + SmartPlanner.paceLabel(tuning, model: model)
    }
    /// The genre, and what 自動 found: 「自動 · 数学」.
    public var genreLine: String {
        genre == .auto ? genre.title + " · " + tuning.task.title : genre.title
    }

    private enum CodingKeys: String, CodingKey { case genre, modelID, tuning, searched, notices }
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        genre = (try? values.decodeIfPresent(SmartGenre.self, forKey: .genre)) ?? .auto
        modelID = (try? values.decodeIfPresent(String.self, forKey: .modelID)) ?? ModelSpec.e4b.id
        tuning = (try? values.decodeIfPresent(SmartTuning.self, forKey: .tuning)) ?? SmartTuning(task: .conversation, thinks: false)
        searched = (try? values.decodeIfPresent(Bool.self, forKey: .searched)) ?? false
        let raw = (try? values.decodeIfPresent([String].self, forKey: .notices)) ?? []
        notices = raw.compactMap(SmartNotice.init(rawValue:))
    }
    public func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: CodingKeys.self)
        try values.encode(genre, forKey: .genre)
        try values.encode(modelID, forKey: .modelID)
        try values.encode(tuning, forKey: .tuning)
        try values.encode(searched, forKey: .searched)
        try values.encode(notices.map(\.rawValue), forKey: .notices)
    }
}

/// 自動's reading of a question: from its words and what comes with it, in
/// the app's five languages, with plain string and pattern checks, so the
/// choice costs no model run and no wait. A genre the person named wins over
/// the words; a recording always goes to the one model that hears it.
public enum SmartClassifier {
    public static func task(genre: SmartGenre, prompt: String, attachments kinds: [ChatAttachment.Kind]) -> SmartTask {
        if kinds.contains(.audio) { return .voice }
        switch genre {
        case .reasoning: return .reasoning
        case .math: return .math
        case .textSummary: return .textSummary
        case .fileSummary: return .fileSummary
        case .programming: return .programming
        case .webSearch: return .webSearch
        case .auto: break
        }
        let text = prompt.lowercased()
        if kinds.contains(.file) { return .fileSummary }
        if kinds.contains(.video) { return .video }
        if kinds.contains(.image) {
            if asksForCode(text) { return .programming }
            if asksForMath(text) { return .math }
            if asksToRead(text) { return .photoText }
            if asksToReason(text) { return .reasoning }
            return .photo
        }
        if asksForCode(text) { return .programming }
        if asksForMath(text) { return .math }
        if asksToSummarize(text) { return .textSummary }
        if asksToReason(text) { return .reasoning }
        if asksToWrite(text) || text.count >= 400 { return .writing }
        return .conversation
    }

    static func asksForCode(_ text: String) -> Bool {
        if text.contains("```") { return true }
        // Words that start a line of code only: "let", "class" or "import"
        // start English sentences too.
        if matches(text, #"(?m)^\s*(func|def|#include)\s"#) || matches(text, #"(print|printf|println|console\.log)\("#) { return true }
        if text.contains("{") && text.contains("}") && (text.contains(";") || text.contains("=") || text.contains("(")) { return true }
        // Not 関数 or 함수 alone, which math has too, nor the English words
        // with another everyday meaning (bug, script, program, function,
        // swift, java, ruby, rust, react).
        if containsAny(text, ["プログラム", "コード", "スクリプト", "変数", "バグ", "デバッグ", "コンパイル", "アルゴリズム",
                              "正規表現", "メソッド", "ライブラリ", "フレームワーク",
                              "代码", "代碼", "编程", "編程", "程序", "程式", "调试", "調試", "算法", "演算法",
                              "코드", "프로그램", "프로그래밍", "디버그", "버그", "알고리즘", "스크립트"]) { return true }
        return matches(text, #"(?<![a-z])(code|coding|programming|debug|debugging|compile|compiler|algorithm|refactor|snippet|regex|swiftui|python|javascript|typescript|kotlin|golang|php|sql|html|css|json|yaml|bash|xcode|github)(?![a-z])"#)
            || text.contains("c++") || text.contains("c#")
    }

    static func asksForMath(_ text: String) -> Bool {
        // An operation between numbers; a minus or a slash only with spaces
        // round it, as dates and phone numbers have none.
        if matches(text, #"[0-9０-９]\s*[+×÷*^＋＝=]\s*[0-9０-９(（a-z]"#)
            || matches(text, #"[0-9０-９]\s+[\-−/－]\s+[0-9０-９(（]"#) { return true }
        if containsAny(text, ["計算", "解いて", "解け", "方程式", "数式", "連立", "因数分解", "微分", "積分", "確率", "期待値",
                              "平方根", "√", "∫", "σ", "π", "証明して", "算数", "数学", "何個", "何通り", "何倍",
                              "割り算", "掛け算", "足し算", "引き算", "面積", "体積", "平均値", "分数", "小数", "関数",
                              "计算", "方程", "數學", "解题", "解題", "概率", "機率", "积分", "导数", "導數", "函数", "函數",
                              "계산", "방정식", "수학", "확률", "적분", "미분", "함수"]) { return true }
        return matches(text, #"(?<![a-z])(calculate|calculation|solve|equation|integral|derivative|probability|arithmetic|algebra|geometry|math|maths|percentage|prove that)(?![a-z])"#)
    }

    static func asksToSummarize(_ text: String) -> Bool {
        containsAny(text, ["要約", "まとめて", "まとめる", "まとめを", "要点", "要旨", "かいつまんで", "3行で", "三行で",
                           "あらすじ", "サマリー",
                           "总结", "總結", "摘要", "概括", "归纳", "歸納", "要點",
                           "요약", "정리해", "핵심"])
            || matches(text, #"(?<![a-z])(summari[sz]e|summary|tl;?dr|key points|recap)(?![a-z])"#)
    }

    /// A strong word, or a weak one in a longer question or twice: 「なぜ空は
    /// 青いの？」 stays a quick answer.
    static func asksToReason(_ text: String) -> Bool {
        if containsAny(text, ["推論", "論理", "筋道", "順を追って", "ステップバイステップ", "比較して", "比較する", "比べて",
                              "メリットとデメリット", "メリット・デメリット", "長所と短所", "どちらがいい", "どちらが良い",
                              "どっちがいい", "選ぶべき", "分析して", "考察", "戦略", "仮説", "パズル", "なぞなぞ", "謎解き",
                              "矛盾", "根拠", "判断して", "検証して",
                              "推理", "逻辑", "邏輯", "比较", "分析", "优缺点", "優缺點", "策略", "谜题", "謎題",
                              "추론", "논리", "비교", "분석", "장단점", "전략", "퍼즐"]) { return true }
        if matches(text, #"(?<![a-z])(reasoning|logic|logical|step by step|compare|comparison|versus|pros and cons|trade-?offs?|analy[sz]e|analysis|strategy|puzzle|riddle|which is better|hypothesis)(?![a-z])"#) { return true }
        let weak = ["なぜ", "どうして", "理由", "違い", "原因", "为什么", "為什麼", "原因", "왜", "이유", "차이"]
        let hits = weak.filter { text.contains($0) }.count + (matches(text, #"(?<![a-z])why(?![a-z])"#) ? 1 : 0)
        return hits >= 2 || (hits == 1 && text.count >= 80)
    }

    static func asksToRead(_ text: String) -> Bool {
        containsAny(text, ["文字", "読んで", "読み取", "書いてある", "書かれて", "テキスト", "レシート", "メニュー", "看板",
                           "細かい", "小さい字", "翻訳", "何と書", "なんて書",
                           "识别", "識別", "读一下", "讀一下", "翻译", "翻譯", "写着", "寫著",
                           "글자", "읽어", "텍스트", "번역", "적혀"])
            || matches(text, #"(?<![a-z])(read|text|transcribe|ocr|receipt|menu|sign|translate|written)(?![a-z])"#)
    }

    static func asksToWrite(_ text: String) -> Bool {
        containsAny(text, ["作成", "作って", "書いて", "資料", "メールを", "レポート", "手紙", "企画書", "文章を書",
                           "写一", "寫一", "撰写", "撰寫", "制作", "製作",
                           "작성", "써 줘", "써줘", "만들어"])
            || matches(text, #"(?<![a-z])(write|draft|compose|create)(?![a-z])"#)
    }

    private static func containsAny(_ text: String, _ words: [String]) -> Bool {
        words.contains { text.contains($0) }
    }
    private static func matches(_ text: String, _ pattern: String) -> Bool {
        text.range(of: pattern, options: .regularExpression) != nil
    }
}

/// Smart Mode's choice of model and settings for one question.
///
/// Models are chosen by what they can do and by what has been seen on the
/// person's iPhone, not by their names or sizes (the directive): Gemma 4
/// E4B and E2B (`starters`) are the ones whose chats, photos, files, search
/// and E4B's thinking were confirmed there; every other model is a stand-in
/// for a question neither can take (LFM3-Omni 2B for a spoken question, the
/// one model that hears one), or for a phone that has neither. 12B is a test
/// version that needs TestFlight's address space and never thinks;
/// Phi-4-mini-reasoning, made for math, answered Japanese in Chinese or
/// English on the phone's runtime (1.1.0 (205)), so it is never preferred
/// for math. A model is used only when it is saved on the phone, unlocked
/// and able to start on this launch; Smart Mode never downloads one.
///
/// A chat keeps its model while that model suits the question, so a
/// conversation is not reloaded at every turn: an everyday question, a
/// summary or a search stays on the chat's E4B or E2B; reasoning, math and
/// code go to E4B, whose thinking was confirmed; fine print in a photo and a
/// video go to E2B, whose photos take 280 image tokens and which hears a
/// video's sound on every launch, unless E4B can on this one. A model that
/// failed this launch (`Context.avoided`) is tried last.
public enum SmartPlanner {
    public struct Context: Sendable, Equatable {
        /// The chat's model now.
        public var current: ModelSpec
        /// Models with all their files saved (ModelStore.isInstalled).
        public var installed: Set<String>
        public var developer: Bool
        /// PhotoDetail.deeperFits: the launch's address space has room for
        /// E4B's photos at 280 with thinking.
        public var deeperFits: Bool
        /// LargeModelProbe.twelveBFitsAtLaunch.
        public var twelveBFits: Bool
        /// E4B is tight for this phone's memory (ModelRecommendation.fit):
        /// E2B comes first for everything.
        public var prefersSmall: Bool
        /// Models whose reply failed this launch.
        public var avoided: Set<String>
        /// The person's Tavily connection (WebSearchKeyState.isReady).
        public var searchReady: Bool
        /// A file or video in the chat or the draft (WebSearchPolicy.blockedByFiles).
        public var searchBlocked: Bool
        /// VideoSound.e4bHears: E4B writes down a video's sound on this
        /// launch; E2B always does.
        public var e4bHearsVideo: Bool

        public init(current: ModelSpec, installed: Set<String>, developer: Bool = false, deeperFits: Bool = PhotoDetail.deeperFits,
                    twelveBFits: Bool = LargeModelProbe.twelveBFitsAtLaunch, prefersSmall: Bool = false,
                    avoided: Set<String> = [], searchReady: Bool = false, searchBlocked: Bool = false,
                    e4bHearsVideo: Bool = VideoSound.e4bHears) {
            self.current = current; self.installed = installed; self.developer = developer; self.deeperFits = deeperFits
            self.twelveBFits = twelveBFits; self.prefersSmall = prefersSmall; self.avoided = avoided
            self.searchReady = searchReady; self.searchBlocked = searchBlocked; self.e4bHearsVideo = e4bHearsVideo
        }
    }

    public struct Request: Sendable, Equatable {
        public var genre: SmartGenre
        public var prompt: String
        /// What is sent with the question.
        public var attachments: [ChatAttachment.Kind]
        /// What the chat's earlier messages carry.
        public var earlier: Set<ChatAttachment.Kind>
        /// The photo detail the chat's last reply read its photos with: a
        /// question about the same photos keeps it, so the engine loaded for
        /// them is not loaded again (a detail of its own is a plan of its own).
        public var earlierDetail: PhotoDetail?
        public init(genre: SmartGenre, prompt: String, attachments: [ChatAttachment.Kind] = [], earlier: Set<ChatAttachment.Kind> = [],
                    earlierDetail: PhotoDetail? = nil) {
            self.genre = genre; self.prompt = prompt; self.attachments = attachments; self.earlier = earlier
            self.earlierDetail = earlierDetail
        }
    }

    public struct Plan: Sendable, Equatable {
        public let model: ModelSpec
        public let tuning: SmartTuning
        /// Whether the turn may search (the chat's ウェブ検索 genre with the
        /// person's connection, and no file).
        public let searches: Bool
        public let notices: [SmartNotice]
        public func reply(genre: SmartGenre) -> SmartReply {
            SmartReply(genre: genre, modelID: model.id, tuning: tuning, searched: searches, notices: notices)
        }
    }

    public struct Unavailable: LocalizedError, Sendable, Equatable {
        public let message: String
        public var errorDescription: String? { message }
    }

    /// The models confirmed on the person's iPhone for everyday chats.
    public static let starters = [ModelSpec.e4b.id, ModelSpec.e2b.id]
    /// Stand-ins, in the order they are tried.
    public static let standIns = [ModelSpec.gemma12B, .qwen35, .qwen25, .lfm3, .lfm3VL, .lfm3Omni, .phi4MiniReasoning, .qwen3].map(\.id)

    public static func plan(_ request: Request, in context: Context) -> Result<Plan, Unavailable> {
        let task = SmartClassifier.task(genre: request.genre, prompt: request.prompt, attachments: request.attachments)
        let kinds = Set(request.attachments)
        let wantsSearch = task == .webSearch
        let searches = wantsSearch && context.searchReady && !context.searchBlocked && !TryQuestion.isSample(request.prompt)
        let needs = Needs(voice: kinds.contains(.audio), photos: kinds.contains(.image), video: kinds.contains(.video),
                          files: kinds.contains(.file), search: searches)
        guard let model = order(for: task, request: request, context: context)
            .compactMap(ModelSpec.find)
            .first(where: { usable($0, needs, context) }) else {
            return .failure(Unavailable(message: unavailableMessage(needs, context)))
        }
        var notices: [SmartNotice] = []
        if wantsSearch && !searches {
            if !context.searchReady { notices.append(.searchNeedsConnection) }
            else if context.searchBlocked { notices.append(.searchBlockedByFiles) }
        }
        if !starters.contains(model.id) && task != .voice { notices.append(.outsideStarters) }
        // Photos the model reads this turn, new or earlier in the chat.
        let newVision = needs.photos || needs.video
        let vision = model.supportsVision && (newVision || request.earlier.contains(.image) || request.earlier.contains(.video))
        var thinks = false
        if task.pace == .careful {
            if !thinksHere(model) {
                if !model.capabilities.reasons { notices.append(.modelDoesNotThink) }
            } else if vision && !context.deeperFits {
                // Thinking with photos was seen on the phone only with
                // じっくり考える's room (280 on the GPU, 1.0.121); without it
                // photos run as 深く, without thinking, as じっくり考える's do.
                notices.append(.noThinkingWithPhotos)
            } else {
                thinks = true
            }
        }
        // E4B's photos: 70 for a brief reply, 280 for the rest (140 on the
        // CPU without the room for 280), and as before for the same photos.
        let detail: PhotoDetail?
        if model.photoDetails.isEmpty { detail = nil }
        else if vision && !newVision, let kept = request.earlierDetail { detail = kept }
        else { detail = task.pace == .quick ? .fast : .deeper }
        let tuning = SmartTuning(task: task, thinks: thinks, photoDetail: detail.map(\.running))
        return .success(Plan(model: model, tuning: tuning, searches: searches, notices: notices))
    }

    /// Thinking that Smart Mode uses: Gemma 4 E4B's and E2B's on LiteRT-LM.
    /// A reasoning model thinks on its own (Phi); the others are left as
    /// they answer without it.
    static func thinksHere(_ model: ModelSpec) -> Bool {
        starters.contains(model.id) && model.supportsThinking
    }

    /// The model a Smart chat rests on before its next question: the one it
    /// has, or the person's model when saved, else the first saved model
    /// Smart Mode would use; nil when none is saved.
    public static func restingModel(preferred: ModelSpec, context: Context) -> ModelSpec? {
        if context.installed.contains(preferred.id), allowed(preferred, context) { return preferred }
        return (pool(context) + standIns).compactMap(ModelSpec.find).first { context.installed.contains($0.id) && allowed($0, context) }
    }

    /// The model whose attachments the composer offers in a Smart chat: the
    /// chat's when it takes photos and files, else the first saved starter,
    /// which the question with them will go to.
    public static func attachmentModel(context: Context) -> ModelSpec {
        let current = context.current
        if context.installed.contains(current.id), current.capabilities.photos == .native, current.capabilities.documents {
            return current
        }
        return pool(context).compactMap(ModelSpec.find).first { context.installed.contains($0.id) } ?? current
    }

    /// 「考えてから返信」「速さを優先」「標準」.
    public static func paceLabel(_ tuning: SmartTuning, model: ModelSpec?) -> String {
        if tuning.thinks || model?.capabilities.reasons == true { return String(localized: "考えてから返信") }
        return tuning.pace == .quick ? String(localized: "速さを優先") : String(localized: "標準")
    }

    struct Needs: Equatable {
        var voice = false, photos = false, video = false, files = false, search = false
    }

    static func pool(_ context: Context) -> [String] {
        context.prefersSmall ? [ModelSpec.e2b.id, ModelSpec.e4b.id] : starters
    }

    static func order(for task: SmartTask, request: Request, context: Context) -> [String] {
        let pool = pool(context)
        let current = context.current.id
        let keep = pool.contains(current) ? [current] : []
        var order: [String]
        switch task {
        case .voice: order = [ModelSpec.lfm3Omni.id]
        // E4B reads fine print at 280 only with the room for it.
        case .photoText: order = (context.deeperFits ? keep : []) + [ModelSpec.e2b.id, ModelSpec.e4b.id]
        // A video's sound is heard by E2B, and by E4B with the room for it.
        case .video: order = (context.e4bHearsVideo ? keep : []) + [ModelSpec.e2b.id, ModelSpec.e4b.id]
        case .reasoning, .math, .programming: order = context.prefersSmall ? keep + pool : [ModelSpec.e4b.id, ModelSpec.e2b.id]
        case .conversation where current == ModelSpec.lfm3Omni.id && request.earlier.contains(.audio):
            // A spoken question's chat goes on with the model that heard it:
            // no other model reads the recording.
            order = [current] + pool
        default: order = keep + pool
        }
        order += pool + standIns
        var seen = Set<String>()
        let unique = order.filter { seen.insert($0).inserted }
        return unique.filter { !context.avoided.contains($0) } + unique.filter { context.avoided.contains($0) }
    }

    static func allowed(_ model: ModelSpec, _ context: Context) -> Bool {
        !model.isLocked && (context.developer || !model.isDeveloperOnly)
            && (model.id != ModelSpec.gemma12B.id || context.twelveBFits)
    }

    static func usable(_ model: ModelSpec, _ needs: Needs, _ context: Context) -> Bool {
        guard context.installed.contains(model.id), allowed(model, context) else { return false }
        let can = model.capabilities
        if needs.voice && !can.voice { return false }
        if needs.photos && can.photos != .native { return false }
        if needs.video && !(can.photos == .native && can.videos) { return false }
        if needs.files && !can.documents { return false }
        if needs.search && !model.supportsWebSearch { return false }
        return true
    }

    static func unavailableMessage(_ needs: Needs, _ context: Context) -> String {
        // The model that hears a question takes photos, but no video or file.
        if needs.voice && (needs.video || needs.files) && context.installed.contains(ModelSpec.lfm3Omni.id) {
            return String(localized: "話しかけた質問には、動画やファイルを一緒に送れません。分けて送ってください。")
        }
        if needs.voice { return String(localized: "話しかけて使うには、設定の「モデル管理」からLFM3-Omni 2Bをダウンロードしてください。") }
        if needs.photos || needs.video { return String(localized: "写真や動画を読むには、設定の「モデル管理」からGemma 4 E2BかE4Bをダウンロードしてください。") }
        if needs.files { return String(localized: "ファイルを読むには、設定の「モデル管理」からGemma 4 E2BかE4Bをダウンロードしてください。") }
        return String(localized: "設定の「モデル管理」からGemma 4 E2BかE4Bをダウンロードしてください。")
    }
}
