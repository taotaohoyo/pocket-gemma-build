import Foundation

/// What a model is offered right now: its capabilities (ModelCapabilities),
/// with photos at the image tokens its chats use
/// (ModelSpec.chatVisualTokenBudgets). Do not change E4B's model pin.
public struct ModelAttachmentPolicy: Sendable {
    public let modelID: String
    public let capabilities: ModelCapabilities
    /// The most image tokens a chat photo gets.
    public let photoTokens: Int
    public init(model: ModelSpec) {
        modelID = model.id; capabilities = model.capabilities
        photoTokens = model.chatVisualTokenBudgets.max() ?? 0
    }
    public var allowsImages: Bool { capabilities.photos == .native }
    /// E4B's photos take fewer image tokens than E2B's 280, to fit the
    /// phone's address space, so fine print is harder to read; with さらに深く
    /// offered they can take 280 too.
    public var coarsePhotos: Bool { allowsImages && photoTokens < 280 }
    public static var coarsePhotoNote: String { String(localized: "写真は、メモリに収めるため粗めに読み取ります。細かい文字はGemma 4 E2Bの方が読み取れます。") }
    /// A text-only model takes a photo's text, read on the device, as text.
    public var readsPhotoText: Bool { capabilities.photos == .textRecognition }
    /// The photo item opens the picker: the model's own vision, or OCR.
    public var allowsPhotos: Bool { allowsImages || readsPhotoText }
    /// A video's scenes (VideoScenes) go to the vision encoder as photos
    /// do, so the models that see photos take videos; never as text.
    public var allowsVideo: Bool { allowsImages }
    public var allowsDocuments: Bool { capabilities.documents }
    public var allowsAnyAttachment: Bool { allowsPhotos || allowsDocuments }
    /// What a video gives the model, in the guide and on the attachment.
    public static var videoNote: String { String(localized: "動画は開始・中間・終了付近の3場面を読み込みます。音声は解析しません。") }
    public static var documentFormats: String { String(localized: "TXT・Markdown・PDF・CSV・JSON・Word") }
    public var summary: String {
        if allowsImages {
            return (allowsDocuments ? String(localized: "テキスト・写真・動画・ファイル") : String(localized: "テキスト・写真・動画"))
                + (coarsePhotos ? " · " + String(localized: "写真は粗め") : "")
        }
        if readsPhotoText { return allowsDocuments ? String(localized: "テキスト・ファイル・写真の文字") : String(localized: "テキスト・写真の文字") }
        return allowsDocuments ? String(localized: "テキスト・ファイル") : String(localized: "テキスト")
    }
    public var guidance: String {
        let files = String(localized: "ファイル（\(Self.documentFormats)）は端末内で本文の文字だけを読み取り、モデルに渡します。")
        if allowsImages {
            return Sentences.join([String(localized: "写真と動画を利用できます。"), coarsePhotos ? Self.coarsePhotoNote : "",
                                   Self.videoNote, allowsDocuments ? files : ""])
        }
        if readsPhotoText {
            return Sentences.join([String(localized: "このモデルはテキスト専用で、写真の見た目（人物・物・色など）は理解できません。写真は端末内の文字認識で、写っている文字だけを読み取って渡します。写真の内容を見てほしいときはGemma 4 E2Bへ切り替えてください。"),
                                   allowsDocuments ? files : ""])
        }
        if allowsDocuments {
            return Sentences.join([String(localized: "このモデルはテキスト専用で、写真の中身を読み取れません。写真を使うにはGemma 4 E2Bへ切り替えてください。"), files])
        }
        return String(localized: "このモデルはテキスト専用で、写真やファイルは読み込めません。写真やファイルを使うにはGemma 4 E2Bへ切り替えてください。")
    }
    public func allows(_ attachment: ChatAttachment) -> Bool {
        switch attachment.kind {
        case .image:
            if allowsImages { return attachment.imageNames.count == 1 && attachment.extractedText == nil }
            // Only the photo's recognized text, never its pixels.
            return readsPhotoText && attachment.imageNames.isEmpty && hasText(attachment)
        case .video:
            // Its scenes, as images: at least one and no more than were taken.
            return allowsVideo && (1...VideoScenes.count).contains(attachment.imageNames.count) && attachment.extractedText == nil
        case .file:
            // Only extracted text: a file kind must never carry images.
            return allowsDocuments && attachment.imageNames.isEmpty && hasText(attachment)
        }
    }
    private func hasText(_ attachment: ChatAttachment) -> Bool {
        !(attachment.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ?? true)
    }
    public func validateNewAttachments(_ attachments: [ChatAttachment]) throws {
        guard attachments.allSatisfy(allows) else { throw Unavailable(message: guidance) }
    }
    /// Keep the saved archive intact. Old unsupported media must never silently
    /// re-enable vision when a reader sends a text reply in an existing thread.
    public func inferenceHistory(_ messages: [ChatMessage]) -> [ChatMessage] {
        messages.map { original in
            let allowed = original.media.filter(allows)
            guard allowed.count != original.media.count else { return original }
            var copy = original
            copy.attachments = allowed.isEmpty ? nil : allowed
            if original.role == .user { copy.text += "\n[以前の添付は現在のモデルでは読み込んでいません。]" }
            return copy
        }
    }
    public struct Unavailable: LocalizedError, Sendable {
        public let message: String
        public init(message: String) { self.message = message }
        public var errorDescription: String? { message }
    }
}

/// The picker can finish after its sheet is dismissed or the model changes.
/// Bind its result to the conversation that opened it, not the current screen.
public struct AttachmentImportContext: Equatable, Sendable {
    public let threadID: UUID?
    public let modelID: String
    public init(threadID: UUID?, modelID: String) { self.threadID = threadID; self.modelID = modelID }
    public func matches(threadID: UUID?, modelID: String) -> Bool {
        self.threadID != nil && self.threadID == threadID && self.modelID == modelID
    }
}
