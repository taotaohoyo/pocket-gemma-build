import Foundation

/// Product availability is separate from a model's architectural capabilities.
/// Re-enable E4B here only after device validation; do not change its model pin.
public struct ModelAttachmentPolicy: Sendable {
    public let modelID: String
    public init(model: ModelSpec) { modelID = model.id }
    private static let suspendedAttachmentModels: Set<String> = [ModelSpec.e4b.id]
    public var isTemporarilyLocked: Bool { Self.suspendedAttachmentModels.contains(modelID) }
    public var allowsImages: Bool {
        [ModelSpec.e2b.id, ModelSpec.e4b.id].contains(modelID) && !isTemporarilyLocked
    }
    public var allowsTextFiles: Bool { !isTemporarilyLocked }
    public var allowsAnyAttachment: Bool { allowsImages || allowsTextFiles }
    public var summary: String {
        if isTemporarilyLocked { return "テキスト · 添付は調整中" }
        return allowsImages ? "テキスト・写真・TXT" : "テキスト・TXT"
    }
    public var guidance: String {
        if isTemporarilyLocked {
            return "添付は現在調整中です。画像の利用にはGemma 4 E2Bへ切り替えてください。テキストでの会話は引き続き利用できます。"
        }
        return allowsImages ? "現在は写真とTXTファイルを利用できます。カメラ・動画・その他の形式は調整中です。"
            : "現在はTXTファイルを利用できます。画像の利用にはGemma 4 E2Bへ切り替えてください。"
    }
    public func allows(_ attachment: ChatAttachment) -> Bool {
        switch attachment.kind {
        case .image:
            return allowsImages && attachment.imageNames.count == 1
                && attachment.extractedText == nil
        case .video: return false
        case .file:
            return allowsTextFiles && attachment.imageNames.isEmpty
                && (attachment.name as NSString).pathExtension.lowercased() == "txt"
                && !(attachment.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ?? true)
        }
    }
    public func validateNewAttachments(_ attachments: [ChatAttachment]) throws {
        guard attachments.allSatisfy(allows) else { throw Unavailable(message: guidance) }
    }
    /// Keep the saved archive intact. Old unsupported media must never silently
    /// re-enable vision when a reader sends a text reply in an existing thread.
    public func inferenceHistory(_ messages: [ChatMessage]) -> [ChatMessage] {
        messages.map { original in
            let allowed = original.media.filter(allows)
            guard allowed.count != original.media.count else { return original }
            var copy = original
            copy.attachments = allowed.isEmpty ? nil : allowed
            if original.role == .user { copy.text += "\n[以前の添付は現在のモデルでは読み込んでいません。]" }
            return copy
        }
    }
    public struct Unavailable: LocalizedError, Sendable {
        public let message: String
        public var errorDescription: String? { message }
    }
}
