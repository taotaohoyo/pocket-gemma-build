import Foundation

/// What a model is offered right now: its capabilities (ModelCapabilities)
/// minus inputs still being checked on device. Re-enable E4B photos here only
/// after device validation; do not change its model pin.
public struct ModelAttachmentPolicy: Sendable {
    public let modelID: String
    public let capabilities: ModelCapabilities
    public init(model: ModelSpec) { modelID = model.id; capabilities = model.capabilities }
    /// E4B's image path failed on device (VISION-*.md). Files are read into
    /// text and never reach the vision encoder, so they stay available.
    private static let suspendedPhotoModels: Set<String> = [ModelSpec.e4b.id]
    public var photosSuspended: Bool { capabilities.photos == .native && Self.suspendedPhotoModels.contains(modelID) }
    public var allowsImages: Bool { capabilities.photos == .native && !photosSuspended }
    /// A text-only model takes a photo's text, read on the device, as text.
    public var readsPhotoText: Bool { capabilities.photos == .textRecognition }
    /// The photo item opens the picker: the model's own vision, or OCR.
    public var allowsPhotos: Bool { allowsImages || readsPhotoText }
    public var allowsDocuments: Bool { capabilities.documents }
    public var allowsAnyAttachment: Bool { allowsPhotos || allowsDocuments }
    public static let documentFormats = "TXT・Markdown・PDF・CSV・JSON・Word"
    public var summary: String {
        if photosSuspended { return "テキスト・ファイル · 写真は調整中" }
        if allowsImages { return allowsDocuments ? "テキスト・写真・ファイル" : "テキスト・写真" }
        if readsPhotoText { return allowsDocuments ? "テキスト・ファイル・写真の文字" : "テキスト・写真の文字" }
        return allowsDocuments ? "テキスト・ファイル" : "テキスト"
    }
    public var guidance: String {
        let files = "ファイル（\(Self.documentFormats)）は端末内で本文の文字だけを読み取り、モデルに渡します。"
        if photosSuspended {
            return "このモデルの写真は現在調整中です。写真を使うにはGemma 4 E2Bへ切り替えてください。" + (allowsDocuments ? files : "")
        }
        if allowsImages {
            return "写真を利用できます。" + (allowsDocuments ? files : "") + "カメラ・動画は調整中です。"
        }
        if readsPhotoText {
            return "このモデルはテキスト専用で、写真の見た目（人物・物・色など）は理解できません。写真は端末内の文字認識で、写っている文字だけを読み取って渡します。写真の内容を見てほしいときはGemma 4 E2Bへ切り替えてください。"
                + (allowsDocuments ? files : "")
        }
        return "このモデルはテキスト専用で、写真の中身を読み取れません。写真を使うにはGemma 4 E2Bへ切り替えてください。"
            + (allowsDocuments ? files : "")
    }
    public func allows(_ attachment: ChatAttachment) -> Bool {
        switch attachment.kind {
        case .image:
            if allowsImages { return attachment.imageNames.count == 1 && attachment.extractedText == nil }
            // Only the photo's recognized text, never its pixels.
            return readsPhotoText && attachment.imageNames.isEmpty && hasText(attachment)
        case .video: return false
        case .file:
            // Only extracted text: a file kind must never carry images.
            return allowsDocuments && attachment.imageNames.isEmpty && hasText(attachment)
        }
    }
    private func hasText(_ attachment: ChatAttachment) -> Bool {
        !(attachment.extractedText?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ?? true)
    }
    public func validateNewAttachments(_ attachments: [ChatAttachment]) throws {
        guard attachments.allSatisfy(allows) else { throw Unavailable(message: guidance) }
    }
    /// Keep the saved archive intact. Old unsupported media must never silently
    /// re-enable vision when a reader sends a text reply in an existing thread.
    public func inferenceHistory(_ messages: [ChatMessage]) -> [ChatMessage] {
        messages.map { original in
            let allowed = original.media.filter(allows)
            guard allowed.count != original.media.count else { return original }
            var copy = original
            copy.attachments = allowed.isEmpty ? nil : allowed
            if original.role == .user { copy.text += "\n[以前の添付は現在のモデルでは読み込んでいません。]" }
            return copy
        }
    }
    public struct Unavailable: LocalizedError, Sendable {
        public let message: String
        public init(message: String) { self.message = message }
        public var errorDescription: String? { message }
    }
}

/// The picker can finish after its sheet is dismissed or the model changes.
/// Bind its result to the conversation that opened it, not the current screen.
public struct AttachmentImportContext: Equatable, Sendable {
    public let threadID: UUID?
    public let modelID: String
    public init(threadID: UUID?, modelID: String) { self.threadID = threadID; self.modelID = modelID }
    public func matches(threadID: UUID?, modelID: String) -> Bool {
        self.threadID != nil && self.threadID == threadID && self.modelID == modelID
    }
}
