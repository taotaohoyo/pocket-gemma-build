import Foundation

public enum CodeTokenKind: String, Sendable, CaseIterable {
    case plain, keyword, type, string, number, comment, function, attribute, tag, property, inserted, deleted, heading
}

public struct CodeToken: Equatable, Sendable {
    public var kind: CodeTokenKind
    public var text: String
}

/// Colors code in replies by language: keywords, types, strings, numbers,
/// comments and so on, with a small scanner per language family instead
/// of a JavaScript highlighter. The tokens always join back into the code
/// exactly as written, so copying is unaffected.
public enum SyntaxHighlighter {
    /// Longer code is shown without colors.
    public static let maximumLength = 200_000

    /// The language's name for the code block header, or nil when unknown.
    /// Languages without colors still get their name (`toml` is "TOML").
    public static func displayName(for hint: String?) -> String? {
        if let name = language(for: hint)?.name { return name }
        return normalizedHint(hint).flatMap { plainNames[$0] }
    }

    /// A file name extension for sharing the code as a file.
    public static func fileExtension(for hint: String?) -> String {
        guard let name = language(for: hint)?.name else {
            return normalizedHint(hint).flatMap { plainExtensions[$0] } ?? "txt"
        }
        return extensions[name] ?? "txt"
    }

    /// `language-python`, `{.python}`, `python:main.py` and `py title=x`
    /// all name a language by their first word.
    static func normalizedHint(_ hint: String?) -> String? {
        guard var word = hint?.trimmingCharacters(in: .whitespaces).lowercased()
            .split(separator: " ").first.map(String.init) else { return nil }
        word = word.trimmingCharacters(in: CharacterSet(charactersIn: "{}."))
        for prefix in ["language-", "lang-"] where word.hasPrefix(prefix) { word.removeFirst(prefix.count) }
        if let colon = word.firstIndex(of: ":"), colon > word.startIndex { word = String(word[..<colon]) }
        return word.isEmpty ? nil : word
    }

    private static let extensions: [String: String] = [
        "Swift": "swift", "Python": "py", "JavaScript": "js", "TypeScript": "ts", "Java": "java", "Kotlin": "kt",
        "C": "c", "C++": "cpp", "Objective-C": "m", "C#": "cs", "Go": "go", "Rust": "rs", "Ruby": "rb", "PHP": "php",
        "Shell": "sh", "SQL": "sql", "JSON": "json", "YAML": "yml", "CSS": "css", "Dart": "dart", "Lua": "lua",
        "R": "r", "HTML": "html", "XML": "xml", "Diff": "diff", "Markdown": "md",
    ]

    /// Languages shown by name but without colors.
    static let plainNames: [String: String] = [
        "toml": "TOML", "ini": "INI", "cfg": "INI", "dockerfile": "Dockerfile", "docker": "Dockerfile",
        "makefile": "Makefile", "make": "Makefile", "powershell": "PowerShell", "ps1": "PowerShell", "pwsh": "PowerShell",
        "graphql": "GraphQL", "gql": "GraphQL", "proto": "Protocol Buffers", "protobuf": "Protocol Buffers",
        "scala": "Scala", "haskell": "Haskell", "hs": "Haskell", "tex": "TeX", "latex": "LaTeX", "zig": "Zig",
        "cmake": "CMake", "text": "テキスト", "txt": "テキスト", "plaintext": "テキスト", "plain": "テキスト",
        "csv": "CSV", "tsv": "TSV", "nginx": "nginx", "elixir": "Elixir", "erlang": "Erlang", "clojure": "Clojure",
        "perl": "Perl", "julia": "Julia", "matlab": "MATLAB", "asm": "アセンブリ", "assembly": "アセンブリ",
        "vb": "Visual Basic", "vba": "VBA", "fortran": "Fortran", "groovy": "Groovy", "gradle": "Gradle",
        "terraform": "Terraform", "hcl": "HCL", "solidity": "Solidity", "verilog": "Verilog", "vhdl": "VHDL",
        "regex": "正規表現", "mermaid": "Mermaid", "env": ".env", "properties": "Properties", "http": "HTTP",
        "applescript": "AppleScript", "ocaml": "OCaml", "fsharp": "F#", "f#": "F#", "elm": "Elm", "lisp": "Lisp",
        "scheme": "Scheme", "prolog": "Prolog", "cobol": "COBOL", "pascal": "Pascal", "nim": "Nim", "crystal": "Crystal",
    ]

    private static let plainExtensions: [String: String] = [
        "toml": "toml", "ini": "ini", "cfg": "cfg", "dockerfile": "Dockerfile", "makefile": "Makefile",
        "powershell": "ps1", "ps1": "ps1", "graphql": "graphql", "proto": "proto", "scala": "scala", "haskell": "hs",
        "hs": "hs", "tex": "tex", "latex": "tex", "zig": "zig", "cmake": "cmake", "csv": "csv", "tsv": "tsv",
        "perl": "pl", "julia": "jl", "matlab": "m", "groovy": "groovy", "gradle": "gradle", "terraform": "tf",
        "solidity": "sol", "elixir": "ex", "erlang": "erl", "clojure": "clj", "ocaml": "ml", "fsharp": "fs",
    ]

    // MARK: Detection

    /// A language for code that names none, from unmistakable signs only: a
    /// shebang, a diff or XML header, JSON that parses, `import SwiftUI`,
    /// `def …:` and so on. Nil when nothing is certain.
    public static func detectedLanguage(_ code: String) -> String? {
        let sample = String(code.prefix(4_000))
        let trimmed = sample.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count > 1 else { return nil }
        let lines = trimmed.split(separator: "\n").prefix(40)
            .map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        func any(_ test: (String) -> Bool) -> Bool { lines.contains(where: test) }
        if let first = lines.first, first.hasPrefix("#!") {
            if first.contains("python") { return "python" }
            if first.contains("node") { return "javascript" }
            if first.contains("ruby") { return "ruby" }
            if first.contains("sh") { return "bash" }
            return nil
        }
        if trimmed.hasPrefix("diff --git")
            || (any { $0.hasPrefix("@@ ") && $0.dropFirst(3).contains("@@") } && any { $0.hasPrefix("--- ") || $0.hasPrefix("+++ ") }) {
            return "diff"
        }
        let lowered = trimmed.lowercased()
        if lowered.hasPrefix("<?xml") { return "xml" }
        if lowered.hasPrefix("<!doctype html") || lowered.hasPrefix("<html") { return "html" }
        if let first = trimmed.first, first == "{" || first == "[", code.utf8.count <= 100_000,
           let data = code.trimmingCharacters(in: .whitespacesAndNewlines).data(using: .utf8),
           (try? JSONSerialization.jsonObject(with: data)) != nil {
            return "json"
        }
        let firstWord = lines.first?.split(separator: " ").first.map { $0.uppercased() } ?? ""
        let upper = trimmed.uppercased()
        if ["SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "ALTER", "DROP", "WITH"].contains(firstWord),
           [" FROM ", " INTO ", " TABLE ", " SET ", "\nFROM ", "\nSET "].contains(where: upper.contains) {
            return "sql"
        }
        if any({ $0.hasPrefix("package ") }) && trimmed.contains("func ") { return "go" }
        if any({ ["import SwiftUI", "import UIKit", "import Foundation", "import Combine"].contains($0) })
            || (trimmed.contains("func ") && trimmed.contains("->") && !trimmed.contains("fn ")) {
            return "swift"
        }
        if trimmed.contains("fn main()") || (trimmed.contains("fn ") && trimmed.contains("let mut ")) { return "rust" }
        if trimmed.contains("public static void main") || any({ $0.hasPrefix("public class ") }) { return "java" }
        if any({ $0.hasPrefix("#include") }) {
            return trimmed.contains("std::") || trimmed.contains("<iostream>") ? "cpp" : "c"
        }
        if any({ ($0.hasPrefix("def ") || $0.hasPrefix("class ")) && $0.hasSuffix(":") })
            || any({ $0.hasPrefix("from ") && $0.contains(" import ") })
            || (any { $0.hasPrefix("import ") } && trimmed.contains("print(")) {
            return "python"
        }
        if trimmed.contains("console.log(")
            || (any { $0.hasPrefix("const ") || $0.hasPrefix("let ") } && (trimmed.contains("=>") || trimmed.contains("function "))) {
            return "javascript"
        }
        let commands = lines.filter { !$0.hasPrefix("#") }
        if !commands.isEmpty, commands.count <= 20, commands.allSatisfy({ line in
            // `export default App;` is JavaScript.
            line.hasPrefix("$ ") || (shellCommands.contains(String(line.split(separator: " ").first ?? ""))
                                     && !line.hasSuffix(";") && !line.hasSuffix("{"))
        }) {
            return "bash"
        }
        return nil
    }

    /// Commands that start a line of a shell session.
    private static let shellCommands: Set<String> = [
        "brew", "npm", "npx", "yarn", "pnpm", "pip", "pip3", "git", "cd", "sudo", "apt", "apt-get", "curl", "wget",
        "mkdir", "ls", "export", "echo", "chmod", "docker", "xcodebuild", "cargo", "make", "ssh", "rm", "cp", "mv",
        "touch", "cat", "source", "conda", "pod", "gem", "bundle", "kubectl", "xcrun", "defaults", "open",
    ]

    public static func tokens(_ code: String, language hint: String?) -> [CodeToken] {
        guard !code.isEmpty else { return [] }
        guard code.utf8.count <= maximumLength, let language = language(for: hint) else {
            return [CodeToken(kind: .plain, text: code)]
        }
        var scanner = TokenScanner(Array(code.unicodeScalars))
        switch language.mode {
        case .code(let grammar): scanner.scanCode(grammar)
        case .markup: scanner.scanMarkup()
        case .diff: scanner.scanLines(diff: true)
        case .markdown: scanner.scanLines(diff: false)
        }
        return scanner.tokens
    }

    // MARK: Languages

    struct Grammar {
        var keywords: Set<String> = []
        var types: Set<String> = []
        var lineComments: [String] = []
        var blockComments: [(String, String)] = []
        var strings: [String] = ["\"", "'"]
        var multilineStrings: [String] = []
        var capitalizedTypes = true
        var caseInsensitive = false
        var attributePrefixes: Set<Unicode.Scalar> = []
        var identifierExtras: Set<Unicode.Scalar> = []
        var variablePrefix: Unicode.Scalar?
        /// JSON, YAML and CSS: a name before `:` is a property.
        var colonKeys = false
        /// CSS colors such as `#fff`.
        var hashNumbers = false
        /// Rust macros such as `println!`.
        var macroBang = false
    }

    enum Mode { case code(Grammar), markup, diff, markdown }

    struct Language { let name: String; let mode: Mode }

    private static func words(_ list: String) -> Set<String> { Set(list.split(separator: " ").map(String.init)) }

    private static let cKeywords = "auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while bool true false NULL nullptr"
    private static let javaScriptKeywords = "break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield async await of static get set null undefined true false NaN Infinity from as"

    static func language(for hint: String?) -> Language? {
        guard let hint = normalizedHint(hint) else { return nil }
        let slash: [String] = ["//"], cBlock = [("/*", "*/")]
        switch hint {
        case "swift":
            return Language(name: "Swift", mode: .code(Grammar(
                keywords: words("associatedtype class deinit enum extension fileprivate func import init inout internal let open operator private precedencegroup protocol public rethrows static struct subscript typealias var break case catch continue default defer do else fallthrough for guard if in repeat return throw switch where while as Any await async false is nil self Self super throws true try some any actor nonisolated isolated mutating nonmutating override final lazy weak unowned convenience required dynamic indirect optional get set willSet didSet package macro consuming borrowing"),
                lineComments: slash, blockComments: cBlock, strings: ["\""], multilineStrings: ["\"\"\""],
                attributePrefixes: ["@", "#"])))
        case "python", "py", "python3", "py3":
            return Language(name: "Python", mode: .code(Grammar(
                keywords: words("and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case False None True self"),
                types: words("int float str bool list dict set tuple bytes object type range complex frozenset"),
                lineComments: ["#"], multilineStrings: ["\"\"\"", "'''"], attributePrefixes: ["@"])))
        case "javascript", "js", "jsx", "mjs", "cjs", "node":
            return Language(name: "JavaScript", mode: .code(Grammar(
                keywords: words(javaScriptKeywords), lineComments: slash, blockComments: cBlock,
                multilineStrings: ["`"], attributePrefixes: ["@"], identifierExtras: ["$"])))
        case "typescript", "ts", "tsx":
            return Language(name: "TypeScript", mode: .code(Grammar(
                keywords: words(javaScriptKeywords + " interface type enum implements namespace declare abstract private protected public readonly is keyof infer satisfies override"),
                types: words("string number boolean any unknown never void object symbol bigint"),
                lineComments: slash, blockComments: cBlock, multilineStrings: ["`"],
                attributePrefixes: ["@"], identifierExtras: ["$"])))
        case "java":
            return Language(name: "Java", mode: .code(Grammar(
                keywords: words("abstract assert break case catch class const continue default do else enum extends final finally for goto if implements import instanceof interface native new package private protected public return static strictfp super switch synchronized this throw throws transient try volatile while var record sealed permits yield true false null"),
                types: words("int long short byte char float double boolean void"),
                lineComments: slash, blockComments: cBlock, multilineStrings: ["\"\"\""], attributePrefixes: ["@"])))
        case "kotlin", "kt", "kts":
            return Language(name: "Kotlin", mode: .code(Grammar(
                keywords: words("as break class continue do else false for fun if in interface is null object package return super this throw true try typealias val var when while by catch constructor finally get import init set where abstract annotation companion const data enum external final infix inline inner internal lateinit open operator out override private protected public reified sealed suspend tailrec vararg"),
                lineComments: slash, blockComments: cBlock, multilineStrings: ["\"\"\""], attributePrefixes: ["@"])))
        case "c", "h":
            return Language(name: "C", mode: .code(Grammar(
                keywords: words(cKeywords), types: words("size_t int8_t int16_t int32_t int64_t uint8_t uint16_t uint32_t uint64_t FILE"),
                lineComments: slash, blockComments: cBlock, capitalizedTypes: false, attributePrefixes: ["#"])))
        case "cpp", "c++", "cc", "cxx", "hpp", "hh":
            return Language(name: "C++", mode: .code(Grammar(
                keywords: words(cKeywords + " alignas alignof and asm catch class constexpr const_cast decltype delete dynamic_cast explicit export friend mutable namespace new noexcept operator or not private protected public reinterpret_cast static_assert static_cast template this thread_local throw try typeid typename using virtual co_await co_return co_yield concept requires override final"),
                types: words("string vector map set unordered_map size_t auto"),
                lineComments: slash, blockComments: cBlock, attributePrefixes: ["#"])))
        case "objective-c", "objc", "objectivec", "m", "mm":
            return Language(name: "Objective-C", mode: .code(Grammar(
                keywords: words(cKeywords + " self super nil Nil YES NO id instancetype interface implementation end property synthesize protocol selector import nonatomic strong weak copy readonly"),
                lineComments: slash, blockComments: cBlock, attributePrefixes: ["#", "@"])))
        case "csharp", "cs", "c#":
            return Language(name: "C#", mode: .code(Grammar(
                keywords: words("abstract as base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly ref return sbyte sealed short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using virtual void volatile while var async await record init get set yield where"),
                lineComments: slash, blockComments: cBlock, attributePrefixes: ["#"])))
        case "go", "golang":
            return Language(name: "Go", mode: .code(Grammar(
                keywords: words("break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil iota"),
                types: words("int int8 int16 int32 int64 uint uint8 uint16 uint32 uint64 uintptr float32 float64 complex64 complex128 byte rune string bool error any"),
                lineComments: slash, blockComments: cBlock, multilineStrings: ["`"])))
        case "rust", "rs":
            return Language(name: "Rust", mode: .code(Grammar(
                keywords: words("as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while"),
                types: words("i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str"),
                lineComments: slash, blockComments: cBlock, strings: ["\""], macroBang: true)))
        case "ruby", "rb":
            return Language(name: "Ruby", mode: .code(Grammar(
                keywords: words("alias and begin break case class def do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield require attr_accessor attr_reader puts"),
                lineComments: ["#"], attributePrefixes: ["@"])))
        case "php":
            return Language(name: "PHP", mode: .code(Grammar(
                keywords: words("abstract and array as break callable case catch class clone const continue declare default do echo else elseif empty extends final finally fn for foreach function global if implements include include_once instanceof interface isset list match namespace new or print private protected public readonly require require_once return static switch throw trait try unset use var while xor yield true false null"),
                lineComments: ["//", "#"], blockComments: cBlock, variablePrefix: "$")))
        case "bash", "sh", "shell", "zsh", "console", "terminal", "shellscript", "fish":
            return Language(name: "Shell", mode: .code(Grammar(
                keywords: words("if then else elif fi case esac for select while until do done in function time return exit export local readonly declare unset shift break continue source alias echo cd sudo"),
                lineComments: ["#"], capitalizedTypes: false, identifierExtras: ["-"], variablePrefix: "$")))
        case "sql", "mysql", "postgresql", "postgres", "sqlite", "plsql":
            return Language(name: "SQL", mode: .code(Grammar(
                keywords: words("select from where and or not insert into values update set delete create table drop alter add column primary key foreign references index view join inner left right outer full on group by order having limit offset as distinct union all exists in is null like between case when then else end default unique check constraint begin commit rollback transaction if returning with asc desc true false"),
                types: words("integer int text varchar char boolean real date timestamp numeric decimal serial bigint"),
                lineComments: ["--"], blockComments: cBlock, strings: ["'", "\""], capitalizedTypes: false, caseInsensitive: true)))
        case "json", "jsonc", "json5":
            return Language(name: "JSON", mode: .code(Grammar(
                keywords: words("true false null"), lineComments: slash, blockComments: cBlock,
                strings: ["\""], capitalizedTypes: false, colonKeys: true)))
        case "yaml", "yml":
            return Language(name: "YAML", mode: .code(Grammar(
                keywords: words("true false null yes no on off"), lineComments: ["#"],
                capitalizedTypes: false, identifierExtras: ["-"], colonKeys: true)))
        case "css", "scss", "less":
            return Language(name: "CSS", mode: .code(Grammar(
                keywords: words("important inherit initial unset auto none"), lineComments: hint == "css" ? [] : slash,
                blockComments: cBlock, capitalizedTypes: false, attributePrefixes: ["@"],
                identifierExtras: ["-"], colonKeys: true, hashNumbers: true)))
        case "dart":
            return Language(name: "Dart", mode: .code(Grammar(
                keywords: words("abstract as assert async await break case catch class const continue covariant default deferred do dynamic else enum export extends extension external factory false final finally for get hide if implements import in interface is late library mixin new null on operator part required rethrow return set show static super switch sync this throw true try typedef var void while with yield"),
                lineComments: slash, blockComments: cBlock, multilineStrings: ["\"\"\"", "'''"], attributePrefixes: ["@"])))
        case "lua":
            return Language(name: "Lua", mode: .code(Grammar(
                keywords: words("and break do else elseif end false for function goto if in local nil not or repeat return then true until while"),
                lineComments: ["--"], blockComments: [("--[[", "]]")], capitalizedTypes: false)))
        case "r":
            return Language(name: "R", mode: .code(Grammar(
                keywords: words("if else repeat while function for in next break TRUE FALSE NULL Inf NaN NA return library"),
                lineComments: ["#"], capitalizedTypes: false)))
        case "html", "xml", "svg", "xhtml", "plist", "vue", "xaml":
            return Language(name: hint == "xml" || hint == "plist" ? "XML" : "HTML", mode: .markup)
        case "diff", "patch":
            return Language(name: "Diff", mode: .diff)
        case "markdown", "md":
            return Language(name: "Markdown", mode: .markdown)
        default:
            return nil
        }
    }

    // MARK: Scanning

    struct TokenScanner {
        let scalars: [Unicode.Scalar]
        var tokens: [CodeToken] = []
        init(_ scalars: [Unicode.Scalar]) { self.scalars = scalars }

        mutating func emit(_ kind: CodeTokenKind, _ start: Int, _ end: Int) {
            guard end > start else { return }
            var text = String.UnicodeScalarView()
            text.append(contentsOf: scalars[start..<end])
            if let last = tokens.last, last.kind == kind {
                tokens[tokens.count - 1].text += String(text)
            } else {
                tokens.append(CodeToken(kind: kind, text: String(text)))
            }
        }

        func starts(_ pattern: [Unicode.Scalar], at index: Int) -> Bool {
            guard !pattern.isEmpty, index + pattern.count <= scalars.count else { return false }
            for offset in pattern.indices where scalars[index + offset] != pattern[offset] { return false }
            return true
        }

        func find(_ pattern: [Unicode.Scalar], from index: Int) -> Int? {
            var position = index
            while position + pattern.count <= scalars.count {
                if starts(pattern, at: position) { return position }
                position += 1
            }
            return nil
        }

        func nextNonSpace(after index: Int) -> Unicode.Scalar? {
            var position = index
            while position < scalars.count, scalars[position] == " " || scalars[position] == "\t" { position += 1 }
            return position < scalars.count ? scalars[position] : nil
        }

        static func isLetter(_ scalar: Unicode.Scalar) -> Bool {
            scalar.properties.isAlphabetic || scalar == "_"
        }
        static func isDigit(_ scalar: Unicode.Scalar) -> Bool { ("0"..."9").contains(scalar) }

        mutating func scanCode(_ grammar: Grammar) {
            let blockComments = grammar.blockComments.map { (Array($0.0.unicodeScalars), Array($0.1.unicodeScalars)) }
            let lineComments = grammar.lineComments.map { Array($0.unicodeScalars) }
            let multiline = grammar.multilineStrings.map { Array($0.unicodeScalars) }
            let delimiters = (multiline + grammar.strings.map { Array($0.unicodeScalars) })
                .sorted { $0.count > $1.count }
            func identifierScalar(_ scalar: Unicode.Scalar) -> Bool {
                Self.isLetter(scalar) || Self.isDigit(scalar) || grammar.identifierExtras.contains(scalar)
            }
            var index = 0
            var plainStart = 0
            scanning: while index < scalars.count {
                let scalar = scalars[index]
                for (open, close) in blockComments where starts(open, at: index) {
                    emit(.plain, plainStart, index)
                    let end = find(close, from: index + open.count).map { $0 + close.count } ?? scalars.count
                    emit(.comment, index, end)
                    index = end; plainStart = end
                    continue scanning
                }
                for marker in lineComments where starts(marker, at: index) {
                    emit(.plain, plainStart, index)
                    var end = index
                    while end < scalars.count, scalars[end] != "\n" { end += 1 }
                    emit(.comment, index, end)
                    index = end; plainStart = end
                    continue scanning
                }
                for delimiter in delimiters where starts(delimiter, at: index) {
                    emit(.plain, plainStart, index)
                    let spansLines = multiline.contains(delimiter)
                    var end = index + delimiter.count
                    while end < scalars.count {
                        if scalars[end] == "\\" { end += 2; continue }
                        if starts(delimiter, at: end) { end += delimiter.count; break }
                        if scalars[end] == "\n", !spansLines { break }
                        end += 1
                    }
                    end = min(end, scalars.count)
                    let isKey = grammar.colonKeys && nextNonSpace(after: end) == ":"
                    emit(isKey ? .property : .string, index, end)
                    index = end; plainStart = end
                    continue scanning
                }
                let previous: Unicode.Scalar? = index > 0 ? scalars[index - 1] : nil
                let followedByDigit = index + 1 < scalars.count && Self.isDigit(scalars[index + 1])
                if Self.isDigit(scalar) || (scalar == "." && followedByDigit) || (grammar.hashNumbers && scalar == "#" && index + 1 < scalars.count && scalars[index + 1].properties.isASCIIHexDigit),
                   !(previous.map(identifierScalar) ?? false) {
                    emit(.plain, plainStart, index)
                    var end = index + 1
                    while end < scalars.count {
                        let next = scalars[end]
                        if identifierScalar(next) || next == "." { end += 1; continue }
                        if (next == "+" || next == "-"), end > index, scalars[end - 1] == "e" || scalars[end - 1] == "E",
                           !(scalars[index...].starts(with: ["0", "x"])) { end += 1; continue }
                        break
                    }
                    emit(.number, index, end)
                    index = end; plainStart = end
                    continue
                }
                if let prefix = grammar.variablePrefix, scalar == prefix, index + 1 < scalars.count,
                   identifierScalar(scalars[index + 1]) || scalars[index + 1] == "{" {
                    emit(.plain, plainStart, index)
                    var end = index + 1
                    if scalars[end] == "{" {
                        while end < scalars.count, scalars[end] != "}", scalars[end] != "\n" { end += 1 }
                        end = min(end + 1, scalars.count)
                    } else {
                        while end < scalars.count, identifierScalar(scalars[end]) { end += 1 }
                    }
                    emit(.property, index, end)
                    index = end; plainStart = end
                    continue
                }
                if grammar.attributePrefixes.contains(scalar), index + 1 < scalars.count, Self.isLetter(scalars[index + 1]),
                   !(previous.map(identifierScalar) ?? false) {
                    emit(.plain, plainStart, index)
                    var end = index + 1
                    while end < scalars.count, identifierScalar(scalars[end]) { end += 1 }
                    emit(.attribute, index, end)
                    index = end; plainStart = end
                    continue
                }
                if Self.isLetter(scalar) || (grammar.identifierExtras.contains(scalar) && scalar != "-") {
                    emit(.plain, plainStart, index)
                    var end = index + 1
                    while end < scalars.count, identifierScalar(scalars[end]) { end += 1 }
                    var word = String.UnicodeScalarView()
                    word.append(contentsOf: scalars[index..<end])
                    let text = String(word)
                    let key = grammar.caseInsensitive ? text.lowercased() : text
                    let next = nextNonSpace(after: end)
                    let kind: CodeTokenKind
                    if grammar.keywords.contains(key) { kind = .keyword }
                    else if grammar.types.contains(key) { kind = .type }
                    else if grammar.colonKeys, next == ":", !(end + 1 < scalars.count && scalars[end + 1] == ":") { kind = .property }
                    else if grammar.capitalizedTypes, let first = text.unicodeScalars.first,
                            first.properties.isUppercase, text.count > 1 { kind = .type }
                    else if next == "(" || (grammar.macroBang && end < scalars.count && scalars[end] == "!") { kind = .function }
                    else { kind = .plain }
                    emit(kind, index, end)
                    index = end; plainStart = end
                    continue
                }
                index += 1
            }
            emit(.plain, plainStart, scalars.count)
        }

        /// HTML and XML: tags, attributes, values and comments.
        mutating func scanMarkup() {
            let commentOpen = Array("<!--".unicodeScalars), commentClose = Array("-->".unicodeScalars)
            var index = 0
            var plainStart = 0
            while index < scalars.count {
                if starts(commentOpen, at: index) {
                    emit(.plain, plainStart, index)
                    let end = find(commentClose, from: index + 4).map { $0 + 3 } ?? scalars.count
                    emit(.comment, index, end)
                    index = end; plainStart = end
                    continue
                }
                guard scalars[index] == "<", index + 1 < scalars.count,
                      Self.isLetter(scalars[index + 1]) || "/?!".unicodeScalars.contains(scalars[index + 1]) else {
                    index += 1
                    continue
                }
                emit(.plain, plainStart, index)
                var end = index + 1
                while end < scalars.count, "/?!".unicodeScalars.contains(scalars[end]) { end += 1 }
                while end < scalars.count, Self.isLetter(scalars[end]) || Self.isDigit(scalars[end]) || ":-.".unicodeScalars.contains(scalars[end]) { end += 1 }
                emit(.tag, index, end)
                index = end
                // Attributes up to the end of the tag.
                while index < scalars.count, scalars[index] != ">" {
                    let scalar = scalars[index]
                    if scalar == "\"" || scalar == "'" {
                        var close = index + 1
                        while close < scalars.count, scalars[close] != scalar { close += 1 }
                        close = min(close + 1, scalars.count)
                        emit(.string, index, close)
                        index = close
                    } else if Self.isLetter(scalar) {
                        var close = index + 1
                        while close < scalars.count, Self.isLetter(scalars[close]) || Self.isDigit(scalars[close]) || ":-.".unicodeScalars.contains(scalars[close]) { close += 1 }
                        emit(.attribute, index, close)
                        index = close
                    } else {
                        emit(.plain, index, index + 1)
                        index += 1
                    }
                }
                if index < scalars.count {
                    emit(.tag, index, index + 1)
                    index += 1
                }
                plainStart = index
            }
            emit(.plain, plainStart, scalars.count)
        }

        /// Diff lines by their first character; Markdown headings.
        mutating func scanLines(diff: Bool) {
            var start = 0
            while start < scalars.count {
                var end = start
                while end < scalars.count, scalars[end] != "\n" { end += 1 }
                let lineEnd = min(end + 1, scalars.count)
                let first = start < end ? scalars[start] : nil
                let kind: CodeTokenKind
                if diff {
                    if starts(Array("+++".unicodeScalars), at: start) || starts(Array("---".unicodeScalars), at: start)
                        || starts(Array("diff ".unicodeScalars), at: start) || starts(Array("index ".unicodeScalars), at: start) {
                        kind = .comment
                    } else if first == "+" { kind = .inserted }
                    else if first == "-" { kind = .deleted }
                    else if starts(Array("@@".unicodeScalars), at: start) { kind = .keyword }
                    else { kind = .plain }
                } else {
                    kind = first == "#" ? .heading : first == ">" ? .comment : .plain
                }
                emit(kind, start, lineEnd)
                start = lineEnd
            }
        }
    }
}
