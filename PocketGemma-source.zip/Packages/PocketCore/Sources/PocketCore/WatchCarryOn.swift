import Foundation

/// When the Apple Watch app asks the iPhone to go on with its answer
/// (WatchLink.carryOn, 2026-10-24). Away from the screen the iPhone writes
/// the watch's answers on the CPU in the background time iOS gives it,
/// about 30 seconds, and a longer answer pauses there. Each message from
/// the watch wakes Fielua for another stretch, so the watch asks for the
/// rest: again after every round that wrote more, once more after a round
/// that wrote nothing (the iPhone may still have been stopping the last
/// one), and at most `maximumRounds` times. Then the answer waits for
/// Fielua to be opened on the iPhone, as before. Foundation only: the
/// watch app compiles this file itself (it has no PocketCore).
public struct WatchCarryOn: Equatable, Sendable {
    /// About five minutes of writing on the CPU, longer than E2B's answers.
    public static let maximumRounds = 16
    /// The answer's length when the watch last asked; -1 before it asked.
    public private(set) var length = -1
    public private(set) var rounds = 0
    /// Rounds in a row after which the answer was no longer.
    public private(set) var idle = 0

    public init() {}

    /// Whether to ask now for the rest of an answer paused at `length`
    /// characters. `again`: the watch app is back on screen, a new chance
    /// after rounds that wrote nothing.
    public mutating func ask(at length: Int, again: Bool = false) -> Bool {
        let idle = length > self.length || again ? 0 : self.idle + 1
        guard idle < 2, rounds < Self.maximumRounds else { return false }
        self.idle = idle
        self.length = length
        rounds += 1
        return true
    }
}
