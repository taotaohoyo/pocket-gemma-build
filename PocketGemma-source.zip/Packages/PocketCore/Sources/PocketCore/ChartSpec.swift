import Foundation

/// A chart from a ```chart block: a bar, line or pie chart of a series of
/// values, or of a few series side by side, each item a label and its
/// values. Only what the block says is drawn: no value is filled in,
/// rounded, scaled or reordered, and a block that does not hold up is not
/// drawn at all (`RichBlockError`).
public struct ChartSpec: Equatable, Sendable {
    public enum Kind: String, Equatable, Sendable, CaseIterable {
        case bar, line, pie

        /// What the chart is called, on its card and to VoiceOver.
        public var name: String {
            switch self {
            case .bar: return String(localized: "棒グラフ")
            case .line: return String(localized: "折れ線グラフ")
            case .pie: return String(localized: "円グラフ")
            }
        }
    }

    public struct Item: Equatable, Sendable {
        public var label: String
        /// One value per series; nil where the data gives none (bar and
        /// line charts only).
        public var values: [Double?]

        public init(label: String, values: [Double?]) {
            self.label = label
            self.values = values
        }
    }

    public var kind: Kind
    public var title: String
    public var unit: String
    /// The series' names, one for each value of every item. A single
    /// series may have no name.
    public var series: [String]
    public var items: [Item]

    public init(kind: Kind, title: String = "", unit: String = "", series: [String] = [""], items: [Item]) {
        self.kind = kind
        self.title = title
        self.unit = unit
        self.series = series
        self.items = items
    }

    public var isSingleSeries: Bool { series.count == 1 }

    // MARK: Limits

    /// The most items each kind shows legibly on a phone.
    public static func maximumItems(_ kind: Kind, series: Int) -> Int {
        switch kind {
        case .bar: return series <= 1 ? 30 : max(1, 60 / series)
        case .line: return 120
        case .pie: return 12
        }
    }

    public static let maximumSeries = 4
    /// Longest title and label, in characters; a unit is shorter.
    static let maximumText = 200
    static let maximumUnit = 40
    /// Larger values are not a chart's (a model's runaway digits).
    static let maximumMagnitude = 1e15

    // MARK: Parsing

    /// The block's JSON checked and read. Accepted shapes: items
    /// (`"data":[{"label":"東京","value":1400}]`, or `"values":[…]` with
    /// `"series":[…]` names), parallel `"labels"` (or a single series' labels
    /// misnamed `"series"`) and `"values"`, and
    /// Chart.js's `"labels"` and `"datasets"`. JSON5 is read too (trailing
    /// commas, comments), and a word before the object or a note after it is
    /// left out. Numbers may be written as text with thousands grouped by
    /// commas (`"1,400"`); text with a unit in it (`"12%"`) is not a number.
    public static func parse(_ source: String) -> Result<ChartSpec, RichBlockError> {
        guard source.utf8.count <= RichBlocks.sourceLimit else { return .failure(.tooLarge) }
        guard let open = source.firstIndex(of: "{"), let close = source.lastIndex(of: "}"), open < close,
              let object = try? JSONSerialization.jsonObject(with: Data(source[open...close].utf8), options: [.json5Allowed]),
              let root = object as? [String: Any] else { return .failure(.unreadable) }
        guard let typeName = text(root["type"] ?? root["chartType"] ?? root["kind"]) else { return .failure(.missingType) }
        guard let kind = Self.kind(named: typeName) else { return .failure(.unknownType(typeName)) }
        let title = text(root["title"]) ?? ""
        let unit = text(root["unit"]) ?? ""
        guard title.count <= maximumText, unit.count <= maximumUnit else { return .failure(.textTooLong) }

        let table: RawTable
        switch rawTable(root) {
        case .success(let found): table = found
        case .failure(let error): return .failure(error)
        }
        guard !table.labels.isEmpty, !table.series.isEmpty else { return .failure(.noData) }
        guard table.labels.allSatisfy({ $0.count <= maximumText }),
              table.series.allSatisfy({ $0.count <= maximumText }) else { return .failure(.textTooLong) }
        let seriesLimit = kind == .pie ? 1 : maximumSeries
        guard table.series.count <= seriesLimit else { return .failure(.tooManySeries(limit: seriesLimit)) }
        let itemLimit = maximumItems(kind, series: table.series.count)
        guard table.labels.count <= itemLimit else { return .failure(.tooManyItems(limit: itemLimit)) }

        var items: [Item] = []
        for (label, raw) in zip(table.labels, table.rows) {
            var values: [Double?] = []
            for value in raw {
                if value is NSNull, kind != .pie {
                    values.append(nil)
                    continue
                }
                guard let number = Self.number(value) else { return .failure(.notANumber(label: label)) }
                if kind == .pie, number < 0 { return .failure(.negativeInPie(label: label)) }
                values.append(number)
            }
            items.append(Item(label: label, values: values))
        }
        guard items.contains(where: { $0.values.contains { $0 != nil } }) else { return .failure(.noData) }
        if kind == .pie, items.reduce(0.0, { $0 + ($1.values.first.flatMap { $0 } ?? 0) }) <= 0 {
            return .failure(.emptyPie)
        }
        return .success(ChartSpec(kind: kind, title: title, unit: unit, series: table.series, items: items))
    }

    /// The kind a block's `"type"` names, in the words models use for it.
    static func kind(named name: String) -> Kind? {
        switch name.lowercased() {
        case "bar", "bars", "column", "columns", "棒", "棒グラフ": return .bar
        case "line", "lines", "折れ線", "折れ線グラフ": return .line
        case "pie", "donut", "doughnut", "円", "円グラフ": return .pie
        default: return nil
        }
    }

    /// Labels, series names and each item's values as the JSON has them.
    private struct RawTable {
        var labels: [String]
        var series: [String]
        var rows: [[Any]]
    }

    private static func rawTable(_ root: [String: Any]) -> Result<RawTable, RichBlockError> {
        if let items = root["data"] as? [Any] {
            return itemTable(items, names: root["series"])
        }
        // Parallel arrays, at the top or inside "data" as Chart.js has them.
        let container = (root["data"] as? [String: Any]) ?? root
        guard let labelValues = container["labels"] as? [Any] ?? seriesAsLabels(container) else { return .failure(.noData) }
        var labels: [String] = []
        for (index, value) in labelValues.enumerated() {
            guard let label = text(value) else { return .failure(.missingLabel(index + 1)) }
            labels.append(label)
        }
        var names: [String] = []
        var columns: [[Any]] = []
        if let sets = (container["datasets"] ?? container["series"]) as? [Any], !sets.isEmpty,
           sets.allSatisfy({ $0 is [String: Any] }) {
            for case let set as [String: Any] in sets {
                guard let values = (set["data"] ?? set["values"]) as? [Any] else { return .failure(.noData) }
                names.append(text(set["label"] ?? set["name"]) ?? "")
                columns.append(values)
            }
        } else if let values = container["values"] as? [Any] {
            names = [text(container["name"]) ?? ""]
            columns = [values]
        } else {
            return .failure(.noData)
        }
        guard columns.allSatisfy({ $0.count == labels.count }) else { return .failure(.countMismatch) }
        let rows = labels.indices.map { row in columns.map { $0[row] } }
        return .success(RawTable(labels: labels, series: seriesNames(names), rows: rows))
    }

    /// One series' labels written as `"series"` beside a flat `"values"` of
    /// the same length, with no `"labels"` (E2B, three charts in one reply).
    /// Series names need items to belong to, so these can only be labels.
    private static func seriesAsLabels(_ container: [String: Any]) -> [Any]? {
        guard let names = container["series"] as? [Any], let values = container["values"] as? [Any],
              names.count == values.count, names.allSatisfy({ $0 is String }),
              !values.contains(where: { $0 is [Any] || $0 is [String: Any] }) else { return nil }
        return names
    }

    private static func itemTable(_ items: [Any], names: Any?) -> Result<RawTable, RichBlockError> {
        var labels: [String] = []
        var rows: [[Any]] = []
        var width: Int?
        for (index, element) in items.enumerated() {
            guard let item = element as? [String: Any] else { return .failure(.unreadable) }
            guard let label = text(item["label"] ?? item["name"] ?? item["x"] ?? item["category"]) else {
                return .failure(.missingLabel(index + 1))
            }
            let values: [Any]
            if let many = item["values"] as? [Any] {
                values = many
            } else if let one = item["value"] ?? item["y"] {
                values = [one]
            } else {
                return .failure(.notANumber(label: label))
            }
            if let width, width != values.count { return .failure(.seriesMismatch(label: label)) }
            width = values.count
            labels.append(label)
            rows.append(values)
        }
        guard let width, width > 0 else { return .failure(.noData) }
        var given: [String] = []
        if let list = names as? [Any] {
            given = list.map { text($0) ?? "" }
            guard given.count == width else { return .failure(.seriesMismatch(label: labels[0])) }
        } else {
            given = Array(repeating: "", count: width)
        }
        return .success(RawTable(labels: labels, series: seriesNames(given), rows: rows))
    }

    /// Series names for the legend: several series each get a name (系列2)
    /// and no two share one; a single series may stay unnamed.
    private static func seriesNames(_ names: [String]) -> [String] {
        guard names.count > 1 else { return names.isEmpty ? [""] : names }
        var used: Set<String> = []
        return names.enumerated().map { index, name in
            let base = name.isEmpty ? String(localized: "系列\(index + 1)") : name
            var result = base
            var copy = 2
            while used.contains(result) {
                result = String(localized: "\(base)（\(copy)）")
                copy += 1
            }
            used.insert(result)
            return result
        }
    }

    /// A label, title or name: text with its line breaks as spaces, or a
    /// number as the data writes it (a year, 2024).
    private static func text(_ value: Any?) -> String? {
        if let string = value as? String {
            let trimmed = string.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespaces)
            return trimmed.isEmpty ? nil : trimmed
        }
        if let number = value as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            let double = number.doubleValue
            return double.isFinite ? plain(double) : nil
        }
        return nil
    }

    static func number(_ value: Any) -> Double? {
        var result: Double?
        if let number = value as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() {
            result = number.doubleValue
        } else if let string = value as? String {
            result = number(fromText: string)
        }
        guard let result, result.isFinite, abs(result) <= maximumMagnitude else { return nil }
        return result
    }

    /// A number written as text: full-width digits read as digits, and
    /// commas only where they group thousands.
    static func number(fromText text: String) -> Double? {
        var digits = text.precomposedStringWithCompatibilityMapping
            .replacingOccurrences(of: "\u{2212}", with: "-")
            .trimmingCharacters(in: .whitespaces)
        if digits.contains(",") {
            guard digits.range(of: #"^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$"#, options: .regularExpression) != nil else { return nil }
            digits.removeAll { $0 == "," }
        }
        guard digits.range(of: #"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$"#, options: .regularExpression) != nil else { return nil }
        return Double(digits)
    }

    // MARK: Text

    /// A value as the data gives it, every digit kept: `1400`, `12.5`;
    /// with thousands grouped, `1,400`.
    public static func plain(_ value: Double, grouped: Bool = false) -> String {
        guard value != 0 else { return "0" }
        var text: String
        if value == value.rounded(), abs(value) < 1e15 {
            text = String(Int64(value))
        } else {
            text = "\(value)"
            if text.contains("e") {
                text = String(format: "%.12f", value)
                while text.hasSuffix("0") { text.removeLast() }
                if text.hasSuffix(".") { text.removeLast() }
            }
        }
        guard grouped else { return text }
        let negative = text.hasPrefix("-")
        if negative { text.removeFirst() }
        let parts = text.split(separator: ".", maxSplits: 1, omittingEmptySubsequences: false)
        var whole = String(parts[0])
        var result = ""
        while whole.count > 3 {
            result = "," + String(whole.suffix(3)) + result
            whole = String(whole.dropLast(3))
        }
        result = whole + result
        if parts.count > 1 { result += "." + String(parts[1]) }
        return (negative ? "-" : "") + result
    }

    /// A value with its unit, as the chart shows it: `1,400万人`; a missing
    /// value is a dash.
    public func display(_ value: Double?) -> String {
        guard let value else { return "—" }
        return Self.plain(value, grouped: true) + unit
    }

    /// The pie's whole: every slice's value added up.
    public var total: Double {
        items.reduce(0.0) { $0 + ($1.values.first.flatMap { $0 } ?? 0) }
    }

    /// A slice's share of the pie, as a percentage with one decimal: `35.0%`.
    public func percentage(_ index: Int) -> String {
        guard items.indices.contains(index), let value = items[index].values.first.flatMap({ $0 }), total > 0 else { return "" }
        return String(format: "%.1f%%", value / total * 100)
    }

    /// What the chart shows when nothing is picked: the largest bar, a
    /// line's first and last values, or a pie's total.
    public var overview: String {
        guard isSingleSeries else { return String(localized: "項目をタップすると数値を表示します") }
        let known = items.compactMap { item in item.values[0].map { (label: item.label, value: $0) } }
        switch kind {
        case .bar:
            guard let largest = known.max(by: { $0.value < $1.value }) else { return "" }
            return String(localized: "最大：\(largest.label) \(display(largest.value))")
        case .line:
            guard let first = known.first, let last = known.last else { return "" }
            if known.count == 1 { return String(localized: "\(first.label)：\(display(first.value))") }
            return "\(first.label) \(display(first.value)) → \(last.label) \(display(last.value))"
        case .pie:
            return String(localized: "合計：\(display(total))")
        }
    }

    /// What the chart shows for a picked item: `東京：1,400万人`, with its
    /// share in a pie chart and every series' value when there are several.
    public func readout(at index: Int) -> String {
        guard items.indices.contains(index) else { return overview }
        let item = items[index]
        if isSingleSeries {
            let share = kind == .pie ? String(localized: "（\(percentage(index))）") : ""
            return String(localized: "\(item.label)：\(display(item.values[0]))\(share)")
        }
        let values = zip(series, item.values).map { "\($0) \(display($1))" }
        return String(localized: "\(item.label)：\(values.joined(separator: String(localized: "・")))")
    }

    // MARK: Copying

    /// The headers of the value columns: the series' names (or 値) with the
    /// unit.
    private var valueHeaders: [String] {
        series.map { name in
            let header = name.isEmpty ? String(localized: "値") : name
            return unit.isEmpty ? header : String(localized: "\(header)（\(unit)）")
        }
    }

    /// The chart's data as a Markdown table under its title, in its order,
    /// with each value as written: what the chart was drawn from.
    public var markdown: String {
        func cell(_ text: String) -> String { text.replacingOccurrences(of: "|", with: "\\|") }
        func line(_ cells: [String]) -> String { "| " + cells.joined(separator: " | ") + " |" }
        var lines = [line([String(localized: "項目")] + valueHeaders.map(cell)), line(["---"] + valueHeaders.map { _ in "--:" })]
        lines += items.map { item in
            line([cell(item.label)] + item.values.map { $0.map { Self.plain($0) } ?? "" })
        }
        let table = lines.joined(separator: "\n")
        return title.isEmpty ? table : title + "\n\n" + table
    }

    /// The data as tab-separated cells, which Numbers, Excel and Google
    /// Sheets paste into cells.
    public var tabSeparated: String {
        func cell(_ text: String) -> String { text.replacingOccurrences(of: "\t", with: " ") }
        let header = ([String(localized: "項目")] + valueHeaders).map(cell).joined(separator: "\t")
        let rows = items.map { item in
            ([cell(item.label)] + item.values.map { $0.map { Self.plain($0) } ?? "" }).joined(separator: "\t")
        }
        return ([header] + rows).joined(separator: "\n")
    }

    // MARK: VoiceOver

    /// What VoiceOver says on reaching the chart: "棒グラフ、都道府県別の人口、
    /// 5項目、単位 万人".
    public var spokenSummary: String {
        var parts = [kind.name]
        if !title.isEmpty { parts.append(title) }
        parts.append(String(localized: "\(items.count)項目"))
        if !isSingleSeries { parts.append(String(localized: "系列 \(series.joined(separator: String(localized: "、")))")) }
        if !unit.isEmpty { parts.append(String(localized: "単位 \(unit)")) }
        return parts.joined(separator: String(localized: "、"))
    }

    /// A mark's label for VoiceOver: the item, and its series when there
    /// are several.
    public func spokenLabel(_ index: Int, series column: Int = 0) -> String {
        guard items.indices.contains(index) else { return "" }
        let label = items[index].label
        return isSingleSeries || !series.indices.contains(column) ? label : String(localized: "\(label)、\(series[column])")
    }

    /// An item for VoiceOver: "東京、1,400万人", with each series' value and a
    /// pie slice's share ("35.0パーセント").
    public func spokenItem(_ index: Int) -> String {
        guard items.indices.contains(index) else { return "" }
        let item = items[index]
        if isSingleSeries {
            let share = kind == .pie ? String(localized: "、\(percentage(index).replacingOccurrences(of: "%", with: ""))パーセント") : ""
            return String(localized: "\(item.label)、\(display(item.values[0]))\(share)")
        }
        return ([item.label] + zip(series, item.values).map { "\($0) \(display($1))" }).joined(separator: String(localized: "、"))
    }

    // MARK: Layout

    /// Whether bars stand upright: a few items with short labels fit under
    /// upright bars on a phone; more, or longer labels, read better as rows.
    public var prefersColumns: Bool {
        guard kind == .bar, items.count <= 6, items.count * series.count <= 12 else { return false }
        return items.allSatisfy { Self.width(of: $0.label) <= 8 }
    }

    /// A label's width in half-width units: wide characters (Japanese,
    /// emoji) count two.
    static func width(of text: String) -> Int {
        text.unicodeScalars.reduce(0) { $0 + ($1.value < 0x1100 ? 1 : 2) }
    }

    /// The value axis: zero (for bars and pies, and for a line when its
    /// values come near it) and every value, with `headroom` above the
    /// largest for its label, rounded out to round numbers, so the axis does
    /// not move while the marks grow in.
    public func valueRange(headroom: Double = 0.1) -> ClosedRange<Double> {
        let values = items.flatMap(\.values).compactMap { $0 }
        let smallest = values.min() ?? 0, largest = values.max() ?? 0
        let zero = kind != .line || (smallest >= 0 && smallest <= largest / 2)
            || (largest <= 0 && largest >= smallest / 2) || (smallest < 0 && largest > 0)
        var low = zero ? min(0, smallest) : smallest
        var high = zero ? max(0, largest) : largest
        if high == low {
            if high == 0 { high = 1 } else { low -= abs(low) * 0.1; high += abs(high) * 0.1 }
        }
        let room = (high - low) * headroom
        if high > 0 || !zero { high += room }
        if low < 0 || !zero { low -= room }
        let step = Self.roundStep((high - low) / 4)
        return (floor(low / step) * step)...(ceil(high / step) * step)
    }

    /// A round step near `raw`: 1, 2, 2.5 or 5 times a power of ten.
    static func roundStep(_ raw: Double) -> Double {
        guard raw > 0, raw.isFinite else { return 1 }
        let base = pow(10, floor(log10(raw)))
        let fraction = raw / base
        let round: Double = fraction <= 1 ? 1 : fraction <= 2 ? 2 : fraction <= 2.5 ? 2.5 : fraction <= 5 ? 5 : 10
        return round * base
    }

    /// The items whose labels the category axis of a line chart shows: at
    /// most `maximum`, evenly spaced from the first, and the last when it is
    /// not crowded by the one before.
    public func tickIndices(maximum: Int) -> [Int] {
        let count = items.count
        guard count > 0 else { return [] }
        let step = max(1, Int((Double(count) / Double(max(1, maximum))).rounded(.up)))
        var ticks = Array(stride(from: 0, to: count, by: step))
        if let last = ticks.last, last != count - 1 {
            if count - 1 - last >= max(1, step / 2) { ticks.append(count - 1) } else { ticks[ticks.count - 1] = count - 1 }
        }
        return ticks
    }

    /// A value axis label: grouped digits, without the unit (the card says
    /// it).
    public static func axisLabel(_ value: Double) -> String {
        abs(value) < 1e-9 ? "0" : plain((value * 1e6).rounded() / 1e6, grouped: true)
    }

    /// A label shortened to `width` half-width units for an axis; the
    /// readout, VoiceOver and copying keep the whole label.
    public static func shortened(_ label: String, width: Int) -> String {
        guard Self.width(of: label) > width else { return label }
        var result = ""
        var used = 0
        for character in label {
            let size = Self.width(of: String(character))
            guard used + size <= width - 1 else { break }
            result.append(character)
            used += size
        }
        return result + "…"
    }

    /// The kind and title of a chart block still arriving, from what has
    /// come of it, for its placeholder.
    public static func peek(_ partial: String) -> (kind: Kind?, title: String?) {
        func string(after key: String) -> String? {
            guard let found = partial.range(of: "\"\(key)\"") else { return nil }
            let rest = partial[found.upperBound...].drop(while: { $0 == " " || $0 == ":" || $0 == "\t" || $0 == "\n" })
            guard rest.first == "\"" else { return nil }
            let body = rest.dropFirst()
            guard let end = body.firstIndex(of: "\"") else { return nil }
            let value = String(body[..<end])
            return value.isEmpty || value.contains("\\") ? nil : value
        }
        let title = string(after: "title").map { String($0.prefix(maximumText)) }
        return (string(after: "type").flatMap { Self.kind(named: $0) }, title)
    }
}
