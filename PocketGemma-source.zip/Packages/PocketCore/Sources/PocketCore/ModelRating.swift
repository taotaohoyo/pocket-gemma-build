import Foundation

/// 回答の速さ on モデル管理's cards (1.1.0 (225), fielua-reports Issue #4):
/// one word of five for how fast a model writes once it has begun, read
/// from the tokens a second someone measured on an iPhone. It says nothing
/// about how clever or right a model is, nor how big its file is.
public enum ReplySpeed: Int, CaseIterable, Comparable, Sendable {
    case verySlow = 1, slow, fast, veryFast, fastest

    /// Japanese reads at about 8 to 10 characters a second and Gemma
    /// writes about 1.7 of them a token, so 5 tokens a second is about
    /// reading pace: under it かなりゆっくり, then ゆっくり to 12, 速い to
    /// 20, とても速い to 40 and 高速 from there.
    public init(tokensPerSecond: Double) {
        switch tokensPerSecond {
        case 40...: self = .fastest
        case 20...: self = .veryFast
        case 12...: self = .fast
        case 5...: self = .slow
        default: self = .verySlow
        }
    }

    public var label: String {
        switch self {
        case .verySlow: String(localized: "かなりゆっくり")
        case .slow: String(localized: "ゆっくり")
        case .fast: String(localized: "速い")
        case .veryFast: String(localized: "とても速い")
        // 「高速」 alone is already 高速・深く's (GenerationSettings).
        case .fastest: String(localized: "回答の速さ・高速", defaultValue: "高速")
        }
    }

    /// A card's word when nothing measured backs one.
    public static var unratedLabel: String { String(localized: "未評価") }

    public static func < (lhs: ReplySpeed, rhs: ReplySpeed) -> Bool { lhs.rawValue < rhs.rawValue }
}

/// What a card's 回答の速さ rests on: a speed measured on an iPhone with
/// the file Fielua downloads, by its distributor or by Fielua, or, for a
/// model that always thinks before it answers, that design. Models no one
/// has timed on an iPhone have none and read 未評価.
public struct SpeedEvidence: Equatable, Sendable {
    public enum Source: Sendable {
        /// The distributor's model card (litert-community on Hugging Face).
        case distributor
        /// Measured with Fielua on the developer's iPhone.
        case fielua
        /// Not timed on an iPhone: the model writes its thoughts first.
        case reasoning
    }

    public let speed: ReplySpeed
    public let source: Source
    /// Decoding speed in tokens a second, where one was measured.
    public let tokensPerSecond: Double?
    /// The iPhone it was measured on ("iPhone 17 Pro").
    public let device: String
    /// "GPU" or "CPU": the one Fielua runs the model on.
    public let processor: String

    init(_ tokensPerSecond: Double, on device: String, _ processor: String, by source: Source) {
        self.speed = ReplySpeed(tokensPerSecond: tokensPerSecond); self.source = source
        self.tokensPerSecond = tokensPerSecond; self.device = device; self.processor = processor
    }
    init(reasoningOn processor: String) {
        speed = .verySlow; source = .reasoning; tokensPerSecond = nil; device = ""; self.processor = processor
    }

    /// One line for the card's 詳細.
    public var basis: String {
        let rounded = Int((tokensPerSecond ?? 0).rounded())
        switch source {
        case .distributor: return String(localized: "\(device)の\(processor)で毎秒約\(rounded)トークン（配布元の公開値）")
        case .fielua: return String(localized: "\(device)の\(processor)で毎秒約\(rounded)トークン（Fieluaの実測）")
        case .reasoning: return String(localized: "答える前に毎回考えるため、返信が始まるまで時間がかかります。iPhoneでの測定値はまだありません。")
        }
    }

    /// The card's 詳細 for a model without evidence.
    public static var noneBasis: String { String(localized: "iPhoneでの測定値はまだありません。") }

    /// The evidence for each model Fielua offers (2026-10-28). The
    /// distributor's figures are its iPhone 17 Pro rows (1024 tokens in,
    /// 256 out, warm caches); 12B is TestFlight 199 on the developer's
    /// iPhone 18 Pro (iPhone19,2), 2026-10-26. Qwen3 0.6B's file has no
    /// figures at all and Qwen2.5 1.5B only Android ones, so none.
    public static func of(_ model: ModelSpec) -> SpeedEvidence? {
        switch model.id {
        case ModelSpec.e2b.id: SpeedEvidence(56.5, on: "iPhone 17 Pro", "GPU", by: .distributor)
        case ModelSpec.e4b.id: SpeedEvidence(25.1, on: "iPhone 17 Pro", "GPU", by: .distributor)
        case ModelSpec.gemma12B.id: SpeedEvidence(15.9, on: "iPhone 18 Pro", "GPU", by: .fielua)
        // The Mixed INT4 file Fielua downloads, on the CPU it runs on.
        case ModelSpec.qwen35.id: SpeedEvidence(8.9, on: "iPhone 17 Pro", "CPU", by: .distributor)
        // Up to 1,536 tokens of thoughts before every answer (205).
        case ModelSpec.phi4MiniReasoning.id: SpeedEvidence(reasoningOn: "CPU")
        default: nil
        }
    }
}

/// 端末への負担 on モデル管理's cards (1.1.0 (225)): how much of this
/// device the model takes while it runs, in three words. Unlike 必要メモリ
/// (the same estimate for every device) or 保存容量 (the file), it depends
/// on the device: the share of its memory the estimate takes, a step up
/// for a model that works on the CPU with its weights held in memory
/// (Phi-4-mini-reasoning, Qwen3.5 4B: all cores for long stretches, and
/// they warmed the phone in 205).
public enum DeviceBurden: Int, CaseIterable, Comparable, Sendable {
    case low = 1, moderate, high

    public init(memoryShare: Double, holdsCPUWeights: Bool) {
        let level: DeviceBurden = memoryShare < 0.4 ? .low : memoryShare < 0.6 ? .moderate : .high
        self = holdsCPUWeights ? DeviceBurden(rawValue: min(level.rawValue + 1, DeviceBurden.high.rawValue))! : level
    }

    public var label: String {
        switch self {
        case .low: String(localized: "小さい")
        case .moderate: String(localized: "普通")
        case .high: String(localized: "大きい")
        }
    }

    /// The row's name: the device in the reader's hand.
    public static func title(isPad: Bool) -> String {
        isPad ? String(localized: "iPadへの負担") : String(localized: "iPhoneへの負担")
    }

    public static func < (lhs: DeviceBurden, rhs: DeviceBurden) -> Bool { lhs.rawValue < rhs.rawValue }
}
