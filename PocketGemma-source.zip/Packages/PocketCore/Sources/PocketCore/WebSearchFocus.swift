import Foundation

/// What a question searches for, kept exact on its way to Tavily and back
/// (1.1.0 (208)). On the phone E4B turned 「iOS27.2っていつ更新されるのー？」
/// into the search 「iOS 17.2 更新時期」 and answered in English that there
/// was nothing on iOS 27.2 (205, 2026-10-27): the model takes iOS 17 for
/// the latest, nothing between its call and Tavily kept the question's own
/// version, the first three pages went to the model whatever they were
/// about, and the reply's language was only described, never named.
///
/// The question's versions, model numbers, years, dates and (in a question
/// in Japanese, Chinese or Korean) Latin-script names are read here once.
/// The query keeps them (`repair`), the pages are ranked by whether they
/// name them, by official sites and by date (`select`), an off-target or
/// stale search is made once more (`retry`), and the model is told which
/// pages are about what was asked (WebSearch.toolResponse).
public struct SearchTarget: Equatable, Sendable {
    public struct Anchor: Equatable, Sendable {
        public enum Kind: String, Sendable {
            /// A name and its number: "iOS 27.2", "iPhone 18", "Gemma 4".
            case version
            /// Letters and digits in one word: "E2B", "A19", "SM-S938N".
            case token
            /// A number with a point and no name: "27.2", "3.13".
            case number
            case year, date
            /// A Latin-script word in a question in another script: "Pixel".
            case name
        }
        /// As a query writes it: "iOS 27.2", "E2B", "2026", "10月27日".
        public var text: String
        public var kind: Kind
        /// A version's name ("iOS") and number ("27.2").
        public var name: String?
        public var number: String?

        /// Whether a page that doesn't name it is about something else.
        /// Years, dates, plain numbers and names only rank pages.
        public var identifies: Bool { kind == .version || kind == .token }
        /// Whether a query that left it out gets it back. A name the model
        /// wrote another way (Pixel as ピクセル) still searches the same.
        var restores: Bool { kind != .name }

        /// The ways a page may write it: "iOS 27.2", "iOS27.2", "iOS-27.2".
        var variants: [String] {
            guard let name, let number else { return [text, text.replacingOccurrences(of: " ", with: "")] }
            return ["\(name) \(number)", "\(name)\(number)", "\(name)-\(number)"]
        }
    }

    public var anchors: [Anchor]
    /// Versions and years the person's last messages named, newest first,
    /// for a follow-up that doesn't name its own ("それはいつ出るの？"). The
    /// replies' are left out: a reply may have named the wrong version.
    public var earlier: [Anchor]
    /// The question's language named in English ("Japanese"), as the video
    /// note names it (VideoDigest.replyLanguage); nil when too short to tell.
    public var language: String?
    /// The question asks for the newest information: the latest or today's,
    /// or when a version it names comes out or is updated.
    public var wantsLatest: Bool
    public var today: Date

    /// `earlier` is the person's last messages before the question, newest
    /// first.
    public init(question: String, earlier context: [String] = [], language: String? = nil, today: Date = Date()) {
        anchors = Self.anchors(in: question)
        earlier = context.flatMap { Self.anchors(in: $0) }.filter { $0.kind == .version || $0.kind == .year }
        self.language = language ?? VideoDigest.replyLanguage(of: question)
        let folded = question.precomposedStringWithCompatibilityMapping.lowercased()
        let names = anchors.contains { $0.kind == .version || $0.kind == .number }
        wantsLatest = Self.latestWords.contains { folded.contains($0) }
            || names && Self.releaseWords.contains { folded.contains($0) }
        self.today = today
    }

    public var isEmpty: Bool { anchors.isEmpty && earlier.isEmpty }
    /// What a page must name to be about the question: "iOS 27.2".
    public var identifying: [Anchor] { anchors.filter(\.identifies) }

    /// What a page must name to be about what `query` searches: the
    /// question's own, and for a follow-up the earlier version the query
    /// names (after `repair`), so a follow-up on another topic asks nothing.
    public func identifying(for query: String?) -> [Anchor] {
        var names = Set(anchors.compactMap { $0.name?.lowercased() })
        let follow = earlier.filter { anchor in
            guard anchor.kind == .version, let name = anchor.name?.lowercased(), names.insert(name).inserted else { return false }
            return query.map { Self.range(of: anchor, in: $0) != nil } ?? false
        }
        return identifying + follow
    }

    // MARK: The query

    /// The model's query with the question's own words put back: a changed
    /// version gets the question's number again, one left out comes first,
    /// and a year older than this one goes when the latest is asked for and
    /// neither the question nor the chat named it.
    public func repair(_ query: String) -> String {
        var query = query, prefix: [String] = []
        for anchor in anchors where anchor.restores && Self.range(of: anchor, in: query) == nil {
            if let range = replaceable(anchor, in: query) {
                query.replaceSubrange(range, with: anchor.text)
            } else {
                prefix.append(anchor.text)
            }
        }
        // A follow-up's query that changed the version the chat was about:
        // the newest message's version of each name.
        var names = Set(anchors.compactMap { $0.name?.lowercased() })
        for anchor in earlier where anchor.kind == .version {
            guard let name = anchor.name, names.insert(name.lowercased()).inserted,
                  Self.range(of: anchor, in: query) == nil,
                  let range = Self.versionRanges(of: name, in: query).first else { continue }
            query.replaceSubrange(range.whole, with: anchor.text)
        }
        if wantsLatest && !anchors.contains(where: { $0.kind == .year || $0.kind == .date }) {
            let year = Calendar(identifier: .gregorian).component(.year, from: today)
            let named = Set(earlier.filter { $0.kind == .year }.map(\.text))
            var kept = "", from = query.startIndex
            for range in Self.matches(#"(?<![0-9])(19|20)[0-9]{2}(?![0-9])"#, in: query) {
                let found = String(query[range])
                guard let value = Int(found), value < year, !named.contains(found) else { continue }
                kept += query[from..<range.lowerBound]
                from = range.upperBound
            }
            query = kept + query[from...]
        }
        return WebSearch.normalizedQuery((prefix + [query]).joined(separator: " ")) ?? query
    }

    /// Where the query wrote something else in the anchor's place: its name
    /// with another number, its name alone, or another number of the same
    /// shape (17.2 for 27.2); another year for its year. Numbers the
    /// question names itself ("iOS 27.1と27.2") stay.
    private func replaceable(_ anchor: Anchor, in query: String) -> Range<String.Index>? {
        let taken = Set(anchors.compactMap { $0.kind == .year ? $0.text : $0.number })
        switch anchor.kind {
        case .version:
            guard let name = anchor.name, let number = anchor.number else { return nil }
            if let found = Self.versionRanges(of: name, in: query).first(where: { !taken.contains($0.number) }) { return found.whole }
            if let word = Self.matches("(?<![A-Za-z0-9])" + NSRegularExpression.escapedPattern(for: name) + "(?![A-Za-z])",
                                       in: query, caseInsensitive: true).first { return word }
            return number.contains(".") ? Self.sameShape(as: number, in: query, skipping: taken) : nil
        case .number:
            return anchor.number.flatMap { Self.sameShape(as: $0, in: query, skipping: taken) }
        case .year:
            return Self.matches(#"(?<![0-9])(19|20)[0-9]{2}(?![0-9])"#, in: query).first { !taken.contains(String(query[$0])) }
        default:
            return nil
        }
    }

    private static func sameShape(as number: String, in query: String, skipping taken: Set<String>) -> Range<String.Index>? {
        let dots = number.filter { $0 == "." }.count
        return matches(#"(?<![A-Za-z0-9.])[0-9]+(\.[0-9]+)+(?![0-9.]*[0-9])"#, in: query).first {
            let found = String(query[$0])
            return found.filter { $0 == "." }.count == dots && !taken.contains(found)
        }
    }

    // MARK: The pages

    /// The pages the model reads, best first: those that name what was
    /// asked, then official sites and (for the latest) newer dates, then
    /// Tavily's order. A page about another version (iOS 17.2 for 27.2) is
    /// left out; `excluding` leaves out pages an earlier search of the reply
    /// already gave.
    public func select(_ hits: [WebSearchHit], query: String? = nil, excluding given: Set<String> = [],
                       limit: Int = WebSearch.resultLimit) -> WebSearchFindings {
        var seen = given
        let fresh = hits.filter { seen.insert($0.url).inserted }
        let ids = identifying(for: query)
        var others: [String] = []
        let scored: [(hit: WebSearchHit, about: Bool, score: Double)] = fresh.enumerated().compactMap { index, hit in
            let text = hit.title + " " + hit.text
            let named = ids.filter { Self.range(of: $0, in: text) != nil }
            let about = named.count == ids.count
            if !about {
                let elsewhere = ids.filter { !named.contains($0) }.flatMap { Self.otherVersions(of: $0, in: text) }
                if !elsewhere.isEmpty {
                    for other in elsewhere where !others.contains(other) { others.append(other) }
                    return nil
                }
            }
            var score = ids.isEmpty ? 0 : about ? 100 : 30 * Double(named.count) / Double(ids.count)
            score += 10 * Double(anchors.filter { !$0.identifies && Self.range(of: $0, in: text) != nil }.count)
            if isOfficial(hit.url) { score += wantsLatest ? 30 : 15 }
            if wantsLatest, let published = hit.published {
                let days = today.timeIntervalSince(published) / 86_400
                score += days <= 90 ? 20 : days <= 365 ? 8 : days > 730 ? -20 : 0
            }
            return (hit, about, score - 4 * Double(index))
        }
        let chosen = scored.enumerated().sorted { ($0.element.score, -$0.offset) > ($1.element.score, -$1.offset) }
            .prefix(limit).map { $0.element }
        // Old pages count only where nothing identifies the target: a
        // version's pages are as old as the version.
        let dated = chosen.compactMap { $0.hit.published }
        let stale = wantsLatest && ids.isEmpty && !dated.isEmpty && dated.allSatisfy { today.timeIntervalSince($0) > 365 * 86_400 }
        return WebSearchFindings(hits: chosen.map { $0.hit }, about: chosen.map { ids.isEmpty || $0.about },
                                 others: Array(others.prefix(3)), stale: stale, asked: ids.map(\.text))
    }

    /// One more search when this one missed: with what was asked as an
    /// exact phrase when no page named it, or limited to the past year when
    /// every dated page was older. nil when it found what was asked.
    public func retry(after findings: WebSearchFindings, query: String) -> TavilyQuery? {
        let ids = identifying(for: query)
        if findings.identifies && findings.matched == 0 && !ids.isEmpty {
            var rest = query
            for anchor in ids {
                while let range = Self.range(of: anchor, in: rest) { rest.replaceSubrange(range, with: " ") }
            }
            let phrases = ids.map { "\"\($0.text)\"" }
            guard let exact = WebSearch.normalizedQuery((phrases + [rest]).joined(separator: " ")) else { return nil }
            var retry = TavilyQuery(exact)
            retry.exactMatch = true
            return retry
        }
        if findings.stale {
            var retry = TavilyQuery(query)
            retry.timeRange = "year"
            return retry
        }
        return nil
    }

    /// The first place the page's text names what was asked, to show the
    /// model that part of it (WebSearch.snippet).
    public func firstMention(in text: String) -> String.Index? {
        (anchors + earlier.filter { $0.kind == .version }).compactMap { Self.range(of: $0, in: text)?.lowerBound }.min()
    }

    /// The question names the maker's site for what it asks about, or the
    /// page is a government's or a university's.
    func isOfficial(_ url: String) -> Bool {
        guard let host = URL(string: url)?.host?.lowercased() else { return false }
        if Self.publicSuffixes.contains(where: { host.hasSuffix($0) }) { return true }
        let words = (anchors + earlier).map { ($0.name ?? $0.text).lowercased() }
        let domains = Self.officialSites.filter { site in site.names.contains { name in words.contains(name) } }.flatMap { $0.domains }
        return domains.contains { host == $0 || host.hasSuffix("." + $0) }
    }

    // MARK: Reading the words

    static func anchors(in text: String) -> [Anchor] {
        let text = text.precomposedStringWithCompatibilityMapping
        let otherScript = text.unicodeScalars.contains {
            (0x3040...0x30FF).contains($0.value) || (0x3400...0x9FFF).contains($0.value) || (0xAC00...0xD7AF).contains($0.value)
        }
        var found: [Anchor] = []
        func add(_ anchor: Anchor) {
            let key = anchor.text.lowercased().replacingOccurrences(of: " ", with: "")
            if !found.contains(where: { $0.text.lowercased().replacingOccurrences(of: " ", with: "") == key }) { found.append(anchor) }
        }
        var dates: [String] = []
        for pattern in [#"[0-9]{4}[年/\-.][0-9]{1,2}[月/\-.][0-9]{1,2}日?"#, #"(?<![0-9年])[0-9]{1,2}月[0-9]{1,2}日"#, #"[0-9]{1,2}월 ?[0-9]{1,2}일"#] {
            for range in matches(pattern, in: text) {
                let date = String(text[range])
                dates.append(date)
                add(Anchor(text: date, kind: .date))
            }
        }
        let words = matches(#"[A-Za-z0-9][A-Za-z0-9+._\-]*"#, in: text).map { range -> (String, Range<String.Index>) in
            var word = String(text[range])
            while let last = word.last, ".-_".contains(last) { word.removeLast() }
            return (word, range)
        }
        var index = 0
        while index < words.count {
            let (word, range) = words[index]
            index += 1
            let letters = word.allSatisfy { $0.isASCII && $0.isLetter }
            if letters {
                // A name and the number after it: "iOS 27.2", "Gemma 4".
                if index < words.count, isNumber(words[index].0), isVersionName(word, otherScript: otherScript),
                   text[range.upperBound..<words[index].1.lowerBound].allSatisfy({ $0 == " " || $0 == "-" }),
                   text.distance(from: range.upperBound, to: words[index].1.lowerBound) <= 2 {
                    add(Anchor(text: "\(word) \(words[index].0)", kind: .version, name: word, number: words[index].0))
                    index += 1
                } else if otherScript && word.count >= 2 {
                    add(Anchor(text: word, kind: .name))
                }
            } else if let split = firstMatch(#"^([A-Za-z]{2,})([0-9]+(\.[0-9]+)*)$"#, in: word) {
                // Written together: "iOS27.2", "iPhone18".
                add(Anchor(text: "\(split[1]) \(split[2])", kind: .version, name: split[1], number: split[2]))
            } else if word.first?.isLetter == true && word.contains(where: \.isNumber) {
                add(Anchor(text: word, kind: .token))
            } else if word.first?.isNumber == true && word.contains(where: \.isLetter) {
                // "256GB", "5G": the question's words, but not what it is about.
                if firstMatch(#"^[0-9]+(st|nd|rd|th)$"#, in: word.lowercased()) == nil { add(Anchor(text: word, kind: .name)) }
            } else if firstMatch(#"^[0-9]+(\.[0-9]+)+$"#, in: word) != nil, !dates.contains(where: { $0.contains(word) }) {
                add(Anchor(text: word, kind: .number, number: word))
            } else if firstMatch(#"^(19|20)[0-9]{2}$"#, in: word) != nil, !dates.contains(where: { $0.contains(word) }) {
                add(Anchor(text: word, kind: .year))
            }
        }
        return Array(found.prefix(6))
    }

    private static func isNumber(_ word: String) -> Bool { firstMatch(#"^[0-9]+(\.[0-9]+)*$"#, in: word) != nil }

    /// A name before a number is a version's only when it looks like a
    /// product's: written with a capital ("iOS", "Gemma"), and not a word
    /// such as "Top 5". In Japanese, Chinese or Korean any Latin word is.
    private static func isVersionName(_ word: String, otherScript: Bool) -> Bool {
        if otherScript { return true }
        return word.contains(where: \.isUppercase) && !commonWords.contains(word.lowercased())
    }

    /// Where the text names the anchor, as a whole word or number: "iOS
    /// 27.2" in "iOS 27.2.1" but not "iOS 27.21"; case and width ignored.
    static func range(of anchor: Anchor, in text: String) -> Range<String.Index>? {
        for variant in anchor.variants where !variant.isEmpty {
            var from = text.startIndex
            while from < text.endIndex,
                  let found = text.range(of: variant, options: [.caseInsensitive, .widthInsensitive], range: from..<text.endIndex) {
                let before = found.lowerBound > text.startIndex ? text[text.index(before: found.lowerBound)] : nil
                let after = found.upperBound < text.endIndex ? text[found.upperBound] : nil
                let alnum: (Character?) -> Bool = { $0.map { $0.isASCII && ($0.isLetter || $0.isNumber) } ?? false }
                let startsWord = variant.first.map { $0.isASCII && ($0.isLetter || $0.isNumber) } ?? false
                let open = !startsWord || !alnum(before)
                let close: Bool
                if variant.last?.isNumber == true { close = !(after?.isASCII == true && after?.isNumber == true) }
                else if variant.last?.isLetter == true && variant.last?.isASCII == true { close = !(after?.isASCII == true && after?.isLetter == true) }
                else { close = true }
                if open && close { return found }
                from = text.index(after: found.lowerBound)
            }
        }
        return nil
    }

    /// The name with a number after it, and the number: "iOS 17.2".
    static func versionRanges(of name: String, in text: String) -> [(whole: Range<String.Index>, number: String)] {
        let pattern = "(?<![A-Za-z0-9])" + NSRegularExpression.escapedPattern(for: name) + #"[ \-]?([0-9]+(\.[0-9]+)*)"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [] }
        return regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap { match in
            guard let whole = Range(match.range, in: text), let number = Range(match.range(at: 1), in: text) else { return nil }
            return (whole, String(text[number]))
        }
    }

    /// Other versions of the same name the text names, when it doesn't
    /// name this one: "iOS 17.2" for "iOS 27.2". "iOS 27" and "iOS 27.2.1"
    /// are the same line.
    static func otherVersions(of anchor: Anchor, in text: String) -> [String] {
        guard let name = anchor.name, let number = anchor.number else { return [] }
        let folded = text.precomposedStringWithCompatibilityMapping
        return versionRanges(of: name, in: folded).map { $0.number }.filter {
            $0 != number && !$0.hasPrefix(number + ".") && !number.hasPrefix($0 + ".")
        }.map { "\(name) \($0)" }
    }

    static func matches(_ pattern: String, in text: String, caseInsensitive: Bool = false) -> [Range<String.Index>] {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: caseInsensitive ? [.caseInsensitive] : []) else { return [] }
        return regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap { Range($0.range, in: text) }
    }

    private static func firstMatch(_ pattern: String, in text: String) -> [String]? {
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) else { return nil }
        return (0..<match.numberOfRanges).map { Range(match.range(at: $0), in: text).map { String(text[$0]) } ?? "" }
    }

    static let commonWords: Set<String> = ["top", "under", "over", "about", "around", "in", "on", "at", "for", "by", "to", "the",
                                           "a", "an", "of", "and", "or", "page", "step", "part", "day", "days", "year", "years",
                                           "chapter", "level", "number", "no", "vs", "i", "my", "we", "is", "are", "was", "be"]
    static let latestWords = ["最新", "最近", "現在", "今日", "きょう", "昨日", "明日", "今週", "来週", "今月", "来月", "今年", "来年", "今の", "今は", "いま",
                              "速報", "ニュース", "latest", "newest", "current", "recent", "today", "tonight", "this week", "this month",
                              "this year", "news", "upcoming", "최신", "최근", "현재", "오늘", "이번 주", "뉴스", "目前", "现在", "今天", "新闻", "新聞"]
    static let releaseWords = ["更新", "アップデート", "リリース", "配信", "発売", "公開", "出る", "出ます", "来る", "update", "release", "launch",
                               "come out", "coming", "업데이트", "출시", "배포", "发布", "發布", "推出", "上市"]
    static let publicSuffixes = [".go.jp", ".lg.jp", ".ac.jp", ".gov", ".gov.uk", ".gov.cn", ".gov.tw", ".go.kr", ".edu", ".europa.eu"]
    /// Makers' own sites for the names a question may use.
    static let officialSites: [(names: [String], domains: [String])] = [
        (["ios", "ipados", "macos", "watchos", "visionos", "tvos", "iphone", "ipad", "mac", "macbook", "imac", "airpods", "apple",
          "xcode", "safari", "icloud", "siri", "testflight"], ["apple.com"]),
        (["android", "pixel", "google", "gemini", "gemma", "chrome", "chromeos", "gmail", "youtube"],
         ["google.com", "blog.google", "android.com", "google.dev", "youtube.com"]),
        (["windows", "microsoft", "xbox", "copilot", "azure", "surface"], ["microsoft.com"]),
        (["galaxy", "samsung"], ["samsung.com"]),
        (["playstation", "ps5", "xperia", "sony"], ["sony.com", "playstation.com", "sony.jp", "sony.co.jp"]),
        (["nintendo", "switch"], ["nintendo.com", "nintendo.co.jp"]),
        (["chatgpt", "openai", "gpt"], ["openai.com"]),
        (["claude", "anthropic"], ["anthropic.com"]),
        (["llama", "meta", "instagram", "facebook", "whatsapp", "threads"], ["meta.com", "about.fb.com", "instagram.com"]),
        (["tavily"], ["tavily.com"]),
        (["python"], ["python.org"]),
        (["tesla"], ["tesla.com"]),
    ]
}

/// The pages a search gives the model, and how they relate to what was
/// asked.
public struct WebSearchFindings: Equatable, Sendable {
    public var hits: [WebSearchHit]
    /// Per page: it names what the question is about (always true when
    /// nothing identifies it).
    public var about: [Bool]
    /// Other versions the left-out pages named ("iOS 17.2").
    public var others: [String]
    /// The latest was asked for and every dated page is over a year old.
    public var stale: Bool
    /// What a page had to name to be about the search ("iOS 27.2").
    public var asked: [String]
    /// The search names something a page must name to be about it.
    public var identifies: Bool { !asked.isEmpty }
    public var label: String { asked.joined(separator: ", ") }
    public var matched: Int { about.filter { $0 }.count }

    public init(hits: [WebSearchHit], about: [Bool]? = nil, others: [String] = [], stale: Bool = false, asked: [String] = []) {
        self.hits = hits
        self.about = about ?? hits.map { _ in true }
        self.others = others
        self.stale = stale
        self.asked = asked
    }
}
