import Foundation

/// The developer GPU start test: Qwen started once on the phone's GPU, with a
/// chosen precision, answering one fixed question. On the phone, 1.0.104's
/// Qwen3 0.6B GPU build failed on every launch (litert_compiled_model.h:1961)
/// with no reason in its message. Chats keep Qwen3 on the CPU
/// (ModelCapabilities.gpu) whatever the test finds.
public enum GPUStartTest {
    /// Qwen3, the model being tested, and Qwen2.5, which ran on the phone's
    /// GPU, for comparison.
    public static let modelIDs = [ModelSpec.qwen3.id, ModelSpec.qwen25.id]
    /// The only input, so the GPU's native messages never hold the user's text.
    public static let question = "日本の首都はどこですか？一文で答えてください。"
    public static let maxOutputTokens = 64
    /// A GPU that answers far slower than this is a result too: the reply is
    /// stopped rather than holding the test open.
    public static let replySeconds: Double = 120
    /// Marks the test's records in the diagnostics (InferenceDiagnostic.inputPath).
    public static let inputPath = "gpu_start_test_fixed_question"
}

/// The GPU's compute precision for the GPU start test (the runtime's public
/// EngineConfig.activationDataType).
public enum GPUPrecision: String, CaseIterable, Identifiable, Codable, Sendable {
    /// No override, as 1.0.104 started Qwen3 on the phone.
    case modelDefault
    case float16
    case float32
    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .modelDefault: return "指定なし（1.0.104と同じ）"
        case .float16: return "16ビット"
        case .float32: return "32ビット"
        }
    }
    /// What the diagnostics record (InferenceDiagnostic.activationPrecision).
    public var diagnosticLabel: String {
        switch self {
        case .modelDefault: return "model/runtime default (no override)"
        case .float16: return "float16 (override)"
        case .float32: return "float32 (override)"
        }
    }
}
