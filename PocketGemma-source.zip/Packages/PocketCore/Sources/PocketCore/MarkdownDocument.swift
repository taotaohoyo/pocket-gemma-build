import Foundation

/// LaTeX taken out of the text before parsing, inline (`$x$`) or on a line
/// of its own (`$$x$$`).
public struct MarkdownMath: Hashable, Sendable {
    public var latex: String
    public var display: Bool
    /// The math as written, delimiters included (`$x$`, `\(x\)`), for
    /// text that turns out to be code and for copying.
    public var raw: String
    public init(latex: String, display: Bool, raw: String = "") {
        self.latex = latex
        self.display = display
        self.raw = raw
    }
}

/// Marks inline math in a block's text. The marked characters are the
/// LaTeX source, which VoiceOver and copying keep.
public enum MarkdownMathAttribute: AttributedStringKey {
    public typealias Value = MarkdownMath
    public static let name = "PocketCore.MarkdownMath"
}

public struct MarkdownTable: Equatable {
    public enum Alignment: Equatable { case leading, center, trailing }
    public var alignments: [Alignment]
    public var header: [AttributedString]
    public var rows: [[AttributedString]]
}

public struct MarkdownListItem: Equatable {
    /// The item's number in an ordered list.
    public var ordinal: Int
    /// A checklist item (`- [ ]` or `- [x]`): whether it is checked.
    public var checked: Bool?
    public var blocks: [MarkdownBlock]
}

public indirect enum MarkdownBlock: Equatable {
    case paragraph(AttributedString)
    case heading(level: Int, AttributedString)
    case code(language: String?, code: String)
    case math(String)
    case quote([MarkdownBlock])
    case list(ordered: Bool, items: [MarkdownListItem])
    case table(MarkdownTable)
    case image(url: URL?, alt: String)
    case rule
}

/// A reply chunk parsed into blocks with Foundation's Markdown parser
/// (CommonMark with GitHub's tables and strikethrough). Inline text keeps
/// Foundation's inline attributes (emphasis, code, links), which SwiftUI's
/// `Text` draws. The original text stays the source for copying.
public struct MarkdownDocument: Equatable {
    public var blocks: [MarkdownBlock]
    /// While streaming: the last block is a `$$` or `\[` formula whose
    /// closing line has not arrived (or a `\begin{cases}` written without
    /// them whose `\end` has not), so its source is still growing.
    public var openMathAtEnd = false

    /// `streaming` closes syntax the reply has not finished yet.
    /// `references` are the reply's link definitions, for chunks that use them.
    public init(_ source: String, streaming: Bool = false, references: String = "") {
        let repaired: String
        if streaming {
            let repair = MarkdownSource.repairStreamingDetailed(source)
            repaired = repair.text
            openMathAtEnd = repair.closedMath
        } else {
            repaired = source
        }
        let prepared = MarkdownSource.prepare(repaired)
        let text = references.isEmpty ? prepared.text : prepared.text + "\n\n" + references
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { blocks = []; return }
        let options = AttributedString.MarkdownParsingOptions(
            allowsExtendedAttributes: false, interpretedSyntax: .full,
            failurePolicy: .returnPartiallyParsedIfPossible, languageCode: nil)
        guard let parsed = try? AttributedString(markdown: text, options: options) else {
            blocks = [.paragraph(Self.finish(AttributedString(repaired), math: []))]
            return
        }
        let root = Node(kind: nil, identity: -1)
        for run in parsed.runs {
            var node = root
            let components = Self.outermostFirst(run.presentationIntent?.components ?? [])
            if components.isEmpty {
                // Text Foundation puts in no block (an HTML block, for one)
                // is kept as a paragraph of its own rather than lost.
                if let last = root.children.last, last.kind == nil {
                    node = last
                } else {
                    let loose = Node(kind: nil, identity: -2)
                    root.children.append(loose)
                    node = loose
                }
            }
            for component in components {
                if let last = node.children.last, last.identity == component.identity {
                    node = last
                } else {
                    let child = Node(kind: component.kind, identity: component.identity)
                    node.children.append(child)
                    node = child
                }
            }
            node.text.append(AttributedString(parsed[run.range]))
        }
        blocks = Self.blocks(root.children, math: prepared.math)
    }

    private final class Node {
        let kind: PresentationIntent.Kind?
        let identity: Int
        var children: [Node] = []
        var text = AttributedString()
        init(kind: PresentationIntent.Kind?, identity: Int) {
            self.kind = kind
            self.identity = identity
        }
    }

    private static func isLeaf(_ kind: PresentationIntent.Kind) -> Bool {
        switch kind {
        case .paragraph, .header, .codeBlock, .thematicBreak, .tableCell: return true
        default: return false
        }
    }

    /// Foundation lists a run's intents from the innermost block outwards.
    private static func outermostFirst(_ components: [PresentationIntent.IntentType]) -> [PresentationIntent.IntentType] {
        guard components.count > 1 else { return components }
        if let first = components.first, isLeaf(first.kind) { return components.reversed() }
        return components
    }

    private static func blocks(_ nodes: [Node], math: [MarkdownMath]) -> [MarkdownBlock] {
        nodes.flatMap { block($0, math: math) }
    }

    private static func block(_ node: Node, math: [MarkdownMath]) -> [MarkdownBlock] {
        guard let kind = node.kind else {
            guard node.children.isEmpty else { return blocks(node.children, math: math) }
            // Loose text (an HTML block) ends with its line break.
            var text = node.text
            while let last = text.characters.last, last.isNewline { text.characters.removeLast() }
            return paragraph(text, math: math)
        }
        switch kind {
        case .paragraph:
            return paragraph(node.text, math: math)
        case .header(let level):
            return [.heading(level: level, finish(node.text, math: math))]
        case .codeBlock(let hint):
            var code = MarkdownSource.restoreCode(String(node.text.characters), math: math)
            if code.hasSuffix("\n") { code.removeLast() }
            // The info string's first word names the language (```swift title=a).
            let language = hint?.split(whereSeparator: \.isWhitespace).first.map { $0.lowercased() }
            if language == "math" { return [.math(code.trimmingCharacters(in: .whitespacesAndNewlines))] }
            return [.code(language: language?.isEmpty == false ? language : nil, code: code)]
        case .blockQuote:
            return [.quote(blocks(node.children, math: math))]
        case .orderedList, .unorderedList:
            var ordered = false
            if case .orderedList = kind { ordered = true }
            let items = node.children.enumerated().map { offset, child in
                var ordinal = offset + 1
                if case .listItem(let number)? = child.kind { ordinal = number }
                return listItem(ordinal: ordinal, blocks: blocks(child.children.isEmpty ? [child] : child.children, math: math))
            }
            return [.list(ordered: ordered, items: items)]
        case .table(let columns):
            return [.table(table(node, columns: columns, math: math))]
        case .thematicBreak:
            return [.rule]
        default:
            return node.children.isEmpty ? paragraph(node.text, math: math) : blocks(node.children, math: math)
        }
    }

    /// `[ ]` or `[x]` at the start of an item makes it a checklist item.
    private static func listItem(ordinal: Int, blocks: [MarkdownBlock]) -> MarkdownListItem {
        var blocks = blocks
        guard case .paragraph(var text)? = blocks.first else {
            return MarkdownListItem(ordinal: ordinal, checked: nil, blocks: blocks)
        }
        let plain = String(text.characters.prefix(4))
        let checked: Bool? = plain.hasPrefix("[ ]") ? false
            : (plain.hasPrefix("[x]") || plain.hasPrefix("[X]")) ? true : nil
        guard let checked, plain.count == 3 || plain.last == " " else {
            return MarkdownListItem(ordinal: ordinal, checked: nil, blocks: blocks)
        }
        let end = text.characters.index(text.startIndex, offsetBy: min(4, text.characters.count))
        text.removeSubrange(text.startIndex..<end)
        blocks[0] = .paragraph(text)
        return MarkdownListItem(ordinal: ordinal, checked: checked, blocks: blocks)
    }

    private static func table(_ node: Node, columns: [PresentationIntent.TableColumn], math: [MarkdownMath]) -> MarkdownTable {
        let alignments: [MarkdownTable.Alignment] = columns.map { column in
            switch column.alignment {
            case .center: return .center
            case .right: return .trailing
            default: return .leading
            }
        }
        var header: [AttributedString] = []
        var rows: [[AttributedString]] = []
        for row in node.children {
            var cells = Array(repeating: AttributedString(), count: max(columns.count, 1))
            for (offset, cell) in row.children.enumerated() {
                var column = offset
                if case .tableCell(let index)? = cell.kind { column = index }
                guard column >= 0 else { continue }
                if column >= cells.count { cells.append(contentsOf: Array(repeating: AttributedString(), count: column - cells.count + 1)) }
                cells[column] = finish(cell.text, math: math)
            }
            if case .tableHeaderRow? = row.kind { header = cells } else { rows.append(cells) }
        }
        let width = max(columns.count, header.count, rows.map(\.count).max() ?? 0)
        func padded(_ cells: [AttributedString]) -> [AttributedString] {
            cells + Array(repeating: AttributedString(), count: max(0, width - cells.count))
        }
        return MarkdownTable(alignments: alignments + Array(repeating: .leading, count: max(0, width - alignments.count)),
                             header: padded(header), rows: rows.map(padded))
    }

    /// A paragraph's text; images in it follow as blocks of their own.
    private static func paragraph(_ text: AttributedString, math: [MarkdownMath]) -> [MarkdownBlock] {
        var images: [MarkdownBlock] = []
        var remaining = AttributedString()
        for run in text.runs {
            if let url = run.imageURL {
                images.append(.image(url: url, alt: String(text[run.range].characters)))
            } else {
                remaining.append(text[run.range])
            }
        }
        let finished = finish(remaining, math: math)
        let hasText = finished.characters.contains { !$0.isWhitespace }
        return (hasText ? [.paragraph(finished)] : []) + images
    }

    private static let linkDetector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue)

    /// Line breaks kept, the hair spaces and math placeholders of
    /// `MarkdownSource.prepare` resolved, links limited to web and mail
    /// addresses, and bare web addresses made links.
    static func finish(_ text: AttributedString, math: [MarkdownMath]) -> AttributedString {
        // Rebuilt run by run: indices go stale once a string changes.
        var result = AttributedString()
        for run in text.runs {
            var piece = AttributedString(text[run.range])
            if let intent = run.inlinePresentationIntent, intent.contains(.softBreak) || intent.contains(.lineBreak) {
                // A single line break in a reply is a line break, as in Messages.
                var attributes = run.attributes
                let rest = intent.subtracting([.softBreak, .lineBreak])
                attributes.inlinePresentationIntent = rest.isEmpty ? nil : rest
                piece = AttributedString("\n", attributes: attributes)
            }
            if let url = run.link, !MarkdownLinkPolicy.isAllowed(url) { piece.link = nil }
            result.append(piece)
        }
        while let space = result.characters.firstIndex(of: MarkdownSource.flankingSpace) {
            result.characters.remove(at: space)
        }
        if !math.isEmpty { resolveMath(&result, math: math) }
        addBareLinks(&result)
        return result
    }

    private static func resolveMath(_ text: inout AttributedString, math: [MarkdownMath]) {
        let characters = Array(text.characters)
        var found: [(start: Int, length: Int, index: Int)] = []
        var offset = 0
        while offset < characters.count {
            guard characters[offset] == MarkdownSource.mathOpen,
                  let close = characters[offset...].firstIndex(of: MarkdownSource.mathClose),
                  let index = Int(String(characters[(offset + 1)..<close])), math.indices.contains(index) else {
                offset += 1
                continue
            }
            found.append((offset, close - offset + 1, index))
            offset = close + 1
        }
        for match in found.reversed() {
            let lower = text.characters.index(text.startIndex, offsetBy: match.start)
            let upper = text.characters.index(lower, offsetBy: match.length)
            var attributes = text[lower..<upper].runs.first?.attributes ?? AttributeContainer()
            attributes[MarkdownMathAttribute.self] = math[match.index]
            text.replaceSubrange(lower..<upper, with: AttributedString(math[match.index].latex, attributes: attributes))
        }
    }

    private static func addBareLinks(_ text: inout AttributedString) {
        guard let detector = linkDetector else { return }
        let plain = String(text.characters)
        guard plain.contains(".") else { return }
        let matches = detector.matches(in: plain, range: NSRange(plain.startIndex..., in: plain))
        for match in matches.reversed() {
            guard let url = match.url, MarkdownLinkPolicy.isWeb(url), let range = Range(match.range, in: plain) else { continue }
            let start = plain.distance(from: plain.startIndex, to: range.lowerBound)
            let length = plain.distance(from: range.lowerBound, to: range.upperBound)
            let lower = text.characters.index(text.startIndex, offsetBy: start)
            let upper = text.characters.index(lower, offsetBy: length)
            let busy = text[lower..<upper].runs.contains { run in
                run.link != nil || run[MarkdownMathAttribute.self] != nil
                    || run.inlinePresentationIntent?.contains(.code) == true
            }
            if !busy { text[lower..<upper].link = url }
        }
    }
}

/// Links in replies open only web and mail addresses, never other apps'
/// schemes, scripts or local files.
public enum MarkdownLinkPolicy {
    public static func isWeb(_ url: URL) -> Bool {
        guard let scheme = url.scheme?.lowercased() else { return false }
        return (scheme == "https" || scheme == "http") && url.host?.isEmpty == false
    }

    public static func isAllowed(_ url: URL) -> Bool {
        isWeb(url) || url.scheme?.lowercased() == "mailto"
    }

    /// Images load only over HTTPS, and only when the reader asks.
    public static func isLoadableImage(_ url: URL) -> Bool {
        url.scheme?.lowercased() == "https" && url.host?.isEmpty == false
    }
}
