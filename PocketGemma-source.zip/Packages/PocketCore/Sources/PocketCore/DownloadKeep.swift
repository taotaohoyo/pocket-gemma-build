import Foundation

/// What a model file's download has left on the phone to go on from
/// (1.1.0 (293), Hachimoto さん's directive of 2026-11-17 on downloads that
/// failed in the background and started again from nothing).
///
/// The bytes themselves are iOS's: the background session keeps them in its
/// own folder and hands the app resume data (`ModelLibrary.resumeURL`) to go
/// on from. This record, next to it (`ModelLibrary.keepURL`), says whether
/// the download should go on by itself at the next launch (`running`: the
/// app ended, or iOS stopped it, while it ran) or waits for the person
/// (`paused`: they stopped it keeping what came, or it failed with what came
/// kept; `closed`, since 1.1.0 (294): they closed the app from the app
/// switcher while it ran), and how far it was, for the card. Until 292
/// nothing said so: a launch forgot every download iOS had stopped, and the
/// resume data went with the first try that used it.
public struct DownloadKeep: Codable, Equatable, Sendable {
    public enum State: String, Codable, Sendable {
        /// Under way when last written.
        case running
        /// Stopped with what came kept, until the person goes on.
        case paused
        /// Under way when the person closed the app from the app switcher
        /// (1.1.0 (294), Hachimoto さん's choice of 2026-11-17): it waits for
        /// the person like `paused`. iOS stops the task then and hands its
        /// resume data to the next launch, so the data may come after this.
        case closed

        /// Waits for the person's 続きから: nothing starts by itself.
        public var waitsForPerson: Bool { self != .running }
    }

    /// What follows iOS's stop of a file's task (1.1.0 (294)): it waits
    /// for the person when they closed the app from the app switcher
    /// (`reason` NSURLErrorCancelledReasonUserForceQuitApplication), or when
    /// the record already says so. From a launch iOS did not begin from the
    /// person's tap, a download can't ask iOS to keep the app running, so
    /// off screen its figure stopped about 30 s after leaving (293 on the
    /// phone, 2026-11-17); 続きから starts it from the tap, with iOS's own
    /// progress. Background updates off (1) or iOS short of resources (2)
    /// go on by themselves, as in 293.
    public static func waitsForPerson(afterSystemStop reason: Int, record: State?) -> Bool {
        reason == NSURLErrorCancelledReasonUserForceQuitApplication || (record?.waitsForPerson ?? false)
    }

    public var state: State
    /// Bytes received when last written (the card's figure while paused).
    /// 0 when not known, as for resume data an earlier version left.
    public var receivedBytes: Int64
    public var expectedBytes: Int64
    /// The request's choice of モバイル通信でもダウンロード.
    public var cellular: Bool
    public var updated: Date

    public init(state: State, receivedBytes: Int64, expectedBytes: Int64, cellular: Bool, updated: Date = Date()) {
        self.state = state
        self.receivedBytes = max(0, receivedBytes)
        self.expectedBytes = expectedBytes
        self.cellular = cellular
        self.updated = updated
    }

    /// How far the file got, when known.
    public var fraction: Double? {
        guard receivedBytes > 0, expectedBytes > 0 else { return nil }
        return min(1, Double(receivedBytes) / Double(expectedBytes))
    }

    public static func read(from url: URL) -> DownloadKeep? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try? decoder.decode(DownloadKeep.self, from: data)
    }

    public func write(to url: URL) throws {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        try encoder.encode(self).write(to: url, options: .atomic)
    }
}

/// How a download task ended, from the error the session gave its end.
public enum DownloadEnding: Equatable, Sendable {
    /// The app cancelled it: to start it again, or the person's stop.
    case cancelledByApp
    /// iOS cancelled it (NSURLErrorBackgroundTaskCancelledReasonKey): the
    /// person closed the app from the app switcher (0), background updates
    /// are off for it (1), or the system needed the resources (2). Not the
    /// person's stop of the download: what came is kept. Since 1.1.0 (294)
    /// the first waits for the person's 続きから (`DownloadKeep.waitsForPerson`).
    case stoppedBySystem(reason: Int)
    /// Anything else: the network, the Hub, the phone.
    case failed

    public init(_ error: NSError) {
        guard error.domain == NSURLErrorDomain, error.code == NSURLErrorCancelled else {
            self = .failed
            return
        }
        if let reason = error.userInfo[NSURLErrorBackgroundTaskCancelledReasonKey] as? Int {
            self = .stoppedBySystem(reason: reason)
        } else {
            self = .cancelledByApp
        }
    }

    /// The download record's words for iOS's reason.
    public static func reasonText(_ reason: Int) -> String {
        switch reason {
        case NSURLErrorCancelledReasonUserForceQuitApplication: return "アプリが閉じられた"
        case NSURLErrorCancelledReasonBackgroundUpdatesDisabled: return "バックグラウンド更新がオフ"
        case NSURLErrorCancelledReasonInsufficientSystemResources: return "iOSの資源不足"
        default: return "理由 \(reason)"
        }
    }
}

/// What a failed download task leads to (1.1.0 (293)). Until 292 a task
/// that went on from resume data and then failed without new resume data
/// started over from the beginning at once, and the resume data was
/// deleted when the task started: a connection lost early in a resumed task
/// lost everything received before it.
public enum DownloadRetry: Equatable, Sendable {
    /// Again from the resume data the failed task left.
    case fromNewData
    /// Again from the resume data kept before the failed task (it left none).
    case fromKeptData
    /// From the beginning: the kept data can no longer be used. The Hub's
    /// link in it ran out (its CDN links last about an hour), the file
    /// behind it changed, or going on from it already failed once.
    case fromStart
    /// No try now: the download stops, keeping what came, with words that
    /// say why (a full phone, a file gone from the Hub, too many tries).
    case stop

    /// - Parameters:
    ///   - failure: why the task ended.
    ///   - resumed: the task went on from resume data.
    ///   - hasNewData: the task's end came with resume data.
    ///   - hasKeptData: resume data from before the task is on the phone.
    ///   - keptDataFailed: a task already went on from that kept data and
    ///     failed without new data, so it is not tried again.
    ///   - tries: automatic tries so far for this download.
    ///   - maxTries: how many it may make.
    public static func after(_ failure: DownloadFailure, resumed: Bool, hasNewData: Bool, hasKeptData: Bool,
                             keptDataFailed: Bool, tries: Int, maxTries: Int) -> DownloadRetry {
        guard tries < maxTries else { return .stop }
        switch failure {
        case .http(let status) where [401, 403, 410, 412, 416].contains(status):
            // A refused or run-out link, a file that changed: the bytes
            // iOS kept for it can't be asked for again. From the Hub's own
            // link again, from the beginning.
            return .fromStart
        case .http(let status) where status == 408 || status == 429 || status >= 500:
            // The Hub had trouble; what came still fits the file.
            return hasNewData ? .fromNewData : hasKeptData && !keptDataFailed ? .fromKeptData : .fromStart
        case .connectionLost, .stalled:
            if hasNewData { return .fromNewData }
            if hasKeptData && !keptDataFailed { return .fromKeptData }
            // Nothing kept to lose.
            return .fromStart
        case .other:
            // An end the app has no words for. Resume data it left is tried.
            // A task that went on from kept data and ended so without new
            // data tries that data once more; failing again, the data is
            // taken as unusable and the file starts over.
            if hasNewData { return .fromNewData }
            guard resumed else { return .stop }
            return hasKeptData && !keptDataFailed ? .fromKeptData : .fromStart
        default:
            return .stop
        }
    }
}

extension ModelDownload {
    /// The room a download needs on the phone (1.1.0 (293)): what is still
    /// to come of each file, as what came is already on the phone in iOS's
    /// folder, plus the other downloads under way, plus 1 GB to spare.
    /// Until 292 a download going on from what it had asked for the whole
    /// file's room again.
    public static func roomNeeded(remaining files: [(byteCount: Int64, received: Int64)], others: Int64) -> Int64 {
        files.reduce(0) { $0 + max(0, $1.byteCount - min(max($1.received, 0), $1.byteCount)) } + max(0, others) + 1_000_000_000
    }
}
