import Foundation

/// Who wrote a saved reply, as far as the record says (1.1.0 (296), the
/// user's directive of 2026-11-17 「Smart Memory｜モデル自己認識の混同・誤回答
/// 修正」), for Smart Memory's note: a reply quoted from another model's
/// chat is named as that model's.
///
/// What the model that answers reads about itself is as before for Gemma 4
/// and LFM3: their system turn names no model
/// (GenerationSettings.systemMessage), and each says who it is from what it
/// was trained on, as with Smart Memory off. Naming it there was tried with
/// the real models and left out. LFM3 1.7B, told "You are LFM3 1.7B, an AI
/// model made by Liquid AI" before or after the prompt, answered Japanese
/// questions in English and 「日本の首都はどこですか？」 with 「私はLiquid AIに
/// よって開発されたLFM3モデルです。」 (run 44162653547). Qwen2.5 1.5B alone,
/// which named no model, reads its name after the prompt
/// (GenerationSettings.qwenNameNote). And no wording, in the system turn or
/// in the record, kept LFM3 or Qwen from repeating another model's
/// introduction once it was in their input for the same question. So the
/// introduction is kept out of the input instead (SelfQuestion,
/// SmartMemoryIndex.search), in Smart Memory's record and among the chat's
/// own turns.
public struct ReplyAuthor: Equatable, Sendable {
    /// "Gemma 4 E2B", "Claude Opus 5.5", a PC model's name.
    public let name: String
    /// The on-device model's id; nil for Claude and a PC's model.
    public let modelID: String?

    /// A chat answered off the iPhone names its model itself (Claude, the
    /// PC). Otherwise the reply's own record (`ChatMessage.modelID`, kept
    /// since 296), or Smart Mode's (`SmartReply.modelID`, since 249). nil
    /// for an older reply: its chat's model is not proof of who wrote it
    /// (Smart Mode moves a chat between models, the Apple Watch asks
    /// Gemma 4 E2B in any chat), so it is named as unknown, never guessed.
    public static func of(_ reply: ChatMessage, in thread: ChatThread) -> ReplyAuthor? {
        guard reply.role == .assistant else { return nil }
        if let claude = thread.claude { return named(claude.modelName, fallback: "Claude") }
        if let pc = thread.pc { return named(pc.shortModel, fallback: "a model on the person's PC") }
        guard let id = reply.modelID ?? reply.smart?.modelID else { return nil }
        return ReplyAuthor(name: ModelSpec.named(id)?.name ?? label(id), modelID: id)
    }

    /// Whether the reply is surely `model`'s own.
    public func isModel(_ model: ModelSpec?) -> Bool { modelID != nil && modelID == model?.id }

    private static func named(_ name: String, fallback: String) -> ReplyAuthor {
        let name = label(name)
        return ReplyAuthor(name: name.isEmpty ? fallback : name, modelID: nil)
    }

    /// A name as the note writes it: one line, letters, digits and the few
    /// marks model names have, at most 40 characters. A PC's model name is
    /// the PC's text, not Fielua's.
    static func label(_ name: String) -> String {
        let allowed = name.unicodeScalars.filter { scalar in
            scalar.properties.isAlphabetic || scalar.properties.numericType != nil || " .-_:/+".unicodeScalars.contains(scalar)
        }
        return String(String(String.UnicodeScalarView(allowed)).trimmingCharacters(in: .whitespaces).prefix(40))
    }
}
