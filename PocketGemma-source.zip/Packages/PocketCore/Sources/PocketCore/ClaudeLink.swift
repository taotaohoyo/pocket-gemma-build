import Foundation

/// Claude (1.1.0 (257), the user's directive of 2026-11-06 「Claude API
/// 接続」): a chat answered by Claude, Anthropic's model, through Fielua's
/// own relay (claude-relay in the repository, on Cloudflare Workers). The
/// Anthropic key is the relay's alone: the app holds only this device's
/// access token, which the developer can stop at any time. Text only; the
/// conversation stays on the iPhone and only the turns a reply needs go,
/// over HTTPS. This file holds what does not need the network: the invite
/// link, the server's address, the turns sent, and the reply's events.
public enum ClaudeLink {
    /// The relay's address as typed or carried by an invite: https, a host
    /// and maybe a port, nothing else. `allowsLocal`: plain http to this
    /// Mac (127.0.0.1, localhost), for the UI preview's checks alone.
    public static func server(_ text: String, allowsLocal: Bool = false) -> URL? {
        var trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.contains("://") { trimmed = "https://" + trimmed }
        while trimmed.hasSuffix("/") { trimmed.removeLast() }
        guard let components = URLComponents(string: trimmed),
              let scheme = components.scheme?.lowercased(),
              let host = components.host?.lowercased(), !host.isEmpty,
              components.user == nil, components.password == nil,
              components.path.isEmpty, components.query == nil, components.fragment == nil,
              host.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "." || $0 == "-") }),
              !host.hasPrefix("."), !host.hasSuffix("."), !host.hasPrefix("-") else { return nil }
        if let port = components.port, !(1...65535).contains(port) { return nil }
        let local = host == "127.0.0.1" || host == "localhost"
        guard scheme == "https" || (scheme == "http" && allowsLocal && local) else { return nil }
        // An https name needs a dot (fielua-claude.example.workers.dev).
        guard local || host.contains(".") else { return nil }
        var clean = URLComponents()
        clean.scheme = scheme
        clean.host = host
        clean.port = components.port
        return clean.url
    }

    /// The invite code as the relay makes it (16 of Crockford's base32,
    /// shown as four groups of four), read leniently: spaces and dashes
    /// left out, lower case taken, O read as 0 and I or L as 1.
    public static func code(_ text: String) -> String? {
        let alphabet = Set("0123456789ABCDEFGHJKMNPQRSTVWXYZ")
        var code = ""
        for character in text.uppercased() where character != " " && character != "-" && character != "\n" {
            switch character {
            case "O": code.append("0")
            case "I", "L": code.append("1")
            default:
                guard alphabet.contains(character) else { return nil }
                code.append(character)
            }
        }
        return code.count == 16 ? code : nil
    }

    /// The code as shown: "ABCD-EFGH-JKMN-PQRS".
    public static func grouped(_ code: String) -> String {
        stride(from: 0, to: code.count, by: 4).map { start in
            let from = code.index(code.startIndex, offsetBy: start)
            return String(code[from..<code.index(from, offsetBy: min(4, code.count - start))])
        }.joined(separator: "-")
    }
}

/// An invite to use Claude through the developer's relay: the link the
/// relay's /join page opens (fielua://claude?server=..&code=..), or the
/// page's own link (https://<relay>/join#CODE), as the developer shares it.
public struct ClaudeInvite: Equatable, Identifiable, Sendable {
    public let server: URL
    public let code: String
    public var id: String { server.absoluteString + "#" + code }
    /// The relay's host, which the person is shown before anything is sent.
    public var host: String { server.host ?? server.absoluteString }

    public init(server: URL, code: String) {
        self.server = server
        self.code = code
    }

    public init?(_ text: String, allowsLocal: Bool = false) {
        guard let components = URLComponents(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              let scheme = components.scheme?.lowercased() else { return nil }
        if scheme == "fielua" {
            guard components.host == "claude" else { return nil }
            var query: [String: String] = [:]
            for item in components.queryItems ?? [] where query[item.name] == nil { query[item.name] = item.value ?? "" }
            guard let server = query["server"].flatMap({ ClaudeLink.server($0, allowsLocal: allowsLocal) }),
                  let code = query["code"].flatMap(ClaudeLink.code) else { return nil }
            self.init(server: server, code: code)
            return
        }
        guard scheme == "https" || (scheme == "http" && allowsLocal), components.path == "/join",
              let fragment = components.fragment, let code = ClaudeLink.code(fragment) else { return nil }
        var origin = components
        origin.path = ""
        origin.fragment = nil
        guard origin.query == nil, let text = origin.string,
              let server = ClaudeLink.server(text, allowsLocal: allowsLocal) else { return nil }
        self.init(server: server, code: code)
    }
}

/// This iPhone's registration with the relay. Kept whole in the keychain,
/// on this device only (ClaudeKeychain): it holds the access token.
public struct ClaudeAccount: Codable, Equatable, Sendable {
    /// The relay, as ClaudeLink.server gives it.
    public var server: String
    public var token: String
    /// The name the developer gave this person, and "developer" or "friend".
    public var name: String
    public var role: String
    public var registeredAt: Date

    public init(server: String, token: String, name: String, role: String, registeredAt: Date = Date()) {
        self.server = server
        self.token = token
        self.name = name
        self.role = role
        self.registeredAt = registeredAt
    }

    public var isDeveloper: Bool { role == "developer" }
    public var host: String { URL(string: server)?.host ?? server }
}

/// Fielua's reasoning levels for Claude: 低, 中, 高, 超高, sent as
/// Anthropic's `output_config.effort` (low to xhigh). Anthropic's "max" is
/// never offered.
public enum ClaudeEffort: String, Codable, CaseIterable, Hashable, Sendable {
    case low, medium, high, xhigh
}

/// A model the relay offers, with the levels it takes.
public struct ClaudeModel: Equatable, Hashable, Identifiable, Sendable {
    /// Anthropic's model id ("claude-opus-5-5").
    public var id: String
    /// "Claude Opus 5.5".
    public var name: String
    public var efforts: [ClaudeEffort]
    /// Anthropic's own default for the model.
    public var defaultEffort: ClaudeEffort

    public init(id: String, name: String, efforts: [ClaudeEffort] = ClaudeEffort.allCases, defaultEffort: ClaudeEffort) {
        self.id = id
        self.name = name
        self.efforts = efforts
        self.defaultEffort = defaultEffort
    }

    /// "Opus 5.5": the name without "Claude", for the model pill.
    public var shortName: String { name.hasPrefix("Claude ") ? String(name.dropFirst(7)) : name }

    public static let opus = ClaudeModel(id: "claude-opus-5-5", name: "Claude Opus 5.5", defaultEffort: .medium)

    /// The relay's catalog as this version knows it (claude-relay
    /// src/claude.ts MODELS), in Fielua's order: Opus 5.5 first. The relay's
    /// own list replaces it once it answers, so a model it stops offering
    /// can't be chosen.
    public static let builtIn: [ClaudeModel] = [
        opus,
        ClaudeModel(id: "claude-fable-5-2", name: "Claude Fable 5.2", defaultEffort: .high),
        ClaudeModel(id: "claude-sonnet-5-5", name: "Claude Sonnet 5.5", defaultEffort: .high),
        ClaudeModel(id: "claude-haiku-5-5", name: "Claude Haiku 5.5", defaultEffort: .medium),
    ]

    /// Models a newer one took the place of (the relay's `former`): no
    /// longer offered for a new chat, but a chat begun with one goes on
    /// with it, as the relay still takes it. Each with the model that took
    /// its place, for the next new chat when it was the one chosen last.
    public static let former: [(model: ClaudeModel, successor: String)] = [
        // Claude Fable 5.2 took its place on 2026-11-10.
        (ClaudeModel(id: "claude-fable-5-1", name: "Claude Fable 5.1", defaultEffort: .high), "claude-fable-5-2"),
    ]

    /// A chat's model: one the relay offers, or a former one (a chat begun
    /// with it goes on); nil for any other.
    public static func forChat(_ id: String, offered: [ClaudeModel]) -> ClaudeModel? {
        offered.first { $0.id == id } ?? former.first { $0.model.id == id }?.model
    }

    /// The model a new chat gets for this id: the one offered, or the one
    /// that took a former model's place; nil when neither is offered.
    public static func forNewChat(_ id: String, offered: [ClaudeModel]) -> ClaudeModel? {
        let id = former.first { $0.model.id == id }?.successor ?? id
        return offered.first { $0.id == id }
    }

    /// The relay's `models` (GET /v1/status), in its order: levels this
    /// version doesn't offer (max) left out, and a model without any. nil
    /// when the relay sent none (an older relay).
    public static func catalog(_ value: Any?) -> [ClaudeModel]? {
        guard let list = value as? [[String: Any]] else { return nil }
        return list.compactMap { item in
            guard let id = item["id"] as? String, !id.isEmpty else { return nil }
            let efforts = ((item["efforts"] as? [String]) ?? []).compactMap(ClaudeEffort.init(rawValue:))
            guard let first = efforts.first else { return nil }
            let preferred = (item["defaultEffort"] as? String).flatMap(ClaudeEffort.init(rawValue:))
            return ClaudeModel(id: id, name: item["name"] as? String ?? id, efforts: efforts,
                               defaultEffort: preferred.flatMap { efforts.contains($0) ? $0 : nil } ?? first)
        }
    }
}

/// The chat's Claude: its replies come from this model through the relay,
/// at this level.
public struct ClaudeChatTarget: Codable, Equatable, Hashable, Sendable {
    /// The model's id as the relay names it ("claude-opus-5-5"), sent with
    /// every question.
    public var model: String
    /// "Claude Opus 5.5".
    public var modelName: String
    /// The reasoning level sent with every question; nil in chats from
    /// before levels (1.1.0 (257) first builds): the model's default.
    public var effort: ClaudeEffort?

    public init(model: String, modelName: String, effort: ClaudeEffort? = nil) {
        self.model = model
        self.modelName = modelName
        self.effort = effort
    }

    public init(_ model: ClaudeModel, effort: ClaudeEffort? = nil) {
        self.init(model: model.id, modelName: model.name,
                  effort: effort.flatMap { model.efforts.contains($0) ? $0 : nil } ?? model.defaultEffort)
    }

    public static let fallback = ClaudeChatTarget(.opus)

    private enum CodingKeys: String, CodingKey { case model, modelName, effort }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        model = try container.decode(String.self, forKey: .model)
        modelName = try container.decode(String.self, forKey: .modelName)
        // A level this version doesn't know leaves the chat on the model's default.
        let raw: String? = (try? container.decodeIfPresent(String.self, forKey: .effort)) ?? nil
        effort = raw.flatMap(ClaudeEffort.init(rawValue:))
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(model, forKey: .model)
        try container.encode(modelName, forKey: .modelName)
        try container.encodeIfPresent(effort, forKey: .effort)
    }
}

/// Why the relay won't answer now, as it says it.
public enum ClaudeUnavailable: String, Equatable, Sendable {
    /// The relay has no Anthropic key yet.
    case notConfigured = "not_configured"
    /// Anthropic said the credit ran out: the relay stopped itself, and
    /// nothing is bought. The developer resumes after adding credit.
    case pausedBilling = "paused_billing"
    /// The account's monthly spend limit was reached: stopped the same way.
    case pausedLimit = "paused_limit"
    /// Friends may use Claude only once the developer turns it on.
    case friendsDisabled = "friends_disabled"
}

/// The turns a Claude reply needs: the latest complete text exchanges,
/// newest kept first, within the relay's limits, then the question. An
/// exchange whose question carried a photo, video, recording or file is
/// left out (Claude would read its words without what they are about), and
/// failed or stopped replies are never sent back.
public enum ClaudeContext {
    /// Well inside the relay's 192 KB in all and 60 turns.
    public static let byteBudget = 96 * 1024
    public static let maxMessages = 40
    /// The relay takes a turn of at most 64 KB.
    public static let maxTurnBytes = 60 * 1024

    public static func turns(history: [ChatMessage], question: String) -> [PCTurn] {
        var pairs: [(String, String)] = []
        var pending: ChatMessage?
        for message in history {
            if message.role == .user {
                pending = message
            } else {
                if let asked = pending, asked.media.isEmpty, message.state == .complete,
                   !asked.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                   !message.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    pairs.append((asked.text, message.text))
                }
                pending = nil
            }
        }
        var kept: [PCTurn] = []
        var used = question.utf8.count
        for (asked, answer) in pairs.reversed() {
            let cost = asked.utf8.count + answer.utf8.count
            guard asked.utf8.count <= maxTurnBytes, answer.utf8.count <= maxTurnBytes,
                  used + cost <= byteBudget, kept.count + 3 <= maxMessages else { break }
            kept.insert(contentsOf: [PCTurn(role: "user", content: asked), PCTurn(role: "assistant", content: answer)], at: 0)
            used += cost
        }
        return kept + [PCTurn(role: "user", content: question)]
    }
}

/// One event of a reply as the relay passes on Anthropic's stream: only
/// the `data:` lines are read, each a JSON object with its `type`.
public enum ClaudeStreamEvent: Equatable, Sendable {
    /// The reply began, from this model (another, after a server-side fallback).
    case started(model: String)
    /// Claude thinks before it answers (its thinking, a summary, is not shown).
    case thinking
    case text(String)
    /// Claude declined this request and the fallback model too (stop_reason "refusal").
    case refused
    /// The reply reached its length limit (stop_reason "max_tokens").
    case cutOff
    case done
    /// Anthropic's error in the middle of the stream ("overloaded_error"...).
    case failed(type: String)
    /// Still at it: a ping, the end of a block, anything without words.
    case alive

    /// nil for a line that is not data (event names, blank lines). A
    /// comment line (":") is a keep-alive: still at it.
    public init?(line: String) {
        if line.hasPrefix(":") { self = .alive; return }
        guard line.hasPrefix("data:") else { return nil }
        let payload = line.dropFirst(5).trimmingCharacters(in: .whitespaces)
        guard let data = payload.data(using: .utf8),
              let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let type = object["type"] as? String else { return nil }
        switch type {
        case "message_start":
            self = .started(model: (object["message"] as? [String: Any])?["model"] as? String ?? "")
        case "content_block_start":
            let block = object["content_block"] as? [String: Any]
            switch block?["type"] as? String {
            case "thinking", "redacted_thinking": self = .thinking
            case "text":
                let text = block?["text"] as? String ?? ""
                self = text.isEmpty ? .alive : .text(text)
            default: self = .alive
            }
        case "content_block_delta":
            let delta = object["delta"] as? [String: Any]
            switch delta?["type"] as? String {
            case "text_delta": self = .text(delta?["text"] as? String ?? "")
            case "thinking_delta", "signature_delta": self = .thinking
            default: self = .alive
            }
        case "message_delta":
            switch (object["delta"] as? [String: Any])?["stop_reason"] as? String {
            case "refusal": self = .refused
            case "max_tokens": self = .cutOff
            default: self = .alive
            }
        case "message_stop": self = .done
        case "error":
            self = .failed(type: (object["error"] as? [String: Any])?["type"] as? String ?? "api_error")
        default: self = .alive
        }
    }
}
