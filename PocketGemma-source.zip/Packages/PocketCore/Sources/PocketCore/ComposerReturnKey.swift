import Foundation

/// A hardware keyboard's Return in the composer (Magic Keyboard on iPad,
/// fielua-reports #3, 1.1.0 (222)). Until then Return was the text view's
/// own and only ever began a new line; the on-screen keyboard's return key
/// still does, as before, and never comes here.
public enum ComposerReturnKey {
    public enum Action: Equatable, Sendable {
        /// The message goes, as the send button sends it, if it can be sent.
        case send
        /// The keyboard's own: a new line, or the IME confirming its word.
        case text
    }

    /// `composing`: the IME still holds a word being written or converted
    /// (marked text), so Return confirms it, as in every iPad app, and
    /// never sends. Shift or Option: a new line, as in Messages on iPad.
    /// Control is left to iPadOS. Command (⌘Return) sends too.
    public static func action(composing: Bool, shift: Bool, option: Bool, control: Bool) -> Action {
        if composing || shift || option || control { return .text }
        return .send
    }
}
