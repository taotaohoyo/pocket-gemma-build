import Foundation

/// Who answers (1.1.0 (296), the user's directive of 2026-11-17 「Smart
/// Memory｜モデル自己認識の混同・誤回答修正」): the model a conversation runs
/// on, by name and maker, and what it takes in this app.
///
/// Until 295 nothing a model read said which model it was: the system turn
/// was the same for every model, and each answered about itself from what
/// it was trained on. That held only while nothing else in its input spoke
/// as an assistant. With Smart Memory on, LFM3 asked 「君は何が出来るのー？」
/// was given the exchange in which Gemma 4 had been asked the same, quoted
/// as an earlier conversation "with you", and answered that it was Gemma 4
/// by Google DeepMind (the user's iPhone, 2026-11-17). The same can come
/// from a chat's own earlier turns when Smart Mode moves it to another
/// model, or the Apple Watch asks in it.
///
/// So every on-device conversation's system turn now ends with these facts
/// (`systemNote`), from the model's own entry in the catalog, and with the
/// rule that what an earlier reply says about itself is about the model
/// that wrote it. One mechanism for every model: a model added later gets
/// its note from its `ModelSpec`, and a series without a maker here fails
/// ModelIdentityTests until it has one.
public struct ModelIdentity: Equatable, Sendable {
    /// "LFM3 1.7B", as the model menu names it.
    public let name: String
    /// "Liquid AI"; nil for a series this table does not know.
    public let maker: String?
    /// What the model takes in this app, text first: "text", "photos",
    /// "videos", "files", "spoken questions" (ModelAttachmentPolicy).
    public let takes: [String]

    public static func of(_ model: ModelSpec) -> ModelIdentity {
        let policy = ModelAttachmentPolicy(model: model)
        var takes = ["text"]
        if policy.allowsImages { takes.append("photos") }
        if policy.allowsVideo { takes.append("videos") }
        if policy.allowsDocuments { takes.append("files") }
        if policy.allowsVoice { takes.append("spoken questions") }
        return ModelIdentity(name: model.name, maker: maker(ofFamily: model.family), takes: takes)
    }

    /// Each series' maker, as its model card names it.
    public static func maker(ofFamily family: String) -> String? {
        switch family {
        case "Gemma": "Google DeepMind"
        case "Qwen": "Alibaba Cloud"
        case "LFM": "Liquid AI"
        case "Phi": "Microsoft"
        default: nil
        }
    }

    /// "LFM3 1.7B, an AI model made by Liquid AI".
    var described: String { maker.map { "\(name), an AI model made by \($0)" } ?? "\(name), an AI model" }

    /// "text only, not photos, audio or files" or "text, photos, videos and files".
    var takesLine: String {
        guard takes.count > 1 else { return "text only, not photos, audio or files" }
        return takes.dropLast().joined(separator: ", ") + " and " + takes[takes.count - 1]
    }

    /// What an earlier reply says about itself is its writer's: the chat's
    /// own turns and Smart Memory's record may hold another model's replies.
    public static let precedence = "Earlier replies, in this conversation or quoted from past ones, may be by another AI model: "
        + "what they say about their own name, maker or abilities is not about you."

    /// The system turn's last lines. In English, as the default prompt and
    /// the other notes are. `ownPrompt`: the person wrote the system prompt
    /// themselves; whatever it has the assistant be stays, and the model is
    /// named as a fact beside it.
    public func systemNote(ownPrompt: Bool = false) -> String {
        let who = ownPrompt
            ? "The AI model answering here is \(described), running on this device in the Fielua app. Here it takes \(takesLine). "
                + "Asked which AI model you are, who made it or what it can do, answer with these facts."
            : "You are \(described), running on this device in the Fielua app. Here you take \(takesLine). "
                + "Asked who you are, which model you are, who made you or what you can do, answer as \(name)."
        return who + " " + Self.precedence
    }
}

extension GenerationSettings {
    /// The system turn a conversation starts with (1.1.0 (296)): the prompt
    /// and its reply notes as before (`systemMessage(for:)`), then who
    /// answers (ModelIdentity). Its 80 tokens or so come out of
    /// `reservedTokens`, as the reply notes' do; Gemma's turns are fitted
    /// to the real count of the whole turn (GemmaService).
    public func systemTurn(for model: ModelSpec) -> String {
        systemMessage(for: model) + "\n" + ModelIdentity.of(model).systemNote(ownPrompt: !usesDefaultSystemPrompt)
    }
}

/// Who wrote a saved reply, as far as the record says (1.1.0 (296)), for
/// Smart Memory's note: a reply quoted from another model's chat is named
/// as that model's.
public struct ReplyAuthor: Equatable, Sendable {
    /// "Gemma 4 E2B", "Claude Opus 5.5", a PC model's name.
    public let name: String
    /// The on-device model's id; nil for Claude and a PC's model.
    public let modelID: String?

    /// A chat answered off the iPhone names its model itself (Claude, the
    /// PC). Otherwise the reply's own record (`ChatMessage.modelID`, kept
    /// since 296), or Smart Mode's (`SmartReply.modelID`, since 249). nil
    /// for an older reply: its chat's model is not proof of who wrote it
    /// (Smart Mode moves a chat between models, the Apple Watch asks
    /// Gemma 4 E2B in any chat), so it is named as unknown, never guessed.
    public static func of(_ reply: ChatMessage, in thread: ChatThread) -> ReplyAuthor? {
        guard reply.role == .assistant else { return nil }
        if let claude = thread.claude { return named(claude.modelName, fallback: "Claude") }
        if let pc = thread.pc { return named(pc.shortModel, fallback: "a model on the person's PC") }
        guard let id = reply.modelID ?? reply.smart?.modelID else { return nil }
        return ReplyAuthor(name: ModelSpec.named(id)?.name ?? label(id), modelID: id)
    }

    /// Whether the reply is surely `model`'s own.
    public func isModel(_ model: ModelSpec?) -> Bool { modelID != nil && modelID == model?.id }

    private static func named(_ name: String, fallback: String) -> ReplyAuthor {
        let name = label(name)
        return ReplyAuthor(name: name.isEmpty ? fallback : name, modelID: nil)
    }

    /// A name as the note writes it: one line, letters, digits and the few
    /// marks model names have, at most 40 characters. A PC's model name is
    /// the PC's text, not Fielua's.
    static func label(_ name: String) -> String {
        let allowed = name.unicodeScalars.filter { scalar in
            scalar.properties.isAlphabetic || scalar.properties.numericType != nil || " .-_:/+".unicodeScalars.contains(scalar)
        }
        return String(String(String.UnicodeScalarView(allowed)).trimmingCharacters(in: .whitespaces).prefix(40))
    }
}
