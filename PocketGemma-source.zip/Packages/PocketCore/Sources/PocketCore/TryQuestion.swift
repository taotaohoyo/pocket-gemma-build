import Foundation

/// 体験型おすすめ質問 (fielua-reports Issue #1, 2026-10-28, 「初回E2Bセットアップ
/// ＋体験型おすすめ質問」): three small chips over the field of an empty chat,
/// 「数学を解く」「文章を要約」「資料を作る」. A tap sends the chip's question,
/// written out in full, through the chat's own send, so the model chosen for
/// the chat answers it on the phone, as it would anything typed; nothing is
/// written in advance and the question and its reply are an ordinary chat.
/// The three were tried on Gemma 4 E2B. The chip's word and the question
/// follow the app's language (the String Catalog).
public enum TryQuestion: String, CaseIterable, Identifiable, Sendable {
    case math, summary, document

    public var id: String { rawValue }

    /// The chip's word.
    public var label: String {
        switch self {
        case .math: String(localized: "数学を解く")
        case .summary: String(localized: "文章を要約")
        case .document: String(localized: "資料を作る")
        }
    }

    /// What the chip sends: a question of its own, longer than its word,
    /// that needs nothing from the web.
    public var prompt: String { prompt(in: .main) }

    /// The question in the language of `bundle`'s table (an app language's
    /// .lproj; the E2B probe asks it in each), Japanese where it has none.
    public func prompt(in bundle: Bundle) -> String {
        switch self {
        case .math:
            String(localized: "48個のお菓子を6人で同じ数ずつ分けると1人何個？式と考え方を順番に説明してください。", bundle: bundle)
        case .summary:
            String(localized: "次の文を3つのポイントに要約してください。『学校の図書館では毎週金曜に読書イベントを開きます。参加者が好きな本を紹介し、感想を共有することで、新しい本に出会い、読書を楽しむ機会が増えています。』", bundle: bundle)
        case .document:
            String(localized: "小さなカフェの開業準備について、見出し・箇条書き・表・チェックリストを含む短いMarkdown資料を作成してください。", bundle: bundle)
        }
    }

    /// Whether a message is one of the questions, as the chips send it: the
    /// try questions never search the web, even in a chat whose search is
    /// on (the switch is left as it is), so what is tried stays on the phone.
    public static func isSample(_ text: String) -> Bool {
        let asked = text.trimmingCharacters(in: .whitespacesAndNewlines)
        return !asked.isEmpty && allCases.contains { $0.prompt == asked }
    }
}
