import Foundation

public enum ExecutionBackend: String, CaseIterable, Identifiable, Codable, Sendable {
    case gpu = "GPU", cpu = "CPU"
    public var id: String { rawValue }
}

public enum VisionCPUImplementation: String, CaseIterable, Identifiable, Codable, Sendable {
    case xnnpack, builtin
    public var id: String { rawValue }
    public var title: String { self == .xnnpack ? "標準（XNNPACK）" : "互換（組み込みCPU）" }
}

/// How E4B reads a chat's photos and writes its replies, chosen in the
/// composer (ModelSpec.photoDetails). On the phone E4B's photos fit at 70
/// image tokens with the language model on the GPU; at 140 that GPU run
/// failed, and with the language model on the CPU they fit with more room to
/// spare (the vision probe, 2026-10-20). Signed by the paid team with Extended
/// Virtual Addressing, the app had ten times the address space, and 280 fit
/// with the language model on the GPU (TestFlight 1.0.120, 2026-10-21).
///
/// Since 1.1.0 (248) the person chooses between two (`choices`, the user's
/// directive of 2026-10-31): 高速 and じっくり考える, which was さらに深く.
/// 深く is no longer a choice: it is how じっくり考える runs on a launch
/// without the address space for it (`running`), never thinking, and the
/// chat says so. A 深く saved before reads as じっくり考える (`choice`).
public enum PhotoDetail: String, CaseIterable, Identifiable, Codable, Sendable {
    /// 70 image tokens; the language model stays on its saved backend. Its
    /// replies are brief and never think, and its turns without photos
    /// decode with the model's MTP drafter (GenerationSettings.isFast).
    case fast
    /// 140 image tokens; the language model runs on the CPU while the chat
    /// has photos, so those replies are slower. Text-only chats keep the
    /// saved backend. The drafter as saved; never thinks
    /// (GenerationSettings.deeperFallsBack). じっくり考える's fallback where
    /// the launch lacks the room for it; a choice of its own until 1.1.0 (247).
    case deep
    /// じっくり考える (さらに深く until 1.1.0 (247)): 280 image tokens, E2B's,
    /// with the language model on its saved backend: on the phone a photo
    /// and a short reply took 2.0-2.2 s on the GPU, against 深く's 2.8 s on
    /// the CPU. Its replies always think first, with room of their own for
    /// it, and are asked to check their reasoning (GenerationSettings.isDeeper).
    /// Runs as itself only where the launch's address space has room for it
    /// (`deeperFits`), as 深く elsewhere.
    case deeper
    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .fast: String(localized: "高速")
        case .deep: String(localized: "深く")
        case .deeper: String(localized: "じっくり考える")
        }
    }
    public var imageTokens: Int {
        switch self {
        case .fast: 70
        case .deep: 140
        case .deeper: 280
        }
    }

    /// What the person chooses between, for a model with a choice
    /// (ModelSpec.photoDetails), on every launch.
    public static let choices: [PhotoDetail] = [.fast, .deeper]
    /// The choice a detail belongs to: 深く is じっくり考える's, whether it ran
    /// in its place or was saved before 1.1.0 (248), when it was a choice of
    /// its own.
    public var choice: PhotoDetail { self == .deep ? .deeper : self }
    /// What a choice runs as on this launch: じっくり考える as itself where the
    /// address space has room for it, as 深く where it hasn't.
    public var running: PhotoDetail { choice == .deeper && !Self.deeperFits ? .deep : choice }

    /// Whether this launch's address space has room for じっくり考える. Set
    /// once, by `offer(atLaunch:)` from the app's init, before any chat
    /// reads it.
    public private(set) static var deeperFits = false
    /// The largest free block of address space at launch that じっくり考える
    /// needs. E4B's engine on the GPU took about 7.0 GB of it and a photo at
    /// 280 about 1.2 GB more (TestFlight 1.0.120, 2026-10-21); the free
    /// Apple ID's 6.44 GB at launch ran out at 280 on the GPU (1.0.112), and
    /// with Extended Virtual Addressing the phone had 68.7 GB.
    public static let deeperAddressSpace: UInt64 = 16_000_000_000
    public static func offer(atLaunch space: AddressSpace?) {
        deeperFits = (space?.largestFree ?? 0) >= deeperAddressSpace
    }
}

public struct GenerationSettings: Codable, Equatable, Sendable {
    /// The default prompt as saved. 1.1.0 (183) and earlier sent it to the
    /// model as written; it now only marks the default, which the model
    /// reads as `defaultInstruction` and 構成 shows in the app's language.
    /// A prompt the person wrote is sent as written.
    public static let defaultSystemPrompt = "あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"
    /// What the model reads for the default prompt, in every app language:
    /// the same words in English. With the Japanese prompt Gemma answered
    /// "hi" in Japanese (1.1.0 (183)); in English it answered each message
    /// in its own language, after a chat in another language too. A longer
    /// instruction about the reply's language did worse: E2B answered "hi"
    /// in Chinese (real replies, run 40236656017).
    public static let defaultInstruction = "You are a kind and straightforward assistant. Please answer clearly in the same language as the user."
    /// What 高速 asks of E4B after the system prompt, for every turn: shorter
    /// replies finish sooner. A length, detail or format the person asks for
    /// still wins, and nothing is cut off (a fixed output cap stopped replies
    /// mid-sentence before 1.0.66). Its ~30 tokens come out of
    /// `reservedTokens`. In English since 1.1.0 (187), as the default
    /// prompt is: Japanese words here pulled replies to Japanese as the
    /// Japanese prompt did.
    public static let briefReplyNote = "Skip any preamble and keep the reply short and to the point. If the user asks for a length, level of detail or format, follow it."
    /// What じっくり考える asks of E4B after the system prompt, for every turn:
    /// to think the question through and check its reasoning before it
    /// answers. A length or format the person asks for still wins. Its ~50
    /// tokens come out of `reservedTokens`, as 高速's note does. In English
    /// since 1.1.0 (187), as 高速's is.
    public static let carefulReplyNote = "Before answering, make sure of what the question means and assumes, and think it through step by step. Check calculations and facts again, and give the reasons for your conclusion. If the user asks for a length or format, follow it."

    /// Phi-4-mini-reasoning's note after the system prompt
    /// (`ModelCapabilities.reasons`). With the system prompt alone it
    /// answered Japanese questions in Chinese 6 times in 9; with this note 8
    /// of 9 answers were Japanese, none Chinese, and 8 were right against 6
    /// (Arm CPU, thinking 1,536 tokens, run 40444282901, 1.1.0 (206)).
    public static let answerLanguageNote = "Write your final answer in the same language as the user's message: a question in Japanese gets its answer in Japanese, never in Chinese or English."

    public var maxTokens = 4096
    public var maxOutputTokens = 512
    public var topK = 40
    public var topP = 0.95
    public var temperature = 0.7
    public var visualTokenBudget = 280
    public var backend: ExecutionBackend = .gpu
    // Keep the language decoder on its saved backend; select the image
    // encoder independently. This is a compatibility candidate, not a claim
    // that CPU vision succeeds on every physical device.
    public var visionBackend: ExecutionBackend = .cpu
    // Explicit per-model choice. Never silently retry or migrate to builtin.
    public var visionCPUImplementation: VisionCPUImplementation = .xnnpack
    /// Used only by a model that offers the choice (ModelSpec.photoDetails);
    /// it sets that model's image tokens and how 高速 and じっくり考える reply
    /// (PhotoDetail). Normalized, it is what runs on this launch: 深く for
    /// じっくり考える without the room (PhotoDetail.running).
    public var photoDetail: PhotoDetail = .fast
    public var enableThinking = false
    public var enableSpeculativeDecoding = false
    public var systemPrompt = GenerationSettings.defaultSystemPrompt
    /// Smart Mode's settings for one turn (`tuned(_:for:)`), on top of the
    /// person's: how the reply goes about it and whether it thinks first,
    /// in place of the reply mode. Never saved (not a coding key), but part
    /// of the settings' identity, so a turn tuned otherwise starts its own
    /// conversation, as a changed reply mode does. nil outside Smart Mode.
    public var smart: SmartTuning?
    public init() {}
    /// A model's starting values, before the person changes any: a model
    /// that can't use the GPU starts on the CPU. Qwen keeps TopK 40 and TopP
    /// 0.95: neither those nor its model cards' 20 and 0.8 looped on varied
    /// requests (run 39369954741), but 20 and 0.8 put a file's injected line
    /// into Qwen3 0.6B's summary and turned a photo-text question back into
    /// the reply (run 39369957734); 40 and 0.95 passed both (run 39366612826).
    /// Phi-4-mini-reasoning starts on the CPU too (`startsOnGPU`). LFM3
    /// starts with its card's sampling (temperature 0.1, TopK 50, no TopP),
    /// with which it answered the Arm CPU check's Japanese questions (run
    /// 40788630913); LFM3-VL 2B (1.1.0 (234)) with the same, and
    /// LFM3-Omni 2B (236), whose card asks for greedy decoding: 0.1 is next
    /// to it, and answered its spoken question (run 40796978426).
    public init(for model: ModelSpec) {
        self.init()
        if !model.supportsGPU || !model.capabilities.startsOnGPU { backend = .cpu }
        if model.family == "LFM" { temperature = 0.1; topK = 50; topP = 1 }
    }

    private enum CodingKeys: String, CodingKey {
        case maxTokens, maxOutputTokens, topK, topP, temperature, visualTokenBudget
        case backend, visionBackend, visionCPUImplementation, photoDetail, enableThinking, enableSpeculativeDecoding, systemPrompt
    }
    public init(from decoder: Decoder) throws {
        self.init()
        let values = try decoder.container(keyedBy: CodingKeys.self)
        maxTokens = try values.decodeIfPresent(Int.self, forKey: .maxTokens) ?? maxTokens
        maxOutputTokens = try values.decodeIfPresent(Int.self, forKey: .maxOutputTokens) ?? maxOutputTokens
        topK = try values.decodeIfPresent(Int.self, forKey: .topK) ?? topK
        topP = try values.decodeIfPresent(Double.self, forKey: .topP) ?? topP
        temperature = try values.decodeIfPresent(Double.self, forKey: .temperature) ?? temperature
        visualTokenBudget = try values.decodeIfPresent(Int.self, forKey: .visualTokenBudget) ?? visualTokenBudget
        backend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .backend) ?? backend
        visionBackend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .visionBackend) ?? .cpu
        visionCPUImplementation = try values.decodeIfPresent(VisionCPUImplementation.self, forKey: .visionCPUImplementation) ?? .xnnpack
        photoDetail = (try? values.decodeIfPresent(PhotoDetail.self, forKey: .photoDetail)) ?? .fast
        enableThinking = try values.decodeIfPresent(Bool.self, forKey: .enableThinking) ?? enableThinking
        enableSpeculativeDecoding = try values.decodeIfPresent(Bool.self, forKey: .enableSpeculativeDecoding) ?? enableSpeculativeDecoding
        systemPrompt = try values.decodeIfPresent(String.self, forKey: .systemPrompt) ?? systemPrompt
    }
    public var reservedTokens: Int { max(128, min(512, maxTokens / 8)) }
    /// The room じっくり考える keeps for thinking besides the reply's: a
    /// quarter of the context, 1024 tokens at the default 4096. A turn's
    /// input gets that much less, so a long chat can't leave the thinking no
    /// room to answer in. Normalized settings carry じっくり考える only for a
    /// model that offers it, on a launch with the room for it.
    /// Smart Mode's thinking has the same room (SmartTuning.thinks).
    public var deeperThinkingTokens: Int {
        if let smart { return smart.thinks ? maxTokens / 4 : 0 }
        return photoDetail == .deeper && PhotoDetail.deeperFits ? maxTokens / 4 : 0
    }
    /// The room a reasoning model (Phi-4-mini-reasoning) keeps for the
    /// thinking it does before every answer: 3/8 of the context, 1,536
    /// tokens at 4,096, so with the reply's room it has the 2,048 its card
    /// asks for. Set by `normalized(for:)`; 0 for every other model.
    public private(set) var reasoningTokens = 0
    public static func reasoningRoom(contextTokens: Int) -> Int { contextTokens * 3 / 8 }
    /// The tokens a turn's input may take: the context less the reply's
    /// room, the reserve, and じっくり考える's or a reasoning model's thinking.
    public var inputTokenLimit: Int { maxTokens - maxOutputTokens - reservedTokens - deeperThinkingTokens - reasoningTokens }
    public var inputByteBudget: Int {
        max(0, min(16000, inputTokenLimit * 2) - modelPrompt.utf8.count)
    }

    /// Whether the prompt is the default one, which the model reads as
    /// `defaultInstruction`; any other text is the person's own.
    public var usesDefaultSystemPrompt: Bool { systemPrompt == Self.defaultSystemPrompt }
    /// The prompt as the model reads it: the default's instruction, or the
    /// person's prompt as written.
    public var modelPrompt: String { usesDefaultSystemPrompt ? Self.defaultInstruction : systemPrompt }

    public func normalized(for model: ModelSpec) -> Self {
        var copy = self
        copy.maxTokens = min(model.maximumContextTokens, max(1024, maxTokens))
        copy.maxOutputTokens = min(copy.maxTokens / 2, max(128, maxOutputTokens))
        copy.topK = min(64, max(1, topK))
        copy.topP = topP.isFinite ? min(1, max(0.01, topP)) : 0.95
        copy.temperature = temperature.isFinite ? min(2, max(0, temperature)) : 0.7
        if model.photoDetails.isEmpty {
            copy.photoDetail = .fast
            let budgets = model.chatVisualTokenBudgets
            copy.visualTokenBudget = budgets.contains(visualTokenBudget) ? visualTokenBudget : min(280, budgets.max() ?? 280)
        } else {
            // What the choice runs as on this launch: じっくり考える as 深く
            // where the address space lacks the room for it, and a 深く saved
            // before 1.1.0 (248) as じっくり考える where it has the room.
            copy.photoDetail = photoDetail.running
            // The detail that runs sets the image tokens, whatever was saved.
            copy.visualTokenBudget = copy.photoDetail.imageTokens
        }
        copy.systemPrompt = Self.prefix(systemPrompt, byteLimit: 4000)
        // 高速 never thinks; じっくり考える thinks whatever was saved, and its
        // fallback 深く never does (`thinks`). Both leave the saved choice as
        // it was.
        copy.enableThinking = model.supportsThinking && enableThinking && !copy.isFast(on: model)
        copy.reasoningTokens = model.capabilities.reasons ? Self.reasoningRoom(contextTokens: copy.maxTokens) : 0
        copy.enableSpeculativeDecoding = model.supportsSpeculation && enableSpeculativeDecoding
        // A model that can't use the GPU runs on the CPU, whatever was saved,
        // and one that can't use the CPU (12B) on the GPU.
        if !model.supportsGPU { copy.backend = .cpu }
        if !model.supportsCPU { copy.backend = .gpu }
        return copy
    }

    /// The language model's backend for a turn. 深く (じっくり考える without
    /// the room) moves a chat with photos to the CPU; without photos the
    /// saved backend stays, as it does for じっくり考える's photos. Normalized
    /// settings carry 深く only for a model that offers the choice.
    public func languageBackend(needsVision: Bool) -> ExecutionBackend {
        needsVision && photoDetail == .deep ? .cpu : backend
    }

    /// Whether these are E4B's 高速 settings: a model that offers photo
    /// details, with 高速 chosen. Other models read as 高速 after
    /// normalizing, so the model decides.
    /// Smart Mode's turns are none of the reply modes: their pace says how
    /// they reply (SmartTuning).
    public func isFast(on model: ModelSpec) -> Bool {
        smart == nil && !model.photoDetails.isEmpty && photoDetail == .fast
    }

    /// Whether these are E4B's じっくり考える settings, on a launch with the
    /// room for it (PhotoDetail.deeperFits).
    public func isDeeper(on model: ModelSpec) -> Bool {
        smart == nil && !model.photoDetails.isEmpty && photoDetail == .deeper && PhotoDetail.deeperFits
    }

    /// Whether じっくり考える is chosen on a launch without the room for it,
    /// so it runs as 深く: photos at 140 with the language model on the CPU,
    /// and no thinking. The chat and the menu say so; it never answers as
    /// another mode unannounced (the user's directive, 2026-10-31).
    public func deeperFallsBack(on model: ModelSpec) -> Bool {
        smart == nil && !model.photoDetails.isEmpty && photoDetail.choice == .deeper && !PhotoDetail.deeperFits
    }

    /// Whether a reply thinks before it answers: as saved, never in 高速 or
    /// in じっくり考える's fallback, and always in じっくり考える and on a
    /// reasoning model. Smart Mode's turns think as their tuning says,
    /// whatever was saved.
    public func thinks(on model: ModelSpec) -> Bool {
        if let smart { return model.supportsThinking && (model.capabilities.reasons || smart.thinks) }
        return model.supportsThinking && (model.capabilities.reasons || isDeeper(on: model)
            || enableThinking && !isFast(on: model) && !deeperFallsBack(on: model))
    }

    /// The most tokens a reply thinks for before the runtime makes it answer;
    /// 0 when it doesn't think. A saved thinking takes up to half the reply's
    /// room; じっくり考える and a reasoning model have room of their own
    /// (`deeperThinkingTokens`, `reasoningTokens`).
    public func thinkingTokenBudget(on model: ModelSpec) -> Int {
        guard thinks(on: model) else { return 0 }
        if model.capabilities.reasons { return Self.reasoningRoom(contextTokens: min(model.maximumContextTokens, maxTokens)) }
        if smart != nil { return deeperThinkingTokens }
        return isDeeper(on: model) ? deeperThinkingTokens : min(1024, maxOutputTokens / 2)
    }

    /// The system message a conversation starts with: the prompt as the
    /// model reads it, and 高速's request for brief replies or じっくり考える's
    /// for care, or Phi's note on the answer's language. じっくり考える's
    /// fallback (深く) asks for neither.
    ///
    /// A Smart Mode turn on Gemma 4 E4B or E2B gets its pace's note (高速's
    /// for a quick one, じっくり考える's for a careful one) and its task's
    /// (SmartTask.note); a stand-in model reads the prompt as before, as
    /// its replies were checked with it.
    public func systemMessage(for model: ModelSpec) -> String {
        if model.capabilities.reasons { return modelPrompt + " " + Self.answerLanguageNote }
        if let smart {
            guard SmartPlanner.starters.contains(model.id) else { return modelPrompt }
            var parts = [modelPrompt]
            switch smart.pace {
            case .quick: parts.append(Self.briefReplyNote)
            case .careful: parts.append(Self.carefulReplyNote)
            case .standard: break
            }
            if let note = smart.note { parts.append(note) }
            return parts.joined(separator: "\n")
        }
        if isFast(on: model) { return modelPrompt + "\n" + Self.briefReplyNote }
        if isDeeper(on: model) { return modelPrompt + "\n" + Self.carefulReplyNote }
        return modelPrompt
    }

    /// Whether a turn decodes with the model's MTP drafter (speculative
    /// decoding): as saved, and always for 高速's turns without photos. With
    /// photos E4B's 高速 leaves only ~0.28 GB of address space free on the
    /// phone (2026-10-20), so the drafter stays off there unless it was
    /// saved on. Google reports up to 2.2x faster decoding on phone GPUs
    /// with no change in quality; unmeasured on the phone so far.
    ///
    /// Smart Mode's turns decode as saved: a quick turn and a careful one
    /// then share the engine, which the drafter would make two (a reload of
    /// several seconds between them).
    public func speculativeDecoding(for model: ModelSpec, needsVision: Bool) -> Bool {
        if smart != nil { return enableSpeculativeDecoding }
        return enableSpeculativeDecoding || (model.supportsSpeculation && isFast(on: model) && !needsVision)
    }

    /// The settings of a Smart Mode turn: the person's for the model (its
    /// context, sampling, backends and prompt), with the turn's tuning in
    /// place of the reply mode, and E4B's photos at the tuning's detail as
    /// it runs on this launch (PhotoDetail.running).
    public func tuned(_ tuning: SmartTuning, for model: ModelSpec) -> GenerationSettings {
        var copy = self
        copy.smart = tuning
        if !model.photoDetails.isEmpty, let detail = tuning.photoDetail { copy.photoDetail = detail }
        return copy.normalized(for: model)
    }

    /// 1.0.105 and 1.0.106 saved Qwen3's settings with the CPU whatever was
    /// chosen, while its GPU build failed at 16-bit. Applied once, this moves
    /// that CPU to the GPU Qwen3 now runs on at 32-bit; a CPU chosen after
    /// that stays.
    public static func movingQwen3ToTheGPU(_ saved: [String: GenerationSettings]) -> [String: GenerationSettings] {
        var saved = saved
        if saved[ModelSpec.qwen3.id]?.backend == .cpu { saved[ModelSpec.qwen3.id]?.backend = .gpu }
        return saved
    }

    public static func prefix(_ text: String, byteLimit: Int) -> String {
        var result = "", count = 0
        for character in text {
            let next = String(character)
            guard count + next.utf8.count <= max(0, byteLimit) else { break }
            result += next
            count += next.utf8.count
        }
        return result
    }
}
