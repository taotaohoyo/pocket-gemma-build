import Foundation

public enum ExecutionBackend: String, CaseIterable, Identifiable, Codable, Sendable {
    case gpu = "GPU", cpu = "CPU"
    public var id: String { rawValue }
}

public enum VisionCPUImplementation: String, CaseIterable, Identifiable, Codable, Sendable {
    case xnnpack, builtin
    public var id: String { rawValue }
    public var title: String { self == .xnnpack ? "標準（XNNPACK）" : "互換（組み込みCPU）" }
}

/// How E4B reads a chat's photos and writes its replies, chosen in the
/// composer (ModelSpec.photoDetails). On the phone E4B's photos fit at 70
/// image tokens with the language model on the GPU; at 140 that GPU run
/// failed, and with the language model on the CPU they fit with more room to
/// spare (the vision probe, 2026-10-20). Signed by the paid team with Extended
/// Virtual Addressing, the app had ten times the address space, and 280 fit
/// with the language model on the GPU (TestFlight 1.0.120, 2026-10-21).
public enum PhotoDetail: String, CaseIterable, Identifiable, Codable, Sendable {
    /// 70 image tokens; the language model stays on its saved backend. Its
    /// replies are brief and never think, and its turns without photos
    /// decode with the model's MTP drafter (GenerationSettings.isFast).
    case fast
    /// 140 image tokens; the language model runs on the CPU while the chat
    /// has photos, so those replies are slower. Text-only chats keep the
    /// saved backend. Replies keep their length, thinking and drafter as
    /// saved.
    case deep
    /// 280 image tokens, E2B's, with the language model on its saved
    /// backend: on the phone a photo and a short reply took 2.0-2.2 s on the
    /// GPU, against 深く's 2.8 s on the CPU. Its replies always think first,
    /// with room of their own for it, and are asked to check their reasoning
    /// (GenerationSettings.isDeeper). Offered only where the launch's address
    /// space has room for it (`offered`).
    case deeper
    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .fast: String(localized: "高速")
        case .deep: String(localized: "深く")
        case .deeper: String(localized: "さらに深く")
        }
    }
    public var imageTokens: Int {
        switch self {
        case .fast: 70
        case .deep: 140
        case .deeper: 280
        }
    }

    /// The details this launch offers (ModelSpec.photoDetails): さらに深く
    /// only where the address space had room for it at launch. Set once, by
    /// `offer(atLaunch:)` from the app's init, before any chat reads it.
    public private(set) static var offered: [PhotoDetail] = [.fast, .deep]
    /// The largest free block of address space at launch that さらに深く
    /// needs. E4B's engine on the GPU took about 7.0 GB of it and a photo at
    /// 280 about 1.2 GB more (TestFlight 1.0.120, 2026-10-21); the free
    /// Apple ID's 6.44 GB at launch ran out at 280 on the GPU (1.0.112), and
    /// with Extended Virtual Addressing the phone had 68.7 GB.
    public static let deeperAddressSpace: UInt64 = 16_000_000_000
    public static func offer(atLaunch space: AddressSpace?) {
        offered = (space?.largestFree ?? 0) >= deeperAddressSpace ? allCases : [.fast, .deep]
    }
}

public struct GenerationSettings: Codable, Equatable, Sendable {
    /// The default prompt as saved. 1.1.0 (183) and earlier sent it to the
    /// model as written; it now only marks the default, which the model
    /// reads as `defaultInstruction` and 構成 shows in the app's language.
    /// A prompt the person wrote is sent as written.
    public static let defaultSystemPrompt = "あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"
    /// What the model reads for the default prompt, in every app language:
    /// the same words in English. With the Japanese prompt Gemma answered
    /// "hi" in Japanese (1.1.0 (183)); in English it answered each message
    /// in its own language, after a chat in another language too. A longer
    /// instruction about the reply's language did worse: E2B answered "hi"
    /// in Chinese (real replies, run 40236656017).
    public static let defaultInstruction = "You are a kind and straightforward assistant. Please answer clearly in the same language as the user."
    /// What 高速 asks of E4B after the system prompt, for every turn: shorter
    /// replies finish sooner. A length, detail or format the person asks for
    /// still wins, and nothing is cut off (a fixed output cap stopped replies
    /// mid-sentence before 1.0.66). Its ~30 tokens come out of
    /// `reservedTokens`. In English since 1.1.0 (187), as the default
    /// prompt is: Japanese words here pulled replies to Japanese as the
    /// Japanese prompt did.
    public static let briefReplyNote = "Skip any preamble and keep the reply short and to the point. If the user asks for a length, level of detail or format, follow it."
    /// What さらに深く asks of E4B after the system prompt, for every turn:
    /// to think the question through and check its reasoning before it
    /// answers. A length or format the person asks for still wins. Its ~50
    /// tokens come out of `reservedTokens`, as 高速's note does. In English
    /// since 1.1.0 (187), as 高速's is.
    public static let carefulReplyNote = "Before answering, make sure of what the question means and assumes, and think it through step by step. Check calculations and facts again, and give the reasons for your conclusion. If the user asks for a length or format, follow it."
    public var maxTokens = 4096
    public var maxOutputTokens = 512
    public var topK = 40
    public var topP = 0.95
    public var temperature = 0.7
    public var visualTokenBudget = 280
    public var backend: ExecutionBackend = .gpu
    // Keep the language decoder on its saved backend; select the image
    // encoder independently. This is a compatibility candidate, not a claim
    // that CPU vision succeeds on every physical device.
    public var visionBackend: ExecutionBackend = .cpu
    // Explicit per-model choice. Never silently retry or migrate to builtin.
    public var visionCPUImplementation: VisionCPUImplementation = .xnnpack
    /// Used only by a model that offers the choice (ModelSpec.photoDetails);
    /// it sets that model's image tokens and how 高速 and さらに深く reply
    /// (PhotoDetail).
    public var photoDetail: PhotoDetail = .fast
    public var enableThinking = false
    public var enableSpeculativeDecoding = false
    public var systemPrompt = GenerationSettings.defaultSystemPrompt
    public init() {}
    /// A model's starting values, before the person changes any: a model
    /// that can't use the GPU starts on the CPU. Qwen keeps TopK 40 and TopP
    /// 0.95: neither those nor its model cards' 20 and 0.8 looped on varied
    /// requests (run 39369954741), but 20 and 0.8 put a file's injected line
    /// into Qwen3 0.6B's summary and turned a photo-text question back into
    /// the reply (run 39369957734); 40 and 0.95 passed both (run 39366612826).
    public init(for model: ModelSpec) {
        self.init()
        if !model.supportsGPU { backend = .cpu }
    }

    private enum CodingKeys: String, CodingKey {
        case maxTokens, maxOutputTokens, topK, topP, temperature, visualTokenBudget
        case backend, visionBackend, visionCPUImplementation, photoDetail, enableThinking, enableSpeculativeDecoding, systemPrompt
    }
    public init(from decoder: Decoder) throws {
        self.init()
        let values = try decoder.container(keyedBy: CodingKeys.self)
        maxTokens = try values.decodeIfPresent(Int.self, forKey: .maxTokens) ?? maxTokens
        maxOutputTokens = try values.decodeIfPresent(Int.self, forKey: .maxOutputTokens) ?? maxOutputTokens
        topK = try values.decodeIfPresent(Int.self, forKey: .topK) ?? topK
        topP = try values.decodeIfPresent(Double.self, forKey: .topP) ?? topP
        temperature = try values.decodeIfPresent(Double.self, forKey: .temperature) ?? temperature
        visualTokenBudget = try values.decodeIfPresent(Int.self, forKey: .visualTokenBudget) ?? visualTokenBudget
        backend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .backend) ?? backend
        visionBackend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .visionBackend) ?? .cpu
        visionCPUImplementation = try values.decodeIfPresent(VisionCPUImplementation.self, forKey: .visionCPUImplementation) ?? .xnnpack
        photoDetail = (try? values.decodeIfPresent(PhotoDetail.self, forKey: .photoDetail)) ?? .fast
        enableThinking = try values.decodeIfPresent(Bool.self, forKey: .enableThinking) ?? enableThinking
        enableSpeculativeDecoding = try values.decodeIfPresent(Bool.self, forKey: .enableSpeculativeDecoding) ?? enableSpeculativeDecoding
        systemPrompt = try values.decodeIfPresent(String.self, forKey: .systemPrompt) ?? systemPrompt
    }
    public var reservedTokens: Int { max(128, min(512, maxTokens / 8)) }
    /// The room さらに深く keeps for thinking besides the reply's: a quarter
    /// of the context, 1024 tokens at the default 4096. A turn's input gets
    /// that much less, so a long chat can't leave the thinking no room to
    /// answer in. Normalized settings carry さらに深く only for a model that
    /// offers it.
    public var deeperThinkingTokens: Int { photoDetail == .deeper ? maxTokens / 4 : 0 }
    /// The tokens a turn's input may take: the context less the reply's
    /// room, the reserve, and さらに深く's thinking.
    public var inputTokenLimit: Int { maxTokens - maxOutputTokens - reservedTokens - deeperThinkingTokens }
    public var inputByteBudget: Int {
        max(0, min(16000, inputTokenLimit * 2) - modelPrompt.utf8.count)
    }

    /// Whether the prompt is the default one, which the model reads as
    /// `defaultInstruction`; any other text is the person's own.
    public var usesDefaultSystemPrompt: Bool { systemPrompt == Self.defaultSystemPrompt }
    /// The prompt as the model reads it: the default's instruction, or the
    /// person's prompt as written.
    public var modelPrompt: String { usesDefaultSystemPrompt ? Self.defaultInstruction : systemPrompt }

    public func normalized(for model: ModelSpec) -> Self {
        var copy = self
        copy.maxTokens = min(model.maximumContextTokens, max(1024, maxTokens))
        copy.maxOutputTokens = min(copy.maxTokens / 2, max(128, maxOutputTokens))
        copy.topK = min(64, max(1, topK))
        copy.topP = topP.isFinite ? min(1, max(0.01, topP)) : 0.95
        copy.temperature = temperature.isFinite ? min(2, max(0, temperature)) : 0.7
        if model.photoDetails.isEmpty {
            copy.photoDetail = .fast
            let budgets = model.chatVisualTokenBudgets
            copy.visualTokenBudget = budgets.contains(visualTokenBudget) ? visualTokenBudget : min(280, budgets.max() ?? 280)
        } else {
            // さらに深く saved where this launch doesn't offer it reads as 深く.
            if !model.photoDetails.contains(photoDetail) { copy.photoDetail = .deep }
            // The chosen detail sets the image tokens, whatever was saved.
            copy.visualTokenBudget = copy.photoDetail.imageTokens
        }
        copy.systemPrompt = Self.prefix(systemPrompt, byteLimit: 4000)
        // 高速 never thinks, and 深く keeps the saved choice. さらに深く thinks
        // whatever was saved (`thinks`) and leaves the choice as it was, for 深く.
        copy.enableThinking = model.supportsThinking && enableThinking && !copy.isFast(on: model)
        copy.enableSpeculativeDecoding = model.supportsSpeculation && enableSpeculativeDecoding
        // A model that can't use the GPU runs on the CPU, whatever was saved,
        // and one that can't use the CPU (12B) on the GPU.
        if !model.supportsGPU { copy.backend = .cpu }
        if !model.supportsCPU { copy.backend = .gpu }
        return copy
    }

    /// The language model's backend for a turn. 深く moves a chat with
    /// photos to the CPU; without photos the saved backend stays, as it does
    /// for さらに深く's photos. Normalized settings carry 深く only for a model
    /// that offers it.
    public func languageBackend(needsVision: Bool) -> ExecutionBackend {
        needsVision && photoDetail == .deep ? .cpu : backend
    }

    /// Whether these are E4B's 高速 settings: a model that offers photo
    /// details, with 高速 chosen. Other models read as 高速 after
    /// normalizing, so the model decides.
    public func isFast(on model: ModelSpec) -> Bool {
        !model.photoDetails.isEmpty && photoDetail == .fast
    }

    /// Whether these are E4B's さらに深く settings, on a launch that offers
    /// it (PhotoDetail.offered).
    public func isDeeper(on model: ModelSpec) -> Bool {
        model.photoDetails.contains(.deeper) && photoDetail == .deeper
    }

    /// Whether a reply thinks before it answers: as saved, never in 高速,
    /// and always in さらに深く.
    public func thinks(on model: ModelSpec) -> Bool {
        model.supportsThinking && (isDeeper(on: model) || enableThinking && !isFast(on: model))
    }

    /// The most tokens a reply thinks for before the runtime makes it answer;
    /// 0 when it doesn't think. A saved thinking takes up to half the reply's
    /// room; さらに深く has room of its own (`deeperThinkingTokens`).
    public func thinkingTokenBudget(on model: ModelSpec) -> Int {
        guard thinks(on: model) else { return 0 }
        return isDeeper(on: model) ? deeperThinkingTokens : min(1024, maxOutputTokens / 2)
    }

    /// The system message a conversation starts with: the prompt as the
    /// model reads it, and 高速's request for brief replies or さらに深く's
    /// for care.
    public func systemMessage(for model: ModelSpec) -> String {
        if isFast(on: model) { return modelPrompt + "\n" + Self.briefReplyNote }
        if isDeeper(on: model) { return modelPrompt + "\n" + Self.carefulReplyNote }
        return modelPrompt
    }

    /// Whether a turn decodes with the model's MTP drafter (speculative
    /// decoding): as saved, and always for 高速's turns without photos. With
    /// photos E4B's 高速 leaves only ~0.28 GB of address space free on the
    /// phone (2026-10-20), so the drafter stays off there unless it was
    /// saved on. Google reports up to 2.2x faster decoding on phone GPUs
    /// with no change in quality; unmeasured on the phone so far.
    public func speculativeDecoding(for model: ModelSpec, needsVision: Bool) -> Bool {
        enableSpeculativeDecoding || (model.supportsSpeculation && isFast(on: model) && !needsVision)
    }

    /// 1.0.105 and 1.0.106 saved Qwen3's settings with the CPU whatever was
    /// chosen, while its GPU build failed at 16-bit. Applied once, this moves
    /// that CPU to the GPU Qwen3 now runs on at 32-bit; a CPU chosen after
    /// that stays.
    public static func movingQwen3ToTheGPU(_ saved: [String: GenerationSettings]) -> [String: GenerationSettings] {
        var saved = saved
        if saved[ModelSpec.qwen3.id]?.backend == .cpu { saved[ModelSpec.qwen3.id]?.backend = .gpu }
        return saved
    }

    public static func prefix(_ text: String, byteLimit: Int) -> String {
        var result = "", count = 0
        for character in text {
            let next = String(character)
            guard count + next.utf8.count <= max(0, byteLimit) else { break }
            result += next
            count += next.utf8.count
        }
        return result
    }
}
