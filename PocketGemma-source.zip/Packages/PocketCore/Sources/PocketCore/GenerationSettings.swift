import Foundation

public enum ExecutionBackend: String, CaseIterable, Identifiable, Codable, Sendable {
    case gpu = "GPU", cpu = "CPU"
    public var id: String { rawValue }
}

public enum VisionCPUImplementation: String, CaseIterable, Identifiable, Codable, Sendable {
    case xnnpack, builtin
    public var id: String { rawValue }
    public var title: String { self == .xnnpack ? "標準（XNNPACK）" : "互換（組み込みCPU）" }
}

public struct GenerationSettings: Codable, Equatable, Sendable {
    public static let defaultSystemPrompt = "あなたは親切で率直なアシスタントです。ユーザーと同じ言語で、わかりやすく回答してください。"
    public var maxTokens = 4096
    public var maxOutputTokens = 512
    public var topK = 40
    public var topP = 0.95
    public var temperature = 0.7
    public var visualTokenBudget = 280
    public var backend: ExecutionBackend = .gpu
    // Keep the language decoder on its saved backend; select the image
    // encoder independently. This is a compatibility candidate, not a claim
    // that CPU vision succeeds on every physical device.
    public var visionBackend: ExecutionBackend = .cpu
    // Explicit per-model choice. Never silently retry or migrate to builtin.
    public var visionCPUImplementation: VisionCPUImplementation = .xnnpack
    public var enableThinking = false
    public var enableSpeculativeDecoding = false
    public var systemPrompt = GenerationSettings.defaultSystemPrompt
    public init() {}
    /// A model's starting values, before the person changes any: a model
    /// that can't use the GPU starts on the CPU. Qwen keeps TopK 40 and TopP
    /// 0.95: neither those nor its model cards' 20 and 0.8 looped on varied
    /// requests (run 39369954741), but 20 and 0.8 put a file's injected line
    /// into Qwen3 0.6B's summary and turned a photo-text question back into
    /// the reply (run 39369957734); 40 and 0.95 passed both (run 39366612826).
    public init(for model: ModelSpec) {
        self.init()
        if !model.supportsGPU { backend = .cpu }
    }

    private enum CodingKeys: String, CodingKey {
        case maxTokens, maxOutputTokens, topK, topP, temperature, visualTokenBudget
        case backend, visionBackend, visionCPUImplementation, enableThinking, enableSpeculativeDecoding, systemPrompt
    }
    public init(from decoder: Decoder) throws {
        self.init()
        let values = try decoder.container(keyedBy: CodingKeys.self)
        maxTokens = try values.decodeIfPresent(Int.self, forKey: .maxTokens) ?? maxTokens
        maxOutputTokens = try values.decodeIfPresent(Int.self, forKey: .maxOutputTokens) ?? maxOutputTokens
        topK = try values.decodeIfPresent(Int.self, forKey: .topK) ?? topK
        topP = try values.decodeIfPresent(Double.self, forKey: .topP) ?? topP
        temperature = try values.decodeIfPresent(Double.self, forKey: .temperature) ?? temperature
        visualTokenBudget = try values.decodeIfPresent(Int.self, forKey: .visualTokenBudget) ?? visualTokenBudget
        backend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .backend) ?? backend
        visionBackend = try values.decodeIfPresent(ExecutionBackend.self, forKey: .visionBackend) ?? .cpu
        visionCPUImplementation = try values.decodeIfPresent(VisionCPUImplementation.self, forKey: .visionCPUImplementation) ?? .xnnpack
        enableThinking = try values.decodeIfPresent(Bool.self, forKey: .enableThinking) ?? enableThinking
        enableSpeculativeDecoding = try values.decodeIfPresent(Bool.self, forKey: .enableSpeculativeDecoding) ?? enableSpeculativeDecoding
        systemPrompt = try values.decodeIfPresent(String.self, forKey: .systemPrompt) ?? systemPrompt
    }
    public var reservedTokens: Int { max(128, min(512, maxTokens / 8)) }
    public var inputByteBudget: Int {
        max(0, min(16000, (maxTokens - maxOutputTokens - reservedTokens) * 2) - systemPrompt.utf8.count)
    }

    public func normalized(for model: ModelSpec) -> Self {
        var copy = self
        copy.maxTokens = min(model.maximumContextTokens, max(1024, maxTokens))
        copy.maxOutputTokens = min(copy.maxTokens / 2, max(128, maxOutputTokens))
        copy.topK = min(64, max(1, topK))
        copy.topP = topP.isFinite ? min(1, max(0.01, topP)) : 0.95
        copy.temperature = temperature.isFinite ? min(2, max(0, temperature)) : 0.7
        copy.visualTokenBudget = model.visualTokenBudgets.contains(visualTokenBudget) ? visualTokenBudget : 280
        copy.systemPrompt = Self.prefix(systemPrompt, byteLimit: 4000)
        copy.enableThinking = model.supportsThinking && enableThinking
        copy.enableSpeculativeDecoding = model.supportsSpeculation && enableSpeculativeDecoding
        // A model that can't use the GPU runs on the CPU, whatever was saved.
        if !model.supportsGPU { copy.backend = .cpu }
        return copy
    }

    /// 1.0.105 and 1.0.106 saved Qwen3's settings with the CPU whatever was
    /// chosen, while its GPU build failed at 16-bit. Applied once, this moves
    /// that CPU to the GPU Qwen3 now runs on at 32-bit; a CPU chosen after
    /// that stays.
    public static func movingQwen3ToTheGPU(_ saved: [String: GenerationSettings]) -> [String: GenerationSettings] {
        var saved = saved
        if saved[ModelSpec.qwen3.id]?.backend == .cpu { saved[ModelSpec.qwen3.id]?.backend = .gpu }
        return saved
    }

    public static func prefix(_ text: String, byteLimit: Int) -> String {
        var result = "", count = 0
        for character in text {
            let next = String(character)
            guard count + next.utf8.count <= max(0, byteLimit) else { break }
            result += next
            count += next.utf8.count
        }
        return result
    }
}
