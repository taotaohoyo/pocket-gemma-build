import Foundation

/// The entitlements in an executable's own code signature, read from the
/// file (public file reads only; it maps nothing). iOS checks this signature
/// at launch, so the app can show what the installed build carries after
/// whoever signed it last, TestFlight's re-signing included.
public enum SignedEntitlements {
    /// Lets the app map a larger address space (Extended Virtual Addressing).
    public static let extendedVirtualAddressing = "com.apple.developer.kernel.extended-virtual-addressing"
    /// Raises the memory limit before iOS ends the app.
    public static let increasedMemoryLimit = "com.apple.developer.kernel.increased-memory-limit"
    public static let memoryKeys = [extendedVirtualAddressing, increasedMemoryLimit]

    /// The memory entitlements set to true in the signature of the
    /// executable at `url`, in `memoryKeys` order; nil when the file has no
    /// signature this can read.
    public static func memoryEntitlements(ofExecutableAt url: URL) -> [String]? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }
        let entitlements = Self.read { offset, count in
            guard (try? handle.seek(toOffset: offset)) != nil else { return nil }
            return try? handle.read(upToCount: count)
        }
        return entitlements.map(memoryEntitlements(in:))
    }

    public static func memoryEntitlements(in entitlements: [String: Any]) -> [String] {
        memoryKeys.filter { entitlements[$0] as? Bool == true }
    }

    /// The entitlements of a thin or universal Mach-O, read through
    /// `read(offset, count)`: empty when the signature has no entitlements,
    /// nil when there is no signature or it is malformed.
    public static func read(_ read: (UInt64, Int) -> Data?) -> [String: Any]? {
        func bytes(_ offset: UInt64, _ count: Int) -> Data? {
            guard count > 0 else { return Data() }
            guard let data = read(offset, count), data.count == count else { return nil }
            return data
        }
        guard let magic = bytes(0, 8) else { return nil }
        var slice: UInt64 = 0
        switch magic.bigEndian32(at: 0) {
        case 0xCAFE_BABE, 0xCAFE_BABF:
            // Universal binary: the arm64 slice, or the first.
            let wide = magic.bigEndian32(at: 0) == 0xCAFE_BABF
            let width = wide ? 32 : 20
            let count = Int(magic.bigEndian32(at: 4))
            guard (1...16).contains(count), let table = bytes(8, count * width) else { return nil }
            let offsets = (0..<count).map { index -> (cpu: UInt32, offset: UInt64) in
                let base = index * width
                let offset = wide ? table.bigEndian64(at: base + 8) : UInt64(table.bigEndian32(at: base + 8))
                return (table.bigEndian32(at: base), offset)
            }
            slice = (offsets.first { $0.cpu == 0x0100_000C } ?? offsets[0]).offset
        case 0xCFFA_EDFE:
            break
        default:
            return nil
        }
        // mach_header_64: ncmds and sizeofcmds, then the load commands.
        guard let header = bytes(slice, 32), header.littleEndian32(at: 0) == 0xFEED_FACF else { return nil }
        let commandBytes = Int(header.littleEndian32(at: 20))
        guard (0...1_048_576).contains(commandBytes), let commands = bytes(slice + 32, commandBytes) else { return nil }
        var position = 0
        var signature: (offset: UInt64, size: Int)?
        for _ in 0..<Int(header.littleEndian32(at: 16)) {
            guard position + 8 <= commands.count else { return nil }
            let command = commands.littleEndian32(at: position), size = Int(commands.littleEndian32(at: position + 4))
            guard size >= 8, position + size <= commands.count else { return nil }
            if command == 0x1D, size >= 16 {
                // LC_CODE_SIGNATURE: the signature's offset in this slice, and size.
                signature = (UInt64(commands.littleEndian32(at: position + 8)), Int(commands.littleEndian32(at: position + 12)))
            }
            position += size
        }
        guard let signature, signature.size >= 12, let superBlob = bytes(slice + signature.offset, 12),
              superBlob.bigEndian32(at: 0) == 0xFADE_0CC0 else { return nil }
        let slots = Int(superBlob.bigEndian32(at: 8))
        guard (0...64).contains(slots), 12 + slots * 8 <= signature.size,
              let index = bytes(slice + signature.offset + 12, slots * 8) else { return nil }
        // Slot 5 holds the entitlements as an XML property list.
        guard let entry = (0..<slots).first(where: { index.bigEndian32(at: $0 * 8) == 5 }) else { return [:] }
        let start = UInt64(index.bigEndian32(at: entry * 8 + 4))
        guard start + 8 <= UInt64(signature.size), let blob = bytes(slice + signature.offset + start, 8),
              blob.bigEndian32(at: 0) == 0xFADE_7171 else { return nil }
        let length = Int(blob.bigEndian32(at: 4))
        guard (8...1_048_576).contains(length), start + UInt64(length) <= UInt64(signature.size),
              let plist = bytes(slice + signature.offset + start + 8, length - 8) else { return nil }
        return (try? PropertyListSerialization.propertyList(from: plist, format: nil)) as? [String: Any]
    }
}

private extension Data {
    func bigEndian32(at offset: Int) -> UInt32 {
        self[startIndex + offset..<startIndex + offset + 4].reduce(0) { $0 << 8 | UInt32($1) }
    }
    func bigEndian64(at offset: Int) -> UInt64 {
        self[startIndex + offset..<startIndex + offset + 8].reduce(0) { $0 << 8 | UInt64($1) }
    }
    func littleEndian32(at offset: Int) -> UInt32 {
        self[startIndex + offset..<startIndex + offset + 4].reversed().reduce(0) { $0 << 8 | UInt32($1) }
    }
}
