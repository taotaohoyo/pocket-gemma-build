import Foundation

public enum VisionProbeKind: String, CaseIterable, Identifiable, Sendable {
    case squareJPEG, portraitJPEG, encoderDelegate, encoderBuiltin, adapterDelegate, adapterBuiltin
    public var id: String { rawValue }
    public var isComponent: Bool { self != .squareJPEG && self != .portraitJPEG }
    public var isEncoder: Bool { self == .encoderDelegate || self == .encoderBuiltin }
    public var usesBuiltin: Bool { self == .encoderBuiltin || self == .adapterBuiltin }
    public var title: String {
        switch self {
        case .squareJPEG: return "同梱JPEG・正方形（会話API）"
        case .portraitJPEG: return "同梱JPEG・縦長（会話API）"
        case .encoderDelegate: return "エンコーダー単体・XNNPACK"
        case .encoderBuiltin: return "エンコーダー単体・組み込みCPU"
        case .adapterDelegate: return "アダプター単体・XNNPACK"
        case .adapterBuiltin: return "アダプター単体・組み込みCPU"
        }
    }
}
