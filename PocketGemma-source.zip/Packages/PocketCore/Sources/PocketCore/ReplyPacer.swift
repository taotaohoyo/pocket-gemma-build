import Foundation

/// Lays a streaming reply's text out a step behind the model, at a steady
/// pace, so tokens that arrive in a burst (the first ones, held back while
/// the Aurora Orb shrinks away, or a batch after a stall) still read as
/// writing. The reply's text itself is untouched: the store, the archive,
/// copying and continuation keep the whole text, and only how much of it
/// is on screen trails. A reference, so the row's pacing task sees the
/// text as it grows while the row's view value is remade. Used on the main
/// actor by the message row.
///
/// The pace is unhurried: about three quarters of the model's own speed,
/// whatever that is on the device, measured over its last stretch of
/// writing, so the text reads as writing rather than as keeping up, and the
/// backlog that builds covers the model's pauses. It is bounded: the display
/// never falls more than about two seconds behind at its own pace, so a long
/// reply is shown at the model's speed two seconds behind it rather than
/// further and further behind. The text starts at that pace the moment its
/// place is free, and from then on the pace moves towards its target over a
/// few tenths of a second rather than at once, so a batch after a stall
/// speeds the text up gently; what remains when the reply ends runs on at
/// the pace the text had, neither rushed nor drawn out. The row passes the
/// pace on to the text views (ReplyCadence), which time each character to
/// it. A model slower than the least pace is shown as it writes, each piece
/// within a step of arriving.
public final class ReplyPacer {
    /// The display runs at this share of the model's own speed, so the text
    /// reads as unhurried writing rather than as keeping up...
    public static let relaxation = 0.75
    /// ...the speed measured over the model's last stretch of writing (from
    /// its first characters while they are younger than that).
    public static let rateWindow: TimeInterval = 2.5
    /// How far behind the display may fall at its own pace: a long reply is
    /// shown at the model's speed about this long behind it, and what
    /// remains when the reply ends runs on for at most about this long.
    public static let drainLag: TimeInterval = 2.0
    /// The display never gets ahead of its backlog: what has arrived is laid
    /// out over at least this long, so the first characters, and a batch
    /// after a pause, ramp rather than appear at once.
    public static let lagWhileWriting: TimeInterval = 1.0
    /// Characters per second at the least while the model writes: enough
    /// that the last characters of a backlog do not crawl, low enough that
    /// a slow model's backlog is kept rather than drained...
    public static let slowestWhileWriting = 12.0
    /// ...and once the reply has ended, so a short reply does not crawl.
    public static let slowestAfterEnd = 15.0
    /// How long the pace takes to close most of the way to its target
    /// while the model writes (a batch after a stall speeds the text up
    /// gently)...
    public static let paceSmoothing: TimeInterval = 0.3
    /// ...and once the reply has ended, so what remains runs on rather
    /// than rushing.
    public static let paceSmoothingAfterEnd: TimeInterval = 0.35
    /// The longest time one step covers, so a pause (a busy main thread,
    /// the app suspended) does not come back as a burst.
    public static let longestStep: TimeInterval = 0.15
    /// Posted when more of a reply is laid out, so the conversation follows
    /// the text as it grows, as it follows the model's text.
    public static let revealed = Notification.Name("PocketAI.replyTextRevealed")

    /// The model's text so far, and whether it is still writing.
    public var text: String
    public var generating: Bool
    /// While the orb holds the reply's place, nothing is laid out.
    public var held: Bool
    /// Characters laid out so far.
    public private(set) var shown: Int
    /// Characters per second now.
    public private(set) var pace = 0.0
    /// The model's speed of late, characters a second (0 before it has
    /// written anything).
    public private(set) var modelPace = 0.0
    private var carry = 0.0
    private var lastTick: TimeInterval?
    /// When the text last grew to each count, over the rate window.
    private var arrivals: [(at: TimeInterval, count: Int)] = []
    /// The pace the text had when the reply ended, kept until it is shown.
    private var paceAtEnd: Double?

    public init(text: String, generating: Bool, held: Bool, shown: Int) {
        self.text = text
        self.generating = generating
        self.held = held
        self.shown = shown
    }

    public var caughtUp: Bool { shown >= text.count }

    /// Lays out more of the text for the time since the last call, and
    /// returns the new count when it changed.
    public func advance(at now: TimeInterval) -> Int? {
        let elapsed = min(max(now - (lastTick ?? now), 0), Self.longestStep)
        lastTick = now
        let total = text.count
        if shown > total {
            // The text was replaced by a shorter one; the count follows.
            shown = total
            carry = 0
            arrivals.removeAll(keepingCapacity: true)
            paceAtEnd = nil
            return shown
        }
        if total > 0, arrivals.last?.count != total {
            arrivals.append((at: now, count: total))
        }
        guard !held else {
            carry = 0
            return nil
        }
        let backlog = total - shown
        modelPace = rate(at: now, total: total)
        // Unhurried: a share of the model's speed, yet never so slow that
        // the backlog outgrows the drain lag.
        let unhurried = max(Self.relaxation * modelPace, Double(backlog) / Self.drainLag)
        let target: Double
        if generating {
            paceAtEnd = nil
            target = max(Self.slowestWhileWriting, min(Double(backlog) / Self.lagWhileWriting, unhurried))
        } else {
            // What remains runs on at the pace the text had when the reply
            // ended: never slower, and faster only to keep within the lag.
            let kept = paceAtEnd ?? pace
            paceAtEnd = kept
            target = max(Self.slowestAfterEnd, kept, unhurried)
        }
        if pace == 0 {
            // The first step once the place is free: no ramp from nothing.
            pace = target
        } else {
            let smoothing = generating ? Self.paceSmoothing : Self.paceSmoothingAfterEnd
            pace += (target - pace) * (1 - exp(-elapsed / smoothing))
        }
        guard backlog > 0 else {
            carry = 0
            return nil
        }
        carry += pace * elapsed
        let step = min(Int(carry), backlog)
        guard step > 0 else { return nil }
        // A rich block (a chart) is laid out whole, never as its data.
        let end = MarkdownSource.pacedEnd(text, shown: shown, end: shown + Self.wholeSyntax(text, from: shown, step: step),
                                          generating: generating)
        guard end > shown else { return nil }
        carry = step < backlog ? carry - Double(step) : 0
        shown = end
        return shown
    }

    /// The model's speed of late: characters a second over the last
    /// `rateWindow` of its writing, or since its first characters while they
    /// are younger than that; 0 before it has written anything.
    private func rate(at now: TimeInterval, total: Int) -> Double {
        while arrivals.count >= 2, arrivals[1].at <= now - Self.rateWindow {
            arrivals.removeFirst()
        }
        guard let base = arrivals.first, now > base.at else { return 0 }
        return Double(max(total - base.count, 0)) / (now - base.at)
    }

    /// How long the row waits between steps: about 24 a second for a reply
    /// of ordinary length, down to 10 as it grows very long, since each step
    /// has the reply's last chunk parsed and laid out again (about 2 ms,
    /// 10-20 ms for the longest chunks), and a step's characters appear one
    /// after another (ReplyRevealBuffer's stagger) whatever the cadence.
    public static func interval(forLength count: Int) -> TimeInterval {
        let share = min(Double(max(count, 0)) / 16_000, 1)
        return 1.0 / 24 + share * (0.1 - 1.0 / 24)
    }

    /// Markdown and LaTeX syntax that should arrive whole: a step never ends
    /// inside a run of these, nor inside a backslash command's name, so
    /// unfinished syntax shows no more often than token streaming shows it.
    private static let syntax: Set<Character> = [
        "*", "_", "`", "$", "\\", "#", "|", "[", "]", "(", ")", "{", "}", "~", "<", ">", "!", "^",
    ]

    /// The step, extended past any syntax it would end inside. Steps count
    /// characters (grapheme clusters), so an emoji sequence or a combining
    /// mark is never split from what it belongs to.
    public static func wholeSyntax(_ text: String, from shown: Int, step: Int) -> Int {
        var end = text.index(text.startIndex, offsetBy: shown + step)
        var count = step
        var command = commandBefore(text, end)
        while end < text.endIndex {
            let next = text[end]
            if syntax.contains(next) {
                command = next == "\\"
            } else if !(command && next.isLetter) {
                break
            }
            end = text.index(after: end)
            count += 1
        }
        return count
    }

    /// Whether the text just before `end` is a backslash and letters: a
    /// command still being named.
    private static func commandBefore(_ text: String, _ end: String.Index) -> Bool {
        var index = end
        var letters = 0
        while index > text.startIndex, letters < 16 {
            index = text.index(before: index)
            let character = text[index]
            if character == "\\" { return true }
            guard character.isLetter else { return false }
            letters += 1
        }
        return false
    }
}
