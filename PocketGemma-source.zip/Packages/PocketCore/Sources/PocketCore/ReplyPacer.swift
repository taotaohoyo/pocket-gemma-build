import Foundation

/// Lays a streaming reply's text out a step behind the model, at a steady
/// pace, so tokens that arrive in a burst (the first ones, held back while
/// the Aurora Orb shrinks away, or a batch after a stall) still read as
/// writing. The reply's text itself is untouched: the store, the archive,
/// copying and continuation keep the whole text, and only how much of it
/// is on screen trails. A reference, so the row's pacing task sees the
/// text as it grows while the row's view value is remade. Used on the main
/// actor by the message row.
///
/// The pace follows the backlog, what the model has written that is not yet
/// shown: the display runs at the model's own speed about a second behind
/// it, whatever that speed is on the device, and the second of text in hand
/// covers the model's pauses. The text starts at that pace the moment its
/// place is free, and from then on the pace moves towards its target over a
/// few tenths of a second rather than at once, so a batch after a stall, or
/// the end of the reply, speeds the text up gently. A model slower than the
/// least pace is shown as it writes, each piece within a step of arriving.
public final class ReplyPacer {
    /// The display aims to be this far behind the model while it writes...
    public static let lagWhileWriting: TimeInterval = 1.0
    /// ...and lays out what remains this quickly once the reply has ended.
    public static let lagAfterEnd: TimeInterval = 0.4
    /// Characters per second at the least while the model writes: enough
    /// that the last characters of a backlog do not crawl, low enough that
    /// a slow model's backlog is kept rather than drained.
    public static let slowestWhileWriting = 12.0
    /// ...and once the reply has ended, so it finishes crisply.
    public static let slowestAfterEnd = 30.0
    /// How long the pace takes to close most of the way to its target.
    public static let paceSmoothing: TimeInterval = 0.2
    /// The longest time one step covers, so a pause (a busy main thread,
    /// the app suspended) does not come back as a burst.
    public static let longestStep: TimeInterval = 0.15
    /// Posted when more of a reply is laid out, so the conversation follows
    /// the text as it grows, as it follows the model's text.
    public static let revealed = Notification.Name("PocketAI.replyTextRevealed")

    /// The model's text so far, and whether it is still writing.
    public var text: String
    public var generating: Bool
    /// While the orb holds the reply's place, nothing is laid out.
    public var held: Bool
    /// Characters laid out so far.
    public private(set) var shown: Int
    /// Characters per second now.
    public private(set) var pace = 0.0
    private var carry = 0.0
    private var lastTick: TimeInterval?

    public init(text: String, generating: Bool, held: Bool, shown: Int) {
        self.text = text
        self.generating = generating
        self.held = held
        self.shown = shown
    }

    public var caughtUp: Bool { shown >= text.count }

    /// Lays out more of the text for the time since the last call, and
    /// returns the new count when it changed.
    public func advance(at now: TimeInterval) -> Int? {
        let elapsed = min(max(now - (lastTick ?? now), 0), Self.longestStep)
        lastTick = now
        let total = text.count
        if shown > total {
            // The text was replaced by a shorter one; the count follows.
            shown = total
            carry = 0
            return shown
        }
        guard !held else {
            carry = 0
            return nil
        }
        let backlog = total - shown
        let lag = generating ? Self.lagWhileWriting : Self.lagAfterEnd
        let slowest = generating ? Self.slowestWhileWriting : Self.slowestAfterEnd
        let target = max(slowest, Double(backlog) / lag)
        if pace == 0 {
            // The first step once the place is free: no ramp from nothing.
            pace = target
        } else {
            pace += (target - pace) * (1 - exp(-elapsed / Self.paceSmoothing))
        }
        guard backlog > 0 else {
            carry = 0
            return nil
        }
        carry += pace * elapsed
        let step = min(Int(carry), backlog)
        guard step > 0 else { return nil }
        carry = step < backlog ? carry - Double(step) : 0
        shown += Self.wholeSyntax(text, from: shown, step: step)
        return shown
    }

    /// How long the row waits between steps: about 24 a second for a reply
    /// of ordinary length, down to 10 as it grows very long, since each step
    /// has the reply's last chunk parsed and laid out again (about 2 ms,
    /// 10-20 ms for the longest chunks), and a step's characters appear one
    /// after another (ReplyRevealBuffer's stagger) whatever the cadence.
    public static func interval(forLength count: Int) -> TimeInterval {
        let share = min(Double(max(count, 0)) / 16_000, 1)
        return 1.0 / 24 + share * (0.1 - 1.0 / 24)
    }

    /// Markdown and LaTeX syntax that should arrive whole: a step never ends
    /// inside a run of these, nor inside a backslash command's name, so
    /// unfinished syntax shows no more often than token streaming shows it.
    private static let syntax: Set<Character> = [
        "*", "_", "`", "$", "\\", "#", "|", "[", "]", "(", ")", "{", "}", "~", "<", ">", "!", "^",
    ]

    /// The step, extended past any syntax it would end inside. Steps count
    /// characters (grapheme clusters), so an emoji sequence or a combining
    /// mark is never split from what it belongs to.
    public static func wholeSyntax(_ text: String, from shown: Int, step: Int) -> Int {
        var end = text.index(text.startIndex, offsetBy: shown + step)
        var count = step
        var command = commandBefore(text, end)
        while end < text.endIndex {
            let next = text[end]
            if syntax.contains(next) {
                command = next == "\\"
            } else if !(command && next.isLetter) {
                break
            }
            end = text.index(after: end)
            count += 1
        }
        return count
    }

    /// Whether the text just before `end` is a backslash and letters: a
    /// command still being named.
    private static func commandBefore(_ text: String, _ end: String.Index) -> Bool {
        var index = end
        var letters = 0
        while index > text.startIndex, letters < 16 {
            index = text.index(before: index)
            let character = text[index]
            if character == "\\" { return true }
            guard character.isLetter else { return false }
            letters += 1
        }
        return false
    }
}
