import Foundation

/// What the copy menus put on the pasteboard: a table as tab-separated
/// cells for a spreadsheet or as Markdown, formulas as they were written.
extension MarkdownTable {
    /// One line per row, cells separated by tabs, which Numbers, Excel and
    /// Google Sheets paste into cells.
    public var tabSeparated: String {
        ([header] + rows).map { row in
            row.map { MarkdownTable.plain($0).replacingOccurrences(of: "\t", with: " ") }.joined(separator: "\t")
        }.joined(separator: "\n")
    }

    /// The table as GitHub Markdown, with its column alignment and the
    /// cells' emphasis, code, links and formulas.
    public var markdown: String {
        func line(_ cells: [String]) -> String { "| " + cells.joined(separator: " | ") + " |" }
        let delimiters = header.indices.map { column -> String in
            let alignment: Alignment = column < alignments.count ? alignments[column] : .leading
            switch alignment {
            case .leading: return "---"
            case .center: return ":-:"
            case .trailing: return "--:"
            }
        }
        let cells = { (row: [AttributedString]) in row.map(MarkdownTable.markdownCell) }
        return ([line(cells(header)), line(delimiters)] + rows.map { line(cells($0)) }).joined(separator: "\n")
    }

    /// A cell back in Markdown: emphasis, strikethrough, code, links and
    /// formulas as written, `|` escaped so it stays inside the cell.
    static func markdownCell(_ text: AttributedString) -> String {
        var result = ""
        var previous: MarkdownMath?
        for run in text.runs {
            let math = run[MarkdownMathAttribute.self]
            defer { previous = math }
            if let math {
                if math != previous { result += math.raw.isEmpty ? "$\(math.latex)$" : math.raw }
                continue
            }
            var piece = String(text[run.range].characters).replacingOccurrences(of: "\n", with: " ")
            let intent = run.inlinePresentationIntent ?? []
            if intent.contains(.code) {
                piece = wrapped(piece, in: "`")
            } else {
                if intent.contains(.strikethrough) { piece = wrapped(piece, in: "~~") }
                if intent.contains(.emphasized) { piece = wrapped(piece, in: "*") }
                if intent.contains(.stronglyEmphasized) { piece = wrapped(piece, in: "**") }
            }
            // A bare address stays bare.
            if let link = run.link, piece != link.absoluteString { piece = "[\(piece)](\(link.absoluteString))" }
            result += piece
        }
        return result.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "|", with: "\\|")
    }

    /// `marker` around the text, with spaces at either end kept outside,
    /// where Markdown still reads it as emphasis.
    private static func wrapped(_ text: String, in marker: String) -> String {
        guard let first = text.firstIndex(where: { !$0.isWhitespace }),
              let last = text.lastIndex(where: { !$0.isWhitespace }) else { return text }
        return String(text[..<first]) + marker + String(text[first...last]) + marker + String(text[text.index(after: last)...])
    }

    /// What VoiceOver says on reaching the table: "表、2行、3列".
    public var spokenSummary: String { "表、\(rows.count)行、\(header.count)列" }

    /// A cell for VoiceOver: its column's header, then its text with each
    /// formula read out ("価格、x の 2 乗").
    public func spokenCell(row: Int, column: Int) -> String {
        guard rows.indices.contains(row), rows[row].indices.contains(column) else { return "" }
        let name = header.indices.contains(column) ? MarkdownTable.spoken(header[column]) : ""
        var value = MarkdownTable.spoken(rows[row][column])
        if value.isEmpty { value = "空欄" }
        return name.isEmpty ? value : "\(name)、\(value)"
    }

    /// A cell's text with each formula read out, for VoiceOver.
    public static func spoken(_ text: AttributedString) -> String {
        var result = ""
        var previous: MarkdownMath?
        for run in text.runs {
            let math = run[MarkdownMathAttribute.self]
            defer { previous = math }
            if let math {
                if math != previous { result += " " + MathSpeech.spoken(math.latex) + " " }
                continue
            }
            result += String(text[run.range].characters)
        }
        return result.split(whereSeparator: { $0 == " " || $0 == "\n" }).joined(separator: " ")
    }

    /// A cell's text with each formula as written (`$x^2$`) and line
    /// breaks as spaces.
    static func plain(_ text: AttributedString) -> String {
        var result = ""
        var previous: MarkdownMath?
        for run in text.runs {
            let math = run[MarkdownMathAttribute.self]
            defer { previous = math }
            if let math {
                // A formula split over runs is written once.
                if math != previous { result += math.raw.isEmpty ? math.latex : math.raw }
                continue
            }
            result += String(text[run.range].characters)
        }
        return result.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespaces)
    }
}
