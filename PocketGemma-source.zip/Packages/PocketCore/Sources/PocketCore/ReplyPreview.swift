import Foundation

/// 要点 beside the Aurora Orb (1.1.0 (302), the user's directive of
/// 2026-11-20): while a reply is written, a short point of what it has
/// said so far stands faint beside the orb in at most two lines, and
/// gives way to the next as the reply moves on. Which point, and when, is
/// ReplyPoints'; this is only how the points come and go: each comes in as
/// one piece, its characters one after another (ReplyPreviewLine), and a
/// new one takes the place of the one before, which rises away as it comes
/// (301's 生成中の一節, whose phrases were the reply's own newest words).
/// A plain class, used on the main actor by the message row.
public final class ReplyPreview {
    /// Characters of a point that came together: up to `count` (from the
    /// piece before), at `at` (reference-date seconds).
    public struct Piece: Equatable, Sendable {
        public let count: Int
        public let at: TimeInterval
        public init(count: Int, at: TimeInterval) {
            self.count = count
            self.at = at
        }
    }

    public struct Phrase: Equatable, Sendable {
        /// 1 for the reply's first point, and so on.
        public let number: Int
        public let text: String
        public let pieces: [Piece]
        public let shownAt: TimeInterval
        /// Its height laid out (points), and the height it eases from,
        /// since `heightAt` (a point's own height: it never grows).
        public let height: Double
        public let heightFrom: Double
        public let heightAt: TimeInterval
    }

    /// The point that gave way, and when.
    public struct Leaving: Equatable, Sendable {
        public let phrase: Phrase
        public let at: TimeInterval
    }

    /// The most lines a point takes.
    public static let lines = 2
    /// How long a point takes to give way (the view's), after which it is
    /// forgotten.
    public static let swapDuration: TimeInterval = 0.5
    /// How long a height eases (kept for the view's centring).
    public static let heightEase: TimeInterval = 0.3
    /// The first point's characters start this long after it is made,
    /// once the stage's words (書いています) have gone back into the orb
    /// (ReplyLight's 0.25 s), so the two never stand over each other...
    public static let firstDelay: TimeInterval = 0.25
    /// ...and a new point's just after the one giving way starts to go: a
    /// short cross-fade, the old already blurring, so the place beside the
    /// orb never stands empty nor holds two points at full strength (301).
    public static let swapDelay: TimeInterval = 0.05

    public private(set) var current: Phrase?
    public private(set) var previous: Leaving?
    /// When the reply's first point came (reference-date seconds): the
    /// stage's words give way to it.
    public private(set) var firstShownAt: TimeInterval?
    /// The width a point is laid out in (points), set by its view.
    public var width: Double = 0
    /// The slow motion for filming (1 in the app): each time above is this
    /// many times as long.
    public let timeScale: Double
    private var phrases = 0

    public init(timeScale: Double = 1) {
        self.timeScale = timeScale
    }

    /// Shows `point` from `now` in place of the one before, which gives
    /// way; `measure` gives its height laid out at the point's font.
    /// Returns whether anything shown changed (not for the same point).
    @discardableResult
    public func show(_ point: String, now: TimeInterval, measure: (String) -> Double) -> Bool {
        tidy(now: now)
        guard !point.isEmpty, point != current?.text else { return false }
        let delay = current == nil ? Self.firstDelay : Self.swapDelay
        if let current { previous = Leaving(phrase: current, at: now) }
        phrases += 1
        let height = measure(point)
        current = Phrase(number: phrases, text: point, pieces: [Piece(count: point.count, at: now + delay * timeScale)],
                         shownAt: now, height: height, heightFrom: height, heightAt: now)
        if firstShownAt == nil { firstShownAt = now }
        return true
    }

    /// Forgets the point that gave way once its fade is over. Returns
    /// whether it did.
    @discardableResult
    public func tidy(now: TimeInterval) -> Bool {
        guard let leaving = previous, now - leaving.at > Self.swapDuration * timeScale else { return false }
        previous = nil
        return true
    }

    /// The height a point shows at `now`.
    public static func height(of phrase: Phrase, at now: TimeInterval, timeScale: Double = 1) -> Double {
        let way = min(max((now - phrase.heightAt) / (heightEase * timeScale), 0), 1)
        let eased = way * way * (3 - 2 * way)
        return phrase.heightFrom + (phrase.height - phrase.heightFrom) * eased
    }
}

/// How the points read a reply's lines (ReplyOutline): words without
/// Markdown's marks (from 1.1.0 (297)'s glimpse and 301's phrases, which
/// read the same way).
public enum ReplyPreviewText {
    /// A reply's text as words, line by line without Markdown's marks
    /// (tables as their cells), for checks.
    public static func plain(_ text: String) -> String {
        withoutThoughts(text).split(separator: "\n").map { raw -> String in
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.hasPrefix("|") { return cellWords(line)?.joined(separator: " ") ?? "" }
            return plainLine(line)
        }.filter { !$0.isEmpty }.joined(separator: " ")
    }

    static let stops: Set<Character> = ["。", "！", "？", "!", "?", "．"]
    static let pauses: Set<Character> = ["、", "，", ",", "；", ";", "："]
    static let closers: Set<Character> = ["」", "』", "）", ")", "”", "’", "\"", "】", "〉", "》"]

    static func isHiragana(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        return (0x3041...0x309F).contains(scalar.value)
    }

    static func isJapanese(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        return (0x3040...0x30FF).contains(scalar.value) || (0x4E00...0x9FFF).contains(scalar.value)
    }

    /// A table's row as its cells' words; nil for the row of dashes under
    /// its head.
    static func cellWords(_ line: String) -> [String]? {
        let cells = line.split(separator: "|").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        if !cells.isEmpty, cells.allSatisfy({ $0.allSatisfy { ":-".contains($0) } }) { return nil }
        let words = cells.map(inline).filter { !$0.isEmpty }
        return words.isEmpty ? nil : words
    }

    /// A thinking model's thought, should one ever reach a reply's text:
    /// <think>…</think> and the like left out, an unclosed one to the end,
    /// and all before a closing tag that has no opening one.
    static func withoutThoughts(_ text: String) -> String {
        guard text.contains("<") else { return text }
        var result = text
        for tag in ["think", "thinking", "thought", "reasoning"] {
            let open = "<\(tag)>", close = "</\(tag)>"
            while let start = result.range(of: open, options: .caseInsensitive) {
                if let end = result.range(of: close, options: .caseInsensitive, range: start.upperBound..<result.endIndex) {
                    result.removeSubrange(start.lowerBound..<end.upperBound)
                } else {
                    result.removeSubrange(start.lowerBound..<result.endIndex)
                }
            }
            if let end = result.range(of: close, options: .caseInsensitive) {
                result.removeSubrange(result.startIndex..<end.upperBound)
            }
        }
        return result
    }

    /// --- *** ___ and the like.
    static func isRule(_ line: String) -> Bool {
        let marks = line.filter { $0 != " " }
        guard marks.count >= 3, let first = marks.first, "-*_".contains(first) else { return false }
        return marks.allSatisfy { $0 == first }
    }

    /// A line without its block marks (quotes, headings, list items, task
    /// boxes, in any nesting) and its inline ones.
    static func plainLine(_ line: String) -> String {
        var content = Substring(line)
        while let rest = afterBlockMark(content) { content = rest }
        return inline(String(content))
    }

    static func afterBlockMark(_ line: Substring) -> Substring? {
        let trimmed = line.drop { $0 == " " || $0 == "\t" }
        if trimmed.hasPrefix(">") { return trimmed.dropFirst() }
        if trimmed.first == "#" {
            let hashes = trimmed.prefix { $0 == "#" }.count
            let rest = trimmed.dropFirst(hashes)
            return hashes <= 6 && (rest.isEmpty || rest.first == " ") ? rest : nil
        }
        for mark in ["- ", "* ", "+ ", "[ ] ", "[x] ", "[X] "] where trimmed.hasPrefix(mark) {
            return trimmed.dropFirst(mark.count)
        }
        let digits = trimmed.prefix { $0.isASCII && $0.isNumber }
        if !digits.isEmpty, digits.count <= 3 {
            let rest = trimmed.dropFirst(digits.count)
            if rest.hasPrefix(". ") || rest.hasPrefix(") ") { return rest.dropFirst(2) }
        }
        return nil
    }

    /// A line's words without emphasis, code and strikethrough marks, links
    /// as their words, and without formulas (MarkdownSource's reading of
    /// them, and one still being written), pictures, footnote marks, tags
    /// and web addresses; spaces run together.
    static func inline(_ line: String) -> String {
        var math: [MarkdownMath] = []
        let characters = Array(MarkdownSource.extractInlineMath(line, into: &math))
        var output = ""
        var index = 0
        while index < characters.count {
            let character = characters[index]
            switch character {
            case MarkdownSource.mathOpen:
                // A formula: left out.
                index = (characters[index...].firstIndex(of: MarkdownSource.mathClose) ?? characters.count - 1) + 1
            case "\\":
                guard index + 1 < characters.count else { index += 1; continue }
                let next = characters[index + 1]
                if next.isLetter && next.isASCII {
                    // A command, a formula's: left out with its name.
                    index += 2
                    while index < characters.count, characters[index].isLetter, characters[index].isASCII { index += 1 }
                } else if next == "(" || next == "[" {
                    // A formula still being written: the rest of the line.
                    index = characters.count
                } else {
                    // An escaped mark is the mark itself.
                    output.append(next)
                    index += 2
                }
            case "$":
                // A formula still being written (`$x^2` with no closing
                // dollar yet): the rest of the line; a price stays.
                if index + 1 < characters.count, !characters[index + 1].isWhitespace,
                   MarkdownSource.looksLikeLaTeX(characters[(index + 1)...]) {
                    index = characters.count
                } else {
                    output.append(character)
                    index += 1
                }
            case "!" where index + 1 < characters.count && characters[index + 1] == "[":
                // A picture: left out.
                index = linkEnd(characters, from: index + 1)?.end ?? characters.count
            case "[":
                if index + 1 < characters.count, characters[index + 1] == "^" {
                    // A footnote mark.
                    index = (characters[index...].firstIndex(of: "]") ?? characters.count - 1) + 1
                } else if let link = linkEnd(characters, from: index) {
                    output += inline(String(characters[(index + 1)..<link.textEnd]))
                    index = link.end
                } else {
                    output.append(character)
                    index += 1
                }
            case "<":
                // A tag or an address in brackets, or one being written.
                index = (characters[index...].firstIndex(of: ">") ?? characters.count - 1) + 1
            case "*", "~", "`":
                index += 1
            case "_":
                // Between letters or digits (snake_case) it is a character.
                let before = index > 0 ? characters[index - 1] : " "
                let after = index + 1 < characters.count ? characters[index + 1] : " "
                if before.isASCII, before.isLetter || before.isNumber, after.isASCII, after.isLetter || after.isNumber {
                    output.append(character)
                }
                index += 1
            case "h" where starts("https://", characters, at: index) || starts("http://", characters, at: index):
                while index < characters.count, !characters[index].isWhitespace { index += 1 }
            default:
                output.append(character)
                index += 1
            }
        }
        return output.split(whereSeparator: { $0 == " " || $0 == "\t" }).joined(separator: " ")
    }

    /// `[words](address)` or `[words][name]` from the bracket at `start`:
    /// where its words end and where the link ends. Nil for a bracket that
    /// is not one (yet).
    private static func linkEnd(_ characters: [Character], from start: Int) -> (textEnd: Int, end: Int)? {
        guard start < characters.count, characters[start] == "[" else { return nil }
        var depth = 0
        var close: Int?
        for index in start..<characters.count {
            if characters[index] == "[" { depth += 1 }
            if characters[index] == "]" {
                depth -= 1
                if depth == 0 { close = index; break }
            }
        }
        guard let close, close + 1 < characters.count else { return nil }
        let opener = characters[close + 1]
        guard opener == "(" || opener == "[" else { return nil }
        let closer: Character = opener == "(" ? ")" : "]"
        // An address still being written: the link ends with the line.
        let end = characters[(close + 2)...].firstIndex(of: closer).map { $0 + 1 } ?? characters.count
        return (close, end)
    }

    private static func starts(_ prefix: String, _ characters: [Character], at index: Int) -> Bool {
        let marks = Array(prefix)
        guard index + marks.count <= characters.count else { return false }
        return Array(characters[index..<(index + marks.count)]) == marks
    }
}
