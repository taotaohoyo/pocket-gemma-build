import Foundation

/// 生成中の一節 (1.1.0 (301), the user's directive of 2026-11-20): beside
/// the Aurora Orb, while a reply is written, the newest words the model has
/// written, faint, in at most two lines. The orb writes on under the
/// reply's newest line; the reply's text above it is laid out as before
/// (ReplyPacer, a second or two behind the model), so the phrase beside the
/// orb is what the text is about to say.
///
/// Only the reply's own words are read, as the person will read them a
/// moment later: the models' thoughts never reach a reply's text (the
/// engines keep them apart) and a thought block is left out here too, and
/// so are Markdown's marks, formulas, tables' rules, charts' data, pictures
/// and link addresses. Code shows as its lines. Nothing is asked of a
/// model for it, nothing is summarised, and nothing is shown before the
/// model has written it: a phrase is always the words so far, from a place
/// where a clause, a line or a word begins.
///
/// A phrase begins with the reply's first words and grows as the model
/// writes. Once it fills its two lines, it stays at least `shortestLife`
/// (half a breath of the orb), then gives way to a new phrase: the newest
/// words that fit one line, from the start of a clause where there is one,
/// so it always has room to grow. A slow model's phrase grows a character
/// at a time; a fast one's changes every two seconds or so, never with
/// each token. A plain class, used on the main actor by the message row.
public final class ReplyPreview {
    /// Characters of a phrase that came together: up to `count` (from the
    /// piece before), at `at` (reference-date seconds).
    public struct Piece: Equatable, Sendable {
        public let count: Int
        public let at: TimeInterval
        public init(count: Int, at: TimeInterval) {
            self.count = count
            self.at = at
        }
    }

    public struct Phrase: Equatable, Sendable {
        /// 1 for the reply's first phrase, and so on.
        public let number: Int
        /// Where it starts in the reply's words (ReplyPreviewReader's count).
        public let start: Int
        public fileprivate(set) var text: String
        public fileprivate(set) var pieces: [Piece]
        public let shownAt: TimeInterval
        /// Its height laid out (points), and the height it eases from,
        /// since `heightAt`, when it grows to a second line.
        public fileprivate(set) var height: Double
        public fileprivate(set) var heightFrom: Double
        public fileprivate(set) var heightAt: TimeInterval
    }

    /// The phrase that gave way, and when.
    public struct Leaving: Equatable, Sendable {
        public let phrase: Phrase
        public let at: TimeInterval
    }

    /// The most lines a phrase takes.
    public static let lines = 2
    /// How long a full phrase shows before the next takes its place: half
    /// the orb's breath (AuroraOrbView.breathPeriod)...
    public static let shortestLife: TimeInterval = 1.8
    /// ...and once the reply has ended, so its last words still show.
    public static let shortestLifeAtEnd: TimeInterval = 0.9
    /// How often the row reads the reply for it at most.
    public static let interval: TimeInterval = 0.12
    /// How long a phrase takes to give way (the view's), after which it is
    /// forgotten.
    public static let swapDuration: TimeInterval = 0.5
    /// How long its height eases when it grows to its second line.
    public static let heightEase: TimeInterval = 0.3
    /// Pieces older than this are merged into one: they have long settled.
    static let settledAge: TimeInterval = 1.2
    /// How far back a new phrase may start (characters).
    static let reach = 140

    public private(set) var current: Phrase?
    public private(set) var previous: Leaving?
    /// The width a phrase is laid out in (points), set by its view.
    public var width: Double = 0
    /// The preview's slow motion for filming (1 in the app): each time
    /// above is this many times as long.
    public let timeScale: Double
    private var reader = ReplyPreviewReader()
    private var phrases = 0
    private var readerStarts = 0

    public init(timeScale: Double = 1) {
        self.timeScale = timeScale
    }

    /// Reads the reply's text so far (`source`, the model's) at `now`:
    /// starts, grows or replaces the phrase. `measure` gives a text's
    /// height laid out in `width` at the phrase's font, `lineHeight` one
    /// line's. Returns whether anything shown changed.
    @discardableResult
    public func update(source: String, ended: Bool, now: TimeInterval, lineHeight: Double,
                       measure: (String) -> Double) -> Bool {
        guard width > 0, lineHeight > 0 else { return false }
        let before = (current, previous)
        if let leaving = previous, now - leaving.at > Self.swapDuration * timeScale { previous = nil }
        reader.read(ReplyPreviewText.withoutThoughts(source))
        if reader.starts != readerStarts {
            // The reply's text was replaced (a reply written again): its
            // words start over, and so does the phrase.
            readerStarts = reader.starts
            current = nil
            previous = nil
        }
        let tip = reader.total
        func lines(_ height: Double) -> Int { max(1, Int(height / lineHeight + 0.2)) }
        guard var phrase = current else {
            if let first = reader.firstWords(), first < tip {
                current = newPhrase(from: first, tip: tip, now: now, lines: lines, measure: measure)
            }
            return before.0 != current || before.1 != previous
        }
        let whole = reader.text(from: phrase.start, to: tip)
        let height = measure(whole)
        if lines(height) <= Self.lines {
            grow(&phrase, to: whole, height: height, now: now)
            current = phrase
        } else if now - phrase.shownAt >= (ended ? Self.shortestLifeAtEnd : Self.shortestLife) * timeScale,
                  let start = nextStart(after: phrase.start, tip: tip, lines: lines, measure: measure) {
            previous = Leaving(phrase: phrase, at: now)
            current = newPhrase(from: start, tip: tip, now: now, lines: lines, measure: measure)
        } else {
            let fitted = longest(whole, lines: lines, measure: measure)
            grow(&phrase, to: fitted.text, height: fitted.height, now: now)
            current = phrase
        }
        return before.0 != current || before.1 != previous
    }

    /// The height a phrase shows at `now`, easing to its second line.
    public static func height(of phrase: Phrase, at now: TimeInterval, timeScale: Double = 1) -> Double {
        let way = min(max((now - phrase.heightAt) / (heightEase * timeScale), 0), 1)
        let eased = way * way * (3 - 2 * way)
        return phrase.heightFrom + (phrase.height - phrase.heightFrom) * eased
    }

    private func newPhrase(from start: Int, tip: Int, now: TimeInterval, lines: (Double) -> Int,
                           measure: (String) -> Double) -> Phrase {
        let whole = reader.text(from: start, to: tip)
        var text = whole
        var height = measure(whole)
        if lines(height) > Self.lines {
            let fitted = longest(whole, lines: lines, measure: measure)
            text = fitted.text
            height = fitted.height
        }
        phrases += 1
        return Phrase(number: phrases, start: start, text: text, pieces: [Piece(count: text.count, at: now)],
                      shownAt: now, height: height, heightFrom: height, heightAt: now)
    }

    /// The phrase as `text` now: what it had stays as it came, the rest is
    /// a new piece.
    private func grow(_ phrase: inout Phrase, to text: String, height: Double, now: TimeInterval) {
        guard text != phrase.text else { return }
        let common = zip(phrase.text, text).prefix { $0 == $1 }.count
        var pieces: [Piece] = []
        for piece in phrase.pieces {
            let count = min(piece.count, common)
            guard count > (pieces.last?.count ?? 0) else { break }
            // Long settled: one piece, drawn as it is (time 0).
            let at = now - piece.at > Self.settledAge * timeScale ? 0 : piece.at
            if at == 0, let last = pieces.last, last.at == 0 {
                pieces[pieces.count - 1] = Piece(count: count, at: 0)
            } else {
                pieces.append(Piece(count: count, at: at))
            }
        }
        if text.count > (pieces.last?.count ?? 0) { pieces.append(Piece(count: text.count, at: now)) }
        phrase.pieces = pieces
        phrase.text = text
        if abs(height - phrase.height) > 1 {
            phrase.heightFrom = Self.height(of: phrase, at: now, timeScale: timeScale)
            phrase.heightAt = now
            phrase.height = height
        }
    }

    /// The most of `text` from its start that fits the phrase's lines, cut
    /// before a word still being written in a language with spaces.
    private func longest(_ text: String, lines: (Double) -> Int, measure: (String) -> Double) -> (text: String, height: Double) {
        let characters = Array(text)
        var low = 1
        var high = characters.count
        var best = (text: String(characters.prefix(1)), height: measure(String(characters.prefix(1))))
        while low <= high {
            let middle = (low + high) / 2
            let candidate = String(characters.prefix(middle))
            let height = measure(candidate)
            if lines(height) <= Self.lines {
                best = (candidate, height)
                low = middle + 1
            } else {
                high = middle - 1
            }
        }
        let count = best.text.count
        if count < characters.count, characters[count].isASCII, characters[count].isLetter,
           characters[count - 1].isASCII, characters[count - 1].isLetter,
           let space = characters[max(0, count - 16)..<count].lastIndex(of: " "), space > 0 {
            let cut = String(characters[..<space])
            return (cut, measure(cut))
        }
        return best
    }

    /// Where the next phrase starts: the earliest place after the last
    /// phrase's start, a clause's or a line's start if it can, from which
    /// the newest words fit one line; else a word's start; else just the
    /// newest characters that fit. Nil when nothing new would show.
    private func nextStart(after start: Int, tip: Int, lines: (Double) -> Int, measure: (String) -> Double) -> Int? {
        let earliest = max(start + 1, tip - Self.reach, reader.base)
        guard earliest < tip else { return nil }
        func fitsOne(_ from: Int) -> Bool {
            let text = reader.text(from: from, to: tip)
            return !text.isEmpty && lines(measure(text)) <= 1
        }
        for candidate in reader.clauseStarts(from: earliest, to: tip) where fitsOne(candidate) { return candidate }
        for candidate in reader.wordStarts(from: earliest, to: tip) where fitsOne(candidate) { return candidate }
        var low = earliest
        var high = tip - 1
        var found: Int?
        while low <= high {
            let middle = (low + high) / 2
            if fitsOne(middle) {
                found = middle
                high = middle - 1
            } else {
                low = middle + 1
            }
        }
        return found
    }
}

/// The reply's words as the preview reads them (ReplyPreview): its lines
/// one after another with a space between, each without Markdown's marks
/// (ReplyPreviewText), code as its lines, tables as their cells; formulas,
/// charts' data, rules and fences left out. Lines that have ended are read
/// once; the line still being written is read again each time. Only the
/// last few hundred characters are kept; positions count from the start.
public struct ReplyPreviewReader {
    /// Characters kept behind the newest.
    static let keep = 1_200

    /// The words kept, and how many came before them.
    public private(set) var words: [Character] = []
    public private(set) var base = 0
    /// Where lines start (positions), the kept ones.
    public private(set) var lineStarts: [Int] = []
    /// How many times the source was found replaced and read afresh.
    public private(set) var starts = 0

    /// The settled words (ended lines) and the line still being written.
    private var settled: [Character] = []
    private var open: [Character] = []
    private var openStart: Int?
    /// Bytes of the source read as ended lines, and their last few, to see
    /// that the next text goes on from them.
    private var consumed = 0
    private var checkpoint: [UInt8] = []
    private var fence: String?
    /// A code block's contents show, except a chart's data.
    private var fenceShows = true
    private var mathEnd: String?

    public init() {}

    /// Every position up to this has a character.
    public var total: Int { base + words.count }

    public mutating func read(_ source: String) {
        let utf8 = source.utf8
        if utf8.count < consumed || !continues(source) {
            let count = starts + 1
            self = ReplyPreviewReader()
            starts = count
        }
        var start = utf8.index(utf8.startIndex, offsetBy: consumed)
        while let newline = utf8[start...].firstIndex(of: UInt8(ascii: "\n")) {
            commit(String(source[start..<newline]))
            start = utf8.index(after: newline)
        }
        consumed = utf8.distance(from: utf8.startIndex, to: start)
        checkpoint = Array(utf8[utf8.index(start, offsetBy: -min(consumed, 24))..<start])
        let rest = String(source[start...])
        open = Array(openLine(rest))
        openStart = nil
        words = settled
        if !open.isEmpty {
            if !words.isEmpty { words.append(" ") }
            openStart = base + words.count
            words += open
        }
        trim()
    }

    /// The words from `from` to `to` (positions), without spaces at the start.
    public func text(from: Int, to: Int) -> String {
        let lower = min(max(from - base, 0), words.count)
        let upper = min(max(to - base, lower), words.count)
        return String(String(words[lower..<upper]).drop { $0 == " " })
    }

    /// Where the first words start, once there is a letter or a digit.
    public func firstWords() -> Int? {
        guard words.contains(where: { $0.isLetter || $0.isNumber }) else { return nil }
        guard let index = words.firstIndex(where: { $0 != " " }) else { return nil }
        return base + index
    }

    /// The starts of clauses and lines from `from` up to `to`, in order: a
    /// line's first character, and the first character after 。！？!?、，,；;：
    /// (with a closing quote or bracket) and the spaces after it.
    public func clauseStarts(from: Int, to: Int) -> [Int] {
        var result: [Int] = []
        let lines = Set(lineStarts).union(openStart.map { [$0] } ?? [])
        let lower = max(from - base, 0)
        let upper = min(to - base, words.count)
        guard lower < upper else { return [] }
        for index in lower..<upper {
            let position = base + index
            if lines.contains(position) { result.append(position); continue }
            guard index > 0 else { continue }
            var back = index - 1
            while back > 0, words[back] == " " { back -= 1 }
            while back > 0, ReplyPreviewText.closers.contains(words[back]) { back -= 1 }
            let previous = words[back]
            let stop = ReplyPreviewText.stops.contains(previous) || ReplyPreviewText.pauses.contains(previous)
                || (previous == "." && back + 1 < words.count && words[back + 1] == " ")
            if stop, words[index] != " ", !ReplyPreviewText.closers.contains(words[index]) { result.append(position) }
        }
        return result
    }

    /// The starts of words from `from` up to `to`, in order: after a space,
    /// and in Japanese where a run of hiragana (a particle or an ending)
    /// gives way to a kanji or katakana word.
    public func wordStarts(from: Int, to: Int) -> [Int] {
        var result: [Int] = []
        let lower = max(from - base, 1)
        let upper = min(to - base, words.count)
        guard lower < upper else { return [] }
        for index in lower..<upper {
            let previous = words[index - 1], character = words[index]
            if previous == " " && character != " " {
                result.append(base + index)
            } else if ReplyPreviewText.isHiragana(previous), !ReplyPreviewText.isHiragana(character),
                      ReplyPreviewText.isJapanese(character), character != "ー" {
                result.append(base + index)
            }
        }
        return result
    }

    // MARK: Reading

    private func continues(_ source: String) -> Bool {
        guard consumed > 0 else { return true }
        let utf8 = source.utf8
        guard utf8.count >= consumed else { return false }
        let end = utf8.index(utf8.startIndex, offsetBy: consumed)
        let from = utf8.index(end, offsetBy: -checkpoint.count)
        return utf8[from..<end].elementsEqual(checkpoint)
    }

    /// An ended line, read once.
    private mutating func commit(_ raw: String) {
        let line = raw.trimmingCharacters(in: .whitespaces)
        if let open = fence {
            if line.hasPrefix(open) {
                fence = nil
                append(nil)
            } else {
                append(fenceShows ? line : nil)
            }
            return
        }
        if let end = mathEnd {
            let closes = end == "\\end{" ? line.contains(end) : line.hasSuffix(end)
            if closes { mathEnd = nil }
            append(nil)
            return
        }
        if line.hasPrefix("```") || line.hasPrefix("~~~") {
            fence = String(line.prefix(3))
            let info = line.dropFirst(3).trimmingCharacters(in: .whitespaces).lowercased()
            fenceShows = !(info.hasPrefix("chart") || info.hasPrefix("json"))
            append(nil)
            return
        }
        if line.hasPrefix("$$") {
            if !(line.count >= 4 && line.hasSuffix("$$")) { mathEnd = "$$" }
            append(nil)
            return
        }
        if line.hasPrefix("\\[") {
            if !line.hasSuffix("\\]") { mathEnd = "\\]" }
            append(nil)
            return
        }
        if line.hasPrefix("\\begin{") {
            if !line.contains("\\end{") { mathEnd = "\\end{" }
            append(nil)
            return
        }
        if line.hasPrefix("|") {
            append(ReplyPreviewText.cells(line))
            return
        }
        append(ReplyPreviewText.isRule(line) ? nil : ReplyPreviewText.plainLine(line))
    }

    /// The line still being written, as it reads so far.
    private func openLine(_ raw: String) -> String {
        let line = raw.trimmingCharacters(in: .whitespaces)
        if let open = fence { return line.hasPrefix(open) || !fenceShows ? "" : line }
        if mathEnd != nil { return "" }
        for mark in ["```", "~~~", "$$", "\\[", "\\begin"] where line.hasPrefix(mark) { return "" }
        if line.hasPrefix("|") { return ReplyPreviewText.cells(line) ?? "" }
        // `---` may yet be a rule: nothing until it is something else.
        if !line.isEmpty, line.allSatisfy({ "-*_ ".contains($0) }) { return "" }
        return ReplyPreviewText.plainLine(line)
    }

    private mutating func append(_ line: String?) {
        guard let line, !line.isEmpty else { return }
        if !settled.isEmpty { settled.append(" ") }
        lineStarts.append(base + settled.count)
        settled += Array(line)
    }

    private mutating func trim() {
        let extra = settled.count - Self.keep
        guard extra > 200 else { return }
        settled.removeFirst(extra)
        words.removeFirst(min(extra, words.count))
        base += extra
        lineStarts.removeAll { $0 < base }
        if let start = openStart, start < base { openStart = nil }
    }
}

/// What the preview reads of a reply's lines: words without Markdown's
/// marks (from 1.1.0 (297)'s glimpse, which read the same way).
public enum ReplyPreviewText {
    static let stops: Set<Character> = ["。", "！", "？", "!", "?", "．"]
    static let pauses: Set<Character> = ["、", "，", ",", "；", ";", "："]
    static let closers: Set<Character> = ["」", "』", "）", ")", "”", "’", "\"", "】", "〉", "》"]

    static func isHiragana(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        return (0x3041...0x309F).contains(scalar.value)
    }

    static func isJapanese(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        return (0x3040...0x30FF).contains(scalar.value) || (0x4E00...0x9FFF).contains(scalar.value)
    }

    /// A table's row as its cells' words, two spaces between; nil for the
    /// row of dashes under its head.
    static func cells(_ line: String) -> String? {
        let cells = line.split(separator: "|").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
        if !cells.isEmpty, cells.allSatisfy({ $0.allSatisfy { ":-".contains($0) } }) { return nil }
        let words = cells.map(inline).filter { !$0.isEmpty }
        return words.isEmpty ? nil : words.joined(separator: "  ")
    }

    /// A thinking model's thought, should one ever reach a reply's text:
    /// <think>…</think> and the like left out, an unclosed one to the end,
    /// and all before a closing tag that has no opening one.
    static func withoutThoughts(_ text: String) -> String {
        guard text.contains("<") else { return text }
        var result = text
        for tag in ["think", "thinking", "thought", "reasoning"] {
            let open = "<\(tag)>", close = "</\(tag)>"
            while let start = result.range(of: open, options: .caseInsensitive) {
                if let end = result.range(of: close, options: .caseInsensitive, range: start.upperBound..<result.endIndex) {
                    result.removeSubrange(start.lowerBound..<end.upperBound)
                } else {
                    result.removeSubrange(start.lowerBound..<result.endIndex)
                }
            }
            if let end = result.range(of: close, options: .caseInsensitive) {
                result.removeSubrange(result.startIndex..<end.upperBound)
            }
        }
        return result
    }

    /// --- *** ___ and the like.
    static func isRule(_ line: String) -> Bool {
        let marks = line.filter { $0 != " " }
        guard marks.count >= 3, let first = marks.first, "-*_".contains(first) else { return false }
        return marks.allSatisfy { $0 == first }
    }

    /// A line without its block marks (quotes, headings, list items, task
    /// boxes, in any nesting) and its inline ones.
    static func plainLine(_ line: String) -> String {
        var content = Substring(line)
        while let rest = afterBlockMark(content) { content = rest }
        return inline(String(content))
    }

    private static func afterBlockMark(_ line: Substring) -> Substring? {
        let trimmed = line.drop { $0 == " " || $0 == "\t" }
        if trimmed.hasPrefix(">") { return trimmed.dropFirst() }
        if trimmed.first == "#" {
            let hashes = trimmed.prefix { $0 == "#" }.count
            let rest = trimmed.dropFirst(hashes)
            return hashes <= 6 && (rest.isEmpty || rest.first == " ") ? rest : nil
        }
        for mark in ["- ", "* ", "+ ", "[ ] ", "[x] ", "[X] "] where trimmed.hasPrefix(mark) {
            return trimmed.dropFirst(mark.count)
        }
        let digits = trimmed.prefix { $0.isASCII && $0.isNumber }
        if !digits.isEmpty, digits.count <= 3 {
            let rest = trimmed.dropFirst(digits.count)
            if rest.hasPrefix(". ") || rest.hasPrefix(") ") { return rest.dropFirst(2) }
        }
        return nil
    }

    /// A line's words without emphasis, code and strikethrough marks, links
    /// as their words, and without formulas (MarkdownSource's reading of
    /// them, and one still being written), pictures, footnote marks, tags
    /// and web addresses; spaces run together.
    static func inline(_ line: String) -> String {
        var math: [MarkdownMath] = []
        let characters = Array(MarkdownSource.extractInlineMath(line, into: &math))
        var output = ""
        var index = 0
        while index < characters.count {
            let character = characters[index]
            switch character {
            case MarkdownSource.mathOpen:
                // A formula: left out.
                index = (characters[index...].firstIndex(of: MarkdownSource.mathClose) ?? characters.count - 1) + 1
            case "\\":
                guard index + 1 < characters.count else { index += 1; continue }
                let next = characters[index + 1]
                if next.isLetter && next.isASCII {
                    // A command, a formula's: left out with its name.
                    index += 2
                    while index < characters.count, characters[index].isLetter, characters[index].isASCII { index += 1 }
                } else if next == "(" || next == "[" {
                    // A formula still being written: the rest of the line.
                    index = characters.count
                } else {
                    // An escaped mark is the mark itself.
                    output.append(next)
                    index += 2
                }
            case "$":
                // A formula still being written (`$x^2` with no closing
                // dollar yet): the rest of the line; a price stays.
                if index + 1 < characters.count, !characters[index + 1].isWhitespace,
                   MarkdownSource.looksLikeLaTeX(characters[(index + 1)...]) {
                    index = characters.count
                } else {
                    output.append(character)
                    index += 1
                }
            case "!" where index + 1 < characters.count && characters[index + 1] == "[":
                // A picture: left out.
                index = linkEnd(characters, from: index + 1)?.end ?? characters.count
            case "[":
                if index + 1 < characters.count, characters[index + 1] == "^" {
                    // A footnote mark.
                    index = (characters[index...].firstIndex(of: "]") ?? characters.count - 1) + 1
                } else if let link = linkEnd(characters, from: index) {
                    output += inline(String(characters[(index + 1)..<link.textEnd]))
                    index = link.end
                } else {
                    output.append(character)
                    index += 1
                }
            case "<":
                // A tag or an address in brackets, or one being written.
                index = (characters[index...].firstIndex(of: ">") ?? characters.count - 1) + 1
            case "*", "~", "`":
                index += 1
            case "_":
                // Between letters or digits (snake_case) it is a character.
                let before = index > 0 ? characters[index - 1] : " "
                let after = index + 1 < characters.count ? characters[index + 1] : " "
                if before.isASCII, before.isLetter || before.isNumber, after.isASCII, after.isLetter || after.isNumber {
                    output.append(character)
                }
                index += 1
            case "h" where starts("https://", characters, at: index) || starts("http://", characters, at: index):
                while index < characters.count, !characters[index].isWhitespace { index += 1 }
            default:
                output.append(character)
                index += 1
            }
        }
        return output.split(whereSeparator: { $0 == " " || $0 == "\t" }).joined(separator: " ")
    }

    /// `[words](address)` or `[words][name]` from the bracket at `start`:
    /// where its words end and where the link ends. Nil for a bracket that
    /// is not one (yet).
    private static func linkEnd(_ characters: [Character], from start: Int) -> (textEnd: Int, end: Int)? {
        guard start < characters.count, characters[start] == "[" else { return nil }
        var depth = 0
        var close: Int?
        for index in start..<characters.count {
            if characters[index] == "[" { depth += 1 }
            if characters[index] == "]" {
                depth -= 1
                if depth == 0 { close = index; break }
            }
        }
        guard let close, close + 1 < characters.count else { return nil }
        let opener = characters[close + 1]
        guard opener == "(" || opener == "[" else { return nil }
        let closer: Character = opener == "(" ? ")" : "]"
        // An address still being written: the link ends with the line.
        let end = characters[(close + 2)...].firstIndex(of: closer).map { $0 + 1 } ?? characters.count
        return (close, end)
    }

    private static func starts(_ prefix: String, _ characters: [Character], at index: Int) -> Bool {
        let marks = Array(prefix)
        guard index + marks.count <= characters.count else { return false }
        return Array(characters[index..<(index + marks.count)]) == marks
    }
}
