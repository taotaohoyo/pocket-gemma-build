import Foundation

/// 起動時のチャット (user, 2026-10-25 13:55 UTC, 「起動時のチャット選択機能・オン
/// ボーディング拡張」): what Fielua shows when it is launched. 前回の会話 opens
/// the chat that was open when it was last left, as it was, its unsent
/// text too; 新しいチャット opens a new chat with the keyboard up, and a small
/// capsule over the field goes back to the chat of before. Only a launch
/// chooses: coming back from the background leaves the chat as it is.
public enum LaunchChatMode: String, CaseIterable, Identifiable, Sendable {
    case resume, newChat

    public var id: String { rawValue }
    public static let storageKey = "launch-chat-v1"
    /// 起動時にキーボードを開いておく (1.1.0 (161) to (181)): on, a launch
    /// opened a new chat with the keyboard up, which 新しいチャット does now;
    /// off, the chat stayed as it was.
    public static let legacyKeyboardKey = "keyboard-at-launch-v1"

    /// Before the choice is first read: a phone that had the switch keeps
    /// what its launches did. The switch's key goes either way, so the two
    /// can never say different things.
    public static func migrate(_ defaults: UserDefaults = .standard) {
        defer { defaults.removeObject(forKey: legacyKeyboardKey) }
        guard defaults.string(forKey: storageKey) == nil, defaults.object(forKey: legacyKeyboardKey) != nil else { return }
        let mode: LaunchChatMode = defaults.bool(forKey: legacyKeyboardKey) ? .newChat : .resume
        defaults.set(mode.rawValue, forKey: storageKey)
    }

    /// The choice; 前回の会話 until another is made, as launches were before.
    public static func current(_ defaults: UserDefaults = .standard) -> LaunchChatMode {
        defaults.string(forKey: storageKey).flatMap(Self.init(rawValue:)) ?? .resume
    }
}

/// Which chats a launch opens and offers.
public enum LaunchChatPlan {
    /// The chat open when Fielua last left the screen.
    public static let lastOpenKey = "chat-last-open-v1"

    public static func remember(_ id: UUID?, _ defaults: UserDefaults = .standard) {
        if let id { defaults.set(id.uuidString, forKey: lastOpenKey) } else { defaults.removeObject(forKey: lastOpenKey) }
    }
    public static func lastOpen(_ defaults: UserDefaults = .standard) -> UUID? {
        defaults.string(forKey: lastOpenKey).flatMap(UUID.init(uuidString:))
    }

    /// The chat a launch opens on: the one last open, while it is there,
    /// else the latest (`threads` newest first).
    public static func opening(_ threads: [ChatThread], lastOpen: UUID?) -> UUID? {
        if let lastOpen, threads.contains(where: { $0.id == lastOpen }) { return lastOpen }
        return threads.first?.id
    }

    /// 「前回の会話に戻る」's chat: the one open before the launch, when it has
    /// messages, else the chat with messages last written in. Never the new
    /// chat itself; nil when there is nothing to go back to.
    public static func returnTarget(_ threads: [ChatThread], before: UUID?, newChat: UUID) -> UUID? {
        let written = threads.filter { $0.id != newChat && !$0.messages.isEmpty }
        if let before, written.contains(where: { $0.id == before }) { return before }
        return written.max { $0.updatedAt < $1.updatedAt }?.id
    }
}

/// 入力途中の文章, kept through a launch: the text in a chat's field when
/// Fielua left the screen, for that chat, until the chat is open again. Only
/// the text; photos and files waiting to be sent are not kept. In the
/// app's UserDefaults, on the phone only, protected as the history file is
/// (until first unlock).
public enum LaunchDrafts {
    public static let storageKey = "launch-drafts-v1"
    /// A chat's draft goes once it is older than this many others.
    public static let limit = 20

    public static func load(_ defaults: UserDefaults = .standard) -> [UUID: String] {
        let stored = defaults.dictionary(forKey: storageKey) as? [String: String] ?? [:]
        var drafts: [UUID: String] = [:]
        for (key, text) in stored { if let id = UUID(uuidString: key), !text.isEmpty { drafts[id] = text } }
        return drafts
    }

    /// The text in `thread`'s field; empty, its kept draft goes.
    public static func set(_ text: String, for thread: UUID, _ defaults: UserDefaults = .standard) {
        var stored = defaults.dictionary(forKey: storageKey) as? [String: String] ?? [:]
        let order = defaults.stringArray(forKey: storageKey + "-order") ?? []
        var kept = order.filter { $0 != thread.uuidString && stored[$0] != nil }
        if text.isEmpty {
            stored[thread.uuidString] = nil
        } else {
            stored[thread.uuidString] = text
            kept.append(thread.uuidString)
        }
        while kept.count > limit { stored[kept.removeFirst()] = nil }
        store(stored, order: kept, defaults)
    }

    public static func remove(_ thread: UUID, _ defaults: UserDefaults = .standard) { set("", for: thread, defaults) }

    /// Drafts of chats that are gone.
    public static func prune(keeping threads: Set<UUID>, _ defaults: UserDefaults = .standard) {
        let stored = defaults.dictionary(forKey: storageKey) as? [String: String] ?? [:]
        let kept = stored.filter { key, _ in UUID(uuidString: key).map { threads.contains($0) } ?? false }
        guard kept.count != stored.count else { return }
        let order = (defaults.stringArray(forKey: storageKey + "-order") ?? []).filter { kept[$0] != nil }
        store(kept, order: order, defaults)
    }

    private static func store(_ stored: [String: String], order: [String], _ defaults: UserDefaults) {
        if stored.isEmpty {
            defaults.removeObject(forKey: storageKey); defaults.removeObject(forKey: storageKey + "-order")
        } else {
            defaults.set(stored, forKey: storageKey); defaults.set(order, forKey: storageKey + "-order")
        }
    }
}
