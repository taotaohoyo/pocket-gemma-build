import Foundation

/// Evidence from native messages, never a delegate/operator guessed from the
/// requested backend. Delegate node 1480 is not an underlying model operator.
public struct NativeLogEvidence: Codable, Equatable, Sendable {
    public let observedDelegates: [String]
    public let failedDelegate: String?
    public let operatorNames: [String]
    public let delegateNodes: [Int]
    public let sourceLocations: [String]
    public let failingComponent: String?
    public let xnnpackPhase: String?
    public let preparedImagePatches: [Int]?

    public init(error: String, logLines: [String]) {
        let lines = ([error] + logLines).flatMap { $0.components(separatedBy: .newlines) }
        let joined = lines.joined(separator: "\n")
        let patches = Self.matches(#"(?i)which will result in\s+(\d+)\s+patches"#, in: joined).compactMap(Int.init)
        preparedImagePatches = patches.isEmpty ? nil : patches
        if joined.localizedCaseInsensitiveContains("XNNPack delegate failed to reshape runtime") {
            xnnpackPhase = "reshape_runtime"
        } else if joined.localizedCaseInsensitiveContains("XNNPack delegate failed to reshape external value") {
            xnnpackPhase = "reshape_external_value"
        } else { xnnpackPhase = nil }
        observedDelegates = ["XNNPACK", "Metal"].filter { name in
            joined.range(of: name, options: .caseInsensitive) != nil
        }
        if lines.contains(where: { $0.range(of: "XNNPACK", options: .caseInsensitive) != nil &&
            ($0.localizedCaseInsensitiveContains("failed") || $0.localizedCaseInsensitiveContains("error")) }) {
            failedDelegate = "XNNPACK"
        } else if lines.contains(where: { $0.localizedCaseInsensitiveContains("metal") &&
            ($0.localizedCaseInsensitiveContains("failed") || $0.localizedCaseInsensitiveContains("error")) }) {
            failedDelegate = "Metal"
        } else { failedDelegate = nil }
        operatorNames = Self.matches(#"(?i:builtin opcode|unsupported (?:operator|op)|unresolved custom op)\s*[:=]?\s*['\"]?([A-Z][A-Z0-9_]{2,})"#, in: joined)
            .map { $0.uppercased() }.uniqued()
        delegateNodes = Self.matches(#"(?i)Node (?:number|index)\s+(\d+)\s*\(TfLiteXNNPackDelegate\)"#, in: joined)
            .compactMap(Int.init).uniqued()
        sourceLocations = Self.matches(#"([A-Za-z0-9_]+\.(?:cc|mm|h):\d+)"#, in: joined).uniqued()
        // Normal initialization logs mention the vision executor even when
        // the actual failure is in the language embedding input. Prefer the
        // returned native error, and never classify a success marker as a fault.
        func component(_ text: String) -> String? {
            // The runtime records this at the failed synchronous Run call;
            // ordinary initialization/OK markers are never failure evidence.
            if text.contains("PG_VISION_FAILURE component=vision_encoder") { return "vision_encoder" }
            if text.contains("PG_VISION_FAILURE component=vision_adapter") { return "vision_adapter" }
            if text.localizedCaseInsensitiveContains("failed to map section") { return "model_loader" }
            if text.contains("llm_litert_compiled_model_executor") { return "language_executor" }
            if text.contains("vision_litert_compiled_model_executor.cc:") { return "vision_executor" }
            return nil
        }
        let failureLogs = logLines.filter {
            let lower = $0.lowercased()
            return lower.contains("error:") || lower.contains("failed ") || lower.hasPrefix("e0000")
        }.joined(separator: "\n")
        failingComponent = component(error) ?? component(failureLogs)
    }

    private static func matches(_ pattern: String, in text: String) -> [String] {
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }
        return regex.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap {
            guard let range = Range($0.range(at: 1), in: text) else { return nil }
            return String(text[range])
        }
    }
}

/// Only operational native errors are retained. Text/JSON/prompts/responses,
/// file names and unrelated stderr output are not a diagnostic log source.
public struct NativeLogBuffer: Sendable {
    public private(set) var lines: [String] = []
    public private(set) var discardedLines = 0
    public private(set) var truncated = false
    /// Also keep the GPU's own messages, for the GPU start test only: its
    /// one input is a fixed question (GPUStartTest), never the user's text.
    public let keepsGPUMessages: Bool
    private var pending = Data()
    public init(keepsGPUMessages: Bool = false) { self.keepsGPUMessages = keepsGPUMessages }

    public mutating func append(_ data: Data) {
        pending.append(data)
        while let newline = pending.firstIndex(of: 10) {
            consume(String(decoding: pending[..<newline], as: UTF8.self))
            pending.removeSubrange(...newline)
        }
        if pending.count > 4096 { pending = Data(pending.suffix(4096)); truncated = true }
    }
    public mutating func finish() {
        if !pending.isEmpty { consume(String(decoding: pending, as: UTF8.self)); pending.removeAll() }
    }
    private mutating func consume(_ raw: String) {
        let lower = raw.lowercased()
        // A narrow allowlist avoids accidentally persisting the SDK's verbose
        // conversation/JSON dumps. Do not expand this to all ERROR/INFO lines.
        let operational = ["xnnpack delegate", "tflitexnnpackdelegate", "modify graph with delegate",
            "failed to allocate tensors", "failed to invoke the compiled model", "failed to prepare",
            "builtin opcode", "unresolved custom op", "unsupported operator", "unsupported op:",
            "texture binding has argument index", "metal accelerator", "created a metal device",
            "metal residency set", "metal shader", "delegate_metal.mm:",
            "vision_litert_compiled_model_executor.cc:", "llm_litert_compiled_model_executor",
            "litert_compiled_model.h:", "failed to decode image",
            // A missing vision encoder may mean an absent section or a failed
            // mmap. Keep the loader's cause without treating it as a diagnosis.
            "failed to map section", "section not found:", "not found. skipping",
            "pg_component vision_resources=engine_pool", "pg_component vision_cpu_kernel=",
            // absl prefixes these with severity/time/source. Accept only the
            // three fixed embedding state markers, not arbitrary SDK output.
            "pg_component embeddings_initialized ",
            "pg_component embeddings_ready_before_llm_compile",
            "pg_component llm_vision_prefill ",
            "pg_vision_run component=", "pg_vision_ok component=", "pg_vision_failure component=",
            "tflite reporter:"]
        let internalXNN = lower.contains("error in xnnpack:") || lower.contains("xnnpack error:") ||
            (lower.contains("failed to reshape") && lower.contains("operator"))
        let tensorDetail = lower.hasPrefix("pg_component ") || lower.contains("resize image from ") ||
            lower.contains("encoder_signature_index:") || lower.contains("adapter_signature_index:") ||
            (lower.contains("replacing ") && lower.contains("tflitexnnpackdelegate"))
        let gpuMessage = keepsGPUMessages && Self.gpuTerms.contains(where: lower.contains)
        guard operational.contains(where: lower.contains) || internalXNN || tensorDetail || gpuMessage,
              !raw.contains("\"role\""),
              !raw.contains("\"content\""), !lower.contains("prompt:"), !lower.contains("response:") else {
            discardedLines += 1; return
        }
        let line = GenerationSettings.prefix(Self.redact(raw), byteLimit: 800)
        if line.utf8.count < Self.redact(raw).utf8.count { truncated = true }
        lines.append(line)
        // The GPU test's messages still fit beside 23 other records in the
        // diagnostics history (768 KB).
        let limit = keepsGPUMessages ? (lines: 96, bytes: 12_288) : (lines: 64, bytes: 8192)
        while lines.count > limit.lines || lines.reduce(0, { $0 + $1.utf8.count }) > limit.bytes {
            lines.removeFirst(); truncated = true
        }
    }
    /// What the GPU's build and run report: the Metal delegate, its kernels
    /// and precision, and any failure.
    private static let gpuTerms = ["metal", "gpu", "ml_drift", "delegate", "accelerator", "compiled_model",
        "shader", "kernel", "precision", "fp16", "fp32", "float16", "float32",
        "error", "fail", "unsupported", "not supported", "unimplemented"]
    public static func redact(_ raw: String) -> String {
        var text = raw
        for pattern in [#"(?:/private)?/var/(?:mobile|folders)/[^\s\"\)]+"#,
                        #"/Users/[^\s\"\)]+"#, #"[A-Z]:\\[^\r\n\"\)]+"#,
                        #"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"#,
                        #"https?://[^\s\"\)]+"#] {
            if let regex = try? NSRegularExpression(pattern: pattern) {
                text = regex.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: "<redacted>")
            }
        }
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

private extension Array where Element: Hashable {
    func uniqued() -> [Element] {
        var seen = Set<Element>()
        return filter { seen.insert($0).inserted }
    }
}
