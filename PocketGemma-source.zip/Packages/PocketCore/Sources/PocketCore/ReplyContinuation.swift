import Foundation

/// A reply whose conversation fills its context window stops mid-sentence,
/// and the runtime reports that as a normal finish. The reply is carried on
/// in a fresh conversation that holds the question and the reply's tail,
/// and is told which headings and items the earlier part already wrote and
/// which number comes next. A continuation that apologises or starts over is
/// dropped unseen and asked for again.
public enum ReplyContinuation {
    public static let maximumRounds = 4
    /// Further tries after a continuation is dropped, before the reply ends.
    public static let maximumRetries = 2

    public struct Request: Equatable, Sendable {
        public let question: String
        /// One short line per heading, item or paragraph written before the tail.
        public let outline: String
        public let tail: String
        /// Names the numbered item the reply is on and the number after it.
        public var next = ""
        /// The user turn that asks for the rest of the reply.
        public var instruction: String { ReplyContinuation.instruction(outline: outline, next: next) }
    }

    // Asked plainly, like a person saying "go on". Telling the model its
    // answer was cut off at a limit made E2B apologise for a broken system
    // instead of continuing.
    static let covered = "ここまでのあなたの回答では、次の見出しと項目を書きました。\n"
    static let noRepeat = "\nこれらは繰り返さないでください。\n"
    static let ask = "続けてください。前置きは書かずに、あなたの回答の最後の文字のすぐ後から、同じ言語と同じ書式で、番号も続けて、残りを漏れなく書いてください。"

    static func instruction(outline: String, next: String) -> String {
        guard !outline.isEmpty else { return next + ask }
        return covered + outline + noRepeat + next + ask
    }

    /// Bytes the instruction adds around an outline.
    static var outlineOverhead: Int { (covered + noRepeat + ask).utf8.count }

    /// A small model told only to go on tends to start its list over; the
    /// number to write next keeps it on track. It is offered only if items
    /// remain, so a list cut at its last item isn't padded.
    static func next(after reply: String) -> String {
        guard let current = openItem(of: reply) else { return "" }
        return "番号付きの項目は「\(current.lead)」まで書きました。項目が残っていれば、次の番号は\(current.number + 1)です。\n"
    }

    /// Decoding stops silently once the KV cache holds the engine's token limit.
    public static func filledContext(tokenCount: Int, maxTokens: Int) -> Bool {
        tokenCount >= maxTokens - 1
    }

    /// Sized with the app's two-bytes-per-token input estimate, so the new
    /// conversation keeps at least the reply's reserved space free. The tail
    /// comes first; the outline takes what room is left.
    public static func request(prompt: String, reply: String, settings: GenerationSettings) -> Request {
        let question = GenerationSettings.prefix(prompt, byteLimit: settings.maxTokens / 4)
        let cue = next(after: reply)
        let room = settings.inputByteBudget - question.utf8.count - outlineOverhead - cue.utf8.count
        let start = tailStart(of: reply, byteLimit: max(256, min(settings.maxTokens / 2, room)))
        let ending = tail(of: reply, from: start)
        let earlier = outline(of: reply[..<start], byteLimit: min(settings.maxTokens / 4, room - ending.utf8.count))
        return Request(question: question, outline: earlier, tail: ending, next: cue)
    }

    static func tail(of reply: String, byteLimit: Int) -> String {
        tail(of: reply, from: tailStart(of: reply, byteLimit: byteLimit))
    }

    static func tailStart(of reply: String, byteLimit: Int) -> String.Index {
        guard reply.utf8.count > byteLimit else { return reply.startIndex }
        var start = reply.endIndex, used = 0
        while start > reply.startIndex {
            let previous = reply.index(before: start)
            used += reply[previous].utf8.count
            guard used <= byteLimit else { break }
            start = previous
        }
        // Begin on a whole line when one starts early in the window.
        let window = reply[start...]
        if let newline = window.prefix(window.count / 3).firstIndex(of: "\n") {
            start = reply.index(after: newline)
        }
        return start
    }

    /// A cut inside a code block keeps the block's opening fence.
    static func tail(of reply: String, from start: String.Index) -> String {
        let fences = reply[..<start].split(separator: "\n", omittingEmptySubsequences: false)
            .filter { $0.drop(while: { $0 == " " }).hasPrefix("```") }
        let body = String(reply[start...])
        if fences.count % 2 == 1, let open = fences.last { return String(open) + "\n" + body }
        return body
    }

    /// The lines before the tail, without emphasis marks, code, rules or table
    /// separators, each cut short. When even short leads don't fit, the latest
    /// ones are kept, since the reply goes on from them.
    static func outline(of text: Substring, byteLimit: Int) -> String {
        guard byteLimit > 0 else { return "" }
        var entries: [String] = [], inCode = false
        for line in text.split(separator: "\n") {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix("```") { inCode.toggle(); continue }
            guard !inCode, trimmed.contains(where: { !"|-:*_= ".contains($0) }) else { continue }
            entries.append(trimmed.replacingOccurrences(of: "**", with: "")
                .replacingOccurrences(of: "__", with: "").replacingOccurrences(of: "`", with: ""))
        }
        for width in [24, 16, 10] {
            let joined = entries.map { String($0.prefix(width)) }.joined(separator: "\n")
            if joined.utf8.count <= byteLimit { return joined }
        }
        var kept: [String] = [], used = 0
        for entry in entries.reversed().map({ String($0.prefix(10)) }) {
            guard used + entry.utf8.count + 1 <= byteLimit else { break }
            kept.insert(entry, at: 0)
            used += entry.utf8.count + 1
        }
        return kept.joined(separator: "\n")
    }

    /// Whether enough of a continuation is held back to trim and check it: a
    /// rewritten last line, an announcement line and the opening of what
    /// follows.
    public static func canCheck(_ opening: String, after reply: String) -> Bool {
        let announced = announcement(in: Substring(opening)).map { opening.distance(from: opening.startIndex, to: $0) } ?? 0
        return opening.count >= unfinishedLine(of: reply).count + announced + 80
    }

    /// The continuation without what the model announced or repeated: a short
    /// "続きです" or "承知しました" line, the reply's unfinished last line
    /// written again from its start, or text the reply already ends with. A
    /// new list item or heading after a finished last line starts on its own
    /// line.
    public static func trimmedStart(of continuation: String, after reply: String) -> String {
        var text = Substring(continuation)
        if let end = announcement(in: text) { text = text[end...] }
        let unfinished = unfinishedLine(of: reply)
        if !unfinished.trimmingCharacters(in: .whitespaces).isEmpty, text.hasPrefix(unfinished) {
            return String(text.dropFirst(unfinished.count))
        }
        for length in stride(from: min(text.count, reply.count, 400), through: 2, by: -1) {
            let head = text.prefix(length)
            guard reply.hasSuffix(head) else { continue }
            let wholeLines = head.last == "\n" && reply.dropLast(length).last.map { $0 == "\n" } ?? true
            if length >= 12 || wholeLines { return String(text.dropFirst(length)) }
        }
        if !reply.isEmpty, !reply.hasSuffix("\n"), item(of: text) != nil || text.hasPrefix("#")
            || text.hasPrefix("- ") || text.hasPrefix("* ") {
            return "\n" + String(text)
        }
        return String(text)
    }

    /// Where the text goes on after a short first line that only announces
    /// it ("続きです", "承知しました").
    static func announcement(in text: Substring) -> String.Index? {
        guard let newline = text.firstIndex(of: "\n") else { return nil }
        let line = text[..<newline].trimmingCharacters(in: .whitespaces).lowercased()
        guard line.count <= 40, announcements.contains(where: { line.contains($0) }) else { return nil }
        return text[text.index(after: newline)...].firstIndex(where: { $0 != "\n" }) ?? text.endIndex
    }

    static let announcements = ["続き", "続け", "承知", "かしこまりました", "わかりました", "了解", "continu"]
    /// Opening words of a model that answers the request as a new task.
    static let acknowledgements = ["承知", "かしこまりました", "わかりました", "了解", "お任せ"]
    static let apologies = ["申し訳", "すみません", "ごめんなさい", "お詫び", "失礼しました", "失礼いたしました",
                            "途中で切れ", "切れてしまい", "やり直", "書き直", "再構成", "訂正", "sorry", "apologi"]

    /// Whether a trimmed continuation answers the request instead of carrying
    /// the reply on: it apologises or says it starts over (in words the reply
    /// itself doesn't use), it opens with a long acknowledgement that restates
    /// the task, or its first numbered item goes back in the reply's list.
    public static func rejects(_ continuation: String, after reply: String) -> Bool {
        let opening = continuation.prefix(160).lowercased(), written = reply.lowercased()
        if apologies.contains(where: { opening.contains($0) && !written.contains($0) }) { return true }
        let lines = continuation.split(separator: "\n", omittingEmptySubsequences: false)
        if let first = lines.first(where: { !$0.trimmingCharacters(in: .whitespaces).isEmpty }), first.count > 40,
           acknowledgements.contains(where: { first.prefix(12).contains($0) }) { return true }
        let earlier = items(of: reply)
        // The first line finishes the reply's unfinished one.
        var separated = false
        for line in lines.dropFirst(reply.isEmpty || reply.hasSuffix("\n") ? 0 : 1) {
            guard let new = item(of: line) else {
                if startsSection(line) { separated = true }
                continue
            }
            if earlier.contains(where: { $0.number == new.number && $0.name == new.name && new.name.count >= 2 }) {
                return true
            }
            // A nested list goes on from the one under the reply's last item.
            let list = new.nested ? Array(earlier.reversed().prefix(while: { $0.nested }).reversed())
                : earlier.filter { !$0.nested }
            guard let last = list.last, new.number <= last.number else { return false }
            // A list numbered from 1 again is new content when a heading or
            // a paragraph stands between it and the reply's list.
            return new.number > 1 || !separated && openItem(of: reply) != nil
        }
        return false
    }

    struct Item: Equatable {
        let number: Int
        /// The item's first words: up to its first separator, without emphasis.
        let name: String
        let nested: Bool
    }

    /// A line written as "12. ", "12．" or "12) ", also inside emphasis or
    /// after heading marks ("**12. 名前**", "### 12. 名前").
    static func item(of line: Substring) -> Item? {
        let indent = line.prefix(while: { $0 == " " || $0 == "\t" }).count
        var text = line.dropFirst(indent)
        if text.hasPrefix("#") { text = text.drop(while: { $0 == "#" }).drop(while: { $0 == " " }) }
        if text.hasPrefix("**") || text.hasPrefix("__") { text = text.dropFirst(2) }
        let digits = text.prefix(while: { $0.isASCII && $0.isNumber })
        guard !digits.isEmpty, digits.count <= 4, let mark = text.dropFirst(digits.count).first,
              ".．)".contains(mark), let number = Int(digits) else { return nil }
        let rest = text.dropFirst(digits.count + 1).replacingOccurrences(of: "**", with: "")
            .replacingOccurrences(of: "__", with: "").trimmingCharacters(in: .whitespaces)
        let name = rest.prefix(while: { !"：:、，,。（(　 *|\n".contains($0) }).prefix(12)
        return Item(number: number, name: String(name), nested: indent >= 2)
    }

    /// The reply's numbered items outside code blocks, in order.
    static func items(of reply: String) -> [Item] {
        var found: [Item] = [], inCode = false
        for line in reply.split(separator: "\n") {
            if line.trimmingCharacters(in: .whitespaces).hasPrefix("```") { inCode.toggle(); continue }
            if !inCode, let numbered = item(of: line) { found.append(numbered) }
        }
        return found
    }

    /// The reply's last numbered item while its list is still going: only
    /// indented lines and bullets follow it, as an item's details do. Its
    /// lead is the line without emphasis, cut short.
    static func openItem(of reply: String) -> (number: Int, lead: String)? {
        var inCode = false, last: (number: Int, lead: String)?
        for line in reply.split(separator: "\n") {
            if line.trimmingCharacters(in: .whitespaces).hasPrefix("```") { inCode.toggle(); last = nil; continue }
            guard !inCode else { continue }
            if let numbered = item(of: line), !numbered.nested {
                let lead = line.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "**", with: "")
                    .replacingOccurrences(of: "__", with: "").drop(while: { $0 == "#" || $0 == " " })
                last = (numbered.number, String(lead.prefix(24)))
            } else if startsSection(line) {
                last = nil
            }
        }
        return inCode ? nil : last
    }

    /// A line that ends a list rather than adding to its last item: a
    /// heading, a rule, or text that starts at the margin.
    static func startsSection(_ line: Substring) -> Bool {
        guard let first = line.first, first != " ", first != "\t" else { return false }
        return !(["* ", "- ", "+ ", "・", "•"].contains { line.hasPrefix($0) } || line == "*" || line == "-")
    }

    static func unfinishedLine(of reply: String) -> Substring {
        reply.split(separator: "\n", omittingEmptySubsequences: false).last ?? ""
    }
}
