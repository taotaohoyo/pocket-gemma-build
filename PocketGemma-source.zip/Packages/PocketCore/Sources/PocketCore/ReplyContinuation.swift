import Foundation

/// A reply whose conversation fills its context window stops mid-sentence,
/// and the runtime reports that as a normal finish. The reply is carried on
/// in a fresh conversation that holds the question and the reply's tail,
/// and is told which headings and items the earlier part already wrote.
public enum ReplyContinuation {
    public static let maximumRounds = 4

    public struct Request: Equatable, Sendable {
        public let question: String
        /// One short line per heading, item or paragraph written before the tail.
        public let outline: String
        public let tail: String
        /// The user turn that asks for the rest of the reply.
        public var instruction: String { ReplyContinuation.instruction(outline: outline) }
    }

    static let opening = "あなたの直前の回答は長さの上限で途中で切れています。"
    static let covered = "回答の前半では、次の見出しと項目をすでに書いています。\n"
    static let ask = "前置き・あいさつ・言い直し・繰り返しを書かずに、切れた位置のすぐ後から、同じ言語と同じ書式で続きだけを書いてください。"
    static let noRepeat = "すでに書いた項目は二度と書かず、番号付きの一覧は番号を続けて、残りの項目を漏れなく書いてください。"

    static func instruction(outline: String) -> String {
        guard !outline.isEmpty else { return opening + ask }
        return opening + covered + outline + "\n" + ask + noRepeat
    }

    /// Bytes the instruction adds around an outline.
    static var outlineOverhead: Int { (opening + covered + "\n" + ask + noRepeat).utf8.count }

    /// Decoding stops silently once the KV cache holds the engine's token limit.
    public static func filledContext(tokenCount: Int, maxTokens: Int) -> Bool {
        tokenCount >= maxTokens - 1
    }

    /// Sized with the app's two-bytes-per-token input estimate, so the new
    /// conversation keeps at least the reply's reserved space free. The tail
    /// comes first; the outline takes what room is left.
    public static func request(prompt: String, reply: String, settings: GenerationSettings) -> Request {
        let question = GenerationSettings.prefix(prompt, byteLimit: settings.maxTokens / 4)
        let room = settings.inputByteBudget - question.utf8.count - outlineOverhead
        let start = tailStart(of: reply, byteLimit: max(256, min(settings.maxTokens / 2, room)))
        let ending = tail(of: reply, from: start)
        let earlier = outline(of: reply[..<start], byteLimit: min(settings.maxTokens / 4, room - ending.utf8.count))
        return Request(question: question, outline: earlier, tail: ending)
    }

    static func tail(of reply: String, byteLimit: Int) -> String {
        tail(of: reply, from: tailStart(of: reply, byteLimit: byteLimit))
    }

    static func tailStart(of reply: String, byteLimit: Int) -> String.Index {
        guard reply.utf8.count > byteLimit else { return reply.startIndex }
        var start = reply.endIndex, used = 0
        while start > reply.startIndex {
            let previous = reply.index(before: start)
            used += reply[previous].utf8.count
            guard used <= byteLimit else { break }
            start = previous
        }
        // Begin on a whole line when one starts early in the window.
        let window = reply[start...]
        if let newline = window.prefix(window.count / 3).firstIndex(of: "\n") {
            start = reply.index(after: newline)
        }
        return start
    }

    /// A cut inside a code block keeps the block's opening fence.
    static func tail(of reply: String, from start: String.Index) -> String {
        let fences = reply[..<start].split(separator: "\n", omittingEmptySubsequences: false)
            .filter { $0.drop(while: { $0 == " " }).hasPrefix("```") }
        let body = String(reply[start...])
        if fences.count % 2 == 1, let open = fences.last { return String(open) + "\n" + body }
        return body
    }

    /// The lines before the tail, without emphasis marks, code, rules or table
    /// separators, each cut short. When even short leads don't fit, the latest
    /// ones are kept, since the reply goes on from them.
    static func outline(of text: Substring, byteLimit: Int) -> String {
        guard byteLimit > 0 else { return "" }
        var entries: [String] = [], inCode = false
        for line in text.split(separator: "\n") {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix("```") { inCode.toggle(); continue }
            guard !inCode, trimmed.contains(where: { !"|-:*_= ".contains($0) }) else { continue }
            entries.append(trimmed.replacingOccurrences(of: "**", with: "")
                .replacingOccurrences(of: "__", with: "").replacingOccurrences(of: "`", with: ""))
        }
        for width in [24, 16, 10] {
            let joined = entries.map { String($0.prefix(width)) }.joined(separator: "\n")
            if joined.utf8.count <= byteLimit { return joined }
        }
        var kept: [String] = [], used = 0
        for entry in entries.reversed().map({ String($0.prefix(10)) }) {
            guard used + entry.utf8.count + 1 <= byteLimit else { break }
            kept.insert(entry, at: 0)
            used += entry.utf8.count + 1
        }
        return kept.joined(separator: "\n")
    }

    /// How much of a continuation to hold back before it is trimmed: enough
    /// to cover a rewritten last line and a short announcement line.
    public static func heldLength(after reply: String) -> Int {
        unfinishedLine(of: reply).count + 48
    }

    /// The continuation without what the model announced or repeated: a short
    /// "続きです" line, the reply's unfinished last line written again from
    /// its start, or text the reply already ends with.
    public static func trimmedStart(of continuation: String, after reply: String) -> String {
        var text = Substring(continuation)
        if let newline = text.firstIndex(of: "\n") {
            let line = text[..<newline].trimmingCharacters(in: .whitespaces)
            if line.count <= 40, line.contains("続き") || line.lowercased().contains("continu") {
                text = text[text.index(after: newline)...].drop(while: { $0 == "\n" })
            }
        }
        let unfinished = unfinishedLine(of: reply)
        if !unfinished.trimmingCharacters(in: .whitespaces).isEmpty, text.hasPrefix(unfinished) {
            return String(text.dropFirst(unfinished.count))
        }
        for length in stride(from: min(text.count, reply.count, 400), through: 2, by: -1) {
            let head = text.prefix(length)
            guard reply.hasSuffix(head) else { continue }
            let wholeLines = head.last == "\n" && reply.dropLast(length).last.map { $0 == "\n" } ?? true
            if length >= 12 || wholeLines { return String(text.dropFirst(length)) }
        }
        return String(text)
    }

    static func unfinishedLine(of reply: String) -> Substring {
        reply.split(separator: "\n", omittingEmptySubsequences: false).last ?? ""
    }
}
