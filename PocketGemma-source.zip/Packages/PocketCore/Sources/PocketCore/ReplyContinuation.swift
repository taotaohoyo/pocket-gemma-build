import Foundation

/// A reply whose conversation fills its context window stops mid-sentence,
/// and the runtime reports that as a normal finish. The reply is carried on
/// in a fresh conversation that holds the question and the reply's tail,
/// and is told which headings and items the earlier part already wrote. A
/// continuation that apologises or starts over is dropped unseen.
public enum ReplyContinuation {
    public static let maximumRounds = 4

    public struct Request: Equatable, Sendable {
        public let question: String
        /// One short line per heading, item or paragraph written before the tail.
        public let outline: String
        public let tail: String
        /// The user turn that asks for the rest of the reply.
        public var instruction: String { ReplyContinuation.instruction(outline: outline) }
    }

    // Asked plainly, like a person saying "go on". Telling the model its
    // answer was cut off at a limit made E2B apologise for a broken system
    // instead of continuing.
    static let covered = "ここまでのあなたの回答では、次の見出しと項目を書きました。\n"
    static let noRepeat = "\nこれらは繰り返さないでください。\n"
    static let ask = "続けてください。前置きは書かずに、あなたの回答の最後の文字のすぐ後から、同じ言語と同じ書式で、番号も続けて、残りを漏れなく書いてください。"
    /// The second try after a continuation that apologised or started over.
    public static let plainInstruction = "続けて"

    static func instruction(outline: String) -> String {
        guard !outline.isEmpty else { return ask }
        return covered + outline + noRepeat + ask
    }

    /// Bytes the instruction adds around an outline.
    static var outlineOverhead: Int { (covered + noRepeat + ask).utf8.count }

    /// Decoding stops silently once the KV cache holds the engine's token limit.
    public static func filledContext(tokenCount: Int, maxTokens: Int) -> Bool {
        tokenCount >= maxTokens - 1
    }

    /// Sized with the app's two-bytes-per-token input estimate, so the new
    /// conversation keeps at least the reply's reserved space free. The tail
    /// comes first; the outline takes what room is left.
    public static func request(prompt: String, reply: String, settings: GenerationSettings) -> Request {
        let question = GenerationSettings.prefix(prompt, byteLimit: settings.maxTokens / 4)
        let room = settings.inputByteBudget - question.utf8.count - outlineOverhead
        let start = tailStart(of: reply, byteLimit: max(256, min(settings.maxTokens / 2, room)))
        let ending = tail(of: reply, from: start)
        let earlier = outline(of: reply[..<start], byteLimit: min(settings.maxTokens / 4, room - ending.utf8.count))
        return Request(question: question, outline: earlier, tail: ending)
    }

    static func tail(of reply: String, byteLimit: Int) -> String {
        tail(of: reply, from: tailStart(of: reply, byteLimit: byteLimit))
    }

    static func tailStart(of reply: String, byteLimit: Int) -> String.Index {
        guard reply.utf8.count > byteLimit else { return reply.startIndex }
        var start = reply.endIndex, used = 0
        while start > reply.startIndex {
            let previous = reply.index(before: start)
            used += reply[previous].utf8.count
            guard used <= byteLimit else { break }
            start = previous
        }
        // Begin on a whole line when one starts early in the window.
        let window = reply[start...]
        if let newline = window.prefix(window.count / 3).firstIndex(of: "\n") {
            start = reply.index(after: newline)
        }
        return start
    }

    /// A cut inside a code block keeps the block's opening fence.
    static func tail(of reply: String, from start: String.Index) -> String {
        let fences = reply[..<start].split(separator: "\n", omittingEmptySubsequences: false)
            .filter { $0.drop(while: { $0 == " " }).hasPrefix("```") }
        let body = String(reply[start...])
        if fences.count % 2 == 1, let open = fences.last { return String(open) + "\n" + body }
        return body
    }

    /// The lines before the tail, without emphasis marks, code, rules or table
    /// separators, each cut short. When even short leads don't fit, the latest
    /// ones are kept, since the reply goes on from them.
    static func outline(of text: Substring, byteLimit: Int) -> String {
        guard byteLimit > 0 else { return "" }
        var entries: [String] = [], inCode = false
        for line in text.split(separator: "\n") {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix("```") { inCode.toggle(); continue }
            guard !inCode, trimmed.contains(where: { !"|-:*_= ".contains($0) }) else { continue }
            entries.append(trimmed.replacingOccurrences(of: "**", with: "")
                .replacingOccurrences(of: "__", with: "").replacingOccurrences(of: "`", with: ""))
        }
        for width in [24, 16, 10] {
            let joined = entries.map { String($0.prefix(width)) }.joined(separator: "\n")
            if joined.utf8.count <= byteLimit { return joined }
        }
        var kept: [String] = [], used = 0
        for entry in entries.reversed().map({ String($0.prefix(10)) }) {
            guard used + entry.utf8.count + 1 <= byteLimit else { break }
            kept.insert(entry, at: 0)
            used += entry.utf8.count + 1
        }
        return kept.joined(separator: "\n")
    }

    /// How much of a continuation to hold back before it is trimmed and
    /// checked: a rewritten last line, an announcement line and the opening
    /// of what follows.
    public static func heldLength(after reply: String) -> Int {
        unfinishedLine(of: reply).count + 80
    }

    /// The continuation without what the model announced or repeated: a short
    /// "続きです" or "承知しました" line, the reply's unfinished last line
    /// written again from its start, or text the reply already ends with. A
    /// new list item or heading after a finished last line starts on its own
    /// line.
    public static func trimmedStart(of continuation: String, after reply: String) -> String {
        var text = Substring(continuation)
        if let newline = text.firstIndex(of: "\n") {
            let line = text[..<newline].trimmingCharacters(in: .whitespaces).lowercased()
            if line.count <= 40, announcements.contains(where: { line.contains($0) }) {
                text = text[text.index(after: newline)...].drop(while: { $0 == "\n" })
            }
        }
        let unfinished = unfinishedLine(of: reply)
        if !unfinished.trimmingCharacters(in: .whitespaces).isEmpty, text.hasPrefix(unfinished) {
            return String(text.dropFirst(unfinished.count))
        }
        for length in stride(from: min(text.count, reply.count, 400), through: 2, by: -1) {
            let head = text.prefix(length)
            guard reply.hasSuffix(head) else { continue }
            let wholeLines = head.last == "\n" && reply.dropLast(length).last.map { $0 == "\n" } ?? true
            if length >= 12 || wholeLines { return String(text.dropFirst(length)) }
        }
        if !reply.isEmpty, !reply.hasSuffix("\n"), itemNumber(of: text) != nil || text.hasPrefix("#")
            || text.hasPrefix("- ") || text.hasPrefix("* ") {
            return "\n" + String(text)
        }
        return String(text)
    }

    static let announcements = ["続き", "続け", "承知", "かしこまりました", "わかりました", "了解", "continu"]
    static let apologies = ["申し訳", "すみません", "ごめんなさい", "お詫び", "失礼しました", "失礼いたしました",
                            "途中で切れ", "切れてしまい", "sorry", "apologi"]

    /// Whether a trimmed continuation answers the request instead of carrying
    /// the reply on: it apologises (in words the reply itself doesn't use), or
    /// it starts the reply's numbered list over from an item already written.
    public static func rejects(_ continuation: String, after reply: String) -> Bool {
        let opening = continuation.prefix(160).lowercased(), written = reply.lowercased()
        if apologies.contains(where: { opening.contains($0) && !written.contains($0) }) { return true }
        let first = continuation.drop(while: { $0 == "\n" || $0 == " " }).prefix(while: { $0 != "\n" })
        guard let number = itemNumber(of: first) else { return false }
        let lines = reply.split(separator: "\n")
        guard let last = lines.compactMap({ itemNumber(of: $0) }).last, number <= last else { return false }
        let lead = itemLead(first)
        return lead.count >= 4 && lines.contains { itemLead($0) == lead }
    }

    /// The number of a line written as "12. ", "12．" or "12) ".
    static func itemNumber(of line: Substring) -> Int? {
        let trimmed = line.drop(while: { $0 == " " })
        let digits = trimmed.prefix(while: { $0.isASCII && $0.isNumber })
        guard !digits.isEmpty, digits.count <= 4, let mark = trimmed.dropFirst(digits.count).first,
              ".．)".contains(mark) else { return nil }
        return Int(digits)
    }

    static func itemLead(_ line: Substring) -> String {
        String(line.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "**", with: "")
            .replacingOccurrences(of: "__", with: "").prefix(12))
    }

    static func unfinishedLine(of reply: String) -> Substring {
        reply.split(separator: "\n", omittingEmptySubsequences: false).last ?? ""
    }
}
