import Foundation

/// A reply whose conversation fills its context window stops mid-sentence,
/// and the runtime reports that as a normal finish. The reply is carried on
/// in a fresh conversation that holds the question and the reply's tail.
public enum ReplyContinuation {
    public static let maximumRounds = 4
    public static let instruction = "あなたの直前の回答は長さの上限で途中で切れています。前置き・あいさつ・言い直し・繰り返しを書かずに、切れた位置のすぐ後から、同じ言語と同じ書式で続きだけを書いてください。"

    public struct Request: Equatable, Sendable {
        public let question: String
        public let tail: String
    }

    /// Decoding stops silently once the KV cache holds the engine's token limit.
    public static func filledContext(tokenCount: Int, maxTokens: Int) -> Bool {
        tokenCount >= maxTokens - 1
    }

    /// Sized with the app's two-bytes-per-token input estimate, so the new
    /// conversation keeps at least the reply's reserved space free.
    public static func request(prompt: String, reply: String, settings: GenerationSettings) -> Request {
        let question = GenerationSettings.prefix(prompt, byteLimit: settings.maxTokens / 4)
        let room = settings.inputByteBudget - question.utf8.count - instruction.utf8.count
        return Request(question: question, tail: tail(of: reply, byteLimit: max(256, min(settings.maxTokens / 2, room))))
    }

    static func tail(of reply: String, byteLimit: Int) -> String {
        guard reply.utf8.count > byteLimit else { return reply }
        var start = reply.endIndex, used = 0
        while start > reply.startIndex {
            let previous = reply.index(before: start)
            used += reply[previous].utf8.count
            guard used <= byteLimit else { break }
            start = previous
        }
        // Begin on a whole line when one starts early in the window.
        let window = reply[start...]
        if let newline = window.prefix(window.count / 3).firstIndex(of: "\n") {
            start = reply.index(after: newline)
        }
        // A cut inside a code block keeps the block's opening fence.
        let fences = reply[..<start].split(separator: "\n", omittingEmptySubsequences: false)
            .filter { $0.drop(while: { $0 == " " }).hasPrefix("```") }
        let body = String(reply[start...])
        if fences.count % 2 == 1, let open = fences.last { return String(open) + "\n" + body }
        return body
    }

    /// How much of a continuation to hold back before it is trimmed: enough
    /// to cover a rewritten last line and a short announcement line.
    public static func heldLength(after reply: String) -> Int {
        unfinishedLine(of: reply).count + 48
    }

    /// The continuation without what the model announced or repeated: a short
    /// "続きです" line, the reply's unfinished last line written again from
    /// its start, or text the reply already ends with.
    public static func trimmedStart(of continuation: String, after reply: String) -> String {
        var text = Substring(continuation)
        if let newline = text.firstIndex(of: "\n") {
            let line = text[..<newline].trimmingCharacters(in: .whitespaces)
            if line.count <= 40, line.contains("続き") || line.lowercased().contains("continu") {
                text = text[text.index(after: newline)...].drop(while: { $0 == "\n" })
            }
        }
        let unfinished = unfinishedLine(of: reply)
        if !unfinished.trimmingCharacters(in: .whitespaces).isEmpty, text.hasPrefix(unfinished) {
            return String(text.dropFirst(unfinished.count))
        }
        for length in stride(from: min(text.count, reply.count, 400), through: 2, by: -1) {
            let head = text.prefix(length)
            guard reply.hasSuffix(head) else { continue }
            let wholeLines = head.last == "\n" && reply.dropLast(length).last.map { $0 == "\n" } ?? true
            if length >= 12 || wholeLines { return String(text.dropFirst(length)) }
        }
        return String(text)
    }

    static func unfinishedLine(of reply: String) -> Substring {
        reply.split(separator: "\n", omittingEmptySubsequences: false).last ?? ""
    }
}
