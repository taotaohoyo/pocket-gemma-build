import Foundation

/// A question to the assistant about itself, as it is now (1.1.0 (296),
/// the user's directive of 2026-11-17): who it is, which model it is, who
/// made it, what it can do (「君は何が出来るの？」, 「どのモデル？」, "Who made
/// you?", 你是谁？, 넌 누구야?).
///
/// Smart Memory recalls nothing for one. Only the model that answers knows
/// the answer, and what the search finds for it is the same question put to
/// whichever model answered before: on 295, LFM3 asked 「君は何が出来るのー？」
/// got Gemma 4's answer to 「君は何が出来るの？」 as its record and said it was
/// Gemma 4. The answer comes from the model and its system turn
/// (ModelIdentity), as with Smart Memory off.
///
/// Kept narrow, so what the person asks about earlier chats is searched as
/// before:
/// - a question about before (「以前使っていたAIは何？」, 「前に何て名乗って
///   た？」, "Which model did I use last time?") is not one;
/// - nor is one with anything else to search for (「Pythonで何が出来る？」,
///   「夏目漱石って誰？」, "What can you do for my resume?");
/// - nor one about a name alone (「君の名前は？」): the person may have given
///   the assistant a name in another chat.
/// A question this misses is searched, and the note says whose its replies
/// are (SmartMemoryNote.authorship).
public enum SelfQuestion {
    public static func asksNow(_ question: String) -> Bool {
        let text = normalized(question)
        return !isAboutBefore(text) && asksOnlyAboutTheAssistant(text, names: false)
    }

    /// A saved exchange's question that asked the assistant of that chat
    /// about itself, its name included (「あなたは誰？モデルの名前を教えて」,
    /// 「君の名前は？」): the reply is that assistant's introduction of
    /// itself, whichever model it was. Smart Memory recalls such an exchange
    /// only for a question about before (`asksAboutBefore`): for any other
    /// it says nothing about the person, and a small model takes it for its
    /// own (LFM3 1.7B did with the rule against it in its system turn and
    /// in the record, run 44155457626). What the person told the assistant
    /// (「あなたの名前はポチね」) is not one, and is recalled as before.
    public static func introduces(_ question: String) -> Bool {
        // A question about the assistant alone is short; a long one has
        // something else in it.
        guard question.utf16.count <= 160 else { return false }
        let text = normalized(question)
        // Every saved exchange is read once for the index: one pass tells
        // the many questions that ask nothing of the kind.
        if let anyAsk, anyAsk.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) == nil { return false }
        return !isAboutBefore(text) && asksOnlyAboutTheAssistant(text, names: true)
    }

    private static let anyAsk = try? NSRegularExpression(pattern: (nameAsks + asks).map { "(?:" + $0 + ")" }.joined(separator: "|"))

    /// A question about before, about what was said, or about another
    /// model (「以前使っていたAIは何？」): an earlier assistant's
    /// introduction may answer it.
    public static func asksAboutBefore(_ question: String) -> Bool { isAboutBefore(normalized(question)) }

    private static func normalized(_ question: String) -> String {
        String(question.prefix(400)).precomposedStringWithCompatibilityMapping.lowercased()
    }

    private static func isAboutBefore(_ text: String) -> Bool {
        befores.contains(where: { text.contains($0) })
            || englishBefores.contains { text.range(of: $0, options: .regularExpression) != nil }
    }

    private static func asksOnlyAboutTheAssistant(_ text: String, names: Bool) -> Bool {
        var rest = text, asked = false
        for pattern in (names ? nameAsks : []) + asks {
            while let range = rest.range(of: pattern, options: .regularExpression) {
                rest.replaceSubrange(range, with: " ")
                asked = true
            }
        }
        guard asked else { return false }
        for pattern in addressed {
            while let range = rest.range(of: pattern, options: .regularExpression) { rest.replaceSubrange(range, with: " ") }
        }
        // Nothing else to search for: the words left are those every
        // question has (SmartMemoryTerms' own reading).
        return SmartMemoryTerms.question(rest).terms.isEmpty
    }

    /// A name asked for, for `introduces` only: the question now is still
    /// searched (the person may have given the assistant a name).
    private static let nameAsks: [String] = [
        #"(の)?(お)?(名前|なまえ)(は|を|って)?(何|なに|なん)?"#,
        #"何(と|て)(呼|よ)(べば|んだら)[ぁ-ん]{0,6}"#,
        #"\bwhat(\s+is|'s|s)\s+your\s+name\b"#,
        #"\b(your|ur)\s+name\b"#,
        #"你叫(什么|什麼)(名字)?|(你的)?名字(是|叫)?(什么|什麼)?"#,
        #"이름(이|은)?\s?(뭐야|뭐예요|뭐니|뭔가요|무엇입니까|무엇인가요)?"#
    ]

    /// What is asked: an ability, an identity, a maker.
    private static let asks: [String] = [
        // Japanese
        // 何で + きみ and なんで + きのう are no 「できる」: it needs its ending.
        #"(何|なに|どんな(こと|事)|どういう(こと|事))(が|を|って)?(出来|でき)(る|ます|ん|そう)(こと|事)?"#,
        #"なん(が|を|って)(出来|でき)(る|ます|ん|そう)(こと|事)?"#,
        #"(出来|でき)(る|ます)(こと|事)"#,
        #"何が得意|得意な(こと|事)|得意分野|苦手な(こと|事)"#,
        #"(どの|何の|なんの|どんな|どういう|何という|なんという|どこの)(ai|モデル|言語モデル|llm)"#,
        #"(ai|モデル|言語モデル|llm)(の(名前|種類))?(は|って)(何|なに|なん|どれ)"#,
        #"モデル名"#,
        #"(誰|だれ|どこ)(が|に)(作|つく|開発|かいはつ)[ぁ-ん]{0,6}"#,
        #"(作|つく)った(の|人|会社)?(は)?(誰|だれ|どこ)"#,
        #"開発(元|者|会社)|どこの会社"#,
        #"自己紹介"#,
        // English
        #"\bwho\s+(are|r)\s+(you|u)\b"#,
        #"\bwhat\s+are\s+you\b"#,
        #"\b(which|what)\s+(ai\s+|language\s+)?model\b"#,
        #"\bwhat(\s+is|'s|s)\s+your\s+model\b"#,
        #"\bwho\s+(made|created|built|developed|trained)\s+you\b"#,
        #"\bwhat\s+can\s+you\s+(do|help)\b"#,
        #"\bwhat\s+are\s+you\s+(able|capable)\b"#,
        #"\b(what\s+are\s+)?your\s+(capabilities|abilities|skills)\b"#,
        #"\bintroduce\s+yourself\b"#,
        #"\btell\s+me\s+about\s+yourself\b"#,
        // Chinese
        #"(什么|什麼|哪个|哪個|哪一个|哪一個)(ai)?(模型|大模型)"#,
        #"你是(谁|誰|什么|什麼|哪个|哪個)"#,
        #"(谁|誰|哪家公司)(开发|開發|创造|創造|训练|訓練|做|制作|製作)(了|的)?(你)?"#,
        #"你(能|会|會|可以)(做|干|幹)?(些)?(什么|什麼)"#,
        #"你有(什么|什麼)功能"#,
        #"自我介(绍|紹)(一下)?|介(绍|紹)一下你自己"#,
        // Korean
        #"누구(야|니|세요|예요|입니까|인가요|죠|지)?"#,
        #"(어떤|무슨|어느)\s?(ai\s?)?모델(이야|이에요|인가요|입니까|이니|인지|이죠|이지)?"#,
        #"(뭘|뭐를|뭐|무엇을|무얼)\s?할\s?수\s?있(어요|어|니|나요|습니까|는지)?"#,
        #"할\s?수\s?있는\s?(일|것)"#,
        #"누가\s?(널|너를|당신을)?\s?만들(었어요|었어|었니|었나요|었습니까)?"#,
        #"자기\s?소개\s?(해\s?주세요|해줘|해봐|해)?"#,
        // Who, bare, after the patterns that begin with it (誰が作った, 誰開發).
        #"誰|だれ|何者|なにもの|どなた"#
    ]

    /// Who is asked, and the words that only carry the question.
    private static let addressed: [String] = [
        #"君|きみ|あなた|貴方|お前|おまえ|あんた|そちら"#,
        #"\b(fielua|ai|assistant|chatbot|bot|llm)\b"#,
        #"フィエルア|アシスタント|ai|モデル"#,
        #"你|您|是|吗|嗎|呢|呀|啊|吧|的|请问|請問|请|請|模型"#,
        #"너는|넌|너|당신은|당신"#
    ]

    /// A question about before, about what was said, or about another
    /// model: its answer may be in an earlier chat.
    private static let befores: [String] = [
        "前に", "前の", "前回", "以前", "昔", "さっき", "先ほど", "さきほど", "過去", "今まで", "これまで", "最初", "履歴", "記憶",
        "覚え", "おぼえ", "言ってた", "言ってい", "言った", "言いました", "名乗", "使ってた", "使ってい", "使った",
        "話してた", "話してい", "話した", "聞いた", "くれた",
        "だった", "でした", "っけ", "他の", "ほかの", "別の", "違う",
        "之前", "上次", "刚才", "剛才", "记得", "記得", "说过", "說過", "曾经", "曾經", "过去", "過去", "其他", "别的", "別的",
        "전에", "이전", "아까", "지난", "예전", "기억", "말했", "다른"
    ]
    private static let englishBefores: [String] = [
        #"\b(before|earlier|previous|previously|ago|history|remember|said|told|was|were|did|other|another|else)\b"#,
        #"\blast\s+time\b"#, #"\bused\s+to\b"#
    ]
}
