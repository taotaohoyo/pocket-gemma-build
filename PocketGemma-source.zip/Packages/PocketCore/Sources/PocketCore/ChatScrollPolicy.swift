/// Content growth alone must not be mistaken for the reader scrolling away.
public struct ChatScrollPolicy: Sendable {
    public private(set) var followsLatest = true
    public private(set) var userIsScrolling = false
    private var distance = 0.0
    public init() {}
    public var shouldFollowStream: Bool { followsLatest && !userIsScrolling }
    public var showsJumpButton: Bool { !followsLatest && distance > 32 }

    public mutating func observe(distanceFromBottom: Double) {
        distance = distanceFromBottom.isFinite ? max(0, distanceFromBottom) : 0
        // Keyboard/inset changes can bring the reader back to the bottom even
        // without a drag phase. Clear a stale jump button in that case.
        if distance <= 32 { followsLatest = true }
        else if userIsScrolling { followsLatest = false }
    }
    public mutating func setUserScrolling(_ scrolling: Bool) {
        if userIsScrolling && !scrolling { followsLatest = distance <= 32 }
        userIsScrolling = scrolling
    }
    public mutating func requestLatest() {
        followsLatest = true
        userIsScrolling = false
    }
}

public enum ChatScrollGeometry {
    /// Both edges must share a coordinate system. For overlaid input bars,
    /// use the measured content end and reading edge rather than the scroll
    /// view's full bounds, which can extend behind the keyboard.
    public static func distanceFromBottom(contentHeight: Double, visibleBottom: Double) -> Double {
        guard contentHeight.isFinite, visibleBottom.isFinite else { return 0 }
        return max(0, contentHeight - visibleBottom)
    }
}
