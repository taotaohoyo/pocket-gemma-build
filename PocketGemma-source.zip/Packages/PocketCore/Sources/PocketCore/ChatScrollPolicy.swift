/// Content growth alone must not be mistaken for the reader scrolling away.
public struct ChatScrollPolicy: Sendable {
    public private(set) var followsLatest = true
    public private(set) var userIsScrolling = false
    private var distance = 0.0
    public init() {}
    public var shouldFollowStream: Bool { followsLatest && !userIsScrolling }
    public var showsJumpButton: Bool { !followsLatest && distance > 32 }

    public mutating func observe(distanceFromBottom: Double) {
        distance = distanceFromBottom.isFinite ? max(0, distanceFromBottom) : 0
        // Keyboard/inset changes can bring the reader back to the bottom even
        // without a drag phase. Clear a stale jump button in that case.
        if distance <= 32 { followsLatest = true }
        else if userIsScrolling { followsLatest = false }
    }
    public mutating func setUserScrolling(_ scrolling: Bool) {
        if userIsScrolling && !scrolling { followsLatest = distance <= 32 }
        userIsScrolling = scrolling
    }
    public mutating func requestLatest() {
        followsLatest = true
        userIsScrolling = false
    }
}

/// Whether the reader rests at the end of the conversation, for the folded
/// composer's latest button, which flows into the chat button there. It
/// arrives within `arrive` of the end and leaves only past `leave`, so small
/// offset changes (lazy row estimates, a bounce) cannot draw the button in
/// and out again.
public struct ChatEndPresence: Sendable, Equatable {
    public static let arrive = 32.0
    public static let leave = 80.0
    public private(set) var atEnd = true
    public init() {}
    public mutating func observe(distanceFromBottom: Double) {
        let distance = distanceFromBottom.isFinite ? max(0, distanceFromBottom) : 0
        if distance <= Self.arrive { atEnd = true }
        else if distance > Self.leave { atEnd = false }
    }
}

public enum ChatScrollGeometry {
    /// Both edges must share a coordinate system. For overlaid input bars,
    /// use the measured content end and reading edge rather than the scroll
    /// view's full bounds, which can extend behind the keyboard.
    public static func distanceFromBottom(contentHeight: Double, visibleBottom: Double) -> Double {
        guard contentHeight.isFinite, visibleBottom.isFinite else { return 0 }
        return max(0, contentHeight - visibleBottom)
    }
}
