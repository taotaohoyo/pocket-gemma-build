import Foundation

/// What each model can take in, in one place. Whether an input is offered
/// right now (a path still being checked on device) is ModelAttachmentPolicy's
/// call on top of this. A model with native photos also takes videos, as a
/// few of their scenes (VideoScenes); audio is not offered for any model.
public struct ModelCapabilities: Sendable, Equatable {
    /// How a photo reaches the model.
    public enum Photos: Sendable, Equatable {
        /// The model's own vision encoder reads the image.
        case native
        /// A text-only model: the photo's text is read on the device (OCR)
        /// and only that text reaches the model. It never sees the image.
        /// No model uses it now: Qwen takes text only.
        case textRecognition
        /// No photo input at all.
        case unsupported
    }
    public let photos: Photos
    /// TXT, Markdown, PDF, CSV, JSON and Word, read into plain text on the
    /// device. The model never receives the file's bytes.
    public let documents: Bool
    /// Replies in the shared ```chart format (RichBlock); the renderer is the
    /// same for every model, a small model may follow the format less often.
    public let charts: Bool
    public let thinking: Bool
    /// The context the pinned file was exported with (its KV cache).
    public let contextTokens: Int
    /// Whether replies may be generated on the GPU. LiteRT-LM gives the GPU
    /// the whole graph with no CPU fallback.
    public let gpu: Bool
    /// Whether replies may be generated on the CPU. Gemma 4 12B wrote about
    /// 0.2 tokens a second there on the phone (2026-10-26), against 16 on
    /// the GPU, so it runs on the GPU only, and its reply waits for the app
    /// instead of going on on the CPU in the background.
    public let cpu: Bool
    /// The GPU's precision for replies (EngineConfig.activationDataType). On
    /// the phone, Qwen3 0.6B's GPU build failed at the runtime's 16-bit
    /// default: the Metal shader generated for it did not compile ('half4'
    /// initialized from 'float4', 1.0.106's GPU start test). At 32-bit it
    /// started and answered, so Qwen3 runs on the GPU at 32-bit. Gemma and
    /// Qwen2.5 1.5B ran on the phone's GPU at the default.
    public let gpuPrecision: GPUPrecision
    /// Whether the GPU engine starts in the runtime's benchmark mode
    /// (ExperimentalFlags.enableBenchmark), which also has the GPU wait
    /// actively for each run and for its weights. Gemma 4 12B only.
    public let gpuBenchmarkMode: Bool
    /// A reasoning model, which thinks before every answer whatever the
    /// thinking switch says: Phi-4-mini-reasoning. Its thoughts stream in
    /// the runtime's thought channel and are never shown; each reply keeps
    /// room for them (`GenerationSettings.reasoningTokens`).
    public let reasons: Bool
    /// Whether a model that can use both starts on the GPU before the person
    /// chooses. Phi-4-mini-reasoning starts on the CPU: its GPU start hasn't
    /// been seen on the phone yet (1.1.0 (205)), and the CPU answered in the
    /// checks before it was added.
    public let startsOnGPU: Bool

    init(photos: Photos, documents: Bool, charts: Bool, thinking: Bool, contextTokens: Int, gpu: Bool, cpu: Bool,
         gpuPrecision: GPUPrecision, gpuBenchmarkMode: Bool, reasons: Bool = false, startsOnGPU: Bool = true) {
        self.photos = photos; self.documents = documents; self.charts = charts; self.thinking = thinking
        self.contextTokens = contextTokens; self.gpu = gpu; self.cpu = cpu; self.gpuPrecision = gpuPrecision
        self.gpuBenchmarkMode = gpuBenchmarkMode; self.reasons = reasons; self.startsOnGPU = startsOnGPU
    }

    public static func of(_ model: ModelSpec) -> ModelCapabilities {
        switch model.id {
        case ModelSpec.e4b.id, ModelSpec.e2b.id:
            return ModelCapabilities(photos: .native, documents: true, charts: true, thinking: true, contextTokens: 8192,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        // Gemma 4 12B: text and files; its photos and audio are not checked
        // on the phone. Thinking stays off until a reply with it has been
        // seen there. 1.1.0 (200)'s chats wrote unrelated words and Bengali
        // letters on the phone's GPU (4,096 tokens, no benchmark mode). 201
        // started it as the developer 12B check had (1,024 tokens, benchmark
        // mode) with a new cache, and it answered; its comparison answered
        // with each of 1,024 and 4,096, with and without benchmark mode, all
        // from fresh caches (user 13:55 UTC 2026-10-26). So 202 is back at
        // 4,096 tokens, which reads files, with benchmark mode, which waits
        // for the weights before the first reply (GemmaService).
        case ModelSpec.gemma12B.id:
            return ModelCapabilities(photos: .unsupported, documents: true, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: false, gpuPrecision: .modelDefault, gpuBenchmarkMode: true)
        // Qwen takes text only: the plus menu offers it no photos, camera,
        // files or video.
        case ModelSpec.qwen3.id:
            // Qwen3-0.6B_dynamic_wi4b32_afp32 was exported with 4,096 tokens.
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .float32, gpuBenchmarkMode: false)
        // Phi-4-mini-reasoning (1.1.0 (205)): text only, 4,096 tokens. It
        // always thinks first; its card asks for at least 2,048 tokens for
        // the thinking and the answer. Both processors can be chosen.
        case ModelSpec.phi4MiniReasoning.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false,
                                     reasons: true, startsOnGPU: false)
        // Qwen3.5 4B Mixed INT4 (1.1.0 (205)): the text decoder only, with a
        // 4,096-token KV budget. CPU only: its export card measured an iPhone
        // 17 Pro's GPU at 5.74 GB of memory and 65 s to load, against the
        // CPU's 1.68 GB at 8.9 tokens a second (GPU 11.4). Thinking is off
        // unless switched on, as its template now defaults. Its card asks
        // for a new engine for each conversation, but on LiteRT-LM 0.18.0's
        // CPU a conversation after six others answered exactly as one on a
        // fresh engine (run 40412428363), and a start takes ~45 s there, so
        // conversations share the engine as the other models' do.
        case ModelSpec.qwen35.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: false, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        case ModelSpec.qwen25.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        default:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: false, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        }
    }
}
