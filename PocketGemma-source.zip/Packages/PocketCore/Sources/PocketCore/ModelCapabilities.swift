import Foundation

/// What each model can take in, in one place. Whether an input is offered
/// right now (a path still being checked on device) is ModelAttachmentPolicy's
/// call on top of this. A model with native photos also takes videos, as a
/// few of their scenes (VideoScenes); audio is not offered for any model.
public struct ModelCapabilities: Sendable, Equatable {
    /// How a photo reaches the model.
    public enum Photos: Sendable, Equatable {
        /// The model's own vision encoder reads the image.
        case native
        /// A text-only model: the photo's text is read on the device (OCR)
        /// and only that text reaches the model. It never sees the image.
        /// No model uses it now: Qwen takes text only.
        case textRecognition
        /// No photo input at all.
        case unsupported
    }
    public let photos: Photos
    /// TXT, Markdown, PDF, CSV, JSON and Word, read into plain text on the
    /// device. The model never receives the file's bytes.
    public let documents: Bool
    /// Replies in the shared ```chart format (RichBlock); the renderer is the
    /// same for every model, a small model may follow the format less often.
    public let charts: Bool
    public let thinking: Bool
    /// The context the pinned file was exported with (its KV cache).
    public let contextTokens: Int
    /// Whether replies may be generated on the GPU. LiteRT-LM gives the GPU
    /// the whole graph with no CPU fallback.
    public let gpu: Bool
    /// Whether replies may be generated on the CPU. Gemma 4 12B wrote about
    /// 0.2 tokens a second there on the phone (2026-10-26), against 16 on
    /// the GPU, so it runs on the GPU only, and its reply waits for the app
    /// instead of going on on the CPU in the background.
    public let cpu: Bool
    /// The GPU's precision for replies (EngineConfig.activationDataType). On
    /// the phone, Qwen3 0.6B's GPU build failed at the runtime's 16-bit
    /// default: the Metal shader generated for it did not compile ('half4'
    /// initialized from 'float4', 1.0.106's GPU start test). At 32-bit it
    /// started and answered, so Qwen3 runs on the GPU at 32-bit. Gemma and
    /// Qwen2.5 1.5B ran on the phone's GPU at the default.
    public let gpuPrecision: GPUPrecision
    /// Whether the GPU engine starts in the runtime's benchmark mode
    /// (ExperimentalFlags.enableBenchmark), which also has the GPU wait
    /// actively for each run and for its weights. Gemma 4 12B only.
    public let gpuBenchmarkMode: Bool
    /// A reasoning model, which thinks before every answer whatever the
    /// thinking switch says: Phi-4-mini-reasoning. Its thoughts stream in
    /// the runtime's thought channel and are never shown; each reply keeps
    /// room for them (`GenerationSettings.reasoningTokens`).
    public let reasons: Bool
    /// Whether a model that can use both starts on the GPU before the person
    /// chooses. Phi-4-mini-reasoning starts on the CPU: its GPU start hasn't
    /// been seen on the phone yet (1.1.0 (205)), and the CPU answered in the
    /// checks before it was added.
    public let startsOnGPU: Bool
    /// Whether a reply stops when the phone grows hot or the reply runs far
    /// too long (ReplyGuard): Phi-4-mini-reasoning and Qwen3.5 4B, which on
    /// 1.1.0 (205) showed only 「考えています…」 while the phone grew hot.
    public let guardsReplies: Bool
    /// Whether the CPU engine's weight cache file stays locked in memory
    /// while the engine runs (WeightCacheLock in the app). The runtime maps
    /// the file and reads all of its packed weights for every word; iOS may
    /// drop a mapped file's pages whenever it needs memory and read them
    /// back on the next use. Once Qwen3.5's 2.66 GB or Phi's 2.17 GB no
    /// longer stayed in memory, each word read them back from storage: on
    /// the simulator Qwen3.5 took 4 to 10 seconds a word, with 1.8 million
    /// page reads for six words, while E2B, whose cache is 0.79 GB, ran as
    /// fast as the official macOS build (1.1.0 (206)).
    public let locksCPUWeights: Bool
    /// Whether each new conversation starts on an engine that has run none:
    /// Qwen3.5 4B. LiteRT-LM 0.18.0 reuses the prompt a new conversation
    /// shares with the last one but not Qwen3.5's recurrent state (its
    /// card; LiteRT-LM issue 3165). With thinking on, from the fourth
    /// conversation on one engine every reply was empty, its thought only
    /// the system prompt, on the official Arm CPU build (run 40450328334),
    /// and the app's simulator check got no answer the same way (run
    /// 40448102818) (1.1.0 (206)). A turn that goes on in the live
    /// conversation keeps the engine.
    public let oneConversationPerEngine: Bool

    init(photos: Photos, documents: Bool, charts: Bool, thinking: Bool, contextTokens: Int, gpu: Bool, cpu: Bool,
         gpuPrecision: GPUPrecision, gpuBenchmarkMode: Bool, reasons: Bool = false, startsOnGPU: Bool = true,
         guardsReplies: Bool = false, locksCPUWeights: Bool = false, oneConversationPerEngine: Bool = false) {
        self.photos = photos; self.documents = documents; self.charts = charts; self.thinking = thinking
        self.contextTokens = contextTokens; self.gpu = gpu; self.cpu = cpu; self.gpuPrecision = gpuPrecision
        self.gpuBenchmarkMode = gpuBenchmarkMode; self.reasons = reasons; self.startsOnGPU = startsOnGPU
        self.guardsReplies = guardsReplies; self.locksCPUWeights = locksCPUWeights
        self.oneConversationPerEngine = oneConversationPerEngine
    }

    public static func of(_ model: ModelSpec) -> ModelCapabilities {
        switch model.id {
        case ModelSpec.e4b.id, ModelSpec.e2b.id:
            return ModelCapabilities(photos: .native, documents: true, charts: true, thinking: true, contextTokens: 8192,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        // Gemma 4 12B: text and files; its photos and audio are not checked
        // on the phone. Thinking stays off until a reply with it has been
        // seen there. 1.1.0 (200)'s chats wrote unrelated words and Bengali
        // letters on the phone's GPU (4,096 tokens, no benchmark mode). 201
        // started it as the developer 12B check had (1,024 tokens, benchmark
        // mode) with a new cache, and it answered; its comparison answered
        // with each of 1,024 and 4,096, with and without benchmark mode, all
        // from fresh caches (user 13:55 UTC 2026-10-26). So 202 is back at
        // 4,096 tokens, which reads files, with benchmark mode, which waits
        // for the weights before the first reply (GemmaService).
        case ModelSpec.gemma12B.id:
            return ModelCapabilities(photos: .unsupported, documents: true, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: false, gpuPrecision: .modelDefault, gpuBenchmarkMode: true)
        // Qwen takes text only: the plus menu offers it no photos, camera,
        // files or video.
        case ModelSpec.qwen3.id:
            // Qwen3-0.6B_dynamic_wi4b32_afp32 was exported with 4,096 tokens.
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .float32, gpuBenchmarkMode: false)
        // Phi-4-mini-reasoning (1.1.0 (205)): text only, 4,096 tokens. It
        // always thinks first; its card asks for at least 2,048 tokens for
        // the thinking and the answer. Both processors can be chosen.
        case ModelSpec.phi4MiniReasoning.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false,
                                     reasons: true, startsOnGPU: false, guardsReplies: true, locksCPUWeights: true)
        // Qwen3.5 4B Mixed INT4 (1.1.0 (205)): the text decoder only, with a
        // 4,096-token KV budget. CPU only: its export card measured an iPhone
        // 17 Pro's GPU at 5.74 GB of memory and 65 s to load, against the
        // CPU's 1.68 GB at 8.9 tokens a second (GPU 11.4). Thinking is off
        // unless switched on, as its template now defaults. Its card asks
        // for a new engine for each conversation; 205 shared one, as a
        // conversation after six others had answered as on a fresh engine
        // (run 40412428363, thinking off), but with thinking on later ones
        // came back empty, so since 206 each new conversation gets its own.
        case ModelSpec.qwen35.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: false, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false,
                                     guardsReplies: true, locksCPUWeights: true, oneConversationPerEngine: true)
        case ModelSpec.qwen25.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        default:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: false, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault, gpuBenchmarkMode: false)
        }
    }
}
