import Foundation

/// What each model can take in, in one place. Whether an input is offered
/// right now (a path still being checked on device) is ModelAttachmentPolicy's
/// call on top of this. Video and audio are not offered for any model.
public struct ModelCapabilities: Sendable, Equatable {
    /// How a photo reaches the model.
    public enum Photos: Sendable, Equatable {
        /// The model's own vision encoder reads the image.
        case native
        /// A text-only model: the photo's text is read on the device (OCR)
        /// and only that text reaches the model. It never sees the image.
        case textRecognition
        /// No photo input at all.
        case unsupported
    }
    public let photos: Photos
    /// TXT, Markdown, PDF, CSV, JSON and Word, read into plain text on the
    /// device. The model never receives the file's bytes.
    public let documents: Bool
    /// Replies in the shared ```chart format (RichBlock); the renderer is the
    /// same for every model, a small model may follow the format less often.
    public let charts: Bool
    public let thinking: Bool
    /// The context the pinned file was exported with (its KV cache).
    public let contextTokens: Int
    /// Whether replies may be generated on the GPU. LiteRT-LM gives the GPU
    /// the whole graph with no CPU fallback.
    public let gpu: Bool
    /// The GPU's precision for replies (EngineConfig.activationDataType). On
    /// the phone, Qwen3 0.6B's GPU build failed at the runtime's 16-bit
    /// default: the Metal shader generated for it did not compile ('half4'
    /// initialized from 'float4', 1.0.106's GPU start test). At 32-bit it
    /// started and answered, so Qwen3 runs on the GPU at 32-bit. Gemma and
    /// Qwen2.5 1.5B ran on the phone's GPU at the default.
    public let gpuPrecision: GPUPrecision

    public static func of(_ model: ModelSpec) -> ModelCapabilities {
        switch model.id {
        case ModelSpec.e4b.id, ModelSpec.e2b.id:
            return ModelCapabilities(photos: .native, documents: true, charts: true, thinking: true, contextTokens: 8192,
                                     gpu: true, gpuPrecision: .modelDefault)
        case ModelSpec.qwen3.id:
            // Qwen3-0.6B_dynamic_wi4b32_afp32 was exported with 4,096 tokens.
            return ModelCapabilities(photos: .textRecognition, documents: true, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: true, gpuPrecision: .float32)
        case ModelSpec.qwen25.id:
            return ModelCapabilities(photos: .textRecognition, documents: true, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, gpuPrecision: .modelDefault)
        default:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: false, thinking: false, contextTokens: 4096,
                                     gpu: true, gpuPrecision: .modelDefault)
        }
    }
}
