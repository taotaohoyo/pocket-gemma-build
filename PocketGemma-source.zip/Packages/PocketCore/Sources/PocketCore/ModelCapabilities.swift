import Foundation

/// What each model can take in, in one place. Whether an input is offered
/// right now (a path still being checked on device) is ModelAttachmentPolicy's
/// call on top of this. A model with native photos also takes videos, as a
/// few of their scenes (VideoScenes); audio is not offered for any model.
public struct ModelCapabilities: Sendable, Equatable {
    /// How a photo reaches the model.
    public enum Photos: Sendable, Equatable {
        /// The model's own vision encoder reads the image.
        case native
        /// A text-only model: the photo's text is read on the device (OCR)
        /// and only that text reaches the model. It never sees the image.
        /// No model uses it now: Qwen takes text only.
        case textRecognition
        /// No photo input at all.
        case unsupported
    }
    public let photos: Photos
    /// TXT, Markdown, PDF, CSV, JSON and Word, read into plain text on the
    /// device. The model never receives the file's bytes.
    public let documents: Bool
    /// Replies in the shared ```chart format (RichBlock); the renderer is the
    /// same for every model, a small model may follow the format less often.
    public let charts: Bool
    public let thinking: Bool
    /// The context the pinned file was exported with (its KV cache).
    public let contextTokens: Int
    /// Whether replies may be generated on the GPU. LiteRT-LM gives the GPU
    /// the whole graph with no CPU fallback.
    public let gpu: Bool
    /// Whether replies may be generated on the CPU. Gemma 4 12B wrote about
    /// 0.2 tokens a second there on the phone (2026-10-26), against 16 on
    /// the GPU, so it runs on the GPU only, and its reply waits for the app
    /// instead of going on on the CPU in the background.
    public let cpu: Bool
    /// The GPU's precision for replies (EngineConfig.activationDataType). On
    /// the phone, Qwen3 0.6B's GPU build failed at the runtime's 16-bit
    /// default: the Metal shader generated for it did not compile ('half4'
    /// initialized from 'float4', 1.0.106's GPU start test). At 32-bit it
    /// started and answered, so Qwen3 runs on the GPU at 32-bit. Gemma and
    /// Qwen2.5 1.5B ran on the phone's GPU at the default.
    public let gpuPrecision: GPUPrecision

    public static func of(_ model: ModelSpec) -> ModelCapabilities {
        switch model.id {
        case ModelSpec.e4b.id, ModelSpec.e2b.id:
            return ModelCapabilities(photos: .native, documents: true, charts: true, thinking: true, contextTokens: 8192,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault)
        // Gemma 4 12B: text and files, at the 4,096 tokens of the other
        // text models; its photos and audio are not checked on the phone.
        // Thinking stays off until a reply with it has been seen there.
        case ModelSpec.gemma12B.id:
            return ModelCapabilities(photos: .unsupported, documents: true, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: false, gpuPrecision: .modelDefault)
        // Qwen takes text only: the plus menu offers it no photos, camera,
        // files or video.
        case ModelSpec.qwen3.id:
            // Qwen3-0.6B_dynamic_wi4b32_afp32 was exported with 4,096 tokens.
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: true, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .float32)
        case ModelSpec.qwen25.id:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: true, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault)
        default:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: false, thinking: false, contextTokens: 4096,
                                     gpu: true, cpu: true, gpuPrecision: .modelDefault)
        }
    }
}
