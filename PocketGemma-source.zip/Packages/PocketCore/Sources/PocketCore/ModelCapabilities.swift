import Foundation

/// What each model can take in, in one place. Whether an input is offered
/// right now (a path still being checked on device) is ModelAttachmentPolicy's
/// call on top of this. Video and audio are not offered for any model.
public struct ModelCapabilities: Sendable, Equatable {
    /// How a photo reaches the model.
    public enum Photos: Sendable, Equatable {
        /// The model's own vision encoder reads the image.
        case native
        /// A text-only model: no photo input at all.
        case unsupported
    }
    public let photos: Photos
    /// TXT, Markdown, PDF, CSV, JSON and Word, read into plain text on the
    /// device. The model never receives the file's bytes.
    public let documents: Bool
    /// Replies in the shared ```chart format (RichBlock); the renderer is the
    /// same for every model, a small model may follow the format less often.
    public let charts: Bool
    public let thinking: Bool
    /// The context the pinned file was exported with (its KV cache).
    public let contextTokens: Int

    public static func of(_ model: ModelSpec) -> ModelCapabilities {
        switch model.id {
        case ModelSpec.e4b.id, ModelSpec.e2b.id:
            return ModelCapabilities(photos: .native, documents: true, charts: true, thinking: true, contextTokens: 8192)
        case ModelSpec.qwen3.id:
            // Qwen3-0.6B_dynamic_wi4b32_afp32 was exported with 4,096 tokens.
            return ModelCapabilities(photos: .unsupported, documents: true, charts: true, thinking: true, contextTokens: 4096)
        case ModelSpec.qwen25.id:
            return ModelCapabilities(photos: .unsupported, documents: true, charts: true, thinking: false, contextTokens: 4096)
        default:
            return ModelCapabilities(photos: .unsupported, documents: false, charts: false, thinking: false, contextTokens: 4096)
        }
    }
}
