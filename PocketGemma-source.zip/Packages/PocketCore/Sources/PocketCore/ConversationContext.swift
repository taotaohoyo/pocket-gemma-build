import Foundation

/// A native conversation already contains completed turns. Reuse it only when
/// it belongs to this chat and ends with exactly the history being supplied.
/// The history is chosen by a byte estimate, so it can leave out older turns
/// the conversation still holds; reuse keeps them while the conversation's
/// real token count has room (GemmaService checks it), instead of rebuilding
/// the chat without them.
public struct ConversationContext: Sendable {
    private struct Entry: Equatable, Sendable {
        let role: ChatRole
        let text: String
        let attachments: [ChatAttachment]
        init(role: ChatRole, text: String, attachments: [ChatAttachment]) {
            self.role = role; self.text = text; self.attachments = attachments
        }
        init(_ message: ChatMessage) { self.init(role: message.role, text: message.text, attachments: message.media) }
        /// Whether the conversation's turn is `given`: the same, or `given`
        /// its excerpt (HistoryExcerpt, 1.1.0 (256)), the conversation then
        /// holding the whole of it.
        func holds(_ given: Entry) -> Bool {
            self == given || (role == given.role && attachments == given.attachments && HistoryExcerpt.isExcerpt(given.text, of: text))
        }
    }
    private var threadID: UUID?
    private var entries: [Entry] = []
    /// The conversation's real token count after its last completed turn.
    private var tokens = Int.max

    public init() {}

    public func canReuse(threadID: UUID, history: [ChatMessage]) -> Bool {
        let recent = history.map(Entry.init)
        // Whole turns only: what the history leaves out is older user/reply pairs.
        return self.threadID == threadID && entries.count >= recent.count
            && (entries.count - recent.count) % 2 == 0
            && zip(entries.suffix(recent.count), recent).allSatisfy { $0.holds($1) }
    }

    public mutating func completeTurn(threadID: UUID, history: [ChatMessage], prompt: String, reply: String,
                                     attachments: [ChatAttachment] = [], tokens: Int = .max) {
        // A rebuilt conversation (invalidated first) holds just this history.
        if !canReuse(threadID: threadID, history: history) { entries = history.map(Entry.init) }
        self.threadID = threadID
        self.tokens = tokens
        entries.append(Entry(role: .user, text: prompt, attachments: attachments))
        entries.append(Entry(role: .assistant, text: reply, attachments: []))
    }

    /// The turns the last conversation held, when this history ends with
    /// them and they took fewer than `tokenLimit` tokens. A conversation
    /// released with the model (the app went to the background, say) comes
    /// back with them, not just with the shorter history the byte estimate
    /// chose. Older turns with photos or files are left to that choice.
    public func heldHistory(threadID: UUID, history: [ChatMessage], tokenLimit: Int) -> [ChatMessage]? {
        guard canReuse(threadID: threadID, history: history), entries.count > history.count, tokens < tokenLimit
        else { return nil }
        let older = entries.prefix(entries.count - history.count)
        guard older.allSatisfy({ $0.attachments.isEmpty }) else { return nil }
        // An excerpt in the history comes back whole, as the conversation held it.
        let held = zip(history, entries.suffix(history.count)).map { message, entry -> ChatMessage in
            var message = message
            message.text = entry.text
            return message
        }
        return older.map { ChatMessage(role: $0.role, text: $0.text) } + held
    }

    public mutating func invalidate() {
        threadID = nil
        entries = []
        tokens = .max
    }
}

/// UI callbacks from an expired native request must not affect a newer reply.
public struct ReplyTicket: Sendable {
    public private(set) var activeID: UUID?
    public init() {}
    public mutating func begin() -> UUID {
        let id = UUID()
        activeID = id
        return id
    }
    public func accepts(_ id: UUID) -> Bool { activeID == id }
    @discardableResult public mutating func finish(_ id: UUID) -> Bool {
        guard accepts(id) else { return false }
        activeID = nil
        return true
    }
}
