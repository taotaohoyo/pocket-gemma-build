import Foundation
import CryptoKit

/// PCと接続 (1.1.0 (253), the user's directive of 2026-11-01 「Windows・
/// iPhone間のローカルAI接続」): a chat whose replies come from a model on the
/// person's Windows PC, through Fielua for Windows on the same LAN. Text
/// only; the conversation stays on the iPhone and only the turns a reply
/// needs go to the PC. This file holds what does not need the network:
/// the QR code's invitation, the numbers both screens show, the reply's
/// lines and which turns are sent. The connection itself is the app's
/// (PCLinkClient), over TLS to the PC's own certificate, checked by its
/// SHA-256 (the fingerprint the QR code carries).
public enum PCLink {
    /// Fielua Link's version, as Fielua for Windows speaks it.
    public static let protocolVersion = 1
    /// Bonjour's service type; the Info.plist's NSBonjourServices names it.
    public static let serviceType = "_fielua._tcp"
    public static let defaultPort = 47860
    /// The PC answers by its mDNS name too, whatever its address today.
    public static func mdnsHost(pcID: String) -> String { "fielua-\(pcID).local" }
    /// The Bonjour TXT entry of a Fielua for Windows that lets the iPhone
    /// register it by choosing it in the list (1.1.0 (254), 「Fielua Link
    /// 接続体験改善」): pair=select. An older one lacks it and is registered
    /// with its connection code, as before.
    public static let pairKey = "pair"
    public static let pairSelect = "select"
    /// Where Windows's mobile hotspot puts the PC itself.
    public static let hotspotAddress = "192.168.137.1"

    // MARK: The numbers both screens show

    public static func base64URL(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    public static func data(base64URL text: String) -> Data? {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        guard !s.isEmpty, s.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "+" || $0 == "/") }) else { return nil }
        while s.count % 4 != 0 { s += "=" }
        return Data(base64Encoded: s)
    }

    public static func sha256(_ parts: Data...) -> Data {
        var hasher = SHA256()
        for part in parts { hasher.update(data: part) }
        return Data(hasher.finalize())
    }

    /// What the PC promises before it hears the iPhone's random value.
    public static func commitment(serverNonce: Data) -> String {
        base64URL(sha256(Data("fielua-link-commit-v1".utf8), serverNonce))
    }

    /// The six digits both screens show, as "123 456". The person compares
    /// them: a device in between could not make them match, as the PC
    /// committed to its random value before it heard the iPhone's.
    public static func confirmationNumber(fingerprint: Data, clientNonce: Data, serverNonce: Data) -> String {
        let hash = sha256(Data("fielua-link-sas-v1".utf8), fingerprint, clientNonce, serverNonce)
        let value = Int(hash.prefix(4).reduce(UInt32(0)) { $0 << 8 | UInt32($1) } % 1_000_000)
        return String(format: "%03d %03d", value / 1000, value % 1000)
    }

    /// The PC keeps this, never the token itself.
    public static func tokenHash(_ token: String) -> String {
        sha256(Data("fielua-link-token-v1".utf8), Data(token.trimmingCharacters(in: .whitespacesAndNewlines).utf8))
            .map { String(format: "%02x", $0) }.joined()
    }

    /// 32 bytes from the system's secure random source.
    public static func randomNonce() -> Data {
        SymmetricKey(size: .bits256).withUnsafeBytes { Data($0) }
    }

    /// The connection code as typed: its digits alone.
    public static func normalizedCode(_ text: String) -> String {
        String(text.filter { $0.isASCII && $0.isNumber })
    }

    /// The PC's addresses in the order to try them: the one that answered
    /// last, the PC where Bonjour finds it and addresses on the iPhone's
    /// own network, then names (wherever the PC is), then addresses on
    /// other networks, which rarely answer (1.1.0 (254)). Each once.
    public static func orderedHosts(_ hosts: [String], first: String? = nil, announced: String? = nil,
                                    network: PCLinkNetwork? = nil) -> [String] {
        var seen = Set<String>()
        var all = hosts
        if let announced { all.insert(announced, at: 0) }
        if let first { all.insert(first, at: 0) }
        let unique = all.filter { seen.insert($0.lowercased()).inserted }
        func rank(_ host: String) -> Int {
            if let first, host.caseInsensitiveCompare(first) == .orderedSame { return 0 }
            if let announced, host.caseInsensitiveCompare(announced) == .orderedSame { return 1 }
            if PCLinkNetwork.value(host) == nil { return 2 }
            guard let network else { return 2 }
            return network.contains(host) ? 1 : 3
        }
        return unique.enumerated()
            .sorted { (rank($0.element), $0.offset) < (rank($1.element), $1.offset) }
            .map(\.element)
    }

    /// "192.168.1.10", "192.168.1.10:47860" or "DESKTOP.local:47861".
    public static func address(_ text: String) -> (host: String, port: Int)? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !trimmed.contains("/"), !trimmed.contains(" ") else { return nil }
        let parts = trimmed.split(separator: ":", omittingEmptySubsequences: false)
        switch parts.count {
        case 1: return (trimmed, defaultPort)
        case 2:
            guard !parts[0].isEmpty, let port = Int(parts[1]), (1...65535).contains(port) else { return nil }
            return (String(parts[0]), port)
        default: return nil
        }
    }
}

/// The QR code Fielua for Windows shows:
/// fielua://pair?v=1&id=..&n=..&h=192.168.1.10,192.168.1.11&p=47860&fp=..&s=..
public struct PCPairingInvite: Equatable, Sendable {
    public let pcID: String
    public let pcName: String
    public let hosts: [String]
    public let port: Int
    /// The SHA-256 of the PC's certificate.
    public let fingerprint: Data
    /// The one-time value that lets this iPhone ask to be registered.
    public let secret: String

    public init?(_ text: String) {
        guard let components = URLComponents(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              components.scheme == "fielua", components.host == "pair" else { return nil }
        var query: [String: String] = [:]
        for item in components.queryItems ?? [] where query[item.name] == nil { query[item.name] = item.value ?? "" }
        guard query["v"] == String(PCLink.protocolVersion),
              let id = query["id"], !id.isEmpty, id.count <= 64,
              id.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber) }),
              let portText = query["p"], let port = Int(portText), (1...65535).contains(port),
              let fingerprint = query["fp"].flatMap(PCLink.data(base64URL:)), fingerprint.count == 32,
              let secret = query["s"], PCLink.data(base64URL: secret)?.count == 32 else { return nil }
        pcID = id
        let name = (query["n"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        pcName = name.isEmpty ? "Windows PC" : String(name.prefix(60))
        hosts = (query["h"] ?? "").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
        self.port = port
        self.fingerprint = fingerprint
        self.secret = secret
    }
}

/// A PC this iPhone is registered with. Kept whole in the keychain, on
/// this device only (PCLinkKeychain): it holds the token.
public struct PCPairedPC: Codable, Equatable, Sendable {
    public var pcID: String
    public var pcName: String
    /// base64url of the certificate's SHA-256.
    public var fingerprint: String
    /// Addresses to try, the last that answered first.
    public var hosts: [String]
    public var port: Int
    public var deviceID: String
    public var token: String
    public var pairedAt: Date

    public init(pcID: String, pcName: String, fingerprint: String, hosts: [String], port: Int,
                deviceID: String, token: String, pairedAt: Date = Date()) {
        self.pcID = pcID
        self.pcName = pcName
        self.fingerprint = fingerprint
        self.hosts = hosts
        self.port = port
        self.deviceID = deviceID
        self.token = token
        self.pairedAt = pairedAt
    }

    /// The addresses to try in order: the saved ones, then the PC's mDNS
    /// name, which follows the PC to a new address.
    public var candidateHosts: [String] {
        var seen = Set<String>()
        return (hosts + [PCLink.mdnsHost(pcID: pcID)]).filter { seen.insert($0.lowercased()).inserted }
    }

    /// The address that answered goes first next time, then the PC's own
    /// addresses as it gave them (1.1.0 (254): IPv4 only, for when its
    /// name can't be looked up), then the rest; six at most. Its port, if
    /// Bonjour found it on another.
    public mutating func answered(at host: String, port: Int? = nil, addresses: [String] = []) {
        var seen = Set<String>()
        let list = ([host] + addresses.filter { PCLinkNetwork.value($0) != nil } + hosts)
            .filter { seen.insert($0.lowercased()).inserted }
        hosts = Array(list.prefix(6))
        if let port, (1...65535).contains(port) { self.port = port }
    }
}

/// An IPv4 network as an address and its prefix ("192.168.1.0/24"): the
/// iPhone's own network, to tell whether it is still the one the PC last
/// answered on, and whether it is the PC's mobile hotspot.
public struct PCLinkNetwork: Equatable, Hashable, Sendable, CustomStringConvertible {
    /// The network's first address (the address with its host bits off).
    public let base: UInt32
    public let prefix: Int

    public init?(address: String, prefix: Int) {
        guard let value = Self.value(address), (1...32).contains(prefix) else { return nil }
        self.prefix = prefix
        base = value & Self.mask(prefix)
    }

    /// From an address and its netmask, as the system gives them.
    public init?(address: String, netmask: String) {
        guard let mask = Self.value(netmask), mask != 0, (~mask) & ((~mask) &+ 1) == 0 else { return nil }
        self.init(address: address, prefix: mask.nonzeroBitCount)
    }

    /// "192.168.1.0/24", as kept between launches.
    public init?(_ text: String) {
        let parts = text.split(separator: "/")
        guard parts.count == 2, let prefix = Int(parts[1]) else { return nil }
        self.init(address: String(parts[0]), prefix: prefix)
    }

    public var description: String {
        let octets = [24, 16, 8, 0].map { String((base >> UInt32($0)) & 0xFF) }
        return octets.joined(separator: ".") + "/\(prefix)"
    }

    public func contains(_ host: String) -> Bool {
        guard let value = Self.value(host) else { return false }
        return value & Self.mask(prefix) == base
    }

    /// Windows's mobile hotspot (192.168.137.0/24, the PC at .1).
    public var isWindowsHotspot: Bool {
        prefix >= 24 && PCLinkNetwork(address: PCLink.hotspotAddress, prefix: 24)?.base == base & Self.mask(24)
    }

    /// A dotted IPv4 address as a number; nil for names and anything else.
    public static func value(_ text: String) -> UInt32? {
        let parts = text.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return nil }
        var value: UInt32 = 0
        for part in parts {
            guard !part.isEmpty, part.count <= 3, part.allSatisfy({ $0.isASCII && $0.isNumber }),
                  let octet = UInt32(part), octet <= 255 else { return nil }
            value = value << 8 | octet
        }
        return value
    }

    private static func mask(_ prefix: Int) -> UInt32 { prefix >= 32 ? .max : ~(UInt32.max >> UInt32(prefix)) }
}

/// Why the registered PC doesn't answer, as far as the iPhone can tell
/// (1.1.0 (254), 「Fielua Link 接続体験改善」). Never surer than the
/// facts: where several causes fit (a PC asleep, Fielua's reception off, a
/// network that keeps devices apart), the person gets what to check.
public enum PCLinkProblem: Equatable, Sendable {
    /// iOS's ローカルネットワーク is off for Fielua.
    case localNetworkOff
    /// The iPhone is on no Wi-Fi (or wired) network.
    case noNetwork
    /// The PC announces itself on this network, yet doesn't answer: its
    /// firewall, most likely, or a network that passes announcements only.
    case pcSilent
    /// The PC last answered through its mobile hotspot, and the iPhone is
    /// on another network now.
    case hotspotElsewhere
    /// The iPhone is on another network than when the PC last answered.
    case otherNetwork
    /// Nothing heard from the PC: off or asleep, Fielua closed or its
    /// reception off, another network, or one that keeps devices apart.
    case notFound

    public struct Facts: Equatable, Sendable {
        public var localNetworkDenied: Bool
        /// nil while unknown.
        public var onLocalNetwork: Bool?
        /// The iPhone's network now.
        public var phoneNetwork: PCLinkNetwork?
        /// The iPhone's network when the PC last answered.
        public var lastNetwork: PCLinkNetwork?
        /// The PC is announced (Bonjour) on this network now.
        public var pcAnnounced: Bool
        /// The PC's addresses as it showed them just now (its QR code): it
        /// is running, so an address on the iPhone's network that doesn't
        /// answer is the PC refusing, or the network.
        public var pcAddresses: [String]

        public init(localNetworkDenied: Bool = false, onLocalNetwork: Bool? = nil, phoneNetwork: PCLinkNetwork? = nil,
                    lastNetwork: PCLinkNetwork? = nil, pcAnnounced: Bool = false, pcAddresses: [String] = []) {
            self.localNetworkDenied = localNetworkDenied
            self.onLocalNetwork = onLocalNetwork
            self.phoneNetwork = phoneNetwork
            self.lastNetwork = lastNetwork
            self.pcAnnounced = pcAnnounced
            self.pcAddresses = pcAddresses
        }
    }

    public static func diagnose(_ facts: Facts) -> PCLinkProblem {
        if facts.localNetworkDenied { return .localNetworkOff }
        if facts.onLocalNetwork == false { return .noNetwork }
        if facts.pcAnnounced { return .pcSilent }
        let shown = facts.pcAddresses.filter { PCLinkNetwork.value($0) != nil }
        if let now = facts.phoneNetwork, !shown.isEmpty {
            return shown.contains(where: now.contains) ? .pcSilent : .otherNetwork
        }
        if let last = facts.lastNetwork, let now = facts.phoneNetwork, last != now {
            return last.isWindowsHotspot ? .hotspotElsewhere : .otherNetwork
        }
        return .notFound
    }
}

/// A model on the PC, as its list gives it.
public struct PCModel: Codable, Equatable, Identifiable, Sendable {
    public var name: String
    public var sizeBytes: Int64
    public var family: String?
    public var parameterSize: String?
    public var quantization: String?
    public var id: String { name }

    public init(name: String, sizeBytes: Int64 = 0, family: String? = nil, parameterSize: String? = nil, quantization: String? = nil) {
        self.name = name
        self.sizeBytes = sizeBytes
        self.family = family
        self.parameterSize = parameterSize
        self.quantization = quantization
    }

    /// "gemma3:4b" without ":latest", for the menu and the pill.
    public var shortName: String {
        name.hasSuffix(":latest") ? String(name.dropLast(7)) : name
    }
}

/// The chat's PC model: its replies come from this model on this PC.
public struct PCChatTarget: Codable, Equatable, Hashable, Sendable {
    public var pcID: String
    public var pcName: String
    public var model: String

    public init(pcID: String, pcName: String, model: String) {
        self.pcID = pcID
        self.pcName = pcName
        self.model = model
    }

    public var shortModel: String { PCModel(name: model).shortName }
}

/// One line of a reply as the PC streams it.
public enum PCChatEvent: Equatable, Sendable {
    case started(model: String)
    case delta(content: String, thinking: String)
    /// Still working (the model loading, Ollama starting): sent every few
    /// seconds, so a lost connection shows.
    case waiting(stage: String?)
    case done(outputTokens: Int, evalMilliseconds: Int)
    case failed(kind: String, detail: String)
    case stopped

    public init?(line: String) {
        guard let data = line.data(using: .utf8),
              let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let type = object["type"] as? String else { return nil }
        switch type {
        case "started": self = .started(model: object["model"] as? String ?? "")
        case "delta":
            self = .delta(content: object["content"] as? String ?? "", thinking: object["thinking"] as? String ?? "")
        case "waiting": self = .waiting(stage: object["stage"] as? String)
        case "done":
            let stats = object["stats"] as? [String: Any]
            self = .done(outputTokens: (stats?["outputTokens"] as? NSNumber)?.intValue ?? 0,
                         evalMilliseconds: (stats?["evalMs"] as? NSNumber)?.intValue ?? 0)
        case "failed":
            let error = object["error"] as? [String: Any]
            self = .failed(kind: error?["kind"] as? String ?? "other", detail: error?["detail"] as? String ?? "")
        case "stopped": self = .stopped
        default: return nil
        }
    }
}

/// A turn as the PC takes it.
public struct PCTurn: Codable, Equatable, Sendable {
    public var role: String
    public var content: String
    public init(role: String, content: String) { self.role = role; self.content = content }
}

/// The turns a PC reply needs: the latest complete exchanges, newest
/// kept first, within a budget, then the question. Only text goes: an
/// exchange whose question carried a photo, video, recording or file is
/// left out, as the PC would read its words without what they are about.
/// Failed and stopped replies are never sent back.
public enum PCContext {
    public static let byteBudget = 32 * 1024
    public static let maxMessages = 40

    public static func turns(history: [ChatMessage], question: String,
                             byteBudget: Int = PCContext.byteBudget, maxMessages: Int = PCContext.maxMessages) -> [PCTurn] {
        var pairs: [(ChatMessage, ChatMessage)] = []
        var pending: ChatMessage?
        for message in history {
            if message.role == .user {
                pending = message
            } else {
                if let asked = pending, asked.media.isEmpty, !asked.text.isEmpty,
                   message.state == .complete, !message.text.isEmpty {
                    pairs.append((asked, message))
                }
                pending = nil
            }
        }
        var kept: [PCTurn] = []
        var used = question.utf8.count
        for (asked, answer) in pairs.reversed() {
            let cost = asked.text.utf8.count + answer.text.utf8.count
            guard used + cost <= byteBudget, kept.count + 3 <= maxMessages else { break }
            kept.insert(contentsOf: [PCTurn(role: "user", content: asked.text),
                                     PCTurn(role: "assistant", content: answer.text)], at: 0)
            used += cost
        }
        return kept + [PCTurn(role: "user", content: question)]
    }
}
