import Foundation

/// Fielua's own backup in iCloud (1.1.0 (252)): a folder in the app's iCloud
/// container, outside the container's Documents folder, so neither the Files
/// app nor iCloud Drive lists it. It is hidden, not locked with a key of the
/// person's own: whoever signs in to the same Apple Account gets it back, and
/// iCloud's storage settings show it and can delete it.
///
/// Each device writes only its own folder, `<deviceID>/`: its conversations
/// and the attachments they use. After the conversations it removes its
/// attachments no conversation uses any more, so a deleted chat's photos and
/// files leave iCloud with it. Restoring merges every device's folder.
public struct PrivateBackup {
    /// Inside the container, beside (never in) its Documents folder.
    public static let folderName = "Backup"
    public static let archiveName = "conversations.json"
    public static let attachmentsName = "Attachments"
    /// An archive larger than this is not read (as with the folder backup).
    public static let largestArchive = 32_000_000
    public let root: URL

    public init(container: URL) {
        root = container.appendingPathComponent(Self.folderName, isDirectory: true)
    }

    public struct Saved: Equatable, Sendable {
        public var copied: Int
        public var removed: Int
    }

    /// This device's folder; a device ID is a UUID, never a path.
    public func deviceFolder(_ deviceID: String) throws -> URL {
        guard UUID(uuidString: deviceID) != nil else { throw CocoaError(.fileWriteInvalidFileName) }
        return root.appendingPathComponent(deviceID, isDirectory: true)
    }

    /// Writes this device's folder: the attachments the conversations use
    /// that are not there yet (`source(name)` is where each is now), then the
    /// conversations, only once every attachment they name is there, then
    /// removes this device's attachments that none of them uses.
    @discardableResult
    public func save(_ threads: [ChatThread], deviceID: String, source: (String) -> URL?) throws -> Saved {
        let names = try HistoryMerge.attachmentNames(in: threads)
        let device = try deviceFolder(deviceID)
        let media = device.appendingPathComponent(Self.attachmentsName, isDirectory: true)
        let files = FileManager.default
        try files.createDirectory(at: media, withIntermediateDirectories: true)
        for url in [root, device, media] { try Self.requireDirectory(url) }
        let present = Set(try Self.entries(in: media).map(\.name))
        var saved = Saved(copied: 0, removed: 0)
        for name in names.sorted() where !present.contains(name) {
            try Task.checkCancellation()
            guard let from = source(name), files.fileExists(atPath: from.path) else { throw CocoaError(.fileReadNoSuchFile) }
            try files.copyItem(at: from, to: media.appendingPathComponent(name))
            saved.copied += 1
        }
        try ChatArchive(fileURL: device.appendingPathComponent(Self.archiveName)).save(threads)
        for entry in try Self.entries(in: media) where !names.contains(entry.name) {
            // The item itself; an older iOS's stand-in for a file still in
            // iCloud (".name.icloud") when only that is here.
            let logical = media.appendingPathComponent(entry.name)
            if (try? files.removeItem(at: logical)) != nil || (try? files.removeItem(at: entry.url)) != nil {
                saved.removed += 1
            }
        }
        return saved
    }

    /// Every device's conversations, merged, with the attachments they use
    /// copied to `destination(name)` where that has no file yet.
    /// `prepare(url)` runs before each file is read; the app has iCloud
    /// download it there. Throws when there is no conversation, or when an
    /// attachment a conversation names is in no device's folder (yet), so a
    /// restore never brings back a conversation without its photos.
    public func restore(prepare: (URL) throws -> Void, destination: (String) -> URL?) throws -> [ChatThread] {
        try Self.requireDirectory(root)
        let files = FileManager.default
        var restored: [ChatThread] = []
        var folders: [(url: URL, media: Set<String>)] = []
        let devices = try files.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        for device in devices.sorted(by: { $0.lastPathComponent < $1.lastPathComponent })
        where UUID(uuidString: device.lastPathComponent) != nil {
            let values = try device.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isDirectory == true, values.isSymbolicLink != true else { continue }
            guard try Self.entries(in: device).contains(where: { $0.name == Self.archiveName }) else { continue }
            let file = device.appendingPathComponent(Self.archiveName)
            try prepare(file)
            try Self.requireFile(file)
            let size = try files.attributesOfItem(atPath: file.path)[.size] as? NSNumber
            guard (size?.intValue ?? Int.max) <= Self.largestArchive else { throw CocoaError(.fileReadTooLarge) }
            restored = HistoryMerge.merge(local: restored, incoming: try ChatArchive(fileURL: file).load())
            let media = device.appendingPathComponent(Self.attachmentsName, isDirectory: true)
            let hasMedia = (try? media.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]))
                .map { $0.isDirectory == true && $0.isSymbolicLink != true } ?? false
            folders.append((device, hasMedia ? Set(try Self.entries(in: media).map(\.name)) : []))
        }
        guard !restored.isEmpty else { throw CocoaError(.fileReadNoSuchFile) }
        for name in try HistoryMerge.attachmentNames(in: restored).sorted() {
            try Task.checkCancellation()
            guard let to = destination(name) else { throw CocoaError(.fileReadCorruptFile) }
            if files.fileExists(atPath: to.path) { continue }
            guard let folder = folders.first(where: { $0.media.contains(name) }) else { throw CocoaError(.fileReadNoSuchFile) }
            let from = folder.url.appendingPathComponent(Self.attachmentsName, isDirectory: true).appendingPathComponent(name)
            try prepare(from)
            try Self.requireFile(from)
            try files.createDirectory(at: to.deletingLastPathComponent(), withIntermediateDirectories: true)
            try files.copyItem(at: from, to: to)
        }
        return restored
    }

    /// The name a folder entry stands for: its own, or for an older iOS's
    /// stand-in of a file still in iCloud (".photo.jpg.icloud") the file's.
    /// nil for anything else hidden, and for unsafe names.
    public static func itemName(_ entry: String) -> String? {
        var name = entry
        if entry.hasPrefix("."), entry.hasSuffix(".icloud") {
            name = String(entry.dropFirst().dropLast(".icloud".count))
        }
        guard !name.hasPrefix("."), ChatAttachment.isSafeFileName(name) else { return nil }
        return name
    }

    /// The files in `folder` by the name they stand for. Throws on a folder
    /// or a symbolic link where a file belongs.
    static func entries(in folder: URL) throws -> [(name: String, url: URL)] {
        let urls = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        return try urls.compactMap { url in
            guard let name = itemName(url.lastPathComponent) else { return nil }
            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isDirectory != true || name == attachmentsName else { throw CocoaError(.fileReadCorruptFile) }
            guard values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
            if values.isDirectory == true { return nil }
            return (name: name, url: url)
        }
    }

    static func requireDirectory(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
    }

    static func requireFile(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
    }
}
