import Foundation

/// The iPhone's chats as Fielua's Apple Watch app sees them (2026-10-24).
/// The chats on the iPhone are the record. The watch is sent a short list of
/// them and, for the chat it shows, that chat's latest messages (a page),
/// and keeps only a copy of those (Cache). It never sends history back:
/// what it adds is a question, which the iPhone writes into the chat
/// itself. Both sides name a chat by its id on the iPhone, so a question
/// from the watch goes to that chat and no other, and the question's id is
/// its message's, so a question sent twice is written once.
///
/// This file is compiled into PocketCore and, as it is, into the watch
/// app, which has no PocketCore: Foundation only. The iPhone builds the
/// list and pages from its chats in WatchHistoryBuilder.
public enum WatchHistory {
    /// The most chats the list carries, the latest first.
    public static let listLimit = 40
    /// A page's room in bytes. WatchConnectivity's messages hold about
    /// 64 KB, and a page goes in one.
    public static let pageBudget = 40_000
    /// The most of one message a page carries, from its start; the rest is
    /// read on the iPhone.
    public static let messageLimit = 6_000
    /// The most messages a page carries.
    public static let pageMessages = 60
    /// Room for a message's id, state and keys in the encoded page.
    static let messageOverhead = 160

    /// One chat in the watch's list.
    public struct Summary: Codable, Equatable, Identifiable, Sendable {
        public var id: String
        public var title: String
        public var updated: Date
        /// The chat's model, as short as the watch shows it: E4B, E2B,
        /// Qwen3 0.6B.
        public var model: String
        /// The chat is Gemma 4 E2B's, the model that answers the watch.
        public var watchModel: Bool
        /// Its messages on the iPhone.
        public var count: Int

        public init(id: String, title: String, updated: Date, model: String, watchModel: Bool, count: Int) {
            self.id = id
            self.title = title
            self.updated = updated
            self.model = model
            self.watchModel = watchModel
            self.count = count
        }
    }

    public struct List: Codable, Equatable, Sendable {
        public var chats: [Summary]
        /// The watch's conversation of 1.1.0 (152), before the two shared
        /// chat ids, and the chat it was on the iPhone: the watch takes the
        /// chat's id for it.
        public var formerConversation: String?
        public var formerChat: String?

        public init(chats: [Summary], formerConversation: String? = nil, formerChat: String? = nil) {
            self.chats = chats
            self.formerConversation = formerConversation
            self.formerChat = formerChat
        }

        public func summary(_ chat: String) -> Summary? { chats.first { $0.id == chat } }
    }

    public struct Message: Codable, Equatable, Identifiable, Sendable {
        public var id: String
        public var fromUser: Bool
        public var text: String
        /// As WatchLink.State names it: finished, waiting, writing, paused,
        /// stopped, failed.
        public var state: String
        /// Only the text's start came: the whole is on the iPhone.
        public var clipped: Bool
        /// Photos and files sent with it, which only the iPhone shows.
        public var attachments: Int

        public init(id: String, fromUser: Bool, text: String, state: String, clipped: Bool = false, attachments: Int = 0) {
            self.id = id
            self.fromUser = fromUser
            self.text = text
            self.state = state
            self.clipped = clipped
            self.attachments = attachments
        }
    }

    /// A chat's latest messages, as many as fit, starting on a question.
    public struct Page: Codable, Equatable, Sendable {
        public var chat: String
        public var updated: Date
        public var model: String
        public var watchModel: Bool
        /// All its messages on the iPhone.
        public var count: Int
        public var messages: [Message]
        /// The older messages left on the iPhone.
        public var earlier: Int

        public init(chat: String, updated: Date, model: String, watchModel: Bool, count: Int, messages: [Message],
                    earlier: Int) {
            self.chat = chat
            self.updated = updated
            self.model = model
            self.watchModel = watchModel
            self.count = count
            self.messages = messages
            self.earlier = earlier
        }

        /// The list says the chat has changed since this page.
        public func isBehind(_ summary: Summary) -> Bool {
            summary.updated > updated || summary.count != count
        }
    }

    /// A question and its answer, as the watch shows them. The id is the
    /// question's: the watch's own question has the same.
    public struct Turn: Equatable, Sendable {
        public var id: String
        public var question: String
        public var answer: String
        public var state: String
        public var clipped: Bool
        public var attachments: Int
    }

    /// A page's messages as questions and their answers. An answer goes
    /// with the question before it; a question with none ended without one.
    public static func turns(_ messages: [Message]) -> [Turn] {
        var turns: [Turn] = []
        var open = false
        for message in messages {
            if message.fromUser {
                turns.append(Turn(id: message.id, question: message.text, answer: "", state: "stopped",
                                  clipped: message.clipped, attachments: message.attachments))
                open = true
            } else if open, var last = turns.popLast() {
                last.answer = message.text
                last.state = message.state
                last.clipped = last.clipped || message.clipped
                last.attachments += message.attachments
                turns.append(last)
                open = false
            } else {
                // An answer with no question before it: shown on its own.
                turns.append(Turn(id: message.id, question: "", answer: message.text, state: message.state,
                                  clipped: message.clipped, attachments: message.attachments))
            }
        }
        return turns
    }

    /// The watch's copy: the last list, and the pages of the chats it
    /// opened lately, the latest first. It is only a copy: a newer list or
    /// page replaces what it holds.
    public struct Cache: Codable, Equatable, Sendable {
        public static let pagesKept = 8
        public private(set) var list: List?
        public private(set) var pages: [Page] = []

        public init() {}

        public func page(_ chat: String) -> Page? { pages.first { $0.chat == chat } }

        public mutating func store(_ page: Page) {
            pages.removeAll { $0.chat == page.chat }
            pages.insert(page, at: 0)
            if pages.count > Self.pagesKept { pages.removeLast(pages.count - Self.pagesKept) }
        }

        /// Takes a newer list. Returns the chats it showed that the iPhone
        /// no longer has, and drops their pages. A chat that only fell off
        /// the end of a full list (the latest come first) is not among them.
        @discardableResult
        public mutating func apply(_ next: List) -> Set<String> {
            let previous = list?.chats ?? []
            list = next
            let now = Set(next.chats.map(\.id))
            let full = next.chats.count >= WatchHistory.listLimit
            let oldest = next.chats.last?.updated ?? .distantPast
            let gone = Set(previous.filter { !now.contains($0.id) && (!full || $0.updated >= oldest) }.map(\.id))
            pages.removeAll { gone.contains($0.chat) }
            return gone
        }

        /// The chat should be read again from the iPhone: no page yet, or
        /// the list says it changed.
        public func needsPage(_ chat: String) -> Bool {
            guard let page = page(chat) else { return true }
            guard let summary = list?.summary(chat) else { return false }
            return page.isBehind(summary)
        }
    }

    /// Sorted keys, so the same list is the same bytes (WatchBridge sends
    /// the list again only when it changed).
    public static func encode<T: Encodable>(_ value: T) -> Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .sortedKeys
        return try? encoder.encode(value)
    }

    public static func decode<T: Decodable>(_ type: T.Type, from data: Data?) -> T? {
        guard let data else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    /// The text from its start, as much as fits in `bytes` of UTF-8,
    /// never cutting a character; and whether some was left out.
    public static func clip(_ text: String, bytes: Int) -> (text: String, clipped: Bool) {
        guard text.utf8.count > bytes else { return (text, false) }
        var used = 0
        var end = text.startIndex
        for character in text {
            let size = character.utf8.count
            guard used + size <= bytes else { break }
            used += size
            end = text.index(after: end)
        }
        return (String(text[..<end]), true)
    }
}
