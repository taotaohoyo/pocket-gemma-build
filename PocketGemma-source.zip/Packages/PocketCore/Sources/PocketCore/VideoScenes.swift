import Foundation

/// A video of 1.1.0 (192) and (193) reached Gemma 4 as three of its
/// scenes, near the start, the middle and the end, which its vision encoder
/// reads as it reads photos; its sound was not read. Such videos in older
/// chats still go this way. Since 1.1.0 (194) a video is analysed
/// (VideoAnalysis); its times are written as `label` gives them.
public enum VideoScenes {
    public static let count = 3
    /// Where the scenes are taken, in seconds: a little in from each end, so
    /// a fade in or out is not what the model sees. Empty for a video
    /// without a length.
    public static func times(duration: Double) -> [Double] {
        guard duration.isFinite, duration > 0 else { return [] }
        let inset = min(0.5, duration * 0.1)
        return [inset, duration / 2, max(inset, duration - inset)]
    }
    /// A place in the video as the model reads it: "0:07", "12:30", "1:02:05".
    public static func label(_ seconds: Double) -> String {
        let total = seconds.isFinite ? max(0, Int(seconds.rounded(.down))) : 0
        let hours = total / 3600, minutes = total % 3600 / 60, rest = total % 60
        return hours > 0 ? String(format: "%d:%02d:%02d", hours, minutes, rest) : String(format: "%d:%02d", minutes, rest)
    }
    /// What the model's turn says before an older video's scenes
    /// (GemmaService), in English as the files' material is since 1.1.0
    /// (187), so the reply keeps the question's language.
    public static func opening(name: String, duration: Double?) -> String {
        let length = duration.map { " (length \(label($0)))" } ?? ""
        return "\nThese are frames from the attached video \(name)\(length) near its start, middle and end, in time order. Its sound is not included."
    }
    /// Each scene's time, before its image; nil when the scenes were not
    /// taken at `times` (a video without a length).
    public static func sceneLabels(duration: Double?, scenes: Int) -> [String]? {
        let places = times(duration: duration ?? 0)
        guard scenes > 0, places.count == scenes else { return nil }
        return places.map { "\n[\(label($0))]" }
    }
}
