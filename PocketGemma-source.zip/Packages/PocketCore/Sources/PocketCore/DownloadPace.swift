import Foundation

/// How fast the downloads of a continued-processing task received, from
/// the bytes they reached (1.1.0 (295)). When iOS ends the task, the
/// download record says how fast the last half minute was against the
/// task's best half minute: iOS ends a task whose progress it finds slower
/// than expected (WWDC25 "Finish tasks in the background"), and the 293
/// record of 2026-11-17 19:50 showed the progress moving to the end while
/// the transfer had fallen from about 1 MB/s to 0.1 MB/s.
public struct DownloadPace: Sendable, Equatable {
    struct Sample: Sendable, Equatable {
        let time: TimeInterval
        let bytes: Int64
    }

    /// The span a rate is taken over.
    public static let window: TimeInterval = 30
    /// Samples older than this go.
    static let kept: TimeInterval = 120

    private(set) var samples: [Sample] = []
    /// The best rate over a whole `window` since the task started, in bytes
    /// a second.
    public private(set) var best: Double = 0

    public init() {}

    /// The bytes reached at `time` (seconds on any steady clock). Bytes
    /// that go back (a download left the batch, or started again) start the
    /// samples over; the best stays.
    public mutating func note(bytes: Int64, at time: TimeInterval) {
        if let last = samples.last, bytes < last.bytes || time < last.time { samples = [] }
        samples.append(Sample(time: time, bytes: bytes))
        samples.removeAll { time - $0.time > Self.kept }
        if let first = samples.first, time - first.time >= Self.window, let rate = rate(now: time) {
            best = max(best, rate)
        }
    }

    /// Bytes a second over the last `window` before `now`: from the newest
    /// sample at least that old (or the oldest there is) to the bytes
    /// reached by `now`. Nil with less than a second of samples.
    public func rate(now: TimeInterval) -> Double? {
        guard let last = samples.last,
              let start = samples.last(where: { now - $0.time >= Self.window }) ?? samples.first,
              now - start.time >= 1 else { return nil }
        return Double(last.bytes - start.bytes) / (now - start.time)
    }

    /// For the record: "0.1 MB/秒".
    public static func text(_ rate: Double?) -> String {
        guard let rate else { return "不明" }
        return String(format: "%.1f MB/秒", rate / 1_000_000)
    }
}
