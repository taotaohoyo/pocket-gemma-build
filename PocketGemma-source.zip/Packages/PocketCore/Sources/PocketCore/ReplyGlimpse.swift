import Foundation

/// The Aurora Orb's glimpse of the reply (生成プレビュー, 1.1.0 (297)). Once
/// the model's first words have come, the orb no longer gives way at once:
/// it goes on breathing for a moment while one short phrase of those words
/// shows faint under it, and then leaves as before, the phrase going with
/// it, and the reply's text begins in its place.
///
/// Only the reply's own text is read, as the person will read it a moment
/// later: the models' thoughts never reach a reply's text (the engines keep
/// them apart), and a thought block is left out here too; so are code,
/// formulas, tables, charts, pictures, markup and link addresses. Nothing is
/// asked of a model for it, and nothing is summarised: the phrase is the
/// reply's own words.
///
/// The glimpse lives in the pause the text keeps anyway. ReplyPacer shows a
/// reply about two seconds behind the model at most (drainLag); the orb now
/// leaves about 1.6 s after the first words rather than at once, so the
/// text starts about two seconds behind the model and keeps that distance:
/// a long reply ends when it did, a short one a few tenths of a second to
/// a second later. A reply that ends before a phrase could show, one that
/// begins with code or a table, and one with nothing to read yet are shown
/// as before. A plain class, used on the main actor by the message row.
public final class ReplyGlimpse {
    /// What the row is to do next: look again at `until` (or when the text
    /// changes), or let the orb leave now.
    public enum Decision: Equatable {
        case wait(until: TimeInterval?)
        case leave
    }

    /// The longest the glimpse waits after the first words for a whole
    /// clause; then the words so far show, with an ellipsis...
    public static let gather: TimeInterval = 0.4
    /// ...and with nothing to read by this long after the first text (a
    /// reply that opens with marks still to be written), the orb leaves.
    public static let patience: TimeInterval = 0.8
    /// How long a phrase shows before the orb leaves: its fade in, and a
    /// moment to read it...
    public static let hold: TimeInterval = 1.2
    /// ...but the orb leaves this long after the first text at the latest,
    /// so the reply's text begins about ReplyPacer.drainLag behind it...
    public static let latest: TimeInterval = 1.6
    /// ...and a phrase is never cut shorter than this, when the reply ends
    /// either (it has nearly come by then, so it never flashes), and no
    /// longer once the reply has ended, so a short reply is not kept back.
    public static let shortest: TimeInterval = 0.4

    /// The phrase showing, and when it began to.
    public private(set) var phrase: String?
    public private(set) var shownAt: TimeInterval?
    /// When the reply's first text came, and its first words.
    public private(set) var firstTextAt: TimeInterval?
    public private(set) var firstWordsAt: TimeInterval?
    /// The orb has been let go; nothing changes after that.
    public private(set) var done = false
    /// The preview's slow motion for filming (1 in the app): every time
    /// above is this many times as long.
    public let timeScale: Double

    public init(timeScale: Double = 1) {
        self.timeScale = timeScale
    }

    /// Looks at the reply's text so far (the row's, charts read) at `now`:
    /// picks the phrase once there is one, and says when the orb leaves.
    public func step(text: String, generating: Bool, now: TimeInterval) -> Decision {
        guard !done else { return .leave }
        guard !text.isEmpty else { return .wait(until: nil) }
        let first = firstTextAt ?? now
        firstTextAt = first
        if let shownAt {
            var leaveAt = leaving(shownAt: shownAt, first: first)
            // Ended: the phrase stays its shortest, no longer.
            if !generating { leaveAt = min(leaveAt, shownAt + Self.shortest * timeScale) }
            return now >= leaveAt ? finish() : .wait(until: leaveAt)
        }
        // A reply that has ended before a phrase showed is shown as before.
        guard generating else { return finish() }
        switch ReplyGlimpseText.opening(text) {
        case .other:
            return finish()
        case .undecided:
            let deadline = first + Self.patience * timeScale
            return now >= deadline ? finish() : .wait(until: deadline)
        case .prose:
            let words = firstWordsAt ?? now
            firstWordsAt = words
            let partial = now >= words + Self.gather * timeScale
            if let pick = ReplyGlimpseText.phrase(ReplyGlimpseText.clauses(ReplyGlimpseText.prose(text)), partial: partial) {
                phrase = pick
                shownAt = now
                return .wait(until: leaving(shownAt: now, first: first))
            }
            let deadline = first + Self.patience * timeScale
            if partial, now >= deadline { return finish() }
            return .wait(until: partial ? deadline : words + Self.gather * timeScale)
        }
    }

    /// When the orb leaves once a phrase shows: after the hold, by `latest`
    /// after the first text, and never before the phrase's shortest.
    private func leaving(shownAt: TimeInterval, first: TimeInterval) -> TimeInterval {
        max(min(shownAt + Self.hold * timeScale, first + Self.latest * timeScale), shownAt + Self.shortest * timeScale)
    }

    private func finish() -> Decision {
        done = true
        return .leave
    }
}

/// The words a glimpse may show, from a reply's text: its prose without
/// Markdown's marks, cut into clauses.
public enum ReplyGlimpseText {
    /// Only the reply's beginning is read: the glimpse is over within two
    /// seconds of it.
    static let readLimit = 600
    /// A clause shows with at least this many letters or digits; a shorter
    /// one (はい、) joins the next on its line.
    public static let shortestClause = 6
    /// The longest phrase kept: one line of the glimpse holds less.
    public static let longestPhrase = 40

    public enum Opening: Equatable {
        /// Only marks or spaces so far.
        case undecided
        /// Words to read.
        case prose
        /// Code, a formula, a table, a chart, a picture or markup, which the
        /// glimpse leaves to the reply.
        case other
    }

    public struct Clause: Equatable {
        public let text: String
        /// Ended by its punctuation or its line.
        public let complete: Bool
        public init(text: String, complete: Bool) {
            self.text = text
            self.complete = complete
        }
    }

    /// How the reply begins.
    public static func opening(_ text: String) -> Opening {
        let start = withoutThoughts(String(text.prefix(readLimit))).drop { $0.isWhitespace }
        guard !start.isEmpty else { return .undecided }
        for mark in ["```", "~~~", "$$", "\\[", "\\begin", "|", "![", "<"] where start.hasPrefix(mark) {
            return .other
        }
        return prose(String(start)).contains { $0.isLetter || $0.isNumber } ? .prose : .undecided
    }

    /// The reply's words so far, a line for each of its lines: headings,
    /// quotes, list items and paragraphs without their marks, links as
    /// their words; code blocks, formulas, tables, rules, pictures, tags,
    /// addresses and thought blocks left out (as empty lines).
    public static func prose(_ text: String) -> String {
        let source = withoutThoughts(String(text.prefix(readLimit)))
        var lines: [String] = []
        var fence: String?
        var mathEnd: String?
        for raw in source.split(separator: "\n", omittingEmptySubsequences: false) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if let open = fence {
                if line.hasPrefix(open) { fence = nil }
                lines.append("")
                continue
            }
            if let end = mathEnd {
                let closes = end == "\\end{" ? line.contains(end) : line.hasSuffix(end)
                if closes { mathEnd = nil }
                lines.append("")
                continue
            }
            if line.hasPrefix("```") || line.hasPrefix("~~~") {
                fence = String(line.prefix(3))
            } else if line.hasPrefix("$$") {
                if !(line.count >= 4 && line.hasSuffix("$$")) { mathEnd = "$$" }
            } else if line.hasPrefix("\\[") {
                if !line.hasSuffix("\\]") { mathEnd = "\\]" }
            } else if line.hasPrefix("\\begin{") {
                if !line.contains("\\end{") { mathEnd = "\\end{" }
            } else if !line.hasPrefix("|"), !isRule(line) {
                lines.append(plainLine(line))
                continue
            }
            lines.append("")
        }
        return lines.joined(separator: "\n")
    }

    /// The prose cut after each 。！？!?、，,；;： (and a full stop before a
    /// space), with the closing quote or bracket that follows; a clause too
    /// short to show joins the next on its line. A line's last clause is
    /// complete once the line has ended.
    public static func clauses(_ prose: String) -> [Clause] {
        var result: [Clause] = []
        let lines = prose.split(separator: "\n", omittingEmptySubsequences: false)
        for (number, line) in lines.enumerated() {
            let ended = number < lines.count - 1
            let characters = Array(line)
            var piece = ""
            var index = 0
            while index < characters.count {
                let character = characters[index]
                piece.append(character)
                index += 1
                let fullStop = character == "." && (index == characters.count ? ended : characters[index] == " ")
                guard stops.contains(character) || pauses.contains(character) || fullStop else { continue }
                while index < characters.count, closers.contains(characters[index]) {
                    piece.append(characters[index])
                    index += 1
                }
                // Short: carried on to the next clause of the line.
                if letters(piece) < shortestClause, index < characters.count { continue }
                append(piece, complete: true, to: &result)
                piece = ""
            }
            append(piece, complete: ended, to: &result)
        }
        return result
    }

    /// The phrase to show: the newest whole clause with words enough, or
    /// with `partial` the newest words so far, up to where a word surely
    /// ended, and an ellipsis after them.
    public static func phrase(_ clauses: [Clause], partial: Bool) -> String? {
        if let whole = clauses.last(where: { $0.complete && letters($0.text) >= shortestClause }) {
            return shortened(whole.text)
        }
        guard partial, let last = clauses.last, let words = wordsSoFar(last.text) else { return nil }
        let text = shortened(words)
        return text.hasSuffix("…") ? text : text + "…"
    }

    /// A clause still being written, up to where a word surely ended. In
    /// Japanese, which has no spaces: where a run of hiragana (a particle
    /// or an ending) gives way to a kanji or katakana word (仕組みを|使っ),
    /// or at its end after a particle (量子コンピュータは); never inside a
    /// word still coming (量子コンピュ, ゆっく wait). Elsewhere before its
    /// last space. Nil with fewer than four letters by then.
    static func wordsSoFar(_ text: String) -> String? {
        let characters = Array(text)
        var cut: Int?
        if characters.contains(where: isJapanese) {
            for index in characters.indices.dropFirst()
            where isHiragana(characters[index - 1]) && !isHiragana(characters[index]) && characters[index] != "ー" {
                cut = index
            }
            if let last = characters.last, particles.contains(last) { cut = characters.count }
        } else {
            cut = characters.lastIndex(where: { $0 == " " })
        }
        guard let cut else { return nil }
        let words = String(characters[..<cut]).trimmingCharacters(in: .whitespaces)
        return letters(words) >= 4 ? words : nil
    }

    /// Particles a clause in writing may end on for now.
    private static let particles: Set<Character> = ["は", "が", "を", "に", "で", "と", "も", "へ", "の", "や"]

    private static func isHiragana(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        return (0x3041...0x309F).contains(scalar.value)
    }

    private static func isJapanese(_ character: Character) -> Bool {
        guard let scalar = character.unicodeScalars.first else { return false }
        return (0x3040...0x30FF).contains(scalar.value) || (0x4E00...0x9FFF).contains(scalar.value)
    }

    // MARK: Pieces

    private static let stops: Set<Character> = ["。", "！", "？", "!", "?", "．"]
    private static let pauses: Set<Character> = ["、", "，", ",", "；", ";", "："]
    private static let closers: Set<Character> = ["」", "』", "）", ")", "”", "’", "\"", "】", "〉", "》"]

    static func letters(_ text: String) -> Int {
        text.reduce(0) { $0 + ($1.isLetter || $1.isNumber ? 1 : 0) }
    }

    private static func append(_ piece: String, complete: Bool, to clauses: inout [Clause]) {
        let text = piece.trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return }
        clauses.append(Clause(text: text, complete: complete))
    }

    private static func shortened(_ text: String) -> String {
        text.count > longestPhrase ? String(text.prefix(longestPhrase)) + "…" : text
    }

    /// A thinking model's thought, should one ever reach a reply's text:
    /// <think>…</think> and the like left out, an unclosed one to the end,
    /// and all before a closing tag that has no opening one.
    static func withoutThoughts(_ text: String) -> String {
        guard text.contains("<") else { return text }
        var result = text
        for tag in ["think", "thinking", "thought", "reasoning"] {
            let open = "<\(tag)>", close = "</\(tag)>"
            while let start = result.range(of: open, options: .caseInsensitive) {
                if let end = result.range(of: close, options: .caseInsensitive, range: start.upperBound..<result.endIndex) {
                    result.removeSubrange(start.lowerBound..<end.upperBound)
                } else {
                    result.removeSubrange(start.lowerBound..<result.endIndex)
                }
            }
            if let end = result.range(of: close, options: .caseInsensitive) {
                result.removeSubrange(result.startIndex..<end.upperBound)
            }
        }
        return result
    }

    /// --- *** ___ and the like.
    private static func isRule(_ line: String) -> Bool {
        let marks = line.filter { $0 != " " }
        guard marks.count >= 3, let first = marks.first, "-*_".contains(first) else { return false }
        return marks.allSatisfy { $0 == first }
    }

    /// A line without its block marks (quotes, headings, list items, task
    /// boxes, in any nesting) and its inline ones.
    static func plainLine(_ line: String) -> String {
        var content = Substring(line)
        while let rest = afterBlockMark(content) { content = rest }
        return inline(String(content))
    }

    private static func afterBlockMark(_ line: Substring) -> Substring? {
        let trimmed = line.drop { $0 == " " || $0 == "\t" }
        if trimmed.hasPrefix(">") { return trimmed.dropFirst() }
        if trimmed.first == "#" {
            let hashes = trimmed.prefix { $0 == "#" }.count
            let rest = trimmed.dropFirst(hashes)
            return hashes <= 6 && (rest.isEmpty || rest.first == " ") ? rest : nil
        }
        for mark in ["- ", "* ", "+ ", "[ ] ", "[x] ", "[X] "] where trimmed.hasPrefix(mark) {
            return trimmed.dropFirst(mark.count)
        }
        let digits = trimmed.prefix { $0.isASCII && $0.isNumber }
        if !digits.isEmpty, digits.count <= 3 {
            let rest = trimmed.dropFirst(digits.count)
            if rest.hasPrefix(". ") || rest.hasPrefix(") ") { return rest.dropFirst(2) }
        }
        return nil
    }

    /// A line's words without emphasis, code and strikethrough marks, links
    /// as their words, and without formulas (MarkdownSource's reading of
    /// them, and one still being written), pictures, footnote marks, tags
    /// and web addresses; spaces run together.
    static func inline(_ line: String) -> String {
        var math: [MarkdownMath] = []
        let characters = Array(MarkdownSource.extractInlineMath(line, into: &math))
        var output = ""
        var index = 0
        while index < characters.count {
            let character = characters[index]
            switch character {
            case MarkdownSource.mathOpen:
                // A formula: left out.
                index = (characters[index...].firstIndex(of: MarkdownSource.mathClose) ?? characters.count - 1) + 1
            case "\\":
                guard index + 1 < characters.count else { index += 1; continue }
                let next = characters[index + 1]
                if next.isLetter && next.isASCII {
                    // A command, a formula's: left out with its name.
                    index += 2
                    while index < characters.count, characters[index].isLetter, characters[index].isASCII { index += 1 }
                } else if next == "(" || next == "[" {
                    // A formula still being written: the rest of the line.
                    index = characters.count
                } else {
                    // An escaped mark is the mark itself.
                    output.append(next)
                    index += 2
                }
            case "$":
                // A formula still being written (`$x^2` with no closing
                // dollar yet): the rest of the line; a price stays.
                if index + 1 < characters.count, !characters[index + 1].isWhitespace,
                   MarkdownSource.looksLikeLaTeX(characters[(index + 1)...]) {
                    index = characters.count
                } else {
                    output.append(character)
                    index += 1
                }
            case "!" where index + 1 < characters.count && characters[index + 1] == "[":
                // A picture: left out.
                index = linkEnd(characters, from: index + 1)?.end ?? characters.count
            case "[":
                if index + 1 < characters.count, characters[index + 1] == "^" {
                    // A footnote mark.
                    index = (characters[index...].firstIndex(of: "]") ?? characters.count - 1) + 1
                } else if let link = linkEnd(characters, from: index) {
                    output += inline(String(characters[(index + 1)..<link.textEnd]))
                    index = link.end
                } else {
                    output.append(character)
                    index += 1
                }
            case "<":
                // A tag or an address in brackets, or one being written.
                index = (characters[index...].firstIndex(of: ">") ?? characters.count - 1) + 1
            case "*", "~", "`":
                index += 1
            case "_":
                // Between letters or digits (snake_case) it is a character.
                let before = index > 0 ? characters[index - 1] : " "
                let after = index + 1 < characters.count ? characters[index + 1] : " "
                if before.isASCII, before.isLetter || before.isNumber, after.isASCII, after.isLetter || after.isNumber {
                    output.append(character)
                }
                index += 1
            case "h" where starts("https://", characters, at: index) || starts("http://", characters, at: index):
                while index < characters.count, !characters[index].isWhitespace { index += 1 }
            default:
                output.append(character)
                index += 1
            }
        }
        return output.split(whereSeparator: { $0 == " " || $0 == "\t" }).joined(separator: " ")
    }

    /// `[words](address)` or `[words][name]` from the bracket at `start`:
    /// where its words end and where the link ends. Nil for a bracket that
    /// is not one (yet).
    private static func linkEnd(_ characters: [Character], from start: Int) -> (textEnd: Int, end: Int)? {
        guard start < characters.count, characters[start] == "[" else { return nil }
        var depth = 0
        var close: Int?
        for index in start..<characters.count {
            if characters[index] == "[" { depth += 1 }
            if characters[index] == "]" {
                depth -= 1
                if depth == 0 { close = index; break }
            }
        }
        guard let close, close + 1 < characters.count else { return nil }
        let opener = characters[close + 1]
        guard opener == "(" || opener == "[" else { return nil }
        let closer: Character = opener == "(" ? ")" : "]"
        // An address still being written: the link ends with the line.
        let end = characters[(close + 2)...].firstIndex(of: closer).map { $0 + 1 } ?? characters.count
        return (close, end)
    }

    private static func starts(_ prefix: String, _ characters: [Character], at index: Int) -> Bool {
        let marks = Array(prefix)
        guard index + marks.count <= characters.count else { return false }
        return Array(characters[index..<(index + marks.count)]) == marks
    }
}

/// How a glimpse comes and goes: rising a few points out of a soft blur as
/// it fades in, and fading on up into the blur as the orb leaves, with the
/// orb's own clock. With Reduce Motion it only fades. One phrase shows at a
/// time and never changes while it shows; its look depends on time alone,
/// so the preview's slow motion can film it frame by frame.
public enum ReplyGlimpseMotion {
    /// The fade in, and out as the orb leaves (it shrinks over 0.7 s, so the
    /// phrase has gone before the reply's text begins).
    public static let appear: TimeInterval = 0.6
    public static let disappear: TimeInterval = 0.45
    /// With Reduce Motion: fades alone, as quick as the orb's.
    public static let appearReduced: TimeInterval = 0.25
    public static let disappearReduced: TimeInterval = 0.18
    /// Points it rises as it comes, and on as it goes.
    public static let rise = 3.0
    public static let drift = 2.0
    /// Its blur at rest (just enough to read as not yet written), and as it
    /// comes and goes.
    public static let restingBlur = 0.35
    public static let softBlur = 2.2

    public struct Look: Equatable {
        public var opacity: Double
        public var blur: Double
        /// Down from its place, in points (negative: above it).
        public var offset: Double
    }

    /// The look `sinceShown` seconds after the phrase began to show, and
    /// `sinceLeaving` after the orb began to leave.
    public static func look(sinceShown: TimeInterval, sinceLeaving: TimeInterval?, reduced: Bool, timeScale: Double = 1) -> Look {
        let comes = clamp(sinceShown / ((reduced ? appearReduced : appear) * timeScale))
        let came = 1 - pow(1 - comes, 3)
        var look = Look(opacity: came,
                        blur: reduced ? restingBlur : restingBlur * came + softBlur * (1 - came),
                        offset: reduced ? 0 : rise * (1 - came))
        if let sinceLeaving {
            let goes = clamp(sinceLeaving / ((reduced ? disappearReduced : disappear) * timeScale))
            let gone = goes * goes * (3 - 2 * goes)
            look.opacity *= 1 - gone
            if !reduced {
                look.blur += (softBlur - restingBlur) * gone
                look.offset -= drift * gone
            }
        }
        return look
    }

    /// Whether the look still changes at that moment (it rests once it has
    /// come, until the orb leaves, and once it has gone).
    public static func moving(sinceShown: TimeInterval, sinceLeaving: TimeInterval?, reduced: Bool, timeScale: Double = 1) -> Bool {
        if let sinceLeaving { return sinceLeaving < (reduced ? disappearReduced : disappear) * timeScale }
        return sinceShown < (reduced ? appearReduced : appear) * timeScale
    }

    private static func clamp(_ value: Double) -> Double { min(max(value, 0), 1) }
}
