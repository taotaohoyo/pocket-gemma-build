import Foundation

/// LaTeX from a model made readable for SwiftMath, which lacks some of what
/// models write (`align`, `\dfrac`, `\operatorname`, primes, full-width
/// characters) and drops a bare `$`, `%`, `#` or `~` without a word.
/// Copying always gives the LaTeX as written; this only shapes what is drawn.
public enum MathSyntax {
    /// Full-width characters to ASCII, environments and commands SwiftMath
    /// lacks to ones it has, `'` to `\prime`, then the escapes of `prepared`.
    public static func normalized(_ latex: String) -> String {
        prepared(rewritten(asciiWidth(latex)))
    }

    /// Escapes a bare `$`, `%` or `#` and turns `~` into a space, so `50%`
    /// draws as "50%" and not "50"; what is already escaped stays as it is.
    public static func prepared(_ latex: String) -> String {
        guard latex.contains(where: { "$%#~".contains($0) }) else { return latex }
        var result = ""
        result.reserveCapacity(latex.count + 8)
        var escaped = false
        for character in latex {
            if escaped {
                result.append(character)
                escaped = false
                continue
            }
            switch character {
            case "\\":
                result.append(character)
                escaped = true
            case "$", "%", "#":
                result.append("\\")
                result.append(character)
            case "~":
                // A tie is a space that does not break; SwiftMath has `\ `.
                result += "\\ "
            default:
                result.append(character)
            }
        }
        return result
    }

    // MARK: - Width

    /// Full-width ASCII (`ｘ＝１`), the ideographic space, the minus sign and
    /// a typographic apostrophe or prime become their ASCII forms.
    static func asciiWidth(_ latex: String) -> String {
        guard latex.unicodeScalars.contains(where: { asciiForm($0) != nil }) else { return latex }
        var scalars = String.UnicodeScalarView()
        for scalar in latex.unicodeScalars {
            scalars.append(asciiForm(scalar) ?? scalar)
        }
        return String(scalars)
    }

    private static func asciiForm(_ scalar: Unicode.Scalar) -> Unicode.Scalar? {
        switch scalar.value {
        // The full-width ampersand would split a table and the full-width
        // tilde is a Japanese range mark (1～10); both stay text.
        case 0xFF01...0xFF05, 0xFF07...0xFF5D: return Unicode.Scalar(scalar.value - 0xFEE0)
        case 0x3000: return " "
        case 0x2212: return "-"
        case 0x2019, 0x2032: return "'"
        default: return nil
        }
    }

    // MARK: - Commands and environments

    /// Commands SwiftMath draws under another name.
    static let renamed: [String: String] = [
        "dfrac": "frac", "tfrac": "frac", "cfrac": "frac",
        "operatorname": "mathrm", "operatorname*": "mathrm",
        "boldsymbol": "bm", "pmb": "bm", "mathbold": "bm",
        "mathscr": "mathcal", "textsf": "mathsf", "texttt": "mathtt",
        "mbox": "text", "textnormal": "text", "textup": "text", "hbox": "text",
        "emph": "mathit",
        "dots": "ldots", "dotsc": "ldots", "dotso": "ldots",
        "dotsb": "cdots", "dotsm": "cdots", "dotsi": "cdots",
        "implies": "Rightarrow", "impliedby": "Leftarrow", "gets": "leftarrow",
        "varnothing": "emptyset",
        "lVert": "Vert", "rVert": "Vert", "lvert": "vert", "rvert": "vert",
        "textdegree": "degree",
        // Drawn close to the original: an arrow accent for a long arrow, a
        // line for a brace or a box.
        "overrightarrow": "vec", "underbrace": "underline", "overbrace": "overline",
        "boxed": "underline", "fbox": "underline",
        "enspace": " ", "thinspace": ",", "medspace": ">", ":": ">", "thickspace": ";", "negthinspace": "!",
        "newline": "\\",
    ]

    /// Commands drawn as text SwiftMath has no command for.
    static let replaced: [String: String] = [
        "therefore": "∴", "because": "∵", "nexists": "∄", "nmid": "∤",
        "bmod": "\\ \\mathrm{mod}\\ ", "mod": "\\ \\mathrm{mod}\\ ",
    ]

    /// Commands left out, with how many brace arguments go with them. Sizes
    /// (`\bigl`) and `\middle` leave their delimiter; colors leave their
    /// text, which a template image could not color anyway.
    static let dropped: [String: Int] = [
        "middle": 0, "nonumber": 0, "notag": 0, "hline": 0, "vline": 0,
        "displaybreak": 0, "allowdisplaybreaks": 0, "strut": 0, "mathstrut": 0,
        "bigl": 0, "bigr": 0, "big": 0, "bigm": 0, "Bigl": 0, "Bigr": 0, "Big": 0, "Bigm": 0,
        "biggl": 0, "biggr": 0, "bigg": 0, "biggm": 0, "Biggl": 0, "Biggr": 0, "Bigg": 0, "Biggm": 0,
        "mathbin": 0, "mathrel": 0, "mathord": 0, "mathop": 0, "mathpunct": 0, "mathinner": 0,
        "mathclap": 0, "mathrlap": 0, "mathllap": 0, "smash": 0, "mathnormal": 0, "ensuremath": 0,
        "label": 1, "hspace": 1, "hspace*": 1, "vspace": 1, "vspace*": 1,
        "phantom": 1, "hphantom": 1, "vphantom": 1, "cline": 1, "color": 1,
        "textcolor": 1, "colorbox": 1, "fcolorbox": 2,
    ]

    /// Commands whose brace argument is kept between other text. An
    /// equation's tag is drawn after it, so "式(1)" in the prose finds it.
    static let wrapped: [String: (open: String, close: String)] = [
        "substack": ("\\begin{matrix}", "\\end{matrix}"),
        "pmod": ("\\ (\\mathrm{mod}\\ ", ")"),
        "tag": ("\\qquad (", ")"),
        "tag*": ("\\qquad ", ""),
    ]

    /// Environments under another name; an empty name drops the wrapper.
    static let environments: [String: String] = [
        "align": "aligned", "align*": "aligned", "alignat": "aligned", "alignat*": "aligned",
        "alignedat": "aligned", "flalign": "aligned", "flalign*": "aligned",
        "eqnarray*": "eqnarray", "gather*": "gather", "gathered": "gather",
        "multline": "gather", "multline*": "gather",
        "array": "matrix", "tabular": "matrix", "smallmatrix": "matrix", "subarray": "matrix",
        "cases*": "cases", "dcases": "cases", "dcases*": "cases", "rcases": "cases",
        "equation": "", "equation*": "", "math": "", "displaymath": "",
    ]

    /// Environments whose `\begin` takes an argument SwiftMath does not.
    static let environmentArguments: Set<String> = ["alignat", "alignat*", "alignedat", "array", "tabular"]

    /// How SwiftMath's two-column environments end, inside which a relation
    /// after `&` is given its left space.
    static let alignedCloses: Set<String> = ["\\end{aligned}", "\\end{split}", "\\end{eqalign}"]

    /// Relations a model writes at the start of an aligned column.
    static let relations: Set<String> = [
        "le", "leq", "ge", "geq", "ne", "neq", "approx", "equiv", "sim", "simeq", "cong",
        "propto", "to", "rightarrow", "Rightarrow", "Leftrightarrow", "iff", "implies",
        "in", "subset", "subseteq", "supset", "supseteq", "mapsto", "ll", "gg", "leqslant", "geqslant",
    ]

    /// Commands whose brace argument is text, where `'` stays an apostrophe.
    static let textCommands: Set<String> = [
        "text", "textrm", "textbf", "textit", "textsf", "texttt", "mbox", "mathrm",
        "operatorname", "operatorname*", "hbox", "textnormal", "textup",
    ]

    /// The rewriting of commands, environments and primes.
    static func rewritten(_ latex: String) -> String {
        guard latex.contains("\\") || latex.contains("'") else { return latex }
        let characters = Array(latex)
        var output = ""
        output.reserveCapacity(characters.count + 16)
        var index = 0
        var depth = 0
        /// The brace depth of the innermost open text group.
        var textDepth: Int?
        /// The next `{` opens a text group.
        var textOpens = false
        /// What closes each open environment, under the name it was given.
        var environmentStack: [String] = []
        while index < characters.count {
            let character = characters[index]
            if character == "\\", index + 1 < characters.count {
                let (name, next) = command(characters, from: index + 1)
                index = next
                textOpens = false
                switch name {
                case "begin", "end":
                    guard let (environment, after) = braced(characters, from: index) else {
                        output += "\\" + name
                        continue
                    }
                    index = after
                    let trimmed = environment.trimmingCharacters(in: .whitespaces)
                    if name == "end" {
                        let fallback = environments[trimmed] ?? trimmed
                        output += environmentStack.popLast() ?? (fallback.isEmpty ? "" : "\\end{\(fallback)}")
                        continue
                    }
                    var drawn = environments[trimmed] ?? trimmed
                    var specification = ""
                    if environmentArguments.contains(trimmed), let (argument, afterArgument) = braced(characters, from: index) {
                        index = afterArgument
                        specification = argument
                    }
                    if drawn == "matrix", specification.contains("|") {
                        // An augmented matrix's divider is notation, so the
                        // array stays as written and shows as its source.
                        environmentStack.append("\\end{\(trimmed)}")
                        output += "\\begin{\(trimmed)}{\(specification)}"
                        continue
                    }
                    var close = drawn.isEmpty ? "" : "\\end{\(drawn)}"
                    if drawn == "aligned" || drawn == "cases",
                       !environmentBody(characters, from: index, of: trimmed).contains("&") {
                        if drawn == "aligned" {
                            // One column: SwiftMath's aligned needs two; gather centers the lines.
                            drawn = "gather"
                            close = "\\end{gather}"
                        } else {
                            // Simultaneous equations without conditions: SwiftMath's
                            // cases needs two columns, so the last line gets an empty one.
                            close = "&" + close
                        }
                    }
                    environmentStack.append(close)
                    if !drawn.isEmpty { output += "\\begin{\(drawn)}" }
                case "\\":
                    // `\\*` and `\\[4pt]` are a plain line break.
                    output += "\\\\"
                    if index < characters.count, characters[index] == "*" { index += 1 }
                    if index < characters.count, characters[index] == "[",
                       let close = characters[index...].firstIndex(of: "]"),
                       isLength(characters[(index + 1)..<close]) {
                        index = close + 1
                    }
                case "not":
                    if index + 2 < characters.count, characters[index] == "\\",
                       characters[index + 1] == "i", characters[index + 2] == "n",
                       index + 3 == characters.count || !characters[index + 3].isLetter {
                        output += "\\notin"
                        index += 3
                    } else if index < characters.count, characters[index] == "=" {
                        output += "\\neq"
                        index += 1
                    } else {
                        output += "\\not"
                    }
                default:
                    if let count = dropped[name] {
                        for _ in 0..<count {
                            if let (_, after) = braced(characters, from: index) { index = after }
                        }
                    } else if let text = replaced[name] {
                        output += text
                    } else if let (open, close) = wrapped[name], let (content, after) = braced(characters, from: index) {
                        output += open + rewritten(content) + close
                        index = after
                    } else {
                        let drawn = renamed[name] ?? name
                        output += "\\" + drawn
                        if textCommands.contains(name) { textOpens = true }
                        // A letter right after a renamed command would join it.
                        if drawn != name, drawn.last?.isLetter == true,
                           index < characters.count, characters[index].isLetter {
                            output += " "
                        }
                    }
                }
                continue
            }
            if character == "{" {
                depth += 1
                if textOpens, textDepth == nil { textDepth = depth }
                textOpens = false
                output.append(character)
                index += 1
                continue
            }
            if character == "}" {
                if textDepth == depth { textDepth = nil }
                depth = max(0, depth - 1)
                output.append(character)
                index += 1
                continue
            }
            if character == "&", let close = environmentStack.last, alignedCloses.contains(close),
               startsWithRelation(characters, from: index + 1) {
                // In SwiftMath's aligned the relation that starts the second
                // column came out without the space on its left (`a= b`), so
                // a thick space is written in.
                output += "&\\;"
                textOpens = false
                index += 1
                continue
            }
            if character == "'", textDepth == nil {
                var count = 0
                while index + count < characters.count, characters[index + count] == "'" { count += 1 }
                let primes = String(repeating: "\\prime", count: count)
                output += output.last == "^" ? "{\(primes)}" : "^{\(primes)}"
                index += count
                continue
            }
            if !character.isWhitespace { textOpens = false }
            output.append(character)
            index += 1
        }
        return output
    }

    /// The command name after a backslash: letters with a trailing `*`, or
    /// one other character.
    private static func command(_ characters: [Character], from start: Int) -> (name: String, next: Int) {
        var index = start
        var name = ""
        if characters[index].isLetter, characters[index].isASCII {
            while index < characters.count, characters[index].isLetter, characters[index].isASCII {
                name.append(characters[index])
                index += 1
            }
            if index < characters.count, characters[index] == "*" {
                name.append("*")
                index += 1
            }
        } else {
            name = String(characters[index])
            index += 1
        }
        return (name, index)
    }

    /// Whether a relation (`=`, `<`, `\le`, …) comes next, after spaces.
    private static func startsWithRelation(_ characters: [Character], from start: Int) -> Bool {
        var index = start
        while index < characters.count, characters[index].isWhitespace { index += 1 }
        guard index < characters.count else { return false }
        if "=<>".contains(characters[index]) { return true }
        guard characters[index] == "\\", index + 1 < characters.count else { return false }
        return relations.contains(command(characters, from: index + 1).name)
    }

    /// The text from `start` up to the environment's `\end`.
    private static func environmentBody(_ characters: [Character], from start: Int, of environment: String) -> String {
        let text = String(characters[start...])
        guard let end = text.range(of: "\\end{\(environment)}") else { return text }
        return String(text[..<end.lowerBound])
    }

    /// A brace argument after optional spaces: its text and the index past it.
    private static func braced(_ characters: [Character], from start: Int) -> (content: String, next: Int)? {
        var index = start
        while index < characters.count, characters[index] == " " { index += 1 }
        guard index < characters.count, characters[index] == "{" else { return nil }
        var depth = 0
        var position = index
        while position < characters.count {
            let character = characters[position]
            if character == "\\" { position += 2; continue }
            if character == "{" { depth += 1 }
            if character == "}" {
                depth -= 1
                if depth == 0 {
                    return (String(characters[(index + 1)..<position]), position + 1)
                }
            }
            position += 1
        }
        return nil
    }

    /// `4pt`, `-1.5ex`, `2 em`: a TeX length.
    private static func isLength(_ content: ArraySlice<Character>) -> Bool {
        let text = String(content).replacingOccurrences(of: " ", with: "")
        let units = ["pt", "em", "ex", "mm", "cm", "in", "px", "mu", "bp", "pc", "dd", "cc", "sp"]
        guard let unit = units.first(where: { text.hasSuffix($0) }) else { return false }
        let number = text.dropLast(unit.count)
        let digits = number.hasPrefix("-") ? number.dropFirst() : number[...]
        return digits.contains(where: \.isNumber) && digits.allSatisfy { $0.isNumber || $0 == "." }
    }

    // MARK: - Text runs

    /// The prefix of the placeholder commands that stand for runs of text.
    public static let placeholderPrefix = "PocketText"

    /// SwiftMath drops every character it gives no math meaning, which is all
    /// Japanese. Runs of such text become placeholder commands (`\PocketTextA`)
    /// that the app registers as atoms and restores to the text afterwards.
    /// `isKnown` says whether SwiftMath has a meaning for a character;
    /// `symbolName` gives the command for a symbol it knows by name (×, ≤, α),
    /// which keeps its math spacing.
    public static func placeholders(_ latex: String, isKnown: (Character) -> Bool,
                                    symbolName: (Character) -> String?) -> (source: String, texts: [String]) {
        var source = ""
        var texts: [String] = []
        var run = ""
        func endRun() {
            guard !run.isEmpty else { return }
            source += "{\\\(placeholderName(texts.count))}"
            texts.append(run)
            run = ""
        }
        for character in latex {
            if character.isASCII || (run.isEmpty && character.isWhitespace) || isKnown(character) {
                endRun()
                source.append(character)
            } else if let symbol = symbolName(character), !symbol.hasPrefix(placeholderPrefix),
                      symbol.allSatisfy({ $0.isASCII && $0.isLetter }) {
                endRun()
                source += "{\\\(symbol)}"
            } else {
                run.append(character)
            }
        }
        endRun()
        return (source, texts)
    }

    /// Placeholder command names are letters only: 0 → A, 25 → Z, 26 → BA.
    public static func placeholderName(_ index: Int) -> String {
        var letters = ""
        var rest = index
        repeat {
            letters.insert(Character(UnicodeScalar(UInt8(65 + rest % 26))), at: letters.startIndex)
            rest /= 26
        } while rest > 0
        return placeholderPrefix + letters
    }
}
