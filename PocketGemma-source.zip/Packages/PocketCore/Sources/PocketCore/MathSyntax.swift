import Foundation

/// LaTeX made safe for SwiftMath, which drops a bare `$`, `%`, `#` or `~`
/// without a word (so `50%` drew as "50"). Each becomes the command that
/// draws it; what is already escaped stays as it is.
public enum MathSyntax {
    public static func prepared(_ latex: String) -> String {
        guard latex.contains(where: { "$%#~".contains($0) }) else { return latex }
        var result = ""
        result.reserveCapacity(latex.count + 8)
        var escaped = false
        for character in latex {
            if escaped {
                result.append(character)
                escaped = false
                continue
            }
            switch character {
            case "\\":
                result.append(character)
                escaped = true
            case "$", "%", "#":
                result.append("\\")
                result.append(character)
            case "~":
                // A tie is a space that does not break; SwiftMath has `\ `.
                result += "\\ "
            default:
                result.append(character)
            }
        }
        return result
    }
}
