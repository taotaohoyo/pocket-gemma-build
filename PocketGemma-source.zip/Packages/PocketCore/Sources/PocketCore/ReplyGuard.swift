import Foundation

/// Stops a reply that heats the phone or runs far too long, for the models
/// that can (`ModelCapabilities.guardsReplies`): Phi-4-mini-reasoning and
/// Qwen3.5 4B. On 1.1.0 (205) both showed only 「考えています…」 on the
/// phone while it grew hot (user, 02:27 UTC 2026-10-27). The other models
/// have no such limits; every model keeps the 120-second silence watchdog
/// (ChatStore).
public struct ReplyGuard: Sendable, Equatable {
    public enum Stop: String, Sendable, Equatable {
        /// iOS reports the phone as hot (`ProcessInfo.ThermalState.serious`
        /// or `.critical`), when it slows the processors down anyway.
        case heat
        /// No word of the answer this long after the model began on the
        /// question (thinking included).
        case noAnswer
        /// The reply as a whole has run this long.
        case tooLong
    }

    /// Seconds from the start of generation, after loading, to the first
    /// word of the answer. Phi's whole thinking budget (1,536 tokens) took
    /// up to 2.5 minutes on a 4-core Arm CPU (run 40439991123).
    public let firstAnswerSeconds: TimeInterval
    /// Seconds from the start of generation to the end of the reply.
    public let totalSeconds: TimeInterval

    public static let standard = ReplyGuard(firstAnswerSeconds: 300, totalSeconds: 600)

    public static func of(_ model: ModelSpec) -> ReplyGuard? {
        model.capabilities.guardsReplies ? standard : nil
    }

    /// Why the reply stops now, or nil. `generating` is nil while the model
    /// is still loading, which neither time limit counts; heat stops it
    /// then too.
    public func stop(thermal: ProcessInfo.ThermalState, generating seconds: TimeInterval?, answered: Bool) -> Stop? {
        if thermal == .serious || thermal == .critical { return .heat }
        guard let seconds else { return nil }
        if !answered && seconds >= firstAnswerSeconds { return .noAnswer }
        if seconds >= totalSeconds { return .tooLong }
        return nil
    }
}
