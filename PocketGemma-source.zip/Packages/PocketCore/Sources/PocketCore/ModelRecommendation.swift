import Foundation

public struct DeviceCapacity: Equatable, Sendable {
    public let memoryBytes: UInt64
    public let freeDiskBytes: Int64
    public let processorCount: Int
    public let isPad: Bool
    public let availableMemoryBytes: UInt64?
    public init(memoryBytes: UInt64, freeDiskBytes: Int64, processorCount: Int, isPad: Bool, availableMemoryBytes: UInt64? = nil) {
        self.memoryBytes = memoryBytes; self.freeDiskBytes = max(0, freeDiskBytes)
        self.processorCount = max(1, processorCount); self.isPad = isPad
        self.availableMemoryBytes = availableMemoryBytes
    }
    public var workingMemoryEstimate: Double {
        let estimate = Double(memoryBytes) * (isPad ? 0.60 : 0.55)
        return availableMemoryBytes.map { min(estimate, Double($0) * 0.90) } ?? estimate
    }
}

/// How a model fits a device, for モデル管理's cards and the automatic
/// choice: estimates for the bundled quantized exports, not an iOS memory
/// entitlement; runtime limits may be lower. The speed is what someone
/// measured on an iPhone (SpeedEvidence), nil where no one has.
public struct ModelFit: Equatable, Sendable {
    public let speed: SpeedEvidence?
    public let burden: DeviceBurden
    /// The estimate's share of this device's memory, behind `burden`.
    public let memoryShare: Double
    public let hasDiskSpace: Bool
    public let memoryIsTight: Bool
    public let estimatedMemoryBytes: Double
    public let deviceMemoryBudgetBytes: Double
    public var speedLabel: String { speed?.speed.label ?? ReplySpeed.unratedLabel }
}

public enum ModelRecommendation {
    public static func estimatedMemoryBytes(_ model: ModelSpec) -> Double {
        Double(model.downloadByteCount) * 1.18 + (model.supportsVision ? 900_000_000 : 650_000_000)
    }
    public static func fit(_ model: ModelSpec, device: DeviceCapacity, isInstalled: Bool = false) -> ModelFit {
        let estimate = estimatedMemoryBytes(model)
        let ratio = estimate / max(1, device.workingMemoryEstimate)
        // The burden is read against the device's memory, not what is free
        // the moment this screen opens: a model the app already holds
        // would make every other one look heavier (1.1.0 (225), as the
        // gauges before it). Whether it fits now (memoryIsTight, for the
        // automatic choice) still reads what is free.
        let share = estimate / Double(max(1, device.memoryBytes))
        return ModelFit(speed: SpeedEvidence.of(model),
                        burden: DeviceBurden(memoryShare: share, holdsCPUWeights: model.capabilities.locksCPUWeights),
                        memoryShare: share,
                        hasDiskSpace: isInstalled || device.freeDiskBytes >= model.downloadByteCount + 1_000_000_000,
                        memoryIsTight: ratio > 1, estimatedMemoryBytes: estimate,
                        deviceMemoryBudgetBytes: device.workingMemoryEstimate)
    }
    public static func recommended(for device: DeviceCapacity, installedIDs: Set<String> = [],
                                   includeDeveloperModels: Bool = true) -> ModelSpec? {
        // Prefer a visual Gemma export when there is comfortable headroom;
        // otherwise choose a smaller model. Qwen is a candidate only while
        // developer settings are on: Qwen2.5, open to everyone from 1.1.0
        // (204), is chosen by hand, as is the test version 12B, never here.
        let allowed = { (spec: ModelSpec) in includeDeveloperModels || spec.isStarter }
        return [ModelSpec.e4b, .e2b, .qwen25, .qwen3].filter(allowed).first {
            let result = fit($0, device: device, isInstalled: installedIDs.contains($0.id))
            return result.hasDiskSpace && !result.memoryIsTight
        } ?? [ModelSpec.qwen3, .qwen25, .e2b, .e4b].filter(allowed).first { fit($0, device: device, isInstalled: installedIDs.contains($0.id)).hasDiskSpace }
    }
}
