import Foundation

public struct DeviceCapacity: Equatable, Sendable {
    public let memoryBytes: UInt64
    public let freeDiskBytes: Int64
    public let processorCount: Int
    public let isPad: Bool
    public let availableMemoryBytes: UInt64?
    public init(memoryBytes: UInt64, freeDiskBytes: Int64, processorCount: Int, isPad: Bool, availableMemoryBytes: UInt64? = nil) {
        self.memoryBytes = memoryBytes; self.freeDiskBytes = max(0, freeDiskBytes)
        self.processorCount = max(1, processorCount); self.isPad = isPad
        self.availableMemoryBytes = availableMemoryBytes
    }
    public var workingMemoryEstimate: Double {
        let estimate = Double(memoryBytes) * (isPad ? 0.60 : 0.55)
        return availableMemoryBytes.map { min(estimate, Double($0) * 0.90) } ?? estimate
    }
}

/// Conservative comparisons for the bundled quantized exports, not measured
/// tokens/sec or an iOS memory entitlement. Runtime limits may be lower.
public struct ModelFit: Equatable, Sendable {
    public let load: Double
    public let responsiveness: Double
    public let hasDiskSpace: Bool
    public let memoryIsTight: Bool
    public let estimatedMemoryBytes: Double
    public let deviceMemoryBudgetBytes: Double
    public var loadLabel: String {
        load >= 0.85 ? String(localized: "非常に重い") : load >= 0.55 ? String(localized: "重い")
            : load >= 0.30 ? String(localized: "普通") : String(localized: "軽い")
    }
    public var speedLabel: String {
        responsiveness >= 0.72 ? String(localized: "軽快") : responsiveness >= 0.45 ? String(localized: "ふつう") : String(localized: "じっくり")
    }
}

public enum ModelRecommendation {
    public static func estimatedMemoryBytes(_ model: ModelSpec) -> Double {
        Double(model.byteCount) * 1.18 + (model.supportsVision ? 900_000_000 : 650_000_000)
    }
    public static func fit(_ model: ModelSpec, device: DeviceCapacity, isInstalled: Bool = false) -> ModelFit {
        let estimate = estimatedMemoryBytes(model)
        let ratio = estimate / max(1, device.workingMemoryEstimate)
        let baseSpeed: Double
        switch model.id {
        case ModelSpec.qwen3.id: baseSpeed = 0.94
        case ModelSpec.qwen25.id: baseSpeed = 0.74
        case ModelSpec.e2b.id: baseSpeed = 0.58
        default: baseSpeed = 0.40
        }
        // A common catalogue scale, independent of free RAM at the moment
        // this screen is opened. Keep device suitability separate below.
        let relativeSize = estimate / estimatedMemoryBytes(.e4b)
        let relativeSpeed = baseSpeed / 0.94
        return ModelFit(load: min(1, max(0, relativeSize)), responsiveness: min(1, max(0, relativeSpeed)),
                        hasDiskSpace: isInstalled || device.freeDiskBytes >= model.byteCount + 1_000_000_000,
                        memoryIsTight: ratio > 1, estimatedMemoryBytes: estimate,
                        deviceMemoryBudgetBytes: device.workingMemoryEstimate)
    }
    public static func recommended(for device: DeviceCapacity, installedIDs: Set<String> = [],
                                   includeDeveloperModels: Bool = true) -> ModelSpec? {
        // Prefer a visual Gemma export when there is comfortable headroom;
        // otherwise choose a smaller model. Developer-only models (Qwen) are
        // candidates only while developer settings are on.
        let allowed = { (spec: ModelSpec) in includeDeveloperModels || !spec.isDeveloperOnly }
        return [ModelSpec.e4b, .e2b, .qwen25, .qwen3].filter(allowed).first {
            let result = fit($0, device: device, isInstalled: installedIDs.contains($0.id))
            return result.hasDiskSpace && !result.memoryIsTight
        } ?? [ModelSpec.qwen3, .qwen25, .e2b, .e4b].filter(allowed).first { fit($0, device: device, isInstalled: installedIDs.contains($0.id)).hasDiskSpace }
    }
}
