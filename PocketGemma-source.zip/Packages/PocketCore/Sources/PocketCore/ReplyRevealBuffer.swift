import Foundation

/// Ephemeral presentation data; the original reply remains the archive and
/// copy source. Each piece of text the pacer lays out is given a time for
/// its first character to start appearing and a spacing for the rest, on
/// one continuous schedule: a character starts where the one before it left
/// off, at the pace the text is being laid out, whichever piece brought it.
/// So the pieces' boundaries never show as a change of rhythm, no character
/// starts before it is laid out, and none waits long after.
public struct ReplyRevealBuffer: Sendable {
    /// How long one character takes to fade and rise into place.
    public static let duration: TimeInterval = 0.26
    /// How long its brand colour takes to give way to its own colour.
    public static let tintDuration: TimeInterval = 0.7
    /// How long a character is drawn on its own after it starts.
    public static var inFlight: TimeInterval { max(duration, tintDuration) }
    /// A pause longer than this before a piece makes it a fresh start: the
    /// schedule begins again at the piece's arrival.
    public static let pauseBeforeFreshStart: TimeInterval = 0.5
    /// A fresh start places its first character this many steps after its
    /// arrival, so that the next step's characters follow on without a gap
    /// when a step's whole characters fall short of its pace.
    public static let freshLead = 0.5
    /// The schedule aims to run one step ahead of the pieces: a lead off by
    /// `leadGain` seconds changes the spacing by `leadCorrectionLimit`, and
    /// never more.
    public static let leadGain: TimeInterval = 1.0
    public static let leadCorrectionLimit = 0.15
    /// No character starts more than this far after its piece's arrival:
    /// pieces coming faster than the pace never queue up, and a burst is
    /// squeezed to fit.
    public static let furthestLead: TimeInterval = 0.25
    /// Between the starts of consecutive characters.
    public static let spacingRange: ClosedRange<TimeInterval> = 0.004...0.1
    /// The pace (characters a second) and step assumed when the caller gives
    /// none: previews, and a row's first piece.
    public static let defaultPace = 33.0
    public static let defaultStep: TimeInterval = 1.0 / 24
    public static let maximumAnimatedSegments = 32

    public struct Segment: Equatable, Sendable {
        public let text: String
        /// When its first character starts...
        public let startsAt: TimeInterval
        /// ...and the time between the starts of its characters.
        public let spacing: TimeInterval
        public var lastStartsAt: TimeInterval {
            startsAt + Double(max(text.count - 1, 0)) * spacing
        }
        /// When its last character has fully appeared, in its own colour.
        public var settlesAt: TimeInterval { lastStartsAt + ReplyRevealBuffer.inFlight }
    }

    /// Where a piece is placed on the schedule, and where the schedule then
    /// stands.
    public struct Placement: Equatable, Sendable {
        public var startsAt: TimeInterval
        public var spacing: TimeInterval
        /// When the character after the piece may start.
        public var next: TimeInterval
    }

    public private(set) var settledText: String
    public private(set) var segments: [Segment] = []
    private var lastArrival: TimeInterval?
    private var nextStart: TimeInterval?
    public var text: String { settledText + segments.map(\.text).joined() }
    public var animationDeadline: TimeInterval? { segments.map(\.settlesAt).max() }

    public init(text: String = "") { settledText = text }

    /// Takes the text as laid out now; what was added is placed on the
    /// schedule at `pace` characters a second, the pieces coming every
    /// `step` seconds.
    public mutating func update(_ newText: String, at now: TimeInterval,
                                pace: Double = ReplyRevealBuffer.defaultPace,
                                step: TimeInterval = ReplyRevealBuffer.defaultStep) {
        settle(at: now)
        let previous = text
        guard previous != newText else { return }
        // A correction or a newly joined Unicode grapheme is shown intact.
        // Never split a Japanese combining mark or an emoji sequence into two
        // independently laid-out Text runs.
        guard newText.hasPrefix(previous) else { reset(newText); return }
        let added = String(newText.dropFirst(previous.count))
        guard !added.isEmpty, previous + added == newText else { reset(newText); return }
        let placed = Self.place(count: added.count, at: now, after: lastArrival, next: nextStart, pace: pace, step: step)
        segments.append(Segment(text: added, startsAt: placed.startsAt, spacing: placed.spacing))
        lastArrival = now
        nextStart = placed.next
        while segments.count > Self.maximumAnimatedSegments {
            settledText += segments.removeFirst().text
        }
    }

    /// Where a piece of `count` characters that came at `now` goes: after
    /// the piece before (which came at `since`, leaving the schedule at
    /// `next`) it carries on from where that left off, never earlier than
    /// now, since a character that started in the past would pop in half
    /// drawn, and never later than `furthestLead`; after a pause, or
    /// first, it starts afresh half a step on. Its characters are
    /// `1 / pace` apart, nudged so the schedule keeps about a step ahead of
    /// the pieces, and squeezed if a burst would otherwise trail far behind
    /// its arrival.
    public static func place(count: Int, at now: TimeInterval, after since: TimeInterval?, next: TimeInterval?,
                             pace: Double, step: TimeInterval) -> Placement {
        let step = max(step, 0.001)
        let start: TimeInterval
        if let since, let next, now - since < pauseBeforeFreshStart {
            start = min(max(next, now), now + furthestLead)
        } else {
            start = now + freshLead * step
        }
        let lead = start - now
        let correction = min(max((lead - step) / leadGain, -leadCorrectionLimit), leadCorrectionLimit)
        var spacing = (1 / max(pace, 1)) * (1 - correction)
        spacing = min(max(spacing, spacingRange.lowerBound), spacingRange.upperBound)
        if count > 1 {
            let room = now + furthestLead - start
            spacing = min(spacing, max(room / Double(count - 1), 0))
        }
        return Placement(startsAt: start, spacing: spacing, next: start + Double(max(count, 1)) * spacing)
    }

    /// Pieces whose last character has fully appeared join the settled text,
    /// in order, so the settled text is always the reply's prefix.
    public mutating func settle(at now: TimeInterval) {
        while let first = segments.first, now >= first.settlesAt {
            settledText += segments.removeFirst().text
        }
    }

    public mutating func reset(_ text: String) {
        settledText = text
        segments.removeAll(keepingCapacity: true)
        lastArrival = nil
        nextStart = nil
    }
}
