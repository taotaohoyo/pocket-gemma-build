import Foundation

/// Ephemeral presentation data; the original reply remains the archive and
/// copy source. Each arriving piece keeps its own clock so rapid tokens don't
/// restart the animation on words that have already become readable, and
/// its characters start one after another (`stagger`) so a piece of several
/// characters flows in rather than appearing at once.
public struct ReplyRevealBuffer: Sendable {
    /// How long one character takes to appear.
    public static let duration: TimeInterval = 0.22
    /// Characters of a piece start this far apart when nothing came before
    /// it to tell its pace...
    public static let defaultStagger: TimeInterval = 0.03
    /// ...and otherwise the time since the piece before, shared among the
    /// piece's characters, within these bounds: the characters finish
    /// starting about when the next piece comes, so pieces flow into one
    /// another, and a burst never trails far behind its arrival.
    public static let staggerRange: ClosedRange<TimeInterval> = 0.005...0.04
    /// A pause longer than this before a piece makes it a fresh start.
    public static let pauseBeforeFreshStart: TimeInterval = 0.5
    public static let maximumAnimatedSegments = 24

    public struct Segment: Equatable, Sendable {
        public let text: String
        public let arrivedAt: TimeInterval
        /// Time between the starts of the segment's characters.
        public let stagger: TimeInterval
        /// When its last character has fully appeared.
        public var settlesAt: TimeInterval {
            arrivedAt + Double(max(text.count - 1, 0)) * stagger + ReplyRevealBuffer.duration
        }
    }

    public private(set) var settledText: String
    public private(set) var segments: [Segment] = []
    private var lastArrival: TimeInterval?
    public var text: String { settledText + segments.map(\.text).joined() }
    public var animationDeadline: TimeInterval? { segments.map(\.settlesAt).max() }

    public init(text: String = "") { settledText = text }

    public mutating func update(_ newText: String, at now: TimeInterval) {
        settle(at: now)
        let previous = text
        guard previous != newText else { return }
        // A correction or a newly joined Unicode grapheme is shown intact.
        // Never split a Japanese combining mark or an emoji sequence into two
        // independently laid-out Text runs.
        guard newText.hasPrefix(previous) else { reset(newText); return }
        let added = String(newText.dropFirst(previous.count))
        guard !added.isEmpty, previous + added == newText else { reset(newText); return }
        segments.append(Segment(text: added, arrivedAt: now,
                                stagger: Self.stagger(for: added.count, since: lastArrival, now: now)))
        lastArrival = now
        while segments.count > Self.maximumAnimatedSegments {
            settledText += segments.removeFirst().text
        }
    }

    /// The time between character starts for a piece of `count` characters
    /// that came at `now`, after the piece before it at `since`.
    public static func stagger(for count: Int, since: TimeInterval?, now: TimeInterval) -> TimeInterval {
        guard let since, now - since < pauseBeforeFreshStart else { return defaultStagger }
        let shared = (now - since) / Double(max(count, 1))
        return min(max(shared, staggerRange.lowerBound), staggerRange.upperBound)
    }

    public mutating func settle(at now: TimeInterval) {
        while let first = segments.first, now >= first.settlesAt {
            settledText += segments.removeFirst().text
        }
    }

    public mutating func reset(_ text: String) {
        settledText = text
        segments.removeAll(keepingCapacity: true)
        lastArrival = nil
    }
}
