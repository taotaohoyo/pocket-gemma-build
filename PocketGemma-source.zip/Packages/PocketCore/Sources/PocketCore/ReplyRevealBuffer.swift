import Foundation

/// Ephemeral presentation data; the original reply remains the archive and
/// copy source. Each arriving piece keeps its own clock so rapid tokens don't
/// restart the animation on words that have already become readable.
public struct ReplyRevealBuffer: Sendable {
    public static let duration: TimeInterval = 0.32
    public static let maximumAnimatedSegments = 24

    public struct Segment: Equatable, Sendable {
        public let text: String
        public let arrivedAt: TimeInterval
    }

    public private(set) var settledText: String
    public private(set) var segments: [Segment] = []
    public var text: String { settledText + segments.map(\.text).joined() }
    public var animationDeadline: TimeInterval? { segments.last.map { $0.arrivedAt + Self.duration } }

    public init(text: String = "") { settledText = text }

    public mutating func update(_ newText: String, at now: TimeInterval) {
        settle(at: now)
        let previous = text
        guard previous != newText else { return }
        // A correction or a newly joined Unicode grapheme is shown intact.
        // Never split a Japanese combining mark or an emoji sequence into two
        // independently laid-out Text runs.
        guard newText.hasPrefix(previous) else { reset(newText); return }
        let added = String(newText.dropFirst(previous.count))
        guard !added.isEmpty, previous + added == newText else { reset(newText); return }
        segments.append(Segment(text: added, arrivedAt: now))
        while segments.count > Self.maximumAnimatedSegments {
            settledText += segments.removeFirst().text
        }
    }

    public mutating func settle(at now: TimeInterval) {
        while let first = segments.first, now - first.arrivedAt >= Self.duration {
            settledText += segments.removeFirst().text
        }
    }

    public mutating func reset(_ text: String) {
        settledText = text
        segments.removeAll(keepingCapacity: true)
    }
}
