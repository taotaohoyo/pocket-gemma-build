import Foundation

/// 要点 (1.1.0 (302), the user's directive of 2026-11-20): what the point
/// beside the Aurora Orb says while a reply is written, and when it
/// changes. Build 301 showed the reply's own newest words there, which only
/// said again, faintly, what the reply says; a point instead says in a few
/// words what the reply has been telling.
///
/// Only the reply's text that is already laid out on the screen is read
/// (the row gives it; never words still to come, never the model's
/// thoughts, its instructions or anything else), as an outline
/// (ReplyOutline): the sections under its headings, their sentences that
/// have ended, list items' lead terms, tables' heads, code blocks,
/// formulas and charts. When enough new has been written (`next`), a
/// request says which passage the point is for, and what its structure
/// alone can say of it (`fallback`):
/// - a summary: the app may have the passage summed up on the phone, in a
///   short noun phrase (Apple's on-device model, ReplyPointWriter), which
///   is shown only if it passes ReplyPointCheck (short, not the passage's
///   own words cut out, nothing in it the passage does not say);
/// - otherwise, the passage's structure: a list's lead terms (under the
///   section's heading, if it fits), a table's head, the kind of block
///   being written, or the topics the passage names (ReplyTopics: what it
///   says は, とは, について of). Never a heading or a sentence alone,
///   which the reply shows already. Plain sentences that name no topic
///   give no new point: the one before stays, or the orb still says
///   書いています.
/// A point stays at least `quiet` before the next takes its place, and a
/// new point is asked for only when a new section begins or about
/// `nextMinimum` characters more have been written. A plain class, used
/// on the main actor by the message row.
public final class ReplyPoints {
    public enum Kind: String, Sendable {
        /// Summed up by a model, and checked.
        case summary
        /// The topics the passage names.
        case topics
        /// From the reply's structure: headings, items, tables, blocks.
        case structure
    }

    public struct Point: Equatable, Sendable {
        public let text: String
        public let kind: Kind
        public init(text: String, kind: Kind) {
            self.text = text
            self.kind = kind
        }
    }

    public struct Request: Equatable, Sendable {
        /// 1 for the reply's first, and so on.
        public let number: Int
        /// The section's heading, if it has one.
        public let heading: String?
        /// The finished words the point is for (plain, no Markdown).
        public let passage: String
        /// What the reply's structure says of it, without any model.
        public let fallback: Point?
        /// Whether a summary may be asked for (prose and lists; a table,
        /// code, a formula or a chart says what it is by itself).
        public let summarises: Bool
        /// Mostly Japanese.
        public let japanese: Bool
    }

    /// Finished characters before the first point...
    public static let firstMinimum = 36
    /// ...and new ones before the next in the same section (about four
    /// seconds of a phone's Gemma), or a new paragraph's own...
    public static let nextMinimum = 110
    public static let paragraphMinimum = 40
    /// After an ask that gave no new point, a few more characters and a
    /// moment are enough to ask again (the passage then the same, longer).
    public static let retryMinimum = 30
    public static let retryWait: TimeInterval = 1.5
    /// A new section's characters before its point.
    public static let sectionMinimum = 24
    /// A point stays at least this long: a breath and more of the orb.
    public static let quiet: TimeInterval = 4.5
    /// The most characters a passage carries (the newest).
    public static let passageLength = 420
    /// How often the row reads the reply for it at most.
    public static let interval: TimeInterval = 0.25
    /// The longest point (characters): two lines beside the orb.
    public static let longest = 24
    public static let longestLatin = 44

    public private(set) var point: Point?
    public private(set) var pointAt: TimeInterval?
    public private(set) var requests = 0
    /// Whether one is out (asked, not yet settled).
    public var waiting: Bool { pending != nil }
    public private(set) var outline = ReplyOutline()

    private struct Mark {
        let section: Int
        let written: Int
        let paragraphs: Int
        let leads: Int
        let blocks: Int
        /// Where its passage began, when it was asked, and whether it gave
        /// a new point.
        let from: Int
        let at: TimeInterval
        var fruitful = false
    }
    private var asked: Mark?
    private var pending: Request?
    private var outlineStarts = 0

    public init() {}

    /// Reads the reply's text laid out so far (Markdown).
    public func read(_ text: String) {
        outline.read(ReplyPreviewText.withoutThoughts(text))
        if outline.starts != outlineStarts {
            // The text was replaced (written again): it is read afresh.
            outlineStarts = outline.starts
            asked = nil
        }
    }

    /// The next point's request, if one is due at `now`; nil while one is
    /// out, while the last point is still new, once the reply has ended,
    /// or while too little has been written since the last.
    public func next(now: TimeInterval, ended: Bool) -> Request? {
        guard !ended, pending == nil else { return nil }
        if let at = pointAt, now - at < Self.quiet { return nil }
        let index = outline.sections.count - 1
        let section = outline.sections[index]
        let written = outline.newestWritten
        let paragraphs = outline.newestParagraphs
        let paragraphStart = outline.newestParagraphStart
        let leads = section.leads.count
        let blocks = section.blocks
        let since: Mark?
        var from = max(written - Self.passageLength, 0)
        if let asked {
            if asked.section == index {
                // A new paragraph is a new step of the reply: its own
                // words, once it has a few.
                let newParagraph = paragraphs > asked.paragraphs && written - paragraphStart >= Self.paragraphMinimum
                let retry = !asked.fruitful && written - asked.written >= Self.retryMinimum && now - asked.at >= Self.retryWait
                guard written - asked.written >= Self.nextMinimum || newParagraph || retry || leads - asked.leads >= 2
                        || blocks > asked.blocks else { return nil }
                since = asked
                if newParagraph {
                    from = max(paragraphStart, from)
                } else if !asked.fruitful {
                    from = max(asked.from, from)
                } else {
                    from = max(asked.written - 60, from)
                }
            } else {
                guard written >= Self.sectionMinimum || leads >= 2 || blocks > 0 else { return nil }
                since = nil
            }
        } else {
            guard written >= Self.firstMinimum || leads >= 2 || blocks > 0
                    || (section.heading != nil && written >= 12) else { return nil }
            since = nil
        }
        let passage = outline.passage(from: from)
        let japanese = ReplyPointText.isMostlyJapanese(section.heading.map { $0 + passage } ?? passage)
        let newBlock = blocks > (since?.blocks ?? 0)
        var fallback: Point?
        var summarises = true
        if newBlock, let last = section.last, last.isBlock {
            fallback = Self.blockPoint(last, section: section, japanese: japanese)
            summarises = false
        } else if section.last == .list {
            // The newest items' terms, or the section's when only one is new.
            let fresh = Array(section.leads.dropFirst(since?.leads ?? 0))
            fallback = Self.leadsPoint(fresh.count >= 2 ? fresh : section.leads, heading: section.heading, japanese: japanese)
        }
        if fallback == nil, let topics = ReplyTopics.point(passage, bold: section.bold, japanese: japanese) {
            fallback = Point(text: topics, kind: .topics)
        }
        guard summarises ? !passage.isEmpty : fallback != nil else { return nil }
        requests += 1
        asked = Mark(section: index, written: written, paragraphs: paragraphs, leads: leads, blocks: blocks, from: from, at: now)
        let request = Request(number: requests, heading: section.heading, passage: passage, fallback: fallback,
                              summarises: summarises, japanese: japanese)
        pending = request
        return request
    }

    /// The request's point: `summary` (a model's, if one was asked) if it
    /// passes ReplyPointCheck, else the structure's. Nil when there is no
    /// point or it is the one already shown.
    @discardableResult
    public func settle(_ request: Request, summary: String?, now: TimeInterval) -> Point? {
        if pending == request { pending = nil }
        var chosen: Point?
        if request.summarises, let summary,
           let text = ReplyPointCheck.accept(summary, source: (request.heading.map { $0 + " " } ?? "") + request.passage) {
            chosen = Point(text: text, kind: .summary)
        }
        if chosen == nil { chosen = request.fallback }
        // Nothing to say of it: asked again soon, with a little more.
        guard let chosen else { return nil }
        if request.number == requests { asked?.fruitful = true }
        // The point already shown: it stays.
        guard ReplyPointText.normalised(chosen.text) != point.map({ ReplyPointText.normalised($0.text) }) else { return nil }
        point = chosen
        pointAt = now
        return chosen
    }

    // MARK: The structure's points

    static func fits(_ text: String, japanese: Bool) -> Bool {
        (1...(japanese ? longest : longestLatin)).contains(text.count)
    }

    /// The items' lead terms, as many as fit, under the heading if that
    /// fits too: 量子の性質：重ね合わせ・もつれ.
    static func leadsPoint(_ terms: [String], heading: String?, japanese: Bool) -> Point? {
        let joiner = japanese ? "・" : " · "
        var leads: [String] = []
        for lead in terms where !leads.contains(lead) { leads.append(lead) }
        guard leads.count >= 2 else { return nil }
        var shown = leads
        while shown.count > 1, shown.joined(separator: joiner).count > (japanese ? 20 : 40) { shown.removeLast() }
        var text = shown.joined(separator: joiner)
        if japanese, shown.count < leads.count { text += "など" }
        if let heading, fits(heading + "：" + text, japanese: japanese) {
            text = heading + (japanese ? "：" : ": ") + text
        }
        return fits(text, japanese: japanese) ? Point(text: text, kind: .structure) : nil
    }

    /// What a block being written is: 表：機種・価格・重さ, Swift のコード,
    /// 数式, グラフ.
    static func blockPoint(_ block: ReplyOutline.Block, section: ReplyOutline.Section, japanese: Bool) -> Point? {
        let text: String
        switch block {
        case .table:
            guard let head = section.table, !head.isEmpty else { return nil }
            var shown = Array(head.prefix(3))
            let joiner = japanese ? "・" : ", "
            while shown.count > 1, shown.joined(separator: joiner).count > (japanese ? 18 : 36) { shown.removeLast() }
            text = (japanese ? "表：" : "Table: ") + shown.joined(separator: joiner)
        case .code(let language):
            let name = ReplyPointText.languageName(language)
            text = japanese ? (name.map { "\($0) のコード" } ?? "コード") : (name.map { "\($0) code" } ?? "Code")
        case .formula:
            text = japanese ? "数式" : "Formula"
        case .chart:
            text = japanese ? "グラフ" : "Chart"
        case .prose, .list:
            return nil
        }
        return fits(text, japanese: japanese) ? Point(text: text, kind: .structure) : nil
    }
}

/// A reply's outline as far as it is written (ReplyPoints): its sections
/// (a new one at each heading), each with its sentences that have ended in
/// plain words, its list items' lead terms, its first table's head, its
/// code blocks' languages, formulas, charts and bold terms, and what was
/// written last. Lines that have ended are read once; of the line still
/// being written only the sentences that have ended count. Only the newest
/// characters of a section are kept; counts are from its start.
public struct ReplyOutline {
    public enum Block: Equatable, Sendable {
        case prose, list, table, code(String), formula, chart

        var isBlock: Bool {
            switch self {
            case .prose, .list: false
            default: true
            }
        }
    }

    public struct Section: Equatable, Sendable {
        public internal(set) var heading: String?
        /// The newest finished words, and how many came before them.
        public internal(set) var prose: [Character] = []
        public internal(set) var dropped = 0
        public internal(set) var leads: [String] = []
        public internal(set) var table: [String]?
        public internal(set) var code: [String] = []
        public internal(set) var formulas = 0
        public internal(set) var charts = 0
        public internal(set) var bold: [String] = []
        public internal(set) var last: Block?
        /// How many paragraphs (and lists) it has had, and where the newest
        /// began (a count of its characters).
        public internal(set) var paragraphs = 0
        public internal(set) var paragraphStart = 0

        public var blocks: Int { code.count + formulas + charts + (table == nil ? 0 : 1) }
        public var written: Int { dropped + prose.count }
        var isEmpty: Bool { heading == nil && written == 0 && leads.isEmpty && blocks == 0 }
    }

    static let keep = 1_200

    public private(set) var sections: [Section] = [Section()]
    /// How many times the text was found replaced and read afresh.
    public private(set) var starts = 0
    /// The sentences that have ended in the line still being written.
    public private(set) var openProse: [Character] = []

    private var consumed = 0
    private var checkpoint: [UInt8] = []
    private var fence: String?
    private var mathEnd: String?
    private var inTable = false
    /// A blank line (or a block, or a heading) came since the last words:
    /// the next start a paragraph.
    private var afterBreak = true

    public init() {}

    /// The newest section's paragraphs, the one being written too...
    public var newestParagraphs: Int {
        sections[sections.count - 1].paragraphs + (afterBreak && !openProse.isEmpty ? 1 : 0)
    }

    /// ...and where the newest began.
    public var newestParagraphStart: Int {
        let section = sections[sections.count - 1]
        guard afterBreak, !openProse.isEmpty else { return section.paragraphStart }
        return section.written + (section.prose.isEmpty ? 0 : 1)
    }

    /// The newest section's finished characters, the open line's too.
    public var newestWritten: Int {
        let section = sections[sections.count - 1]
        guard !openProse.isEmpty else { return section.written }
        return section.written + (section.prose.isEmpty ? 0 : 1) + openProse.count
    }

    /// The newest section's finished words from `from` (a count from its
    /// start) to the newest.
    public func passage(from: Int) -> String {
        let section = sections[sections.count - 1]
        var words = section.prose
        if !openProse.isEmpty {
            if !words.isEmpty { words.append(" ") }
            words += openProse
        }
        let lower = min(max(from - section.dropped, 0), words.count)
        return String(String(words[lower...]).drop { $0 == " " })
    }

    public mutating func read(_ source: String) {
        let utf8 = source.utf8
        if utf8.count < consumed || !continues(source) {
            let count = starts + 1
            self = ReplyOutline()
            starts = count
        }
        var start = utf8.index(utf8.startIndex, offsetBy: consumed)
        while let newline = utf8[start...].firstIndex(of: UInt8(ascii: "\n")) {
            commit(String(source[start..<newline]))
            start = utf8.index(after: newline)
        }
        consumed = utf8.distance(from: utf8.startIndex, to: start)
        checkpoint = Array(utf8[utf8.index(start, offsetBy: -min(consumed, 24))..<start])
        openProse = Array(openSentences(String(source[start...])))
    }

    private func continues(_ source: String) -> Bool {
        guard consumed > 0 else { return true }
        let utf8 = source.utf8
        guard utf8.count >= consumed else { return false }
        let end = utf8.index(utf8.startIndex, offsetBy: consumed)
        let from = utf8.index(end, offsetBy: -checkpoint.count)
        return utf8[from..<end].elementsEqual(checkpoint)
    }

    private var newest: Int { sections.count - 1 }

    /// An ended line, read once.
    private mutating func commit(_ raw: String) {
        let line = raw.trimmingCharacters(in: .whitespaces)
        if let open = fence {
            if line.hasPrefix(open) { fence = nil }
            return
        }
        if let end = mathEnd {
            let closes = end == "\\end{" ? line.contains(end) : line.hasSuffix(end)
            if closes { mathEnd = nil }
            return
        }
        guard !line.isEmpty else {
            inTable = false
            afterBreak = true
            return
        }
        if line.hasPrefix("```") || line.hasPrefix("~~~") {
            afterBreak = true
            fence = String(line.prefix(3))
            let info = line.dropFirst(3).trimmingCharacters(in: .whitespaces).lowercased()
            if info.hasPrefix("chart") {
                sections[newest].charts += 1
                sections[newest].last = .chart
            } else {
                let language = String(info.prefix { !$0.isWhitespace && $0 != "{" })
                sections[newest].code.append(language)
                sections[newest].last = .code(language)
            }
            return
        }
        if line.hasPrefix("$$") || line.hasPrefix("\\[") || line.hasPrefix("\\begin{") {
            if line.hasPrefix("$$") {
                if !(line.count >= 4 && line.hasSuffix("$$")) { mathEnd = "$$" }
            } else if line.hasPrefix("\\[") {
                if !line.hasSuffix("\\]") { mathEnd = "\\]" }
            } else if !line.contains("\\end{") {
                mathEnd = "\\end{"
            }
            sections[newest].formulas += 1
            sections[newest].last = .formula
            afterBreak = true
            return
        }
        if line.hasPrefix("|") {
            afterBreak = true
            if !inTable {
                inTable = true
                if sections[newest].table == nil, let head = ReplyPreviewText.cellWords(line) {
                    sections[newest].table = head
                    sections[newest].last = .table
                }
            }
            return
        }
        inTable = false
        if ReplyPreviewText.isRule(line) { return }
        if line.first == "#" {
            let hashes = line.prefix { $0 == "#" }.count
            let rest = line.dropFirst(hashes)
            if hashes <= 6, rest.first == " " {
                let heading = ReplyPointText.trimmedTerm(ReplyPreviewText.inline(String(rest)))
                guard !heading.isEmpty else { return }
                afterBreak = true
                if sections[newest].isEmpty {
                    sections[newest].heading = heading
                } else {
                    sections.append(Section(heading: heading))
                }
                return
            }
        }
        for term in ReplyPointText.boldTerms(line) where !sections[newest].bold.contains(term) {
            sections[newest].bold.append(term)
        }
        if let content = ReplyPointText.listContent(line) {
            if let lead = ReplyPointText.lead(of: content) { sections[newest].leads.append(lead) }
            append(ReplyPreviewText.plainLine(line))
            sections[newest].last = .list
        } else {
            append(ReplyPreviewText.plainLine(line))
            sections[newest].last = .prose
        }
    }

    private mutating func append(_ words: String) {
        guard !words.isEmpty else { return }
        var section = sections[newest]
        if !section.prose.isEmpty { section.prose.append(" ") }
        if afterBreak {
            afterBreak = false
            section.paragraphs += 1
            section.paragraphStart = section.written
        }
        section.prose += Array(words)
        let extra = section.prose.count - Self.keep
        if extra > 200 {
            section.prose.removeFirst(extra)
            section.dropped += extra
        }
        sections[newest] = section
    }

    /// The sentences that have ended in the line still being written: a
    /// paragraph's or a quote's, up to its last 。！？!? (or a full stop
    /// and a space); nothing of a heading, an item, a table or a block
    /// still being written.
    private func openSentences(_ raw: String) -> String {
        guard fence == nil, mathEnd == nil else { return "" }
        let line = raw.trimmingCharacters(in: .whitespaces)
        guard !line.isEmpty, line.first != "#", line.first != "|", ReplyPointText.listContent(line) == nil else { return "" }
        for mark in ["```", "~~~", "$$", "\\[", "\\begin"] where line.hasPrefix(mark) { return "" }
        let plain = Array(ReplyPreviewText.plainLine(line))
        var end: Int?
        for index in plain.indices.reversed() {
            let character = plain[index]
            if "。！？!?".contains(character) || (character == "." && index + 1 < plain.count && plain[index + 1] == " ") {
                end = index + 1
                break
            }
        }
        guard var end else { return "" }
        while end < plain.count, ReplyPreviewText.closers.contains(plain[end]) { end += 1 }
        return String(plain[..<end])
    }
}

/// The topics a passage names (ReplyPoints' points without a model): the
/// words it says は, とは, について of, or names with という, its bold
/// terms, two of them, in the order the passage has them: 量子コンピュー
/// タ・量子ビット. A word is a run of kanji, katakana or Latin letters, or
/// two such joined by の (量子の状態). Nothing when the passage names fewer
/// than two topics.
public enum ReplyTopics {
    /// Words too general to be a topic.
    static let general: Set<String> = Set("""
        場合 必要 可能 今回 以下 以上 全体 部分 一般 自分 状態 方法 簡単 説明 回答 質問 内容 理由 仕組 意味 \
        時 事 物 者 方 中 上 下 前 後 他 等 例 点 際 一方 具体 実際 本当 非常 大切 重要 注意 便利 普通 様々 \
        色々 主 次 最後 最初 今 今日 皆 目安 コツ ポイント 基本 結果 効果 影響 特徴 違い 種類 以外 最近 現在 \
        将来 今後 多 少 全 一番 私 僕 あなた 答 話 件 側 通 頃 毎日 他人 全員 全部 一部 両方 結論 まとめ 注意点
        """.split { $0 == " " || $0 == "\n" }.map(String.init))

    /// After a word, how strongly it is the topic.
    private static let marks: [(String, Int)] = [("とは", 3), ("について", 3), ("は", 2), ("という", 1), ("って", 1)]

    public static func point(_ passage: String, bold: [String] = [], japanese: Bool) -> String? {
        var found: [(term: String, strength: Int, at: Int)] = []
        if japanese {
            let characters = Array(passage)
            var index = 0
            while index < characters.count {
                for (mark, strength) in marks {
                    let markCharacters = Array(mark)
                    guard index + markCharacters.count <= characters.count,
                          Array(characters[index..<(index + markCharacters.count)]) == markCharacters else { continue }
                    // は of はい, はず, はじめ: not the topic's mark.
                    if mark == "は", index + 1 < characters.count, "いずじ".contains(characters[index + 1]) { continue }
                    if let term = word(before: index, in: characters), usable(term) {
                        found.append((term, strength, index - term.count))
                    }
                    break
                }
                index += 1
            }
        }
        for term in bold where passage.contains(term) && usable(term) {
            let at = passage.range(of: term).map { passage.distance(from: passage.startIndex, to: $0.lowerBound) } ?? 0
            found.append((term, 3, at))
        }
        var best: [String: (strength: Int, at: Int)] = [:]
        for item in found {
            if let known = best[item.term] {
                best[item.term] = (max(known.strength, item.strength), min(known.at, item.at))
            } else {
                best[item.term] = (item.strength, item.at)
            }
        }
        let ranked = best.keys.sorted {
            let a = best[$0]!, b = best[$1]!
            return a.strength != b.strength ? a.strength > b.strength : a.at < b.at
        }
        var picked: [String] = []
        let room = japanese ? 20 : 40
        for term in ranked {
            if picked.contains(where: { $0.contains(term) || term.contains($0) }) { continue }
            if picked.reduce(0, { $0 + $1.count + 1 }) + term.count > room { continue }
            picked.append(term)
            if picked.count == 2 { break }
        }
        // Two, or none: one word alone would read as the reply's first
        // words cut out.
        guard picked.count == 2 else { return nil }
        picked.sort { best[$0]!.at < best[$1]!.at }
        return picked.joined(separator: japanese ? "・" : " · ")
    }

    private static func usable(_ term: String) -> Bool {
        guard term.count >= 2, term.count <= 12, !general.contains(term) else { return false }
        return !term.allSatisfy { $0.isNumber || $0 == "." }
    }

    /// The word that ends just before `end`: a run of kanji, katakana or
    /// Latin letters and digits, with the run before it joined by の.
    private static func word(before end: Int, in characters: [Character]) -> String? {
        var start = end
        while start > 0, ReplyPointText.isWordCharacter(characters[start - 1]) { start -= 1 }
        guard start < end else { return nil }
        var term = String(characters[start..<end])
        if start >= 2, characters[start - 1] == "の" {
            var before = start - 1
            while before > 0, ReplyPointText.isWordCharacter(characters[before - 1]) { before -= 1 }
            let head = String(characters[before..<(start - 1)])
            if !head.isEmpty, !general.contains(head), head.count + 1 + term.count <= 12 { term = head + "の" + term }
        }
        return term
    }
}

/// Whether a model's point may be shown (ReplyPoints): one short noun
/// phrase, cleaned of quotes and marks; not the passage's own words cut
/// out (most of it one run of the passage, or the passage's first words);
/// every number in it the passage's, and most of its words the passage's
/// (kanji by their pairs, katakana and Latin words whole), so it says
/// nothing the reply has not; no refusal, and nothing about the text
/// itself (この文章は…).
public enum ReplyPointCheck {
    /// Words a point may use that the passage need not: what kind of thing
    /// it tells.
    static let kinds: Set<String> = Set("""
        方法 原因 理由 手順 注意点 注意 特徴 違い 比較 対策 概要 種類 仕組 使い方 選び方 基本 ポイント メリット \
        デメリット 利点 欠点 課題 対処法 対処 効果 影響 役割 例 具体例 流れ 関係 条件 目安 説明 紹介 解説 提案 \
        考え方 見方 コツ 注意事項 定義 意味 性質 背景 現状 状況 可能性 重要性 必要性 仕組み 方 点
        """.split { $0 == " " || $0 == "\n" }.map(String.init))
    /// Refusals and words about the text: never a point unless the
    /// passage says them.
    static let refusals = ["申し訳", "できません", "お手伝い", "要約", "この文章", "このテキスト", "文章は", "本文",
                           "sorry", "i can't", "i cannot", "summary", "the text", "this text", "passage"]

    public static func accept(_ raw: String, source: String) -> String? {
        guard let text = cleaned(raw) else { return nil }
        let count = text.count
        let japaneseText = ReplyPointText.isMostlyJapanese(text)
        if japaneseText {
            guard (3...ReplyPoints.longest).contains(count) else { return nil }
        } else {
            guard (3...ReplyPoints.longestLatin).contains(count), text.split(separator: " ").count <= 7 else { return nil }
        }
        let lowerSource = source.lowercased()
        for word in refusals where text.lowercased().contains(word) && !lowerSource.contains(word) { return nil }
        guard grounded(text, in: source), !isCopy(text, of: source) else { return nil }
        return text
    }

    /// The point without what a model may put around it: the first line,
    /// no quotes or brackets around it, no label, bullet or number before
    /// it, no full stop or です after it, spaces run together.
    static func cleaned(_ raw: String) -> String? {
        guard let line = raw.split(whereSeparator: \.isNewline)
            .map({ $0.trimmingCharacters(in: .whitespaces) }).first(where: { !$0.isEmpty }) else { return nil }
        var text = ReplyPreviewText.inline(line)
        let pairs: [(Character, Character)] = [("「", "」"), ("『", "』"), ("\"", "\""), ("“", "”"), ("'", "'"),
                                              ("【", "】"), ("(", ")"), ("（", "）")]
        // Round after round, as one thing may hide another (「…」。).
        var before = ""
        while before != text {
            before = text
            for label in ["要点", "見出し", "話題", "テーマ", "Point", "Topic", "Summary", "Heading"] {
                for colon in ["：", ":"] where text.hasPrefix(label + colon) { text = String(text.dropFirst(label.count + colon.count)) }
            }
            while let first = text.first, "・-•*●○▶>→".contains(first) { text = String(text.dropFirst()) }
            let digits = text.prefix { $0.isASCII && $0.isNumber }
            if !digits.isEmpty, text.dropFirst(digits.count).hasPrefix(". ") { text = String(text.dropFirst(digits.count + 2)) }
            while let last = text.last, "。．.！!？?、,：:;；".contains(last) { text = String(text.dropLast()) }
            for (open, close) in pairs where text.count >= 2 && text.first == open && text.last == close {
                text = String(text.dropFirst().dropLast())
            }
            for ending in ["です", "である", "でした"] where text.hasSuffix(ending) && text.count > ending.count + 2 {
                text = String(text.dropLast(ending.count))
            }
            text = text.trimmingCharacters(in: .whitespaces)
        }
        text = text.split(separator: " ", omittingEmptySubsequences: true).joined(separator: " ")
        return text.isEmpty ? nil : text
    }

    /// Every number in `point` in `source`, and most of its words: a kanji
    /// run by its pairs (half of them at least), katakana and Latin words
    /// whole; words of `kinds` aside, at least 60% of the rest, and a
    /// point of one word that word.
    public static func grounded(_ point: String, in source: String) -> Bool {
        let lowerSource = source.lowercased()
        let sourceSet = Set(source)
        let characters = Array(point)
        var index = 0
        var words = 0, covered = 0
        while index < characters.count {
            let kind = ReplyPointText.kind(characters[index])
            guard kind != .other, kind != .hiragana else {
                index += 1
                continue
            }
            var end = index + 1
            while end < characters.count, ReplyPointText.kind(characters[end]) == kind { end += 1 }
            let word = String(characters[index..<end])
            index = end
            if kind == .digit {
                guard source.contains(word) else { return false }
                continue
            }
            if kinds.contains(word) { continue }
            switch kind {
            case .kanji:
                if word.count == 1 {
                    if kinds.contains(word) { continue }
                    words += 1
                    if sourceSet.contains(word.first!) { covered += 1 }
                } else {
                    let run = Array(word)
                    let pairs = (0..<(run.count - 1)).map { String(run[$0...($0 + 1)]) }
                    let found = pairs.filter { source.contains($0) }.count
                    words += 1
                    if found * 2 >= pairs.count { covered += 1 }
                }
            case .katakana, .latin:
                guard word.count >= 2 else { continue }
                words += 1
                let lower = word.lowercased()
                if lowerSource.contains(lower) {
                    covered += 1
                } else if kind == .latin, lower.count >= 5, lowerSource.contains(String(lower.prefix(max(3, lower.count - 3)))) {
                    // An English word in another form (saving, save).
                    covered += 1
                } else if kind == .katakana, word.count >= 4 {
                    let run = Array(word)
                    if (0...(run.count - 3)).contains(where: { source.contains(String(run[$0..<($0 + 3)])) }) { covered += 1 }
                }
            default:
                break
            }
        }
        guard words > 0 else { return false }
        return Double(covered) >= Double(words) * 0.6
    }

    /// Whether `point` is the passage's own words cut out: most of it (80%)
    /// one run of the passage, spaces and marks aside, or, short, the
    /// passage's first words.
    public static func isCopy(_ point: String, of source: String) -> Bool {
        let a = Array(ReplyPointText.normalised(point))
        let b = Array(ReplyPointText.normalised(source))
        guard !a.isEmpty, !b.isEmpty else { return false }
        if a.count < 8 { return b.starts(with: a) && a.count >= 4 }
        // The longest run they share.
        var previous = [Int](repeating: 0, count: b.count + 1)
        var longest = 0
        for i in 1...a.count {
            var row = [Int](repeating: 0, count: b.count + 1)
            for j in 1...b.count where a[i - 1] == b[j - 1] {
                row[j] = previous[j - 1] + 1
                longest = max(longest, row[j])
            }
            previous = row
        }
        return Double(longest) >= Double(a.count) * 0.8
    }
}

/// Characters and words as the points read them.
public enum ReplyPointText {
    enum Kind { case kanji, katakana, hiragana, latin, digit, other }

    static func kind(_ character: Character) -> Kind {
        guard let scalar = character.unicodeScalars.first else { return .other }
        let value = scalar.value
        if (0x4E00...0x9FFF).contains(value) || (0x3400...0x4DBF).contains(value) || "々〆ヶ".contains(character) { return .kanji }
        if (0x30A1...0x30FA).contains(value) || character == "ー" { return .katakana }
        if (0x3041...0x309F).contains(value) { return .hiragana }
        if character.isASCII, character.isNumber { return .digit }
        if character.isASCII, character.isLetter { return .latin }
        return .other
    }

    /// A character of a topic's word (ReplyTopics).
    static func isWordCharacter(_ character: Character) -> Bool {
        switch kind(character) {
        case .kanji, .katakana, .latin, .digit: true
        default: false
        }
    }

    /// Mostly Japanese: kana and kanji at least a fifth of its letters.
    public static func isMostlyJapanese(_ text: String) -> Bool {
        var japanese = 0, letters = 0
        for character in text {
            switch kind(character) {
            case .kanji, .katakana, .hiragana:
                japanese += 1
                letters += 1
            case .latin:
                letters += 1
            default:
                break
            }
        }
        return letters == 0 || Double(japanese) >= Double(letters) * 0.2
    }

    /// Without spaces and marks, lower case: for comparing points.
    public static func normalised(_ text: String) -> String {
        String(text.lowercased().filter { kind($0) != .other || $0.isLetter })
    }

    /// A list item's content after its mark (- * + 1. [ ] and the like),
    /// or nil for a line that is not one.
    static func listContent(_ line: String) -> String? {
        let trimmed = line.drop { $0 == " " || $0 == "\t" }
        var content: Substring?
        for mark in ["- ", "* ", "+ ", "・"] where trimmed.hasPrefix(mark) {
            content = trimmed.dropFirst(mark.count)
            break
        }
        if content == nil {
            let digits = trimmed.prefix { $0.isASCII && $0.isNumber }
            if !digits.isEmpty, digits.count <= 3 {
                let rest = trimmed.dropFirst(digits.count)
                if rest.hasPrefix(". ") || rest.hasPrefix(") ") { content = rest.dropFirst(2) }
            }
        }
        guard var item = content else { return nil }
        for box in ["[ ] ", "[x] ", "[X] "] where item.hasPrefix(box) { item = item.dropFirst(box.count) }
        return String(item)
    }

    /// An item's lead term: its bold start (**重ね合わせ**：…), the words
    /// before a colon or a dash near its start, or the item itself when it
    /// is short and no sentence.
    static func lead(of content: String) -> String? {
        let trimmed = content.trimmingCharacters(in: .whitespaces)
        if trimmed.hasPrefix("**"), let close = trimmed.range(of: "**", range: trimmed.index(trimmed.startIndex, offsetBy: 2)..<trimmed.endIndex) {
            let term = trimmedTerm(ReplyPreviewText.inline(String(trimmed[trimmed.index(trimmed.startIndex, offsetBy: 2)..<close.lowerBound])))
            if (1...16).contains(term.count) { return term }
        }
        let plain = ReplyPreviewText.inline(trimmed)
        for separator in ["：", ": ", " - ", " — ", "—"] {
            if let range = plain.range(of: separator) {
                let term = trimmedTerm(String(plain[..<range.lowerBound]))
                if (1...16).contains(term.count) { return term }
            }
        }
        if (1...14).contains(plain.count), !plain.contains(where: { "。！？!?、,".contains($0) }) {
            return trimmedTerm(plain)
        }
        return nil
    }

    /// The bold terms of a line (**…** and __…__), short ones only.
    static func boldTerms(_ line: String) -> [String] {
        var terms: [String] = []
        for mark in ["**", "__"] {
            var rest = line[...]
            while let open = rest.range(of: mark), let close = rest.range(of: mark, range: open.upperBound..<rest.endIndex) {
                let term = trimmedTerm(ReplyPreviewText.inline(String(rest[open.upperBound..<close.lowerBound])))
                if (2...16).contains(term.count), !term.contains(where: { "。！？!?".contains($0) }) { terms.append(term) }
                rest = rest[close.upperBound...]
            }
        }
        return terms
    }

    /// Without spaces, colons or full stops at its ends.
    static func trimmedTerm(_ text: String) -> String {
        text.trimmingCharacters(in: CharacterSet(charactersIn: " 　：:。．.、,"))
    }

    /// A code block's language as people write it.
    static func languageName(_ info: String) -> String? {
        let names = ["swift": "Swift", "python": "Python", "py": "Python", "js": "JavaScript", "javascript": "JavaScript",
                     "ts": "TypeScript", "typescript": "TypeScript", "json": "JSON", "html": "HTML", "css": "CSS",
                     "sql": "SQL", "kotlin": "Kotlin", "java": "Java", "c": "C", "cpp": "C++", "c++": "C++", "go": "Go",
                     "rust": "Rust", "ruby": "Ruby", "sh": "シェル", "bash": "シェル", "zsh": "シェル", "shell": "シェル",
                     "yaml": "YAML", "xml": "XML", "php": "PHP", "r": "R", "dart": "Dart", "csharp": "C#", "cs": "C#"]
        guard !info.isEmpty else { return nil }
        if let name = names[info] { return name }
        guard info.count <= 12, info.allSatisfy({ $0.isLetter || $0.isNumber }) else { return nil }
        return info.prefix(1).uppercased() + info.dropFirst()
    }
}
