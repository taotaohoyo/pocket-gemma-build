import Foundation

/// How VoiceOver reads a formula, in Japanese, from its LaTeX: `\frac{a}{b}`
/// as "b 分の a", `x^2` as "x の 2 乗", `\sqrt{x}` as "ルート x", rows of
/// `cases` or `aligned` one after another. A command it does not know is
/// read by its name, so nothing in the formula goes unread.
public enum MathSpeech {
    public static func spoken(_ latex: String) -> String {
        var reader = Reader(characters: Array(latex.prefix(4_000)))
        return tidy(reader.list(closing: nil).joined(separator: " "))
    }

    static func tidy(_ text: String) -> String {
        var result = text.split(whereSeparator: { $0 == " " || $0 == "\n" || $0 == "\t" }).joined(separator: " ")
        for (from, to) in [(" 、", "、"), ("、 ", "、"), ("、、", "、"), ("( ", "("), (" )", ")")] {
            while result.contains(from) { result = result.replacingOccurrences(of: from, with: to) }
        }
        while result.hasPrefix("、") { result.removeFirst() }
        while result.hasSuffix("、") { result.removeLast() }
        return result
    }

    /// Characters read as a word of their own.
    static let symbols: [Character: String] = [
        "+": "プラス", "-": "マイナス", "\u{2212}": "マイナス", "=": "イコール", "<": "小なり", ">": "大なり",
        "×": "かける", "*": "かける", "·": "かける", "÷": "わる", "/": "わる", "±": "プラスマイナス",
        "≤": "小なりイコール", "≥": "大なりイコール", "≠": "ノットイコール", "≈": "ニアリーイコール",
        "→": "矢印", "⇒": "ならば", "∞": "無限大", "%": "パーセント", "!": "の階乗", ",": "、",
    ]

    /// Commands read as a word, without arguments.
    static let words: [String: String] = [
        // Operators and relations
        "times": "かける", "cdot": "かける", "ast": "かける", "div": "わる", "pm": "プラスマイナス", "mp": "マイナスプラス",
        "le": "小なりイコール", "leq": "小なりイコール", "leqslant": "小なりイコール",
        "ge": "大なりイコール", "geq": "大なりイコール", "geqslant": "大なりイコール",
        "ne": "ノットイコール", "neq": "ノットイコール", "approx": "ニアリーイコール", "simeq": "ニアリーイコール",
        "sim": "チルダ", "equiv": "合同", "cong": "合同", "propto": "比例", "ll": "非常に小さい", "gg": "非常に大きい",
        "to": "矢印", "rightarrow": "矢印", "longrightarrow": "矢印", "leftarrow": "左矢印", "gets": "左矢印",
        "Rightarrow": "ならば", "implies": "ならば", "Leftarrow": "逆向きのならば", "Leftrightarrow": "同値", "iff": "同値",
        "leftrightarrow": "両矢印", "mapsto": "写す",
        "in": "属する", "notin": "属さない", "ni": "含む", "subset": "部分集合", "subseteq": "部分集合",
        "supset": "上位集合", "supseteq": "上位集合", "cup": "和集合", "cap": "共通部分", "setminus": "差集合",
        "emptyset": "空集合", "varnothing": "空集合", "forall": "すべての", "exists": "存在する", "neg": "否定",
        "land": "かつ", "wedge": "かつ", "lor": "または", "vee": "または", "therefore": "ゆえに", "because": "なぜなら",
        "infty": "無限大", "partial": "パーシャル", "nabla": "ナブラ", "angle": "角", "triangle": "三角形",
        "perp": "垂直", "parallel": "平行", "circ": "マル", "degree": "度", "prime": "プライム",
        "cdots": "…", "ldots": "…", "dots": "…", "vdots": "…", "ddots": "…", "dotsc": "…", "dotsb": "…",
        "mid": "|", "vert": "|", "Vert": "‖", "lvert": "|", "rvert": "|", "langle": "〈", "rangle": "〉",
        "lfloor": "床関数", "rfloor": "", "lceil": "天井関数", "rceil": "",
        // Functions
        "sin": "サイン", "cos": "コサイン", "tan": "タンジェント", "cot": "コタンジェント", "sec": "セカント",
        "csc": "コセカント", "arcsin": "アークサイン", "arccos": "アークコサイン", "arctan": "アークタンジェント",
        "sinh": "ハイパボリックサイン", "cosh": "ハイパボリックコサイン", "tanh": "ハイパボリックタンジェント",
        "log": "ログ", "ln": "自然対数", "lg": "ログ", "exp": "エクスポネンシャル", "det": "行列式",
        "gcd": "最大公約数", "deg": "次数", "dim": "次元", "ker": "核", "arg": "偏角",
        // Greek letters
        "alpha": "アルファ", "beta": "ベータ", "gamma": "ガンマ", "Gamma": "ガンマ", "delta": "デルタ", "Delta": "デルタ",
        "epsilon": "イプシロン", "varepsilon": "イプシロン", "zeta": "ゼータ", "eta": "イータ",
        "theta": "シータ", "vartheta": "シータ", "Theta": "シータ", "iota": "イオタ", "kappa": "カッパ",
        "lambda": "ラムダ", "Lambda": "ラムダ", "mu": "ミュー", "nu": "ニュー", "xi": "クサイ", "Xi": "クサイ",
        "pi": "パイ", "Pi": "パイ", "rho": "ロー", "varrho": "ロー", "sigma": "シグマ", "Sigma": "シグマ",
        "tau": "タウ", "upsilon": "ウプシロン", "phi": "ファイ", "varphi": "ファイ", "Phi": "ファイ",
        "chi": "カイ", "psi": "プサイ", "Psi": "プサイ", "omega": "オメガ", "Omega": "オメガ",
        "hbar": "エイチバー", "ell": "エル",
        // Escaped characters
        "%": "パーセント", "$": "ドル", "&": "アンド", "#": "#", "_": "_", "{": "{", "}": "}", "|": "‖",
    ]

    /// Big operators, read with their limits ("i イコール 1 から n までの和").
    static let operators: [String: String] = [
        "sum": "和", "prod": "積", "coprod": "余積", "int": "積分", "iint": "二重積分", "iiint": "三重積分",
        "oint": "周回積分", "bigcup": "和集合", "bigcap": "共通部分", "lim": "極限", "limsup": "上極限",
        "liminf": "下極限", "max": "最大", "min": "最小", "sup": "上限", "inf": "下限",
    ]

    /// Commands that only space, size or style what follows.
    static let silent: Set<String> = [
        ",", ";", ":", "!", " ", ">", "quad", "qquad", "enspace", "thinspace", "medspace", "thickspace",
        "negthinspace", "negmedspace", "negthickspace", "displaystyle", "textstyle", "scriptstyle",
        "scriptscriptstyle", "limits", "nolimits", "left", "right", "middle", "big", "Big", "bigg", "Bigg",
        "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr", "Biggl", "Biggr", "nonumber", "notag", "label",
        "hline", "allowbreak", "newline",
    ]

    /// Commands whose argument is text, read as written.
    static let textual: Set<String> = ["text", "textrm", "textnormal", "textbf", "textit", "textsf", "texttt", "mbox", "emph", "hbox"]

    /// Commands that only style their argument.
    static let styling: Set<String> = [
        "mathrm", "mathbf", "mathit", "mathsf", "mathtt", "mathbb", "mathcal", "mathfrak", "mathscr", "boldsymbol",
        "bm", "operatorname", "underline", "boxed", "cancel", "bcancel", "xcancel", "overbrace", "underbrace",
        "displaylines", "mathop", "mathbin", "mathrel", "mathord",
    ]

    struct Reader {
        let characters: [Character]
        var index = 0
        /// Groups and commands open around the reader. Past `deepest`,
        /// braces only separate words, so a formula nested thousands deep
        /// cannot run the stack out.
        var depth = 0
        static let deepest = 40

        /// Words up to `closing` (consumed) or the end.
        mutating func list(closing: Character?) -> [String] {
            depth += 1
            defer { depth -= 1 }
            var words: [String] = []
            var word = ""
            func flush() {
                if !word.isEmpty { words.append(word); word = "" }
            }
            while index < characters.count {
                let character = characters[index]
                if let closing, character == closing {
                    index += 1
                    break
                }
                switch character {
                case " ", "\n", "\t", "~":
                    flush()
                    index += 1
                case "{":
                    flush()
                    index += 1
                    if depth < Reader.deepest { words.append(contentsOf: list(closing: "}")) }
                case "}", "&":
                    flush()
                    index += 1
                case "^":
                    flush()
                    index += 1
                    words.append(superscript())
                case "_":
                    flush()
                    index += 1
                    words.append("下付き " + argument())
                case "'", "\u{2032}", "\u{2019}":
                    flush()
                    index += 1
                    words.append("プライム")
                case "\\":
                    flush()
                    words.append(contentsOf: command())
                default:
                    if let name = MathSpeech.symbols[character] {
                        flush()
                        words.append(name)
                    } else {
                        word.append(character)
                    }
                    index += 1
                }
            }
            flush()
            return words
        }

        /// One argument: a group, a command or a character.
        mutating func argument() -> String {
            skipSpaces()
            guard index < characters.count else { return "" }
            let character = characters[index]
            if character == "{" {
                index += 1
                return depth < Reader.deepest ? list(closing: "}").joined(separator: " ") : ""
            }
            if character == "\\" { return depth < Reader.deepest ? command().joined(separator: " ") : "" }
            index += 1
            return MathSpeech.symbols[character] ?? String(character)
        }

        /// A group's text as written, for `\text{…}` and environment names.
        mutating func rawArgument() -> String {
            skipSpaces()
            guard index < characters.count else { return "" }
            guard characters[index] == "{" else {
                index += 1
                return String(characters[index - 1])
            }
            var depth = 0
            let start = index + 1
            while index < characters.count {
                if characters[index] == "\\" { index += 2; continue }
                if characters[index] == "{" { depth += 1 }
                if characters[index] == "}" {
                    depth -= 1
                    if depth == 0 {
                        index += 1
                        return String(characters[start..<(index - 1)])
                    }
                }
                index += 1
            }
            return String(characters[min(start, characters.count)...])
        }

        mutating func skipSpaces() {
            while index < characters.count, characters[index] == " " || characters[index] == "\n" { index += 1 }
        }

        mutating func superscript() -> String {
            skipSpaces()
            for (name, word) in [("\\circ", "度"), ("{\\circ}", "度"), ("\\prime", "プライム"), ("{\\prime}", "プライム")]
            where starts(with: name) {
                index += name.count
                return word
            }
            let power = argument()
            // `f^{\prime\prime}` is f double prime, not a power.
            let words = power.split(separator: " ")
            return !words.isEmpty && words.allSatisfy({ $0 == "プライム" }) ? power : "の \(power) 乗"
        }

        func starts(with text: String) -> Bool {
            let pattern = Array(text)
            return index + pattern.count <= characters.count
                && characters[index..<(index + pattern.count)].elementsEqual(pattern)
        }

        /// A command at the backslash and what it takes.
        mutating func command() -> [String] {
            depth += 1
            defer { depth -= 1 }
            index += 1
            guard index < characters.count else { return [] }
            var name = ""
            if characters[index].isLetter && characters[index].isASCII {
                while index < characters.count, characters[index].isLetter && characters[index].isASCII {
                    name.append(characters[index])
                    index += 1
                }
                if index < characters.count, characters[index] == "*" { index += 1 }
            } else {
                name = String(characters[index])
                index += 1
            }
            if name == "\\" { return ["、"] }
            if MathSpeech.silent.contains(name) {
                // `\right.` closes nothing that is read.
                if ["left", "right", "middle"].contains(name) || name.hasPrefix("big") || name.hasPrefix("Big") {
                    skipSpaces()
                    if index < characters.count, characters[index] == "." { index += 1 }
                }
                if name == "label" { _ = rawArgument() }
                return []
            }
            if let word = MathSpeech.words[name] { return word.isEmpty ? [] : [word] }
            if let word = MathSpeech.operators[name] { return [limits(word, limit: name == "lim")] }
            if MathSpeech.textual.contains(name) { return [rawArgument()] }
            if MathSpeech.styling.contains(name) { return [argument()] }
            switch name {
            case "frac", "dfrac", "tfrac", "cfrac":
                let numerator = argument()
                let denominator = argument()
                return ["\(denominator) 分の \(numerator)"]
            case "binom", "dbinom", "tbinom":
                let total = argument()
                let chosen = argument()
                return ["\(total) C \(chosen)"]
            case "sqrt":
                skipSpaces()
                var degree: String?
                if index < characters.count, characters[index] == "[" {
                    index += 1
                    degree = list(closing: "]").joined(separator: " ")
                }
                let radicand = argument()
                return [degree.map { "\($0) 乗根 \(radicand)" } ?? "ルート \(radicand)"]
            case "vec", "overrightarrow": return ["ベクトル \(argument())"]
            case "bar", "overline": return ["\(argument()) バー"]
            case "hat", "widehat": return ["\(argument()) ハット"]
            case "tilde", "widetilde": return ["\(argument()) チルダ"]
            case "dot": return ["\(argument()) ドット"]
            case "ddot": return ["\(argument()) ツードット"]
            case "phantom", "hphantom", "vphantom":
                _ = argument()
                return []
            case "color":
                _ = rawArgument()
                return []
            case "textcolor", "colorbox":
                _ = rawArgument()
                return [argument()]
            case "hspace", "vspace", "kern", "mkern":
                _ = rawArgument()
                return []
            case "tag":
                return ["(\(rawArgument()))"]
            case "pmod": return ["モッド \(argument())"]
            case "bmod", "mod": return ["モッド"]
            case "not": return ["ノット"]
            case "begin":
                let environment = rawArgument()
                if ["array", "alignat", "alignedat", "tabular", "subarray"].contains(environment.replacingOccurrences(of: "*", with: "")) {
                    _ = rawArgument()
                }
                if environment.hasSuffix("matrix") { return ["行列"] }
                if environment.hasPrefix("cases") || environment.hasSuffix("cases") { return ["場合分け"] }
                return []
            case "end":
                _ = rawArgument()
                return []
            default:
                return [name]
            }
        }

        /// A big operator's limits after it, in either order.
        mutating func limits(_ word: String, limit: Bool) -> String {
            var lower: String?
            var upper: String?
            for _ in 0..<2 {
                skipSpaces()
                if starts(with: "\\limits") { index += 7; skipSpaces() }
                guard index < characters.count else { break }
                if characters[index] == "_", lower == nil {
                    index += 1
                    lower = argument()
                } else if characters[index] == "^", upper == nil {
                    index += 1
                    upper = argument()
                }
            }
            if limit, let lower {
                if let arrow = lower.range(of: " 矢印 ") {
                    return "\(lower[..<arrow.lowerBound]) が \(lower[arrow.upperBound...]) に近づくときの\(word)"
                }
                return "\(lower) のときの\(word)"
            }
            switch (lower, upper) {
            case let (lower?, upper?): return "\(lower) から \(upper) までの\(word)"
            case let (lower?, nil): return "\(lower) についての\(word)"
            case let (nil, upper?): return "\(upper) までの\(word)"
            default: return word
            }
        }
    }
}
