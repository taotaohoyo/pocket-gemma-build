import Foundation

/// How VoiceOver reads a formula from its LaTeX, in the app's language:
/// `\frac{a}{b}` as "b 分の a", "a over b", "b 分之 a" or "b 분의 a",
/// `x^2` as "x の 2 乗" or "x squared", `\sqrt{x}` as "ルート x" or
/// "square root of x", rows of `cases` or `aligned` one after another. A
/// command it does not know is read by its name, so nothing in the formula
/// goes unread.
public enum MathSpeech {
    /// The languages a formula is read in. The app's String Catalog names
    /// its own under "math-speech-language"; without the catalog, as in
    /// PocketCore's tests, Japanese.
    public enum Language: String, Sendable {
        case ja, en, zh, ko

        public static var current: Language {
            Language(rawValue: String(localized: "math-speech-language", defaultValue: "ja",
                                      comment: "The language VoiceOver reads formulas in: ja, en, zh or ko.")) ?? .ja
        }
    }

    public static func spoken(_ latex: String, in language: Language = .current) -> String {
        let vocabulary = Vocabulary.of(language)
        var reader = Reader(characters: Array(latex.prefix(4_000)), vocabulary: vocabulary)
        return tidy(reader.list(closing: nil).joined(separator: " "), comma: vocabulary.comma)
    }

    static func tidy(_ text: String, comma: String) -> String {
        var result = text.split(whereSeparator: { $0 == " " || $0 == "\n" || $0 == "\t" }).joined(separator: " ")
        // A Japanese or Chinese comma stands without spaces; a Latin one
        // with a space after it.
        let pairs = comma == "," ? [(" ,", ","), (",,", ",")]
            : [(" \(comma)", comma), ("\(comma) ", comma), (comma + comma, comma)]
        for (from, to) in pairs + [("( ", "("), (" )", ")")] {
            while result.contains(from) { result = result.replacingOccurrences(of: from, with: to) }
        }
        while result.hasPrefix(comma) { result.removeFirst(comma.count) }
        while result.hasSuffix(comma) { result.removeLast(comma.count) }
        return result.trimmingCharacters(in: .whitespaces)
    }

    /// Commands read the same in every language: dots, bars and brackets.
    static let marks: [String: String] = [
        "cdots": "…", "ldots": "…", "dots": "…", "vdots": "…", "ddots": "…", "dotsc": "…", "dotsb": "…",
        "mid": "|", "vert": "|", "Vert": "‖", "lvert": "|", "rvert": "|", "langle": "〈", "rangle": "〉",
        "rfloor": "", "rceil": "",
        // Escaped characters
        "#": "#", "_": "_", "{": "{", "}": "}", "|": "‖",
    ]

    /// Commands that only space, size or style what follows.
    static let silent: Set<String> = [
        ",", ";", ":", "!", " ", ">", "quad", "qquad", "enspace", "thinspace", "medspace", "thickspace",
        "negthinspace", "negmedspace", "negthickspace", "displaystyle", "textstyle", "scriptstyle",
        "scriptscriptstyle", "limits", "nolimits", "left", "right", "middle", "big", "Big", "bigg", "Bigg",
        "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr", "Biggl", "Biggr", "nonumber", "notag", "label",
        "hline", "allowbreak", "newline",
    ]

    /// Commands whose argument is text, read as written.
    static let textual: Set<String> = ["text", "textrm", "textnormal", "textbf", "textit", "textsf", "texttt", "mbox", "emph", "hbox"]

    /// Commands that only style their argument.
    static let styling: Set<String> = [
        "mathrm", "mathbf", "mathit", "mathsf", "mathtt", "mathbb", "mathcal", "mathfrak", "mathscr", "boldsymbol",
        "bm", "operatorname", "underline", "boxed", "cancel", "bcancel", "xcancel", "overbrace", "underbrace",
        "displaylines", "mathop", "mathbin", "mathrel", "mathord",
    ]

    enum Accent { case vector, bar, hat, tilde, dot, doubleDot }

    /// One language's words for a formula, and how it puts them together.
    struct Vocabulary: Sendable {
        let language: Language
        /// Characters read as a word of their own.
        let symbols: [Character: String]
        /// Commands read as a word, without arguments.
        let words: [String: String]
        /// Big operators, read with their limits ("i イコール 1 から n までの和").
        let operators: [String: String]

        static func of(_ language: Language) -> Vocabulary {
            switch language {
            case .ja: japanese
            case .en: english
            case .zh: chinese
            case .ko: korean
            }
        }

        var comma: String {
            switch language {
            case .ja: "、"
            case .zh: "，"
            case .en, .ko: ","
            }
        }
        var prime: String {
            switch language {
            case .ja: "プライム"
            case .en: "prime"
            case .zh: "撇"
            case .ko: "프라임"
            }
        }
        var degree: String {
            switch language {
            case .ja: "度"
            case .en: "degrees"
            case .zh: "度"
            case .ko: "도"
            }
        }
        /// What `\to` and → read as; a limit's `x \to 0` reads it as approaching.
        var arrow: String {
            switch language {
            case .ja: "矢印"
            case .en: "to"
            case .zh: "箭头"
            case .ko: "화살표"
            }
        }
        var matrix: String {
            switch language {
            case .ja: "行列"
            case .en: "matrix"
            case .zh: "矩阵"
            case .ko: "행렬"
            }
        }
        var cases: String {
            switch language {
            case .ja: "場合分け"
            case .en: "cases"
            case .zh: "分段"
            case .ko: "경우"
            }
        }
        var modulo: String {
            switch language {
            case .ja: "モッド"
            case .en: "mod"
            case .zh: "模"
            case .ko: "모드"
            }
        }
        var not: String {
            switch language {
            case .ja: "ノット"
            case .en: "not"
            case .zh: "非"
            case .ko: "부정"
            }
        }

        func below(_ index: String) -> String {
            switch language {
            case .ja: "下付き " + index
            case .en: "sub " + index
            case .zh: "下标 " + index
            case .ko: "아래첨자 " + index
            }
        }

        /// A power, read after its base.
        func power(_ exponent: String) -> String {
            switch language {
            case .ja: return "の \(exponent) 乗"
            case .en: return exponent == "2" ? "squared" : exponent == "3" ? "cubed" : "to the power of \(exponent)"
            case .zh: return exponent == "2" ? "的平方" : exponent == "3" ? "的立方" : "的 \(exponent) 次方"
            case .ko: return exponent == "2" ? "의 제곱" : exponent == "3" ? "의 세제곱" : "의 \(exponent) 제곱"
            }
        }

        func fraction(_ numerator: String, _ denominator: String) -> String {
            switch language {
            case .ja: "\(denominator) 分の \(numerator)"
            case .en: "\(numerator) over \(denominator)"
            case .zh: "\(denominator) 分之 \(numerator)"
            case .ko: "\(denominator) 분의 \(numerator)"
            }
        }

        func root(_ radicand: String, degree: String?) -> String {
            switch language {
            case .ja:
                return degree.map { "\($0) 乗根 \(radicand)" } ?? "ルート \(radicand)"
            case .en:
                guard let degree, degree != "2" else { return "square root of \(radicand)" }
                if degree == "3" { return "cube root of \(radicand)" }
                return "\(Self.ordinal(degree)) root of \(radicand)"
            case .zh:
                guard let degree, degree != "2" else { return "根号 \(radicand)" }
                return "\(degree) 次根号 \(radicand)"
            case .ko:
                guard let degree, degree != "2" else { return "루트 \(radicand)" }
                return "\(degree) 제곱근 \(radicand)"
            }
        }

        /// "4th", "21st", "nth".
        static func ordinal(_ number: String) -> String {
            guard let value = Int(number) else { return number + "th" }
            if (11...13).contains(value % 100) { return number + "th" }
            return number + ([1: "st", 2: "nd", 3: "rd"][value % 10] ?? "th")
        }

        func binomial(_ total: String, _ chosen: String) -> String {
            switch language {
            case .ja, .ko: "\(total) C \(chosen)"
            case .en: "\(total) choose \(chosen)"
            case .zh: "\(total) 选 \(chosen)"
            }
        }

        func accent(_ accent: Accent, _ base: String) -> String {
            switch (language, accent) {
            case (.ja, .vector): "ベクトル \(base)"
            case (.ja, .bar): "\(base) バー"
            case (.ja, .hat): "\(base) ハット"
            case (.ja, .tilde): "\(base) チルダ"
            case (.ja, .dot): "\(base) ドット"
            case (.ja, .doubleDot): "\(base) ツードット"
            case (.en, .vector): "vector \(base)"
            case (.en, .bar): "\(base) bar"
            case (.en, .hat): "\(base) hat"
            case (.en, .tilde): "\(base) tilde"
            case (.en, .dot): "\(base) dot"
            case (.en, .doubleDot): "\(base) double dot"
            case (.zh, .vector): "向量 \(base)"
            case (.zh, .bar): "\(base) 拔"
            case (.zh, .hat): "\(base) 帽"
            case (.zh, .tilde): "\(base) 波浪"
            case (.zh, .dot): "\(base) 点"
            case (.zh, .doubleDot): "\(base) 双点"
            case (.ko, .vector): "벡터 \(base)"
            case (.ko, .bar): "\(base) 바"
            case (.ko, .hat): "\(base) 햇"
            case (.ko, .tilde): "\(base) 틸드"
            case (.ko, .dot): "\(base) 닷"
            case (.ko, .doubleDot): "\(base) 더블 닷"
            }
        }

        /// A limit as its variable approaches a value ("x が 0 に近づくときの極限").
        func approaching(_ word: String, _ variable: String, _ value: String) -> String {
            switch language {
            case .ja: "\(variable) が \(value) に近づくときの\(word)"
            case .en: "\(word) as \(variable) approaches \(value)"
            case .zh: "\(variable) 趋于 \(value) 时的\(word)"
            case .ko: "\(variable) 값이 \(value) 에 가까워질 때의 \(word)"
            }
        }

        /// A limit under a condition with no arrow ("n のときの極限").
        func limit(_ word: String, at condition: String) -> String {
            switch language {
            case .ja: "\(condition) のときの\(word)"
            case .en: "\(word) over \(condition)"
            case .zh: "\(condition) 时的\(word)"
            case .ko: "\(condition) 일 때의 \(word)"
            }
        }

        /// A big operator with the limits it has.
        func bounds(_ word: String, lower: String?, upper: String?) -> String {
            switch (language, lower, upper) {
            case let (.ja, lower?, upper?): "\(lower) から \(upper) までの\(word)"
            case let (.ja, lower?, nil): "\(lower) についての\(word)"
            case let (.ja, nil, upper?): "\(upper) までの\(word)"
            case let (.en, lower?, upper?): "\(word) from \(lower) to \(upper)"
            case let (.en, lower?, nil): "\(word) over \(lower)"
            case let (.en, nil, upper?): "\(word) up to \(upper)"
            case let (.zh, lower?, upper?): "从 \(lower) 到 \(upper) 的\(word)"
            case let (.zh, lower?, nil): "关于 \(lower) 的\(word)"
            case let (.zh, nil, upper?): "到 \(upper) 的\(word)"
            case let (.ko, lower?, upper?): "\(lower) 부터 \(upper) 까지의 \(word)"
            case let (.ko, lower?, nil): "\(lower) 에 대한 \(word)"
            case let (.ko, nil, upper?): "\(upper) 까지의 \(word)"
            case (_, nil, nil): word
            }
        }

        static let japanese = Vocabulary(language: .ja, symbols: [
            "+": "プラス", "-": "マイナス", "\u{2212}": "マイナス", "=": "イコール", "<": "小なり", ">": "大なり",
            "×": "かける", "*": "かける", "·": "かける", "÷": "わる", "/": "わる", "±": "プラスマイナス",
            "≤": "小なりイコール", "≥": "大なりイコール", "≠": "ノットイコール", "≈": "ニアリーイコール",
            "→": "矢印", "⇒": "ならば", "∞": "無限大", "%": "パーセント", "!": "の階乗", ",": "、",
        ], words: [
            // Operators and relations
            "times": "かける", "cdot": "かける", "ast": "かける", "div": "わる", "pm": "プラスマイナス", "mp": "マイナスプラス",
            "le": "小なりイコール", "leq": "小なりイコール", "leqslant": "小なりイコール",
            "ge": "大なりイコール", "geq": "大なりイコール", "geqslant": "大なりイコール",
            "ne": "ノットイコール", "neq": "ノットイコール", "approx": "ニアリーイコール", "simeq": "ニアリーイコール",
            "sim": "チルダ", "equiv": "合同", "cong": "合同", "propto": "比例", "ll": "非常に小さい", "gg": "非常に大きい",
            "to": "矢印", "rightarrow": "矢印", "longrightarrow": "矢印", "leftarrow": "左矢印", "gets": "左矢印",
            "Rightarrow": "ならば", "implies": "ならば", "Leftarrow": "逆向きのならば", "Leftrightarrow": "同値", "iff": "同値",
            "leftrightarrow": "両矢印", "mapsto": "写す",
            "in": "属する", "notin": "属さない", "ni": "含む", "subset": "部分集合", "subseteq": "部分集合",
            "supset": "上位集合", "supseteq": "上位集合", "cup": "和集合", "cap": "共通部分", "setminus": "差集合",
            "emptyset": "空集合", "varnothing": "空集合", "forall": "すべての", "exists": "存在する", "neg": "否定",
            "land": "かつ", "wedge": "かつ", "lor": "または", "vee": "または", "therefore": "ゆえに", "because": "なぜなら",
            "infty": "無限大", "partial": "パーシャル", "nabla": "ナブラ", "angle": "角", "triangle": "三角形",
            "perp": "垂直", "parallel": "平行", "circ": "マル", "degree": "度", "prime": "プライム",
            "lfloor": "床関数", "lceil": "天井関数",
            // Functions
            "sin": "サイン", "cos": "コサイン", "tan": "タンジェント", "cot": "コタンジェント", "sec": "セカント",
            "csc": "コセカント", "arcsin": "アークサイン", "arccos": "アークコサイン", "arctan": "アークタンジェント",
            "sinh": "ハイパボリックサイン", "cosh": "ハイパボリックコサイン", "tanh": "ハイパボリックタンジェント",
            "log": "ログ", "ln": "自然対数", "lg": "ログ", "exp": "エクスポネンシャル", "det": "行列式",
            "gcd": "最大公約数", "deg": "次数", "dim": "次元", "ker": "核", "arg": "偏角",
            // Greek letters
            "alpha": "アルファ", "beta": "ベータ", "gamma": "ガンマ", "Gamma": "ガンマ", "delta": "デルタ", "Delta": "デルタ",
            "epsilon": "イプシロン", "varepsilon": "イプシロン", "zeta": "ゼータ", "eta": "イータ",
            "theta": "シータ", "vartheta": "シータ", "Theta": "シータ", "iota": "イオタ", "kappa": "カッパ",
            "lambda": "ラムダ", "Lambda": "ラムダ", "mu": "ミュー", "nu": "ニュー", "xi": "クサイ", "Xi": "クサイ",
            "pi": "パイ", "Pi": "パイ", "rho": "ロー", "varrho": "ロー", "sigma": "シグマ", "Sigma": "シグマ",
            "tau": "タウ", "upsilon": "ウプシロン", "phi": "ファイ", "varphi": "ファイ", "Phi": "ファイ",
            "chi": "カイ", "psi": "プサイ", "Psi": "プサイ", "omega": "オメガ", "Omega": "オメガ",
            "hbar": "エイチバー", "ell": "エル",
            // Escaped characters
            "%": "パーセント", "$": "ドル", "&": "アンド",
        ], operators: [
            "sum": "和", "prod": "積", "coprod": "余積", "int": "積分", "iint": "二重積分", "iiint": "三重積分",
            "oint": "周回積分", "bigcup": "和集合", "bigcap": "共通部分", "lim": "極限", "limsup": "上極限",
            "liminf": "下極限", "max": "最大", "min": "最小", "sup": "上限", "inf": "下限",
        ])

        static let english = Vocabulary(language: .en, symbols: [
            "+": "plus", "-": "minus", "\u{2212}": "minus", "=": "equals", "<": "is less than", ">": "is greater than",
            "×": "times", "*": "times", "·": "times", "÷": "divided by", "/": "divided by", "±": "plus or minus",
            "≤": "is less than or equal to", "≥": "is greater than or equal to", "≠": "is not equal to",
            "≈": "is approximately equal to", "→": "to", "⇒": "implies", "∞": "infinity", "%": "percent",
            "!": "factorial", ",": ",",
        ], words: [
            "times": "times", "cdot": "times", "ast": "times", "div": "divided by", "pm": "plus or minus", "mp": "minus or plus",
            "le": "is less than or equal to", "leq": "is less than or equal to", "leqslant": "is less than or equal to",
            "ge": "is greater than or equal to", "geq": "is greater than or equal to", "geqslant": "is greater than or equal to",
            "ne": "is not equal to", "neq": "is not equal to", "approx": "is approximately equal to",
            "simeq": "is approximately equal to", "sim": "tilde", "equiv": "is equivalent to", "cong": "is congruent to",
            "propto": "is proportional to", "ll": "is much less than", "gg": "is much greater than",
            "to": "to", "rightarrow": "to", "longrightarrow": "to", "leftarrow": "left arrow", "gets": "left arrow",
            "Rightarrow": "implies", "implies": "implies", "Leftarrow": "is implied by", "Leftrightarrow": "if and only if",
            "iff": "if and only if", "leftrightarrow": "left right arrow", "mapsto": "maps to",
            "in": "is in", "notin": "is not in", "ni": "contains", "subset": "subset of", "subseteq": "subset of",
            "supset": "superset of", "supseteq": "superset of", "cup": "union", "cap": "intersection", "setminus": "minus",
            "emptyset": "empty set", "varnothing": "empty set", "forall": "for all", "exists": "there exists", "neg": "not",
            "land": "and", "wedge": "and", "lor": "or", "vee": "or", "therefore": "therefore", "because": "because",
            "infty": "infinity", "partial": "partial", "nabla": "nabla", "angle": "angle", "triangle": "triangle",
            "perp": "perpendicular to", "parallel": "parallel to", "circ": "composed with", "degree": "degrees", "prime": "prime",
            "lfloor": "floor of", "lceil": "ceiling of",
            "sin": "sine", "cos": "cosine", "tan": "tangent", "cot": "cotangent", "sec": "secant",
            "csc": "cosecant", "arcsin": "arc sine", "arccos": "arc cosine", "arctan": "arc tangent",
            "sinh": "hyperbolic sine", "cosh": "hyperbolic cosine", "tanh": "hyperbolic tangent",
            "log": "log", "ln": "natural log", "lg": "log", "exp": "exponential", "det": "determinant",
            "gcd": "GCD", "deg": "degree", "dim": "dimension", "ker": "kernel", "arg": "argument",
            "alpha": "alpha", "beta": "beta", "gamma": "gamma", "Gamma": "gamma", "delta": "delta", "Delta": "delta",
            "epsilon": "epsilon", "varepsilon": "epsilon", "zeta": "zeta", "eta": "eta",
            "theta": "theta", "vartheta": "theta", "Theta": "theta", "iota": "iota", "kappa": "kappa",
            "lambda": "lambda", "Lambda": "lambda", "mu": "mu", "nu": "nu", "xi": "xi", "Xi": "xi",
            "pi": "pi", "Pi": "pi", "rho": "rho", "varrho": "rho", "sigma": "sigma", "Sigma": "sigma",
            "tau": "tau", "upsilon": "upsilon", "phi": "phi", "varphi": "phi", "Phi": "phi",
            "chi": "chi", "psi": "psi", "Psi": "psi", "omega": "omega", "Omega": "omega",
            "hbar": "h bar", "ell": "ell",
            "%": "percent", "$": "dollars", "&": "and",
        ], operators: [
            "sum": "sum", "prod": "product", "coprod": "coproduct", "int": "integral", "iint": "double integral",
            "iiint": "triple integral", "oint": "contour integral", "bigcup": "union", "bigcap": "intersection",
            "lim": "limit", "limsup": "limit superior", "liminf": "limit inferior", "max": "maximum", "min": "minimum",
            "sup": "supremum", "inf": "infimum",
        ])

        static let chinese = Vocabulary(language: .zh, symbols: [
            "+": "加", "-": "减", "\u{2212}": "减", "=": "等于", "<": "小于", ">": "大于",
            "×": "乘", "*": "乘", "·": "乘", "÷": "除以", "/": "除以", "±": "正负",
            "≤": "小于等于", "≥": "大于等于", "≠": "不等于", "≈": "约等于",
            "→": "箭头", "⇒": "推出", "∞": "无穷大", "%": "百分号", "!": "的阶乘", ",": "，",
        ], words: [
            "times": "乘", "cdot": "乘", "ast": "乘", "div": "除以", "pm": "正负", "mp": "负正",
            "le": "小于等于", "leq": "小于等于", "leqslant": "小于等于",
            "ge": "大于等于", "geq": "大于等于", "geqslant": "大于等于",
            "ne": "不等于", "neq": "不等于", "approx": "约等于", "simeq": "约等于",
            "sim": "波浪号", "equiv": "恒等于", "cong": "全等于", "propto": "正比于", "ll": "远小于", "gg": "远大于",
            "to": "箭头", "rightarrow": "箭头", "longrightarrow": "箭头", "leftarrow": "左箭头", "gets": "左箭头",
            "Rightarrow": "推出", "implies": "推出", "Leftarrow": "被推出", "Leftrightarrow": "当且仅当", "iff": "当且仅当",
            "leftrightarrow": "双向箭头", "mapsto": "映射到",
            "in": "属于", "notin": "不属于", "ni": "包含", "subset": "子集", "subseteq": "子集",
            "supset": "超集", "supseteq": "超集", "cup": "并", "cap": "交", "setminus": "差集",
            "emptyset": "空集", "varnothing": "空集", "forall": "对于任意", "exists": "存在", "neg": "非",
            "land": "且", "wedge": "且", "lor": "或", "vee": "或", "therefore": "所以", "because": "因为",
            "infty": "无穷大", "partial": "偏", "nabla": "纳布拉", "angle": "角", "triangle": "三角形",
            "perp": "垂直于", "parallel": "平行于", "circ": "复合", "degree": "度", "prime": "撇",
            "lfloor": "向下取整", "lceil": "向上取整",
            "sin": "正弦", "cos": "余弦", "tan": "正切", "cot": "余切", "sec": "正割",
            "csc": "余割", "arcsin": "反正弦", "arccos": "反余弦", "arctan": "反正切",
            "sinh": "双曲正弦", "cosh": "双曲余弦", "tanh": "双曲正切",
            "log": "对数", "ln": "自然对数", "lg": "常用对数", "exp": "指数", "det": "行列式",
            "gcd": "最大公约数", "deg": "次数", "dim": "维数", "ker": "核", "arg": "辐角",
            "alpha": "阿尔法", "beta": "贝塔", "gamma": "伽马", "Gamma": "伽马", "delta": "德尔塔", "Delta": "德尔塔",
            "epsilon": "艾普西龙", "varepsilon": "艾普西龙", "zeta": "泽塔", "eta": "伊塔",
            "theta": "西塔", "vartheta": "西塔", "Theta": "西塔", "iota": "约塔", "kappa": "卡帕",
            "lambda": "兰姆达", "Lambda": "兰姆达", "mu": "缪", "nu": "纽", "xi": "克西", "Xi": "克西",
            "pi": "派", "Pi": "派", "rho": "柔", "varrho": "柔", "sigma": "西格玛", "Sigma": "西格玛",
            "tau": "陶", "upsilon": "宇普西龙", "phi": "斐", "varphi": "斐", "Phi": "斐",
            "chi": "希", "psi": "普西", "Psi": "普西", "omega": "欧米伽", "Omega": "欧米伽",
            "hbar": "h 拔", "ell": "l",
            "%": "百分号", "$": "美元符号", "&": "和",
        ], operators: [
            "sum": "和", "prod": "积", "coprod": "余积", "int": "积分", "iint": "二重积分", "iiint": "三重积分",
            "oint": "环路积分", "bigcup": "并集", "bigcap": "交集", "lim": "极限", "limsup": "上极限",
            "liminf": "下极限", "max": "最大值", "min": "最小值", "sup": "上确界", "inf": "下确界",
        ])

        static let korean = Vocabulary(language: .ko, symbols: [
            "+": "플러스", "-": "마이너스", "\u{2212}": "마이너스", "=": "이퀄", "<": "작다", ">": "크다",
            "×": "곱하기", "*": "곱하기", "·": "곱하기", "÷": "나누기", "/": "나누기", "±": "플러스 마이너스",
            "≤": "작거나 같다", "≥": "크거나 같다", "≠": "같지 않다", "≈": "근사",
            "→": "화살표", "⇒": "이면", "∞": "무한대", "%": "퍼센트", "!": "팩토리얼", ",": ",",
        ], words: [
            "times": "곱하기", "cdot": "곱하기", "ast": "곱하기", "div": "나누기", "pm": "플러스 마이너스", "mp": "마이너스 플러스",
            "le": "작거나 같다", "leq": "작거나 같다", "leqslant": "작거나 같다",
            "ge": "크거나 같다", "geq": "크거나 같다", "geqslant": "크거나 같다",
            "ne": "같지 않다", "neq": "같지 않다", "approx": "근사", "simeq": "근사",
            "sim": "틸드", "equiv": "합동", "cong": "합동", "propto": "비례", "ll": "매우 작다", "gg": "매우 크다",
            "to": "화살표", "rightarrow": "화살표", "longrightarrow": "화살표", "leftarrow": "왼쪽 화살표", "gets": "왼쪽 화살표",
            "Rightarrow": "이면", "implies": "이면", "Leftarrow": "역방향 이면", "Leftrightarrow": "동치", "iff": "동치",
            "leftrightarrow": "양방향 화살표", "mapsto": "대응",
            "in": "원소", "notin": "원소가 아님", "ni": "포함", "subset": "부분집합", "subseteq": "부분집합",
            "supset": "상위집합", "supseteq": "상위집합", "cup": "합집합", "cap": "교집합", "setminus": "차집합",
            "emptyset": "공집합", "varnothing": "공집합", "forall": "모든", "exists": "존재한다", "neg": "부정",
            "land": "그리고", "wedge": "그리고", "lor": "또는", "vee": "또는", "therefore": "따라서", "because": "왜냐하면",
            "infty": "무한대", "partial": "파셜", "nabla": "나블라", "angle": "각", "triangle": "삼각형",
            "perp": "수직", "parallel": "평행", "circ": "합성", "degree": "도", "prime": "프라임",
            "lfloor": "바닥 함수", "lceil": "천장 함수",
            "sin": "사인", "cos": "코사인", "tan": "탄젠트", "cot": "코탄젠트", "sec": "시컨트",
            "csc": "코시컨트", "arcsin": "아크사인", "arccos": "아크코사인", "arctan": "아크탄젠트",
            "sinh": "하이퍼볼릭 사인", "cosh": "하이퍼볼릭 코사인", "tanh": "하이퍼볼릭 탄젠트",
            "log": "로그", "ln": "자연로그", "lg": "로그", "exp": "지수 함수", "det": "행렬식",
            "gcd": "최대공약수", "deg": "차수", "dim": "차원", "ker": "핵", "arg": "편각",
            "alpha": "알파", "beta": "베타", "gamma": "감마", "Gamma": "감마", "delta": "델타", "Delta": "델타",
            "epsilon": "엡실론", "varepsilon": "엡실론", "zeta": "제타", "eta": "에타",
            "theta": "세타", "vartheta": "세타", "Theta": "세타", "iota": "요타", "kappa": "카파",
            "lambda": "람다", "Lambda": "람다", "mu": "뮤", "nu": "뉴", "xi": "크시", "Xi": "크시",
            "pi": "파이", "Pi": "파이", "rho": "로", "varrho": "로", "sigma": "시그마", "Sigma": "시그마",
            "tau": "타우", "upsilon": "입실론", "phi": "파이", "varphi": "파이", "Phi": "파이",
            "chi": "카이", "psi": "프사이", "Psi": "프사이", "omega": "오메가", "Omega": "오메가",
            "hbar": "에이치바", "ell": "엘",
            "%": "퍼센트", "$": "달러", "&": "앤드",
        ], operators: [
            "sum": "합", "prod": "곱", "coprod": "쌍대곱", "int": "적분", "iint": "이중적분", "iiint": "삼중적분",
            "oint": "선적분", "bigcup": "합집합", "bigcap": "교집합", "lim": "극한", "limsup": "상극한",
            "liminf": "하극한", "max": "최댓값", "min": "최솟값", "sup": "상한", "inf": "하한",
        ])
    }

    struct Reader {
        let characters: [Character]
        let vocabulary: Vocabulary
        var index = 0
        /// Groups and commands open around the reader. Past `deepest`,
        /// braces only separate words, so a formula nested thousands deep
        /// cannot run the stack out.
        var depth = 0
        static let deepest = 40

        init(characters: [Character], vocabulary: Vocabulary) {
            self.characters = characters
            self.vocabulary = vocabulary
        }

        /// Words up to `closing` (consumed) or the end.
        mutating func list(closing: Character?) -> [String] {
            depth += 1
            defer { depth -= 1 }
            var words: [String] = []
            var word = ""
            func flush() {
                if !word.isEmpty { words.append(word); word = "" }
            }
            while index < characters.count {
                let character = characters[index]
                if let closing, character == closing {
                    index += 1
                    break
                }
                switch character {
                case " ", "\n", "\t", "~":
                    flush()
                    index += 1
                case "{":
                    flush()
                    index += 1
                    if depth < Reader.deepest { words.append(contentsOf: list(closing: "}")) }
                case "}", "&":
                    flush()
                    index += 1
                case "^":
                    flush()
                    index += 1
                    words.append(superscript())
                case "_":
                    flush()
                    index += 1
                    words.append(vocabulary.below(argument()))
                case "'", "\u{2032}", "\u{2019}":
                    flush()
                    index += 1
                    words.append(vocabulary.prime)
                case "\\":
                    flush()
                    words.append(contentsOf: command())
                default:
                    if let name = vocabulary.symbols[character] {
                        flush()
                        words.append(name)
                    } else {
                        word.append(character)
                    }
                    index += 1
                }
            }
            flush()
            return words
        }

        /// One argument: a group, a command or a character.
        mutating func argument() -> String {
            skipSpaces()
            guard index < characters.count else { return "" }
            let character = characters[index]
            if character == "{" {
                index += 1
                return depth < Reader.deepest ? list(closing: "}").joined(separator: " ") : ""
            }
            if character == "\\" { return depth < Reader.deepest ? command().joined(separator: " ") : "" }
            index += 1
            return vocabulary.symbols[character] ?? String(character)
        }

        /// A group's text as written, for `\text{…}` and environment names.
        mutating func rawArgument() -> String {
            skipSpaces()
            guard index < characters.count else { return "" }
            guard characters[index] == "{" else {
                index += 1
                return String(characters[index - 1])
            }
            var depth = 0
            let start = index + 1
            while index < characters.count {
                if characters[index] == "\\" { index += 2; continue }
                if characters[index] == "{" { depth += 1 }
                if characters[index] == "}" {
                    depth -= 1
                    if depth == 0 {
                        index += 1
                        return String(characters[start..<(index - 1)])
                    }
                }
                index += 1
            }
            return String(characters[min(start, characters.count)...])
        }

        mutating func skipSpaces() {
            while index < characters.count, characters[index] == " " || characters[index] == "\n" { index += 1 }
        }

        mutating func superscript() -> String {
            skipSpaces()
            for (name, word) in [("\\circ", vocabulary.degree), ("{\\circ}", vocabulary.degree),
                                 ("\\prime", vocabulary.prime), ("{\\prime}", vocabulary.prime)]
            where starts(with: name) {
                index += name.count
                return word
            }
            let power = argument()
            // `f^{\prime\prime}` is f double prime, not a power.
            let words = power.split(separator: " ")
            return !words.isEmpty && words.allSatisfy({ $0 == vocabulary.prime }) ? power : vocabulary.power(power)
        }

        func starts(with text: String) -> Bool {
            let pattern = Array(text)
            return index + pattern.count <= characters.count
                && characters[index..<(index + pattern.count)].elementsEqual(pattern)
        }

        /// A command at the backslash and what it takes.
        mutating func command() -> [String] {
            depth += 1
            defer { depth -= 1 }
            index += 1
            guard index < characters.count else { return [] }
            var name = ""
            if characters[index].isLetter && characters[index].isASCII {
                while index < characters.count, characters[index].isLetter && characters[index].isASCII {
                    name.append(characters[index])
                    index += 1
                }
                if index < characters.count, characters[index] == "*" { index += 1 }
            } else {
                name = String(characters[index])
                index += 1
            }
            if name == "\\" { return [vocabulary.comma] }
            if MathSpeech.silent.contains(name) {
                // `\right.` closes nothing that is read.
                if ["left", "right", "middle"].contains(name) || name.hasPrefix("big") || name.hasPrefix("Big") {
                    skipSpaces()
                    if index < characters.count, characters[index] == "." { index += 1 }
                }
                if name == "label" { _ = rawArgument() }
                return []
            }
            if let word = vocabulary.words[name] ?? MathSpeech.marks[name] { return word.isEmpty ? [] : [word] }
            if let word = vocabulary.operators[name] { return [limits(word, limit: name == "lim")] }
            if MathSpeech.textual.contains(name) { return [rawArgument()] }
            if MathSpeech.styling.contains(name) { return [argument()] }
            switch name {
            case "frac", "dfrac", "tfrac", "cfrac":
                let numerator = argument()
                let denominator = argument()
                return [vocabulary.fraction(numerator, denominator)]
            case "binom", "dbinom", "tbinom":
                let total = argument()
                let chosen = argument()
                return [vocabulary.binomial(total, chosen)]
            case "sqrt":
                skipSpaces()
                var degree: String?
                if index < characters.count, characters[index] == "[" {
                    index += 1
                    degree = list(closing: "]").joined(separator: " ")
                }
                let radicand = argument()
                return [vocabulary.root(radicand, degree: degree)]
            case "vec", "overrightarrow": return [vocabulary.accent(.vector, argument())]
            case "bar", "overline": return [vocabulary.accent(.bar, argument())]
            case "hat", "widehat": return [vocabulary.accent(.hat, argument())]
            case "tilde", "widetilde": return [vocabulary.accent(.tilde, argument())]
            case "dot": return [vocabulary.accent(.dot, argument())]
            case "ddot": return [vocabulary.accent(.doubleDot, argument())]
            case "phantom", "hphantom", "vphantom":
                _ = argument()
                return []
            case "color":
                _ = rawArgument()
                return []
            case "textcolor", "colorbox":
                _ = rawArgument()
                return [argument()]
            case "hspace", "vspace", "kern", "mkern":
                _ = rawArgument()
                return []
            case "tag":
                return ["(\(rawArgument()))"]
            case "pmod": return ["\(vocabulary.modulo) \(argument())"]
            case "bmod", "mod": return [vocabulary.modulo]
            case "not": return [vocabulary.not]
            case "begin":
                let environment = rawArgument()
                if ["array", "alignat", "alignedat", "tabular", "subarray"].contains(environment.replacingOccurrences(of: "*", with: "")) {
                    _ = rawArgument()
                }
                if environment.hasSuffix("matrix") { return [vocabulary.matrix] }
                if environment.hasPrefix("cases") || environment.hasSuffix("cases") { return [vocabulary.cases] }
                return []
            case "end":
                _ = rawArgument()
                return []
            default:
                return [name]
            }
        }

        /// A big operator's limits after it, in either order.
        mutating func limits(_ word: String, limit: Bool) -> String {
            var lower: String?
            var upper: String?
            for _ in 0..<2 {
                skipSpaces()
                if starts(with: "\\limits") { index += 7; skipSpaces() }
                guard index < characters.count else { break }
                if characters[index] == "_", lower == nil {
                    index += 1
                    lower = argument()
                } else if characters[index] == "^", upper == nil {
                    index += 1
                    upper = argument()
                }
            }
            if limit, let lower {
                if let arrow = lower.range(of: " \(vocabulary.arrow) ") {
                    return vocabulary.approaching(word, String(lower[..<arrow.lowerBound]), String(lower[arrow.upperBound...]))
                }
                return vocabulary.limit(word, at: lower)
            }
            return vocabulary.bounds(word, lower: lower, upper: upper)
        }
    }
}
