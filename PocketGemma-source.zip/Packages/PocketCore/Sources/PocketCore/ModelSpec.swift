import Foundation
import CryptoKit

public struct ModelSpec: Sendable, Identifiable, Equatable {
    public let id: String
    public let name: String
    public let family: String
    public let summary: String
    public let sourceURL: URL
    public let fileName: String
    public let byteCount: Int64
    public let sha256: String
    public let downloadURL: URL

    public init(fileName: String, byteCount: Int64, sha256: String, downloadURL: URL,
                id: String? = nil, name: String? = nil, family: String = "Gemma",
                summary: String = "", sourceURL: URL? = nil) {
        self.id = id ?? fileName
        self.name = name ?? fileName
        self.family = family
        self.summary = summary
        self.sourceURL = sourceURL ?? downloadURL
        self.fileName = fileName
        self.byteCount = byteCount
        self.sha256 = sha256
        self.downloadURL = downloadURL
    }

    public static let e4b = ModelSpec(
        fileName: "gemma-4-E4B-it.litertlm",
        byteCount: 3_659_530_240,
        sha256: "0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm/resolve/28299f30ee4d43294517a4ac93abd6163412f07f/gemma-4-E4B-it.litertlm?download=true")!,
        id: "gemma-4-e4b", name: "Gemma 4 E4B", summary: String(localized: "E2Bより大きいGemma。日本語の会話に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm")!
    )

    public static let e2b = ModelSpec(
        fileName: "gemma-4-E2B-it.litertlm", byteCount: 2_588_147_712,
        sha256: "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1/gemma-4-E2B-it.litertlm?download=true")!,
        id: "gemma-4-e2b", name: "Gemma 4 E2B", summary: String(localized: "E4Bより小さいGemma。日本語の会話に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm")!
    )

    public static let qwen3 = ModelSpec(
        fileName: "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm", byteCount: 344_671_744,
        sha256: "03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/a3c5d805ae362dff7f580bc25f2dfb9a5a7eaa76/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true")!,
        id: "qwen3-06b", name: "Qwen3 0.6B", family: "Qwen", summary: String(localized: "小容量のモデル。短い会話や手軽なお試しに。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen3-0.6B")!
    )

    public static let qwen25 = ModelSpec(
        fileName: "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm", byteCount: 1_597_922_856,
        sha256: "c4a9b7289365ab80fe599b844b77ad253eb3c53fb0e5d963d699146a6f01255e",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/5e6e7a58d03777898b31330a15d2e0a5a9107de3/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm?download=true")!,
        id: "qwen25-15b", name: "Qwen2.5 1.5B", family: "Qwen", summary: String(localized: "指示に答える会話モデル。多言語のテキストに。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct")!
    )

    public static let catalog: [ModelSpec] = [.e4b, .e2b, .qwen3, .qwen25]

    /// Gemma 4 12B (2026-10-26): shown as ロック中 in モデル管理 and the chat's
    /// model menu while its run on the phone is being checked. It is not in
    /// `catalog`, so `find`, downloads, imports, the choice of model and the
    /// chats never reach it (and AppFiles still removes a 12B file from the
    /// models folder at launch). Only the developer 12B check
    /// (LargeModelProbe) downloads this pinned file, into a folder of its own.
    /// The whole export: text, vision, audio and the MTP drafter.
    public static let gemma12B = ModelSpec(
        fileName: "gemma-4-12B-it.litertlm", byteCount: 6_883_278_368,
        sha256: "58fd31b778ca2c21c80d634fb34fc5a89d11d563a38dfd3cbf1b40dbf252a8b6",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm/resolve/161028364f396379d490ed64ff07c6ef0fcd02d9/gemma-4-12B-it.litertlm?download=true")!,
        id: "gemma-4-12b", name: "Gemma 4 12B", summary: String(localized: "検証中の大きなGemma。この端末で動くことを確かめるまでロックしています。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm")!
    )
    /// Models listed but not usable yet: they can't be chosen, downloaded,
    /// imported or run (`isLocked`). Unlocking is a new build, not a setting.
    public static let lockedCatalog: [ModelSpec] = [.gemma12B]
    public var isLocked: Bool { Self.lockedCatalog.contains { $0.id == id } }
    /// Pinned E2B/E4B files expose only vision_70/140/280 signatures. The
    /// architecture's advertised 1120 limit is not the limit of these exports.
    public var visualTokenBudgets: [Int] {
        if id == Self.e2b.id || id == Self.e4b.id { return [70, 140, 280] }
        return [70, 140, 280, 560, 1120]
    }
    /// The budgets a chat may use. On the phone E4B's photos ran out of the
    /// app's address space at 280 image tokens (the vision probe,
    /// 2026-10-20), so its chats take its photo details' 70 or 140, and 280
    /// only with さらに深く, where the launch has the room; the probe still
    /// runs all.
    public var chatVisualTokenBudgets: [Int] { photoDetails.isEmpty ? visualTokenBudgets : photoDetails.map(\.imageTokens) }
    /// The photo details a chat can choose between (高速・深く, and さらに深く
    /// where this launch offers it); empty when the model's photos have no
    /// choice.
    public var photoDetails: [PhotoDetail] { id == Self.e4b.id ? PhotoDetail.offered : [] }
    /// Only usable models: a locked one's id (an old 12B chat) finds nothing
    /// and falls back to E4B.
    public static func find(_ id: String?) -> ModelSpec? { catalog.first { $0.id == id } }
    /// The app focuses on Gemma 4 E4B/E2B. Other models are listed, downloaded
    /// and selectable only while developer settings are on.
    public var isDeveloperOnly: Bool { id != Self.e4b.id && id != Self.e2b.id }
    public static func visibleCatalog(developer: Bool) -> [ModelSpec] {
        catalog.filter { developer || !$0.isDeveloperOnly }
    }
    public var monogram: String { String(family.prefix(1)) }
    public var capabilities: ModelCapabilities { .of(self) }
    public var supportsVision: Bool { capabilities.photos == .native }
    public var supportsThinking: Bool { capabilities.thinking }
    public var supportsGPU: Bool { capabilities.gpu }
    public var supportsSpeculation: Bool { supportsVision }
    /// Gemma 4 E2B and E4B call tools (the web search) in their own format.
    public var supportsWebSearch: Bool { id == Self.e2b.id || id == Self.e4b.id }
    public var maximumContextTokens: Int { capabilities.contextTokens }
    public var sizeLabel: String {
        ByteCountFormatter.string(fromByteCount: byteCount, countStyle: .decimal)
    }
}

public enum ModelValidationError: LocalizedError {
    case wrongSize(Int64, Int64)
    case wrongChecksum

    public var errorDescription: String? {
        switch self {
        case .wrongSize(let actual, let expected):
            return String(localized: "モデルのサイズが一致しません（\(actual) / \(expected) bytes）。選んだモデルの対応ファイルを取り込んでください。")
        case .wrongChecksum:
            return String(localized: "モデルの内容を確認できませんでした。対応するモデルをダウンロードし直してください。")
        }
    }
}

public enum ModelValidator {
    /// Read in bounded chunks; never load the 3.66 GB model into a Data at once.
    public static func validate(_ url: URL, spec: ModelSpec = .e4b) throws {
        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        let actual = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        guard actual == spec.byteCount else { throw ModelValidationError.wrongSize(actual, spec.byteCount) }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while true {
            try Task.checkCancellation()
            // Foundation can keep the backing NSData in the thread's outer
            // autorelease pool even when Swift's chunk goes out of scope.
            // Drain it on every read, including on a detached task worker.
            let hasData = try autoreleasepool { () throws -> Bool in
                guard let chunk = try handle.read(upToCount: 1_048_576), !chunk.isEmpty else { return false }
                hash.update(data: chunk)
                return true
            }
            if !hasData { break }
        }
        let checksum = hash.finalize().map { String(format: "%02x", $0) }.joined()
        guard checksum == spec.sha256 else { throw ModelValidationError.wrongChecksum }
    }
}

