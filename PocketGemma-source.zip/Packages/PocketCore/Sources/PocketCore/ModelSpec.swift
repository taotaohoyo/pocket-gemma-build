import Foundation
import CryptoKit

public struct ModelSpec: Sendable, Identifiable, Equatable {
    public let id: String
    public let name: String
    public let family: String
    public let summary: String
    public let sourceURL: URL
    public let fileName: String
    public let byteCount: Int64
    public let sha256: String
    public let downloadURL: URL

    public init(fileName: String, byteCount: Int64, sha256: String, downloadURL: URL,
                id: String? = nil, name: String? = nil, family: String = "Gemma",
                summary: String = "", sourceURL: URL? = nil) {
        self.id = id ?? fileName
        self.name = name ?? fileName
        self.family = family
        self.summary = summary
        self.sourceURL = sourceURL ?? downloadURL
        self.fileName = fileName
        self.byteCount = byteCount
        self.sha256 = sha256
        self.downloadURL = downloadURL
    }

    public static let e4b = ModelSpec(
        fileName: "gemma-4-E4B-it.litertlm",
        byteCount: 3_659_530_240,
        sha256: "0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm/resolve/28299f30ee4d43294517a4ac93abd6163412f07f/gemma-4-E4B-it.litertlm?download=true")!,
        id: "gemma-4-e4b", name: "Gemma 4 E4B", summary: String(localized: "E2Bより大きいGemma。日本語の会話に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm")!
    )

    public static let e2b = ModelSpec(
        fileName: "gemma-4-E2B-it.litertlm", byteCount: 2_588_147_712,
        sha256: "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1/gemma-4-E2B-it.litertlm?download=true")!,
        id: "gemma-4-e2b", name: "Gemma 4 E2B", summary: String(localized: "E4Bより小さいGemma。日本語の会話に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm")!
    )

    public static let qwen3 = ModelSpec(
        fileName: "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm", byteCount: 344_671_744,
        sha256: "03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/a3c5d805ae362dff7f580bc25f2dfb9a5a7eaa76/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true")!,
        id: "qwen3-06b", name: "Qwen3 0.6B", family: "Qwen", summary: String(localized: "小容量のモデル。短い会話や手軽なお試しに。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen3-0.6B")!
    )

    public static let qwen25 = ModelSpec(
        fileName: "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm", byteCount: 1_597_922_856,
        sha256: "c4a9b7289365ab80fe599b844b77ad253eb3c53fb0e5d963d699146a6f01255e",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/5e6e7a58d03777898b31330a15d2e0a5a9107de3/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm?download=true")!,
        id: "qwen25-15b", name: "Qwen2.5 1.5B", family: "Qwen", summary: String(localized: "指示に答える会話モデル。多言語のテキストに。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct")!
    )

    /// Phi-4-mini-reasoning (Microsoft, MIT), 1.1.0 (205): math and logic.
    /// The int4 block-32 export with 4,096 tokens of context; its metadata
    /// declares the `thought` channel, so its <think> reasoning streams apart
    /// from the answer, and it always reasons before it answers
    /// (`ModelCapabilities.reasons`). Text only.
    public static let phi4MiniReasoning = ModelSpec(
        fileName: "model.litertlm", byteCount: 2_784_187_376,
        sha256: "d507262ca3d01d93d59c573a82e6f2eeb3aec21d9a67c31fb4c0f93d17225b8f",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Phi-4-mini-reasoning/resolve/cbcc9be3bd879651abbb2330be0943c19d037122/model.litertlm?download=true")!,
        id: "phi-4-mini-reasoning", name: "Phi-4-mini-reasoning", family: "Phi",
        summary: String(localized: "考えてから答えるモデル。数学や論理の問題に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/Phi-4-mini-reasoning")!
    )

    /// Qwen3.5 4B (Alibaba, Apache 2.0), 1.1.0 (205): everyday talk in many
    /// languages. The Mixed INT4 export (int4 block-32 linears, int8
    /// embedding and output head) holds the text decoder only: its vision
    /// tower was dropped, so it takes text only, whatever Qwen3.5 can do
    /// elsewhere.
    public static let qwen35 = ModelSpec(
        fileName: "Qwen3.5-4B_mixed_int4.litertlm", byteCount: 2_754_070_624,
        sha256: "7243c33c9c6192150ab6da7ac13a9efdc24ff1a653eabc93b2757de4b44b012a",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen3.5-4B/resolve/190cd3223e7701c271c927fe84f1fa66b498f79d/Qwen3.5-4B_mixed_int4.litertlm?download=true")!,
        id: "qwen35-4b", name: "Qwen3.5 4B", family: "Qwen",
        summary: String(localized: "多言語の会話モデル。日常の会話や幅広い質問に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen3.5-4B")!
    )

    /// LFM3-1.7B (Liquid AI, LFM Open License v1.0), 1.1.0 (232): quick
    /// everyday talk. LiteRT-LM has no export of it, so the app runs Liquid
    /// AI's own GGUF on llama.cpp (`runtime`), the QAD Q4_0 file: trained
    /// for 4-bit, 1.05 GB, and on an Arm CPU faster than Q4_K_M (32 tokens
    /// a second against 28, run 40788630913) with the same answers. Text
    /// only; it may think first in a <think> block, mostly in English.
    public static let lfm3 = ModelSpec(
        fileName: "LFM3-1.7B-QAD-Q4_0.gguf", byteCount: 1_049_615_680,
        sha256: "43a7d09a0e9cba91b63eb7052488b9564569bddfd65754d2e426465e572a7452",
        downloadURL: URL(string: "https://huggingface.co/LiquidAI/LFM3-1.7B-GGUF/resolve/bad5729bba61d076fff20d2548e62526665af215/LFM3-1.7B-QAD-Q4_0.gguf?download=true")!,
        id: "lfm3-17b", name: "LFM3 1.7B", family: "LFM",
        summary: String(localized: "軽くて速い会話モデル。短い質問や日常の会話に。"),
        sourceURL: URL(string: "https://huggingface.co/LiquidAI/LFM3-1.7B-GGUF")!
    )

    /// The usable models. Gemma 4 12B joined them for everyone in 1.1.0
    /// (204), as a test version (`isTestVersion`), after E2B and E4B;
    /// Phi-4-mini-reasoning and Qwen3.5 4B in 205, before the older Qwen;
    /// LFM3 1.7B in 232, last.
    public static var catalog: [ModelSpec] { [.e4b, .e2b, .gemma12B, .phi4MiniReasoning, .qwen35, .qwen3, .qwen25, .lfm3] }

    /// Gemma 4 12B (2026-10-26): listed as ロック中 in 1.1.0 (196), for
    /// developers with 開発者設定 and a password from 200 (DeveloperUnlock),
    /// and open to everyone from 204 (the user, 22:01 UTC 2026-10-26) as a
    /// test version that may misbehave, which its card, its menu item and
    /// its chats say. On the phone it answered on the GPU at about 16
    /// tokens a second and on the CPU at 0.2 (TestFlight 1.1.0 (199)), so it
    /// runs on the GPU only, with text and files, and only where the
    /// signature gives it the address space (TestFlight, not the sideload).
    /// The export also carries vision, audio and the MTP drafter, which the
    /// app doesn't use for it.
    public static let gemma12B = ModelSpec(
        fileName: "gemma-4-12B-it.litertlm", byteCount: 6_883_278_368,
        sha256: "58fd31b778ca2c21c80d634fb34fc5a89d11d563a38dfd3cbf1b40dbf252a8b6",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm/resolve/161028364f396379d490ed64ff07c6ef0fcd02d9/gemma-4-12B-it.litertlm?download=true")!,
        id: "gemma-4-12b", name: "Gemma 4 12B", summary: String(localized: "E4Bより大きいGemma。込み入った質問に。"),
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm")!
    )
    /// Models listed but not usable now: they can't be chosen, downloaded,
    /// imported or run (`isLocked`). None since 1.1.0 (204), when 12B
    /// opened; the locked card and menu item stay for a model to come.
    public static var lockedCatalog: [ModelSpec] { [] }
    public var isLocked: Bool { Self.lockedCatalog.contains { $0.id == id } }
    /// Pinned E2B/E4B files expose only vision_70/140/280 signatures. The
    /// architecture's advertised 1120 limit is not the limit of these exports.
    public var visualTokenBudgets: [Int] {
        if id == Self.e2b.id || id == Self.e4b.id { return [70, 140, 280] }
        return [70, 140, 280, 560, 1120]
    }
    /// The budgets a chat may use. On the phone E4B's photos ran out of the
    /// app's address space at 280 image tokens (the vision probe,
    /// 2026-10-20), so its chats take its photo details' 70 or 140, and 280
    /// only with さらに深く, where the launch has the room; the probe still
    /// runs all.
    public var chatVisualTokenBudgets: [Int] { photoDetails.isEmpty ? visualTokenBudgets : photoDetails.map(\.imageTokens) }
    /// The photo details a chat can choose between (高速・深く, and さらに深く
    /// where this launch offers it); empty when the model's photos have no
    /// choice.
    public var photoDetails: [PhotoDetail] { id == Self.e4b.id ? PhotoDetail.offered : [] }
    /// Only usable models: a locked one's id finds nothing, so its chats
    /// fall back to E4B.
    public static func find(_ id: String?) -> ModelSpec? { catalog.first { $0.id == id } }
    /// Qwen3 0.6B is listed, downloaded and selectable only while developer
    /// settings are on. Qwen2.5 1.5B and Gemma 4 12B were too until 1.1.0
    /// (204), when the user opened them to everyone.
    public var isDeveloperOnly: Bool { id == Self.qwen3.id }
    /// The models the automatic choice picks from for everyone: Gemma 4
    /// E4B and E2B. The first launch's setup offered only these until
    /// 1.1.0 (218); from 219 it lists every model, E2B first.
    public var isStarter: Bool { id == Self.e4b.id || id == Self.e2b.id }
    public static var starterCatalog: [ModelSpec] { catalog.filter(\.isStarter) }
    /// Open to everyone, but a test version that may misbehave: Gemma 4 12B
    /// (1.1.0 (204)), and Phi-4-mini-reasoning (205), whose second turns on
    /// LiteRT-LM 0.18.0's CPU often answered in Chinese or English, and
    /// now and then fell apart, whatever the setup (runs 40416388599 and
    /// 40418000120). Its card, its menu item and its chats say so.
    /// LFM3 1.7B too (232): the first model on llama.cpp, not yet seen on
    /// an iPhone.
    public var isTestVersion: Bool { id == Self.gemma12B.id || id == Self.phi4MiniReasoning.id || id == Self.lfm3.id }
    public static var testVersionNote: String { String(localized: "テスト版のため、不具合がある場合があります。") }
    public static func visibleCatalog(developer: Bool) -> [ModelSpec] {
        catalog.filter { developer || !$0.isDeveloperOnly }
    }
    public var monogram: String { String(family.prefix(1)) }
    /// The runtime that reads the file: LiteRT-LM for .litertlm, llama.cpp
    /// for .gguf (1.1.0 (232)).
    public var runtime: ModelRuntime { fileExtension == "gguf" ? .llamaCpp : .liteRT }
    /// The file's extension, which an imported file must have.
    public var fileExtension: String { (fileName as NSString).pathExtension.lowercased() }
    public var capabilities: ModelCapabilities { .of(self) }
    public var supportsVision: Bool { capabilities.photos == .native }
    public var supportsThinking: Bool { capabilities.thinking }
    public var supportsGPU: Bool { capabilities.gpu }
    public var supportsCPU: Bool { capabilities.cpu }
    public var supportsSpeculation: Bool { supportsVision }
    /// Gemma 4 E2B and E4B call tools (the web search) in their own format.
    public var supportsWebSearch: Bool { id == Self.e2b.id || id == Self.e4b.id }
    public var maximumContextTokens: Int { capabilities.contextTokens }
    public var sizeLabel: String {
        ByteCountFormatter.string(fromByteCount: byteCount, countStyle: .decimal)
    }
}

public enum ModelRuntime: String, Sendable {
    case liteRT, llamaCpp
}

public enum ModelValidationError: LocalizedError {
    case wrongSize(Int64, Int64)
    case wrongChecksum

    public var errorDescription: String? {
        switch self {
        case .wrongSize(let actual, let expected):
            return String(localized: "モデルのサイズが一致しません（\(actual) / \(expected) bytes）。選んだモデルの対応ファイルを取り込んでください。")
        case .wrongChecksum:
            return String(localized: "モデルの内容を確認できませんでした。対応するモデルをダウンロードし直してください。")
        }
    }
}

public enum ModelValidator {
    /// Read in bounded chunks; never load the 3.66 GB model into a Data at once.
    public static func validate(_ url: URL, spec: ModelSpec = .e4b) throws {
        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        let actual = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        guard actual == spec.byteCount else { throw ModelValidationError.wrongSize(actual, spec.byteCount) }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while true {
            try Task.checkCancellation()
            // Foundation can keep the backing NSData in the thread's outer
            // autorelease pool even when Swift's chunk goes out of scope.
            // Drain it on every read, including on a detached task worker.
            let hasData = try autoreleasepool { () throws -> Bool in
                guard let chunk = try handle.read(upToCount: 1_048_576), !chunk.isEmpty else { return false }
                hash.update(data: chunk)
                return true
            }
            if !hasData { break }
        }
        let checksum = hash.finalize().map { String(format: "%02x", $0) }.joined()
        guard checksum == spec.sha256 else { throw ModelValidationError.wrongChecksum }
    }
}

