import Foundation
import CryptoKit

public struct ModelSpec: Sendable, Identifiable, Equatable {
    public let id: String
    public let name: String
    public let family: String
    public let summary: String
    public let sourceURL: URL
    public let fileName: String
    public let byteCount: Int64
    public let sha256: String
    public let downloadURL: URL

    public init(fileName: String, byteCount: Int64, sha256: String, downloadURL: URL,
                id: String? = nil, name: String? = nil, family: String = "Gemma",
                summary: String = "", sourceURL: URL? = nil) {
        self.id = id ?? fileName
        self.name = name ?? fileName
        self.family = family
        self.summary = summary
        self.sourceURL = sourceURL ?? downloadURL
        self.fileName = fileName
        self.byteCount = byteCount
        self.sha256 = sha256
        self.downloadURL = downloadURL
    }

    public static let e4b = ModelSpec(
        fileName: "gemma-4-E4B-it.litertlm",
        byteCount: 3_659_530_240,
        sha256: "0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm/resolve/28299f30ee4d43294517a4ac93abd6163412f07f/gemma-4-E4B-it.litertlm?download=true")!,
        id: "gemma-4-e4b", name: "Gemma 4 E4B", summary: "これまで使っていたモデル。日本語の会話に。",
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E4B-it-litert-lm")!
    )

    public static let e2b = ModelSpec(
        fileName: "gemma-4-E2B-it.litertlm", byteCount: 2_588_147_712,
        sha256: "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1/gemma-4-E2B-it.litertlm?download=true")!,
        id: "gemma-4-e2b", name: "Gemma 4 E2B", summary: "E4Bより小さいGemma。日本語の会話に。",
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm")!
    )

    public static let qwen3 = ModelSpec(
        fileName: "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm", byteCount: 344_671_744,
        sha256: "03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/a3c5d805ae362dff7f580bc25f2dfb9a5a7eaa76/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true")!,
        id: "qwen3-06b", name: "Qwen3 0.6B", family: "Qwen", summary: "小容量のモデル。短い会話や手軽なお試しに。",
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen3-0.6B")!
    )

    public static let qwen25 = ModelSpec(
        fileName: "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm", byteCount: 1_597_922_856,
        sha256: "c4a9b7289365ab80fe599b844b77ad253eb3c53fb0e5d963d699146a6f01255e",
        downloadURL: URL(string: "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/5e6e7a58d03777898b31330a15d2e0a5a9107de3/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm?download=true")!,
        id: "qwen25-15b", name: "Qwen2.5 1.5B", family: "Qwen", summary: "指示に答える会話モデル。多言語のテキストに。",
        sourceURL: URL(string: "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct")!
    )

    public static let gemma12b = ModelSpec(
        fileName: "gemma-4-12B-it.litertlm", byteCount: 6_883_278_368,
        sha256: "58fd31b778ca2c21c80d634fb34fc5a89d11d563a38dfd3cbf1b40dbf252a8b6",
        downloadURL: URL(string: "https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm/resolve/7a0b1ce0ea821bcd01c5f72af84155e02191152f/gemma-4-12B-it.litertlm?download=true")!,
        id: "gemma-4-12b", name: "Gemma 4 12B",
        summary: "大容量のGemma。写真とファイルにも対応。メモリ12GB以上の端末向けの試験提供で、iPhoneでの動作は未検証です。",
        sourceURL: URL(string: "https://huggingface.co/litert-community/gemma-4-12B-it-litert-lm")!
    )
    public static let catalog: [ModelSpec] = [.e4b, .e2b, .gemma12b, .qwen3, .qwen25]
    /// Pinned E2B/E4B files expose only vision_70/140/280 signatures. The
    /// architecture's advertised 1120 limit is not the limit of these exports.
    public var visualTokenBudgets: [Int] {
        if id == Self.e2b.id || id == Self.e4b.id { return [70, 140, 280] }
        return [70, 140, 280, 560, 1120]
    }
    public static func find(_ id: String?) -> ModelSpec? { catalog.first { $0.id == id } }
    public var monogram: String { String(family.prefix(1)) }
    public var supportsVision: Bool { id == Self.e4b.id || id == Self.e2b.id || id == Self.gemma12b.id }
    public var isExperimental: Bool { id == Self.gemma12b.id }
    public var supportsThinking: Bool { supportsVision || id == Self.qwen3.id }
    public var supportsSpeculation: Bool { supportsVision }
    public var maximumContextTokens: Int { id == Self.qwen25.id ? 4096 : 8192 }
    public var sizeLabel: String {
        ByteCountFormatter.string(fromByteCount: byteCount, countStyle: .decimal)
    }
}

public enum ModelValidationError: LocalizedError {
    case wrongSize(Int64, Int64)
    case wrongChecksum

    public var errorDescription: String? {
        switch self {
        case .wrongSize(let actual, let expected):
            return "モデルのサイズが一致しません（\(actual) / \(expected) bytes）。選んだモデルの対応ファイルを取り込んでください。"
        case .wrongChecksum:
            return "モデルの内容を確認できませんでした。対応するモデルをダウンロードし直してください。"
        }
    }
}

public enum ModelValidator {
    /// Read in bounded chunks; never load the 3.66 GB model into a Data at once.
    public static func validate(_ url: URL, spec: ModelSpec = .e4b) throws {
        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        let actual = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        guard actual == spec.byteCount else { throw ModelValidationError.wrongSize(actual, spec.byteCount) }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while true {
            try Task.checkCancellation()
            // Foundation can keep the backing NSData in the thread's outer
            // autorelease pool even when Swift's chunk goes out of scope.
            // Drain it on every read, including on a detached task worker.
            let hasData = try autoreleasepool { () throws -> Bool in
                guard let chunk = try handle.read(upToCount: 1_048_576), !chunk.isEmpty else { return false }
                hash.update(data: chunk)
                return true
            }
            if !hasData { break }
        }
        let checksum = hash.finalize().map { String(format: "%02x", $0) }.joined()
        guard checksum == spec.sha256 else { throw ModelValidationError.wrongChecksum }
    }
}

