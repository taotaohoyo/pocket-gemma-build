import Foundation

/// What becomes of a model Fielua no longer offers (`ModelSpec.retiredCatalog`;
/// Phi-4-mini-reasoning, fielua-reports Issue #17, the user's decision of
/// 2026-11-15, 1.1.0 (279)), for a phone that had it:
///
/// - Chosen: the phone goes on with a saved model in its place (`standIn`);
///   with none saved, with E2B to download, as a new phone. Nothing
///   downloads by itself and no model is run that is not on the phone.
/// - Its chats, their replies and its settings stay as they are; a chat of
///   it answers with the phone's choice from then on (`ModelSpec.chatModel`).
/// - Its files stay until the person deletes them in モデル管理 (`leftovers`,
///   `remove`): never deleted by an update, never left where nothing shows
///   them. A download of it that was under way stops (ModelStore).
/// - The person is told once (`notice`).
public enum ModelRetirement {
    /// The phone's choice at launch.
    public struct Selection: Equatable, Sendable {
        /// The model the phone uses.
        public let model: ModelSpec
        /// The retired model the person had chosen, in whose place `model` is.
        public let replaced: ModelSpec?
    }

    /// The model chosen before (`savedID`, ModelStore's "selectedModelID")
    /// while Fielua offers it. A retired one gives way to `standIn`, else
    /// E2B, the first model of a new phone (not downloaded). A model never
    /// chosen (or one this version doesn't know): E4B where a model is
    /// saved, else E2B, as since 1.1.0 (219).
    public static func selection(savedID: String?, installed: Set<String>) -> Selection {
        if let spec = ModelSpec.find(savedID) { return Selection(model: spec, replaced: nil) }
        if let retired = ModelSpec.retired(savedID) {
            return Selection(model: standIn(installed: installed) ?? .e2b, replaced: retired)
        }
        let hasModel = ModelSpec.catalog.contains { saved($0, installed) }
        return Selection(model: hasModel ? .e4b : .e2b, replaced: nil)
    }

    /// The saved model that takes a retired one's place: Gemma 4 E4B (it
    /// thinks before answering when asked, as Phi always did), then E2B,
    /// then the other models everyone can choose that are no test version,
    /// then the test versions, 12B last (it needs TestFlight's address
    /// space). nil when none of them is saved.
    public static func standIn(installed: Set<String>) -> ModelSpec? {
        let everyone = ModelSpec.visibleCatalog(developer: false).filter { !$0.isStarter }
        let tests = everyone.filter(\.isTestVersion)
        let order = [ModelSpec.e4b, .e2b] + everyone.filter { !$0.isTestVersion }
            + tests.filter { $0.id != ModelSpec.gemma12B.id } + tests.filter { $0.id == ModelSpec.gemma12B.id }
        return order.first { saved($0, installed) }
    }

    private static func saved(_ spec: ModelSpec, _ installed: Set<String>) -> Bool {
        spec.files.allSatisfy { installed.contains($0.id) }
    }

    // MARK: - Files

    /// Every place a retired model's own things may be: its file where each
    /// version kept it, its receipt, a finished download not checked yet,
    /// a stopped download's resume data, and the engines' caches built from
    /// it (`caches/<runtime>/<sha256>`; Phi's CPU weight cache alone is
    /// about 2.2 GB). Each named by the model's id or its checksum, except
    /// the file: Phi's is "model.litertlm", a name anyone might give a file,
    /// so it counts as Phi's only at Phi's exact size (`belongs`).
    public static func paths(of spec: ModelSpec, in library: ModelLibrary, caches: URL) -> [URL] {
        let files = spec.files.flatMap { file in
            library.allModelURLs(file) + [library.receiptURL(file), library.pendingURL(file), library.resumeURL(file)]
        }
        let runtimes = (try? FileManager.default.contentsOfDirectory(at: caches, includingPropertiesForKeys: nil)) ?? []
        return files + runtimes.map { $0.appendingPathComponent(spec.sha256, isDirectory: true) }
    }

    /// Whether a path of `paths` is the model's to count and remove: any of
    /// them but the model file's places, and a file there only at the
    /// file's exact size. A file of another size under the same name is
    /// never counted or removed.
    static func belongs(_ url: URL, to spec: ModelSpec, in library: ModelLibrary) -> Bool {
        guard let file = spec.files.first(where: { library.allModelURLs($0).contains(url) }) else { return true }
        return fileSize(url) == file.byteCount
    }

    /// Less than this, without the model file, is no row (`leftovers`).
    static let minimumBytes: Int64 = 1_000_000

    /// Each retired model with something of it on the phone, and what it
    /// all takes. Empty once deleted, or where it never was.
    public static func leftovers(in library: ModelLibrary, caches: URL) -> [RetiredModelFiles] {
        ModelSpec.retiredCatalog.compactMap { spec in
            let present = paths(of: spec, in: library, caches: caches).filter {
                FileManager.default.fileExists(atPath: $0.path) && belongs($0, to: spec, in: library)
            }
            let bytes = present.reduce(0) { $0 + size(of: $1) }
            let hasModelFile = present.contains { url in spec.files.contains { library.allModelURLs($0).contains(url) } }
            // A receipt or a stopped download's note alone (bytes) is no
            // space to give back, and no row.
            guard hasModelFile || bytes >= minimumBytes else { return nil }
            return RetiredModelFiles(spec: spec, bytes: bytes, hasModelFile: hasModelFile)
        }
    }

    /// Deletes what `leftovers` counts for the model, the receipts first,
    /// so a file that could not go never counts as checked again. The first
    /// failure is thrown after everything else was tried.
    public static func remove(_ spec: ModelSpec, in library: ModelLibrary, caches: URL) throws {
        let all = paths(of: spec, in: library, caches: caches)
        let receipts = spec.files.map(library.receiptURL)
        var failure: Error?
        for url in receipts + all.filter({ !receipts.contains($0) })
        where FileManager.default.fileExists(atPath: url.path) && belongs(url, to: spec, in: library) {
            do { try FileManager.default.removeItem(at: url) } catch { failure = failure ?? error }
        }
        if let failure { throw failure }
    }

    private static func fileSize(_ url: URL) -> Int64? {
        (try? FileManager.default.attributesOfItem(atPath: url.path))?[.size].flatMap { ($0 as? NSNumber)?.int64Value }
    }

    /// A file's size, or a folder's files' together.
    static func size(of url: URL) -> Int64 {
        var isFolder: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isFolder) else { return 0 }
        guard isFolder.boolValue else { return fileSize(url) ?? 0 }
        let keys: [URLResourceKey] = [.fileSizeKey, .isRegularFileKey]
        var total: Int64 = 0
        let walk = FileManager.default.enumerator(at: url, includingPropertiesForKeys: keys)
        while let item = walk?.nextObject() as? URL {
            let values = try? item.resourceValues(forKeys: Set(keys))
            if values?.isRegularFile == true { total += Int64(values?.fileSize ?? 0) }
        }
        return total
    }

    // MARK: - Telling the person

    /// Where the retired models the person was told about are kept (ids).
    public static let toldKey = "retired-model-notices-v1"

    /// The retired model to tell the person about at this launch: the one
    /// they had chosen, else one whose files are on the phone; once each,
    /// never again after `told` has it. nil for a phone that never had one.
    public static func notice(replaced: ModelSpec?, leftovers: [RetiredModelFiles], told: Set<String>) -> RetirementNotice? {
        if let replaced, !told.contains(replaced.id) {
            return RetirementNotice(retired: replaced, chosen: true,
                                    bytes: leftovers.first { $0.spec.id == replaced.id }?.bytes ?? 0)
        }
        guard let left = leftovers.first(where: { !told.contains($0.spec.id) }) else { return nil }
        return RetirementNotice(retired: left.spec, chosen: false, bytes: left.bytes)
    }
}

/// A retired model's things on the phone (ModelRetirement.leftovers), for
/// モデル管理's 提供を終了したモデル.
public struct RetiredModelFiles: Identifiable, Equatable, Sendable {
    public let spec: ModelSpec
    /// What its file, a download not checked yet and its engine caches take.
    public let bytes: Int64
    /// The model file itself is there (not only caches or a download).
    public let hasModelFile: Bool
    public var id: String { spec.id }
    public init(spec: ModelSpec, bytes: Int64, hasModelFile: Bool) {
        self.spec = spec; self.bytes = bytes; self.hasModelFile = hasModelFile
    }
    public var sizeLabel: String { ByteCountFormatter.string(fromByteCount: bytes, countStyle: .decimal) }
}

/// What the person is told once about a retired model (ModelRetirement.notice).
public struct RetirementNotice: Identifiable, Equatable, Sendable {
    public let retired: ModelSpec
    /// The person had chosen it: the phone uses another now.
    public let chosen: Bool
    /// What its things on the phone take; 0 when nothing of it is there.
    public let bytes: Int64
    public var id: String { retired.id }
    public init(retired: ModelSpec, chosen: Bool, bytes: Int64) {
        self.retired = retired; self.chosen = chosen; self.bytes = bytes
    }

    public var title: String { String(localized: "\(retired.name)の提供を終了しました") }

    /// What changed, in the order the person needs it: the model the chats
    /// use now (`current`, ready or to download), that the chats stay, and
    /// where the files go.
    public func message(current: ModelSpec, currentReady: Bool) -> String {
        var lines: [String] = []
        if chosen {
            lines.append(currentReady ? String(localized: "これからの会話は\(current.name)で行います。")
                         : String(localized: "使うモデルを、設定の「モデル管理」でダウンロードしてください。"))
        }
        lines.append(String(localized: "これまでの会話はそのまま残ります。"))
        if bytes > 0 {
            let size = ByteCountFormatter.string(fromByteCount: bytes, countStyle: .decimal)
            lines.append(String(localized: "端末に残っているファイル（\(size)）は、設定の「モデル管理」から削除できます。"))
        }
        return lines.joined(separator: "\n")
    }
}
