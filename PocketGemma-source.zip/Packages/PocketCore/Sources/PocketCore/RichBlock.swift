import Foundation

/// A rich block in a reply: a fenced block with a reserved tag (```chart)
/// whose body is JSON the reply draws as its own view rather than as code.
/// The tag picks a parser here (`RichBlocks.block`) and a view in the app
/// (`RichBlockView`). A new kind adds a tag, a case of `RichContent`, its
/// parser and its view; the rest of the Markdown pipeline stays as it is.
public struct RichBlock: Equatable, Sendable {
    public enum State: Equatable, Sendable {
        /// Checked and ready to draw.
        case ready(RichContent)
        /// Still arriving: its fence has not closed yet.
        case pending
        /// Not drawable; shown as its source under the reason.
        case failed(RichBlockError)
    }

    /// The fence's tag, `chart`.
    public var tag: String
    /// The block's body as written, for the fallback and copying.
    public var source: String
    public var state: State

    public init(tag: String, source: String, state: State) {
        self.tag = tag
        self.source = source
        self.state = state
    }
}

public enum RichContent: Equatable, Sendable {
    case chart(ChartSpec)
}

/// Why a rich block is shown as its source instead of drawn.
public enum RichBlockError: Error, Equatable, Sendable {
    case unfinished
    case tooLarge
    case unreadable
    case missingType
    case unknownType(String)
    case noData
    case missingLabel(Int)
    case tooManyItems(limit: Int)
    case tooManySeries(limit: Int)
    case notANumber(label: String)
    case countMismatch
    case seriesMismatch(label: String)
    case negativeInPie(label: String)
    case emptyPie
    case textTooLong

    /// The reason, for the line above the block's source.
    public var message: String {
        func name(_ label: String) -> String { label.count > 20 ? String(label.prefix(20)) + "…" : label }
        switch self {
        case .unfinished: return String(localized: "データが途中で終わっています")
        case .tooLarge: return String(localized: "データが大きすぎます")
        case .unreadable: return String(localized: "データの形式を読み取れませんでした")
        case .missingType: return String(localized: "グラフの種類が書かれていません")
        case .unknownType(let type): return String(localized: "「\(name(type))」は表示できないグラフの種類です")
        case .noData: return String(localized: "表示する数値がありません")
        case .missingLabel(let index): return String(localized: "\(index)番目の項目に名前がありません")
        case .tooManyItems(let limit): return String(localized: "項目が多すぎます（最大\(limit)項目）")
        case .tooManySeries(let limit):
            return limit == 1 ? String(localized: "円グラフに表示できる系列は1つです") : String(localized: "系列が多すぎます（最大\(limit)系列）")
        case .notANumber(let label): return String(localized: "「\(name(label))」の値が数値ではありません")
        case .countMismatch: return String(localized: "項目名と数値の数が合いません")
        case .seriesMismatch(let label): return String(localized: "「\(name(label))」の数値の数が系列の数と合いません")
        case .negativeInPie(let label): return String(localized: "円グラフに負の値があります（\(name(label))）")
        case .emptyPie: return String(localized: "円グラフの合計が0です")
        case .textTooLong: return String(localized: "題名・単位・項目名が長すぎます")
        }
    }
}

/// The rich blocks a reply can hold, by their fences' tags.
public enum RichBlocks {
    /// Tags of fenced blocks drawn as rich blocks. `math` is not one: it
    /// holds LaTeX and has its own block.
    public static let tags: Set<String> = ["chart"]
    /// Put after the tag of a rich block's fence that a streaming reply has
    /// not closed yet (`MarkdownSource.repairStreaming`)...
    static let pendingMarker: Character = "\u{E002}"
    /// ...or that a finished reply never closed (it was stopped while the
    /// block was being written).
    static let unfinishedMarker: Character = "\u{E003}"
    /// The most a block's source may hold, in bytes; a chart's data is a
    /// few hundred.
    public static let sourceLimit = 16_000

    /// Whether a fence tag still being written (`cha`) may become a rich
    /// block's.
    static func mayName(_ partial: Substring) -> Bool {
        let word = partial.lowercased()
        return tags.contains { $0.hasPrefix(word) }
    }

    /// The rich block a fenced block with this info word (lowercased) is,
    /// or nil for code.
    static func block(word: String, source: String) -> RichBlock? {
        let tag = word.filter { $0 != pendingMarker && $0 != unfinishedMarker }
        guard tags.contains(tag) else { return nil }
        if word.contains(pendingMarker) { return RichBlock(tag: tag, source: source, state: .pending) }
        if word.contains(unfinishedMarker) { return RichBlock(tag: tag, source: source, state: .failed(.unfinished)) }
        switch ChartSpec.parse(source) {
        case .success(let chart): return RichBlock(tag: tag, source: source, state: .ready(.chart(chart)))
        case .failure(let error): return RichBlock(tag: tag, source: source, state: .failed(error))
        }
    }
}

/// The note added to a message that asks for a chart, so the model writes
/// it as a ```chart block the reply can draw. Only such messages carry it,
/// so other replies, and the tokens they spend, are as before; the chat
/// keeps the message as it was written. The app's own system prompt, which
/// the user can edit, is left alone, and so is the conversation the model
/// keeps between turns.
public enum RichFormatGuide {
    /// Words that ask for a chart, or for numbers a chart shows well: in
    /// Japanese, and since 1.1.0 (195) the chart words of Chinese (both
    /// scripts) and Korean.
    static let words = ["グラフ", "チャート", "図示", "図にして", "図で示", "可視化", "視覚化", "推移", "割合", "構成比", "内訳",
                        "图表", "圖表", "柱状图", "柱狀圖", "条形图", "條形圖", "长条图", "長條圖", "折线图", "折線圖",
                        "饼图", "餅圖", "圆饼图", "圓餅圖", "可视化", "視覺化",
                        "차트", "그래프", "시각화"]
    /// Not letters on either side, so `chart形式` asks and `flowchart` does not.
    static let english = #"(?i)(?<![a-z])(charts?|graphs?|plots?|plotting|visuali[sz]e|visuali[sz]ation)(?![a-z])"#
    /// Charts the app does not draw, named with a word above.
    static let otherCharts = ["フローチャート", "ガントチャート"]
    /// A message naming a language or tool to draw the chart with wants
    /// code or steps for it. (Not "コード" alone: "コードブロックで" asks for
    /// the chart.)
    static let code = #"(?i)(?<![a-z])(python|javascript|typescript|swift|html|css|sql|matplotlib|plotly|chart\.js|excel|latex|mermaid)(?![a-z])"#

    /// Whether the message asks for a chart: it carries the note, and the
    /// reply's chart data is read as the model meant it even when fenced
    /// otherwise (`MarkdownSource.readingCharts`).
    public static func asksForChart(_ prompt: String) -> Bool {
        var text = prompt
        for other in otherCharts where text.contains(other) { text = text.replacingOccurrences(of: other, with: "") }
        // The conversation asks this of every message it shows, so the
        // patterns only run on a message that holds one of the words.
        let lowered = text.lowercased()
        let asks = words.contains { text.contains($0) }
            || (["chart", "graph", "plot", "visuali"].contains { lowered.contains($0) }
                && text.range(of: english, options: .regularExpression) != nil)
        return asks && text.range(of: code, options: .regularExpression) == nil
    }

    /// The note for this message, or nil when it does not call for a chart.
    /// One note in English for every language since 1.1.0 (195), as the
    /// app's other words to the model are since 187: the Japanese note went
    /// to any message with kana or kanji, so a Chinese one got it and the
    /// reply could turn Japanese.
    public static func guide(for prompt: String) -> String? {
        asksForChart(prompt) ? chart : nil
    }

    /// It names the app's chart feature as the block: asked to use
    /// "PocketAIのネイティブグラフ表示機能", E2B wrote a sentence saying where
    /// each chart would appear instead of a block (1.0.105).
    public static let chart = """
    (A note from the app: this app's (Pocket AI's) chart feature draws a chart wherever a reply has a ```chart block like the one below. When asked for a chart, or when a chart makes numbers easier to compare, follow over time or see as shares, write it like this:

    ```chart
    {"type":"bar","title":"Title","unit":"Unit","data":[{"label":"Item A","value":120},{"label":"Item B","value":80}]}
    ```

    - type is bar (compare), line (over time) or pie (shares)
    - write the title, unit and labels, and the text around the block, in the language of the user's message
    - value is a plain number, without a unit or commas. Do not make up numbers you are not sure of
    - only for several series in one chart, write "series":["2023","2024"] and "values":[120,135] for each item
    - for several charts, write one ```chart block for each
    - do not write a sentence saying where a chart would go instead of the block
    - do not put the ```chart block inside another code block; write a short explanation before or after it)
    """
}
