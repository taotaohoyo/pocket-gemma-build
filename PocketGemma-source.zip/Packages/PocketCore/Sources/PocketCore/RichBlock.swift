import Foundation

/// A rich block in a reply: a fenced block with a reserved tag (```chart)
/// whose body is JSON the reply draws as its own view rather than as code.
/// The tag picks a parser here (`RichBlocks.block`) and a view in the app
/// (`RichBlockView`). A new kind adds a tag, a case of `RichContent`, its
/// parser and its view; the rest of the Markdown pipeline stays as it is.
public struct RichBlock: Equatable, Sendable {
    public enum State: Equatable, Sendable {
        /// Checked and ready to draw.
        case ready(RichContent)
        /// Still arriving: its fence has not closed yet.
        case pending
        /// Not drawable; shown as its source under the reason.
        case failed(RichBlockError)
    }

    /// The fence's tag, `chart`.
    public var tag: String
    /// The block's body as written, for the fallback and copying.
    public var source: String
    public var state: State

    public init(tag: String, source: String, state: State) {
        self.tag = tag
        self.source = source
        self.state = state
    }
}

public enum RichContent: Equatable, Sendable {
    case chart(ChartSpec)
}

/// Why a rich block is shown as its source instead of drawn.
public enum RichBlockError: Error, Equatable, Sendable {
    case unfinished
    case tooLarge
    case unreadable
    case missingType
    case unknownType(String)
    case noData
    case missingLabel(Int)
    case tooManyItems(limit: Int)
    case tooManySeries(limit: Int)
    case notANumber(label: String)
    case countMismatch
    case seriesMismatch(label: String)
    case negativeInPie(label: String)
    case emptyPie
    case textTooLong

    /// The reason, for the line above the block's source.
    public var message: String {
        func name(_ label: String) -> String { label.count > 20 ? String(label.prefix(20)) + "…" : label }
        switch self {
        case .unfinished: return "データが途中で終わっています"
        case .tooLarge: return "データが大きすぎます"
        case .unreadable: return "データの形式を読み取れませんでした"
        case .missingType: return "グラフの種類が書かれていません"
        case .unknownType(let type): return "「\(name(type))」は表示できないグラフの種類です"
        case .noData: return "表示する数値がありません"
        case .missingLabel(let index): return "\(index)番目の項目に名前がありません"
        case .tooManyItems(let limit): return "項目が多すぎます（最大\(limit)項目）"
        case .tooManySeries(let limit):
            return limit == 1 ? "円グラフに表示できる系列は1つです" : "系列が多すぎます（最大\(limit)系列）"
        case .notANumber(let label): return "「\(name(label))」の値が数値ではありません"
        case .countMismatch: return "項目名と数値の数が合いません"
        case .seriesMismatch(let label): return "「\(name(label))」の数値の数が系列の数と合いません"
        case .negativeInPie(let label): return "円グラフに負の値があります（\(name(label))）"
        case .emptyPie: return "円グラフの合計が0です"
        case .textTooLong: return "題名・単位・項目名が長すぎます"
        }
    }
}

/// The rich blocks a reply can hold, by their fences' tags.
public enum RichBlocks {
    /// Tags of fenced blocks drawn as rich blocks. `math` is not one: it
    /// holds LaTeX and has its own block.
    public static let tags: Set<String> = ["chart"]
    /// Put after the tag of a rich block's fence that a streaming reply has
    /// not closed yet (`MarkdownSource.repairStreaming`)...
    static let pendingMarker: Character = "\u{E002}"
    /// ...or that a finished reply never closed (it was stopped while the
    /// block was being written).
    static let unfinishedMarker: Character = "\u{E003}"
    /// The most a block's source may hold, in bytes; a chart's data is a
    /// few hundred.
    public static let sourceLimit = 16_000

    /// Whether a fence tag still being written (`cha`) may become a rich
    /// block's.
    static func mayName(_ partial: Substring) -> Bool {
        let word = partial.lowercased()
        return tags.contains { $0.hasPrefix(word) }
    }

    /// The rich block a fenced block with this info word (lowercased) is,
    /// or nil for code.
    static func block(word: String, source: String) -> RichBlock? {
        let tag = word.filter { $0 != pendingMarker && $0 != unfinishedMarker }
        guard tags.contains(tag) else { return nil }
        if word.contains(pendingMarker) { return RichBlock(tag: tag, source: source, state: .pending) }
        if word.contains(unfinishedMarker) { return RichBlock(tag: tag, source: source, state: .failed(.unfinished)) }
        switch ChartSpec.parse(source) {
        case .success(let chart): return RichBlock(tag: tag, source: source, state: .ready(.chart(chart)))
        case .failure(let error): return RichBlock(tag: tag, source: source, state: .failed(error))
        }
    }
}

/// The note added to a message that asks for a chart, so the model writes
/// it as a ```chart block the reply can draw. Only such messages carry it,
/// so other replies, and the tokens they spend, are as before; the chat
/// keeps the message as it was written. The app's own system prompt, which
/// the user can edit, is left alone, and so is the conversation the model
/// keeps between turns.
public enum RichFormatGuide {
    /// Words that ask for a chart, or for numbers a chart shows well.
    static let words = ["グラフ", "チャート", "図示", "図にして", "図で示", "可視化", "視覚化", "推移", "割合", "構成比", "内訳"]
    static let english = #"(?i)\b(charts?|graphs?|plots?|plotting|visuali[sz]e|visuali[sz]ation)\b"#

    /// The note for this message, or nil when it does not call for a chart.
    /// A message with no Japanese in it gets the note in English, so the
    /// note does not turn the reply's language.
    public static func guide(for prompt: String) -> String? {
        let asks = words.contains { prompt.contains($0) }
            || prompt.range(of: english, options: .regularExpression) != nil
        guard asks else { return nil }
        let japanese = prompt.unicodeScalars.contains { (0x3040...0x30FF).contains($0.value) || (0x4E00...0x9FFF).contains($0.value) }
        return japanese ? chart : chartInEnglish
    }

    public static let chart = """
    （アプリからの補足：このアプリは回答の中のグラフを表示できます。数値の比較・推移・割合をグラフで示すと分かりやすい場合だけ、次の形式で書いてください。

    ```chart
    {"type":"bar","title":"題名","unit":"単位","data":[{"label":"項目A","value":120},{"label":"項目B","value":80}]}
    ```

    ・type は bar（比較）、line（推移）、pie（割合）のどれか
    ・value は数値だけ（単位やカンマを付けない）。確かでない数値を作らない
    ・複数の系列は "series":["2023年","2024年"] と各項目の "values":[120,135] で書く
    ・グラフの前後に短い説明を書く）
    """

    public static let chartInEnglish = """
    (A note from the app: this app can draw charts in replies. Only when a chart makes numbers easier to compare, follow over time or see as shares, write it like this:

    ```chart
    {"type":"bar","title":"Title","unit":"Unit","data":[{"label":"Item A","value":120},{"label":"Item B","value":80}]}
    ```

    - type is bar (compare), line (over time) or pie (shares)
    - value is a plain number, without a unit or commas. Do not make up numbers you are not sure of
    - for several series, write "series":["2023","2024"] and "values":[120,135] for each item
    - write a short explanation before or after the chart)
    """
}
