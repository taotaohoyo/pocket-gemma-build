import Foundation

/// Deleting conversations (設定 › 会話履歴, 1.1.0 (251)): what goes with
/// them and what stays. Only the chats chosen go. Their attachment files go
/// too, except any another chat or the composer still uses; the replies
/// that remain forget the deleted chats as Smart Memory sources.
public enum ChatDeletion {
    public struct Plan: Equatable, Sendable {
        /// The chats that stay, in their order.
        public var remaining: [ChatThread]
        /// The chats deleted, as asked and found.
        public var deleted: Set<UUID>
        /// Attachment files only the deleted chats used.
        public var files: Set<String>
    }

    /// `keeping`: attachment files in use elsewhere, such as the composer's.
    public static func plan(deleting ids: Set<UUID>, from threads: [ChatThread], keeping: Set<String> = []) -> Plan {
        let deleted = threads.filter { ids.contains($0.id) }
        var remaining = threads.filter { !ids.contains($0.id) }
        let gone = Set(deleted.map(\.id))
        let used = fileNames(in: remaining).union(keeping)
        let files = fileNames(in: deleted).subtracting(used)
        // A remaining reply keeps no pointer to a deleted chat.
        for ti in remaining.indices {
            for mi in remaining[ti].messages.indices {
                guard let recall = remaining[ti].messages[mi].memory else { continue }
                let left = recall.sources.filter { !gone.contains($0.thread) }
                if left.count != recall.sources.count {
                    remaining[ti].messages[mi].memory = left.isEmpty ? nil : MemoryRecall(sources: left)
                }
            }
        }
        return Plan(remaining: remaining, deleted: gone, files: files)
    }

    /// Every attachment file the chats keep, with the safe names only.
    public static func fileNames(in threads: [ChatThread]) -> Set<String> {
        Set(threads.flatMap(\.messages).flatMap(\.media).flatMap(\.fileNames).filter(ChatAttachment.isSafeFileName))
    }
}

/// A deletion's attachment files, written down before the conversations are
/// saved without the chats and crossed off once the files are gone: a
/// deletion cut short (the app ended, the phone restarted) finishes at the
/// next launch, and a file a chat uses again is never removed.
public struct DeletionJournal: Codable, Equatable, Sendable {
    public var threads: [UUID]
    public var files: [String]
    public init(threads: [UUID], files: [String]) { self.threads = threads; self.files = files }

    public static func load(_ url: URL) -> DeletionJournal? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(DeletionJournal.self, from: data)
    }
    public func save(_ url: URL) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(self).write(to: url, options: .atomic)
    }
    /// The files still to remove: none a saved chat uses.
    public func pending(given threads: [ChatThread], keeping: Set<String> = []) -> Set<String> {
        Set(files.filter(ChatAttachment.isSafeFileName))
            .subtracting(ChatDeletion.fileNames(in: threads)).subtracting(keeping)
    }
}

/// Moving the app's files into its private folders (1.1.0 (251)): models
/// leave Documents, which the Files app showed. Every item is renamed, not
/// copied, inside the app's own container (one volume): it is never in two
/// places nor in none, needs no free space, and a move cut short leaves
/// each item whole in one of the two folders. Nothing is ever deleted: an
/// item the destination already has a different one of stays where it is,
/// and the app reads from either folder (ModelLibrary.fallbackDirectories).
public enum StorageMigration {
    public struct Report: Codable, Equatable, Sendable {
        public var moved: [String] = []
        /// The destination had an item of the name: the source stays.
        public var keptInPlace: [String] = []
        /// The rename failed (left where it was) or could not be checked.
        public var failed: [String: String] = [:]
        public var sourceRemoved = false
        public init() {}
        public var isComplete: Bool { keptInPlace.isEmpty && failed.isEmpty }
        public var summary: String {
            "moved \(moved.count), kept \(keptInPlace.count), failed \(failed.count)" + (sourceRemoved ? ", source folder removed" : "")
        }
    }

    /// Moves every item of `source` into `destination` and checks each one
    /// arrived whole: the same file (its identity) of the same size. The
    /// source folder goes only once empty.
    public static func move(contentsOf source: URL, into destination: URL,
                            fileManager: FileManager = .default) -> Report {
        var report = Report()
        var isFolder: ObjCBool = false
        guard fileManager.fileExists(atPath: source.path, isDirectory: &isFolder), isFolder.boolValue else { return report }
        let keys: [URLResourceKey] = [.fileSizeKey, .fileResourceIdentifierKey, .isDirectoryKey, .isSymbolicLinkKey]
        let items: [URL]
        do {
            items = try fileManager.contentsOfDirectory(at: source, includingPropertiesForKeys: keys)
            try fileManager.createDirectory(at: destination, withIntermediateDirectories: true)
        } catch {
            report.failed[source.lastPathComponent] = error.localizedDescription
            return report
        }
        for item in items.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
            let name = item.lastPathComponent
            let target = destination.appendingPathComponent(name)
            if fileManager.fileExists(atPath: target.path) {
                report.keptInPlace.append(name)
                continue
            }
            let before = try? item.resourceValues(forKeys: Set(keys))
            do {
                try fileManager.moveItem(at: item, to: target)
            } catch {
                report.failed[name] = error.localizedDescription
                continue
            }
            // URLs cache resource values: read the moved item afresh.
            let after = try? URL(fileURLWithPath: target.path).resourceValues(forKeys: Set(keys))
            let sameSize = before?.fileSize == after?.fileSize
            let sameFile = before?.fileResourceIdentifier.map { identifier in
                (identifier as AnyObject).isEqual(after?.fileResourceIdentifier) } ?? true
            if after != nil && sameSize && sameFile && !fileManager.fileExists(atPath: item.path) {
                report.moved.append(name)
            } else {
                report.failed[name] = "not verified after the move"
            }
        }
        if (try? fileManager.contentsOfDirectory(atPath: source.path))?.isEmpty == true {
            report.sourceRemoved = (try? fileManager.removeItem(at: source)) != nil
        }
        return report
    }
}
