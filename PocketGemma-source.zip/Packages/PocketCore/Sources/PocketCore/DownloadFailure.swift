import Foundation

/// Why a model download stopped, in words that say what to do (1.1.0
/// (240)). Before 240 every stop read 「ダウンロードを完了できませんでした。」
/// with iOS's own text under it, or 「通信状態を確認して」 for any answer of
/// the Hub that was not a file, so a refused link, a broken connection and
/// a file that failed its SHA-256 check all looked alike.
public enum DownloadFailure: Equatable, Sendable {
    /// No network at all, or iOS keeps this app off it.
    case offline
    /// The connection broke or stopped answering part of the way.
    case connectionLost
    /// The Hub or its CDN could not be found or reached.
    case serverUnreachable
    /// The secure connection to the Hub failed (TLS, a date far off, a
    /// network that inspects traffic).
    case secureConnection
    /// The Hub answered, but not with the file.
    case http(Int)
    /// Nothing new arrived for too long, even after starting again.
    case stalled
    /// The phone has no room for the file.
    case noSpace
    /// The file arrived, but not the pinned size or SHA-256.
    case wrongSize(Int64, Int64)
    case wrongChecksum
    /// Anything else, by its error domain and code.
    case other(String, Int)

    public enum Kind: Sendable { case network, server, file, storage }

    public var kind: Kind {
        switch self {
        case .offline, .connectionLost, .serverUnreachable, .secureConnection, .stalled, .other: .network
        case .http: .server
        case .wrongSize, .wrongChecksum: .file
        case .noSpace: .storage
        }
    }

    public static func from(_ error: Error) -> DownloadFailure {
        if let validation = error as? ModelValidationError {
            switch validation {
            case .wrongSize(let actual, let expected): return .wrongSize(actual, expected)
            case .wrongChecksum: return .wrongChecksum
            }
        }
        let error = error as NSError
        switch (error.domain, error.code) {
        case (NSURLErrorDomain, NSURLErrorNotConnectedToInternet), (NSURLErrorDomain, NSURLErrorDataNotAllowed),
             (NSURLErrorDomain, NSURLErrorInternationalRoamingOff), (NSURLErrorDomain, NSURLErrorCallIsActive):
            return .offline
        case (NSURLErrorDomain, NSURLErrorNetworkConnectionLost), (NSURLErrorDomain, NSURLErrorTimedOut):
            return .connectionLost
        case (NSURLErrorDomain, NSURLErrorCannotFindHost), (NSURLErrorDomain, NSURLErrorCannotConnectToHost),
             (NSURLErrorDomain, NSURLErrorDNSLookupFailed):
            return .serverUnreachable
        case (NSURLErrorDomain, NSURLErrorSecureConnectionFailed), (NSURLErrorDomain, NSURLErrorServerCertificateHasBadDate),
             (NSURLErrorDomain, NSURLErrorServerCertificateUntrusted), (NSURLErrorDomain, NSURLErrorServerCertificateHasUnknownRoot),
             (NSURLErrorDomain, NSURLErrorServerCertificateNotYetValid), (NSURLErrorDomain, NSURLErrorClientCertificateRejected),
             (NSURLErrorDomain, NSURLErrorAppTransportSecurityRequiresSecureConnection):
            return .secureConnection
        case (NSURLErrorDomain, NSURLErrorCannotWriteToFile), (NSCocoaErrorDomain, NSFileWriteOutOfSpaceError),
             (NSPOSIXErrorDomain, Int(ENOSPC)):
            return .noSpace
        default:
            if let underlying = error.userInfo[NSUnderlyingErrorKey] as? NSError,
               underlying.domain == NSPOSIXErrorDomain, underlying.code == Int(ENOSPC) { return .noSpace }
            return .other(error.domain, error.code)
        }
    }

    /// The Hub's answer to a download, when it is not the file.
    public static func from(status: Int) -> DownloadFailure? {
        (200...299).contains(status) ? nil : .http(status)
    }

    /// Whether starting the same download again at once can help: a link
    /// that ran out, a broken connection. Not a file that is gone, a full
    /// phone or a phone with no network.
    public var retriesAtOnce: Bool {
        switch self {
        case .connectionLost, .stalled: true
        case .http(let status): [401, 403, 408, 410, 412, 416].contains(status) || status >= 500
        default: false
        }
    }

    /// What the alert and the model's card say. `keepsReceived`: what
    /// arrived is kept, and the next download goes on from there.
    public func message(keepsReceived: Bool = false) -> String {
        let text: String
        switch self {
        case .offline:
            text = String(localized: "通信エラー：インターネットに接続されていません。接続を確認して、もう一度ダウンロードしてください。")
        case .connectionLost:
            text = String(localized: "通信エラー：通信が途切れました。もう一度ダウンロードしてください。")
        case .serverUnreachable:
            text = String(localized: "通信エラー：配布元（Hugging Face）に接続できません。別のネットワークで試すか、しばらくしてからもう一度ダウンロードしてください。")
        case .secureConnection:
            text = String(localized: "通信エラー：配布元と安全に接続できませんでした。日付と時刻の設定や、VPN・通信を検査するアプリを確認してください。")
        case .http(let status) where status == 404 || status == 410:
            text = String(localized: "配布元のエラー：配布元にファイルが見つかりません（HTTP \(status)）。アプリの更新が必要です。")
        case .http(let status) where status == 401 || status == 403:
            text = String(localized: "配布元のエラー：配布元がファイルの受け取りを断りました（HTTP \(status)）。もう一度ダウンロードしてください。")
        case .http(429):
            text = String(localized: "配布元のエラー：配布元が混み合っています（HTTP 429）。しばらく待ってから、もう一度ダウンロードしてください。")
        case .http(let status) where status >= 500:
            text = String(localized: "配布元のエラー：配布元のサーバーで問題が起きています（HTTP \(status)）。しばらくしてから、もう一度ダウンロードしてください。")
        case .http(let status):
            text = String(localized: "配布元のエラー：配布元から予期しない応答がありました（HTTP \(status)）。もう一度ダウンロードしてください。")
        case .stalled:
            text = String(localized: "通信エラー：配布元からデータが届きません。Wi-Fiを切り替えるか、しばらくしてからもう一度ダウンロードしてください。")
        case .noSpace:
            text = String(localized: "空き容量不足：iPhoneの空き容量が足りません。不要なデータを削除してから、もう一度ダウンロードしてください。")
        case .wrongSize(let actual, let expected):
            text = String(localized: "ファイル確認エラー：受け取ったファイルの大きさが正しくありません（\(actual) / \(expected) バイト）。壊れたファイルは削除しました。もう一度ダウンロードしてください。")
        case .wrongChecksum:
            text = String(localized: "ファイル確認エラー：受け取ったファイルの内容が配布元のものと一致しません（SHA-256）。壊れたファイルは削除しました。もう一度ダウンロードしてください。")
        case .other(let domain, let code):
            text = String(localized: "通信エラー：ダウンロードを完了できませんでした（\(domain) \(code)）。もう一度ダウンロードしてください。")
        }
        return keepsReceived ? text + "\n" + String(localized: "受け取った分は残してあり、次は続きから受け取ります。") : text
    }

    /// The download record's short form.
    public var logText: String {
        switch self {
        case .offline: "通信なし"
        case .connectionLost: "通信が途切れた"
        case .serverUnreachable: "配布元に接続できない"
        case .secureConnection: "安全な接続に失敗"
        case .http(let status): "HTTP \(status)"
        case .stalled: "受信が止まった"
        case .noSpace: "空き容量不足"
        case .wrongSize(let actual, let expected): "大きさ違い \(actual)/\(expected)"
        case .wrongChecksum: "SHA-256不一致"
        case .other(let domain, let code): "\(domain) \(code)"
        }
    }
}

/// How long a running download has gone without a new byte (1.1.0 (240)).
/// On TestFlight 239 a download could sit at 0% with no error and no end;
/// ModelStore now reads this every two seconds while the app is on screen.
public struct DownloadStall: Sendable, Equatable {
    public private(set) var bytes: Int64
    public private(set) var since: Date

    /// After this long without a byte the card says it is waiting for the
    /// Hub; after `restartAfter`, the download starts again from what it has.
    public static let noticeAfter: TimeInterval = 20
    public static let restartAfter: TimeInterval = 45
    /// Starts again at most this often before it stops with `.stalled`.
    public static let restarts = 2

    public init(bytes: Int64 = 0, now: Date = Date()) {
        self.bytes = bytes
        self.since = now
    }

    /// Notes the bytes received now; returns how long none came.
    public mutating func idle(received: Int64, now: Date) -> TimeInterval {
        if received != bytes {
            bytes = received
            since = now
        }
        return now.timeIntervalSince(since)
    }
}
