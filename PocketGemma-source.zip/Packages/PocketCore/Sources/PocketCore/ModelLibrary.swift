import Foundation

/// Separate files and receipts for each catalog model. Keep the original E4B
/// paths so an AltStore update can reuse the already verified download.
public struct ModelLibrary: Sendable {
    public let directory: URL
    /// Receipts and partial downloads; kept out of a user-visible model folder.
    public let stateDirectory: URL
    /// Where the model files were before (Documents/Models until 1.1.0
    /// (250)): a file the move into `directory` left there (StorageMigration)
    /// is still read from there until it can be moved.
    public let fallbackDirectories: [URL]
    public init(directory: URL, stateDirectory: URL? = nil, fallbackDirectories: [URL] = []) {
        self.directory = directory
        self.stateDirectory = stateDirectory ?? directory
        self.fallbackDirectories = fallbackDirectories
    }
    /// The file in `directory`, or where an earlier version left it.
    public func modelURL(_ spec: ModelSpec) -> URL {
        let primary = directory.appendingPathComponent(spec.fileName)
        guard !fallbackDirectories.isEmpty, !FileManager.default.fileExists(atPath: primary.path) else { return primary }
        for folder in fallbackDirectories {
            let url = folder.appendingPathComponent(spec.fileName)
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return primary
    }
    /// Every place the file may be, for deleting it.
    public func allModelURLs(_ spec: ModelSpec) -> [URL] {
        ([directory] + fallbackDirectories).map { $0.appendingPathComponent(spec.fileName) }
    }
    public func pendingURL(_ spec: ModelSpec) -> URL {
        stateDirectory.appendingPathComponent(spec.id == ModelSpec.e4b.id ? "download.pending" : "\(spec.id).pending")
    }
    /// What a stopped download of the file had received (URLSession's
    /// resume data, 1.1.0 (240)): the next download goes on from there.
    public func resumeURL(_ spec: ModelSpec) -> URL {
        stateDirectory.appendingPathComponent("\(spec.id).resume")
    }
    public func receiptURL(_ spec: ModelSpec) -> URL {
        stateDirectory.appendingPathComponent(spec.id == ModelSpec.e4b.id ? "verified.txt" : "\(spec.id).verified")
    }
    /// Every file of the model checked and saved: LFM3-VL 2B needs its
    /// picture projector too (1.1.0 (234)).
    public func isInstalled(_ spec: ModelSpec) -> Bool { spec.files.allSatisfy(hasFile) }
    /// This one file checked and saved.
    public func hasFile(_ spec: ModelSpec) -> Bool {
        guard let receipt = try? String(contentsOf: receiptURL(spec), encoding: .utf8),
              receipt == spec.sha256,
              let attrs = try? FileManager.default.attributesOfItem(atPath: modelURL(spec).path),
              (attrs[.size] as? NSNumber)?.int64Value == spec.byteCount else { return false }
        return true
    }
    /// Call only after bounded SHA-256 validation of this model's pending file.
    public func installValidated(_ spec: ModelSpec) throws {
        let destination = directory.appendingPathComponent(spec.fileName)
        if FileManager.default.fileExists(atPath: destination.path) {
            _ = try FileManager.default.replaceItemAt(destination, withItemAt: pendingURL(spec))
        } else {
            try FileManager.default.moveItem(at: pendingURL(spec), to: destination)
        }
        try spec.sha256.write(to: receiptURL(spec), atomically: true, encoding: .utf8)
        // The checked file replaces one an earlier version left behind, as
        // it replaced one in the same folder before.
        for folder in fallbackDirectories {
            try? FileManager.default.removeItem(at: folder.appendingPathComponent(spec.fileName))
        }
    }
}
