import Foundation

/// A reply stopped partway, when the app left the screen (the GPU can't run
/// in the background), goes on from its last character. Asked in a new turn
/// to go on, E2B on the phone wrote the request back as its answer, or began
/// a new list inside bold it had left open (1.1.0 (133), 2026-10-23). So the
/// model is given its own unfinished turn instead: the question rendered with
/// the model's chat template up to where its reply begins, then the reply so
/// far. There is no new turn to answer; the model writes on.
public enum OpenTurn {
    /// A chat template that writes each message's text as it is, for a
    /// prompt already rendered with the model's own template. Messages come
    /// as a list (`messages`) or one at a time (`extra_context.message`),
    /// and their content as text or as parts.
    public static let rawTemplate = """
    {%- macro text(message) -%}
    {%- if message.content is string -%}{{ message.content }}
    {%- elif message.content is defined -%}{%- for part in message.content -%}{%- if part.type == 'text' -%}{{ part.text }}{%- endif -%}{%- endfor -%}
    {%- endif -%}
    {%- endmacro -%}
    {%- if extra_context is defined and extra_context.message is defined -%}{{ text(extra_context.message) }}
    {%- else -%}{%- for message in messages -%}{{ text(message) }}{%- endfor -%}
    {%- endif -%}
    """

    /// At most this many bytes of the reply are given back: enough to keep
    /// its thread. In the background, on the CPU, less (BackgroundRead).
    public static let tailBytes = 4000

    /// The question and the part of the reply the model reads again, sized
    /// with the app's two-bytes-per-token estimate so the reply's reserved
    /// space stays free. A long reply gives back its end, from the start of
    /// a line, with a code block's opening fence when it stopped inside one.
    public static func parts(prompt: String, reply: String, settings: GenerationSettings,
                             tailLimit: Int = tailBytes) -> (question: String, tail: String) {
        let question = GenerationSettings.prefix(prompt, byteLimit: settings.maxTokens / 4)
        let room = settings.inputByteBudget - question.utf8.count
        let tail = ReplyContinuation.tail(of: reply, byteLimit: max(256, min(tailLimit, room)))
        return (question, tail)
    }

    /// The prompt: the rendered question, which ends where the model's turn
    /// begins, and the reply so far. Nothing is added after the reply's last
    /// character, so the model goes on in the middle of a word, a bold
    /// phrase or a table row.
    public static func prompt(renderedQuestion: String, tail: String) -> String {
        renderedQuestion + tail
    }
}

/// A reply that goes on in the background runs on the CPU, which on the
/// phone reads about a tenth as fast as the GPU: E4B took 16.6 seconds to
/// read a chat's history again before its first character, after 11 seconds
/// of loading (1.1.0 (136), iPhone 18 Pro). There it reads back less, so it
/// starts writing sooner: the reply's end, and when nothing had been written
/// yet, only the chat's latest turns.
public enum BackgroundRead {
    /// About 500 Japanese characters of the reply so far.
    public static let tailBytes = 1500

    /// A quarter of the usual room for earlier turns, the latest kept first.
    public static func historyBudget(_ settings: GenerationSettings) -> Int {
        settings.inputByteBudget / 4
    }
}

/// What a notification says about a reply that ended while the app was not
/// on screen.
public enum ReplyNotice {
    public static let finishedTitle = "返信が届きました"
    public static let pausedTitle = "返信の途中で止まりました"
    public static let pausedBody = "Fieluaを開くと、続きを書きます。"
    public static let failedTitle = "返信を書けませんでした"
    public static let failedBody = "Fieluaを開いて、もう一度送ってください。"

    /// The reply's first words as plain text: Markdown marks, code, math and
    /// chart blocks and table rules left out, lines joined, cut short.
    public static func preview(of reply: String, limit: Int = 90) -> String {
        var words: [String] = [], inBlock = false
        for raw in reply.split(separator: "\n", omittingEmptySubsequences: true) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.hasPrefix("```") || line == "$$" { inBlock.toggle(); continue }
            guard !inBlock else { continue }
            // Table rules and horizontal rules.
            if !line.isEmpty, line.allSatisfy({ "|-:= *_".contains($0) }) { continue }
            var text = Substring(line)
            for mark in ["> ", "- ", "* ", "+ ", "・"] where text.hasPrefix(mark) { text = text.dropFirst(mark.count) }
            if text.hasPrefix("#") { text = text.drop(while: { $0 == "#" }).drop(while: { $0 == " " }) }
            var plain = String(text)
            for mark in ["**", "__", "`", "$"] { plain = plain.replacingOccurrences(of: mark, with: "") }
            plain = plain.replacingOccurrences(of: "|", with: " ")
                .split(separator: " ", omittingEmptySubsequences: true).joined(separator: " ")
            if !plain.isEmpty { words.append(plain) }
            if words.joined(separator: " ").count > limit { break }
        }
        let joined = words.joined(separator: " ")
        guard joined.count > limit else { return joined }
        return String(joined.prefix(limit)) + "…"
    }

    /// The share of iOS's progress bar for a reply that has this many
    /// characters. A reply's length isn't known while it is written, so the
    /// bar rises with every character, slower as the reply grows, and only
    /// fills when the reply ends; the text beside it gives the real count.
    public static func progressUnits(characters: Int, total: Int64 = 1000) -> Int64 {
        guard characters > 0 else { return 0 }
        let share = Double(characters) / Double(characters + 1500)
        return min(total - 50, max(1, Int64(Double(total - 50) * share)))
    }
}
