import Foundation

/// Sentences written one after another, as the app's language writes
/// them: nothing between them in Japanese and Chinese, a space in English
/// and Korean (the String Catalog's "sentence-gap"). Without the app's
/// catalog, as in PocketCore's tests, the Japanese way.
public enum Sentences {
    public static func join(_ parts: [String]) -> String {
        parts.filter { !$0.isEmpty }.joined(separator: gap)
    }

    public static var gap: String {
        String(localized: "sentence-gap", defaultValue: "",
               comment: "Put between two sentences: empty in Japanese and Chinese, one space in English and Korean.")
    }
}
