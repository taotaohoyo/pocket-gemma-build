# Reviewed 1.0.15 (16) candidate source
Pinned native LM resource sharing, explicit CPU vision kernels, and reviewed photo imports.
LFS inputs are verified; runtime/IPA validators reject missing or mismatched dependencies.
Native semantic inference and UI regression tests must pass before candidate IPA publication.
Physical-device image recognition remains unverified until tested on the user's device.
Stable AltStore source remains unchanged. No user media, histories, telemetry, or credentials.
