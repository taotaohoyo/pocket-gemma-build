# 1.0.13 (14)

The physical-device GPU/CPU result in 1.0.12 reached image prefill, then failed
inside XNNPACK runtime reshape at delegated node 2374. Allocation failure is
the enclosing LiteRT result, not proof that malloc or iOS memory limits failed.

This candidate keeps official LiteRT-LM 0.18.0, the same E2B/E4B model hashes,
the saved chat configuration and the existing structured image input.

- A bundled JPEG reaches the official Swift Conversation API directly, with
  no Photos/AttachmentStorage/Swift-side resize or re-encoding. Compare square
  and portrait fixtures at Context 4096 / Vision 280, MTP/thinking off.
- An independent, diagnostic-only LiteRT C API path copies the encoder or
  adapter section verbatim and invokes synthetic tensors with delegate mode
  or built-in optimized CPU kernels. CPU builtin mode bypasses XNNPACK. It
  does not feed these tensors back into the language model and must not be
  reported as a successful image conversation.
- Both paths release the normal chat engine before the test, use isolated
  temporary caches, preserve the model SHA256, and retain failures.
- Diagnostics distinguish XNNPACK runtime/external-value reshape, retain
  available internal operator messages and tensor layouts, record native
  status, section/fixture hashes and sample app memory every 200 ms.

The Swift LM API does not expose the LiteRT CPU kernel mode. A successful
component test alone is insufficient to adopt it as the production multimodal
backend. A compatible native LM change/build would still be required.

The bridge uses public headers from the pinned LiteRT source revision declared
by official 0.18.0. No replacement runtime, altered model metadata, hidden
fallback, or increased-memory entitlement is introduced. Physical-device
vision success remains unverified until the next IPA is tested on the phone.
