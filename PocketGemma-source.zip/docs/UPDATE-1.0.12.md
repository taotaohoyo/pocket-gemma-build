# 1.0.12 (13): independent vision backends and physical-device diagnosis

The reported 1.0.11 physical-device failure is in `conversation_creation`,
`vision_litert_compiled_model_executor.cc:313` / `litert_compiled_model.h:1961`,
with main GPU / vision GPU. The language decoder already works on this phone.
This differs from our prior simulator main-decoder Metal compilation failure.
Neither 70 tokens nor 280 tokens fixed the reported phone failure.

Changes:
- Preserve the main backend and independently save the vision encoder backend.
  Old settings migrate to vision CPU; existing main/token/sampling/prompt values
  remain. Users can explicitly compare GPU/GPU, GPU/CPU and CPU/CPU.
- Remove automatic token-budget retries. A failed configuration is retained
  without another configuration overwriting its outcome.
- Keep both pinned model files and hashes. Cache identities remain separate for
  each model/backend/context/token/MTP configuration.
- Record up to 24 attempts, memory by stage, sampler configuration, native
  errors, available operational stderr, named delegates/operators/delegate
  nodes, and the native framework's actual build receipt. Unspecified causes
  remain unknown. Node 1480 is not attributed to an underlying operator.
- Preserve original stderr output; do not substitute OCR or disable vision.
  Capture is bounded and filtered; OSLog/filtered/unavailable lines cannot be
  recovered. Diagnostics stay on the device until the user shares them.

Keep the same model, context and visual budget for comparison. Use a new
conversation and the same image for each attempt. No model re-download is
required. GPU/CPU is a candidate for the reported device, not yet a confirmed
physical-device fix. Native/CI outcomes are published separately after testing.

Primary evidence:
- [0.18 vision compiler](https://github.com/google-ai-edge/LiteRT-LM/blob/v0.18.0/runtime/executor/vision_litert_compiled_model_executor.cc#L218)
- [Swift backend API](https://github.com/google-ai-edge/LiteRT-LM/blob/v0.18.0/swift/Config.swift)
- [Official native package and checksum](https://github.com/google-ai-edge/LiteRT-LM/blob/v0.18.0/Package.swift)
- [Issue 2979: CPU/XNNPACK failure on a phone](https://github.com/google-ai-edge/LiteRT-LM/issues/2979)
- [Issue 2370: older runtime, modified E4B bundle and operator/delegation issues](https://github.com/google-ai-edge/LiteRT-LM/issues/2370)
- [Gallery maintainer: iOS source not released](https://github.com/google-ai-edge/gallery/issues/634)

The official release remains 0.18.0 as checked on 2026-10-14. Its binary target
archive is checksum-pinned by SwiftPM. The actual embedded framework is hashed
after Xcode builds the app and checked again against the IPA. The upstream
WORKSPACE's LiteRT ref is recorded as source provenance, not presented as a
binary's self-reported version. Full flags for the official prebuilt and the
Gallery iOS binary/build configuration are unavailable from public metadata.
