import ActivityKit
import Foundation

/// Model downloads shown as a Live Activity (Dynamic Island and Lock
/// Screen). Shared by the app, which starts and updates it, and the widget
/// extension, which draws it.
///
/// One activity carries every download: iOS shows only one activity of an
/// app in the Dynamic Island, so two models downloading at once share it.
struct ModelDownloadAttributes: ActivityAttributes {
    enum Phase: String, Codable, Hashable { case downloading, verifying, finished, failed }

    struct Download: Codable, Hashable {
        var modelID: String
        var modelName: String
        /// A Gemma model (until 1.1.0 (281) it showed the Google "G" logo).
        var showsGemmaLogo: Bool
        /// The model's symbol on the brand's yellow, for a model of a family
        /// without a series mark.
        var symbol: String
        var fraction: Double
        var phase: Phase
        /// The model's family (1.1.0 (282)): Gemma, Qwen and LFM show their
        /// series' mark, as in the app (SeriesMark). Optional, so an
        /// activity sent before it still reads.
        var family: String? = nil
        var percent: Int { Int((min(max(fraction, 0), 1) * 100).rounded(.down)) }
        var status: String {
            switch phase {
            case .downloading: return String(localized: "ダウンロード中")
            case .verifying: return String(localized: "ファイルを確認中")
            case .finished: return String(localized: "保存しました")
            case .failed: return String(localized: "ダウンロードできませんでした")
            }
        }
    }

    struct ContentState: Codable, Hashable {
        /// The first download, as 1.0.53-54 stored it.
        var fraction: Double
        var phase: Phase
        /// Every download now, in the order they started (from 1.0.55).
        var downloads: [Download]? = nil
    }

    /// The model the activity started with.
    var modelID: String
    var modelName: String
    var showsGemmaLogo: Bool
    var symbol: String
    /// The family of the model it started with (1.1.0 (282)).
    var family: String? = nil

    func downloads(in state: ContentState) -> [Download] {
        if let downloads = state.downloads, !downloads.isEmpty { return downloads }
        return [Download(modelID: modelID, modelName: modelName, showsGemmaLogo: showsGemmaLogo, symbol: symbol,
                         fraction: state.fraction, phase: state.phase, family: family)]
    }
}
