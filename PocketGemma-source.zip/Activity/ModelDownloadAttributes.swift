import ActivityKit
import Foundation

/// A model download shown as a Live Activity (Dynamic Island and Lock
/// Screen). Shared by the app, which starts and updates it, and the widget
/// extension, which draws it.
struct ModelDownloadAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        enum Phase: String, Codable, Hashable { case downloading, verifying, finished, failed }
        var fraction: Double
        var phase: Phase
        var percent: Int { Int((min(max(fraction, 0), 1) * 100).rounded(.down)) }
        var status: String {
            switch phase {
            case .downloading: return "ダウンロード中"
            case .verifying: return "ファイルを確認中"
            case .finished: return "保存しました"
            case .failed: return "ダウンロードできませんでした"
            }
        }
    }
    var modelID: String
    var modelName: String
    /// Gemma models show the Gemma logo, as in the app's model list; the
    /// others show this symbol on a colored circle.
    var showsGemmaLogo: Bool
    var symbol: String
}
