import ActivityKit
import Foundation

/// Model downloads shown as a Live Activity (Dynamic Island and Lock
/// Screen). Shared by the app, which starts and updates it, and the widget
/// extension, which draws it.
///
/// One activity carries every download: iOS shows only one activity of an
/// app in the Dynamic Island, so two models downloading at once share it.
struct ModelDownloadAttributes: ActivityAttributes {
    enum Phase: String, Codable, Hashable { case downloading, verifying, finished, failed }

    struct Download: Codable, Hashable {
        var modelID: String
        var modelName: String
        /// Gemma models show the Gemma logo, as in the app's model list; the
        /// others show this symbol on a colored circle.
        var showsGemmaLogo: Bool
        var symbol: String
        var fraction: Double
        var phase: Phase
        var percent: Int { Int((min(max(fraction, 0), 1) * 100).rounded(.down)) }
        var status: String {
            switch phase {
            case .downloading: return "ダウンロード中"
            case .verifying: return "ファイルを確認中"
            case .finished: return "保存しました"
            case .failed: return "ダウンロードできませんでした"
            }
        }
    }

    struct ContentState: Codable, Hashable {
        /// The first download, as 1.0.53-54 stored it.
        var fraction: Double
        var phase: Phase
        /// Every download now, in the order they started (from 1.0.55).
        var downloads: [Download]? = nil
    }

    /// The model the activity started with.
    var modelID: String
    var modelName: String
    var showsGemmaLogo: Bool
    var symbol: String

    func downloads(in state: ContentState) -> [Download] {
        if let downloads = state.downloads, !downloads.isEmpty { return downloads }
        return [Download(modelID: modelID, modelName: modelName, showsGemmaLogo: showsGemmaLogo, symbol: symbol,
                         fraction: state.fraction, phase: state.phase)]
    }
}
