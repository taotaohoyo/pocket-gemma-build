import ActivityKit
import SwiftUI
import WidgetKit

@main
struct PocketActivityBundle: WidgetBundle {
    var body: some Widget { ModelDownloadLiveActivity() }
}

/// A model download in the Dynamic Island: the model's mark on the left and
/// the percentage on the right. Pressing the island shows the name and a bar.
/// Two models downloading at once share the island: one model's mark and
/// percentage on each side, and a row for each when pressed.
struct ModelDownloadLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: ModelDownloadAttributes.self) { context in
            DownloadLockScreen(downloads: context.attributes.downloads(in: context.state))
        } dynamicIsland: { context in
            let downloads = context.attributes.downloads(in: context.state)
            let first = downloads[0]
            let second = downloads.count > 1 ? downloads[1] : nil
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    if second == nil {
                        DownloadMark(download: first, size: 40)
                            .padding(.leading, 6)
                    }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if second == nil {
                        DownloadFigure(download: first)
                            .font(.system(size: 24, weight: .semibold).monospacedDigit())
                            .foregroundStyle(.white)
                            .padding(.trailing, 6)
                    }
                }
                DynamicIslandExpandedRegion(.center) {
                    if second == nil {
                        VStack(spacing: 2) {
                            Text(first.modelName).font(.headline).lineLimit(1)
                            Text(first.status).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    } else {
                        Text("\(downloads.count)つのモデルをダウンロード中")
                            .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    if second == nil {
                        ProgressView(value: first.fraction)
                            .tint(DownloadMark.accent)
                            .padding(.horizontal, 6).padding(.top, 4)
                    } else {
                        VStack(spacing: 10) {
                            ForEach(downloads.prefix(2), id: \.modelID) { download in
                                DownloadRow(download: download)
                            }
                        }
                        .padding(.horizontal, 6).padding(.top, 2)
                    }
                }
            } compactLeading: {
                if second == nil {
                    DownloadMark(download: first, size: 22)
                } else {
                    DownloadPair(download: first)
                }
            } compactTrailing: {
                if let second {
                    DownloadPair(download: second)
                } else {
                    DownloadFigure(download: first)
                        .font(.system(size: 14, weight: .semibold).monospacedDigit())
                        .foregroundStyle(DownloadMark.accent)
                }
            } minimal: {
                DownloadRing(download: first)
            }
            .keylineTint(DownloadMark.accent)
        }
    }
}

/// One side of the island while two models download.
private struct DownloadPair: View {
    let download: ModelDownloadAttributes.Download
    var body: some View {
        HStack(spacing: 4) {
            DownloadMark(download: download, size: 20)
            DownloadFigure(download: download)
                .font(.system(size: 13, weight: .semibold).monospacedDigit())
                .foregroundStyle(DownloadMark.accent)
        }
    }
}

/// A download as a row, when the pressed island lists two.
private struct DownloadRow: View {
    let download: ModelDownloadAttributes.Download
    var body: some View {
        HStack(spacing: 10) {
            DownloadMark(download: download, size: 28)
            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .firstTextBaseline) {
                    Text(download.modelName).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Spacer(minLength: 6)
                    DownloadFigure(download: download)
                        .font(.system(size: 15, weight: .semibold).monospacedDigit())
                }
                ProgressView(value: download.fraction).tint(DownloadMark.accent)
            }
        }
    }
}

private struct DownloadFigure: View {
    let download: ModelDownloadAttributes.Download
    var body: some View {
        switch download.phase {
        case .finished: Image(systemName: "checkmark").accessibilityLabel(download.status)
        case .failed: Image(systemName: "exclamationmark").accessibilityLabel(download.status)
        case .downloading, .verifying: Text("\(download.percent)%")
        }
    }
}

private struct DownloadRing: View {
    let download: ModelDownloadAttributes.Download
    var body: some View {
        ZStack {
            Circle().stroke(DownloadMark.accent.opacity(0.28), lineWidth: 2.5)
            Circle()
                .trim(from: 0, to: download.phase == .downloading ? min(max(download.fraction, 0), 1) : 1)
                .stroke(download.phase == .failed ? Color.orange : DownloadMark.accent,
                        style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
                .rotationEffect(.degrees(-90))
            DownloadMark(download: download, size: 16)
        }
        .frame(width: 25, height: 25)
        .accessibilityElement()
        .accessibilityLabel("\(download.modelName) \(download.phase == .downloading ? "\(download.percent)%" : download.status)")
    }
}

private struct DownloadMark: View {
    static let accent = Color.blue
    let download: ModelDownloadAttributes.Download
    let size: CGFloat
    var body: some View {
        if download.showsGemmaLogo {
            Image("ModelLogo").resizable().interpolation(.high).scaledToFit()
                .frame(width: size * 0.82, height: size * 0.82)
                .frame(width: size, height: size)
                .accessibilityHidden(true)
        } else {
            Image(systemName: download.symbol)
                .font(.system(size: size * 0.44, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .background(LinearGradient(colors: [.indigo, .purple], startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: Circle())
                .accessibilityHidden(true)
        }
    }
}

private struct DownloadLockScreen: View {
    let downloads: [ModelDownloadAttributes.Download]
    var body: some View {
        VStack(alignment: .leading, spacing: downloads.count > 1 ? 10 : 12) {
            ForEach(downloads.prefix(2), id: \.modelID) { download in
                if downloads.count > 1 {
                    DownloadRow(download: download)
                } else {
                    HStack(spacing: 12) {
                        DownloadMark(download: download, size: 36)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(download.modelName).font(.headline).lineLimit(1)
                            Text(download.status).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 8)
                        DownloadFigure(download: download)
                            .font(.system(size: 22, weight: .semibold).monospacedDigit())
                    }
                    ProgressView(value: download.fraction).tint(DownloadMark.accent)
                }
            }
        }
        .padding(16)
    }
}
