import ActivityKit
import SwiftUI
import WidgetKit

@main
struct PocketActivityBundle: WidgetBundle {
    var body: some Widget { ModelDownloadLiveActivity() }
}

/// A model download in the Dynamic Island: the model's mark on the left and
/// the percentage on the right. Pressing the island shows the name and a bar.
/// Each model downloads with its own activity; while two run, iOS shows both
/// as small circles (one beside the island, one apart from it), each the
/// model's mark inside a ring that fills with the download.
struct ModelDownloadLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: ModelDownloadAttributes.self) { context in
            DownloadLockScreen(attributes: context.attributes, state: context.state)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    DownloadMark(attributes: context.attributes, size: 40)
                        .padding(.leading, 6)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    DownloadFigure(state: context.state)
                        .font(.system(size: 24, weight: .semibold).monospacedDigit())
                        .foregroundStyle(.white)
                        .padding(.trailing, 6)
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(spacing: 2) {
                        Text(context.attributes.modelName).font(.headline).lineLimit(1)
                        Text(context.state.status).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    ProgressView(value: context.state.fraction)
                        .tint(DownloadMark.accent)
                        .padding(.horizontal, 6).padding(.top, 4)
                }
            } compactLeading: {
                DownloadMark(attributes: context.attributes, size: 22)
            } compactTrailing: {
                DownloadFigure(state: context.state)
                    .font(.system(size: 14, weight: .semibold).monospacedDigit())
                    .foregroundStyle(DownloadMark.accent)
            } minimal: {
                DownloadRing(attributes: context.attributes, state: context.state)
            }
            .keylineTint(DownloadMark.accent)
        }
    }
}

private struct DownloadFigure: View {
    let state: ModelDownloadAttributes.ContentState
    var body: some View {
        switch state.phase {
        case .finished: Image(systemName: "checkmark").accessibilityLabel(state.status)
        case .failed: Image(systemName: "exclamationmark").accessibilityLabel(state.status)
        case .downloading, .verifying: Text("\(state.percent)%")
        }
    }
}

private struct DownloadRing: View {
    let attributes: ModelDownloadAttributes
    let state: ModelDownloadAttributes.ContentState
    var body: some View {
        ZStack {
            Circle().stroke(DownloadMark.accent.opacity(0.28), lineWidth: 2.5)
            Circle()
                .trim(from: 0, to: state.phase == .downloading ? min(max(state.fraction, 0), 1) : 1)
                .stroke(state.phase == .failed ? Color.orange : DownloadMark.accent,
                        style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
                .rotationEffect(.degrees(-90))
            DownloadMark(attributes: attributes, size: 16)
        }
        .frame(width: 25, height: 25)
        .accessibilityElement()
        .accessibilityLabel("\(attributes.modelName) \(state.phase == .downloading ? "\(state.percent)%" : state.status)")
    }
}

private struct DownloadMark: View {
    static let accent = Color.blue
    let attributes: ModelDownloadAttributes
    let size: CGFloat
    var body: some View {
        if attributes.showsGemmaLogo {
            Image("ModelLogo").resizable().interpolation(.high).scaledToFit()
                .frame(width: size * 0.82, height: size * 0.82)
                .frame(width: size, height: size)
                .accessibilityHidden(true)
        } else {
            Image(systemName: attributes.symbol)
                .font(.system(size: size * 0.44, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .background(LinearGradient(colors: [.indigo, .purple], startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: Circle())
                .accessibilityHidden(true)
        }
    }
}

private struct DownloadLockScreen: View {
    let attributes: ModelDownloadAttributes
    let state: ModelDownloadAttributes.ContentState
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                DownloadMark(attributes: attributes, size: 36)
                VStack(alignment: .leading, spacing: 2) {
                    Text(attributes.modelName).font(.headline).lineLimit(1)
                    Text(state.status).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer(minLength: 8)
                DownloadFigure(state: state)
                    .font(.system(size: 22, weight: .semibold).monospacedDigit())
            }
            ProgressView(value: state.fraction).tint(DownloadMark.accent)
        }
        .padding(16)
    }
}
