#!/bin/bash
# The layered app icon (scripts/make-glass-icon.py, user 2026-11-12) as iOS
# draws it: Xcode's own Icon Composer renderer (ictool) for every look and
# appearance, actool's compile of the .icon, and the looks on a simulator's
# home screen next to the current icon. Artifacts can't be fetched from the
# cloud sessions, so every picture is printed into the log as base64
# (ICON_IMG <name> <chunk> <data>).
set -uo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
out=build/icon
mkdir -p "$out"
python3 -m venv /tmp/iconenv && /tmp/iconenv/bin/pip install --quiet pillow numpy
PY=/tmp/iconenv/bin/python

emit() {
  base64 -i "$2" | tr -d '\n' | fold -w 8000 | awk -v n="$1" '{print "ICON_IMG", n, NR-1, $0}'
  echo "ICON_IMG_END $1"
}

xcode_app="${DEVELOPER_DIR%/Contents/Developer}"
ictool="$xcode_app/Contents/Applications/Icon Composer.app/Contents/Executables/ictool"
echo "ICTOOL: $ictool"
ls "$xcode_app/Contents/Applications/Icon Composer.app/Contents/Executables/" || true
"$ictool" --version || true
"$ictool" --help 2>&1 | head -60 || true

looks=(A B C)
renditions=(Default Dark TintedLight TintedDark ClearLight ClearDark)
for look in "${looks[@]}"; do
  for r in "${renditions[@]}"; do
    png="$out/$look-$r.png"
    "$ictool" "design/glass-icon/$look/AppIcon.icon" --export-image --output-file "$png" \
      --platform iOS --rendition "$r" --width 512 --height 512 --scale 1 > "$out/ictool.log" 2>&1 \
      || "$ictool" "design/glass-icon/$look/AppIcon.icon" --export-preview iOS "$r" 512 512 1 "$png" >> "$out/ictool.log" 2>&1 \
      || { echo "ICTOOL-FAIL $look $r"; tail -5 "$out/ictool.log"; continue; }
    echo "ICTOOL-OK $look $r $(sips -g pixelWidth -g pixelHeight -g hasAlpha "$png" | tail -3 | tr -s ' \n' ' ')"
    emit "$look-$r" "$png"
  done
done

# actool: the .icon alone, then with the asset catalog that still holds the
# flat AppIcon.appiconset.
xcrun actool --version | head -5 || true
mkdir -p "$out/actool-icon" "$out/actool-both"
xcrun actool design/glass-icon/A/AppIcon.icon --compile "$out/actool-icon" --platform iphonesimulator \
  --minimum-deployment-target 26.4 --app-icon AppIcon --target-device iphone --target-device ipad \
  --output-partial-info-plist "$out/actool-icon/partial.plist" --output-format human-readable-text \
  --notices --warnings --errors 2>&1 | tail -20
echo "ACTOOL-ICON files: $(ls "$out/actool-icon" | tr '\n' ' ')"
plutil -p "$out/actool-icon/partial.plist" || true
xcrun actool PocketGemma/Assets.xcassets design/glass-icon/A/AppIcon.icon --compile "$out/actool-both" --platform iphonesimulator \
  --minimum-deployment-target 26.4 --app-icon AppIcon --target-device iphone --target-device ipad \
  --output-partial-info-plist "$out/actool-both/partial.plist" --output-format human-readable-text \
  --notices --warnings --errors 2>&1 | tail -20
echo "ACTOOL-BOTH files: $(ls "$out/actool-both" | tr '\n' ' ')"
plutil -p "$out/actool-both/partial.plist" || true

# XcodeGen: how the .icon lands in the project when it sits in PocketGemma/.
brew install xcodegen > /dev/null 2>&1 || true
xcodegen --version || true
cp -R design/glass-icon/A/AppIcon.icon PocketGemma/AppIcon.icon
xcodegen generate --spec project.yml > /dev/null 2>&1 && grep -n "AppIcon.icon\|petal-1" PocketGemma.xcodeproj/project.pbxproj | head -20
rm -rf PocketGemma/AppIcon.icon PocketGemma.xcodeproj

# The home screen: a small app per look (and one with today's icon), side by
# side on the simulator's first page, light and dark.
sdk="$(xcrun --sdk iphonesimulator --show-sdk-path)"
mkdir -p "$out/stub"
cat > "$out/stub/main.swift" <<'SWIFT'
import SwiftUI
@main struct IconPreview: App { var body: some Scene { WindowGroup { Color.yellow } } }
SWIFT
xcrun --sdk iphonesimulator swiftc -parse-as-library -target arm64-apple-ios26.0-simulator -sdk "$sdk" \
  "$out/stub/main.swift" -o "$out/stub/IconPreview" || echo "STUB-COMPILE-FAIL"
mkdir -p "$out/now.xcassets"
cp -R PocketGemma/Assets.xcassets/AppIcon.appiconset "$out/now.xcassets/"
printf '{"info":{"author":"xcode","version":1}}\n' > "$out/now.xcassets/Contents.json"
make_app() { # id label source
  local app="$out/apps/$1.app"
  mkdir -p "$app" "$out/apps/$1-partial"
  cp "$out/stub/IconPreview" "$app/"
  xcrun actool "$3" --compile "$app" --platform iphonesimulator --minimum-deployment-target 26.0 \
    --app-icon AppIcon --target-device iphone --output-partial-info-plist "$out/apps/$1-partial/p.plist" \
    --output-format human-readable-text --errors 2>&1 | tail -5
  "$PY" - "$app/Info.plist" "$out/apps/$1-partial/p.plist" "$1" "$2" <<'PYEOF'
import plistlib, sys
info = {"CFBundleIdentifier": "com.fielua.iconpreview." + sys.argv[3].lower(), "CFBundleExecutable": "IconPreview",
        "CFBundleName": sys.argv[4], "CFBundleDisplayName": sys.argv[4], "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": "1.0", "CFBundleVersion": "1", "MinimumOSVersion": "26.0",
        "CFBundleSupportedPlatforms": ["iPhoneSimulator"], "UIDeviceFamily": [1], "UILaunchScreen": {},
        "CFBundleInfoDictionaryVersion": "6.0"}
try:
    info.update(plistlib.load(open(sys.argv[2], "rb")))
except Exception as e:
    print("PARTIAL-PLIST missing", e)
plistlib.dump(info, open(sys.argv[1], "wb"))
print("APP", sys.argv[3], info.get("CFBundleIcons"))
PYEOF
  codesign -f -s - "$app" > /dev/null 2>&1 || echo "CODESIGN-FAIL $1"
}
make_app NOW "いまのアイコン" "$out/now.xcassets"
for look in "${looks[@]}"; do make_app "$look" "$look 案" "design/glass-icon/$look/AppIcon.icon"; done

runtime_id="$(xcrun simctl list runtimes -j | "$PY" -c 'import json,sys; r=[x for x in json.load(sys.stdin)["runtimes"] if x.get("isAvailable") and x["name"].startswith("iOS")]; print(max(r,key=lambda x: tuple(map(int,x["version"].split("."))))["identifier"])')"
device_type="$(xcrun simctl list devicetypes -j | "$PY" -c 'import json,sys; d=json.load(sys.stdin)["devicetypes"]; p=[x for x in d if x["name"] in ("iPhone 17 Pro","iPhone 16 Pro")]; print(p[0]["identifier"])')"
udid="$(xcrun simctl create 'Fielua icon preview' "$device_type" "$runtime_id")"
echo "SIM $udid $runtime_id $device_type"
xcrun simctl boot "$udid"
python3 scripts/native-test-watchdog.py --timeout 480 --log "$out/boot.log" --metrics "$out/boot.jsonl" -- \
  xcrun simctl bootstatus "$udid" -b || echo "BOOT-SLOW"
xcrun simctl status_bar "$udid" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 \
  --batteryState charged --batteryLevel 100 || true
for id in NOW A B C; do xcrun simctl install "$udid" "$out/apps/$id.app" && echo "INSTALLED $id"; done
sleep 8
xcrun simctl io "$udid" screenshot "$out/home-first.png"
state="$HOME/Library/Developer/CoreSimulator/Devices/$udid/data/Library/SpringBoard/IconState.plist"
ls "$(dirname "$state")" || true
xcrun simctl shutdown "$udid"
"$PY" - "$state" <<'PYEOF'
import plistlib, sys
path = sys.argv[1]
try:
    state = plistlib.load(open(path, "rb"))
except Exception as e:
    print("ICONSTATE unreadable", e); sys.exit(0)
ours = ["com.fielua.iconpreview." + x for x in ("now", "a", "b", "c")]
pages = state.get("iconLists", [])
print("ICONSTATE pages", [len(p) for p in pages], "dock", state.get("buttonBar"))
print("ICONSTATE page1", pages[0] if pages else None)
for p in pages:
    for x in ours:
        while x in p: p.remove(x)
pages = [p for p in pages if p]
first = pages[0] if pages else []
moved = [x for x in first if isinstance(x, str)][:4]
for x in moved: first.remove(x)
pages[0] = ours + first
if len(pages) > 1: pages[1] = moved + pages[1]
else: pages.append(moved)
state["iconLists"] = pages
plistlib.dump(state, open(path, "wb"))
print("ICONSTATE rewritten", [len(p) for p in pages])
PYEOF
xcrun simctl boot "$udid"
python3 scripts/native-test-watchdog.py --timeout 300 --log "$out/boot2.log" --metrics "$out/boot2.jsonl" -- \
  xcrun simctl bootstatus "$udid" -b || echo "BOOT2-SLOW"
xcrun simctl status_bar "$udid" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 \
  --batteryState charged --batteryLevel 100 || true
xcrun simctl ui "$udid" appearance light
sleep 10
xcrun simctl io "$udid" screenshot "$out/home-light.png"
xcrun simctl ui "$udid" appearance dark
sleep 8
xcrun simctl io "$udid" screenshot "$out/home-dark.png"
xcrun simctl shutdown "$udid" || true
for shot in home-first home-light home-dark; do
  [ -f "$out/$shot.png" ] || continue
  "$PY" -c "from PIL import Image; import sys; im=Image.open(sys.argv[1]).convert('RGB'); print('SHOT', sys.argv[1], im.size); im.save(sys.argv[2], quality=90)" "$out/$shot.png" "$out/$shot.jpg"
  emit "$shot" "$out/$shot.jpg"
done
echo "ICON-CHECK-DONE"
