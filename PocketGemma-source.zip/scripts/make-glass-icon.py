"""Fielua's app icon as an iOS 26 layered icon (Icon Composer's .icon).

The flat icon (scripts/make-icon.py) is one picture. iOS 26 draws an icon
made of layers itself: each layer is a piece of Liquid Glass with its own
edge light, depth and shadow, and the system makes the dark, tinted and
clear looks from the same layers. Here each of the flower's five petals is
its own layer, drawn exactly as on the flat icon (same outlines, gold, gaps
and place), on the same paper / charcoal fill, so the flower keeps its
shape and colour and the glass comes from iOS (user, 2026-11-12: 「今のアイ
コンにプラスで写真アプリみたいにガラスみたいな雰囲気に」).

Writes <out>/AppIcon.icon/ (icon.json + Assets/petal-N.png) for one look,
or every look in LOOKS with --all. Needs numpy and Pillow.
"""
import argparse
import importlib.util
import json
import math
import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("make_icon", root / "scripts/make-icon.py")
mk = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(mk)

CANVAS = 1024  # Icon Composer's iOS canvas, in points


def petal_layers(size=CANVAS, gold=mk.ICON_GOLD, side=0.10, gap=0.010, widen=1.0, cut=True, S=4):
    """The five petals, each on its own transparent `size` square, where the
    flat icon puts them. `cut` keeps the flat icon's gaps between petals;
    `widen` > 1 makes each petal fuller across so neighbours overlap."""
    width = int(size * 0.66)
    lo, hi = mk.bounds()
    scale = width / (hi - lo)[0]
    mark = mk.icon_flower(width, *gold, gap=gap)
    x0 = (size - mark.size[0]) // 2
    y0 = int(round(size * mk.ICON_CENTRE - mk.mass_centre(mark)))
    W = H = size * S
    yy, xx = np.mgrid[0:H, 0:W] + 0.5
    X = (xx / S - x0) / scale + lo[0]
    Y = (yy / S - y0) / scale + lo[1]
    base, tip = (np.array(c, float) for c in gold)
    insides, colours, edges = [], [], []
    for i, mesh in enumerate(mk.FLOWER["meshes"]):
        pts = mk.outline(i, 96)
        a = math.radians(mesh["axis"])
        if widen != 1.0:
            c, s = math.cos(a), math.sin(a)
            R = np.array([[c, s], [-s, c]])
            q = pts @ R.T
            q[:, 1] *= widen
            pts = q @ R
        poly = [tuple(p) for p in ((pts - lo) * scale + [x0, y0]) * S]
        m = Image.new("L", (W, H), 0)
        ImageDraw.Draw(m).polygon(poly, fill=255)
        inside = np.asarray(m) > 127
        along = (math.cos(a), math.sin(a))
        across = (math.cos(a + math.pi / 2), math.sin(a + math.pi / 2))
        u = ((X * along[0] + Y * along[1]) - mesh["u"][0]) / (mesh["u"][1] - mesh["u"][0])
        v = ((X * across[0] + Y * across[1]) - mesh["v"][0]) / (mesh["v"][1] - mesh["v"][0])
        t = mk.smoothstep(u * 1.05)[..., None]
        colours.append(np.clip(base * (1 - t) + tip * t + (v - 0.5)[..., None] * side * 255, 0, 255))
        e = Image.new("L", (W, H), 0)
        ImageDraw.Draw(e).line(poly + [poly[0]], fill=255, width=max(1, int(gap * width * S / 0.66)), joint="curve")
        insides.append(inside)
        edges.append((np.asarray(e) > 127) & ~inside)
    layers = []
    for i in range(5):
        visible = insides[i].copy()
        if cut:  # as the flat icon: later petals cut a gap into earlier ones
            for k in range(i + 1, 5):
                visible &= ~edges[k]
        image = Image.fromarray(np.dstack([colours[i], visible * 255.0]).astype(np.uint8), "RGBA")
        layers.append(image.resize((size, size), Image.LANCZOS))
    return layers


def colour(rgb, alpha=1.0):
    return "srgb:" + ",".join(f"{c / 255:.5f}" for c in rgb) + f",{alpha:.5f}"


def gradient(top, bottom):
    return {"linear-gradient": [colour(top), colour(bottom)],
            "orientation": {"start": {"x": 0.5, "y": 0.0}, "stop": {"x": 0.5, "y": 1.0}}}


PAPER_FILL = gradient((0xFC, 0xF9, 0xF3), (0xF2, 0xEB, 0xDE))
NIGHT_FILL = gradient((0x2B, 0x27, 0x22), (0x14, 0x12, 0x10))

# The looks shown to the user (2026-11-12). Every look keeps the paper /
# charcoal fill; they differ in how much of a glass each petal is.
LOOKS = {
    # Each petal its own piece of glass, nearly solid: the flat icon's
    # shape and colour with an edge light and depth on every petal.
    "A": {"title": "ガラスの花びら", "widen": 1.0, "cut": True, "opacity": 1.0,
          "group": {"lighting": "individual", "specular": True,
                    "shadow": {"kind": "layer-color", "opacity": 0.5},
                    "translucency": {"enabled": True, "value": 0.2}}},
    # Same shape, clearer glass: the paper shows through the petals.
    "B": {"title": "透きとおる花びら", "widen": 1.0, "cut": True, "opacity": 0.9,
          "group": {"lighting": "individual", "specular": True,
                    "shadow": {"kind": "layer-color", "opacity": 0.5},
                    "translucency": {"enabled": True, "value": 0.55}}},
    # Petals a little fuller so neighbours overlap and the overlaps show a
    # deeper gold through the glass, as layered glass does.
    "C": {"title": "重なって透ける花びら", "widen": 1.2, "cut": False, "opacity": 0.85,
          "group": {"lighting": "individual", "specular": True,
                    "shadow": {"kind": "layer-color", "opacity": 0.5},
                    "translucency": {"enabled": True, "value": 0.5}}},
}


def manifest(look):
    # Icon Composer lists the front layer first: the petal drawn last (on
    # top in the flat icon) comes first.
    layers = [{"name": f"petal-{i}", "image-name": f"petal-{i}.png", "glass": True,
               "opacity": look["opacity"]} for i in range(5, 0, -1)]
    if look["opacity"] == 1.0:
        for layer in layers:
            del layer["opacity"]
    group = {"name": "Flower", "layers": layers, **look["group"]}
    return {
        "fill-specializations": [{"value": PAPER_FILL}, {"appearance": "dark", "value": NIGHT_FILL}],
        "groups": [group],
        "supported-platforms": {"squares": "shared"},
    }


def write(look, out):
    bundle = out / "AppIcon.icon"
    if bundle.exists():
        shutil.rmtree(bundle)
    (bundle / "Assets").mkdir(parents=True)
    for i, layer in enumerate(petal_layers(widen=look["widen"], cut=look["cut"]), 1):
        layer.save(bundle / "Assets" / f"petal-{i}.png", optimize=True)
    (bundle / "icon.json").write_text(json.dumps(manifest(look), indent=2, ensure_ascii=False) + "\n")
    return bundle


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--look", default="A", choices=sorted(LOOKS))
    parser.add_argument("--out", default=str(root / "PocketGemma"))
    parser.add_argument("--all", metavar="DIR", help="write every look to DIR/<look>/AppIcon.icon")
    args = parser.parse_args()
    if args.all:
        for name, look in LOOKS.items():
            print(write(look, Path(args.all) / name))
    else:
        print(write(LOOKS[args.look], Path(args.out)))


if __name__ == "__main__":
    main()
