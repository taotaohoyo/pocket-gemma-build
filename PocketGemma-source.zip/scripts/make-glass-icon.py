"""Fielua's app icon as an iOS 26 layered icon (Icon Composer's .icon).

The flat icon (scripts/make-icon.py) is one picture. iOS 26 draws an icon
made of layers itself: each layer is a piece of Liquid Glass with its own
edge light, depth and shadow, and the system makes the dark, tinted and
clear looks from the same layers. Here each of the flower's five petals is
its own layer, drawn exactly as on the flat icon (same outlines, gold, gaps
and place), on the same paper / charcoal fill, so the flower keeps its
shape and colour and the glass comes from iOS (user, 2026-11-12: 「今のアイ
コンにプラスで写真アプリみたいにガラスみたいな雰囲気に」).

The user chose look A (2026-11-12, 「A結構好きかも」): it was the app's icon
in 1.1.0 (266). iOS 27 draws glass layers its own way, so on the user's
iPhone look A did not look like the preview (see BAKE_BOX below); from
1.1.0 (267) the icon is look A as iOS 26 draws it, kept as a picture
(user, 2026-11-12: 「見本の絵をそのまま使う」) in an ordinary icon set.

Running this script with no arguments bakes Xcode's renders kept in
design/glass-icon/bake-renders/ into design/glass-icon/baked/AppIcon.icon
(the flower on plain layers), writes the app's
PocketGemma/Assets.xcassets/AppIcon.appiconset from it, and writes
FieluaIcon (the small home-screen icon in 起動時のチャット's preview) from
the renders in design/brand/glass/ (Icon Composer's ictool,
scripts/bake-glass-icon.sh and scripts/check-glass-icon.sh; there is no
ictool off a Mac). --look X --out DIR writes a glass look, --all DIR every
look for comparing.
Needs numpy and Pillow.
"""
import argparse
import importlib.util
import io
import json
import math
import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageCms, ImageDraw

root = Path(__file__).resolve().parents[1]
_spec = importlib.util.spec_from_file_location("make_icon", root / "scripts/make-icon.py")
mk = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(mk)

CANVAS = 1024  # Icon Composer's iOS canvas, in points


def petal_layers(size=CANVAS, gold=mk.ICON_GOLD, side=0.10, gap=0.010, widen=1.0, cut=True, glass=None, S=4):
    """The five petals, each on its own transparent `size` square, where the
    flat icon puts them. `cut` keeps the flat icon's gaps between petals;
    `widen` > 1 makes each petal fuller across so neighbours overlap.
    `glass` (gain, offset per channel) undoes the glass's own tint: iOS draws
    a petal colour c as about gain * c + offset, so the petals are painted
    (c - offset) / gain and come out in the flat icon's gold."""
    width = int(size * 0.66)
    lo, hi = mk.bounds()
    scale = width / (hi - lo)[0]
    mark = mk.icon_flower(width, *gold, gap=gap)
    x0 = (size - mark.size[0]) // 2
    y0 = int(round(size * mk.ICON_CENTRE - mk.mass_centre(mark)))
    W = H = size * S
    yy, xx = np.mgrid[0:H, 0:W] + 0.5
    X = (xx / S - x0) / scale + lo[0]
    Y = (yy / S - y0) / scale + lo[1]
    base, tip = (np.array(c, float) for c in gold)
    insides, colours, edges = [], [], []
    for i, mesh in enumerate(mk.FLOWER["meshes"]):
        pts = mk.outline(i, 96)
        a = math.radians(mesh["axis"])
        if widen != 1.0:
            c, s = math.cos(a), math.sin(a)
            R = np.array([[c, s], [-s, c]])
            q = pts @ R.T
            q[:, 1] *= widen
            pts = q @ R
        poly = [tuple(p) for p in ((pts - lo) * scale + [x0, y0]) * S]
        m = Image.new("L", (W, H), 0)
        ImageDraw.Draw(m).polygon(poly, fill=255)
        inside = np.asarray(m) > 127
        along = (math.cos(a), math.sin(a))
        across = (math.cos(a + math.pi / 2), math.sin(a + math.pi / 2))
        u = ((X * along[0] + Y * along[1]) - mesh["u"][0]) / (mesh["u"][1] - mesh["u"][0])
        v = ((X * across[0] + Y * across[1]) - mesh["v"][0]) / (mesh["v"][1] - mesh["v"][0])
        t = mk.smoothstep(u * 1.05)[..., None]
        c = base * (1 - t) + tip * t + (v - 0.5)[..., None] * side * 255
        if glass:
            c = (c - np.array(glass[1])) / np.array(glass[0])
        colours.append(np.clip(c, 0, 255))
        e = Image.new("L", (W, H), 0)
        ImageDraw.Draw(e).line(poly + [poly[0]], fill=255, width=max(1, int(gap * width * S / 0.66)), joint="curve")
        insides.append(inside)
        edges.append((np.asarray(e) > 127) & ~inside)
    layers = []
    for i in range(5):
        visible = insides[i].copy()
        if cut:  # as the flat icon: later petals cut a gap into earlier ones
            for k in range(i + 1, 5):
                visible &= ~edges[k]
        image = Image.fromarray(np.dstack([colours[i], visible * 255.0]).astype(np.uint8), "RGBA")
        layers.append(image.resize((size, size), Image.LANCZOS))
    return layers


def colour(rgb, alpha=1.0):
    return "srgb:" + ",".join(f"{c / 255:.5f}" for c in rgb) + f",{alpha:.5f}"


def gradient(top, bottom):
    return {"linear-gradient": [colour(top), colour(bottom)],
            "orientation": {"start": {"x": 0.5, "y": 0.0}, "stop": {"x": 0.5, "y": 1.0}}}


PAPER_FILL = gradient((0xFC, 0xF9, 0xF3), (0xF2, 0xEB, 0xDE))
NIGHT_FILL = gradient((0x2B, 0x27, 0x22), (0x14, 0x12, 0x10))

# How iOS's glass turns a petal's colour c into what shows, per channel
# (gain * c + offset), fitted to Xcode 26.6's renders of look A (translucency
# 0.2) on paper and on charcoal (run 43223801994, 2026-11-12; r 0.85-0.99).
GLASS_DAY = ((1.055, 0.935, 0.749), (-18.0, 19.3, 47.9))
GLASS_NIGHT = ((1.083, 0.945, 0.734), (-31.4, 10.8, 43.2))

# The looks shown to the user (2026-11-12). Every look keeps the paper /
# charcoal fill; they differ in how much of a glass each petal is.
LOOKS = {
    # Each petal its own piece of glass, nearly solid, painted so that
    # through the glass it shows the flat icon's gold (day and night sets):
    # the flat icon's shape and colour with an edge light and depth.
    "A": {"title": "ガラスの花びら", "widen": 1.0, "cut": True, "opacity": 1.0, "match": True,
          "group": {"lighting": "individual", "specular": True,
                    "shadow": {"kind": "layer-color", "opacity": 0.5},
                    "translucency": {"enabled": True, "value": 0.2}}},
    # Same shape, clearer glass: the paper shows through and the gold is
    # lighter. Less see-through at night, where the charcoal would dull it.
    "B": {"title": "透きとおる花びら", "widen": 1.0, "cut": True, "opacity": 1.0, "match": False,
          "group": {"lighting": "individual", "specular": True,
                    "shadow": {"kind": "layer-color", "opacity": 0.5},
                    "translucency": {"enabled": True, "value": 0.55},
                    "translucency-specializations": [
                        {"appearance": "dark", "value": {"enabled": True, "value": 0.25}}]}},
    # Petals a little fuller so neighbours overlap and the overlaps show
    # through the glass, as layered glass does; gold matched as in A.
    "C": {"title": "重なって透ける花びら", "widen": 1.12, "cut": False, "opacity": 0.9, "match": True,
          "group": {"lighting": "individual", "specular": True,
                    "shadow": {"kind": "layer-color", "opacity": 0.5},
                    "translucency": {"enabled": True, "value": 0.4}}},
}


def manifest(look):
    # Icon Composer lists the front layer first: the petal drawn last (on
    # top in the flat icon) comes first. With matched gold there is a day
    # set (hidden in dark) and a night set (shown only in dark).
    sets = [("", None)]
    if look["match"]:
        # A plain "hidden" key wins over its specializations (Xcode 26.6
        # drew no flower in dark), so both states go in the list.
        sets = [("", {"hidden-specializations": [{"value": False}, {"appearance": "dark", "value": True}]}),
                ("-night", {"hidden-specializations": [{"value": True}, {"appearance": "dark", "value": False}]})]
    layers = []
    for suffix, extra in sets:
        for i in range(5, 0, -1):
            layer = {"name": f"petal-{i}{suffix}", "image-name": f"petal-{i}{suffix}.png", "glass": True}
            if look["opacity"] != 1.0:
                layer["opacity"] = look["opacity"]
            layer.update(extra or {})
            layers.append(layer)
    group = {"name": "Flower", "layers": layers, **look["group"]}
    return {
        "fill-specializations": [{"value": PAPER_FILL}, {"appearance": "dark", "value": NIGHT_FILL}],
        "groups": [group],
        "supported-platforms": {"squares": "shared"},
    }


def write(look, out):
    bundle = out / "AppIcon.icon"
    if bundle.exists():
        shutil.rmtree(bundle)
    (bundle / "Assets").mkdir(parents=True)
    shape = {"widen": look["widen"], "cut": look["cut"]}
    if look["match"]:
        sets = [("", petal_layers(gold=mk.ICON_GOLD, glass=GLASS_DAY, **shape)),
                ("-night", petal_layers(gold=mk.ICON_GOLD_NIGHT, glass=GLASS_NIGHT, **shape))]
    else:
        sets = [("", petal_layers(**shape))]
    for suffix, layers in sets:
        for i, layer in enumerate(layers, 1):
            layer.save(bundle / "Assets" / f"petal-{i}{suffix}.png", optimize=True)
    (bundle / "icon.json").write_text(json.dumps(manifest(look), indent=2, ensure_ascii=False) + "\n")
    return bundle


def small_icons():
    """FieluaIcon, 64pt at 3x, light and dark: iOS's own drawing of the
    icon (design/brand/glass/, 512px with the squircle's corners clear), its
    corners filled with the tile so the app's rounded clip shows no gap."""
    glass = root / "design/brand/glass"
    small = root / "PocketGemma/Assets.xcassets/FieluaIcon.imageset"
    for name, rendition, tile in (("FieluaIcon.png", "Default", ((0xFC, 0xF9, 0xF3), (0xF2, 0xEB, 0xDE))),
                                  ("FieluaIcon-Dark.png", "Dark", ((0x2B, 0x27, 0x22), (0x14, 0x12, 0x10)))):
        render = Image.open(glass / f"AppIcon-{rendition}.png").convert("RGBA")
        base = mk.tile(render.size[0], *tile)
        base.alpha_composite(render)
        base.convert("RGB").resize((192, 192), Image.LANCZOS).save(small / name, optimize=True)
        print(small / name)


# 1.1.0 (267): look A as iOS 26 draws it, kept as a picture. iOS 27 draws
# glass layers its own way: a sharper edge light with dark parts, grey ring
# shadows and less blur (WWDC26 session 8012). On the user's iPhone (iOS
# 27.2, 2026-11-12, 「なんかサンプル画像と違うくない？」) look A showed thin
# dark rims, a grey shadow and no gold glow, so it no longer matched the
# preview the user chose. The previewed look only stays if the flower is
# that iOS 26 render itself, on a plain (not glass) layer. bake_sources()
# writes look A on its own fills and on contrasting ones, with and without
# the flower; scripts/bake-glass-icon.sh renders them with Xcode 26.6's
# ictool; bake() pulls the flower and its glow out of those renders
# (matting against two backgrounds), so that on the paper / charcoal fill
# it is exactly the iOS 26 render. The system still draws the fill, the
# tile's edge and the dark, tinted and clear looks.
BAKE_BOX = (112, 112, 912, 912)  # holds the flower and its glow, canvas px
ALT_FILLS = ((0, 0, 0), (255, 255, 255))  # day, night: far from paper / charcoal
APPEARANCES = (("Default", "day"), ("Dark", "night"))


def bake_sources(out):
    """Look A on its fills and on ALT_FILLS (A-real, A-alt), and the same
    fills with nothing on them (fill-real, fill-alt)."""
    out = Path(out)
    real = write(LOOKS["A"], out / "A-real")
    alt = write(LOOKS["A"], out / "A-alt")
    data = json.loads((alt / "icon.json").read_text())
    data["fill-specializations"] = [{"value": gradient(ALT_FILLS[0], ALT_FILLS[0])},
                                    {"appearance": "dark", "value": gradient(ALT_FILLS[1], ALT_FILLS[1])}]
    (alt / "icon.json").write_text(json.dumps(data, indent=2) + "\n")
    for name, source in (("fill-real", real), ("fill-alt", alt)):
        bundle = out / name / "AppIcon.icon"
        if bundle.exists():
            shutil.rmtree(bundle)
        (bundle / "Assets").mkdir(parents=True)
        Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0)).save(bundle / "Assets/blank.png")
        data = json.loads((source / "icon.json").read_text())
        data["groups"] = [{"name": "Blank", "layers": [{"name": "blank", "image-name": "blank.png", "glass": False}]}]
        (bundle / "icon.json").write_text(json.dumps(data, indent=2) + "\n")
        print(bundle)


def matte(s1, s2, b1, b2):
    """The layer (straight RGBA) that over background b1 gives s1, with its
    coverage from how s1 and s2 differ against b1 and b2 (float arrays).
    The coverage is raised where s1 needs more of the layer than that, e.g.
    the glow, which tints the paper but leaves black as it is."""
    d = b1 - b2
    a = 1 - ((s1 - s2) * np.sign(d)).sum(-1) / np.maximum(np.abs(d).sum(-1), 1)
    # Renders of the same fill differ by up to 3 levels (dither, and sRGB vs
    # P3 output): that much is the fill itself, not the layer.
    tol = 3
    darker = np.clip(b1 - s1 - tol, 0, None) / np.maximum(b1, 1)
    lighter = np.clip(s1 - b1 - tol, 0, None) / np.maximum(255 - b1, 1)
    a = np.clip(np.maximum(a, np.maximum(darker, lighter).max(-1)), 0, 1)
    a[(np.abs(s1 - b1).max(-1) <= tol) | (a < 1.5 / 255)] = 0
    p = np.clip(s1 - b1 * (1 - a)[..., None], 0, 255 * a[..., None])
    rgb = np.where(a[..., None] > 0, p / np.maximum(a[..., None], 1e-6), 0)
    return np.dstack([np.clip(rgb, 0, 255), a * 255])


def crop(path, p3):
    """A render's flower box as Display P3 numbers. ictool tags most renders
    Display P3 and leaves some untagged (sRGB); the preview pictures showed
    those P3 numbers as they are, so the baked layers keep them as numbers
    and the icon shows the previewed colours (the flat icon's gold)."""
    image = Image.open(path)
    if not image.info.get("icc_profile"):
        image = ImageCms.profileToProfile(image.convert("RGB"), ImageCms.createProfile("sRGB"), p3,
                                          renderingIntent=ImageCms.Intent.RELATIVE_COLORIMETRIC, outputMode="RGB")
    image = image.convert("RGB")
    if image.size == (CANVAS, CANVAS):  # a whole render, not one already cropped to the box
        image = image.crop(BAKE_BOX)
    return np.asarray(image, float)


def bake(renders, out):
    """PocketGemma/AppIcon.icon from Xcode's renders of the bake_sources()
    bundles (renders/<bundle>-<Default|Dark>.png, 1024 px)."""
    renders, out = Path(renders), Path(out)
    bundle = out / "AppIcon.icon"
    if bundle.exists():
        shutil.rmtree(bundle)
    (bundle / "Assets").mkdir(parents=True)
    tagged = [Image.open(f).info.get("icc_profile") for f in sorted(renders.glob("*.png"))]
    p3 = ImageCms.ImageCmsProfile(io.BytesIO(next(t for t in tagged if t)))
    for rendition, name in APPEARANCES:
        s1, s2, b1, b2 = (crop(renders / f"{b}-{rendition}.png", p3) for b in ("A-real", "A-alt", "fill-real", "fill-alt"))
        layer = matte(s1, s2, b1, b2)
        x0, y0, x1, y1 = BAKE_BOX
        edge = np.concatenate([layer[0, :, 3], layer[-1, :, 3], layer[:, 0, 3], layer[:, -1, 3]])
        back = b1 * (1 - layer[..., 3:] / 255) + layer[..., :3] * layer[..., 3:] / 255
        print(f"BAKE {name}: coverage max {layer[..., 3].max():.0f}, at the box edge max {edge.max():.0f}; "
              f"over the fill vs render: mean {np.abs(back - s1).mean():.3f}, max {np.abs(back - s1).max():.1f}")
        full = np.zeros((CANVAS, CANVAS, 4))
        full[y0:y1, x0:x1] = layer
        Image.fromarray(np.round(full).astype(np.uint8), "RGBA").save(bundle / "Assets" / f"flower-{name}.png", optimize=True)
    data = baked_manifest()
    (bundle / "icon.json").write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
    print(bundle)
    return bundle


def baked_manifest():
    # Plain layers: no glass, edge light, shadow or see-through of iOS's own,
    # as all of that is in the picture already. Day picture hidden in dark,
    # night picture shown only in dark (both states listed, see manifest()).
    layers = [{"name": "flower", "image-name": "flower-day.png", "glass": False,
               "hidden-specializations": [{"value": False}, {"appearance": "dark", "value": True}]},
              {"name": "flower-night", "image-name": "flower-night.png", "glass": False,
               "hidden-specializations": [{"value": True}, {"appearance": "dark", "value": False}]}]
    group = {"name": "Flower", "layers": layers, "specular": False,
             "shadow": {"kind": "none", "opacity": 0.5}, "translucency": {"enabled": False, "value": 0.5}}
    return {"fill-specializations": [{"value": PAPER_FILL}, {"appearance": "dark", "value": NIGHT_FILL}],
            "groups": [group], "supported-platforms": {"squares": "shared"}}


def picture_icons(bundle, out):
    """The app's AppIcon.appiconset from the baked layers: the flower on the
    paper / charcoal tile (the same tile as the flat icon), and its
    lightness on black for the tinted look. A plain .icon of the same
    layers had ragged, stepped petal edges on the iOS 26.5 simulator's
    home screen (2026-11-12, runs 43239463682 and 43245210869), while
    ictool drew it smooth; this icon set showed smooth edges there, and the
    flat icon's icon set of the same kind showed right on the user's
    iPhone (iOS 27). (Icons in the home screen's right column took on a
    little of the blue wallpaper behind them, flat icon too: not a colour
    fault of the icon.)"""
    assets = Path(bundle) / "Assets"
    icons = Path(out)
    icons.mkdir(parents=True, exist_ok=True)
    for name, layer, top, bottom in (("AppIcon.png", "flower-day.png", (0xFC, 0xF9, 0xF3), (0xF2, 0xEB, 0xDE)),
                                     ("AppIcon-Dark.png", "flower-night.png", (0x2B, 0x27, 0x22), (0x14, 0x12, 0x10))):
        base = mk.tile(CANVAS, top, bottom)
        base.alpha_composite(Image.open(assets / layer).convert("RGBA"))
        base.convert("RGB").save(icons / name, optimize=True)
    flower = np.asarray(Image.open(assets / "flower-day.png").convert("RGBA"), float)
    lightness = (0.2126 * flower[..., 0] + 0.7152 * flower[..., 1] + 0.0722 * flower[..., 2]) * flower[..., 3] / 255
    Image.fromarray(np.clip(lightness, 0, 255).astype(np.uint8), "L").convert("RGB").save(
        icons / "AppIcon-Tinted.png", optimize=True)
    shutil.copy(root / "design/brand/flat-icon/AppIcon.appiconset/Contents.json", icons / "Contents.json")
    print(icons)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--look", choices=sorted(LOOKS), help="write this glass look to --out")
    parser.add_argument("--out", default=str(root / "PocketGemma"))
    parser.add_argument("--all", metavar="DIR", help="write every look to DIR/<look>/AppIcon.icon")
    parser.add_argument("--bake-sources", metavar="DIR", help="write the bundles bake() needs rendered")
    parser.add_argument("--bake", metavar="RENDERS", help="write the picture-petal icon from their renders")
    args = parser.parse_args()
    if args.bake_sources:
        bake_sources(args.bake_sources)
    elif args.bake:
        bake(args.bake, Path(args.out))
    elif args.all:
        for name, look in LOOKS.items():
            print(write(look, Path(args.all) / name))
    elif args.look:
        print(write(LOOKS[args.look], Path(args.out)))
    else:
        baked = bake(root / "design/glass-icon/bake-renders", root / "design/glass-icon/baked")
        picture_icons(baked, root / "PocketGemma/Assets.xcassets/AppIcon.appiconset")
        small_icons()


if __name__ == "__main__":
    main()
