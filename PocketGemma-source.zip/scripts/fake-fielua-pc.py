#!/usr/bin/env python3
"""A stand-in for Fielua for Windows, for the pc-link UI check (1.1.0 (253)).

Speaks Fielua Link v1 as the PC does (fielua-windows src-tauri/src/link):
TLS 1.3 only, its own self-signed P-256 certificate, the connection code
with the commitment and the six digits, approval after a few seconds (as
the PC's person would), the Bearer token, the model list, NDJSON replies
with heartbeats, cancel, and unpair. It is not an AI: its replies say how
many turns they were given, so the check sees which turns the iPhone sent.
From 1.1.0 (254): registering by choosing the PC in the iPhone's list
(method "select", no code, approved 6 seconds after the digits so the
check can say they differ first), the iPhone withdrawing a registration
(/v1/pair/cancel), the same iPhone starting over, and its addresses in
/v1/status, as the PC's 「Fielua Link 接続体験改善」 does.

usage: fake-fielua-pc.py <dir for its certificate> [--port 47870] [--code 24681357]

Prints FAKE-PC lines: READY, BEGIN, SAS (the six digits, which check-ui.sh
compares with the iPhone's PC-LINK number lines), APPROVED, CANCELLED,
CHAT, STOPPED, GONE, UNPAIRED, REFUSED. Listens on 127.0.0.1 only.
"""
import argparse
import base64
import hashlib
import hmac
import http.server
import json
import os
import secrets
import socketserver
import ssl
import subprocess
import sys
import threading
import time

PC_ID = 'fakepc0123456789'
PC_NAME = 'テスト用PC'
MODELS = [
    {'name': 'gemma3:4b', 'sizeBytes': 3_338_801_804, 'family': 'gemma3', 'parameterSize': '4.3B', 'quantization': 'Q4_K_M'},
    {'name': 'qwen3:8b', 'sizeBytes': 5_225_376_047, 'family': 'qwen3', 'parameterSize': '8.2B', 'quantization': 'Q4_K_M'},
]


def b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()


def unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))


def say(*parts):
    print('FAKE-PC', *parts, flush=True)


class State:
    def __init__(self, code: str, fingerprint: bytes):
        self.lock = threading.Lock()
        self.code = code
        self.fingerprint = fingerprint
        self.session = None  # dict
        self.tokens = {}  # sha256 hex -> device id
        self.cancelled = set()


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    state: State = None

    def log_message(self, fmt, *args):
        pass

    # ---- plumbing

    def body(self):
        length = int(self.headers.get('Content-Length') or 0)
        if length > 300_000:
            return None
        raw = self.rfile.read(length) if length else b''
        try:
            return json.loads(raw or b'{}')
        except ValueError:
            return None

    def send_json(self, status, payload):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def error(self, status, code):
        self.send_json(status, {'error': code})

    def device(self):
        auth = self.headers.get('Authorization') or ''
        if not auth.startswith('Bearer '):
            return None
        digest = hashlib.sha256(b'fielua-link-token-v1' + auth[7:].strip().encode()).hexdigest()
        with self.state.lock:
            for known, device in self.state.tokens.items():
                if hmac.compare_digest(known, digest):
                    return device
        return None

    # ---- routes

    def do_GET(self):
        if self.path == '/v1/status':
            if not self.device():
                say('REFUSED', self.path)
                return self.error(401, 'unauthorized')
            return self.send_json(200, {'protocol': 1, 'pcId': PC_ID, 'pcName': PC_NAME, 'appVersion': '0.1.0',
                                        'engine': {'running': True, 'version': '0.0-fake'},
                                        'addresses': ['127.0.0.1']})
        if self.path == '/v1/models':
            if not self.device():
                say('REFUSED', self.path)
                return self.error(401, 'unauthorized')
            return self.send_json(200, {'models': MODELS})
        self.error(404, 'notFound')

    def do_POST(self):
        body = self.body()
        if body is None:
            return self.error(400, 'badRequest')
        route = {
            '/v1/pair/begin': self.begin, '/v1/pair/confirm': self.confirm, '/v1/pair/wait': self.wait,
            '/v1/pair/cancel': self.pair_cancel,
            '/v1/chat': self.chat, '/v1/chat/cancel': self.cancel, '/v1/unpair': self.unpair,
        }.get(self.path)
        if not route:
            return self.error(404, 'notFound')
        route(body)

    def begin(self, body):
        device = body.get('deviceId')
        with self.state.lock:
            s = self.state.session
            # One registration at a time; the same iPhone may start over.
            if s and s['state'] == 'pending' and s['device'] != device:
                return self.error(409, 'busy')
        if body.get('method') == 'select' and 'code' not in body and 'secret' not in body:
            method = 'select'
        elif 'code' in body:
            if not hmac.compare_digest(str(body.get('code') or ''), self.state.code):
                say('REFUSED', 'wrong code')
                return self.error(403, 'badCredential')
            method = 'code'
        else:
            return self.error(400, 'badRequest')
        server_nonce = secrets.token_bytes(32)
        session = b64(secrets.token_bytes(16))
        with self.state.lock:
            self.state.session = {'id': session, 'device': device, 'name': body.get('deviceName'), 'method': method,
                                  'serverNonce': server_nonce, 'confirmedAt': None, 'state': 'pending'}
        say('BEGIN', f'method={method}')
        self.send_json(200, {'protocol': 1, 'session': session,
                             'commit': b64(hashlib.sha256(b'fielua-link-commit-v1' + server_nonce).digest())})

    def confirm(self, body):
        with self.state.lock:
            s = self.state.session
            if not s or s['id'] != body.get('session') or s['state'] != 'pending':
                return self.error(404, 'noSession')
            client_nonce = unb64(str(body.get('clientNonce') or ''))
            if len(client_nonce) != 32:
                return self.error(400, 'badRequest')
            s['confirmedAt'] = time.time()
            digest = hashlib.sha256(b'fielua-link-sas-v1' + self.state.fingerprint + client_nonce + s['serverNonce']).digest()
            n = int.from_bytes(digest[:4], 'big') % 1_000_000
            say('SAS', f'{n // 1000:03d} {n % 1000:03d}')
            nonce = s['serverNonce']
        self.send_json(200, {'serverNonce': b64(nonce), 'pcId': PC_ID, 'pcName': PC_NAME})

    def wait(self, body):
        deadline = time.time() + 25
        while time.time() < deadline:
            with self.state.lock:
                s = self.state.session
                if not s or s['id'] != body.get('session'):
                    return self.send_json(200, {'state': 'expired'})
                if s['state'] == 'denied':
                    self.state.session = None
                    return self.send_json(200, {'state': 'denied'})
                if s['confirmedAt'] is None:
                    return self.error(409, 'notConfirmed')
                # The PC's person compares the digits and approves (a little
                # later for a PC chosen in the list, so the check can say the
                # digits differ first).
                if time.time() - s['confirmedAt'] >= (6 if s['method'] == 'select' else 4):
                    token = b64(secrets.token_bytes(32))
                    self.state.tokens[hashlib.sha256(b'fielua-link-token-v1' + token.encode()).hexdigest()] = s['device']
                    self.state.session = None
                    say('APPROVED', s['name'])
                    return self.send_json(200, {'state': 'approved', 'token': token, 'deviceId': s['device'],
                                                'pcId': PC_ID, 'pcName': PC_NAME})
            time.sleep(0.25)
        self.send_json(200, {'state': 'pending'})

    def pair_cancel(self, body):
        # The iPhone withdrew (the digits differed, or it left): the
        # approval closes; nothing is registered.
        with self.state.lock:
            s = self.state.session
            if not s or s['id'] != body.get('session'):
                return self.send_json(200, {'state': 'expired'})
            s['state'] = 'denied'
            say('CANCELLED', f"method={s['method']}")
        self.send_json(200, {'state': 'cancelled'})

    def chunk(self, payload) -> bool:
        data = (json.dumps(payload, ensure_ascii=False) + '\n').encode()
        try:
            self.wfile.write(f'{len(data):x}\r\n'.encode() + data + b'\r\n')
            self.wfile.flush()
            return True
        except OSError:
            return False

    def chat(self, body):
        if not self.device():
            say('REFUSED', self.path)
            return self.error(401, 'unauthorized')
        messages = body.get('messages') or []
        model = body.get('model')
        request = str(body.get('requestId') or '')
        if not messages or messages[-1].get('role') != 'user' or any(m.get('role') not in ('user', 'assistant') for m in messages):
            return self.error(400, 'badRequest')
        say('CHAT', f'model={model} turns={len(messages)} roles={",".join(m["role"][0] for m in messages)}')
        self.send_response(200)
        self.send_header('Content-Type', 'application/x-ndjson')
        self.send_header('Transfer-Encoding', 'chunked')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        if model not in [m['name'] for m in MODELS]:
            self.chunk({'type': 'failed', 'error': {'kind': 'modelNotFound', 'detail': str(model)}})
            return self.end_stream()
        self.chunk({'type': 'started', 'model': model})
        time.sleep(0.8)
        self.chunk({'type': 'waiting'})
        question = messages[-1].get('content', '')
        if '長く' in question:
            pieces = [f'長い返信の{i}文目です。' for i in range(1, 121)]
            pause = 0.25
        else:
            pieces = ['テスト用のPCが', '答えています。', f'受け取った発言は{len(messages)}件です。']
            pause = 0.3
        for piece in pieces:
            with self.state.lock:
                stopped = request in self.state.cancelled
            if stopped:
                say('STOPPED', 'by cancel')
                self.chunk({'type': 'stopped'})
                return self.end_stream()
            if not self.chunk({'type': 'delta', 'content': piece, 'thinking': ''}):
                say('GONE', 'the iPhone closed the connection')
                return
            time.sleep(pause)
        self.chunk({'type': 'done', 'stats': {'outputTokens': len(pieces) * 4, 'evalMs': int(len(pieces) * pause * 1000)}})
        self.end_stream()

    def end_stream(self):
        try:
            self.wfile.write(b'0\r\n\r\n')
            self.wfile.flush()
        except OSError:
            pass

    def cancel(self, body):
        if not self.device():
            return self.error(401, 'unauthorized')
        with self.state.lock:
            self.state.cancelled.add(str(body.get('requestId') or ''))
        say('CANCEL', body.get('requestId'))
        self.send_json(200, {'ok': True})

    def unpair(self, body):
        auth = self.headers.get('Authorization') or ''
        digest = hashlib.sha256(b'fielua-link-token-v1' + auth[7:].strip().encode()).hexdigest()
        with self.state.lock:
            removed = self.state.tokens.pop(digest, None)
        if removed is None:
            return self.error(401, 'unauthorized')
        say('UNPAIRED', removed)
        self.send_json(200, {'ok': True})


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('dir')
    parser.add_argument('--port', type=int, default=47870)
    parser.add_argument('--code', default='24681357')
    args = parser.parse_args()
    os.makedirs(args.dir, exist_ok=True)
    key, cert = os.path.join(args.dir, 'key.pem'), os.path.join(args.dir, 'cert.pem')
    subprocess.run(['openssl', 'ecparam', '-name', 'prime256v1', '-genkey', '-noout', '-out', key], check=True)
    subprocess.run(['openssl', 'req', '-new', '-x509', '-key', key, '-out', cert, '-days', '7', '-subj', '/CN=fielua-fake-pc',
                    '-sha256'], check=True)
    with open(cert) as handle:
        fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert(handle.read())).digest()
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.load_cert_chain(cert, key)
    context.set_alpn_protocols(['http/1.1'])
    Handler.state = State(args.code, fingerprint)
    server = Server(('127.0.0.1', args.port), Handler)
    server.socket = context.wrap_socket(server.socket, server_side=True)
    say('READY', f'port={args.port} fingerprint={b64(fingerprint)} openssl={ssl.OPENSSL_VERSION}')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    sys.exit(main())
