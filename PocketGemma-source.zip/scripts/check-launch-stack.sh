#!/bin/bash
# How deep the main thread's stack goes while the chat opens (1.1.0 (239)).
# 1.1.0 (238) crashed at launch on the phone: building the composer's
# SwiftUI types took the rest of the main thread's 1 MB of stack. The
# simulator gives the main thread 8 MB, so the UI checks never saw it. This
# builds the UI preview as Release (the optimized code the phone runs), opens
# it with `--stack-probe` (Preview/StackProbe.swift) and prints its
# STACK-PEAK lines: the deepest the main thread went, in bytes.
# Usage: scripts/check-launch-stack.sh [limit-kb]
set -euo pipefail
cd "$(dirname "$0")/.."
limit_kb="${1:-640}"
source scripts/select-xcode.sh
xcodegen generate --spec preview-project.yml
mkdir -p build/Stack
xcrun simctl list runtimes -j > build/Stack/runtimes.json
xcrun simctl list devicetypes -j > build/Stack/devicetypes.json
runtime_id="$(python3 - <<'PY'
import json
with open('build/Stack/runtimes.json') as f: runtimes = json.load(f)['runtimes']
usable = [r for r in runtimes if r.get('isAvailable') and r['name'].startswith('iOS') and int(r['version'].split('.')[0]) >= 26]
print(max(usable, key=lambda r: tuple(map(int, r['version'].split('.'))))['identifier'])
PY
)"
device_type="$(python3 - <<'PY'
import json
with open('build/Stack/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] in ('iPhone 17 Pro', 'iPhone 16 Pro')]
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPhone')))
PY
)"
simulator_id="$(xcrun simctl create 'Fielua launch stack' "$device_type" "$runtime_id")"
xcrun simctl boot "$simulator_id"
xcrun simctl bootstatus "$simulator_id" -b > build/Stack/boot.log 2>&1
xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview -configuration Release \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/StackDerivedData \
  CODE_SIGNING_ALLOWED=NO build > build/Stack/compile.log 2>&1 \
  || { grep -E 'error:|\*\* .* FAILED' build/Stack/compile.log | head -40; exit 65; }
app="$(find build/StackDerivedData/Build/Products/Release-iphonesimulator -maxdepth 1 -name '*.app' | head -1)"
echo "STACK-APP $app"
xcrun simctl install "$simulator_id" "$app"
bundle="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$app/Info.plist")"
# launch <name> <arguments...>: a fresh process, its probe lines for 8 seconds.
launch() {
  local name="$1"; shift
  xcrun simctl terminate "$simulator_id" "$bundle" > /dev/null 2>&1 || true
  xcrun simctl launch --console-pty --terminate-running-process "$simulator_id" "$bundle" \
    -AppleLanguages '(ja)' --stack-probe "$@" > "build/Stack/$name.log" 2>&1 &
  local pid=$!
  sleep 9
  kill "$pid" > /dev/null 2>&1 || true
  wait "$pid" 2> /dev/null || true
  xcrun simctl terminate "$simulator_id" "$bundle" > /dev/null 2>&1 || true
  grep -E 'STACK-(PROBE|PEAK)' "build/Stack/$name.log" | sed "s/^/$name: /" | tr -d '\r' || echo "$name: no probe lines"
  xcrun simctl io "$simulator_id" screenshot "build/Stack/$name.png" > /dev/null 2>&1 || true
}
# The first launch (the setup over the chat), then the chat with E2B saved,
# as on the tester's phone, and the same in dark mode.
launch first
launch e2b --e2b
launch e2b-dark --e2b --dark
xcrun simctl shutdown "$simulator_id" || true
# The deepest of every launch, against the limit: the phone has 1024 KB.
python3 - "$limit_kb" build/Stack/first.log build/Stack/e2b.log build/Stack/e2b-dark.log <<'PY'
import re, sys
limit = int(sys.argv[1])
peaks = []
for path in sys.argv[2:]:
    found = [int(m) for m in re.findall(r'STACK-PEAK .*?kb=(\d+)', open(path, errors='replace').read())]
    peaks.append(max(found) if found else None)
print('STACK-SUMMARY peaks_kb=' + ','.join('none' if p is None else str(p) for p in peaks) + f' limit_kb={limit}')
if any(p is None for p in peaks): sys.exit('STACK-FAILED: a launch printed no probe line')
if max(peaks) > limit: sys.exit(f'STACK-FAILED: {max(peaks)} KB is over {limit} KB (the phone has 1024 KB)')
print('STACK-PASSED')
PY
