"""Bound a CI XCTest process, report activity, and preserve logs on timeout."""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time


def snapshot(root_pid):
    if sys.platform != 'darwin':
        return [], 'CPU sampling is available on the macOS CI runner only'
    result = subprocess.run(['ps', '-axo', 'pid,ppid,pcpu,rss,etime,comm'],
                            capture_output=True, text=True, timeout=4, check=True)
    rows = []
    for line in result.stdout.splitlines()[1:]:
        fields = line.split(None, 5)
        if len(fields) == 6:
            rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]),
                'cpuPercent': float(fields[2]), 'rssBytes': int(fields[3])*1024,
                'processElapsed': fields[4], 'name': Path(fields[5]).name})
    owned = {root_pid}
    while True:
        descendants = {row['pid'] for row in rows if row['ppid'] in owned}
        if descendants <= owned:
            break
        owned |= descendants
    # Simulator app processes are launched by CoreSimulator, not xcodebuild.
    # This runs only in the dedicated CI job and never prints process arguments.
    return [row for row in rows if row['pid'] in owned or row['name'] == 'PocketGemma'], None


def stop_group(process):
    if os.name != 'posix':
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=5)
        return
    for sig, allowance in [(signal.SIGINT, 8), (signal.SIGTERM, 5), (signal.SIGKILL, 5)]:
        if process.poll() is not None:
            return
        try:
            os.killpg(process.pid, sig)
            process.wait(timeout=allowance)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            continue


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--timeout', type=float, required=True)
    parser.add_argument('--interval', type=float, default=15)
    parser.add_argument('--log', type=Path, required=True)
    parser.add_argument('--metrics', type=Path, required=True)
    parser.add_argument('--simulator')
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    assert command and 0 < args.timeout <= 1800 and 0.1 <= args.interval <= 30
    if args.simulator:
        assert re.fullmatch(r'[A-Fa-f0-9-]{36}', args.simulator)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.metrics.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic(); timed_out = False
    with args.log.open('wb') as output, args.metrics.open('w') as metrics:
        process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                                   start_new_session=(os.name == 'posix'))
        try:
            while process.poll() is None:
                elapsed = time.monotonic() - started
                try:
                    processes, unavailable = snapshot(process.pid)
                except (OSError, ValueError, subprocess.SubprocessError) as error:
                    processes, unavailable = [], str(error)
                stat = args.log.stat()
                record = {'elapsedSeconds': round(elapsed, 2), 'pid': process.pid,
                    'logBytes': stat.st_size, 'secondsSinceLogUpdate': round(time.time()-stat.st_mtime, 2),
                    'processes': processes, 'cpuSamplingUnavailable': unavailable}
                metrics.write(json.dumps(record)+'\n'); metrics.flush()
                print('NATIVE_ACTIVITY '+json.dumps(record), flush=True)
                if elapsed >= args.timeout:
                    timed_out = True
                    if sys.platform == 'darwin':
                        for row in processes:
                            if row['name'] == 'PocketGemma':
                                try:
                                    sample = subprocess.run(['sample', str(row['pid']), '1', '1'],
                                        capture_output=True, timeout=5)
                                    args.metrics.with_suffix('.stack.txt').write_bytes(sample.stdout[:1000000])
                                except (OSError, subprocess.SubprocessError):
                                    pass
                                break
                    print('NATIVE_TIMEOUT: stopping this test process group; logs retained', flush=True)
                    stop_group(process)
                    if args.simulator and sys.platform == 'darwin':
                        try:
                            subprocess.run(['xcrun', 'simctl', 'terminate', args.simulator,
                                'app.pocketgemma.personal'], capture_output=True, timeout=10)
                        except (OSError, subprocess.SubprocessError) as error:
                            print('NATIVE_SHUTDOWN_NOTE '+str(error)[:200], flush=True)
                    break
                time.sleep(min(args.interval, max(0.1, args.timeout-elapsed)))
        finally:
            stop_group(process)
        outcome = {'timedOut': timed_out, 'childExitCode': process.poll(),
                   'elapsedSeconds': round(time.monotonic()-started, 2), 'timeoutSeconds': args.timeout}
        metrics.write(json.dumps({'outcome': outcome})+'\n'); metrics.flush()
        print('NATIVE_OUTCOME '+json.dumps(outcome), flush=True)
    return 124 if timed_out else process.returncode


if __name__ == '__main__':
    sys.exit(main())
