"""The main thread in each of 設定's sampled moments (1.1.0 (291)).

The UI check's settings-profile scope runs macOS's `sample` on the preview
app for two seconds at a millisecond around each moment the app asks for
(SettingsProfileDemo.gate): the sheet's first openings, モデル管理's and the
other pages' slides. For each sample file this prints, for the main thread:
how many samples it took and how many were busy (not waiting in the run
loop), the busiest path from the run loop down, the functions it was in
(inclusive, busy samples only), the ones it was in at the top of the stack,
and the app's own.

    python3 scripts/sample-summary.py build/UI/samples
"""
import collections
import pathlib
import re
import sys

APP = 'PocketGemmaPreview'
IDLE_LEAVES = {'mach_msg2_trap', 'mach_msg_trap', 'mach_msg_overwrite', '__psynch_cvwait', 'semaphore_wait_trap',
               '__workq_kernreturn', 'kevent_id', '__semwait_signal'}
QUIET = re.compile(r'^(start|main|UIApplicationMain|GSEventRunModal|CFRunLoopRunSpecific|__CFRunLoopRun|'
                   r'_?CFRunLoopRun.*|-\[UIApplication _run\]|_UIApplicationMainPreparations|__CFRunLoopDoObservers|'
                   r'__CFRUNLOOP_IS_CALLING_OUT_TO_.*|__CFRunLoopDoSources0|__CFRunLoopDoSource0|__CFRunLoopDoBlocks|'
                   r'static .*App\.main\(\)|.*\$main|\?\?\?|start_sim|thread_start|_pthread_start)$')


class Node:
    __slots__ = ('name', 'binary', 'count', 'children', 'idle', 'parent')

    def __init__(self, name, binary, count, parent):
        self.name, self.binary, self.count, self.parent = name, binary, count, parent
        self.children = []
        self.idle = 0


def frame(text):
    found = re.match(r'(.+?)  \(in (.+?)\)', text)
    if found:
        return found.group(1).strip(), found.group(2)
    return re.split(r'  ', text, 1)[0].strip(), ''


def main_thread(path):
    """The main thread's call tree in a `sample` report, and its samples."""
    lines = path.read_text(errors='replace').splitlines()
    try:
        start = next(i for i, line in enumerate(lines) if line.startswith('Call graph:'))
    except StopIteration:
        return None
    threads = []
    current = None
    stack = []
    for line in lines[start + 1:]:
        if not line.strip():
            if current is not None:
                break
            continue
        header = re.match(r'^ {4}(\d+) (Thread_\S+.*)$', line)
        if header:
            current = Node(header.group(2), '', int(header.group(1)), None)
            threads.append(current)
            stack = [(-1, current)]
            continue
        node = re.match(r'^ {4}([+!:| ]+)(\d+) (.+)$', line)
        if not node or current is None:
            continue
        depth = len(node.group(1))
        while stack and stack[-1][0] >= depth:
            stack.pop()
        parent = stack[-1][1]
        name, binary = frame(node.group(3))
        child = Node(name, binary, int(node.group(2)), parent)
        parent.children.append(child)
        stack.append((depth, child))
    if not threads:
        return None
    main = next((t for t in threads if 'main-thread' in t.name), threads[0])
    mark_idle(main, False)
    return main


def mark_idle(node, waiting):
    """Samples spent waiting in the run loop for something to do, under each
    node. A wait anywhere else (a message to another process, a lock) is
    the main thread held up, and counts as busy."""
    waiting = waiting or node.name == '__CFRunLoopServiceMachPort'
    own = node.count - sum(c.count for c in node.children)
    node.idle = own if waiting and node.name in IDLE_LEAVES else 0
    for child in node.children:
        node.idle += mark_idle(child, waiting)
    return node.idle


def held(node, path, found):
    """Waits outside the run loop's: the main thread held up, by where."""
    own = node.count - sum(c.count for c in node.children)
    if own > 0 and node.name in IDLE_LEAVES and node.idle < own:
        where = ' < '.join(short(n, 60) for n in reversed(path[-6:]) if not QUIET.match(n))
        found[where] += own - node.idle
    for child in node.children:
        held(child, path + [node.name], found)


def short(name, width=150):
    name = re.sub(r'\s+', ' ', name)
    return name if len(name) <= width else name[:width - 3] + '...'


def summarize(path):
    label = path.stem
    main = main_thread(path)
    if main is None:
        print(f'SAMPLE {label} no call graph ({path.stat().st_size} bytes)')
        return None
    total = main.count
    busy = total - main.idle
    print(f'SAMPLE {label} main thread {total} samples, busy {busy} (~{busy} ms at 1 ms)')
    inclusive = collections.Counter()
    own = collections.Counter()
    app = collections.Counter()

    def walk(node, above):
        node_busy = node.count - node.idle
        if node.parent is not None and node.name not in above and node_busy > 0:
            if not QUIET.match(node.name):
                inclusive[node.name] += node_busy
            if APP in node.binary and not QUIET.match(node.name):
                app[node.name] += node_busy
        rest = node.count - sum(c.count for c in node.children)
        if node.parent is not None and rest > 0 and node.name not in IDLE_LEAVES:
            own[node.name] += rest
        for child in node.children:
            walk(child, above | {node.name})

    walk(main, frozenset())
    # The busiest way down: at each step the child with the most busy samples.
    node, steps = main, []
    while node.children:
        child = max(node.children, key=lambda c: c.count - c.idle)
        if child.count - child.idle < max(5, busy // 20):
            break
        if not QUIET.match(child.name):
            steps.append(f'{child.count - child.idle} {short(child.name, 90)}')
        node = child
    for step in steps[:40]:
        print(f'SAMPLE-PATH {label} {step}')
    for name, count in inclusive.most_common(30):
        print(f'SAMPLE-INC {label} {count:5d} {100 * count / busy if busy else 0:5.1f}% {short(name)}')
    for name, count in own.most_common(15):
        print(f'SAMPLE-SELF {label} {count:5d} {short(name)}')
    for name, count in app.most_common(20):
        print(f'SAMPLE-APP {label} {count:5d} {short(name)}')
    waits = collections.Counter()
    held(main, [], waits)
    for where, count in waits.most_common(6):
        print(f'SAMPLE-HELD {label} {count:5d} {short(where, 400)}')
    return total, busy


def main():
    folder = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else 'build/UI/samples')
    files = sorted(folder.glob('*.txt'), key=lambda p: p.stat().st_mtime)
    print(f'SAMPLE files: {len(files)} in {folder}')
    table = collections.defaultdict(dict)
    for path in files:
        try:
            result = summarize(path)
        except Exception as error:  # one bad file must not hide the others
            print(f'SAMPLE {path.stem} unreadable: {error}')
            continue
        if result:
            way, _, moment = path.stem.partition('-')
            table[moment][way] = result
    # The same moment, the marks as shapes and as pictures, side by side:
    # busy samples of the main thread's samples in each two seconds.
    for moment, ways in table.items():
        print(f'SAMPLE-TABLE {moment} ' + ' '.join(f'{way}={busy}/{total}' for way, (total, busy) in sorted(ways.items())))


main()
