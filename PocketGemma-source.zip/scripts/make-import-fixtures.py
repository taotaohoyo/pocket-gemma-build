"""Synthetic resources for file import tests. Contains no user content."""
from pathlib import Path
import io
import zipfile
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

root = Path(__file__).resolve().parents[1] / "Preview/Fixtures"
root.mkdir(exist_ok=True)
with zipfile.ZipFile(root / "sample-word.docx", "w", zipfile.ZIP_DEFLATED) as archive:
    archive.writestr("[Content_Types].xml", '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
    archive.writestr("word/document.xml", '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Word本文の確認😊</w:t></w:r></w:p></w:body></w:document>')
with zipfile.ZipFile(root / "sample-oversize.docx", "w", zipfile.ZIP_DEFLATED) as archive:
    archive.writestr("word/document.xml", b"x" * 8_000_001)
scan = Image.new("RGB", (1400, 1000), "white")
draw = ImageDraw.Draw(scan)
draw.text((100, 180), "SCAN PDF 123", fill="black", font=ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 80))
pdf = canvas.Canvas(str(root / "sample-scan.pdf"), pagesize=(700,500))
pdf.drawImage(ImageReader(scan), 0, 0, width=700, height=500)
pdf.save()
print("Wrote synthetic Word, scan PDF and over-size import fixtures")
