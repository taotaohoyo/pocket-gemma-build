#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
# The Apple Watch app has screenshots of its own, on a watch simulator.
if [[ "${UI_WATCH_ONLY:-0}" == 1 ]]; then exec bash scripts/check-watch-ui.sh; fi
source scripts/select-xcode.sh
xcodegen generate --spec preview-project.yml
mkdir -p build/UI
xcrun simctl list runtimes -j > build/UI/runtimes.json
xcrun simctl list devicetypes -j > build/UI/devicetypes.json
runtime_id="$(python3 - <<'PY'
import json
with open('build/UI/runtimes.json') as f: runtimes = json.load(f)['runtimes']
usable = [r for r in runtimes if r.get('isAvailable') and r['name'].startswith('iOS') and int(r['version'].split('.')[0]) >= 26]
if not usable: raise SystemExit('An installed iOS 26+ simulator runtime is required for the UI checks.')
print(max(usable, key=lambda r: tuple(map(int, r['version'].split('.'))))['identifier'])
PY
)"
device_type="$(python3 - <<'PY'
import json
with open('build/UI/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] in ('iPhone 17 Pro', 'iPhone 16 Pro')]
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPhone')))
PY
)"
xcrun simctl list devices -j > build/UI/devices.json
simulator_id="$(python3 - "$runtime_id" <<'PY'
import json,sys
devices=json.load(open('build/UI/devices.json'))['devices'].get(sys.argv[1],[])
preferred=[d for d in devices if d.get('isAvailable') and d['name'] in ('iPhone 17 Pro','iPhone 16 Pro')]
print(preferred[0]['udid'] if preferred else '')
PY
)"
if [[ -z "$simulator_id" ]]; then
  simulator_id="$(xcrun simctl create 'Pocket Gemma UI verification' "$device_type" "$runtime_id")"
fi
recording_pid=""
sampler_pid=""
pad_id=""
wait_owned_child() {
  local owned_pid="$1"
  for _ in {1..15}; do
    kill -0 "$owned_pid" 2>/dev/null || break
    sleep 1
  done
  if kill -0 "$owned_pid" 2>/dev/null; then
    kill -TERM "$owned_pid" 2>/dev/null || true
    sleep 1
    kill -KILL "$owned_pid" 2>/dev/null || true
  fi
  wait "$owned_pid" || true
}
shutdown_simulator() {
  python3 - "$1" <<'PY'
import subprocess,sys
try:
    subprocess.run(['xcrun','simctl','shutdown',sys.argv[1]],timeout=20,check=False)
except (OSError,subprocess.TimeoutExpired) as error:
    print('UI_CLEANUP_NOTE: '+str(error),flush=True)
PY
}
stop_recording() {
  if [[ -n "$sampler_pid" ]]; then
    kill -TERM "$sampler_pid" 2>/dev/null || true
    wait_owned_child "$sampler_pid"
    sampler_pid=""
  fi
  if [[ -n "$recording_pid" ]]; then
    kill -INT "$recording_pid" 2>/dev/null || true
    wait_owned_child "$recording_pid"
    recording_pid=""
  fi
}
trap 'stop_recording; shutdown_simulator "$simulator_id"; if [[ -n "$pad_id" ]]; then shutdown_simulator "$pad_id"; fi' EXIT
xcrun simctl boot "$simulator_id" || true
# A fresh simulator's data migration can stall before any application test.
# Prefer the runner's existing device and bound startup separately from XCTest.
python3 scripts/native-test-watchdog.py --timeout 480 \
  --log build/UI/boot.log --metrics build/UI/boot-activity.jsonl -- \
  xcrun simctl bootstatus "$simulator_id" -b
# No selected scroll-layout case reads Photos. Do not let optional fixture
# registration block its independent chat checks. Keep both simulator setup
# calls bounded and retain their outcome separately from application tests.
if [[ "${UI_SCROLL_LAYOUT_ONLY:-0}" != "1" && "${UI_BOTTOM_ONLY:-0}" != "1" ]]; then
  python3 scripts/native-test-watchdog.py --timeout 60 \
    --log build/UI/photo-seed.log --metrics build/UI/photo-seed-activity.jsonl -- \
    xcrun simctl addmedia "$simulator_id" Preview/Fixtures/sample-image.png \
    || echo 'UI_PREPARATION_NOTE: photo fixture registration did not finish; picker selection is not validated by these open/close checks.'
fi
python3 scripts/native-test-watchdog.py --timeout 30 \
  --log build/UI/status-bar.log --metrics build/UI/status-bar-activity.jsonl -- \
  xcrun simctl status_bar "$simulator_id" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 --batteryState charged --batteryLevel 100 \
  || echo 'UI_PREPARATION_NOTE: cosmetic status-bar override unavailable.'
# The web search checks keep a key in the keychain, which the simulator
# grants only to a signed app with a keychain group: sign locally (no team,
# no profile) with a simulator-only group for those checks. The preview app
# carries no runtime binaries whose hashes are verified.
signing=(CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO)
if [[ "${UI_WEB_SEARCH_ONLY:-0}" == "1" || "${UI_COMPOSER_TYPE_ONLY:-0}" == "1" || "${UI_SETTINGS_REGRESSION_ONLY:-0}" == "1" \
      || "${UI_WORDING_ONLY:-0}" == "1" || "${UI_UNFOLD_ROW_ONLY:-0}" == "1" || "${UI_REDESIGN_ONLY:-0}" == "1" \
      || "${UI_TRY_QUESTIONS_ONLY:-0}" == "1" ]]; then
  cat > build/UI/simulator-keychain.entitlements <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>keychain-access-groups</key><array><string>$(PRODUCT_BUNDLE_IDENTIFIER)</string></array>
</dict></plist>
PLIST
  signing=(CODE_SIGNING_ALLOWED=YES CODE_SIGNING_REQUIRED=NO CODE_SIGN_STYLE=Manual CODE_SIGN_IDENTITY=-
    DEVELOPMENT_TEAM= PROVISIONING_PROFILE_SPECIFIER= CODE_SIGN_ENTITLEMENTS="$PWD/build/UI/simulator-keychain.entitlements")
fi
# Compile first, so the recording contains the interactions rather than a long
# simulator startup or compiler wait. This uses the same derived test products.
python3 scripts/native-test-watchdog.py --timeout 420 \
  --log build/UI/compile.log --metrics build/UI/compile-activity.jsonl -- \
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
  -destination "platform=iOS Simulator,id=$simulator_id" \
  -derivedDataPath build/DerivedData \
  "${signing[@]}" build-for-testing \
  || { echo 'UI_COMPILE_FAILED: first compiler errors follow'; grep -E 'error:|\*\* .* FAILED' build/UI/compile.log | head -40; exit 65; }
# Every Japanese string the preview asks for has its English, Chinese and
# Korean (1.1.0 (183)); the lines are for review, the tests run either way.
python3 scripts/check-strings.py build/DerivedData PocketGemma/Localization/Localizable.xcstrings Activity/Localizable.xcstrings \
  || echo 'LOC-CHECK: strings without translations, listed above'
xcrun simctl io "$simulator_id" recordVideo --codec=h264 build/UI/interaction.mp4 > build/UI/recording.log 2>&1 &
recording_pid=$!
if [[ "${UI_MENU_VIDEO_ONLY:-0}" == "1" || "${UI_JUMP_TUCK_ONLY:-0}" == "1" || "${UI_COMPOSER_TYPE_ONLY:-0}" == "1" || "${UI_SETTINGS_UI_ONLY:-0}" == "1" \
      || "${UI_TIDY_ONLY:-0}" == "1" || "${UI_SETTINGS_KEYBOARD_OPEN_ONLY:-0}" == "1" || "${UI_FLOWER_ONLY:-0}" == "1" ]]; then
  # The test marks each menu tap with the Mac's clock; note when the
  # recording starts, so scripts/menu-frames.swift finds the frames
  # (scripts/flower-frames.swift for the flower).
  python3 - <<'PY' || true
import pathlib, time
log = pathlib.Path('build/UI/recording.log')
for _ in range(80):
    if log.exists() and 'Recording started' in log.read_text(errors='replace'): break
    time.sleep(0.1)
pathlib.Path('build/UI/recording-start.txt').write_text(f'{time.time():.3f}\n')
print('MENU-FRAMES recording log: ' + (log.read_text(errors='replace').strip()[:200] if log.exists() else 'none'))
PY
fi
python3 scripts/sample-ui-processes.py build/UI &
sampler_pid=$!
set +e
selected_ui_tests=()
if [[ "${UI_FOCUSED_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testInlinePhotoDockAndRepeatedMenuOpenClose
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySettingsAndDeveloperVisibilityPersist
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotosOpenThePickerAndKeepTheDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSwitchFromE2BWithDraftAttachmentCannotSendToE4B
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMenuSendAndInteractiveBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStreamingReplyRemainsReadableAndFinishes
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion)
fi
if [[ "${UI_AX_GUIDE_ONLY:-0}" == "1" ]]; then
  # The large-type attachment menu, and E4B's 高速・深く in the configuration.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotoDetailIsSavedWithTheModel)
fi
ui_timeout=600
if [[ "${UI_FILES_ONLY:-0}" == "1" ]]; then
  # Attachments per model: E4B files as text, Qwen with no attachment items,
  # photo guidance, E2B photos, document formats, encodings and the archive,
  # and videos as three scenes (1.1.0 (192)).
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testVideoImportSamplesThreeScenesAndDraftRemoval
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDocumentImportsPreviewAndArchiveRestore
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWordScannedPdfAndOversizeImports
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testQwenOffersNoAttachments
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotosOpenThePickerAndKeepTheDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSwitchFromE2BWithDraftAttachmentCannotSendToE4B
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable)
  # The document case (two launches, six imports, two sends) took 116s of
  # the usual 120 on 192 and 149s, 94s and 141s on 194's runs with every
  # step passing (40261052110, 40263146932, 40264855719): a slow runner's
  # time, not a stall, so it gets the longer allowance.
  test_allowance=200
  ui_timeout=780
fi
if [[ "${UI_SCROLL_LAYOUT_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard)
  ui_timeout=420
fi
if [[ "${UI_PLUS_ONLY:-0}" == "1" ]]; then
  # Plus-menu motion review: the recording test first (alphabetical order is
  # not guaranteed, so the log timestamps locate it in interaction.mp4), then
  # the existing menu, lock, reduced-motion and layout regressions.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testPlusMenuGlassMorphOpenCloseAndInterruption
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testInlinePhotoDockAndRepeatedMenuOpenClose
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotosOpenThePickerAndKeepTheDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMenuSendAndInteractiveBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader)
fi
if [[ "${UI_HISTORY_ONLY:-0}" == "1" ]]; then
  # History sidebar review: the slide itself, the settings reached from it
  # (developer switch, the GPU start test, model delete), downloads in the
  # Dynamic Island, and the pull past a conversation's end that opens a new
  # chat.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySidebarSlide
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySettingsAndDeveloperVisibilityPersist
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGPUStartTestScreenOpensFromDeveloperDiagnostics
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testModelCatalogSwitchPreservesGemmaHistory
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testModelDeleteAsksFirstAndOffersDownloadAgain
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDownloadLiveActivityInDynamicIsland
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTwoDownloadLiveActivitiesInDynamicIsland
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testPullPastEndOpensNewChat)
fi
if [[ "${UI_ISLAND_ONLY:-0}" == "1" ]]; then
  # The model download in the Dynamic Island: Gemma, two at once, and Qwen.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testDownloadLiveActivityInDynamicIsland
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTwoDownloadLiveActivitiesInDynamicIsland
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testQwenDownloadLiveActivityInDynamicIsland)
fi
if [[ "${UI_PROBE_ONLY:-0}" == "1" ]]; then
  # Which suspect froze the app while the long chat scrolled up (1.0.59).
  # A frozen variant fails after about four minutes, so allow for several.
  # Round 4 (keyboard open, dismissal mode, one send) never froze.
  # Rounds 5-6: the send test froze unless the stack was eager.
  # Round 7: the stream test with the eager block and with all rows lazy.
  # Round 8: the eager outer stack against the 1.0.71 eager lazy item,
  # which left the screen blank, and the send and long-chat checks.
  selected_ui_tests=(
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testProbeMixedAttachmentEagerItem
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testProbeLongerChatScrollsThroughLazyRows
  )
  ui_timeout=1140
fi
if [[ "${UI_MARKDOWN_ONLY:-0}" == "1" ]]; then
  # Markdown replies, light and dark, while streaming, plus the plain
  # streaming reveal and the first reply's stability they must not break.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testOpeningChatsFromHistoryLandsAtTheEnd
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testPullPastEndOpensNewChat
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownReplyRendersEveryBlock
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownReplyInDarkMode
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownCopyMenusAndVoiceOverLabels
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownLongArticleLayout
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownStreamingNeverShowsRawSyntax
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStreamingReplyRemainsReadableAndFinishes
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testParagraphBreakKeepsRainbowFlowing
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOpenSourceLicensesShowTheirTexts
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWideTableScrollsAloneAndCopiesItself
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWideTableInDarkMode
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWideTableBeforeTheFixForComparison
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTokenStreamFirstReplyNeverMovesDown)
  # About six minutes of tests (1.0.98) plus the three wide-table cases.
  ui_timeout=900
fi
if [[ "${UI_TABLES_ONLY:-0}" == "1" ]]; then
  # Tables a little wider than the reply (1.1.0 (220)): long Japanese and
  # English columns wrap to the reply's width, light, dark on a 375 pt
  # phone, while streaming and as 219 drew them for comparison; the wide
  # table still scrolls alone and copies itself, and the Markdown sample's
  # small table and its streaming are as before, its finishing time beside
  # 219's drawing on the same runner (MARKDOWN-NOTE lines, SHOT
  # markdown-table-*). The layout probes are scope tables-probe.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testLongTextTablesFitTheReply
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongTextTablesFitInDarkOnANarrowPhone
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongTextTablesFitWhileStreaming
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongTextTablesBeforeTheFixForComparison
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWideTableScrollsAloneAndCopiesItself
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWideTableInDarkMode
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownReplyRendersEveryBlock
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownStreamingNeverShowsRawSyntax
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownStreamingWith219TablesForComparison)
  test_allowance=480
  ui_timeout=1320
fi
if [[ "${UI_TABLES_PROBE_ONLY:-0}" == "1" ]]; then
  # The long tables' layout, one change at a time (TABLE-PROBE lines, SHOT
  # markdown-table-probe-*): a dozen launches, so a longer allowance.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testLongTablesLayoutVariants)
  test_allowance=480
  ui_timeout=720
fi
if [[ "${UI_CHARTS_ONLY:-0}" == "1" ]]; then
  # Charts in replies (Phase 6-1), light, dark, at the largest text size and
  # streaming, plus the Markdown, table and streaming checks their blocks
  # and the reply's pacing must not break.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testChartsDrawInRepliesAndCopyTheirData
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testChartsInDarkMode
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testChartsAtTheLargestTextSize
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testChartStreamsWithoutShowingItsData
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWrappedChartFromThePhoneIsDrawn
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownReplyRendersEveryBlock
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMarkdownStreamingNeverShowsRawSyntax
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWideTableScrollsAloneAndCopiesItself
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStreamingReplyRemainsReadableAndFinishes
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testParagraphBreakKeepsRainbowFlowing
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTokenStreamFirstReplyNeverMovesDown)
  # About a minute each (the markdown scope's 14 took about 17 minutes).
  ui_timeout=1020
fi
if [[ "${UI_CHART_READING_ONLY:-0}" == "1" ]]; then
  # Chart data as Gemma writes it on the phone (1.0.101+): the wrapped chart
  # streamed, the chart block as asked for, and charts between prose in a
  # reply to a chart request.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testWrappedChartFromThePhoneIsDrawn
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testChartStreamsWithoutShowingItsData
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testChartsDrawInRepliesAndCopyTheirData)
  ui_timeout=480
fi
if [[ "${UI_JUMP_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testJumpControlMotionFrames
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard)
fi
if [[ "${UI_SEND_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSendWithKeyboardOpenMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstReplyInNewChatDoesNotJump
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGrowingFirstReplyNeverMovesBackDown
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTokenStreamFirstReplyNeverMovesDown
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testManualScrollAndComposerRemainResponsiveAfterGrowingReply
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader)
fi
if [[ "${UI_ORB_ONLY:-0}" == "1" ]]; then
  # The Aurora Orb in the reply's place, and the first-reply checks it
  # must not upset; a short reply that ends while the orb leaves never
  # says 停止しました before its text (1.1.0 (189), ORB reply-end lines).
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testShortReplyNeverSaysStoppedBeforeItsText
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAuroraOrbWaitsForFirstVisibleText
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAuroraOrbInDarkMode
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAuroraOrbHoldsStillWithReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstReplyInNewChatDoesNotJump
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTokenStreamFirstReplyNeverMovesDown
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGrowingFirstReplyNeverMovesBackDown
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStreamingReplyRemainsReadableAndFinishes
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion)
  # Each orb case waits 12 s for its reply on top of launch and typing.
  ui_timeout=1020
fi
if [[ "${UI_ORB_VIDEO_ONLY:-0}" == "1" ]]; then
  # Only the light and dark orb cases, so the session recording
  # (interaction.mp4) is short and shows the orb for about 12 s each.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testAuroraOrbWaitsForFirstVisibleText
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAuroraOrbInDarkMode)
  ui_timeout=420
fi
if [[ "${UI_COMPOSER_ONLY:-0}" == "1" ]]; then
  # The two-row composer and its fold into three buttons (Phase UI-1): the
  # new composer cases and frame sheets first, then the send, plus menu,
  # per-model attachment, history and jump checks the composer must keep.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerTwoRowsWithAndWithoutKeyboard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerFoldsIntoThreeButtonsAndOnlyChatUnfolds
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStaysOpenThroughKeyboardSendAndStreaming
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerVoiceButtonSaysThereIsNoVoiceInputYet
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerFoldInDarkModeWithReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMorphFramesLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMorphFramesDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerPhotoDetailPillOnlyForE4B
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotoDetailIsSavedWithTheModel
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMenuSendAndInteractiveBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerClearsJapaneseEmojiAndDismissesKeyboardOnEverySend
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testPlusMenuGlassMorphOpenCloseAndInterruption
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testInlinePhotoDockAndRepeatedMenuOpenClose
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testQwenOffersNoAttachments
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotosOpenThePickerAndKeepTheDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySidebarSlide)
  # Eighteen cases, most under a minute (the first sixteen took ten).
  ui_timeout=1140
fi
if [[ "${UI_COMPOSER_LAB_ONLY:-0}" == "1" ]]; then
  # A short look at the composer while it is being changed (integrated
  # directive, 2026-10-21): the model pill and its Gemma 4 submenu, the
  # header's settings, the plus and 高速 menus opened and closed again and
  # again, the pills' spacing (also with さらに深く), the rows, and the
  # fold's frame sheet.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerModelMenuLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerModelMenuDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMenusLeaveTheScreenAsItWasLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerPhotoDetailPillOnlyForE4B
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerDeeperPillKeepsTheRow
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerDeeperPillOnANarrowPhone
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testPlusMenuGlassMorphOpenCloseAndInterruption
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMenuSendAndInteractiveBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerTwoRowsWithAndWithoutKeyboard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotoDetailIsSavedWithTheModel
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BDeeperAlwaysThinks
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGenerationSettingsCancelSaveAndPromptPersist
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMorphFramesLight)
  # Thirteen cases: the menu cycles took over three minutes, and eleven
  # cases took 950s on a slow runner (run 39703164025).
  ui_timeout=1260
fi
if [[ "${UI_MENU_VIDEO_ONLY:-0}" == "1" ]]; then
  # The plus and 高速 menus while they open and close, frame by frame from
  # the session recording (the light-mode afterimage, 1.0.114 on device).
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMenuFrames)
  ui_timeout=420
fi
if [[ "${UI_JUMP_TUCK_ONLY:-0}" == "1" ]]; then
  # The folded composer's latest button flowing into the chat button at the
  # end and out of it again (integrated directive, 2026-10-21), frame by
  # frame from the session recording, with the fold cases it must keep.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testFoldedLatestButtonFlowsIntoTheChatButton
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerFoldsIntoThreeButtonsAndOnlyChatUnfolds
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerFoldInDarkModeWithReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMorphFramesLight)
  ui_timeout=600
fi
if [[ "${UI_APP_NAME_ONLY:-0}" == "1" ]]; then
  # The app's name (Fielua since 1.0.123) where the app writes it: the
  # history sidebar's title and the voice button's note.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySidebarSlide
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerVoiceButtonSaysThereIsNoVoiceInputYet)
  ui_timeout=420
fi
if [[ "${UI_SETTINGS_OPEN_ONLY:-0}" == "1" ]]; then
  # モデルと設定 without slow work before it opens (1.0.125): from the
  # history sidebar with the developer settings, the automatic model choice
  # and the diagnostics card around the GPU start test.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySettingsAndDeveloperVisibilityPersist
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAutomaticDeviceChoiceAndCloudBackupOptIn
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGPUStartTestScreenOpensFromDeveloperDiagnostics)
  ui_timeout=600
fi
if [[ "${UI_WEB_SEARCH_ONLY:-0}" == "1" ]]; then
  # Web search (2026-10-22): the plus menu's switch, the pill beside the
  # plus, what a reply searched and its pages (light and dark), a search
  # without a connection, the Tavily key's guidance, registration and
  # deletion, and Qwen without search. Tavily sign-in (1.1.0 (207)):
  # Tavily's own page opened from 新規登録 (real network) and cancelled,
  # disconnecting and signing in again, and signing in without a
  # connection. The line when no page named the version asked (1.1.0 (208)).
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchSwitchPillAndSources
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchSourcesDarkOfflineAndQwenOffersNone
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchSaysWhenNoPageNamedTheVersion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchKeyGuidanceAndRegister
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchKeyReadBackAndDelete
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTavilySignUpOpensTavilysPageAndCancelComesBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTavilyConnectedDisconnectAndSignInAgain
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTavilySignInWithoutAConnection)
  ui_timeout=960
fi
if [[ "${UI_CELLULAR_DOWNLOAD_ONLY:-0}" == "1" ]]; then
  # モバイル通信でもダウンロード (0.0.1 (132)): a download waiting for Wi-Fi
  # on cellular, the switch in モデルと設定 (light, dark, kept after a
  # relaunch) and at first launch.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testCellularDownloadSwitchStartsAWaitingDownload
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchOnCellularOffersTheSwitch)
  ui_timeout=420
fi
if [[ "${UI_FIRST_LAUNCH_ONLY:-0}" == "1" ]]; then
  # 初回起動 (1.1.0 (172), the setup of four steps): a first launch with
  # a download, resumed midway with a failed download retried, dark with
  # the models saved, on cellular, and again after 開発者設定
  # 「初回起動扱いにする」 at the next launch; モデル's memory and space
  # notes on phones of 6, 8 and 12 GB (1.1.0 (179)). Pages as SHOT
  # onboarding-*.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingFirstLaunchDownloadsAndOpensTheChat
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingMemoryAndSpaceNotes
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingResumesAndRetriesAFailedDownload
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingDarkWithSavedModelsNeedsNoDownload
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchOnCellularOffersTheSwitch
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchResetShowsTheWelcomeAgain
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStartupOncePerEditionForEveryone)
  # Once per edition for everyone (1.1.0 (181), STARTUP-EDITION lines):
  # six launches in one case, and the reset case took 107s of 120.
  test_allowance=200
  ui_timeout=1080
fi
if [[ "${UI_BLOOM_ONLY:-0}" == "1" ]]; then
  # Aurora Bloom (1.1.0 (178)): ようこそ's light growing from launch in
  # light and dark (WELCOME-BLOOM lines, SHOT onboarding-bloom-*), its
  # haptics stopping with 続ける and when Fielua goes inactive, Reduce
  # Motion, a normal launch without it, and 「初回起動扱いにする」 playing
  # it again.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingFirstLaunchDownloadsAndOpensTheChat
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingDarkWithSavedModelsNeedsNoDownload
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWelcomeBloomHapticsStopWithContinueAndWhenInactive
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchResetShowsTheWelcomeAgain)
  # The reset case took 107s of the usual 120 (run 40184148168), and the
  # haptics case launches three times, each held 5s by --bloom-delay.
  test_allowance=200
  ui_timeout=900
fi
if [[ "${UI_COMPOSER_TYPE_ONLY:-0}" == "1" ]]; then
  # 入力欄のタイプ (2026-10-23): 従来型 from the settings, its pills while
  # typing, its jump control and web search globe in dark mode, and 縮小型's
  # fold and lower row as before.
  # The pills' rise out of the field and sink back into it, frame by frame
  # from the session recording. 起動時のチャット (1.1.0 (182), until then
  # 起動時にキーボードを開いておく) beside it in キーボードと入力, and the
  # launch it opens. The two types' phones
  # playing in キーボード (light frames, dark, Reduce Motion) first.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsPlayTogether
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testClassicComposerFromSettingsShowsPillsWhileTyping
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatCarriesOverTheKeyboardSwitch
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testClassicComposerDarkJumpAndWebSearch
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testClassicPillsRiseAndSinkFrames
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerFoldsIntoThreeButtonsAndOnlyChatUnfolds
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerModelMenuLight)
  ui_timeout=1080
fi
if [[ "${UI_LAUNCH_CHAT_ONLY:-0}" == "1" ]]; then
  # 起動時のチャット (1.1.0 (182)): 新しいチャット's launch with the keyboard
  # and 「前回の会話に戻る」 (light スマート, dark スタンダード), back from the
  # home screen and back to the chat of before; 前回の会話 opening the chat
  # last open with its text; 1.1.0 (181)'s keyboard switch carried over and
  # the choice kept in キーボードと入力; the setup's phones playing together
  # (frame sheets light and dark, Reduce Motion). LAUNCH-CHAT lines, SHOT
  # launch-chat-*.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatPreviewsPlayTogether
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatPreviewsDarkStandard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatPreviewsReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatNewChatOpensWithTheKeyboardAndAWayBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatNewChatDarkStandard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatResumeOpensTheLastChatWithItsText
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatCarriesOverTheKeyboardSwitch)
  ui_timeout=900
fi
if [[ "${UI_SEND_LOG_ONLY:-0}" == "1" ]]; then
  # A send with a video in Picture in Picture and 送信直後の画面の記録
  # (1.1.0 (184)): PIP-SEND and SEND-LOG lines, SHOT pip-*; and the send
  # with the keyboard open as before. The slid conversation's corner
  # shadow drawn alone against the blended one (1.1.0 (190)): DRESSING
  # lines, SHOT dressing-*; and the history's slide as before.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSendWithPictureInPictureAndTheSendRecord
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSendWithKeyboardOpenMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testPanelCornerShadeMatchesTheBlendedShadow
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySidebarSlide)
  test_allowance=300
  ui_timeout=750
fi
if [[ "${UI_CONFIG_SHEET_ONLY:-0}" == "1" ]]; then
  # 構成 (1.1.0 (182), user 2026-10-25): the checkmark and the tabs that
  # stay one control (CONFIG lines, SHOT config-*), and saving and
  # cancelling as before.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testConfigurationCheckmarkAndTabsGlide
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGenerationSettingsCancelSaveAndPromptPersist)
  test_allowance=200
  ui_timeout=600
fi
if [[ "${UI_KEYBOARD_PREVIEW_ONLY:-0}" == "1" ]]; then
  # Only the two types' phones in キーボード (2026-10-24): light frames and
  # the choice kept, dark, Reduce Motion; for changes to the phones alone.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsPlayTogether
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsReduceMotion)
  ui_timeout=480
fi
if [[ "${UI_KEYBOARD_SETTINGS_ONLY:-0}" == "1" ]]; then
  # キーボードと入力 as two rows with their own pages (1.1.0 (191), user
  # 2026-10-25 22:47 UTC): the rows and their values, each page and back,
  # the choices kept, 起動時のチャット's phones in the style chosen (dark,
  # Reduce Motion) and playing on their page, 入力スタイル's phones as
  # before, 1.1.0 (181)'s switch carried over, the setup's 入力スタイル and
  # 起動時のチャット steps as they were, the pages in English, Chinese and
  # Korean; and the plus menu without カメラ (E4B, E2B, the guide).
  # KEYBOARD-SETTINGS, LAUNCH-CHAT and LANG lines; SHOT settings-keyboard-*,
  # launch-chat-*, onboarding-*, lang-*, e4b-attachments-*, large-type-*.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testKeyboardSettingsListOpensEachChoice
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testKeyboardSettingsDarkLaunchPhonesFollowTheStyle
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatSettingsPreviewsPlay
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsPlayTogether
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerStylePreviewsReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatCarriesOverTheKeyboardSwitch
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOnboardingFirstLaunchDownloadsAndOpensTheChat
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatPreviewsPlayTogether
    -only-testing:PocketGemmaUITests/LanguageUITests/testSettingsInEnglish
    -only-testing:PocketGemmaUITests/LanguageUITests/testSettingsInChinese
    -only-testing:PocketGemmaUITests/LanguageUITests/testSettingsInKorean
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotosOpenThePickerAndKeepTheDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSwitchFromE2BWithDraftAttachmentCannotSendToE4B
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable)
  test_allowance=200
  ui_timeout=1500
fi
if [[ "${UI_UNFOLD_ROW_ONLY:-0}" == "1" ]]; then
  # スマート入力欄 after an unfold (1.1.0 (209), user's report 2026-10-27):
  # the plus, 検索, 深く and model buttons tapped with the keyboard up and
  # down and the jump control above the panel (UNFOLD-ROW lines), now and
  # with 1.1.0 (205)'s unfold (--unfold-as-205) for comparison;
  # the fold and unfold as before, and the unfold's frames
  # (composer-strip-light-*), so the motion is seen to be unchanged.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSmartComposerRowAnswersAfterUnfold
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSmartComposerRowAfterUnfoldBefore
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerFoldsIntoThreeButtonsAndOnlyChatUnfolds
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerMorphFramesLight)
  # The strict case launches twice (the record is read in 開発者設定):
  # 270 s on run 40450715532, past 240 s.
  test_allowance=360
  ui_timeout=900
fi
if [[ "${UI_TIDY_ONLY:-0}" == "1" ]]; then
  # 振動・画像吹き出し・設定の整理 (2026-10-25): a sent photo without a
  # bubble (light, dark, its preview), the conversation's layout and reading
  # place with a photo while it scrolls, オープンソースライセンス's rows as
  # the page fades in (frames cut from the recording) and its texts, and
  # キーボードと入力 with the two types' phones but no heading above them.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSentPhotoStandsWithoutABubble
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLicensesPageFadesInWithItsRowsInPlace
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOpenSourceLicensesShowTheirTexts
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatCarriesOverTheKeyboardSwitch)
  # The photo and licenses tests go through light and dark in one test.
  test_allowance=240
  ui_timeout=720
fi
if [[ "${UI_SETTINGS_UI_ONLY:-0}" == "1" ]]; then
  # 設定 (2026-10-23, 設定画面UIリニューアル): the glass sheet's six rows and
  # their pages in light and dark, at full height for comparison, the
  # Fielua title shrinking into the bar (frame sheets, Reduce Motion too)
  # and settling, and モデル管理 page by page, printed as SHOT lines
  # (settings-*) for review. Pages sliding over the sheet's glass and back
  # (1.1.0 (147)'s device check) are cut from the session recording.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsPagesSlideLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsPagesSlideDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsSheetRowsLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsSheetRowsDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsSheetFullHeightProbe
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsTitleShrinksIntoTheBar
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsTitleReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsTitleSettles
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsTourLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsTourDeveloper)
  ui_timeout=1080
fi
if [[ "${UI_SETTINGS_KEYBOARD_OPEN_ONLY:-0}" == "1" ]]; then
  # 設定 opening with the keyboard up (1.1.0 (203), user's recording
  # 2026-10-26 16:01 UTC: the rows grew from a sliver now and then): before,
  # each change alone and now, cut from the recording (SHOT
  # composer-video-settings-open-*, SETTINGS-OPEN lines); and the sheet's
  # rows and page slides as before (settings-new-light-*, settings-push-*).
  # The same opening asked for inside an animation, before and now
  # (composer-video-settings-anim-*): the simulator's keyboard is down
  # before its sheet comes, so the first test cannot catch the overlap.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsOpensWholeWithTheKeyboardUp
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsOpenedInsideAnAnimation
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsSheetRowsLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsPagesSlideLight)
  test_allowance=300
  ui_timeout=780
fi
if [[ "${UI_SETTINGS_PERF_ONLY:-0}" == "1" ]]; then
  # 設定's page slides measured (1.1.0 (153)): every page in and back out
  # for each way of sliding, the meter's table printed as SETTINGS-PERF
  # lines, and the slide with its swipe back as the device will run it.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsPageSlidesMeasured
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsPagesSlideLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSettingsBackButtonComesAndGoesWithThePage)
  ui_timeout=780
  # The measurement alone runs about two and a half minutes.
  test_allowance=300
fi
if [[ "${UI_SETTINGS_REGRESSION_ONLY:-0}" == "1" ]]; then
  # What moved into 設定's pages still works: the developer settings and
  # diagnostics, the automatic choice and iCloud opt-in, deleting a model,
  # the licenses, the cellular switch, 従来型 from キーボード, and the web
  # search key from the chat's note.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySettingsAndDeveloperVisibilityPersist
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAutomaticDeviceChoiceAndCloudBackupOptIn
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testGPUStartTestScreenOpensFromDeveloperDiagnostics
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testModelDeleteAsksFirstAndOffersDownloadAgain
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOpenSourceLicensesShowTheirTexts
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testCellularDownloadSwitchStartsAWaitingDownload
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testClassicComposerFromSettingsShowsPillsWhileTyping
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchKeyGuidanceAndRegister)
  ui_timeout=1020
fi
if [[ "${UI_TEXT_SIZE_ONLY:-0}" == "1" ]]; then
  # The app's own text size (2026-10-23): iOS's largest and smallest
  # 文字サイズ leave the composer and the plus menu at the default size,
  # and the layouts at --large-type still hold the composer's row.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testTextSizeIgnoresIOSLargestSize
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTextSizeIgnoresIOSSmallestSize
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerDeeperPillKeepsTheRow
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable)
  ui_timeout=600
fi
if [[ "${UI_REDESIGN_ONLY:-0}" == "1" ]]; then
  # ブランド刷新 (2026-10-27): the chat, the history sidebar, an empty chat,
  # the model menu, a searched reply, the thinking orb and 設定's pages in
  # the new paper and yellow, light and dark (SHOT redesign-*, REDESIGN
  # lines), and the reply text's golds as it flows in (the paragraph and
  # Markdown checks that read its colours). UI Phase 2 (1.1.0 (214)): the
  # empty chat's living flower, light, dark and with Reduce Motion (SHOT
  # redesign-flower-*). UI Phase 3 (1.1.0 (215)): the flower over time
  # (breathing, a petal's flight, typing, Low Power Mode, back from the
  # home screen, frames a second) and 構成 on the paper (SHOT
  # redesign-*-config-*), with 構成's tabs still one control.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testRedesignChatLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testRedesignChatDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testRedesignSettingsLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testRedesignSettingsDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerBreathesLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerBreathesDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerHoldsStillWithReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerRestsInLowPower
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerResumesAfterBackground
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWhileTypingLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWhileTypingDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWithReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testConfigSheetOnPaperLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testConfigSheetOnPaperDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDeveloperTestSheetOnPaper
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testConfigurationCheckmarkAndTabsGlide
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testParagraphBreakKeepsRainbowFlowing)
  test_allowance=200
  ui_timeout=1680
fi
if [[ "${UI_TRY_QUESTIONS_ONLY:-0}" == "1" ]]; then
  # 体験型おすすめ質問 (1.1.0 (219)): an empty chat's three try chips over
  # the field, light and dark on a 375 pt phone, going away while the
  # person types and coming back, a tap sending its question as an
  # ordinary chat that the history keeps; giving way to no model and to
  # 「前回の会話に戻る」; never searching in a chat whose search is on (TRY
  # lines, SHOT try-*). The flower leaving while typing, as in 216.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testTryQuestionsLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTryQuestionsDarkOnANarrowPhone
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTryQuestionsGiveWay
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testTryQuestionDoesNotSearch
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWhileTypingLight)
  test_allowance=200
  ui_timeout=900
fi
if [[ "${UI_FLOWER_ONLY:-0}" == "1" ]]; then
  # The empty chat's living flower alone (1.1.0 (215)), from the redesign
  # set: breathing, a petal's flight, Reduce Motion, Low Power Mode and
  # back from the home screen (REDESIGN flower lines), and since 1.1.0
  # (216) going away while the person types and coming back, frame by
  # frame from the recording (FLOWER-FRAMES lines, SHOT flower-video-*).
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerBreathesLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerBreathesDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerHoldsStillWithReduceMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerRestsInLowPower
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerResumesAfterBackground
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWhileTypingLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWhileTypingDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLivingFlowerLeavesWithReduceMotion)
  test_allowance=200
  ui_timeout=1080
fi
if [[ "${UI_WORDING_ONLY:-0}" == "1" ]]; then
  # 文言の整理 (2026-10-24): the chat, 設定 and the welcome with their new
  # words (SHOT wording-*), and the checks that find the changed words:
  # the orb's label, the voice note, the attachment guide, an empty chat's
  # mark, 新しいチャット and 設定 in the plus menu, and 停止する. The orb in
  # dark mode: the light case also counts the first text's Rainbow Flow as
  # the orb's colour, on 166 too (run 40093870526).
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testWordingChatScreens
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWordingSettingsScreens
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testAuroraOrbInDarkMode
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testComposerVoiceButtonSaysThereIsNoVoiceInputYet
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BPhotosOpenThePickerAndKeepTheDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testQwenOffersNoAttachments
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testPullPastEndOpensNewChat
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLaunchChatCarriesOverTheKeyboardSwitch
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOpeningChatsFromHistoryLandsAtTheEnd
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testWebSearchKeyReadBackAndDelete
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStreamingReplyRemainsReadableAndFinishes)
  ui_timeout=1080
fi
if [[ "${UI_LOCKED_MODEL_ONLY:-0}" == "1" ]]; then
  # Gemma 4 12B and Qwen2.5 1.5B open to everyone (1.1.0 (204); locked in
  # 196, a developer's with a password in 200): the model menu, モデル管理's
  # cards with 12B's テスト版 badge and note, and a 12B chat's note, light,
  # dark (as the sideload) and English. COMPOSER open-12b lines; SHOT
  # composer-open-12b-*, settings-open-12b-*, settings-open-qwen25-*, composer-chat-open-12b-*.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testOpenTwelveBLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOpenTwelveBDark
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testOpenTwelveBInEnglish)
  ui_timeout=600
fi
if [[ "${UI_NEW_MODELS_ONLY:-0}" == "1" ]]; then
  # Phi-4-mini-reasoning and Qwen3.5 4B (1.1.0 (205)): the model menu lists
  # them after Gemma 4 and before Qwen2.5; モデル管理's cards, Phi's with its
  # thinking note. Light and dark. COMPOSER new-models lines; SHOT
  # composer-new-models-*, settings-new-models-*.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testNewModelsLight
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testNewModelsDark)
  ui_timeout=600
fi
if [[ "${UI_LANGUAGES_ONLY:-0}" == "1" ]]; then
  # 多言語対応 (1.1.0 (183)): the first launch, 設定 and its pages, and the
  # chat with its menu, history and configuration in English, Chinese and
  # Korean (SHOT lang-*; LANG-JA lines for words still in Japanese script),
  # and English for a language Fielua doesn't have, Japanese for Japanese.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/LanguageUITests)
  ui_timeout=1500
fi
if [[ "${UI_BOTTOM_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testManualScrollAndComposerRemainResponsiveAfterGrowingReply)
  # Include XCTest runner startup/teardown as well as both120s case bounds.
  ui_timeout=420
fi
python3 scripts/native-test-watchdog.py --timeout "$ui_timeout" \
  --log build/UI/focused-tests.log --metrics build/UI/test-activity.jsonl -- \
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
  -destination "platform=iOS Simulator,id=$simulator_id" \
  -derivedDataPath build/DerivedData -resultBundlePath build/UI/Preview.xcresult \
  -parallel-testing-enabled NO \
  -test-timeouts-enabled YES -maximum-test-execution-time-allowance "${test_allowance:-120}" \
  "${selected_ui_tests[@]}" \
  "${signing[@]}" test-without-building
test_exit=$?
set -e
# Keep failure locations available without transferring a large recording or
# xcresult bundle. Full logs and screenshots are still preserved separately.
python3 - <<'PY'
from pathlib import Path
lines=Path('build/UI/focused-tests.log').read_text(errors='replace').splitlines()
# Results on their own, so a long stack dump (whose frames contain
# "error:" in selectors) cannot push them out of the window below.
print('\n'.join(s[:1000] for s in lines if ('Test Case ' in s and ('passed' in s or 'failed' in s)) or 'Executed ' in s))
# The table layout probes, all of them (testLongTablesLayoutVariants).
print('\n'.join(s[:1000] for s in lines if 'TABLE-PROBE ' in s))
selected=[s for s in lines if ': error:' in s or 'PHOTO-SHEET' in s or 'HISTORY-SIDEBAR' in s or 'HISTORY-OPEN' in s or 'MARKDOWN-NOTE' in s or 'PROBE ' in s or 'MIXED ' in s or 'ORB ' in s or 'BLOOM' in s or 'STARTUP-EDITION' in s or 'COMPOSER ' in s or 'MENU-MARK ' in s or 'WEB-SEARCH ' in s or 'SETTINGS-TOUR ' in s or 'SETTINGS-OPEN ' in s or 'SETTINGS-PERF ' in s or 'WORDING ' in s or 'REDESIGN ' in s or 'ONBOARDING' in s or 'SENT-PHOTO ' in s or 'LICENSES ' in s or 'LAUNCH-CHAT' in s or 'CONFIG ' in s or 'PIP-SEND' in s or 'SEND-LOG' in s or 'DRESSING ' in s or 'KEYBOARD-' in s or 'UNFOLD-ROW' in s or 'ATTACH-GUIDE' in s or 'TRY ' in s or 'Restarting after' in s or '** TEST' in s or 'Testing failed' in s]
print('\n'.join(s[:1000] for s in selected[-120:]))
# The language checks' words, all of them (LanguageUITests).
print('\n'.join([s[:400] for s in lines if s.lstrip().startswith('LANG')][:800]))
PY
# Where a preview app that stayed above 75% CPU spent its time
# (scripts/sample-ui-processes.py), printed for review without artifacts:
# the main thread's frames that carry at least a quarter of its samples.
python3 - <<'PY' || true
import pathlib, re
for path in sorted(pathlib.Path('build/UI').glob('ui-*.stack.txt')):
    lines = path.read_text(errors='replace').splitlines()
    print(f'STACK-BEGIN {path.name}')
    total = None; shown = 0
    for line in lines:
        frame = re.match(r'^\s*[+!:| ]*(\d+) (.*)$', line)
        if total is None:
            if frame and 'com.apple.main-thread' in line: total = int(frame.group(1))
            continue
        if re.match(r'^\s{4}\d+ Thread_', line) or not line.strip(): break
        if frame and int(frame.group(1)) * 4 >= total:
            depth = len(line) - len(line.lstrip(' +!:|'))
            symbol = re.sub(r'\s+', ' ', re.sub(r'\s*\[0x[0-9a-f,]+\]', '', frame.group(2)))
            print(f'STACK {depth:3d} {frame.group(1)} {symbol[:170]}')
            shown += 1
            if shown >= 400: break
    top = next((i for i, l in enumerate(lines) if l.startswith('Sort by top of stack')), None)
    if top is not None:
        for l in lines[top:top + 30]: print('STACK-TOP ' + re.sub(r'\s+', ' ', l.strip())[:170])
    print(f'STACK-END {path.name}')
PY
stop_recording
if [[ "${UI_MENU_VIDEO_ONLY:-0}" == "1" && -f build/UI/interaction.mp4 ]]; then
  swift scripts/menu-frames.swift build/UI/interaction.mp4 build/UI/recording-start.txt \
    build/UI/focused-tests.log build/UI/menu-frames || echo 'MENU-FRAMES failed'
fi
if [[ "${UI_COMPOSER_TYPE_ONLY:-0}" == "1" && -f build/UI/interaction.mp4 ]]; then
  # 従来型's field and pills: the screen from 40% down, its leading 62%,
  # on wider tiles so the pills' drops can be read.
  MENU_FRAMES_TILE=280 swift scripts/menu-frames.swift build/UI/interaction.mp4 build/UI/recording-start.txt \
    build/UI/focused-tests.log build/UI/menu-frames 0.4 0 0.62 || echo 'MENU-FRAMES failed'
fi
if [[ ( "${UI_SETTINGS_UI_ONLY:-0}" == "1" || "${UI_TIDY_ONLY:-0}" == "1" ) && -f build/UI/interaction.mp4 ]]; then
  # 設定's pages coming and going: the whole screen, on narrow tiles.
  MENU_FRAMES_TILE=160 swift scripts/menu-frames.swift build/UI/interaction.mp4 build/UI/recording-start.txt \
    build/UI/focused-tests.log build/UI/menu-frames 0 0 1 || echo 'MENU-FRAMES failed'
fi
if [[ "${UI_SETTINGS_KEYBOARD_OPEN_ONLY:-0}" == "1" && -f build/UI/interaction.mp4 ]]; then
  # The sheet rising over the keyboard going down: the whole screen.
  MENU_FRAMES_TILE=200 swift scripts/menu-frames.swift build/UI/interaction.mp4 build/UI/recording-start.txt \
    build/UI/focused-tests.log build/UI/menu-frames 0 0 1 || echo 'MENU-FRAMES failed'
fi
if [[ "${UI_FLOWER_ONLY:-0}" == "1" && -f build/UI/interaction.mp4 ]]; then
  # The compiler's warnings go aside: in the log they split the sheets.
  swift scripts/flower-frames.swift build/UI/interaction.mp4 build/UI/recording-start.txt \
    build/UI/focused-tests.log build/UI/flower-frames 2>build/UI/flower-frames.err \
    || { echo 'FLOWER-FRAMES failed'; tail -20 build/UI/flower-frames.err; }
fi
if [[ "${UI_JUMP_TUCK_ONLY:-0}" == "1" && -f build/UI/interaction.mp4 ]]; then
  # The folded buttons: the screen's lowest fifth, its middle 64%.
  swift scripts/menu-frames.swift build/UI/interaction.mp4 build/UI/recording-start.txt \
    build/UI/focused-tests.log build/UI/menu-frames 0.8 0.18 0.64 || echo 'MENU-FRAMES failed'
fi
if [[ -d build/UI/Preview.xcresult ]]; then
  xcrun xcresulttool export attachments --path build/UI/Preview.xcresult --output-path build/UI/attachments || true
  # Small review sheets (frame strips) on their own, so they can be
  # fetched without the recording or the result bundle.
  python3 - <<'PY' || true
import json, pathlib, shutil
root = pathlib.Path('build/UI/attachments'); out = pathlib.Path('build/UI/strips'); out.mkdir(exist_ok=True)
manifest = json.loads((root / 'manifest.json').read_text())
for test in manifest:
    for item in test.get('attachments', []):
        name = item.get('suggestedHumanReadableName', '')
        if 'strip' in name or name.startswith('jump-'):
            shutil.copy(root / item['exportedFileName'], out / name)
PY
  # Photo sheet screenshots, small enough to print into the job log for
  # review where artifact downloads are unavailable.
  python3 - <<'PY' || true
import base64, json, pathlib, subprocess
root = pathlib.Path('build/UI/attachments')
manifest = json.loads((root / 'manifest.json').read_text())
for test in manifest:
    for item in test.get('attachments', []):
        name = item.get('suggestedHumanReadableName', '').split('_')[0]
        if name in ('inline-photo-grid', 'inline-photo-picked', 'expanded-inline-photo-grid', 'photo-sheet-collapsed') \
                or name.startswith('history-') or name.startswith('markdown-') or name.startswith('probe-') or name.startswith('mixed-after') \
                or name.startswith('orb-') or name.startswith('composer-') or name.startswith('web-search-') \
                or name.startswith('video-') \
                or name.startswith('cellular-') or name.startswith('settings-') or name.startswith('wording-') \
                or name.startswith('redesign-') or name.startswith('onboarding-') or name.startswith('first-launch-') or name.startswith('startup-edition-') \
                or name.startswith('launch-chat-') or name.startswith('config-') or name.startswith('lang-') \
                or name.startswith('pip-') or name.startswith('dressing-') or name.startswith('e4b-attachments') \
                or name.startswith('large-type-attachment') or name.startswith('try-'):
            shot = pathlib.Path('build/UI') / f'shot-{name}.jpg'
            # Dynamic Island crops are short strips; keep them sharp.
            # Whole settings pages: their small captions must stay legible.
            size = '1600' if name.startswith('markdown-reveal') or name.startswith('settings-') or name.startswith('launch-chat-preview-frames') \
                else '1200' if name.startswith('wording-') or name.startswith('lang-') or name.startswith('redesign-') \
                else '1000' if 'island' in name or 'pull-snapshots' in name or name.startswith('orb-strip') or name.startswith('composer-strip') \
                else '900' if name.startswith('markdown-') or name.startswith('orb-') or name.startswith('composer-') or name.startswith('web-search-') \
                or name.startswith('cellular-') or name.startswith('onboarding-') or name.startswith('launch-chat-') \
                or name.startswith('config-') or name.startswith('pip-') or name.startswith('dressing-') or name.startswith('try-') else '560'
            # The welcome's light at its own pixels, for its outline.
            if name.startswith('onboarding-orb'):
                size, quality = '840', '90'
            elif name.startswith('onboarding-bloom'):
                size, quality = '1120', '75'
            elif name.startswith('video-'):
                size, quality = '900', '50'
            else:
                quality = '50'
            subprocess.run(['sips', '-s', 'format', 'jpeg', '-s', 'formatOptions', quality, '-Z', size,
                            str(root / item['exportedFileName']), '--out', str(shot)], check=True, capture_output=True)
            print(f'SHOT-BEGIN {name}'); print(base64.b64encode(shot.read_bytes()).decode()); print('SHOT-END')
PY
fi
if [[ "$test_exit" -ne 0 ]]; then
  xcrun simctl io "$simulator_id" screenshot build/UI/failure.png || true
fi
if [[ "$test_exit" -eq 0 && "${UI_FOCUSED_ONLY:-0}" != "1" ]]; then
  xcrun simctl shutdown "$simulator_id"
  pad_type="$(python3 - <<'PY'
import json
with open('build/UI/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] == 'iPad Pro 11-inch (M4)']
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPad')))
PY
)"
  pad_id="$(xcrun simctl create 'Pocket Gemma iPad startup' "$pad_type" "$runtime_id")"
  xcrun simctl boot "$pad_id"
  xcrun simctl bootstatus "$pad_id" -b
  set +e
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
    -destination "platform=iOS Simulator,id=$pad_id" \
    -derivedDataPath build/DerivedData -resultBundlePath build/UI/iPad.xcresult \
    -parallel-testing-enabled NO \
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchModelChoiceAndCompletionPersist \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
  test_exit=$?
  set -e
  if [[ -d build/UI/iPad.xcresult ]]; then
    xcrun xcresulttool export attachments --path build/UI/iPad.xcresult --output-path build/UI/ipad-attachments || true
  fi
fi
exit "$test_exit"
