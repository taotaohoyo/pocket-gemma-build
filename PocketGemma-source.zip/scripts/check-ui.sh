#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
xcodegen generate --spec preview-project.yml
mkdir -p build/UI
xcrun simctl list runtimes -j > build/UI/runtimes.json
xcrun simctl list devicetypes -j > build/UI/devicetypes.json
runtime_id="$(python3 - <<'PY'
import json
with open('build/UI/runtimes.json') as f: runtimes = json.load(f)['runtimes']
usable = [r for r in runtimes if r.get('isAvailable') and r['name'].startswith('iOS') and int(r['version'].split('.')[0]) >= 26]
if not usable: raise SystemExit('An installed iOS 26+ simulator runtime is required for the UI checks.')
print(max(usable, key=lambda r: tuple(map(int, r['version'].split('.'))))['identifier'])
PY
)"
device_type="$(python3 - <<'PY'
import json
with open('build/UI/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] in ('iPhone 17 Pro', 'iPhone 16 Pro')]
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPhone')))
PY
)"
xcrun simctl list devices -j > build/UI/devices.json
simulator_id="$(python3 - "$runtime_id" <<'PY'
import json,sys
devices=json.load(open('build/UI/devices.json'))['devices'].get(sys.argv[1],[])
preferred=[d for d in devices if d.get('isAvailable') and d['name'] in ('iPhone 17 Pro','iPhone 16 Pro')]
print(preferred[0]['udid'] if preferred else '')
PY
)"
if [[ -z "$simulator_id" ]]; then
  simulator_id="$(xcrun simctl create 'Pocket Gemma UI verification' "$device_type" "$runtime_id")"
fi
recording_pid=""
sampler_pid=""
pad_id=""
wait_owned_child() {
  local owned_pid="$1"
  for _ in {1..15}; do
    kill -0 "$owned_pid" 2>/dev/null || break
    sleep 1
  done
  if kill -0 "$owned_pid" 2>/dev/null; then
    kill -TERM "$owned_pid" 2>/dev/null || true
    sleep 1
    kill -KILL "$owned_pid" 2>/dev/null || true
  fi
  wait "$owned_pid" || true
}
shutdown_simulator() {
  python3 - "$1" <<'PY'
import subprocess,sys
try:
    subprocess.run(['xcrun','simctl','shutdown',sys.argv[1]],timeout=20,check=False)
except (OSError,subprocess.TimeoutExpired) as error:
    print('UI_CLEANUP_NOTE: '+str(error),flush=True)
PY
}
stop_recording() {
  if [[ -n "$sampler_pid" ]]; then
    kill -TERM "$sampler_pid" 2>/dev/null || true
    wait_owned_child "$sampler_pid"
    sampler_pid=""
  fi
  if [[ -n "$recording_pid" ]]; then
    kill -INT "$recording_pid" 2>/dev/null || true
    wait_owned_child "$recording_pid"
    recording_pid=""
  fi
}
trap 'stop_recording; shutdown_simulator "$simulator_id"; if [[ -n "$pad_id" ]]; then shutdown_simulator "$pad_id"; fi' EXIT
xcrun simctl boot "$simulator_id" || true
# A fresh simulator's data migration can stall before any application test.
# Prefer the runner's existing device and bound startup separately from XCTest.
python3 scripts/native-test-watchdog.py --timeout 480 \
  --log build/UI/boot.log --metrics build/UI/boot-activity.jsonl -- \
  xcrun simctl bootstatus "$simulator_id" -b
# No selected scroll-layout case reads Photos. Do not let optional fixture
# registration block its independent chat checks. Keep both simulator setup
# calls bounded and retain their outcome separately from application tests.
if [[ "${UI_SCROLL_LAYOUT_ONLY:-0}" != "1" && "${UI_BOTTOM_ONLY:-0}" != "1" ]]; then
  python3 scripts/native-test-watchdog.py --timeout 60 \
    --log build/UI/photo-seed.log --metrics build/UI/photo-seed-activity.jsonl -- \
    xcrun simctl addmedia "$simulator_id" Preview/Fixtures/sample-image.png \
    || echo 'UI_PREPARATION_NOTE: photo fixture registration did not finish; picker selection is not validated by these open/close checks.'
fi
python3 scripts/native-test-watchdog.py --timeout 30 \
  --log build/UI/status-bar.log --metrics build/UI/status-bar-activity.jsonl -- \
  xcrun simctl status_bar "$simulator_id" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 --batteryState charged --batteryLevel 100 \
  || echo 'UI_PREPARATION_NOTE: cosmetic status-bar override unavailable.'
# Compile first, so the recording contains the interactions rather than a long
# simulator startup or compiler wait. This uses the same derived test products.
python3 scripts/native-test-watchdog.py --timeout 420 \
  --log build/UI/compile.log --metrics build/UI/compile-activity.jsonl -- \
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
  -destination "platform=iOS Simulator,id=$simulator_id" \
  -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build-for-testing \
  || { echo 'UI_COMPILE_FAILED: first compiler errors follow'; grep -E 'error:|\*\* .* FAILED' build/UI/compile.log | head -40; exit 65; }
xcrun simctl io "$simulator_id" recordVideo --codec=h264 build/UI/interaction.mp4 > build/UI/recording.log 2>&1 &
recording_pid=$!
python3 scripts/sample-ui-processes.py build/UI &
sampler_pid=$!
set +e
selected_ui_tests=()
if [[ "${UI_FOCUSED_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testInlinePhotoDockAndRepeatedMenuOpenClose
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testHistorySettingsAndDeveloperVisibilityPersist
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BAttachmentLocksAndE2BSwitchKeepDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSwitchFromE2BWithDraftAttachmentCannotSendToE4B
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMenuSendAndInteractiveBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testStreamingReplyRemainsReadableAndFinishes
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion)
fi
if [[ "${UI_AX_GUIDE_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable)
fi
ui_timeout=600
if [[ "${UI_SCROLL_LAYOUT_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard)
  ui_timeout=420
fi
if [[ "${UI_PLUS_ONLY:-0}" == "1" ]]; then
  # Plus-menu motion review: the recording test first (alphabetical order is
  # not guaranteed, so the log timestamps locate it in interaction.mp4), then
  # the existing menu, lock, reduced-motion and layout regressions.
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testPlusMenuGlassMorphOpenCloseAndInterruption
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testInlinePhotoDockAndRepeatedMenuOpenClose
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testE4BAttachmentLocksAndE2BSwitchKeepDraft
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLargeTypeReducedMotionAttachmentMenuRemainsUsable
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testDarkModeWithReducedMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMenuSendAndInteractiveBack
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader)
fi
if [[ "${UI_SEND_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testSendWithKeyboardOpenMotion
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstReplyInNewChatDoesNotJump
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testSendFromOlderMessagesWithMultilineKeyboardKeepsLatestAndCanScroll
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testShortConversationAndGrowingReplyStayStableWithKeyboard
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testManualScrollAndComposerRemainResponsiveAfterGrowingReply
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testLongConversationJumpControlAndHeader)
fi
if [[ "${UI_BOTTOM_ONLY:-0}" == "1" ]]; then
  selected_ui_tests=(-only-testing:PocketGemmaUITests/ChatMotionUITests/testMixedAttachmentStreamHasNoLayoutOverlapAndKeepsReadingPosition
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testManualScrollAndComposerRemainResponsiveAfterGrowingReply)
  # Include XCTest runner startup/teardown as well as both120s case bounds.
  ui_timeout=420
fi
python3 scripts/native-test-watchdog.py --timeout "$ui_timeout" \
  --log build/UI/focused-tests.log --metrics build/UI/test-activity.jsonl -- \
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
  -destination "platform=iOS Simulator,id=$simulator_id" \
  -derivedDataPath build/DerivedData -resultBundlePath build/UI/Preview.xcresult \
  -parallel-testing-enabled NO \
  -test-timeouts-enabled YES -maximum-test-execution-time-allowance 120 \
  "${selected_ui_tests[@]}" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
test_exit=$?
set -e
# Keep failure locations available without transferring a large recording or
# xcresult bundle. Full logs and screenshots are still preserved separately.
python3 - <<'PY'
from pathlib import Path
lines=Path('build/UI/focused-tests.log').read_text(errors='replace').splitlines()
selected=[s for s in lines if ('Test Case ' in s and ('passed' in s or 'failed' in s)) or 'error:' in s or 'Executed ' in s]
print('\n'.join(s[:1000] for s in selected[-80:]))
PY
stop_recording
if [[ -d build/UI/Preview.xcresult ]]; then
  xcrun xcresulttool export attachments --path build/UI/Preview.xcresult --output-path build/UI/attachments || true
fi
if [[ "$test_exit" -ne 0 ]]; then
  xcrun simctl io "$simulator_id" screenshot build/UI/failure.png || true
fi
if [[ "$test_exit" -eq 0 && "${UI_FOCUSED_ONLY:-0}" != "1" ]]; then
  xcrun simctl shutdown "$simulator_id"
  pad_type="$(python3 - <<'PY'
import json
with open('build/UI/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] == 'iPad Pro 11-inch (M4)']
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPad')))
PY
)"
  pad_id="$(xcrun simctl create 'Pocket Gemma iPad startup' "$pad_type" "$runtime_id")"
  xcrun simctl boot "$pad_id"
  xcrun simctl bootstatus "$pad_id" -b
  set +e
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
    -destination "platform=iOS Simulator,id=$pad_id" \
    -derivedDataPath build/DerivedData -resultBundlePath build/UI/iPad.xcresult \
    -parallel-testing-enabled NO \
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchModelChoiceAndCompletionPersist \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
  test_exit=$?
  set -e
  if [[ -d build/UI/iPad.xcresult ]]; then
    xcrun xcresulttool export attachments --path build/UI/iPad.xcresult --output-path build/UI/ipad-attachments || true
  fi
fi
exit "$test_exit"
