#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
xcodegen generate --spec preview-project.yml
mkdir -p build/UI
xcrun simctl list runtimes -j > build/UI/runtimes.json
xcrun simctl list devicetypes -j > build/UI/devicetypes.json
runtime_id="$(python3 - <<'PY'
import json
with open('build/UI/runtimes.json') as f: runtimes = json.load(f)['runtimes']
usable = [r for r in runtimes if r.get('isAvailable') and r['name'].startswith('iOS') and int(r['version'].split('.')[0]) >= 26]
if not usable: raise SystemExit('An installed iOS 26+ simulator runtime is required for the UI checks.')
print(max(usable, key=lambda r: tuple(map(int, r['version'].split('.'))))['identifier'])
PY
)"
device_type="$(python3 - <<'PY'
import json
with open('build/UI/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] in ('iPhone 17 Pro', 'iPhone 16 Pro')]
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPhone')))
PY
)"
simulator_id="$(xcrun simctl create 'Pocket Gemma UI verification' "$device_type" "$runtime_id")"
recording_pid=""
pad_id=""
stop_recording() {
  if [[ -n "$recording_pid" ]]; then
    kill -INT "$recording_pid" 2>/dev/null || true
    wait "$recording_pid" || true
    recording_pid=""
  fi
}
trap 'stop_recording; xcrun simctl shutdown "$simulator_id" || true; if [[ -n "$pad_id" ]]; then xcrun simctl shutdown "$pad_id" || true; fi' EXIT
xcrun simctl boot "$simulator_id"
xcrun simctl bootstatus "$simulator_id" -b
xcrun simctl status_bar "$simulator_id" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 --batteryState charged --batteryLevel 100
# Compile first, so the recording contains the interactions rather than a long
# simulator startup or compiler wait. This uses the same derived test products.
xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
  -destination "platform=iOS Simulator,id=$simulator_id" \
  -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build-for-testing
xcrun simctl io "$simulator_id" recordVideo --codec=h264 build/UI/interaction.mp4 > build/UI/recording.log 2>&1 &
recording_pid=$!
set +e
xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
  -destination "platform=iOS Simulator,id=$simulator_id" \
  -derivedDataPath build/DerivedData -resultBundlePath build/UI/Preview.xcresult \
  -parallel-testing-enabled NO \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
test_exit=$?
set -e
stop_recording
if [[ -d build/UI/Preview.xcresult ]]; then
  xcrun xcresulttool export attachments --path build/UI/Preview.xcresult --output-path build/UI/attachments || true
fi
if [[ "$test_exit" -ne 0 ]]; then
  xcrun simctl io "$simulator_id" screenshot build/UI/failure.png || true
fi
if [[ "$test_exit" -eq 0 ]]; then
  xcrun simctl shutdown "$simulator_id"
  pad_type="$(python3 - <<'PY'
import json
with open('build/UI/devicetypes.json') as f: devices = json.load(f)['devicetypes']
preferred = [d for d in devices if d['name'] == 'iPad Pro 11-inch (M4)']
print(preferred[0]['identifier'] if preferred else next(d['identifier'] for d in reversed(devices) if d['name'].startswith('iPad')))
PY
)"
  pad_id="$(xcrun simctl create 'Pocket Gemma iPad startup' "$pad_type" "$runtime_id")"
  xcrun simctl boot "$pad_id"
  xcrun simctl bootstatus "$pad_id" -b
  set +e
  xcodebuild -project PocketGemmaPreview.xcodeproj -scheme PocketGemmaPreview \
    -destination "platform=iOS Simulator,id=$pad_id" \
    -derivedDataPath build/DerivedData -resultBundlePath build/UI/iPad.xcresult \
    -parallel-testing-enabled NO \
    -only-testing:PocketGemmaUITests/ChatMotionUITests/testFirstLaunchModelChoiceAndCompletionPersist \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
  test_exit=$?
  set -e
  if [[ -d build/UI/iPad.xcresult ]]; then
    xcrun xcresulttool export attachments --path build/UI/iPad.xcresult --output-path build/UI/ipad-attachments || true
  fi
fi
exit "$test_exit"
