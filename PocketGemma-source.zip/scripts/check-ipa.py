"""Check actual packaged output, including architecture and bundled frameworks."""
import plistlib
import hashlib
import json
import struct
import sys
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'NativeRuntime'))
from native_artifact import FRAMEWORKS, INSTALL_NAMES, macho

def check(path, with_watch=True):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None, 'Duplicate or corrupt IPA members'
        base = "Payload/PocketGemma.app/"
        info = plistlib.loads(archive.read(base + "Info.plist"))
        executable = archive.read(base + info["CFBundleExecutable"])
        assert info["CFBundlePackageType"] == "APPL", "Bundle must be an iPhone app"
        assert "iPhoneOS" in info.get("CFBundleSupportedPlatforms", []), "Simulator apps cannot be sideloaded"
        assert info["CFBundleIdentifier"] == "app.pocketgemma.personal"
        assert info.get("CFBundleDisplayName") == "Fielua", "The home screen name is Fielua"
        magic, cpu = struct.unpack("<II", executable[:8])
        assert magic == 0xFEEDFACF and cpu == 0x0100000C, "Expected an ARM64 device executable"
        assert not any(name.endswith((".litertlm", ".gguf")) for name in names), "Model must be downloaded on device"
        # The licenses of llama.cpp and LFM3 1.7B ship in the app (1.1.0 (232)).
        for license in ("llama.cpp.txt", "LFM-Open-License-v1.0.txt"):
            assert base + license in names, f"License text missing: {license}"
        # A download keeps the app running in the background through a
        # continued-processing task, not a silent sound: iOS refuses island
        # updates from an app kept running by sound alone.
        assert "audio" not in info.get("UIBackgroundModes", []), "Background audio mode must stay off"
        assert any(pattern.endswith(".model-download.*") for pattern in info.get("BGTaskSchedulerPermittedIdentifiers", [])), \
            "Continued download task identifiers missing"
        # Swift Package Manager embeds dynamic binary dependencies; static ones
        # are linked into the executable. Check any embedded framework is real.
        frameworks = [name for name in names if name.endswith(".framework/Info.plist")]
        for framework_plist in frameworks:
            details = plistlib.loads(archive.read(framework_plist))
            binary = framework_plist.removesuffix("Info.plist") + details["CFBundleExecutable"]
            assert binary in names, f"Missing framework binary: {binary}"
        # App extensions (the model download's Live Activity): AltStore signs
        # each one, so it needs its binary, an identifier under the app's and
        # the app's version.
        for extension_plist in [name for name in names if name.startswith(base + "PlugIns/") and name.endswith(".appex/Info.plist")]:
            extension = plistlib.loads(archive.read(extension_plist))
            assert extension_plist.removesuffix("Info.plist") + extension["CFBundleExecutable"] in names, "Missing extension binary"
            assert extension["CFBundleIdentifier"].startswith(info["CFBundleIdentifier"] + "."), "Extension identifier must extend the app's"
            assert (extension.get("CFBundleShortVersionString"), extension.get("CFBundleVersion")) == \
                (info.get("CFBundleShortVersionString"), info.get("CFBundleVersion")), "Extension version must match the app"
            assert "NSExtensionPointIdentifier" in extension.get("NSExtension", {}), "Extension point missing"
            assert extension.get("CFBundleDisplayName") == info["CFBundleDisplayName"], "Extension name must match the app's"
        # The Apple Watch app (2026-10-23): a watch app of this iPhone app,
        # named and numbered as it is. The sideload IPA leaves it out
        # (--no-watch), since SideInstaller can't install it (build-ios.sh).
        watch_base = base + "Watch/PocketWatch.app/"
        if with_watch:
            assert watch_base + "Info.plist" in names, "Apple Watch app missing"
            watch = plistlib.loads(archive.read(watch_base + "Info.plist"))
            assert watch_base + watch["CFBundleExecutable"] in names, "Missing Apple Watch app binary"
            assert watch.get("WKApplication") is True, "The Apple Watch app must be a watch app"
            assert watch.get("WKCompanionAppBundleIdentifier") == info["CFBundleIdentifier"], "Apple Watch app must name this app"
            assert watch["CFBundleIdentifier"].startswith(info["CFBundleIdentifier"] + "."), "Watch identifier must extend the app's"
            assert "WatchOS" in watch.get("CFBundleSupportedPlatforms", []), "Apple Watch app must be built for the watch"
            assert (watch.get("CFBundleShortVersionString"), watch.get("CFBundleVersion"), watch.get("CFBundleDisplayName")) == \
                (info.get("CFBundleShortVersionString"), info.get("CFBundleVersion"), info["CFBundleDisplayName"]), \
                "Apple Watch app version and name must match the app"
        else:
            assert not any(name.startswith(base + "Watch/") for name in names), "The sideload IPA must leave the Apple Watch app out"
        if base + 'runtime-build.json' in names:
            receipt = json.loads(archive.read(base + 'runtime-build.json'))
            assert receipt['target'] == 'iphoneos'
            assert receipt['runtimeVersion'] == '0.18.0'
            assert receipt['artifactSHA256'] == 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347'
            for native in receipt['nativeFiles']:
                data = archive.read(base + native['name'])
                assert native['bytes'] == len(data) and native['sha256'] == hashlib.sha256(data).hexdigest(), 'Runtime receipt does not match embedded native bytes'
            if receipt.get('nativeBuild'):
                minimum = tuple(int(v) for v in info['MinimumOSVersion'].split('.'))
                assert minimum >= (26, 4), 'Pinned native dependencies require iOS 26.4 or later'
                expected = {f'Frameworks/{name}.framework/{name}' for name in FRAMEWORKS}
                assert {n['name'] for n in receipt['nativeFiles']} == expected and len(receipt['nativeFiles']) == 3, 'IPA lacks a native runtime dependency'
                for native in receipt['nativeFiles']:
                    details = macho(archive.read(base + native['name']), 2)
                    native_minimum = details['minimumOS']
                    native_version = (native_minimum >> 16, (native_minimum >> 8) & 255)
                    assert native_version <= minimum[:2], 'Native library requires a newer iOS version than the app declares'
                    name = native['name'].split('/')[-1]
                    assert details['installName'] == INSTALL_NAMES[name], 'Wrong IPA framework install ID'
                    assert all(d in INSTALL_NAMES.values() or d.startswith(('/System/Library/', '/usr/lib/')) for d in details['dependencies']), 'IPA has an unpackaged native dependency'
        print(f"IPA structure OK: {info['CFBundleIdentifier']} ({info['CFBundleDisplayName']}), ARM64, {len(frameworks)} embedded frameworks, "
              + (f"Apple Watch app {watch['CFBundleIdentifier']}" if with_watch else "no Apple Watch app (sideload)"))

if __name__ == "__main__":
    check(sys.argv[1], with_watch="--no-watch" not in sys.argv[2:])

