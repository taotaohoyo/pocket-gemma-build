// Extracts closely spaced frames around marked moments of the UI test
// recording and lays them out on one JPEG per mark, so motion can be
// reviewed from the log without downloading the video.
// Usage: swift motion-frames.swift <video.mp4> <recordingStartEpoch> <outDir> name=epoch=offsetMs=stepMs=count ...
import AVFoundation
import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

let arguments = CommandLine.arguments
guard arguments.count >= 5, let start = Double(arguments[2]) else {
    print("usage: motion-frames.swift video start outDir marks..."); exit(2)
}
let asset = AVURLAsset(url: URL(fileURLWithPath: arguments[1]))
let generator = AVAssetImageGenerator(asset: asset)
generator.appliesPreferredTrackTransform = true
generator.requestedTimeToleranceBefore = .zero
generator.requestedTimeToleranceAfter = .zero
let duration = (try? await asset.load(.duration).seconds) ?? 0

for spec in arguments.dropFirst(4) {
    let parts = spec.split(separator: "=").map(String.init)
    guard parts.count == 5, let mark = Double(parts[1]), let offset = Double(parts[2]),
          let step = Double(parts[3]), let count = Int(parts[4]) else { continue }
    var frames: [CGImage] = []
    for index in 0..<count {
        let seconds = mark - start + (offset + Double(index) * step) / 1000
        guard seconds >= 0, seconds <= duration else { continue }
        if let image = try? await generator.image(at: CMTime(seconds: seconds, preferredTimescale: 600)).image {
            frames.append(image)
        }
    }
    guard let first = frames.first else { print("MOTION-FRAMES \(parts[0]): no frames"); continue }
    // The composer area: the lower part of the screen.
    let crop = CGRect(x: 0, y: Double(first.height) * 0.6, width: Double(first.width), height: Double(first.height) * 0.36)
    let scale = 0.25, columns = 5
    let cell = CGSize(width: crop.width * scale, height: crop.height * scale)
    let rows = (frames.count + columns - 1) / columns
    let gap = 4.0
    let size = CGSize(width: (cell.width + gap) * Double(columns), height: (cell.height + gap) * Double(rows))
    guard let context = CGContext(data: nil, width: Int(size.width), height: Int(size.height), bitsPerComponent: 8,
                                  bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { continue }
    context.setFillColor(CGColor(red: 1, green: 0, blue: 0.5, alpha: 1))
    context.fill(CGRect(origin: .zero, size: size))
    for (index, frame) in frames.enumerated() {
        guard let part = frame.cropping(to: crop) else { continue }
        let column = index % columns, row = index / columns
        let rect = CGRect(x: Double(column) * (cell.width + gap),
                          y: size.height - Double(row + 1) * (cell.height + gap),
                          width: cell.width, height: cell.height)
        context.draw(part, in: rect)
    }
    guard let sheet = context.makeImage() else { continue }
    let url = URL(fileURLWithPath: arguments[3]).appendingPathComponent("motion-\(parts[0]).jpg")
    guard let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil) else { continue }
    CGImageDestinationAddImage(destination, sheet, [kCGImageDestinationLossyCompressionQuality: 0.6] as CFDictionary)
    CGImageDestinationFinalize(destination)
    print("MOTION-FRAMES \(parts[0]): \(frames.count) frames from \(Int(offset)) ms every \(Int(step)) ms")
}
