[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$taskRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskDist = Join-Path $taskRoot 'dist'
New-Item -ItemType Directory -Path $taskDist -Force | Out-Null
$taskZip = Join-Path $taskDist 'PocketGemma-source.zip'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$taskStream = [System.IO.File]::Open($taskZip, [System.IO.FileMode]::Create)
$taskArchive = [System.IO.Compression.ZipArchive]::new($taskStream, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    $taskEntries = @('.github', 'Packages', 'PocketGemma', 'Preview', 'UITests', 'scripts', 'docs', 'project.yml', 'preview-project.yml', 'README.md', '.gitignore', '.gitattributes')
    foreach ($taskEntry in $taskEntries) {
        $taskPath = Join-Path $taskRoot $taskEntry
        if ((Get-Item -LiteralPath $taskPath).PSIsContainer) {
            $taskFiles = Get-ChildItem -LiteralPath $taskPath -Recurse -File -Force
        } else {
            $taskFiles = @(Get-Item -LiteralPath $taskPath)
        }
        foreach ($taskFile in $taskFiles) {
            $taskName = [System.IO.Path]::GetRelativePath($taskRoot, $taskFile.FullName).Replace([System.IO.Path]::DirectorySeparatorChar, [char]'/')
            if ($taskName -match '(^|/)(\.build|__pycache__|\.swiftpm)(/|$)') { continue }
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($taskArchive, $taskFile.FullName, $taskName) | Out-Null
        }
    }
} finally {
    $taskArchive.Dispose()
    $taskStream.Dispose()
}
Write-Output "Source package: $taskZip"
Write-Output 'Extract this ZIP, then upload its contents (including .github) to the GitHub repository root.'
