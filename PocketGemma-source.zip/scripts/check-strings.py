#!/usr/bin/env python3
"""Every Japanese string the code asks for has its translations (1.1.0 (183)).

Reads the compiler's string lists (.stringsdata, SWIFT_EMIT_LOC_STRINGS) under
a derived data folder and the String Catalogs given after it, and prints
LOC-MISSING for a key the code uses that no catalog has, LOC-INCOMPLETE for a
key without English, Chinese or Korean, LOC-UNUSED for a catalog key no list
names (some are looked up at run time), and LOC-LPROJ for the languages each
built app carries. Exits 1 when a key is missing or incomplete.

usage: check-strings.py <derived data> <catalog.xcstrings>...
"""
import json
import pathlib
import re
import sys

derived = pathlib.Path(sys.argv[1])
known: dict[str, set[str]] = {}
manual: set[str] = set()
for name in sys.argv[2:]:
    catalog = json.loads(pathlib.Path(name).read_text(encoding='utf-8'))
    for key, entry in catalog['strings'].items():
        known.setdefault(key, set()).update(entry.get('localizations', {}))
        if entry.get('extractionState') == 'manual':
            manual.add(key)

used: dict[str, set[str]] = {}
intermediates = derived / 'Build' / 'Intermediates.noindex'
for path in intermediates.rglob('*.stringsdata'):
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (ValueError, UnicodeDecodeError):
        print('LOC-UNREADABLE', path.name, path.read_bytes()[:160])
        continue
    source = pathlib.Path(data.get('source', path.stem)).name
    for table, entries in data.get('tables', {}).items():
        for item in entries:
            used.setdefault(item['key'], set()).add(f'{table}:{source}')

japanese = re.compile('[぀-ヿ一-鿿！-～]')
missing = sorted(key for key in used if key not in known and japanese.search(key))
incomplete = sorted(key for key in used if key in known and not {'en', 'zh-Hans', 'zh-Hant', 'ko'} <= known[key])
unused = sorted(key for key in known if key not in used and key not in manual)
for key in missing:
    print('LOC-MISSING', json.dumps(key, ensure_ascii=False), ', '.join(sorted(used[key])[:3]))
for key in incomplete:
    print('LOC-INCOMPLETE', json.dumps(key, ensure_ascii=False), sorted(known[key]))
for key in unused:
    print('LOC-UNUSED', json.dumps(key, ensure_ascii=False))
print(f'LOC-SUMMARY keys used {len(used)}, missing {len(missing)}, incomplete {len(incomplete)}, '
      f'unused {len(unused)} (of {len(known)} in the catalogs, {len(manual)} looked up at run time)')

products = derived / 'Build' / 'Products'
for app in sorted(products.glob('*/*.app')) + sorted(products.glob('*/*.app/PlugIns/*.appex')) \
        + sorted(products.glob('*/*.app/Watch/*.app')):
    languages = sorted(p.stem for p in app.glob('*.lproj') if (p / 'Localizable.strings').exists())
    info = app / 'Info.plist'
    region = ''
    if info.exists():
        import plistlib
        with info.open('rb') as handle:
            plist = plistlib.load(handle)
        region = f"region={plist.get('CFBundleDevelopmentRegion')} localizations={plist.get('CFBundleLocalizations')}"
    print('LOC-LPROJ', app.relative_to(products), languages, region)

sys.exit(1 if missing or incomplete else 0)
