// The phone's history drawer filmed a sixtieth of a second a frame (1.1.0
// (272), DrawerFilm in the preview): each film's frames, kept by the app as
// JPEGs, made into an H.264 film at sixty frames a second and printed into
// the log as base64 (SHOT drawer-film-<name>.mp4), for review where
// artifact downloads are unavailable.
//
// swift scripts/drawer-film.swift <frames root> <output dir>
import AVFoundation
import CoreGraphics
import Foundation
import ImageIO

let arguments = CommandLine.arguments
guard arguments.count == 3 else { print("DRAWER-FILM usage: frames-root out"); exit(2) }
let root = URL(fileURLWithPath: arguments[1], isDirectory: true)
let output = URL(fileURLWithPath: arguments[2], isDirectory: true)
try? FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
let films = ((try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)) ?? [])
    .filter { $0.hasDirectoryPath }
    .sorted { $0.lastPathComponent < $1.lastPathComponent }
print("DRAWER-FILM films=\(films.count)")

func image(_ url: URL) -> CGImage? {
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
    return CGImageSourceCreateImageAtIndex(source, 0, nil)
}

for film in films {
    let frames = ((try? FileManager.default.contentsOfDirectory(at: film, includingPropertiesForKeys: nil)) ?? [])
        .filter { $0.pathExtension == "jpg" }
        .sorted { $0.lastPathComponent < $1.lastPathComponent }
    guard let first = frames.first.flatMap(image) else { print("DRAWER-FILM \(film.lastPathComponent) no frames"); continue }
    let width = 540
    let height = Int((Double(width) * Double(first.height) / Double(first.width) / 2).rounded()) * 2
    let url = output.appendingPathComponent("drawer-film-\(film.lastPathComponent).mp4")
    try? FileManager.default.removeItem(at: url)
    guard let writer = try? AVAssetWriter(outputURL: url, fileType: .mp4) else { continue }
    let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
        AVVideoCodecKey: AVVideoCodecType.h264,
        AVVideoWidthKey: width,
        AVVideoHeightKey: height,
        AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: 2_500_000,
                                          AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel],
    ])
    input.expectsMediaDataInRealTime = false
    let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
        kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
        kCVPixelBufferWidthKey as String: width,
        kCVPixelBufferHeightKey as String: height,
    ])
    writer.add(input)
    guard writer.startWriting() else { print("DRAWER-FILM \(film.lastPathComponent) writer: \(writer.error.map { "\($0)" } ?? "?")"); continue }
    writer.startSession(atSourceTime: .zero)
    var written = 0
    for (index, frame) in frames.enumerated() {
        guard let picture = image(frame), let pool = adaptor.pixelBufferPool else { continue }
        var buffer: CVPixelBuffer?
        CVPixelBufferPoolCreatePixelBuffer(nil, pool, &buffer)
        guard let buffer else { continue }
        CVPixelBufferLockBaseAddress(buffer, [])
        if let context = CGContext(data: CVPixelBufferGetBaseAddress(buffer), width: width, height: height,
                                   bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
                                   space: CGColorSpaceCreateDeviceRGB(),
                                   bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) {
            context.interpolationQuality = .high
            context.draw(picture, in: CGRect(x: 0, y: 0, width: width, height: height))
        }
        CVPixelBufferUnlockBaseAddress(buffer, [])
        while !input.isReadyForMoreMediaData { Thread.sleep(forTimeInterval: 0.005) }
        if adaptor.append(buffer, withPresentationTime: CMTime(value: CMTimeValue(index), timescale: 60)) { written += 1 }
    }
    input.markAsFinished()
    let done = DispatchSemaphore(value: 0)
    writer.finishWriting { done.signal() }
    done.wait()
    guard writer.status == .completed, let data = try? Data(contentsOf: url) else {
        print("DRAWER-FILM \(film.lastPathComponent) failed: \(writer.error.map { "\($0)" } ?? "?")")
        continue
    }
    print("DRAWER-FILM \(film.lastPathComponent) frames=\(frames.count) written=\(written) size=\(width)x\(height) bytes=\(data.count)")
    print("SHOT-BEGIN drawer-film-\(film.lastPathComponent).mp4"); print(data.base64EncodedString()); print("SHOT-END")
}
