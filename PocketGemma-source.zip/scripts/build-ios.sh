#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh

if ! command -v xcodegen >/dev/null; then
  echo "Install XcodeGen on the macOS build machine first: brew install xcodegen" >&2
  exit 1
fi
xcodegen generate --spec project.yml
# No -sdk: the destination picks the iPhone SDK for the app and the watchOS
# SDK for its Apple Watch app.
xcodebuild \
  -project PocketGemma.xcodeproj \
  -scheme PocketGemma \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  build

app_path='build/DerivedData/Build/Products/Release-iphoneos/PocketGemma.app'
test -f "$app_path/PocketGemma"
test -f "$app_path/Info.plist"
# 120Hz for the app's own animations on iPhone (project.yml).
[[ "$(/usr/libexec/PlistBuddy -c 'Print :CADisableMinimumFrameDurationOnPhone' "$app_path/Info.plist")" == true ]]
# The model download's Live Activity (Dynamic Island) extension.
test -f "$app_path/PlugIns/PocketActivity.appex/Info.plist"
# The Apple Watch app, built with the iPhone app (TestFlight ships it).
test -f "$app_path/Watch/PocketWatch.app/Info.plist"
test -f "$app_path/Watch/PocketWatch.app/PocketWatch"
# Five languages (1.1.0 (183), Traditional Chinese 187): every Japanese string the app, its Live
# Activity and its watch app ask for is translated, and each carries them.
python3 scripts/check-strings.py build/DerivedData PocketGemma/Localization/Localizable.xcstrings \
  Activity/Localizable.xcstrings Watch/Localizable.xcstrings || echo 'LOC-CHECK: strings without translations, listed above'
for bundle in "$app_path" "$app_path/PlugIns/PocketActivity.appex" "$app_path/Watch/PocketWatch.app"; do
  for language in en ja zh-Hans zh-Hant ko; do test -f "$bundle/$language.lproj/Localizable.strings"; done
done
python3 scripts/record-runtime-build.py --app "$app_path" --derived-data build/DerivedData --target iphoneos --configuration Release
mkdir -p build/Payload
# ditto preserves permissions and framework layout required for re-signing.
ditto "$app_path" build/Payload/PocketGemma.app
# The sideload IPA leaves the Apple Watch app out. SideInstaller installs
# the app as <bundle>.<Team ID> but keeps the watch app's
# WKCompanionAppBundleIdentifier, and iOS then refuses the whole install
# (InvalidCompanionAppBundleIdentifier, 1.1.0 (149), 2026-10-23). The
# watch app comes with TestFlight, whose archive keeps it.
rm -rf build/Payload/PocketGemma.app/Watch
# Open-source licenses of bundled code (Apache-2.0 / MIT require a copy with
# the binary). Settings > オープンソースライセンス shows these files.
licenses=build/Payload/PocketGemma.app/ThirdPartyLicenses
mkdir -p "$licenses"
litert_license=Packages/PocketLiteRTLM/LICENSE
[[ -f "$litert_license" ]] || litert_license="$(find build/DerivedData/SourcePackages/checkouts -maxdepth 2 -path '*LiteRT-LM*/LICENSE' 2>/dev/null | head -1 || true)"
[[ -n "$litert_license" && -f "$litert_license" ]] && cp "$litert_license" "$licenses/LiteRT-LM.txt" || true
zip_license="$(find build/DerivedData/SourcePackages/checkouts -maxdepth 2 -path '*ZIPFoundation*/LICENSE' 2>/dev/null | head -1 || true)"
[[ -n "$zip_license" ]] && cp "$zip_license" "$licenses/ZIPFoundation.txt" || true
math_license="$(find build/DerivedData/SourcePackages/checkouts -maxdepth 2 -path '*SwiftMath*/LICENSE*' 2>/dev/null | head -1 || true)"
[[ -n "$math_license" ]] && cp "$math_license" "$licenses/SwiftMath.txt" || true
ls "$licenses"
(
  cd build
  ditto -c -k --keepParent Payload PocketGemma-unsigned.ipa
)
python3 scripts/check-ipa.py build/PocketGemma-unsigned.ipa --no-watch
echo "Built build/PocketGemma-unsigned.ipa (unsigned; install using AltStore Classic)."

