#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh

if ! command -v xcodegen >/dev/null; then
  echo "Install XcodeGen on the macOS build machine first: brew install xcodegen" >&2
  exit 1
fi
xcodegen generate --spec project.yml
# No -sdk: the destination picks the iPhone SDK for the app and the watchOS
# SDK for its Apple Watch app.
xcodebuild \
  -project PocketGemma.xcodeproj \
  -scheme PocketGemma \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  build

app_path='build/DerivedData/Build/Products/Release-iphoneos/PocketGemma.app'
test -f "$app_path/PocketGemma"
test -f "$app_path/Info.plist"
# The model download's Live Activity (Dynamic Island) extension.
test -f "$app_path/PlugIns/PocketActivity.appex/Info.plist"
# The Apple Watch app, which installs with the iPhone app.
test -f "$app_path/Watch/PocketWatch.app/Info.plist"
test -f "$app_path/Watch/PocketWatch.app/PocketWatch"
python3 scripts/record-runtime-build.py --app "$app_path" --derived-data build/DerivedData --target iphoneos --configuration Release
mkdir -p build/Payload
# ditto preserves permissions and framework layout required for re-signing.
ditto "$app_path" build/Payload/PocketGemma.app
# Open-source licenses of bundled code (Apache-2.0 / MIT require a copy with
# the binary). Settings > オープンソースライセンス shows these files.
licenses=build/Payload/PocketGemma.app/ThirdPartyLicenses
mkdir -p "$licenses"
litert_license=Packages/PocketLiteRTLM/LICENSE
[[ -f "$litert_license" ]] || litert_license="$(find build/DerivedData/SourcePackages/checkouts -maxdepth 2 -path '*LiteRT-LM*/LICENSE' 2>/dev/null | head -1 || true)"
[[ -n "$litert_license" && -f "$litert_license" ]] && cp "$litert_license" "$licenses/LiteRT-LM.txt" || true
zip_license="$(find build/DerivedData/SourcePackages/checkouts -maxdepth 2 -path '*ZIPFoundation*/LICENSE' 2>/dev/null | head -1 || true)"
[[ -n "$zip_license" ]] && cp "$zip_license" "$licenses/ZIPFoundation.txt" || true
math_license="$(find build/DerivedData/SourcePackages/checkouts -maxdepth 2 -path '*SwiftMath*/LICENSE*' 2>/dev/null | head -1 || true)"
[[ -n "$math_license" ]] && cp "$math_license" "$licenses/SwiftMath.txt" || true
ls "$licenses"
(
  cd build
  ditto -c -k --keepParent Payload PocketGemma-unsigned.ipa
)
python3 scripts/check-ipa.py build/PocketGemma-unsigned.ipa
echo "Built build/PocketGemma-unsigned.ipa (unsigned; install using AltStore Classic)."

