"""Render the app icon: the welcome screen's aurora light (AuroraOrbShader.metal's
auroraWelcomeOrb), as it looks about 12 s in, for the light, dark and tinted home screen.
A numpy port of the shader's colours, edge and spill, drawn at twice the size and then
downsampled. Needs numpy and Pillow. The banded orb it replaced is kept in design/legacy."""
import json
from pathlib import Path

import numpy as np
from PIL import Image

root = Path(__file__).resolve().parents[1]
icons = root / "PocketGemma/Assets.xcassets/AppIcon.appiconset"
SS, FINAL = 2048, 1024            # rendered at twice the size, then downsampled
DIAMETER = 0.60                   # the light across, as a share of the canvas
TIME = 11.75                      # seconds into the welcome's flow: the frame of 1.1.0 (174)'s check

EDGE = 0.654                      # the light's rim in the shader's units
RIM = EDGE - 0.0225               # where auroraWelcomeOrb draws the outline
FEATHER = 0.0101                  # its width: a point at the welcome's 280pt canvas

LUMA = np.array([0.2126, 0.7152, 0.0722])
# The icon's colours, light mode then dark mode (a touch brighter so they carry on black).
COLOURS = {
    "red": ((0.89, 0.36, 0.31), (0.94, 0.40, 0.34)),
    "orange": ((0.945, 0.67, 0.157), (0.97, 0.70, 0.20)),
    "yellow": ((0.973, 0.753, 0.102), (0.99, 0.78, 0.15)),
    "green": ((0.125, 0.67, 0.365), (0.16, 0.74, 0.41)),
    "blue": ((0.114, 0.498, 0.96), (0.18, 0.55, 1.00)),
}


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def hash_(cx, cy):
    qx = cx.astype(np.int64).astype(np.uint32) * np.uint32(1597334673)
    qy = cy.astype(np.int64).astype(np.uint32) * np.uint32(3812015801)
    return ((qx ^ qy) * np.uint32(1597334673)).astype(np.float64) / 4294967296.0


def noise(x, y):
    cx, cy = np.floor(x), np.floor(y)
    fx, fy = x - cx, y - cy
    ux = fx * fx * fx * (fx * (fx * 6 - 15) + 10)
    uy = fy * fy * fy * (fy * (fy * 6 - 15) + 10)

    def corner(dx, dy):
        angle = hash_(cx + dx, cy + dy) * 6.2831853
        return np.cos(angle) * (fx - dx) + np.sin(angle) * (fy - dy)

    a, b, c, d = corner(0, 0), corner(1, 0), corner(0, 1), corner(1, 1)
    ab, cd = a + (b - a) * ux, c + (d - c) * ux
    return ab + (cd - ab) * uy


def fbm(x, y):
    value = 0.5 * noise(x, y)
    x, y = (0.8 * x - 0.6 * y) * 2.02 + 3.1, (0.6 * x + 0.8 * y) * 2.02 + 1.7
    return value + 0.25 * noise(x, y)


def eddy(x, y, cx, cy, turn):
    dx, dy = x - cx, y - cy
    angle = turn * np.exp(-3 * (dx * dx + dy * dy))
    c, s = np.cos(angle), np.sin(angle)
    return cx + c * dx - s * dy, cy + s * dx + c * dy


def sway(t, angle, radius, swing, swing_rate, wobble, wobble_rate, wobble_phase):
    a = angle + swing * np.sin(swing_rate * t)
    r = radius + wobble * np.sin(wobble_rate * t + wobble_phase)
    return r * np.cos(a), r * np.sin(a)


def chroma(c):
    return np.linalg.norm(np.asarray(c) - np.dot(c, LUMA))


def light(n, dark):
    """auroraWelcomeOrb at TIME on an n-pixel canvas: straight colour and alpha."""
    ys, xs = np.mgrid[0:n, 0:n].astype(np.float64)
    unit = DIAMETER * n / 2 / RIM                 # pixels per shader unit
    px, py = (xs + 0.5 - n / 2) / unit, (ys + 0.5 - n / 2) / unit
    r = np.hypot(px, py)

    # aurora::colour: beyond the rim, the rim's colour in the same direction.
    pull = np.where(r > EDGE, EDGE / np.maximum(r, 1e-9), 1.0)
    wx, wy = px * pull, py * pull
    ti = 1.6 * TIME
    wx, wy = eddy(wx, wy, 0.30 * np.sin(0.23 * ti + 0.5), 0.28 * np.cos(0.19 * ti + 2.2), 1.1 * np.sin(0.37 * ti + 0.9))
    wx, wy = eddy(wx, wy, 0.32 * np.sin(0.17 * ti + 3.9), 0.30 * np.cos(0.29 * ti + 5.1), 1.1 * np.sin(0.29 * ti + 3.8))
    wx, wy = eddy(wx, wy, 0.26 * np.sin(0.31 * ti + 1.7), 0.27 * np.cos(0.13 * ti + 0.4), 1.1 * np.sin(0.43 * ti + 5.6))
    drift = (0.045 * ti, -0.035 * ti)
    bend_x = fbm(wx * 1.3 + drift[0], wy * 1.3 + drift[1])
    bend_y = fbm(wx * 1.3 + 5.2 - drift[1], wy * 1.3 + 1.3 - drift[0])
    wx, wy = wx + 0.18 * bend_x, wy + 0.18 * bend_y

    places = {
        "red": sway(ti, -1.5708, 0.40, 0.32, 0.19, 0.05, 0.27, 0.8),
        "orange": sway(ti, -2.30, 0.40, -0.22, 0.23, 0.04, 0.31, 2.0),
        "yellow": sway(ti, 3.1416, 0.42, 0.30, 0.13, 0.05, 0.21, 4.1),
        "green": sway(ti, 1.5708, 0.40, -0.30, 0.17, 0.05, 0.29, 1.3),
        "blue": sway(ti, 0.0, 0.36, 0.34, 0.11, 0.06, 0.23, 5.0),
    }
    centre = (0.10 * np.sin(0.37 * ti + 0.4), 0.08 * np.cos(0.29 * ti + 1.9))
    spreads = {"red": 12.0, "orange": 16.0, "yellow": 12.0 * 0.9, "green": 12.0 * 0.85, "blue": 12.0}
    colours = {k: np.array(v[0]) + (np.array(v[1]) - np.array(v[0])) * dark for k, v in COLOURS.items()}

    def glow(at, spread):
        return np.exp(-spread * ((wx - at[0]) ** 2 + (wy - at[1]) ** 2))

    weights = {k: glow(places[k], spreads[k]) for k in places}
    weights["blue"] = weights["blue"] + 0.55 * glow(centre, 2.5) + 0.03
    total = sum(weights.values())
    rgb = sum(colours[k] * weights[k][..., None] for k in weights) / total[..., None]

    want = sum(chroma(colours[k]) * weights[k] for k in weights) / total
    luma = rgb @ LUMA
    have = np.linalg.norm(rgb - luma[..., None], axis=-1)
    seam = 4 * weights["red"] * weights["blue"] / (total * total)
    gain = 1 + 0.65 * (1 - 0.75 * seam) * (np.clip(want / np.maximum(have, 1e-4), 1, 2.5) - 1)
    rgb = luma[..., None] + (rgb - luma[..., None]) * gain[..., None]

    mist = 0.5 + 1.2 * fbm(wx * 1.4 - 0.05 * ti, wy * 1.4 + 0.04 * ti)
    rgb = rgb * (0.93 + 0.11 * mist)[..., None]
    rgb = rgb * (1 - 0.03 * smoothstep(0.7 * EDGE, EDGE, r))[..., None]

    # The outline and aurora::spill, the soft tinted shadow around it.
    core = 1 - smoothstep(RIM - FEATHER / 2, RIM + FEATHER / 2, r)
    beyond = np.maximum(np.hypot(px, py - 0.10) - EDGE, 0)
    spill = (0.28 + 0.06 * dark) * np.exp(-beyond / 0.22) * (1 - smoothstep(0.85, 1.2, r))
    alpha = np.where(r < 1.2, core + (1 - core) * spill, 0)
    return np.clip(rgb, 0, 1), alpha


def hex_rgb(h):
    return np.array([int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)])


def render(mode, n=SS):
    dark = 1.0 if mode == "dark" else 0.0
    rgb, alpha = light(n, dark)
    # Blended as the app does, in sRGB values, over the home screen tile.
    y = (np.mgrid[0:n, 0:n][0] / (n - 1))[..., None]
    top, bottom = ("#0d0c14", "#040407") if dark else ("#fbfbfd", "#f1f2f7")
    bg = hex_rgb(top) * (1 - y) + hex_rgb(bottom) * y
    out = rgb * alpha[..., None] + bg * (1 - alpha[..., None])
    image = Image.fromarray((np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8))
    return image.resize((FINAL, FINAL), Image.Resampling.LANCZOS)


def tinted(dark):
    """Grayscale for the tinted home screen: iOS colours it, so keep the colours as light and shade."""
    gray = np.asarray(dark.convert("L")).astype(np.float64) / 255
    gray = np.clip((gray - 0.03) / (np.percentile(gray, 99.7) - 0.03), 0, 1) ** 1.15
    return Image.fromarray((gray * 255 + 0.5).astype(np.uint8)).convert("RGB")


icons.mkdir(parents=True, exist_ok=True)
render("light").save(icons / "AppIcon.png")
dark = render("dark")
dark.save(icons / "AppIcon-Dark.png")
tinted(dark).save(icons / "AppIcon-Tinted.png")
(icons / "Contents.json").write_text(json.dumps({
    "images": [
        {"filename": "AppIcon.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"},
        {"appearances": [{"appearance": "luminosity", "value": "dark"}],
         "filename": "AppIcon-Dark.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"},
        {"appearances": [{"appearance": "luminosity", "value": "tinted"}],
         "filename": "AppIcon-Tinted.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"},
    ],
    "info": {"author": "xcode", "version": 1},
}, indent=2))
print(icons)
