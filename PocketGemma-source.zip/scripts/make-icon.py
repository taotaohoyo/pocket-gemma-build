"""Render Fielua's icons and launch art from the flower (brand 2026-10-27).

The five-petal mark lives in design/brand/flower.json: cubic outlines traced
from the reference artwork and a colour mesh per petal fitted to it. This
script draws it with numpy and Pillow (no other tools) for:

- the app icon: light (warm paper tile), dark (warm charcoal tile) and
  tinted (the flower's lightness on black, which iOS colours). Since 1.1.0
  (214) the icon draws the mark its own way (`icon_flower`): the same
  outlines in a deeper gold, with crisp gaps between the petals, so the
  flower stands out from the tile at home-screen size instead of fading
  into it (user, 2026-10-27: the 212 icon looked pale and blurred);
- the Apple Watch icon (the light one);
- FieluaIcon (the home-screen icon drawn in the 起動時のチャット preview);
- LaunchFlower and LaunchBackground (iOS's launch screen);
- PaperGrain (the paper's faint grain, light and dark);
- design/brand/ exports for sharing.

The app draws the same mark from vectors (PocketGemma/Views/FlowerMark.swift).
The banded-orb icon of 1.1.0 (176) and its script are kept in design/legacy.
Needs numpy and Pillow.
"""
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

root = Path(__file__).resolve().parents[1]
catalog = root / "PocketGemma/Assets.xcassets"
brand = root / "design/brand"
FLOWER = json.loads((brand / "flower.json").read_text())

PAPER = (0xFA, 0xF7, 0xF1)
NIGHT = (0x17, 0x15, 0x12)


def bezier(c, t):
    t = t[:, None]
    p0, p1, p2, p3 = (np.array(p, float) for p in c)
    return (1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3


def outline(index, steps=64):
    t = np.linspace(0, 1, steps, endpoint=False)
    return np.vstack([bezier(s, t) for s in FLOWER["petals"][index]])


def bounds():
    pts = np.vstack([outline(i, 128) for i in range(5)])
    return pts.min(0), pts.max(0)


def catmull(p0, p1, p2, p3, t):
    return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
                  + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3)


def mesh_colour(mesh, u, v):
    """The petal's colour at (u, v) in 0...1 along and across: a smooth
    curve through the grid's colours (as SwiftUI's MeshGradient draws it)."""
    rows, cols = mesh["rows"], mesh["columns"]
    grid = np.array(mesh["colors"], float).reshape(rows, cols, 3)
    padded = np.pad(grid, ((1, 1), (1, 1), (0, 0)), mode="edge")
    gu, gv = np.clip(u, 0, 1) * (rows - 1), np.clip(v, 0, 1) * (cols - 1)
    iu = np.clip(np.floor(gu).astype(int), 0, rows - 2)
    iv = np.clip(np.floor(gv).astype(int), 0, cols - 2)
    fu, fv = (gu - iu)[..., None], (gv - iv)[..., None]
    across = [catmull(*(padded[iu + k, iv + j] for j in range(4)), fv) for k in range(4)]
    return np.clip(catmull(*across, fu), 0, 255)


def flower(width, supersample=4):
    """The flower, `width` pixels wide, on transparency (RGBA)."""
    lo, hi = bounds()
    scale = width / (hi - lo)[0]
    height = int(math.ceil((hi - lo)[1] * scale))
    S = supersample
    W, H = width * S, height * S
    yy, xx = np.mgrid[0:H, 0:W] + 0.5
    X = xx / (scale * S) + lo[0]
    Y = yy / (scale * S) + lo[1]
    rgb = np.zeros((H, W, 3))
    alpha = np.zeros((H, W))
    for i, mesh in enumerate(FLOWER["meshes"]):
        poly = (outline(i) - lo) * scale * S
        mask_img = Image.new("L", (W, H), 0)
        ImageDraw.Draw(mask_img).polygon([tuple(p) for p in poly], fill=255)
        inside = np.asarray(mask_img) > 127
        a = math.radians(mesh["axis"])
        along = (math.cos(a), math.sin(a))
        across = (math.cos(a + math.pi / 2), math.sin(a + math.pi / 2))
        u = ((X * along[0] + Y * along[1]) - mesh["u"][0]) / (mesh["u"][1] - mesh["u"][0])
        v = ((X * across[0] + Y * across[1]) - mesh["v"][0]) / (mesh["v"][1] - mesh["v"][0])
        rgb[inside] = mesh_colour(mesh, u[inside], v[inside])
        alpha[inside] = 255
    image = Image.fromarray(np.dstack([rgb, alpha]).astype(np.uint8), "RGBA")
    return image.resize((width, height), Image.LANCZOS)


def smoothstep(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def icon_flower(width, base, tip, side=0.10, gap=0.010, supersample=4):
    """The mark for the app icon, `width` pixels wide (RGBA): each petal from
    `base` at the centre to `tip`, a touch lighter on the side toward the
    next petal, and a gap `gap` of the icon's width cut along each petal's
    edge where it lies over the one before, so the five read apart."""
    lo, hi = bounds()
    scale = width / (hi - lo)[0]
    height = int(math.ceil((hi - lo)[1] * scale))
    S = supersample
    W, H = width * S, height * S
    yy, xx = np.mgrid[0:H, 0:W] + 0.5
    X = xx / (scale * S) + lo[0]
    Y = yy / (scale * S) + lo[1]
    rgb = np.zeros((H, W, 3))
    alpha = np.zeros((H, W))
    base, tip = np.array(base, float), np.array(tip, float)
    for i, mesh in enumerate(FLOWER["meshes"]):
        poly = [tuple(p) for p in (outline(i, 96) - lo) * scale * S]
        mask_img = Image.new("L", (W, H), 0)
        ImageDraw.Draw(mask_img).polygon(poly, fill=255)
        inside = np.asarray(mask_img) > 127
        a = math.radians(mesh["axis"])
        along = (math.cos(a), math.sin(a))
        across = (math.cos(a + math.pi / 2), math.sin(a + math.pi / 2))
        u = ((X * along[0] + Y * along[1]) - mesh["u"][0]) / (mesh["u"][1] - mesh["u"][0])
        v = ((X * across[0] + Y * across[1]) - mesh["v"][0]) / (mesh["v"][1] - mesh["v"][0])
        t = smoothstep(u[inside] * 1.05)[:, None]
        colour = base * (1 - t) + tip * t + (v[inside] - 0.5)[:, None] * side * 255
        edge = Image.new("L", (W, H), 0)
        ImageDraw.Draw(edge).line(poly + [poly[0]], fill=255, width=max(1, int(gap * width * S / 0.66)), joint="curve")
        alpha[(np.asarray(edge) > 127) & ~inside] = 0
        rgb[inside] = np.clip(colour, 0, 255)
        alpha[inside] = 255
    image = Image.fromarray(np.dstack([rgb, alpha]).astype(np.uint8), "RGBA")
    return image.resize((width, height), Image.LANCZOS)


# The icon's flower: deep gold at the centre to a warm yellow at the tips
# on paper, a little lighter on charcoal (1.1.0 (214)).
ICON_GOLD = ((232, 160, 18), (255, 212, 84))
ICON_GOLD_NIGHT = ((236, 168, 30), (255, 220, 110))


def tile(size, top, bottom):
    """A square of a soft vertical gradient."""
    t = np.linspace(0, 1, size)[:, None, None]
    colours = np.array(top, float) * (1 - t) + np.array(bottom, float) * t
    return Image.fromarray(np.broadcast_to(colours, (size, size, 3)).astype(np.uint8), "RGB").convert("RGBA")


# Where the flower's weight sits on the icon, from the top (1.1.0 (215)).
# Its box centred (214) put the weight 3.3% low: the single petal at the
# top is slimmer than the two at the bottom, so the eye read the flower as
# sitting low (user, 2026-10-27). The mass centre is also within 0.4% of
# the centre of the circle through the five tips. At 49.7% (215) it looked
# a little high on the phone, so it sits a hair below the middle (user,
# 2026-10-28).
ICON_CENTRE = 0.505


def mass_centre(mark):
    """The mark's centre of weight (its opacity), in pixels from its top."""
    a = np.asarray(mark.split()[3], float)
    return (a.sum(axis=1) * np.arange(a.shape[0])).sum() / a.sum() + 0.5


def place(base, mark, centre_y=ICON_CENTRE, shadow=None):
    """The flower on `base`, centred across and its weight at `centre_y`
    down the tile (not its box: see ICON_CENTRE)."""
    size = base.size[0]
    x = (size - mark.size[0]) // 2
    y = int(round(size * centre_y - mass_centre(mark)))
    if shadow:
        colour, opacity, blur, drop = shadow
        a = np.asarray(mark.split()[3], float) * opacity
        shade = Image.fromarray(np.dstack([np.full(a.shape + (3,), colour, float), a]).astype(np.uint8), "RGBA")
        pad = Image.new("RGBA", base.size, (0, 0, 0, 0))
        pad.alpha_composite(shade, (x, y + drop))
        base.alpha_composite(pad.filter(ImageFilter.GaussianBlur(blur)))
    base.alpha_composite(mark, (x, y))
    return base


def app_icon(size=1024, dark=False):
    width = int(size * 0.66)
    if dark:
        mark = icon_flower(width, *ICON_GOLD_NIGHT, gap=0.010)
        base = tile(size, (0x2B, 0x27, 0x22), (0x14, 0x12, 0x10))
        return place(base, mark, shadow=((0, 0, 0), 0.40, size * 0.02, int(size * 0.01)))
    mark = icon_flower(width, *ICON_GOLD, gap=0.010)
    base = tile(size, (0xFC, 0xF9, 0xF3), (0xF2, 0xEB, 0xDE))
    return place(base, mark, shadow=((0x8A, 0x5A, 0x08), 0.16, size * 0.018, int(size * 0.010)))


def tinted_icon(size=1024):
    """The flower's lightness on black: iOS colours it with the person's tint."""
    mark = icon_flower(int(size * 0.66), *ICON_GOLD, gap=0.010)
    r, g, b, a = (np.asarray(c, float) for c in mark.split())
    lightness = (0.2126 * r + 0.7152 * g + 0.0722 * b) * a / 255
    grey = Image.fromarray(np.clip(lightness, 0, 255).astype(np.uint8), "L").convert("RGBA")
    grey.putalpha(mark.split()[3])
    base = Image.new("RGBA", (size, size), (0, 0, 0, 255))
    return place(base, grey)


def grain(size, dark):
    """A tile of faint paper grain: specks a few percent lighter or darker."""
    rng = np.random.default_rng(20261027 + int(dark))
    noise = rng.normal(0, 1, (size, size))
    # Soften to fibres about a pixel and a half across.
    noise = np.asarray(Image.fromarray(((noise + 4) * 32).clip(0, 255).astype(np.uint8)).filter(
        ImageFilter.GaussianBlur(0.6)), float) / 32 - 4
    if dark:
        colour, strength = (255, 244, 224), 0.035
    else:
        colour, strength = (92, 70, 40), 0.045
    alpha = np.clip(np.abs(noise) * strength * 255 / 2, 0, 255)
    rgb = np.broadcast_to(np.array(colour, float), (size, size, 3))
    return Image.fromarray(np.dstack([rgb, alpha]).astype(np.uint8), "RGBA")


def contents(images, info=True):
    data = {"images": images, "info": {"author": "xcode", "version": 1}}
    return json.dumps(data, indent=2) + "\n"


def save(image, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, optimize=True)


def main():
    icons = catalog / "AppIcon.appiconset"
    save(app_icon().convert("RGB"), icons / "AppIcon.png")
    save(app_icon(dark=True).convert("RGB"), icons / "AppIcon-Dark.png")
    save(tinted_icon().convert("RGB"), icons / "AppIcon-Tinted.png")
    save(app_icon().convert("RGB"), root / "Watch/Assets.xcassets/AppIcon.appiconset/AppIcon.png")

    # The home-screen icon in 起動時のチャット's preview: 64pt at 3x.
    small = catalog / "FieluaIcon.imageset"
    save(app_icon(192).convert("RGB"), small / "FieluaIcon.png")
    save(app_icon(192, dark=True).convert("RGB"), small / "FieluaIcon-Dark.png")

    # iOS's launch screen: the flower 112pt wide on the paper.
    launch = catalog / "LaunchFlower.imageset"
    for scale in (2, 3):
        save(flower(112 * scale), launch / f"LaunchFlower@{scale}x.png")
    (launch / "Contents.json").write_text(contents([
        {"filename": "LaunchFlower@2x.png", "idiom": "universal", "scale": "2x"},
        {"filename": "LaunchFlower@3x.png", "idiom": "universal", "scale": "3x"},
    ]))
    background = catalog / "LaunchBackground.colorset"
    background.mkdir(parents=True, exist_ok=True)

    def colour(rgb):
        return {"color-space": "srgb", "components": {
            "red": f"0x{rgb[0]:02X}", "green": f"0x{rgb[1]:02X}", "blue": f"0x{rgb[2]:02X}", "alpha": "1.000"}}
    (background / "Contents.json").write_text(json.dumps({"colors": [
        {"color": colour(PAPER), "idiom": "universal"},
        {"appearances": [{"appearance": "luminosity", "value": "dark"}], "color": colour(NIGHT), "idiom": "universal"},
    ], "info": {"author": "xcode", "version": 1}}, indent=2) + "\n")

    # The paper's grain: a 128pt tile at 3x, light and dark.
    paper = catalog / "PaperGrain.imageset"
    save(grain(384, dark=False), paper / "PaperGrain.png")
    save(grain(384, dark=True), paper / "PaperGrain-Dark.png")
    (paper / "Contents.json").write_text(contents([
        {"filename": "PaperGrain.png", "idiom": "universal", "scale": "3x"},
        {"appearances": [{"appearance": "luminosity", "value": "dark"}],
         "filename": "PaperGrain-Dark.png", "idiom": "universal", "scale": "3x"},
    ]))

    # For sharing: the flower alone and the icons with rounded corners.
    save(flower(1024), brand / "fielua-flower-1024.png")
    for name, image in (("light", app_icon()), ("dark", app_icon(dark=True))):
        mask = Image.new("L", image.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, 1023, 1023), radius=225, fill=255)
        image = image.copy()
        image.putalpha(mask)
        save(image, brand / f"fielua-icon-{name}.png")


if __name__ == "__main__":
    main()
