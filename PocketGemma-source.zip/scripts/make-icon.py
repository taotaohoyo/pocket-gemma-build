"""Render Fielua's icons and launch art from the flower (brand 2026-10-27).

The five-petal mark lives in design/brand/flower.json: cubic outlines traced
from the reference artwork and a colour mesh per petal fitted to it. This
script draws it with numpy and Pillow (no other tools) for:

- the app icon: light (cream paper tile), dark (warm charcoal tile) and
  tinted (the flower's lightness on black, which iOS colours);
- the Apple Watch icon (the light one);
- FieluaIcon (the home-screen icon drawn in the 起動時のチャット preview);
- LaunchFlower and LaunchBackground (iOS's launch screen);
- PaperGrain (the paper's faint grain, light and dark);
- design/brand/ exports for sharing.

The app draws the same mark from vectors (PocketGemma/Views/FlowerMark.swift).
The banded-orb icon of 1.1.0 (176) and its script are kept in design/legacy.
Needs numpy and Pillow.
"""
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

root = Path(__file__).resolve().parents[1]
catalog = root / "PocketGemma/Assets.xcassets"
brand = root / "design/brand"
FLOWER = json.loads((brand / "flower.json").read_text())

PAPER = (0xFA, 0xF7, 0xF1)
NIGHT = (0x17, 0x15, 0x12)


def bezier(c, t):
    t = t[:, None]
    p0, p1, p2, p3 = (np.array(p, float) for p in c)
    return (1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3


def outline(index, steps=64):
    t = np.linspace(0, 1, steps, endpoint=False)
    return np.vstack([bezier(s, t) for s in FLOWER["petals"][index]])


def bounds():
    pts = np.vstack([outline(i, 128) for i in range(5)])
    return pts.min(0), pts.max(0)


def catmull(p0, p1, p2, p3, t):
    return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
                  + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3)


def mesh_colour(mesh, u, v):
    """The petal's colour at (u, v) in 0...1 along and across: a smooth
    curve through the grid's colours (as SwiftUI's MeshGradient draws it)."""
    rows, cols = mesh["rows"], mesh["columns"]
    grid = np.array(mesh["colors"], float).reshape(rows, cols, 3)
    padded = np.pad(grid, ((1, 1), (1, 1), (0, 0)), mode="edge")
    gu, gv = np.clip(u, 0, 1) * (rows - 1), np.clip(v, 0, 1) * (cols - 1)
    iu = np.clip(np.floor(gu).astype(int), 0, rows - 2)
    iv = np.clip(np.floor(gv).astype(int), 0, cols - 2)
    fu, fv = (gu - iu)[..., None], (gv - iv)[..., None]
    across = [catmull(*(padded[iu + k, iv + j] for j in range(4)), fv) for k in range(4)]
    return np.clip(catmull(*across, fu), 0, 255)


def flower(width, supersample=4):
    """The flower, `width` pixels wide, on transparency (RGBA)."""
    lo, hi = bounds()
    scale = width / (hi - lo)[0]
    height = int(math.ceil((hi - lo)[1] * scale))
    S = supersample
    W, H = width * S, height * S
    yy, xx = np.mgrid[0:H, 0:W] + 0.5
    X = xx / (scale * S) + lo[0]
    Y = yy / (scale * S) + lo[1]
    rgb = np.zeros((H, W, 3))
    alpha = np.zeros((H, W))
    for i, mesh in enumerate(FLOWER["meshes"]):
        poly = (outline(i) - lo) * scale * S
        mask_img = Image.new("L", (W, H), 0)
        ImageDraw.Draw(mask_img).polygon([tuple(p) for p in poly], fill=255)
        inside = np.asarray(mask_img) > 127
        a = math.radians(mesh["axis"])
        along = (math.cos(a), math.sin(a))
        across = (math.cos(a + math.pi / 2), math.sin(a + math.pi / 2))
        u = ((X * along[0] + Y * along[1]) - mesh["u"][0]) / (mesh["u"][1] - mesh["u"][0])
        v = ((X * across[0] + Y * across[1]) - mesh["v"][0]) / (mesh["v"][1] - mesh["v"][0])
        rgb[inside] = mesh_colour(mesh, u[inside], v[inside])
        alpha[inside] = 255
    image = Image.fromarray(np.dstack([rgb, alpha]).astype(np.uint8), "RGBA")
    return image.resize((width, height), Image.LANCZOS)


def tile(size, top, bottom):
    """A square of a soft vertical gradient."""
    t = np.linspace(0, 1, size)[:, None, None]
    colours = np.array(top, float) * (1 - t) + np.array(bottom, float) * t
    return Image.fromarray(np.broadcast_to(colours, (size, size, 3)).astype(np.uint8), "RGB").convert("RGBA")


def place(base, mark, centre_y=0.5, shadow=None):
    """The flower on `base`, its box centred (a touch above the middle)."""
    size = base.size[0]
    x = (size - mark.size[0]) // 2
    y = int(size * centre_y - mark.size[1] / 2)
    if shadow:
        colour, opacity, blur, drop = shadow
        a = np.asarray(mark.split()[3], float) * opacity
        shade = Image.fromarray(np.dstack([np.full(a.shape + (3,), colour, float), a]).astype(np.uint8), "RGBA")
        pad = Image.new("RGBA", base.size, (0, 0, 0, 0))
        pad.alpha_composite(shade, (x, y + drop))
        base.alpha_composite(pad.filter(ImageFilter.GaussianBlur(blur)))
    base.alpha_composite(mark, (x, y))
    return base


def app_icon(size=1024, dark=False):
    mark = flower(int(size * 0.64))
    if dark:
        base = tile(size, (0x26, 0x23, 0x1F), (0x12, 0x10, 0x0E))
        return place(base, mark, shadow=((0, 0, 0), 0.35, size * 0.02, int(size * 0.008)))
    base = tile(size, (0xFD, 0xFB, 0xF6), (0xF3, 0xED, 0xE2))
    return place(base, mark, shadow=((0x8A, 0x63, 0x14), 0.10, size * 0.025, int(size * 0.012)))


def tinted_icon(size=1024):
    """The flower's lightness on black: iOS colours it with the person's tint."""
    mark = flower(int(size * 0.64))
    r, g, b, a = (np.asarray(c, float) for c in mark.split())
    lightness = (0.2126 * r + 0.7152 * g + 0.0722 * b) * a / 255
    grey = Image.fromarray(np.clip(lightness, 0, 255).astype(np.uint8), "L").convert("RGBA")
    grey.putalpha(mark.split()[3])
    base = Image.new("RGBA", (size, size), (0, 0, 0, 255))
    return place(base, grey)


def grain(size, dark):
    """A tile of faint paper grain: specks a few percent lighter or darker."""
    rng = np.random.default_rng(20261027 + int(dark))
    noise = rng.normal(0, 1, (size, size))
    # Soften to fibres about a pixel and a half across.
    noise = np.asarray(Image.fromarray(((noise + 4) * 32).clip(0, 255).astype(np.uint8)).filter(
        ImageFilter.GaussianBlur(0.6)), float) / 32 - 4
    if dark:
        colour, strength = (255, 244, 224), 0.035
    else:
        colour, strength = (92, 70, 40), 0.045
    alpha = np.clip(np.abs(noise) * strength * 255 / 2, 0, 255)
    rgb = np.broadcast_to(np.array(colour, float), (size, size, 3))
    return Image.fromarray(np.dstack([rgb, alpha]).astype(np.uint8), "RGBA")


def contents(images, info=True):
    data = {"images": images, "info": {"author": "xcode", "version": 1}}
    return json.dumps(data, indent=2) + "\n"


def save(image, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, optimize=True)


def main():
    icons = catalog / "AppIcon.appiconset"
    save(app_icon().convert("RGB"), icons / "AppIcon.png")
    save(app_icon(dark=True).convert("RGB"), icons / "AppIcon-Dark.png")
    save(tinted_icon().convert("RGB"), icons / "AppIcon-Tinted.png")
    save(app_icon().convert("RGB"), root / "Watch/Assets.xcassets/AppIcon.appiconset/AppIcon.png")

    # The home-screen icon in 起動時のチャット's preview: 64pt at 3x.
    small = catalog / "FieluaIcon.imageset"
    save(app_icon(192).convert("RGB"), small / "FieluaIcon.png")
    save(app_icon(192, dark=True).convert("RGB"), small / "FieluaIcon-Dark.png")

    # iOS's launch screen: the flower 112pt wide on the paper.
    launch = catalog / "LaunchFlower.imageset"
    for scale in (2, 3):
        save(flower(112 * scale), launch / f"LaunchFlower@{scale}x.png")
    (launch / "Contents.json").write_text(contents([
        {"filename": "LaunchFlower@2x.png", "idiom": "universal", "scale": "2x"},
        {"filename": "LaunchFlower@3x.png", "idiom": "universal", "scale": "3x"},
    ]))
    background = catalog / "LaunchBackground.colorset"
    background.mkdir(parents=True, exist_ok=True)

    def colour(rgb):
        return {"color-space": "srgb", "components": {
            "red": f"0x{rgb[0]:02X}", "green": f"0x{rgb[1]:02X}", "blue": f"0x{rgb[2]:02X}", "alpha": "1.000"}}
    (background / "Contents.json").write_text(json.dumps({"colors": [
        {"color": colour(PAPER), "idiom": "universal"},
        {"appearances": [{"appearance": "luminosity", "value": "dark"}], "color": colour(NIGHT), "idiom": "universal"},
    ], "info": {"author": "xcode", "version": 1}}, indent=2) + "\n")

    # The paper's grain: a 128pt tile at 3x, light and dark.
    paper = catalog / "PaperGrain.imageset"
    save(grain(384, dark=False), paper / "PaperGrain.png")
    save(grain(384, dark=True), paper / "PaperGrain-Dark.png")
    (paper / "Contents.json").write_text(contents([
        {"filename": "PaperGrain.png", "idiom": "universal", "scale": "3x"},
        {"appearances": [{"appearance": "luminosity", "value": "dark"}],
         "filename": "PaperGrain-Dark.png", "idiom": "universal", "scale": "3x"},
    ]))

    # For sharing: the flower alone and the icons with rounded corners.
    save(flower(1024), brand / "fielua-flower-1024.png")
    for name, image in (("light", app_icon()), ("dark", app_icon(dark=True))):
        mask = Image.new("L", image.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, 1023, 1023), radius=225, fill=255)
        image = image.copy()
        image.putalpha(mask)
        save(image, brand / f"fielua-icon-{name}.png")


if __name__ == "__main__":
    main()
