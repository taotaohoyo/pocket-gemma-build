"""Instruments' Time Profiler on 設定's sheet and pages (1.1.0 (291)).

Reads the main thread's samples from an exported time-profile table
(xctrace export --xpath '.../table[@schema="time-profile"]'), lines the
profile's clock up with the app's (SettingsProfileDemo's SYNC pulses: the
samples inside fieluaProfileSyncPulse), and for each moment the app noted
(the sheet asked for, presented, rising, closed; each page's slide asked
for, its first frame, its last) adds up what the main thread was doing:
the busy time, and the functions it was in, inclusive, on their own (the
leaf) and the app's own.

    python3 scripts/profile-summary.py profile.xml settings-profile-marks.txt settings-present.txt
"""
import collections
import re
import sys
import xml.etree.ElementTree as ET

if len(sys.argv) < 3:
    sys.exit(__doc__)
xml_path, marks_path = sys.argv[1], sys.argv[2]
present_path = sys.argv[3] if len(sys.argv) > 3 else None
APP = 'PocketGemmaPreview'


def resolve_table(path):
    ids = {}
    samples = []
    threads = collections.Counter()

    def value(el):
        if el is None:
            return None
        ref = el.get('ref')
        if ref is not None:
            return ids.get(ref)
        return ids.get(el.get('id')) if el.get('id') is not None else None

    for _, el in ET.iterparse(path, events=('end',)):
        tag = el.tag
        ident = el.get('id')
        if ident is not None:
            if tag == 'binary':
                ids[ident] = el.get('name') or ''
            elif tag == 'frame':
                binary = el.find('binary')
                ids[ident] = (el.get('name') or el.get('addr') or '?', value(binary) if binary is not None else '')
            elif tag == 'backtrace':
                frames = []
                for frame in el.findall('frame'):
                    resolved = value(frame)
                    if resolved is not None:
                        frames.append(resolved)
                ids[ident] = tuple(frames)
            elif tag in ('sample-time', 'weight'):
                try:
                    ids[ident] = int(el.text or 0)
                except ValueError:
                    ids[ident] = 0
            else:
                ids[ident] = el.get('fmt') or (el.text or '')
        if tag == 'row':
            time = value(el.find('sample-time'))
            thread = value(el.find('thread')) or ''
            weight = value(el.find('weight')) or 1_000_000
            backtrace = value(el.find('backtrace')) or ()
            threads[thread] += 1
            if time is not None and 'Main Thread' in thread:
                samples.append((time / 1e9, weight / 1e6, backtrace))
            el.clear()
    samples.sort(key=lambda s: s[0])
    return samples, threads


samples, threads = resolve_table(xml_path)
print(f'PROFILE samples on the main thread: {len(samples)}; threads seen: {len(threads)}')
for name, count in threads.most_common(6):
    print(f'PROFILE thread {count} {name[:120]}')
if not samples:
    sys.exit(0)

# The app's moments, on the media clock.
marks = []
for line in open(marks_path, encoding='utf-8', errors='replace'):
    parts = line.rstrip('\n').split(' ', 1)
    if len(parts) == 2:
        try:
            marks.append((float(parts[0]), parts[1]))
        except ValueError:
            pass
syncs = []
for _, text in marks:
    found = re.match(r'SYNC (\S+) start=([\d.]+) end=([\d.]+)', text)
    if found:
        syncs.append((found.group(1), float(found.group(2)), float(found.group(3))))

# The pulses in the profile: runs of samples inside fieluaProfileSyncPulse.
pulse_times = [t for t, _, bt in samples if any('fieluaProfileSyncPulse' in f[0] for f in bt)]
clusters = []
for t in pulse_times:
    if clusters and t - clusters[-1][-1] < 0.5:
        clusters[-1].append(t)
    else:
        clusters.append([t])
print(f'PROFILE sync pulses: app {[(s[0], round(s[1], 3)) for s in syncs]}; profile {[(round(c[0], 3), len(c)) for c in clusters]}')
if not syncs or not clusters:
    print('PROFILE no clock to line up: only the whole profile follows')
    offset = None
else:
    offsets = [c[0] - s[1] for s, c in zip(syncs, clusters)]
    offset = offsets[0]
    print('PROFILE clock offsets (profile - media): ' + ', '.join(f'{o:.4f}' for o in offsets))

times = [s[0] for s in samples]


def window(start, end):
    """The main thread's samples between two media times."""
    import bisect
    if offset is None:
        return []
    lo = bisect.bisect_left(times, start + offset)
    hi = bisect.bisect_right(times, end + offset)
    return samples[lo:hi]


# Frames that say nothing: the run loop and the app's entry.
QUIET = re.compile(r'^(start|main|UIApplicationMain|GSEventRunModal|CFRunLoopRun|__CFRunLoopRun|CFRunLoopRunSpecific|'
                   r'-\[UIApplication _run\]|_UIApplicationMainPreparations|__CFRunLoopDoObservers|'
                   r'__CFRUNLOOP_IS_CALLING_OUT_TO_AN_OBSERVER_CALLBACK_FUNCTION__|static .*App\.main\(\)|'
                   r'.*\$main|.*PreviewApp.*main.*|0x[0-9a-f]+)$')


def short(name):
    name = re.sub(r'\s+', ' ', name)
    return name if len(name) <= 170 else name[:167] + '...'


def tops(group, label, inclusive=36, leaves=22, own=22):
    total = sum(w for _, w, _ in group)
    inc = collections.Counter()
    leaf = collections.Counter()
    app = collections.Counter()
    for _, weight, bt in group:
        seen = set()
        for name, binary in bt:
            if name in seen:
                continue
            seen.add(name)
            if not QUIET.match(name):
                inc[name] += weight
            if binary and APP in binary:
                app[name] += weight
        if bt:
            leaf[bt[0][0]] += weight
    print(f'PROFILE-TOP {label} busy {total:.0f}ms in {len(group)} samples')
    for name, ms in inc.most_common(inclusive):
        print(f'PROFILE-INC {label} {ms:7.1f}ms {100 * ms / total if total else 0:5.1f}% {short(name)}')
    for name, ms in leaf.most_common(leaves):
        print(f'PROFILE-SELF {label} {ms:7.1f}ms {short(name)}')
    for name, ms in app.most_common(own):
        print(f'PROFILE-APP {label} {ms:7.1f}ms {short(name)}')


# Windows of the sheet: asked, presented (its view joined the window), and
# its first beat away from where it would rest (SETTINGS-RISE's at= list).
present = {}
if present_path:
    try:
        for line in open(present_path, encoding='utf-8', errors='replace'):
            media = re.search(r' m([\d.]+) ', line)
            opened = re.search(r'open=(\d+)', line)
            if not media or not opened:
                continue
            n = int(opened.group(1))
            entry = present.setdefault(n, {})
            if 'SETTINGS-PRESENT' in line:
                entry['present'] = float(media.group(1))
            elif 'SETTINGS-RISE' in line:
                beats = re.search(r'at=([\d.:,\-]+)', line)
                if beats:
                    pairs = [p.split(':') for p in beats.group(1).split(',') if ':' in p]
                    pairs = [(float(a), float(b)) for a, b in pairs if a and b]
                    if pairs:
                        first_y = pairs[0][1]
                        moving = next((ms for ms, y in pairs if abs(y - first_y) > 1), None)
                        entry['rise_ms'] = moving
            elif 'SETTINGS-FALL' in line:
                entry['fall'] = float(media.group(1))
    except OSError:
        pass

groups = collections.defaultdict(list)
rows = collections.defaultdict(list)


def add(kind, start, end, index):
    group = window(start, end)
    busy = sum(w for _, w, _ in group)
    rows[kind].append(f'{index}:{busy:.0f}/{(end - start) * 1000:.0f}')
    groups[kind].extend(group)


opens = [(t, text.split()[1]) for t, text in marks if text.startswith('SHEET-OPEN ')]
closes = [(t, text.split()[1]) for t, text in marks if text.startswith('SHEET-CLOSE ')]
for n, (t, label) in enumerate(opens, start=1):
    entry = present.get(n, {})
    first = 'first' if n == 1 else 'again'
    if 'present' in entry:
        add(f'sheet-open-{first}:asked-to-presented', t, entry['present'], label)
        if entry.get('rise_ms') is not None:
            rise = entry['present'] + entry['rise_ms'] / 1000
            add(f'sheet-open-{first}:presented-to-rising', entry['present'], rise, label)
            add(f'sheet-open-{first}:rising', rise, rise + 0.45, label)
    else:
        add(f'sheet-open-{first}:asked+1500ms', t, t + 1.5, label)
for t, label in closes:
    add('sheet-close', t, t + 0.6, label)

slides = []
for _, text in marks:
    found = re.match(r'SLIDE (\d+) (\S+) asked=([\d.]+) first=([\d.]+) last=([\d.]+)', text)
    if found:
        slides.append((int(found.group(1)), found.group(2), float(found.group(3)), float(found.group(4)), float(found.group(5))))
seen_steps = collections.Counter()
for index, step, asked, first, last in slides:
    seen_steps[step] += 1
    which = 'first' if seen_steps[step] == 1 else 'again'
    add(f'{step}-{which}:asked-to-moving', asked, first, index)
    add(f'{step}:first-60ms', first, first + 0.06, index)
    add(f'{step}:moving', first, last, index)
    add(f'{step}:after-last-250ms', last, last + 0.25, index)

for kind in sorted(rows):
    print(f'PROFILE-WINDOW {kind} busy/length ms: ' + ' '.join(rows[kind]))

detailed = ['sheet-open-first:asked-to-presented', 'sheet-open-first:presented-to-rising',
            'sheet-open-again:asked-to-presented', 'sheet-open-again:presented-to-rising', 'sheet-open-again:rising',
            'sheet-close', 'models-open-first:asked-to-moving', 'models-open-again:asked-to-moving',
            'models-open:first-60ms', 'models-back:after-last-250ms', 'gemma-open-again:asked-to-moving',
            'web-open-again:asked-to-moving', 'history-open-again:asked-to-moving', 'keyboard-open-again:asked-to-moving',
            'models-back-again:asked-to-moving', 'models-open:moving']
for kind in detailed:
    if groups.get(kind):
        tops(groups[kind], kind)
if offset is None:
    tops(samples, 'whole-profile')
