#!/bin/bash
# Look A as iOS 26 draws it, kept as a picture for iOS 27 (1.1.0 (267),
# scripts/make-glass-icon.py bake_sources / bake): Xcode's own Icon Composer
# renderer (ictool) draws look A on its fills and on contrasting ones, with
# and without the flower; bake() pulls the flower out of those renders; then
# the baked icon is drawn again in every appearance and compared with look A.
# Artifacts can't be fetched from the cloud sessions, so the renders it
# was baked from and the baked icon's renders are printed into the log as
# base64 (ICON_IMG <name> <chunk> <data>).
set -uo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
out=build/bake
mkdir -p "$out/renders" "$out/crops"
python3 -m venv /tmp/iconenv && /tmp/iconenv/bin/pip install --quiet pillow numpy
PY=/tmp/iconenv/bin/python

emit() {
  base64 -i "$2" | tr -d '\n' | fold -w 8000 | awk -v n="$1" '{print "ICON_IMG", n, NR-1, $0}'
  echo "ICON_IMG_END $1"
}

xcode_app="${DEVELOPER_DIR%/Contents/Developer}"
ictool="$xcode_app/Contents/Applications/Icon Composer.app/Contents/Executables/ictool"
"$ictool" --version || true
render() { # bundle rendition size png
  "$ictool" "$1" --export-image --output-file "$4" --platform iOS --rendition "$2" \
    --width "$3" --height "$3" --scale 1 > "$out/ictool.log" 2>&1 \
    || { echo "ICTOOL-FAIL $1 $2"; tail -5 "$out/ictool.log"; return 1; }
}

"$PY" scripts/make-glass-icon.py --bake-sources "$out/src" || { echo "BAKE-SOURCES-FAIL"; exit 1; }
for bundle in A-real A-alt fill-real fill-alt; do
  for r in Default Dark; do
    render "$out/src/$bundle/AppIcon.icon" "$r" 1024 "$out/renders/$bundle-$r.png" && echo "RENDERED $bundle $r"
  done
done
"$PY" scripts/make-glass-icon.py --bake "$out/renders" --out "$out/baked" || { echo "BAKE-FAIL"; exit 1; }

# The baked icon in every appearance, and Default / Dark at full size
# against look A's own render.
for r in Default Dark TintedLight TintedDark ClearLight ClearDark; do
  render "$out/baked/AppIcon.icon" "$r" 512 "$out/baked-$r.png" && emit "baked-$r" "$out/baked-$r.png"
done
for r in Default Dark; do
  render "$out/baked/AppIcon.icon" "$r" 1024 "$out/check-$r.png" || continue
  "$PY" - "$out/check-$r.png" "$out/renders/A-real-$r.png" "$r" <<'PYEOF'
import sys
import numpy as np
from PIL import Image
a, b = (np.asarray(Image.open(p).convert("RGBA"), float) for p in sys.argv[1:3])
d = np.abs(a - b)[..., :3]
inner = d[112:912, 112:912]
print(f"COMPARE {sys.argv[3]} baked vs look A: whole mean {d.mean():.3f} p99 {np.percentile(d, 99):.1f} max {d.max():.0f}; "
      f"flower box mean {inner.mean():.3f} p99.9 {np.percentile(inner, 99.9):.1f} max {inner.max():.0f}")
PYEOF
done

# actool takes a .icon of plain layers as well.
mkdir -p "$out/actool"
xcrun actool "$out/baked/AppIcon.icon" --compile "$out/actool" --platform iphoneos \
  --minimum-deployment-target 26.4 --app-icon AppIcon --target-device iphone --target-device ipad \
  --output-partial-info-plist "$out/actool/partial.plist" --output-format human-readable-text \
  --notices --warnings --errors 2>&1 | tail -10
xcrun assetutil --info "$out/actool/Assets.car" 2>/dev/null | grep -E '"(Name|AssetType)"' | sort | uniq -c | head -20 || true

# What bake() was made from, cropped to the flower's box (bake() reads only
# that box), so the same icon can be baked again off a Mac.
for f in "$out/renders"/*.png; do
  name="$(basename "$f" .png)"
  "$PY" -c "from PIL import Image; import sys; Image.open(sys.argv[1]).convert('RGB').crop((112, 112, 912, 912)).save(sys.argv[2], optimize=True)" "$f" "$out/crops/$name.png"
  emit "crop-$name" "$out/crops/$name.png"
done
echo "BAKE-DONE"
