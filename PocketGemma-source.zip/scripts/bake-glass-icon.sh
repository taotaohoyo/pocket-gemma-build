#!/bin/bash
# The app icon from 1.1.0 (267): look A as iOS 26 draws it, kept as a
# picture for iOS 27 (scripts/make-glass-icon.py bake, picture_icons).
# Xcode's own Icon Composer renderer (ictool) draws look A on its fills and
# on contrasting ones, with and without the flower; bake() pulls the flower
# out of those renders and must give design/glass-icon/baked/AppIcon.icon
# again (the app's AppIcon.appiconset is made from it). That plain-layer
# .icon is drawn in every appearance and compared with look A; the app's
# icon set and the .icon are compiled with actool; and the app's icon goes
# on a simulator's home screen next to 266's glass icon, the plain-layer
# .icon and the flat icon. Artifacts can't be fetched from the cloud
# sessions, so pictures are printed into the log as base64
# (ICON_IMG <name> <chunk> <data>).
set -uo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
out=build/bake
mkdir -p "$out/renders"
python3 -m venv /tmp/iconenv && /tmp/iconenv/bin/pip install --quiet pillow numpy
PY=/tmp/iconenv/bin/python

emit() {
  base64 -i "$2" | tr -d '\n' | fold -w 8000 | awk -v n="$1" '{print "ICON_IMG", n, NR-1, $0}'
  echo "ICON_IMG_END $1"
}

xcode_app="${DEVELOPER_DIR%/Contents/Developer}"
ictool="$xcode_app/Contents/Applications/Icon Composer.app/Contents/Executables/ictool"
"$ictool" --version || true
render() { # bundle rendition size png
  "$ictool" "$1" --export-image --output-file "$4" --platform iOS --rendition "$2" \
    --width "$3" --height "$3" --scale 1 > "$out/ictool.log" 2>&1 \
    || { echo "ICTOOL-FAIL $1 $2"; tail -5 "$out/ictool.log"; return 1; }
}

"$PY" scripts/make-glass-icon.py --bake-sources "$out/src" || { echo "BAKE-SOURCES-FAIL"; exit 1; }
for bundle in A-real A-alt fill-real fill-alt; do
  for r in Default Dark; do
    render "$out/src/$bundle/AppIcon.icon" "$r" 1024 "$out/renders/$bundle-$r.png" && echo "RENDERED $bundle $r"
  done
done
"$PY" scripts/make-glass-icon.py --bake "$out/renders" --out "$out/baked" || { echo "BAKE-FAIL"; exit 1; }

# Baked again from today's renders, the .icon must be the one kept.
"$PY" - "$out/baked/AppIcon.icon" design/glass-icon/baked/AppIcon.icon <<'PYEOF'
import json, sys
from pathlib import Path
import numpy as np
from PIL import Image
new, app = map(Path, sys.argv[1:3])
same_json = json.loads((new / "icon.json").read_text()) == json.loads((app / "icon.json").read_text())
diffs = [np.abs(np.asarray(Image.open(new / "Assets" / f), int) - np.asarray(Image.open(app / "Assets" / f), int)).max()
         for f in ("flower-day.png", "flower-night.png")]
print(f"BAKE-REPRODUCED icon.json same {same_json}, layer max diff {diffs}")
PYEOF

# The plain-layer .icon in every appearance, and Default / Dark at full
# size against look A as the previews showed it (ictool's Display P3 numbers
# shown as they are; the plain layers are sRGB, so their render is turned
# back into sRGB numbers before comparing).
icon=design/glass-icon/baked/AppIcon.icon
for r in Default Dark TintedLight TintedDark ClearLight ClearDark; do
  render "$icon" "$r" 512 "$out/app-$r.png" && emit "app-$r" "$out/app-$r.png"
done
for r in Default Dark; do
  render "$icon" "$r" 1024 "$out/check-$r.png" || continue
  "$PY" - "$out/check-$r.png" "$out/renders/A-real-$r.png" "$r" <<'PYEOF'
import io, sys
import numpy as np
from PIL import Image, ImageCms
def seen(path, to_srgb):
    image = Image.open(path)
    icc = image.info.get("icc_profile")
    if icc and to_srgb:
        image = ImageCms.profileToProfile(image.convert("RGB"), ImageCms.ImageCmsProfile(io.BytesIO(icc)),
                                          ImageCms.createProfile("sRGB"), outputMode="RGB")
    return np.asarray(image.convert("RGB"), float)
a, b = seen(sys.argv[1], True), seen(sys.argv[2], False)
d = np.abs(a - b)
box = d[112:912, 112:912]
print(f"COMPARE {sys.argv[3]} plain-layer .icon vs look A as previewed: flower box mean {box.mean():.2f} "
      f"p99 {np.percentile(box, 99):.1f} p99.9 {np.percentile(box, 99.9):.1f} max {box.max():.0f}")
PYEOF
done

# actool: the app's catalog (its AppIcon icon set: light, dark, tinted),
# and the plain-layer .icon with how its layer pictures are stored.
mkdir -p "$out/actool" "$out/actool-plain"
xcrun actool PocketGemma/Assets.xcassets --compile "$out/actool" --platform iphoneos \
  --minimum-deployment-target 26.4 --app-icon AppIcon --target-device iphone --target-device ipad \
  --output-partial-info-plist "$out/actool/partial.plist" --output-format human-readable-text \
  --notices --warnings --errors 2>&1 | tail -10
plutil -p "$out/actool/partial.plist" || true
xcrun assetutil --info "$out/actool/Assets.car" 2>/dev/null | "$PY" -c "import json,sys; a=json.load(sys.stdin); print('APP-ICON-CAR', sorted({(str(x.get('AssetType')), str(x.get('Name')), str(x.get('Appearance', ''))) for x in a[1:] if 'AppIcon' in str(x.get('Name', ''))}))" || true
xcrun actool "$icon" --compile "$out/actool-plain" --platform iphoneos \
  --minimum-deployment-target 26.4 --app-icon AppIcon --target-device iphone \
  --output-partial-info-plist "$out/actool-plain/partial.plist" --output-format human-readable-text \
  --notices --warnings --errors 2>&1 | tail -10
xcrun assetutil --info "$out/actool-plain/Assets.car" 2>/dev/null | "$PY" -c "
import json, sys
for x in json.load(sys.stdin)[1:]:
    if 'flower' in str(x.get('Name', '')):
        print('PLAIN-LAYER', {k: x.get(k) for k in ('Name', 'AssetType', 'Compression', 'Encoding', 'Colorspace', 'PixelWidth', 'Scale', 'Idiom', 'Appearance', 'SizeOnDisk')})
" || true

# The home screen (iOS 26.5 simulator): small apps with 266's glass icon,
# the app's icon, the plain-layer .icon and the flat icon, side by side on
# the first page.
sdk="$(xcrun --sdk iphonesimulator --show-sdk-path)"
mkdir -p "$out/stub" "$out/flat.xcassets" "$out/app.xcassets"
cat > "$out/stub/main.swift" <<'SWIFT'
import SwiftUI
@main struct IconPreview: App { var body: some Scene { WindowGroup { Color.yellow } } }
SWIFT
xcrun --sdk iphonesimulator swiftc -parse-as-library -target arm64-apple-ios26.0-simulator -sdk "$sdk" \
  "$out/stub/main.swift" -o "$out/stub/IconPreview" || echo "STUB-COMPILE-FAIL"
cp -R design/brand/flat-icon/AppIcon.appiconset "$out/flat.xcassets/"
cp -R PocketGemma/Assets.xcassets/AppIcon.appiconset "$out/app.xcassets/"
for c in flat app; do printf '{"info":{"author":"xcode","version":1}}\n' > "$out/$c.xcassets/Contents.json"; done
make_app() { # id label source
  local app="$out/apps/$1.app"
  mkdir -p "$app" "$out/apps/$1-partial"
  cp "$out/stub/IconPreview" "$app/"
  xcrun actool "$3" --compile "$app" --platform iphonesimulator --minimum-deployment-target 26.0 \
    --app-icon AppIcon --target-device iphone --output-partial-info-plist "$out/apps/$1-partial/p.plist" \
    --output-format human-readable-text --errors 2>&1 | tail -5
  "$PY" - "$app/Info.plist" "$out/apps/$1-partial/p.plist" "$1" "$2" <<'PYEOF'
import plistlib, sys
info = {"CFBundleIdentifier": "com.fielua.iconpreview." + sys.argv[3].lower(), "CFBundleExecutable": "IconPreview",
        "CFBundleName": sys.argv[4], "CFBundleDisplayName": sys.argv[4], "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": "1.0", "CFBundleVersion": "1", "MinimumOSVersion": "26.0",
        "CFBundleSupportedPlatforms": ["iPhoneSimulator"], "UIDeviceFamily": [1], "UILaunchScreen": {},
        "CFBundleInfoDictionaryVersion": "6.0"}
try:
    info.update(plistlib.load(open(sys.argv[2], "rb")))
except Exception as e:
    print("PARTIAL-PLIST missing", e)
plistlib.dump(info, open(sys.argv[1], "wb"))
print("APP", sys.argv[3], info.get("CFBundleIcons"))
PYEOF
  codesign -f -s - "$app" > /dev/null 2>&1 || echo "CODESIGN-FAIL $1"
}
make_app glass "266 ガラス" design/glass-icon/A/AppIcon.icon
make_app app "267 アプリ" "$out/app.xcassets"
make_app plain "ガラスなし層" "$icon"
make_app flat "平面" "$out/flat.xcassets"

runtime_id="$(xcrun simctl list runtimes -j | "$PY" -c 'import json,sys; r=[x for x in json.load(sys.stdin)["runtimes"] if x.get("isAvailable") and x["name"].startswith("iOS")]; print(max(r,key=lambda x: tuple(map(int,x["version"].split("."))))["identifier"])')"
device_type="$(xcrun simctl list devicetypes -j | "$PY" -c 'import json,sys; d=json.load(sys.stdin)["devicetypes"]; p=[x for x in d if x["name"] in ("iPhone 17 Pro","iPhone 16 Pro")]; print(p[0]["identifier"])')"
udid="$(xcrun simctl create 'Fielua icon check' "$device_type" "$runtime_id")"
echo "SIM $udid $runtime_id $device_type"
xcrun simctl boot "$udid"
python3 scripts/native-test-watchdog.py --timeout 480 --log "$out/boot.log" --metrics "$out/boot.jsonl" -- \
  xcrun simctl bootstatus "$udid" -b || echo "BOOT-SLOW"
for id in glass app plain flat; do xcrun simctl install "$udid" "$out/apps/$id.app" && echo "INSTALLED $id"; done
sleep 8
state="$HOME/Library/Developer/CoreSimulator/Devices/$udid/data/Library/SpringBoard/IconState.plist"
xcrun simctl shutdown "$udid"
"$PY" - "$state" <<'PYEOF'
import plistlib, sys
path = sys.argv[1]
try:
    state = plistlib.load(open(path, "rb"))
except Exception as e:
    print("ICONSTATE unreadable", e); sys.exit(0)
ours = ["com.fielua.iconpreview." + x for x in ("glass", "app", "plain", "flat")]
pages = state.get("iconLists", [])
for p in pages:
    for x in ours:
        while x in p: p.remove(x)
pages = [p for p in pages if p]
first = pages[0] if pages else []
moved = [x for x in first if isinstance(x, str)][:4]
for x in moved: first.remove(x)
pages[0] = ours + first
if len(pages) > 1: pages[1] = moved + pages[1]
else: pages.append(moved)
state["iconLists"] = pages
plistlib.dump(state, open(path, "wb"))
print("ICONSTATE rewritten", [len(p) for p in pages])
PYEOF
xcrun simctl boot "$udid"
python3 scripts/native-test-watchdog.py --timeout 300 --log "$out/boot2.log" --metrics "$out/boot2.jsonl" -- \
  xcrun simctl bootstatus "$udid" -b || echo "BOOT2-SLOW"
xcrun simctl status_bar "$udid" override --time '9:41' --dataNetwork wifi --wifiMode active --wifiBars 3 \
  --batteryState charged --batteryLevel 100 || true
xcrun simctl ui "$udid" appearance light
# iOS's own first-boot banners (Apple Intelligence) slide over the top row
# for a few seconds: wait them out.
sleep 40
xcrun simctl io "$udid" screenshot "$out/home.png"
xcrun simctl shutdown "$udid" || true
if [ -f "$out/home.png" ]; then
  "$PY" -c "from PIL import Image; import sys; im=Image.open(sys.argv[1]).convert('RGB'); print('SHOT', im.size); im.save(sys.argv[2], quality=90)" "$out/home.png" "$out/home.jpg"
  emit home "$out/home.jpg"
fi
echo "BAKE-DONE"
