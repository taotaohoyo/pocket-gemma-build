"""CI-only CPU/RSS samples; take one public macOS stack sample on sustained UI load."""
from pathlib import Path
import argparse,json,signal,subprocess,time

p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=True)
running=True;high={};sampled=set();start=time.monotonic()
def stop(*_):
    global running
    running=False
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
with (a.output/'ui-process-activity.jsonl').open('w') as out:
    while running:
        try:
            result=subprocess.run(['ps','-axo','pid=,pcpu=,rss=,etime=,comm='],capture_output=True,text=True,timeout=5)
        except (OSError,subprocess.TimeoutExpired) as error:
            record={'elapsedSeconds':round(time.monotonic()-start,2),'processes':[],
                'cpuSamplingUnavailable':str(error)}
            out.write(json.dumps(record)+'\n');out.flush()
            print('UI_ACTIVITY '+json.dumps(record),flush=True)
            for _ in range(5):
                if not running:break
                time.sleep(1)
            continue
        rows=[]
        for line in result.stdout.splitlines():
            fields=line.strip().split(None,4)
            if len(fields)!=5:continue
            pid,cpu,rss,elapsed,command=fields
            name=Path(command).name
            if name not in ('PocketGemmaPreview','PocketGemmaUITests-Runner','xcodebuild'):continue
            row={'pid':int(pid),'cpuPercent':float(cpu),'rssBytes':int(rss)*1024,'elapsed':elapsed,'name':name}
            rows.append(row)
            if name=='PocketGemmaPreview':
                high[pid]=high.get(pid,0)+1 if float(cpu)>75 else 0
                if high[pid]>=2 and pid not in sampled and len(sampled)<2:
                    sampled.add(pid)
                    stack=a.output/f'ui-{pid}.stack.txt'
                    try:
                        sample=subprocess.run(['sample',pid,'1','10','-file',str(stack)],capture_output=True,text=True,timeout=30)
                        (a.output/f'ui-{pid}.stack.json').write_text(json.dumps({'pid':int(pid),'exitCode':sample.returncode,
                            'stack':stack.read_text(errors='replace') if stack.exists() else '',
                            'stderr':sample.stderr},indent=2)+'\n')
                    except subprocess.TimeoutExpired:
                        (a.output/f'ui-{pid}.stack.json').write_text(json.dumps({'pid':int(pid),'samplingTimedOutSeconds':30,
                            'partialStack':stack.read_text(errors='replace') if stack.exists() else ''},indent=2)+'\n')
        record={'elapsedSeconds':round(time.monotonic()-start,2),'processes':rows}
        out.write(json.dumps(record)+'\n');out.flush()
        print('UI_ACTIVITY '+json.dumps(record),flush=True)
        for _ in range(15):
            if not running:break
            time.sleep(1)
