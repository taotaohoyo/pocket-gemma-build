// The empty chat's flower going and coming back while the person types
// (1.1.0 (216)), frame by frame from the session recording (simctl
// recordVideo): screenshots take half a second and miss the change itself.
// For each FLOWER-MARK line the test printed, every recorded frame of the
// flower's box: how much of its colour it shows (of the most in the span),
// the largest step between two frames, and a contact sheet, printed into
// the log for review where artifact downloads are unavailable.
//
// swift scripts/flower-frames.swift <recording.mp4> <start epoch file> <test log> <output dir>
//   FLOWER-MARK <name> <epoch> <span s> <box x y width height, points> <screen width, points>
import AVFoundation
import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

let arguments = CommandLine.arguments
guard arguments.count == 5 else { print("FLOWER-FRAMES usage: video start log out"); exit(2) }
let video = URL(fileURLWithPath: arguments[1])
let start = Double((try? String(contentsOfFile: arguments[2], encoding: .utf8))?
    .trimmingCharacters(in: .whitespacesAndNewlines) ?? "") ?? 0
let output = URL(fileURLWithPath: arguments[4], isDirectory: true)
try? FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
let log = (try? String(contentsOfFile: arguments[3], encoding: .utf8)) ?? ""

struct Mark { let name: String; let epoch: Double; let span: Double; let box: CGRect; let screenWidth: Double }
var marks: [Mark] = []
for line in log.split(separator: "\n") {
    guard let range = line.range(of: "FLOWER-MARK ") else { continue }
    let fields = line[range.upperBound...].split(separator: " ")
    let numbers = fields.dropFirst().compactMap { Double($0) }
    guard fields.count >= 8, numbers.count >= 7, !marks.contains(where: { $0.name == String(fields[0]) }) else { continue }
    marks.append(Mark(name: String(fields[0]), epoch: numbers[0], span: numbers[1],
                      box: CGRect(x: numbers[2], y: numbers[3], width: numbers[4], height: numbers[5]), screenWidth: numbers[6]))
}
print("FLOWER-FRAMES start=\(start) marks=\(marks.count)")
guard start > 0, !marks.isEmpty else { exit(0) }

let asset = AVURLAsset(url: video)
guard let track = asset.tracks(withMediaType: .video).first else { print("FLOWER-FRAMES no video track"); exit(0) }
let context = CIContext(options: [.useSoftwareRenderer: false])
let columns = 6, maxTiles = 30, tileWidth = 110.0, probeSide = 72

struct Frame { let time: Double; let tile: CGImage; let colour: Double }

/// The flower's colour in a frame: how far each pixel is from grey, summed
/// (the paper and the charcoal are all but grey), so it falls as the
/// flower fades and as it shrinks, and a jump shows as one big step.
func colour(of tile: CGImage) -> Double {
    var pixels = [UInt8](repeating: 0, count: probeSide * probeSide * 4)
    var total = 0.0
    pixels.withUnsafeMutableBytes { bytes in
        guard let small = CGContext(data: bytes.baseAddress, width: probeSide, height: probeSide, bitsPerComponent: 8,
                                    bytesPerRow: probeSide * 4, space: CGColorSpaceCreateDeviceRGB(),
                                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
        small.draw(tile, in: CGRect(x: 0, y: 0, width: probeSide, height: probeSide))
    }
    for index in stride(from: 0, to: pixels.count, by: 4) {
        let r = Int(pixels[index]), g = Int(pixels[index + 1]), b = Int(pixels[index + 2])
        total += Double(max(0, max(r, g, b) - min(r, g, b) - 12))
    }
    return total
}

func frames(for mark: Mark) -> [Frame] {
    let at = mark.epoch - start
    guard let reader = try? AVAssetReader(asset: asset) else { return [] }
    reader.timeRange = CMTimeRange(start: CMTime(seconds: max(0, at - 0.3), preferredTimescale: 600),
                                   end: CMTime(seconds: max(0, at + mark.span), preferredTimescale: 600))
    let out = AVAssetReaderTrackOutput(track: track, outputSettings:
        [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
    reader.add(out)
    guard reader.startReading() else { return [] }
    var result: [Frame] = []
    while let sample = out.copyNextSampleBuffer() {
        guard let buffer = CMSampleBufferGetImageBuffer(sample) else { continue }
        let image = CIImage(cvPixelBuffer: buffer)
        let full = image.extent
        let scale = full.width / mark.screenWidth
        // Core Image's origin is at the bottom.
        let box = CGRect(x: mark.box.minX * scale, y: full.height - mark.box.maxY * scale,
                         width: mark.box.width * scale, height: mark.box.height * scale).intersection(full)
        let down = tileWidth / box.width
        let tileImage = image.cropped(to: box)
            .transformed(by: CGAffineTransform(translationX: -box.minX, y: -box.minY).concatenating(CGAffineTransform(scaleX: down, y: down)))
        guard let tile = context.createCGImage(tileImage, from: tileImage.extent.integral) else { continue }
        result.append(Frame(time: CMSampleBufferGetPresentationTimeStamp(sample).seconds - at, tile: tile, colour: colour(of: tile)))
    }
    return result
}

func writeSheet(_ tiles: [CGImage], to url: URL) -> Bool {
    guard let first = tiles.first else { return false }
    let width = first.width, height = first.height, gap = 4
    let rows = (tiles.count + columns - 1) / columns
    let sheetWidth = columns * width + (columns - 1) * gap, sheetHeight = rows * height + (rows - 1) * gap
    guard let sheet = CGContext(data: nil, width: sheetWidth, height: sheetHeight, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
    sheet.setFillColor(CGColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 1))
    sheet.fill(CGRect(x: 0, y: 0, width: sheetWidth, height: sheetHeight))
    for (index, tile) in tiles.enumerated() {
        let row = index / columns, column = index % columns
        // Rows run from the top, while the context's origin is at the bottom.
        let y = sheetHeight - (row + 1) * height - row * gap
        sheet.draw(tile, in: CGRect(x: column * (width + gap), y: y, width: width, height: height))
    }
    guard let image = sheet.makeImage(),
          let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil)
    else { return false }
    CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.6] as CFDictionary)
    return CGImageDestinationFinalize(destination)
}

for mark in marks {
    let all = frames(for: mark)
    guard all.count > 1, let most = all.map(\.colour).max(), most > 0 else {
        print("FLOWER-FRAMES \(mark.name) frames=\(all.count)"); continue
    }
    let shares = all.map { $0.colour / most * 100 }
    var step = (size: 0.0, at: 0.0, gap: 0.0)
    for index in 1..<all.count where abs(shares[index] - shares[index - 1]) > step.size {
        step = (abs(shares[index] - shares[index - 1]), all[index].time, all[index].time - all[index - 1].time)
    }
    let gaps = zip(all, all.dropFirst()).map { $1.time - $0.time }
    // Half the flower or more between two frames close together is a jump;
    // the springs move it a quarter at most in a tenth of a second.
    let jumps = all.indices.dropFirst().filter { abs(shares[$0] - shares[$0 - 1]) >= 50 && all[$0].time - all[$0 - 1].time <= 0.1 }
    print(String(format: "FLOWER-FRAMES %@ frames=%d longest gap=%.0f ms, largest step=%.1f%% at %.0f ms (after %.0f ms): %@",
                 mark.name, all.count, (gaps.max() ?? 0) * 1000, step.size, step.at * 1000, step.gap * 1000,
                 jumps.isEmpty ? (step.size >= 50 ? "no jump between close frames (a gap in the recording)" : "smooth")
                               : "JUMP at " + jumps.map { String(format: "%.0f ms", all[$0].time * 1000) }.joined(separator: ", ")))
    print("FLOWER-FRAMES \(mark.name) ms=" + all.map { String(format: "%.0f", $0.time * 1000) }.joined(separator: ","))
    print("FLOWER-FRAMES \(mark.name) colour=" + shares.map { String(format: "%.1f", $0) }.joined(separator: ","))
    // The frames that change, two either side, at most maxTiles of them.
    let moving = shares.indices.dropFirst().filter { abs(shares[$0] - shares[$0 - 1]) > 0.3 }
    var first = max(0, (moving.first ?? 0) - 2), last = min(all.count - 1, (moving.last ?? all.count - 1) + 2)
    if last <= first { first = 0; last = all.count - 1 }
    var picked = Array(first...last)
    if picked.count > maxTiles {
        let stride = Double(picked.count - 1) / Double(maxTiles - 1)
        picked = (0..<maxTiles).map { picked[Int((Double($0) * stride).rounded())] }
    }
    print("FLOWER-FRAMES \(mark.name) shown ms=" + picked.map { String(format: "%.0f", all[$0].time * 1000) }.joined(separator: ","))
    let url = output.appendingPathComponent("flower-video-\(mark.name).jpg")
    guard writeSheet(picked.map { all[$0].tile }, to: url), let data = try? Data(contentsOf: url) else { continue }
    print("SHOT-BEGIN flower-video-\(mark.name)"); print(data.base64EncodedString()); print("SHOT-END")
}
