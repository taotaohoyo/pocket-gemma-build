"""Exercise package validation using fixtures, not a simulated iOS build."""
import contextlib
import importlib.util
import io
import hashlib
import json
import plistlib
import struct
import zipfile
from pathlib import Path

spec = importlib.util.spec_from_file_location("ipa_check", Path(__file__).with_name("check-ipa.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
from native_artifact import FRAMEWORKS, INSTALL_NAMES
from test_native_artifact import native as synthetic_native

def fixture(platform="iPhoneOS", cpu=0x0100000C, model=False, missing_framework=False, receipt=False, tamper=False):
    base = "Payload/PocketGemma.app/"
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr(base + "Info.plist", plistlib.dumps({
            "CFBundleExecutable": "PocketGemma", "CFBundlePackageType": "APPL",
            "CFBundleIdentifier": "app.pocketgemma.personal", "CFBundleSupportedPlatforms": [platform],
        }))
        archive.writestr(base + "PocketGemma", struct.pack("<II", 0xFEEDFACF, cpu))
        if model:
            archive.writestr(base + "model.litertlm", b"fixture")
        if missing_framework:
            archive.writestr(base + "Frameworks/Runtime.framework/Info.plist",
                             plistlib.dumps({"CFBundleExecutable": "Runtime"}))
        if receipt:
            native = b"synthetic native binary"
            name = 'Frameworks/CLiteRTLM.framework/CLiteRTLM'
            archive.writestr(base + name, native + (b'tampered' if tamper else b''))
            archive.writestr(base + 'runtime-build.json', json.dumps({
                'target': 'iphoneos', 'runtimeVersion': '0.18.0',
                'artifactSHA256': 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347',
                'nativeFiles': [{'name': name, 'bytes': len(native), 'sha256': hashlib.sha256(native).hexdigest()}]
            }))
    buffer.seek(0)
    return buffer

def custom_fixture(minimum='26.4', omit_receipt_entry=False, simulator_slice=False, unpackaged=False):
    base = 'Payload/PocketGemma.app/'
    buffer = io.BytesIO()
    records = []
    with zipfile.ZipFile(buffer, 'w') as archive:
        archive.writestr(base + 'Info.plist', plistlib.dumps({
            'CFBundleExecutable': 'PocketGemma', 'CFBundlePackageType': 'APPL',
            'CFBundleIdentifier': 'app.pocketgemma.personal', 'CFBundleSupportedPlatforms': ['iPhoneOS'],
            'MinimumOSVersion': minimum,
        }))
        archive.writestr(base + 'PocketGemma', struct.pack('<II', 0xFEEDFACF, 0x0100000C))
        for name in FRAMEWORKS:
            deps = ['@rpath/missing.dylib'] if unpackaged else []
            data = synthetic_native(name, 7 if simulator_slice else 2, deps)
            prefix = f'Frameworks/{name}.framework/'
            archive.writestr(base + prefix + 'Info.plist', plistlib.dumps({'CFBundleExecutable': name}))
            archive.writestr(base + prefix + name, data)
            records.append({'name': prefix + name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        if omit_receipt_entry: records.pop()
        archive.writestr(base + 'runtime-build.json', json.dumps({
            'target': 'iphoneos', 'runtimeVersion': '0.18.0',
            'artifactSHA256': 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347',
            'nativeBuild': {'buildID': '0.18.0-pg1'}, 'nativeFiles': records,
        }))
    buffer.seek(0)
    return buffer

with contextlib.redirect_stdout(io.StringIO()):
    module.check(fixture())
    module.check(fixture(receipt=True))
    module.check(custom_fixture())
cases = [
    {"platform": "iPhoneSimulator"}, {"cpu": 0x01000007},
    {"model": True}, {"missing_framework": True},
    {"receipt": True, "tamper": True},
]
for case in cases:
    try:
        module.check(fixture(**case))
    except AssertionError:
        continue
    raise AssertionError(f"Validator accepted an invalid package: {case}")
for case in [{'minimum': '17.0'}, {'omit_receipt_entry': True}, {'simulator_slice': True}, {'unpackaged': True}]:
    try:
        module.check(custom_fixture(**case))
    except (AssertionError, ValueError):
        continue
    raise AssertionError(f'Validator accepted an invalid custom runtime IPA: {case}')
print('Package validator: 3 valid fixtures accepted; 9 invalid fixtures rejected, including incomplete/custom native runtime IPAs.')
