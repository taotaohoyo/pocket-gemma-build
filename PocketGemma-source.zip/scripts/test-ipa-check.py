"""Exercise package validation using fixtures, not a simulated iOS build."""
import contextlib
import importlib.util
import io
import hashlib
import json
import plistlib
import struct
import zipfile
from pathlib import Path

spec = importlib.util.spec_from_file_location("ipa_check", Path(__file__).with_name("check-ipa.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def fixture(platform="iPhoneOS", cpu=0x0100000C, model=False, missing_framework=False, receipt=False, tamper=False):
    base = "Payload/PocketGemma.app/"
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr(base + "Info.plist", plistlib.dumps({
            "CFBundleExecutable": "PocketGemma", "CFBundlePackageType": "APPL",
            "CFBundleIdentifier": "app.pocketgemma.personal", "CFBundleSupportedPlatforms": [platform],
        }))
        archive.writestr(base + "PocketGemma", struct.pack("<II", 0xFEEDFACF, cpu))
        if model:
            archive.writestr(base + "model.litertlm", b"fixture")
        if missing_framework:
            archive.writestr(base + "Frameworks/Runtime.framework/Info.plist",
                             plistlib.dumps({"CFBundleExecutable": "Runtime"}))
        if receipt:
            native = b"synthetic native binary"
            name = 'Frameworks/CLiteRTLM.framework/CLiteRTLM'
            archive.writestr(base + name, native + (b'tampered' if tamper else b''))
            archive.writestr(base + 'runtime-build.json', json.dumps({
                'target': 'iphoneos', 'runtimeVersion': '0.18.0',
                'artifactSHA256': 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347',
                'nativeFiles': [{'name': name, 'bytes': len(native), 'sha256': hashlib.sha256(native).hexdigest()}]
            }))
    buffer.seek(0)
    return buffer

with contextlib.redirect_stdout(io.StringIO()):
    module.check(fixture())
    module.check(fixture(receipt=True))
cases = [
    {"platform": "iPhoneSimulator"}, {"cpu": 0x01000007},
    {"model": True}, {"missing_framework": True},
    {"receipt": True, "tamper": True},
]
for case in cases:
    try:
        module.check(fixture(**case))
    except AssertionError:
        continue
    raise AssertionError(f"Validator accepted an invalid package: {case}")
print("Package validator: 2 valid fixtures accepted; 5 invalid fixtures rejected (including mismatched native receipt).")
