#!/bin/bash
# Screenshots of the Apple Watch app on a watch simulator (check-ui.sh with
# UI_WATCH_ONLY=1). The app shows a sample conversation of its own in Debug
# (WatchSession's previews), so no iPhone is needed. Only the watch app is
# built, from a small project of its own: the full project's packages need
# the native runtime.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
out=build/UI
mkdir -p "$out"
cat > build/watch-preview.yml <<'YML'
name: FieluaWatchPreview
settings:
  base:
    SWIFT_VERSION: "5.0"
    MARKETING_VERSION: "1.1.0"
    CURRENT_PROJECT_VERSION: "1"
targets:
  PocketWatch:
    type: application
    platform: watchOS
    deploymentTarget: "26.0"
    sources:
      - path: ../Watch
        excludes:
          - Info.plist
    info:
      path: WatchPreview-Info.plist
      properties:
        CFBundleDisplayName: Fielua
        CFBundleShortVersionString: $(MARKETING_VERSION)
        CFBundleVersion: $(CURRENT_PROJECT_VERSION)
        WKApplication: YES
        WKCompanionAppBundleIdentifier: app.pocketgemma.personal
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: app.pocketgemma.personal.watchkitapp
        ASSETCATALOG_COMPILER_APPICON_NAME: AppIcon
        TARGETED_DEVICE_FAMILY: "4"
    scheme: {}
YML
xcodegen generate --spec build/watch-preview.yml --project build

xcrun simctl list runtimes -j > "$out/watch-runtimes.json"
pick_runtime() {
  python3 - "$out/watch-runtimes.json" <<'PY'
import json, sys
runtimes = json.load(open(sys.argv[1]))['runtimes']
usable = [r for r in runtimes if r.get('isAvailable') and r['name'].startswith('watchOS') and int(r['version'].split('.')[0]) >= 26]
print(max(usable, key=lambda r: tuple(map(int, r['version'].split('.'))))['identifier'] if usable else '')
PY
}
runtime_id="$(pick_runtime)"
if [[ -z "$runtime_id" ]]; then
  echo 'WATCH-UI: no watchOS 26+ simulator runtime installed, downloading it'
  xcodebuild -downloadPlatform watchOS
  xcrun simctl list runtimes -j > "$out/watch-runtimes.json"
  runtime_id="$(pick_runtime)"
fi
[[ -n "$runtime_id" ]] || { echo 'WATCH-UI: no watchOS simulator runtime'; exit 70; }
xcrun simctl list devicetypes -j > "$out/watch-devicetypes.json"
device_type="$(python3 - "$out/watch-devicetypes.json" <<'PY'
import json, sys
types = [d for d in json.load(open(sys.argv[1]))['devicetypes'] if d['name'].startswith('Apple Watch')]
# The latest large Series watch, as on the person's wrist most often.
series = [d for d in types if 'Series' in d['name'] and '46mm' in d['name']]
print((series or types)[-1]['identifier'])
PY
)"
echo "WATCH-UI: $runtime_id on $device_type"
watch_id="$(xcrun simctl create 'Fielua watch screenshots' "$device_type" "$runtime_id")"
cleanup() { xcrun simctl shutdown "$watch_id" >/dev/null 2>&1 || true; xcrun simctl delete "$watch_id" >/dev/null 2>&1 || true; }
trap cleanup EXIT
xcrun simctl boot "$watch_id"
xcrun simctl bootstatus "$watch_id" -b

xcodebuild -project build/FieluaWatchPreview.xcodeproj -scheme PocketWatch -configuration Debug \
  -destination "id=$watch_id" -derivedDataPath build/WatchDerivedData \
  CODE_SIGNING_ALLOWED=YES CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY=- DEVELOPMENT_TEAM= \
  build 2>&1 | tee "$out/watch-build.log" | grep -E '(error|warning: .*Watch/|BUILD)' || true
app=build/WatchDerivedData/Build/Products/Debug-watchsimulator/PocketWatch.app
[[ -d "$app" ]] || { echo 'WATCH-UI: build failed'; tail -60 "$out/watch-build.log"; exit 65; }
xcrun simctl install "$watch_id" "$app"

bundle=app.pocketgemma.personal.watchkitapp
for preview in empty answer waiting writing paused; do
  xcrun simctl terminate "$watch_id" "$bundle" >/dev/null 2>&1 || true
  xcrun simctl launch "$watch_id" "$bundle" -WatchPreview "$preview"
  sleep 5
  xcrun simctl io "$watch_id" screenshot "$out/watch-$preview.png"
  echo "WATCH-UI: watch-$preview.png"
done
