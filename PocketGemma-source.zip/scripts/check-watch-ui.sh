#!/bin/bash
# Screenshots of the Apple Watch app on a watch simulator (check-ui.sh with
# UI_WATCH_ONLY=1). The app shows a sample conversation of its own in Debug
# (WatchSession's previews), so no iPhone is needed. Only the watch app is
# built, from a small project of its own: the full project's packages need
# the native runtime.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
out=build/UI
mkdir -p "$out"
cat > build/watch-preview.yml <<'YML'
name: FieluaWatchPreview
settings:
  base:
    SWIFT_VERSION: "5.0"
    MARKETING_VERSION: "1.1.0"
    CURRENT_PROJECT_VERSION: "1"
targets:
  PocketWatch:
    type: application
    platform: watchOS
    deploymentTarget: "26.0"
    sources:
      - path: ../Watch
        excludes:
          - Info.plist
      - path: ../Packages/PocketCore/Sources/PocketCore/WatchHistory.swift
    info:
      path: WatchPreview-Info.plist
      properties:
        CFBundleDisplayName: Fielua
        CFBundleShortVersionString: $(MARKETING_VERSION)
        CFBundleVersion: $(CURRENT_PROJECT_VERSION)
        WKApplication: YES
        WKCompanionAppBundleIdentifier: app.pocketgemma.personal
    settings:
      base:
        PRODUCT_BUNDLE_IDENTIFIER: app.pocketgemma.personal.watchkitapp
        ASSETCATALOG_COMPILER_APPICON_NAME: AppIcon
        TARGETED_DEVICE_FAMILY: "4"
    scheme: {}
YML
xcodegen generate --spec build/watch-preview.yml --project build

xcrun simctl list runtimes -j > "$out/watch-runtimes.json"
pick_runtime() {
  python3 - "$out/watch-runtimes.json" <<'PY'
import json, sys
runtimes = json.load(open(sys.argv[1]))['runtimes']
usable = [r for r in runtimes if r.get('isAvailable') and r['name'].startswith('watchOS') and int(r['version'].split('.')[0]) >= 26]
print(max(usable, key=lambda r: tuple(map(int, r['version'].split('.'))))['identifier'] if usable else '')
PY
}
runtime_id="$(pick_runtime)"
if [[ -z "$runtime_id" ]]; then
  echo 'WATCH-UI: no watchOS 26+ simulator runtime installed, downloading it'
  xcodebuild -downloadPlatform watchOS
  xcrun simctl list runtimes -j > "$out/watch-runtimes.json"
  runtime_id="$(pick_runtime)"
fi
[[ -n "$runtime_id" ]] || { echo 'WATCH-UI: no watchOS simulator runtime'; exit 70; }
xcrun simctl list devicetypes -j > "$out/watch-devicetypes.json"
device_type="$(python3 - "$out/watch-devicetypes.json" <<'PY'
import json, sys
types = [d for d in json.load(open(sys.argv[1]))['devicetypes'] if d['name'].startswith('Apple Watch')]
# The latest large Series watch.
series = [d for d in types if 'Series' in d['name'] and '46mm' in d['name']]
print((series or types)[-1]['identifier'])
PY
)"
echo "WATCH-UI: $runtime_id on $device_type"
watch_id="$(xcrun simctl create 'Fielua watch screenshots' "$device_type" "$runtime_id")"
cleanup() { xcrun simctl shutdown "$watch_id" >/dev/null 2>&1 || true; xcrun simctl delete "$watch_id" >/dev/null 2>&1 || true; }
trap cleanup EXIT
xcrun simctl boot "$watch_id"
xcrun simctl bootstatus "$watch_id" -b

xcodebuild -project build/FieluaWatchPreview.xcodeproj -scheme PocketWatch -configuration Debug \
  -destination "id=$watch_id" -derivedDataPath build/WatchDerivedData \
  CODE_SIGNING_ALLOWED=YES CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY=- DEVELOPMENT_TEAM= \
  build 2>&1 | tee "$out/watch-build.log" | grep -E '(error|warning: .*Watch/|BUILD)' || true
app=build/WatchDerivedData/Build/Products/Debug-watchsimulator/PocketWatch.app
[[ -d "$app" ]] || { echo 'WATCH-UI: build failed'; tail -60 "$out/watch-build.log"; exit 65; }
xcrun simctl install "$watch_id" "$app"

bundle=app.pocketgemma.personal.watchkitapp
# Artifacts can't be downloaded from the cloud sessions, so each shot also
# goes into the log, as a JPEG in base64 lines. `size`: the longest side in
# pixels, smaller for the frame sheets.
shoot() {
  local name="$1" size="${2:-0}"
  xcrun simctl io "$watch_id" screenshot "$out/watch-$name.png" >/dev/null 2>&1
  if [[ "$size" -gt 0 ]]; then
    sips -Z "$size" -s format jpeg -s formatOptions 70 "$out/watch-$name.png" --out "$out/watch-$name.jpg" >/dev/null
  else
    sips -s format jpeg -s formatOptions 80 "$out/watch-$name.png" --out "$out/watch-$name.jpg" >/dev/null
  fi
  base64 -i "$out/watch-$name.jpg" | tr -d '\n' | fold -w 4000 | sed "s/^/WATCH_SHOT $name /"
  echo
}
launch() {
  xcrun simctl terminate "$watch_id" "$bundle" >/dev/null 2>&1 || true
  xcrun simctl launch "$watch_id" "$bundle" -WatchPreview "$1"
  started=$(python3 -c 'import time; print(time.time())')
}
since() { python3 -c "import time; print(f'{time.time() - $started:.2f}')"; }
# What the Debug app logged about the fold (WatchTrace) in the last `$1`.
trace() {
  xcrun simctl spawn "$watch_id" log show --last "$1" --style compact \
    --predicate 'subsystem == "app.pocketgemma.watch.preview"' 2>/dev/null | sed 's/^/WATCH-LOG /' | tail -"$2" || true
}
# The watch app's crash reports, if any: the reason and the crashed thread.
crashes() {
  python3 - <<'PY' || true
import json, pathlib
for p in sorted(pathlib.Path.home().glob('Library/Logs/DiagnosticReports/PocketWatch*.ips')):
    head, _, body = p.read_text(errors='replace').partition('\n')
    try:
        report = json.loads(body)
    except ValueError:
        print('WATCH-CRASH', p.name, 'unreadable')
        continue
    print('WATCH-CRASH', p.name, json.dumps(report.get('exception')), json.dumps(report.get('termination'))[:400])
    images = report.get('usedImages', [])
    for thread in report.get('threads', []):
        if not thread.get('triggered'):
            continue
        for frame in thread.get('frames', [])[:30]:
            index = frame.get('imageIndex')
            image = images[index].get('name', '?') if index is not None and index < len(images) else '?'
            print('WATCH-CRASH  ', image, frame.get('symbol', frame.get('imageOffset')))
PY
}

for preview in empty answer waiting writing paused other folded folded-answering; do
  launch "$preview"
  # Past the launch screen, which a slow runner can show for several seconds.
  sleep 10
  shoot "$preview"
  echo "WATCH-UI: watch-$preview"
done
trace 3m 40
crashes

# The list opens 1.5 s after the screen appears, as a tap would.
launch history
sleep 3
for i in 1 2 3 4 5; do shoot "history-$i" 320; echo "WATCH-FRAME history-$i $(since)"; sleep 2; done
trace 1m 20
crashes

# The fold, eight times slower (WatchMotion.slowdown): it starts 3 s after
# the screen appears and unfolds 14 s later. A shot about every second,
# with room between them for the simulator to draw.
launch morph
sleep 3
for i in $(seq -w 1 40); do shoot "morph-$i" 220; echo "WATCH-FRAME morph-$i $(since)"; sleep 0.4; done
trace 1m 120

# Scrolled as a person would: into the middle 5 s after the screen
# appears (folds), then to the end 10 s later (unfolds). The label at the
# top leading corner says which it thinks. A shot every 2 s, wherever the
# launch screen ends.
launch scroll
sleep 4
for i in $(seq -w 1 16); do shoot "scroll-$i" 320; echo "WATCH-FRAME scroll-$i $(since)"; sleep 1.4; done
trace 1m 160
crashes
echo "WATCH-UI: done"
