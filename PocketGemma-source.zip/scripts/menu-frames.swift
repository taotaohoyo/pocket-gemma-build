// Frames of the composer's menus opening and closing, from the session
// recording (simctl recordVideo, the simulator's display), for review where
// artifact downloads are unavailable: one contact sheet per MENU-MARK line
// that testComposerMenuFrames printed, printed into the log as base64.
// Screenshots wait for the app to settle and miss the animation itself.
//
// swift scripts/menu-frames.swift <recording.mp4> <start epoch file> <test log> <output dir>
import AVFoundation
import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

let arguments = CommandLine.arguments
guard arguments.count == 5 else { print("MENU-FRAMES usage: video start log out"); exit(2) }
let video = URL(fileURLWithPath: arguments[1])
let start = Double((try? String(contentsOfFile: arguments[2], encoding: .utf8))?
    .trimmingCharacters(in: .whitespacesAndNewlines) ?? "") ?? 0
let output = URL(fileURLWithPath: arguments[4], isDirectory: true)
try? FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
let log = (try? String(contentsOfFile: arguments[3], encoding: .utf8)) ?? ""
var marks: [(String, Double)] = []
for line in log.split(separator: "\n") {
    guard let range = line.range(of: "MENU-MARK ") else { continue }
    let fields = line[range.upperBound...].split(separator: " ")
    if fields.count >= 2, let time = Double(fields[1]), !marks.contains(where: { $0.0 == String(fields[0]) }) {
        marks.append((String(fields[0]), time))
    }
}
print("MENU-FRAMES start=\(start) marks=\(marks.count)")
guard start > 0, !marks.isEmpty else { exit(0) }

let asset = AVURLAsset(url: video)
guard let track = asset.tracks(withMediaType: .video).first else { print("MENU-FRAMES no video track"); exit(0) }
print("MENU-FRAMES video duration=\(asset.duration.seconds) track=\(track.timeRange.start.seconds)+\(track.timeRange.duration.seconds)")
let context = CIContext(options: [.useSoftwareRenderer: false])
// The menus open upward from the plus and 高速 at the composer's leading
// end: the lower 60% of the screen, its leading 72%.
let cropTop = 0.4, cropWidth = 0.72, tileWidth = 220.0, columns = 6, maxTiles = 24

struct Frame { let time: Double; let tile: CGImage; let probe: [UInt8] }

func frames(from: Double, to: Double) -> [Frame] {
    guard let reader = try? AVAssetReader(asset: asset) else { return [] }
    reader.timeRange = CMTimeRange(start: CMTime(seconds: max(0, from), preferredTimescale: 600),
                                   end: CMTime(seconds: max(0, to), preferredTimescale: 600))
    let out = AVAssetReaderTrackOutput(track: track, outputSettings:
        [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
    reader.add(out)
    guard reader.startReading() else { return [] }
    var result: [Frame] = []
    while let sample = out.copyNextSampleBuffer() {
        guard let buffer = CMSampleBufferGetImageBuffer(sample) else { continue }
        let time = CMSampleBufferGetPresentationTimeStamp(sample).seconds
        let image = CIImage(cvPixelBuffer: buffer)
        let full = image.extent
        // Core Image's origin is at the bottom: the lower part starts at 0.
        let lower = CGRect(x: 0, y: 0, width: full.width * cropWidth, height: full.height * (1 - cropTop))
        let scale = tileWidth / lower.width
        let tileImage = image.cropped(to: lower).transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        guard let tile = context.createCGImage(tileImage, from: tileImage.extent.integral) else { continue }
        // A small gray copy to find the frames that change.
        let probeSize = (w: 48, h: 64)
        var probe = [UInt8](repeating: 0, count: probeSize.w * probeSize.h)
        probe.withUnsafeMutableBytes { bytes in
            if let gray = CGContext(data: bytes.baseAddress, width: probeSize.w, height: probeSize.h, bitsPerComponent: 8,
                                    bytesPerRow: probeSize.w, space: CGColorSpaceCreateDeviceGray(),
                                    bitmapInfo: CGImageAlphaInfo.none.rawValue) {
                gray.draw(tile, in: CGRect(x: 0, y: 0, width: probeSize.w, height: probeSize.h))
            }
        }
        result.append(Frame(time: time, tile: tile, probe: probe))
    }
    return result
}

func difference(_ a: [UInt8], _ b: [UInt8]) -> Double {
    var total = 0
    for index in a.indices { total += abs(Int(a[index]) - Int(b[index])) }
    return Double(total) / Double(a.count)
}

func writeSheet(_ tiles: [CGImage], to url: URL) -> Bool {
    guard let first = tiles.first else { return false }
    let width = first.width, height = first.height, gap = 4
    let rows = (tiles.count + columns - 1) / columns
    let sheetWidth = columns * width + (columns - 1) * gap, sheetHeight = rows * height + (rows - 1) * gap
    guard let sheet = CGContext(data: nil, width: sheetWidth, height: sheetHeight, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
    sheet.setFillColor(CGColor(red: 1, green: 0, blue: 1, alpha: 1))
    sheet.fill(CGRect(x: 0, y: 0, width: sheetWidth, height: sheetHeight))
    for (index, tile) in tiles.enumerated() {
        let row = index / columns, column = index % columns
        // Rows run from the top, while the context's origin is at the bottom.
        let y = sheetHeight - (row + 1) * height - row * gap
        sheet.draw(tile, in: CGRect(x: column * (width + gap), y: y, width: width, height: height))
    }
    guard let image = sheet.makeImage(),
          let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil)
    else { return false }
    CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.55] as CFDictionary)
    return CGImageDestinationFinalize(destination)
}

for (name, epoch) in marks {
    // The tap lands a few hundred milliseconds after its mark.
    let at = epoch - start
    let all = frames(from: at - 0.4, to: at + 2.2)
    guard all.count > 1 else { print("MENU-FRAMES \(name) at=\(at) frames=\(all.count)"); continue }
    var changes = [0.0]
    for index in 1..<all.count { changes.append(difference(all[index - 1].probe, all[index].probe)) }
    let moving = changes.indices.filter { changes[$0] > 0.4 }
    var first = max(0, (moving.first ?? 0) - 2), last = min(all.count - 1, (moving.last ?? all.count - 1) + 2)
    if last <= first { first = 0; last = all.count - 1 }
    var picked = Array(first...last)
    if picked.count > maxTiles {
        let step = Double(picked.count - 1) / Double(maxTiles - 1)
        picked = (0..<maxTiles).map { picked[Int((Double($0) * step).rounded())] }
    }
    let times = picked.map { String(format: "%.0f", (all[$0].time - at) * 1000) }.joined(separator: ",")
    let deltas = picked.map { String(format: "%.1f", changes[$0]) }.joined(separator: ",")
    print("MENU-FRAMES \(name) at=\(String(format: "%.2f", at)) frames=\(all.count) shown=\(picked.count) ms=\(times) change=\(deltas)")
    let url = output.appendingPathComponent("composer-video-\(name).jpg")
    guard writeSheet(picked.map { all[$0].tile }, to: url), let data = try? Data(contentsOf: url) else { continue }
    print("SHOT-BEGIN composer-video-\(name)"); print(data.base64EncodedString()); print("SHOT-END")
}
