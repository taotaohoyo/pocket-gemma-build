// The history's 設定 button held down, from the session recording (simctl
// recordVideo), for review where artifact downloads are unavailable
// (1.1.0 (300)): for each GEAR-MARK line testSettingsButtonPressStaysPut
// printed (name, epoch, the button's frame in points, the screen's width),
// the button's corner of every frame from just before the press until 設定
// covers it, at the screen's own pixels, on one sheet printed as base64;
// and per frame the gear glyph's box (its centre and size in points), the
// notice dot's yellow pixels and their centre, and how light the circle's
// inside is (the press's wash), as GEAR-PRESS lines.
//
// swift scripts/gear-press.swift <recording.mp4> <start epoch file> <test log> <output dir>
import AVFoundation
import CoreImage
import Foundation
import ImageIO
import UniformTypeIdentifiers

let arguments = CommandLine.arguments
guard arguments.count == 5 else { print("GEAR-PRESS usage: video start log out"); exit(2) }
let video = URL(fileURLWithPath: arguments[1])
let start = Double((try? String(contentsOfFile: arguments[2], encoding: .utf8))?
    .trimmingCharacters(in: .whitespacesAndNewlines) ?? "") ?? 0
let output = URL(fileURLWithPath: arguments[4], isDirectory: true)
try? FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
let log = (try? String(contentsOfFile: arguments[3], encoding: .utf8)) ?? ""

struct Mark { let name: String; let epoch: Double; let frame: CGRect; let screenWidth: Double }
var marks: [Mark] = []
for line in log.split(separator: "\n") {
    guard let range = line.range(of: "GEAR-MARK ") else { continue }
    let fields = line[range.upperBound...].split(separator: " ").map(String.init)
    guard fields.count >= 7, let epoch = Double(fields[1]), let x = Double(fields[2]), let y = Double(fields[3]),
          let w = Double(fields[4]), let h = Double(fields[5]), let screen = Double(fields[6]),
          !marks.contains(where: { $0.name == fields[0] }) else { continue }
    marks.append(Mark(name: fields[0], epoch: epoch, frame: CGRect(x: x, y: y, width: w, height: h), screenWidth: screen))
}
print("GEAR-PRESS start=\(start) marks=\(marks.count)")
guard start > 0, !marks.isEmpty else { exit(0) }

let asset = AVURLAsset(url: video)
guard let track = asset.tracks(withMediaType: .video).first else { print("GEAR-PRESS no video track"); exit(0) }
let context = CIContext(options: [.useSoftwareRenderer: false])

struct Reading {
    let time: Double
    let tile: CGImage
    let glyph: CGRect?      // points, in the crop
    let dot: Int
    let dotCentre: CGPoint?
    let inside: Double      // mean luma of the circle's ring between gear and rim
}

func read(_ mark: Mark, from: Double, to: Double) -> [Reading] {
    guard let reader = try? AVAssetReader(asset: asset) else { return [] }
    reader.timeRange = CMTimeRange(start: CMTime(seconds: max(0, from), preferredTimescale: 600),
                                   end: CMTime(seconds: max(0, to), preferredTimescale: 600))
    let out = AVAssetReaderTrackOutput(track: track, outputSettings:
        [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA])
    reader.add(out)
    guard reader.startReading() else { return [] }
    var result: [Reading] = []
    // The button and 18pt round it.
    let margin = 18.0
    let area = mark.frame.insetBy(dx: -margin, dy: -margin)
    while let sample = out.copyNextSampleBuffer() {
        guard let buffer = CMSampleBufferGetImageBuffer(sample) else { continue }
        let time = CMSampleBufferGetPresentationTimeStamp(sample).seconds
        let image = CIImage(cvPixelBuffer: buffer)
        let full = image.extent
        let scale = Double(full.width) / mark.screenWidth
        // Core Image's origin is at the bottom.
        let rect = CGRect(x: Double(area.minX) * scale, y: Double(full.height) - Double(area.maxY) * scale,
                          width: Double(area.width) * scale, height: Double(area.height) * scale).integral
        let cropped = image.cropped(to: rect).transformed(by: CGAffineTransform(translationX: -rect.minX, y: -rect.minY))
        guard let tile = context.createCGImage(cropped, from: CGRect(origin: .zero, size: rect.size)) else { continue }
        let width = tile.width, height = tile.height
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let drawn = bytes.withUnsafeMutableBytes { raw -> Bool in
            guard let bitmap = CGContext(data: raw.baseAddress, width: width, height: height, bitsPerComponent: 8,
                                         bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
                                         bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            bitmap.draw(tile, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }
        guard drawn else { continue }
        // The background's luma at the crop's corner (left bottom, away
        // from the dot): the gear is far from it, dark on light or light
        // on dark.
        func pixel(_ x: Int, _ y: Int) -> (Int, Int, Int) {
            let index = (y * width + x) * 4
            return (Int(bytes[index]), Int(bytes[index + 1]), Int(bytes[index + 2]))
        }
        let corner = pixel(2, height - 3)
        let ground = (corner.0 * 2126 + corner.1 * 7152 + corner.2 * 722) / 10000
        let dark = ground < 128
        let centreX = Double(mark.frame.midX - area.minX) * scale, centreY = Double(mark.frame.midY - area.minY) * scale
        let radius = Double(mark.frame.width) / 2 * scale
        var minX = Int.max, maxX = Int.min, minY = Int.max, maxY = Int.min
        var dot = 0, dotX = 0.0, dotY = 0.0, ring = 0, ringSum = 0
        for y in 0..<height {
            for x in 0..<width {
                let (r, g, b) = pixel(x, y)
                let luma = (r * 2126 + g * 7152 + b * 722) / 10000
                let chroma = max(r, g, b) - min(r, g, b)
                if r > 215, g > 165, g < 235, b < 120 {
                    dot += 1; dotX += Double(x); dotY += Double(y)
                    continue
                }
                let dx = Double(x) + 0.5 - centreX, dy = Double(y) + 0.5 - centreY
                let d = (dx * dx + dy * dy).squareRoot()
                // The gear: well inside the circle, strongly dark (light
                // mode) or light (dark mode) and grey.
                if d < radius * 0.75, chroma < 40, dark ? luma > 130 : luma < 150 {
                    minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
                }
                if d > radius * 0.62, d < radius * 0.85 { ring += 1; ringSum += luma }
            }
        }
        let glyph = minX <= maxX ? CGRect(x: Double(minX) / scale, y: Double(minY) / scale,
                                          width: Double(maxX - minX + 1) / scale, height: Double(maxY - minY + 1) / scale) : nil
        let dotCentre = dot > 0 ? CGPoint(x: dotX / Double(dot) / scale, y: dotY / Double(dot) / scale) : nil
        result.append(Reading(time: time, tile: tile, glyph: glyph, dot: dot, dotCentre: dotCentre,
                              inside: ring > 0 ? Double(ringSum) / Double(ring) : 0))
    }
    return result
}

func writeSheet(_ tiles: [CGImage], columns: Int, to url: URL) -> Bool {
    guard let first = tiles.first else { return false }
    let width = first.width, height = first.height, gap = 4
    let rows = (tiles.count + columns - 1) / columns
    let sheetWidth = columns * width + (columns - 1) * gap, sheetHeight = rows * height + (rows - 1) * gap
    guard let sheet = CGContext(data: nil, width: sheetWidth, height: sheetHeight, bitsPerComponent: 8, bytesPerRow: 0,
                                space: CGColorSpaceCreateDeviceRGB(),
                                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
    sheet.setFillColor(CGColor(red: 1, green: 0, blue: 1, alpha: 1))
    sheet.fill(CGRect(x: 0, y: 0, width: sheetWidth, height: sheetHeight))
    for (index, tile) in tiles.enumerated() {
        let row = index / columns, column = index % columns
        let y = sheetHeight - (row + 1) * height - row * gap
        sheet.draw(tile, in: CGRect(x: column * (width + gap), y: y, width: width, height: height))
    }
    guard let image = sheet.makeImage(),
          let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.jpeg.identifier as CFString, 1, nil)
    else { return false }
    CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.8] as CFDictionary)
    return CGImageDestinationFinalize(destination)
}

for mark in marks {
    let at = mark.epoch - start
    // The press lands a few hundred milliseconds after its mark and lasts
    // 1.2 s; 設定 then comes up over the button.
    let all = read(mark, from: at - 0.3, to: at + 2.2)
    guard let rest = all.first, let restGlyph = rest.glyph else { print("GEAR-PRESS \(mark.name) at=\(at) frames=\(all.count) no gear"); continue }
    var lines: [String] = []
    var shiftMost = 0.0, sizeMost = 0.0, dotLeast = Int.max, dotMost = 0, dotMoved = 0.0
    var washMost = 0.0
    for reading in all {
        let ms = String(format: "%.0f", (reading.time - at) * 1000)
        guard let glyph = reading.glyph else { lines.append("\(ms):covered"); continue }
        // A frame where 設定 has come up has no gear where it was, or one
        // far from it: the press is over.
        let shift = hypot(Double(glyph.midX - restGlyph.midX), Double(glyph.midY - restGlyph.midY))
        let size = Double(max(abs(glyph.width - restGlyph.width), abs(glyph.height - restGlyph.height)))
        if shift > 12 || size > 12 { lines.append("\(ms):covered"); continue }
        shiftMost = max(shiftMost, shift)
        sizeMost = max(sizeMost, size)
        washMost = max(washMost, abs(reading.inside - rest.inside))
        if rest.dot > 0 {
            dotLeast = min(dotLeast, reading.dot); dotMost = max(dotMost, reading.dot)
            if let centre = reading.dotCentre, let first = rest.dotCentre {
                dotMoved = max(dotMoved, hypot(Double(centre.x - first.x), Double(centre.y - first.y)))
            }
        }
        lines.append(ms + String(format: ":gear(%.1f,%.1f %.1fx%.1f) dot %ld inside %.0f", Double(glyph.midX), Double(glyph.midY),
                                 Double(glyph.width), Double(glyph.height), reading.dot, reading.inside))
    }
    print("GEAR-PRESS \(mark.name) at=\(String(format: "%.2f", at)) frames=\(all.count) "
          + String(format: "gear moved at most %.2fpt, size changed at most %.2fpt; dot pixels %@; dot moved at most %.2fpt; wash %.0f levels",
                   shiftMost, sizeMost, rest.dot > 0 ? "\(dotLeast)-\(dotMost)" : "none", dotMoved, washMost))
    print("GEAR-PRESS \(mark.name) frames (ms after the mark): " + lines.joined(separator: " "))
    // Every frame while held, at most 24 on the sheet.
    var picked = Array(all.indices)
    if picked.count > 24 {
        let step = Double(picked.count - 1) / 23
        picked = (0..<24).map { picked[Int((Double($0) * step).rounded())] }
    }
    let url = output.appendingPathComponent("gearpress-film-\(mark.name).jpg")
    guard writeSheet(picked.map { all[$0].tile }, columns: 8, to: url), let data = try? Data(contentsOf: url) else { continue }
    print("GEAR-PRESS \(mark.name) sheet ms=" + picked.map { String(format: "%.0f", (all[$0].time - at) * 1000) }.joined(separator: ","))
    print("SHOT-BEGIN gearpress-film-\(mark.name)"); print(data.base64EncodedString()); print("SHOT-END")
}
