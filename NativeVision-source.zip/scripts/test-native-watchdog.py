"""Verify timeout termination, preserved evidence and failure propagation."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest


class WatchdogTests(unittest.TestCase):
    def invoke(self, command, timeout):
        temp_root=Path(__file__).resolve().parent.parent/'dist/watchdog-test-tmp'
        temp_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temp_root) as temp:
            root=Path(temp); log=root/'test.log'; metrics=root/'activity.jsonl'
            assert root.resolve().is_relative_to(temp_root.resolve())
            result=subprocess.run([sys.executable, str(Path(__file__).with_name('native-test-watchdog.py')),
                '--timeout', str(timeout), '--interval', '0.1', '--log', str(log), '--metrics', str(metrics),
                '--', sys.executable, '-u', '-c', command], capture_output=True, text=True, timeout=12)
            self.assertTrue(metrics.is_file(), result.stderr)
            records=[json.loads(line) for line in metrics.read_text().splitlines()]
            return result.returncode, log.read_text(), records[-1]['outcome'], records

    def test_timeout_stops_child_and_preserves_activity_and_log(self):
        code,log,outcome,records=self.invoke('import time; print("started"); time.sleep(30)',0.4)
        self.assertEqual(code,124); self.assertTrue(outcome['timedOut'])
        self.assertIn('started',log); self.assertIsNotNone(outcome['childExitCode'])
        self.assertLess(outcome['elapsedSeconds'],10)
        self.assertTrue(any(row.get('logBytes',0)>0 for row in records))

    def test_failure_is_not_reported_as_success(self):
        code,log,outcome,_=self.invoke('import sys; print("failed"); sys.exit(7)',2)
        self.assertEqual(code,7); self.assertFalse(outcome['timedOut']); self.assertIn('failed',log)

    def test_completed_command_passes(self):
        code,log,outcome,_=self.invoke('print("completed")',2)
        self.assertEqual(code,0); self.assertFalse(outcome['timedOut']); self.assertIn('completed',log)


if __name__ == '__main__':
    unittest.main()
