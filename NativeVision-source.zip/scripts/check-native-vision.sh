#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
mkdir -p build/NativeVision
xcodegen generate --spec native-test-project.yml
xcrun simctl list runtimes -j > build/NativeVision/runtimes.json
runtime_id="$(python3 - <<'PY'
import json
d=json.load(open('build/NativeVision/runtimes.json'))['runtimes']
usable=[r for r in d if r.get('isAvailable') and r['name'].startswith('iOS') and tuple(map(int,r['version'].split('.'))) >= (26,4)]
assert usable, 'Pinned native dependency requires an installed iOS 26.4+ simulator'
print(max(usable, key=lambda r:tuple(map(int,r['version'].split('.'))))['identifier'])
PY
)"
simulator_id="$(xcrun simctl create 'Pocket Gemma actual native vision' 'com.apple.CoreSimulator.SimDeviceType.iPhone-17-Pro' "$runtime_id")"
log_pid=""
cleanup() {
  if [[ -n "$log_pid" ]]; then kill "$log_pid" 2>/dev/null || true; fi
  xcrun simctl shutdown "$simulator_id" || true
}
trap cleanup EXIT
xcrun simctl boot "$simulator_id"
xcrun simctl bootstatus "$simulator_id" -b
if ! xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build-for-testing \
  > build/NativeVision/build.log 2>&1; then
  tail -180 build/NativeVision/build.log
  exit 1
fi
python3 scripts/record-runtime-build.py --app build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app --derived-data build/NativeDerived --target iphonesimulator --configuration Debug > build/NativeVision/runtime-build.json
xcrun simctl install "$simulator_id" build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app
data_container="$(xcrun simctl get_app_container "$simulator_id" app.pocketgemma.personal data)"
python3 scripts/download-vision-models.py "$data_container/Documents/NativeModels"
xcrun simctl spawn "$simulator_id" log stream --level debug --predicate 'process == "PocketGemma"' \
  > build/NativeVision/native-system.log 2>&1 &
log_pid=$!
set +e
xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  -resultBundlePath build/NativeVision/NativeVision.xcresult -parallel-testing-enabled NO \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testProductionConfigurationMatrix4096 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testPhotoImportSniffsExtensionlessAndGenericData \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBundledJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBundledJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBuiltinJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBuiltinJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testBuiltinVisionRecoverySwitchAndMemoryPlateau \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BIsolatedCPUComponents \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BIsolatedCPUComponents \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testNativeLogCaptureRestoresStderrAndRecordsOnlyOperationalErrors \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUModelSwitchImagesAndText \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUBadImageErrorThenGoodImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BCPUBadImageErrorThenGoodImage \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building \
  > build/NativeVision/tests.log 2>&1
test_exit=$?
set -e
if [[ -d build/NativeVision/NativeVision.xcresult ]]; then
  xcrun xcresulttool get test-results summary --path build/NativeVision/NativeVision.xcresult \
    > build/NativeVision/summary.json || true
fi
# Preserve the real XCTest failure before any diagnostic-export assertion.
tail -150 build/NativeVision/tests.log
python3 - <<'PY'
from pathlib import Path
import json
root=Path.home()/'Library/Logs/DiagnosticReports'
records=[]
for path in sorted(root.glob('PocketGemma*.ips'), key=lambda p:p.stat().st_mtime, reverse=True)[:5]:
    if path.stat().st_size <= 1500000:
        records.append({'file':path.name,'report':path.read_text(errors='replace')})
Path('build/NativeVision/native-crashes.json').write_text(json.dumps(records))
PY
python3 - <<'PY'
import base64, json, re
from pathlib import Path
root = Path('build/NativeVision')
log = (root / 'tests.log').read_text(errors='replace')
for marker, filename in [('MATRIX', 'configuration-matrix.json'), ('HISTORY', 'inference-comparisons.json')]:
    matches = re.findall(r'NATIVE_' + marker + r'_JSON ([A-Za-z0-9+/=]+)', log)
    if not matches:
        raise SystemExit('Missing native diagnostic export: ' + marker)
    data = base64.b64decode(matches[-1], validate=True)
    assert len(data) < 768000 and isinstance(json.loads(data), list)
    (root / filename).write_bytes(data)
probes = [json.loads(base64.b64decode(item, validate=True)) for item in
          re.findall(r'NATIVE_PROBE_JSON ([A-Za-z0-9+/=]+)', log)]
assert probes, 'Missing direct/component diagnostic exports'
(root / 'isolated-probes.json').write_text(json.dumps(probes, indent=2))
stability = re.findall(r'NATIVE_STABILITY_JSON ([A-Za-z0-9+/=]+)', log)
assert stability, 'Missing repeated-inference memory evidence'
(root / 'memory-stability.json').write_bytes(base64.b64decode(stability[-1], validate=True))
PY
exit "$test_exit"
