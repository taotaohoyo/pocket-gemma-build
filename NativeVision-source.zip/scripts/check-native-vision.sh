#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
mkdir -p build/NativeVision
xcodegen generate --spec native-test-project.yml
xcrun simctl list runtimes -j > build/NativeVision/runtimes.json
runtime_id="$(python3 - <<'PY'
import json
d=json.load(open('build/NativeVision/runtimes.json'))['runtimes']
usable=[r for r in d if r.get('isAvailable') and r['name'].startswith('iOS') and tuple(map(int,r['version'].split('.'))) >= (26,4)]
assert usable, 'Pinned native dependency requires an installed iOS 26.4+ simulator'
print(max(usable, key=lambda r:tuple(map(int,r['version'].split('.'))))['identifier'])
PY
)"
simulator_id="$(xcrun simctl create 'Pocket Gemma actual native vision' 'com.apple.CoreSimulator.SimDeviceType.iPhone-17-Pro' "$runtime_id")"
log_pid=""
cleanup() {
  if [[ -n "$log_pid" ]]; then kill "$log_pid" 2>/dev/null || true; fi
  xcrun simctl shutdown "$simulator_id" || true
}
trap cleanup EXIT
xcrun simctl boot "$simulator_id"
xcrun simctl bootstatus "$simulator_id" -b
if ! xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build-for-testing \
  > build/NativeVision/build.log 2>&1; then
  tail -180 build/NativeVision/build.log
  exit 1
fi
python3 scripts/record-runtime-build.py --app build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app --derived-data build/NativeDerived --target iphonesimulator --configuration Debug > build/NativeVision/runtime-build.json
xcrun simctl install "$simulator_id" build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app
data_container="$(xcrun simctl get_app_container "$simulator_id" app.pocketgemma.personal data)"
probe="${NATIVE_PROBE:-text}"
# Download only the pinned files the selected probe loads.
case "$probe" in
  qwen-text|qwen-files) native_models=QWEN3,QWEN25 ;;
  *) native_models=E2B,E4B ;;
esac
NATIVE_MODELS="$native_models" python3 scripts/download-vision-models.py "$data_container/Documents/NativeModels"
xcrun simctl spawn "$simulator_id" log stream --level debug --predicate 'process == "PocketGemma"' \
  > build/NativeVision/native-system.log 2>&1 &
log_pid=$!
save_crash_reports() {
python3 - <<'PY'
from pathlib import Path
import json
root=Path.home()/'Library/Logs/DiagnosticReports'
records=[]
for path in sorted(root.glob('PocketGemma*.ips'), key=lambda p:p.stat().st_mtime, reverse=True)[:5]:
    if path.stat().st_size <= 1500000:
        records.append({'file':path.name,'report':path.read_text(errors='replace')})
Path('build/NativeVision/native-crashes.json').write_text(json.dumps(records))
PY
}
# Fail fast on an LM initialization crash instead of relaunching the app for
# every image case. No image suite is run until this small text request passes.
case "$probe" in
  ui-ux-regression)
    process_limit=600; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testAttachmentGatesBeforeNativeEntry
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BVerifiedImageAndDocumentImports
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BTextOnlyAfterLegacyImageHistory)
    ;;
  text)
    process_limit=240; test_limit=120
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke)
    ;;
  long-reply)
    process_limit=900; test_limit=720
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLongReplyContinuesPastContextWindow)
    ;;
  chart-reply)
    process_limit=1500; test_limit=1200
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testChartRepliesFromRealModels)
    ;;
  qwen-text)
    # Qwen3 0.6B and Qwen2.5 1.5B on CPU: Japanese chat turns, Markdown, math
    # and code. The watchdog allows at most 1800 seconds, so files and photo
    # text run in qwen-files.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenJapaneseChatAndRichReplies)
    ;;
  qwen-files)
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testDocumentImportsForEveryModel
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testLongFileExcerptAroundTheQuestion
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenReadsFilesAsMaterial
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenReadsPhotoText)
    ;;
  files)
    # E2B/E4B read files as material; E2B's own photo path still answers.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BVerifiedImageAndDocumentImports
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testDocumentImportsForEveryModel
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testLongFileExcerptAroundTheQuestion
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testGemmaReadsFilesAsMaterial)
    ;;
  images-xnnpack)
    process_limit=900; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSquareJPEG70)
    ;;
  text-and-images-xnnpack)
    process_limit=600; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BPortraitJPEG)
    ;;
  images-builtin)
    process_limit=600; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBuiltinJPEGs
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBuiltinJPEGs)
    ;;
  *) echo "Unsupported explicit native probe: $probe"; exit 2 ;;
esac
echo "NATIVE_SELECTED_PROBE $probe process_limit=$process_limit test_limit=$test_limit"
set +e
python3 scripts/native-test-watchdog.py --timeout "$process_limit" \
  --log build/NativeVision/smoke.log --metrics build/NativeVision/smoke-activity.jsonl \
  --simulator "$simulator_id" -- \
  xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  -resultBundlePath build/NativeVision/NativeSmoke.xcresult -parallel-testing-enabled NO \
  -test-timeouts-enabled YES -default-test-execution-time-allowance "$test_limit" \
  -maximum-test-execution-time-allowance "$test_limit" \
  "${selected_tests[@]}" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
smoke_exit=$?
set -e
tail -100 build/NativeVision/smoke.log
grep -aE 'NATIVE_(CHART_|MODEL_REPLY|FILE_EXCERPT|EXCERPT|PHOTO_TEXT|ADDRESS)' build/NativeVision/smoke.log || true
save_crash_reports
if [[ -d build/NativeVision/NativeSmoke.xcresult ]]; then
  xcrun xcresulttool get test-results summary --path build/NativeVision/NativeSmoke.xcresult \
    > build/NativeVision/smoke-summary.json || true
fi
if [[ "$smoke_exit" -ne 0 ]]; then
  if [[ -s build/NativeVision/smoke-summary.json ]]; then
    cp build/NativeVision/smoke-summary.json build/NativeVision/summary.json
  fi
  echo "Selected probe $probe failed or timed out ($smoke_exit). Evidence retained; no full suite or automatic retry."
  exit "$smoke_exit"
fi
if [[ "${NATIVE_SMOKE_ONLY:-0}" == 1 ]]; then
  cp build/NativeVision/smoke-summary.json build/NativeVision/summary.json
  echo "Bounded explicit SDK probe passed ($probe). Full image suite was not run."
  exit 0
fi
set +e
python3 scripts/native-test-watchdog.py --timeout 1200 \
  --log build/NativeVision/tests.log --metrics build/NativeVision/test-activity.jsonl \
  --simulator "$simulator_id" -- \
  xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  -resultBundlePath build/NativeVision/NativeVision.xcresult -parallel-testing-enabled NO \
  -test-timeouts-enabled YES -default-test-execution-time-allowance 180 \
  -maximum-test-execution-time-allowance 600 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testProductionConfigurationMatrix4096 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testPhotoImportSniffsExtensionlessAndGenericData \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBundledJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBundledJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBuiltinJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBuiltinJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testBuiltinVisionRecoverySwitchAndMemoryPlateau \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BIsolatedCPUComponents \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BIsolatedCPUComponents \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testNativeLogCaptureRestoresStderrAndRecordsOnlyOperationalErrors \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUModelSwitchImagesAndText \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUBadImageErrorThenGoodImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BCPUBadImageErrorThenGoodImage \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
test_exit=$?
set -e
if [[ -d build/NativeVision/NativeVision.xcresult ]]; then
  xcrun xcresulttool get test-results summary --path build/NativeVision/NativeVision.xcresult \
    > build/NativeVision/image-summary.json || true
fi
# Preserve the real XCTest failure before any diagnostic-export assertion.
tail -150 build/NativeVision/tests.log
save_crash_reports
python3 - <<'PY'
from pathlib import Path
import json
root=Path('build/NativeVision')
if (root/'image-summary.json').is_file() and (root/'image-summary.json').stat().st_size:
    image=json.loads((root/'image-summary.json').read_text())
    smoke=json.loads((root/'smoke-summary.json').read_text())
    summary=dict(image)
    for key in ['passedTests','failedTests','skippedTests','totalTestCount']:
        summary[key]=image[key]+smoke[key]
    summary['result']='Passed' if image['result']=='Passed' and smoke['result']=='Passed' else 'Failed'
    summary['phaseSummaries']=['smoke-summary.json','image-summary.json']
    (root/'summary.json').write_text(json.dumps(summary,indent=2))
PY
if [[ "$test_exit" -ne 0 ]]; then
  echo "Image suite failed or hit its 20-minute wall limit ($test_exit); logs and activity retained."
  exit "$test_exit"
fi
python3 - <<'PY'
import base64, json, re
from pathlib import Path
root = Path('build/NativeVision')
log = (root / 'tests.log').read_text(errors='replace')
for marker, filename in [('MATRIX', 'configuration-matrix.json'), ('HISTORY', 'inference-comparisons.json')]:
    matches = re.findall(r'NATIVE_' + marker + r'_JSON ([A-Za-z0-9+/=]+)', log)
    if not matches:
        raise SystemExit('Missing native diagnostic export: ' + marker)
    data = base64.b64decode(matches[-1], validate=True)
    assert len(data) < 768000 and isinstance(json.loads(data), list)
    (root / filename).write_bytes(data)
probes = [json.loads(base64.b64decode(item, validate=True)) for item in
          re.findall(r'NATIVE_PROBE_JSON ([A-Za-z0-9+/=]+)', log)]
assert probes, 'Missing direct/component diagnostic exports'
(root / 'isolated-probes.json').write_text(json.dumps(probes, indent=2))
stability = re.findall(r'NATIVE_STABILITY_JSON ([A-Za-z0-9+/=]+)', log)
assert stability, 'Missing repeated-inference memory evidence'
(root / 'memory-stability.json').write_bytes(base64.b64decode(stability[-1], validate=True))
PY
exit "$test_exit"
