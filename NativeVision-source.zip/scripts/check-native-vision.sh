#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/select-xcode.sh
mkdir -p build/NativeVision
xcodegen generate --spec native-test-project.yml
xcrun simctl list runtimes -j > build/NativeVision/runtimes.json
runtime_id="$(python3 - <<'PY'
import json
d=json.load(open('build/NativeVision/runtimes.json'))['runtimes']
usable=[r for r in d if r.get('isAvailable') and r['name'].startswith('iOS') and tuple(map(int,r['version'].split('.'))) >= (26,4)]
assert usable, 'Pinned native dependency requires an installed iOS 26.4+ simulator'
print(max(usable, key=lambda r:tuple(map(int,r['version'].split('.'))))['identifier'])
PY
)"
simulator_id="$(xcrun simctl create 'Pocket Gemma actual native vision' 'com.apple.CoreSimulator.SimDeviceType.iPhone-17-Pro' "$runtime_id")"
log_pid=""
cleanup() {
  if [[ -n "$log_pid" ]]; then kill "$log_pid" 2>/dev/null || true; fi
  xcrun simctl shutdown "$simulator_id" || true
}
trap cleanup EXIT
xcrun simctl boot "$simulator_id"
xcrun simctl bootstatus "$simulator_id" -b
if ! xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build-for-testing \
  > build/NativeVision/build.log 2>&1; then
  tail -180 build/NativeVision/build.log
  exit 1
fi
python3 scripts/record-runtime-build.py --app build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app --derived-data build/NativeDerived --target iphonesimulator --configuration Debug > build/NativeVision/runtime-build.json
xcrun simctl install "$simulator_id" build/NativeDerived/Build/Products/Debug-iphonesimulator/PocketGemma.app
data_container="$(xcrun simctl get_app_container "$simulator_id" app.pocketgemma.personal data)"
probe="${NATIVE_PROBE:-text}"
# Download only the pinned files the selected probe loads.
case "$probe" in
  qwen-text) native_models=E2B,QWEN3,QWEN25 ;;
  qwen-files|qwen-gpu) native_models=QWEN3,QWEN25 ;;
  files|chart-talk|chart-recall|chart-sheet|chart-final|chart-placeholder|open-turn|reply-language-e2b|try-questions-e2b) native_models=E2B ;;
  reply-language-e4b-*|audio-e4b|video-audio-e4b) native_models=E4B ;;
  audio-e2b|video-audio-e2b|video-long-e2b) native_models=E2B ;;
  gemma12b-text) native_models=GEMMA12B ;;
  phi-text) native_models=PHI4 ;;
  qwen35-text|qwen35-thinking) native_models=QWEN35 ;;
  qwen35-trace) native_models=QWEN35 ;;
  phi-trace) native_models=PHI4 ;;
  cpu-compare) native_models=E2B,QWEN3,QWEN35 ;;
  gpu-new-models|memory-new-models|lock-new-models) native_models=QWEN35,PHI4 ;;
  *) native_models=E2B,E4B ;;
esac
NATIVE_MODELS="$native_models" python3 scripts/download-vision-models.py "$data_container/Documents/NativeModels"
xcrun simctl spawn "$simulator_id" log stream --level debug --predicate 'process == "PocketGemma"' \
  > build/NativeVision/native-system.log 2>&1 &
log_pid=$!
save_crash_reports() {
python3 - <<'PY'
from pathlib import Path
import json
root=Path.home()/'Library/Logs/DiagnosticReports'
records=[]
for path in sorted(root.glob('PocketGemma*.ips'), key=lambda p:p.stat().st_mtime, reverse=True)[:5]:
    if path.stat().st_size <= 1500000:
        records.append({'file':path.name,'report':path.read_text(errors='replace')})
Path('build/NativeVision/native-crashes.json').write_text(json.dumps(records))
PY
}
# Fail fast on an LM initialization crash instead of relaunching the app for
# every image case. No image suite is run until this small text request passes.
case "$probe" in
  ui-ux-regression)
    process_limit=600; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testAttachmentGatesBeforeNativeEntry
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BVerifiedImageAndDocumentImports
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPortraitJPEG)
    ;;
  text)
    process_limit=240; test_limit=120
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke)
    ;;
  long-reply)
    process_limit=900; test_limit=720
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLongReplyContinuesPastContextWindow)
    ;;
  open-turn)
    # A reply stopped partway (the app left the screen) goes on from its
    # last character in its own turn, on the CPU; then the long reply still
    # carries on past the context window, and E2B's photo still answers.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BStoppedReplyGoesOnFromItsLastCharacter
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLongReplyContinuesPastContextWindow
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage)
    ;;
  chart-reply)
    process_limit=1500; test_limit=1200
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testChartRepliesFromRealModels)
    ;;
  chart-talk|chart-recall)
    # E2B on CPU: a chart in a new chat and after other turns (chart-talk),
    # or a chart of data only the history holds, also after the app was in
    # the background (chart-recall).
    process_limit=1800; test_limit=1500
    if [[ "$probe" == chart-talk ]]; then
      selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartAfterOtherTurns)
    else
      selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartRecallsEarlierData
                      -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartRecallAfterLeavingTheApp)
    fi
    ;;
  chart-sheet)
    # E2B on CPU: three charts, Markdown and an analysis in one reply, as
    # asked on the phone (1.0.105), new and after other turns.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartSheet)
    ;;
  chart-final)
    # E2B on CPU: the user's own request from the phone (1.0.105), new and
    # after other turns, reworded, and without naming the native charts.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartFinalTest)
    ;;
  chart-placeholder)
    # E2B on CPU: the user's request again in a chat whose earlier reply
    # wrote placeholder sentences instead of charts (the phone, 1.0.105).
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartAfterPlaceholderReply)
    ;;
  qwen-text)
    # Qwen3 0.6B and Qwen2.5 1.5B on the CPU (the app's path for Qwen3): a
    # cold start, the GPU start 1.0.104 made on the phone, and switches with
    # E2B with the address space each leaves mapped. The chat, sampling and
    # memory tests (testQwen25/testQwen3JapaneseChatAndRichReplies,
    # testQwen3SamplingOnVariedRequests,
    # testQwen3MemoryOnLiveAndRebuiltConversations) ran through the same CPU
    # path at bd1882a (run 39369954741). The watchdog allows at most 1800
    # seconds, so Qwen's attachment refusals run in qwen-files.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenColdStartsOnTheCPUAndAfterAGPUFailure
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenSwitchesWithE2BReleaseTheirAddressSpace)
    ;;
  qwen-gpu)
    # The developer GPU start test: Qwen3 at each precision and Qwen2.5 on
    # the simulator's GPU (no Metal argument buffers or residency set here,
    # unlike the phone), then a Qwen3 chat on the GPU at 32-bit and a
    # Qwen2.5 chat in the same process.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenGPUStartTestRecordsEachPrecision)
    ;;
  qwen-files)
    # Qwen takes text only: imports and new files are refused, and older
    # chats with attachments still answer without them.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testDocumentImportsForEveryModel
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testLongFileExcerptAroundTheQuestion
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwenTakesTextOnlyAndAnswersOlderAttachmentChats)
    ;;
  e4b-photos)
    # E4B's chat photos at 70 image tokens (a photo, a text turn with it in
    # the history, a second photo), E2B's photo still at 280, the gates and
    # imports, then what a 280 photo takes from E4B's address space with a
    # 4096 and a 2048 context.
    process_limit=1800; test_limit=900
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testAttachmentGatesBeforeNativeEntry
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testDocumentImportsForEveryModel
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BChatPhotoAt70ImageTokens
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BVisionAddressSpaceByContext)
    ;;
  e4b-deep)
    # 深く: E4B's chat photos at 140 image tokens with the language model on
    # the CPU (a photo, a text turn with it in the history, a second photo),
    # E2B's photo still at 280, and the gates.
    process_limit=1800; test_limit=900
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testAttachmentGatesBeforeNativeEntry
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDeepChatPhotosAt140OnTheCPU)
    ;;
  e4b-fast)
    # 高速 without photos: E4B's MTP drafter, brief replies and no thinking,
    # beside 深く with and without the drafter (CPU), and E2B's photo still
    # at 280.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BFastTextTurnsDraftAndStayBrief)
    ;;
  web-search)
    # Web search: E2B and E4B call the tool when asked to look something up
    # and answer from the pages (real Wikipedia pages stand in for Tavily,
    # as CI has no key), a sum needs no search, no connection and stop are
    # handled, the largest results fit one GPU prefill, E4B also answers in
    # 深く, a reply that ended without a word after its search is written
    # again from the results, and E2B's photo still answers with search on
    # and off. The key's keychain round trip runs in the UI check (the
    # unsigned native app has no keychain).
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testWebSearchResultsFitOneGPUPrefill
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPhotoWithWebSearchOn
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BWebSearchAnswersFromResults
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BWebSearchAnswersAgainFromTheResults
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BWebSearchOfflineAnswersWithoutIt
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BStopCancelsTheSearch
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BWebSearchAnswersFromResults)
    ;;
  search-focus-e2b|search-focus-e4b|search-focus-e4b-more)
    # What a question asks about stays what is searched (1.1.0 (208)): the
    # versions in 「iOS27.2っていつ更新されるのー？」 (E4B searched 17.2 on
    # 205), 17.2 itself, a version no page names, iPhone 18 in Korean and a
    # follow-up, with mock Tavily pages (CI has no key) and the real model
    # on the CPU. E2B also measures the longest results' prefill for the
    # GPU and reads its photo with search on; E4B, slow on the simulator's
    # CPU, takes the cases in two runs.
    process_limit=1800; test_limit=1500
    case "$probe" in
      search-focus-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testWebSearchResultsFitOneGPUPrefill
                                        -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPhotoWithWebSearchOn
                                        -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSearchKeepsTheAskedVersion) ;;
      search-focus-e4b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSearchKeepsTheAskedVersion) ;;
      *) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSearchSaysWhatItCouldNotFind) ;;
    esac
    ;;
  search-live-e2b|search-live-e2b-more|search-live-e4b|search-live-e4b-more|search-live-e4b-rest|search-live-e2b-hidden|search-live-e4b-hidden)
    # Real Tavily and the real model (1.1.0 (211)): the ChatGPT question
    # that 210 answered from old pages in English, versions, the latest
    # software and news, follow-ups and what no page confirms, searched for
    # real through the runner's local relay (scripts/tavily-relay.py, which
    # alone holds the key) and answered on the CPU. Skipped without the
    # TAVILY_API_KEY secret. *-hidden: the ChatGPT cases when the searches
    # come back without the maker's pages, so the reply searches its sites.
    process_limit=1800; test_limit=1500
    case "$probe" in
      search-live-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLiveSearch) ;;
      search-live-e2b-hidden) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLiveSearchWithoutTheMakersPages) ;;
      search-live-e4b-hidden) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BLiveSearchWithoutTheMakersPages) ;;
      search-live-e2b-more) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLiveSearchMore) ;;
      search-live-e4b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BLiveSearch) ;;
      search-live-e4b-rest) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BLiveSearchRest) ;;
      *) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BLiveSearchMore) ;;
    esac
    ;;
  search-recorded-e2b|search-recorded-e4b)
    # The ChatGPT cases over the pages Tavily found on 2026-10-27
    # (1.1.0 (211)), real pages kept in the test, for runners without the
    # TAVILY_API_KEY secret; the real model on the CPU. Not a live search.
    process_limit=1800; test_limit=1500
    case "$probe" in
      search-recorded-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BRecordedSearch) ;;
      *) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BRecordedSearch) ;;
    esac
    ;;
  files)
    # E2B reads files as material, and its own photo path still answers.
    process_limit=1500; test_limit=1200
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BVerifiedImageAndDocumentImports
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testDocumentImportsForEveryModel
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testLongFileExcerptAroundTheQuestion
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BReadsFilesAsMaterial)
    ;;
  video)
    # 動画 (1.1.0 (192)): a made video's three scenes reach E2B and E4B in
    # order through the app's importer and service, and whether the pinned
    # E2B file takes sound at all (printed, not used by the app).
    process_limit=1800; test_limit=900
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BReadsAVideosScenesInOrder
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BReadsAVideosScenesInOrder
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BAudioInputFeasibility)
    ;;
  audio-e2b|audio-e4b)
    # A video's sound (1.1.0 (194)), measured before the app uses it: what
    # the pinned file declares, the memory an audio executor adds, the
    # audio tokens per second, spoken Japanese of several lengths written
    # down, sound that is not speech, and the system's sound classifier.
    process_limit=1800; test_limit=1700
    if [[ "$probe" == audio-e2b ]]; then
      selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BAudioMeasurements)
    else
      selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BAudioMeasurements)
    fi
    ;;
  video-audio-e2b|video-long-e2b|video-audio-e4b)
    # 動画の映像と音声 (1.1.0 (194)): made videos through the app's importer
    # and service: speech over three scenes (questions on the picture, the
    # speech and both), a video without sound, and a two-minute one whose
    # speech is condensed for the reply. One probe each, so they run side
    # by side within the watchdog's limit.
    process_limit=1800; test_limit=1700
    case "$probe" in
      video-audio-e2b)
        selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BVideoWithSpeechAndScenes
                        -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BVideoWithoutSound) ;;
      video-long-e2b)
        selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLongVideo) ;;
      *)
        selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BVideoWithSpeechAndScenes) ;;
    esac
    ;;
  images-xnnpack)
    # Five photos, three of them E4B on the CPU (280 and 70 image tokens).
    process_limit=1500; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSquareJPEG70)
    ;;
  text-and-images-xnnpack)
    process_limit=600; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testA0PatchedRuntimeTextSmoke
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BPortraitJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSquareJPEG
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BPortraitJPEG)
    ;;
  images-builtin)
    process_limit=600; test_limit=240
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBuiltinJPEGs
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBuiltinJPEGs)
    ;;
  reply-language-e2b|reply-language-e4b-current|reply-language-e4b-app|reply-language-e4b-app-rest)
    # Which language real replies are written in (1.1.0 (187)): sixteen
    # messages in new chats and after short chats, and questions about a
    # file, with the app's own system message; E4B also with the Japanese
    # prompt of 183 and its Japanese 高速 note, one per run, as the
    # simulator's CPU is slow.
    process_limit=1800; test_limit=1500
    case "$probe" in
      reply-language-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BReplyLanguage) ;;
      reply-language-e4b-current) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BReplyLanguageCurrent) ;;
      reply-language-e4b-app) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BReplyLanguageApp) ;;
      *) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BReplyLanguageAppRest) ;;
    esac
    ;;
  feature-language-e2b|long-reply-language|feature-language-e4b-search|feature-language-e4b-continuation|feature-language-e4b-chart|search-note-e2b|search-note-e4b)
    # Which language replies keep where the app adds words of its own
    # (1.1.0 (195)): a web search's notes and results (Wikipedia stands in
    # for Tavily, as CI has no key, and results written in the probe in
    # another language than the question's), the request that carries a
    # long reply on, and the chart note. E2B runs all three and a long reply
    # carried on round after round; E4B, slow on the simulator's CPU, one
    # part per run.
    process_limit=1800; test_limit=1500
    case "$probe" in
      search-note-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSearchNoteWordings) ;;
      search-note-e4b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSearchNoteWordings) ;;
      feature-language-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BSearchLanguage
                                            -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BContinuationLanguage
                                            -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartLanguage) ;;
      long-reply-language) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BLongReplyLanguages) ;;
      feature-language-e4b-search) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BSearchLanguage) ;;
      feature-language-e4b-continuation) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BContinuationLanguage) ;;
      *) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BChartLanguage) ;;
    esac
    ;;
  chart-note-e2b|chart-note-e4b)
    # Chart requests in a new chat whose words are mostly numbers (1.1.0
    # (244)): E2B answered the person's Japanese steps request in English
    # the first time on the phone. The 243 note, the app's (the message's
    # language named) and, for E2B, the note before the question and none,
    # through the app's own path (NATIVE_CHART_NOTE lines, replies in base64).
    process_limit=1800; test_limit=1500
    case "$probe" in
      chart-note-e2b) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BChartNoteWordings) ;;
      *) selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BChartNoteWordings) ;;
    esac
    ;;
  try-questions-e2b)
    # 体験型おすすめ質問 (1.1.0 (219)): the three try chips' questions in the
    # five app languages, asked of the real E2B on the CPU through the
    # app's own path (NATIVE_TRY_QUESTION lines, replies whole in base64).
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BTryQuestions)
    ;;
  phi-text)
    # Phi-4-mini-reasoning (1.1.0 (205)) on the CPU a new chat starts it
    # on: a Japanese word problem; it thinks first and only the answer shows.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testPhiReasoningAnswersAJapaneseWordProblem)
    ;;
  cpu-compare)
    # The phone's CPU answered with E2B but not with Qwen3.5 4B (205): the
    # same question on Qwen3 0.6B (block-32 4-bit like the new models), E2B
    # and Qwen3.5, with CPU time and pages read, against the official
    # macOS build on the same runner (arm-new-models.yml).
    process_limit=1800; test_limit=1700
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUCompareQwen3
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUCompareE2B
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUCompareQwen35)
    ;;
  gpu-new-models)
    # Qwen3.5 4B and Phi-4-mini-reasoning on the GPU (Metal), one question
    # each in one process: the stream, its times and memory.
    process_limit=1800; test_limit=1700
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testGPUQwen35RawStream
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testGPUPhiRawStream)
    ;;
  memory-new-models)
    # Qwen3.5 4B and Phi-4-mini-reasoning on the CPU with their weights
    # packed in the process's memory (cache ":memory"), not a mapped file.
    process_limit=1800; test_limit=1700
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testMemoryQwen35RawStream
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testMemoryPhiRawStream)
    ;;
  lock-new-models)
    # The same question with the app's fix (1.1.0 (206)): the CPU engine's
    # mapped weight cache file, locked in memory (WeightCacheLock).
    process_limit=1800; test_limit=1700
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testLockedQwen35RawStream
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testLockedPhiRawStream)
    ;;
  qwen35-trace|phi-trace)
    # 1.1.0 (205) on the phone showed only 「考えています…」 for both new
    # models: the runtime's own stream for one question, chunk by chunk,
    # on the app's CPU engine and on one with 32-bit activations.
    process_limit=1800; test_limit=1700
    if [ "$probe" = qwen35-trace ]; then
      selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwen35RawStream)
    else
      selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testPhiRawStream)
    fi
    ;;
  qwen35-text)
    # Qwen3.5 4B (1.1.0 (205)) on the CPU: the Japanese chat with history,
    # Markdown, math, code and a thinking turn; then a later conversation on
    # the same engine against a fresh engine's, greedy.
    process_limit=1800; test_limit=900
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwen35JapaneseChatAndRichReplies
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwen35LaterConversationsStartClean)
    ;;
  qwen35-thinking)
    # Qwen3.5 4B with thinking on in two new chats in a row (1.1.0 (206)):
    # each starts on a fresh engine and answers.
    process_limit=1800; test_limit=1000
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testQwen35ThinksInEachNewConversation)
    ;;
  gemma12b-text)
    # Gemma 4 12B (locked in the app, 1.1.0 (196)): a chat that names it is
    # refused before the runtime, then the developer 12B check's own path
    # loads the pinned file on the CPU and answers its fixed question.
    process_limit=1800; test_limit=1500
    selected_tests=(-only-testing:PocketGemmaNativeTests/NativeVisionTests/testLockedModelNeverRunsInAChat
                    -only-testing:PocketGemmaNativeTests/NativeVisionTests/testGemma12BTextProbeOnTheCPU)
    ;;
  *) echo "Unsupported explicit native probe: $probe"; exit 2 ;;
esac
echo "NATIVE_SELECTED_PROBE $probe process_limit=$process_limit test_limit=$test_limit"
# The app's words are translated since 1.1.0 (183) and these tests read its
# Japanese ones (notes, guides), so the app runs in Japanese, as the UI tests
# do. What reaches the model does not depend on the app's language.
set +e
python3 scripts/native-test-watchdog.py --timeout "$process_limit" \
  --log build/NativeVision/smoke.log --metrics build/NativeVision/smoke-activity.jsonl \
  --simulator "$simulator_id" -- \
  xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  -resultBundlePath build/NativeVision/NativeSmoke.xcresult -parallel-testing-enabled NO \
  -testLanguage ja -testRegion JP \
  -test-timeouts-enabled YES -default-test-execution-time-allowance "$test_limit" \
  -maximum-test-execution-time-allowance "$test_limit" \
  "${selected_tests[@]}" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
smoke_exit=$?
set -e
tail -100 build/NativeVision/smoke.log
grep -aE 'NATIVE_(LANG|WEB_SEARCH|SEARCH_FOCUS[A-Z_]*|SEARCH_LIVE[A-Z_]*|SEARCH_RECORDED[A-Z_]*|CHART_|MODEL_REPLY|FILE_EXCERPT|EXCERPT|PHOTO_TEXT|ADDRESS|TAG_ECHO|CONTINUING|SAMPLING|MEMORY|QWEN_START|QWEN_MEMORY|GPU_TEST|E4B_CHAT|E4B_DEEP|E4B_FAST|FEATURE_[A-Z]+|LONG_LANG[A-Z_]*|TRY_QUESTION[A-Z_]*)' build/NativeVision/smoke.log || true
# Assertion messages usually sit above the tail; print them on their own.
grep -aE ': error: |^Test Case .*(passed|failed|skipped)' build/NativeVision/smoke.log | head -80 || true
grep -aE 'NATIVE_(VIDEO|AUDIO)' build/NativeVision/smoke.log || true
grep -aE 'NATIVE_12B' build/NativeVision/smoke.log || true
save_crash_reports
if [[ -d build/NativeVision/NativeSmoke.xcresult ]]; then
  xcrun xcresulttool get test-results summary --path build/NativeVision/NativeSmoke.xcresult \
    > build/NativeVision/smoke-summary.json || true
fi
if [[ -s build/NativeVision/smoke-summary.json ]]; then
  python3 - build/NativeVision/smoke-summary.json <<'SUMMARY' || true
import json, sys
for failure in json.load(open(sys.argv[1])).get('testFailures', []):
    name = failure.get('testIdentifierString') or failure.get('testName', '')
    print('NATIVE_FAILURE', name, '-', ' '.join(str(failure.get('failureText', '')).split())[:600])
SUMMARY
fi
if [[ "$smoke_exit" -ne 0 ]]; then
  if [[ -s build/NativeVision/smoke-summary.json ]]; then
    cp build/NativeVision/smoke-summary.json build/NativeVision/summary.json
  fi
  echo "Selected probe $probe failed or timed out ($smoke_exit). Evidence retained; no full suite or automatic retry."
  exit "$smoke_exit"
fi
if [[ "${NATIVE_SMOKE_ONLY:-0}" == 1 ]]; then
  cp build/NativeVision/smoke-summary.json build/NativeVision/summary.json
  echo "Bounded explicit SDK probe passed ($probe). Full image suite was not run."
  exit 0
fi
set +e
python3 scripts/native-test-watchdog.py --timeout 1200 \
  --log build/NativeVision/tests.log --metrics build/NativeVision/test-activity.jsonl \
  --simulator "$simulator_id" -- \
  xcodebuild -project PocketGemma.xcodeproj -scheme NativeVision \
  -destination "platform=iOS Simulator,id=$simulator_id" -derivedDataPath build/NativeDerived \
  -resultBundlePath build/NativeVision/NativeVision.xcresult -parallel-testing-enabled NO \
  -testLanguage ja -testRegion JP \
  -test-timeouts-enabled YES -default-test-execution-time-allowance 180 \
  -maximum-test-execution-time-allowance 600 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testProductionConfigurationMatrix4096 \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testPhotoImportSniffsExtensionlessAndGenericData \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBundledJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBundledJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BDirectBuiltinJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BDirectBuiltinJPEGs \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testBuiltinVisionRecoverySwitchAndMemoryPlateau \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BIsolatedCPUComponents \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BIsolatedCPUComponents \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testNativeLogCaptureRestoresStderrAndRecordsOnlyOperationalErrors \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE2BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BProductionCPUImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUModelSwitchImagesAndText \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testCPUBadImageErrorThenGoodImage \
  -only-testing:PocketGemmaNativeTests/NativeVisionTests/testE4BCPUBadImageErrorThenGoodImage \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO test-without-building
test_exit=$?
set -e
if [[ -d build/NativeVision/NativeVision.xcresult ]]; then
  xcrun xcresulttool get test-results summary --path build/NativeVision/NativeVision.xcresult \
    > build/NativeVision/image-summary.json || true
fi
# Preserve the real XCTest failure before any diagnostic-export assertion.
tail -150 build/NativeVision/tests.log
save_crash_reports
python3 - <<'PY'
from pathlib import Path
import json
root=Path('build/NativeVision')
if (root/'image-summary.json').is_file() and (root/'image-summary.json').stat().st_size:
    image=json.loads((root/'image-summary.json').read_text())
    smoke=json.loads((root/'smoke-summary.json').read_text())
    summary=dict(image)
    for key in ['passedTests','failedTests','skippedTests','totalTestCount']:
        summary[key]=image[key]+smoke[key]
    summary['result']='Passed' if image['result']=='Passed' and smoke['result']=='Passed' else 'Failed'
    summary['phaseSummaries']=['smoke-summary.json','image-summary.json']
    (root/'summary.json').write_text(json.dumps(summary,indent=2))
PY
if [[ "$test_exit" -ne 0 ]]; then
  echo "Image suite failed or hit its 20-minute wall limit ($test_exit); logs and activity retained."
  exit "$test_exit"
fi
python3 - <<'PY'
import base64, json, re
from pathlib import Path
root = Path('build/NativeVision')
log = (root / 'tests.log').read_text(errors='replace')
for marker, filename in [('MATRIX', 'configuration-matrix.json'), ('HISTORY', 'inference-comparisons.json')]:
    matches = re.findall(r'NATIVE_' + marker + r'_JSON ([A-Za-z0-9+/=]+)', log)
    if not matches:
        raise SystemExit('Missing native diagnostic export: ' + marker)
    data = base64.b64decode(matches[-1], validate=True)
    assert len(data) < 768000 and isinstance(json.loads(data), list)
    (root / filename).write_bytes(data)
probes = [json.loads(base64.b64decode(item, validate=True)) for item in
          re.findall(r'NATIVE_PROBE_JSON ([A-Za-z0-9+/=]+)', log)]
assert probes, 'Missing direct/component diagnostic exports'
(root / 'isolated-probes.json').write_text(json.dumps(probes, indent=2))
stability = re.findall(r'NATIVE_STABILITY_JSON ([A-Za-z0-9+/=]+)', log)
assert stability, 'Missing repeated-inference memory evidence'
(root / 'memory-stability.json').write_bytes(base64.b64decode(stability[-1], validate=True))
PY
exit "$test_exit"
