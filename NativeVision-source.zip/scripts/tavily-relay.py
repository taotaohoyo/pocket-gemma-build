#!/usr/bin/env python3
"""The live search probes' way to Tavily (1.1.0 (211)).

    tavily-relay.py LOG          serve http://127.0.0.1:8765 until stopped
    tavily-relay.py --print LOG  print what was searched and found

The simulator's test sends the app's own search request here, with a
stand-in key; this process sends the same body on to Tavily's search API
with the key from TAVILY_API_KEY, which only it has. It listens on the
loopback address only. The log keeps each search's options and results
(titles, addresses, dates, the start of each text), never the key or the
request's headers.
"""
import http.server
import json
import os
import sys
import time
import urllib.error
import urllib.request

ENDPOINT = 'https://api.tavily.com/search'
PORT = 8765
OPTIONS = ('query', 'search_depth', 'topic', 'max_results', 'time_range', 'exact_match', 'include_published_date')


def serve(log_path):
    key = os.environ.get('TAVILY_API_KEY', '')
    if not key:
        sys.exit('TAVILY_API_KEY is not set')

    class Relay(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.answer(200 if self.path == '/health' else 404, b'ok')

        def do_POST(self):
            if self.path != '/search':
                return self.answer(404, b'')
            body = self.rfile.read(int(self.headers.get('Content-Length') or 0))
            try:
                asked = json.loads(body)
            except ValueError:
                return self.answer(400, b'{}')
            began = time.time()
            request = urllib.request.Request(ENDPOINT, data=body, method='POST', headers={
                'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key})
            try:
                with urllib.request.urlopen(request, timeout=20) as response:
                    status, data = response.status, response.read()
            except urllib.error.HTTPError as error:
                status, data = error.code, error.read()
            except Exception as error:  # noqa: BLE001 - the probe sees a 502
                status, data = 502, json.dumps({'error': type(error).__name__}).encode()
            entry = {'time': round(began, 3), 'seconds': round(time.time() - began, 2), 'status': status,
                     'asked': {name: asked[name] for name in OPTIONS if name in asked}}
            try:
                results = json.loads(data).get('results', [])
                entry['results'] = [{'title': item.get('title'), 'url': item.get('url'),
                                     'date': item.get('published_date'), 'score': item.get('score'),
                                     'text': (item.get('content') or '')[:240]} for item in results]
            except (ValueError, AttributeError):
                entry['results'] = []
            with open(log_path, 'a', encoding='utf-8') as log:
                log.write(json.dumps(entry, ensure_ascii=False) + '\n')
            self.answer(status, data)

        def answer(self, status, data):
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *_):
            pass

    http.server.ThreadingHTTPServer(('127.0.0.1', PORT), Relay).serve_forever()


def show(log_path):
    if not os.path.exists(log_path):
        print('TAVILY_LIVE none')
        return
    with open(log_path, encoding='utf-8') as log:
        for line in log:
            entry = json.loads(line)
            print('TAVILY_LIVE', json.dumps({name: entry[name] for name in ('status', 'seconds', 'asked')}, ensure_ascii=False))
            for index, item in enumerate(entry.get('results', [])):
                print('TAVILY_LIVE_RESULT', index, item.get('date') or '-', item.get('url'), '|', (item.get('title') or '')[:90])
                print('TAVILY_LIVE_TEXT', index, ' '.join((item.get('text') or '').split())[:240])


if __name__ == '__main__':
    if sys.argv[1:2] == ['--print']:
        show(sys.argv[2])
    else:
        serve(sys.argv[1])
