"""Download public pinned test weights. Never include them in source/artifacts.

NATIVE_MODELS picks the files (comma separated, default E2B,E4B), so a probe
downloads only the models its tests load."""
from pathlib import Path
import urllib.request, hashlib, os, sys
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
pinned = {
    'E2B': ('litert-community/gemma-4-E2B-it-litert-lm', 'b3ca0d2f076785a8f4b2219ddbd2bdb99954eae1', 'gemma-4-E2B-it.litertlm',
            2588147712, '181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c'),
    'E4B': ('litert-community/gemma-4-E4B-it-litert-lm', '28299f30ee4d43294517a4ac93abd6163412f07f', 'gemma-4-E4B-it.litertlm',
            3659530240, '0b2a8980ce155fd97673d8e820b4d29d9c7d99b8fa6806f425d969b145bd52e0'),
    'QWEN3': ('litert-community/Qwen3-0.6B', 'a3c5d805ae362dff7f580bc25f2dfb9a5a7eaa76', 'Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm',
              344671744, '03e7da1eb1108b50dffaa9bb52cc7bcbad2eb0c66ca990267f480c1e545d2856'),
    'QWEN25': ('litert-community/Qwen2.5-1.5B-Instruct', '5e6e7a58d03777898b31330a15d2e0a5a9107de3',
               'Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm',
               1597922856, 'c4a9b7289365ab80fe599b844b77ad253eb3c53fb0e5d963d699146a6f01255e'),
}
names = [n.strip().upper() for n in os.environ.get('NATIVE_MODELS', 'E2B,E4B').split(',') if n.strip()]
assert names and all(n in pinned for n in names), f'Unknown pinned model in {names}'
for name in names:
    repo, rev, file, size, digest = pinned[name]; sha = hashlib.sha256()
    url = f'https://huggingface.co/{repo}/resolve/{rev}/{file}?download=true'
    print('Downloading', name, flush=True)
    with urllib.request.urlopen(url, timeout=180) as response, (out/file).open('wb') as target:
        while chunk := response.read(8*1024*1024): target.write(chunk); sha.update(chunk)
    assert (out/file).stat().st_size == size and sha.hexdigest() == digest, 'Pinned model integrity mismatch'
    print('Verified', name, digest, flush=True)
