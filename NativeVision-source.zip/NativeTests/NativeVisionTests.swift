import XCTest
import UIKit
import Metal
import Darwin
import LiteRTLM
import PocketCore
import VisionRuntimeBridge
@testable import PocketGemma

actor ProbeReply {
    var text = ""
    var seams: [Int] = []
    func append(_ chunk: String) { text += chunk }
    func value() -> String { text.lowercased() }
    func markSeam() { seams.append(text.count) }
}

final class NativeVisionTests: XCTestCase {
    override func setUpWithError() throws {
        executionTimeAllowance = 180
        try AppFiles.prepareModels()
        let fixtures = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("NativeModels")
        for spec in [ModelSpec.e2b, .e4b] where !AppFiles.hasVerifiedModel(spec) {
            let source = fixtures.appendingPathComponent(spec.fileName)
            guard FileManager.default.fileExists(atPath: source.path) else {
                throw XCTSkip("Real pinned model fixture missing; never substitute mock inference.")
            }
            let pending = AppFiles.pendingModel(spec)
            if FileManager.default.fileExists(atPath: pending.path) { try FileManager.default.removeItem(at: pending) }
            try FileManager.default.moveItem(at: source, to: pending)
            try ModelValidator.validate(pending, spec: spec)
            try AppFiles.installVerifiedModel(spec)
        }
        print("NATIVE_ENV iOS=\(UIDevice.current.systemVersion) physicalMemory=\(ProcessInfo.processInfo.physicalMemory) Metal=\(MTLCreateSystemDefaultDevice()?.name ?? "unavailable") SDK=0.18.0")
    }

    func fixture(circle: Bool = false) async throws -> ChatAttachment {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
        let image = UIGraphicsImageRenderer(size: CGSize(width: 512, height: 512)).image { ctx in
            UIColor.white.setFill(); ctx.fill(CGRect(x: 0, y: 0, width: 512, height: 512))
            (circle ? UIColor.green : UIColor.red).setFill()
            let bounds = CGRect(x: 96, y: 96, width: 320, height: 320)
            if circle { ctx.cgContext.fillEllipse(in: bounds) } else { ctx.fill(bounds) }
        }
        try XCTUnwrap(image.jpegData(compressionQuality: 0.85)).write(to: url)
        // Exercise the production EXIF/resize/JPEG import, not an alternate codec.
        return try await AttachmentStorage.importFile(url)
    }

    func testPhotoImportSniffsExtensionlessAndGenericData() async throws {
        let image = try await fixture()
        let normalized = try XCTUnwrap(AttachmentStorage.url(try XCTUnwrap(image.imageNames.first)))
        let data = try Data(contentsOf: normalized)
        for suffix in ["", ".data", ".bin"] {
            let source = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + suffix)
            try data.write(to: source)
            let imported = try await AttachmentStorage.importFile(source)
            XCTAssertEqual(imported.kind, .image)
            XCTAssertEqual(imported.imageNames.count, 1)
            let jpeg = try XCTUnwrap(AttachmentStorage.url(try XCTUnwrap(imported.imageNames.first)))
            XCTAssertNotNil(UIImage(contentsOfFile: jpeg.path), "Import must produce a decodable image, not just an image label")
            AttachmentStorage.remove(imported)
            try FileManager.default.removeItem(at: source)
        }
        AttachmentStorage.remove(image)
    }

    // Run before any image work: detect duplicate C++ registries/ABI mixing
    // in a newly linked runtime with the smallest real CPU text request.
    func testA0PatchedRuntimeTextSmoke() async throws {
        executionTimeAllowance = 120
        // Leave stderr attached to XCTest for this first SDK-only probe. A
        // native CHECK/abort must remain visible even if Swift never unwinds.
        ExperimentalFlags.optIntoExperimentalAPIs()
        ExperimentalFlags.visualTokenBudget = nil
        ExperimentalFlags.enableSpeculativeDecoding = false
        let cache = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        let engine = Engine(engineConfig: try EngineConfig(modelPath: AppFiles.model(.e2b).path,
            backend: .cpu(), maxNumTokens: 4096, cacheDir: cache.path))
        print("NATIVE_BARE_SMOKE before_initialize")
        fflush(stdout)
        try await engine.initialize()
        print("NATIVE_BARE_SMOKE initialized")
        let conversation = try await engine.createConversation(with: ConversationConfig(
            samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, enableSpeculativeDecoding: false))
        var reply = ""
        for try await part in conversation.sendMessageStream(
            Message("What is 2 plus 3? Answer only with the number."), maxOutputTokens: 32) {
            reply += part.toString
        }
        print("NATIVE_BARE_SMOKE reply=\(reply)")
        XCTAssertTrue(reply.contains("5"), reply)
    }

    // A reply that fills its context window (2048 here, app sampling
    // defaults) is carried on to its end, and every continuation goes on
    // from the item the reply stopped at instead of going back in the list.
    // Which prefectures E2B names is its own knowledge, so coverage is only
    // printed.
    func testE2BLongReplyContinuesPastContextWindow() async throws {
        executionTimeAllowance = 720
        let result = ProbeReply()
        var settings = GenerationSettings(); settings.maxTokens = 2048; settings.backend = .cpu
        try await GemmaService().generate(threadID: UUID(),
            prompt: "日本の47都道府県すべてについて、北海道から沖縄県まで順番に、番号・都道府県名・県庁所在地・名物・代表的な観光地・30字ほどの紹介を1行ずつ書いてください。省略はしないでください。",
            history: [], model: .e2b, settings: settings, attachments: [],
            onStage: { stage in
                print("NATIVE_STAGE gemma-4-e2b \(stage)")
                if stage == .continuing { await result.markSeam() }
            }, onText: { await result.append($0) })
        let reply = await result.text, seams = Array(Set(await result.seams)).sorted()
        let stages = try XCTUnwrap(InferenceDiagnostic.load()).events.map(\.stage)
        print("NATIVE_LONG_REPLY chars=\(reply.count) bytes=\(reply.utf8.count) seams=\(seams) stages=\(stages)")
        // Numbered lines, also bold or under heading marks: where each starts,
        // its number, and which prefecture it names.
        var items: [(offset: Int, number: Int, name: String)] = [], offset = 0
        for line in reply.split(separator: "\n", omittingEmptySubsequences: false) {
            defer { offset += line.count + 1 }
            var text = line.drop(while: { $0 == " " })
            if text.hasPrefix("#") { text = text.drop(while: { $0 == "#" || $0 == " " }) }
            if text.hasPrefix("**") { text = text.dropFirst(2) }
            let digits = text.prefix(while: { $0.isASCII && $0.isNumber })
            guard let number = Int(digits), let mark = text.dropFirst(digits.count).first, ".．)".contains(mark) else { continue }
            let name = text.dropFirst(digits.count + 1).replacingOccurrences(of: "*", with: "")
                .trimmingCharacters(in: .whitespaces).prefix(while: { !"：:、,（( ".contains($0) })
            items.append((offset, number, String(name)))
        }
        var jumps: [String] = []
        for seam in seams {
            let at = reply.index(reply.startIndex, offsetBy: min(seam, reply.count))
            let around = String(reply[reply.index(at, offsetBy: -min(160, seam))..<at]) + "⟦seam⟧" + String(reply[at...].prefix(160))
            let before = items.last(where: { $0.offset < seam })?.number
            let after = items.first(where: { $0.offset >= seam })?.number
            print("NATIVE_LONG_REPLY_SEAM \(seam) before=\(before.map { "\($0)" } ?? "-") after=\(after.map { "\($0)" } ?? "-") \(around.replacingOccurrences(of: "\n", with: "⏎"))")
            if let before, let after, after != before + 1 { jumps.append("\(seam): \(before) → \(after)") }
        }
        let prefectures = ["北海道", "青森", "岩手", "宮城", "秋田", "山形", "福島", "茨城", "栃木", "群馬", "埼玉", "千葉",
            "東京", "神奈川", "新潟", "富山", "石川", "福井", "山梨", "長野", "岐阜", "静岡", "愛知", "三重", "滋賀", "京都",
            "大阪", "兵庫", "奈良", "和歌山", "鳥取", "島根", "岡山", "広島", "山口", "徳島", "香川", "愛媛", "高知", "福岡",
            "佐賀", "長崎", "熊本", "大分", "宮崎", "鹿児島", "沖縄"]
        let named = items.map { item in prefectures.first { item.name.hasPrefix($0) } ?? "?\(item.name)" }
        let missing = prefectures.filter { !named.contains($0) }
        let repeated = Set(named.filter { name in named.filter { $0 == name }.count > 1 }).sorted()
        print("NATIVE_LONG_REPLY_ITEMS numbers=\(items.map { $0.number }) names=\(named)")
        print("NATIVE_LONG_REPLY_COVERAGE missing=\(missing) repeated=\(repeated) jumps=\(jumps)")
        print("NATIVE_LONG_REPLY_TEXT \(Data(reply.utf8).base64EncodedString())")
        XCTAssertEqual(InferenceDiagnostic.load()?.result, "success")
        XCTAssertTrue(stages.contains("reply_continuation"), "\(stages)")
        XCTAssertFalse(seams.isEmpty)
        XCTAssertEqual(jumps, [], "Each continuation must go on with the next number")
    }

    func testAttachmentGatesBeforeNativeEntry() async throws {
        let image = try await fixture()
        defer { AttachmentStorage.remove(image) }
        let previousRun = InferenceDiagnostic.load()?.runID
        do {
            _ = try await production(GemmaService(), .e4b, image: image, backend: .cpu)
            XCTFail("E4B attachments must fail before entering the runtime")
        } catch is ModelAttachmentPolicy.Unavailable {} catch { XCTFail("Wrong gate error: \(error)") }
        XCTAssertEqual(InferenceDiagnostic.load()?.runID, previousRun)
        do {
            _ = try await VisionDiagnosticRunner.run(model: .e4b, kind: .squareJPEG, main: .gpu, vision: .cpu)
            XCTFail("Suspended E4B probes must not restart native vision")
        } catch is ModelAttachmentPolicy.Unavailable {} catch { XCTFail("Wrong probe gate: \(error)") }
        let source = try XCTUnwrap(AttachmentStorage.url(image.storedName))
        do {
            _ = try await AttachmentStorage.importFile(source, model: .e4b)
            XCTFail("E4B must reject import as well as sending")
        } catch is ModelAttachmentPolicy.Unavailable {} catch { XCTFail("Wrong import gate: \(error)") }
        await MainActor.run {
            let store = ChatStore(); store.newChat(modelID: ModelSpec.e4b.id)
            let original = store.messages
            XCTAssertFalse(store.send("describe", attachments: [image]))
            XCTAssertFalse(store.isGenerating)
            XCTAssertEqual(store.messages, original)
        }
    }

    func testE2BVerifiedImageAndTXTImports() async throws {
        let image = try await fixture()
        defer { AttachmentStorage.remove(image) }
        let stored = try XCTUnwrap(AttachmentStorage.url(image.storedName))
        let png = try XCTUnwrap(UIImage(contentsOfFile: stored.path)?.pngData())
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        for (name, bytes) in [("image.png", png), ("note.txt", Data("日本語の添付😊".utf8))] {
            let url = directory.appendingPathComponent(name); try bytes.write(to: url)
            let attachment = try await AttachmentStorage.importFile(url, model: .e2b)
            XCTAssertTrue(ModelAttachmentPolicy(model: .e2b).allows(attachment))
            if attachment.kind == .image {
                let jpeg = try XCTUnwrap(AttachmentStorage.url(try XCTUnwrap(attachment.imageNames.first)))
                XCTAssertNotNil(UIImage(contentsOfFile: jpeg.path))
            } else { XCTAssertEqual(attachment.extractedText, "日本語の添付😊") }
            AttachmentStorage.remove(attachment)
        }
        let unsupported = directory.appendingPathComponent("unsupported.pdf")
        try Data("%PDF-1.7".utf8).write(to: unsupported)
        do {
            _ = try await AttachmentStorage.importFile(unsupported, model: .e2b)
            XCTFail("Unverified document formats must remain unavailable")
        } catch is ModelAttachmentPolicy.Unavailable {} catch { XCTFail("Wrong format gate: \(error)") }
    }

    func testE4BTextOnlyAfterLegacyImageHistory() async throws {
        executionTimeAllowance = 240
        let image = ChatAttachment(kind: .image, name: "old.jpg", storedName: "old.jpg", imageNames: ["must-not-read.jpg"])
        let history = [ChatMessage(role: .user, text: "以前の画像", attachments: [image]),
                       ChatMessage(role: .assistant, text: "以前の会話です。")]
        let answer = try await production(GemmaService(), .e4b, image: nil, backend: .cpu,
            history: history, text: "What is 2 plus 3? Answer only with the number.")
        XCTAssertTrue(answer.contains("5"), answer)
        let record = try XCTUnwrap(InferenceDiagnostic.load())
        XCTAssertEqual(record.imageCount, 0); XCTAssertNil(record.visionBackend)
        XCTAssertEqual(record.result, "success")
        XCTAssertEqual(history[0].media, [image], "Archive content must remain intact")
    }

    // Real replies to chart requests with the app's own settings and format
    // note, printed whole so the renderer can be checked against them.
    func testChartRepliesFromRealModels() async throws {
        executionTimeAllowance = 1200
        let cases: [(ModelSpec, String, String)] = [
            (.e2b, "natural", "1月から4月の月別売上高（1月120万円、2月180万円、3月150万円、4月230万円）をグラフにしてください。"),
            (.e2b, "explicit", "次のデータをchart形式で表示してください。1月120、2月180、3月150、4月230（単位は万円）"),
            (.e2b, "pie", "一日の時間の使い方を円グラフにして。睡眠8時間、仕事8時間、家事2時間、自由時間6時間です。"),
            (.e4b, "natural", "1月から4月の月別売上高（1月120万円、2月180万円、3月150万円、4月230万円）をグラフにしてください。"),
            (.e4b, "explicit", "次のデータをchart形式で表示してください。1月120、2月180、3月150、4月230（単位は万円）"),
        ]
        for (spec, name, prompt) in cases {
            let result = ProbeReply()
            var settings = GenerationSettings(); settings.backend = .cpu
            let start = Date()
            try await GemmaService().generate(threadID: UUID(), prompt: prompt, history: [], model: spec,
                settings: settings, attachments: [],
                onStage: { print("NATIVE_STAGE \(spec.id) \($0)") }, onText: { await result.append($0) })
            let reply = await result.text
            let kinds = MarkdownDocument(reply).blocks.map { block -> String in
                switch block {
                case .code(let language, _): return "code(\(language ?? "-"))"
                case .rich(let rich): return "rich(\(rich))".prefix(80).description
                case .paragraph: return "paragraph"
                default: return "\(block)".prefix(24).description
                }
            }
            print("NATIVE_CHART_CASE \(spec.id) \(name) seconds=\(Int(Date().timeIntervalSince(start))) chars=\(reply.count) blocks=\(kinds)")
            print("NATIVE_CHART_REPLY \(spec.id) \(name) \(Data(reply.utf8).base64EncodedString())")
            fflush(stdout)
            XCTAssertFalse(reply.isEmpty)
        }
    }

    func production(_ service: GemmaService, _ spec: ModelSpec, image: ChatAttachment?,
                    budget: Int = 280, backend: ExecutionBackend = .gpu, visionBackend: ExecutionBackend = .cpu, thread: UUID = UUID(), history: [ChatMessage] = [],
                    text: String = "Describe the main shape and its color in English with one short sentence.",
                    kernel: VisionCPUImplementation = .xnnpack) async throws -> String {
        let result = ProbeReply()
        var settings = GenerationSettings(); settings.maxTokens = 4096
        settings.maxOutputTokens = 128; settings.topK = 1; settings.topP = 1
        settings.temperature = 0; settings.visualTokenBudget = budget; settings.backend = backend
        settings.visionBackend = visionBackend
        settings.visionCPUImplementation = kernel
        try await service.generate(threadID: thread, prompt: text, history: history, model: spec,
            settings: settings, attachments: image.map { [$0] } ?? [],
            onStage: { print("NATIVE_STAGE \(spec.id) \($0)") },
            onText: { await result.append($0) })
        let reply = await result.value()
        print("NATIVE_REPLY \(spec.id) \(reply)")
        XCTAssertFalse(reply.isEmpty)
        return reply
    }

    // GPU failures in this virtual Metal device are recorded as blocked tests,
    // never as successful image recognition or evidence of a phone vision bug.
    func testProductionConfigurationMatrix4096() async throws {
        executionTimeAllowance = 360
        let image = try await fixture()
        var records: [InferenceDiagnostic] = []
        for spec in [ModelSpec.e2b, .e4b] {
            for (main, vision) in [(ExecutionBackend.gpu, ExecutionBackend.gpu), (.gpu, .cpu), (.cpu, .cpu)] {
                let service = GemmaService()
                do {
                    let reply = try await production(service, spec, image: image, backend: main, visionBackend: vision)
                    XCTAssertTrue(reply.contains("red") && (reply.contains("square") || reply.contains("rectangle")), reply)
                    XCTAssertEqual(InferenceDiagnostic.load()?.result, "success")
                } catch {
                    let record = try XCTUnwrap(InferenceDiagnostic.load())
                    let native = (record.nativeLogLines ?? []).joined(separator: "\n")
                    XCTAssertEqual(main, .gpu, "CPU/CPU must perform real vision inference")
                    XCTAssertEqual(record.stage, "engine_initialization", "Only the previously measured simulator main-GPU limitation may block this probe")
                    XCTAssertTrue(native.contains("texture binding has argument index") || native.contains("delegate_metal.mm:"), "Unexpected native failure: \(error)\n\(native)")
                    print("NATIVE_SIMULATOR_BLOCKED \(spec.id) \(main)/\(vision) stage=\(record.stage)")
                }
                let record = try XCTUnwrap(InferenceDiagnostic.load())
                XCTAssertEqual(record.modelSHA256, spec.sha256)
                XCTAssertEqual(record.contextTokens, 4096); XCTAssertEqual(record.visionTokens, 280)
                XCTAssertEqual(record.mainBackend, main.rawValue); XCTAssertEqual(record.visionBackend, vision.rawValue)
                XCTAssertNotNil(record.runtimeBuild, "Native binary receipt must be available in diagnostic exports")
                XCTAssertFalse(record.conversationWasReused ?? false)
                records.append(record)
                await service.unload()
            }
        }
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        let destination = AppFiles.root.appendingPathComponent("native-configuration-matrix.json")
        let matrixData = try encoder.encode(records)
        try matrixData.write(to: destination)
        // XCTest may run a cloned simulator container. Export synthetic-only
        // diagnostic evidence via stdout as well as the production local file.
        print("NATIVE_MATRIX_JSON \(matrixData.base64EncodedString())")
        print("NATIVE_HISTORY_JSON \(try encoder.encode(InferenceDiagnostic.history()).base64EncodedString())")
        XCTAssertEqual(records.filter { $0.result == "success" && $0.mainBackend == "CPU" }.count, 2)
    }

    func testNativeLogCaptureRestoresStderrAndRecordsOnlyOperationalErrors() throws {
        let capture = try XCTUnwrap(NativeLogCapture())
        let bytes = "ERROR: XNNPack delegate failed to reshape runtime\nNode number 1480 (TfLiteXNNPackDelegate) failed to prepare.\nPrivate synthetic unrelated text\n"
        bytes.withCString { pointer in _ = write(STDERR_FILENO, pointer, strlen(pointer)) }
        let first = capture.finish()
        XCTAssertEqual(first.lines.count, 2); XCTAssertEqual(first.discardedLines, 1)
        XCTAssertEqual(NativeLogEvidence(error: "", logLines: first.lines).failedDelegate, "XNNPACK")
        let another = try XCTUnwrap(NativeLogCapture(), "stderr reservation must be released after an error")
        XCTAssertTrue(another.finish().lines.isEmpty)
    }

    func testE2BDirectBundledJPEGs() async throws { try await directJPEGs(.e2b) }
    func testE4BDirectBundledJPEGs() async throws { try await directJPEGs(.e4b) }
    func testE2BDirectBuiltinJPEGs() async throws { try await directJPEGs(.e2b, kernel: .builtin) }
    func testE4BDirectBuiltinJPEGs() async throws { try await directJPEGs(.e4b, kernel: .builtin) }
    // Each fixture has its own deadline. Two valid E4B replies previously
    // exceeded the single combined case's limit; do not hide that failure.
    func testE2BSquareJPEG() async throws { try await directJPEGs(.e2b, kinds: [.squareJPEG]) }
    func testE2BPortraitJPEG() async throws { try await directJPEGs(.e2b, kinds: [.portraitJPEG]) }
    func testE4BSquareJPEG() async throws { try await directJPEGs(.e4b, kinds: [.squareJPEG]) }
    func testE4BPortraitJPEG() async throws { try await directJPEGs(.e4b, kinds: [.portraitJPEG]) }
    private func directJPEGs(_ spec: ModelSpec, kernel: VisionCPUImplementation = .xnnpack,
                             kinds: [VisionProbeKind] = [.squareJPEG, .portraitJPEG]) async throws {
        executionTimeAllowance = 240
        for kind in kinds {
            let reply: String
            do { reply = try await VisionDiagnosticRunner.run(model: spec, kind: kind, main: .cpu, vision: .cpu, kernel: kernel) }
            catch { exportProbe(); throw error }
            exportProbe()
            XCTAssertTrue(reply.lowercased().contains("red")); XCTAssertTrue(reply.lowercased().contains("square"))
            let record = try XCTUnwrap(InferenceDiagnostic.load())
            XCTAssertEqual(record.inputPath, "bundled_jpeg_direct_sdk")
            XCTAssertEqual(record.contextTokens, 4096); XCTAssertEqual(record.visionTokens, 280)
            XCTAssertEqual(record.modelSHA256, spec.sha256); XCTAssertEqual(record.result, "success")
            XCTAssertEqual(record.visionCPUImplementation, kernel.rawValue)
            XCTAssertEqual(record.runtimeBuild?.nativeBuild?.buildID, "0.18.0-pg4")
            let native = (record.nativeLogLines ?? []).joined(separator: "\n")
            // absl streams bool as true/false; other native loggers may use
            // 1/0. Preserve the same required values in either representation.
            let readiness = native.replacingOccurrences(of: "=true", with: "=1")
                .replacingOccurrences(of: "=false", with: "=0")
            XCTAssertTrue(readiness.contains("embeddings_initialized text_lookup=1 ple_lookup=1"), native)
            XCTAssertTrue(native.contains("embeddings_ready_before_llm_compile"), native)
            XCTAssertTrue(readiness.contains("llm_vision_prefill text_lookup=1 ple_lookup=1 requires_ple=1"), native)
            XCTAssertTrue(native.contains("PG_COMPONENT vision_resources=engine_pool"), native)
            XCTAssertTrue(native.contains("PG_VISION_OK component=vision_encoder"), native)
            XCTAssertTrue(native.contains("PG_VISION_OK component=vision_adapter"), native)
            XCTAssertFalse(native.contains("PG_VISION_FAILURE"), native)
            XCTAssertTrue(native.contains(kernel == .builtin ? "vision_cpu_kernel=builtin_no_xnnpack" : "vision_cpu_kernel=delegate_xnnpack"), native)
            XCTAssertGreaterThan(record.sampledPeakVirtualSize ?? 0, 0)
        }
    }
    func testE2BIsolatedCPUComponents() async throws { try await isolatedComponents(.e2b) }
    func testE4BIsolatedCPUComponents() async throws { try await isolatedComponents(.e4b) }
    private func isolatedComponents(_ spec: ModelSpec) async throws {
        executionTimeAllowance = 300
        for kind in [VisionProbeKind.encoderDelegate, .encoderBuiltin, .adapterDelegate, .adapterBuiltin] {
            do {
                let description = try await VisionDiagnosticRunner.run(model: spec, kind: kind, main: .cpu, vision: .cpu)
                print("NATIVE_COMPONENT_RESULT \(spec.id) \(kind.rawValue) \(description)")
                exportProbe()
                let record = try XCTUnwrap(InferenceDiagnostic.load())
                XCTAssertEqual(record.result, "success")
                XCTAssertEqual(record.outputFinite, true)
                XCTAssertEqual(record.inputPath, "isolated_component_synthetic_tensors")
                XCTAssertEqual(record.testedComponent, kind.isEncoder ? "vision_encoder" : "vision_adapter")
                XCTAssertEqual(record.modelSHA256, spec.sha256)
            } catch {
                exportProbe()
                XCTFail("\(spec.id) \(kind.rawValue) failed: \(error.localizedDescription)")
            }
        }
    }
    private func exportProbe() {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        if let record = InferenceDiagnostic.load(), let data = try? encoder.encode(record) {
            print("NATIVE_PROBE_JSON \(data.base64EncodedString())")
        }
    }

    func testE2BProductionImage() async throws { try await productionImage(.e2b) }
    func testE4BProductionImage() async throws { try await productionImage(.e4b) }
    func testE2BProductionCPUImage() async throws { try await productionImage(.e2b, backend: .cpu) }
    func testE4BProductionCPUImage() async throws { try await productionImage(.e4b, backend: .cpu) }
    func productionImage(_ spec: ModelSpec, backend: ExecutionBackend = .gpu) async throws {
        let service = GemmaService(), image = try await fixture()
        let reply = try await production(service, spec, image: image, backend: backend)
        XCTAssertTrue(reply.contains("red") && (reply.contains("square") || reply.contains("rectangle")), reply)
        let text = try await production(service, spec, image: nil, backend: backend, text: "What is 2 plus 3? Answer only with the number.")
        XCTAssertTrue(text.contains("5"), text)
        await service.unload()
    }
    func testE2BProductionBudget70() async throws { try await budget70(.e2b) }
    func testE4BProductionBudget70() async throws { try await budget70(.e4b) }
    func budget70(_ spec: ModelSpec) async throws {
        let service = GemmaService(), image = try await fixture()
        let reply = try await production(service, spec, image: image, budget: 70)
        XCTAssertTrue(reply.contains("red"), reply)
        await service.unload()
    }
    func testE2BNativeCPUEncoder() async throws { try await cpuEncoder(.e2b) }
    func testE4BNativeCPUEncoder() async throws { try await cpuEncoder(.e4b) }
    func testE2BNativeCPUEncoder280() async throws { try await cpuEncoder(.e2b, budget: 280) }
    func testE4BNativeCPUEncoder280() async throws { try await cpuEncoder(.e4b, budget: 280) }
    func testE2BNativeGPUEncoder70() async throws { try await cpuEncoder(.e2b, vision: .gpu) }
    func testE4BNativeGPUEncoder70() async throws { try await cpuEncoder(.e4b, vision: .gpu) }
    func testE2BNativeGPUEncoderFloat32() async throws { try await cpuEncoder(.e2b, vision: .gpu, precision: .float32) }
    func testE4BNativeGPUEncoderFloat32() async throws { try await cpuEncoder(.e4b, vision: .gpu, precision: .float32) }
    func testE2BAllCPU70() async throws { try await cpuEncoder(.e2b, main: .cpu(threadCount: 3)) }
    func testE4BAllCPU70() async throws { try await cpuEncoder(.e4b, main: .cpu(threadCount: 3)) }
    func testE2BAllCPU280() async throws { try await cpuEncoder(.e2b, budget: 280, main: .cpu(threadCount: 3)) }
    func testE4BAllCPU280() async throws { try await cpuEncoder(.e4b, budget: 280, main: .cpu(threadCount: 3)) }
    func testE2BMainCPUVisionGPU70() async throws { try await cpuEncoder(.e2b, vision: .gpu, main: .cpu(threadCount: 3)) }
    func testE4BMainCPUVisionGPU70() async throws { try await cpuEncoder(.e4b, vision: .gpu, main: .cpu(threadCount: 3)) }
    func cpuEncoder(_ spec: ModelSpec, budget: Int32 = 70, vision: Backend = .cpu(threadCount: 3),
                    precision: ActivationDataType? = nil, main: Backend = .gpu) async throws {
        let image = try await fixture()
        ExperimentalFlags.optIntoExperimentalAPIs(); ExperimentalFlags.visualTokenBudget = budget
        defer { ExperimentalFlags.visualTokenBudget = nil }
        let cache = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true)
        let engine = Engine(engineConfig: try EngineConfig(modelPath: AppFiles.model(spec).path,
            backend: main, visionBackend: vision, maxNumTokens: 2048, cacheDir: cache.path, activationDataType: precision))
        print("NATIVE_ENCODER_STAGE initialize \(spec.id) main=\(main) vision=\(vision) budget=\(budget) precision=\(String(describing: precision))")
        try await engine.initialize()
        let chat = try await engine.createConversation(with: ConversationConfig(
            samplerConfig: try SamplerConfig(topK: 1, topP: 1, temperature: 0),
            thinkingConfig: ThinkingConfig(enableThinking: false, thinkingTokenBudget: 0),
            automaticToolCalling: false, visualTokenBudget: budget, enableSpeculativeDecoding: false))
        print("NATIVE_ENCODER_STAGE image \(spec.id)")
        var reply = ""
        for try await part in chat.sendMessageStream(Message(contents: [
            .imageFile(try XCTUnwrap(AttachmentStorage.url(image.imageNames[0])).path),
            .text("Describe the main shape and its color in English with one short sentence.")]), maxOutputTokens: 128) {
            reply += part.toString
        }
        print("NATIVE_ENCODER_REPLY \(spec.id) \(reply)")
        XCTAssertTrue(reply.lowercased().contains("red"), reply)
    }

    func testModelSwitchImagesAndText() async throws {
        try await modelSwitch(backend: .gpu)
    }
    func testCPUModelSwitchImagesAndText() async throws {
        try await modelSwitch(backend: .cpu)
    }
    func modelSwitch(backend: ExecutionBackend) async throws {
        executionTimeAllowance = 360
        let service = GemmaService(), image = try await fixture()
        for spec in [ModelSpec.e2b, .e4b, .e2b] {
            let text = try await production(service, spec, image: nil, backend: backend, text: "What is 4 plus 4? Answer only with the number.")
            XCTAssertTrue(text.contains("8"), text)
            let reply = try await production(service, spec, image: image, backend: backend)
            XCTAssertTrue(reply.contains("red"), reply)
        }
        await service.unload()
    }

    func testBadImageErrorThenGoodImage() async throws {
        try await recovery(backend: .gpu)
    }
    func testCPUBadImageErrorThenGoodImage() async throws {
        try await recovery(backend: .cpu)
    }
    func testE4BCPUBadImageErrorThenGoodImage() async throws {
        try await recovery(.e4b, backend: .cpu)
    }
    func testBuiltinVisionRecoverySwitchAndMemoryPlateau() async throws {
        executionTimeAllowance = 600
        let service = GemmaService()
        let red = try await fixture(), green = try await fixture(circle: true)
        var records: [[String: String]] = []
        // Three passes per model use the same engine and fresh conversations.
        // Alternating unseen pixel content prevents a constant "red square"
        // response from passing as image recognition.
        for spec in [ModelSpec.e2b, .e4b] {
            var footprints: [UInt64] = []
            var virtualSizes: [UInt64] = []
            for index in 0..<3 {
                let circle = index % 2 == 1
                let reply = try await production(service, spec, image: circle ? green : red,
                    backend: .cpu, kernel: .builtin)
                XCTAssertTrue(reply.contains(circle ? "green" : "red"), reply)
                XCTAssertTrue((circle ? (reply.contains("circle") || reply.contains("circular") || reply.contains("round")) : (reply.contains("square") || reply.contains("rectangle"))), reply)
                footprints.append(PGProcessMemoryFootprint()); virtualSizes.append(PGProcessVirtualSize())
                records.append(["model": spec.id, "iteration": String(index), "footprint": String(footprints.last!),
                    "virtualSize": String(virtualSizes.last!), "kernel": "builtin", "reply": reply])
            }
            // Allow the allocator to retain scratch buffers; reject large
            // continuing growth after warmup. This is a simulator bound only.
            XCTAssertLessThanOrEqual(footprints[2], footprints[1] + 128 * 1024 * 1024)
            XCTAssertLessThanOrEqual(virtualSizes[2], virtualSizes[1] + 512 * 1024 * 1024)
            let text = try await production(service, spec, image: nil, backend: .cpu,
                text: "What is 2 plus 3? Answer only with the number.", kernel: .builtin)
            XCTAssertTrue(text.contains("5"), text)
        }
        let name = UUID().uuidString + ".jpg"
        try Data([0, 1, 2]).write(to: XCTUnwrap(AttachmentStorage.url(name)))
        let broken = ChatAttachment(kind: .image, name: "synthetic invalid JPEG", storedName: name, imageNames: [name])
        do {
            _ = try await production(service, .e4b, image: broken, backend: .cpu, kernel: .builtin)
            XCTFail("Invalid JPEG unexpectedly accepted")
        } catch { print("NATIVE_EXPECTED_BUILTIN_ERROR \(error.localizedDescription)") }
        let recovered = try await production(service, .e4b, image: green, backend: .cpu, kernel: .builtin)
        XCTAssertTrue(recovered.contains("green") && (recovered.contains("circle") || recovered.contains("circular") || recovered.contains("round")), recovered)
        let switched = try await production(service, .e2b, image: red, backend: .cpu, kernel: .builtin)
        XCTAssertTrue(switched.contains("red") && (switched.contains("square") || switched.contains("rectangle")), switched)
        let data = try JSONEncoder().encode(records)
        print("NATIVE_STABILITY_JSON \(data.base64EncodedString())")
        await service.unload()
    }
    func recovery(_ spec: ModelSpec = .e2b, backend: ExecutionBackend) async throws {
        let service = GemmaService(), image = try await fixture()
        let name = UUID().uuidString + ".jpg"
        try Data([0, 1, 2]).write(to: XCTUnwrap(AttachmentStorage.url(name)))
        let broken = ChatAttachment(kind: .image, name: "synthetic invalid JPEG", storedName: name, imageNames: [name])
        do {
            _ = try await production(service, spec, image: broken, backend: backend)
            XCTFail("Invalid JPEG unexpectedly accepted")
        } catch { print("NATIVE_EXPECTED_ERROR \(error.localizedDescription)") }
        let recovered = try await production(service, spec, image: image, backend: backend)
        XCTAssertTrue(recovered.contains("red"), recovered)
        await service.unload()
    }
}
