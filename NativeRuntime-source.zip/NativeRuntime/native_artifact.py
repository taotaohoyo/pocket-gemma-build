"""Fail-closed validation of the pinned native runtime, on Windows and macOS."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import plistlib
import stat
import struct
import zipfile

BUILD_ID = '0.18.0-pg3'
OFFICIAL_SHA256 = 'd765b99592d4ec3d0c9e2bd69469454af06c834861340672da1891c0c121c347'
FRAMEWORKS = ('CLiteRTLM', 'PGOriginalRuntime', 'PGConstraintProvider')
PLATFORMS = {'ios_arm64': 2, 'ios_sim_arm64': 7}
INSTALL_NAMES = {name: f'@rpath/{name}.framework/{name}' for name in FRAMEWORKS}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def macho(data, platform):
    require(not data.startswith(b'version https://git-lfs.github.com/spec/v1'), 'Git LFS pointer is not a native binary')
    require(len(data) >= 65536, 'Native binary is missing or implausibly small')
    magic, cpu, subtype, kind, count, commands_size, flags, reserved = struct.unpack_from('<8I', data)
    require(magic == 0xFEEDFACF and cpu == 0x0100000C and kind == 6, 'Expected thin ARM64 Mach-O dylib')
    require(0 < count < 10000 and 32 + commands_size <= len(data), 'Invalid Mach-O command table')
    result = {'architecture': 'arm64', 'platform': None, 'dependencies': [], 'installName': None, 'reexports': []}
    offset = 32
    for _ in range(count):
        require(offset + 8 <= 32 + commands_size, 'Truncated Mach-O load command')
        command, size = struct.unpack_from('<2I', data, offset)
        require(size >= 8 and size % 4 == 0 and offset + size <= 32 + commands_size, 'Invalid Mach-O load command bounds')
        if command == 0x32:
            require(size >= 24, 'Truncated LC_BUILD_VERSION')
            actual, minimum, sdk, _ = struct.unpack_from('<4I', data, offset + 8)
            result.update(platform=actual, minimumOS=minimum, sdk=sdk)
        if command in (0xd, 0xc, 0x80000018, 0x8000001f, 0x20, 0x80000023):
            require(size >= 24, 'Truncated dylib load command')
            start = struct.unpack_from('<I', data, offset + 8)[0]
            require(24 <= start < size, 'Invalid dylib name offset')
            raw = data[offset + start:offset + size]
            require(b'\0' in raw, 'Unterminated dylib name')
            name = raw.split(b'\0', 1)[0].decode('utf-8')
            if command == 0xd:
                result['installName'] = name
            else:
                result['dependencies'].append(name)
                if command == 0x8000001f:
                    result['reexports'].append(name)
        offset += size
    require(offset == 32 + commands_size, 'Inconsistent Mach-O command size')
    require(result['platform'] == platform, f'Wrong Mach-O platform: {result["platform"]}, expected {platform}')
    return result

def verify_lfs(source, lock):
    records = []
    require({e['slice'] for e in lock['prebuiltLibraries']} == set(PLATFORMS), 'Missing pinned iOS LFS library')
    for expected in lock['prebuiltLibraries']:
        path = Path(source) / expected['path']
        data = path.read_bytes()
        require(len(data) == expected['bytes'] and sha256(data) == expected['sha256'], f'LFS object hash/size mismatch: {expected["path"]}')
        details = macho(data, PLATFORMS[expected['slice']])
        require(details['installName'] == '@rpath/libGemmaModelConstraintProvider.dylib', 'Unexpected upstream constraint install ID')
        records.append({**expected, 'platform': details['platform']})
    return records

def verify_payload(read, lock):
    receipt = json.loads(read('native-runtime-build.json'))
    require(receipt['buildID'] == BUILD_ID, 'Wrong native build identity')
    require(receipt['sourceRevision'] == lock['upstreamRevision'] and receipt['liteRTSourceRef'] == lock['liteRTRef'], 'Wrong native source pins')
    require(receipt['patchSHA256'] == lock['patchSHA256'] and receipt['originalArtifactSHA256'] == OFFICIAL_SHA256, 'Wrong native patch or provider')
    require(receipt['prebuiltLibraries'] == lock['prebuiltLibraries'], 'Unpinned native LFS inputs')
    require(receipt.get('linkIsolation') == {'lmExportsSHA256': lock['lmExportsSHA256'], 'miniaudioClassName': lock['miniaudioClassName'], 'reexportsProvider': False,
            'runtimeBuiltinSource': 'PGOriginalRuntime C API', 'providerRuntimePatchSHA256': lock['providerRuntimePatchSHA256']},
            'Native runtime lacks the isolated LM C ABI link policy')
    expected_keys = {(name, arch) for name in FRAMEWORKS for arch in PLATFORMS}
    items = receipt['binaries']
    require(len(items) == len(expected_keys) and {(e['name'], e['slice']) for e in items} == expected_keys,
            'Runtime must include all three frameworks for both ARM64 platforms')
    binaries = {}
    for name in FRAMEWORKS:
        info = plistlib.loads(read(f'{name}.xcframework/Info.plist'))
        entries = info['AvailableLibraries']
        require(len(entries) == 2, f'Expected exactly two slices: {name}')
        for entry in entries:
            require(entry['SupportedPlatform'] == 'ios' and entry['SupportedArchitectures'] == ['arm64'], 'Wrong XCFramework architecture/platform')
            variant = entry.get('SupportedPlatformVariant')
            require(variant in (None, 'simulator'), 'Unexpected XCFramework platform variant')
            arch = 'ios_sim_arm64' if variant == 'simulator' else 'ios_arm64'
            prefix = f'{name}.xcframework/{entry["LibraryIdentifier"]}/{entry["LibraryPath"]}'
            require(entry['LibraryPath'] == name + '.framework', 'Unexpected framework path')
            bundle = plistlib.loads(read(prefix + '/Info.plist'))
            require(bundle['CFBundleExecutable'] == name and bundle['CFBundlePackageType'] == 'FMWK', 'Wrong framework bundle metadata')
            data = read(prefix + '/' + name)
            record = next(e for e in items if (e['name'], e['slice']) == (name, arch))
            require(len(data) == record['bytes'] and sha256(data) == record['sha256'], 'Runtime binary hash/size differs from receipt')
            details = macho(data, PLATFORMS[arch])
            require(details['installName'] == INSTALL_NAMES[name], f'Wrong native install ID: {name}')
            for dependency in details['dependencies']:
                require(dependency in INSTALL_NAMES.values() or dependency.startswith(('/System/Library/', '/usr/lib/')),
                        f'Unpackaged non-system native dependency: {dependency}')
            require((name, arch) not in binaries, 'Duplicate runtime slice')
            binaries[(name, arch)] = details
    require(set(binaries) == expected_keys, 'Duplicate or missing XCFramework slice')
    for arch in PLATFORMS:
        deps = binaries[('CLiteRTLM', arch)]['dependencies']
        require(not binaries[('CLiteRTLM', arch)]['reexports'], 'LM must not reexport the original LM/C++ provider')
        require(INSTALL_NAMES['PGOriginalRuntime'] in deps and INSTALL_NAMES['PGConstraintProvider'] in deps,
                'Rebuilt LM is not linked to its packaged runtime providers')
    return receipt

def verify_tree(root, lock):
    root = Path(root).resolve()
    def read(name):
        p = (root / name).resolve()
        require(p.is_relative_to(root), 'Native artifact path escapes root')
        return p.read_bytes()
    return verify_payload(read, lock)

def verify_zip(path, lock):
    path = Path(path)
    require(path.is_file() and path.stat().st_size > 100000, 'Required native ZIP is absent or contains no plausible binaries')
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) and len(names) < 5000, 'Duplicate or excessive native ZIP members')
        require(sum(e.file_size for e in archive.infolist()) < 750000000, 'Native ZIP exceeds bounded extracted size')
        for item in archive.infolist():
            p = PurePosixPath(item.filename)
            require(not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename and ':' not in item.filename,
                    'Unsafe native ZIP member')
            require(not stat.S_ISLNK(item.external_attr >> 16), 'Unexpected native ZIP symlink')
        require(archive.testzip() is None, 'Native ZIP CRC failed')
        return verify_payload(archive.read, lock)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['lfs', 'zip', 'tree'])
    parser.add_argument('path', type=Path)
    args = parser.parse_args()
    lock = json.loads(Path(__file__).with_name('upstream-lock.json').read_text())
    value = verify_lfs(args.path, lock) if args.kind == 'lfs' else (verify_zip if args.kind == 'zip' else verify_tree)(args.path, lock)
    print(json.dumps({'validated': args.kind, 'path': str(args.path), 'binaries': len(value['binaries']) if isinstance(value, dict) else len(value)}, indent=2))
