"""Reject the actual build failure modes before spending a macOS build run."""
from pathlib import Path
import copy
import io
import json
import plistlib
import shutil
import struct
import subprocess
import tempfile
import unittest
import zipfile
from native_artifact import BUILD_ID, FRAMEWORKS, INSTALL_NAMES, OFFICIAL_SHA256, PLATFORMS, macho, sha256, verify_lfs, verify_payload, verify_zip

LOCK = json.loads(Path(__file__).with_name('upstream-lock.json').read_text())

def native(name, platform, deps=()):
    commands = []
    for command, text in [(0xd, INSTALL_NAMES[name])] + [(0xc, d) for d in deps]:
        raw = text.encode() + b'\0'
        size = (24 + len(raw) + 7) // 8 * 8
        commands.append(struct.pack('<6I', command, size, 24, 0, 0, 0) + raw + b'\0' * (size - 24 - len(raw)))
    commands.append(struct.pack('<6I', 0x32, 24, platform, 15 << 16, 26 << 16, 0))
    body = b''.join(commands)
    data = struct.pack('<8I', 0xFEEDFACF, 0x0100000C, 0, 6, len(commands), len(body), 0, 0) + body
    return data.ljust(65536, b'\0')

def payload():
    result = {}
    items = []
    for name in FRAMEWORKS:
        available = []
        for arch, platform in PLATFORMS.items():
            identifier = 'ios-arm64-simulator' if platform == 7 else 'ios-arm64'
            entry = {'LibraryIdentifier': identifier, 'LibraryPath': name + '.framework',
                     'SupportedPlatform': 'ios', 'SupportedArchitectures': ['arm64']}
            if platform == 7:
                entry['SupportedPlatformVariant'] = 'simulator'
            available.append(entry)
            prefix = f'{name}.xcframework/{identifier}/{name}.framework'
            deps = [INSTALL_NAMES['PGOriginalRuntime'], INSTALL_NAMES['PGConstraintProvider']] if name == 'CLiteRTLM' else ['/usr/lib/libSystem.B.dylib']
            data = native(name, platform, deps)
            result[prefix + '/' + name] = data
            result[prefix + '/Info.plist'] = plistlib.dumps({'CFBundleExecutable': name, 'CFBundlePackageType': 'FMWK'})
            items.append({'name': name, 'slice': arch, 'bytes': len(data), 'sha256': sha256(data)})
        result[name + '.xcframework/Info.plist'] = plistlib.dumps({'AvailableLibraries': available})
    receipt = {'buildID': BUILD_ID, 'sourceRevision': LOCK['upstreamRevision'], 'liteRTSourceRef': LOCK['liteRTRef'],
               'patchSHA256': LOCK['patchSHA256'], 'originalArtifactSHA256': OFFICIAL_SHA256,
               'linkIsolation': {'lmExportsSHA256': LOCK['lmExportsSHA256'], 'miniaudioClassName': LOCK['miniaudioClassName'], 'reexportsProvider': False,
                                 'runtimeBuiltinSource': 'PGOriginalRuntime C API', 'providerRuntimePatchSHA256': LOCK['providerRuntimePatchSHA256']},
               'prebuiltLibraries': LOCK['prebuiltLibraries'], 'binaries': items}
    result['native-runtime-build.json'] = json.dumps(receipt).encode()
    return result

class NativeArtifactTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp_root = Path(__file__).resolve().parent.parent / 'build/native-artifact-fixtures'
        cls.temp_root.mkdir(parents=True, exist_ok=True)

    def setUp(self):
        self.files = payload()

    def validate(self):
        return verify_payload(self.files.__getitem__, LOCK)

    def edit_receipt(self, change):
        receipt = json.loads(self.files['native-runtime-build.json'])
        change(receipt)
        self.files['native-runtime-build.json'] = json.dumps(receipt).encode()

    def test_complete_device_and_simulator_payload_is_accepted(self):
        self.assertEqual(len(self.validate()['binaries']), 6)

    def test_old_nonisolated_runtime_receipt_is_rejected(self):
        self.edit_receipt(lambda r: r.pop('linkIsolation'))
        with self.assertRaisesRegex(ValueError, 'isolated LM C ABI'):
            self.validate()

    def test_missing_provider_runtime_import_policy_is_rejected(self):
        self.edit_receipt(lambda r: r['linkIsolation'].pop('runtimeBuiltinSource'))
        with self.assertRaisesRegex(ValueError, 'isolated LM C ABI'):
            self.validate()

    def test_wrong_provider_runtime_patch_is_rejected(self):
        self.edit_receipt(lambda r: r['linkIsolation'].update(providerRuntimePatchSHA256='0' * 64))
        with self.assertRaisesRegex(ValueError, 'isolated LM C ABI'):
            self.validate()

    def test_lm_cannot_reexport_original_provider(self):
        name = 'CLiteRTLM.xcframework/ios-arm64/CLiteRTLM.framework/CLiteRTLM'
        data = bytearray(self.files[name])
        first_size = struct.unpack_from('<I', data, 36)[0]
        struct.pack_into('<I', data, 32 + first_size, 0x8000001f)
        self.files[name] = bytes(data)
        self.edit_receipt(lambda r: r['binaries'][0].update(sha256=sha256(data)))
        with self.assertRaisesRegex(ValueError, 'must not reexport'):
            self.validate()

    def test_lfs_pointer_is_not_a_library(self):
        with self.assertRaisesRegex(ValueError, 'Git LFS pointer'):
            macho(b'version https://git-lfs.github.com/spec/v1\noid sha256:abc\nsize 21054392\n', 2)

    def test_wrong_platform_is_rejected_even_with_arm64(self):
        with self.assertRaisesRegex(ValueError, 'platform'):
            macho(native('CLiteRTLM', 7), 2)

    def test_truncated_load_command_is_rejected(self):
        data = bytearray(native('CLiteRTLM', 2))
        struct.pack_into('<I', data, 36, 0xfffffff0)
        with self.assertRaisesRegex(ValueError, 'bounds'):
            macho(data, 2)

    def test_receipt_cannot_omit_constraint_library(self):
        self.edit_receipt(lambda r: r['binaries'].pop())
        with self.assertRaisesRegex(ValueError, 'all three frameworks'):
            self.validate()

    def test_receipt_cannot_duplicate_device_for_simulator(self):
        self.edit_receipt(lambda r: r['binaries'][0].update(slice=r['binaries'][1]['slice']))
        with self.assertRaisesRegex(ValueError, 'all three frameworks'):
            self.validate()

    def test_changed_native_bytes_are_rejected(self):
        name = 'CLiteRTLM.xcframework/ios-arm64/CLiteRTLM.framework/CLiteRTLM'
        self.files[name] += b'changed'
        with self.assertRaisesRegex(ValueError, 'hash/size'):
            self.validate()

    def test_unpackaged_dependency_is_rejected(self):
        name = 'CLiteRTLM.xcframework/ios-arm64/CLiteRTLM.framework/CLiteRTLM'
        data = native('CLiteRTLM', 2, ['@rpath/libGemmaModelConstraintProvider.dylib'])
        self.files[name] = data
        self.edit_receipt(lambda r: r['binaries'][0].update(sha256=sha256(data), bytes=len(data)))
        with self.assertRaisesRegex(ValueError, 'Unpackaged'):
            self.validate()

    def test_native_payload_round_trip_and_consumer_path(self):
        with tempfile.TemporaryDirectory(dir=self.temp_root) as task_dir:
            target = Path(task_dir) / 'PocketGemma-NativeRuntime.zip'
            with zipfile.ZipFile(target, 'w') as z:
                for name, data in self.files.items(): z.writestr(name, data)
            self.assertEqual(len(verify_zip(target, LOCK)['binaries']), 6)

    def test_zip_with_only_build_log_is_rejected(self):
        with tempfile.TemporaryDirectory(dir=self.temp_root) as task_dir:
            target = Path(task_dir) / 'PocketGemma-NativeRuntime.zip'
            with zipfile.ZipFile(target, 'w') as z: z.writestr('native-rebuild.log', b'link failed')
            with self.assertRaisesRegex(ValueError, 'plausible binaries'):
                verify_zip(target, LOCK)

    def test_zip_cannot_escape_extraction_root(self):
        with tempfile.TemporaryDirectory(dir=self.temp_root) as task_dir:
            target = Path(task_dir) / 'PocketGemma-NativeRuntime.zip'
            with zipfile.ZipFile(target, 'w') as z:
                for name, data in self.files.items(): z.writestr(name, data)
                z.writestr('../unreviewed.py', b'no')
            with self.assertRaisesRegex(ValueError, 'Unsafe'):
                verify_zip(target, LOCK)

    def test_lfs_validation_rejects_pointer_before_build(self):
        with tempfile.TemporaryDirectory(dir=self.temp_root) as task_dir:
            for entry in LOCK['prebuiltLibraries']:
                target = Path(task_dir) / entry['path']; target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(b'version https://git-lfs.github.com/spec/v1\n')
            with self.assertRaisesRegex(ValueError, 'LFS object hash/size'):
                verify_lfs(task_dir, LOCK)

    @unittest.skipUnless(shutil.which('bash') and shutil.which('tee'), 'Bash pipeline reproduction runs on the macOS CI host')
    def test_child_link_failure_reaches_outer_actions_shell(self):
        with tempfile.TemporaryDirectory(dir=self.temp_root) as task_dir:
            command = "bash -c 'exit 37' | tee native-rebuild.log"
            old = subprocess.run(['bash', '-e', '-c', command], cwd=task_dir)
            fixed = subprocess.run(['bash', '-e', '-o', 'pipefail', '-c', command], cwd=task_dir)
            self.assertEqual(old.returncode, 0)
            self.assertEqual(fixed.returncode, 37)

if __name__ == '__main__':
    unittest.main(verbosity=2)
