"""Package every non-system dependency of the patched LM as an XCFramework."""
from pathlib import Path
import json
import plistlib
import shutil
import subprocess
import sys
from native_artifact import BUILD_ID, FRAMEWORKS, INSTALL_NAMES, OFFICIAL_SHA256, PLATFORMS, macho, require, sha256, verify_tree

root = Path('build/NativeRuntime').resolve()
lock = json.loads(Path('NativeRuntime/upstream-lock.json').read_text())
official = root / 'Official/CLiteRTLM.xcframework'
info = plistlib.loads((official / 'Info.plist').read_bytes())
parts = {('ios_sim_arm64' if e.get('SupportedPlatformVariant') == 'simulator' else 'ios_arm64'): e
         for e in info['AvailableLibraries'] if e['SupportedPlatform'] == 'ios' and e['SupportedArchitectures'] == ['arm64']}
require(set(parts) == set(PLATFORMS), 'Official framework is missing a required ARM64 slice')
old_constraint = '@rpath/libGemmaModelConstraintProvider.dylib'

def clear_signature(bundle):
    path = bundle / '_CodeSignature'
    if path.exists():
        shutil.rmtree(path)

def dependency_module(bundle, name):
    for leaf in ('Headers', 'Modules'):
        path = bundle / leaf
        if path.exists():
            shutil.rmtree(path)
        path.mkdir()
    (bundle / 'Headers' / (name + '.h')).write_text('// Dependency-only native module.\n')
    (bundle / 'Modules/module.modulemap').write_text(f'framework module {name} {{ umbrella header "{name}.h" export * }}\n')

def rewrite_constraint_dependency(binary, arch):
    details = macho(binary.read_bytes(), PLATFORMS[arch])
    if old_constraint in details['dependencies']:
        subprocess.run(['install_name_tool', '-change', old_constraint, INSTALL_NAMES['PGConstraintProvider'], str(binary)], check=True)

if sys.argv[1] == 'prepare':
    for arch, entry in parts.items():
        original = official / entry['LibraryIdentifier'] / entry['LibraryPath']
        provider = root / 'Providers' / arch / 'PGOriginalRuntime.framework'
        shutil.copytree(original, provider)
        clear_signature(provider)
        (provider / 'CLiteRTLM').rename(provider / 'PGOriginalRuntime')
        subprocess.run(['install_name_tool', '-id', INSTALL_NAMES['PGOriginalRuntime'], str(provider / 'PGOriginalRuntime')], check=True)
        rewrite_constraint_dependency(provider / 'PGOriginalRuntime', arch)
        dependency_module(provider, 'PGOriginalRuntime')
        details = plistlib.loads((provider / 'Info.plist').read_bytes())
        details.update(CFBundleExecutable='PGOriginalRuntime', CFBundleName='PGOriginalRuntime', CFBundleIdentifier='app.pocketgemma.runtime.provider')
        (provider / 'Info.plist').write_bytes(plistlib.dumps(details))

        constraint = root / 'Providers' / arch / 'PGConstraintProvider.framework'
        constraint.mkdir()
        source = root / 'upstream/prebuilt' / arch / 'libGemmaModelConstraintProvider.dylib'
        original_info = macho(source.read_bytes(), PLATFORMS[arch])
        shutil.copy2(source, constraint / 'PGConstraintProvider')
        subprocess.run(['install_name_tool', '-id', INSTALL_NAMES['PGConstraintProvider'], str(constraint / 'PGConstraintProvider')], check=True)
        dependency_module(constraint, 'PGConstraintProvider')
        minimum = original_info['minimumOS']
        details = {'CFBundleExecutable': 'PGConstraintProvider', 'CFBundleName': 'PGConstraintProvider',
                   'CFBundleIdentifier': 'app.pocketgemma.runtime.constraint', 'CFBundlePackageType': 'FMWK',
                   'CFBundleVersion': '1', 'CFBundleShortVersionString': '0.18.0',
                   'MinimumOSVersion': f'{minimum >> 16}.{(minimum >> 8) & 255}',
                   'CFBundleSupportedPlatforms': ['iPhoneSimulator' if arch == 'ios_sim_arm64' else 'iPhoneOS']}
        (constraint / 'Info.plist').write_bytes(plistlib.dumps(details))
    sys.exit(0)

require(sys.argv[1] == 'finish', 'Unknown native packaging operation')
artifacts = root / 'Artifacts'
artifacts.mkdir()
framework_args = {name: [] for name in FRAMEWORKS}
binaries = []
for arch, entry in parts.items():
    original = official / entry['LibraryIdentifier'] / entry['LibraryPath']
    custom = root / 'Rebuilt' / arch / 'CLiteRTLM.framework'
    shutil.copytree(original, custom)
    shutil.copy2(root / f'{arch}.dylib', custom / 'CLiteRTLM')
    clear_signature(custom)
    rewrite_constraint_dependency(custom / 'CLiteRTLM', arch)
    replaced_headers = []
    for header in (root / 'upstream/c').glob('*.h'):
        matches = list((custom / 'Headers').rglob(header.name))
        if matches:
            require(len(matches) == 1, f'Ambiguous public header: {header.name}')
            shutil.copy2(header, matches[0])
            replaced_headers.append(header.name)
    require('engine.h' in replaced_headers, 'Patched C API header was not installed')
    exported = subprocess.check_output(['nm', '-gU', str(custom / 'CLiteRTLM')], text=True)
    require('_pocket_gemma_engine_settings_set_vision_cpu_kernel_mode' in exported and '_litert_lm_engine_create' in exported,
            'Rebuilt LM lacks the patched or original C API')
    for name in FRAMEWORKS:
        bundle = custom if name == 'CLiteRTLM' else root / 'Providers' / arch / (name + '.framework')
        data = (bundle / name).read_bytes()
        details = macho(data, PLATFORMS[arch])
        require(details['installName'] == INSTALL_NAMES[name], 'Wrong native install ID after packaging')
        framework_args[name] += ['-framework', str(bundle)]
        binaries.append({'slice': arch, 'name': name, 'bytes': len(data), 'sha256': sha256(data),
                         'dependencies': details['dependencies'], 'platform': details['platform']})
for name, options in framework_args.items():
    subprocess.run(['xcodebuild', '-create-xcframework', *options, '-output', str(artifacts / (name + '.xcframework'))], check=True)
receipt = {'baseRuntime': '0.18.0', 'buildID': BUILD_ID, 'sourceRevision': lock['upstreamRevision'],
           'liteRTSourceRef': lock['liteRTRef'], 'patchSHA256': lock['patchSHA256'],
           'originalArtifactSHA256': OFFICIAL_SHA256, 'prebuiltLibraries': lock['prebuiltLibraries'],
           'scope': 'Patched LM resource sharing and explicit CPU vision kernels; official LiteRT provider and pinned constraint dependency.',
           'binaries': binaries}
(artifacts / 'native-runtime-build.json').write_text(json.dumps(receipt, indent=2) + '\n')
verify_tree(artifacts, lock)
shutil.make_archive(str(root / 'PocketGemma-NativeRuntime'), 'zip', artifacts)
print(json.dumps(receipt, indent=2))
